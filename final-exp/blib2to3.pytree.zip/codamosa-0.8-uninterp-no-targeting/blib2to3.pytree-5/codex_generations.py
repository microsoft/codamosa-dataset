

# Generated at 2022-06-21 10:33:10.922387
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert issubclass(BasePattern, object)
    assert BasePattern.type is None
    assert BasePattern.__repr__(None) == 'BasePattern()'


# Generated at 2022-06-21 10:33:22.400368
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    import sys
    import os
    import unittest
    import astunparse

    test_basedir = os.path.dirname(__file__)
    sys.path.insert(0, os.path.join(test_basedir, '..'))

    from astunparse.unparser import BasePattern, NodePattern, LeafPattern, WildcardPattern


    class TestBasePattern(unittest.TestCase):
        def test_BasePattern_optimize(self):
            x = BasePattern()
            self.assertEqual(x.optimize(), x)
            self.assertEqual(x.match(x, None), True)
            self.assertEqual(x.match_seq([x], None), False)
            self.assertEqual(list(x.generate_matches([x])), [])



# Generated at 2022-06-21 10:33:30.886315
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse

    gr = Grammar()
    gr.add_production("file_input", ["NEWLINE", "file_input"])
    gr.add_production("file_input", ["stmt", "file_input"])
    gr.add_production("file_input", [])
    gr.add_production("stmt", ["expr"])
    gr.add_production("expr", ["+"])

    t = parse("+", gr)
    assert t.type == gr.symbol2number["file_input"]
    assert len(t.children) == 1
    t = t.children[0]
    assert t.type == gr.symbol2number["stmt"]
    assert len(t.children) == 1
    t = t

# Generated at 2022-06-21 10:33:43.893270
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    a = Node(1, [])
    b = Node(2, [])
    c = Node(3, [])
    d = Node(4, [])
    e = Node(5, [])
    f = Node(6, [])
    g = Node(7, [])
    h = Node(8, [])
    i = Node(9, [])
    j = Node(10, [])
    x = Node(11, [a, b, c, d, e, f, g, h, i, j])
    x.update_sibling_maps()

# Generated at 2022-06-21 10:33:52.340278
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # (a b)*
    n1 = NodePattern(type=257, content=(LeafPattern(type=1, content='a'), LeafPattern(type=1, content='b')))
    n2 = NodePattern(type=257, content=(LeafPattern(type=1, content='a'), LeafPattern(type=1, content='b')))
    n3 = NodePattern(type=257, content=(LeafPattern(type=1, content='a'), LeafPattern(type=1, content='b')))
    n4 = NodePattern(type=257, content=(LeafPattern(type=1, content='a'), LeafPattern(type=1, content='b')))
    n5 = NodePattern(type=257, content=(LeafPattern(type=1, content='a'), LeafPattern(type=1, content='b')))
    w

# Generated at 2022-06-21 10:33:55.953191
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, 'whats up?')
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-21 10:34:03.004173
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    def m(arg): return arg
    class SubPattern(BasePattern):
        def __init__(self, type, content): pass
        def _submatch(self, node, results): return m(results) is not None
        def match_seq(self, nodes, results): pass
    p = SubPattern(1, 2)
    assert isinstance(p.generate_matches([3]), Iterator)
    assert isinstance(next(p.generate_matches([3])), tuple)


# Generated at 2022-06-21 10:34:15.380766
# Unit test for method set_child of class Node
def test_Node_set_child():
    for name, value in globals().items():
        if hasattr(value, "orig_node"):
            if isinstance(value, Node):
                print("Node", value.type, name)
                assert value.type == value.orig_node.type
                try:
                    assert value.children == value.orig_node.children
                except AssertionError:
                    print("children")
                    raise
                assert value.parent is None
                assert value.was_changed is False
                assert value.was_checked is False
                assert value.fixers_applied == value.orig_node.fixers_applied
            elif isinstance(value, Leaf):
                print("Leaf", value.type, name)
                assert value.type == value.orig_node.type
                assert value.value == value.orig_node.value


# Generated at 2022-06-21 10:34:16.951123
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """Unit test for method __new__ of class BasePattern"""
    BasePattern()


# Generated at 2022-06-21 10:34:23.364571
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    n = NegatedPattern(pattern_parse("asdf", "asdf"))
    assert n.match_seq(["asdf"])

    n = NegatedPattern(pattern_parse("asdf", "asdf"))
    assert not n.match_seq(["asdf", "asdf"])

    n = NegatedPattern(None)
    assert n.match_seq([])



# Generated at 2022-06-21 10:34:48.781992
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, value="1", context=None, prefix=None, fixers_applied=[])
    assert next(leaf.post_order()) == leaf


# Generated at 2022-06-21 10:34:50.766578
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    for leaf in _make_one_node_and_its_clone().post_order():
        assert leaf.clone() == leaf


# Generated at 2022-06-21 10:34:52.440763
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .test_pattern import test2  # :: "test2"

    results = list(pattern_ut.generate_matches(test2, "next", [test2]))
    assert results == [(1, {"node": test2})]

# Generated at 2022-06-21 10:35:01.904830
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import pickle
    from mypy.test.testutils import TestCase


# Generated at 2022-06-21 10:35:03.887265
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(3) in ("NAME", 3)


T = TypeVar("T")



# Generated at 2022-06-21 10:35:10.067795
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    with pytest.raises(AssertionError):
        NegatedPattern(0)
    assert negates_match(NegatedPattern())
    assert not negates_match(NegatedPattern(LeafPattern()))
    assert negates_match(NegatedPattern(
        NegatedPattern(WildcardPattern(min=1))))



# Generated at 2022-06-21 10:35:12.196836
# Unit test for constructor of class NodePattern
def test_NodePattern():
    NodePattern()
    NodePattern(1)
    NodePattern(1, "ab")
    NodePattern(1, "ab", "c")
    # Invalid argument types.  These should raise some kind of assertion
    # error.
    # NodePattern(type="")
    # NodePattern(content=1)
    # NodePattern(content=1, name=1)



# Generated at 2022-06-21 10:35:15.571777
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import inspect
    # We are only interested in the first argument
    # in the definition of the method match
    argspec = inspect.getargspec(BasePattern.match)
    assert argspec.args == ["self", "node", "results"]



# Generated at 2022-06-21 10:35:24.611348
# Unit test for method set_child of class Node
def test_Node_set_child():
    from . import pytree
    from .pygram import python_symbols as sympy
    from .pygram import python_grammar
    import lib2to3.fixes
    n = pytree.Node(sympy.file_input, [])
    def_list = pytree.Node(sympy.funcdef, [], [n])
    n.append_child(def_list)
    def_list.append_child(pytree.Leaf(0, "def"))
    def_list.append_child(pytree.Leaf(1, " "))
    def_list.append_child(pytree.Leaf(1, "f"))
    def_list.append_child(pytree.Leaf(0, "("))

# Generated at 2022-06-21 10:35:33.324960
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    # Pattern with a single alternative (a b c)
    pattern = WildcardPattern([["a", "b", "c"]])
    assert pattern.match(Node(ord("a"), [Leaf(ord("a"))]))
    assert pattern.match(Node(ord("b"), [Leaf(ord("b"))]))
    assert pattern.match(Node(ord("c"), [Leaf(ord("c"))]))
    assert not pattern.match(Node(ord("d"), [Leaf(ord("d"))]))

# Generated at 2022-06-21 10:35:52.638864
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    node = Node(257, [])
    node.insert_child(0, Leaf(1, ""))
    assert node.children == [Leaf(1, "")]
    node.insert_child(0, Leaf(1, ""))
    assert node.children == [Leaf(1, ""), Leaf(1, "")]
    node.insert_child(1, Leaf(1, ""))
    assert node.children == [Leaf(1, ""), Leaf(1, ""), Leaf(1, "")]


# Generated at 2022-06-21 10:36:02.345984
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node, Base

    n = Node(
        [Leaf(1, lineno=1), Leaf(2, lineno=2), Leaf(3, lineno=3),
            Leaf(4, lineno=4)])
    assert n.remove() is None
    assert n.children[0].remove() == 0
    assert n.children[0].remove() is None
    assert n.children[1].remove() == 0
    assert n.children[0].remove() == 0
    assert n.children[0].remove() is None



# Generated at 2022-06-21 10:36:04.296333
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    node = Leaf(type=1, value="foo")
    assert list(node.pre_order()) == [node]


# Generated at 2022-06-21 10:36:11.608804
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    l = Leaf(0, "")
    assert l.__str__() == ""
    assert l.prefix == ""
    l = Leaf(0, "x")
    assert l.__str__() == "x"
    assert l.prefix == ""
    l = Leaf(0, "x", (0, 0))
    assert l.__str__() == "x"
    assert l.prefix == ""
    l = Leaf(0, "x", prefix="\n")
    assert l.__str__() == "\nx"
    assert l.prefix == "\n"


# Generated at 2022-06-21 10:36:22.630180
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    p = WildcardPattern([[Leaf(0, "a")], [Leaf(0, "b")]], min=2)
    assert p.match_seq([Leaf(0, "a"), Leaf(0, "b")])
    assert p.match_seq([Leaf(0, "a"), Leaf(0, "a"), Leaf(0, "a"), Leaf(0, "b")])
    assert not p.match_seq([Leaf(0, "a")])
    assert not p.match_seq([Leaf(0, "a"), Leaf(0, "a"), Leaf(0, "b"), Leaf(0, "b")])
    p = WildcardPattern([[Leaf(0, "a")], [Leaf(0, "b")]], min=3)

# Generated at 2022-06-21 10:36:34.340545
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    import io
    from pgen2 import parse


# Generated at 2022-06-21 10:36:37.674500
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    x = Leaf(0, "0", context=("1", (1, 1)))
    assert list(x.post_order()) == [x]


# Generated at 2022-06-21 10:36:48.836948
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class NodePattern(BasePattern):  # NodePattern
        def _submatch(self, node, results=None):
            return results is None or node.type in results

    s = [0, 1, 2, 3, 1, 4, 5, 5, 4, 6, 7, 8, 9]

    class S(Node):

        def leaves(self):
            yield self

    n = S(0, [S(i) for i in s])

    class P(NodePattern):  # P
        type = 0

    a = P()

    assert list(a.generate_matches(list(n.leaves()))) == [(14, {})]
    a.type = 1
    assert list(a.generate_matches(list(n.leaves()))) == []
    a.type = 2

# Generated at 2022-06-21 10:36:57.840536
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern([[NodePattern()]])
    assert p.min == 1 and p.max == 1 and p.content == (((NodePattern(),),),)
    p = WildcardPattern(min=1)
    assert p.min == 1 and p.max == HUGE and p.content is None
    p = WildcardPattern(max=2)
    assert p.min == 0 and p.max == 2 and p.content is None
    p = WildcardPattern(min=1, max=2)
    assert p.min == 1 and p.max == 2 and p.content is None
    # Other cases are already tested by optimize()



# Generated at 2022-06-21 10:36:59.247752
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    bp = BasePattern()
    assert bp is not None



# Generated at 2022-06-21 10:37:33.055530
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from mypy.grammar import Grammar
    from mypy.lex import lex

    def test_gram(source, expected_repr):
        ast = Grammar.program(lex(source))
        assert str(ast.children[0].children[0].pattern.optimize()) == expected_repr

    test_gram('x = 1', "NodePattern(type='simple_stmt', content=[[LeafPattern(type=258, content='=')], [StarListPattern(content=[[NodePattern()]])]], name='node')")
    test_gram('x = 1 if 2 else 3\n', "NodePattern(type='simple_stmt', content=[[LeafPattern(type=258, content='=')], [StarListPattern(content=[[NodePattern()]])]], name='node')")

# Generated at 2022-06-21 10:37:40.118444
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node1 = Node(syms.decorator, [Leaf(1, '[')])
    assert repr(node1) == 'Node(decorator, [Leaf(1, \'?\')])'
    assert str(node1) == '['


# Generated at 2022-06-21 10:37:47.372076
# Unit test for method clone of class Node
def test_Node_clone():
    """ Unit test for method clone of class Node """
    print_verbose('testing Node.clone')
    # Test creation of empty node
    node = Node(1, [])
    assert node.type == 1
    assert node.children == []
    assert node.parent is None
    # Test creation of non-empty node
    leaf1 = Leaf(1, 'a')
    leaf2 = Leaf(1, 'b')
    node2 = Node(2, [leaf1, leaf2])

    assert leaf1.parent == node2
    assert leaf2.parent == node2
    assert node2.type == 2
    assert node2.children == [leaf1, leaf2]
    assert node2.parent is None
    # Test equality
    node3 = Node(2, [leaf1, leaf2])
    assert node2 == node3
   

# Generated at 2022-06-21 10:37:54.579327
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class MyPattern(BasePattern):
        def __init__(self, type, content, name):
            super().__init__(type, content, name)
    p1 = MyPattern(1, 2, 3)
    p2 = MyPattern(1, None, 3)
    p3 = MyPattern(None, 2, 3)
    p4 = MyPattern(None, None, 3)
    assert p1.match_seq([]) is False
    assert p1.match_seq([]) is False
    assert p1.match_seq([1]) is False
    assert p1.match_seq([2]) is False
    assert p1.match_seq([3]) is False
    assert p1.match_seq([1, 2]) is False
    assert p1.match_seq([1, 3]) is False

# Generated at 2022-06-21 10:37:59.814177
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    _1 = Node(0, [])
    _2 = Leaf(0, "")
    _3 = Node(0, [])
    _2.parent = _1
    _3.parent = _1
    _1.children.extend([_2, _3])
    assert list(_1.pre_order()) == [_1, _2, _3]



# Generated at 2022-06-21 10:38:06.763454
# Unit test for method __new__ of class Base
def test_Base___new__():
    from .pytree_builder import PyTreeVisitor
    from .pytree import Node
    from .pygram import python_symbols

    class Test(PyTreeVisitor):
        def visit_file_input(self, node):
            return node

    tree = Node(python_symbols.file_input, [])

    vis = Test()
    new = vis.visit(tree)


# Generated at 2022-06-21 10:38:16.848940
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    class TestWildcardPattern_match(unittest.TestCase):
        def test_case1(self):
            pattern = Pattern('stmt*')

# Generated at 2022-06-21 10:38:28.373202
# Unit test for constructor of class NodePattern
def test_NodePattern():
    assert NodePattern(None, []).type is None
    assert NodePattern(None, []).content == []
    assert NodePattern(None, [LeafPattern(1)]).type is None
    assert NodePattern(None, [LeafPattern(1)]).content == [LeafPattern(1)]
    assert NodePattern(257, [LeafPattern(1)]).type == 257
    assert NodePattern(257, [LeafPattern(1)]).content == [LeafPattern(1)]
    assert NodePattern(257, [LeafPattern(1)], "x").type == 257
    assert NodePattern(257, [LeafPattern(1)], "x").content == [LeafPattern(1)]
    assert NodePattern(257, [LeafPattern(1)], "x").name == "x"



# Generated at 2022-06-21 10:38:32.122331
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf("test", "")
    l2 = Leaf("test", "", prefix=("hello", (1, 1)))
    assert l.type == "test"
    assert l.value == ""
    assert l.prefix == ""
    assert l.lineno == 0
    assert l.column == 0
    assert l2.prefix == "hello"
    assert l2.lineno == 1
    assert l2.column == 1


# Generated at 2022-06-21 10:38:39.791044
# Unit test for constructor of class NodePattern
def test_NodePattern():
    NodePattern(257, ("<any-string>",), "test")
    NodePattern(type=257, content=("<any-string>",), name="test")
    NodePattern(257, ("<any-string>", "<any-string>"))
    NodePattern(type=257, content=("<any-string>", "<any-string>"))
    NodePattern(257, 401)
    NodePattern(type=257, content=(401,))
    NodePattern(257, [401, 402], "test")
    NodePattern(type=257, content=[401, 402], name="test")
    NodePattern(257, ["<any-string>", 401], "test")
    NodePattern(type=257, content=["<any-string>", 401], name="test")

# Generated at 2022-06-21 10:39:44.405459
# Unit test for method optimize of class WildcardPattern

# Generated at 2022-06-21 10:39:50.897677
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # This is a basic test on the Base class preorder method
    e = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Node(1, [Leaf(1, "c")])])
    assert list(e.pre_order()) == [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), e]
    e = Node(1, [])
    assert list(e.pre_order()) == [e]



# Generated at 2022-06-21 10:40:01.188186
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node
    from .parse import Symbol
    node = Node(Symbol.or_expr, [
        Leaf(1, "a"),
        Node(Symbol.or_expr, [
            Leaf(1, "b"),
            Leaf(1, "c"),
        ]),
        Node(Symbol.or_expr, [
            Node(Symbol.or_expr, [
                Node(Symbol.or_expr, [
                    Node(Symbol.or_expr, [
                        Node(Symbol.or_expr, [
                            Node(Symbol.or_expr, [
                                Leaf(1, "d")
                            ])
                        ])
                    ])
                ]),
                Leaf(1, "e"),
            ]),
        ]),
    ])
    cloned = node.clone()

# Generated at 2022-06-21 10:40:03.609842
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    pattern=NegatedPattern([StringPattern('a'),NodePattern(2)])
    result=pattern.match(core.String('a'))
    assert result == False

# Generated at 2022-06-21 10:40:12.883581
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    p = WildcardPattern([[LeafPattern(token.NAME)], [LeafPattern(token.NUMBER)]])
    assert p.match([Leaf(token.NAME, "a"), Leaf(token.NUMBER, "1")])
    assert not p.match([Leaf(token.NUMBER, "1"), Leaf(token.NUMBER, "1")])
    p = WildcardPattern([[LeafPattern(token.NAME)], []])
    assert p.match([Leaf(token.NAME, "a")])
    assert p.match([])
    assert not p.match([Leaf(token.NUMBER, "1")])



# Generated at 2022-06-21 10:40:20.784309
# Unit test for function convert
def test_convert():
    from .pgen2 import driver

    g = driver.load_grammar(grammar)
    t = g.driver.parsed_tokens()
    assert convert(g, t[2]) == Node(257, [Leaf(1, 'def', (5, 0)), Leaf(2, 'f', (5, 4))])
    if parser.__version__ < "3.5":
        assert convert(g, t[3]) == Node(258, [Leaf(3, '(', (5, 6)), Leaf(4, ')', (5, 7)), Leaf(5, ':', (5, 8))])

# Generated at 2022-06-21 10:40:21.524769
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pass



# Generated at 2022-06-21 10:40:31.680013
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():

    def wc(alt, min=0, max=HUGE, name=None):
        return WildcardPattern(alt, min, max, name)

    def n(type, content=None, name=None):
        return NodePattern(type, content, name)

    def l(type, content, name=None):
        return LeafPattern(type, content, name)

    # Test normal cases
    def check(pattern, target, matches):
        items = list(pattern.generate_matches(target))
        assert len(items) == len(matches), "%s %s %s %s" % (
            pattern,
            target,
            items,
            matches,
        )

# Generated at 2022-06-21 10:40:37.667304
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node, Leaf
    tree = Node(1, [])
    assert tree.depth() == 0
    tree.parent = Node(2, [])
    assert tree.depth() == 1
    tree = Leaf(1, "")
    assert tree.depth() == 0
    tree.parent = Node(2, [])
    # TODO: Fix assert tree.depth() == 1



# Generated at 2022-06-21 10:40:45.858047
# Unit test for method post_order of class Base
def test_Base_post_order():
    import unittest
    from .pgen2.tokenize import generate_tokens

    grammar = Grammar()

    class Checker:
        def __init__(self):
            self.checks = []
            self.tokens = []

        def add_check(self, check):
            self.checks.append(check)

        def add_token(self, check):
            self.tokens.append(check)

    checker = Checker()
    checker.add_check(lambda x: '\n' in x.prefix or sys.version_info < (3, 0))

    def test_code(code):
        # type: (Text) -> None
        for token in generate_tokens(StringIO(code).readline):
            if token.type == 0:  # ENDMARKER
                break