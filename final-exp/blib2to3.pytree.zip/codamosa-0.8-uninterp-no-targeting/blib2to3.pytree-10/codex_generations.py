

# Generated at 2022-06-21 10:33:24.533815
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Node # type: ignore
    import sys
    import os

    class Dummy:
        def __init__(self):
            self.prefix = ""
            self.parent = None

        def clone(self):
            return self

    node = Node(257, [Dummy(), Dummy()])
    child = Dummy()
    child.parent = node
    node.set_child(0, child)
    assert node.children[0].parent == node


# Generated at 2022-06-21 10:33:36.850494
# Unit test for method post_order of class Base
def test_Base_post_order():
    import random
    import pytree

    g = Grammar()

    def test_nodes(n1: Union[List[pytree.Base], pytree.Base],
                   n2: Union[List[pytree.Base], pytree.Base]) -> None:
        for n in n1.post_order():
            assert n in n1
        for n in n2.post_order():
            assert n in n2
        for n in n1.post_order():
            assert n in n2
        for n in n2.post_order():
            assert n in n1

    # Part 1
    random.seed(2)
    for i in range(100):
        n1 = g.parse("")
        n2 = g.parse("")
        test_nodes(n1, n2)

# Generated at 2022-06-21 10:33:48.353521
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    pattern = WildcardPattern([[LeafPattern(type=python_tokens.NAME)]], min=1, max=1)
    node = Node(
        value="func_name",
        type=python_symbols.funcdef,
        children=[
            Node(
                value="module_name",
                type=python_symbols.file_input,
                children=[
                    Leaf(value="def", type=python_tokens.NAME),
                ],
            )
        ],
    )
    result = list(pattern.generate_matches(node.children[0].children))
    assert len(result) == 1
    assert result[0][0] == 1
    assert len(result[0][1]) == 1

# Generated at 2022-06-21 10:33:54.840654
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    class L(Leaf):
        def pre_order(self):
            for node in [self]:
                yield node
    class N(Node):
        def pre_order(self):
            for node in [self]:
                yield node
            for child in self.children:
                yield from child.pre_order()
    a = L(1, 2)
    b = L(3, 4)
    c = L(0, 0)
    d = L(9, 17)
    n = N(99, [a, b, c, d])
    assert n.pre_order() == [n, a, b, c, d]



# Generated at 2022-06-21 10:33:57.280631
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "a", None)
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-21 10:34:03.316062
# Unit test for function convert
def test_convert():
    import pgen2.parsed_grammar

    gr = pgen2.parsed_grammar.grammar
    for node in gr.build_parser().parse("foo").post_order():
        assert isinstance(node, (Node, Leaf))
test_convert()



# Generated at 2022-06-21 10:34:14.206341
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf

    # Test the Node.set_child method.

    # Create a Node object and set its children to a list of Leaf objects.
    t = Node(1, [Leaf(1, "first"), Leaf(2, "second"), Leaf(3, "third")])

    # Push a Leaf object on the front of the list.
    l = Leaf(1, "firstA")
    t.insert_child(0, l)

    # Verify that the node is first in the child list.
    assert t.children[0] is l
    # Verify that the node's parent is the parent Node.
    assert l.parent is t



# Generated at 2022-06-21 10:34:17.859214
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    import blib2to3.pytree
    import blib2to3.pgen2.token
    node = blib2to3.pytree.Leaf(blib2to3.pgen2.token.NAME, 'x',
                                (1, 2))
    assert node.get_lineno() == 1


# Generated at 2022-06-21 10:34:24.474949
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pgen2 import token
    stmt = Node(
        python_symbols.single_input,
        [
            Leaf(token.NAME, "x"),
            Leaf(token.EQUAL, "="),
            Leaf(token.NAME, "y"),
            Leaf(token.PLUS, "+"),
            Leaf(token.NAME, "z"),
        ],
    )
    stmt.insert_child(3, Leaf(token.RBRACE, "}"))
    assert stmt.children == [
        Leaf(token.NAME, "x"),
        Leaf(token.EQUAL, "="),
        Leaf(token.NAME, "y"),
        Leaf(token.RBRACE, "}"),
        Leaf(token.PLUS, "+"),
        Leaf(token.NAME, "z"),
    ]
   

# Generated at 2022-06-21 10:34:35.643744
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class ConcretePattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

    p = ConcretePattern(type=3)
    assert p.match_seq([Leaf(type=3)])
    assert not p.match_seq([])
    assert not p.match_seq([Leaf(type=2)])
    assert not p.match_seq([Leaf(type=3), Leaf(type=4)])
    assert p.match_seq([Leaf(type=3)], {})
    assert not p.match_seq([Leaf(type=2)], {})
    results = {}
    p.match_seq([Leaf(type=3, value="a")], results)
   

# Generated at 2022-06-21 10:34:55.638863
# Unit test for method post_order of class Base

# Generated at 2022-06-21 10:35:03.236309
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.grammar import Grammar
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    import sys
    g = Grammar()
    d = Driver(g, convert)
    try:
        g.parse(sys.modules[__name__].__file__, "simpleexpr_test")
    except ParseError as err:
        print(err.nice_error_message(filename=sys.modules[__name__].__file__))
        raise SystemExit
    from .pgen2.tokenize import generate_tokens
    from .pgen2.parse import parse
    from .pgen2.pgen import GrammarError
    from .pgen2.token import tok_name
    c = d.parse("1 + 2", "eval_input")
   

# Generated at 2022-06-21 10:35:14.700519
# Unit test for method __eq__ of class Base
def test_Base___eq__():

    class Sub(Base):

        type = NAME
        context = None
        children = []

        def _eq(self, other: "Sub") -> bool:
            return True

        def clone(self: "Sub") -> "Sub":
            from .pyparse import Node

            return Sub(self.type, self.context, self.children)

        def post_order(self) -> Iterator[Base]:
            yield self

        def pre_order(self) -> Iterator[Base]:
            yield self

    a = Sub(NAME, None, [])
    b = Sub(NAME, None, [])
    assert a == b
    c = Sub(NAME, None, [])
    c.children = [c]
    assert a != c
    d = Sub(NAME, Leaf(NAME, "foo"), [])
    assert a != d



# Generated at 2022-06-21 10:35:21.180852
# Unit test for method leaves of class Base
def test_Base_leaves():
    x = Leaf(0, 'x')
    y = Leaf(0, 'y')
    z = Leaf(0, 'z')
    node = Node(1, [x, y, z])
    assert list(node.leaves()) == [x, y, z]
    assert list(x.leaves()) == [x]
    assert list(y.leaves()) == [y]
    assert list(z.leaves()) == [z]

# Generated at 2022-06-21 10:35:28.115483
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    for i in range(100):
        x = []
        for j in range(i):
            x.append(WildcardPattern())
        if x == []:
            x.append(WildcardPattern())
        assert WildcardPattern(x).match_seq([]), i
        assert not WildcardPattern(x).match_seq([Leaf(token.NAME, "*")]), i



# Generated at 2022-06-21 10:35:33.060238
# Unit test for method remove of class Base
def test_Base_remove():
    from copy import copy

    root = Node(1, [Leaf(1, "test")])

    children = copy(root.children)
    assert children == root.children
    assert root.children[0] == root.children and root.children[0] is root.children

    root.children[0].remove()
    assert root.children != children


# Generated at 2022-06-21 10:35:42.656302
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.nt_item) == "nt_item"
    assert type_repr(python_symbols.l_item) == "l_item"
    assert type_repr(python_symbols.r_item) == "r_item"
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(2) == "NAME"
    assert type_repr(python_symbols.COMMENT) == "COMMENT"
    assert type_repr(python_symbols.INDENT) == "INDENT"



# Generated at 2022-06-21 10:35:45.277487
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    r = Leaf(1, "v0")
    result = [n for n in r.post_order()]
    assert result == [r]


# Generated at 2022-06-21 10:35:52.144649
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    source = 'A.B()'
    tree = astroid.extract_node(source)
    call = tree.body[0].value

    # default
    clone = call.clone()
    assert isinstance(clone, astroid.Call)
    assert clone.func.attrname == 'B'
    assert clone.func.expr.name == 'A'
    assert clone.args == []

    # non default
    name = call.func.expr.clone()
    assert isinstance(name, astroid.Name)
    assert name.name == 'A'



# Generated at 2022-06-21 10:36:04.560036
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():

    class NodeMock(Node):
        def __init__(self, type, children, context=None, prefix=None,
                     fixers_applied=None):
            self.type = type
            self.children = children
            self.fixers_applied=fixers_applied

        def __repr__(self):
            return "%s(%s, %r)" % (self.__class__.__name__, type_repr(self.type), self.children)

    from .pygram import python_symbols
    from .pgen2 import token

    children_mock_list = [Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c")]

# Generated at 2022-06-21 10:36:19.647841
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    t = LeafPattern(content='a')
    assert t.type is None
    assert t.content == 'a'
    assert t.name is None
    t = LeafPattern(type=42, content='a', name='test')
    assert t.type == 42
    assert t.content == 'a'
    assert t.name == 'test'



# Generated at 2022-06-21 10:36:21.326977
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(1, [])
    assert repr(node) == "Node(1, [])"


# Generated at 2022-06-21 10:36:28.290630
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    import StringIO

    f = StringIO.StringIO("\n")
    t = Leaf(token.NEWLINE, "\n", (1, 0), (1, 1), f)
    assert not t.was_changed
    t.changed()
    assert t.was_changed

    g = Leaf(token.INDENT, "    ", (2, 0), (2, 4), f)

    class dummyNode(Node):
        def _eq(self, other):
            return True

        def clone(self):
            return self

        def post_order(self):
            return iter([])

        def pre_order(self):
            return iter([])


# Generated at 2022-06-21 10:36:40.778959
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():


  # Testing function match of class WildcardPattern
  WildcardPattern(content=None, min=0, max=1, name='rp').match(nodes=Node(2, [Leaf(1, '1'), Leaf(1, '2')]), results=None)
  # Testing function match of class WildcardPattern
  WildcardPattern(content=None, min=0, max=1, name='rp').match(nodes=Node(2, [Leaf(1, '1'), Leaf(1, '2'), Leaf(1, '3')]), results=None)
  # Testing function match of class WildcardPattern

# Generated at 2022-06-21 10:36:51.252058
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    line = "print 'Welcome to GeeksforGeeks'"
    line_tokens = [
        Leaf(307, "print", (1, 0)),
        Leaf(1, " ", (1, 5)),
        Leaf(417, "'Welcome to GeeksforGeeks'", (1, 6)),
    ]
    test_node2 = Node(308, line_tokens, (1, 0))
    assert test_node2.get_child(-1).prefix == "'Welcome to GeeksforGeeks'"
    child = Leaf(418, "Isn't it wonderful?", (1, 6))
    test_node2.insert_child(-1, child)
    assert test_node2.get_child(-1).prefix == "'Isn't it wonderful?'"

# Generated at 2022-06-21 10:36:58.684459
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert repr(BasePattern(1)) == "BasePattern(None, None, None)"
    assert repr(BasePattern(1, 2, 3)) == "BasePattern(1, 2, 3)"
    assert repr(BasePattern(1, None, 3)) == "BasePattern(1, 3)"
    assert repr(BasePattern(1, 2)) == "BasePattern(1, 2, None)"
    try:
        BasePattern()
    except TypeError:
        pass
    else:
        raise TestFailed



# Generated at 2022-06-21 10:37:02.223112
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    node = Leaf(0, "abc")
    assert list(node.leaves()) == [node]


# Generated at 2022-06-21 10:37:06.895218
# Unit test for method append_child of class Node
def test_Node_append_child():
    from ...python_tree import Leaf

    node = Node(1, [])
    leaf = Leaf(1, "")
    node.append_child(leaf)

    assert leaf in node.children
    assert node.children[-1] is leaf
    assert node is leaf.parent
    assert node.was_changed



# Generated at 2022-06-21 10:37:14.868173
# Unit test for method __str__ of class Node
def test_Node___str__():


    # Test leaves
    o = Leaf(1, "some text", (1, 0))
    assert str(o) == "some text"

    o = Leaf(1, "some text")
    assert str(o) == "some text"


    # Test simple node
    o = Node(1, [Leaf(1, "some text", (1, 0))], (1, 0))
    assert str(o) == "some text"

    o = Node(1, [Leaf(1, "some text", (1, 0))])
    assert str(o) == "some text"

    o = Node(1, [Leaf(1, "some text")])
    assert str(o) == "some text"


# Generated at 2022-06-21 10:37:25.237016
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    import sys;sys.path.append("/home/travis/build/python/cpython")
    from .pattern_lib import pgen2_grammar

    def __str__(self):
        return "%s(%d, %r, %r)" % (
            self.__class__.__name__,
            self.type,
            self.value,
            self.prefix,
        )

    def _submatch(self, node, results=None):
        return self.content == node.value

    def check_pattern(pattern, input, should_match):
        leaf = Leaf(42, input)

# Generated at 2022-06-21 10:37:40.836955
# Unit test for method depth of class Base
def test_Base_depth():
    from . import pytree
    test_node = pytree.Node(type=0)
    assert test_node.depth() == 0
    test_child = pytree.Node(type=0, children=[test_node])
    assert test_node.depth() == 1


# Generated at 2022-06-21 10:37:44.403028
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    t = [1, 2, 3, 4, 5]
    # empty sequences always match
    assert NegatedPattern().match_seq([])
    # we cannot match the entire sequence if content is a non-None pattern
    assert not NegatedPattern(t).match_seq([1, 2, 3, 4])
    # the match is trivial if the entire sequence is not covered by the pattern
    assert NegatedPattern(t).match_seq([1, 2, 3])
    # the match is trivial if the entire sequence is not covered by the pattern
    assert NegatedPattern([[1, 2], [3, 4]]).match_seq([1, 2, 3, 4])

# Generated at 2022-06-21 10:37:51.404636
# Unit test for method post_order of class Base
def test_Base_post_order():
  from .pytree import Leaf, Node, Base

  assert list(Leaf(10, "foo").post_order()) == [Leaf(10, "foo")]
  assert list(Node(10, [Leaf(10, "foo"), Leaf(11, "bar")]).post_order()) == [
      Leaf(10, "foo"), Leaf(11, "bar"), Node(10, [Leaf(10, "foo"), Leaf(11, "bar")])
  ]



# Generated at 2022-06-21 10:37:58.335413
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import unittest
    from test.test_support import run_unittest
    import parser

    class WildcardPatternTest(unittest.TestCase):
        def test_match_seq(self):
            #
            # Verify escape sequences are decoded
            #
            pat1 = WildcardPattern(content=((LeafPattern(type=token.STRING, content=r"\n"),),))
            pat2 = WildcardPattern(content=((LeafPattern(type=token.STRING, content="\n"),),))
            source1 = parser.suite("f('''\\n''')")
            source2 = parser.suite("f('''\n''')")
            self.assertTrue(pat1.match_seq(source1))
            self.assertTrue(pat2.match_seq(source2))


# Generated at 2022-06-21 10:38:11.035910
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from .pygram import python_symbols as syms

    def WildcardPattern_match_seq(nodes, min=0, max=HUGE, content=None):
        nodes = tuple(nodes)
        if content is None:
            content = [[NodePattern()]]
        return tuple(
            WildcardPattern(
                min=min, max=max, content=tuple(map(tuple, content))
            ).generate_matches(nodes)
        )

    def NodePattern_match(node, *, type=None, content=None):
        if type is None and content is None:
            return False
        if type is not None:
            assert 0 <= type < 256, type
        if content is not None:
            assert isinstance(content, str), repr(content)

# Generated at 2022-06-21 10:38:14.928372
# Unit test for constructor of class Node
def test_Node():
    """
    >>> n = Node(1, [Leaf(2, ""), Leaf(3, "")])
    >>> n.children
    [Leaf(type=2, value='', context=None), Leaf(type=3, value='', context=None)]
    """
    pass



# Generated at 2022-06-21 10:38:26.396243
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp = WildcardPattern(None, 1, 1, "foo")
    assert wp.optimize() == NodePattern(name="foo")
    assert not isinstance(wp.optimize(), WildcardPattern)
    wp = WildcardPattern([[Literal("foo")], [Literal("bar")]], 1, 1, "foo")
    assert isinstance(wp.optimize(), WildcardPattern)
    wp = WildcardPattern(None, 2, 2, "foo")
    assert wp.optimize() == wp
    wp = WildcardPattern([[Literal("foo")], [Literal("bar")]], 2, 2, "foo")
    assert isinstance(wp.optimize(), WildcardPattern)

# Generated at 2022-06-21 10:38:32.149993
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    # Test the LeafPattern class
    from .pgen2 import token

    identifier = LeafPattern(token.NAME)
    number = LeafPattern(token.NUMBER)
    my_name = number.match(Leaf(token.NAME, "my_name"))
    assert my_name is False, my_name
    my_name = number.match(Leaf(token.NUMBER, "my_name"))
    assert my_name is False, my_name
    my_number = number.match(Leaf(token.NUMBER, "42"))
    assert my_number == True, my_number
    assert my_number is True, my_number



# Generated at 2022-06-21 10:38:33.508325
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # No need to test.
    pass
# Unit tests for method BasePattern._submatch

# Generated at 2022-06-21 10:38:41.973558
# Unit test for method remove of class Base
def test_Base_remove():
    class Node(Base):
        def __init__(self, children=None):
            self.children = children or []

        def _eq(self, other):
            return False

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def clone(self):
            return self.__class__([child.clone() for child in self.children])

        def __repr__(self):
            return f"{self.__class__.__name__}({self.children!r})"

    class Leaf(Base):
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-21 10:39:17.891051
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    import unittest

    pattern_classes: List[Type[BasePattern]] = [NodePattern, LeafPattern, WildcardPattern]
    pattern_types = {}
    for c in pattern_classes:
        pattern_types[c.__name__] = c

    class BasePatternTestCase(unittest.TestCase):

        def get_pattern(self, cls: Type[BasePattern], source: Text) -> BasePattern:
            if cls is WildcardPattern:
                source = "*" + source
            return pattern_types[cls.__name__](source)

        def check(self, source: Text) -> None:
            for cls in pattern_classes:
                pat = self.get_pattern(cls, source)
                self.assertEqual(pat, pat.optimize())


# Generated at 2022-06-21 10:39:24.322636
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.token import tok_name
    # Not a leaf so match should return False
    assert LeafPattern(tok_name.NAME, "x").match(Node(tok_name.NAME, [])) is False
    # Value mismatch
    assert LeafPattern(tok_name.NAME, "x").match(Leaf(tok_name.NAME, "y")) is False
    # Type mismatch
    assert LeafPattern(tok_name.NAME, "x").match(Leaf(tok_name.DEDENT, "x")) is False
    # Matches
    assert LeafPattern(tok_name.NAME, "x").match(Leaf(tok_name.NAME, "x")) is True
    # Matches with a dict that stores the node that matched
    results = {}

# Generated at 2022-06-21 10:39:36.217244
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    t = BasePattern()
    assert t.match(Leaf(0, "")) == False
    assert t.match(Leaf(0, "a")) == False
    assert t.match(Leaf(0)) == False
    assert t.match(Leaf(0, "", fixers_applied=[""])) == False
    assert t.match(Leaf(0, "", lineno=0)) == False
    assert t.match(Leaf(0, "", column=0)) == False
    assert t.match(Leaf(0, "", bracket_depth=0)) == False
    assert t.match(Leaf(0, "", opening_bracket=Leaf(0, ""))) == False
    assert t.match(Leaf(0, "", used_names=set([""]))) == False

# Generated at 2022-06-21 10:39:37.448708
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    pattern = BasePattern()
    assert pattern.optimize() is pattern
    assert repr(pattern) == "BasePattern(None, None, None)"

# Generated at 2022-06-21 10:39:39.441157
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    """
    Create an example of a Leaf node and test the leaves() method
    >>> l = Leaf(0, "value")
    >>> result = [n for n in l.leaves()]
    >>> result == [l]
    True
    """
    pass


# Generated at 2022-06-21 10:39:41.031241
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    pytest.skip("TODO: write test")


# Generated at 2022-06-21 10:39:48.287887
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.token import LPAR, NAME, NUMBER, RPAR, NEWLINE, INDENT

    n = Leaf(NAME, "abc")
    assert list(n.post_order()) == [n]

    n = Leaf(NAME, "abc")
    assert list(n.post_order()) == [n]

    n = Leaf(NAME, "abc")
    assert list(n.post_order()) == [n]



# Generated at 2022-06-21 10:39:52.756164
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    import parser
    import sys
    import unittest
    import _io
    import ast

    class NegatedPatternTestCase(unittest.TestCase):
        def test_generate_matches(self):
            # Test 1.
            pattern = NegatedPattern()
            nodes = (1, 2, 3, 4)
            pattern.generate_matches(nodes)

            # Test 2.
            pattern = NegatedPattern(NodePattern(ast.Module))
            nodes = (1, 2, 3, 4)
            pattern.generate_matches(nodes)

            # Test 3.
            pattern = NegatedPattern(NodePattern(ast.Module))
            nodes = (ast.Module([]))
            pattern.generate_matches(nodes)

    def _run_doctest():
        import doctest



# Generated at 2022-06-21 10:39:54.054412
# Unit test for constructor of class Base
def test_Base():  # type: ignore
    assert not Base()



# Generated at 2022-06-21 10:39:57.818544
# Unit test for constructor of class BasePattern
def test_BasePattern():
    """BasePattern(type, content=None, name=None)"""
    assert BasePattern()
    assert BasePattern(sym.x)
    assert BasePattern(sym.x, 17)
    assert BasePattern(sym.x, name="y")



# Generated at 2022-06-21 10:40:23.789978
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import NUMBER, NAME
    # Setup
    leaf = Leaf(NUMBER, "42")
    leaf.prefix = " # comment\n"
    leaf.fixers_applied = ["fix_one", "fix_two"]

    # Exercise
    copy = leaf.clone()

    # Verify
    assert copy.type == NUMBER
    assert copy.value == "42"
    assert copy.prefix == " # comment\n"
    assert copy.fixers_applied == ["fix_one", "fix_two"]

    # Cleanup - done automatically


# Generated at 2022-06-21 10:40:33.989105
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # <pre>[#Base.__eq__#]
    # self == other
    # --
    # Compare two nodes for equality.
    # This calls the method _eq().
    # </pre>

    # <post>[#Base.__eq__#]
    # def __eq__(self, other)
    #   self.__class__ is not other.__class__:
    #     return NotImplemented
    #   self._eq(other)
    # class Base(object):
    #   def __eq__(self, other):
    #     if self.__class__ is not other.__class__:
    #       return NotImplemented
    #     return self._eq(other)
    # </post>
    pass


# Generated at 2022-06-21 10:40:43.132956
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    n = None
    class DummyPattern(BasePattern):
        type = 42
    p = DummyPattern()
    assert list(p.generate_matches([])) == []
    assert list(p.generate_matches([n])) == []
    assert list(p.generate_matches([n, n])) == []
    assert list(p.generate_matches([n, n, n])) == []
    assert list(p.generate_matches([n, Leaf(42, "")])) == []
    assert list(p.generate_matches([Leaf(42, "")])) == [(1, {})]
    assert list(p.generate_matches([Leaf(42, ""), Leaf(42, "")])) == [(1, {})]

# Generated at 2022-06-21 10:40:50.012927
# Unit test for constructor of class Node
def test_Node():
    # Test for the creation of leaf nodes

    l1 = Leaf(1, "test")
    l2 = Leaf(1, "test")
    l3 = Leaf(2, "test2")
    assert l1 == l2, "Nodes were created equal but did not compare as such"
    assert l1 != l3, "Nodes were created not equal but did not compare as such"
    assert l1 is not l2, "Nodes compared equal but were not the same"

    # Test for the creation of interior nodes
    n1 = Node(1, [l1, l2])
    n2 = Node(1, [l1, l2])
    n3 = Node(2, [l1, l3])
    assert n1 == n2, "Nodes were created equal but did not compare as such"
    assert n2 != n

# Generated at 2022-06-21 10:40:52.128977
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            b = BasePattern()
            self.assertRaises(NotImplementedError, b.match_seq, [], None)

    unittest.main()



# Generated at 2022-06-21 10:40:58.464815
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols

    a = Node(python_symbols.funcdef, [])
    b = Node(python_symbols.classdef, [])
    c = Node(python_symbols.suite, [a, b])
    d = Node(python_symbols.file_input, [c])
    e = Leaf(1, '"blah"')
    a.append_child(e)
    assert list(d.post_order()) == list(d.pre_order())[::-1]

# Generated at 2022-06-21 10:41:08.674945
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # Test the 'empty' case
    pattern = NegatedPattern()
    assert pattern.match(None) == False
    assert pattern.match_seq([]) == True
    assert pattern.match_seq([None]) == False

    # Test the 'not empty' case
    pattern = NegatedPattern(NodePattern())
    assert pattern.match(None) == False
    assert pattern.match_seq([]) == False
    assert pattern.match_seq([None]) == False
    assert pattern.match_seq([Leaf(0, "zero"), Leaf(0, "one")]) == True
    assert pattern.match_seq([Leaf(0, "zero"), Leaf(0, "_")]) == False



# Generated at 2022-06-21 10:41:18.851848
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import tok_name

    leaf = Leaf(1, "leaf0", (None, (1, 1)))
    leaf_clone = leaf.clone()
    assert leaf != leaf_clone
    assert leaf.__repr__() == leaf_clone.__repr__()
    assert leaf.__str__() == leaf_clone.__str__()
    assert leaf.children == leaf_clone.children
    assert leaf.type == leaf_clone.type
    assert leaf.value == leaf_clone.value
    assert leaf.prefix == leaf_clone.prefix
    assert leaf.lineno == leaf_clone.lineno
    assert leaf.column == leaf_clone.column

# Generated at 2022-06-21 10:41:30.183185
# Unit test for function type_repr
def test_type_repr():
    import inspect
    import re
    from .pygram import python_symbols

    global _type_reprs
    _type_reprs.clear()  # refresh cache
    _type_reprs.update(
        dict(map(reversed, inspect.getmembers(python_symbols)))
    )
    for key, value in _type_reprs.items():
        assert value == type_repr(key)
    for key in filter(lambda x: isinstance(x, int), python_symbols.__dict__.values()):
        assert type_repr(key).find("token.") != 0
        assert "_" not in type_repr(key)
        assert re.match(r"[A-Z_0-9]+", type_repr(key)), type_repr(key)
