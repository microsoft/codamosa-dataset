

# Generated at 2022-06-21 10:33:58.595148
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.number) == "number"
    assert type_repr(python_symbols.number2) == "number2"
    assert type_repr(python_symbols.number3) == "number3"
    assert type_repr(python_symbols.single_input) == "single_input"



# Generated at 2022-06-21 10:34:01.854596
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    from .pgen2 import token
    n = Node(token.IF, [])
    l = Leaf(token.NAME, "test", prefix=" ")
    n.append_child(l)
    assert l.depth() == 1


# Generated at 2022-06-21 10:34:14.559009
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w1 = WildcardPattern(["a", "b", "c"])
    w2 = WildcardPattern(["d", "e"])
    w3 = WildcardPattern(["f", "g", "h"])
    w4 = WildcardPattern(["a", w2, "c"])
    w5 = WildcardPattern(["a", NodePattern(type="d"), "c"])
    assert w4.content == (("a", ("d", "e"), "c"),)
    assert w4.min == 1
    assert w4.max == 1
    assert w4.match_seq(["a", "d", "c"])
    assert not w4.match_seq(["a", "d"])

# Generated at 2022-06-21 10:34:21.690095
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    import test_parser, pickle
    from . import parse

    # This will raise an AssertionError if not all possibilities are explored
    def check_matches(s, expected):
        r = parse(s, start="eval_input")
        p = pickle.loads(pickle.dumps(test_parser.expr_context))
        m = [
            (t, sorted(r[t]))
            for t in "load_deref load_attr load_global load_name"
            if t in r
        ]
        assert m == expected

    check_matches("foo", [("load_name", ["foo"])])
    check_matches("foo.bar", [("load_deref", ["foo", "bar"])])

# Generated at 2022-06-21 10:34:26.399871
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    s = StringIO()
    ex = "1\n  2\n    5\n    6\n  3\n  4\n"
    d = Node(1, [Node(2, [Leaf(1, "5"), Leaf(1, "6")]), Leaf(1, "3"), Leaf(1, "4")])
    for node in d.pre_order():
        print(node, file=s)
    assert s.getvalue() == ex, repr(s.getvalue()) + repr(ex)



# Generated at 2022-06-21 10:34:31.296418
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    assert NegatedPattern().match_seq([])
    assert NegatedPattern(content=NegatedPattern()).match_seq([])
    assert not NegatedPattern(content=NegatedPattern(content=LeafPattern())).match_seq([])
    assert not NegatedPattern(content=LeafPattern()).match_seq([])
    assert not NegatedPattern(content=WildcardPattern(content=[NodePattern()])).match_seq(
        [LeafPattern()]
    )
    assert NegatedPattern(content=WildcardPattern(content=[])).match_seq([LeafPattern()])


# Generated at 2022-06-21 10:34:42.185793
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    d = WildcardPattern([[NodePattern(type=NAME)], []])
    assert d.match_seq([Leaf(NAME, "a")])
    assert not d.match_seq([Leaf(NAME, "a"), Leaf(NAME, "b")])
    d = WildcardPattern([[NodePattern(type=NAME)]])
    assert not d.match_seq([Leaf(NAME, "a")])
    assert not d.match_seq([Leaf(NAME, "a"), Leaf(NAME, "b")])
    d = WildcardPattern([[], [NodePattern(type=NAME)]])
    assert not d.match_seq([Leaf(NAME, "a")])
    assert not d.match_seq([Leaf(NAME, "a"), Leaf(NAME, "b")])
    d = WildcardPattern()

# Generated at 2022-06-21 10:34:47.927794
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    modules = []
    f = 'foo()\nbar()\n'
    m = Module(f)
    modules.append(m)
    assert m.pre_order() == m.pre_order()

    def test_Node_pre_order():
        modules = []
        f = 'foo()\nbar()\n'
        m = Module(f)
        modules.append(m)
        assert m.pre_order() == modules
        assert m.pre_order() == m.pre_order()
        assert m.pre_order().next_sibling() == modules
        assert m.pre_order() == m.pre_order().next_sibling()



# Generated at 2022-06-21 10:34:53.880147
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    grammar = Grammar()
    parent = Node(grammar.number, [
        Leaf(grammar.number, "123")
    ])
    child = Node(grammar.number, [
        Leaf(grammar.number, "456")
    ])
    parent.insert_child(0, child)
    assert child.parent == parent, child.parent
    assert parent.children[0] == child
    assert parent.children[1].prefix == "\n"
    assert parent.children[1].value == "123"



# Generated at 2022-06-21 10:35:02.100064
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    x = WildcardPattern()
    assert not x.wildcards
    assert not isinstance(x.optimize(), WildcardPattern)

    x = WildcardPattern(content=[])
    assert not x.wildcards
    assert not isinstance(x.optimize(), WildcardPattern)

    x = WildcardPattern(content=[[]])
    assert not x.wildcards
    assert not isinstance(x.optimize(), WildcardPattern)

    x = WildcardPattern(content=[[NodePattern()]])
    assert not isinstance(x.optimize(), WildcardPattern)

    x = WildcardPattern(content=[[LeafPattern()]])
    assert not isinstance(x.optimize(), WildcardPattern)

    x = WildcardPattern(content=[[WildcardPattern()]])

# Generated at 2022-06-21 10:35:18.691632
# Unit test for method append_child of class Node
def test_Node_append_child():
    node_a = mock.Mock(parent=None, children=[], lineno=1)
    node_b = mock.Mock(parent=None, children=[], lineno=1)
    node_a.append_child(node_b)
    assert node_a.children == [node_b]
    assert node_b.parent is node_a

# Generated at 2022-06-21 10:35:24.895205
# Unit test for method clone of class Base
def test_Base_clone():
    import copy
    from . import pytree
    from .pygram import python_symbols
    from .pgen2 import token

    # Make sure we can clone a Python symbol node
    node = pytree.Node(python_symbols.power, [])
    copy.deepcopy(node)

    # Make sure we can clone a ParseError node
    node = pytree.Node(-1, [])
    copy.deepcopy(node)

    # Make sure we can clone a token node
    node = pytree.Leaf(token.COLON, "", (1, 0))
    copy.deepcopy(node)


# Generated at 2022-06-21 10:35:26.785484
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """Unit test for method __repr__ of class Node"""
    Node(0,[])


# Generated at 2022-06-21 10:35:28.661890
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p1 = NodePattern(MINUS, [LeafPattern(token.MINUS)])



# Generated at 2022-06-21 10:35:39.019193
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # 
    import parser as _parser
    patterns = [
        ("a b !(c d)", False, False),
        ("a b !(c d)", False, True),
        ("a b !(c d)", True, False),
        ("a b !(c d)", True, True),
        ("a !(b)", False, False),
    ]
    for (pattern, nodematch, nodeseqmatch) in patterns:
        #
        tree = _parser.expr(pattern)
        p = tree.pattern().optimize()
        node = tree.root
        #
        m1 = p.match(node)
        m2 = p.match_seq([node])
        m3 = list(p.generate_matches([node]))

# Generated at 2022-06-21 10:35:49.178969
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as syms
    from .pgen2 import token
    import unittest

    class Test(unittest.TestCase):
        def test_leaf_lineno(self):
            leaf_lineno = 5
            leaf = Leaf(token.COMMA, "(", (leaf_lineno, 1))
            self.assertEqual(leaf_lineno, leaf.get_lineno())

        def test_leaf_lineno_with_intervening_node(self):
            leaf_lineno = 5
            leaf = Leaf(token.COMMA, "(", (leaf_lineno, 1))
            node = Node(syms.suite, [Leaf(token.NAME, "x", (3, 1)), leaf])


# Generated at 2022-06-21 10:35:53.658803
# Unit test for constructor of class Leaf
def test_Leaf():
    r = Leaf(1, "a")
    assert r.type == 1
    assert r.value == "a"
    assert r.prefix == ""
    assert r.lineno == 0
    assert r.column == 0
    assert r.parent is None
    assert r.children == []
    assert r.fixers_applied == []
    assert r.bracket_depth == 0
    assert r.opening_bracket is None
    assert r.used_names == set()

    r = Leaf(1, "a", (None, None))
    assert r.type == 1
    assert r.value == "a"
    assert r.prefix == ""
    assert r.lineno == 0
    assert r.column == 0

    r = Leaf(1, "a", prefix="\r\n")
    assert r.type == 1

# Generated at 2022-06-21 10:35:59.736332
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    the_str = 'Node(test, [Leaf(test2, \"test\")])'
    n = Node(node_type=0, children=[Leaf(leaf_type=0, value="test")])
    assert(the_str == repr(n))
    print(repr(n))


# Generated at 2022-06-21 10:36:02.603410
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    x = NegatedPattern(NodePattern(None))
    x.content = NodePattern(None)
    assert not (x.match(LeafPattern(None)))


# Generated at 2022-06-21 10:36:07.495588
# Unit test for function convert
def test_convert():
    gr = Grammar(tokenizer.tokenize, tokenizer.ENDFINALLY, convert)
    raw_node = (1, '', None, [])
    res = convert(gr, raw_node)
    assert res.type == 1
    assert res.value == ''
    assert res.context is None
    assert res.children == []

# Generated at 2022-06-21 10:36:35.498764
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # Nothing to do here
    pass

# Generated at 2022-06-21 10:36:47.245162
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # initialise the test
    from typing import List
    from .pgen2.grammar import ISNONTERMINAL, Grammar
    from .pgen2.parse import BasePattern
    from .pgen2.pgen import parse_grammar
    from .pgen2.pgen import Base, Leaf, Node
    rules = '''A -> "(" A ")" | "(" A ")" B | "(" A ")" B C | "(" A ")" B C D'''
    start = 'A'
    g = parse_grammar(rules, start)
    A_pattern = BasePattern(240, 'A')
    left_pattern = LeafPattern(40, '(')
    right_pattern = LeafPattern(41, ')')
    g.start_symbol = g.symbol2number[start]
    expected_output

# Generated at 2022-06-21 10:36:49.771781
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    bp = BasePattern()
    try:
        ### bp.__repr__()
        assert False, "Cannot instantiate BasePattern"
    except Exception:
        pass


# Generated at 2022-06-21 10:37:00.561573
# Unit test for method post_order of class Base
def test_Base_post_order():
    check_post_order(
     Base(0, '', (), []),
     [])
    check_post_order(
     Leaf(0, '', (), [], ''),
     [])
    check_post_order(
     Node(0, '', (), [Base(0, '', (), [])]),
     [Base(0, '', (), [])])
    check_post_order(
     Node(0, '', (), [Leaf(0, '', (), [], '')]),
     [Leaf(0, '', (), [], '')])
    check_post_order(
     Node(0, '', (), [Node(0, '', (), [])]),
     [Node(0, '', (), [])])

# Generated at 2022-06-21 10:37:10.641641
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    global BasePattern
    # Imports from __main__module
    global match_seq
    global convert
    global BasePattern
    global LeafPattern, NodePattern, Any, WildcardPattern, Optional

    from .pgen2 import driver, token

    class MyDriver(driver.Driver):
        def parse_tokens(self, tokens: List[Leaf], start_symbol: int) -> NL:
            assert start_symbol >= 256
            # Create a grammar and a parser for the given starting symbol.
            gr: Grammar = self.grammar
            parser = Parser(gr, start_symbol)
            # Create a Leaf from each token and feed it to the parser.
            generators = []
            for t in tokens:
                leaf = Leaf(t.type, t.value, t.context)

# Generated at 2022-06-21 10:37:12.061784
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    assert Base_test.get_suffix() == ""
Base_test = Base()



# Generated at 2022-06-21 10:37:13.998215
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    l = Leaf(1, 'a')
    c = l.clone()
    c.value = 'b'
    assert l.value == 'a'



# Generated at 2022-06-21 10:37:15.340207
# Unit test for method __new__ of class Base
def test_Base___new__():
    with raises(NotImplementedError):
        Base()

# Generated at 2022-06-21 10:37:20.886086
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    """
    If you modify Leaf.__str__, then you need to re evaluate this unit test.
    
    Here are the relevant bits of code from Leaf.__str__.
    
    return self.prefix + str(self.value)
    """
    __test__ = False
    if __test__:
        raise Exception("Unit test not implemented")

# Generated at 2022-06-21 10:37:29.971798
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    f = open('data.txt')
    line = f.readline().strip()
    f.close()
    from .pygram import python_grammar_no_print_statement
    from .pgen2 import tokenize
    from .pytree import Node, convert_str

    g = python_grammar_no_print_statement
    g.check_validity()
    t = list(tokenize.generate_tokens(StringIO(line).readline))
    t = list(x for x in t if x.type != tokenize.COMMENT)
    stack = [convert_str(t, g)]
    while stack:
        n = stack.pop()
        print(n)
        stack.extend(n.children)
    print('-----------------------------')

# Generated at 2022-06-21 10:37:42.477930
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
  assert True
test_Leaf___repr__()

# Generated at 2022-06-21 10:37:53.506492
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    tree = astroid.parse("4+3")
    assert tree.lineno == 1
    assert len(tree.children) == 2
    assert len(tree.child_sequence()) == 3
    assert len(tree.nodes_of_class(astroid.BinOp)) == 1

    tree.child_sequence()[1].clone()
    assert tree.lineno == 1
    assert len(tree.children) == 2
    assert len(tree.child_sequence()) == 3
    assert len(tree.nodes_of_class(astroid.BinOp)) == 1

    tree.child_sequence()[0].clone()
    assert tree.lineno == 1
    assert len(tree.children) == 2
    assert len(tree.child_sequence()) == 3

# Generated at 2022-06-21 10:37:55.212906
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    body = Leaf(1, "2")
    body.clone()


# Generated at 2022-06-21 10:37:58.800413
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    class AnyLeaf(LeafPattern):
        def __init__(self, name=None):
            LeafPattern.__init__(self, None, None, name)
    def match(leaf_pattern, node, results=None) -> bool:
        return leaf_pattern.match(node, results)
    assert not match(LeafPattern(1, "1"), Leaf(1, "2"))
    assert match(LeafPattern(1, "1"), Leaf(1, "1"))
    assert not match(LeafPattern(1, "1"), Leaf(1, ""))
    assert match(AnyLeaf(), Leaf(2, ""))
    assert not match(AnyLeaf(), Node(3, []))



# Generated at 2022-06-21 10:38:03.023982
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(2, "a", prefix=" ", fixers_applied=[1, 2])
    assert leaf.type == 2
    assert leaf.value == "a"
    assert leaf.prefix == " "
    assert leaf.fixers_applied == [1, 2]


# Generated at 2022-06-21 10:38:14.929423
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2 import token

    def test0():
        b = BasePattern()
        assert b.optimize() is b

    def test1():
        b = BasePattern(token.NAME)
        assert b.optimize() is b

    def test2():
        b = BasePattern(token.NAME, "async")
        assert b.optimize() is b

    def test3():
        b = BasePattern(token.NAME, "async", "name")
        assert b.optimize() is b

    def test4():
        b = BasePattern(token.NAME, name="name")
        assert b.optimize() is b

    def test5():
        b = BasePattern(token.NAME, "yield", name="name")
        assert b.optimize() is b


# Generated at 2022-06-21 10:38:21.682004
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    class test_Node(Node):
        def __init__(self):
            super().__init__(type=2, children=[])
    parent = test_Node()
    node = test_Node()
    node.parent = parent
    parent.children.append(node)
    parent.update_sibling_maps()
    assert node.next_sibling is None
    assert node.prev_sibling is None

# Generated at 2022-06-21 10:38:30.449877
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    pattern = WildcardPattern([[Leaf(token.NAME, "abc")]])
    node = Leaf(token.NAME, "abc")
    nodes = [node]
    result = list(pattern.generate_matches(nodes))
    assert result == [(1, {})], result
    pattern = WildcardPattern([[NodePattern(type=syms.testlist, content=[Leaf(token.NAME, "abc")])], [Leaf(token.NAME, "abc")]])
    node = Node(syms.testlist, [Leaf(token.NAME, "abc")])
    nodes = [node]
    result = list(pattern.generate_matches(nodes))
    assert result == [(1, {})], result

# Generated at 2022-06-21 10:38:37.001969
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from symtable import Symbol, syms
    from _ast import Assert, Assign, Attribute, BinOp, BitAnd, BitOr, BitXor, BoolOp
    from _ast import BoolOp, Break, Call, Compare, Continue, Delete, Dict, Div, Eq, Expression
    from _ast import FloorDiv, For, Gt, GtE, If, In, Index, Is, IsNot, LShift, Lt, LtE, List
    from _ast import ListComp, Load, Mod, Module, Mult, Name, NameConstant, Not, NotEq, NotIn
    from _ast import Num, Or, Pass, Pow, Raise, Return, RShift, Set, SetComp, Slice, Store
    from _ast import Str, Sub, Subscript, Tuple, UAdd, USub, While, WildcardPattern, With

   

# Generated at 2022-06-21 10:38:46.488377
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    try:
        from ...blib2to3.pygram import python_symbols as symbols
    except ImportError:
        symbols = sys.modules["blib2to3.pgen2.pgen2.python_symbols"]

    import blib2to3.pgen2.driver
    driver = blib2to3.pgen2.driver
    driver.main()

    import lib2to3.pyparse
    pyparse = lib2to3.pyparse
    pyparse.main()

    import blib2to3.pgen2.pgen
    pgen = blib2to3.pgen2.pgen
    pgen.main()

    import lib2to3.fixer_util
    fixer_util = lib2to3.fixer_util
    fixer_util.main()

   

# Generated at 2022-06-21 10:39:21.962824
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    # This is a stub. It does NOT test the sibling maps of the node.
    pass


# Generated at 2022-06-21 10:39:25.990515
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    n = Node(0, None, [Leaf(1, "a"), Leaf(0, "b")])
    assert list(n.pre_order()) == [n, n.children[0], n.children[1]]

# Generated at 2022-06-21 10:39:32.471082
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    t = LeafPattern(5, "abc", "foo")
    assert t.type == 5
    assert t.content == "abc"
    assert t.name == "foo"
    assert repr(t) == "LeafPattern(NAME, 'abc', 'foo')"
    assert str(t) == "LeafPattern(NAME, 'abc', 'foo')"



# Generated at 2022-06-21 10:39:35.707363
# Unit test for method leaves of class Base
def test_Base_leaves():
    with open('./base.pyi', 'r') as f:
        tree = Base.parse(f.read())
    assert list(tree.leaves()) == list(tree.post_order())



# Generated at 2022-06-21 10:39:47.737034
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    assert BasePattern(1).match(Leaf(1, "foo"))
    assert BasePattern(1, "bar").match(Leaf(1, "bar"))
    assert BasePattern(1, "bar")._submatch(Leaf(1, "bar"))
    assert not BasePattern(1, "bar")._submatch(Leaf(1, "foo"))
    assert not BasePattern(1, "bar").match(Leaf(1, "foo"))
    assert BasePattern(1, "bar").match(Leaf(1, "bar"))
    assert not BasePattern(1, "bar")._submatch(Leaf(1, "foo"))
    assert not BasePattern(1, "bar").match(Leaf(1, "foo"))

# Generated at 2022-06-21 10:39:58.031824
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    #
    # Generate some test data
    #
    from random import random, seed
    from io import StringIO

    # Seed the random number generator for repeatability
    seed(42)
    # Create a new tree for every test
    tree = NL()
    # Keep track of the tree structure in a list
    tree_list = []
    # Fill the tree with random data and track the tree structure
    for i in range(10):
        node = NL()
        for j in range(4):
            node.append(Leaf(int(random() * 10)))
        tree.append(node)
        tree_list.append(node)

    #
    # Test
    #
    # Create the wildcard to be tested
    wildcard = WildcardPattern(min = 3)
    # Run the test
    found = False
    #

# Generated at 2022-06-21 10:40:05.534212
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    """Unit test for method match of class BasePattern."""
    from parser import Parser
    from .pgen2.parse import ParseError
    from .pgen2.driver import ParserDriver
    from .pgen2.grammar import Grammar

    p_grammar = """
        root: list
        list: item+
        item: (NUMBER | NAME) NEWLINE+
        %import common.NUMBER
        %import common.WS_INLINE
        %import common.NEWLINE
        %import common.NAME
        %ignore WS_INLINE
    """
    pgen = ParserGenerator()
    grammar = pgen(p_grammar)
    parser = Parser(grammar, convert)
    driver = ParserDriver(parser, convert, None)
    source = "a\nb\nc\n"
    root

# Generated at 2022-06-21 10:40:16.001287
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # this is a bit of a whitebox test
    p = WildcardPattern([[NodePattern(type=token.NAME), NodePattern(type=token.NAME)]])
    assert p.match_seq([Leaf(1, "foo", "foo"), Leaf(1, "bar", "bar")])
    assert not p.match_seq([Leaf(1, "foo", "foo"), Leaf(2, "bar", "bar")])

    for ast_type in (Module, Expr, FunctionDef):
        p = WildcardPattern([[NodePattern(type=ast_type)]])
        assert p.match_seq([NL(ast_type, [Leaf(1, "pass", "Pass")])])

# Generated at 2022-06-21 10:40:23.053841
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import WildcardSequencePattern

    class A(BasePattern):
        def __init__(self, _):
            pass
        def _submatch(self, _):
            pass
    class B(A):
        pass
    a = A('a')
    assert a == a.optimize()

    assert a.optimize() is A('a').optimize()

    b = B('b')
    assert b.optimize() is B('b').optimize()

    assert LeafPattern(1, 1).optimize() is LeafPattern(1, 1).optimize()

# Generated at 2022-06-21 10:40:25.702555
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.parse import parse

    node = parse('abc')
    assert id(next(node.pre_order())) == id(node)


# Generated at 2022-06-21 10:40:48.056865
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2 import token
    lp = LeafPattern(token.NAME, "var")
    assert lp.match(Leaf(token.NAME, "var"))
    assert not lp.match(Leaf(token.NAME, "xxx"))
    assert not lp.match(Node(syms.fob))
    assert not lp.match(Leaf(token.COMMENT, "xxx"))
    assert not lp.match(Leaf(syms.fob, "xxx"))

# Generated at 2022-06-21 10:40:48.655230
# Unit test for method leaves of class Base
def test_Base_leaves():
    pass

# Generated at 2022-06-21 10:40:50.936906
# Unit test for constructor of class Base
def test_Base():
    a = Base()
    assert not a.was_changed
    assert not a.was_checked
    assert a.parent is None
    assert a.children == []



# Generated at 2022-06-21 10:40:57.866549
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """
    class Node(object):
    def __init__(self, type, children, context=None, prefix=None, fixers_applied=None):
        self.type = type
        self.children = list(children)
        for ch in self.children:
            assert ch.parent is None, repr(ch)
            ch.parent = self
        if prefix is not None:
            self.prefix = prefix
        if fixers_applied:
            self.fixers_applied = fixers_applied[:]
        else:
            self.fixers_applied = None
    """

    import copy
    import pprint
    import sys
    """Default return type: Node"""
    type = 257
    children = [257, 257, 257]
    context = 257
    prefix = 257

# Generated at 2022-06-21 10:41:09.266203
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    from .pgen2 import parse

    import sys
    if sys.flags.optimize >= 2:
        pytest.skip("Doc tests are not run with -O2 and above")

    gr = parse(
        """
    file_input: (NEWLINE | stmt)* ENDMARKER
    stmt: simple_stmt | compound_stmt
    simple_stmt: NAME '=' NAME
    compound_stmt: if_stmt
    if_stmt: 'if' NAME ':' suite 'else' ':' suite
    suite: NEWLINE INDENT stmt+ DEDENT
    """
    )
    # This test is based on the Grammar example in the module
    # documentation.
    expected = gr.number2symbol[10]
    assert expected == "if_stmt", expected

# Generated at 2022-06-21 10:41:19.210109
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    import ast
    test_string = '1 + 2'
    test_ast = ast.parse(test_string)
    test_tree = tree_from_ast(test_ast)
    test_leaf = test_tree.children[2]
    assert test_leaf.type == token.NUMBER
    assert test_leaf.value == '2'
    assert test_leaf.prefix == ''
    assert test_leaf.lineno == 1
    assert test_leaf.column == 3
    test_clone = test_leaf.clone()
    assert test_clone.type == token.NUMBER
    assert test_clone.value == '2'
    assert test_clone.prefix == ''
    assert test_clone.lineno == 1
    assert test_clone.column == 3
    assert test_clone is not test_leaf
    assert test_clone

# Generated at 2022-06-21 10:41:21.591927
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert_raises(AssertionError, lambda: BasePattern())