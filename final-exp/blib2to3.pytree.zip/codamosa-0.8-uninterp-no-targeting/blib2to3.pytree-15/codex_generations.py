

# Generated at 2022-06-21 10:32:29.711994
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_Base_get_suffix_line1()
    test_Base_get_suffix_line2()

# Generated at 2022-06-21 10:32:36.088651
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    a = Leaf(0, str())
    b = a.clone()
    assert a.type == b.type and a.value == b.value \
        and a._prefix == b._prefix and a.fixers_applied == b.fixers_applied
    assert a.parent == b.parent and a.children == b.children \
        and a.next_sibling == b.next_sibling and a.prev_sibling == b.prev_sibling


# Generated at 2022-06-21 10:32:40.659870
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2 import token

    pattern = LeafPattern(token.NUMBER, 3)
    assert pattern is pattern.optimize()

    pattern = LeafPattern(token.NUMBER, 3, "foo")
    assert pattern is pattern.optimize()



# Generated at 2022-06-21 10:32:49.364035
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node
    a = Node(1, [], prefix="a")
    b = Node(2, [], prefix="b")
    c = Node(3, [], prefix="c")
    d = Node(4, [], prefix="d")
    a.append_child(b)
    a.append_child(c)
    a.append_child(d)
    nodes = []
    for child in a.post_order():
        nodes.append(child.type)
    assert nodes == [2, 3, 4, 1]


# Generated at 2022-06-21 10:32:56.695739
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    import pytree as pt

    node1 = pt.Symbol(42, "ABC")
    node2 = pt.Keyword(42, "ABC")
    node1.append_child(node2)
    node3 = pt.Keyword(42, "ABC")
    node1.insert_child(0, node3)
    assert node1.children == [node3, node2]
    node4 = pt.Keyword(42, "ABC")
    node1.insert_child(2, node4)
    assert node1.children == [node3, node2, node4]
    node5 = pt.Keyword(42, "ABC")
    node1.insert_child(2, node5)
    assert node1.children == [node3, node2, node5, node4]
    assert node1.prefix == ""


# Generated at 2022-06-21 10:33:03.445281
# Unit test for method post_order of class Node
def test_Node_post_order():
    import unittest
    import io
    import ast
    import sys
    import test.support
    import pickle

    try:
        import _testcapi
    except ImportError:
        _testcapi = None
    expected = test.support.findfile("ast/expected")

    class TestCase(unittest.TestCase):

        def __init__(self, node, filename=None, lineno=None):
            super().__init__(methodName="test_%s" % node)
            self.node = node
            self.filename = filename
            self.lineno = lineno
            self.track_visitors = False
            self.visitors = []

        def test_Node(self):
            self.run()


# Generated at 2022-06-21 10:33:07.906779
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    assert NegatedPattern().match_seq([])
    assert not NegatedPattern().match_seq([1])
    assert NegatedPattern(NodePattern()).match_seq([])
    assert not NegatedPattern(NodePattern()).match_seq([1])
    assert NegatedPattern(NodePattern(type=token.NAME)).match_seq([])
    assert NegatedPattern(NodePattern(type=token.NAME)).match_seq([1])
    assert NegatedPattern(WildcardPattern()).match_seq([])
    assert NegatedPattern(WildcardPattern()).match_seq([1])
    assert NegatedPattern(NegatedPattern()).match_seq([])
    assert not NegatedPattern(NegatedPattern()).match_seq([1])



# Generated at 2022-06-21 10:33:17.175017
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    p = WildcardPattern(min=0, max=HUGE, name="bare_name")
    n = NegatedPattern(content=p)
    assert list(n.generate_matches([])) == [(0, {})]
    assert not list(n.generate_matches([Leaf(token.NAME, "a")]))
    assert not list(n.generate_matches([Leaf(token.NAME, "foo")]))

    p = WildcardPattern(min=1, max=HUGE, name="bare_name")
    n = NegatedPattern(content=p)
    assert not list(n.generate_matches([Leaf(token.NAME, "a")]))
    assert not list(n.generate_matches([Leaf(token.NAME, "foo")]))

# Unit test

# Generated at 2022-06-21 10:33:29.135001
# Unit test for function type_repr
def test_type_repr():
    # Check that a symbol name is returned.
    assert type_repr(python_symbols.power) == 'power'
    # Check that integer-like objects are returned unchanged.
    assert type_repr(python_symbols.ENDMARKER) == python_symbols.ENDMARKER
    assert type_repr(python_symbols.COMMENT) == python_symbols.COMMENT
    assert type_repr(python_symbols.NAME) == python_symbols.NAME
    assert type_repr(python_symbols.STRING) == python_symbols.STRING
    assert type_repr(python_symbols.NUMBER) == python_symbols.NUMBER
    assert type_repr(python_symbols.ERRORTOKEN) == python_sy

# Generated at 2022-06-21 10:33:36.435724
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(0, [Leaf('a', 'b', 1, 2)], 'c')
    assert n.__repr__() == "Node(0, ['a'])"
    n = Node(0, [Leaf('a', 'b', 1, 2), Leaf('a', 'b', 1, 2)], 'c')
    assert n.__repr__() == "Node(0, ['a', 'a'])"


# Generated at 2022-06-21 10:34:01.049739
# Unit test for function type_repr
def test_type_repr():
    assert(type_repr(0) == 0)
    assert(type_repr(1) == 1)
    assert(type_repr(python_symbols.dup_filename) == "dup_filename")
    # pass  # comment out pass statement



# Generated at 2022-06-21 10:34:13.856827
# Unit test for function convert
def test_convert():
    """
    Check conversion of raw nodes to Node and Leaf instances.
    """
    from .pgen2.driver import Driver

    gr = Driver(convert=convert).grammar
    node = convert(gr, (token.NAME, "foo", None, None))
    assert isinstance(node, Leaf)
    assert node.type == token.NAME
    assert node.value == "foo"
    assert node.children == []
    node = convert(gr, (gr.symbol2number["single_input"], None, None, [node]))
    assert isinstance(node, Node)
    assert node.type == gr.symbol2number["single_input"]
    assert node.children == [Leaf(token.NAME, "foo")]

# Generated at 2022-06-21 10:34:17.890700
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from io import StringIO
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import driver, tokenize


# Generated at 2022-06-21 10:34:20.926539
# Unit test for method append_child of class Node
def test_Node_append_child():
    from blib2to3.pytree import Leaf
    node_tree = Node(0, [Leaf(1,'a')])
    node_tree.append_child(Leaf(2,'b'))
    assert node_tree.children[1].value == 'b'
    assert node_tree.children[1].value == 'b'


# Generated at 2022-06-21 10:34:21.927808
# Unit test for constructor of class BasePattern
def test_BasePattern():
    p = BasePattern()
    assert p.type is None


# Generated at 2022-06-21 10:34:30.506588
# Unit test for method remove of class Base
def test_Base_remove():
    # remove(self) ->
    #     """
    #     Remove the node from the tree. Returns the position of the node in its
    #     parent's children before it was removed.
    #     """
    #     if self.parent:
    #         for i, node in enumerate(self.parent.children):
    #             if node is self:
    #                 del self.parent.children[i]
    #                 self.parent.changed()
    #                 self.parent.invalidate_sibling_maps()
    #                 self.parent = None
    #                 return i
    #     return None

    foo = Node(BUILD_LIST, [])
    bar = Leaf(1, "2")
    foo.children = [bar]

    foo.remove()
    assert foo.parent is None

# Generated at 2022-06-21 10:34:40.174229
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    # Testing 1 unsuccessful paths and 0 successful paths
    # Without context_data
    node = BasePattern()
    # Constructor created by method __new__ of class BasePattern
    assert isinstance(node, BasePattern) is True, "node is not an instance of BasePattern"
    # Testing init attribute type of class BasePattern
    assert node.type is None, "node.type is not None"
    # Testing init attribute content of class BasePattern
    assert node.content is None, "node.content is not None"
    # Testing init attribute name of class BasePattern
    assert node.name is None, "node.name is not None"

# Generated at 2022-06-21 10:34:51.805008
# Unit test for method depth of class Base
def test_Base_depth():
    from . import pytree
    from .pygram import python_symbols as syms

    def get_leaves(tree, parent=None):
        if isinstance(tree, pytree.Leaf):
            return [tree]
        else:
            assert isinstance(tree, pytree.Base)
            tree.parent = parent
            leaves = []
            for child in tree.children:
                ret = get_leaves(child, tree)
                leaves.extend(ret)
            return leaves

    def check_depth(tree, expected):
        leaves = get_leaves(tree)
        for leaf in leaves:
            assert leaf.depth() == expected

    for depth in range(4):
        tree = pytree.Node(syms.funcdef, [pytree.Leaf(1, "foo")])

# Generated at 2022-06-21 10:35:01.838012
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Values used in test cases
    node = Node(257, [Leaf(1, "token2"), Leaf(3, "token3"), Leaf(1, "token4"), Leaf(1, "token1")])
    _expected = "Node(257, [Leaf(1, 'token2'), Leaf(3, 'token3'), Leaf(1, 'token4'), Leaf(1, 'token1')])"
    # Test for method __repr__ of class BasePattern
    # AssertionError: BasePattern does not support __repr__
    try:
        assert BasePattern().__repr__() == "Node(257, [Leaf(1, 'token2'), Leaf(3, 'token3'), Leaf(1, 'token4'), Leaf(1, 'token1')])"
    except AssertionError:
        pass
    # Call

# Generated at 2022-06-21 10:35:04.722399
# Unit test for method clone of class Base
def test_Base_clone():
    from lib2to3.pytree import Leaf
    l = Leaf(0, "0")
    c = l.clone()
    assert l == c
    assert l is not c



# Generated at 2022-06-21 10:35:28.952550
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    assert NegatedPattern().match_seq([])
    assert NegatedPattern().match_seq([42])
    assert NegatedPattern(NodePattern()).match_seq([])
    assert not NegatedPattern(NodePattern()).match_seq([42])
    assert not NegatedPattern(NodePattern()).match_seq([[]])
    assert NegatedPattern(NodePattern(type=token.NAME)).match_seq([])
    assert not NegatedPattern(NodePattern(type=token.NAME)).match_seq([42])
    assert NegatedPattern(NodePattern(type=token.NAME)).match_seq([[]])
    assert not NegatedPattern(NodePattern(type=token.NAME)).match_seq([[42]])
    assert NegatedPattern(NodePattern(type=token.NAME)).match_seq([42, 43])
    assert not Negated

# Generated at 2022-06-21 10:35:34.903581
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    leaf = Leaf(123,'sample')
    assert repr(leaf) == 'Leaf({0}, \'{1}\')'.format(tok_name.get(123, 123),'sample')
    #assert repr(leaf) == 'Leaf(%s, %r)' % (tok_name.get(123, 123),'sample')


# Generated at 2022-06-21 10:35:37.100109
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # test for issue 4379
    n = NegatedPattern()
    n.match(1)
test_NegatedPattern_match()



# Generated at 2022-06-21 10:35:41.655993
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(256, [])
    node.prev_sibling_map = [1, 2]
    node.next_sibling_map = [1, 2]
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map == None
    assert node.next_sibling_map == None


# Generated at 2022-06-21 10:35:51.472305
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern()
    assert p.type is None
    assert p.content is None
    assert p.name is None
    p = NodePattern(type=10)
    assert p.type == 10
    assert p.content is None
    assert p.name is None
    p = NodePattern(name="foo")
    assert p.type is None
    assert p.content is None
    assert p.name == "foo"
    p = NodePattern(type=10, name="foo")
    assert p.type == 10
    assert p.content is None
    assert p.name == "foo"
    p = NodePattern(type=10, content=["foo"])
    assert p.type == 10
    assert p.content == ["foo"]
    assert p.name is None
    p = NodePattern(content=["foo"])

# Generated at 2022-06-21 10:36:00.060402
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # TODO: change this behavior to match the python parser.
    # Instead of getting the lineno of the first child, it
    # should be the lineno of the first nonwhitespace child
    from .pytree import Leaf, Node

    t = Node(2, [Leaf(0, "1"), Leaf(1, "\n"), Leaf(4, "\n"), Leaf(0, "2")])
    t.changed()
    assert t.get_lineno() == 1



# Generated at 2022-06-21 10:36:04.317502
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    n = Node(256, [Leaf(1, 'a')])
    n.update_sibling_maps()
    assert n.prev_sibling_map[id(n.children[0])] is None
    assert n.next_sibling_map[id(n.children[0])] is None



# Generated at 2022-06-21 10:36:13.558163
# Unit test for function generate_matches
def test_generate_matches():
    tokens = [
        NL(56, 'def'),
        NL(56, 'f'),
        NL(56, '('),
        NL(56, 'x'),
        NL(56, ')'),
        NL(56, '='),
        NL(56, '1'),
        NL(56, '+'),
        NL(56, '2'),
    ]
    counts = [
        (3, {}),
        (2, {}),
        (5, {}),
        (1, {}),
        (6, {}),
        (4, {}),
        (7, {}),
    ]

# Generated at 2022-06-21 10:36:16.206926
# Unit test for constructor of class BasePattern
def test_BasePattern():
    p = BasePattern()
    assert 0, "Cannot instantiate BasePattern"
# End of unit test



# Generated at 2022-06-21 10:36:24.686619
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as syms

    foo = Node(syms.varargslist, [Leaf(1, "a"), Leaf(1, "b")])
    bar = Node(syms.varargslist, [Leaf(1, "c"), Leaf(1, "d")])
    baz = Leaf(1, "e")
    foo.replace(bar)
    assert foo.parent is None
    assert bar.parent is not None
    assert bar.parent.children == [Leaf(1, "c"), Leaf(1, "d")]
    assert bar.children == [Leaf(1, "c"), Leaf(1, "d")]
    foo.replace(baz)
    assert foo.parent is None
    assert baz.parent is not None


# Generated at 2022-06-21 10:37:05.969823
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, 'a')
    assert l.type == 1
    assert l.value == 'a'
    assert l.children == []



# Generated at 2022-06-21 10:37:14.258422
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    from .pgen2 import token

    from . import pgen2
    pgen2  # Shut up pyflakes!

    # Test that BasePattern can be inherited

    class SubClass(BasePattern):

        pass

    a = SubClass()
    assert isinstance(a, BasePattern)

    # Test that BasePattern cannot be instantiated directly

    # Instantiate BasePattern directly
    try:
        b = BasePattern()
    except TypeError:
        pass
    else:
        assert_string(str(b), "Cannot instantiate BasePattern")

    # Test that the constructor prevents instantiating of subclasses
    # when the first argument is not a type

    # First argument is string
    try:
        c = SubClass("TYPE", "CONTENT")
    except TypeError:
        pass

# Generated at 2022-06-21 10:37:15.628472
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Imports from __future__ are not supported.
    pass

# Generated at 2022-06-21 10:37:25.853225
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from lib2to3.pgen2.parse import parse_grammar
    from lib2to3.pgen2.tokenize import generate_tokens
    from lib2to3.pgen2.token import tok_name
    from lib2to3.pgen2.driver import Driver
    from ..fixer_util import Leaf, Node
    import os
    from io import StringIO
    from ..pytree import Leaf as SLeaf
    from pprint import pprint
    import sys
    
    ###############################################################################
    
    
    
    
    class BP(BasePattern):
    
        def __new__(cls, *args, **kwds):
            assert cls is not BasePattern, "Cannot instantiate BasePattern"
            return object.__new__(cls)
    
    
    


# Generated at 2022-06-21 10:37:30.645925
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from typing import List,Any
    from .pgen2.driver import Driver
    from .pgen2.pgen import PgenParser
    from .pgen2 import pgen
    from .pgen2.parse import ParseError
    from .pgen2 import token
    import io
    import re

    p = Driver(pgen.grammar, convert)
    match = p.parse(io.StringIO(""))


# Generated at 2022-06-21 10:37:32.894984
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(0, [])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map is None
    assert node.next_sibling_map is None

# Generated at 2022-06-21 10:37:38.535788
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pygram import python_symbols as syms, python_grammar
    from .pgen2 import token  # for constants
    from . import pytree

    module = pytree.Node(syms.file_input, [
        pytree.Leaf(token.NUMBER, "1", prefix="\n"),
        pytree.Leaf(token.NAME, "x"),
        pytree.Leaf(token.NUMBER, "2", prefix="\n"),
    ])
    module.update_sibling_maps()
    assert module.next_sibling_map[id(module.children[0])] is module.children[1]
    assert module.prev_sibling_map[id(module.children[2])] is module.children[1]
    # Test that leaf is None for first and last element in children list

# Generated at 2022-06-21 10:37:42.723554
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern()
    assert n.type is None
    assert n.content is None
    assert n.name is None
    n = NodePattern(1)
    assert n.type == 1
    assert n.content is None
    assert n.name is None
    n = NodePattern(1, [1, 2])
    assert n.type == 1
    assert list(n.content) == [1, 2]
    assert n.name is None
    n = NodePattern(1, [1, 2], "name")
    assert n.type == 1
    assert list(n.content) == [1, 2]
    assert n.name == "name"



# Generated at 2022-06-21 10:37:45.650872
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    leaf = Leaf(1, 1, prefix="a")
    assert str(leaf) == "a1"


# Generated at 2022-06-21 10:37:49.743605
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    pattern = LeafPattern(1)
    node = Leaf(1, 'test')
    assert pattern.match(node) is True
    node = Leaf(2, 'test')
    assert pattern.match(node) is False


# Generated at 2022-06-21 10:38:15.391272
# Unit test for method __str__ of class Node
def test_Node___str__():
    """Test Node.__str__()."""
    def check(name, input, expect):
        node = parse(input, "<test>", name)
        actual = str(node)
        assert actual == expect, repr(actual)

    check("assign", "a = b\n", "a = b\n")
    check("assign", "a  =\t  b\n", "a = b\n")
    check("simple", "a + b\n", "a + b\n")
    check("expr", "a + b + c\n", "a + b + c\n")
    check("expr2", "a + b - c\n", "a + b - c\n")
    check("expr3", "a + (b - c)\n", "a + (b - c)\n")
test

# Generated at 2022-06-21 10:38:22.447406
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    assert Leaf(19, "a", fixers_applied=[]).__repr__() == "Leaf(NAME, 'a')"
    assert Leaf(234, "a", fixers_applied=[]).__repr__() == \
        "Leaf(%s, 'a')" % tok_name[234]


# Generated at 2022-06-21 10:38:30.851692
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.driver import Driver

    grammar = """
    start = any* value
    any = 'a'
    value = 'b'
    """

    d = Driver(grammar, convert)
    t = d.parse_string("aaaabb")
    p = BasePattern()  # type: ignore[misc]
    p.type = t.type
    p.content = t.children[0].value
    matches = list(p.generate_matches(t.children))
    assert len(matches) == 1
    assert matches[0][0] == 5
    assert matches[0][1] == {}

    p = BasePattern()  # type: ignore[misc]
    p.type = t.type
    p.content = t.children[-1].value

# Generated at 2022-06-21 10:38:34.008854
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node

    leaf1 = Leaf(1, "foo") # type: ignore
    leaf2 = Leaf(1, "bar") # type: ignore
    leaf3 = Leaf(1, "baz") # type: ignore
    node = Node(2, [leaf1, leaf2, leaf3])

    retval = list(node.leaves())
    assert retval == [leaf1, leaf2, leaf3]



# Generated at 2022-06-21 10:38:36.694970
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    t = LeafPattern()
    t = LeafPattern(1)
    t = LeafPattern(1, "hello")
    t = LeafPattern(1, "hello", "name")
    t = LeafPattern(1, name="name")
    try:
        t = LeafPattern(257)
    except AssertionError:
        pass
    try:
        t = LeafPattern(1, 2)
    except AssertionError:
        pass



# Generated at 2022-06-21 10:38:39.740321
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
        r = Leaf(0, '', (0, 0))
        assert str(r) == ''
        r = Leaf(0, '', (0, 0))
        r.value = 'a'
        assert str(r) == 'a'
        r = Leaf(0, '', (0, 0))
        r.prefix = 'b'
        assert str(r) == 'b'
        r = Leaf(0, '', (0, 0))
        r.value = 'a'
        r.prefix = 'b'
        assert str(r) == 'ba'

# Generated at 2022-06-21 10:38:43.512508
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    x = Leaf('a', 1)
    y = Node(syms.expr, [x])
    z = y.clone()
    return x == z.children[0]


# Generated at 2022-06-21 10:38:44.750563
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    pass # nothing to test, method is called in Node.__init__()

# Generated at 2022-06-21 10:38:46.523733
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node(256, [Leaf(1, b"hello")])
    assert str(node) == "hello"


# Generated at 2022-06-21 10:38:48.527176
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == "True"
    assert type_repr(4) == "STRING"
    assert type_repr(42) == 42



# Generated at 2022-06-21 10:39:13.459933
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    pass


# Generated at 2022-06-21 10:39:19.400380
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.token import NAME, NEWLINE

    tree = Leaf(NAME, "name")
    for x in tree.post_order():
        assert x == tree

    tree = Node(NAME, [Leaf(NEWLINE, ""), Leaf(NAME, "name")])
    for x in tree.post_order():
        assert x != tree
    assert list(tree.post_order())[-1] == tree



 

# Generated at 2022-06-21 10:39:22.967405
# Unit test for method append_child of class Node
def test_Node_append_child():
    node = Node(256,[])
    node2 = Node(256,[])
    node.append_child(node2)
    assert node.children[0] == node2
    assert node2.parent == node


# Generated at 2022-06-21 10:39:29.921620
# Unit test for constructor of class Node
def test_Node():
    from .pytree import Leaf

    Leaf(1, "")
    Node(1, [])
    Node(1, [Leaf(1, ""), Leaf(1, "")])
    Node(1, [Node(1, []), Leaf(1, "")])
    Node(1, [Leaf(1, ""), Node(1, [])])
    Node(1, [Node(1, []), Node(1, [])])



# Generated at 2022-06-21 10:39:42.734992
# Unit test for constructor of class NodePattern
def test_NodePattern():
    pattern = NodePattern(name="blah")
    assert isinstance(pattern, NodePattern), pattern
    assert pattern.type is None, pattern.type
    assert pattern.content is None, pattern.content
    assert pattern.name == "blah", pattern.name
    pattern = NodePattern(type=token.NAME, content=[LeafPattern(token.NAME)], name="blah")
    assert isinstance(pattern, NodePattern), pattern
    assert pattern.type == token.NAME, pattern.type
    assert len(pattern.content) == 1, pattern.content
    assert isinstance(pattern.content[0], LeafPattern), pattern.content[0]
    assert pattern.name == "blah", pattern.name
    pattern = NodePattern(type=token.NAME, content="blah")
    raise AssertionError



# Generated at 2022-06-21 10:39:53.485381
# Unit test for method remove of class Base
def test_Base_remove():
    x1 = Leaf(1, "")
    x2 = Leaf(2, "")
    x3 = Leaf(3, "")
    x4 = Leaf(4, "")
    x5 = Leaf(5, "")
    x6 = Leaf(6, "")

    n1 = Node(7, [x1, x2])
    n2 = Node(8, [x3, x4, x5])
    n3 = Node(9, [x6])

    p = Node(10, [n1, n2, n3])

    n2.remove()
    assert n2.parent is None

    assert p.children == [n1, x6]
    assert n1.parent is p
    assert x6.parent is p

    n3.remove()
    assert n3.parent is None

    assert p

# Generated at 2022-06-21 10:40:02.945882
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    import pytest

    def err(content: object, min: object, max: object, name: object) -> None:
        with pytest.raises(AssertionError):
            WildcardPattern(content, min, max, name)

    err("hi", 0, 1, None)
    err("hi", -1, 1, None)
    err("hi", 1, 0, None)
    err("hi", 1, HUGE, None)
    err("hi", 1, 2, "name")
    err("hi", HUGE, -1, "name")
    err("hi", 0, 2, "name")
    err("hi", 0, 1, 1)
    err("hi", 0, 1, None)

    pat = WildcardPattern("hi", 0, 1, "name")
    assert pat.content is None

# Generated at 2022-06-21 10:40:07.146409
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    node = Leaf(1,"test")
    assert node.value == "test"
    clone = node.clone()
    assert node is not clone
    assert node.value == clone.value
    node.value += "toto"
    assert node.value != clone.value


# Generated at 2022-06-21 10:40:17.026430
# Unit test for method replace of class Base

# Generated at 2022-06-21 10:40:27.136649
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    # Default
    l = LeafPattern()
    assert l.match(Leaf(1, "Test String")) == True

    # No Leaf
    assert LeafPattern().match(Node(1, "Test String")) == False

    # Type
    assert l.match(Leaf(2, "Test String")) == False

    # Content
    assert l.match(Leaf(1, "Test String 2")) == False

    # Name
    r = {}
    assert l.match(Leaf(1, "Test String"), r) == True
    assert r == {}

    # All
    l = LeafPattern(type=1, content="Test String", name="Name")
    r = {}
    assert l.match(Leaf(2, "Test String"), r) == False
    assert r == {}


# Generated at 2022-06-21 10:40:52.558961
# Unit test for method __str__ of class Node
def test_Node___str__():
    cls = Node(0, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert str(cls) == "abc"

# Generated at 2022-06-21 10:40:57.518142
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from . import tokenize, parse
    from .parse import LeftRecursiveGrammarError
    def test(src, type_, content=None, name=None, comment=None):
        if not isinstance(type_, int):
            type_name = type_
            tok_name = {v: k for k, v in tokenize.tok_name.items()}
            type_ = tok_name[type_]
        else:
            type_name = tokenize.tok_name[type_]
        if content is None:
            content = type_name
        if name is None:
            name = type_name
        pat = BasePattern(type_=type_, content=content, name=name)
        node = next(parse.parse(src))
        expected = [(1, {name: node})]


# Generated at 2022-06-21 10:41:08.674478
# Unit test for method clone of class Base
def test_Base_clone():
    from lib2to3 import refactor

    # Test case: simple node.
    sys.stdout = StringIO()
    node = Leaf(0, "")
    node.prefix = ":)"
    node.clone().pretty_print()
    sys.stdout.seek(0)
    assert sys.stdout.read() == ":)\n"
    sys.stdout = sys.__stdout__

    # Test case: simple tree.
    sys.stdout = StringIO()
    tree = Base(0, "", None, "a b c")
    tree.prefix = ":)"
    tree.clone().pretty_print()
    sys.stdout.seek(0)
    assert sys.stdout.read() == ":)a\n  b\n  c\n"
    sys.stdout = sys.__

# Generated at 2022-06-21 10:41:16.413229
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    # Test that leaves method yields self
    l1 = Leaf(1, "test")
    l2 = Leaf(2, "test")
    l3 = Leaf(3, "test")
    n1 = Node(1, (l1, l2, l3))

    leaves = []
    for l in n1.leaves():
        leaves.append(l)

    assert len(leaves) == 3
    assert leaves[0] == l1
    assert leaves[1] == l2
    assert leaves[2] == l3



# Generated at 2022-06-21 10:41:18.528611
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    """Unit test for method leaves of class Leaf"""
    leaf = Leaf(1,"test value")
    assert leaf.leaves() == [leaf]


# Generated at 2022-06-21 10:41:29.890483
# Unit test for method clone of class Base
def test_Base_clone():
    """Unit test for method clone of class Base."""
    import unittest

    class NodeForTestingClone(Node):
        """
        A subclass of Node for testing Base.clone
        """

        def __init__(self, left: NL, right: NL) -> None:
            """
            Constructor for NodeForTestingClone.
            """
            Node.__init__(self, "TestCloneNode", [left, right])

        def clone(self) -> "NodeForTestingClone":
            """
            Clone the current node.
            """
            return NodeForTestingClone(self.children[0].clone(),
                                       self.children[1].clone())

    class LeafForTestingClone(Leaf):
        """
        A subclass of Leaf for testing Base.clone
        """
