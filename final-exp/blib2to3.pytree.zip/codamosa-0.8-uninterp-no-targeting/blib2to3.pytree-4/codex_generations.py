

# Generated at 2022-06-21 10:33:25.123841
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from . import grammar
    from . import pgen2

    gr = pgen2.grammar.Grammar()
    optimizations = """
    leafoptimized:  a
    leafoptimized:  b
    nodeoptimized:  leafoptimized
    endmarkeroptimized:  DEF
    """

    gr.optimize_grammar(optimizations)
    node = gr.symbol2number["leafoptimized"]
    pattern = grammar.BasePattern(node, "a")
    assert pattern.optimize().type == gr.symbol2number["leafoptimized"]



# Generated at 2022-06-21 10:33:29.113793
# Unit test for method clone of class Base
def test_Base_clone():
    import lib2to3.pytree as pytree
    mytree = pytree.Node(1,[pytree.Leaf(2, 'abc')])
    mytree_clone = mytree.clone()
    assert mytree._eq(mytree_clone)


# Generated at 2022-06-21 10:33:34.211114
# Unit test for method clone of class Base
def test_Base_clone():
    import pytest
    from .pytree import Leaf
    b = Base()
    with pytest.raises(NotImplementedError):
        b.clone()
    b = Leaf(1, "abc")
    with pytest.raises(NotImplementedError):
        b.clone()


# Generated at 2022-06-21 10:33:39.428141
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import ast
    w = WildcardPattern(min=3)
    assert w.optimize() is w
    w = WildcardPattern([[LiteralPattern(42),
                          NodePattern(ast.addop, name="op"),
                          NodePattern(name="next")]], min=1)
    assert w.optimize() is w
    w = WildcardPattern([[LiteralPattern(42),
                          WildcardPattern([[NodePattern(ast.addop, name="op")]],
                                          name="op"),
                          NodePattern(name="next")]], min=1)
    assert w.optimize() is w

# Generated at 2022-06-21 10:33:49.904708
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pattern_lib import compose, empty

    # BasePattern.optimize is abstract
    try:
        BasePattern().optimize()
    except NotImplementedError:
        pass
    else:
        assert False, "expected NotImplementedError"

    assert compose(empty, empty).optimize() is empty

    # Test that BasePattern.optimize is called by NodePattern.optimize
    class NodePattern1(NodePattern):
        def optimize(self):
            return NodePattern(self.type, [self.children[0].optimize()])

    assert (
        NodePattern1("A", [(NodePattern("B", []), "a"), (NodePattern("C", []), "b")]).optimize()
        == NodePattern("A", [(NodePattern("B", []), "a")])
    )

# Generated at 2022-06-21 10:33:52.057597
# Unit test for method append_child of class Node
def test_Node_append_child():
    node = Node(0, [])
    child = Node(1, [])
    node.append_child(child)
    assert node.children[0] == child


# Generated at 2022-06-21 10:34:02.852509
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    import pydoc
    import difflib
    import unittest
    from six.moves import StringIO
    from test import support

    import pydoc
    from pydoc import *

    def assertEqual(obj1, obj2):
        """Test that obj1 and obj2 are equal;  if not, raise an
        AssertionError exception."""
        # This is only needed when running under -O, because the
        # assertEqual (and assertTrue, etc) methods are not inlined.
        if not obj1 == obj2:
            raise AssertionError("%r != %r" % (obj1, obj2))

    def assertValue(pattern, value, result=None):
        assertEqual(pattern.match(value), result)
        assertEqual(pattern.match_seq([value]), result)

   

# Generated at 2022-06-21 10:34:10.150021
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.parse import Pattern
    pattern = Pattern(pattern)
    assert pattern.__repr__() == 'Pattern()'
    assert pattern.__repr__() == 'Pattern()'
    import sys
    if '-x' in sys.argv:
        # assert pattern.__repr__() == 'Pattern()'
        pass

# Generated at 2022-06-21 10:34:11.694074
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    with pytest.raises(AssertionError):
        BasePattern()

# Generated at 2022-06-21 10:34:19.792913
# Unit test for method replace of class Base
def test_Base_replace():
    t1 = Leaf(1, "test")
    t2 = Leaf(1, "test")
    t3 = Leaf(1, "test")
    t4 = Leaf(1, "test")
    t5 = Leaf(1, "test")
    t6 = Leaf(1, "test")
    t12 = List([t1, t2])
    t123 = List([t1, t2, t3])
    t1234 = List([t1, t2, t3, t4])
    t2345 = List([t2, t3, t4, t5])
    t123456 = List([t1, t2, t3, t4, t5, t6])
    t2_5 = List([t2, t3, t4, t5])

# Generated at 2022-06-21 10:34:49.329889
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    # Test 1: regular expressions with 1 dot
    node = Node('A', [Leaf('x', "abcd")], 0, 0)
    matches = list(WildcardPattern().generate_matches([node]))
    assert len(matches) == 1
    assert matches[0][0] == 1
    
    # Test 2: regular expressions with 1 dot and 1 number
    matches = list(WildcardPattern(min=1).generate_matches([node]))
    assert len(matches) == 1
    assert matches[0][0] == 1
    
    # Test 3: regular expressions with 1 dot and 2 numbers
    matches = list(WildcardPattern(min=2).generate_matches([node]))
    assert len(matches) == 0
    
    # Test 4: regular expressions with 1 dot and 3 numbers


# Generated at 2022-06-21 10:34:54.266160
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    # x.__init__(y,z)
    # -> 0
    x = WildcardPattern([['.']])
    assert x.min == 0
    assert x.max == huge
    # -> 1
    x = WildcardPattern([['.']], 1)
    assert x.min == 1
    assert x.max == huge
    # -> 2
    x = WildcardPattern([['.']], 2)
    assert x.min == 2
    assert x.max == huge
    # -> 3
    x = WildcardPattern([['.']], 3)
    assert x.min == 3
    assert x.max == huge
    # -> 4
    x = WildcardPattern([['.']], 4)
    assert x.min == 4
    assert x.max == huge
    # -> 5

# Generated at 2022-06-21 10:34:57.835247
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Base, Leaf

    n = Leaf(0, "")
    for i in range(10):
        n = Leaf(0, "", [n])
    assert n.depth() == 10
    n2 = Leaf(0, "", [n])
    assert n.depth() == 10



# Generated at 2022-06-21 10:35:02.850823
# Unit test for constructor of class Leaf
def test_Leaf():
    import unittest
    import unittest.mock
    from .pytree import Leaf, Node
    from .pgen2.token import tok_name

    # Create a mock context
    p = unittest.mock.Mock()
    p.return_value = (unittest.mock.Mock(), unittest.mock.Mock())
    with unittest.mock.patch('lib2to3.pygram.python_symbols.context', p):
        # Create a mock token
        t = unittest.mock.Mock()
        leaf = Leaf(t.type, '"' + t.string + '"', unittest.mock.Mock())
        # Check leaf type
        assert leaf.type is t.type
        # Check leaf value

# Generated at 2022-06-21 10:35:14.420344
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern(min=0, max=1).optimize() == WildcardPattern(min=0, max=1)
    assert WildcardPattern(content=[[NodePattern(type=1)]]).optimize() == WildcardPattern(content=[[NodePattern()]])
    assert WildcardPattern(min=0, max=HUGE).optimize() == WildcardPattern(min=0, max=HUGE)
    assert WildcardPattern(content=[[NodePattern(type=1)]], min=1, max=1).optimize() == NodePattern(type=1)
    assert WildcardPattern(content=[[NodePattern(type=1)]]).optimize() == WildcardPattern(content=[[NodePattern()]])

# Generated at 2022-06-21 10:35:17.926803
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    def driver(type, value, prefix):
        a = Leaf(type, value, prefix)
        expected = [a]
        answer_is_correct = True
        for a_, e_ in zip(
            a.pre_order(), expected
        ):
            if a_!= e_:
                answer_is_correct = False
        assert answer_is_correct
    driver(0, '', '')
    driver(0, ' ', '')
    driver(0, '', ' ')
    driver(0, ' ', ' ')

# Generated at 2022-06-21 10:35:25.087368
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():

    from .pgen2.token import tok_name

    for type_ in range(256):
        value = 'value_%s' % type_
        tok = Leaf(type_, value)
        result = tok.__repr__()

        assert result == 'Leaf(%s, %r)' %(tok_name.get(type_, type_), value)


# Generated at 2022-06-21 10:35:33.572949
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node
    from .pygram import python_symbols
    from . import pytoken


# Generated at 2022-06-21 10:35:35.471615
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, "a")
    assert l.leaves() == [l]


# Generated at 2022-06-21 10:35:43.541248
# Unit test for method post_order of class Node
def test_Node_post_order():
    """
    Check that Node.post_order() works.
    """
    from . import pytree

    t = pytree.Node(1, [])
    t.append_child(Leaf(1, "a"))
    t.append_child(
        pytree.Node(
            2,
            [
                Leaf(1, "b"),
                Leaf(4, "c"),
            ],
        )
    )
    t.append_child(Leaf(3, "d"))
    test = []
    for c in t.post_order():
        test.append(c)
    assert len(test) == 5
    assert test[0].prefix == "a"
    assert test[1].type == 1
    assert test[2].prefix == "c"
    assert test[3].type == 2
    assert test

# Generated at 2022-06-21 10:36:04.108788
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import token_map
    from .pgen2.parse import Pattern
    assert repr(Pattern(None, None)) == "Pattern(None, None, None)"
    assert repr(Pattern(token_map["NUMBER"], None)) == "Pattern(NUMBER, None, None)"
    assert repr(Pattern(None, "42")) == "Pattern(None, '42', None)"
    assert repr(Pattern(None, None, "foo")) == "Pattern(None, None, 'foo')"

# Generated at 2022-06-21 10:36:07.942668
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """Unit test for method optimize of class BasePattern."""

    class MyPattern(BasePattern):
        def __init__(self):
            self.type = 1
    pattern = MyPattern()
    assert pattern.optimize() is pattern

# Generated at 2022-06-21 10:36:11.686580
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    node1 = Leaf(1, u'2')
    node2 = Leaf(1, u'2')
    node1.append_child(node2)
    try:
        node1.leaves()
    except NotImplementedError:
        pass

    assert node1.leaves() is not None



# Generated at 2022-06-21 10:36:22.623392
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    class DummyNode(Node):
        def __init__(self):
            self.type = "dummy"
            self.children = []
            self.context = ("", (0, 0))
            self.attr = []
    dummyNode = DummyNode()
    leaf = Leaf(1, "something", ("", (0, 0)))
    assert leaf.get_suffix() == ""
    dummyNode.children = [leaf]
    leaf.parent = dummyNode
    assert leaf.get_suffix() == ""
    assert dummyNode.get_suffix() == ""
    dummyLeaf = Leaf(1, "dummy", ("", (0, 0)))
    dummyLeaf.parent = dummyNode
    dummyNode.children.append(dummyLeaf)
    assert leaf.get_suffix() == "dummy"

# Generated at 2022-06-21 10:36:34.343684
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    import ast
    import compiler
    import os
    import sys
    import tokenize
    def _tokenize(s):
        return [tok for tok in tokenize.generate_tokens(StringIO(s).readline)
                if tok[0] not in (tokenize.COMMENT, tokenize.NL)]

    # Generate AST
    test_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-21 10:36:38.858285
# Unit test for constructor of class Node
def test_Node():
    import unittest

    class Test(unittest.TestCase):
        def test_Node_01(self):
            my_node = Node(
                type=256,
                children=[0, 1, 2],
                context=None,
                prefix="",
                fixers_applied=None,
            )
            self.assertEqual(my_node.type, 256)
            self.assertEqual(my_node.children, [0, 1, 2])
            self.assertEqual(my_node.context, None)
            self.assertEqual(my_node.prefix, "")
            self.assertEqual(my_node.fixers_applied, None)


# Generated at 2022-06-21 10:36:49.962104
# Unit test for function generate_matches
def test_generate_matches():
    class TestPattern(BasePattern):
        def __init__(self, match):
            self.match = match
        def match(self, node, results=None):
            return self.match
    def check(pats, nodes, exprs):
        pat = pats[0]
        for rest in pats[1:]:
            pat = pat & rest
        results = list(generate_matches(pat, nodes))
        assert list(map(repr, results)) == exprs

    # Empty patterns match to an empty sequence
    check([TestPattern(False)], [], [])
    check([TestPattern(False), TestPattern(False)], [], [])
    check([TestPattern(True)], [], [])
    check([TestPattern(True), TestPattern(True)], [], [])

# Generated at 2022-06-21 10:36:50.701240
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    t = Leaf(0, "{")
    t.pre_order()



# Generated at 2022-06-21 10:36:56.555856
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    """Fake test that makes coverage happy."""
    node = Node(256, [])
    assert node.prev_sibling_map is None
    assert node.next_sibling_map is None
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map is None
    assert node.next_sibling_map is None


# Generated at 2022-06-21 10:37:06.193123
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.tokenize import generate_tokens, tokenize
    from .pgen2.token import tok_name
    from io import StringIO
    code = '"""hello"""\n'
    with tokenize(StringIO(code).readline) as gen:
        type, string, start, end, line = next(gen)
        assert type == 3
        assert string == '"""hello"""'
        assert line == code
        s = node_repr(type)
        assert s == 'STRING'
        lp = LeafPattern(type=type, content=string)
        lp1 = LeafPattern(type=type, content=string)
        assert lp == lp1
        assert hash(lp) == hash(lp1)
        type, string, start, end, line = next(gen)

# Generated at 2022-06-21 10:37:32.536847
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern(content=[[LeafPattern(ord("a"))]], min=0, max=HUGE)
    assert p.optimize() == WildcardPattern(
        content=[[LeafPattern(ord("a"))]], min=0, max=HUGE
    )
    p = WildcardPattern(content=[[LeafPattern(ord("a"))]], min=3, max=3)
    assert p.optimize() == WildcardPattern(
        content=[[LeafPattern(ord("a"))]], min=3, max=3
    )
    p = WildcardPattern(content=[[LeafPattern(ord("a"))]], min=1, max=1)
    assert p.optimize() == LeafPattern(ord("a"))

# Generated at 2022-06-21 10:37:38.849944
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    l = LeafPattern(2, "foo")
    assert l.type == 2
    assert l.content == "foo"
    assert l.name is None


# Generated at 2022-06-21 10:37:49.831111
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pytree import Leaf
    class TestNode(Node):

        def __init__(self, type, children, **kwds):
            super().__init__(type, children, **kwds)

    test_node = TestNode(0, [Leaf(0, "")])
    test_node.insert_child(0, Leaf(0, ""))
    assert str(test_node) == " ", test_node
    test_node = TestNode(0, [Leaf(0, "")])
    test_node.insert_child(0, Leaf(0, ""))
    test_node.insert_child(1, Leaf(0, ""))
    assert str(test_node) == "  ", test_node

    # Test the case where the current object has no children
    test_node = TestNode(0, [])

# Generated at 2022-06-21 10:37:55.832136
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import lib2to3.fixer_base as fb
    p = fb.Token('a')
    r = list(p.generate_matches([fb.Token('a')]))
    assert len(r) == 1
    r = list(p.generate_matches([fb.Token('b')]))
    assert len(r) == 0
    r = list(p.generate_matches([fb.Token('a'), fb.Token('a')]))
    assert len(r) == 0


# Generated at 2022-06-21 10:37:58.275602
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """
    This test checks the method __new__ of class BasePattern.
    """
    pattern = BasePattern()
    assert 0


# Generated at 2022-06-21 10:38:02.873579
# Unit test for method __str__ of class Node
def test_Node___str__():
    from . pytree import Node, Leaf

    l1 = Leaf(1, "spam")
    l2 = Leaf(1, "eggs")
    n1 = Node(3, [l1, l2])
    assert n1.__str__() == "spameggs"


# Generated at 2022-06-21 10:38:14.840948
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.tokenize import tokenize, untokenize, generate_tokens, NL, ENCODING, COMMENT
    from .pgen2.token import NAME, NUMBER
    from .pgen2.parse import pickle
    from .pgen2.pgen import token
    from .pgen2.pgen import Nonterminal, Production
    import io

    s = 'import sys\ntest'
    tokens = list(generate_tokens(io.StringIO(s).readline))
    node = pickle.loads(pickle.dumps(tokenize(s)))
    assert node.type == token.ENCODING
    assert len(node.children) == 2
    # function post_order
    nodes = list(node.post_order())
    assert len(nodes) == 5
    #

# Generated at 2022-06-21 10:38:26.357304
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import pprint
    import sys
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.tokenize as tokenize



    # Test with a complete program
    _, t = tokenize.tokenize(StringIO("from os import *").readline)
    t = list(t)
    k, v = t[0]
    assert k == 1
    assert v == 'from'
    k, v = t[1]
    assert k == 31
    assert v == 'os'
    k, v = t[2]
    assert k == 59
    assert v == 'import'
    k, v = t[3]
    assert k == 5
    assert v == '*'


# Generated at 2022-06-21 10:38:32.895506
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    n0 = Node(syms.file_input, [])
    n1 = Node(syms.simple_stmt, [])
    l2 = Leaf(1, "")
    n1.append_child(l2)
    n0.append_child(n1)
    n3 = Node(syms.simple_stmt, [])
    n0.append_child(n3)
    n0.update_sibling_maps()
    assert n1.next_sibling is n3
    assert n3.prev_sibling is n1
    assert n1.prev_sibling is None
    assert n3.next_sibling is None
    return



# Generated at 2022-06-21 10:38:37.478868
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    import re, sys
    import lib2to3.pgen2.parse
    m = lib2to3.pgen2.parse.LeafPattern(type=1)
    n = lib2to3.pgen2.parse.Leaf(1, 'True')
    assert m.match(n, results=None)
    assert m.match(n, results={})
    assert m.match(n, results={'foo': 123})
    assert m.match(n, results={'foo': 123, 'bar': 456})
    assert not m.match(n, results={'foo': 123, 'bar': 456, 42: 'xxx'})
    assert m.match(n, results={'foo': 123, 'bar': 456, 42: 'xxx'})

# Generated at 2022-06-21 10:39:07.117008
# Unit test for function convert
def test_convert():
    from .pgen2.pgen import Grammar
    from .pgen2.parser import Driver
    import io
    import sys
    
    g = Grammar(io.StringIO('''
    test: 'foo'
    '''))
    d = Driver(g, convert)
    output = d.parse_tokens([
        ('foo', 'foo'),
        ('ENDMARKER', ''),
    ])
    assert output == Leaf(5, 'foo')
test_convert()

# Unit test to show the output of convert with an input tree
#
# When the only child is another Node, the child is returned, not a new Node
# containing the child.

# Generated at 2022-06-21 10:39:10.121932
# Unit test for method post_order of class Node
def test_Node_post_order():
    # Create instance of class Node
    node = Node(0, [])

    # Invoke method post_order of class Node
    node.post_order()



# Generated at 2022-06-21 10:39:20.326915
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    tree = compile("@decorator(a, b*c) * (d + e, *args, **kwds)\n")
    assert WildcardPattern().match(tree)
    assert WildcardPattern(content=[['a', 'b']]).match(Node(syms.varargslist, ['a', 'b']))
    assert not WildcardPattern(content=[['a', 'b']]).match(Node(syms.varargslist, ['a', 'c']))
    assert WildcardPattern(content=[['a']]).match(Node(syms.varargslist, ['a']))
    assert WildcardPattern(content=[['a'], ['b']]).match(Node(syms.varargslist, ['a']))

# Generated at 2022-06-21 10:39:22.431948
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "1")
    assert list(leaf.post_order()) == [leaf]



# Generated at 2022-06-21 10:39:26.342152
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Testing the content is None case
    assert list(NegatedPattern().generate_matches("")) == [(0, {})]
    assert list(NegatedPattern().generate_matches("abc")) == []
    # Testing the content is not None case
    np = NegatedPattern(LeafPattern("b"))
    assert list(np.generate_matches("ab")) == [(0, {})]
    assert list(np.generate_matches("b")) == []

_matcher_cache = {}  # type: Dict[Tuple[Pattern, str], Pattern]


# Generated at 2022-06-21 10:39:37.192706
# Unit test for function generate_matches
def test_generate_matches():
    import unittest
    import ast

    pattern = Or([Leaf("a"), Leaf("b")])
    test_matches = [
        ("", []),
        ("c", []),
        ("ab", [("ab", {})]),
        ("aab", [("ab", {}), ("aab", {})]),
        ("abab", [("ab", {}), ("abab", {})]),
    ]
    for text, expected_results in test_matches:
        nodes = list(ast.parse(text).body)
        results = list(generate_matches([pattern], nodes))
        assert results == expected_results, (text, results)
test_generate_matches()



# Generated at 2022-06-21 10:39:49.498804
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import unittest
    import textwrap

    class Tests(unittest.TestCase):

        def check(self, pat, node, result, results={}):
            self.assertEqual(pat.match(node, results), result)
            self.assertEqual(results, {})

        def test_leaf_pattern(self):
            from .pgen2.token import LPAR, NAME
            from .pgen2.parse import ParseError, __inithook__

            __inithook__()
            node = Leaf(LPAR, "(")
            self.check(LeafPattern(), node, True)
            self.check(LeafPattern(NAME), node, False)
            self.check(LeafPattern(LPAR), node, True)
            self.check(LeafPattern(LPAR, "("), node, True)

# Generated at 2022-06-21 10:39:51.152488
# Unit test for method __str__ of class Node
def test_Node___str__():
    """
    Unit test for Node.__str__
    """
    assert False


# Generated at 2022-06-21 10:40:01.372989
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert (
        WildcardPattern(content=[[WildcardPattern()], [NodePattern(type=token.NAME)]])
        == WildcardPattern(content=[(WildcardPattern(),), (NodePattern(type=token.NAME),)])
    )


# We don't use assertions in our generated code, so this flag is ignored.
__all__ = list(token.__all__) + ["SymbolPattern", "WildcardPattern", "generate_matches"]
__all__.remove("N_TOKENS")
__all__.remove("tok_name")
__all__.remove("tok_names")
#
_TOKEN_MAP = token.__dict__
PATTERN_CACHE = {}
# from pprint import pprint

# Pattern matcher
# ===============

# The following functions are all affected by

# Generated at 2022-06-21 10:40:12.167601
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node, PythonLeaf
    from .pygram import python_symbols as syms
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    import io

    l = PythonLeaf(0, 'print(5)', (1, 0))
    n = Node(syms.simple_stmt, [l])
    n.remove()
    assert n.parent is None and l.parent is None

    l = Leaf(token.NAME, 'print', (1, 0))
    n = Node(syms.atom, [l])
    n.remove()
    assert n.parent is None and l.parent is None

    l = Leaf(0, 'print', (1, 0))
    n = Node(syms.atom, [l])
   

# Generated at 2022-06-21 10:40:45.372429
# Unit test for constructor of class BasePattern
def test_BasePattern():
    from .pgen2.token import LPAR, NAME, NUMBER, OP, RPAR, STAR, WHITESPACE

    class L(BasePattern):
        def _submatch(self, node, results=None):
            return True

    assert L(LPAR).type == LPAR
    assert L(LPAR, "(").content == "("
    assert L(LPAR, "(").type == LPAR
    assert L(LPAR, "(").name is None
    assert L(LPAR, "(").name is None
    assert L(LPAR, "(", "lparen").type == LPAR
    assert L(LPAR, "(", "lparen").content == "("
    assert L(LPAR, "(", "lparen").name == "lparen"
    assert L(LPAR, content="(").content == "("


# Generated at 2022-06-21 10:40:53.862846
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    a = Node(256, [])
    b = Node(256, [])
    c = Node(256, [])
    d = Node(256, [])
    a.append_child(b)
    a.append_child(c)
    a.append_child(d)
    a.update_sibling_maps()
    assert a.next_sibling_map == {id(b): c, id(c): d, id(d): None}
    assert a.prev_sibling_map == {id(b): None, id(c): b, id(d): c}



# Generated at 2022-06-21 10:40:57.780752
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(type=1)
    assert isinstance(p, NodePattern)
    assert p.type == 1
    assert p.content is None
    assert p.name is None
    p = NodePattern(type=1, content=[LeafPattern(1, "foo")])
    assert isinstance(p, NodePattern)
    assert isinstance(p.content[0], LeafPattern)



# Generated at 2022-06-21 10:41:09.123529
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    leaf = Leaf(1, "test")
    node = Node(234, [leaf])
    leaf.parent = node
    leaf2 = leaf.clone()
    leaf2.replace(leaf2)
    assert leaf2.parent.children == [leaf2]
    assert leaf.parent is None
    assert node.children == [leaf2]
    node2 = Node(1, [leaf, node])
    leaf.parent = node2
    node.parent = node2
    node.replace(node)
    assert node.parent == node2
    node.children = [leaf, node]
    leaf.parent = node
    node.parent = node
    node.replace([leaf])
    assert node.parent == leaf
    assert leaf.parent == node
    node.children = [leaf]

# Generated at 2022-06-21 10:41:19.095556
# Unit test for method clone of class Base
def test_Base_clone():
    """Test that clone makes a deep copy of the tree."""

    from . import pgen2
    from . import pytree
    from . import python_tree

    g = pgen2.driver.load_grammar('Grammar.txt')
    g.initialize_dfas()
    t = pytree.convert_grammar_to_tree(g)
    for x in t.pre_order():
        assert isinstance(x, pytree.Base)
    t2 = t.clone()
    for x, y in zip(t.pre_order(), t2.pre_order()):
        assert isinstance(x, pytree.Base)
        assert isinstance(y, pytree.Base)
        assert x == y
    assert t == t2
    # Make sure a deep copy was made

# Generated at 2022-06-21 10:41:27.581550
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    """
    >>> from .pgen2 import token
    >>> from .pgen2.grammar import Grammar
    >>> from .pgen2.parse import parse_grammar
    >>> g = parse_grammar(Grammar(), 'Grammar', '''
    ... 'see'
    ... ''', True)
    >>> l = g.symbol2number['see']
    >>> node = Leaf(token.NAME, 'see')
    >>> list(node.post_order()) == [node]
    True
    """
