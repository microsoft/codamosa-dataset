

# Generated at 2022-06-21 10:32:20.730735
# Unit test for method remove of class Base
def test_Base_remove():
    node = Leaf(1, "node", (1, 0))
    assert node.remove() is None
    node.parent = Node(2, None)
    node.parent.children = [Leaf(3, "leaf1", (1, 0)), node]
    node.remove()
    assert node.parent is None
    assert node.remove() is None



# Generated at 2022-06-21 10:32:26.159052
# Unit test for constructor of class Leaf
def test_Leaf():
    """Tests for the constructor of class Leaf."""
    from .pgen2.token import tok_name

    # Use a named constant in the unit test
    # (otherwise, test is pointless)
    tok = tok_name["NAME"]
    x = Leaf(tok, "xyz", prefix="  ", fixers_applied=["fix1"])
    assert_equal(x.type, tok)
    assert_equal(x.value, "xyz")
    assert_equal(x._prefix, "  ")
    assert_equal(x.fixers_applied, ["fix1"])
    assert_equal(x.parent, None)
    assert_equal(x.children, [])
    # str(x) includes the prefix
    assert_equal(str(x), "  xyz")
   

# Generated at 2022-06-21 10:32:31.722084
# Unit test for method leaves of class Base
def test_Base_leaves():
    """ Test the leaves method of class Base"""
    from lib2to3.pgen2 import token

    grammar = Grammar()
    grammar.symbol2number["test"] = 256

    test_leaf = Leaf(token.NUMBER, "99", (1, 1), prefix=" ")
    test_node = Node(256, [test_leaf])

    assert list(test_node.leaves()) == [test_leaf]
    assert list(test_leaf.leaves()) == [test_leaf]



# Generated at 2022-06-21 10:32:37.152066
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """Verify that the Node.pre_order method works."""
    # Make a simple parse tree
    tree = Node(1, [Leaf(1, "foo"), Leaf(1, "bar"), Leaf(1, "baz")])
    # Iterate through it
    result = []
    for node in tree.pre_order():
        result.append(node.type)
    return result == [1, 1, 1]



# Generated at 2022-06-21 10:32:39.242918
# Unit test for method remove of class Base
def test_Base_remove():
    b1 = Base()
    assert b1.remove() == None


# Generated at 2022-06-21 10:32:46.069494
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    from . import token

    l = Leaf(token.NAME, "Leaf")
    assert str(l) == "Leaf"
    l2 = l.clone()
    assert str(l2) == "Leaf"
    l.value = "Node"
    assert str(l) == "Node"
    assert str(l2) == "Leaf"
    l2.prefix = " "
    assert str(l2) == " Leaf"



# Generated at 2022-06-21 10:32:47.912825
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    top = BasePattern()
    assert top.optimize() is top


# Generated at 2022-06-21 10:32:55.912350
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    class TestClass(Leaf):
        def __init__(self, x: int) -> None:
            self.type = x
            self.value = x
            self._prefix = str(x)
            self.children = []
            self.fixers_applied=[]
            self.parent = None
            self.bracket_depth = 0
            self.opening_bracket = None
            self.used_names = None
            self.lineno = None
            self.column = None
            self.was_changed = False
    def test_equivalent(node: TestClass, rep: str) -> None:
        assert str(node) == rep, f"With {node}, got {str(node)} instead of {rep}"
    test_equivalent(TestClass(1), '1')

# Generated at 2022-06-21 10:33:02.447855
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    from . import pytoken
    n1 = Node(syms.file_input, [])
    n2 = Leaf(pytoken.STRING, "hello")
    n1.set_child(0, n2)
    assert n1.prefix == n2.prefix
    assert not n1.children
    assert n2.parent == n1
    n3 = Leaf(pytoken.STRING, "world")
    n1.set_child(0, n3)
    assert not n1.children
    assert n3.parent == n1
    assert n1.prefix == n3.prefix
    assert n2.parent is None
    n1.changed()
    assert n1.was_changed

# Generated at 2022-06-21 10:33:07.834719
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern([[NodePattern(NAME), NodePattern(DOT)], [NodePattern(NUMBER)]],
                        min=1, max=1, name="bare_name")
    assert p.name == "bare_name", p.name
    assert p.min == 1, p.min
    assert p.max == 1, p.max
    assert isinstance(p.content, tuple), p.content
    assert len(p.content) == 2, len(p.content)
    assert isinstance(p.content[0], tuple), p.content[0]
    assert isinstance(p.content[1], tuple), p.content[1]
    assert isinstance(p.content[0][0], NodePattern), p.content[0][0]
    assert isinstance(p.content[0][1], NodePattern), p

# Generated at 2022-06-21 10:33:56.280271
# Unit test for method __str__ of class Node
def test_Node___str__():
    a = Node(
        1,
        [
            Leaf(
                1,
                "a",
                (1, 0),
                (1, 1),
                "",
                None,
            ),
            Node(
                2,
                [
                    Leaf(
                        1,
                        "b",
                        (1, 1),
                        (1, 2),
                        "",
                        None,
                    ),
                    Leaf(
                        1,
                        "c",
                        (1, 2),
                        (1, 3),
                        "",
                        None,
                    ),
                ],
                None,
                "",
                None,
            ),
        ],
        None,
        "",
        None,
    )
    assert a.__str__() == "abc"

# Generated at 2022-06-21 10:34:03.555881
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pygram import python_symbols as symbols
    from .pytree import Leaf
    # Test post_order
    node = Node(symbols.exprlist, [Leaf(1, 'token1'), Leaf(2, 'token2')])
    result = list(node.post_order())
    check = [Leaf(1, 'token1'), Leaf(2, 'token2'), node]
    for i in range(len(result)):
        assert result[i].data == check[i].data, result[i].data
        assert result[i].type == check[i].type, result[i].type
        assert result[i].value == check[i].value, result[i].value
    pass



# Generated at 2022-06-21 10:34:15.641838
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
  class DummyLeaf(Node, Leaf):
    def __init__(self, type: int, value: Text, context: Optional[Context] = None, prefix: Optional[Text] = None, fixers_applied: List[Any] = [],):
      Leaf.__init__(self, type, value, context, prefix, fixers_applied)
      Node.__init__(self, type, [], context, prefix, fixers_applied)
    
    def __repr__(self):
      return "[Leaf: %s]" % (self.value)

    def __str__(self):
      return "[Leaf: %s]" % (self.value)

    def __eq__(self, other):
        return self.value == other.value


# Generated at 2022-06-21 10:34:21.138909
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    root = Node(1, [Node(2, []), Leaf(3, "")])
    n = Node(4, [])
    n.insert_child(0, Leaf(5, "", prefix=" "))
    n.insert_child(0, Leaf(6, ""))
    n.insert_child(0, Leaf(7, "", prefix="\n"))
    root.children[0].insert_child(0, n)
    assert str(root.children[0].children[0].children[1]) == " test"
    assert root.children[0].children[0].children[1].prefix == " "



# Generated at 2022-06-21 10:34:29.214129
# Unit test for constructor of class Base
def test_Base():
    class Node(Base):
        def _eq(self, other):
            return NotImplemented

        def clone(self):
            return NotImplemented

        def post_order(self) -> Iterator[NL]:
            return NotImplemented

        def pre_order(self) -> Iterator[NL]:
            return NotImplemented

    x = Node()
    x.type = 42
    x.children = [Leaf(1, "abc"), Leaf(2, "def")]
    y = Node()
    y.type = 42
    y.children = [Leaf(1, "abc"), Leaf(2, "def")]
    assert x == y, (x, y)
    y.children.append(Leaf(3, "ghi"))
    assert x != y, (x, y)



# Generated at 2022-06-21 10:34:33.595073
# Unit test for method __str__ of class Node
def test_Node___str__():
    for NODE in [
        Node(256, []),
        Node(257, [Leaf(1, "g"), Leaf(2, "l")]),
    ]:
        assert isinstance(NODE.__str__(), str)


# Generated at 2022-06-21 10:34:41.274141
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Test method __repr__ of class BasePattern."""
    pattern = LeafPattern(token.LPAR, "(").optimize()
    pattern
    pattern = LeafPattern(token.LPAR, content=None, name=None).optimize()
    pattern
    pattern = LeafPattern(token.LPAR, value=None, name=None).optimize()
    pattern
    pattern = LeafPattern(token.LPAR, "(", None).optimize()
    pattern
    pattern = LeafPattern(token.LPAR, "(", "left").optimize()
    pattern



# Generated at 2022-06-21 10:34:52.767927
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node, Leaf

    one = Leaf(1, "one")
    two = Leaf(1, "two")
    three = Leaf(1, "three")
    four = Leaf(1, "four")
    five = Leaf(1, "five")
    six = Leaf(1, "six")
    seven = Leaf(1, "seven")
    eight = Leaf(1, "eight")
    nine = Leaf(1, "nine")
    ten = Leaf(1, "ten")
    eleven = Leaf(1, "eleven")
    twelve = Leaf(1, "twelve")
    thirteen = Leaf(1, "thirteen")
    fourteen = Leaf(1, "fourteen")
    fifteen = Leaf(1, "fifteen")


# Generated at 2022-06-21 10:34:59.272194
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    from .pgen2.token import NAME, OP, tokenize

    def _test(code, name, token_type=NAME, pos=0):
        t_code = next(tokenize(StringIO(code).readline))
        assert t_code.type == token.ENCODING
        assert t_code.string == code
        t_name = t_code.clone()
        while True:
            t_name = t_name.next_sibling
            if t_name.type == token.NEWLINE:
                break
            if t_name.type == token_type:
                assert t_name.string == name
                break
        assert t_code == t_name
        assert t_code.prefix == t_name.prefix
        assert t_code.next_sibling == t_name.next_sibling

# Generated at 2022-06-21 10:35:03.076882
# Unit test for constructor of class BasePattern
def test_BasePattern():
    from .pgen2 import driver

    p = driver.compile_pattern("1")
    assert p.type == token.NUMBER
    assert p.content == "1"
    assert p.name is None

    p = driver.compile_pattern("1", "foo")
    assert p.type == token.NUMBER
    assert p.content == "1"
    assert p.name == "foo"



# Generated at 2022-06-21 10:35:46.969147
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    """
    >>> g = Leaf(1, "test")
    >>> p = LeafPattern([1])
    >>> list(p.generate_matches([g]))
    [(1, {})]
    """
    pass



# Generated at 2022-06-21 10:35:55.289735
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern([[NodePattern(1), NodePattern(2)]], min=1, max=2)
    assert isinstance(p.optimize(), NodePattern)
    p = WildcardPattern([[NodePattern(1), WildcardPattern([], min=1, max=1)]], min=1, max=1)
    # assert isinstance(p.optimize(), NodePattern)
    p = WildcardPattern([[NodePattern(1), NodePattern(2)], [NodePattern(1)]], min=1, max=1)
    assert isinstance(p.optimize(), NodePattern)



# Generated at 2022-06-21 10:35:58.745865
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    #
    # BasePattern should not be instantiated directly.
    #
    with raises(AssertionError):
        BasePattern()

# Generated at 2022-06-21 10:36:06.702225
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node, Leaf
    b = Base()
    my_tree = Node(1, [Node(2, [Leaf(1, "foo")]), Leaf(3, "bar")])
    my_leaves = []
    my_nodes = []
    for node in my_tree.post_order():
        if isinstance(node, Leaf):
            my_leaves.append(node)
        else:
            my_nodes.append(node)
    assert my_leaves == [Leaf(3, "bar"), Leaf(1, "foo")]
    assert my_nodes == [Node(2, [Leaf(1, "foo")]), Node(1, [Node(2, [Leaf(1, "foo")]), Leaf(3, "bar")])]

# Generated at 2022-06-21 10:36:11.035478
# Unit test for method __new__ of class Base
def test_Base___new__():
    from . import pytree
    from .pygram import python_symbols

    assert pytree.NodeType(python_symbols.classdef) is pytree.NodeType(
        "classdef", pytree.Node)
    assert pytree.LeafType(token.NAME) is pytree.LeafType("NAME", pytree.Leaf)
    assert pytree.Base() is None



# Generated at 2022-06-21 10:36:22.462653
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    assert NodePattern().match(Node(0))
    assert NodePattern().match(Node(256))
    assert not NodePattern().match(Node(0, [Node(0)]))
    assert not NodePattern().match(Node(1))

    assert NodePattern(0).match(Node(0))
    assert not NodePattern(0).match(Node(256))
    assert NodePattern(0).match(Node(0, [Node(0)]))
    assert NodePattern(0).match(Node(0, [Node(1)]))
    assert NodePattern(0).match(Node(0, [Node(256), Node(0), Node(0)]))
    assert not NodePattern(0).match(Node(1))

    assert not NodePattern(0, [LeafPattern(0)]).match(Node(0))

# Generated at 2022-06-21 10:36:28.923289
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    """
    The documentation string in the class Leaf contains a test case.
    """
    # The test case was removed from the documentation because it did not
    # pass.  It appears below, commented out.
    assert False, "The test case was removed from the documentation because it did not pass."
    # from . import token
    # from .pgen2 import token as pgen_token
    # t = Leaf(token.NAME, "a", lineno=1, column=1)
    # assert str(t) == "a"
    # assert t.prefix is None
    # t = Leaf(pgen_token.NAME, "a", (None, (1, 1)))
    # assert str(t) == "a"
    # assert t.prefix is None


# Generated at 2022-06-21 10:36:41.692713
# Unit test for constructor of class Node
def test_Node():
    # Test argument type checking in constructor
    try:
        Node(0, [], None)
        assert False, "Expected SyntaxError"  # type: ignore
    except SyntaxError:
        pass

    # Test parent pointers
    ch1 = Leaf(1, "x")
    ch2 = Leaf(1, "y")
    node = Node(2, [ch1, ch2])
    assert ch1.parent == node and ch2.parent == node
    # Test str() using a ridiculously small tab size
    assert str(node) == "xy"

    # Test prefix
    node = Node(2, [])
    assert node.prefix == ""
    node = Node(2, [Leaf(1, "")])
    assert node.prefix == ""
    node = Node(2, [Leaf(1, "")])


# Generated at 2022-06-21 10:36:51.758010
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert BasePattern(tok_name.NUMBER, '5').__repr__() == "LeafPattern(NUMBER, '5')"
    assert BasePattern(tok_name.PLUS).__repr__() == "LeafPattern(PLUS)"
    assert BasePattern(tok_name.PLUS, (1, 2)).__repr__() == "LeafPattern(PLUS, (1, 2))"

    assert BasePattern(tok_name.NAME, 'a', 'x').__repr__() == "LeafPattern(NAME, 'a', 'x')"
    assert BasePattern(tok_name.NUMBER, 123, 'x').__repr__() == "LeafPattern(NUMBER, 123, 'x')"

# Generated at 2022-06-21 10:36:57.793771
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    # XXX Should add tests for more of the class's methods.
    assert LeafPattern(type=1, content="abc")
    raises(AssertionError, LeafPattern, type=1, content=list(range(5)))
    raises(AssertionError, LeafPattern, type=257, content="abc")
    assert LeafPattern(type=1, content="abc").content == "abc"



# Generated at 2022-06-21 10:37:47.206653
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from . import pygram
    from .pgen2 import token

    def _N(type, children):
        return Node(type, children, context=None)

    pygram.initialize()

    # test a simple case
    tree = _N(
        pygram.python_symbols.dotted_name,
        [
            Leaf(token.NAME, "spam"),
            Leaf(token.DOT, "."),
            Leaf(token.NAME, "eggs"),
            Leaf(token.DOT, "."),
            Leaf(token.NAME, "ham"),
        ],
    )

# Generated at 2022-06-21 10:37:56.087726
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():

    p1 = WildcardPattern(min=1, max=HUGE, name="a")
    p2 = WildcardPattern(min=1, max=1, name="b")
    p3 = WildcardPattern(min=1, max=1, name="c")
    p4 = WildcardPattern(min=0, max=1, name="d")
    assert p1.match_seq([p1])
    assert p1.match_seq([p1, p1])
    assert not p1.match_seq([p2])
    assert not p1.match_seq([p2, p2])
    assert p1.match_seq([p2, p3])
    assert not p1.match_seq([p2, p3, p2])

# Generated at 2022-06-21 10:38:08.367595
# Unit test for method remove of class Base
def test_Base_remove():
    import random
    import string
    import pickle

    random.seed(99)
    nodes = [
        Leaf(random.randint(0, 255), random.choice(string.ascii_lowercase))
        for _ in range(20)
    ]
    nodes_copy = list(nodes)
    while len(nodes) >= 2:
        index = random.randrange(1, len(nodes) - 1, 2)
        new_node = Node(random.randint(256, 512), [nodes[index - 1], nodes[index]])
        nodes[index - 1] = new_node
        del nodes[index]

    nodes = nodes[0]
    for node in nodes.pre_order():
        if isinstance(node, Node):
            assert node.parent is not None

# Generated at 2022-06-21 10:38:13.433809
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    p = LeafPattern(1, "hello", "name")
    p2 = LeafPattern(1, "world", "name")
    n = Leaf(1, "world")
    assert p.match(n) == False, "should be False"
    assert p2.match(n) == True, "should be True"


# Generated at 2022-06-21 10:38:14.435339
# Unit test for method __new__ of class Base
def test_Base___new__():
    pass



# Generated at 2022-06-21 10:38:20.694944
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = map(
        lambda c: NodePattern(string.lowercase.index(c) + 256, name=c),
        "abcdefghijklmnopqrstuvwxyz",
    )
    assert len(string.lowercase) == 26
    c1 = NegatedPattern()
    c2 = NegatedPattern(a)
    c3 = NegatedPattern(a | b)
    c4 = NegatedPattern(a | b | c)
    c5 = NegatedPattern(a | b | c | d)
    c6 = NegatedPattern(a | b | c | d | e)
    c

# Generated at 2022-06-21 10:38:21.474427
# Unit test for method post_order of class Base
def test_Base_post_order():
    pass



# Generated at 2022-06-21 10:38:22.252958
# Unit test for method replace of class Base
def test_Base_replace():
    pass

# Generated at 2022-06-21 10:38:26.600027
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == "NAME"
    assert type_repr(type_repr(1)) == "NAME"
    assert type_repr(type_repr(type_repr(1))) == "NAME"
    assert type_repr(99) == 99
del test_type_repr



# Generated at 2022-06-21 10:38:28.530939
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    b = BasePattern()
    try:
        b.__repr__()
    except NotImplementedError:
        pass

# Generated at 2022-06-21 10:40:33.110684
# Unit test for method append_child of class Node
def test_Node_append_child():
    from . import pytree

    t = pytree.Node(1, [])
    assert t.children == []
    t.append_child(pytree.Leaf(2, "foo"))
    assert t.children == [pytree.Leaf(2, "foo")]
    assert t.children[0].parent is t
    try:
        t.append_child(None)
    except AssertionError:
        pass
    else:
        assert False, "must raise AssertionError"



# Generated at 2022-06-21 10:40:39.318544
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    n = Node(1, [])
    n.insert_child(0, Leaf(2, ""))
    n.insert_child(0, Leaf(3, ""))
    assert [x.type for x in n.children] == [3, 2], n.children
    n.insert_child(1, Leaf(4, ""))
    assert [x.type for x in n.children] == [3, 4, 2], n.children



# Generated at 2022-06-21 10:40:43.355456
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(type=0, children=[])
    assert n.__repr__() == 'Node(0, [])'
    n2 = Node(type=0, children=[Leaf(type=0, value='')])
    assert n2.__repr__() == "Node(0, [Leaf(0, '')])"



# Generated at 2022-06-21 10:40:44.807009
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    class TestClass():
        def test_case1(self):
            pass


# Generated at 2022-06-21 10:40:51.121597
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.parse import ParseError, parse

    def check(patt, s, complete=True):
        patt = parse(patt, start="pattern")
        tree = parse(s, start="eval")
        if complete:
            expected = bool(patt.match_seq(tree.post_order()))
        else:
            expected = False
        try:
            got = patt.match_seq(tree.post_order())
        except ParseError:
            got = False
        assert expected == got

    check("atom", "[]")
    check("atom", "1 + 2")
    check("atom '+'", "1 + 2")
    check("'1' '+' atom", "1 + 2")
    check("atom '+' atom", "1 + 2")

# Generated at 2022-06-21 10:40:55.518064
# Unit test for method changed of class Base
def test_Base_changed():
    test_string = "abc def"
    l = Leaf(1, test_string, (1, 1))
    n = Node(syms.file_input, [l])
    l.changed()
    assert n.was_changed
    assert l.was_changed
    n.was_changed = False
    l.was_changed = False
    l.parent = None
    l.changed()
    assert not n.was_changed
    assert l.was_changed



# Generated at 2022-06-21 10:40:59.061869
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert issubclass(BasePattern, object)
    # Test the body of BasePattern.__new__
    try:
        BasePattern(*(), **{}).__init__
    except AssertionError:
        pass

# Generated at 2022-06-21 10:41:10.453189
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    import sys, os
    from .pgen2.tokenize import generate_tokens, NL, DEDENT, ENDMARKER, INDENT, NEWLINE
    from .pgen2.token import NAME
    from .pgen2.parse import Parser
    from .pgen2.pgen import PythonParser

    path = os.path.join(sys.base_prefix, "lib/python3.8/test.py")
    with open(path, encoding="utf-8") as f:
        string = f.read()
    tokens = generate_tokens(StringIO(string))
    last = Leaf(0, "")
    for tup in tokens:
        type = tup[0]
        string = tup[1]
        if type == NAME:
            last = Leaf(type, string)

# Generated at 2022-06-21 10:41:12.594266
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    n1 = Base()
    n2 = Base()
    n1 == n2

# Generated at 2022-06-21 10:41:18.661926
# Unit test for constructor of class Node
def test_Node():
    l = Leaf(1, "", (1, 0))
    assert repr(l) == "Leaf(1, '')"
    assert str(l) == ""
    n = Node(2, [l])
    assert repr(n) == "Node(2, [Leaf(1, '')])"
    assert str(n) == ""
    sys.stdout.write("test_Node done.\n")


_Nxt = TypeVar("_Nxt", "Node", "Leaf")

