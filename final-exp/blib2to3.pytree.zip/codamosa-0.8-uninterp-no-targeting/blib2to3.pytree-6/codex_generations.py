

# Generated at 2022-06-21 10:33:14.331325
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    lp = LeafPattern()

    lp = LeafPattern(1)
    assert lp.type == 1
    assert lp.content == None
    assert lp.name == None

    lp = LeafPattern(1, "x")
    assert lp.type == 1
    assert lp.content == "x"
    assert lp.name == None

    lp = LeafPattern(name=1)
    assert lp.type == None
    assert lp.content == None
    assert lp.name == 1

    lp = LeafPattern(2, 3)
    assert lp.type == 2
    assert lp.content == 3
    assert lp.name == None



# Generated at 2022-06-21 10:33:20.508809
# Unit test for method __new__ of class Base
def test_Base___new__():
    """
    Class Base must not be instantiated.

    It must always be a base class.

    >>> n = Base()
    Traceback (most recent call last):
      ...
    AssertionError: Cannot instantiate Base
    """
    pass

# Generated at 2022-06-21 10:33:23.633291
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(python_symbols.testlist, [])
    assert node.__repr__() == "Node(testlist, [])"



# Generated at 2022-06-21 10:33:34.986565
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    src = """
    def f(x):
        if x:
            f(x)
        return f(x)
    x = f(5)
    """
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt", convert=False)
    parser = driver.Parser(grammar, convert=False)
    tree = parser.parse_string(src)
    leaves = list(tree.leaves())
    src2 = "".join(leaf.value for leaf in leaves)
    assert src2 == src
    assert list(tree.leaves()) == leaves
    assert set(tree.pre_order()) == set(tree.post_order()) == set(leaves)

# Generated at 2022-06-21 10:33:42.380829
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    parser = ParserPython()

    buf = "a + 'b'"
    node = parser.parse(buf, debug=False)
    pattern = parser.pattern()

    mresult = pattern.match(node)
    #assert mresult, mresult

    buf2 = "a + 1"
    node2 = parser.parse(buf2, debug=False)
    mresult = pattern.match(node2)
    #assert not mresult, mresult



# Generated at 2022-06-21 10:33:47.937189
# Unit test for constructor of class Base
def test_Base():
    import cStringIO

    save_stdout = sys.stdout
    sys.stdout = stream = cStringIO.StringIO()
    try:
        Base()  # should fail
    except AssertionError:
        pass
    else:
        raise AssertionError("Instantiation of Base should fail")
    sys.stdout = save_stdout



# Generated at 2022-06-21 10:33:53.962171
# Unit test for constructor of class Node
def test_Node():
    # A temporary grammar which uses numbers instead of grammar symbols
    test_grammar = Grammar("""
        start: NUM NUM
        """)
    test_grammar.add_production("start", [("NUM", "1"), ("NUM", "2")])
    test_grammar.seal()
    NUM = test_grammar.symbol("NUM")

    t = Node(NUM, [], None)
    assert t.type == NUM and t.children == []
    t = Node(NUM, [Leaf(NUM, "3", None)], None)
    assert t.type == NUM and t.children == [Leaf(NUM, "3", None)]

    class ArbitraryParent(Node):
        pass

    p = ArbitraryParent(NUM, [])
    assert isinstance(p, ArbitraryParent)

# Generated at 2022-06-21 10:33:56.017446
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    assert_raises(NotImplementedError, Node, None, None).pre_order()

# Generated at 2022-06-21 10:33:58.449502
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    """Test function for Leaf.__repr__"""
    assert Leaf(1,"a",("e",(3,4))).__repr__() == "Leaf(1, 'a')"


# Generated at 2022-06-21 10:34:03.678941
# Unit test for method clone of class Node
def test_Node_clone():
    node = Node(1, [])
    node.used_names = set()
    node.fixers_applied = []
    clone_node = node.clone()
    assert id(node.fixers_applied) != id(clone_node.fixers_applied)
    assert node.fixers_applied == clone_node.fixers_applied
    assert id(node.used_names) != id(clone_node.used_names)
    assert node.used_names == clone_node.used_names



# Generated at 2022-06-21 10:34:32.300230
# Unit test for function convert
def test_convert():
    from .pgen2 import token
    from .pgen2.grammar import Grammar
    literal = Leaf(token.NUMBER, "1")
    assert convert(Grammar({'x': [[literal]]}, {}), (0, '1', None, [literal])) is literal
    x = Node(0, [literal])
    assert convert(Grammar({'x': [[literal]]}, {}), (0, '1', None, [x])) == x
    x = Node(0, [literal])
    assert convert(Grammar({'x': [[literal, literal]]}, {}), (0, '1', None, [x])) == x
    literal2 = Leaf(token.NUMBER, "2")
    x = Node(0, [literal, literal2])

# Generated at 2022-06-21 10:34:36.333766
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, "hello")
    assert leaf.children == []
    assert leaf.value == "hello"
    assert leaf.type == 1
    test_Leaf()


# Generated at 2022-06-21 10:34:41.492413
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node

    def test_children(parent):
        for i in range(20):
            node = Node(parent.type)
            parent.append_child(node)
            assert not node.was_changed
            node.changed()
            assert node.was_changed
            test_children(node)

    leaf = Leaf("acb", "a")
    test_children(leaf)



# Generated at 2022-06-21 10:34:45.327415
# Unit test for method clone of class Leaf
def test_Leaf_clone():
  leaf = Leaf(256, "hello")
  assert leaf.clone().value == "hello"
  assert leaf.clone().type == 256


# Generated at 2022-06-21 10:34:47.384085
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "abc")
    assert l.type == 1
    assert l.value == "abc"


# Generated at 2022-06-21 10:34:56.253977
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    class Node(RootNode):
        def pre_order(self) -> Iterator:
            yield self
            for child in self.children:
                yield from child.pre_order()
    class Leaf(Node):
        def pre_order(self) -> Iterator:
            yield self
    import random
    import string
    random.seed(1)
    def node(depth):
        if depth == 0:
            return Leaf(random.choice(string.ascii_lowercase))
        else:
            children = [node(depth-1) for _ in range(random.randrange(5))]
            return Node(random.choice(string.ascii_uppercase), children)
    for i in range(5):  # Test a few random trees
        tree = node(3)
        # Test pre-order iteration
        s

# Generated at 2022-06-21 10:34:58.014405
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    try:
        leaf = Leaf(323, '1')
        leaf.pre_order()
        assert False, 'failed to raise assertion error'
    except AssertionError:
        pass


# Generated at 2022-06-21 10:35:10.504675
# Unit test for method set_child of class Node
def test_Node_set_child():
    id_nodes = {id(node): node for node in s.pre_order()}
    print(f"id_nodes={id_nodes}")
    print(f"type(id_nodes[id(s.children[0])])={type(id_nodes[id(s.children[0])])}")
    print(f"s.children[0].type={s.children[0].type}")
    print(f"s.children[0].parent={s.children[0].parent}")
    s.set_child(1, Leaf(1, ')"'))
    print(f"s.children[1].type={s.children[1].type}")
    print(f"s.children[1].parent={s.children[1].parent}")

# Generated at 2022-06-21 10:35:12.563972
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    p = LeafPattern(token.NAME, "bar")
    assert repr(p) == 'LeafPattern(NAME, "bar")'

# Generated at 2022-06-21 10:35:22.557189
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pat = WildcardPattern(content = [[LeafPattern(type=L_NAME), NodePattern(type=R_CALL)]])
    nodes = [
        Leaf(L_NAME, "Klass"),
        Node(R_CALL, [], prefix="."),
        Leaf(L_NAME, "method"),
    ]
    assert pat.match_seq(nodes, results={}) == False
    pat = WildcardPattern(content = [[LeafPattern(type=L_NAME), NodePattern(type=R_CALL)]])

# Generated at 2022-06-21 10:36:00.180506
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    l1 = Leaf(1, "x")
    l2 = Leaf(2, "y")
    l3 = Leaf(3, "z")
    l4 = Leaf(4, "w")
    node = Node(1, [l1, l2, Node(2, [l3]), l4])
    l = list(node.pre_order())
    assert l == [node, l1, l2, l3, l4], l



# Generated at 2022-06-21 10:36:01.384004
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert len(list(Leaf(37, "").leaves())) == 1


# Generated at 2022-06-21 10:36:02.912274
# Unit test for method __new__ of class Base
def test_Base___new__():
    import python_ta
    python_ta.check_all(True)


# Generated at 2022-06-21 10:36:06.688881
# Unit test for constructor of class Node
def test_Node():
    assert Node(0, []).type == 0
    assert Node(0, []).children == []
    assert Node(0, [Leaf(1, "x")]) == Node(0, [Leaf(1, "x")])
    try:
        Node(0, [1])
        assert False, "Should have raised ValueError"
    except ValueError:
        pass



# Generated at 2022-06-21 10:36:13.098843
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    foo = WildcardPattern([['foo']])
    assert isinstance(foo.content, tuple)
    assert isinstance(foo.content[0], tuple)
    assert isinstance(foo.content[0][0], tuple)
    assert isinstance(foo.content[0][0][0], LeafPattern)
    assert foo.content[0][0][0].type == token.NAME
    assert foo.content[0][0][0].content == 'foo'

# ++ WildcardPattern Unit test



# Generated at 2022-06-21 10:36:17.196862
# Unit test for constructor of class BasePattern
def test_BasePattern():

    class Pat(BasePattern):
        pass

    r = repr(Pat(syms.simple_stmt))
    assert r == "Pat(syms.simple_stmt, None, None)", r



# Generated at 2022-06-21 10:36:22.377397
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    with open("test_post_order/_test_Leaf.py", "r", encoding="utf-8") as f:
        code = f.read()
    tree = ast.parse(code)
    root = tree_to_nltk(tree)
    count = 0
    for item in root.post_order():
        count += 1
        assert isinstance(item, Leaf)
    assert count == 7



# Generated at 2022-06-21 10:36:29.006634
# Unit test for function generate_matches
def test_generate_matches():
    from .core import Node
    from .nodes import Name

    X = NodePattern(type=tokenize.NAME)
    Y = NodePattern(type=tokenize.NAME)
    Z = NodePattern(type=tokenize.NAME)

    seq = [X, Y, Z]
    seqp = list(map(NodePattern, seq))
    for l in range(4):
        for c, r in generate_matches(seqp, seq[:l]):
            print(" ", l, c, r)

    print("*" * 20)
    xyz = tuple(seq)
    x = seq[0]
    y = seq[1]
    z = seq[2]
    xy = tuple(seq[:2])
    xyz = tuple(seq)
    xy1 = (x, xy, z)

# Generated at 2022-06-21 10:36:41.751189
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    p = NegatedPattern()
    assert p.match(p) == False
    p = NegatedPattern(None)
    assert p.match(p) == False
    p = NegatedPattern(LeafPattern(type=-1))
    assert p.match(p) == False
    p = NegatedPattern(LeafPattern(type=-2, value=1))
    assert p.match(p) == False
    p = NegatedPattern(LeafPattern(type=-2, value=1))
    assert p.match(NodePattern(type=-2, content=[LeafPattern(type=-1)])) == False
    p = NegatedPattern(LeafPattern(type=-2, value=1))
    assert p.match(NodePattern(type=-2, content=[LeafPattern(type=-2, value=1)])) == False

# Generated at 2022-06-21 10:36:43.749613
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    print("test_BasePattern_optimize not yet implemented")



# Generated at 2022-06-21 10:37:07.783278
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    pattern = NegatedPattern(NodePattern(token.NAME))
    assert pattern.match_seq([])
    assert not pattern.match_seq([Leaf(1, 'foo')])
    assert pattern.match_seq([Leaf(1, 'bla')])
    pattern = NegatedPattern(None)
    assert pattern.match_seq([])


# Generated at 2022-06-21 10:37:10.045577
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base = BasePattern()
    assert list(base.generate_matches([Leaf(0, "")])) == [(1, {})]



# Generated at 2022-06-21 10:37:16.336619
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from lib2to3.pytree import Leaf, Node, type_repr

    n = Node(type=1)
    n.children = [Leaf(1, "1-1"), Leaf(1, "1-2")]
    n2 = Node(type=1)
    n2.children = [Leaf(1, "1-1"), Leaf(1, "1-2")]
    assert n == n2
    n2.children[0].value += "X"
    assert n != n2
    assert n.children[0] == n2.children[0]
    n3 = Node(type=1)
    n3.children = []
    assert n != n3
    n4 = Node(type=1)
    assert n != n4
    l = Leaf(type=1, value="42")
   

# Generated at 2022-06-21 10:37:26.332622
# Unit test for method __new__ of class Base
def test_Base___new__():
    from .diff import Base, Node, Leaf
    from . import pytree

    class SubclassOfBase(Base):
        pass

    class SubclassOfSubclassOfBase(SubclassOfBase):
        pass

    class SubclassOfNode(Node):
        pass

    class SubclassOfBaseAndNode(Base, Node):
        pass

    class SubclassOfLeaf(Leaf):
        pass

    class SubclassOfSubclassOfLeaf(SubclassOfLeaf):
        pass

    class SubclassOfBaseAndLeaf(Base, Leaf):
        pass

    class SubclassOfSubclassOfBaseAndLeaf(SubclassOfBase, Leaf):
        pass

    assert issubclass(Node, Base)
    assert issubclass(Leaf, Base)
    assert issubclass(pytree.Node, Base)
    assert issub

# Generated at 2022-06-21 10:37:32.537251
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    alternative = ((LeafPattern(type=NAME, content='x'),),)
    test_pat = WildcardPattern(content=alternative)
    result = tuple(test_pat.generate_matches([Leaf(type=NAME, value='x')]))
    assert result == ((1, {}),), repr(result)
    result = tuple(test_pat.generate_matches([Leaf(type=NAME, value='x'),
                                            Leaf(type=NAME, value='y')]))
    assert result == ((1, {}), (2, {})), repr(result)



# Generated at 2022-06-21 10:37:40.722440
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    assert NL(1) == NL(1)
    assert NL(1) != NL(2)
    assert NL(1) != 1
    assert NL(1) != [1]
    assert NL(1) == NL(1)
    assert not NL(1) == NL(2)
    assert not NL(1) == 1
    assert not NL(1) == [1]
    assert not NL(1) != NL(1)
    assert NL(1) != NL(2)
    assert NL(1) != 1
    assert NL(1) != [1]



# Generated at 2022-06-21 10:37:43.354485
# Unit test for constructor of class BasePattern
def test_BasePattern():
    # Unit test for constructor of class BasePattern
    bp = BasePattern()
    assert isinstance(bp, BasePattern)
    assert bp.type is None
    assert bp.content is None
    assert bp.name is None



# Generated at 2022-06-21 10:37:49.993334
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.parser import SequencePattern
    assert not BasePattern(3, foo).match(Leaf(3, "bar"))
    assert not BasePattern(3, "foo").match(Leaf(3, "bar"))
    assert BasePattern(3, "foo").match(Leaf(3, "foo"))
    assert BasePattern(3, SequencePattern(Any(), Any())).match(
        Leaf(3, "foo")
    )
    assert BasePattern(3, SequencePattern(Any(), Any())).match(
        Leaf(3, "foo"), {}
    )
    assert BasePattern(3, SequencePattern(Any(), Any())).match(
        Leaf(3, "foo"), {}
    )

# Generated at 2022-06-21 10:37:53.895301
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from . import parsetok

    for content in (None, [LeafPattern(None), LeafPattern(None)]):
        d = NodePattern(None, content)
        assert d.type is None
        assert d.name is None
        assert d.content is content
    for content in ([parsetok.Number], LeafPattern(None)):
        try:
            NodePattern(None, content)
        except AssertionError:
            pass
        else:
            assert False, "NodePattern() doesn't raise exception"



# Generated at 2022-06-21 10:38:05.636924
# Unit test for method set_child of class Node
def test_Node_set_child():
    from tests.test_grammar import make_grammar

    g = make_grammar()
    p = g.parse('class A(B): pass')
    assert p.get_type() == g.syms.file_input
    assert p.children[0].get_type() == g.syms.classdef
    p.children[0].set_child(0, Leaf(g.syms.NAME, "C"))
    assert p.children[0].get_type() == g.syms.classdef
    assert p.children[0].children[0].value == "C"
    p.children[0].set_child(1, Leaf(g.syms.NAME, "Q"))
    assert p.children[0].children[1].value == "Q"
    # Add test for setting the child of a Leaf
   

# Generated at 2022-06-21 10:39:00.020052
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    r0 = WildcardPattern(content=[NodePattern(type=1)])
    r1 = r0.optimize()
    r2 = r1.optimize()
    assert r0 is r1 is r2

    r0 = WildcardPattern(content=[NodePattern(type=1)], min=0, max=1, name="a")
    r1 = r0.optimize()
    assert r0 is not r1 and isinstance(r1, NodePattern) and r1.type == 1 and r1.name == "a"

    r0 = WildcardPattern(content=[NodePattern(type=1)], min=1, max=1, name="a")
    r1 = r0.optimize()
    assert r0 is not r1 and isinstance(r1, NodePattern) and r1.type == 1 and r1

# Generated at 2022-06-21 10:39:11.783706
# Unit test for method clone of class Base
def test_Base_clone():
    test_patterns = []
    test_patterns.append(
        (
            None,
            [[None, None, None, []]],
            [
                [None, None, None, []], [None, None, None, []],
                [None, None, None, []], [None, None, None, []]
            ]
        )
    )

    class SimpleNode(Node):
        def __init__(self, *args, **kwds):
            super(SimpleNode, self).__init__(*args, **kwds)
        def _eq(self, other):
            return self.type == other.type
        def clone(self):
            return self.__class__(self.type, [x.clone() for x in self.children])


# Generated at 2022-06-21 10:39:16.143299
# Unit test for function convert
def test_convert():
    gr = load_grammar('Grammar/Grammar')

# Generated at 2022-06-21 10:39:20.049596
# Unit test for constructor of class Node
def test_Node():
    """Test Node constructor."""
    n = Node(python_symbols.file_input, [Leaf(1, ""), Leaf(2, "")])
    assert n.type == python_symbols.file_input
    for i in range(len(n.children)):
        assert n.children[i].parent is n



# Generated at 2022-06-21 10:39:32.571253
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import blib2to3.pytree as pytree
    leaf1 = pytree.Leaf(1, "leaf1")
    leaf2 = pytree.Leaf(1, "leaf2")
    leaf3 = pytree.Leaf(1, "leaf3")
    node = pytree.Node(257, [leaf1, leaf2, leaf3])
    node.update_sibling_maps()
    assert node.prev_sibling_map[id(leaf1)] == None
    assert node.next_sibling_map[id(leaf1)] == leaf2
    assert node.prev_sibling_map[id(leaf2)] == leaf1
    assert node.next_sibling_map[id(leaf2)] == leaf3
    assert node.prev_sibling_map[id(leaf3)] == leaf2
    assert node

# Generated at 2022-06-21 10:39:44.748267
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.tokenize import generate_tokens, TokenInfo
    from .pgen2.parse import ParseError
    class TestPattern(BasePattern):
        def __init__(self, type) -> None:
            self.type = type
    c = TestPattern(token.NAME)
    print(repr(c))
    def match(c, input: Text) -> bool:
        tokens = generate_tokens(StringIO(input).readline)
        node = convert(grammar, build_ast(tokens, None)[0])
        print("nodes:", node)
        if not node:
            return False
        return c.match(node)
    assert match(c, "abc")
    assert not match(c, "123")
    assert not match(c, "")
    d = Test

# Generated at 2022-06-21 10:39:55.775564
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    def f(type_, content, name, node, results):
        p = BasePattern(type_, content, name)
        n = Node(node[0], node[1:])
        r = {}
        assert p.match(n, r) == results
        if results:
            assert r[name] is n

    def g(type_, content, name, node, results):
        p = BasePattern(type_, content, name)
        n = Leaf(node[0], node[1])
        r = {}
        assert p.match(n, r) == results
        if results:
            assert r[name] is n


# Generated at 2022-06-21 10:40:04.173086
# Unit test for method replace of class Base
def test_Base_replace():
    #import lib2to3.fixer_base
    import lib2to3.pgen2.parse
    #import lib2to3.fixer_util
    old_grammar = lib2to3.pgen2.parse.grammar

# Generated at 2022-06-21 10:40:14.750446
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import sys;
    import traceback;
    import sys
    import blib2to3.pgen2.token
    import blib2to3.pytree
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from blib2to3.fixer_util import Leaf, Node
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pytree import Leaf, Node, type_repr
    from blib2to3.pgen2 import driver, tokenize, grammar


# Generated at 2022-06-21 10:40:19.027174
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    import lib2to3.pytree as lib2to3_pytree
    import lib2to3.pygram as lib2to3_pygram
    leaf = lib2to3_pytree.Leaf(lib2to3_pygram.tokens.NAME, 'x')
    pre_order = [tok for tok in leaf.pre_order()]
    assert pre_order == [leaf]



# Generated at 2022-06-21 10:40:45.181734
# Unit test for constructor of class Leaf
def test_Leaf():
    # Don't call super().__init__()
    assertLeaf("foo", "foo")
    assertLeaf("", "")
    assertLeaf("", "", type=1)
    assertLeaf("foo", "foo", type=1)
    assertLeaf("foo", "foo", context=(("", 0), 0))
    assertLeaf("", "", context=(("", 0), 0))
    assertLeaf("bar", "bar", context=("", 0))
    assertLeaf("bar", "bar", prefix="")
    assertLeaf("bar", "bar", prefix="prefix")
    assertLeaf("bar", "bar", prefix="prefix", type=1)



# Generated at 2022-06-21 10:40:48.280726
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    # Instantiating a Node object
    n = Node(0, [])
    # Calling __repr__()
    r = eval(repr(n))
    # Ensuring that the result is of Node type
    assert isinstance(r, Node)
    assert r.type == 0 and r.children == []


# Generated at 2022-06-21 10:40:50.168988
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    """Test constructor of class LeafPattern"""
    lp = LeafPattern()
    lp = LeafPattern(1, "a")
    lp = LeafPattern(1, "a", "b")



# Generated at 2022-06-21 10:40:59.629568
# Unit test for method clone of class Node
def test_Node_clone():
    if 0:
        import sys
        import blib2to3.pygram as pygram
        blib2to3.fixer_util.log_debug(sys.stdout, 'blib2to3.pygram.syms.print_stmt')
        blib2to3.fixer_util.log_debug(sys.stdout, pygram.syms.print_stmt)
        blib2to3.fixer_util.log_debug(sys.stdout, pygram.syms)
    from .parse import token

    start = Node(
        type=pygram.syms.print_stmt,
        children=[Leaf(type=token.PRINT, value='print', context=None)],
        context=None,
    )
    assert str(start) == 'print'
    start_new

# Generated at 2022-06-21 10:41:04.286446
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name, LESS
    node1 = Leaf(LESS, '<')
    assert repr(node1) == "Leaf(LESS, '<')"
    assert str(node1) == "<"


# Generated at 2022-06-21 10:41:15.413734
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    def _test(pat, expected):
        opt = pat.optimize()
        if opt is not expected:
            raise AssertionError(
                f"expected {expected!r}, but got {opt!r} "
                f"(original pattern was {pat!r})"
            )

    # Test LeafPattern
    pat = LeafPattern(1)
    _test(pat, pat)
    del pat.type
    _test(pat, AnyLeafPattern())
    pat.content = "x"
    pat2 = LeafPattern(1, "x")
    _test(pat, pat2)
    del pat.content
    pat.name = "x"
    pat2 = LeafPattern(1, name="x")
    _test(pat, pat2)

    # Test NodePattern
    pat = NodePattern(1)
    _

# Generated at 2022-06-21 10:41:18.432806
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    pattern = LeafPattern(type=token.NAME, content='pass')
    node = Leaf(type=token.NAME, value='pass')
    results = {}
    assert pattern.match(node, results)
    assert results['pass'] == node


# Generated at 2022-06-21 10:41:29.856203
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # WildcardPattern(content, min, max, name)
    assert WildcardPattern(name="x").optimize() == NodePattern(name="x")
    assert WildcardPattern(None, 1, 1, "x").optimize() == NodePattern(name="x")
    assert WildcardPattern(None, 1, 1, "x").optimize().optimize() == NodePattern(name="x")
    assert WildcardPattern(None, 1, 1, None).optimize() == NodePattern()
    assert WildcardPattern(None, 2, 2, "x").optimize().optimize() == WildcardPattern(None, 2, 2, "x")
    assert WildcardPattern(None, 2, 2, None).optimize() == WildcardPattern(None, 2, 2)