

# Generated at 2022-06-21 10:32:43.350117
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    np = NegatedPattern(NodePattern(name='a'))
    for n in ['a', 'ab', 'abc', 'abcd']:
        assert np.match(n) is False


# Generated at 2022-06-21 10:32:53.459948
# Unit test for method match of class WildcardPattern

# Generated at 2022-06-21 10:33:01.130972
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    wildcard = WildcardPattern([[]])
    subpattern = NodePattern(256, [])
    wildcardpattern = WildcardPattern(content=[[subpattern]])
    negpattern = NegatedPattern(content=wildcardpattern)
    assert negpattern.match(Node(256))
    assert not negpattern.match(Node(257))
    assert negpattern.match(Node(256, [Node(257), Node(258)]))
    assert not negpattern.match(Node(256, [Node(256), Node(257)]))
    assert not negpattern.match(Node(256, [Node(256)]))
    assert not negpattern.match(Node(256, [Node(256, [Node(256)])]))
    assert not negpattern.match(Node(256, [Node(256, [Node(256)])]))

# Generated at 2022-06-21 10:33:03.491747
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    assert (NegatedPattern().match_seq(
        [[]]
    )), "NegatedPattern.match_seq([[]]) failed to match"
    assert (NegatedPattern().match_seq(
        [[]]
    )), "NegatedPattern.match_seq([[]]) failed to match"


# Generated at 2022-06-21 10:33:08.858267
# Unit test for function type_repr
def test_type_repr():
    # precondition
    from .pygram import python_symbols

    for val in python_symbols.__dict__.values():  # type: ignore
        assert val != python_symbols.error_leaf or val not in _type_reprs

    # test that all tokens can be looked up
    assert type_repr(python_symbols.error_leaf) == "error_leaf"
    assert type_repr(python_symbols.comma) == "comma"
    assert type_repr(python_symbols.semicolon) == "semicolon"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"

# Generated at 2022-06-21 10:33:17.440523
# Unit test for method __new__ of class Base
def test_Base___new__():
    # pylint: disable=unused-import
    from lib2to3.pgen2 import token
    # pylint: enable=unused-import
    from . import pytree

    # pylint: disable=no-member,unsubscriptable-object
    def check(cls1: Any, cls2: Any, name: Text) -> None:
        assert cls1.x == cls2.x, (cls1.x, cls2.x, name)

    for name in "PythonString PythonNumber PythonInteger PythonFloat PythonComplex".split():
        # c1, c2 = map(PyTreeCls, [name])
        c1, c2 = map(pytree.PyTreeCls, [name])
        check(c1, c2, name)
    pytree.PyTreeCls

# Generated at 2022-06-21 10:33:29.257751
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2 import token, driver

    p = driver.ParserDriver()
    p.setup_grammar()
    assert issubclass(p.grammar.symbol2number["term"], int)
    n = NodePattern(p.grammar.symbol2number["term"])
    assert n.type == p.grammar.symbol2number["term"]
    assert n.content == []
    assert n.name is None
    assert repr(n) == "NodePattern(term)"
    n = NodePattern(p.grammar.symbol2number["term"], name="foo")
    assert n.type == p.grammar.symbol2number["term"]
    assert n.content == []
    assert n.name == "foo"

# Generated at 2022-06-21 10:33:34.140645
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern(name="a")
    assert WildcardPattern(min=1, max=1)
    assert WildcardPattern([[Leaf(token.NAME, "a")]])
    assert WildcardPattern([[WildcardPattern(min=1, max=1)]])
    raises(AssertionError, WildcardPattern, content="a")
    raises(AssertionError, WildcardPattern, content=[(1, 2)])
    raises(AssertionError, WildcardPattern, min=0, max=0)
    raises(AssertionError, WildcardPattern, min=0)
    raises(AssertionError, WildcardPattern, max=0)
    raises(AssertionError, WildcardPattern, min=-1)
    raises(AssertionError, WildcardPattern, max=-1)



# Generated at 2022-06-21 10:33:35.781493
# Unit test for method append_child of class Node
def test_Node_append_child():
    print("test_Node_append_child is not implemented")


# Generated at 2022-06-21 10:33:47.972135
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    """Unit test for method generate_matches of class WildcardPattern"""
    from .grammarparser import parse_grammar


# Generated at 2022-06-21 10:34:56.631607
# Unit test for constructor of class Base
def test_Base():
    assert issubclass(Base, object)
    b = Base()
    assert isinstance(b, object)



# Generated at 2022-06-21 10:35:04.408113
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    assert BasePattern().match(Leaf(1, "A")) == False
    assert BasePattern(1).match(Leaf(1, "A"))
    assert BasePattern(1).match(Leaf(2, "B")) == False
    assert BasePattern(1, "A").match(Leaf(1, "A"))
    assert BasePattern(1, "A").match(Leaf(1, "B")) == False
    assert BasePattern(1, results={"foo": "bar"}).match(Leaf(1, "A")) == False



# Generated at 2022-06-21 10:35:15.787046
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    def test(pat, expected):
        # Convert pattern to sequence of pairs that are arguments to
        # NodePattern and LeafPattern constructors.
        seq: List[Tuple[int, Optional[Any], Optional[Text]]] = []
        stack: List[Tuple[List[Any], List[Any], List[Any]]] = []
        stack.append((pat, seq, []))
        while stack:
            pat, seq, content = stack.pop()
            if isinstance(pat, BasePattern):
                seq.append((pat.type, pat.content, pat.name))
                if isinstance(pat, WildcardPattern):
                    stack.append((pat.pattern, content, []))
            elif isinstance(pat, (list, tuple)):
                content.extend(pat)
            else:
                content.append(pat)


# Generated at 2022-06-21 10:35:17.087765
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    leaf = Leaf(1, 'a' , context = [' ', (0, 0)], prefix = '#')
    assert str(leaf) == '#a'

# Generated at 2022-06-21 10:35:18.894967
# Unit test for method clone of class Base
def test_Base_clone():
    x = Base()
    assert (x == x.clone())



# Generated at 2022-06-21 10:35:27.434221
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    import unittest
    class TestCase(unittest.TestCase):
        def test_simple(self):
            r = Leaf(0, 'value')
            self.assertEqual([r], list(r.pre_order()))
    suite = unittest.TestSuite()
    loader = unittest.TestLoader()
    suite.addTest(loader.loadTestsFromTestCase(TestCase))
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Generated at 2022-06-21 10:35:28.480968
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import grammar

    


# Generated at 2022-06-21 10:35:34.448135
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    import pytest
    from astroid import extract_node, parse
    filecontent = '''
    def my_return(foo):
        while foo:
            return True
        return False
    '''
    node = extract_node(filecontent)
    sub_node = node.body[0].body[0].orelse
    actions2 = NegatedPattern(NodePattern(type=syms.return_stmt))
    assert actions2.match(sub_node[0])
    # Test a condition not matching : the first return match
    assert not actions2.match(node.body[0].body[0])


# Generated at 2022-06-21 10:35:35.941791
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    for tk in range(255):
        l = Leaf(tk, '')
        assert repr(l) == f"Leaf({tk}, '')", 'Leaf(%d, \'\')' % tk


# Generated at 2022-06-21 10:35:37.172973
# Unit test for method clone of class Base
def test_Base_clone():
  assert 0 # some tests


# Generated at 2022-06-21 10:36:04.932256
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern([["a", "b"], ["c"], ["d", "e", "f", "g"]], name="b")
    assert isinstance(p, WildcardPattern)
    assert p.type is None
    assert p.content == (("a", "b"), ("c",), ("d", "e", "f", "g"))
    assert p.min == 0
    assert p.max == HUGE
    assert p.name == "b"



# Generated at 2022-06-21 10:36:13.619507
# Unit test for method remove of class Base
def test_Base_remove():
    from lib2to3.pgen2.parse import parse
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pygram
    st = "a = b"
    t = parse(st)
    #print("Before:")
    #t.print_tree(True)
    a = t.children[2].children[0]
    a.remove()
    assert a.parent is None
    t.children[0].children[1].remove()
    assert t.children[0].children[1].parent is None
    t.invalidate_sibling_maps()
    #print("After:")
    #t.print_tree(True)
    def remove_leaves(t):
        while t.children:
            t.children[0].remove()
    remove

# Generated at 2022-06-21 10:36:23.432550
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import pytree
    from .pgen2 import driver
    from typing import List

    def t(s: str) -> List[pytree.Node]:
        # type: ignore
        return list(driver.parse_string(s))

    foo = NodePattern(type=1)
    bar = NodePattern(type=1)
    p = NegatedPattern(foo)
    assert tuple(p.generate_matches(t("foo bar"))) == (0, {})
    assert tuple(p.generate_matches(t("bar foo"))) == ((2, {}),)
    assert tuple(p.generate_matches(t("foo foo"))) == ()
    p = NegatedPattern()
    assert tuple(p.generate_matches(t("foo bar"))) == (0, {})

# Generated at 2022-06-21 10:36:35.330251
# Unit test for function convert
def test_convert():
    # convert()
    class Grammar:
        number2symbol = {}
    convert(Grammar(), (0, "a", None, [1, 2])).children == [1, 2]
    convert(Grammar(), (0, "a", None, [1])).children == [1]
    convert(Grammar(), (0, "a", None, [])).children == []
    Grammar.number2symbol = {0: "foo"}
    convert(Grammar(), (0, "a", None, [1, 2])).children == [1, 2]
    convert(Grammar(), (0, "a", None, [1])).children == [1]
    convert(Grammar(), (0, "a", None, [])).children == []

# Helper function for function del_node

# Generated at 2022-06-21 10:36:39.863116
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Make sure that Base can't be instantiated.
    try:
        Base()
    except AssertionError as e:
        assert "Cannot instantiate Base" in str(e)
    else:
        assert False, "Expected an AssertionError."

# Generated at 2022-06-21 10:36:42.880218
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(3, 'value', (None, 1))
    assert(l.post_order().__next__() is l)


# Generated at 2022-06-21 10:36:52.195702
# Unit test for function convert
def test_convert():
    # Synthesize a simple Grammar object with just one empty production.
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.symbol2number = {'single_input': 257}
    gr.start = 257
    gr.symbol2label = {}
    gr.labels = ()
    gr.keywords = ('False', 'None', 'True', 'and', 'as', 'assert', 'break',
                   'class', 'continue', 'def', 'del', 'elif', 'else', 'except',
                   'finally', 'for', 'from', 'global', 'if', 'import', 'in',
                   'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise',
                   'return', 'try', 'while', 'with', 'yield')
    gr

# Generated at 2022-06-21 10:36:53.378411
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    node = Leaf(0, 'a')
    assert node.post_order() == [node]

# Generated at 2022-06-21 10:36:57.412271
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node = Node(1, [Leaf(1, "Hello"), Leaf(1, "world")])
    assert node.pre_order().children == [node, "Hello", "world"]



# Generated at 2022-06-21 10:36:58.552882
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    with pytest.raises(AssertionError):
        BasePattern()

# Generated at 2022-06-21 10:37:25.981128
# Unit test for method clone of class Base
def test_Base_clone():
    pass



# Generated at 2022-06-21 10:37:31.299723
# Unit test for method depth of class Base
def test_Base_depth():
    root = Leaf(1, "", (1,1), lineno=1)
    child = Leaf(1, "", (1,1), lineno=1)
    child2 = Leaf(1, "", (1,1), lineno=1)
    root.append_child(child)
    root.append_child(child2)
    assert root.depth() == 0
    assert child.depth() == 1
    assert child2.depth() == 1


# Generated at 2022-06-21 10:37:35.334968
# Unit test for method remove of class Base
def test_Base_remove():
    n1 = Node(type=0)
    n2= Node(type=1)
    n1.children=[n2]
    n2.parent=n1
    n2.remove()
    assert n2.parent is None
    assert n1.children == []



# Generated at 2022-06-21 10:37:47.225609
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    a = Leaf(1, 'foo', (0, 3))
    b = Leaf(1, 'foo', (0, 3))
    c = Leaf(1, 'foo', (0, 3))
    d = Leaf(1, 'foo', (0, 3))
    e = Leaf(1, 'foo', (0, 3))
    f = Leaf(1, 'foo', (0, 3))
    g = Leaf(1, 'foo', (0, 3))
    h = Leaf(1, 'foo', (0, 3))
    i = Leaf(1, 'foo', (0, 3))
    j = Leaf(1, 'foo', (0, 3))
    k = Leaf(1, 'foo', (0, 3))
    l = Leaf(1, 'foo', (0, 3))

# Generated at 2022-06-21 10:37:54.489867
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pygram import python_symbols as syms
    from .pgen2 import token

    # f(a, b)
    node = Node(
        type=syms.funcdef,
        children=[
            Leaf(syms.NAME, "f"),
            Leaf(token.LPAR, "("),
            Leaf(syms.NAME, "a"),
            Leaf(token.COMMA, ","),
            Leaf(syms.NAME, "b"),
            Leaf(token.RPAR, ")"),
        ],
    )

# Generated at 2022-06-21 10:37:55.765348
# Unit test for constructor of class Base
def test_Base():
    assert Base()  # Just construct it and discard it



# Generated at 2022-06-21 10:38:08.034422
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from lib2to3.pgen2.tokenize import generate_tokens, COMMENT, NL
    import sys
    import io
    f_input = sys.argv[1]
    with io.open(f_input, "rb") as f:
        tokens = generate_tokens(f.readline)
    g = Grammar()
    g.parse(tokens)
    n = g.tree
    n_copy = n.clone()
    def file_data():
        f_in = io.open(f_input, "r", encoding="utf-8")
        lines = f_in.readlines()
        return "".join(lines)
    if file_data() != str(n):
        raise AssertionError("")

# Generated at 2022-06-21 10:38:17.562634
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # import this here to avoid circular imports, as this module imports
    # the module containing Base
    from .pytree import Leaf, Node
    import inspect, ast
    assert inspect.stack()[1].function == "test_Base_get_suffix"
    b = Base()
    assert b.get_suffix() == ""
    a = ast.parse("a=1")
    b = a.body[0]
    assert b.get_suffix() == "\n"
    b.remove()
    assert b.get_suffix() == ""
    assert b.next_sibling is None
    assert b.prev_sibling is None
    assert b.parent is None
    a = ast.parse("a=1")
    b = a.body[0]
    new_b = ast.parse("b=2")
   

# Generated at 2022-06-21 10:38:28.529761
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from astroid.builder import parse
    node = parse('foo', 'foo')
    pattern = LeafPattern(content='foo')
    assert pattern.match(node)
    assert pattern.match(node, {})
    assert pattern.match(node, {'bar': node})
    pattern = LeafPattern(content='bar')
    assert not pattern.match(node)
    assert not pattern.match(node, {})
    assert not pattern.match(node, {'bar': node})
    pattern = LeafPattern(name='ident')
    assert pattern.match(node, {'ident': node})
    assert not pattern.match(node)
    assert not pattern.match(node, {})
    pattern = LeafPattern(content='foo', name='ident')
    assert pattern.match(node, {'ident': node})
    assert not pattern.match

# Generated at 2022-06-21 10:38:34.629203
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from .pgen2 import tokenize

    def parse(s):
        return tokenize.generate_tokens(StringIO(s).readline)

    p1 = LeafPattern(type=tokenize.NAME, name="name")
    p2 = NodePattern(type=tokenize.EQUAL, content=[p1, LeafPattern(type=tokenize.STRING)])
    p3 = WildcardPattern(content=[[p2]])
    def test(s, expected):
        pairs = list(p3.generate_matches(parse(s)))
        assert pairs == [(2, {'name': [Name('f', 4), Newline('\n', 5)]})]

    test("f = 'a'\n", (2, {'name': [Name('f', 4), Newline('\n', 5)]}))