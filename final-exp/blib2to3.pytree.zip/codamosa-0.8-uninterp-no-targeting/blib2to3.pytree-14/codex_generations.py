

# Generated at 2022-06-21 10:32:21.663791
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Node, Leaf

    class Foo(Base):

        def __init__(self, arg):
            self.arg = arg

        def _eq(self, other):
            return self.arg == other.arg

        def clone(self):
            return Foo(self.arg)

        def post_order(self):
            yield self
            if self.children:
                for c in self.children:
                    yield from c.post_order()

        def pre_order(self):
            yield self
            if self.children:
                for c in self.children:
                    yield from c.post_order()

    tree = Node(Foo(0))
    tree.append_child(Node(Foo(1)))
    tree.append_child(Node(Foo(2)))

# Generated at 2022-06-21 10:32:30.768006
# Unit test for method remove of class Base
def test_Base_remove():
    l = Leaf(0, "test", (1, 0), [])
    assert l.remove() is None
    assert l.next_sibling is None
    assert l.prev_sibling is None
    assert l.parent is None

    l.parent = Node(0, None, (1, 0), [])
    assert l.remove() == 0
    assert l.parent is None

    first_leaf = Leaf(0, "test", (1, 0), [])
    last_leaf = Leaf(0, "test", (1, 0), [])
    node = Node(0, None, (1, 0), [first_leaf, last_leaf])

    assert first_leaf.next_sibling is last_leaf
    assert last_leaf.prev_sibling is first_leaf

    assert first_leaf.remove() == 0
   

# Generated at 2022-06-21 10:32:34.008190
# Unit test for method __new__ of class Base
def test_Base___new__():
    with pytest.raises(AssertionError) as excinfo:
        Base()
    assert "Cannot instantiate Base" in str(excinfo.value)

# Generated at 2022-06-21 10:32:36.925125
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(0, "")
    assert list(l.leaves()) == [l]
    l.parent = Node(0, [l])
    assert list(l.leaves()) == [l]


# Generated at 2022-06-21 10:32:44.247155
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from . import pytree
    node = pytree.Node(1, [])
    child = pytree.Node(2, [])
    node.insert_child(0, child)
    assert child.parent == node
    assert node.children[0] == child
    assert node.was_changed == True
    assert node.prev_sibling_map == None
    assert node.next_sibling_map == None


# Generated at 2022-06-21 10:32:53.967991
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node, Leaf
    from .pygram import python_grammar

    def find_end_semi(parent):
        for child in parent.children:
            if child.type == python_grammar.syms.semicolon:
                return child
            result = find_end_semi(child)
            if result is not None:
                return result
        return None

    grammar = python_grammar
    value = """\
foo = [
        1, 2
        ]
"""
    tree = grammar.parse_string(value, '<unknown>')
    t = tree.post_order()

# Generated at 2022-06-21 10:33:01.477438
# Unit test for function generate_matches
def test_generate_matches():
    class Node:
        def __init__(self, value, children=None):
            self.value = value
            self.children = children or []
        def __repr__(self):
            return "[{0}]".format(self.value)

    def _match(pattern, nodes):
        nodeseq = [Node(n) for n in nodes]
        matches = [(c, r) for c, r in generate_matches([NodePattern(pattern)], nodeseq)]
        return [c for c, r in matches], [r for c, r in matches]

    assert _match("a", "a") == ([1], [{}])
    assert _match("a b", "a b") == ([2], [{}])
    assert _match("a+", "a") == ([1], [{}])

# Generated at 2022-06-21 10:33:06.934020
# Unit test for method optimize of class WildcardPattern

# Generated at 2022-06-21 10:33:14.032795
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import Lark
    from .pgen2.pgen import ParserGenerator

    pg = ParserGenerator([
        ("start", [
            ["a", "b", "c", "d", "e", "f"],
        ]),
    ])
    p = Lark(pg).parser
    assert p.parse("abcdef").pretty() == "(start a b c d e f)"
    p2 = Lark(pg).parser
    assert p2.parse("abcdef").pretty() == "(start a b c d e f)"
    try:
        Lark(pg, parser="lalr").parser
    except ParseError:
        pass
    else:
        assert False, "parse error not reported"

# Generated at 2022-06-21 10:33:18.993072
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    t = Node(syms.file_input,
             [Leaf(1, "def"),
              Leaf(1, " "),
              Node(syms.funcdef,
                   [Leaf(1, "f"),
                    Leaf(1, "("),
                    Leaf(1, "x"),
                    Leaf(1, ")"),
                    Leaf(1, ":"),
                    Leaf(1, "\n"),
                    Leaf(2, "pass"),
                    Leaf(2, "\n")])])
    f1 = t.children[2]
    f1.parent = t
    f2 = t.children[2].children[3]
    f2.parent = f1
    assert f1.get_lineno() == 1

# Generated at 2022-06-21 10:34:12.329802
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    b = BasePattern.__new__(BasePattern)
    assert isinstance(b, BasePattern)
    b = BasePattern.__new__(LeafPattern)
    assert isinstance(b, LeafPattern)
    b = BasePattern.__new__(NodePattern)
    assert isinstance(b, NodePattern)
    b = BasePattern.__new__(WildcardPattern)
    assert isinstance(b, WildcardPattern)



# Generated at 2022-06-21 10:34:19.455557
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(
        256,
        [Leaf(3, "a"), Leaf(5, "b"), Leaf(2, "c"), Leaf(5, "d"), Leaf(3, "e")],
    )
    assert n.__repr__() == "Node(SYMBOL, [Leaf(NAME, \"a\"), Leaf(COMMA, \",\"),"
    " Leaf(NAME, \"b\"), Leaf(COMMA, \",\"), Leaf(NAME, \"c\"), Leaf(COMMA, \",\"),"
    " Leaf(NAME, \"d\"), Leaf(COMMA, \",\"), Leaf(NAME, \"e\")])"

test_Node___repr__()

# Generated at 2022-06-21 10:34:25.480632
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Node, Leaf
    from .pygram import python_grammar
    from .pygram import python_symbols

    class MockGrammar(Grammar):
        def __init__(self, symbols: Dict[int, Text]) -> None:
            Grammar.__init__(self, "", "", "")
            self.symbol2number = symbols

    p = MockGrammar(python_symbols)

    tree = Node(p.symbol2number["load_stmt"], [Leaf(2, "")])
    result = tree.clone()
    assert isinstance(result, Node)
    assert repr(result) == repr(tree)
    assert result == tree



# Generated at 2022-06-21 10:34:36.333791
# Unit test for constructor of class Node
def test_Node():
    a = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    b = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    c = Node(2, [Leaf(1, "a"), Leaf(1, "b")])
    d = Node(1, [Leaf(1, "a"), Leaf(1, "c")])
    e = Node(1, [Leaf(1, "x"), Leaf(1, "y")])
    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert a.children[0] == b.children[0] == d.children[0]



# Generated at 2022-06-21 10:34:45.158535
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import pprint
    from .pgen2 import driver, token, tokenize

    source = """\
    def foo(a, b):
        return a + b
    """
    g_foo = Grammar()
    g_foo["file_input"] = (
        g_foo.stmt + ZeroOrMore(g_foo.simple_stmt + Newline) + g_foo.ENDMARKER
    )
    g_foo["stmt"] = g_foo.compound_stmt

# Generated at 2022-06-21 10:34:51.556556
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # Test cases
    test_cases = [
        # t0
        (
            Leaf(1, "hello"),
            True,
            "hello",
        ),
    ]
    # Loop over each test case
    for (i, (leaf, result, description)) in enumerate(test_cases):
        assert leaf.pre_order() == result, "test case {0}: {1!r} expected, got {2!r}".format(i+1, result, leaf.pre_order())


# Generated at 2022-06-21 10:34:55.671172
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    t = Leaf(1, "Value", fixers_applied=[])
    t1 = t.clone()
    assert t1 is not t
    assert t1.type == t.type
    assert t1.value == t.value
    assert t1.prefix == t.prefix
    assert t1.fixers_applied == t.fixers_applied


# Generated at 2022-06-21 10:34:57.293401
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    n = NegatedPattern()
    n = NegatedPattern(LeafPattern())
    n = NegatedPattern(WildcardPattern())
    n = NegatedPattern(NodePattern())



# Generated at 2022-06-21 10:35:09.675141
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf
    from .pygram import python_symbols
    for s in ["a", "1", "a+b", "+", "1.234", "1j", "()", "...", "b''"]:
        t = parse(s)
        assert t.clone() == t
        assert t.children[0].clone() == t.children[0]
        if s != "...":
            if s == "()":
                t.children[0].prefix = " "
            else:
                t.children[0].prefix = " " * 5
            t2 = t.clone()
            assert t != t2
            assert t2.children[0].prefix == " " * 5
            t2.children[0].prefix = ""

# Generated at 2022-06-21 10:35:10.691996
# Unit test for method clone of class Base
def test_Base_clone():
    import pytest
    with pytest.raises(NotImplementedError):
        Base().clone()


# Generated at 2022-06-21 10:35:38.891426
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pygram

    #from .pgen2 import driver // parser = driver.build_parser(pygram)
    from .pgen2 import token

    p = pygram.python_grammar_no_print_statement
    parser = Grammar(p, (token, python_symbols))
    leaf1 = Leaf(token.NAME, "test1")
    leaf2 = Leaf(token.NAME, "test2")
    test_node = Node(python_symbols.funcdef, [leaf1, leaf2])
    test_node.update_sibling_maps()
    assert test_node.prev_sibling_map[id(leaf2)] is leaf1

# Generated at 2022-06-21 10:35:49.041168
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    s = b"""\
if (foo):
    bar
"""
    # We have to use a new parser here because the symbols are already set up in
    # the standard library. This means we have to start passing in the
    # grammar as an argument

# Generated at 2022-06-21 10:36:00.655403
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    node = Node(10, [Leaf(0, "first"), Leaf(0, "second"), Leaf(0, "third")])
    node.update_sibling_maps()
    assert node.next_sibling_map[id(node.children[0])] is node.children[1]
    assert node.next_sibling_map[id(node.children[1])] is node.children[2]
    assert node.prev_sibling_map[id(node.children[2])] is node.children[1]
    assert node.prev_sibling_map[id(node.children[1])] is node.children[0]
    assert node.prev_sibling_map[id(node.children[0])] is None



# Generated at 2022-06-21 10:36:08.244483
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pytree import Node as N, Leaf as L, PyTreeVisitor as PV
    from .python_tree import PythonTreeVisitor as PTV

    from . import pygram as P
    from . import python_tree as PT

    class LeafVisitor(PV):
        def visit_leaf(self, node: L, children: Iterable[Any]) -> Text:
            return node.value
        def visit_error_leaf(self, node: L, children: Iterable[Any]) -> Text:
            return node.value

    class Visitor(PTV, LeafVisitor):
        def visit_node(self, node: N, children: Iterable[Any]) -> Text:
            return ''.join(children)

    grammar = P.python_grammar_no_print_statement
    # Test insert before first child

# Generated at 2022-06-21 10:36:12.985369
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.string) == "string"
    assert type_repr(python_symbols.integer) == "integer"
    assert type_repr(python_symbols.atom) == "atom"
    assert type_repr(python_symbols.single_input) == "single_input"
#

FuncType = TypeVar("FuncType", bound=Callable[..., Any])



# Generated at 2022-06-21 10:36:23.221165
# Unit test for function generate_matches
def test_generate_matches():
    assert list(
        generate_matches([NodePattern(type=NAME), NodePattern(type=NUMBER)], [
            nl_name(1),
            nl_number(2)
        ])
    ) == [(2, {})]

# Generated at 2022-06-21 10:36:25.218824
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "text")
    assert not leaf.children
    assert list(leaf.leaves()) == [leaf]



# Generated at 2022-06-21 10:36:30.680839
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(0, [])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map is None, repr(node.prev_sibling_map)
    assert node.next_sibling_map is None, repr(node.next_sibling_map)

test_Node_invalidate_sibling_maps()


# Generated at 2022-06-21 10:36:34.593910
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    arg1=BasePattern()
    arg2=BasePattern()
    expect=(BasePattern(),BasePattern())
    actual=arg1, arg2
    assert actual == expect

# Generated at 2022-06-21 10:36:46.535490
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    # Test .?
    pattern = WildcardPattern(min=0, max=1)
    assert pattern is not None
    assert pattern.content is None
    assert pattern.min == 0
    assert pattern.max == 1
    assert pattern.name is None

    # Test .*
    pattern = WildcardPattern()
    assert pattern is not None
    assert pattern.content is None
    assert pattern.min == 0
    assert pattern.max == sys.maxsize
    assert pattern.name is None

    # Test .+
    pattern = WildcardPattern(min=1)
    assert pattern is not None
    assert pattern.content is None
    assert pattern.min == 1
    assert pattern.max == sys.maxsize
    assert pattern.name is None

    # Test .{3}

# Generated at 2022-06-21 10:37:13.172255
# Unit test for method changed of class Base
def test_Base_changed():
    a = Base()
    assert not a.was_changed

    class Node(Base):
        def clone(self) -> Any:
            raise NotImplementedError

        def _eq(self, other: Any) -> bool:
            raise NotImplementedError

        def post_order(self) -> Iterator[NL]:
            raise NotImplementedError

        def pre_order(self) -> Iterator[NL]:
            raise NotImplementedError

    b = Node()
    b.changed()
    assert b.was_changed
    assert a.was_changed



# Generated at 2022-06-21 10:37:14.636729
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert_raises(NotImplementedError, BasePattern)

# Generated at 2022-06-21 10:37:24.929364
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    global A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z

# Generated at 2022-06-21 10:37:33.024051
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    with pytest.raises(TypeError):
        Leaf()
    #
    with pytest.raises(TypeError):
        Leaf(type=None)
    #
    with pytest.raises(TypeError):
        Leaf(type=None, value=None)
    #
    with pytest.raises(TypeError):
        Leaf(type=None, value=None, context=None)
    #
    with pytest.raises(TypeError):
        Leaf(type=None, value=None, context=None, prefix=None)
    #
    with pytest.raises(TypeError):
        Leaf(type=None, value=None, context=None, prefix=None,
             fixers_applied=None)
    #

# Generated at 2022-06-21 10:37:44.742068
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    ns = [
        Node(0, [Leaf(1, "first"), Leaf(1, "second")]),
        Node(0, [Leaf(1, "first"), Leaf(1, "second"), Node(0, [Leaf(1, "third")])]),
        Node(0, [Leaf(1, "first"), Node(0, [Leaf(1, "second")]), Node(0, [Leaf(1, "third")])]),
        Node(0, [Node(0, [Leaf(1, "first")]), Node(0, [Leaf(1, "second")]), Node(0, [Leaf(1, "third")])]),
        None
    ]
    for n in ns:
        if n is None:
            continue

# Generated at 2022-06-21 10:37:52.457286
# Unit test for method depth of class Base
def test_Base_depth():
    root = Node(0, None, None, [])
    assert root.depth() == 0
    first_child = Node(1, root, None, [])
    root.append_child(first_child)
    assert root.depth() == 0
    assert first_child.depth() == 1
    second_child = Node(2, root, None, [])
    root.append_child(second_child)
    assert root.depth() == 0
    assert first_child.depth() == 1
    assert second_child.depth() == 1


# Generated at 2022-06-21 10:37:55.812746
# Unit test for method __str__ of class Node
def test_Node___str__():
    from .pytree import Leaf, Node
    # Root node
    tree = Node(1, [Leaf(1, 'foo'), Leaf(1, 'bar')])
    res = str(tree)
    assert res == 'foobar'

# Generated at 2022-06-21 10:37:58.276346
# Unit test for method changed of class Base
def test_Base_changed():
    # TODO: Replace with a unit test
    # self.assertTrue(hasattr(Base, 'changed'))
    pass



# Generated at 2022-06-21 10:37:59.814021
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    pattern = NegatedPattern(None)
    assert pattern.content == None


# Generated at 2022-06-21 10:38:07.938780
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node.__new__(Node)
    node.children = [None]
    assert str(node) == ""
    node.children = [Leaf(1, "")]
    assert str(node) == ""
    node.children = [Leaf(1, "1")]
    assert str(node) == "1"
    node.children = [Leaf(1, "1"), Leaf(1, "2")]
    assert str(node) == "12"

# Generated at 2022-06-21 10:38:57.605564
# Unit test for method clone of class Base
def test_Base_clone():
    class ConcreteBase(Base):
        def __init__(self, *args, **kwds):
            Base.__init__(self, *args, **kwds)

        def _eq(self, other):
            return self.__dict__ == other.__dict__

        def clone(self):
            raise NotImplementedError

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

    node1 = ConcreteBase()
    node1.type = 1
    node2 = node1.clone()
    assert node1 == node2, "Clone should have identical properties"
    assert (
        node1 is not node2
    ), "Clone should not be the same object as original"



# Generated at 2022-06-21 10:39:03.687339
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # 1
    # +-2
    # | +-3
    # +-4
    #   +-5
    a1 = Node(1, [Node(2, [Leaf(3, "2")]), Node(4, [Leaf(5, "4")])])
    assert a1.pre_order() == [Leaf(3, "2"), Node(2, [Leaf(3, "2")]), Leaf(5, "4"), Node(4, [Leaf(5, "4")]), Node(1, [Node(2, [Leaf(3, "2")]), Node(4, [Leaf(5, "4")])])]
    # 1
    # +-2
    #   +-3
    # +-4
    #   +-5

# Generated at 2022-06-21 10:39:07.690118
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(0, 0, None, None)
    assert l.type == 0
    assert l.value == 0
    assert l.parent is None
    assert l.prefix == ""
    assert l.children == []

# Generated at 2022-06-21 10:39:18.691387
# Unit test for constructor of class Leaf
def test_Leaf():
    l1 = Leaf(1, 'hi')
    assert len(l1.children) == 0
    assert l1.prefix == ''
    assert l1.lineno == 0
    assert l1.column == 0
    assert l1.value == 'hi'
    l2 = Leaf(2, 'bye', (l1.prefix, (l1.lineno, l1.column)))
    assert l2.prefix == ''
    assert l2.lineno == 0
    assert l2.column == 0
    assert l2.value == 'bye'
    l3 = Leaf(3, 'bye', (' ', (l1.lineno, l1.column)))
    assert l3.prefix == ' '
    assert l3.lineno == 0
    assert l3.column == 0
    assert l3.value == 'bye'
   

# Generated at 2022-06-21 10:39:24.852069
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    for i in BasePattern().generate_matches([]):
        raise self.failureException("Expected no matches but got %r" % list(BasePattern().generate_matches([])))
    try:
        next(BasePattern().generate_matches([Leaf(1, "a"), Leaf(2, "b")]))
    except StopIteration:
        pass
    else:
        raise self.failureException("Expected no matches but got %r" % list(BasePattern().generate_matches([Leaf(1, "a"), Leaf(2, "b")])))
    node = Node(3, [Leaf(1, "a"), Leaf(2, "b")])
    assert next(BasePattern(3).generate_matches([node])) == (1, {})

# Generated at 2022-06-21 10:39:37.297352
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pattern_lib import Name, Number

    class Pattern(BasePattern):

        def _submatch(self, node, results):
            return True

    p = Pattern(NAME)
    assert p.optimize() is p
    p = Pattern(NAME, "foo")
    p2 = p.optimize()
    assert isinstance(p2, Name)
    assert p2.name == "foo"
    p = Pattern(NUMBER, "4.2")
    p2 = p.optimize()
    assert isinstance(p2, Number)
    assert p2.value == "4.2"
    p = Pattern(NUMBER, "4.2", "foo")
    p2 = p.optimize()
    assert isinstance(p2, Number)
    assert p2.value == "4.2"
    assert p

# Generated at 2022-06-21 10:39:38.032885
# Unit test for constructor of class Base
def test_Base():
    a = Base()  # This should fail to initialize.



# Generated at 2022-06-21 10:39:39.433300
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    Leaf(1, "foo")


# Generated at 2022-06-21 10:39:50.734137
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():

    lp = LeafPattern(type=2, content="bar")
    n = Node(type=1, children=[Leaf(type=2, value="bar"), Leaf(type=3, value="baz")])
    assert lp.match(n) is False
    assert lp.match(n.children[0]) is True
    assert lp.match(n.children[1]) is False

    lp = LeafPattern(type=None, content="bar")
    assert lp.match(n) is False
    assert lp.match(n.children[0]) is True
    assert lp.match(n.children[1]) is False

    lp = LeafPattern(type=2, content=None)
    assert lp.match(n) is False
    assert lp.match(n.children[0]) is True


# Generated at 2022-06-21 10:39:51.687989
# Unit test for method remove of class Base
def test_Base_remove():
    assert 1
    return


# Generated at 2022-06-21 10:41:14.946851
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    assert list(NegatedPattern(LeafPattern(1)).generate_matches([])) == [(0, {})]
    assert list(NegatedPattern(LeafPattern(1)).generate_matches([Leaf(1)])) == []

# Generated at 2022-06-21 10:41:16.713493
# Unit test for constructor of class Base
def test_Base():
    Base()


# These helper functions are used by replace(), which is often
# called in pass 3.

# Generated at 2022-06-21 10:41:27.773959
# Unit test for method leaves of class Base
def test_Base_leaves():
    # type: () -> None

    l = Leaf(1, "")
    n = Node(2, [l])
    assert list(n.leaves()) == [l]
    assert list(n.pre_order()) == [n, l]
    assert list(n.post_order()) == [l, n]

    l2 = Leaf(1, "")
    assert l == l2
    assert l.clone() == l

    l3 = Leaf(1, "")
    n2 = Node(2, [l3])
    assert n.clone() == n2
    try:
        n.replace(None)
        assert False, "replace() should have raised an exception"
    except AssertionError:
        pass

    n.replace(l)
    assert n.children == [l]