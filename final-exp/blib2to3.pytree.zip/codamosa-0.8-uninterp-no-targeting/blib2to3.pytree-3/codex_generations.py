

# Generated at 2022-06-21 10:32:41.550066
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name

    class MyPattern(BasePattern):
        type = tok_name["NAME"]
    pattern = MyPattern(tok_name["NAME"])
    nodes = [Leaf(tok_name["NAME"], "hello")]
    assert pattern.match_seq(nodes)
    nodes = [Leaf(tok_name["NAME"], "hello"), Leaf(tok_name["NAME"], "world")]
    assert not pattern.match_seq(nodes)
test_BasePattern_match_seq()



# Generated at 2022-06-21 10:32:46.966773
# Unit test for function generate_matches
def test_generate_matches():
    def test(patterns, nodes):
        print("Generating", patterns, nodes)
        result = list(generate_matches(patterns, nodes))
        print(result)
        return result

    class DummyPattern:
        def __init__(self, n):
            self.n = n

        def generate_matches(self, nodes):
            if nodes:
                yield self.n, {}

    p1 = DummyPattern(1)
    p2 = DummyPattern(2)
    p3 = DummyPattern(3)
    assert test([p1], [1]) == [(1, {})]
    assert test([p1, p2], [1, 2]) == [(2, {})]
    assert test([p1, p2, p3], [1, 2, 3]) == [(3, {})]

# Generated at 2022-06-21 10:32:55.411265
# Unit test for method replace of class Base
def test_Base_replace():
    """Test method replace."""
    lineno = 1
    tokens = [
        ("NAME", "a", lineno),
        ("OP", "+", lineno),
        ("NAME", "b", lineno),
        ("NEWLINE", "\n", lineno),
        ("NAME", "x", lineno + 1),
    ]
    stream = tokenize_str("".join(s for t, s, _ in tokens))
    tree = build_ast(stream)
    assert str(tree) == "Module(stmt=[Expr(value=BinOp(left=Name(id='a'), op=Add(), right=Name(id='b')))])"
    a = tree.children[0].children[0].children[0]
    assert a.type == python_symbols.power

# Generated at 2022-06-21 10:32:59.080282
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    for name in dir(python_symbols):
        val = getattr(python_symbols, name)
        if type(val) == int:
            assert python_symbols.__dict__[type_repr(val)] == val



# Generated at 2022-06-21 10:33:04.387884
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2 import token
    from .pgen2.token import NAME
    from .pgen2.parse import SimpleParser
    from .pytree import Leaf

    def get_subtree(t, key):
        for item in t.post_order():
            if len(item.children) == 1 and isinstance(item.children[0], Leaf):
                if item.children[0].value == key:
                    if item.prefix.strip() != "":
                        return item.prefix
                    else:
                        return item
                else:
                    continue
    import inspect
    l = Leaf(NAME, "a", (0, 0))
    d = inspect.getargspec(Leaf.clone)
    assert len(d.args) == 1
    l0 = l.clone()
    assert l0.type == NAME
    assert l

# Generated at 2022-06-21 10:33:05.663563
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    def test_method(cls):
        # Test this class
        pass
    test_method(BasePattern)


# Generated at 2022-06-21 10:33:08.213350
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(257, [])
    assert node.__repr__() == "Node(NAME, [])"


# Generated at 2022-06-21 10:33:11.169044
# Unit test for constructor of class Leaf
def test_Leaf():
    a = Leaf(1, "hi", context=(" ", (1, 2)))
    assert a.type == 1, a.type
    assert a.value == "hi", a.value
    assert a.prefix == " ", a.prefix



# Generated at 2022-06-21 10:33:19.884395
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    # list of params for constructor of class Leaf
    list_params = [
        (256, "value", (("prefix", (1, 1)),)),
        (256, "value", (("prefix", (1, 1)),)),
        (256, "value", (("prefix", (1, 1)),)),
        (256, "value", (("prefix", (1, 1)),)),
    ]

    try:
        # call the function that we are testing
        for param_1 in list_params:
            obj=Leaf(*param_1)
            obj.clone()
    except:
        assert False


# Generated at 2022-06-21 10:33:23.465143
# Unit test for method changed of class Base
def test_Base_changed():
    from . import pytree

    foo = pytree.Leaf(0, "foo")
    assert not foo.was_changed
    foo.changed()
    assert foo.was_changed



# Generated at 2022-06-21 10:34:03.044934
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # See http://bugs.python.org/issue12834
    p = WildcardPattern([], max=3)
    assert p.match_seq([])
    assert p.match_seq([])
    assert p.match_seq([])
    assert not p.match_seq([None])
    assert not p.match_seq([None, None])

    q = WildcardPattern([[Leaf()]], max=3)
    assert not q.match_seq([])
    assert q.match_seq([None])
    assert q.match_seq([None, None])
    assert q.match_seq([None, None, None])
    assert not q.match_seq([None, None, None, None])
    assert not q.match_seq([None, None, None, None, None])


# Generated at 2022-06-21 10:34:15.418925
# Unit test for method pre_order of class Node

# Generated at 2022-06-21 10:34:27.797352
# Unit test for function convert
def test_convert():

    gr = Grammar()
    gr.add_production("x", ["y", "z", "y"], None, None)
    gr.add_production("a", ["b"], None, None)
    gr.add_production("y", ["c"], None, None)

    # If there's exactly one child, return that child instead of
    # creating a new node.
    def node_a(children):
        return Node(gr.symbol2number["a"], children, context=None)

    assert node_a([Leaf(0, "1", context=None)]) == convert(gr, (0, None, None, [
                Leaf(0, "1", context=None)
            ]))

    # If there's more than one child, dig deeper

# Generated at 2022-06-21 10:34:39.974419
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    leaf = Leaf(1, "asd")
    assert leaf.type == 1
    assert leaf.value == "asd"
    assert leaf.children == []
    assert leaf.parent == None
    assert leaf.prefix == ""
    assert leaf.fixers_applied == []
    assert leaf.bracket_depth == 0
    assert leaf.opening_bracket == None
    assert leaf.used_names == None
    assert leaf._prefix == ""
    assert leaf.lineno == 0
    assert leaf.column == 0

    leaf_repr = repr(leaf)                                                    # Creates a string representation of the object leaf
    assert leaf_repr == "Leaf(1, 'asd')"                                      # Checks if the string representation is correct

    leaf_str = str(leaf)                                                      # Creates a string of the object leaf


# Generated at 2022-06-21 10:34:44.768713
# Unit test for method post_order of class Node
def test_Node_post_order():
    print('Test Node.post_order')
    tree = parse_string('{hi}')
    assert list(tree.post_order()) == [
        Leaf(123, 'hi', (1, 0)),
        Node(13, [
            Leaf(123, 'hi', (1, 0)),
        ], (1, 0)),
        Node(13, [
            Leaf(123, 'hi', (1, 0)),
        ], (1, 0)),
    ]

# Generated at 2022-06-21 10:34:50.366419
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from blib2to3.pgen2.tokenize import generate_tokens

    def token(t):
        return t.type

    for i in range(5):
        src = "if x == 0:\n    print('0!');x = 1;\nelse:\n    print(x);"
        result = list(Base.scan_tree(generate_tokens(src)))

# Generated at 2022-06-21 10:34:55.906153
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    def t(c):
        # test that the supplied Node has a lineno attribute
        if c.get_lineno() is None:
            return False
        else:
            return True
    c = Node(2, [Leaf(1, "foo", 1)])
    assert t(c)



# Generated at 2022-06-21 10:35:00.035295
# Unit test for function generate_matches
def test_generate_matches():
    p0 = NodePattern(type=1)
    p1 = NodePattern(type=2)
    p2 = NodePattern(type=3)
    p01 = NodePattern(type=1, content=[p0, p1])
    p012 = NodePattern(type=2, content=[p01, p2])
    w = WildcardPattern(content=[p012])

    nodes = [NL(1), NL(2), NL(2), NL(2), NL(1), NL(2), NL(3), NL(1), NL(2), NL(2), NL(3), NL(3), NL(1), NL(3), NL(3)]

    # Try to match w to each sequence of nodes
    for i in range(len(nodes)):
        results = {}

# Generated at 2022-06-21 10:35:12.319344
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():

    import unittest
    from . import pytree

    class Test(unittest.TestCase):

        def test1(self):
            # Make sure nodes that have children have the correct lineno
            node = pytree.Node(1, [])
            node.add_child(pytree.Leaf(1, "", (1, 0)))
            self.assertEqual(node.get_lineno(), 1)

            node2 = pytree.Node(1, [])
            node2.add_child(pytree.Leaf(1, "", (0, 0)))
            node.add_child(node2)
            self.assertEqual(node.get_lineno(), 0)

            node3 = pytree.Node(1, [])

# Generated at 2022-06-21 10:35:22.395908
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    leaf = Leaf(1, "leaf")
    pattern_type = LeafPattern(type=1)
    assert pattern_type.match(leaf)
    pattern_type_no_match = LeafPattern(type=2)
    assert not pattern_type_no_match.match(leaf)

    pattern_value = LeafPattern(content="leaf")
    assert pattern_value.match(leaf)
    pattern_value_no_match = LeafPattern(content="test")
    assert not pattern_value_no_match.match(leaf)

    pattern_value_type = LeafPattern(type=1, content="leaf")
    assert pattern_value_type.match(leaf)
    pattern_value_type_no_match = LeafPattern(type=1, content="test")
    assert not pattern_value_type_no_match.match(leaf)
#

# Generated at 2022-06-21 10:35:51.984128
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()



# Generated at 2022-06-21 10:36:04.531094
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import driver, token

    def test(q: BasePattern, p: BasePattern) -> None:
        """
        Test that q matches p exactly. Equivalent to: assert q.match(p)
        """
        if not q.match(p):
            raise ValueError("Test failed: %r does not match %r" % (q, p))

    def test_exact_match(q: BasePattern, p: NL) -> None:
        """
        Test that q matches p exactly. Equivalent to: assert q.match(p)
        """
        if not q.match(p):
            raise ValueError("Test failed: %r does not match %r" % (q, p))


# Generated at 2022-06-21 10:36:05.640696
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()



# Generated at 2022-06-21 10:36:09.192421
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    print("In method NegatedPattern_match")

    pattern = NegatedPattern(None)
    nodes = []
    result = pattern.match(nodes)

    if result:
        print("Passed test 1")
    else:
        print("Failed test 1")


# Generated at 2022-06-21 10:36:16.582301
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    new_node = Node(0,[])
    exception_occurred = False
    try:
        new_node.prev_sibling_map
    except:
        exception_occurred = True
    assert exception_occurred
    exception_occurred = False
    try:
        new_node.next_sibling_map
    except:
        exception_occurred = True
    assert exception_occurred



# Generated at 2022-06-21 10:36:21.818306
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver
    from .pgen2 import token
    gr = Driver().grammar
    for type in [token.NAME, token.NUMBER, token.STRING]:
        node = convert(gr, (type, "test", None, []))
        assert node.type == type, node.type
        assert node.children == [], node.children
        assert node.value == "test", node.value



# Generated at 2022-06-21 10:36:26.154388
# Unit test for function convert
def test_convert():
    assert convert(None, (0, "value", None, [])) == Leaf(0, "value")
    assert (
        convert(None, (0, "value", None, [Leaf(0, "value")])) == Leaf(0, "value")
    )
    children = [Leaf(0, "value1"), Leaf(0, "value2")]
    assert convert(None, (0, "", None, children)) == Node(0, children)
test_convert()

# Generated at 2022-06-21 10:36:28.425638
# Unit test for constructor of class BasePattern
def test_BasePattern():
    # Yes, we really want to test the abstract base class.
    BasePattern(None, None)



# Generated at 2022-06-21 10:36:40.931886
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    from . import token

    gr = driver.load_grammar("Grammar.txt", convert=convert)
    gen = driver.parse_string(gr, "1", tracking=True)

    # First production: integer
    x = next(gen)
    assert isinstance(x, Leaf)
    assert x.type == token.NUMBER
    assert x.value == "1"
    # Second production: atom
    x = next(gen)
    assert isinstance(x, Node)
    assert x.type == gr.number2symbol[31]  # atom
    assert len(x.children) == 1
    # Third production: power, with 2nd's child
    x = next(gen)
    assert isinstance(x, Node)
    assert x.type == gr.number2sy

# Generated at 2022-06-21 10:36:44.574843
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pygram import python_symbols as syms

    n = Node(syms.file_input)
    next_map = n.next_sibling_map
    previous_map = n.prev_sibling_map
    assert next_map is None
    assert previous_map is None

    n.invalidate_sibling_maps()
    assert n.next_sibling_map is None
    assert n.prev_sibling_map is None



# Generated at 2022-06-21 10:38:36.253099
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    p = LeafPattern(type=3, content="a", name="foo")
    assert p.type == 3
    assert p.content == "a"
    assert p.name == "foo"

    # check the defaults (set by the class)
    assert p.type == 3
    assert p.content == "a"
    assert p.name == "foo"



# Generated at 2022-06-21 10:38:45.583070
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    """Unit test for method optimize of class WildcardPattern"""
    assert WildcardPattern(content=[[NodePattern(TYPE)]]).optimize() == (
        WildcardPattern(content=[[NodePattern(TYPE)]])
    )
    assert WildcardPattern(min=2, content=[[NodePattern(TYPE)]]).optimize() == (
        WildcardPattern(min=2, content=[[NodePattern(TYPE)]])
    )
    assert WildcardPattern(content=[[WildcardPattern(content=[[LeafPattern(TYPE)]])]]).optimize() == (
        WildcardPattern(content=[[WildcardPattern(content=[[LeafPattern(TYPE)]])]])
    )

# Generated at 2022-06-21 10:38:48.562941
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert not b.children


# Type alias used to express that a function is a transformation function
# that takes in a node and outputs an iterator of one or more output nodes.
TransformationFunction = Callable[["Node"], Iterator[NL]]



# Generated at 2022-06-21 10:38:50.726684
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    assert list(Leaf(0, 'Hello').post_order()) == [Leaf(0, 'Hello')]

# Generated at 2022-06-21 10:38:55.928994
# Unit test for method depth of class Base
def test_Base_depth():

    c = Leaf(1, "")
    assert c.depth() == 0

    d = Node(2, [c])
    assert d.depth() == 1

    f = Node(3, [d])
    assert f.depth() == 2

    g = Node(4, [f])
    assert g.depth() == 3

    assert c.depth() == 0
    assert d.depth() == 1
    assert f.depth() == 2
    assert g.depth() == 3


# Generated at 2022-06-21 10:39:02.278861
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    parent = Node(42)
    child = Node(66)
    parent.append_child(child)
    assert parent.children == [child]
    new = Node(42, [Node(66, [Leaf(1)]), Node(66, [Leaf(2)])])
    parent.replace(new)
    assert parent.children == new.children
    assert parent.children[0].prefix == new.children[0].prefix

    parent = Node(42)
    child = Node(66)
    parent.append_child(child)
    assert parent.children == [child]
    new = Node(66, [Leaf(1)])
    child.replace(new)
    assert parent.children == [new]
    assert parent.children[0].prefix == new.prefix

    parent

# Generated at 2022-06-21 10:39:12.707036
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    print('Testing method generate_matches of class NegatedPattern')
    string1 = 'dont hold your breath'
    string2 = 'dont hold your breath forever'
    string3 = 'forever'
    string4 = 'hold your breath forever'
    def match(regex, string):
        if regex.match(string):
            return True
        else:
            return False
    x = NegatedPattern(NodePattern(type = 259, content = [], name = None))
    y = x.generate_matches(string1)
    assert match(x, string1) == True
    assert match(x, string2) == False
    assert match(x, string3) == False
    assert match(x, string4) == False



# Generated at 2022-06-21 10:39:21.950353
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import unittest
    class Node_update_sibling_maps_Tests(unittest.TestCase):
        def test_1(self):
            l = Leaf(1, 'a')
            l_1 = Leaf(1, 'a')
            l_2 = Leaf(1, 'a')
            self.assertEqual(l.parent, None)
            self.assertEqual(l.next_sibling, None)
            self.assertEqual(l.prev_sibling, None)

            n = Node(1, [l_1, l_2])
            self.assertEqual(n.children, [l_1, l_2])

            self.assertEqual(l_1.parent, n)
            self.assertEqual(l_1.prev_sibling, None)

# Generated at 2022-06-21 10:39:34.497311
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "foo")
    assert l.type == 1
    assert l.value == "foo"
    assert not l.children

    l = Leaf(1, "foo", (None, (2, 3)))
    assert l.type == 1
    assert l.value == "foo"
    assert not l.children

    l = Leaf(1, "foo", (None, None))
    assert l.type == 1
    assert l.value == "foo"
    assert not l.children

    l = Leaf(1, "foo", "abc")
    assert l.type == 1
    assert l.value == "foo"
    assert not l.children

    l = Leaf(1, "foo", (None, (None, None)))
    assert l.type == 1
    assert l.value == "foo"

# Generated at 2022-06-21 10:39:39.316365
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    """
    unit test for the leaves method of the Leaf class
    """
    L = Leaf(1, "hello")
    t = L.leaves()
    result = []
    for leaf in t:
        result.append(leaf)
    assert result == [L]


# Generated at 2022-06-21 10:40:05.636291
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    does_match, does_not_match = set(), set()
    for x in range(1, 17):
        does_match.add(tuple(Leaf(0) for i in range(x)))
    for x in range(2, 17):
        does_not_match.add(tuple(Leaf(0) for i in range(x)))
    for x in range(1, 5):
        does_not_match.add(tuple(Leaf(0) for i in range(2 * x + 1)))


# Generated at 2022-06-21 10:40:07.065239
# Unit test for method depth of class Base
def test_Base_depth():
    assert Base().depth() == 0


# Generated at 2022-06-21 10:40:09.881164
# Unit test for method clone of class Base
def test_Base_clone():
    N = Base
    try:
        N.clone()
    except NotImplementedError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 10:40:10.501306
# Unit test for method depth of class Base
def test_Base_depth():
    pass



# Generated at 2022-06-21 10:40:15.075291
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    pattern = NodePattern(type=syms.power)
    neg_pattern = NegatedPattern(pattern)
    nodes = [1, 2, 3, 4]
    assert neg_pattern.match_seq(nodes)
    nodes = [1, 2, 3, 4, 5]
    assert not neg_pattern.match_seq(nodes)

# Generated at 2022-06-21 10:40:22.384284
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from .nodes import Node as N
    from .parsestring import Node as S
    # (a b c)*
    w = WildcardPattern(
        content=[S('a'), S('b'), S('c')],
        min=0,
        max=HUGE,
        name='test',
    )
    assert w.optimize() == w
    # a*
    w = WildcardPattern(
        content=None,
        min=0,
        max=HUGE,
        name='test',
    )
    assert w.optimize().__dict__ == NodePattern(name='test').__dict__
    # a+
    w = WildcardPattern(
        content=None,
        min=1,
        max=HUGE,
        name='test',
    )

# Generated at 2022-06-21 10:40:26.914911
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2 import token

    assert LeafPattern(token.NAME, "foo").match(
        Leaf(token.NAME, "foo"))
    assert LeafPattern(token.NAME).match(
        Leaf(token.NAME, "foo"))
    assert not LeafPattern(token.NAME).match(
        Leaf(token.NUMBER, "42"))



# Generated at 2022-06-21 10:40:37.621181
# Unit test for method remove of class Base
def test_Base_remove():
    start = Node(2, [
        Leaf(0, "import"),
        Leaf(1, " "),
        Node(2, [
            Leaf(3, "sys"),
            Leaf(1, "."),
            Leaf(3, "argv"),
        ]),
        Leaf(0, ","),
        Leaf(1, " "),
        Node(2, [
            Leaf(3, "x"),
            Leaf(0, "="),
            Leaf(3, "1"),
        ]),
    ], prefix=" ")

    to_remove = start.children[2].children[1]
    pos = to_remove.remove()
    assert pos == 1
    assert len(start.children) == 6
    assert start.children[2].children[0].prefix == "sys."
    assert start.children[2].children

# Generated at 2022-06-21 10:40:45.896765
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Bugfix in version 2.0.2 from 2011-03-04 (commit 3c1683a0)
    # The bug occurred when mixing .* with .
    # NegatedPattern returned (0, {}) twice for the sequence of nodes
    def test(nodes: List[Text], pattern: Text, expected_counts: List[int]):
        """
        Execute the test.

        This is a unit test function for method generate_matches of class
        NegatedPattern.

        Args:
            nodes: the sequence of nodes to match
            pattern: the pattern to match
            expected_counts: the expected number of matches;
                             as a list of counts and a list of (count, results) pairs
        """
        print(f"Testing nodes={nodes}, pattern={pattern}, expected_counts={expected_counts}")


# Generated at 2022-06-21 10:40:53.696591
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Node, Leaf
    from . import token

    x = Leaf(token.NAME, "x", prefix="")
    y = Leaf(token.NAME, "x", prefix="")
    z = Leaf(token.NAME, "y", prefix="")
    # should not throw an exception
    x == y
    x == z
    x.__eq__(object())
    x.__eq__(None)

    x = Leaf(0, "", prefix="")
    x.__eq__(object())
    x.__eq__(None)



# Generated at 2022-06-21 10:41:22.026116
# Unit test for function convert
def test_convert():
    from .pgen2 import driver

    gr = driver.load_grammar(
        """
        x: 'a'
        y: x
        """
    )

    node = convert(gr, (257, None, None, [convert(gr, (1, "a", None, None))]))
    assert isinstance(node, Node)
    assert len(node.children) == 1
    assert type_repr(node.type) == "y"
    assert [type_repr(node.children[0].type)] == ["x"]
    assert type_repr(node.children[0].children[0].type) == "'a'"

    node = convert(gr, (257, None, None, [convert(gr, (257, None, None, None))]))
    assert type_repr(node.type)

# Generated at 2022-06-21 10:41:26.391632
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    tree = grammar.parse("a = (b + 1) * 3")
    assert isinstance(tree, Node)
    assert isinstance(tree.children[1], Node)
    assert isinstance(tree.children[1].children[0], Leaf)
    assert isinstance(tree.children[1].children[0].next_sibling, Leaf)
    assert tree.children[1].children[0].next_sibling.next_sibling is None
    assert tree.children[1].children[0].get_suffix() == "+ 1) * 3"
    assert tree.children[1].children[0].next_sibling.get_suffix() == " 1) * 3"
from blib2to3.pgen2 import grammar
from blib2to3.pgen2.parse import ParseError