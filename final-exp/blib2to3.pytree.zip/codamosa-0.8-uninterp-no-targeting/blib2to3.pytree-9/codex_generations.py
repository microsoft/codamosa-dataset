

# Generated at 2022-06-21 10:32:42.088362
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert str(WildcardPattern()) == ".?"
    assert str(WildcardPattern(None, 0, 1)) == ".?"
    assert str(WildcardPattern(None, 0, 2)) == ".{0,2}"
    assert str(WildcardPattern(None, 0, 3)) == ".{0,3}"
    assert str(WildcardPattern(None, 0, 1, "spam")) == ".?(spam)"
    assert str(WildcardPattern(None, 1, 1)) == "."
    assert str(WildcardPattern(None, 2, 2)) == ".."
    assert str(WildcardPattern(None, 2, 2, "spam")) == "..(spam)"
    assert str(WildcardPattern(None, 1, 2)) == ".{1,2}"
    assert str(WildcardPattern(None, 1, 3))

# Generated at 2022-06-21 10:32:46.349569
# Unit test for method append_child of class Node
def test_Node_append_child():
    _n = Node(1, [])
    assert len(_n.children) == 0
    _n.append_child(Node(2, []))
    assert len(_n.children) == 1
    assert _n.children[0].type == 2



# Generated at 2022-06-21 10:32:48.883367
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """Test method __repr__ of class Node"""
    # FIXME: write this test
    pass


# Generated at 2022-06-21 10:32:56.362880
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    class NodePattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    assert NodePattern(None).match(Node(1, []))
    assert NodePattern(None).match(Leaf(1, ""))
    assert not NodePattern(None).match(Node(1, []), {None: None})
    assert not NodePattern(None).match(Leaf(1, ""), {None: None})
    assert not NodePattern(2).match(Node(1, []))
    assert NodePattern(1).match(Node(1, []))
    assert NodePattern(1).match(Leaf(1, ""))
    assert not NodePattern(1).match(Node(2, []))
    assert not NodePattern(1).match(Leaf(2, ""))

# Generated at 2022-06-21 10:32:57.490335
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    from .tree import BasePattern
    with pytest.raises(AssertionError):
        BasePattern()

# Generated at 2022-06-21 10:33:07.928797
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf

    l1 = Leaf(1, "foo")
    l2 = Leaf(1, "bar")
    l1.replace(l2)
    assert l1.parent is None and l2.parent is None

    l1 = Leaf(1, "foo")
    l2 = Leaf(2, "bar")
    l3 = Leaf(3, "baz")
    l1.replace([l2, l3])
    assert l1.parent is None
    assert l2.parent is None
    assert l3.parent is None

    n1 = Node(1, [l1])
    n2 = Node(1, [l2])
    n3 = Node(1, [l3])
    l1.replace([n2, n3])
    assert l1.parent is None
    assert n

# Generated at 2022-06-21 10:33:16.687780
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    for i in range(4):
        for j in range(4):
            for k in range(4):
                node = Node(0,[Leaf(1, ""),Leaf(1, ""),Leaf(1, "")])
                node.update_sibling_maps()
                l1 = node.children[0]
                l2 = node.children[1]
                l3 = node.children[2]
                assert l1.prev_sibling is None
                assert l1.next_sibling is l2
                assert l2.prev_sibling is l1
                assert l2.next_sibling is l3
                assert l3.prev_sibling is l2
                assert l3.next_sibling is None



# Generated at 2022-06-21 10:33:25.952250
# Unit test for method post_order of class Base
def test_Base_post_order():

    from .pytree import Node, Leaf
    from .syms import test_atom

    node = Node(test_atom, [Leaf(1, "asdf"), Leaf(1, "jkl;")])
    post_order = list(node.post_order())
    assert len(post_order) == 3, post_order
    assert post_order[1].prefix == "jkl;", post_order
    assert post_order[2].prefix == "asdf", post_order


# Generated at 2022-06-21 10:33:38.060803
# Unit test for method changed of class Base
def test_Base_changed():
    # Baseline case: no change, no exception
    class TestNode(Node):
        def __init__(self, children=None):
            if children:
                super().__init__(None, children=children)

    node = TestNode(children=[TestNode(), TestNode()])
    node.changed()

    # No parent should cause an exception
    node = TestNode()
    try:
        node.changed()
    except Exception as e:
        assert type(e) == AttributeError
    else:
        assert False

    # A node can only have one parent at a time
    node = TestNode(children=[TestNode(), TestNode()])
    try:
        node.changed()
    except Exception as e:
        assert type(e) == RuntimeError
    else:
        assert False



# Generated at 2022-06-21 10:33:45.807750
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    """Test method __eq__ of class Base"""
    parser = Grammar()
    parser.parse_string("import abc as def")
    a = parser.parse_toplevel()
    parser.parse_string("import abc as def")
    b = parser.parse_toplevel()
    assert a == b
    parser.parse_string("import xyz as def")
    c = parser.parse_toplevel()
    assert a != c

_leaf_init = object.__init__



# Generated at 2022-06-21 10:34:11.088178
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.token import tok_name

    leaf = Leaf(tok_name['INDENT'], '    ')
    pre_order_list = list(leaf.pre_order())
    assert pre_order_list == []
test_Leaf_pre_order()


# Generated at 2022-06-21 10:34:19.427149
# Unit test for method set_child of class Node
def test_Node_set_child():
    import lib2to3.pgen2.grammar as grammar
    from lib2to3.pgen2 import token, driver
    import lib2to3.pgen2.parse as parse
    from lib2to3.pgen2.parse import ParseError
    _gr = grammar.grammar
    _convert = parse._convert

# Generated at 2022-06-21 10:34:24.753405
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name
    from .pgen2 import token
    number2symbol = {
        257: 'test',
    }
    assert BasePattern(None, 'a', 'b').__repr__() == "BasePattern(None, 'a', 'b')"
    assert BasePattern(0, 'a', 'b').__repr__() == "BasePattern(" + tok_name[0] + ", 'a', 'b')"
    assert BasePattern(257, 'a', 'b').__repr__() == "BasePattern(test, 'a', 'b')"

# Generated at 2022-06-21 10:34:27.993529
# Unit test for function type_repr
def test_type_repr():
  assert type_repr(0) == 0  # type: ignore
  from .pygram import python_symbols
  assert type_repr(python_symbols.negative) == "negative"



# Generated at 2022-06-21 10:34:31.811209
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    l = Leaf(257, 'a')
    c = l.clone()
    assert l == c
    assert l is not c
    l.type = 258
    assert l != c
    assert c.type == 257


# Generated at 2022-06-21 10:34:37.274368
# Unit test for method __new__ of class Base
def test_Base___new__():
    # test__new__()
    def f():
        Base()  # Raises exception
    try:
        f()
    except TypeError as e:
        assert str(e) == "Cannot instantiate Base", str(e)
        return
    assert False, "__new__ should have raised exception"

# Generated at 2022-06-21 10:34:45.725810
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def check_generate_matches(pattern, nodes, expected):
        check_generate_matches_impl(pattern, nodes, expected, False)

    def check_generate_matches_sorted(pattern, nodes, expected):
        check_generate_matches_impl(pattern, nodes, expected, True)

    def check_generate_matches_impl(pattern, nodes, expected, sorted):
        # Note: calling sorted is an easy way to make a list out of a generator
        expected = sorted(expected)
        generated = sorted(tuple(pattern.generate_matches(nodes)))
        assert generated == expected, "{0!r} != {1!r}".format(generated, expected)

    def p(pattern):
        """Helper function for compiling a pattern."""
        pattern = compile_pattern(pattern)
       

# Generated at 2022-06-21 10:34:54.999014
# Unit test for function generate_matches

# Generated at 2022-06-21 10:34:57.020255
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, 'a')
    it = l.pre_order() # it is an iterator object
    assert next(it).__class__.__name__ == 'Leaf'
    assert next(it) is StopIteration
    #assert next(it).__class__.__name__ == 'StopIteration'


# Generated at 2022-06-21 10:35:06.969132
# Unit test for method post_order of class Node
def test_Node_post_order():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2 import driver, token
    driver = driver.Driver(Grammar(), 'file_input')
    with open('') as inputfile:
        try:
            tokens = generate_tokens(inputfile.readline)
        except ParseError:
            pass
        else:
            tree = driver.parse_tokens(tokens)

    assert False # TODO: implement your test here



# Generated at 2022-06-21 10:35:36.583570
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern().min == 0
    assert WildcardPattern().max == HUGE
    assert WildcardPattern(min=1).min == 1
    assert WildcardPattern(max=2).max == 2
    assert WildcardPattern(min=1, max=2).max == 2
    assert WildcardPattern(min=1, max=2).min == 1
    assert WildcardPattern(min=3, max=2).max == HUGE
    assert WildcardPattern(min=3, max=2).min == 3
    assert WildcardPattern(NodePattern(type=1)).min == 0
    assert WildcardPattern(NodePattern(type=1)).max == HUGE
    assert WildcardPattern(NodePattern(type=1), min=1).min == 1
    assert WildcardPattern(NodePattern(type=1), max=2).max == 2
    assert Wild

# Generated at 2022-06-21 10:35:46.638099
# Unit test for method leaves of class Base

# Generated at 2022-06-21 10:35:50.996142
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    # Instance
    leaf = Leaf(1, 'test_value')
    # Test clone with no arguments
    assert leaf.clone() == leaf, "Test clone with no arguments"

    # Test clone with arguments
    leaf.parent = 'test_parent'
    assert leaf.clone() is not leaf, "Test clone with arguments"



# Generated at 2022-06-21 10:36:03.685433
# Unit test for method insert_child of class Node

# Generated at 2022-06-21 10:36:13.117353
# Unit test for method post_order of class Node
def test_Node_post_order():

    from .pytree import Node, Leaf
    from .pygram import python_symbols
    from . import patcomp
    from . import pytree
    import unittest

    class TestNodePostOrder(unittest.TestCase):
        def build_tree(self) -> pytree.Node:
            node = pytree.Node(python_symbols.file_input, [])
            stmt = pytree.Node(python_symbols.stmt, [])
            node.append_child(stmt)
            expr = pytree.Node(python_symbols.power, [])
            stmt.append_child(expr)
            leaf = pytree.Leaf(0, "1")
            expr.append_child(leaf)
            leaf = pytree.Leaf(0, "**")
            expr.append

# Generated at 2022-06-21 10:36:22.117613
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    t = [
        [None, 1, '"foo"', None, None],
        [None, 1, '"foo"', None, None]
    ]
    node = gr.parse(t)
    assert repr(node) == "Module(1, [Module(1, [Expr(1, [Str(3)])])])"
    assert node.match(node)
    assert node[0].match(node[0])
    assert node[0][0].match(node[0][0])
    assert node[0][0].match(node[0][0], {})



# Generated at 2022-06-21 10:36:34.340481
# Unit test for constructor of class Node
def test_Node():
    from .pygram import python_symbols

    # Test that Node() can be pickled (used to fail)
    import pickle
    import sys

    class PickleTest(Node):
        pass

    leaf = Leaf(49, "")
    node = PickleTest(
        python_symbols.testlist_comp,
        [Leaf(49, ""), Node(python_symbols.comp_for, [Leaf(49, "")])],
    )
    node.append_child(leaf)
    node.insert_child(1, leaf)
    node.set_child(2, leaf)
    node.used_names = []
    node.fixers_applied = []
    pickle.dumps(node)
    # Test that Node() copies prefix if it has a context

# Generated at 2022-06-21 10:36:38.621128
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    children = [Leaf(10, "1"), Leaf(10, "2"), Leaf(10, "3")]
    parent = Node(7, children)
    parent.update_sibling_maps()
    assert type(parent.prev_sibling_map) is dict
    assert type(parent.next_sibling_map) is dict
    assert id(children[0]) in parent.prev_sibling_map
    assert parent.prev_sibling_map[id(children[0])] is None
    assert id(children[0]) in parent.next_sibling_map
    assert parent.next_sibling_map[id(children[0])] is children[1]
    assert id(children[1]) in parent.prev_sibling_map

# Generated at 2022-06-21 10:36:46.397166
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(12, "test")
    assert l.type == 12
    assert l.value == "test"
    assert l.children == []
    assert l.parent == None
    assert l.prefix == ""
    assert l.next_sibling == None
    assert l.prev_sibling == None
    assert l.fixers_applied == None
    assert l.used_names == None
    assert l.bracket_depth == 0
    assert l.opening_bracket == None



# Generated at 2022-06-21 10:36:54.107196
# Unit test for method __repr__ of class Node

# Generated at 2022-06-21 10:37:13.472662
# Unit test for method post_order of class Node
def test_Node_post_order():
    assert_raises(NotImplementedError, Node.post_order, Node())


# Generated at 2022-06-21 10:37:17.249460
# Unit test for method leaves of class Base
def test_Base_leaves():
    from . import pytree
    from .pgen2 import token
    # setup
    tree = pytree.Node(token.LPAR, [])
    # test
    assert list(tree.leaves()) == []


# Generated at 2022-06-21 10:37:20.422699
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(1, [Leaf(1, ""), Leaf(2, "")])
    assert repr(n) == "Node(NUMBER, ['', Leaf(NEWLINE, '')])"



# Generated at 2022-06-21 10:37:29.234191
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    neg = NegatedPattern(content=None)
    test_sequence = ['a', 'b']
    count = 0
    for c, r in neg.generate_matches(test_sequence):
        count += 1
    assert count == 1
    neg = NegatedPattern(content=NodePattern(content=('a', 'b')))
    count = 0
    for c, r in neg.generate_matches(test_sequence):
        count += 1
    assert count == 1
    neg = NegatedPattern(content=WildcardPattern(content=('a', 'b')))
    count = 0
    for c, r in neg.generate_matches(test_sequence):
        count += 1
    assert count == 1

# Unit test of method match of class NegatedPattern

# Generated at 2022-06-21 10:37:30.688714
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    from .unparser import BasePattern as B
    try:
        B()
    except AssertionError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-21 10:37:35.454975
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    import datetime
    from .grammar import CFG
    from .token import tok_name

    # tests for single character match
    for t in "a", "b", "c":
        result = LeafPattern(type=ord(t)).match(Leaf(ord(t), t))
        assert result
    # tests for multiple characters match
    for t in "aa", "bb", "cc":
        result = LeafPattern(type=ord(t[0]), content=t).match(Leaf(ord(t[0]), t))
        assert result
    # tests for non-leaf-node match
    for t in "aa", "bb", "cc":
        result = LeafPattern(type=CFG.nonterminal).match(Node(CFG.nonterminal, [Leaf(ord(t[0]), t)]))

# Generated at 2022-06-21 10:37:40.985499
# Unit test for method set_child of class Node
def test_Node_set_child():
    a = Leaf(1, 'a')
    b = Leaf(2, 'b')
    node = Node(3, [a, b], None, ' ')
    assert node.children == [a, b]
    node.set_child(0, b)
    assert node.children == [b, b]
    assert node.changed() is None


# Generated at 2022-06-21 10:37:52.227788
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols
    def test(in_string: Text, expected: Text):
        tree = compile(in_string, "<test>", "exec", _ast.PyCF_ONLY_AST)
        # Find the first 'test' NAME leaf in the compiled tree
        for leaf in tree.leaves():
            if leaf.value == "test":
                break
        # Check that the suffix of this leaf is as expected.
        assert leaf.suffix == expected
    # Test 1 - the simplest case (test followed by a space and a left paren)
    test("test(", " ")
    # Test 2 - more complicated case (test followed by a comment and a CALL)
    test("test # comment\nTest(", "")
    # Test 3 - empty suffix case (test followed

# Generated at 2022-06-21 10:37:53.305493
# Unit test for constructor of class Leaf
def test_Leaf():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 10:38:05.252870
# Unit test for function convert
def test_convert():
    from .pgen2.parser import Parser
    from .pgen2.grammar import Grammar
    import os.path
    import pprint
    grammar_path = os.path.join(os.path.dirname(__file__), "Grammar")
    with open(grammar_path) as f:
        g = Grammar(f.read(), "Grammar")
    p = Parser(g, convert)
    s = "def f():\n  pass"
    t = p.parse(s)
    pprint.pprint(t)
    assert t.type == g.number2symbol[257]
    assert t.children[0].type == g.number2symbol[1]
    assert t.children[1].type == g.number2symbol[304]

# Generated at 2022-06-21 10:38:51.073057
# Unit test for constructor of class Base
def test_Base():
    try:
        b = Base()
        assert False, "Constructing Base should have given an error"
    except AssertionError:
        pass
    except:
        assert False, f"Constructing Base gave an unexpected error: {sys.exc_info()[1]}"



# Generated at 2022-06-21 10:38:53.937357
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from .pytree import Node
    from .pygram import python_symbols
    node = Node(python_symbols.arith_expr, [])
    assert repr(node) == "Node(arith_expr, [])"

# Generated at 2022-06-21 10:39:04.523750
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    original_nodes = [Node(type=Symbol.empty_stmt), Node(type=Symbol.test)]
    pattern = NegatedPattern(bare_name)
    assert pattern.match_seq(original_nodes) == True
    
    pattern = NegatedPattern(bare_name)
    assert pattern.match_seq([]) == True

    nodes = [Node(type=Symbol.empty_stmt), Node(type=Symbol.test)]
    pattern = NegatedPattern(content=comp_for)
    assert pattern.match_seq(nodes) == True

    pattern = NegatedPattern(comp_for)
    assert pattern.match_seq([]) == False
    
    nodes = [Node(type=Symbol.empty_stmt), Node(type=Symbol.test)]

# Generated at 2022-06-21 10:39:09.843694
# Unit test for method set_child of class Node
def test_Node_set_child():
    x = Leaf(1, "a child")
    n = Node(2, [Leaf(3, "some "), Leaf(4, "text")])
    n.set_child(0, x)
    assert n.children[0] is x
    assert x.parent is n



# Generated at 2022-06-21 10:39:14.232487
# Unit test for function generate_matches
def test_generate_matches():
    from . import walk

    # Standard unit tests
    r = NodePattern(type=NAME, name="nm")
    p = r + NodePattern(type=DOT, name="dot")

# Generated at 2022-06-21 10:39:25.174706
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import driver
    from .pgen2.parse import parse_grammar, dump_grammar
    from .pgen2.tokenize import tokenize_str
    import io


# Generated at 2022-06-21 10:39:37.913845
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # noinspection PyUnusedLocal
    nodes = [1, 2, 3, 4]
    w = WildcardPattern([[NodePattern()]])
    print("min=0, max=1")
    i = 0
    for c, r in w.generate_matches(nodes):
        i += 1
        print("\t%d, %d" % (c, i))

    print("min=1, max=1")
    w = WildcardPattern([[NodePattern()]], 1, 1)
    i = 0
    for c, r in w.generate_matches(nodes):
        i += 1
        print("\t%d, %d" % (c, i))

    print("min=0, max=2")

# Generated at 2022-06-21 10:39:42.026939
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    """Simple test of constructor of class NegatedPattern (Bug #11116)

    Truffle Issue #2650:
    This test failed with python 3.7 as:
    1) FAIL: test_NegatedPattern (__main__.TestNegatedPattern)
       Simple test of constructor of class NegatedPattern (Bug #11116)
       Expected: 0
       Actual  : None
    """
    # A pattern that always matches
    always = WildcardPattern()
    # A pattern that never matches
    never = NegatedPattern(always)
    # Check the number of matches for an empty list
    count = 0
    for c, r in never.generate_matches([]):
        count += 1
    assert count == 0, count


# Generated at 2022-06-21 10:39:44.415187
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(1) == 1

# Some routines to help with debugging.



# Generated at 2022-06-21 10:39:55.238655
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from . import pytree
    from .pgen2.token import SYNC

    if hasattr(pytree.Base, "pre_order"):
        assert pytree.Node.pre_order is not pytree.Base.pre_order
        assert pytree.Leaf.pre_order is not pytree.Base.pre_order
    else:
        # PyPy
        assert pytree.Node.pre_order is not Base.pre_order
        assert pytree.Leaf.pre_order is not Base.pre_order

    # Base.pre_order should not be callable
    try:
        Base.pre_order()
    except TypeError:
        pass
    else:
        raise AssertionError(
            "Base.pre_order should have raised TypeError but didn't")

    # But subclass implementations should be

# Generated at 2022-06-21 10:40:49.875865
# Unit test for method clone of class Node
def test_Node_clone():
    import lib2to3.pgen2.token as token

    x = Node(token.NAME, [Leaf(1, "x")])
    x.fixers_applied = [_fixer_gen(x)]
    y = x.clone()
    assert x == y
    assert x.fixers_applied == y.fixers_applied
    x.type = token.NAME
    assert x != y
    x = Node(token.NAME, [Leaf(token.NUMBER, "1")])
    y = x.clone()
    assert x == y



# Generated at 2022-06-21 10:40:55.525450
# Unit test for method depth of class Base
def test_Base_depth():
    n = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert n.depth() == 0
    n[0].parent = n
    assert n.depth() == 1


# Generated at 2022-06-21 10:41:06.375355
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    lp = LeafPattern(1)
    results = {}
    assert lp.match(Leaf(1)) is True
    assert lp.match(Leaf(2)) is False
    assert (
        LeafPattern(1, "1234").match(Leaf(1, "1234"), results) is True
        and results == {}
    )
    assert (
        LeafPattern(1, "12345").match(Leaf(1, "1234"), results) is False
        and results == {}
    )
    lp = LeafPattern(1, "1234", "test")
    assert (
        lp.match(Leaf(1, "1234"), results) is True and results == {"test": Leaf(1, "1234")}
    )

# Generated at 2022-06-21 10:41:09.072265
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    #
    assert BasePattern.match_seq(None, None, None) == False
    raise NotImplementedError



# Generated at 2022-06-21 10:41:19.064963
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    print("test_WildcardPattern_match")

    # initializing leaf nodes
    node_1 = Leaf(1, "a")
    node_2 = Leaf(1, "a")
    node_3 = Leaf(1, "b")

    with pytest.raises(AssertionError):
        WildcardPattern(min=2, max=1)

    with pytest.raises(AssertionError):
        WildcardPattern(min=-1)

    with pytest.raises(AssertionError):
        WildcardPattern(max=HUGE + 1)

    with pytest.raises(AssertionError):
        WildcardPattern(min=0, max=0)

    with pytest.raises(AssertionError):
        WildcardPattern(max=0)


# Generated at 2022-06-21 10:41:25.526221
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    root = Node(0,())
    root.append_child(Leaf(1,"aa"))
    print(str(root))
    print(repr(root))
    root.insert_child(0,Leaf(2,"bb"))
    print(str(root))
    print(repr(root))
