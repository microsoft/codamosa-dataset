

# Generated at 2022-06-21 10:33:15.204078
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from .make_grammar import lit_str
    a = lit_str("a")
    b = lit_str("b")
    c = lit_str("c")
    a_or_b = a | b
    a_or_b_or_c = a | b | c
    not_a = NegatedPattern(a)
    not_a_or_b = NegatedPattern(a_or_b)
    assert [(c, r)] == list(not_a.generate_matches("c"))
    assert [(0, {})] == list(not_a_or_b.generate_matches("c"))
    assert [(0, {})] == list(not_a.generate_matches(""))
    assert [(0, {})] == list(not_a_or_b.generate_matches(""))

# Generated at 2022-06-21 10:33:27.981324
# Unit test for method set_child of class Node
def test_Node_set_child():
    n = Node(1, [ Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c') ])
    # Basic tests.
    n.set_child(2, Leaf(1, 'x'))
    assert str(n) == "axbx"
    n.set_child(0, Node(1, [Leaf(1, 'm'), Leaf(1, 'n')]))
    assert str(n) == "mnxax"
    n.set_child(1, Leaf(1, '!'))
    assert str(n) == "mn!ax"
    n.set_child(2, n)
    n.set_child(1, n)
    n.set_child(0, n)
    assert str(n) == "mn!axmn!ax"
    n.set

# Generated at 2022-06-21 10:33:29.589845
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    assert list(Leaf(1, "foo").post_order()) == [Leaf(1, "foo")]


# Generated at 2022-06-21 10:33:42.383448
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    tokens = [
        ('comment', '#', 1, 0, '#'),
        ('newline', '\n', 1, 1, '\\n'),
        ('NAME', '', 2, 0, ''),
        ('newline', '\n', 2, 0, '\\n'),
    ]
    pattern = (
        (NodePattern(type=token.COMMENT), '#', NodePattern(type=token.NL)),
        NegatedPattern(NodePattern(type=token.NAME)),
        NodePattern(type=token.NEWLINE),
    )
    p = CompilePattern(pattern)
    assert p.match(tokens)


# Generated at 2022-06-21 10:33:51.857668
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from . import pgen2
    from .pgen2.token import tok_name
    from .tokenize import tokenize
    from typing import Generator

    def generator1(
        fileobj: typing.TextIO,
    ) -> Generator[typing.Tuple[int, Text, typing.Tuple[int, int]], None, None]:
        yield (1, "a", (1, 0))

    def generator2(
        fileobj: typing.TextIO,
    ) -> Generator[typing.Tuple[int, Text, typing.Tuple[int, int]], None, None]:
        yield (2, "b", (2, 0))


# Generated at 2022-06-21 10:34:02.822596
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # This is an extremely simple test case.
    tree = NL(
        "...", [NL("...", [Leaf(1, "5"), Leaf(1, "6")]), NL("...", [Leaf(1, "7")])]
    )
    pattern = WildcardPattern(name="bare_name")
    results = list(pattern.generate_matches(tree.children))
    assert len(results) == 1, results
    assert results[0][0] == 2, results
    assert len(results[0][1]) == 1, results
    assert results[0][1]["bare_name"] == tree.children, results

    # This is a more complex test case.

# Generated at 2022-06-21 10:34:15.258332
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Simple case with an empty sequence of nodes
    pattern = NegatedPattern()
    matches = list(pattern.generate_matches([]))
    assert len(matches) == 1
    count, results = matches[0]
    assert count == 0
    assert len(results) == 0
    # Complex case with non-empty sequence of nodes

# Generated at 2022-06-21 10:34:17.347446
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    try:
        Node.insert_child
    except Exception as e:
        print('insert_child not implemented')
    else:
        print('insert_child: OK')



# Generated at 2022-06-21 10:34:23.991044
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
  """Test for method update_sibling_maps of class Node."""
  from .pytree import Node, Leaf
  from .pgen2 import parse
  from .pgen2.token import Token
  from .pygram import python_symbols as syms
  from . import pytree as pytree
  from .pygram import python_grammar as pgen2_grammar
  from .pygram import python_grammar_no_print_statement as pgen2_no_print_statement_grammar
  from .fixer_util import touch_import_top
  pytree_obj = pytree
  pygram_obj = pytree
  _tuple_str = str
  syms_obj = syms
  Token_obj = Token
  grammar_obj = pgen2_grammar
  pgen2_no_print_statement

# Generated at 2022-06-21 10:34:34.950150
# Unit test for method clone of class Node
def test_Node_clone():
    """
    Unit test for method clone of class Node
    """
    x = Node(1, [])
    y = x.clone()
    z = x.clone()
    assert id(x) == id(x)
    assert id(x) != id(y)
    assert id(x) != id(z)
    assert id(y) != id(z)
    assert x.type == y.type == z.type
    assert x.children == y.children == z.children
    assert x.parent is None
    assert y.parent is None
    assert z.parent is None
    assert x._eq(y)
    assert x._eq(z)
    assert y._eq(x)
    assert y._eq(z)
    assert z._eq(x)
    assert z._eq(y)
    assert x

# Generated at 2022-06-21 10:35:02.596429
# Unit test for method __new__ of class Base
def test_Base___new__():
    with pytest.raises(AssertionError):
        Base()


# Generated at 2022-06-21 10:35:09.040887
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    text = "ai_addr"
    start = "NAME"
    value = "ai_addr"
    startpos = (1, 0)
    endpos = (1, 7)
    context = (text, (startpos, endpos))
    node = Leaf(start, value, context)
    other = Leaf(start, value, context)
    assert node == other



# Generated at 2022-06-21 10:35:17.390649
# Unit test for method changed of class Base
def test_Base_changed():
    from blib2to3.pytree import Leaf

    def _test(nod):
        nod.changed()
        assert nod.was_changed
        assert nod.parent.was_changed
        nod.parent.was_changed = False
        nod.parent.parent.was_changed = False

    leaf = Leaf(0, "test", (0, 0))
    leaf2 = Leaf(1, "test2", (0, 0))
    node = Node(0, [leaf, leaf2])
    node2 = Node(1, [node])
    _test(leaf)
    _test(node)
    _test(node2)



# Generated at 2022-06-21 10:35:26.994024
# Unit test for method __new__ of class Base
def test_Base___new__():
    from .pytree import Base, Node, Leaf
    Base()
    Node()
    Leaf()
    try:
        Base()
    except NotImplementedError:
        pass
    else:
        assert False, 'NotImplementedError not raised'
    try:
        Node()
    except NotImplementedError:
        pass
    else:
        assert False, 'NotImplementedError not raised'
    try:
        Leaf()
    except NotImplementedError:
        pass
    else:
        assert False, 'NotImplementedError not raised'
    # NB:  __new__ is an abstract class



# Generated at 2022-06-21 10:35:33.111216
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    """
    Unit test for method generate_matches of class BasePattern
    """
    import types
    assert isinstance(BasePattern.generate_matches, types.FunctionType)

if __name__ == "__main__":
    import types
    if isinstance(BasePattern, types.ModuleType):
        import pytest
        pytest.main("-qq test_pattern.py")
    else:
        test_BasePattern_generate_matches()

# Generated at 2022-06-21 10:35:38.152946
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    p = BasePattern(1, 'a')
    assert not p.match_seq([])
    assert p.match_seq([Leaf(1, 'a')])
    assert p.match_seq([Leaf(1, 'b')])
    assert not p.match_seq([Leaf(2, 's')])
    assert not p.match_seq([Leaf(1, 1)])
    assert p.match_seq([Leaf(256, 'a')])



# Generated at 2022-06-21 10:35:40.758794
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():

    from .pgen2.token import tok_name

    l = Leaf(type=tok_name['v'], value='Version',
             context=(prefix, (line, column)),
             prefix=pref, fixers_applied=[])

    res = repr(l)
    assert res == "Leaf(v, 'Version')"

# Generated at 2022-06-21 10:35:50.723937
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # tests for class WildcardPattern (TODO: add more)
    print("testing class WildcardPattern")
    x = Symbol("x")
    y = Symbol("y")
    z = Symbol("z")
    a = Symbol("a")
    b = Symbol("b")
    c = Symbol("c")
    d = Symbol("d")
    nodes = [x, y, z]
    assert WildcardPattern(min=1).match_seq(nodes)
    assert WildcardPattern(min=0, max=1).match_seq(nodes)
    assert not WildcardPattern(min=1, max=1).match_seq(nodes)
    assert not WildcardPattern(min=2).match_seq(nodes)
    assert not WildcardPattern(min=1, content=[nodes]).match_seq(nodes)

# Generated at 2022-06-21 10:35:57.827472
# Unit test for method clone of class Node
def test_Node_clone():
    class A:
        type = None
        prefix = ""
        children = []
        parent = None

        def clone(self):
            return A()

    class B:
        type = None
        prefix = ""
        children = []
        parent = None
        fixers_applied = None

        def clone(self):
            return B()

    class C:
        type = None
        prefix = ""
        children = []
        parent = None
        fixers_applied = []

        def clone(self):
            return C()

    node = Node(1, [A()])
    assert node.clone() == node

    node = Node(1, [A(), B()])
    assert node.clone() == node

    node = Node(1, [A(), B()], fixers_applied=["f", "g"])

# Generated at 2022-06-21 10:35:59.045987
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    L = Leaf(1, 1)
    assert list(L.pre_order()) == [L]



# Generated at 2022-06-21 10:36:22.820612
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    pattern = NegatedPattern()
    nodes = ()
    assert pattern.match_seq(nodes) == True


# Generated at 2022-06-21 10:36:34.393189
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    pattern = WildcardPattern(min=0, max=2, content=[[Leaf(1, "a"), Leaf(1, "a")],
                                                     [Leaf(1, "b")],
                                                     [Leaf(1, "c"), Leaf(1, "c")]])
    assert pattern.match([Leaf(1, "a"), Leaf(2, "b")])
    assert pattern.match([Leaf(1, "b")])
    assert pattern.match([Leaf(1, "a"), Leaf(1, "a")])
    assert pattern.match([Leaf(1, "c"), Leaf(1, "c")])
    assert pattern.match([Leaf(1, "b"), Leaf(1, "b")])

# Generated at 2022-06-21 10:36:36.847196
# Unit test for constructor of class Base
def test_Base():
    tree = Leaf(1, "test")
    assert tree.type == 1
    assert tree.value == "test"



# Generated at 2022-06-21 10:36:48.418367
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    from .pygram import python_symbols
    # Make a simple tree
    s = Leaf(python_symbols.test, "s", (1, 0))
    i = Leaf(python_symbols.NAME, "i", (1, 0))
    c = Leaf(python_symbols.COMMA, ",", (1, 0))
    d = Leaf(python_symbols.NAME, "d", (1, 0))
    p = Node(python_symbols.parameters, [c, d], (1, 0))
    n = Node(python_symbols.varargslist, [i,p], (1, 0))
    assert s.depth() == 0
    assert n.depth() == 0
    assert i.depth() == 1
    assert c.depth

# Generated at 2022-06-21 10:36:52.467877
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    node = Node(syms.a, [])
    node.append_child(Leaf(1, 'a'))
    node.append_child(Leaf(2, 'b'))
    node.append_child(Leaf(3, 'c'))


# Generated at 2022-06-21 10:36:56.556546
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    tree = Node(1, [])
    it = tree.pre_order()
    assert next(it) is tree
    with pytest.raises(StopIteration):
        next(it)

# Generated at 2022-06-21 10:37:06.228284
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    # basic test
    pattern = WildcardPattern(content=None)
    assert pattern.match((1, )) == True
    assert pattern.match([1, 2]) == False
    pattern = WildcardPattern(content=None, min=1, max=1)
    assert pattern.match((1, )) == True
    pattern = WildcardPattern(content=None, min=1, max=2)
    assert pattern.match((1, 2)) == True
    assert pattern.match([1, 2]) == False
    assert pattern.match((1, 2, 3)) == False
    pattern = WildcardPattern(content=None, min=0, max=3)
    assert pattern.match((1, 2)) == True
    assert pattern.match([1, 2]) == False
    assert pattern.match((1, 2, 3)) == True

# Generated at 2022-06-21 10:37:11.010393
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Test that empty nodes match.
    seq = []
    for content in (None, NodePattern(type=256), NodePattern(type=256,content=(LeafPattern(1),))):
        assert NegatedPattern(content).match_seq(seq)
    # Test that non-empty nodes fail to match.
    seq = [(LeafPattern(1),)]
    for content in (None, NodePattern(type=256), NodePattern(type=256,content=(LeafPattern(1),))):
        assert not NegatedPattern(content).match_seq(seq)
    # Test that non-empty nodes matching content may match.
    seq = [(LeafPattern(1),), (LeafPattern(2),)]

# Generated at 2022-06-21 10:37:14.142440
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    n = Node(1, [Leaf(2, "a"), Leaf(3, "b"), Leaf(4, "c")])
    n.update_sibling_maps()
    siblings = [n.children[0].next_sibling, n.children[1].next_sibling, n.children[2].next_sibling]
    assert siblings == n.children

# Generated at 2022-06-21 10:37:18.522463
# Unit test for method append_child of class Node
def test_Node_append_child():
    foo = Node(1, [])
    bar = Leaf(2, "")
    foo.append_child(bar)
    assert foo.children == [bar]
    assert foo.children[0].parent == foo
    assert foo.was_changed


# Generated at 2022-06-21 10:37:40.607338
# Unit test for method __str__ of class Node
def test_Node___str__():
  assert True # TODO: implement your test here


# Generated at 2022-06-21 10:37:44.532805
# Unit test for method clone of class Base
def test_Base_clone():
    # The tests have been moved to _test_clone_node.py.

    # The Base class is abstract.
    try:
        obj = Base()
        assert False, 'Base(...) should raise NotImplementedError'
    except NotImplementedError:
        pass
    # Note that this assert statement is valid only if the Base class
    # does not define an __init__() method.



# Generated at 2022-06-21 10:37:45.445394
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    pattern = BasePattern()
    assert pattern is not None


# Generated at 2022-06-21 10:37:53.810400
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    a = Leaf(",", [])
    b = Leaf("y", [])
    c = Leaf("z", [])
    d = Leaf("x", [])
    ab = Node(syms.testlist, [a, b])
    cd = Node(syms.testlist, [c, d])
    abcd = Node(syms.testlist, [ab, cd])
    assert list(abcd.post_order()) == [a, b, ab, c, d, cd, abcd]



# Generated at 2022-06-21 10:37:56.938485
# Unit test for constructor of class Base
def test_Base():
    """
    Check that class Base cannot be instantiated.

    >>> Base()  #doctest: +ELLIPSIS
    Traceback (most recent call last):
    ...
    NotImplementedError
    """



# Generated at 2022-06-21 10:37:58.052460
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    BasePattern()



# Generated at 2022-06-21 10:37:59.156972
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    return



# Generated at 2022-06-21 10:38:01.467008
# Unit test for constructor of class Base
def test_Base():
    # __new__

    # test that creating a Base is impossible
    with pytest.raises(AssertionError):
        Base()


# Generated at 2022-06-21 10:38:02.881214
# Unit test for constructor of class Base
def test_Base():
    try:
        Base()
    except AssertionError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-21 10:38:06.245170
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    a = Node(257, [])
    assert repr(a) == 'Node(NAME, [])'
    return

# Generated at 2022-06-21 10:38:36.303449
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    node = Leaf(123, "")
    assert node.get_lineno() is None
    node.lineno = 42
    assert node.get_lineno() == 42



# Generated at 2022-06-21 10:38:41.973409
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    import lib2to3.fixer_util

    fixer_test = lib2to3.fixer_util.StringWithMarker("def foo()\n")
    _ = lib2to3.pgen2.parse(fixer_test, debug=False)
    _.invalidate_sibling_maps()
    assert _.prev_sibling_map is None
    assert _.next_sibling_map is None



# Generated at 2022-06-21 10:38:49.927435
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import parse

    def test(source, expected):
        actual = parse(source, optimize=True)
        assert actual == expected, (
            "Actual:   %s\nExpected: %s" % (repr(actual), repr(expected))
        )

    test(".+", NodePattern(min=1))
    test(".*", NodePattern(min=0))
    test(".?", NodePattern(min=0, max=1))
    test(".{2,3}", NodePattern(min=2, max=3))
    test(".{5}", NodePattern(min=5, max=5))
    test("(a|b)+", WildcardPattern([(LeafPattern("a"),), (LeafPattern("b"),)], min=1))

# Generated at 2022-06-21 10:39:00.279774
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Non-empty group: return a match if the argument pattern has no matches
    pattern_1 = NegatedPattern(NodePattern(Symbol.testList_star_expr, [Name(Symbol.test_star_expr, "x1", lineno=1), Name(Symbol.test_star_expr, "x2", lineno=1),], lineno=1, col_offset=0))
    # Test empty sequence of nodes: return a match if there is an empty sequence
    pattern_2 = NegatedPattern()
    node = Name(Symbol.test_star_expr, "x1", lineno=1)
    nodes_list = [node]

# Generated at 2022-06-21 10:39:11.159870
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import tok_name

    l1 = Leaf(1, "abc", context=("  ", (12, 13)))
    l2 = l1.clone()
    assert l1 != l2
    assert l1.type == l2.type
    assert l1.type == tok_name[1]
    assert l1.value == l2.value
    assert l1.value == "abc"
    assert l1.prefix == l2.prefix
    assert l1.prefix == "  "
    assert l1.lineno == l2.lineno
    assert l1.lineno == 12
    assert l1.column == l2.column
    assert l1.column == 13

# Generated at 2022-06-21 10:39:13.364787
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pgen2.token import NUMBER
    from .pgen2.parse import parse_string
    n = parse_string("1")
    assert next(n.children[1].leaves()) == Leaf(type=NUMBER, value=1, prefix="1\n")
test_Leaf_leaves()

# Generated at 2022-06-21 10:39:22.173247
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from . import parsetokens

    import unittest

    class Test(unittest.TestCase):
        def test_leaf_match(self):
            self.assertTrue(LeafPattern().match(Leaf(1, "abc")))
            self.assertFalse(LeafPattern().match(Node(2, [])))

        def test_node_match(self):
            self.assertTrue(NodePattern().match(Leaf(1, "abc")))
            self.assertTrue(NodePattern().match(Node(2, [])))
            self.assertFalse(NodePattern(content=["abc"]).match(Leaf(1, "abc")))
            self.assertTrue(NodePattern(content=["abc"]).match(Node(2, ["abc"])))

# Generated at 2022-06-21 10:39:34.727939
# Unit test for method depth of class Base
def test_Base_depth():
    class Node(Base):
        def _eq(self, other):
            return self is other

        def clone(self):
            return self

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

    class Leaf(Base):
        def _eq(self, other):
            return self is other

        def clone(self):
            return self

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

    my_leaf = Leaf()
    my_node = Node()
    my_leaf2 = Leaf()
    my_node2 = Node()
    my_node2.children.append(my_leaf)
    my_node.children.append(my_leaf2)
    my_node.children.append(my_node2)


# Generated at 2022-06-21 10:39:47.503028
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    W = WildcardPattern
    assert W(min=1).match_seq([]) is False
    assert W(min=1).match_seq([Leaf(1, "a")]) is True
    assert W(min=1).match_seq([Leaf(1, "a"), Leaf(1, "b")]) is True
    assert W(min=1, name="x").match_seq([Leaf(1, "a")]) == {
        "x": [Leaf(1, "a")]
    }
    assert W(min=2).match_seq([Leaf(1, "a")]) is False
    assert W(min=2).match_seq([Leaf(1, "a"), Leaf(1, "b")]) is True

# Generated at 2022-06-21 10:39:49.529395
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    a=LeafPattern(name='a',type='a',content='b')
    a.match(node = a)

# Generated at 2022-06-21 10:40:13.166685
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():

    # test the match method
    class dummy_node:
        def __init__(self, children):
            self.children = children

    # test pattern with no content
    wp = WildcardPattern(min=3, max=6)
    r = {}
    assert wp.match(dummy_node([]), r) == False
    assert wp.match(dummy_node([1,2,3]), r) == True
    assert wp.match(dummy_node([1,2,3,4,5,6]), r) == True
    assert wp.match(dummy_node([1,2,3,4,5,6,7]), r) == False

    # test pattern with no content and min = 0
    wp = WildcardPattern(min=0)
    r = {}

# Generated at 2022-06-21 10:40:14.124897
# Unit test for constructor of class Base
def test_Base():
    assert Base()



# Generated at 2022-06-21 10:40:17.264359
# Unit test for constructor of class NodePattern
def test_NodePattern():
    NodePattern()
    NodePattern(256)
    NodePattern(256, [])
    NodePattern(1)
    NodePattern(1, [])
    NodePattern(1, ["a"])
    NodePattern(1, ["a"], "foo")



# Generated at 2022-06-21 10:40:23.950665
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pgen2 import grammar
    from .pygram import python_symbols as syms
    from .pgen2.parse import LiteralsParser
    from .pytree import Leaf, type_repr

    # Get some text and parse it
    with open('blib2to3/pgen2/pgen.grammar', 'r', encoding='utf-8') as file:
        text = file.read()

    pygram = grammar.Grammar()
    lparser = LiteralsParser("grammar", pygram)
    tree = lparser.parse(text)

    # Let's assume we want to get the symbol name of the symbol following
    # a SYNC node. SYNCs can appear in any rule, though, so we'll have to
    # iterate through all of them.

# Generated at 2022-06-21 10:40:30.225850
# Unit test for method clone of class Node
def test_Node_clone():
    """ Test clone of class Node """
    Node.__init__()
    Node.__repr__()
    Node.__str__()
    Node._eq()
    Node.clone()
    Node.post_order()
    Node.pre_order()
    Node.prefix
    Node.set_child()
    Node.insert_child()
    Node.append_child()
    Node.invalidate_sibling_maps()
    Node.update_sibling_maps()


# Generated at 2022-06-21 10:40:40.795258
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    import unittest
    from .pgen2.token import Token
    from .pgen2.tokenize import generate_tokens, TokenInfo
    from .pygram import python_symbols
    a_token = Token()
    a_token.type = python_symbols.testlist
    a_token.value = "testlist"
    a_node = Node(a_token, [])
    a_token.value = "testlist_comp"
    a_token.type = python_symbols.testlist_comp
    a_node.children = [Leaf(a_token, [])]
    a_token.value = "yield_expr"
    a_token.type = python_symbols.yield_expr
    a_stmt = Node(a_token, [])
    a_

# Generated at 2022-06-21 10:40:45.959590
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    a = Leaf(0, '')
    b = Leaf(0, '')
    c = Leaf(0, '')
    n = Node(0, [a, b, c])
    n.update_sibling_maps()

    assert a.next_sibling == b
    assert a.prev_sibling is None
    assert b.next_sibling == c
    assert b.prev_sibling == a
    assert c.next_sibling is None
    assert c.prev_sibling == b


# Generated at 2022-06-21 10:40:55.552775
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    n = Node(test_Base_pre_order.__code__.co_firstlineno, '', ())
    n.children = [Leaf(test_Base_pre_order.__code__.co_firstlineno + 1, '', ())]
    n.children.append(Leaf(test_Base_pre_order.__code__.co_firstlineno + 2, '', ()))
    n1 = Node(test_Base_pre_order.__code__.co_firstlineno + 3, '', ())
    n1.children = [Leaf(test_Base_pre_order.__code__.co_firstlineno + 4, '', ())]
    n1.children.append(Leaf(test_Base_pre_order.__code__.co_firstlineno + 5, '', ()))
    n

# Generated at 2022-06-21 10:41:06.406080
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    # TODO: fix this
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pygram import python_grammar
    t = Leaf(1, "")
    n = Node(syms.simple_stmt, [t])
    assert n.parent is None
    assert n.next_sibling is None
    assert n.prev_sibling is None
    n.fixers_applied = None
    assert n.fixers_applied is None
    assert n.used_names is None
    n.used_names = set(["x"])
    assert n.used_names == set(["x"])
    n.changed()
    assert n.was_changed
    n.was_checked = False
    assert not n.was_checked
    n.was

# Generated at 2022-06-21 10:41:17.453310
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    s = Node(1234,[])
    s.update_sibling_maps()
    assert s.prev_sibling_map == {}
    assert s.next_sibling_map == {}
    assert type(s.prev_sibling_map) is dict
    assert type(s.next_sibling_map) is dict

    s = Node(1234,[Leaf(1234, "_"), Leaf(1234, "_"), Leaf(1234, "_"), Leaf(1234, "_")])
    s.update_sibling_maps()
    assert s.prev_sibling_map == {id(s.children[1]): None, id(s.children[0]): None, id(s.children[2]): s.children[1], id(s.children[3]): s.children[2]}
    assert s.next