

# Generated at 2022-06-11 19:58:48.974392
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    bp = BasePattern()
    assert bp.optimize() is bp
##########################################################################
# CLASSES LeafPattern, NodePattern, WildcardPattern
##########################################################################



# Generated at 2022-06-11 19:58:53.544812
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    """Unit test for method pre_order of class Leaf"""

    l = Leaf(token.NAME, 'name')
    assert list(l.pre_order()) == [l]

# Generated at 2022-06-11 19:59:00.181508
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    n = Node(type=1, children=[Leaf(1, 'a'), Node(type=2, children=[Leaf(1, 'b'), Leaf(1, 'c')])])
    assert list(n.leaves()) == [Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c')]

# Generated at 2022-06-11 19:59:02.627988
# Unit test for method set_child of class Node
def test_Node_set_child():
    n = Node(1, [])
    n.set_child(0, Leaf(1, "a"))
    assert n.children[0].value == "a"


# Generated at 2022-06-11 19:59:14.354597
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pgen2.token import tok_name

    for i in range(256):
        t = Leaf(i, "")
        assert str(t) == ""
        assert t.leaves() == [t]
        assert t.post_order() == [t]
        assert t.pre_order() == [t]
        t = Leaf(i, "token")
        assert str(t) == "token"
        assert t.leaves() == [t]
        assert t.post_order() == [t]
        assert t.pre_order() == [t]
        t = Leaf(i, "token with spaces")
        assert str(t) == "token with spaces"
        assert t.leaves() == [t]
        assert t.post_order() == [t]
        assert t.pre_order()

# Generated at 2022-06-11 19:59:20.091627
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():

    # Node testing
    class X(object):

        def _submatch(self, node, results=None):
            return True

    x = BasePattern.__new__(X)
    x.type = 1
    x.content = 'content'
    assert x.generate_matches([object]) == [(1, {})]



# Generated at 2022-06-11 19:59:22.084907
# Unit test for function type_repr
def test_type_repr():  # type: () -> None
    assert type_repr(1) == "NAME"



# Generated at 2022-06-11 19:59:23.678411
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import pytest
    pytest.skip("TODO")

# Generated at 2022-06-11 19:59:37.163415
# Unit test for method remove of class Base
def test_Base_remove():
    import copy
    from .pytree import Leaf, Node
    from textwrap import dedent

    def check_remove(removed_child):
        child_orig = copy.deepcopy(removed_child)
        parent_orig = removed_child.parent
        lineno = parent_orig.get_lineno()
        node = copy.deepcopy(parent_orig)
        parent_orig.remove()
        removed_child.parent = parent_orig
        node_orig = Node(removed_child.type, [removed_child], lineno=lineno)
        assert str(node) == str(node_orig), print_node(node)
        return

    code = "f(a, b, c, d, e, f)"
    tree = compile(code, "", "exec", _ast.PyCF_ONLY_AST)

# Generated at 2022-06-11 19:59:44.258878
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.grammar import grammar
    # Test leaf pattern
    pat = LeafPattern(grammar.token2symbol["LPAR"], "(")
    assert list(pat.generate_matches([grammar.symbol2token[")"]])) == []
    assert list(pat.generate_matches([grammar.symbol2token["LPAR"]])) == [(1, {})]
    # Test node pattern
    pat = NodePattern(grammar.symbol2number["test"], content={}, name="x")
    assert list(pat.generate_matches([grammar.symbol2token["LPAR"]])) == []

# Generated at 2022-06-11 20:00:32.299824
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node, NodeType
    new_node = Node()
    abc = Leaf()
    def1 = Leaf("def1")
    def2 = Leaf("def2")
    def3 = Leaf("def3")
    def4 = Leaf("def4")
    n = Node("Newnode", [abc, def1, def2, def3, def4], prefix="    ")

# Generated at 2022-06-11 20:00:37.044611
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Test that a use of 'optimize' does not produce a pattern that
    # matches a node with a different type.

    class MyPattern(BasePattern):
        type = 42
        def optimize(self):
            return MyPattern(self.type + 1)

    class MyNode(Leaf):
        type = 42

    n = MyNode(42, "a")
    assert MyPattern()._submatch(n) is False

# Generated at 2022-06-11 20:00:46.892784
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import driver

    gr = driver.load_grammar("Python", "3.0")
    p = NodePattern(gr.syms.funcdef)
    node = gr.parse("def f(): pass")[0]
    match = p.match_seq(node.pre_order())
    assert match == 1, match
    assert p.name is None, p.name
    assert p.content is None, p.content
    assert p.type == gr.syms.funcdef, p.type

    p = NodePattern(gr.syms.funcdef, "f")
    match = p.match_seq(node.pre_order())
    assert match == 1, match
    assert p.name is None, p.name
    assert p.content == "f", p.content

# Generated at 2022-06-11 20:00:51.017716
# Unit test for function generate_matches
def test_generate_matches():
    p = NodePattern(type=1)
    nodes = [NL(1, 1), NL(1, 2)]
    expected = [((1, {}), (2, {}))]
    got = tuple(generate_matches([p], nodes))
    assert expected == got

    p = NodePattern(type=1)
    nodes = [NL(1, 1), NL(2, 2)]
    expected = []
    got = tuple(generate_matches([p], nodes))
    assert expected == got

    p1 = NodePattern(type=1)
    p2 = NodePattern(type=1)
    nodes = [NL(1, 1), NL(1, 2), NL(1, 3)]
    expected = [((2, {}), (3, {}))]

# Generated at 2022-06-11 20:00:57.350162
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    a = Leaf(1, "1")
    b = Leaf(2, "2")
    c = Node(3, [a, b])
    d = Leaf(4, "4")
    e = Node(5, [c, d])
    assert list(e.post_order()) == [a, b, c, d, e]
test_Leaf_post_order()


# Generated at 2022-06-11 20:01:05.187044
# Unit test for method replace of class Base
def test_Base_replace():
    # Construct the nodes under test
    node1 = Node(1, [Leaf(1, "hi")])
    node2 = Node(1, [Leaf(1, "hi")])
    expected_children = [node2]

    # Basic structure
    assert node1.children == [Leaf(1, "hi")]
    node1.replace(node2)

    # Check that the node was replaced
    assert node1.parent is None
    assert node1.children == []
    assert node2.parent.children == expected_children



# Generated at 2022-06-11 20:01:17.252246
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pygram import python_symbols as syms

    tt = Token
    nd = Node
    a = tt(token.NAME, "a")
    b = tt(token.NAME, "b")
    c = tt(token.NAME, "c")
    d = tt(token.NAME, "d")
    e = tt(token.NAME, "e")
    f = tt(token.NAME, "f")
    g = tt(token.NAME, "g")
    h = tt(token.NAME, "h")
    i = tt(token.NAME, "i")
    j = tt(token.NAME, "j")
    k = tt(token.NAME, "k")
    l = tt(token.NAME, "l")
    m = t

# Generated at 2022-06-11 20:01:21.617692
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import NAME, NEWLINE

    t = Leaf(NAME, "a", "b", prefix="c")
    t.clone() == Leaf(NAME, "a", "b", prefix="c")



# Generated at 2022-06-11 20:01:32.599826
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(111) == 111

# for tokenize
ENDMARKER: int = 0
INDENT: int = 1
DEDENT: int = 2
NEWLINE: int = 3
NAME: int = 4
NUMBER: int = 5
STRING: int = 6
NEWLINE_DECORATOR: int = 7
COMMENT: int = 8
ERRORTOKEN: int = 9
NL: int = 10
ENCODING: int = 11

# Pickle fixers, from lib2to3

# Generated at 2022-06-11 20:01:39.316629
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    n = Node(0, [Leaf(0, 'a'), Node(1, [Leaf(0, 'b'), Leaf(0, 'c')]), Leaf(0, 'd')])
    result = [n, n.children[0], n.children[1], n.children[1].children[0],
            n.children[1].children[1], n.children[2]]
    assert list(n.pre_order()) == result


# Generated at 2022-06-11 20:02:05.477878
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import token

    p = LeafPattern(token.NAME)
    assert [(i, r) for i, r in p.generate_matches([Leaf(1, "a"), Leaf(1, "b")])] == [
        (1, {})
    ]

# Generated at 2022-06-11 20:02:13.930189
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf

    class MyNode(Node):
        def _eq(self, other):
            return (type(self), tuple(self.children)) == (
                type(other), tuple(other.children))

        def clone(self):
            return MyNode([ch.clone() for ch in self.children])

    node = Node(type=1, children=[Leaf(1, "foo"), Leaf(1, "bar")])
    MyNode([Leaf(1, "foo"), Leaf(1, "bar")]).replace(
        [Leaf(1, "hack"), Leaf(1, "zap")])
    MyNode([Leaf(1, "foo"), Leaf(1, "bar")]).replace(
        Leaf(1, "hack"))

# Generated at 2022-06-11 20:02:25.873676
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Node
    from .pgen2 import token
    tree = Node(1, [Leaf(token.NAME, "name", (1, 1)),
                     Node(2, [Leaf(token.NAME, "foo", (1, 1)),
                              Leaf(token.NAME, "bar", (1, 1))])])
    foo = tree.children[1].children[0]
    foo.replace(Leaf(token.NAME, "FOO", (1, 1)))
    assert tree == Node(1, [Leaf(token.NAME, "name", (1, 1)),
                            Node(2, [Leaf(token.NAME, "FOO", (1, 1)),
                                     Leaf(token.NAME, "bar", (1, 1))])])



# Generated at 2022-06-11 20:02:33.775459
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    """Test method pre_order of class Base"""
    import lib2to3.pgen2.parse

    grammar = lib2to3.pgen2.parse.parse_grammar("""
    a = b? c
    b = !anything
    c = epsilon
    """)
    tree = grammar.parsed_tree()
    assert list(tree.pre_order()) == [tree, tree.children[0], tree.children[1]]



# Generated at 2022-06-11 20:02:43.113616
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import inspect
    import pprint
    import sys
    import types

    from .pgen2.driver import Driver
    from .pytree import Leaf as L, Node as N
    from .pgen2 import token, grammar

    # Don't test this method on BasePattern
    assert test_BasePattern_match.__module__ == "__main__", test_BasePattern_match.__module__
    if test_BasePattern_match.__module__ == "__main__":
        for m in (BasePattern,):
            for name, obj in inspect.getmembers(m):
                if name.startswith("test_") and isinstance(obj, types.FunctionType):
                    print(name, end=" ... ")
                    print(obj(m))
                    print()
    def test(self):
        test_driver = Driver()

# Generated at 2022-06-11 20:02:53.971685
# Unit test for method leaves of class Base
def test_Base_leaves():
    from lib2to3.pgen2.grammar import Grammar
    from lib2to3.pgen2 import token

    # Example input file
    in_filename = "data/python2.7"
    grammar = Grammar()
    # Put the tokens in to the grammar
    grammar.add_token(token.NAME, "NAME")
    grammar.add_token(token.NUMBER, "NUMBER")
    grammar.add_token(token.OP, "PLUS")
    # Add productions to the grammar
    grammar.add_production("expr", ["expr", "PLUS", "expr"], None)
    grammar.add_production("expr", ["expr", "PLUS", "expr"], None)
    grammar.add_production("expr", ["expr", "PLUS", "expr"], None)

# Generated at 2022-06-11 20:03:06.133700
# Unit test for method replace of class Base
def test_Base_replace():
    n1 = Node(syms.dictorsetmaker, [Leaf(token.STRING, "'something'", (1, 0)),
                                    Node(syms.comp_for, [Leaf(token.NAME,
                                                              "i", (1, 0))]),
                                    Leaf(token.STRING, "'something'", (1, 0))])
    n2 = Node(syms.dictorsetmaker, [Leaf(token.STRING, "'something'", (1, 0)),
                                    Leaf(token.STRING, "'something'", (1, 0))])
    n1.replace(n2)
    
    value = isinstance(n2, list)
    assert value, "replace() method returned unexpected value %s" % repr(value)


# Generated at 2022-06-11 20:03:09.439421
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(18)
    repr(node) == "Node(18, [])"
    node._parent = Node(17)
    node.append('text')
    repr(node) == "Node(18, ['text'])"

# Generated at 2022-06-11 20:03:20.877974
# Unit test for method replace of class Base

# Generated at 2022-06-11 20:03:32.791938
# Unit test for method leaves of class Base
def test_Base_leaves():

    from .pytree import Node, Leaf
    from .fixed_point import fixed_point

    def make_tree(node):
        if isinstance(node, tuple):
            node = Node(node[0], list(map(make_tree, node[1:])))
        return node

    tree = make_tree((1, (1, (1,)), (2, (2,)), (3, (3,))))
    assert list(tree.leaves()) == [
        Leaf(1, '1'),
        Leaf(1, '1'),
        Leaf(2, '2'),
        Leaf(3, '3'),
    ]
    # Ensure that the leaves stay the same after we make changes to the tree
    tree.children[0] = Leaf(3, '3')

# Generated at 2022-06-11 20:03:41.091397
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    global s, p

# Generated at 2022-06-11 20:03:42.026166
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    assert Base().get_lineno() is None



# Generated at 2022-06-11 20:03:44.283119
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    n = Node(0, [])
    assert list(n.pre_order()) == [n]



# Generated at 2022-06-11 20:03:54.543788
# Unit test for method replace of class Base
def test_Base_replace():
    import lib2to3.fixer_util
    import lib2to3.fixer_util as fixer_util
    context = None
    grammar = Grammar("", "", fixer_util.grammar_encoding)
    parent = Node("parent", [], context, parent=None)
    node = Leaf("child1", [], context, parent=parent)
    node2 = Leaf("child2", [], context, parent=parent)
    parent.children.extend([node, node2])
    node.parent = parent
    node.children = []
    node.was_changed = False
    node.was_checked = False
    node2.parent = parent
    node2.children = []
    node2.was_changed = False
    node2.was_checked = False
    parent.was_changed = False
    parent

# Generated at 2022-06-11 20:04:05.893811
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pygram import python_symbols

    from . import pytree

    from .patcomp import compile_pattern as comp

    def test(src: Text, expected: List[Any]) -> None:
        t = pytree.Node(type=python_symbols.file_input, children=[pytree.Leaf(1, src)],)
        assert [ch.prefix for ch in t.pre_order()] == expected
        assert len(list(t.pre_order())) == len(expected)
        print(t)

    test("", [])
    t = pytree.Node(type=python_symbols.file_input, children=[],)
    assert len(list(t.pre_order())) == 0
    test("i = 0", ["", "i = 0"])

# Generated at 2022-06-11 20:04:08.638581
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    import pytree_ng as pyt  # type: ignore

    print(pyt.from_str("a = 5"))



# Generated at 2022-06-11 20:04:18.261069
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    g = Grammar()
    g.parse(r"""
    a: 'a'
    b: 'b'
    c: 'c'
    """)

    n = Node(1, [Leaf(1, 1, "a", "a"),
                 Node(2, [Leaf(3, 1, "b", "b")]),
                 Node(4, [Leaf(5, 1, "c", "c")])])
    assert n.children[0] == Leaf(1, 1, "a", "a")
    assert n.children[1] == Node(2, [Leaf(3, 1, "b", "b")])
    assert n.children[2] == Node(4, [Leaf(5, 1, "c", "c")])

    assert n.get_lineno() == 1

# Generated at 2022-06-11 20:04:22.852477
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    assert eval(repr(Node(256, []))) == Node(256, [])
    assert eval(repr(Node(257, [Leaf(1, 'a')]))) == Node(257, [Leaf(1, 'a')])


# Generated at 2022-06-11 20:04:25.133438
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    #    assert False, "Unit tests not yet implemented!"
    return None



# Generated at 2022-06-11 20:04:32.350362
# Unit test for method depth of class Base
def test_Base_depth():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            p = Leaf(1, 'prefix')
            c = Node(2, [p])
            p.parent = c
            t = Node(2, [c])
            c.parent = t
            self.assertEqual(p.depth(), 2)
            self.assertEqual(c.depth(), 1)
            self.assertEqual(t.depth(), 0)

test_Base_depth()



# Generated at 2022-06-11 20:04:58.503171
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Test that __eq__ propagates to children
    class A(Base):
        def __init__(self, children=()):
            self.children = children

        def clone(self):
            return A([x.clone() for x in self.children])

        def __repr__(self):
            return "<A %r>" % self.children

        def _eq(self, other):
            return (list(self.children) == list(other.children))

    a = A([A([A()]), A([A(), A()])])
    b = A([A(), A([A(), A()])])
    assert a != b
    c = A([A([A()]), A([A(), A()])])
    assert a == c



# Generated at 2022-06-11 20:05:01.712732
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    g = Grammar()
    g.add_nonterminal("a", ["b", "c"])
    g.add_nonterminal("a", ["b"])
    g.add_nonterminal("b", ["c"])
    g.add_nonterminal("b", ["d"])
    g.add_terminal("c", "c")
    g.add_terminal("d", "d")
    g.build_lritems()
    for x in g.nonterminals["a"].pre_order() :
        print(x)



# Generated at 2022-06-11 20:05:03.505537
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(0, "a")
    assert list(l.post_order()) == [l]



# Generated at 2022-06-11 20:05:15.505317
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    assert list(NegatedPattern().generate_matches([])) == [(0, {})]
    assert list(NegatedPattern().generate_matches([(0, None)])), (
        list(NegatedPattern().generate_matches([(0, None)]))
    )
    assert (
        not list(NegatedPattern().generate_matches([(0, None), (0, None)]))
    ), (
        not list(NegatedPattern().generate_matches([(0, None), (0, None)]))
    )

# Generated at 2022-06-11 20:05:21.893059
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():

    # Test case for method optimize of class BasePattern
    class SubPattern(BasePattern):

        # Tests for method optimize of class BasePattern
        def match(self, node, results=None):
            return False
    assert SubPattern(1).optimize() is not SubPattern(1)



# Generated at 2022-06-11 20:05:28.773349
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name
    p = LeafPattern(1, "a")
    assert repr(p) == "LeafPattern(%s, %r)" % (tok_name[p.type], p.content)
    p = NodePattern(2, ["a", "b"])
    assert repr(p) == "NodePattern(%s, %r)" % (type_repr(p.type), p.content)



# Generated at 2022-06-11 20:05:29.987163
# Unit test for method clone of class Base
def test_Base_clone():

    # A trivial class that derives from Base
    # a = Base()
    pass  # no default implementation



# Generated at 2022-06-11 20:05:34.358910
# Unit test for method clone of class Base
def test_Base_clone():
    import copy
    node = Node(type=0, children=[Leaf(1, "one"), Leaf(2, "two")])
    node2 = node.clone()
    assert not (node2 is node)
    assert node == node2
    assert copy.copy(node) == node
    assert copy.deepcopy(node) == node



# Generated at 2022-06-11 20:05:41.615972
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """Demo of pre_order method."""
    l1 = Leaf(1, "foo")
    l2 = Leaf(2, "bar")
    l3 = Leaf(3, "baz")
    n1 = Node(syms.trailer, [l1, l2])
    n2 = Node(syms.expr_stmt, [n1, l3])
    result = list(n2.pre_order())
    expected = [n2, n1, l1, l2, l3]
    assert result == expected, result



# Generated at 2022-06-11 20:05:54.238188
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node, Leaf, PythonLeaf, Internal

    n = Node(Internal, "")
    assert n.depth() == 0
    l = Leaf(PythonLeaf, "", [], [])
    assert l.depth() == 0
    n2 = Node(Internal, "")
    n.append_child(n2)
    assert n2.depth() == 1
    n3 = Node(Internal, "")
    n2.append_child(n3)
    assert n3.depth() == 2

    # Test that the suffix method works
    n = Node(Internal, "")
    n.append_child(Leaf(PythonLeaf, "foo", [], [], prefix=" "))
    n.append_child(Leaf(PythonLeaf, "bar", [], [], prefix="="))

# Generated at 2022-06-11 20:06:16.986823
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Node, Leaf
    from .pygram import python_grammar
    from .pgen2 import driver

    pgen = driver.Driver(python_grammar, convert=python_grammar.number2symbol)
    tree = pgen.parse_string("x = 'abc'\n")
    assert isinstance(tree, Node)
    x_node = tree.children[0].children[0]
    assert x_node.type == python_grammar.syms.expr_stmt
    x_leaf = x_node.children[0]
    assert isinstance(x_leaf, Leaf) and x_leaf.type == python_grammar.tokens.NAME
    assert x_leaf.get_suffix() == " = 'abc'\n"
test_Base_get_suffix()



# Generated at 2022-06-11 20:06:21.753215
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(57) == 57
    import blib2to3.pgen2.grammar
    assert type_repr(blib2to3.pgen2.grammar.python_symbols.NAME) == "NAME"


_type_attrs: Dict[int, List[Text]] = {}



# Generated at 2022-06-11 20:06:33.980360
# Unit test for method remove of class Base
def test_Base_remove():
    import random

    class Node(Base):
        def __init__(self, parent, children=None):
            self.parent = parent
            self.children = children or []
            for child in self.children:
                child.parent = self

                def _eq(self, other):
                    return self.children == other.children

                def clone(self):
                    return Node(self.parent, map(lambda n: n.clone(), self.children))

                def post_order(self):
                    for n in self.children:
                        for x in n.post_order():
                            yield x
                    yield self

                def pre_order(self):
                    yield self
                    for n in self.children:
                        for x in n.pre_order():
                            yield x
