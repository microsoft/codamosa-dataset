

# Generated at 2022-06-11 19:58:56.046626
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert repr(NodePattern(1)) == "NodePattern(1)"
    assert repr(NodePattern(1, "foo")) == "NodePattern(1, 'foo')"
    assert repr(NodePattern(1, "foo", "bar")) == "NodePattern(1, 'foo', 'bar')"
    assert repr(LeafPattern(1)) == "LeafPattern(1)"
    assert repr(LeafPattern(1, "foo")) == "LeafPattern(1, 'foo')"
    assert repr(LeafPattern(1, "foo", "bar")) == "LeafPattern(1, 'foo', 'bar')"
    assert repr(WildcardPattern()) == "WildcardPattern()"

# Generated at 2022-06-11 19:59:06.674096
# Unit test for function generate_matches
def test_generate_matches():
    def t(patterns, nodes, expected):
        actual = list(generate_matches(patterns, nodes))
        assert actual == expected, (actual, expected)
    p = WildcardPattern
    alt = NodePattern
    name = NodePattern
    a = NodePattern(name="a")
    b = NodePattern(name="b")
    c = NodePattern(name="c")
    d = NodePattern(name="d")
    e = NodePattern(name="e")
    f = NodePattern(name="f")
    g = NodePattern(name="g")
    h = NodePattern(name="h")
    m = NodePattern(name="m")
    m.match = lambda _, __: False
    t([], [], [(0, {})])
    t([a], [], [])

# Generated at 2022-06-11 19:59:12.940028
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node
    parent = Node(python_symbols.tokens)
    child1 = Node(python_symbols.argument)
    child2 = Node(python_symbols.argument)
    parent.children = [child1, child2]
    child1.parent = parent
    child2.parent = parent
    assert child1.depth() == 1
    assert child2.depth() == 1



# Generated at 2022-06-11 19:59:14.871709
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    assert type_repr(python_symbols.LPAR) == "('(')"



# Generated at 2022-06-11 19:59:26.211047
# Unit test for method replace of class Base
def test_Base_replace():
    grammar = Grammar(
        r"""
    a : b c d | i
    d : e f
    b : h
    f : g
    x : y z
    """
    )
    tree = grammar.parse("hi")
    i = tree.children[0]
    assert i.next_sibling.prefix == " "
    assert i.next_sibling is tree.children[1]
    tree.children[1].replace(["j", " "])
    assert i.next_sibling.prefix == "j"
    tree.children[1] = "k"
    assert i.next_sibling.prefix == "k"

    # Ensure that we aren't creating aliases within the tree.
    i2 = tree.children[0]
    assert i is not i2
    assert i.prefix == i2.prefix

# Generated at 2022-06-11 19:59:32.271605
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.tokenize import tokenize

    from .pgen2 import token

    from . import parso

    source = 'def f(): pass\n'
    parser_version = parso.parse(source, version='3.7')
    defs = list(parser_version.iter_funcdefs())
    assert len(defs) == 1

    # The number of defs should be 1
    defs_leaf_tokens = 0
    for leaf in defs[0].post_order():
        assert isinstance(leaf, Leaf)
        if leaf.type == token.NAME and leaf.value == 'def':
            defs_leaf_tokens += 1
    assert defs_leaf_tokens == 1
test_Leaf_post_order()

# Generated at 2022-06-11 19:59:33.132420
# Unit test for method post_order of class Node
def test_Node_post_order():
    Node.post_order


# Generated at 2022-06-11 19:59:36.159718
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    node = Leaf(255, 'a')
    post_order = [x for x in node.post_order()]
    assert post_order == [node]


# Generated at 2022-06-11 19:59:39.925880
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.test) == "test"
    assert type_repr(python_symbols.or_test) == "or_test"
    assert type_repr(HUGE + 1) == HUGE + 1


# [Pydev] Addition to parse tree
# [Pydev] NOTE: the object must have a __dict__ or the token_index won't be set

# Generated at 2022-06-11 19:59:47.334597
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols

    assert type_repr(python_symbols.power) == "power"
    assert type_repr(999999) == 999999

# --- for use with node.prefix
type_ignore = "ignore"  # token not parsed by the grammar: comment, etc.
type_whitespace = "whitespace"  # token needs to be preserved in output
type_empty = "empty"  # empty leaves of lists
type_error = "error"  # parser is confused!
type_unknown = "unknown"  # unknown (incomplete) parse state


# Generated at 2022-06-11 20:01:15.360783
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    _str = StringIO("""\
1
a = 1
""")
    grammar = Grammar()
    with grammar.lock:
        grammar.read_grammar("grammar")
        grammar.read_grammar("2to3_grammar")
        grammar.mk_pgen("2to3_grammar")
    stmts = grammar.parse_file("test_Base_get_suffix", _str)
    a = stmts.children[0].children[1]
    assert a.children[0].get_suffix() == " ="
    assert Base(0, "", ((0,0),) ).get_suffix() == ""


# Generated at 2022-06-11 20:01:24.975369
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token
    from copy import copy
    from collections import defaultdict
    import sys
    class _BaseTest(object):
        def __init__(self):
            self.type = token.NUMBER
            self.value = '1'
            self.parent = None
            self.context = None
            assert self.type == token.NUMBER
    def _BaseTest___eq__(self, other):
        # Test the method __eq__ of the class Base
        assert other.__class__ == _BaseTest
        assert self.type == token.NUMBER
        assert other.type == token.NUMBER
        return self.value == other.value

# Generated at 2022-06-11 20:01:34.329665
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import unittest
    from .pgen2.token import Token

    class TestPattern(unittest.TestCase):

        def test_match(self):
            from .pgen2.grammar import Number

            class MyPattern(BasePattern):

                def __init__(self, type, content=None, name=None, **kwds):
                    super().__init__(type, content, name, **kwds)
                    self.type = type

                def _submatch(self, node, results=None):
                    if len(node.children) == 2 and node.children[0].type == Number:
                        if results is not None:
                            results[self.name] = node.children[0]
                        return True
                    else:
                        return False

            p = MyPattern(Number, "42", name="answer")
            n

# Generated at 2022-06-11 20:01:43.338550
# Unit test for constructor of class NodePattern
def test_NodePattern():
    def test(p, t, c, n):
        """Compare pattern p with expected type, content and name."""
        assert p.type == t, "type mismatch: " + repr(p)
        if c is None:
            assert p.content is None, "content mismatch: " + repr(p)
        else:
            assert isinstance(p.content, list), "wrong content type: " + repr(p)
            for i in range(len(c)):
                assert isinstance(p.content[i], type(c[i])), (
                    "content item mismatch: " + repr(p)
                )
        assert p.name == n, "name mismatch: " + repr(p)

    test(NodePattern(), None, None, None)
    test(NodePattern(name="a"), None, None, "a")
   

# Generated at 2022-06-11 20:01:52.563893
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern
    for t, c, r in [
        (1, ("a",), None),
        (None, ("a",), None),
        (1, None, None),
        (None, None, None),
        (None, ("a", "b"), None),
    ]:
        try:
            p(t, c)
        except AssertionError:
            assert r == "assert", ((t, c), r)

# Generated at 2022-06-11 20:02:03.751937
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    """Method match of class BasePattern."""
    import pprint
    from .pgen2 import parse

    def test(s: Text, expected: bool) -> None:
        result = BasePattern().match(parse(s), {})
        assert result is expected, (s, result)

    test("1", True)
    test("'foo'", True)
    test("()", True)

    def test_content(s: Text, expected: bool) -> None:
        result = BasePattern(content="1").match(parse(s), {})
        assert result is expected, (s, result)

    test_content("1", True)
    test_content("'foo'", False)
    test_content("()", False)


# Generated at 2022-06-11 20:02:13.845839
# Unit test for method leaves of class Base
def test_Base_leaves():
    # Create a test string
    test_str = "  \n"
    # Use the function blib2to3.pgen2.tokenize.detect_encoding to determine the
    # encoding of the file. Since detect_encoding is for internal use only, it
    # is imported locally instead of at the module level.
    from blib2to3.pgen2.tokenize import detect_encoding, tokenize

    encoding = detect_encoding(StringIO(test_str).readline)
    # Create a generator for the tokens in the string.
    gen = tokenize(StringIO(test_str).readline)
    # Get the first token, which is a NAME in this case.
    type_, value, start, end, line = next(gen)
    # Create a leaf as the root node.

# Generated at 2022-06-11 20:02:26.181194
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    Leaf = Leaf

    leaves = [
        Leaf(token.NAME, "Y"),
        Leaf(token.EQUAL, "="),
        Leaf(token.NAME, "X"),
        Leaf(token.PLUS, "+"),
        Leaf(token.NAME, "X"),
        Leaf(token.PLUS, "+"),
        Leaf(token.NUMBER, "1"),
    ]

    # This should match; it's equivalent to:
    #     (Y EQUAL (X PLUS X) PLUS NUMBER)

# Generated at 2022-06-11 20:02:30.388842
# Unit test for method depth of class Base
def test_Base_depth():
    """Unit tests for Base.depth"""
    tree = TreeBuilder().build(src)
    for leaf in tree.leaves():
        assert leaf.depth() == leaf.count_newlines()



# Generated at 2022-06-11 20:02:40.869419
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pygram import python_symbols

    nodelist = [
        Leaf(1, "one", (1, 0)),
        Leaf(1, "two", (2, 0)),
        Node(symbol_name="nodething", children=[
            Leaf(1, "three", (3, 0)),
            Leaf(1, "four", (4, 0)),
        ]),
        Leaf(1, "five", (5, 0)),
    ]
    tree = Node(symbol_name="treering", children=nodelist)

    assert tree.get_lineno() == 1
    assert nodelist[0].get_lineno() == 1
    assert nodelist[1].get_lineno() == 2
    assert nodelist[2].get_lineno() == 3

# Generated at 2022-06-11 20:02:55.754121
# Unit test for method clone of class Leaf

# Generated at 2022-06-11 20:03:08.098152
# Unit test for function generate_matches
def test_generate_matches():
    p = NodePattern(T.Name)
    c1 = NodePattern(T.Comment)
    c2 = NodePattern(T.Comment)
    rest = NodePattern(T.Expr, name="expr")
    wc = WildcardPattern(name="wild")
    patterns = [p, c1, rest, c2, wc]
    nodes = [
        AST("Name", "foo"),
        AST("Comment", "bar"),
        AST("Expr", "baz"),
        AST("Comment", "qux"),
        AST("Expr", "grault"),
    ]
    result = {
        "expr": AST("Expr", "baz"),
        "wild": [AST("Comment", "qux"), AST("Expr", "grault")],
    }

# Generated at 2022-06-11 20:03:18.182981
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Test that __eq__ and _eq are called and return the right value
    class MockNode(Base):
        def __init__(self, val):
            Base.__init__(self)
            self.val = val

        def _eq(self, other):
            return self.val == other.val

    obj_1, obj_2 = MockNode(1), MockNode(1)
    assert obj_1 == obj_2
    obj_2.val = 2
    assert obj_1 != obj_2
    obj_3, obj_4 = MockNode(1), object()
    assert obj_3 != obj_4



# Generated at 2022-06-11 20:03:25.678964
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Only run tests if we have the unittest module
    if sys.version_info[:2] >= (2, 1):
        from .test.test_treetools import BaseTestCase
        from .pytree import Leaf, Node, type_repr

        class TestBase(BaseTestCase):

            def test_Base___eq__(self):
                token = Leaf(1, "lhs")
                copy = token.clone()
                backup = token.clone()
                self.assertTrue(token == copy)
                self.assertFalse(token != copy)
                token.type = 2
                self.assertFalse(token == copy)
                self.assertTrue(token != copy)
                token = backup
                self.assertTrue(token == copy)
                self.assertFalse(token != copy)

# Generated at 2022-06-11 20:03:36.566079
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    n = Node(sym.decorator, [])
    assert repr(n) == "Node(decorator, [])"
    n = Node(sym.decorator, [Leaf(token.NAME, "mydeco")])
    assert repr(n) == "Node(decorator, [Leaf(NAME, 'mydeco')])"
    n = Node(sym.decorator, [Leaf(token.NAME, "mydeco", prefix="\n")])
    assert repr(n) == "Node(decorator, [Leaf(NAME, 'mydeco', prefix='\\n')])"
    n = Node(sym.decorator, [Leaf(token.NAME, "mydeco")], prefix="@")

# Generated at 2022-06-11 20:03:42.308806
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Node, Leaf
    from .python_tree import as_string
    a = Leaf(1, "prefix_a")
    a.parent = Node(2, [a])
    b = Leaf(1, "prefix_b")
    b.parent = a.parent
    a.parent.children.append(b)
    assert a.get_suffix() == "prefix_b"
    a.replace(None)
    assert as_string(b.parent) == "prefix_b"
    assert b.get_suffix() == ""



# Generated at 2022-06-11 20:03:45.301371
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    le = Leaf(17, "123")
    assert list(le.pre_order()) == [le]
    assert list(le.post_order()) == [le]


# Generated at 2022-06-11 20:03:47.684418
# Unit test for method leaves of class Base
def test_Base_leaves():
    # TODO: use Hypothesis and implement a strategy for generating Trees
    pass



# Generated at 2022-06-11 20:03:56.171911
# Unit test for method post_order of class Base
def test_Base_post_order():
  import _ast as ast
  import asttokens
  import json
  import sys
  import os

  class ASTTransformer(ast.NodeTransformer):
      def __init__(self, atok):
          self.atok = atok
          self.tree = None
          self.in_number = False
          self.literal_value = None

      def visit_Literal(self, node):
          self.in_number = True
          node = super(ASTTransformer, self).visit_Literal(node)
          self.in_number = False
          return node

      def generic_visit(self, node):
          for name, field in ast.iter_fields(node):
              old_value = getattr(node, name)

# Generated at 2022-06-11 20:04:06.590237
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from optparse import Values
    from test import test_grammar
    from typing import List, Tuple

    def make_test_case(case: Tuple[List, List]) -> Tuple[List, List, List]:
        pattern = WildcardPattern(case[0], 0, 1).optimize()
        return case[0], case[1], pattern.generate_matches(case[1])

    values = Values()
    values.__dict__.update(
        test_grammar.__dict__
    )  # type: ignore # It's OK to ignore this here.
    cases = test_grammar.find_tests(
        optimizer_test_pattern,
        values,
        "find_tests",
    )  # type: List[List]
    # pprint(cases)
    for case in cases:
        case

# Generated at 2022-06-11 20:04:27.672359
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    node = Base()
    node.lineno = 2
    assert node.get_lineno() == 2
    node1 = Base()
    node2 = Base()
    node2.lineno = 3
    node1.children = [node, node2]
    node.parent = node1
    assert node.get_lineno() == 2
    assert node1.get_lineno() == 3
    node3 = Base()
    node1.children = [node3]
    node3.parent = node1
    assert node1.get_lineno() is None



# Generated at 2022-06-11 20:04:36.231040
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import unittest

    class MatchSeqTest(unittest.TestCase):
        def test_BasePattern_match_seq(self):
            class TestBP(BasePattern):
                def __init__(self, *args):
                    self.args = args

                def match_seq(self, ast_list, results):
                    if ast_list == self.args:
                        return True
                    else:
                        return super().match_seq(ast_list, results)

            class TestNode(Node):
                type = 1

                def __init__(self, value):
                    super().__init__(1, value)

            class TestLeaf(Leaf):
                type = 2

                def __init__(self, value):
                    super().__init__(2, value)

            a = TestNode(1)
            b = Test

# Generated at 2022-06-11 20:04:37.589666
# Unit test for method replace of class Base
def test_Base_replace():
    _test_Base_replace()



# Generated at 2022-06-11 20:04:45.111227
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import unittest
    import sys
    klass = Leaf
    class Dummy:
        def __init__(self, value):
            self.value = value

    class DummyTest(unittest.TestCase):
        def test_Leaf_post_order(self):
            self.assertEqual(klass(Dummy("a")).post_order().__next__().value, "a")

    unittest.main(argv=[sys.argv[0]])

# Generated at 2022-06-11 20:04:50.738404
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """Unit test for method generate_matches of class NegatedPattern."""
    nodes = [1, 2, 3]
    p = NegatedPattern(NodePattern(None))
    assert list(p.generate_matches(nodes)) == []
    q = NegatedPattern(NodePattern(1))
    assert list(q.generate_matches(nodes)) == [(0, {})]



# Generated at 2022-06-11 20:05:01.386670
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # Base node (without lineno)
    base = Base()
    assert base.get_lineno() is None, base.get_lineno()

    # Node with a line number
    class TestNode(Node):
        def __init__(self, type, children, lineno):
            super().__init__(type, children)
            self.lineno = lineno
    node = TestNode(0, [], 1)
    assert node.get_lineno() == 1, node.get_lineno()

    # Node without a line number
    class TestNode(Node):
        def __init__(self, type, children):
            super().__init__(type, children)
    node = TestNode(0, [])
    assert node.get_lineno() is None, node.get_lineno()

    # Node with a

# Generated at 2022-06-11 20:05:07.538305
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():

    from lib2to3.pgen2 import parse, token  # type: ignore
    rv = parse("# comment\n3\r\n")
    assert isinstance(rv, Node)
    nc = rv.children[1]
    assert isinstance(nc, Leaf)
    assert token.ENDMARKER == nc.type
    assert nc.get_suffix() == "\r\n"



# Generated at 2022-06-11 20:05:17.661538
# Unit test for method set_child of class Node
def test_Node_set_child():
    lines = [
        "def foo():",
        "    pass",
    ]
    tree = pytree.parse(lines)
    expected = "def foo(): pass"
    actual = str(tree[0])
    assert expected == actual
    new_node = pytree.Leaf(token.NEWLINE, '\n')
    actual = str(new_node)
    expected = '\n'
    assert expected == actual
    new_node.parent = tree[0]
    actual = str(tree[0])
    expected = 'def foo():'
    assert expected == actual
    new_node.parent = None
    actual = str(tree[0])
    expected = 'def foo():'
    assert expected == actual


# Generated at 2022-06-11 20:05:21.892186
# Unit test for function type_repr
def test_type_repr():
    type_repr(python_symbols.int) == "int"
    type_repr(python_symbols.int + 1) == python_symbols.int + 1


# The base AST type

# Generated at 2022-06-11 20:05:32.749754
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Node, Leaf
    parent = Node(1, [Leaf(1, '1'), Leaf(1, '2'), Leaf(1, '3')])
    assert parent.children == [Leaf(1, '1'), Leaf(1, '2'), Leaf(1, '3')]
    child = parent.children[1]
    child.replace(Leaf(1, '4'))
    assert parent.children == [Leaf(1, '1'), Leaf(1, '4'), Leaf(1, '3')]
    child = parent.children[0]
    child.replace([Leaf(1, '5'), Leaf(1, '6')])
    assert parent.children == [Leaf(1, '5'), Leaf(1, '6'), Leaf(1, '4'), Leaf(1, '3')]


# Generated at 2022-06-11 20:06:03.778092
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Make sure repr() output is valid Python input
    exec(repr(LeafPattern(token.NUMBER)))
    exec(repr(NodePattern(symbol.power, (token.NAME, "*"))))
    exec(repr(WildcardPattern()))
    exec(repr(WildcardPattern(token.NUMBER)))
    exec(repr(WildcardPattern(token.NUMBER, '*')))
    exec(repr(WildcardPattern(None, '*')))
    exec(repr(WildcardPattern(None, '+')))
    exec(repr(WildcardPattern(token.COMMENT, '+')))
    exec(repr(WildcardPattern(token.COMMENT, '*')))
    exec(repr(WildcardPattern(token.COMMENT, '?')))

# Generated at 2022-06-11 20:06:15.357523
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import NotAny
    from .pgen2.parse import Literal
    from .pgen2.parse import ParseError

    bp = NotAny(Literal("abc")), Literal("def")
    inp = "def"
    expect = [([], {})]
    assert bp.optimize().generate_matches(inp) == expect

    bp = NotAny(Literal("abc")), Literal("abc")
    inp = "abc"
    expect = []
    assert bp.optimize().generate_matches(inp) == expect
    assert bp.optimize().generate_matches(inp) == expect

    bp = Literal("abc")
    inp = "abc"
    expect = [(1, {})]

# Generated at 2022-06-11 20:06:20.424837
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Node
    tree = Node(0, [Node(0, [Leaf(1, "foo"), Leaf(0, "bar")]), Leaf(2, "stuff")])
    assert list(tree.leaves()) == list(tree.children[0].leaves()) + list(tree.children[1:])



# Generated at 2022-06-11 20:06:24.215935
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    a = Leaf(0, object())
    b = Leaf(1, object())
    assert list(a.post_order()) == [a]
    assert list(b.post_order()) == [b]


# Generated at 2022-06-11 20:06:35.350931
# Unit test for method leaves of class Base
def test_Base_leaves():
    import io
    import sys

    class Mock(io.StringIO):
        def __init__(self):
            io.StringIO.__init__(self)
            self.argv = ["blib2to3/pgen2/pgen/pgen_main.py"]

        def getvalue(self):
            return io.StringIO.getvalue(self).strip()

        def write(self, arg):
            pass

    sys.stdout = Mock()

    from .pytree import Leaf, Node
    from . import pygram

    def test_leaves(node):
        ret = []
        for leaf in node.leaves():
            ret.append(leaf.value)
        return ret

    pygram.initialize()