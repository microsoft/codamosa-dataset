

# Generated at 2022-06-11 19:58:57.606098
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.driver as driver

    d = driver.Driver(convert=convert, grammar=parse.PythonGrammar())
    sample = "1 + 2"
    t = d.parse_tokens(d.tokenize(sample))
    p = LeafPattern(token.PLUS)

# Generated at 2022-06-11 19:59:07.791830
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from mypy.nodes import Leaf, Node

    l01 = Leaf(0, '1')
    l23 = Leaf(0, '23')
    l45 = Leaf(0, '45')
    l67 = Leaf(0, '67')
    l89 = Leaf(0, '89')
    lEmpty = Leaf(0, '')

    # No content
    wp = WildcardPattern()
    assert wp.match_seq([l01])
    assert wp.match_seq([l23])
    assert wp.match_seq([l45])
    assert wp.match_seq([l67])
    assert wp.match_seq([l89])
    assert wp.match_seq([lEmpty])
    assert wp.match_seq([l01, l23])
    assert wp.match_seq

# Generated at 2022-06-11 19:59:18.367452
# Unit test for function generate_matches
def test_generate_matches():
    class NP(NodePattern):
        def __init__(self, type, name=None):
            super().__init__(type)
            self.name = name

    class W(WildcardPattern):
        def __init__(self, content=None, name=None):
            super().__init__(content)
            self.name = name

    class N(NegatedPattern):
        def __init__(self, content=None):
            super().__init__(content)


# Generated at 2022-06-11 19:59:21.440622
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(type=None, children=[])
    assert repr(node) == "Node(None, [])"
    assert str(node) == ""


# Generated at 2022-06-11 19:59:34.613872
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # test optimized matcher
    matcher = WildcardPattern(((LeafPattern(token.NAME, "a"),),), name="bare_name")
    assert matcher.match_seq([Leaf(token.NAME, "a")])
    assert matcher.match_seq([Leaf(token.NAME, "a"), Leaf(token.NAME, "a")])
    assert not matcher.match_seq([Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])

    # test non-optimized matcher
    matcher = WildcardPattern(name="bare_name")
    assert matcher.match_seq([Leaf(token.NAME, "a")])
    assert matcher.match_seq([Leaf(token.NAME, "a"), Leaf(token.NAME, "a")])

# Generated at 2022-06-11 19:59:38.456274
# Unit test for method post_order of class Node
def test_Node_post_order():
    n = Node(0, [])  # List of child nodes
    assert list(n.post_order()) == [n]
# Test cases for method post_order of class Node
# test_Node_post_order() #FIXME: this test case is not worth running

# Generated at 2022-06-11 19:59:48.903624
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    for cls in [LeafPattern, NodePattern]:
        pat = cls(type=1)
        assert pat.match_seq([Leaf(1, "1")])
        assert pat.match_seq([Node(2, [Leaf(1, "1")])])
        assert not pat.match_seq([Node(3, [Leaf(2, "2")])])
        assert not pat.match_seq([Node(1, [])])
        assert not pat.match_seq([])
    pat = LeafPattern(1, "1")
    assert pat.match_seq([Leaf(1, "1")])
    assert pat.match_seq([Node(2, [Leaf(1, "1")])])
    assert not pat.match_seq([Node(3, [Leaf(2, "2")])])


# Generated at 2022-06-11 19:59:53.003372
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pgen2 import token
    leaf = Leaf(token.PLUS, "+")
    leaf2 = Leaf(token.PLUS, "+")
    leaf.parent = leaf2
    assert leaf.get_suffix() == "+"
# End of unit test for method get_suffix of class Base



# Generated at 2022-06-11 19:59:56.337553
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    t = Base()
    assert t.get_suffix() == ""
    n = Node(1, [Leaf(1, "prefix"), Leaf(2, "suffix")])
    l = n.children[0]
    assert l.get_suffix() == "suffix"



# Generated at 2022-06-11 19:59:57.895386
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert list(Leaf(1, 'ciao').leaves()) == [Leaf(1, 'ciao')]


# Generated at 2022-06-11 20:01:01.937581
# Unit test for method replace of class Base
def test_Base_replace():
    class TestBase(Base):

        def _eq(self, other):
            return True

        def clone(self):
            return self

        def post_order(self):
            yield None

        def pre_order(self):
            yield None

    class TestNode(TestBase):
        def __init__(self):
            self.type = 1
            self.children = []

    class TestLeaf(TestBase):
        def __init__(self):
            self.type = 2

        @property
        def prefix(self):
            return ""

    node1 = TestNode()
    node2 = TestNode()
    leaf1 = TestLeaf()
    leaf2 = TestLeaf()

    # node1 -> node2
    node1.replace(node2)
    assert node1.parent is None
    assert node2.parent

# Generated at 2022-06-11 20:01:04.704390
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    p = NodePattern(1, "foo", "bar")
    assert repr(p) == "NodePattern(1, 'foo', 'bar')"



# Generated at 2022-06-11 20:01:13.854684
# Unit test for method post_order of class Base
def test_Base_post_order():
    class _(Base):

        def __init__(self, children):
            self.children = children

        def append_child(self, child):
            self.children.append(child)

        def _eq(self, other):
            return self.children == other.children

        def clone(self):
            return _([c.clone() for c in self.children])

        def post_order(self):
            for ch in self.children:
                yield from ch.post_order()
            yield self

        def pre_order(self):
            yield self
            for ch in self.children:
                yield from ch.pre_order()



# Generated at 2022-06-11 20:01:24.597112
# Unit test for constructor of class NodePattern
def test_NodePattern():
    try:
        NodePattern(256)
    except AssertionError:
        pass
    else:
        assert False, "NodePattern(256) should fail"
    try:
        NodePattern(256, content="")
    except AssertionError:
        pass
    else:
        assert False, "NodePattern(256, content='') should fail"
    try:
        NodePattern(256, content=())
    except AssertionError:
        pass
    else:
        assert False, "NodePattern(256, content=()) should fail"
    try:
        NodePattern(content=())
    except AssertionError:
        pass
    else:
        assert False, "NodePattern(content=()) should fail"

# Generated at 2022-06-11 20:01:26.426184
# Unit test for method remove of class Base
def test_Base_remove():
    b = Base()
    assert b.parent == None
    assert b.remove()== None


# Generated at 2022-06-11 20:01:28.746761
# Unit test for method leaves of class Base
def test_Base_leaves():
    assert Leaf(1, "a").leaves() == ["a"]



# Generated at 2022-06-11 20:01:40.187761
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    import operator
    import pickle
    from .pgen2 import token
    from .pgen2 import driver
    ru = 'a=b+1'
    g = driver.Driver().parse_string(ru, 'single_input')
    sl = g.stmt(expr_context = Load)
    assert set(map(tuple, g.pattern.match_seq(sl.children))) == {
        (token.EQUAL, token.NAME, token.PLUS, token.NUMBER),
        (token.EQUAL, token.NAME, token.PLUS, token.NAME)
    }
    g2 = g.clone()
    sl2 = sl.clone()

# Generated at 2022-06-11 20:01:51.649535
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import sys
    from typing import cast

    from .pytree import Leaf, Node
    from .pgen2 import token

    NodeType = TypeVar("NodeType", bound=Node)

    def pytest_assertrepr_compare(op, left, right):
        if op == "==":
            return

    def check(t1: NodeType, t2: NodeType, eq: bool) -> None:
        if eq:
            assert t1 == t2
        else:
            assert t1 != t2, (t1, t2)

    def check_error(t1, t2, error):
        try:
            t1 == t2
        except error:
            pass

# Generated at 2022-06-11 20:02:01.443050
# Unit test for method remove of class Base
def test_Base_remove():
    s = ""
    t = "a"
    u = "a" + "b"
    v = "a" + "b" + "c"
    t1 = Node(syms.simple_stmt, [Leaf(token.NAME, "a")])
    t2 = Node(syms.simple_stmt, [Leaf(token.NAME, "b")])
    s.parent = t1
    t.parent = t1
    u.parent = t2
    v.parent = t2
    t1.children = [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]
    t2.children = [Leaf(token.NAME, "a"), Leaf(token.NAME, "b"), Leaf(token.NAME, "c")]
    assert s.next_sibling is t

# Generated at 2022-06-11 20:02:09.736577
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node, type_repr

    leaf1 = Leaf(1, 'one')
    leaf2 = Leaf(2, 'two')
    leaf3 = Leaf(3, 'three')
    node = Node(4, [leaf1, leaf2, leaf3])
    assert leaf1.remove() == 0
    assert node.children == [leaf2, leaf3]
    assert leaf1.parent is None
    assert leaf2.remove() == 0
    assert node.children == [leaf3]
    assert leaf2.parent is None
    assert leaf3.remove() == 0
    assert node.children == []
    assert leaf3.parent is None
    assert node.remove() == 0
    print('test_Base_remove passed')
test_Base_remove()

# Generated at 2022-06-11 20:03:22.952892
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern(WildcardPattern(min=1))
    for c, r in pattern.generate_matches([]):
        assert False, "Not supposed to match"
    for c, r in pattern.generate_matches([EmptyNode(token.COMMENT, "")]):
        assert c == 0 and not r, (c, r)
    pattern2 = NegatedPattern(WildcardPattern(min=1, name='foo'))
    for c, r in pattern2.generate_matches([]):
        assert False, "Not supposed to match"
    for c, r in pattern2.generate_matches([EmptyNode(token.COMMENT, "")]):
        assert c == 0 and not r, (c, r)
    pattern3 = NegatedPattern()

# Generated at 2022-06-11 20:03:34.226910
# Unit test for method pre_order of class Node
def test_Node_pre_order():
  lineno = 1
  from . import pytree
  from .pgen2 import token
  from . import pgen2
  from . import fixer_base
  from . import pgen2
  from . import token
  from . import fixer_base
  from .fixer_util import Comma, Name, syms
  import sys, tokenize, io
  tok1 = pytree.Leaf(token.NAME, 'tok1', lineno=lineno, prefix=' ')
  tok2 = pytree.Leaf(token.NAME, 'tok2', lineno=lineno, prefix=' ')
  tok3 = pytree.Leaf(token.NAME, 'tok3', lineno=lineno, prefix=' ')

# Generated at 2022-06-11 20:03:36.522088
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(token.NUMBER, "1")
    assert list(leaf.leaves()) == [leaf]



# Generated at 2022-06-11 20:03:37.829913
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    # method generate_matches not implemented
    pass


# Generated at 2022-06-11 20:03:44.591360
# Unit test for method post_order of class Node
def test_Node_post_order():
    from . import trees
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pytree import Leaf
    from .pgen2 import driver

    g = grammar.Grammar(trees.__file__.replace(b"c", b"y"))
    p = driver.Driver(g, convert=trees.pytree_convert)
    t = p.parse_string("f()")
    assert len(t.children) == 3
    assert isinstance(t.children[0], Leaf)
    assert t.children[0].value == "f"
    assert isinstance(t.children[1], Leaf)
    assert t.children[1].value == "("
    assert isinstance(t.children[2], Leaf)

# Generated at 2022-06-11 20:03:50.494281
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    x = PythonLeaf(25, "test", (1,1))
    y = PythonLeaf(25, "test2", (1,1))
    z = PythonLeaf(25, "test3", (1,1))
    x.parent = PythonNode(256, [x,y,z])
    assert x.get_suffix() == "test2"


# Generated at 2022-06-11 20:03:54.712995
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Node
    n1 = Node(1, [], fixers_applied=["f1", "f2"])
    n2 = n1.clone()
    assert n1.fixers_applied == ["f1", "f2"]
    assert n2.fixers_applied == ["f1", "f2"]


# Generated at 2022-06-11 20:04:00.329971
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols

    for key_val in python_symbols.__dict__.items():
        if key_val[0].isupper():
            assert type_repr(key_val[1]) == key_val[0], key_val[0]



# Generated at 2022-06-11 20:04:10.109997
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    global LeafPattern, NodePattern, WildcardPattern
    from .pgen2.parse import Pattern
    from .pgen2.grammar import BaseGrammar

    class LeafPattern(BasePattern):

        """A pattern matching a single leaf node."""

        def __init__(self, type, content=None, name=None):
            assert type is not None
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            if node.type != self.type:
                return False
            if self.content is not None and node.value != self.content:
                return False
            if results is not None and self.name:
                results[self.name] = node
            return True


# Generated at 2022-06-11 20:04:19.402449
# Unit test for method replace of class Base
def test_Base_replace():
    from .fixer_base import BaseFix

    class MockNode(Base):
        def __init__(self, children):
            self.children = children

    class MockLeaf(Base):
        def __init__(self, item, parent=None):
            self.value = item
            self.prefix = ""
            self.parent = parent

    class MockFix(BaseFix):
        def match(self, node):
            return node.value[0] in "ABC"

        def transform(self, node, results):
            return [mock_a, mock_b]

    mock_a = MockLeaf("A")
    mock_b = MockLeaf("B")
    mock_c = MockLeaf("C")
    mock_d = MockLeaf("D")

# Generated at 2022-06-11 20:05:37.743416
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols

    tree = Leaf(token.NUMBER, "1")
    tree.changed()
    assert tree.next_sibling is None

    tree2 = Leaf(token.NUMBER, "2")
    tree.parent = tree2
    tree2.children = [tree]

    tree3 = Leaf(token.PLUS, "+")
    tree3.parent = tree2
    tree2.children.append(tree3)

    tree4 = Leaf(token.NUMBER, "3")
    tree4.parent = tree2
    tree2.children.append(tree4)

    assert tree.get_suffix() == '+ 3'

    tree_expr_stmt = Node(
        python_symbols.expr_stmt, [tree2])
   

# Generated at 2022-06-11 20:05:46.415888
# Unit test for method leaves of class Base
def test_Base_leaves():
    leaf1 = Leaf(1, 'a')
    leaf2 = Leaf(1, 'b')
    leaf3 = Leaf(1, 'c')
    node1 = Node(2,[leaf1,leaf2])
    node2 = Node(2,[node1,leaf3])
    node3 = Node(2,[node1,node2])
    leaf4 = Leaf(1, 'd')
    leaf5 = Leaf(1, 'e')
    leaf6 = Leaf(1, 'f')
    node4 = Node(2,[leaf4,leaf5])
    node5 = Node(2,[leaf6,node4])
    leaf7 = Leaf(1, 'g')
    node6 = Node(2,[leaf7,node2])
    node7 = Node(2,[node3,node5,node6])

# Generated at 2022-06-11 20:05:49.259229
# Unit test for method leaves of class Base
def test_Base_leaves():
    import warnings
    warnings.warn("test_Base_leaves() built but not run")

# Generated at 2022-06-11 20:06:01.023901
# Unit test for method replace of class Base
def test_Base_replace():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    dtr = g._parse_debug(
        "import FW, SK, S\n"
        "FW(SK(1), S(SK(1)), SK(1))"
    )

    fw = dtr.children[0]
    sk1 = fw.children[0]
    s = fw.children[1]
    sk2 = fw.children[2]

    sk1.replace(Leaf(g.syms.testlist, 'SK(1)'))

    assert dtr.children[0].children[0].prefix == 'SK(1)'
    assert dtr.children[0].children[0].type == g.syms.testlist


# Generated at 2022-06-11 20:06:12.853763
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    from .pygram import python_symbols

    n = Node(python_symbols.simple_stmt, [])
    l1 = Leaf(1, "x")
    l2 = Leaf(2, "y")
    l3 = Leaf(3, "z")
    n.children.extend([l1, l2, l3])

    l1.parent = n
    l2.parent = n
    l3.parent = n

    roots = set([l1, l2, l3])
    assert l1.parent == n
    l1.replace([l2, l3])
    assert l1.parent is None
    assert l2.parent == n
    assert l3.parent == n
    assert n.children == [l2, l3]

# Generated at 2022-06-11 20:06:19.172146
# Unit test for method leaves of class Base
def test_Base_leaves():
    from blib2to3.pgen2.pgen import generate_grammar, tokenize_grammar

    grammar = generate_grammar(Grammar())
    grammar_tokens = tokenize_grammar(grammar)
    root = parse_grammar(grammar_tokens)
    leaves_list = [leaf.value for leaf in root.leaves()]
    assert leaves_list == grammar_tokens



# Generated at 2022-06-11 20:06:22.788372
# Unit test for method clone of class Base
def test_Base_clone():
    class BaseDerived(Base):
        def __init__(self):
            pass
        def __eq__(self, other):
            return True
        def clone(self):
            return Base()

    BaseDerived().clone()


# Generated at 2022-06-11 20:06:34.621842
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    global node_type
    node_type = 0
    def new_node_type():
        global node_type
        node_type += 1
        return node_type
    def Nd(children):
        return Node(new_node_type(), children)
    def Lf(value):
        return Leaf(new_node_type(), value)
    def set_nodes(list):
        return [Nd(item) if isinstance(item, list) else Lf(item) for item in list]
    def test(pattern, nodes, result):
        assert pattern.match_seq(set_nodes(nodes)) == result

    # .*
    test(WildcardPattern(), [], True)
    test(WildcardPattern(), [1], True)
    test(WildcardPattern(), [1, 2], True)

# Generated at 2022-06-11 20:06:39.905237
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.tokenize import tok_name
    from .pgen2.parse import tokenize

    s = "a:=b"
    tokens = list(tokenize(s))
    assert len(tokens) == 3
    assert tok_name[tokens[0].type] == "NAME"
    assert tok_name[tokens[1].type] == "OP"
    assert tok_name[tokens[2].type] == "NAME"
    assert tokens[0].pre_order() == tokens[0]
    assert tokens[1].pre_order() == tokens[1]
    assert tokens[2].pre_order() == tokens[2]
