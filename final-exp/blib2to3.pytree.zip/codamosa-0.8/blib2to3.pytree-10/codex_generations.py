

# Generated at 2022-06-11 19:58:57.474589
# Unit test for method depth of class Base
def test_Base_depth():
    s = """
    def foo():
        pass
    """
    root = pytree.parse(s)
    assert root.depth() == 0
    ifx_stmt = root.children[2]
    assert ifx_stmt.depth() == 1
    pass_stmt = ifx_stmt.children[1]
    assert pass_stmt.depth() == 2


# Generated at 2022-06-11 19:59:07.722327
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from ...pgen2 import driver

    grammar = Grammar(
        """
            start: (NUMBER | NAME) COLON NAME NEWLINE
            NUMBER: "\\d+"
            NAME: "[_a-zA-Z]\\w*"
            COLON: ":"
            NEWLINE: "\\n"
            %import common.WS
            %ignore WS
            """
    )
    parser = driver.Driver(grammar, convert=lambda t: t)
    tree = parser.parse_string("a:b\n")
    assert tree == tree.clone()
    assert tree == tree.clone(convert=lambda t: t)
    assert tree != parser.parse_string("a:c\n")
    assert tree != parser.parse_string("c:b\n")
    assert tree.next_sibling is None

# Generated at 2022-06-11 19:59:18.276531
# Unit test for function generate_matches
def test_generate_matches():
    p0 = NodePattern(type=1)
    p1 = NodePattern(type=2)
    p2 = NodePattern(type=3)
    s0 = NodePattern(type=4)
    s1 = NodePattern(type=5)
    s2 = NodePattern(type=6)
    s3 = NodePattern(type=7)
    wp = WildcardPattern()
    wp2 = WildcardPattern(content = [[p1], [p1, p2]])
    wp3 = WildcardPattern(content = [[s0], [s1], [s2, s3]])
    wp4 = WildcardPattern(content = [[p0], [p1, p2]])
    n0 = NL(0, [NL(1), NL(2), NL(3)])

# Generated at 2022-06-11 19:59:22.176369
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    test = Leaf(TYPE, VALUE, (PREFIX, (LINENO, COLUMN)), FIXERS_APPLIED)
    pre_order = test.pre_order()
    assert next(pre_order) is test



# Generated at 2022-06-11 19:59:29.451978
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    n: Node = Node(2, [Leaf(1, "A"), Leaf(1, "B"), Leaf(1, "C")])
    assert [type(n) for n in n.pre_order()] == [Node, Leaf, Leaf, Leaf]


# Generated at 2022-06-11 19:59:40.597159
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    def create_tree(start):
        start = start
        leaf1 = Leaf(1, "foo")
        leaf1.parent = start
        leaf2 = Leaf(1, "bar")
        leaf2.parent = start
        leaf3 = Leaf(1, "baz")
        leaf3.parent = start
        start.children = [leaf1, leaf2, leaf3]
        return start
    start = create_tree(Node(10, None))

    assert leaf1.get_suffix() == "bar"
    assert leaf2.get_suffix() == "baz"
    assert leaf3.get_suffix() == ""

    start.remove()

    start = create_tree(Leaf(1, "start"))
    assert leaf1.get_suffix() == "bar"
    assert leaf2.get_suffix

# Generated at 2022-06-11 19:59:43.499591
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    'BasePattern(type, content, name)'
    """
    assert 'BasePattern(type, content, name)' == repr(
        BasePattern("type", "content", "name"))



# Generated at 2022-06-11 19:59:52.006065
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from typing import List
    from .pgen2.tokenize import generate_tokens, TokenInfo
    from .pytree import Leaf
    from .pygram import python_symbols

    e = Leaf(1, "alma")
    assert e.get_lineno() == 1

    f = Leaf(1, "alma")
    d = Node(1, [e, f])
    assert d.get_lineno() == 1

    f = Leaf(2, "alma")
    d = Node(1, [e, f])
    assert d.get_lineno() == 1

    d = Node(3, [d, Node(4)])
    assert d.get_lineno() == 1

    e = Leaf(2, "alma")

# Generated at 2022-06-11 20:00:01.758957
# Unit test for method post_order of class Base
def test_Base_post_order():
    import pytree
    from blib2to3.pgen2 import token
    frm = pytree.Node(
        token.NAME, [
            pytree.Leaf(token.NAME, "from"),
            pytree.Leaf(token.NAME, "foo"),
            pytree.Node(token.NAME, [
                pytree.Leaf(token.NAME, "import"),
                pytree.Leaf(token.NAME, "bar"),
            ])
        ]
    )
    expected = [
        pytree.Leaf(token.NAME, "from"),
        pytree.Leaf(token.NAME, "foo"),
        pytree.Leaf(token.NAME, "import"),
        pytree.Leaf(token.NAME, "bar")
    ]
    postorder = list(frm.post_order())


# Generated at 2022-06-11 20:00:03.046034
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from . import token

    leaf = Leaf(token.NAME, "whale")
    assert leaf.post_order() == [leaf]


# Generated at 2022-06-11 20:00:22.681375
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node

    root = Node(1, [Leaf(token.NUMBER, '1', (1, 0)), Leaf(token.PLUS, '+', (1, 2)), Leaf(token.NUMBER, '2', (1, 4))])
    assert [node.type for node in root.pre_order()] == [1, token.NUMBER, token.PLUS, token.NUMBER]
    for node in root.pre_order():
        node.changed()
    assert root.was_changed


# Generated at 2022-06-11 20:00:34.568575
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from .types import red  # noqa
    from .parser_driver import Driver

    driver = Driver(
        ("red -> color 'red'", "color -> 'red' | 'blue' | 'yellow'"),
        "red",
    )
    grammar = driver.grammar
    red_type = grammar.symbol2number["red"]
    grammar.check_consistency()
    t = grammar.type2tuple
    content = t(red_type, [[TextPattern("red")]])
    pattern = NegatedPattern(content)
    nodes = [content]
    matches = list(pattern.generate_matches(nodes))
    assert len(matches) == 0
    assert match_seq(pattern, nodes) is False
    nodes = []
    matches = list(pattern.generate_matches(nodes))


# Generated at 2022-06-11 20:00:39.043227
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(4, 'name')
    assert list(l.leaves()) == [l]


# Generated at 2022-06-11 20:00:41.627084
# Unit test for method post_order of class Node
def test_Node_post_order():
    node = Node(0, []) # TODO: what should the type be?
    assert isinstance(node.post_order(), Iterator)

# Generated at 2022-06-11 20:00:53.365638
# Unit test for method post_order of class Node
def test_Node_post_order():
    a = Node(256, [
        Leaf(1, "foo"),
        Node(258, [
            Leaf(1, "bar"),
            Node(258, [
                Leaf(1, "baz"),
                Leaf(1, "quux"),
            ]),
        ]),
        Leaf(1, "xyzzy"),
    ])

# Generated at 2022-06-11 20:01:01.937519
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node
    n = Node(1, [Node(2, []), Node(3, [Leaf(4, ""), Node(5, [Leaf(6, "")])])])
    it = n.post_order()
    assert next(it).type == 2
    assert next(it).type == 4
    assert next(it).type == 6
    assert next(it).type == 5
    assert next(it).type == 3
    assert next(it).type == 1
    import pytest
    with pytest.raises(StopIteration):
        next(it)

# Generated at 2022-06-11 20:01:04.535438
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    Test node matching for NodePattern instances
    """

    #
    # Patterns that should be optimized away
    #
    for pat in (pattern.EmptyPattern(), pattern.Skip(NodePattern())):
        assert type(pat.optimize()) is pattern.EmptyPattern

    #
    # Patterns that must not be optimized away
    #
    for pat in (pattern.Any(), pattern.Any(), pattern.Skip()):
        assert type(pat.optimize()) is type(pat)



# Generated at 2022-06-11 20:01:12.183367
# Unit test for method depth of class Base
def test_Base_depth():

    class TestBase(Base):

        def __init__(self, children):
            self.children = children

        def post_order(self):
            return self.children

        def pre_order(self):
            return self.children

    class TestChild(TestBase):

        def __init__(self, parent):
            self.parent = parent

    root = TestBase([TestChild(None)])
    assert root.depth() == 0

    child = TestChild(root)
    child.parent = root
    assert child.depth() == 1

# Generated at 2022-06-11 20:01:23.838032
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    g = Grammar()
    a = g.number2symbol[257]
    b = g.number2symbol[258]
    T = NodePattern(type=g.number2symbol[257], content=None, name=None)
    assert list(T.generate_matches([])) == []
    assert list(T.generate_matches([Leaf(a, 'x')])) == [(1, {})]
    assert list(T.generate_matches([Leaf(a, 'x'), Leaf(a, 'y')])) == [(1, {})]
    assert list(T.generate_matches([Leaf(b, 'x')])) == []
    T = NodePattern(type=a, content=[LeafPattern('a', None, None)])

# Generated at 2022-06-11 20:01:33.976245
# Unit test for function generate_matches

# Generated at 2022-06-11 20:01:56.590607
# Unit test for method replace of class Base
def test_Base_replace():
    class node(Base):
        def __init__(self, children=None, parent=None):
            self.children = children
            self.parent = parent
        def post_order(self):
            yield self
            for child in self.children:
                yield from child.post_order()
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()
        def _eq(self, other):
            return self.children == other.children
        def clone(self):
            return node(self.children, None)

    parent = node([])
    child = node([], parent)
    parent.children = [child]

    child.replace(node())
    assert parent.children == [node()]
    assert child.parent is None

    parent2 = node([])

# Generated at 2022-06-11 20:02:07.867905
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as symbols


# Generated at 2022-06-11 20:02:20.467340
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import build_tree


# Generated at 2022-06-11 20:02:28.926209
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node, Internal

    tree = Node(1, [Leaf(1, "a"), Node(1, [Leaf(1, "b"), Internal(1, [Leaf(1, "c"), Leaf(1, "d")])]), Leaf(1, "e")])

    assert set(tree.leaves()) == {Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), Leaf(1, "d"), Leaf(1, "e")}

    tree.remove()

    assert set(tree.leaves()) == {Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), Leaf(1, "d"), Leaf(1, "e")}



# Generated at 2022-06-11 20:02:39.672522
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    if isinstance(__loader__, FSLoader):
        # Only run these tests when running from the unpacked source.
        # Python 3.4 cannot do recursive generators in a doctest, so we
        # cannot run these in the doctest.
        from .test_grammar_lib import test_token, test_pattern, test_pattern_helper
        import sys

        # These tests are for the method generate_matches, so we need to suppress
        # the output that comes from the method match_seq as part of these tests.
        # We set sys.stdout to a StringIO, and restore it later.
        saved_stdout = sys.stdout
        sys.stdout = StringIO()

        # We also have to reinit the grammar token and parser.  This has to be done
        # outside of the try/finally block.


# Generated at 2022-06-11 20:02:45.883085
# Unit test for constructor of class NodePattern
def test_NodePattern():
    try:
        NodePattern("not a type")
    except AssertionError:
        pass
    else:
        raise AssertionError("NodePattern(s) should fail")

    try:
        NodePattern("not a type", "not content or a sequence")
    except AssertionError:
        pass
    else:
        raise AssertionError("NodePattern(s, s) should fail")



# Generated at 2022-06-11 20:02:48.347921
# Unit test for method clone of class Base
def test_Base_clone():
    # Assign param 'self' a value of 'None'
    # Assign param 'other' a value of 'None'
    # No return value expected
    raise NotImplementedError()


# Generated at 2022-06-11 20:03:00.394411
# Unit test for method leaves of class Base
def test_Base_leaves():
    from pprint import pprint

    # A simple sample tree
    t = Bracket(")", "", (1, 0), [])
    n = Bracket(
        "(",
        "",
        (1, 0),
        [
            Leaf(
                1,
                "f",
                (1, 1),
                [
                    Leaf(
                        2,
                        "(",
                        (1, 1),
                        [],
                        ),
                ],
                ),
        ],
        )
    t.parent = n
    n.children.append(t)
    n.parent = None
    n.changed()

    # Expected result
    l = n.leaves()
    l2 = l.copy()
    assert l2==l

# Generated at 2022-06-11 20:03:02.531657
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    x = Leaf (1, '2', 3)
    assert x.leaves() == [x]



# Generated at 2022-06-11 20:03:12.363315
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    # XXX Test for the match method of class BasePattern
    # Note that BasePattern is an abstract base class so the test
    # really checks the method match in its subclasses.
    from .pgen2 import token
    from .pgen2.parse import parse

    token_iter = tokenize.generate_tokens(io.BytesIO(b"abc = 'abc'").readline)
    tokens: List[Leaf] = []
    try:
        while True:
            tok = next(token_iter)
            tokens.append(Leaf(tok[0], tok[1]))
    except tokenize.TokenError:
        pass
    # XXX: need to be on Python 3.5 to have the correct token type

# Generated at 2022-06-11 20:03:52.886838
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Base

    class Dummy(Base):
        def __init__(self):
            self._name = "dummy"

        def _eq(self, other):
            return self._name == other._name

        def clone(self):
            pass

        @property
        def prefix(self):
            pass

        def post_order(self):
            pass

        def pre_order(self):
            pass

        def changed(self):
            pass

    dummy1 = Dummy()
    dummy2 = Dummy()

    # Default implementation works as expected
    assert dummy1 == dummy2
    assert not (dummy1 != dummy2)



# Generated at 2022-06-11 20:03:54.298580
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    pass



# Generated at 2022-06-11 20:04:00.960092
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    class Parent(Node):
        type = 1

    class Child(Base):
        type = 2

    class Sibling(Child):
        type = 3

    parent = Parent()
    child = Child()
    sibling = Sibling()
    parent.append_child(child)
    parent.append_child(sibling)
    assert child.get_suffix() == sibling.prefix



# Generated at 2022-06-11 20:04:03.380706
# Unit test for method remove of class Base
def test_Base_remove():
    parent = Node()
    node = Node()
    parent.append_child(node)
    position = node.remove()
    parent.remove()
    assert position == 0

# Generated at 2022-06-11 20:04:04.929197
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(17, '', None)
    l.post_order()



# Generated at 2022-06-11 20:04:15.917972
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    if sys.version_info[0] == 3:
        # Python 3.x
        s = "foo\nbar\nbaz"
        parent = Node(1, children=[Leaf(1, "foo\n"), Leaf(1, "bar\n")])
        assert parent.get_suffix() == "baz"

        parent = Node(1, children=[Leaf(1, "foo"), Leaf(1, "bar")])
        assert parent.get_suffix() == ""

        parent = Node(1, children=[Leaf(1, "foo\n"), Leaf(1, "bar")])
        assert parent.get_suffix() == ""


    else:
        # Python 2.x
        s = "foo\nbar\nbaz"

# Generated at 2022-06-11 20:04:22.621295
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node
    from .python_tree import Leaf
    from .tree import build_tree
    mytree = build_tree(
        """\
if True:
    print('yes')
else:
    print('no')
""",
        TreeType=TreeType)
    assert tuple(mytree.post_order()) == (
        mytree.children[0].children[1].children[0],
        mytree.children[0].children[1],
        mytree.children[0].children[2],
        mytree.children[0],
        mytree.children[1].children[1].children[0],
        mytree.children[1].children[1],
        mytree.children[1].children[2],
        mytree.children[1],
        mytree)

# Generated at 2022-06-11 20:04:33.872799
# Unit test for method post_order of class Node
def test_Node_post_order():
    n = Node(1, [
        Leaf(1, ""),
        Node(2, [
            Leaf(3, ""),
            Leaf(4, ""),
            Leaf(5, "")
        ]),
        Leaf(6, ""),
        Leaf(7, "")
    ])


# Generated at 2022-06-11 20:04:36.751003
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(0, "")
    assert list(l.pre_order())==[l], "Leaf.pre_order should return a list containing only the invocant leaf"


# Generated at 2022-06-11 20:04:48.442403
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    p = WildcardPattern([[Leaf(token.NAME, "a"), Leaf(token.NAME, "b")], [Leaf(token.NAME, "c")]], name="x")
    assert list(p.generate_matches([Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])) == [(2, {"x": [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]})]

# Generated at 2022-06-11 20:05:29.136629
# Unit test for method leaves of class Base
def test_Base_leaves():

    class BaseLeaf(Leaf):

        """A base leaf class."""

        def __init__(self, name, value):
            self.name = name
            super(BaseLeaf, self).__init__(None, None, (1, 1), value, value)

    def _check_leaves(node, expected_leaves):
        found_leaves = []
        for leaf in node.leaves():
            found_leaves.append(leaf)
        assert found_leaves == expected_leaves, found_leaves

    # Empty node
    root = Node(None, None, (1, 1), [])

    # Single leaf
    leaf_one = BaseLeaf('one', 'one')
    root_one = Node(None, None, (1, 1), [leaf_one])

# Generated at 2022-06-11 20:05:38.799197
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """
    Unit test for method pre_order of class Node.
    """
    import unittest
    from max_phase_tree_gen import AbstractVisitor
    from ._test_util import BaseTestCase

    class Visitor(AbstractVisitor):
        def __init__(self) -> None:
            self.pre_order = []  # type: List[NL]

        def visit_node(self, node_: Node) -> None:
            self.pre_order.append(node_)

    class Test(BaseTestCase):
        """
        Test case for the pre_order method of Node.
        """

        def test_1(self) -> None:
            t = self.get_node("def f(): pass", "simple_stmt")
            v = Visitor()
            t.pre_order_visit(v)

# Generated at 2022-06-11 20:05:46.829188
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pat = NegatedPattern(WildcardPattern(min=1))
    # There should be exactly *one* match
    matches = list(pat.generate_matches([]))
    assert len(matches) == 1, "len(matches) = %d" % len(matches)
    assert len(matches[0]) == 2, "len(matches[0]) = %d" % len(matches[0])
    assert matches[0][0] == 0, "matches[0][0] = %d" % matches[0][0]
    assert len(matches[0][1]) == 0, "len(matches[0][1]) = %d" % len(matches[0][1])
    # There should be no matches

# Generated at 2022-06-11 20:05:50.686245
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    n = NodePattern(type=512)
    assert repr(n) == "NodePattern(type=symbol_number)"



# Generated at 2022-06-11 20:06:02.344313
# Unit test for method depth of class Base
def test_Base_depth():
    def test(node, result):
        if node.depth() != result:
            raise Exception(
                "depth: expected %i got %i"
                % (result, node.depth())
            )
    #
    #  _nodetest:
    #    if node.depth() != result: # pragma: no cover
    #        raise Exception("depth: expected %i got %i" % (result, node.depth()))
    #
    #  _leaf:
    #    _nodetest(node, 0)
    #
    #  _node:
    #    _nodetest(node, 1)
    #
    
    node = Leaf(1, "abcd", (1,2))
    _leaf(node, 0)

# Generated at 2022-06-11 20:06:14.453899
# Unit test for method set_child of class Node

# Generated at 2022-06-11 20:06:26.437732
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    def gen(pattern, nodes):
        return list(pattern.generate_matches(nodes))

    p = LeafPattern(token.STRING)
    assert gen(p, [Leaf(token.STRING, "a")]) == [(1, {})]
    assert gen(p, [Leaf(token.STRING, "a"), Leaf(token.STRING, "b")]) == [(1, {})]
    assert gen(p, [Leaf(token.STRING, "a"), Leaf(token.STRING, "b"), Leaf(token.STRING, "c")]) == [(1, {})]

    p = NodePattern(syms.expr)
    assert gen(p, [Leaf(token.STRING, "a")]) == []

# Generated at 2022-06-11 20:06:36.338355
# Unit test for method remove of class Base
def test_Base_remove():
    class DummyNode(Node):
        """Dummy node that ignores all arguments."""

        def __init__(self):
            super(DummyNode, self).__init__(1,"DUMMY",[])

    dummy1 = DummyNode()
    dummy2 = DummyNode()
    dummy3 = DummyNode()
    dummy1.children = [dummy2, dummy3]
    dummy2.parent = dummy1
    dummy3.parent = dummy1
    assert dummy1.children == [dummy2, dummy3], dummy1.children
    assert dummy2.parent is dummy1, dummy2.parent
    assert dummy3.parent is dummy1, dummy3.parent
    assert dummy1.remove() is None, dummy1.remove()