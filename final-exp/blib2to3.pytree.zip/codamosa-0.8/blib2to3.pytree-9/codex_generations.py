

# Generated at 2022-06-11 19:59:55.962524
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    s = """
    if foo:
        pass
    elif bar:
        pass
    else:
        pass
    """
    t = compile(s, "<test>", "exec")

# Generated at 2022-06-11 19:59:57.057608
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    assert Base().get_lineno() is None



# Generated at 2022-06-11 20:00:00.258203
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(-42) == -42
    assert type_repr(42) == 42



# Generated at 2022-06-11 20:00:10.622363
# Unit test for method clone of class Base
def test_Base_clone():
    class BaseTest(Base):
        def __init__(self, type, parent, context=None):
            self.type = type
            self.parent = parent
            self.context = context
            self.children = []
        def __repr__(self):
            return '<%s at %s>' % (self.__class__.__name__,id(self))
    def _eq(self, other):
        if self.type != other.type:
            return False
        if len(self.children) != len(other.children):
            return False
        for c1, c2 in zip(self.children, other.children):
            if c1 != c2:
                return False
        return True
    def post_order(self):
        for child in self.children:
            yield from child.post_order()

# Generated at 2022-06-11 20:00:18.759791
# Unit test for method clone of class Base
def test_Base_clone():
    class BaseSubclass(Base):
        def __init__(self, x):
            self.x = x
        def _eq(self, other): # type: ignore
            return self.x == other.x
        def clone(self):
            return self.__class__(self.x)
    bs = BaseSubclass(3)
    assert bs.clone() == bs


# Generated at 2022-06-11 20:00:19.900698
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    with pytest.raises(NotImplementedError):
        BasePattern().match_seq([])

# Generated at 2022-06-11 20:00:26.008543
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf

    # NOTE: Not idempotent!
    t = Leaf(1, "", (5, 0))
    t2 = Leaf(2, "", (5, 0))
    t3 = Leaf(3, "", (5, 0))
    t.parent = t2
    t2.children = [t, t3]
    t.remove()
    assert t not in t2.children
    assert t.parent is None
test_Base_remove()



# Generated at 2022-06-11 20:00:30.179935
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    import unittest
    from ast import Add, Num, UAdd
    from . import freeze_ast
    ast1 = Add(Num(n=1), UAdd(Num(n=2)))
    frozen_ast1 = freeze_ast(ast1)
    frozen_ast2 = frozen_ast1.clone()
    ast2 = frozen_ast2.thaw()
    unittest.TestCase().assertEqual(ast1, ast2)


# Generated at 2022-06-11 20:00:38.348739
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pylex import PythonLexer

    l1 = Leaf(1, "foo")
    l2 = Leaf(1, "foo")
    l3 = Leaf(1, "bar")

    # The following code generated a RecursionError in the original
    # version; that could happen if a Node's children were a list
    # containing the node itself.  The fix was to replace
    #     self.children = tuple(self.children)
    # by
    #     self.children = tuple(self.children)
    #         if self.children is not None else None
    # in class Node.
    # n1 = Node(syms.funcdef, (Name(syms.NAME, "foo")))
    # n1.children

# Generated at 2022-06-11 20:00:45.808813
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pytree import Leaf

    class A(BasePattern):
        type = 1

        def _submatch(self, node: Leaf, results=None) -> bool:
            return node.value == "x"

    assert A().match(Leaf(1, "x"))
    assert not A().match(Leaf(2, "x"))
    assert not A().match(Leaf(1, "y"))
    results = {}
    assert A().match(Leaf(1, "x"), results)
    assert not results



# Generated at 2022-06-11 20:01:29.871090
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    
    testsubject = NegatedPattern([[LeafPattern(token.NAME, 'a'), LeafPattern(token.NAME, 'b')], [LeafPattern(token.NAME, 'c')]])
    expected = [[(0, {})]]
    for test_idx, nodes in enumerate([[], ['a'], ['a', 'b'], ['c']]):
        result = [x for x in testsubject.generate_matches(nodes)]
        assert result == expected[test_idx]

test_NegatedPattern_generate_matches()


# Generated at 2022-06-11 20:01:41.004079
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pat = WildcardPattern(min=1)
    assert {} == dict(NegatedPattern(pat).generate_matches([]))
    assert {} == dict(NegatedPattern(pat).generate_matches(["hello"]))
    assert {} == dict(NegatedPattern(pat).generate_matches(["hello", "world"]))
    assert {0: {}} == dict(
        NegatedPattern(NegatedPattern(pat)).generate_matches(["hello"])
    )
    assert {0: {}} == dict(
        NegatedPattern(NegatedPattern(pat)).generate_matches(["hello", "world"])
    )


# A pattern that matches any sequence of nodes.
DOT = WildcardPattern(min=1)



# Generated at 2022-06-11 20:01:53.069057
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    # Just a fairly empty class for testing
    class DummyPattern(BasePattern):
        pass

    class Dummy2Pattern(DummyPattern):
        pass

    class Dummy3Pattern(DummyPattern):
        pass

    class Dummy4Pattern(DummyPattern):
        pass

    from .pgen2.grammar import Symbol

    dp = DummyPattern(Symbol.property_def)
    assert dp.match(Node(Symbol.property_def, []))
    assert not dp.match(Node(Symbol.property_def, []), {})
    assert not dp.match(Node(Symbol.def_stmt, []))
    dp2 = Dummy2Pattern(Symbol.property_def)
    assert dp2.match(Node(Symbol.property_def, []))

# Generated at 2022-06-11 20:01:56.000202
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pgen2 import token
    from .pytree import Leaf, Node, type_repr

    t = Node(token.NAME, [Leaf(token.NAME, 'x')])
    t.leaves()



# Generated at 2022-06-11 20:01:56.534889
# Unit test for method post_order of class Base
def test_Base_post_order():
    pass



# Generated at 2022-06-11 20:02:07.770016
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Test for a non-wildcard pattern matching a sequence of nodes
    import unittest
    from unittest.mock import patch

    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse

    class TestNodePattern(unittest.TestCase):
        def setUp(self) -> None:
            self.grammar = Grammar("", {})
            self.node_pattern = NodePattern(1, None, None)

        def test_match_seq(self) -> None:
            test = [Leaf(1, "test", None, "x", [])]
            self.assertTrue(self.node_pattern.match_seq(test))
            test = [Leaf(2, "test", None, "x", [])]

# Generated at 2022-06-11 20:02:16.712057
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    test_node = Node(
        256,
        [
            Leaf("a"),
            Node(256,
                [
                    Leaf("b"),
                    Leaf("c"),
                ]
            ),
            Leaf("d"),
        ]
    )
    assert test_node.pre_order() == [test_node, test_node.children[0], test_node.children[1], test_node.children[1].children[0], test_node.children[1].children[1], test_node.children[2]]


# Generated at 2022-06-11 20:02:27.380507
# Unit test for method depth of class Base
def test_Base_depth():
    from textwrap import dedent
    from .pytree import Leaf, Node, type_repr
    from .pygram import python_symbols as syms
    from . import consts


# Generated at 2022-06-11 20:02:31.001809
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class DummyPattern(BasePattern):
        type = None
        content = None
        name = None
    p = DummyPattern()
    q = p.optimize()
    assert p is q, (p, q)

# Generated at 2022-06-11 20:02:41.304555
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Test the method post_order of class Base.
    # Input:
    #   node: a node.
    # Output:
    #   a sequence of nodes in the post-order of the tree containing node.
    # Operation:
    #   This method is implemented in the abstract class Base, so this method
    #   serves as a unit test for Base and its concrete subclasses.

    # TODO(jchyan): Consider adding some more unit tests for Base.
    from .pytree import Node

    node = Node(1)
    assert not node.post_order()

    node = Node(2, [Node(1), Node(1), Node(1), Node(1), Node(1), Node(1)])
    res = list(node.post_order())
    assert res == node.children


# Generated at 2022-06-11 20:03:11.425286
# Unit test for function generate_matches
def test_generate_matches():
    """
    Test the generate_matches function.
    """
    node = NL(
        type=1,
        children=[
            NL(type=2, children=[]),
            NL(
                type=3,
                children=[
                    NL(type=4, children=[]),
                    NL(type=5, children=[]),
                ],
            ),
            NL(type=2, children=[]),
        ],
    )
    alt1 = NL(type=4, children=[NL(type=5, children=[])])
    alt2 = NL(type=5, children=[NL(type=4, children=[])])
    alt3 = NL(type=4, children=[])
    alt4 = NL(type=5, children=[])

# Generated at 2022-06-11 20:03:22.323514
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from blib2to3.fixer_util import Leaf, Token, Node, syms, token
    import unittest
    import sys
    import io
    import contextlib # contextlib.redirect_stdout

    class NodeTest(Node):
        """
        Test class for Node
        """
        _fields = ("value",)
        value = ""

    # Testing for Node

    # __init__ test - ok
    # function __init__ of class Node
    unittest.TestCase().assertEqual(False, Node.__init__(Node(), "a", [Leaf(token.TYPE_IGNORE, "1")]))

    # __repr__ test - ok
    # function __repr__ of class Node
    with contextlib.redirect_stdout(io.StringIO()):
        unittest.TestCase

# Generated at 2022-06-11 20:03:25.229974
# Unit test for method post_order of class Node
def test_Node_post_order():
    expr = parser.expr()
    i = expr.post_order()
    assert len(list(i)) == 11

# Generated at 2022-06-11 20:03:27.356446
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.DOT) == "DOT"
    assert type_repr(python_symbols.RBRACK) == "RBRACK"

    assert type_repr(-1234) == -1234


T = TypeVar("T")


# For debugging purposes.
#

# Generated at 2022-06-11 20:03:34.732965
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import ast

    p = LeafPattern(ast.Expr)
    nodes = [ast.Expr(ast.Str("hello"))]
    assert p.match_seq(nodes) is True
    nodes = [ast.Expr(ast.Str(""))]
    assert p.match_seq(nodes) is True
    nodes = [ast.Expr(ast.Name("hello", ast.Load()))]
    assert p.match_seq(nodes) is False
    nodes = []
    assert p.match_seq(nodes) is False



# Generated at 2022-06-11 20:03:39.318522
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Make sure method optimize isn't redefined but returns self.
    class Match(BasePattern):
        def _submatch(self, node, results=None):
            return True

    assert Match.optimize.__func__ is BasePattern.optimize.__func__
    p = Match(Token.NUMBER)
    assert p.optimize() is p

# Generated at 2022-06-11 20:03:43.222033
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    prefix = "test_prefix"
    suffix = "test_suffix"
    test_node = Base(1, prefix)
    assert test_node.get_suffix() == ""
    test_node = Base(1, prefix)
    test_node.parent = Base(1)
    test_node.parent.children = [test_node, Leaf(1, suffix)]
    assert test_node.get_suffix() == suffix



# Generated at 2022-06-11 20:03:53.937027
# Unit test for method leaves of class Base
def test_Base_leaves():
    # Test to make sure the leaves of an empty AST produce no leaves.
    class Node(Base):
        def __init__(self, children: List[NL]):
            self.children = children
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()
        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self
    n = Node([])
    assert list(n.leaves()) == []
    # Test to ensure that all leaves are correctly found by the leaves method
    l1 = Leaf(1, "A")
    l2 = Leaf(2, "B")
    l3 = Leaf(3, "C")
    l4 = Leaf(4, "D")
    l5 = Leaf

# Generated at 2022-06-11 20:04:00.703388
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    class _L(Leaf):
        def __init__(self, type, value, context=None, prefix=None):
            Leaf.__init__(self, type, value, context, prefix)
    t = _L(1, '1')
    assert t.post_order().__next__() is t
    assert t.post_order().__next__() is t



# Generated at 2022-06-11 20:04:11.056678
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols
    tree = Node(python_symbols.expr_stmt, [
        Node(python_symbols.power, [
            Leaf(1, 'name'),
            Leaf(2, '**'),
            Leaf(1, 'power'),
        ], prefix='    ')
    ])

# Generated at 2022-06-11 20:05:28.344871
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Example 1
    class Node(Base):
        def _eq(self, other):
            return True
    n1 = Node()
    n2 = Node()
    n1.__eq__(n2) == True
    n2.__eq__(n1) == True
    # Example 2
    from .pytree import Node, Leaf
    class Node(Node):
        def _eq(self, other):
            return self.type == other.type
    Node(1, []).__eq__(Node(1, [])) == True
    Node(1, []).__eq__(Node(2, [])) == False
    Node(1, []).__eq__(Leaf(1, "")) == False
    # Example 3

# Generated at 2022-06-11 20:05:33.095870
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    """Test method __eq__ of class Base"""
    import unittest
    import ast
    import inspect

    class Base_TestCase(unittest.TestCase):
        def test_Base__eq__(self):
            # Replace this call with other tests
            assert False, "Not implemented"

    unittest.main()



# Generated at 2022-06-11 20:05:40.777817
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    for name, val in vars(python_symbols).items():
        if not name.startswith("_"):
            assert name == type_repr(val)

# Do we allow whitespace to appear in leaf strings?
LEAF_STRING_ALLOW_WHITESPACE: bool = True

# Do we allow trailing comma in lists/tuples/dicts/sets?
LEAF_TRAILING_COMMA: bool = True

# Do we allow a trailing comma in function def parameters lists?
LEAF_FUNCDEF_TRAILING_COMMA: bool = True



# Generated at 2022-06-11 20:05:47.829994
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    import sys
    class DummyPattern:
        def generate_matches(self, nodes):
            for c in range(len(nodes)+1):
                yield c, {}
    pattern = NegatedPattern(DummyPattern())
    nodes = sys._getframe(0).f_locals['nodes']
    for count, results in pattern.generate_matches(nodes):
        assert False, "Negated pattern should never generate matches"



# Generated at 2022-06-11 20:05:54.643008
# Unit test for method set_child of class Node
def test_Node_set_child():
    name = Name('name')
    n = Node(1, [Leaf(1, 'foo'), name, Leaf(1, 'bar')])
    new_name = Name('new_name')
    n.set_child(1, new_name)
    assert name.parent is None
    assert new_name.parent is n
    assert n.children[1] is new_name


# Generated at 2022-06-11 20:06:01.109124
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Node, Leaf
    e1 = Node(1, [Leaf(2, "a"), Leaf(2, "b")])
    e2 = Node(1, [Leaf(2, "a"), Leaf(2, "b")])
    assert e1 == e2
    e3 = Node(1, [Leaf(2, "a"), Leaf(2, "c")])
    assert not e1 == e3

# Generated at 2022-06-11 20:06:06.672284
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class TestPattern(BasePattern):
        def __init__(self, *args, **kwds):
            pass
    pattern = TestPattern(None)
    assert pattern.match_seq([])==False
    assert pattern.match_seq([Node(256,[])])==False
test_BasePattern_match_seq()


# Generated at 2022-06-11 20:06:16.009655
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    node = Node(1, [Leaf(1, "a"), Leaf(2, "b"), Leaf(1, "c")])

    # Test that optimizations don't change the result.
    class DumbPattern(BasePattern):
        def optimize(self):
            return self
    assert DumbPattern(None, "a").match(node) is False
    assert DumbPattern(1).match(node) is True
    assert DumbPattern(1, "b").match(node) is False
    assert DumbPattern(1, "a").match(node) is True
    assert DumbPattern(1, None).match(node) is True
    assert DumbPattern(1, "a").match_seq(node.children) is True
    assert DumbPattern(1, "b").match_seq(node.children) is False



# Generated at 2022-06-11 20:06:28.300648
# Unit test for method set_child of class Node
def test_Node_set_child():
    import unittest
    from ..pygram import python_symbols as syms
    from ..pytree import Leaf, Node

    class Node_set_child_Tests(unittest.TestCase):

        def setUp(self):
            self.leaf1 = Leaf(1, "hi")
            self.leaf2 = Leaf(2, "there")
            children = [self.leaf1, self.leaf2]
            self.node = Node(syms.testList_n, children)

        def test_sets_child_node_parent(self):
            child = Leaf(1, "hi")
            self.node.set_child(0, child)
            self.assertEqual(self.node, self.node.children[0].parent)


# Generated at 2022-06-11 20:06:36.923952
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from . import pytoken
    from .pygram import python_symbols


    def normalize(x):
        if isinstance(x, Base):
            return x.clone()
        elif sys.version_info[0] < 3 and isinstance(x, unicode):
            return x.encode("utf-8")
        else:
            return x


    class BaseTest(Base):
        def _eq(self, other):
            if len(self.children) != len(other.children):
                raise AssertionError("%r: self.children and other.children must have the\
 same length (%r vs %r)" % (type(self), self.children, other.children))