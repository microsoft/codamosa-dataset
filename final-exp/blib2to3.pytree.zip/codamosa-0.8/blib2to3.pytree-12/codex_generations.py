

# Generated at 2022-06-11 19:59:49.448113
# Unit test for method replace of class Base
def test_Base_replace():
    class Node(Base):
        def __init__(self, *children):
            self.children = list(children)
            for child in children:
                child.parent = self

        def clone(self):
            return Node(*[ch.clone() for ch in self.children])

        def _eq(self, other):
            return self.children == other.children

        def post_order(self):
            for ch in self.children:
                yield from ch.post_order()
            yield self

        def pre_order(self):
            yield self
            for ch in self.children:
                yield from ch.pre_order()

        def __repr__(self):
            return f"Node({','.join(repr(ch) for ch in self.children)})"


# Generated at 2022-06-11 19:59:57.612376
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Leaf, Leaf, Leaf
    from .pytree import Leaf, Leaf, Leaf
    from .pytree import Leaf, Leaf, Leaf, Leaf
    from .pytree import Leaf, Leaf, Leaf
    root_node = Node(321, [Node(270, [Leaf(1, 'def'), Leaf(1, 'f'), Leaf(22, '('), Leaf(24, ')'), Leaf(1, ':'), Leaf(4, ''), Leaf(4, ''), Leaf(4, ''), Leaf(4, ''), Leaf(4, '')]), Node(271, [Leaf(4, ''), Leaf(1, 'pass')])], (2, 0), '')
    gen = root_node.post_order()
    assert_equal(next(gen), Leaf(1, 'pass'))

# Generated at 2022-06-11 20:00:08.369275
# Unit test for method post_order of class Node

# Generated at 2022-06-11 20:00:14.919494
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node

    class Foo(Node):
        def __init__(self, children=None, type=None):
            Node.__init__(self, children, type)

    a = Node([1, 2, 3])
    assert a.remove() == 0
    a.append_child(4)
    a.append_child(5)
    a.append_child(6)
    assert a.remove() == 3
    assert a.remove(1) == 1

    b = Node([])
    c = Node([], a)
    d = Foo([], b)
    e = Node([])
    f = Node([], e)
    g = Node([], f)
    b.append_child(c)
    e.append_child(f)
    f.append_child(g)


# Generated at 2022-06-11 20:00:19.317881
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    """ Test the abstract method Base.get_suffix.
    """
    base = Base()
    try:
        base.get_suffix()
        assert False, "Base.get_suffix called on abstract Base instance"
    except NotImplementedError:
        pass



# Generated at 2022-06-11 20:00:28.045344
# Unit test for method leaves of class Base
def test_Base_leaves():
    l1 = Leaf(1, "a")
    l2 = Leaf(2, "b")
    l3 = Leaf(3, "c")
    l4 = Leaf(4, "d")
    l5 = Leaf(5, "e")
    l6 = Leaf(6, "f")
    l7 = Leaf(7, "g")
    l8 = Leaf(8, "h")
    l9 = Leaf(9, "i")
    l10 = Leaf(10, "j")
    l11 = Leaf(11, "k")
    l12 = Leaf(12, "l")

    n1 = Node(1, [l1])
    n2 = Node(2, [l2, l3])
    n4 = Node(4, [l4])
    n5 = Node(5, [n2])


# Generated at 2022-06-11 20:00:37.010854
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    assert Base().get_suffix() == ""

    class Node(Base):
        def __init__(self, children = None, parent = None):
            self.children = children or []
            self.parent = parent
            if parent is not None:
                assert self not in parent.children
            for child in self.children:
                child.parent = self

    class Leaf(Base):
        def __init__(self, prefix="", parent = None):
            self.prefix = prefix
            self.parent = parent
            if parent is not None:
                assert self not in parent.children

    root = Node([
        Leaf("hi"),
        Leaf(" "),
        Leaf("there")])
    assert root.children[0].get_suffix() == " "
    assert root.children[1].get_suffix() == "there"


# Generated at 2022-06-11 20:00:39.823564
# Unit test for method post_order of class Base
def test_Base_post_order():
  # Bug discovered by py3k syntax tests
  n = Node(1, [Node(2, [Leaf(3, 'b'), Leaf(4, 'c')]), Leaf(5, 'a')])
  assert [type(i) for i in n.post_order()] == [Leaf, Leaf, Node, Node]


# Generated at 2022-06-11 20:00:49.914559
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    x = object()
    assert repr(BasePattern(1, x)) == "NodePattern(1, %r)" % x
    assert repr(BasePattern(1, None)) == "NodePattern(1)"
    assert repr(BasePattern(1)) == "NodePattern(1)"
    assert repr(BasePattern(1, x, "x")) == "NodePattern(1, %r, 'x')" % x
    assert repr(BasePattern(1, None, "x")) == "NodePattern(1, None, 'x')"
    assert repr(BasePattern(1, "x")) == "NodePattern(1, 'x')"

# Generated at 2022-06-11 20:01:01.256833
# Unit test for method remove of class Base
def test_Base_remove():
    o = Leaf(1, 'a')
    assert o.remove() is None

    o = Leaf(1, 'a')
    p = Node(2, [o])
    assert o.remove() == 0

    o = Leaf(1, 'a')
    p = Node(2, [o, Leaf(3, 'b')])
    assert o.remove() == 0
    assert p.children == [Leaf(3, 'b')]

    o = Leaf(1, 'a')
    p = Node(2, [o, Leaf(3, 'b'), Leaf(4, 'c')])
    assert o.remove() == 0
    assert p.children == [Leaf(3, 'b'), Leaf(4, 'c')]

    o = Leaf(1, 'a')

# Generated at 2022-06-11 20:01:19.180357
# Unit test for method __repr__ of class BasePattern

# Generated at 2022-06-11 20:01:27.349651
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    """Test method pre_order of class Base."""
    from .pytree import Leaf, Node
    from . import pytree
    from .pygram import python_symbols as syms


# Generated at 2022-06-11 20:01:29.825249
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class DummyPattern(BasePattern):
        pass
    p = DummyPattern()
    assert p is p.optimize()



# Generated at 2022-06-11 20:01:41.193509
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    test_cases = [
        Leaf(1, ""),
        Leaf(1, "", (1, 2)),
        Node(1, []),
        Node(1, [], (1, 2)),
        Node(1, [Leaf(2, "one"), Leaf(2, "two")]),
        Node(1, [Leaf(2, "one"), Leaf(2, "two")], (1, 2)),
    ]
    for case in test_cases:
        new = case.clone()
        assert case == new, (case, new)
        assert case is not new
        for child in case.post_order():
            if isinstance(child, Leaf):
                assert child is not new.leaves().__next__()
            elif isinstance(child, Node):
                assert child

# Generated at 2022-06-11 20:01:53.248482
# Unit test for function generate_matches
def test_generate_matches():
    n1, n2, n3, n4 = [Node(value="n%d" % i) for i in range(1, 5)]
    a, b, c = [NodePattern(value="a"), NodePattern(value="b"), NodePattern(value="c")]
    f = lambda patterns, nodes: [
        (c, r) for c, r in generate_matches(patterns, nodes)
    ]
    assert f([], []) == [(0, {})]
    assert f([a], []) == []
    assert f([a], [n1]) == [(0, {})]
    assert f([a], [n2]) == [(1, {"a": [n2]})]
    assert f([a, b], [n1, n2]) == [(0, {})]

# Generated at 2022-06-11 20:02:00.125481
# Unit test for method match_seq of class WildcardPattern

# Generated at 2022-06-11 20:02:09.124653
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import driver
    from . import tokenize

    def test(pattern, nodes):
        matcher = driver.compile_pattern(pattern)
        assert pattern.match_seq(nodes) == matcher.match_seq(nodes)

    def test_match(pattern, nodes, results):
        matcher = driver.compile_pattern(pattern)
        r = matcher.match_seq(nodes)
        assert r == results
        r = {}
        assert pattern.match_seq(nodes, r) == results
        assert r == results

    test("1+2", [nodes["1"], nodes["+"], nodes["2"]])
    test("1+(2,)", [nodes["1"], nodes["+"], nodes["("], nodes["2"], nodes[","], nodes[")"]])

# Generated at 2022-06-11 20:02:22.416733
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    class DummySubPattern():
        def __init__(self, name=None):
            self.name = name

    p = WildcardPattern(
        [[DummySubPattern()]],
        1,
        1,
        "foo"
    )
    p = p.optimize()
    assert p.__class__ == DummySubPattern

    p = WildcardPattern(
        [[DummySubPattern("foo")]],
        1,
        1,
        "foo"
    )
    # This shouldn't optimize to a NodePattern because it's a repeated subpattern
    p = p.optimize()
    assert p.__class__ == WildcardPattern


#####
# Generators yielding (count, results) tuples.
#
# count is the number of children matched.
# results is a dictionary of results (named subpattern

# Generated at 2022-06-11 20:02:30.182991
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    properties = dict(
        type = 0,
        value = '',
        context = (str, (int, int)),
        prefix = str,
        fixers_applied = list,
    )
    properties.update(type=0)
    properties.update(value='')
    properties.update(context=(str, (int, int)))
    properties.update(prefix=str)
    properties.update(fixers_applied=list)
    properties.update(children=list)
    properties.update(parent=(Optional[Node]))
    properties.update(prev_sibling_map=(Optional[Dict[int, Optional[Leaf]]]))
    properties.update(next_sibling_map=(Optional[Dict[int, Optional[Leaf]]]))
    properties.update(was_changed=bool)
    properties

# Generated at 2022-06-11 20:02:34.891637
# Unit test for function generate_matches
def test_generate_matches():
    # Empty sequence
    result = list(generate_matches([], []))
    assert result == [(0, {})], result

    # Single pattern
    result = list(generate_matches([NodePattern(type=1)], [Name("A", 1)]))
    assert result == [(1, {})], result
    result = list(generate_matches([NodePattern(type=1)], [Name("A", 2)]))
    assert result == [], result

    # Two patterns
    result = list(generate_matches([NodePattern(type=1), NodePattern(type=1)], [Name("A", 1)]))
    assert result == [], result

# Generated at 2022-06-11 20:02:51.807480
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    n = Leaf(1, "")
    assert BasePattern(1).match_seq([n])
    # Missing node
    assert not BasePattern(1).match_seq([])
    # Too many nodes
    assert not BasePattern(1).match_seq([n, n])
    # Wrong type
    assert not BasePattern(1).match_seq([n], results={})
    # Wrong type and results:
    assert not BasePattern(1).match_seq([Leaf(1, [])], results={})

# Generated at 2022-06-11 20:02:56.536154
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    t = Node(1, [Leaf(1, "v1"), Leaf(2, "v2"), Leaf(3, "v3")])
    assert list(t.pre_order()) == [t, t.children[0], t.children[1], t.children[2]]


# Generated at 2022-06-11 20:03:01.432822
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node, Leaf

    for depth in range(4):
        child = Leaf(0, "")
        for _ in range(depth):
            child = Node(0, [child])
        assert child.depth() == depth + 1



# Generated at 2022-06-11 20:03:06.180453
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    print('test_Leaf_post_order... ', end='')
    import pickle
    # Test pickling
    x = Leaf(1,'abc', (1,1))
    assert x == pickle.loads(pickle.dumps(x))
    print('passed')


# Generated at 2022-06-11 20:03:16.780674
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols

    def test_equal(T1, T2, eq=True):
        if eq:
            assert T1 == T2, (T1, T2)
            assert T2 == T1, (T2, T1)
        else:
            assert T1 != T2, (T1, T2)
            assert T2 != T1, (T2, T1)

    a = Leaf(1, "a")
    assert a == a
    assert a != 1
    assert a != "a"
    assert "a" != a
    b = Leaf(1, "b")
    c = Leaf(1, "c")
    d = Node(python_symbols.dictorsetmaker, [a, b])
    assert a in d

# Generated at 2022-06-11 20:03:25.290672
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    import re, pytest
    from _ast27 import Name, FunctionDef

    # Capture the nodes
    nodes = []
    for m in re.finditer(r"def|\w+", "def xyz(abc):"):
        nodes.append(Name(m.group(0)))
    # Optimize them
    p = NodePattern(name="bare_name")
    content = [[p]]
    wc = WildcardPattern(content)
    negated_wc = NegatedPattern(wc)
    # Check the matches
    for m in negated_wc.generate_matches(nodes):
        assert m == (len(nodes), {})
    p = NodePattern(type=FunctionDef)
    content = [[p]]
    wc = WildcardPattern(content)
    negated_wc = Neg

# Generated at 2022-06-11 20:03:36.366302
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.driver as driver
    import lib2to3.fixer_base as fixer_base
    import tests.test_grammar as test_grammar
    import io

    # Make a test grammar.
    grammar = driver.load_grammar(test_grammar)
    test_grammar_str = io.StringIO()
    test_grammar.dump_grammar(test_grammar_str, grammar)

    # Parse the test grammar.
    tree = parse.parse_string(test_grammar_str.getvalue(), grammar)
    print(tree)

    # Test Base_get_suffix()
    s = ', '

# Generated at 2022-06-11 20:03:41.658828
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # '.': WildcardPattern()
    assert WildcardPattern().optimize() == WildcardPattern()
    # '(a b)': WildcardPattern([[LeafPattern('a'), LeafPattern('b')]])
    wp = WildcardPattern([[LeafPattern("a"), LeafPattern("b")]])
    assert wp.optimize() == wp
    assert (
        WildcardPattern(min=2, max=2, content=[[LeafPattern("a"), LeafPattern("b")]],)
        .optimize()
        == NodePattern(content=[LeafPattern("a"), LeafPattern("b")])
    )

# Generated at 2022-06-11 20:03:45.300842
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Node
    n = Node(1, [Node(2, []), Node(3, [])])
    assert list(n.pre_order()) == [n, n.children[0], n.children[1]]



# Generated at 2022-06-11 20:03:51.243492
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(
        type=0,
        value="",
        context=("", (0, 0)),
        prefix="",
        fixers_applied=[],
    )
    generator = leaf.pre_order()
    assert next(generator) is leaf
    with pytest.raises(StopIteration):
        next(generator)


# Generated at 2022-06-11 20:04:28.139767
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node

    a = Leaf(0, "a")
    b = Leaf(0, "b")
    n1 = Node(0, [a, b])

    assert a.get_suffix() == "b"
    assert b.get_suffix() == ""
    assert n1.get_suffix() == ""

    return True


# Generated at 2022-06-11 20:04:36.363267
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(0) == 0
    assert type_repr(python_symbols.error_leaf) == "error_leaf"

# Hacks for Python 3.X:
if sys.version_info[0] == 3:
    # get rid of the 6.X definition
    del type_repr
    from .pygram import python_symbols

    def type_repr(type_num: int) -> Union[int, Text]:
        for name in dir(python_symbols):
            if type(name) == str and name.startswith("NUMBER"):
                # Skip number tokens
                continue
            val = getattr(python_symbols, name)
            if type(val) == int and val == type_num:
                return name
        return type_num


# Generated at 2022-06-11 20:04:48.260952
# Unit test for function generate_matches
def test_generate_matches():
    def g(patterns, nodes):
        return list(generate_matches(patterns, nodes))
    a = NodePattern()
    b = NodePattern()
    c = NodePattern()
    a1 = NodePattern()
    b1 = NodePattern()
    c1 = NodePattern()
    # Empty patterns and nodes
    assert g([], []) == [(0, {})]
    # Empty patterns
    assert g([], [a, b]) == [(0, {})]
    # Empty nodes
    assert g([a, b], []) == [(0, {})]
    # Non-empty patterns and nodes
    assert g([a, b], [a, b]) == [(2, {})]
    # Matches over empty sequences
    assert g([a, b], [a, a]) == [(1, {})]
    # Non-matching

# Generated at 2022-06-11 20:04:51.361537
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.trailer) == "trailer"
    assert type_repr(-2) == -2
    assert type_repr(0) == 0



# Generated at 2022-06-11 20:05:01.953931
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Unit test for Base.get_suffix()
    # Test setup
    from . import pygram
    from .pgen2 import tokenize
    from .pytree import Leaf
    from . import python_tree
    from . import fixer_base
    from .patcomp import PatternCompiler
    from .pygram import python_grammar

    class myfixer(fixer_base.BaseFix):
        pass

    # Test body
    pytree = python_tree.PythonTree
    Compile = PatternCompiler.compile
    pytokens = pygram.python_tokens
    type_repr = pytokens.tok_name
    syms = pygram.python_symbols
    tokens = tokenize.tok_name
    grammar = python_grammar


# Generated at 2022-06-11 20:05:06.608823
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class Example(BasePattern):
        def __init__(self, value):
            self.value = value
        def _submatch(self, node, results=None):
            return node.value == self.value
    e = Example("hello")
    assert e.optimize() is e

# Generated at 2022-06-11 20:05:17.593168
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import SourceFileLoader

    ldr = SourceFileLoader("<string>", "<string>")
    st = ldr.load_module("<string>")
    # Verify that the grammar was compiled correctly

# Generated at 2022-06-11 20:05:29.614515
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node

    def check(expected, tree):
        it = tree.pre_order()
        for item in expected:
            cur = next(it)
            assert cur is item, (cur, item)
        assert cur is item
        try:
            cur = next(it)
        except StopIteration:
            pass
        else:
            assert False, (cur, expected)

    check([], Leaf(1, ""))
    check([Leaf(1, ""), Leaf(2, "")], Node(1, [Leaf(1, ""), Leaf(2, "")]))

# Generated at 2022-06-11 20:05:39.048875
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    if '__package__' not in globals() or __package__ is None or len(__package__)==0:
      from Path import Path
    else:
      from .Path import Path

    c = Path('.').as_cwd()
    pygram = c.join('pygram')
    if pygram.exists():
      pygram_path = pygram
    else:
      pygram = c.parent.join('pygram')
      if pygram.exists():
        pygram_path = pygram
      else:
        raise Exception('No "pygram" directory found')

    # As soon as we have a pygram directory, we can import from it
    from pygram import pytree as pyTree
    from pygram import python_grammar as pythonGrammar

    # Pick up the parser object for Python 3.7


# Generated at 2022-06-11 20:05:46.924942
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pgen2.tokenize import generate_tokens, tokenize, untokenize
    from .pytree import Leaf, Node

    # from .pygram import python_symbols as syms
    def mkleaf(type, string, lineno):
        return Leaf(type, string, lineno)

    def mknode(type_, children, lineno):
        return Node(type_, children, lineno)

    def test_stmts(stmts):
        assert stmts
        tokens = list(tokenize(StringIO(stmts).readline))
        tree = untokenize(tokens)
        tree.changed()
        assert untokenize(tokens) == untokenize(list(tree.leaves()))

    test_stmts("x = 1")
    test_stmts

# Generated at 2022-06-11 20:06:17.484825
# Unit test for function generate_matches
def test_generate_matches():
    n1 = Node(type=0, children=[])
    n2 = Node(type=1, children=[])
    n3 = Node(type=2, children=[])
    n4 = Node(type=3, children=[])
    n5 = Node(type=4, children=[])
    n6 = Node(type=5, children=[])
    n7 = Node(type=6, children=[])
    n8 = Node(type=7, children=[])
    n9 = Node(type=8, children=[])
    n10 = Node(type=9, children=[])
    n11 = Node(type=10, children=[])
    n12 = Node(type=11, children=[])

    # single node pattern
    p1 = NodePattern(1)
    assert list(generate_matches([p1], []))

# Generated at 2022-06-11 20:06:18.226869
# Unit test for method leaves of class Base
def test_Base_leaves(): pass



# Generated at 2022-06-11 20:06:20.084190
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert repr(BasePattern(Token.NAME, None, None)) == "BasePattern(NAME, None, None)"

# Generated at 2022-06-11 20:06:32.844147
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from . import parse, token

    def check(pattern, node, expected):
        print(pattern, node, expected)
        results = {}
        if pattern.match_seq(node, results):
            actual = results
        else:
            actual = None
        assert actual == expected, (actual, expected)

    check(parse.WildcardPattern(), [], None)
    check(parse.WildcardPattern(min=10), [], None)
    check(parse.WildcardPattern(max=10), [], {})
    check(parse.WildcardPattern(), [Leaf(token.NAME, "abc")], {})

# Generated at 2022-06-11 20:06:36.819031
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NOTE) == "NOTE"
    assert type_repr(python_symbols.DUMMY_NOTE) == "DUMMY_NOTE"
    assert type_repr(python_symbols.NOOP) == "NOOP"

