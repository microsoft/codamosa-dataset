

# Generated at 2022-06-11 19:58:51.726917
# Unit test for method post_order of class Node
def test_Node_post_order():
    a = Leaf(1, "a", None)
    b = Leaf(2, "b", None)
    c = Leaf(3, "c", None)
    d = Leaf(4, "d", None)
    foo = Node(5, [c, d], None)
    bar = Node(6, [a, b, foo], None)
    for node, test in zip(bar.post_order(), [d, c, foo, b, a, bar]):
        if node is test:
            continue
        print(node)
        print(test)
        assert node is test
    for node, test in zip(bar.pre_order(), [bar, a, b, foo, c, d]):
        if node is test:
            continue
        print(node)
        print(test)
        assert node is test



# Generated at 2022-06-11 19:59:04.377931
# Unit test for function generate_matches
def test_generate_matches():
    assert list(generate_matches([], [Node(1), Node(2)])) == []
    t1 = NodePattern(1)
    assert list(generate_matches([t1], [])) == []
    assert list(generate_matches([t1], [Node(2)])) == []
    assert list(generate_matches([t1], [Node(1)])) == [(1, {})]
    assert list(generate_matches([t1], [Node(1), Node(1)])) == [(1, {})]
    assert list(generate_matches([t1, t1], [Node(1), Node(2)])) == []
    assert list(generate_matches([t1, t1], [Node(1), Node(1)])) == [(2, {})]



# Generated at 2022-06-11 19:59:14.911117
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    comment = """
    This is a test for the get_suffix method of the Base class.
    """

# Generated at 2022-06-11 19:59:25.662142
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert_equal(repr(BasePattern(1, "value")), "LeafPattern(1, 'value')")
    assert_equal(repr(BasePattern(1, None)), "LeafPattern(1, None)")
    assert_equal(repr(BasePattern(1, name='var')), "LeafPattern(1, None, 'var')")
    assert_equal(repr(BasePattern(257, "value")), "NodePattern(257, 'value')")
    assert_equal(repr(BasePattern(257, None)), "NodePattern(257, None)")
    assert_equal(repr(BasePattern(257, name='var')), "NodePattern(257, None, 'var')")



# Generated at 2022-06-11 19:59:35.907765
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # ------------ Expected result of generate_matches(nodes)
    np = NegatedPattern()
    assert list(np.generate_matches([])) == [(0, {})]
    assert list(np.generate_matches([])),(0, {})
    assert list(np.generate_matches([1,2,3])) == []
    np1 = NegatedPattern(LeafPattern(100))
    assert list(np1.generate_matches([1,2,3])) == [(0, {})]
    assert list(np1.generate_matches([Leaf(100)])) == []


# Generated at 2022-06-11 19:59:41.924266
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p1 = WildcardPattern(min=1, max=1)
    p2 = WildcardPattern(min=1, max=1, name="foo")
    p3 = WildcardPattern(min=0, max=1)
    p4 = WildcardPattern(min=2, max=2)
    p5 = WildcardPattern(min=0, max=1, name="foo")
    p6 = WildcardPattern(min=2, max=2, name="foo")
    p7 = WildcardPattern(min=1, max=1, name="foo", content=[[p1]])
    p8 = WildcardPattern(min=1, max=1, name="foo", content=[[p2]])
    p9 = WildcardPattern(min=1, max=1, name="foo", content=[[p3]])
   

# Generated at 2022-06-11 19:59:43.536911
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import driver

    driver.parse_tokens("a = 1")



# Generated at 2022-06-11 19:59:47.836484
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf

    root = Node(syms.small_stmt, [Leaf(1, "a"), Leaf(1, "b")])
    leaves = list(root.post_order())
    assert leaves[0] is root.children[1]
    assert leaves[1] is root.children[0]
    assert leaves[2] is root



# Generated at 2022-06-11 19:59:52.996661
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    text = "abc def"
    tree = parse_python_input(text, debug_tree=True)
    leaf = get_leaf(tree, "abc", Leaf("abc", 0, 3))
    assert leaf.get_suffix() == " "
    leaf = get_leaf(tree, "def", Leaf("def", 4, 7))
    assert leaf.get_suffix() == ""


# Generated at 2022-06-11 19:59:59.828126
# Unit test for function generate_matches

# Generated at 2022-06-11 20:00:34.528319
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    l = Leaf(1, "a")
    assert l.remove() is None
    l1 = Leaf(1, "b")
    l2 = Leaf(1, "c")
    l3 = Leaf(1, "d")
    l4 = Leaf(2, "e")
    l2.parent = l
    l.children = [l1, l2, l3]
    l4.parent = l2
    l2.children = [l4]

    assert l.remove() is None
    assert l2.remove() == 0
    assert l.children == [l1, l3]

    l2 = Leaf(1, "c")
    l.children.append(l2)
    assert l2.remove() == 1

# Generated at 2022-06-11 20:00:43.130504
# Unit test for method depth of class Base
def test_Base_depth():
    class P(Node):
        def __init__(self, kids):
            self.children = kids

    class Q(Node):
        def __init__(self, kids):
            self.children = kids

    class R(Node):
        def __init__(self, kids):
            self.children = kids

    n1 = P([Q([R([])])])
    n2 = Q([R([])])
    assert n1.depth() == 0
    assert n2.depth() == 1



# Generated at 2022-06-11 20:00:52.300891
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from blib2to3.pgen2.tokenize import generate_tokens, NAME, class_chars
    line_no = 0
    lst = []
    for token in generate_tokens(StringIO("class MyClass: pass").readline):
        if token[0] == NAME and set(token[1]) == class_chars:
            n = Leaf(token[0], token[1], line_no)
            lst.append(n)
        line_no = token[2][0]
    assert lst[0].get_lineno() == 0



# Generated at 2022-06-11 20:01:01.199499
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node, Base
    class Foo(Base):
        def get_lineno(self):
                return super().get_lineno()
    node = Node(1, [Leaf(1, "foo"), Leaf(1, "bar"), Leaf(2, "baz")])
    assert node.children[0].get_lineno() == node.get_lineno()
    assert node.children[1].get_lineno() == node.get_lineno()
    assert node.children[2].get_lineno() == 2
    assert Foo(3, [Leaf(3, "foo")]).get_lineno() is None



# Generated at 2022-06-11 20:01:12.757503
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    #  class Base(object):
    tree = Leaf(1, "x", (1, 1))
    assert tree.get_lineno() == 1
    tree = Leaf(1, "x", (0, 0))
    assert tree.get_lineno() == 0

    tree = Leaf(1, "x", (1, 0))
    node = Node(1, [tree])
    assert node.get_lineno() == 1

    node = Node(1, [])
    assert node.get_lineno() is None

    node = Node(1, [Leaf(2, "y", (2, 1))])
    assert node.get_lineno() == 2

    #  def test_Base_get_suffix(self):

# Generated at 2022-06-11 20:01:19.094546
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """Unit test for method generate_matches of class NegatedPattern"""
    import token
    import tokenize

    s = "if a:\n    pass\nelse:\n    pass\n"

    class FakeOpener(object):
        def __getitem__(self, name):
            return StringIO(s)

    tokens = tokenize.tokenize(FakeOpener()["foo.py"].readline)


# Generated at 2022-06-11 20:01:31.012338
# Unit test for function generate_matches
def test_generate_matches():
    na = NodePattern(type=token.NAME)
    nb = NodePattern(type=token.NAME)
    nc = NodePattern(type=token.NAME)
    nd = NodePattern(type=token.NAME)
    a = Node(type=token.NAME)
    b = Node(type=token.NAME)
    c = Node(type=token.NAME)
    d = Node(type=token.NAME)
    e = Node(type=token.NAME)
    f = Node(type=token.NAME)
    ab = Node(
        type=token.COLON, children=[a, b], prefix=[], type_ignores_children=True
    )

# Generated at 2022-06-11 20:01:42.211757
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern = WildcardPattern(((NodePattern(),), (NodePattern(), NodePattern())))
    assert isinstance(pattern, WildcardPattern), pattern
    pattern = pattern.optimize()
    assert isinstance(pattern, WildcardPattern), pattern
    pattern = WildcardPattern(((NodePattern(),),))
    pattern = pattern.optimize()
    assert isinstance(pattern, NodePattern), pattern
    pattern = WildcardPattern(((NodePattern(),),), min=1, max=1)
    pattern = pattern.optimize()
    assert isinstance(pattern, NodePattern), pattern

    pattern = WildcardPattern(name="bare_name")
    pattern = pattern.optimize()
    assert isinstance(pattern, WildcardPattern), pattern
    pattern = WildcardPattern(((LeafPattern(NAME),),), name="bare_name")
    pattern = pattern.optim

# Generated at 2022-06-11 20:01:45.403520
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():

    l = Leaf(257, 'a', (), '   ')
    assert [l] == [c for c in l.post_order()]



# Generated at 2022-06-11 20:01:56.525014
# Unit test for function generate_matches
def test_generate_matches():
    import unittest
    from test.test_grammar import ParseError

    class Test(unittest.TestCase):
        def _test(self, patterns, nodes, expected):
            patterns = [compile(p) for p in patterns]
            nodes = [compile(n) for n in nodes]
            actual = list(generate_matches(patterns, nodes))
            #print("actual", actual)
            self.assertEqual(actual, expected)


# Generated at 2022-06-11 20:02:40.674389
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    p = WildcardPattern([], min=0, max=2, name="wild")
    q = Leaf(1, 'a')
    r = Leaf(1, 'b')
    seq = [q, q, q, q, q, q, q, q, q, q, q, q, q, q, q, q, q]
    m = p.match_seq(seq)
    assert m, seq



# Generated at 2022-06-11 20:02:41.991877
# Unit test for method post_order of class Base
def test_Base_post_order():
    # test_Base_post_order
    pass

# Generated at 2022-06-11 20:02:48.423681
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import pytree
    #
    token = pytree.Leaf(0, 'a')
    assert token.match(token)
    assert token.match(pytree.Leaf(1, 'b')) is False
    assert token.match(pytree.Leaf(0, 'b')) is False
    assert token.match(pytree.Leaf(0, 'a'))
    assert token.match(pytree.Leaf(0, 'a'), {})
    assert token.match(pytree.Leaf(0, 'a'), {})
    #
    node = pytree.Node(1, [token])
    assert node.match(node)
    assert node.match(pytree.Node(1, [pytree.Leaf(0, 'a')]))
    node.prefix = ' '

# Generated at 2022-06-11 20:02:51.728910
# Unit test for constructor of class NodePattern
def test_NodePattern():
    try:
        NodePattern(content=[])
        raise AssertionError("Empty content must fail")
    except AssertionError:
        pass



# Generated at 2022-06-11 20:03:04.508534
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # The pattern for an identifier
    ident_pattern = NodePattern()
    ident_pattern.type = token.NAME
    ident_pattern.content = Content(Content.RHS_STRING_ONLY)
    # The pattern for a single base expression, which may be anything
    base_expression_pattern = WildcardPattern()
    base_expression_pattern.type = symbol.testlist1
    # An import statement
    import_stmt_pattern = NodePattern()
    import_stmt_pattern.type = symbol.import_stmt
    import_stmt_pattern.patterns = [
        ident_pattern,
        ident_pattern,
        base_expression_pattern
    ]
    import_stmt_pattern.name = "import_stmt_pattern"
    # The pattern for a module body
    body_pattern = WildcardPattern()


# Generated at 2022-06-11 20:03:05.991856
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    x = BasePattern()
    assert not x.match_seq([])
    assert not x.match_seq([Node(0, [])])
    assert not x.match_seq([Node(0, []), Node(0, [])])

# Generated at 2022-06-11 20:03:07.920812
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, "test")
    assert l.leaves() is  not None

# Generated at 2022-06-11 20:03:20.234492
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # 1) Concrete examples
    from .pgen2 import token

    import unittest

    # 1a) LeafPattern
    p = LeafPattern(token.STRING)
    unittest.assertFalse(p.match_seq([]))
    unittest.assertFalse(p.match_seq([Node(1, [])]))
    unittest.assertFalse(p.match_seq([Node(token.STRING, [])]))
    unittest.assertTrue(p.match_seq([Leaf(token.STRING, "")]))

    # 1b) NodePattern
    p = NodePattern(token.metasyntax_dblquote, None, None)
    unittest.assertFalse(p.match_seq([]))

# Generated at 2022-06-11 20:03:22.773243
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.and_expr) == "and_expr"



# Generated at 2022-06-11 20:03:26.132905
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    n = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert n.clone() == n



# Generated at 2022-06-11 20:04:05.922578
# Unit test for method post_order of class Node
def test_Node_post_order():
    import libfuturize.fixes.fix_next
    import libfuturize.fixes.fix_raw_input
    import libfuturize.fixes.fix_reduce
    import libfuturize.fixes.fix_reload
    import libfuturize.fixes.fix_renames
    import libfuturize.fixes.fix_unicode
    import libfuturize.fixes.fix_urllib
    import libfuturize.fixes.fix_xrange
    import libfuturize.fixes.fix_zip
    __file__ = libfuturize.fixes.fix_next.__file__
    __file__ = libfuturize.fixes.fix_raw_input.__file__
    __file__ = libfuturize.fixes.fix_reduce.__file

# Generated at 2022-06-11 20:04:16.525796
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    class Node_is_Base(Base):
        def __init__(self, type_num, parent=None, children=None):
            self.type = type_num
            self.parent = parent
            if children is None:
                children = []
            self.children = children

        def _eq(self, other):
            return True

        def clone(self):
            pass

        @property
        def prefix(self):
            return 'a'

        def post_order(self):
            pass

        def pre_order(self):
            pass

    node = Node_is_Base(1)
    # function, class, method
    node_a = Node_is_Base(2)
    node_b = Base()
    assert (not node == node_a)
    node_a.parent = node
    assert node == node

# Generated at 2022-06-11 20:04:22.967899
# Unit test for method clone of class Node
def test_Node_clone():
    """Test method clone of class Node

    This is a testing stub. Replace this comment with a better
    description of what this code tests.
    """
    # Put your test code here. Be sure to test all possible paths through your code.
    # These are not all of the tests that should be run!
    import sys
    sys.path.append('..')
    #import lib2to3.pgen2.parse
    import lib2to3.pgen2.token
    import lib2to3.pgen2.convert
    mygrammar = lib2to3.pgen2.parse.parse_grammar('../Grammar.txt')
    myconverter = lib2to3.pgen2.convert.Converter(mygrammar)
    mynewgrammar = myconverter.convert()

# Generated at 2022-06-11 20:04:32.311973
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(10) == 10
    assert type_repr(python_symbols.or_test) == "or_test"
    assert type_repr(python_symbols.testlist_comp) == "testlist_comp"
    assert python_symbols.or_test == 1
    class X:
        a = 1
    # py2 and py3 differ
    if sys.version_info[0] == 2:
        assert X.a == 1
    else:
        assert X.a is X.__dict__["a"]



# Generated at 2022-06-11 20:04:35.050126
# Unit test for constructor of class NodePattern
def test_NodePattern():
    pat = NodePattern(None, ())
    pat = NodePattern(None, ["x"])
    pat = NodePattern(None, ["x", WildcardPattern()])


# Generated at 2022-06-11 20:04:46.957452
# Unit test for method get_suffix of class Base

# Generated at 2022-06-11 20:04:53.886609
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from . import pytree

    class Foo(Base):
        def __init__(self):
            pass

        def _eq(self, other):
            return True

    f1 = Foo()
    f2 = Foo()
    f3 = None  # type: Any
    f4 = Foo()
    f4.type = 42
    assert f1 == f2 # assert(f1 == f2)
    assert f1 != f3 # assert(f1 != f3)
    assert f1 != f4 # assert(f1 != f4)



# Generated at 2022-06-11 20:05:04.949483
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """By the way, you could use py.test for this kind of stuff."""
    import unittest
    import test.support
    from . import patcomp


# Generated at 2022-06-11 20:05:08.664769
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    type_ = parse_int(input())
    children = input()
    _repr = parse_func_body(input())
    n = Node(type_, children)
    assert repr(n) == _repr

# Generated at 2022-06-11 20:05:18.691494
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node

    tree_str = """\
for x in [1,2,3]:

    print(x)
"""
    tree = Leaf(0, tree_str, None, None)
    assert tree.get_lineno() == 0

    func = tree.clone()
    func.prefix = ""
    block = Node(python_symbols.suite, [Leaf(token.INDENT, "    ", None, None), Leaf(1, "print(x)", None, None)])
    func.append_child(block)
    # Add another node to the tree to test that it works on nodes that are not
    # at the top level of the tree
    # func is now:
    # for x in [1,2,3]:
    #     print(x)
    # continue

# Generated at 2022-06-11 20:06:24.693503
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(256, "foo")
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-11 20:06:30.484593
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    wp = WildcardPattern(min=1, max=1, content=[["a"]])
    assert not wp.match_seq(["b"])
    assert not wp.match_seq(["a", "b"])
    assert wp.match_seq(["a"])



# Generated at 2022-06-11 20:06:32.378270
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "test")
    assert list(leaf.pre_order()) == [leaf]



# Generated at 2022-06-11 20:06:37.578672
# Unit test for method leaves of class Base
def test_Base_leaves():
    import ast
    import copy
    import random
    assert Base().leaves() == [].__iter__()
    assert type(Base().leaves()) == type([].__iter__())
    random.seed(0)
    for i in range(100):
        l = random.randrange(100)
        t = ast.parse("X" * l)
        assert [x.value for x in Base(t).leaves()] == ["X" * l]
