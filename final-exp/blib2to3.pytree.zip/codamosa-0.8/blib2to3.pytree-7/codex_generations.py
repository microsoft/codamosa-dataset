

# Generated at 2022-06-11 19:58:17.011503
# Unit test for function generate_matches
def test_generate_matches():
    p = NodePattern(NUMBER, [WordPattern("x"), NodePattern(NUMBER, [])])
    n = [NL(NUMBER, "2"), NL(NAME, "x"), NL(NUMBER, "4")]
    for c, r in generate_matches([p], n):
        assert c == 2 and r["x"] == [NL(NUMBER, "2")]


# --------------------
# Pattern matching API
# --------------------



# Generated at 2022-06-11 19:58:21.319681
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    n = Node(256, [Leaf(1, "A", (" ", (1, 0)), "A"),Leaf(1, "B", (" ", (1, 2)), "B")])
    p = LeafPattern(1, "A")
    r = list(p.generate_matches([n]))
    assert r == [(1, {'A': Leaf(1, 'A', (' ', (1, 0)), 'A')})], r

# Generated at 2022-06-11 19:58:33.681627
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    class DummyNode(Node):
        def __eq__(self, other):
            return self.type == other.type and tuple(self.children) == tuple(other.children)
        def __repr__(self):
            return 'DummyNode(type = %d, children = %s)'%(self.type, repr(self.children))

    l1 = Leaf(1, '1')
    l2 = Leaf(2, '2')
    l3 = Leaf(3, '3')
    l4 = Leaf(4, '4')
    l5 = Leaf(5, '5')
    l6 = Leaf(6, '6')
    l7 = Leaf(7, '7')
    l8 = Leaf(8, '8')

# Generated at 2022-06-11 19:58:42.793631
# Unit test for constructor of class NodePattern
def test_NodePattern():
    pattern = NodePattern(content=[LeafPattern(1, "2"), LeafPattern(3, "4")])
    assert pattern.type is None
    assert isinstance(pattern.content, list)
    assert all(isinstance(x, BasePattern) for x in pattern.content)
    assert pattern.name is None

    pattern = NodePattern(1, [LeafPattern(1, "2"), LeafPattern(3, "4")])
    assert pattern.type == 1
    assert isinstance(pattern.content, list)
    assert all(isinstance(x, BasePattern) for x in pattern.content)
    assert pattern.name is None



# Generated at 2022-06-11 19:58:54.447511
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    p = LeafPattern(token.NAME, "f")
    if sys.version_info[:2] >= (3, 5):
        # Test that the output is a generator.
        assert isinstance(p.generate_matches([]), types.GeneratorType)
    from .pgen2.token import tok_name

    # Test that the number of leaf nodes processed is returned.
    assert list(p.generate_matches([Leaf(token.NAME, "f"), Leaf(token.NAME, "g")])) == [
        (1, {"NAME": Leaf(3, "f")})
    ]

    # Test that a LeafPattern with a content value only matches Leaf nodes
    # with that value.

# Generated at 2022-06-11 19:58:57.111948
# Unit test for method set_child of class Node
def test_Node_set_child():
    class Class1:
        pass
    n = Node(0, [])
    n.set_child(0, Class1())



# Generated at 2022-06-11 19:59:02.414075
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Node
    from .pygram import python_symbols
    from .parse import ParserError
    if "Smalltalk" in sys.version:
        raise ParserError("")
    lineno = 42
    cnumber = python_symbols.COMMA
    a = Leaf(cnumber, '(', (1, 3), lineno)
    b = Leaf(cnumber, '(', (1, 3), lineno)
    c = Leaf(cnumber, '(', (1, 3), lineno)
    d = Node(python_symbols.file_input, [a, b, c])
    a.parent = b.parent = c.parent = d
    a.changed()
    if not a.was_changed:
        raise ParserError("")
    b.changed()

# Generated at 2022-06-11 19:59:07.180873
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern()
    nodes = [Leaf(1, "1")]
    for c, r in pattern.generate_matches(nodes):
        print(f"count={c}, r={r}")


# Generated at 2022-06-11 19:59:17.476792
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern = WildcardPattern(
        [[LeafPattern(token.NAME), LeafPattern(token.EQUAL)], [LeafPattern(token.COMMA), LeafPattern(token.COMMA), LeafPattern(token.COMMA)]],
        1,
        1,
    )
    result = pattern.optimize()
    expected = NodePattern(
        content=[
            [
                NodePattern(
                    content=[
                        LeafPattern(token.NAME),
                        LeafPattern(token.EQUAL),
                    ]
                ),
                NodePattern(
                    content=[
                        LeafPattern(token.COMMA),
                        LeafPattern(token.COMMA),
                        LeafPattern(token.COMMA),
                    ]
                )
            ]
        ]
    )
    assert result == expected
    assert result is not pattern

# Generated at 2022-06-11 19:59:19.172981
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # TODO: testing harness for this method
    return NotImplemented


# Generated at 2022-06-11 19:59:38.647475
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # Test all Nodes
    grammar = Grammar(open(grammar_file))

# Generated at 2022-06-11 19:59:49.290329
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    class Pattern(BasePattern):
        pass
    class Node(object):
        def __init__(self, type):
            self.type = type
    nodes = [Node(42)]
    assert tuple(Pattern().generate_matches(nodes)) == ((1, {}),)
    assert tuple(Pattern(type=None).generate_matches(nodes)) == ((1, {}),)
    assert tuple(Pattern(type=42).generate_matches(nodes)) == ((1, {}),)
    assert tuple(Pattern(type=43).generate_matches(nodes)) == ()
    assert tuple(Pattern().generate_matches([])) == ()
    assert tuple(Pattern(type=42).generate_matches([])) == ()
    nodes = []

# Generated at 2022-06-11 19:59:50.949667
# Unit test for method clone of class Base
def test_Base_clone():
    # Test the method clone of the class Base
    raise NotImplementedError



# Generated at 2022-06-11 19:59:58.569459
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from . import grammar, token, parse
    gr = grammar.Grammar()

    class DummyParserDriver(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, *args, **kwds):
            pass
        def parse(self, *args, **kwds):
            return parse.CompUnit('x = "abc"')
    parser = DummyParserDriver(gr, convert)
    p = LeafPattern(token.NAME, content="x")
    res = list(p.generate_matches(parser.parse()[0].children))
    assert res == [(1, {})], res
    p = LeafPattern(token.STRING, content="abc")
    res = list(p.generate_matches(parser.parse()[0].children))
    assert res

# Generated at 2022-06-11 20:00:03.513801
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    print("Testing Node.pre_order")
    s = "a += 1"
    t1 = ast.parse(s)
    t2 = ast.parse(s)
    result = set(Node.pre_order(t1))
    expected = set(t2.pre_order())
    assert result == expected, (result, expected)
    print("[OK]")


# Generated at 2022-06-11 20:00:11.188515
# Unit test for method depth of class Base
def test_Base_depth():
    """Unit test for method depth of class Base"""
    # Not really a unit test, but a demonstration
    from .pytree import Leaf, Node, type_repr, dump, print_tree
    num = Leaf(2, "42", None)
    plus = Leaf(1, "+", None)
    expr = Node(3, [num, plus, num])
    exprplus = Node(3, [expr, Leaf(1, "+", None), num])
    print(exprplus.depth(), expr.depth(), num.depth())
    print_tree(exprplus)
    print(dump(exprplus))



# Generated at 2022-06-11 20:00:23.736973
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import random

    content = random.choice((None, []))  # type: Optional[Iterable[Iterable[Any]]]
    min = random.choice((0, 1))
    max = HUGE
    if not content:
        max = random.choice((1, 10))
    w = WildcardPattern(content, min, max)

    if not content:
        for i in range(min - 1):
            assert not w.match_seq([random.choice(string.ascii_letters) for _ in range(i)])
        for i in range(min, 1 + max):
            assert w.match_seq([random.choice(string.ascii_letters) for _ in range(i)])
        for i in range(max + 1, max + 1 + (max - min) * 2):
            assert not w.match_

# Generated at 2022-06-11 20:00:27.343152
# Unit test for method leaves of class Base
def test_Base_leaves():
    x: Base
    assert x.leaves() == [Leaf(1, "foo"), Leaf(1, "bar")]


# Generated at 2022-06-11 20:00:36.374935
# Unit test for method changed of class Base
def test_Base_changed():
    from .pgen2.parse import Parser
    from .pytree import Leaf, Node, convert_tree_to_pgen_node
    from .fixer_util import Name, Call, String


# Generated at 2022-06-11 20:00:46.153747
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Test for method __eq__(self, other)
    class foo(Base):
        def __init__(self, val):
            self.val = val
        def _eq(self, other):
            return self.val == other.val
        def clone(self):
            return foo(self.val)
        def pre_order(self):
            return
        def post_order(self):
            return
    f1 = foo(1)
    f1c = foo(1)
    f2 = foo(2)
    assert f1 == f1c
    assert not (f1 == f2)

    class bar(Base):
        def __init__(self, val):
            self.val = val
        def _eq(self, other):
            return self.val == other.val

# Generated at 2022-06-11 20:01:23.302726
# Unit test for method post_order of class Node
def test_Node_post_order():
# No additional unit tests found

    return


# Generated at 2022-06-11 20:01:33.925090
# Unit test for method generate_matches of class WildcardPattern

# Generated at 2022-06-11 20:01:43.183914
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    _p = WildcardPattern(((LeafPattern('a'),),), 0, 2)
    _op = WildcardPattern(None, 0, 2)
    assert _p.optimize() == _op, _p.optimize()
    _p = WildcardPattern(((LeafPattern('a'),),), 1, 2)
    _op = LeafPattern('a')
    assert _p.optimize() == _op, _p.optimize()
    _p = WildcardPattern(((LeafPattern('a'),),), 1, 3)
    _op = WildcardPattern(None, 1, 3)
    assert _p.optimize() == _op, _p.optimize()

# Generated at 2022-06-11 20:01:54.529759
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    import unittest

    class NodeTests(unittest.TestCase):
        def setUp(self):
            self.leaf1 = Leaf(1, "a")
            self.leaf2 = Leaf(1, "b")
            self.leaf3 = Leaf(1, "c")
            self.node = Node(1, None, None, [self.leaf1, self.leaf2, self.leaf3])

        def test_get_lineno(self):
            self.assertEqual(self.node.get_lineno(), None)

        def test_get_lineno_leaf_only(self):
            self.assertEqual(self.leaf1.get_lineno(), None)


# Generated at 2022-06-11 20:01:57.784213
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    print(NegatedPattern().generate_matches([1,2,3]))
    print(NegatedPattern().generate_matches([]))
    print(NegatedPattern(NodePattern([])).generate_matches([]))
    print(NegatedPattern(NodePattern([[]])).generate_matches([[]]))


# Generated at 2022-06-11 20:02:04.587105
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    name = Leaf(Token.NAME, "name")
    for leaf in name.leaves():
        assert isinstance(leaf, Leaf)
        assert leaf.type == Token.NAME
        assert leaf.value == "name"
        assert leaf.prefix == ""
        assert leaf.lineno == 0
        assert leaf.column == 0


# Generated at 2022-06-11 20:02:13.892228
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import Base, tok_name

    for cls in [Base, LeafPattern, NodePattern, WildcardPattern]:
        assert cls().match_seq([]) is False
        assert cls().match_seq([Leaf(11, "foo")]) is False
        assert cls().match_seq([Leaf(11, "foo"), Leaf(11, "foo")]) is False
    assert LeafPattern(11, "foo").match_seq([Leaf(11, "foo")]) is True
    assert LeafPattern(11, "foo").match_seq([Leaf(11, "foo"), Leaf(11, "foo")]) is False
    assert NodePattern(11).match_seq([Leaf(11, "foo")]) is True

# Generated at 2022-06-11 20:02:22.305838
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf1 = Leaf(1, "a", ("\n", (0, 0)))
    leaf2 = Leaf(2, "b", ("\n", (0, 1)))
    leaf3 = Leaf(3, "c", ("\n", (0, 2)))
    leaf1.append_child(leaf2)
    leaf2.append_child(leaf3)
    leaves = list(leaf1.leaves())
    assert [leaf1] == leaves


# Generated at 2022-06-11 20:02:30.083110
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import tempfile
    import blib2to3.pgen2.driver
    grm = blib2to3.pgen2.driver.load_grammar()
    drv = blib2to3.pgen2.driver.Driver(grm)
    buf = tempfile.TemporaryFile()
    buf.write(b"if a: pass\n")
    buf.seek(0)
    st = drv.parse_tokens(buf.readline)
    def test_contents(st):
        from .pygram import python_symbols

# Generated at 2022-06-11 20:02:38.928898
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree
    from .pygram import python_symbols

    # Python 2.7
    tree = pytree.Node(python_symbols.single_input, [
        pytree.Leaf(token.STRING, '"hello"', prefix='"'),
    ])
    assert list(Base.post_order(tree)) == [
        pytree.Leaf(token.STRING, '"hello"', prefix='"'),
        pytree.Node(python_symbols.single_input, [
            pytree.Leaf(token.STRING, '"hello"', prefix='"'),
        ]),
    ]



# Generated at 2022-06-11 20:04:03.891595
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class TestNode(Node):
        pattern = NodePattern(type=1, content=Any())
        def _optimize(self, pattern=pattern):
            (context, ), _ = pattern.match(self)
            return context
    node = TestNode(1, [Leaf(1, "x")])
    assert node._optimize() is None

    node = TestNode(1, [Leaf(2, "x")])
    assert node._optimize() is node


#
#  +------------------------------------------------------+
#  |                                                      |
#  |                    Leaf Patterns                     |
#  |                                                      |
#  +------------------------------------------------------+
#


# Generated at 2022-06-11 20:04:10.061093
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    assert Node(type=1, children=[], lineno=1).get_lineno() == 1
    assert Node(type=1, children=[Leaf(type=1, value='a', lineno=1)], lineno=1).get_lineno() == 1
    assert Node(type=1, children=[Leaf(type=1, value='a', lineno=None)], lineno=1).get_lineno() == None



# Generated at 2022-06-11 20:04:19.369423
# Unit test for method post_order of class Base
def test_Base_post_order():
    import pytest

    from .pytree import Leaf, Node

    def check_post_order(node: Node, expected: List[int]) -> None:
        got = [x.type for x in node.post_order()]
        assert got == expected, (got, expected)

    t = Node(1, [])
    check_post_order(t, [1])
    t.append_child(Leaf(2, ""))
    t.append_child(Leaf(3, ""))

    check_post_order(t, [2, 3, 1])

    t.insert_child(1, Node(4, [Leaf(5, "")]))
    check_post_order(t, [2, 5, 4, 3, 1])


# Generated at 2022-06-11 20:04:31.700373
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pygram import python_symbols as syms
    from .pytree import Leaf

    test_node = [1, "", (1, 1), [3, "", (1, 1), [4, "", (1, 1), [1, "", (1, 1), []]]]]
    expected_leaves = [
        [4, "", (1, 1), [1, "", (1, 1), []]]
    ]
    assert_leaves(test_node, expected_leaves)

    test_node_2 = [1, "", (1, 1), [3, "", (1, 1), [4, "", (1, 1), []]]]
    expected_leaves_2 = [
        [4, "", (1, 1), []]
    ]

# Generated at 2022-06-11 20:04:35.733917
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Base.__eq__
    n1 = Node(0, [Leaf(1, "foo"), Leaf(2, "bar")])
    n2 = Node(0, [Leaf(1, "foo"), Leaf(2, "bar")])
    assert n1 == n2 and n2 == n1

# Generated at 2022-06-11 20:04:39.080050
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, 'abc')
    assert l.leaves() == [l], l.leaves()
    

# Generated at 2022-06-11 20:04:49.782162
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pygram import python_symbols as syms
    from .pytree import Leaf
    leaf1 = Leaf(1, "one")
    leaf2 = Leaf(2, "two")
    leaf3 = Leaf(3, "three")
    leaf4 = Leaf(4, "four")
    leaf5 = Leaf(5, "five")
    node1 = Node(syms.expr_stmt, [leaf1, leaf2])
    node2 = Node(syms.expr_stmt, [leaf3, leaf4])
    node3 = Node(syms.file_input, [node1, node2])
    assert node3.get_lineno() == node1.get_lineno()
    assert node1.get_lineno() == leaf1.get_lineno()

# Generated at 2022-06-11 20:05:00.718077
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    for p in (
        parse_pattern("~.+"),
        parse_pattern(r"~[0-9]*\.[0-9]+"),
        parse_pattern(r"~[0-9]+(\.[0-9]+)*(E[-+]?[0-9]+)?j?"),
    ):
        print("Test NegatedPattern.generate_matches with {}".format(p))
        result = list(p.generate_matches([Number(0.0), Number(1.0)]))
        assert len(result) == 1, repr(result)
        print("NegatedPattern.generate_matches(~.+) -> [0, {}]".format(result[0]))
        result[0][1]["value"] == 1.0  # type: ignore

# Generated at 2022-06-11 20:05:11.852864
# Unit test for method leaves of class Base
def test_Base_leaves():
    from io import StringIO
    import sys
    import unittest

    from blib2to3.pgen2 import driver, tokenize

    #from blib2to3.pygram import python_symbols as symbols
    from blib2to3.pytree import Leaf, Node, type_repr

    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from blib2to3.pgen2.pgen import Grammar
        from blib2to3.pgen2.token import Token

    class TestBase(unittest.TestCase):
        """
        Test that the leaves method of Base works as expected
        """


# Generated at 2022-06-11 20:05:13.338222
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(2) == "COMMA"



# Generated at 2022-06-11 20:05:38.319664
# Unit test for method post_order of class Node
def test_Node_post_order():
    #
    # Tests for Node.post_order
    #
    from .pgen2 import token

    t = Node(python_symbols.file_input, [])
    assert list(t.post_order()) == [t]

    t = Node(python_symbols.file_input, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])
    assert list(t.post_order()) == [
        Leaf(token.NAME, "a"),
        Leaf(token.NAME, "b"),
        t,
    ]

    t = Node(
        python_symbols.file_input,
        [Node(python_symbols.stmt, [Leaf(token.NAME, "a")]), Leaf(token.NAME, "b")],
    )

# Generated at 2022-06-11 20:05:44.791861
# Unit test for method remove of class Base
def test_Base_remove():
    """
    >>> from lib2to3.pgen2.tokenize import generate_tokens, TokenInfo
    >>> tokenize = lambda x: list(TokenInfo(*token) for token in generate_tokens(StringIO(x).readline))
    >>> tokenize("abc")
    [(1, 'abc', (1, 0), (1, 3), 'abc')]
    >>> from .pytree import Leaf, Base
    >>> root = Leaf(1, 'abc', tokenize("abc")[0])
    >>> root.remove()
    """



# Generated at 2022-06-11 20:05:50.029330
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern(content=WildcardPattern(min=1))
    assert list(pattern.generate_matches([])) == [(0, {})]
    assert list(pattern.generate_matches([Symbol("abc")])) == []


# Generated at 2022-06-11 20:06:01.548169
# Unit test for method remove of class Base
def test_Base_remove():
    import sys
    import os
    import ast
    from typing import IO, List, Optional
from lib2to3.pgen2.grammar import Grammar
from lib2to3.pgen2.parse import Pattern
from lib2to3.pgen2.token import generate_tokens
from lib2to3.pgen2.tokenize import detect_encoding, tokenize_loop
from lib2to3 import pytree
from lib2to3.pygram import python_symbols as syms
from lib2to3.pygram import python_grammar, PythonGrammar
from lib2to3.pytree import Leaf
from lib2to3.fixer_base import BaseFix
from libfuturize.fixes.fix_print import FixPrint
from libfuturize.fixes.fix_str import FixStr

# Generated at 2022-06-11 20:06:08.560299
# Unit test for method clone of class Base
def test_Base_clone():

    class Node(Base):

        def __init__(self, type, children=None, prefix=""):
            if children is None:
                children = []
            self.type = type
            self.children = children
            self.prefix = prefix
            self.parent = None
            for c in self.children:
                c.parent = self

        def _eq(self, other):
            return (
                self.type == other.type and self.children == other.children
            )

        def __repr__(self):
            return "Node(%s, %r, %r)" % (type_repr(self.type), self.children, self.prefix)

        def clone(self):
            return Node(self.type, [c.clone() for c in self.children], self.prefix)


# Generated at 2022-06-11 20:06:16.855996
# Unit test for method replace of class Base
def test_Base_replace():
    class MockNode(Base):
        def __init__(self, children=None, parent=None):
            self.type = object()
            self.children = children or []
            self.parent = parent
        def _eq(self, other):
            return self is other
        def clone(self):
            return MockNode()
        def post_order(self):
            for child in self.children:
                for node in child.post_order():
                    yield node
            yield self
        def pre_order(self):
            yield self
            for child in self.children:
                for node in child.pre_order():
                    yield node

    a = MockNode()
    b = MockNode()
    a.children.append(b)
    b.parent = a

    b.replace(a)
    assert a.parent is None


# Generated at 2022-06-11 20:06:23.613777
# Unit test for method remove of class Base
def test_Base_remove():
    """Unit test for method remove of class Base"""
    src = """
# a comment
# another comment
a = 1
b = 1
c = a + b
    """.strip()
    from .pygram import python_grammar

    from .pytree import InternalError
    from .pgen2 import driver

    try:
        driver.parse_string(src, python_grammar)
    except InternalError as exc:
        print(exc)
        raise



# Generated at 2022-06-11 20:06:26.971453
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    my_node = Node(1, [Leaf(1, "1"), Leaf(1, "2")])
    assert my_node.get_lineno() == 1


# Generated at 2022-06-11 20:06:36.591362
# Unit test for method post_order of class Node
def test_Node_post_order():
    def post_order(node):
        p = []
        for n in node.post_order():
            p.append(n)
        return p
    n1 = Node(257, [Leaf(1, "foo"), Leaf(1, "bar"), Leaf(1, "baz")])
    n2 = Node(258, [Leaf(1, "fob")])
    n3 = Node(258, [Leaf(1, "boh")])
    n4 = Node(259, [n1, n2, n3])
    l1 = Leaf(1, "bif")
    l2 = Leaf(1, "bof")
    root = Node(260, [l1, l2, n4])