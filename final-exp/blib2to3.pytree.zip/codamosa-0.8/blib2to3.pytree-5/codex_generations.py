

# Generated at 2022-06-11 19:59:15.628920
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert BasePattern(257, None, None).__repr__() == 'BasePattern(257)'
    assert BasePattern(257, 'abc', 'x').__repr__() == "BasePattern(257, 'abc', 'x')"

# Unit tests for class BasePattern

# Generated at 2022-06-11 19:59:22.879374
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    a = Leaf(1, "a")
    b = Node(2, [a])
    c = Leaf(3, "c")
    d = Node(4, [b, c], lineno=5)
    e = Node(5, [d])
    assert a.get_lineno() == 5
    assert b.get_lineno() == 5
    assert c.get_lineno() == 5
    assert d.get_lineno() == 5
    assert e.get_lineno() == 5



# Generated at 2022-06-11 19:59:27.853110
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import parse as _parse

    from .pgen2 import token

    from . import driver

    tree = _parse("[1, 2, 3]", start="value")
    p = BasePattern(type=token.LSQB, name="start")
    matches = list(p.generate_matches(tree.children))
    assert matches == [(1, {"start": tree.children[0]})]



# Generated at 2022-06-11 19:59:29.694366
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    p = BasePattern()
    nodes = []
    matcher = p.generate_matches(nodes)
    assert list(matcher) == []



# Generated at 2022-06-11 19:59:37.352976
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pygram import python_grammar

    tree = Node(python_grammar.number, [Leaf(1, "1"), Leaf(2, ".")])
    tree.changed()
    tree.changed()
    tree.changed()
    tree.changed()
    assert tree.was_changed
    for n in tree.post_order():
        n.changed()



# Generated at 2022-06-11 19:59:38.666378
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    assert (
        WildcardPattern().match_seq(())
    ), "empty node matches empty WildcardPattern"



# Generated at 2022-06-11 19:59:43.950182
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.grammar as grammar_mod
    def test_helper(s, expected_suffix):
        from lib2to3.pgen2.pgen import generate_grammar
        from lib2to3.pgen2 import driver
        from lib2to3.pgen2.tokenize import detect_encoding, tokenize_lines
        from lib2to3.pgen2 import token
        from lib2to3.pgen2.convert import convert_tuple
        with StringIO(s) as f:
            encoding = detect_encoding(f.readline)[0]

# Generated at 2022-06-11 19:59:54.918796
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import grammar
    from . import token

    g = grammar.Nonterminal("test", grammar.parse("a | b | c"))
    t = token.Nonterminal("test", None, 0, 1, 10, 11, children=[])
    p = NegatedPattern(None)
    assert list(p.generate_matches([t])) == []

    p = NegatedPattern(NodePattern(g, [LeafPattern(type=token.TOKEN)]))
    assert len(list(p.generate_matches([t]))) == 1

    g2 = grammar.Nonterminal("test2", grammar.parse("d | e | a"))
    t2 = token.Nonterminal("test2", None, 0, 1, 20, 21, children=[])

# Generated at 2022-06-11 20:00:00.340556
# Unit test for method replace of class Base
def test_Base_replace():
    b=Base()
    # building an empty tree
    a=Leaf(0,None,None,None)
    a.replace(b)
    assert b.parent==a
    assert b.was_changed==True
    a=Node(0,None,None,None)
    a.replace(b)
    assert b.parent==a
    assert b.was_changed==True



# Generated at 2022-06-11 20:00:00.931443
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    pass

# Generated at 2022-06-11 20:00:31.445373
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    leaf = Leaf(1, "abc")
    node = Node(1, [leaf])
    assert node.children == [leaf]
    leaf2 = Leaf(1, "def")
    node.set_child(0, leaf2)
    assert node.children == [leaf2]
    assert leaf.parent is None
    assert leaf2.parent is node

# Generated at 2022-06-11 20:00:36.977580
# Unit test for method clone of class Base
def test_Base_clone():
    foo = Node(0, prefix='foo')
    bar = Node(1, prefix='bar')
    foo.append_child(bar)
    copy_of_foo = foo.clone()
    assert foo == copy_of_foo
    assert isinstance(copy_of_foo, Node)
    assert foo is not copy_of_foo
    assert foo.children[0] is not copy_of_foo.children[0]
    assert foo.children[0] == copy_of_foo.children[0]



# Generated at 2022-06-11 20:00:37.723804
# Unit test for method post_order of class Base
def test_Base_post_order():
    pass

# Generated at 2022-06-11 20:00:44.351444
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    a_pattern = NegatedPattern(WildcardPattern(content=[NodePattern(type=syms.list_iter)]))
    assert list(a_pattern.generate_matches([expr_context(expr_ty, 0) for expr_ty in [1,1,1,1,1]])) == [(0, {})]
    assert list(a_pattern.generate_matches([expr_context(expr_ty, 0) for expr_ty in [1,1,1,1,2]])) == []



# Generated at 2022-06-11 20:00:50.636703
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    c1 = Node(1, [])
    c2 = Node(2, [])
    c3 = Node(3, [])
    n = Node(4, [c1, c2, c3])
    assert [n, c1, c2, c3] == list(n.pre_order())
    assert [n, c1, c2, c3] == list(n.pre_order())

# Generated at 2022-06-11 20:01:02.092980
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .unparser import _results_dict
    from .pgen2 import token
    from .pgen2 import driver
    from . import util
    from . import pytree


# Generated at 2022-06-11 20:01:13.608724
# Unit test for method replace of class Base
def test_Base_replace():
    from . import pytree

    for cls in Leaf, Node:

        #  Test replace(self, new)

        def _test_replace(cls, old_prefix, new_prefix, old_type, new_type,
                          *args):
            node = cls(old_type, old_prefix, *args)
            parent = Node(new_type, new_prefix, [node])
            node.replace(cls(old_type, old_prefix, *args))
            return node, parent

        # Replace a leaf node with another leaf node
        node, parent = _test_replace(cls, "old", "new", 20, 40, 45, 46)
        assert node.parent is None
        assert parent.get_child_nodes() == [node]
        assert parent.prefix == "new"

# Generated at 2022-06-11 20:01:24.443443
# Unit test for method leaves of class Base
def test_Base_leaves():
    class Node(Base):
        def __init__(self, *children):
            self.children = list(children)
            for ch in self.children:
                ch.parent = self

        def __repr__(self):
            return "Node(%s)" % ", ".join(repr(ch) for ch in self.children)

        def post_order(self):
            for ch in self.children:
                yield from ch.post_order()
            yield self

        def pre_order(self):
            yield self
            for ch in self.children:
                yield from ch.pre_order()

        def _eq(self, other):
            return self.children == other.children

        def clone(self):
            return self.__class__(*(ch.clone() for ch in self.children))


# Generated at 2022-06-11 20:01:32.770672
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import NAME

    class TestPattern(BasePattern):
        type = NAME
        content = "foo"

    # test that the method generates correct results
    tp = TestPattern()
    for result in tp.generate_matches([Leaf(NAME, "foo")]):
        break
    else:
        raise AssertionError("Matching token was not found")
    assert result == (1, {})

    # test that it generates no results on mismatch
    tp = TestPattern()
    if list(tp.generate_matches([Leaf(NAME, "bar")])):
        raise AssertionError("Unexpected matches found")


# Generated at 2022-06-11 20:01:41.004818
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf

    t = Leaf(1, 'text', (1, 0), (1, 4))
    assert t.get_lineno() == 1

    t = Node(2, [Leaf(1, 'text', (1, 0), (1, 4)), Leaf(2, 'text2', (2, 0), (2, 5))])
    assert t.get_lineno() == 1

    t = Node(3, [t])
    assert t.get_lineno() == 1

    t = Node(3, [])
    assert t.get_lineno() is None


# Generated at 2022-06-11 20:01:58.727837
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    # Test 1: replacing full subtree
    root = Node(0, [Node(1, [Leaf(2, "foo"), Leaf(3, "bar")]), Leaf(4, "baz")])
    new = Node(5)
    node = root.children[0]
    pos = node.remove()
    assert pos == 0
    assert node.parent is None
    root.insert_child(pos, new)
    assert new.parent is root

    # Test 2: replacing partial subtree
    root = Node(0, [Node(1, [Leaf(2, "foo"), Leaf(3, "bar")]), Leaf(4, "baz")])
    new = [Leaf(5, "newfoo")]
    node = root.children[0]
    pos = node.children

# Generated at 2022-06-11 20:02:07.734750
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class Test:
        """
        Test case for BasePattern.match_seq()
        """

        class TestPattern(BasePattern):
            type = 1234

            def match_seq(self, nodes, results):
                expected_nodes = [Leaf(1234, "nodelist")]
                assert nodes == expected_nodes
                expected_results = {"results": Leaf(1234, "results")}
                assert results == expected_results
                assert self.type == 1234
                return True

        test_pattern = TestPattern()
        test_pattern.match_seq([Leaf(1234, "nodelist")], {"results": Leaf(1234, "results")})

# Generated at 2022-06-11 20:02:13.653730
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """Method generate_matches of class NegatedPattern"""
    # Setup
    s = NegatedPattern()
    nodes = []
    # Exercise
    result = s.generate_matches(nodes)
    # Verify
    assert isinstance(result, types.GeneratorType)
    assert result.__next__() == (0, {})
    # Cleanup - done automatically



# Generated at 2022-06-11 20:02:25.992507
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from .grammar import Leaf, StrippedNode

    p = WildcardPattern([[Leaf(1, "")]], min=1, max=1)
    assert isinstance(p.optimize(), Leaf)

    p = WildcardPattern([[Leaf(1, "")]], min=1, max=HUGE)
    assert isinstance(p.optimize(), WildcardPattern)
    assert p.min == 1
    assert p.max == HUGE

    p = WildcardPattern(None, min=1, max=HUGE)
    assert isinstance(p.optimize(), WildcardPattern)
    assert p.min == 1
    assert p.max == HUGE

    p = WildcardPattern(None, min=1, max=1)
    assert isinstance(p.optimize(), NodePattern)

# Generated at 2022-06-11 20:02:33.775292
# Unit test for method replace of class Base
def test_Base_replace():
    class Node(Base):
        """Node class for testing."""

    node1 = Node()
    node2 = Node()
    node3 = Node()
    node4 = Node()
    node1.children = [node2, node3, node4]
    node2.parent = node1
    node3.parent = node1
    node4.parent = node1
    node1.replace(None)
    assert node1.parent is None
    assert node1.children == []


# Generated at 2022-06-11 20:02:42.204325
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    source = 'x = 5'
    from . import tokenize
    from . import parser

    tokens = tokenize.generate_tokens(source)
    end_token = Leaf(tokenize.ENDMARKER, '', (src, [0, 0]))
    next(tokens)
    n = parser.sequence2st(tokens, end_token)
    assert n.children[0].children[1].children[1].children[0] is n.children[0].children[1].children[1].pre_order()[0]
    assert n is n.pre_order()[0]
    assert end_token is n.pre_order()[-1]

# Generated at 2022-06-11 20:02:43.834111
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
test_type_repr()



# Generated at 2022-06-11 20:02:46.633434
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # this is a simple test
    assert BasePattern().__repr__() == 'BasePattern(None, None, None)'

# Generated at 2022-06-11 20:02:52.349026
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from pprint import pprint
    from . import pytree

    class TestNode(Node):
        pass

    code = "def foo(): pass\n"
    tree = pytree.parse(code)
    for node in tree.pre_order():
        if isinstance(node, TestNode):
            print(
                "Found a test node in",
                node.type,
                pprint(node.children),
                pprint(node.parent),
                pprint(node.next_sibling),
                pprint(node.prev_sibling),
            )



# Generated at 2022-06-11 20:03:02.636563
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # (1, {'x': Leaf(NAME, 'a')})
    p = NodePattern(syms.expr, (sym.atom, "x"), LeafPattern(token.NAME, "a"))
    assert tuple(p.generate_matches([Leaf(token.NAME, "a")])) == (1, {"x": Leaf(token.NAME, "a")})
    # (1, {'x': Leaf(NAME, 'a')})
    p = LeafPattern(token.NAME, "a")
    assert tuple(p.generate_matches([Leaf(token.NAME, "a")])) == (1, {})

