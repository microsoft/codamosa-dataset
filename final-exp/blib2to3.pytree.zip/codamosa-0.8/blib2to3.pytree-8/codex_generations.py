

# Generated at 2022-06-11 19:58:32.814813
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf1 = Leaf(token.NAME, 'name', (), ' ')
    assert list(leaf1.leaves())==[leaf1]

# Generated at 2022-06-11 19:58:43.807751
# Unit test for method leaves of class Base
def test_Base_leaves():
    test = Node(syms.fob, [])
    assert list(test.leaves()) == []
    test = Node(syms.fob, [Node(syms.oar, []), Node(syms.baz, [])])
    assert list(test.leaves()) == []
    test = Node(syms.fob, [Node(syms.oar, [Leaf(1, "oar")]), Node(syms.baz, [])])
    assert list(test.leaves()) == [Leaf(1, "oar")]
    test = Node(1, [])
    assert list(test.leaves()) == []
    test = Leaf(1, "baz")
    assert list(test.leaves()) == [test]



# Generated at 2022-06-11 19:58:47.684343
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(0, "")
    it = l.post_order()
    assert next(it) is l
    try:
        next(it)
    except StopIteration:
        pass
    else:
        assert False, "__next__ should raise StopIteration"


# Generated at 2022-06-11 19:58:56.645198
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    p = BasePattern()
    p.type = 1
    for i in range(5):
        assert list(p.generate_matches([Leaf(1, "")])) == [(1, {})]
    for i in range(5):
        assert list(p.generate_matches([Leaf(2, "")])) == []
    p.generate_matches([Leaf(1, ""), Leaf(1, "")])



# Generated at 2022-06-11 19:58:59.978631
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf as L  # needed for mypy
    lineno = 5  # Dummy value
    context = (
        "<teststring>",
        (lineno, 1),
    )
    tree = Node(1, [L(1, 'foo', context), L(1, 'bar', context)])
    assert tree.get_lineno() == lineno



# Generated at 2022-06-11 19:59:08.912740
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import textwrap
    from lib2to3.tests.data import Grammar
    from lib2to3.pgen2 import driver

    gr = Grammar("""
    single: 'a'
    """)
    d = driver.Driver(gr, convert=convert)
    pattern = NodePattern(gr, "single", name="foo")
    pattern = pattern.optimize()
    data = """a
    """
    results = []
    for tok in d.tokenize(textwrap.dedent(data)):
        results.append(tok)
    assert pattern.match_seq(results)
    results = []
    for tok in d.tokenize(textwrap.dedent(data + "a")):
        results.append(tok)
    assert not pattern.match_seq(results)



# Generated at 2022-06-11 19:59:17.858407
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import copy
    import inspect
    import pickle
    from .pygram import python_symbols
    from .pytree import Leaf, Node

    class MagicMockNL(Node):
        def __init__(self, type, children):
            self.children = children
            self.fixers_applied = None
            self.parent = None
            self.prev_sibling_map = None
            self.type = type
            self.used_names = None
            self.was_changed = False
            self.was_checked = False
            self.next_sibling_map = None
        def __eq__(self, other):
            return self.children == other.children
        def __ne__(self, other):
            return self.children != other.children

# Generated at 2022-06-11 19:59:23.835275
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2 import token

    # Just make sure the implementation is actually used
    class TestPattern(BasePattern):
        def optimize(self):
            return self

        def _submatch(self, node, results):
            return True

    p = TestPattern(token.NUMBER, "42")
    assert p.optimize() is p
    p = TestPattern(token.NUMBER)
    assert p.optimize() is p



# Generated at 2022-06-11 19:59:37.274089
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Node, Leaf

    n = Node(
        5,
        [
            Leaf(3, "hello"),
            Node(6, [Leaf(4, " "), Leaf(3, "world")]),
            Leaf(3, "\n"),
        ],
    )

    # test all preorder traversals are equal, using different constructors

# Generated at 2022-06-11 19:59:43.207093
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import unittest
    import blib2to3.pgen2 as pgen2
    import blib2to3.pgen2.token as token

    class MockNode(Base):
        def __init__(self, type, value, lineno):
            self.type = type
            self.value = value
            self.lineno = lineno

        def _eq(self, other):
            return (self.type == other.type and
                    self.value == other.value and
                    self.lineno == other.lineno)

        def clone(self):
            return MockNode(self.type, self.value, self.lineno)

    def _make_leaves(*values):
        return [MockNode(0, v, i) for i, v in enumerate(values)]


# Generated at 2022-06-11 20:01:07.094023
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from . import token
    from .pgen2 import driver
    from .pgen2.parse import ParseError

    def _test(patterns: Union[BasePattern, Dict[Text, BasePattern]]) -> None:
        """Unit test function for method generate_matches."""
        _patterns: Dict[Text, BasePattern] = {}
        _patterns["1"] = NodePattern(token.STRING, "toto")
        _patterns["2"] = NodePattern(token.STRING, "toto", "foo")
        _patterns["3"] = NodePattern(token.STRING, "toto")
        _patterns["4"] = NodePattern(token.STRING, "toto", "foo")
        _patterns["5"] = UnaryConcatPattern("1", "2")

# Generated at 2022-06-11 20:01:18.946208
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node, Base

    b = Base()
    try:
        b.clone()
    except NotImplementedError:
        pass
    else:
        raise Exception("clone() should have raised NotImplementedError")
    l = Leaf("test", 1)
    b = l.clone()
    assert isinstance(b, Leaf)
    assert b == l
    b.prefix = "foo"
    assert b != l
    b = l.clone()
    assert b == l
    assert b.next_sibling is None
    n = Node("test", [l])
    b = n.clone()
    assert isinstance(b, Node)
    assert b == n
    b.prefix = "foo"
    assert b != n



# Generated at 2022-06-11 20:01:26.726632
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from . import pytree
    from .pygram import python_symbols
    from .pygram import python_grammar


    parse_tuple = ((python_symbols.suite, 0, None, ((python_symbols.stmt, 0, None, ((python_symbols.small_stmt, 0, None, ((python_symbols.flow_stmt, 0, None, ((python_symbols.return_stmt, 0, None, ()),)),),)),)),),)
    stack = [pytree.Node(-1, '', [], parse_tuple)]
    next_id = [1]
    result = pytree.GlobalChoice.pre_order(stack, next_id, python_symbols.file_input, python_grammar)


# Generated at 2022-06-11 20:01:39.274742
# Unit test for function generate_matches
def test_generate_matches():
    node1 = nltk.tree.Tree.fromstring('(A (B b) (C c))')
    node2 = nltk.tree.Tree.fromstring('(A (B b) (D d))')
    node3 = nltk.tree.Tree.fromstring('(A)')
    matches = [(c, sorted(r.items())) for c, r in generate_matches(
        [NodePattern(type=287), NodePattern(type=288)],
        [node1, node2, node3]
    )]


# Generated at 2022-06-11 20:01:50.782781
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import StringIO
    # HACK: reroute stderr to capture recursion limit error messages
    orig_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    results = list(WildcardPattern().generate_matches([Leaf()]))
    sys.stderr = orig_stderr
    assert results == [(1, {})], results
    results = list(
        WildcardPattern(min=2).generate_matches(
            [Leaf(), Leaf()]
        )
    )
    assert results == [(2, {})], results
    results = list(
        WildcardPattern(min=3).generate_matches(
            [Leaf(), Leaf()]
        )
    )
    assert results == [], results
    l1 = Leaf()
    l

# Generated at 2022-06-11 20:01:53.114875
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert next(Leaf(token.NAME, "foo").leaves()) == Leaf(token.NAME, "foo")



# Generated at 2022-06-11 20:02:04.672055
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert repr(LeafPattern(4)) == "LeafPattern(NUMBER)"
    assert repr(LeafPattern(4, "42")) == "LeafPattern(NUMBER, '42')"
    assert repr(LeafPattern(4, "42", "@n")) == "LeafPattern(NUMBER, '42', '@n')"

    import sys
    import builtins

    class _NodePattern(NodePattern):
        _fields = []

    # Check _NodePattern.__repr__ under Python 2 and Python 3
    if sys.version_info[0] == 2:
        assert isinstance(_NodePattern(), builtins.object)  # type: ignore
    else:
        assert isinstance(_NodePattern(), object)


# Generated at 2022-06-11 20:02:10.556101
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.tokenize import tokenize
    from .pgen2.parse import parse
    from io import BytesIO

    s = b'print "hello, world"'
    out = BytesIO()
    tokenize(BytesIO(s).readline, out.write)
    parse(out.getvalue())

# Generated at 2022-06-11 20:02:23.697337
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import inspect
    import types
    import unittest
    import auto_ast
    import ast
    import astunparse

    # Gets this function's name, then goes up one level
    # to get the class Test_Leaf
    class_name = inspect.stack()[0][3]
    if class_name.startswith("test_"):
        class_name = class_name[5:]
    clsmembers = inspect.getmembers(sys.modules[__name__], inspect.isclass)
    for name, cls_ in clsmembers:
        if name.endswith("_" + class_name):
            class_ = cls_
            break
    else:
        raise AssertionError("Could not find class for unit test")
    del class_name


# Generated at 2022-06-11 20:02:25.668405
# Unit test for method post_order of class Base
def test_Base_post_order():
    assert(1)
    # TODO: skeleton
    # assert(False)


# Generated at 2022-06-11 20:02:44.503656
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
  result = list(NegatedPattern().generate_matches('asdf'))
  assert len(result) == 1, result
  result = list(NegatedPattern().generate_matches(''))
  assert len(result) == 1, result
  pattern = NodePattern(content=[LeafPattern(type=token.NAME, content='asdf')])
  result = list(NegatedPattern(content=pattern).generate_matches('asdf'))
  assert len(result) == 0, result
  result = list(NegatedPattern(content=pattern).generate_matches('bsdf'))
  assert len(result) == 1, result
  result = list(NegatedPattern(content=pattern).generate_matches(''))
  assert len(result) == 1, result



# Generated at 2022-06-11 20:02:49.959149
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    l = Leaf(1, "l")
    r = Leaf(1, "r")
    n = Node(1, [l, r])
    l.prefix = ' '
    r.prefix = ' '
    assert l.get_suffix() == ' '
    assert r.get_suffix() == ''
    assert n.get_suffix() == ''
test_Base_get_suffix()


# Generated at 2022-06-11 20:02:50.597534
# Unit test for method get_suffix of class Base

# Generated at 2022-06-11 20:02:56.539362
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    assert Base().get_suffix() == ""
    class Node(Base):
        def __init__(self):
            self.children = [Base()]
    assert Node().get_suffix() == ""
    class Leaf(Base):
        def __init__(self):
            self.prefix = "abc"
    assert Leaf().get_suffix() == "abc"
test_Base_get_suffix()


# Generated at 2022-06-11 20:02:59.564905
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    a = Leaf(1, "a")
    assert a.pre_order() is a
test_Leaf_pre_order()

# Generated at 2022-06-11 20:03:10.701230
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.pgen import BasePattern

    p1 = BasePattern(4)
    p2 = BasePattern(4)
    assert p1.match_seq([_Leaf(4, 'pass', None, None)])
    assert not p1.match_seq([])
    assert p1.match_seq([_Leaf(4, 'pass', None, None)], {})
    assert not p1.match_seq([_Leaf(4, 'pass', None, None)], None)
    assert not p1.match_seq([_Leaf(4, 'pass', None, None)], {})
    assert not p1.match_seq([_Leaf(5, 'pass', None, None)])

# Generated at 2022-06-11 20:03:13.487140
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(1) == 1


# A simple tree data structure, using a simple data structure


# Generated at 2022-06-11 20:03:23.926580
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    print('Test WildcardPattern_optimize')
    assert WildcardPattern().optimize() == NodePattern()
    assert WildcardPattern(name='abc').optimize() == NodePattern(name='abc')
    # Can't test: assert WildcardPattern(content=[[LeafPattern(name='abc')]]).optimize() == NodePattern(name='abc')
    assert WildcardPattern(min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(min=1, max=1, name='abc').optimize() == NodePattern(name='abc')
    assert WildcardPattern(min=2, max=2).optimize() == WildcardPattern(min=2, max=2)

# Generated at 2022-06-11 20:03:35.035218
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    """
    Get the line number which generated the invocant node.
    """
    # Test case 1: Parent has no children
    # Expected result: -1
    node = Base()
    node.children = []
    assert(node.get_lineno() is None)
    # Test case 2: Parent has a leaf child
    # Expected result: 1
    child = Leaf(1, "Test")
    child.lineno = 1
    node.children = [child]
    assert(node.get_lineno() == 1)
    # Test case 3: Parent has a non-leaf child with a leaf grandchild
    # Expected result: 1
    grandchild = Leaf(1, "Test")
    grandchild.lineno = 1
    node.children = [node, grandchild]

# Generated at 2022-06-11 20:03:40.738856
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    simple_node = Leaf(1, "simple node")
    pattern = WildcardPattern()
    assert pattern.match_seq([simple_node])
    assert not pattern.match_seq([])
    pattern = WildcardPattern(name="foo")
    assert pattern.match_seq([simple_node])
    assert not pattern.match_seq([])

    node1 = Leaf(1, "simple node 1")
    node2 = Leaf(1, "simple node 2")
    pattern = WildcardPattern(name="foo")
    assert pattern.match_seq([node1, node2])

    pattern = WildcardPattern(name="foo", min=1)
    assert not pattern.match_seq([])
    assert pattern.match_seq([node1])
    assert pattern.match_seq([node1, node2])


# Generated at 2022-06-11 20:04:05.507954
# Unit test for method post_order of class Base
def test_Base_post_order():
    import pytest
    from .pytree import Node
    from .python_tree import PythonLeaf, PythonNode, stmt
    from .token import Token
    from .pgen2 import token

    node = Node(1)
    node.children = [
        Token(token.NAME, "name1"),
        PythonLeaf(token.NEWLINE, "\n"),
        Token(token.NAME, "name2"),
        PythonLeaf(token.NEWLINE, "\n"),
    ]
    Expected_results = [
        Token(token.NAME, "name1"),
        PythonLeaf(token.NEWLINE, "\n"),
        Token(token.NAME, "name2"),
        PythonLeaf(token.NEWLINE, "\n"),
    ]

    def result():
        for child in node.post_order():
            yield child


# Generated at 2022-06-11 20:04:14.749808
# Unit test for method leaves of class Base
def test_Base_leaves():
    # --TEST--
    # Unit test for method leaves of class Base
    # --FILE--
    import unittest
    import blib2to3
    class BaseTest(unittest.TestCase):
      def setUp(self):
        pass
      def runTest(self):
        # Unit test for method leaves of class Base
        def test_base_leaves():
            node = Node(syms.mod, [Leaf(1, "a"), Node(syms.x)])
            node.children[1].children.append(Leaf(1, "b"))
            assert list(node.leaves()) == [Leaf(1, "a"), Leaf(1, "b")]
    if __name__ == '__main__':
      unittest.main()
    # --CLEAN--
    # Any other files

# Generated at 2022-06-11 20:04:18.000176
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp = WildcardPattern(max=1, content=tuple([(tuple([]))]), name=tuple(['']))
    wp.optimize() == NodePattern(name=tuple(['']))


# Generate matches to a sequence of patterns

# Generated at 2022-06-11 20:04:25.484349
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(1, [Leaf(1, "block", (1, 0)), Leaf(1, "block", (1, 5))])
    test_node = node.children[1]
    new_node = Leaf(2, "123", (2, 0))
    node.set_child(1, new_node)
    assert node.children[1] == new_node
    assert test_node.parent is None


# Generated at 2022-06-11 20:04:35.072437
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import (
        Leaf,
        Node,
        NodeType,
        PythonLeaf,
        PythonNode,
        PythonInternalNode,
        PythonInternalLeaf,
    )
    # Test 1: Leaf.clone
    test_tt = PythonLeaf(3, "dummy")
    test_tt.clone()
    test_tt.clone_all()
    stmt = PythonLeaf.make_token(3, "dummy")
    stmt.clone()
    stmt.clone_all()
    stmt = PythonLeaf(3, "dummy", (1, 2))
    stmt.clone()
    stmt.clone_all()
    # Test 2: Node.clone
    leaf = Leaf(4, "dummy")
    leaf.clone()
    leaf.clone_all()
    leaf

# Generated at 2022-06-11 20:04:39.958673
# Unit test for method depth of class Base
def test_Base_depth():
    node = Leaf(1, "a")
    assert node.depth() == 0
    node = Node(2, "b", parent = node)
    assert node.depth() == 1
    node = Node(3, "c", parent = node)
    assert node.depth() == 2



# Generated at 2022-06-11 20:04:51.024226
# Unit test for method optimize of class WildcardPattern

# Generated at 2022-06-11 20:05:01.623367
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.single_input) == "single_input"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.NUMBER + python_symbols.STRING) == (
        python_symbols.NUMBER + python_symbols.STRING
    )


# The type of names for nonterminals, tokens, etc.
name = str

# The type of an optional regular expression match object
_match = Optional[Any]

# The type of a pattern.
# It's important that an instance of this type is not a boolean,
# even if the underlying pattern is a nonterminal.
pattern = Any

# The type of the argument passed to a pattern (semantic) action.
sem_action

# Generated at 2022-06-11 20:05:06.607864
# Unit test for method leaves of class Base
def test_Base_leaves():
    assert list(Node(foo=[Leaf(1, ""), Leaf(2, "")], type=1).leaves()) == [Leaf(1, ""), Leaf(2, "")]  # noqa: E501
    assert list(Leaf(1, "").leaves()) == [Leaf(1, "")]



# Generated at 2022-06-11 20:05:17.670725
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_grammar

    child = Leaf(10, "abc")
    parent = Leaf(11, "abc", [child])
    grandparent = Leaf(12, "abc", [parent])
    grgrpr = Leaf(13, "abc", [grandparent])
    assert child.get_lineno() == 13
    assert parent.get_lineno() == 13
    assert grandparent.get_lineno() == 13
    assert grgrpr.get_lineno() == 13
    assert Leaf(10, "abc").get_lineno() is None
    assert Leaf(10, "abc", lineno=99).get_lineno() == 99
    assert Leaf(10, "abc", lineno=99).get_lineno() == 99


# Generated at 2022-06-11 20:05:39.026468
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import driver, token

    sample = "1"
    node = driver.parse_string(sample, "expr_stmt")
    assert isinstance(node, Node)
    assert node.type == syms.expr_stmt
    r = {}
    assert node.match(node, r)
    assert r is not None
    assert r.keys() == {None}
    assert r[None] == node
    assert not node.match(node, None)
    assert not node.match(None, None)
    assert not node.match(None, r)
    assert r == {None: node}
    assert node.match(node, r)
    assert r == {None: node}
    leaf = node.children[0]
    assert isinstance(leaf, Leaf)
    assert leaf.type == token.NUM

# Generated at 2022-06-11 20:05:40.909529
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    try:
        b = Base()
    except Exception:
        pass
    else:
        raise Exception


# Generated at 2022-06-11 20:05:53.368882
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # Bare_name special case
    a = Leaf(token.NAME, "a")
    b = Leaf(token.NAME, "b")
    c = Leaf(token.NAME, "c")
    d = Leaf(token.NAME, "d")
    ab = Node(syms.simple_stmt, [a, b])
    cb = Node(syms.simple_stmt, [c, b])
    cd = Node(syms.simple_stmt, [c, d])
    abcb = Node(syms.file_input, [ab, cb])
    assert WildcardPattern(None, 1, 1, "bare_name").generate_matches([a, b]) == [(2, {"bare_name": [a, b]})]
    assert WildcardPattern(None, 1, 1, "bare_name").gener

# Generated at 2022-06-11 20:05:56.581125
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import unittest
    import sys

    class TestCase(unittest.TestCase):
        def test_method_pre_order(self):
            self.assertEqual(
                Base().pre_order,
                NotImplemented,
                msg="pre_order not implemented in Base")
    my_test_object = TestCase()
    my_test_object.test_method_pre_order()



# Generated at 2022-06-11 20:06:05.689955
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from .pytree import Leaf
    leaf = Leaf(1, "hello")
    node = Node(syms.testlist, [Leaf(token.NAME, "hello")])
    assert leaf.get_suffix() == ""
    assert node.get_suffix() == ""
    leaf.next_sibling = Leaf(2, "hello")
    assert leaf.get_suffix() == "hello"
    assert node.get_suffix() == ""
    node.next_sibling = Leaf(2, "hello")
    assert node.get_suffix() == "hello"
    node.next_sibling = None
    assert node.get_suffix() == ""



# Generated at 2022-06-11 20:06:15.888906
# Unit test for method replace of class Base
def test_Base_replace():
    class TestNode(Node):

        def _eq(self, other):
            return True

        def clone(self):
            return TestNode(self.children, prefix="")

        def post_order(self):
            yield from self.children

        def pre_order(self):
            yield from self.children

    class Test:

        def test_replace(self):
            node = TestNode([])
            node.parent = TestNode([])
            node.parent.children = [node]
            node.replace([])
            assert node.parent is None
            assert node.parent.children == []

        def test_replace_with_multiple(self):
            node = TestNode([])
            node.parent = TestNode([])
            node.parent.children = [node]
            node.replace([TestNode([]), TestNode([])])

# Generated at 2022-06-11 20:06:28.238890
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import unittest

    class TestCase(unittest.TestCase):
        def test_not_implemented(self):
            class Foo(Base):
                pass

            foo1 = Foo()
            foo2 = Foo()
            self.assertNotEqual(foo1, foo2)

        def test_runtime_error(self):
            class Foo(Base):
                def _eq(self, other):
                    raise RuntimeError()

            foo1 = Foo()
            foo2 = Foo()
            self.assertNotEqual(foo1, foo2)

    import sys
    from os import getcwd, chdir
    root = getcwd()
    try:
        chdir('test')
        sys.path.insert(0, root)
        unittest.main()
    finally:
        chdir(root)


# Generated at 2022-06-11 20:06:32.802542
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf

    tree = Node(1, children=[Leaf(1, value="foo"), Leaf(1, value="bar")])
    assert list(tree.leaves()) == [Leaf(1, value="foo"), Leaf(1, value="bar")]



# Generated at 2022-06-11 20:06:36.558181
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pat = '- "a"'
    pat = parse(pat)
    print(pat.generate_matches(['a'])) #Expected: nothing
    print(pat.generate_matches([])) #Expected: [(0), ({})]
