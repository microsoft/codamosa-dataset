

# Generated at 2022-06-11 19:58:21.497388
# Unit test for method remove of class Base
def test_Base_remove():
    q = Node(1, [Leaf(1, "1"), Leaf(2, "2"), Leaf(3, "3")])
    assert q.remove() == 0
    assert q.children == [Leaf(2, "2"), Leaf(3, "3")]

    assert q[1].remove() == 1
    assert q.children == [Leaf(2, "2")]

    assert q[0].remove() == 0
    assert q.children == []

    # Test a node with no parent
    assert Leaf(4, "4").remove() is None

    # Test a node with a parent whose children is a tuple, which does not
    # support `del`
    z = Node(1, (Leaf(1, "1"), Leaf(2, "2"), Leaf(3, "3")))
    assert z[1].remove

# Generated at 2022-06-11 19:58:33.918808
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    class MyNode(Node):

        def __init__(self, type, value, children, parent=None):
            Node.__init__(self, type, children, parent=parent)
            self.value = value

    class MyPattern(BasePattern):

        def __init__(self, type, content, name=None):
            BasePattern.__init__(self, type, content, name)

        def _submatch(self, node, results=None):
            if results is not None and self.name:
                results[self.name] = node.value
            return node.value == self.content

    p = MyPattern(1, "test")
    assert p.match(MyNode(1, "test", []))
    assert not p.match(MyNode(1, "blah", []))

# Generated at 2022-06-11 19:58:44.263801
# Unit test for method remove of class Base
def test_Base_remove():

    def t(s, before, after, removed_pos=None, removed_node=None):
        """Helper function for test."""
        tree = compile(s, "", "exec", _ast.PyCF_ONLY_AST)
        before(tree)
        if removed_node is None:
            removed_node = tree.body[removed_pos]
        pos = removed_node.remove()
        assert pos == removed_pos
        print(
            "After removal of %r: %s" % (removed_node, ast.dump(tree, "exec")),
            file=sys.stderr,
        )
        after(tree)
        assert not list(removed_node.post_order())


# Generated at 2022-06-11 19:58:57.384309
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from .pygram import python_symbols as syms

    class Foo(NodePattern):
        def __init__(self):
            super().__init__(
                type=syms.power,
                content=(
                    (NodePattern(type=syms.NAME, name="x"),),
                    (NodePattern(type=syms.NAME, name="y"),),
                ),
            )

    p = NegatedPattern(Foo())
    assert list(p.generate_matches([Node(type=syms.power, children=(Node(type=syms.NAME),))])) == [(0, {})]
    assert list(p.generate_matches([Node(type=syms.power, children=(Node(type=syms.NAME, value="x"),))])) == []

# Generated at 2022-06-11 19:59:07.686571
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():

    # Exact match for single node
    n = Node(type=1, children=[])
    assert list(BasePattern(type=1).generate_matches([n])) == [(1, {})]
    assert not list(BasePattern(type=2).generate_matches([n]))

    # Matching a named pattern doesn't clear the name
    p = BasePattern(type=1, name='x')
    assert list(p.generate_matches([n])) == [(1, {'x': n})]

    # Default implementation for non-wildcard patterns
    n = Node(type=1, children=[])
    n2 = Node(type=2, children=[])
    assert list(BasePattern(type=1).generate_matches([n])) == [(1, {})]

# Generated at 2022-06-11 19:59:16.262347
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf

    leaf = Leaf(0, "some text...", (1,0))
    assert leaf._get_lineno() == leaf.lineno

    leaf = Leaf(0, "some text...", (-1,-1))
    assert leaf._get_lineno() is None

    leaf = Leaf(0, "some text...")
    assert leaf._get_lineno() is None

    node = Node(0, "some text...", [leaf], (-1,-1))
    assert node._get_lineno() == leaf.lineno

    node = Node(0, "some text...", [node], (-1,-1))
    assert node._get_lineno() == leaf.lineno



# Generated at 2022-06-11 19:59:22.359038
# Unit test for method leaves of class Base
def test_Base_leaves():
    import lib2to3.tests.data.expect_futurize
    import lib2to3.pgen2.parse
    grammar = lib2to3.pgen2.parse.load_grammar()
    tree = lib2to3.pgen2.parse.parse_string(lib2to3.tests.data.expect_futurize.input_str,grammar)
    tree.leaves()

# Generated at 2022-06-11 19:59:24.012181
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert Leaf(1, 'value').pre_order() == Leaf(1, 'value')

# Generated at 2022-06-11 19:59:37.346594
# Unit test for method replace of class Base
def test_Base_replace():
    from typing import List
    # Node n1 is the parent of n2 and n3.
    n1 = Node(syms.simple_stmt, [Leaf(token.NAME, "a"), Leaf(token.NEWLINE, "\n")])
    n1.changed()
    n2 = Node(syms.expr_stmt, [Leaf(token.NAME, "b")])
    n3 = Node(syms.expr_stmt, [Leaf(token.NAME, "c")])
    n1.insert_child(1, n2)
    n1.insert_child(2, n3)

    # Replace n2 with n4 and n5.
    n4 = Node(syms.expr_stmt, [Leaf(token.NAME, "d")])

# Generated at 2022-06-11 19:59:40.156804
# Unit test for method leaves of class Base
def test_Base_leaves():
    l = Leaf(1, "test")
    n = Node(2, [l])
    it = n.leaves()
    assert it.__next__() is l
    try:
        it.__next__()
    except StopIteration:
        pass
    else:
        assert False



# Generated at 2022-06-11 20:00:01.881003
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf

    l = Leaf(1, "text", (1, 4))
    l.clone()


# Generated at 2022-06-11 20:00:08.043557
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pygram import python_grammar

    from .pgen2 import driver  # noqa: F401
    from blib2to3.pgen2.tokenize import generate_tokens  # noqa: F401
    from blib2to3.pgen2 import token  # noqa: F401
    p = driver.Driver(python_grammar, convert=convert_leaf)

# Generated at 2022-06-11 20:00:14.458389
# Unit test for method depth of class Base
def test_Base_depth():
    # create a simple tree
    import lib2to3.pgen2.token as token
    num1 = Leaf(token.NUMBER, "123")
    num2 = Leaf(token.NUMBER, "456")
    op = Leaf(token.PLUS, "+")
    num1.parent = num2.parent = op
    op.parent = None
    assert op.depth() == 0
    tree1 = Node(
        token.plus, [num1, op, num2]
    )  # noqa: W999: no space after '('
    assert tree1.depth() == 1
    tree2 = Node(token.multiply, [tree1, op, num1])
    assert tree2.depth() == 2

# Generated at 2022-06-11 20:00:20.898223
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    def test_func():
        import textwrap

        try:
            from StringIO import StringIO
            from tokenize import generate_tokens
        except ImportError:
            from io import StringIO
            from tokenize import tokenize as generate_tokens

        try:
            from ast import parse
        except ImportError:
            # noinspection PyUnresolvedReferences
            import ast
            parse = ast.parse

        # Fix me: not implemented yet.
        #  1 ast.Module(
        #  2     [ast.Expr(ast.Str('Hello, world'),),])
        #  3
        #  4 ast.Module(
        #  5     ast.Interactive(
        #  6         [ast.Expr(ast.Str('Hello, world'),),]))
        #  7
        #  8 ast

# Generated at 2022-06-11 20:00:24.993966
# Unit test for method set_child of class Node
def test_Node_set_child():
    from . import pytree
    from .pgen2 import token

    a = pytree.Node(token.SOME_TOKEN, [], prefix=" ")
    b = pytree.Node(token.SOME_TOKEN, [], prefix=" ")
    a.set_child(0, b)
    return a



# Generated at 2022-06-11 20:00:28.358018
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols
    leaf = Leaf(python_symbols.test, "test", (4, 0))
    assert leaf.get_lineno() == 4
    node = Node(python_symbols.test, [leaf])
    assert node.get_lineno() == 4



# Generated at 2022-06-11 20:00:32.469872
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Setup
    arg0 = BasePattern(type=1, content=None, name=None)
    nodes = [Leaf(1, 'value1')]
    expected = True
    # Exercise
    actual = arg0.match_seq(nodes)
    # Verify
    assert actual == expected, actual


# Generated at 2022-06-11 20:00:36.382148
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    node = Node(1, [Leaf(1, "foo")])
    assert node.get_lineno() == 1
    node.append_child(Leaf(2, "bar"))
    assert node.get_lineno() == 1

    node = Node(1, [Leaf(1, "foo"), Node(1, [Leaf(1, "bar")])])
    assert node.get_lineno() == 1
    node.children[1].prepend_child(Leaf(2, "baz"))
    assert node.get_lineno() == 2


# Generated at 2022-06-11 20:00:46.207747
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    if __name__ == "__main__":
        from .nodes import Node, Leaf

        def do_test(p, nodes, result=True):
            p = WildcardPattern(p)
            nodes = [Leaf(1, n) for n in nodes]

            if p.match_seq(nodes) != result:
                print("Pattern did not match:")
                print(p)
                print(nodes)
            else:
                print("Pattern matched (as expected):")
                print(p)
                print(nodes)

        do_test(
            "ab*cd",
            ["a", "b", "c", "d"],
        )  # null loop
        do_test(
            "ab*cd", ["a", "b", "b", "c", "d"]
        )  # loop
       

# Generated at 2022-06-11 20:00:51.265359
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    l=Leaf(1," ",(1,0))
    n1=Node(1,[l])
    n2=Node(1,[l])
    n3=Node(1,[l])
    n4=Node(1,[n1,n2,n3])
    assert n4.get_lineno()==1



# Generated at 2022-06-11 20:03:05.268008
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert repr(LeafPattern(42)) == "LeafPattern(42, None, None)"
    assert repr(LeafPattern(42, "x")) == "LeafPattern(42, 'x', None)"
    assert repr(LeafPattern(42, "x", "foo")) == "LeafPattern(42, 'x', 'foo')"
    assert (
        repr(LeafPattern(42, "x", "foo", bar=42))
        == "LeafPattern(42, 'x', 'foo', bar=42)"
    )

# Generated at 2022-06-11 20:03:13.798694
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    # Doesn't actually run any test, but type checks the code
    def run_generate_matches_test(pattern, nodes, expected):
        gen = pattern.generate_matches(nodes)
        result = list(gen)
        assert result == expected

    bp = BasePattern()
    try:
        bp.generate_matches([])
    except NotImplementedError:
        pass
    else:
        raise AssertionError("base pattern match didn't fail")

    run_generate_matches_test(LeafPattern(token.NAME), [Leaf(token.NAME, "xyzzy")], [1])
    run_generate_matches_test(LeafPattern(token.NAME, "xyzzy"), [Leaf(token.NAME, "xyzzy")], [1])
    run_generate

# Generated at 2022-06-11 20:03:24.039116
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    import sys

    def test_main():
        if sys.argv[1:]:
            file = sys.argv[1]
        else:
            file = "Grammar.txt"
        f = open(file)

# Generated at 2022-06-11 20:03:35.086290
# Unit test for method leaves of class Base

# Generated at 2022-06-11 20:03:40.779139
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    """Unit test for method optimize of class WildcardPattern."""
    w = WildcardPattern([[NodePattern(258), LeafPattern(token.NAME, "name")]])
    w2 = w.optimize()
    assert isinstance(w2, WildcardPattern)
    assert w is not w2
    assert w2.min == 1
    assert w2.max == 1
    assert w2.content == ((NodePattern(258), LeafPattern(token.NAME, "name")),)

    w = WildcardPattern(
        [[NodePattern(258), LeafPattern(token.NAME, "name")]], name="bare_name"
    )
    w2 = w.optimize()
    assert isinstance(w2, WildcardPattern)
    assert w is w2


# Generated at 2022-06-11 20:03:43.421023
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    t = Leaf(1, "Hey")
    assert [leaf for leaf in t.leaves()] == [t]



# Generated at 2022-06-11 20:03:47.843055
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    source = "x"
    tokens = lexer.tokenize(source)
    tree = parser.parse(tokens)
    list_leaves = tree.leaves()
    assert str(list_leaves[0]) == source



# Generated at 2022-06-11 20:03:49.838193
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(0, "123")
    assert list(l.pre_order()) == [l]



# Generated at 2022-06-11 20:03:52.361654
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(0, "")
    if not [leaf for leaf in l.post_order()] == [l]:
        raise AssertionError

# Generated at 2022-06-11 20:04:00.572695
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node

    node = Node(1, [Leaf(1, 'a'), Leaf(1, 'b')])
    node.set_child(1, Leaf(1, 'x'))
    assert str(node.children[0]) == 'a'
    assert str(node.children[1]) == 'x'
    assert node.children[1].parent is node


# Generated at 2022-06-11 20:05:21.408285
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import sys
    import collections
    import pytree
    # XXX: This test is explicitly not part of the PyPy test suite.
    # On PyPy it hangs forever.
    if len(sys.argv) <= 1:
        return 0 # no arguments
    fn = sys.argv[1]
    f = open(fn, "rb")
    f.seek(0, 2)
    sz = f.tell()
    f.seek(0, 0)
    s = f.read(sz)
    f.close()
    g = pytree.grammar
    tr = g.parse(s)
    print(tr)
    if tr.type != pytree.syms.encoding_decl:
        return 0
    assert tr.type == pytree.syms.encoding_decl

# Generated at 2022-06-11 20:05:32.483180
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    wilds = WildcardPattern([])
    # tests the empty pattern
    assert wilds.match_seq([])
    wilds = WildcardPattern([[]])
    # tests the empty alternative
    assert wilds.match_seq([])
    wilds = WildcardPattern([[Leaf(token.NAME, "foo")]])
    assert wilds.match_seq([Leaf(token.NAME, "foo")])
    assert not wilds.match_seq([Leaf(token.NAME, "bar")])
    wilds = WildcardPattern([[Leaf(token.NAME, "foo")]])
    assert wilds.match_seq([Leaf(token.NAME, "foo")])
    assert not wilds.match_seq([Leaf(token.NAME, "bar")])

# Generated at 2022-06-11 20:05:38.096601
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # Base_pre_order = Base.pre_order
    def Base_pre_order(self):
        yield self
        for child in self.children:
            yield from child.pre_order()

    Base.pre_order = Base_pre_order
    node = Node(type=None, children=[Node(type=None, children=[])])
    for x in node.pre_order():
        pass
    assert x is node
    assert x.children[0] is node.children[0]



# Generated at 2022-06-11 20:05:42.813107
# Unit test for method post_order of class Base
def test_Base_post_order():
    leaf = Leaf(None, None, None)
    assert leaf.post_order() == [leaf]
    node = Node(syms.funcdef, [leaf])
    assert node.post_order() == [leaf, node]
    node.replace(leaf)
    assert leaf.post_order() == [leaf, node]


# Generated at 2022-06-11 20:05:51.697473
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pgen2.tokenize import tokenize

    def token_list(source: Text) -> List[Any]:
        return list(tokenize(BytesIO(source.encode("utf-8")).readline))

    def equal_leaves(source: Text, expected: Text) -> None:
        assert "".join(leaf.value for leaf in token_list(source)) == expected

    equal_leaves("'string'", "'string'")
    equal_leaves("1+2", "1+2")

# Generated at 2022-06-11 20:05:54.016875
# Unit test for method depth of class Base
def test_Base_depth():
    try:
        Base().depth()
    except:
        return 0
    return 1

# Unit test method

# Generated at 2022-06-11 20:06:04.412680
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    nodes = [
        Leaf(1, 'a', prefix='\n', lineno=0, column=0),
        Leaf(1, 'b', prefix=' ', lineno=0, column=0),
        Leaf(1, 'c', prefix=' ', lineno=0, column=0),
        Leaf(1, 'd', prefix='\n', lineno=1, column=0),
    ]
    pat = BasePattern()
    pat.match_seq(nodes)
    pat.match_seq(nodes[:1])
    pat.match_seq(nodes[:2])
    pat.match_seq(nodes[:3])
    pat.match_seq(nodes[:4])
    pat.match_seq([])
    pat.match_seq(nodes[1:])
    pat.match_seq

# Generated at 2022-06-11 20:06:09.902512
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    # Called with wrong argument types
    # Called with incorrect number of arguments
    # Called without arguments
    # Called with argument types: (List[object])
    import pgen2.grammar
    import pgen2.pgen
    gr = pgen2.pgen.driver.load_grammar(pgen2.grammar.python_grammar_no_print_statement)
    x = gr.symbol2number["file_input"]
    assert isinstance(gr.symbol2number, dict)
    assert isinstance(gr.symbol2label, dict)
    assert set(gr.symbol2label) == set(gr.symbol2number)
    assert isinstance(gr.symbol2label[x], str)
    assert 0 in gr.symbol2number.values()
    assert isinstance(x, int)
   

# Generated at 2022-06-11 20:06:17.437860
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.grammar import _add_type_names

    _add_type_names("""
    stmt: simple_stmt
      | compound_stmt
    """)

    class TestPattern(BasePattern):
        def __init__(self, type: int, name: Text) -> None:
            self.type = type
            self.name = name

    pattern = TestPattern(syms.simple_stmt, "sm")
    pattern_list = TestPattern(syms.stmt, "x")
    matches = list(pattern_list.generate_matches([pattern]))
    assert len(matches) == 1
    length, found = matches[0]
    assert length == 1
    assert found["sm"] is pattern
    assert found["x"] is pattern
    assert pattern_list.generate_mat

# Generated at 2022-06-11 20:06:19.449721
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    test = Leaf(1, "test")
    assert list(test.leaves()) == [test]

