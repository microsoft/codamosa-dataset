

# Generated at 2022-06-11 19:58:59.863103
# Unit test for method replace of class Base
def test_Base_replace():
    node = Node(type=1, children=[Leaf(type=2, value="foo"), Leaf(type=3, value="bar")], prefix="")
    node.children[0].parent = node
    rep = Node(type=4, children=[Leaf(type=5, value="spam"), Leaf(type=6, value="eggs")], prefix="")
    node.children[0].replace(rep)

    assert node.children[0].type == 4
    assert node.children[0].children[0].type == 5
    assert node.children[0].children[0].value == "spam"
    assert node.children[0].children[1].type == 6
    assert node.children[0].children[1].value == "eggs"

# Generated at 2022-06-11 19:59:01.598710
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    e = BasePattern()
    assert list(e.generate_matches([None])) == []



# Generated at 2022-06-11 19:59:10.521983
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_grammar
    from . import pytree
    from .pgen2 import token

    python_grammar.initialize()
    src = ""
    pytree.assert_parse(src)
    t = pytree.convert(src)
    assert isinstance(t, Leaf)
    assert t.type == token.ENDMARKER
    assert t.value == ""
    assert t.parent is None

    src = "a"
    pytree.assert_parse(src)
    t = pytree.convert(src)
    assert isinstance(t, Leaf)
    assert t.type == token.NAME
    assert t.value == "a"
    assert t.parent is None

    src = "ab"
    pytree.assert_parse(src)

# Generated at 2022-06-11 19:59:20.882198
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    # Test case for method match

    # Test case for method match_seq
    def test_BasePattern_match_seq():
        p = LeafPattern(1, "")
        assert p.match_seq([Leaf(1, "")])
        assert not p.match_seq([Leaf(1, "x")])

    # Test case for method generate_matches
    def test_BasePattern_generate_matches():
        p = LeafPattern(1, "")
        l = Leaf(1, "")
        m = list(p.generate_matches([l]))
        assert m == [(1, {"matches": l})]


# LeafPattern(type, content=None, name=None)

# Generated at 2022-06-11 19:59:29.578855
# Unit test for method clone of class Node
def test_Node_clone():
    """Method clone of class Node"""
    import random
    import copy
    import blib2to3.pgen2.pgen

    parser = blib2to3.pgen2.pgen.Driver("Python", "Grammar")
    parser.build()
    grammar = parser.grammar

    def test_node(node, grammar=grammar):
        t = copy.copy(node)
        t = t.clone()
        assert node != t, "Node %s unchanged after clone" % node
        assert t == node, (
            "Node %s not equal to original after clone" % node
        )
        assert t.parent is None, "Cloned node has a parent"
        assert t.type == node.type, "Cloned node has wrong type"

# Generated at 2022-06-11 19:59:40.640352
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pygram import python_grammar

    g = Grammar(python_grammar, "3.6")
    n = n0 = Node(g, python_grammar, "file_input", [], prefix="\n    ")
    n1 = Leaf(g, python_grammar, "COMMENT", "\n    # This is a file of Python code.\n    \n", (1, 0))
    n.children = [n1]
    n = n1
    n1 = Leaf(g, python_grammar, "NL", "\n", (2, 0))
    n.children.append(n1)
    n = n.children[0]
    n1 = Node(g, python_grammar, "stmt", [], prefix="pass\n")
    n.children.append(n1)
   

# Generated at 2022-06-11 19:59:49.089945
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    patterns = (
        LeafPattern(token.NAME, "foo", "x"),
        LeafPattern(token.NAME, "foo"),
        LeafPattern(token.NAME, None, "foo"),
        LeafPattern(token.NAME),
        LeafPattern(None, "foo", "x"),
    )
    for pattern in patterns:
        assert repr(pattern) == (
            "LeafPattern(%r, %r, %r)" % (token_repr(pattern.type), pattern.content, pattern.name)
        )


# Method _submatch of class LeafPattern

# Generated at 2022-06-11 19:59:57.368053
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    for test in 0, 1, 2, 3, 4:
        if test == 0: # basic test
            source = "class C:\n    def f(self):\n        return None"
            tree, source_code = to_tuple(source)
            expected = ['class', 'C', ':', 'def', 'f', '(', 'self', ')', ':', 'return', 'None']
            actual = []
            for x in tree.post_order():
                if type(x) == Leaf:
                    actual.append(x.value)
                else:
                    if type(x) == Node and x.children == []:
                        continue
                    actual.append(type_repr(x.type))
            assert actual == expected

# Generated at 2022-06-11 20:00:08.085513
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from . import python_grammar
    from .pgen2 import tokenize

    grammar = python_grammar.grammar
    st = python_grammar.syms
    root = Leaf(Token(25, "def", (1, 0), (1, 3), "def\n"), None)
    p1 = Node(grammar.number2symbol[st.dotted_name], [Leaf(Token(1, "1", (1, 4), (1, 5), "1\n"), root)], root)
    root.append_child(p1)

# Generated at 2022-06-11 20:00:09.629774
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import driver

    driver.parse("a_tuple = (expr,)")



# Generated at 2022-06-11 20:00:40.627218
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    """
    Test the optimization done by WildcardPattern.optimize()
    """
    # no optimization needed
    p1 = WildcardPattern([[Leaf(token.NUMBER, "123", prefix=" ")]], name="bare_name")
    assert p1.optimize() is p1

    # optimize into a simple NodePattern
    p2 = WildcardPattern([[Leaf(token.NAME, "name")]], min=1, max=1, name="name")
    assert p2.optimize() == NodePattern(type=token.NAME, name="name")

    # optimize into a stacked WildcardPattern
    p3 = WildcardPattern([[Leaf(token.NAME, "name")]], name="name")

# Generated at 2022-06-11 20:00:52.300122
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    n = Node(0, [Leaf(0, "a"), Leaf(0, "b"), Leaf(0, "c")])
    n.update_sibling_maps()
    assert n.next_sibling_map[id(n.children[0])] is n.children[1], n.next_sibling_map
    assert n.next_sibling_map[id(n.children[1])] is n.children[2], n.next_sibling_map
    assert n.next_sibling_map[id(n.children[2])] is None, n.next_sibling_map
    assert n.prev_sibling_map[id(n.children[0])] is None, n.prev_sibling_map
    assert n.prev_sibling_map[id(n.children[1])]

# Generated at 2022-06-11 20:00:55.236470
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    parse_tree = make_parse_tree()
    node = parse_tree.children[0].children[0]
    assert node.get_lineno() == 2



# Generated at 2022-06-11 20:00:58.536745
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    f = Leaf(1, '')
    c = Node(2, [f])
    r = c.pre_order()
    assert next(r) is c
    assert next(r) is f        

# Generated at 2022-06-11 20:01:01.299939
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert [leaf for leaf in Leaf(None, None).leaves()] == [Leaf(None, None)]

test_Leaf_leaves()

# Generated at 2022-06-11 20:01:12.849292
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import unittest
    from . import grammar, tokenizer
    from .pgen2.parser import Driver, State
    from .pgen2.grammar import Grammar
    def t(type, token=None):
        if token is None:
            token = type
        return tokenizer.TokenInfo(type, token, 0, 0, 0)

# Generated at 2022-06-11 20:01:13.434585
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    pass



# Generated at 2022-06-11 20:01:22.219079
# Unit test for method replace of class Base
def test_Base_replace():
    from .pgen2 import token

    g = Grammar("""
    start = NAME
    """)
    _, node = g.parse("foo bar")
    assert node.children[0].type == token.NAME

    node2 = Leaf(token.NAME, "bar")
    node.replace(node2)
    assert node.parent is None
    assert node.children is None
    assert node2.parent is not None
    assert node2.parent.children[0] is node2

    node.replace(None)  # Shouldn't crash



# Generated at 2022-06-11 20:01:33.215035
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from .util import Unparser, dump_tree
    from .parse import Suite, Symbol, Leaf
    from .astbuilder import Module
    from .pattern import NodePattern, WildcardPattern
    from .token import NAME, NUMBER
    assert str(NodePattern(type=NAME, name="name")) == ".name"
    assert str(NodePattern(type=NAME, name="name", content=["x", "y", "z"])) == "(.name x y z)"
    assert str(NodePattern(type=NAME, name="name", content=[["x", "y", "z"]])) == "(.name x y z)*"
    assert str(NodePattern(name="name", content=[["x", "y", "z"]])) == "(x y z)*"
    assert str(WildcardPattern(min=0, max=0, name="name"))

# Generated at 2022-06-11 20:01:39.360194
# Unit test for method remove of class Base
def test_Base_remove():

    node = Leaf(0, "")
    import pytest
    with pytest.raises(AttributeError):
        node.remove()
    node.parent = Leaf(0, "")
    with pytest.raises(AttributeError):
        node.remove()
    node.parent.children = [node]
    assert node.remove() == 0

test_Base_remove()
del test_Base_remove



# Generated at 2022-06-11 20:01:53.899744
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "")
    assert list(leaf.leaves()) == [leaf]

# Generated at 2022-06-11 20:01:57.562845
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    # The leaves method should always return a sequence containing only self.
    node1 = Leaf(1, "")
    assert node1.leaves() == [node1]
    node2 = Leaf(2, "")
    assert node2.leaves() == [node2]
    node3 = Leaf(3, "")
    assert node3.leaves() == [node3]


# Generated at 2022-06-11 20:02:08.600939
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    if True:
        pattern = Pattern("hi")
        for value, match in (("x", [0]), ("hi x", [2]), ("x hi", [0]), ("xx", [0])):
            value, nodes = tokenize(value)
            n = 0
            for count, result in pattern.generate_matches(nodes):
                n += 1
                assert count == match[0], (n, count, match[0])
                assert result == {}, (n, result)
            assert n == len(match), (n, match)
    if True:
        pattern = Pattern("hi") | Pattern("hello")
        for value, match in (("x", [0]), ("hi x", [2]), ("x hi", [0]), ("xx", [0])):
            value, nodes = tokenize(value)
            n = 0

# Generated at 2022-06-11 20:02:15.647366
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern(min=1, max=1, name="a").optimize() == NodePattern(name="a")
    assert (
        WildcardPattern(
            ((WildcardPattern(min=1, max=1, name="a"),),), min=2, max=2
        ).optimize()
        == WildcardPattern((NodePattern(name="a"),), min=2, max=2)
    )



# Generated at 2022-06-11 20:02:26.893607
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import unittest
    from lib2to3.fixer_util import Leaf
    from lib2to3.fixer_util import Node
    from lib2to3.fixer_util import Comma
    from lib2to3.fixer_util import Symbol
    from lib2to3.fixer_util import Number

    # Test for next_sibling property
    node = Node(Symbol('test', prefix='test'), [])
    next_node = Node(Symbol('test', prefix='test'), [])
    assert node.next_sibling is None
    node.append_child(next_node)
    assert node.next_sibling is next_node
    node.remove()
    assert node.next_sibling is None
    node.insert_child(0, next_node)

# Generated at 2022-06-11 20:02:28.922297
# Unit test for method __eq__ of class Base
def test_Base___eq__():
   
    # Test method __eq__ of class Base
    assert True



# Generated at 2022-06-11 20:02:36.052391
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert BasePattern(tok_name.NAME, 'a').__repr__() == "LeafPattern(NAME, 'a')"
    assert BasePattern(tok_name.NAME).__repr__() == "LeafPattern(NAME)"
    assert BasePattern(256, 'a').__repr__() == "NodePattern(256, 'a')"
    assert BasePattern(256).__repr__() == "NodePattern(256)"


# Generated at 2022-06-11 20:02:44.572385
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.power) == "power"


# This is not part of the grammar file.
# Python 2: it is there.
# 2.7
_tok_names = [
    name.strip("()")
    for name in dir(python_symbols)
    if name.endswith("_token") and "(" in name
]
_tok_names.insert(0, "endmarker")
# Python 3
# _tok_names = [
#     name.strip("()")
#     for name in dir(python_symbols)
#     if name.endswith("_token") and "_token(" in name
# ]
_tok_names.insert(0, "endmarker")


# Generated at 2022-06-11 20:02:49.447754
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .syms import test_leaf as leaf, test_node as node
    n = node(1, (leaf(2, "a"), leaf(3, "b"), leaf(4, "c")))
    assert [tok.type for tok in n.pre_order()] == [1, 2, 3, 4]
    assert [tok for tok in n.post_order()] == [
        leaf(2, "a"),
        leaf(3, "b"),
        leaf(4, "c"),
        n,
    ]
    assert [tok for tok in n.leaves()] == [leaf(2, "a"), leaf(3, "b"), leaf(4, "c")]

# Generated at 2022-06-11 20:02:55.756416
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert (repr(BasePattern(type=1)) == 
            "BasePattern(<1>)"
            )
    assert (repr(BasePattern(type=1, content="foo")) == 
            "BasePattern(<1>, 'foo')"
            )
    assert (repr(BasePattern(type=1, name="foo")) == 
            "BasePattern(<1>, name='foo')"
            )


# Generated at 2022-06-11 20:04:55.222527
# Unit test for method clone of class Base
def test_Base_clone():
    import copy
    import sys
    import unittest
    from .pgen2 import token

    class TestBaseClone(unittest.TestCase):

        def test_clone_leaf(self):
            leaf = Leaf(token.NAME, 'foo', (1, 0))
            clone = copy.deepcopy(leaf)
            self.assertNotEqual(id(leaf), id(clone))
            self.assertEqual(leaf.type, clone.type)
            self.assertEqual(leaf.value, clone.value)
            self.assertEqual(leaf.context, clone.context)

        def test_clone_node(self):
            child1 = Leaf(token.NAME, 'foo', (1, 0))
            child2 = Leaf(token.RPAR, ')', (1, 3))

# Generated at 2022-06-11 20:04:58.689210
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(15) == 15
    assert type_repr(python_symbols.number) == "number"


T = TypeVar("T", bound="Node")



# Generated at 2022-06-11 20:05:00.057626
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(3) == "LPAR"



# Generated at 2022-06-11 20:05:02.897006
# Unit test for method clone of class Base
def test_Base_clone():
    pyunit = __import__('unit_pytest')
    suite = pyunit.suite()
    suite.run_test(Base.clone, "test_Base_clone")

# Generated at 2022-06-11 20:05:05.205468
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert Leaf(0, '1').leaves() == [Leaf(0, '1')]


# Generated at 2022-06-11 20:05:07.085858
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """
    Not sure if anything needs to be tested here.
    """
    pass


# Generated at 2022-06-11 20:05:15.414768
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    n = Node(0, [Leaf(1, None), Leaf(2, None)])
    p = n.pre_order()
    assert p.send(None) is n
    assert p.send(None) is n.children[0]
    assert p.send(None) is n.children[1]
    try:
        p.send(None)
    except StopIteration:
        pass
    else:
        assert False, "StopIteration not raised by pre_order"

# Generated at 2022-06-11 20:05:24.144558
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # Test 1
    a = Node(1)
    b = Node(2)
    c = Node(3)
    d = Node(4)
    e = Node(5)
    a.children = [b, c]
    b.children = [d, e]
    res = [x for x in a.pre_order()]
    correct = [a, b, d, e, c]
    res = [a, b, d, e, c]
    assert res == correct



# Generated at 2022-06-11 20:05:34.777071
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node, PythonLeaf, PythonNode
    from . import pytree

    from . import Driver

    def mock_driver(x):
        return Driver(Grammar(), pytree)

    driver: Driver = mock_driver(None)
    pytree.Base._default_driver_init = mock_driver

    # Test for class Leaf
    leaf = Leaf(1, "DUMMY_STRING")
    new = Leaf(2, "NEW_STRING")
    leaf.replace(new)
    assert leaf.type == 1
    assert leaf.value == "DUMMY_STRING"
    assert leaf.parent is None

    assert new.type == 2
    assert new.value == "NEW_STRING"
    assert new.parent is None

    # Test for class Node

# Generated at 2022-06-11 20:05:44.299703
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols

    n1 = Leaf(0, "1")
    n2 = Leaf(0, "2")
    n3 = Leaf(0, "3")
    n4 = Leaf(0, "4")
    n5 = Leaf(0, "5")
    n6 = Leaf(0, "6")
    n7 = Leaf(0, "7")

    #     outer          inner
    #    /    \         /    \
    #   1      2   ->  3      4
    #  / \      \     /      / \
    # 5   6      7   5      6   7
    top = Node(python_symbols.file_input, [n1, n2], None)
    n1.parent = top
    n

# Generated at 2022-06-11 20:06:36.108937
# Unit test for method clone of class Base
def test_Base_clone():
    from blib2to3.pgen2.token import NAME
    from blib2to3.pgen2.parse import Parser
    from .pytree import Leaf, Node

    source = "a.b"
    tree = Parser().parse_string(source)
    tree.changed()
    a, per, b = tree.children
    assert isinstance(a, Leaf)
    assert a.type == NAME
    assert a.value == "a"
    assert isinstance(b, Leaf)
    assert b.type == NAME
    assert b.value == "b"
    assert isinstance(per, Leaf)
    assert per.type == 34
    assert per.value == "."
    assert a.parent is per.parent
    assert a.parent is tree
    assert per.parent is tree
    assert b.parent is tree
