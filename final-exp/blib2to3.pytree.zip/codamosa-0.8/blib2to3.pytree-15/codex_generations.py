

# Generated at 2022-06-11 19:59:08.164456
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pgen2 import token

    i = Leaf(token.NAME, "name")
    assert list(i.leaves()) == [i]

# Generated at 2022-06-11 19:59:19.126733
# Unit test for function generate_matches
def test_generate_matches():
    a, b, c = Node(1), Node(2), Node(3)
    abc = [a, b, c]
    assert list(generate_matches([NodePattern(2), NodePattern(3)], abc)) == [
        (2, {})
    ]
    assert list(generate_matches([NodePattern(2), NodePattern(1)], abc)) == []
    assert (
        list(generate_matches([NodePattern(2), WildcardPattern()], abc))
        == list(generate_matches([NodePattern(2), WildcardPattern([])], abc))
        == [(2, {}), (3, {})]
    )

# Generated at 2022-06-11 19:59:22.359015
# Unit test for method post_order of class Base
def test_Base_post_order():
    """
    Test that a subclass of Base doesn't have a Base in its post_order
    iterator
    """
    assert all(isinstance(leaf, Leaf) for leaf in Base.post_order())



# Generated at 2022-06-11 19:59:35.907365
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Test constructor of NodePattern
    assert NodePattern(
        0, None, ""
    )  # Raises: assert type >= 256

    assert NodePattern(257, None, "")
    assert NodePattern(257, [], "")
    assert NodePattern(257, [LeafPattern(1, "")], "")
    assert NodePattern(257, [LeafPattern(1, ""), LeafPattern(1, None)], "")
    assert NodePattern(257, [LeafPattern(1, ""), LeafPattern(1, None, "name")], "")
    assert NodePattern(
        257, [LeafPattern(1, ""), LeafPattern(1, None, "name"), LeafPattern(1, None)], "name"
    )

    assert NodePattern(257, LeafPattern(1, None), "")

# Generated at 2022-06-11 19:59:41.749290
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    import pytest
    import parser
    import inspect
    import ast

    pytest.skip(
        "The following test illustrates the use of TextMatchingException\n"
        "as raised by generate_matches when a matching is found.\n"
        "If this test fails, an error will be raised by the Python interpreter\n"
        "and the output of this test will have been redirected to a file\n"
        "named 'text_match.log' which should contain a message of the form:\n"
        "TextMatchingException: Pattern found in source\n"
        "Source file: '<string>'\n"
        "Line number: <line_number>\n"
        "Column number: <column_number>\n"
    )


# Generated at 2022-06-11 19:59:49.847055
# Unit test for method remove of class Base
def test_Base_remove():
    # Simulate a tree with four nodes, leaf1, leaf2, leaf3, leaf4
    node_a = Leaf(1, "prefix1")
    node_a.parent = Node(2, [node_a])
    node_b = Leaf(1, "prefix1")
    node_b.parent = Node(2, [node_b])
    node_c = Leaf(1, "prefix1")
    node_c.parent = Node(2, [node_c])
    node_d = Leaf(1, "prefix1")
    node_d.parent = Node(2, [node_d])
    root_node = Node(2, [node_a, node_b, node_c, node_d])
    for node in (node_a, node_b, node_c, node_d):
        node.parent

# Generated at 2022-06-11 19:59:59.594030
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node, test_Base_post_order, test_Base_pre_order

    class Node_test_Base_post_order (Node, Base): pass
    class Leaf_test_Base_post_order (Leaf, Base):
        _GENERIC_LEAF = True
        def type_repr(self) -> Union[Text, int]:
            return type_repr(self.value)
        def __repr__(self) -> Text:
            return "<%s %r>" % (self.__class__.__name__, self.value)

    def test(s, expected_sorted=False) -> None:
        t = Node_test_Base_post_order(None, [Leaf_test_Base_post_order(1, "abc")])
        test_Base_post_order

# Generated at 2022-06-11 20:00:04.940317
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Test for a bug in Base.__eq__.
    class Dummy(Leaf):
        pass
    n1 = Dummy(0, "foo")
    n2 = Dummy(0, "foo")
    n3 = Dummy(0, "bar")
    assert n1 == n2
    assert n2 == n1
    assert n1 != n3
    assert n3 != n1



# Generated at 2022-06-11 20:00:13.503173
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Python 3.5 grammar
    from .pygram import python_grammar

    class DummyNode(Node):
        def __init__(self, leaves=()):
            Node.__init__(self, "dummy", leaves)

    def create_tree(s):
        # create a parse tree from a string
        p = gen_python_parser(python_grammar, python_grammar.number2symbol)
        seq, remainder = p.parse_string(s, "file_input")
        if not remainder:
            seq = seq.clone()
            return seq.children[0]
        else:
            # strip off the last leaf since it contains the error we're looking
            # for
            leaf = seq.children[-1]
            seq = seq.clone()
            seq.children = seq.children[:-1]


# Generated at 2022-06-11 20:00:18.115234
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node

    n = Node(56, [Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c')])
    assert n.depth() == 0
    assert n.children[1].depth() == 1



# Generated at 2022-06-11 20:00:35.001551
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern(name="x").optimize() == NodePattern(name="x")
    assert WildcardPattern(min=0, max=1, name="x").optimize() == NodePattern(name="x")
    assert WildcardPattern(min=2, max=2, name="x").optimize() == WildcardPattern(
        max=1, name="x"
    )
    assert WildcardPattern(
        [(LeafPattern("NAME"),)], min=2, max=2, name="x"
    ).optimize() == WildcardPattern(
        [(LeafPattern("NAME"),)], max=1, name="x"
    )

# Generated at 2022-06-11 20:00:35.822804
# Unit test for method replace of class Base
def test_Base_replace():
    raise NotImplementedError



# Generated at 2022-06-11 20:00:36.946402
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    assert False, 'Unimplemented'



# Generated at 2022-06-11 20:00:46.260707
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    w = WildcardPattern([[NodePattern(type=NAME)]])
    assert isinstance(w.optimize(), WildcardPattern)
    w = WildcardPattern([[NodePattern(type=NAME)]], name="foo")
    assert isinstance(w.optimize(), WildcardPattern)
    w = WildcardPattern([[NodePattern(type=NAME)]], name="foo", min=1, max=1)
    assert isinstance(w.optimize(), NodePattern)
    w = WildcardPattern([[NodePattern(type=NAME)]], min=1, max=1)
    assert isinstance(w.optimize(), NodePattern)
    w = WildcardPattern([[WildcardPattern(name="foo")]])
    assert isinstance(w.optimize(), WildcardPattern)

# Generated at 2022-06-11 20:00:47.767721
# Unit test for method clone of class Base
def test_Base_clone():
    assert False, "Test not implemented."


# Generated at 2022-06-11 20:00:53.826633
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    def helper(n, expected_list):
        actual_list = []
        for node in n.pre_order():
            actual_list.append(node)
        return actual_list == expected_list
    a = Leaf(1, "a", None)
    b = Leaf(1, "b", None)
    c = Leaf(1, "c", None)
    d = Leaf(1, "d", None)
    e = Leaf(1, "e", None)
    nodes = [a, b, c, d, e]
    n = Node(0, nodes, None)
    k = Node(0, nodes, None)
    assert test_Node_pre_order.__annotations__ == n.pre_order.__annotations__
    assert helper(n, [n, a, b, c, d, e])


# Generated at 2022-06-11 20:00:56.865459
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    arg0 = Leaf(0, "")
    arg1 = Leaf(0, "")
    Base___eq__(arg0, arg1)


# Generated at 2022-06-11 20:01:01.200191
# Unit test for function generate_matches
def test_generate_matches():
    p1, p2, p3 = NodePattern(1), NodePattern(2), NodePattern(3)
    p23 = NodePattern(2, [p3])
    p123 = NodePattern(1, [p2, p3])
    p12 = NodePattern(1, [p2])
    p13 = NodePattern(1, [p3])
    p123a = NodePattern(1, [p23])
    p12a = NodePattern(1, [p2])
    p13a = NodePattern(1, [p3])
    p_123 = NegatedPattern(p123)
    n1, n2, n3, n4, n5, n6 = [NL(i) for i in range(1, 7)]

# Generated at 2022-06-11 20:01:12.746130
# Unit test for method set_child of class Node
def test_Node_set_child():
    from blib2to3.pytree import Leaf, Node
    x = Leaf(1, 'a', (1, 2), 'prefix')
    y = Leaf(1, 'b', (3, 4), 'prefix2')
    z = Leaf(1, 'c', (5, 6), 'prefix3')
    xyz = Node(1, (x, y, z))
    xyz.set_child(1, y)
    assert xyz.children[1] == y
    y.parent = x
    assert y.parent == x
    x.parent = xyz
    assert x.parent == xyz
    xyz.invalidate_sibling_maps()
    xyz.update_sibling_maps()
    assert xyz.prev_sibling_map[id(z)] == y
    assert xyz.next_

# Generated at 2022-06-11 20:01:15.058712
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    assert Base._eq(Base(), Base()) is False


# Generated at 2022-06-11 20:01:43.158743
# Unit test for method clone of class Base
def test_Base_clone():
    from . import pytree

    def append_newlines(prefix, s):
        lines = s.splitlines(True)
        if not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        return prefix + "".join(lines)

    n = pytree.Node(1001, [pytree.Leaf(3, "a"), pytree.Leaf(3, "b")])
    n.children[0].prefix = append_newlines("  ", "c\n" "d\n")
    n.children[1].prefix = append_newlines("  ", "e\n" "f\n")
    m = n.clone()
    assert n == m
    m.children[0].value = "x"
    m.children[-1].value = "z"


# Generated at 2022-06-11 20:01:46.863742
# Unit test for method replace of class Base
def test_Base_replace():
    import lib2to3.pgen2.parse
    import lib2to3.pgen2.tokenize
    import StringIO
    import lib2to3.pgen2.token


# Generated at 2022-06-11 20:01:57.465366
# Unit test for method leaves of class Base
def test_Base_leaves():
    class MockBase(Base):
        def _eq(self, other):
            return True

        def clone(self):
            return self

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

        @property
        def prefix(self):
            return ""

    class MockNode(Node):
        def _eq(self, other):
            return True

        def clone(self):
            return self

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

        @property
        def prefix(self):
            return ""

    class MockLeaf(Leaf):
        def _eq(self, other):
            return True

        def clone(self):
            return self

        @property
        def prefix(self):
            return ""

   

# Generated at 2022-06-11 20:02:08.515138
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols
    from .pygram import python_grammar
    from . import parse as _parse
    from . import fixed_test_grammar
    sample: Base = Node(python_symbols.file_input,
                                 [Leaf(token.NAME, "print", prefix="\n"),
                                  Leaf(token.NAME, "print", prefix=" "),
                                  Leaf(token.NAME, "print", prefix="\n")],
                                 prefix="\n")
    leaves = list(sample.leaves())
    got = [leaf.value for leaf in leaves]
    expected = ["print", "print", "print"]
    assert got == expected, got
    sample = Leaf(token.NAME, "name", prefix="   ")
    sample.type = None

# Generated at 2022-06-11 20:02:16.165516
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Node, Leaf

    def check(tree, expected):
        result = "".join(x.type for x in tree.post_order())
        assert result == expected, result

    tree = Node(1, [Leaf(2, "a"), Node(3, [Node(4, [Leaf(5, "b")])])])
    check(tree, "ab4c3d1")



# Generated at 2022-06-11 20:02:26.254325
# Unit test for method remove of class Base
def test_Base_remove():
    import random
    import unittest

    class BaseTest(unittest.TestCase):

        def test_remove(self):
            try:
                a = [None, 1, 2, 3, 4, 5, 6]
                i = random.randint(0, len(a) - 1)
                #  node = a[i]
                removed_i = a.remove(a[i])
                removed_i_2 = node.remove()
                self.assertEqual(removed_i, removed_i_2)
            except Exception as e:
                print(e)
                self.assertEqual(1, 0, "Testcase failed")
    unittest.main()




# Generated at 2022-06-11 20:02:38.284949
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .fixer_util import LParen, RParen, Token
    from .fixer_util import get_nodes_of_class

    fake_lparen = LParen()
    fake_rparen = RParen()
    fake_rparen.set_prefix(" ")
    fake_token = Token("XXX", prefix=" ")
    assert fake_lparen.get_lineno() == 0
    assert fake_rparen.get_lineno() == 0
    assert fake_token.get_lineno() == 0

    class FakeNode(Base):
        def __init__(self, lineno):
            self.lineno = lineno
            self.children = []

        def get_prefix(self):
            return "\n"
    node = FakeNode(23)
    # Test the case where the root node has a lineno
   

# Generated at 2022-06-11 20:02:40.818450
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert ''.join(Leaf(0, '').pre_order()) == '<Leaf (0, \'\')>'

# Generated at 2022-06-11 20:02:51.807384
# Unit test for method replace of class Base
def test_Base_replace():
    for a in range(1):
        for b in range(1):
            for c in range(1):
                for d in range(1):
                    # Create some nodes
                    x = Leaf(3, "x", (0, 0))
                    y = Leaf(3, "y", (0, 0))
                    z = Leaf(3, "z", (0, 0))
                    w = Leaf(3, "w", (0, 0))
                    x.prefix = "H"
                    y.prefix = "e"
                    z.prefix = "l"
                    w.prefix = "o"
                    node = Node(2, None, None, [x, y])
                    x.parent = y.parent = node
                    node.changed()
                    node.invalidate_sibling_maps()

# Generated at 2022-06-11 20:02:53.810622
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1,'1')
    assert leaf.pre_order() == iter([leaf])

# Generated at 2022-06-11 20:03:07.876514
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .convert import fix_identity

    x = _parse("a[b, c] + d")[0]
    assert list(x.post_order()) == [_parse('c'), _parse('b'), _parse('a'), _parse('d'), x]


# Generated at 2022-06-11 20:03:15.684158
# Unit test for method post_order of class Node
def test_Node_post_order():
    print("TestNode.test_post_order")
    from lib2to3.pgen2.token import LPAR
    from lib2to3.pytree import Leaf
    p = Node(LPAR, [Leaf(1, "a"), Leaf(1, "b")])
    result = list(p.post_order())
    assert result[0].value == "a"
    assert result[1].value == "b"
    assert result[2].type == LPAR


# Generated at 2022-06-11 20:03:24.702777
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    f,g = TextPattern("f"), TextPattern("g")
    p = WildcardPattern([[f, g]])
    q = NegatedPattern(p)
    result = list(q.generate_matches(["f","g"]))
    assert result == [], result
    result = list(q.generate_matches(["f"]))
    assert result == [(0,{})], result
    result = list(q.generate_matches(["g"]))
    assert result == [(0,{})], result
    result = list(q.generate_matches(["h"]))
    assert result == [(0,{})], result
    result = list(q.generate_matches([]))
    assert result == [(0,{})], result
    q = NegatedPattern()

# Generated at 2022-06-11 20:03:33.194747
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    (node1, node2, node3, node4, node5, node6, node7, node8, node9, node10, node11, node12) = (
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
        Base(),
    )
    assert node1 == node2
    assert node2 == node1
    assert not (node1 != node2)
    assert node1 != node3
    assert not (node1 == node3)

# Generated at 2022-06-11 20:03:41.842697
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    class LeafB(Leaf):
        def changed(self):
            raise Exception("changed!")
    from .pytree import Node
    class NodeB(Node):
        def changed(self):
            raise Exception("changed!")
    l = LeafB(1, 'a')
    l.remove()
    assert l.next_sibling is None
    assert l.prev_sibling is None
    root = NodeB(2, [])
    root.children = [LeafB(1, 'a'),
                     NodeB(2, []),
                     LeafB(1, 'c')]
    assert root.children[0].next_sibling is root.children[1]
    assert root.children[1].next_sibling is root.children[2]
    assert root.children[2].next

# Generated at 2022-06-11 20:03:44.455437
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    n = BasePattern('type', 'content')
    assert repr(n) == "BasePattern('type', 'content', None)"



# Generated at 2022-06-11 20:03:49.655391
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node

    leaf = Leaf(1, "foo")
    node1 = Node(2, [leaf])
    node1.changed()
    node2 = Node(3, [node1])
    leaves = list(node2.leaves())
    assert leaves == [leaf]


# Generated at 2022-06-11 20:03:59.929216
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import pdb
    from lib2to3.pgen2.pgen import DefaultDebugParser
    from lib2to3.pgen2.grammar import Grammar

    # For easier debugging, we use the debugger.
    pdb.set_trace()
    grammar = Grammar(StringIO(DefaultDebugParser.grammar))
    ns = grammar.parse(DefaultDebugParser.start, DefaultDebugParser.text)
    # For easier debugging, we use the debugger.
    pdb.set_trace()
    from .pytree import convert_to_pytree
    pytree = convert_to_pytree(ns)
    a = pytree.children[0]
    b = pytree.children[0]
    # For easier debugging, we use the debugger.
    pdb.set_trace()
    result = a == b
    assert result

# Generated at 2022-06-11 20:04:00.504279
# Unit test for method post_order of class Base
def test_Base_post_order():
    pass


# Generated at 2022-06-11 20:04:10.482267
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node, Leaf
    from .pygram import python_grammar, python_grammar_no_print_statement
    from .pgen2 import token, driver
    from . import py2token, py2grammar
    from . import py3token, py3grammar

    g = driver.Driver(
        py2grammar.grammar, py2token.tok_name,
        py3grammar.grammar, py3token.tok_name,
        python_grammar, "python3",
        python_grammar_no_print_statement, "python3"
    )

    def depth(s):
        # Read a python expression and print the depth of the tree
        t = g.parse_string(s)
        return t.depth()
