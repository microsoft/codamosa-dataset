

# Generated at 2022-06-11 19:58:34.520782
# Unit test for function convert
def test_convert():
    g = Grammar(test_grammar)
    node = convert(g, (g.symbol2number['file_input'], '', None, [
        convert(g, (g.symbol2number['funcdef'], '',
                    None, [
                        convert(g, (g.symbol2number['NAME'], 'foo', None, [])),
                        convert(g, (g.symbol2number['parameters'], '', None, [])),
                        convert(g, (g.symbol2number['COLON'], '', None, [])),
                        convert(g, (g.symbol2number['suite'], '', None, [])),
                    ])),
    ]))
    assert node.type == g.symbol2number['file_input']

# Generated at 2022-06-11 19:58:39.766203
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node, Leaf
    tree = Node(None, [
        Leaf(1, 'foo'),
        Node(None, [
            Leaf(2, 'bar'),
        ]),
    ])
    assert Node.depth(tree) == 0
    assert Node.depth(tree.children[1]) == 1
    assert Leaf.depth(tree.children[1].children[0]) == 2


# Generated at 2022-06-11 19:58:44.263590
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    import pattern.test
    import pattern.en
    import textblob_de.pattern_de as pattern_de
    for module in [pattern.test, pattern.en, pattern_de]:
        for name, value in module.__dict__.items():
            if isinstance(value, WildcardPattern):
                value.optimize()

# Generated at 2022-06-11 19:58:51.593866
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    v1 = Node(type = 0)
    v2 = Node(type = 0)
    v3 = Node(type = 0)
    v4 = Leaf(type = 0)
    v5 = Leaf(type = 0)
    v6 = Leaf(type = 0)
    v7 = Leaf(type = 0)
    v8 = Leaf(type = 0)
    v9 = Leaf(type = 0)
    v10 = Leaf(type = 0)
    v11 = Leaf(type = 0)
    v12 = Leaf(type = 0)
    v13 = Leaf(type = 0)
    v14 = Leaf(type = 0)
    v15 = Leaf(type = 0)
    v16 = Leaf(type = 0)
    v17 = Leaf(type = 0)
    v18 = Leaf(type = 0)
   

# Generated at 2022-06-11 19:59:04.376553
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import unittest
    import itertools
    class Tests(unittest.TestCase):
        def setUp(self):
            pass

        def test_match_seq_1(self):
            # Arrange
            nodes = [Leaf(1, 'a', (0, 0)), Leaf(1, 'a', (0, 0)), Leaf(1, 'a', (0, 0))]
            results = {0: 0, 1: 1, 2: 2}

            # Act
            actual = list(BasePattern.match_seq(Leaf(1, 'a', (0, 0)), nodes))

            # Assert
            self.assertEqual(actual, [(1, {'a': Leaf(1, 'a', (0, 0))})])

    unittest.main(verbosity=2)


# Generated at 2022-06-11 19:59:06.638821
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Arguments:
    #     nodes:
    #     results:
    # Expected results:
    pass # Default implementation for non-wildcard patterns.

# Generated at 2022-06-11 19:59:16.393620
# Unit test for method remove of class Base

# Generated at 2022-06-11 19:59:23.051998
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    test_grammar = Grammar()
    test_grammar.initialize('s -> b a\na -> "a"\nb -> "b"')
    test_tree = test_grammar.parse("ba")
    x = ([y[0] for y in test_tree.pre_order()],["b", "a"])
    assert x == ([y[0] for y in test_tree.pre_order()],["b", "a"])


# Generated at 2022-06-11 19:59:29.335585
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    if not (
        list(
            BasePattern(
                type=1, content=None, name=None,
            ).generate_matches(nodes=[],)
        )
        == []
    ):
        return 0
    if not (
        list(
            BasePattern(
                type=1, content=None, name=None,
            ).generate_matches(nodes=[BaseNode(type=1, value=None, context=None, children=None,),],)
        )
        == [(1, {})]
    ):
        return 0
    return 1



# Generated at 2022-06-11 19:59:38.327881
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test both optimization paths
    assert WildcardPattern().optimize() == NodePattern()
    assert WildcardPattern([[WildcardPattern()]]).optimize() == WildcardPattern(
        [[NodePattern()]]
    )
    # Use a less trivial example
    expr = WildcardPattern(
        [[WildcardPattern([[WildcardPattern()]]), WildcardPattern()]]
    )
    assert expr.optimize() == WildcardPattern(
        [[WildcardPattern([[NodePattern()]]), NodePattern()]]
    )
    assert expr.optimize().optimize() == WildcardPattern(
        [[WildcardPattern([[NodePattern()]]), NodePattern()]]
    )


if __name__ == "__main__":
    test_WildcardPattern_optimize()

# Generated at 2022-06-11 20:00:28.689350
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():

    from .pgen2 import driver

    gram = driver.load_grammar(test_grammar)
    mod = gram.parse("0+1", debug=1)

    def check(nodes, expected):
        pattern = NodePattern(mod.syms.sum)
        actual = pattern.match_seq(nodes)
        assert actual == expected, f"{pattern.type} {len(nodes)} {nodes} {expected} {actual}"

    check([], False)
    check([mod.children[0]], False)
    check([mod.children[0], mod.children[0]], False)
    check([mod.children[0], mod.children[1], mod.children[0]], False)
    check([mod.children[0], mod.children[1], mod.children[2]], True)
    check

# Generated at 2022-06-11 20:00:36.663471
# Unit test for method remove of class Base
def test_Base_remove():
    class BaseTest(Base):
        def _eq(self, other):
            return isinstance(other, BaseTest)

    class NodeTest(BaseTest, Node):
        def __init__(self, *args, **kwds):
            super().__init__(None, *args, **kwds)

    class LeafTest(BaseTest, Leaf):
        def __init__(self, *args, **kwds):
            super().__init__(None, *args, **kwds)

    root = NodeTest(0, None, None, [])
    leaf = LeafTest(0, "", None, None)
    root.append_child(leaf)
    assert leaf.remove() == 0



# Generated at 2022-06-11 20:00:41.813568
# Unit test for method depth of class Base
def test_Base_depth():
    from . import pytree

    t = pytree.Node(0, [pytree.Leaf(1, "hi"), pytree.Leaf(1, "there")])
    assert t.depth() == 0
    assert t.children[0].depth() == 1
    assert t.children[1].depth() == 1



# Generated at 2022-06-11 20:00:47.362860
# Unit test for method post_order of class Base
def test_Base_post_order():
    s = u"""a = b"""
    t = parse_string(s)
    l = list(t.post_order())
    expected = list([Leaf(1, u"a", (1, 0)), Leaf(1, u"=", (1, 2)),
                     Leaf(1, u"b", (1, 4))])
    assert l == expected
    assert l[0].type == expected[0].type
    assert l[0].value == expected[0].value
    assert l[0].prefix == expected[0].prefix
    assert l[0].parent == expected[0].parent



# Generated at 2022-06-11 20:00:53.732446
# Unit test for method set_child of class Node
def test_Node_set_child():
    tree = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), Leaf(1, "d")])
    assert tree.get_child_n(0).value == "a"
    assert tree.get_child_n(1).value == "b"
    assert tree.get_child_n(2).value == "c"
    assert tree.get_child_n(3).value == "d"
    tree.set_child(2, Leaf(1, "C"))
    assert tree.get_child_n(0).value == "a"
    assert tree.get_child_n(1).value == "b"
    assert tree.get_child_n(2).value == "C"
    assert tree.get_child_n(3).value == "d"

# Generated at 2022-06-11 20:01:05.234405
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # The repr() of a Pattern doesn't waste space by showing the
    # type and content arguments unless they differ from the defaults.
    assert repr(LeafPattern(0)) == "LeafPattern(0, None, None)"
    assert repr(LeafPattern(0, None)) == "LeafPattern(0, None, None)"
    assert repr(LeafPattern(0, "abc")) == "LeafPattern(0, 'abc', None)"
    assert repr(LeafPattern(0, "abc")) == "LeafPattern(0, 'abc', None)"
    assert repr(LeafPattern(0, "abc", name="name")) == "LeafPattern(0, 'abc', 'name')"

# Generated at 2022-06-11 20:01:09.760580
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols
    from .parse import parse_text
    grammar = Grammar(python_symbols.python_grammar, "python_symbols")

# Generated at 2022-06-11 20:01:22.101999
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import unittest
    from .pgen2.token import tok_name
    from .pgen2 import token
    from .pgen2 import driver


    class TestPattern(BasePattern):
        def _submatch(self, node, results):
            return True

    tokens_to_match = [
        token.NAME("a"),
        token.NEWLINE("\n"),
        token.NAME("b"),
    ]

    pattern_to_match = TestPattern(type=token.NAME, name="token")

    with driver.PgenDriver("grammar.txt", convert) as parser:

        matches = list(pattern_to_match.generate_matches(tokens_to_match))
        # The list should contain two matches, both token.NAME("a"), with
        # the second match beginning at the NEWLINE token.

# Generated at 2022-06-11 20:01:23.264302
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    return None

# Generated at 2022-06-11 20:01:33.925745
# Unit test for method __repr__ of class BasePattern

# Generated at 2022-06-11 20:02:01.046790
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    node_2 = Leaf(22, "b")
    node_0 = Leaf(22, "a")
    node_0.parent = node_2
    result = node_0.remove()
    assert result is None


# Generated at 2022-06-11 20:02:03.424812
# Unit test for method leaves of class Base
def test_Base_leaves():
    b = Base()
    assert b.leaves() == []



# Generated at 2022-06-11 20:02:10.360609
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    x = Leaf(256, 'Expr')
    leaf_list = list(x.leaves())
    y = Leaf(257, 'Not')
    x.append_child(y)
    leaf_list = list(x.leaves())
    assert len(leaf_list) == 2



# Generated at 2022-06-11 20:02:23.562034
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import NAME, NUMBER, STRING
    from .pgen2.parse import ParseError

    b = BasePattern()

    # This is the first test of a method that does not currently work.
    # The "raise NotImplementedError" in _submatch() is never raised.
    with pytest.raises(NotImplementedError):
        pytest.raises(ParseError, b.match_seq, [Leaf(NAME, "foobar")])

    class Foo(BasePattern):
        pass

    b = Foo()
    with pytest.raises(ParseError, match="This should not match"):
        b.match_seq([Leaf(NAME, "foobar")])


# Generated at 2022-06-11 20:02:27.953875
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pygram import python_grammar as Grammar
    g = Grammar(version="3.7")
    t = g.parse("if a:\n    pass\nelif b:\n    pass")
    lineno = t[1].children[0].children[0].children[0].children[-1].children[0].children[0].get_lineno()
    assert lineno == 1



# Generated at 2022-06-11 20:02:38.750696
# Unit test for method set_child of class Node
def test_Node_set_child():
    n = Node(1, [])
    n.set_child(0, Leaf(1, 'str'))
    n.set_child(-1, Leaf(1, 'str'))
    n.set_child(-2, Leaf(1, 'str'))
    n.set_child(-3, Leaf(1, 'str'))
    n.set_child(-4, Leaf(1, 'str'))
    n.set_child(-5, Leaf(1, 'str'))
    n.set_child(-6, Leaf(1, 'str'))
    n.set_child(-7, Leaf(1, 'str'))
    n.set_child(-8, Leaf(1, 'str'))
    n.set_child(-9, Leaf(1, 'str'))

# Generated at 2022-06-11 20:02:49.974921
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.pgen import BasePattern

    class TestPattern(BasePattern):
        def __init__(self, p1, p2=None, **kwds):
            BasePattern.__init__(self, **kwds)
            self.p1 = p1
            self.p2 = p2

        def _match(self, node, results=None):
            if self.p1 is not None:
                if not self.p1.match_seq(node.children, results):
                    return False
            return True

    p = TestPattern(None, None, type=10)
    q = p.optimize()
    assert q is p, q
    p = TestPattern(None, type=10)
    q = p.optimize()
    assert q is p, q

# Generated at 2022-06-11 20:03:02.260712
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    '''
    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(TestBase))
        return suite
    '''
    import unittest
    from .pytree import Leaf

    class TestBase(unittest.TestCase):

        def test_leaf(self):
            one_1 = Leaf(1, 'one', (0, 0))
            one_2 = Leaf(1, 'one', (0, 0))
            two = Leaf(1, 'two', (0, 0))
            self.assertEqual(one_1.get_suffix(), "")
            self.assertEqual(one_2.get_suffix(), "")
            self.assertEqual(two.get_suffix(), "")

            one_1.add

# Generated at 2022-06-11 20:03:12.193230
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Typing isn't supported for abstract classes. We have to use a
    # concrete subclass.
    WildcardPatternImp = WildcardPattern

    def do_optimize_test(
        typ: type,
        *args,
        input_min: int = 0,
        input_max: int = HUGE,
        input_name: Optional[Text] = None,
        output_min: int = 0,
        output_max: int = HUGE,
        output_name: Optional[Text] = None,
    ) -> None:
        wp = WildcardPatternImp(*args, min=input_min, max=input_max, name=input_name)
        wp2 = wp.optimize()
        assert isinstance(wp2, typ), wp2

# Generated at 2022-06-11 20:03:22.992510
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.tokenize import generate_tokens
    from .pgen2 import token

    from . import tokenize
    from .tokenize import generate_tokens
    from .tokenize import NAME
    from .tokenize import NUMBER
    from .tokenize import OP
    from .tokenize import STRING
    from .tokenize import tokenize
    from typing import Iterator

    def pattern_post_order(pattern):
        # type: (Pattern) -> Iterator[Leaf]
        """This is the method under test"""
        return pattern.post_order()

    a = Leaf(NAME, "a")
    b = Leaf(NAME, "b")
    c = Leaf(NAME, "c")
    d = Leaf(NAME, "d")
    e = Leaf(NAME, "e")

# Generated at 2022-06-11 20:03:44.097967
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import unittest

    from .pytree import Leaf

    class _Test_Leaf_Equality(Leaf):
        """Test that __eq__ is inherited from Base."""

        def _eq(self, other) -> bool:
            return True

    class _Test_Leaf_Not_Equality(Leaf):
        """Test that __eq__ is inherited from Base."""

        def _eq(self, other) -> bool:
            return False

    class BaseTest(unittest.TestCase):

        """Test that __eq__ is implemented in Base."""

        def test_equal(self) -> None:
            left = _Test_Leaf_Equality(0, "a")
            right = _Test_Leaf_Equality(0, "b")
            self.assertEqual(left, right)


# Generated at 2022-06-11 20:03:45.737932
# Unit test for function generate_matches
def test_generate_matches():
    assert list(
        generate_matches(
            [WildcardPattern(min=1), WildcardPattern(min=2)],
            [1, 2, 3, 4, 5],
        )
    ) == [(3, {}), (4, {}), (5, {})]



# Generated at 2022-06-11 20:03:55.631757
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(content=[])
    assert p.type is None and p.content == [] and p.name is None
    p = NodePattern(type=256, content=[], name="x")
    assert p.type == 256 and p.content == [] and p.name == "x"
    nl = Node(type=256, children=[])
    assert p.match(nl)
    # Fails if type doesn't match
    assert not p.match(Leaf(type=16, value="foo"))
    assert not p.match(Node(type=16, children=[]))
    # Fails if number of children doesn't match
    assert not p.match(Node(type=256, children=[Leaf(type=16, value="foo")]))

# Generated at 2022-06-11 20:04:01.085766
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class Test(BasePattern):
        def _submatch(self, node, results=None):
            return True
    p = Test(42)
    assert p.match_seq([node(42)]) == True
    assert p.match_seq([node(42), node(43)]) == False



# Generated at 2022-06-11 20:04:01.657760
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    pass

# Generated at 2022-06-11 20:04:12.571261
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name
    res = repr(LeafPattern(1, "None"))
    assert res == "LeafPattern(NAME, 'None')"
    res = repr(NodePattern(tok_name.NAME, "None", [LeafPattern(1, "None")]))
    assert (
        res
        == "NodePattern(NAME, 'None', [LeafPattern(NAME, 'None')])"
        or res == "NodePattern(NAME, 'None', [LeafPattern(NAME, 'None')])"
    )
    res = repr(WildcardPattern())
    assert res == "WildcardPattern()"
    res = repr(WildcardPattern(None, None, "n"))
    assert res == "WildcardPattern('n')"

# Generated at 2022-06-11 20:04:18.261350
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf
    from . import pygram
    from .pgen2 import driver

    leaf = Leaf(1, "spam")
    assert isinstance(leaf.clone(), Leaf)

    driver = driver.Driver(pygram.python_grammar, pygram.python_grammar_flags,
                           convert=pygram.convert_python_grammar)
    tree = driver.parse_string("spam(eggs)")
    assert isinstance(tree.clone(), Node)



# Generated at 2022-06-11 20:04:31.042237
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from pickle import loads
    from pprint import pformat
    from textwrap import dedent
    import tokenize
    from typing import List, Union, Iterator
    from typing_extensions import Final
    from test.test_tools import FakeGrammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar


# Generated at 2022-06-11 20:04:42.499111
# Unit test for function generate_matches
def test_generate_matches():
    import pprint
    pprint.pprint(list(generate_matches([], [])))
    pprint.pprint(list(generate_matches([WildcardPattern(name="wild")], [])))
    node1 = NL(1, 1)
    node2 = NL(2, 2)
    pprint.pprint(
        list(generate_matches([WildcardPattern()], [node1, node2]))
    )  # noqa: B950
    pprint.pprint(
        list(
            generate_matches(
                [
                    WildcardPattern(name="wild"),
                    NodePattern(name="node", type=1),
                    WildcardPattern(name="wild"),
                ],
                [node1, node2],
            )
        )
    )

# Generated at 2022-06-11 20:04:45.501075
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2 import token
    leaf = Leaf(token.NAME, 'foo')
    assert list(leaf.post_order()) == [leaf]



# Generated at 2022-06-11 20:05:14.791478
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.token import NAME
    l = Leaf(NAME, 'a')
    assert str(sorted(l.post_order(), key = lambda x : str(x))) == "[Leaf(1, 'a')]"

# Generated at 2022-06-11 20:05:21.956169
# Unit test for method __eq__ of class Base
def test_Base___eq__():
  from .pytree import Leaf, Node
  node_1 = Node(1)
  node_2 = Node(1)
  node_2.children = [ Leaf(1, "a") ]
  node_2.changed()
  assert node_1 != node_2
  assert node_2 == node_2


# Generated at 2022-06-11 20:05:31.357087
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    cases = [
        ([], None, []),
        ([], NoPattern(), []),
        ([], WildcardPattern(), []),
        ([], OrPattern(), [(0, {})]),
        (["a"], NoPattern(), [(0, {})]),
        (["a"], WildcardPattern(), []),
        (["a"], OrPattern(), []),
        (["a", "b"], NoPattern(), []),
        (["a", "b"], WildcardPattern(), []),
        (["a", "b"], OrPattern(), []),
    ]
    for arg, pattern, expected in cases:
        actual = list(NegatedPattern(pattern).generate_matches(arg))
        assert actual == expected

# Generated at 2022-06-11 20:05:34.817591
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    class MyLeaf(Leaf):
        def __init__(self, value: Text) -> None:
            super().__init__(0, value)
    a: Leaf = MyLeaf("a")
    assert a.post_order() == [a]

# Generated at 2022-06-11 20:05:44.337473
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parser import (
        PackratParser,
        is_nonterminal,
        is_whitespace,
        repr_node,
    )

    from .pgen2 import tokenize, token

    from .pgen2.grammar import Grammar, DFAParser

    from .pgen2.parse import ParseError

    import unittest

    g = Grammar()
    g["files_input"] = ([], [g.file_input, g.files_input])
    g["file_input"] = ([], [g.NEWLINE, g.eof])

    d = DFAParser(g, token.NT_OFFSET)

    s = """if 1:
    pass"""
    f = open("/tmp/tmp.py", "w")
    f.write(s)

# Generated at 2022-06-11 20:05:54.814618
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    kwds = {"type": 10, "content": None, "name": "added"}
    bp = BasePattern.__new__(BasePattern)
    bp.__init__(**kwds)
    assert bp.type == 10
    assert bp.content is None
    assert bp.name == "added"
    assert bp.optimize() is bp
    assert repr(bp) == "BasePattern(10, None, 'added')"

    #no docstring:
    #bp._submatch
    #bp.match
    #bp.match_seq
    #bp.generate_matches



# Generated at 2022-06-11 20:05:56.960367
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    x = Leaf(0, "")
    assert list(x.post_order()) == [x]

# Generated at 2022-06-11 20:06:05.399035
# Unit test for method remove of class Base
def test_Base_remove():
    source = """a = 1
    b = 2
    c = 3"""
    tree = parse_string(source)
    node = tree.children[1]
    index = node.remove()
    assert index == 1
    assert node.parent is None
    assert node not in tree.children
    assert tree.children[0].value == 'a'
    assert tree.children[1].value == 'c'
    assert tree.children[0].next_sibling.value == 'c'
    assert tree.children[1].prev_sibling.value == 'a'
    assert tree.children[1].next_sibling is None
    assert tree.children[0].prev_sibling is None



# Generated at 2022-06-11 20:06:15.794902
# Unit test for method post_order of class Node
def test_Node_post_order():
    from pprint import pprint
    from .pytree import Node
    from .pygram import python_symbols
    from .pytree import Leaf
    from . import pygram
    from .pygram import python_grammar_no_print_statement

    pygram.init_grammar(python_grammar_no_print_statement)
    def get_type(t):
        return t.type

# Generated at 2022-06-11 20:06:28.178083
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    sample = build_sample_tree()

    eq = sample.__eq__(sample)
    assert eq is True
    eq = sample.__eq__(sample.clone())
    assert eq is True
    eq = sample.__eq__(sample.parent)
    assert eq is False
    eq = sample.__eq__(sample.children[0])
    assert eq is False
    eq = sample.__eq__(sample.children[1])
    assert eq is False
    eq = sample.__eq__(sample.children[2])
    assert eq is False

    eq = sample.__eq__(sample.children[0].clone())
    assert eq is True
    eq = sample.__eq__(sample.children[1].clone())
    assert eq is True
    eq = sample.__eq__(sample.children[2].clone())