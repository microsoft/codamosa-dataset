

# Generated at 2022-06-11 19:58:18.351130
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import pytest
    from .pgen2.parse import Driver
    from .pgen2 import token

    ast_matcher = Driver(grammar=create_grammar(ast_grammar), convert=convert).ast_matcher

    v = ast_matcher.pattern_factory.from_string("expr", "<expr>")
    u = ast_matcher.pattern_factory.from_string("expr", "<expr>")

    matches = ast_matcher.match_seq([v, u], [v])
    assert list(matches) == [1]

    matches = ast_matcher.match_seq([v, u], [v, u])
    assert list(matches) == [2]

    matches = ast_matcher.match_seq([u, v], [v, v])
    assert list(matches)

# Generated at 2022-06-11 19:58:22.602544
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    n = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    l = Leaf(1, "x")
    assert l.post_order() == iter([l])
    assert list(n.post_order()) == [n.children[0], n.children[1], n.children[2], n]

# Generated at 2022-06-11 19:58:24.733096
# Unit test for function type_repr
def test_type_repr():
    assert 'LPAR' in type_repr(python_symbols.LPAR)
    assert type(type_repr(-1)) is int
test_type_repr()



# Generated at 2022-06-11 19:58:36.579010
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import iterparse
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as gram

    def p(s):
        return NodePattern(type=s)

    toptree = iterparse.classify(gram.p_suite, "a = 1")
    tree = toptree[0].children
    w = WildcardPattern(content=[tree], min=1, max=1)
    assert w.match(tree[0]), "WildcardPattern.match failed"
    optw = w.optimize()
    assert optw is tree[0], "WildcardPattern failed to optimize"
    tree = toptree[0].children
    w = WildcardPattern(content=[tree], min=0, max=1)

# Generated at 2022-06-11 19:58:38.050449
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    x = Leaf(1, "test")
    result = x.leaves()
    assert result == iter([x])


# Generated at 2022-06-11 19:58:47.864986
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Test a case where the next node is a Node
    parent = Node(syms.simple_stmt, [])
    child1 = Leaf(token.NAME, "a")
    child2 = Node(syms.power, [])
    parent.append_child(child1)
    parent.append_child(child2)
    expected = ""
    result = child1.get_suffix()
    assert result == expected
    # Test a case where the next node is a Leaf
    parent = Node(syms.power, [])
    child1 = Leaf(token.NAME, "a")
    child2 = Leaf(token.NAME, "b")
    parent.append_child(child1)
    parent.append_child(child2)
    expected = "b"
    result = child1.get_suffix()

# Generated at 2022-06-11 19:59:00.646374
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Construct a pattern that matches abc but not abcd
    abc = make_pattern('abc')
    assert abc.match_seq(['a', 'b', 'c'])
    assert not abc.match_seq(['a', 'b', 'c', 'd'])
    # Construct a pattern that matches anything but abc
    nabc = NegatedPattern(abc)
    assert nabc.match_seq(['a', 'b', 'c', 'd'])
    assert nabc.match_seq(['e', 'f', 'g'])
    assert nabc.match_seq([])
    assert not nabc.match_seq(['a', 'b', 'c'])



# Generated at 2022-06-11 19:59:06.322612
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from . import pgen2

    g = pgen2.make_grammar("""
    foo: bar
    bar: "b" "a" "r"
    """)
    t = g.parse("bar")
    p = NodePattern(g.symbol2number["bar"], None, None)

    result = list(p.generate_matches(t.children))
    assert result == [(1, {})]


# Generated at 2022-06-11 19:59:14.394914
# Unit test for method leaves of class Base
def test_Base_leaves():
    class Node(Base):
        children = []

        def _eq(self, other):
            return True

        def clone(self):
            return Node()

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

    n = Node()
    l = Leaf(1, "string", (0, 0), None)
    n.append_child(l)

    assert list(n.leaves()) == [l], list(n.leaves())
    assert list(l.leaves()) == [l], list(l.leaves())



# Generated at 2022-06-11 19:59:21.290020
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    foo = Leaf(1, "foo")
    bar = Leaf(2, "bar")
    baz = Leaf(3, "baz")
    qux = Leaf(4, "qux")
    node = Node(syms.simple_stmt, [foo, bar])
    assert foo.parent is node
    assert bar.parent is node
    node.append_child(baz)
    node.append_child(qux)
    assert baz.parent is node
    assert qux.parent is node
    leaves = list(node.leaves())
    assert leaves == [foo, bar, baz, qux]


# Generated at 2022-06-11 19:59:48.969074
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    BasePattern().optimize()
BasePattern.optimize.__dict__.__setitem__('stypy_function_name', 'test_BasePattern_optimize')
BasePattern.optimize.__dict__.__setitem__('stypy_param_names_list', [])
BasePattern.optimize.__dict__.__setitem__('stypy_varargs_param_name', None)
BasePattern.optimize.__dict__.__setitem__('stypy_kwargs_param_name', None)
BasePattern.optimize.__dict__.__setitem__('stypy_call_defaults', defaults)
BasePattern.optimize.__dict__.__setitem__('stypy_call_varargs', varargs)

# Generated at 2022-06-11 19:59:58.261043
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    #
    # whitespace = 6, newline = 4
    #
    leaf1 = Leaf(6, ' ')
    leaf2 = Leaf(4, '\n')
    leaf3 = Leaf(6, ' ')
    node1 = pytree.Node(python_symbols.simple_stmt, [leaf1, leaf2, leaf3])
    #
    # whitespace = 6, newline = 4
    #
    leaf4 = Leaf(6, ' ')
    leaf5 = Leaf(4, '\n')
    leaf6 = Leaf(6, ' ')
    node2 = pytree.Node(python_symbols.simple_stmt, [leaf4, leaf5, leaf6])


# Generated at 2022-06-11 20:00:01.799902
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(1, [])
    node.set_child(0, Node(2, [Leaf("", 3, (1, 2), None)]))
    assert node.children[0].prefix == ""



# Generated at 2022-06-11 20:00:04.249365
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    # A trivial test of Node.__repr__
    node = test_Node_Node()
    assert node.__repr__() == 'Node(256, [])'


# Generated at 2022-06-11 20:00:06.082473
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    with pytest.raises(NotImplementedError):
        Base().pre_order()

# Generated at 2022-06-11 20:00:09.734557
# Unit test for method remove of class Base
def test_Base_remove():
    from ..pytree import Leaf, Node

    n = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert n.remove() == 0
    assert len(n.children) == 0



# Generated at 2022-06-11 20:00:14.086235
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import textwrap

    def check_single(s, b):
        nodes = parse("(" + s + ")")[0]
        m = WildcardPattern().match_seq(nodes)
        if m != b:
            print("Error:", s)
            print(" expected:", b)
            print("      got:", m)

    def check(s, b):
        s = s.replace("\n", " ")
        check_single(s, b)
        # Check again, this time with an extra space at the end
        check_single(s + " ", b)

    check("", True)
    check("(a)", True)
    check("(a) (b)", True)
    check("(a) (b) (c)", False)

# Generated at 2022-06-11 20:00:15.905664
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    f = Leaf(257, "abc")
    assert list(f.leaves()) == [f]

# Generated at 2022-06-11 20:00:26.146469
# Unit test for method changed of class Base
def test_Base_changed():
    class ParentError(RuntimeError):
        pass

    class Checker(Base):
        def __init__(self, parent, children=None):
            super().__init__()
            if parent is None:
                self.parent = None
            elif isinstance(parent, Checker):
                self.parent = parent
            else:
                raise TypeError("Parent must be a Checker instance")
            self.children = children or []

        def replace(self, new):
            assert False, "Should not call replace"

        def _eq(self, other):
            if self.children != other.children:
                return False
            return True

        def clone(self):
            return Checker(self.parent, children=self.children)

        def pre_order(self):
            yield self
            for child in self.children:
                yield

# Generated at 2022-06-11 20:00:35.491749
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Node, Leaf
    a = Leaf(1, "a")
    b = Leaf(2, "b")
    c = Leaf(3, "c")
    n = Node(4, [a, b, c])
    a.parent = b.parent = c.parent = n
    assert str(n) == "(4 a b c)"
    assert str(a) == "a"
    b.replace(a)
    assert str(n) == "(4 a a c)"
    assert str(a.next_sibling) == "a"
    assert str(a.prev_sibling) == "a"
    a.replace([b, c])
    assert str(n) == "(4 b c c)"
    assert str(b.next_sibling) == "c"

# Generated at 2022-06-11 20:01:15.982424
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import random, string
    from random import randint

    class A(object):
        def __init__(self, x, y) -> None:
            self.x = x
            self.y = y

        def __eq__(self, other) -> bool:
            if isinstance(other, A):
                return self.x == other.x and self.y == other.y
            else:
                return NotImplemented

    a1 = A(1, 'a')
    a1_ditto = A(1, 'a')
    a1_different = A(1, 'b')
    a2 = A(2, 'a')
    b = 'foo'
    assert a1 == a1_ditto
    assert not (a1 == a1_different)
    assert not (a1 == a2)
   

# Generated at 2022-06-11 20:01:25.267761
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node

    def _unpack_node(n):
        return (
            n.type,
            getattr(n, "value", None),
            getattr(n, "context", None),
            list(map(_unpack_node, n.children)),
        )

    class mynode(Node):
        def _eq(self, other):
            return _unpack_node(self) == _unpack_node(other)

    node = mynode(1, [Leaf(1, "hello"), Leaf(2, "world")])
    clone = node.clone()
    assert clone is not node
    assert clone == node
    assert clone.children[1] is not node.children[1]
    assert clone.children[1] == node.children[1]



# Generated at 2022-06-11 20:01:33.666017
# Unit test for method clone of class Base
def test_Base_clone():
    tree = parse("a = 1")
    assert_equal(str(tree), "a = 1\n")
    tree2 = tree.clone()
    assert_equal(str(tree2), "a = 1\n")
    assert tree != tree2
    tree[1][0].prefix = "X"
    assert_equal(str(tree), "aX = 1\n")
    assert_equal(str(tree2), "a = 1\n")
    tree.children[1].children[0].prefix = "Y"
    assert_equal(str(tree), "aXY = 1\n")
    assert_equal(str(tree2), "a = 1\n")



# Generated at 2022-06-11 20:01:43.064589
# Unit test for method replace of class Base
def test_Base_replace():
    import blib2to3.patcomp as patcomp
    from blib2to3.pgen2.parse import ParseError

    class MyNode(patcomp.Base):
        def _eq(self, other):
            return (
                self.type == other.type and
                self.prefix == other.prefix and
                self.children == other.children
            )

        def post_order(self):
            yield self
            for child in self.children:
                yield from child.post_order()

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def clone(self):
            return MyNode(self.type, self.prefix, self.parent,
                          [c.clone() for c in self.children])


# Generated at 2022-06-11 20:01:55.385998
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
  wp = WildcardPattern(((Leaf(token.NAME, "a"),), (Leaf(token.NAME, "b"),)))
  assert wp.match_seq([Leaf(token.NAME, "a"), Leaf(token.NAME, "c")]) == False
  assert wp.match_seq([]) == True
  assert wp.match_seq([Leaf(token.NAME, "a")]) == True
  assert wp.match_seq([Leaf(token.NAME, "b")]) == True
  assert wp.match_seq([Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]) == True
  assert wp.match_seq(
      [Leaf(token.NAME, "a"), Leaf(token.NAME, "b"), Leaf(token.NAME, "d")]) == True

# Generated at 2022-06-11 20:02:06.922189
# Unit test for method post_order of class Base
def test_Base_post_order():
    def check_node(node: Node, expected: str):
        actual_list: List[str] = [leaf.prefix for leaf in node.post_order()]
        actual = "".join(actual_list)
        assert actual == expected, "Got " + actual + " but expected " + expected

    test_node: Node = Node(type=1,
                           children=[Leaf(1, "foo"),
                                     Node(2, [Leaf(3, "bar"),
                                              Leaf(4, "baz")]),
                                     Leaf(5, "quux")])
    check_node(test_node, "foobarbazquux")
    test_node.children[1].children[1].prefix = "spam"
    check_node(test_node, "foobarspamquux")
    test_

# Generated at 2022-06-11 20:02:08.917019
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class PP(BasePattern): pass
    pp = PP(256)
    n = Node(256, [])
    assert pp.match_seq([n])
    assert not pp.match_seq([n, n])


# Generated at 2022-06-11 20:02:16.647445
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from . import grammar

    t = grammar.tokenize("1+2")
    g = grammar.parse(t)
    p = NodePattern(sym.expr)
    m = list(p.generate_matches(g.children))
    assert m == [(3, {})]
    p = LeafPattern(parser.NAME)
    m = list(p.generate_matches(g.children))
    assert m == [(1, {})]



# Generated at 2022-06-11 20:02:26.325676
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    # First, test that these can match
    for (content, min_, max_), s in [
        (None, 0, HUGE),
        (None, 1, HUGE),
        (None, 0, 1),
        (((),), 0, HUGE),
        (((("a",),),), 1, HUGE),
        (((),), 0, 1),
    ]:
        w = WildcardPattern(content, min_, max_)
        assert w.content == content
        assert w.min == min_
        assert w.max == max_
        assert w.name is None
        match = NodePattern(0, s)
        assert w.match(match) == True



# Generated at 2022-06-11 20:02:38.330381
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    """Unit tests for method match_seq of class BasePattern"""
    from .pgen2 import driver as pgen_driver

    # Verify that pattern matching works in the presence of comments and
    # whitespace.
    gr = pgen_driver.load_grammar(StringIO("""
        expr: x=expr "+" y=expr                # Sum
             | x=expr "-" y=expr                # Difference
             | x=expr "*" y=expr                # Product
             | x=expr "/" y=expr                # Quotient
             | "-" x=expr                       # Negation
             | atom                             # Atom
        atom: NAME                              # Variable
             | NUMBER                           # Number
        %import common.CNAME -> NAME
        %import common.NUMBER
        %ignore " "
        """))
    l = pgen_

# Generated at 2022-06-11 20:03:00.903730
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node  # noqa
    from .pgen2 import token  # noqa

    def c(type, children=None):
        if children is None:
            children = []
        return Node(type, "", (), children)

    def l(type, value, lineno=0):
        # type: (int, Text, int) -> Leaf
        leaf = Leaf(type, value, lineno)
        leaf.parent = n  # Hack.
        return leaf

    def check(input, output):
        n = c(0)
        n.children = input
        for (kid, kid_output) in zip(n.post_order(), output):
            assert kid is kid_output

    n = c(0)

# Generated at 2022-06-11 20:03:09.524765
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # test normal case
    pattern_1 = WildcardPattern(min=1, max=1)
    assert type(pattern_1.optimize()) is NodePattern
    pattern_2 = WildcardPattern(
        content=[[NodePattern()]],
        min=1,
        max=1,
    )
    assert type(pattern_2.optimize()) is NodePattern
    # test case where optimization is not possible
    pattern_3 = WildcardPattern(
        [[WildcardPattern(min=2, max=2)]],
        min=1,
        max=1,
    )
    assert type(pattern_3.optimize()) is WildcardPattern



# Generated at 2022-06-11 20:03:20.920497
# Unit test for method generate_matches of class NegatedPattern

# Generated at 2022-06-11 20:03:29.266387
# Unit test for method leaves of class Base
def test_Base_leaves():
    for cls in (Node, Leaf):
        x = cls(syms.test_list, [Leaf(1, "foo"), Leaf(2, "bar")])
        y = cls(syms.test_list, [x, Leaf(3, "baz")])
        leaves = list(y.leaves())
        assert len(leaves) == 3, leaves
        assert leaves[0].value == "foo"
        assert leaves[1].value == "bar"
        assert leaves[2].value == "baz"



# Generated at 2022-06-11 20:03:39.066343
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    a, b, c, d, e, f = [Leaf(type_, "a") for type_ in range(256, 262)]
    tree = Node(261, [a, b, c, d, e, f])
    tree.update_sibling_maps()
    assert tree.next_sibling_map[id(a)] is b
    assert tree.next_sibling_map[id(b)] is c
    assert tree.next_sibling_map[id(c)] is d
    assert tree.next_sibling_map[id(d)] is e
    assert tree.next_sibling_map[id(e)] is f
    assert tree.next_sibling_map[id(f)] is None

    assert tree.prev_sibling_map[id(a)] is None

# Generated at 2022-06-11 20:03:45.339773
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    node1 = Leaf(1, "s1")
    node2 = Leaf(2, "s2")
    node3 = Leaf(3, "s3")
    node4 = Node(4, [node1, node2, node3])
    node5 = Leaf(5, "s5")
    node6 = Node(6, [node4, node5])
    for x in node6.pre_order():
        assert isinstance(x, Base)
    assert isinstance(node6.pre_order(), Iterator)
    assert list(node6.pre_order()) == [node6, node4, node1, node2, node3, node5]
    node1.replace(None)
    assert list(node6.pre_order()) == [node6, node4, node2, node3, node5]


# Unit test

# Generated at 2022-06-11 20:03:55.392596
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import libfuturize.fixes.fix_basestring
    node = Leaf(1, "str", fixers_applied=[libfuturize.fixes.fix_basestring.FixBasestring])
    results: Dict[Text, NL] = {}
    assert BasePattern(1).match(node, results) == True
    assert BasePattern(1, "str").match(node, results) == True
    assert BasePattern(1, "str1").match(node, results) == False
    assert BasePattern(1, libfuturize.fixes.fix_basestring.FixBasestring).match(node, results) == True
    assert BasePattern(1, libfuturize.fixes.fix_basestring.FixBasestring, "test").match(node, results) == True
    assert results['test']

# Generated at 2022-06-11 20:04:00.133358
# Unit test for function generate_matches
def test_generate_matches():
    pattern = NodePattern(type=1, name="a")
    node = NL(type=1)
    assert tuple(generate_matches([pattern], [node])[0]) == (1, {"a": [node]})



# Generated at 2022-06-11 20:04:07.820319
# Unit test for function generate_matches
def test_generate_matches():
    assert list(generate_matches([], [])) == [(0, {})]
    assert list(generate_matches([NodePattern(type=token.NAME)], [Name('foo')])) == [(1, {})]
    assert list(generate_matches([NodePattern(type=token.NAME)], [Str('foo')])) == []
    assert list(generate_matches([NodePattern(type=token.NAME), NodePattern(type=token.STRING)], [Name('foo'), Str('foo')])) == [(2, {})]
    assert list(generate_matches([NodePattern(type=token.NAME), NodePattern(type=token.STRING)], [Str('foo'), Name('foo')])) == []

# Generated at 2022-06-11 20:04:09.478791
# Unit test for method depth of class Base
def test_Base_depth():
    assert Base().depth() == 0
    assert Node(1, [Node(1)]).depth() == 1


# Generated at 2022-06-11 20:05:12.892235
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import pytest
    from .antlr3.tree import Tree  # type: ignore
    from .common import Node  # type: ignore
    import re

    class TestWildcardPattern(WildcardPattern):
        def __init__(self, content="(c | d*) e", name="bare_name"):
            assert isinstance(content, str), repr(content)
            wrapped_content = []
            for token in re.findall(r"\(.*?\)", content):
                wrapped_content.append(
                    tuple(
                        Leaf(WildcardPattern.symbol_names.index(symbol.strip()))
                        for symbol in token[1:-1].split("|")
                    )
                )

# Generated at 2022-06-11 20:05:20.952235
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # More detailed tests are in test_ast_helper.py
    nodes = [Node(value=i) for i in "abcdefg"]
    patterns = [
        "ab",
        "ab|c",
        "ab|c|d",
        "ab|c|d|e",
        "ab|c|d|e|f",
    ]
    for i, pattern in enumerate(patterns):
        print(pattern)
        pt = parse_pattern(pattern)
        pt = pt.optimize()
        print("* pt", pt)
        j = 0
        for c, r in pt.generate_matches(nodes):
            print("*", c, r)
            j += 1
        assert j == 2 + i

# Helper methods for pattern matching

# Generated at 2022-06-11 20:05:28.663485
# Unit test for method post_order of class Node
def test_Node_post_order():
    n = Node(3, [
        Node(4, []),
        Node(5, [
            Leaf(1, "foo"),
        ]),
    ])
    assert list(n.post_order()) == [
        Node(4, []),
        Leaf(1, "foo"),
        Node(5, [
            Leaf(1, "foo"),
        ]),
        Node(3, [
            Node(4, []),
            Node(5, [
                Leaf(1, "foo"),
            ]),
        ])
    ]

# Generated at 2022-06-11 20:05:38.607752
# Unit test for method remove of class Base
def test_Base_remove():
    # Test the method remove of class Base
    a = Node(1, 2)
    b = Node(2, 3)
    c = Node(3)

    a.remove()
    assert a.parent is None

    a.append_child(b)
    assert b.parent is a
    assert b.remove() == 0
    assert b.parent is None

    a.append_child(b)
    a.append_child(c)
    assert c.parent is a
    assert c.remove() == 1
    assert c.parent is None

    # Test that removing a node invalidates sibling maps
    a.append_child(b)
    a.append_child(c)
    assert c.next_sibling is None
    assert b.next_sibling is c
    assert b.prev_sibling is None

# Generated at 2022-06-11 20:05:46.801791
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from . import pytree
    from .pgen2 import token
    name = pytree.Leaf(token.NAME, 'name')
    name2 = pytree.Leaf(token.NAME, 'name')
    namenot = pytree.Leaf(token.NAME, 'namenot')
    dot = pytree.Leaf(token.DOT, '.')
    namenot2 = pytree.Leaf(token.NAME, 'namenot')
    namenot3 = pytree.Leaf(token.NAME, 'namenot')
    namenot4 = pytree.Leaf(token.NAME, 'namenot')
    assert name == name2
    assert not name == namenot
    name.prefix = 'a'
    name2.prefix = 'b'
    assert name == name2
   

# Generated at 2022-06-11 20:05:59.523087
# Unit test for method clone of class Base

# Generated at 2022-06-11 20:06:03.287862
# Unit test for method leaves of class Base
def test_Base_leaves():
    lineno = 2
    base = Base()
    base.lineno = lineno
    for leaf, expected in [
            (base, []),
            ]:
        with pytest.raises(NotImplementedError):
            got = list(leaf.leaves())
        assert got == expected

# Generated at 2022-06-11 20:06:10.784212
# Unit test for method depth of class Base
def test_Base_depth():
    root = Node(1, [Leaf(1, "foo"), Node(2, [Leaf(2, "bar")])])
    assert root.depth() == 0
    assert root.children[0].depth() == 1
    assert root.children[1].depth() == 1
    assert root.children[1].children[0].depth() == 2

# Generated at 2022-06-11 20:06:17.736466
# Unit test for method replace of class Base
def test_Base_replace():
    t = pytree.Node(1, [pytree.Leaf(1, "a"), pytree.Leaf(1, "b")])
    assert t.children[0].next_sibling is t.children[1]
    t.children[0].replace(pytree.Node(1, [pytree.Leaf(1, "1"), pytree.Leaf(1, "2")]))
    assert t.children[0].next_sibling is t.children[1]
    t.children[0].replace([pytree.Leaf(1, "1"), pytree.Leaf(1, "2")])
    assert t.children[0].next_sibling is t.children[1]
    t.children[0].replace(pytree.Leaf(1, "1"))

# Generated at 2022-06-11 20:06:30.082209
# Unit test for method replace of class Base
def test_Base_replace():
    from . import pytree as p
    root_sym = p.syms.file_input
    root_exps = [
        p.Leaf(p.token.NUMBER, "1", (1, 0)),
        p.Leaf(p.token.PLUS, "+", (1, 2)),
        p.Leaf(p.token.NUMBER, "2", (1, 4)),
    ]
    root = p.Node(root_sym, root_exps)
    number = root.children[0]
    number.replace(
        [
            p.Leaf(p.token.NUMBER, "0", (1, 0)),
            p.Leaf(p.token.NEWLINE, "\n", (1, 2)),
        ])