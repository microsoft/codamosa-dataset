

# Generated at 2022-06-11 19:58:46.290688
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from grako.parsing import Pattern
    # pylint: disable=no-member

    t1 = Leaf(1, '1')
    t2 = Leaf(1, '2')
    t3 = Leaf(1, '3')
    t4 = Leaf(1, '4')
    t5 = Leaf(1, '5')

    t123 = Node(2, [t1, t2, t3])
    t45 = Node(2, [t4, t5])

    t12345 = Node(3, [t123, t45])

    p1 = NodePattern(type=1)
    p2 = NodePattern(type=2)
    p3 = NodePattern(type=3)
    p12 = NodePattern(type=2, content=[p1, p2])

# Generated at 2022-06-11 19:58:50.559401
# Unit test for method remove of class Base
def test_Base_remove():
    class MyNode(Node):
        def __init__(self):
            super().__init__()
            self.children = [self]
    n = MyNode()
    assert n.remove() == 0
    assert n.parent is None



# Generated at 2022-06-11 19:58:52.601754
# Unit test for method leaves of class Base
def test_Base_leaves():
    """Method leaves of class Base"""
    # XXX

# Generated at 2022-06-11 19:58:59.525414
# Unit test for method set_child of class Node
def test_Node_set_child():
  new_node = Node(1, [Leaf(1, 'x')])
  new_node.set_child(0, Leaf(1, 'y'))
  print(new_node.children == [Leaf(1, 'y')])
  print(new_node.children[0].parent == new_node)


# Generated at 2022-06-11 19:59:08.552597
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    leaf1 = Leaf(1, "foo")
    leaf2 = Leaf(1, "bar")
    leaf3 = Leaf(2, "spam")
    node1 = Node(3, [leaf1, leaf2])
    node2 = Node(3, [leaf3, leaf1])
    patterns = [
        LeafPattern(1, "bar"),
        LeafPattern(1, "foo"),
        LeafPattern(2, "spam"),
        NodePattern(3, [LeafPattern(1), LeafPattern(1)]),
        NodePattern(3, [LeafPattern(2), LeafPattern(1)]),
    ]
    for pattern in patterns:
        assert pattern.match(leaf1)
        assert pattern.match(leaf2)
        assert pattern.match(leaf3)
        assert pattern.match(node1)

# Generated at 2022-06-11 19:59:19.653048
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2 import parse, tokenize, grammar
    from .pgen2.driver import Driver
    from .pgen2.token import literal_token_re
    import re
    import sys
    import io

    def test(i_str, o_str, *, n_str=None, v_str=None, d_str=None, g_str=None, sort=False):
        if not n_str:
            n_str = 'ws'
        if v_str:
            v = 'value'
        else:
            v = 'None'
        if d_str:
            d_str = 'tokenize.NL'
        else:
            d_str = 'None'
        if g_str:
            g_str = 'True'
       

# Generated at 2022-06-11 19:59:28.839598
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = WildcardPattern(
        content=[[NodePattern(type=tokenize.NAME)], [NodePattern(type=tokenize.NUMBER)]],
        min=1,
        max=1,
        name="bare_name",
    )

    for count, r in pattern.generate_matches([],):
        assert(count == 0)

    for count, r in pattern.generate_matches([LeafPattern(type=tokenize.NAME, value="foo")],):
        assert(count == 1)

    for count, r in pattern.generate_matches([LeafPattern(type=tokenize.NUMBER, value="1")],):
        assert(count == 1)


# Generated at 2022-06-11 19:59:38.668467
# Unit test for constructor of class NodePattern
def test_NodePattern():
    import pytest
    pattern = NodePattern(type=257, content=())
    assert pattern.type == 257
    assert pattern.content == ()
    assert pattern.wildcards == False
    pattern = NodePattern(type=257, content=(LeafPattern(), LeafPattern()))
    assert pattern.type == 257
    assert pattern.content == (LeafPattern(), LeafPattern())
    assert pattern.wildcards == False
    pattern = NodePattern(type=257, content=(WildcardPattern(), WildcardPattern()))
    assert pattern.type == 257
    assert pattern.content == (WildcardPattern(), WildcardPattern())
    assert pattern.wildcards == True
    pattern = NodePattern(type=257, content=('foo', 'bar'))
    assert pattern.type == 257

# Generated at 2022-06-11 19:59:49.291361
# Unit test for method post_order of class Base
def test_Base_post_order():
    with open('tests/tree.py') as f:
        source = f.read() + '\n'
    from grammar_parser.pgen2 import driver as pgen2_driver
    from blib2to3.pgen2 import tokenize
    from io import StringIO
    from . import fixer_base

    p = pgen2_driver.load_grammar('Grammar.txt')
    p.driver.make_pgen(False)

    class Parser(fixer_base.BaseFix):
        def parse_file(self, f: StringIO, fname: Text) -> None:
            self.grammar = p
            super(Parser, self).parse_file(f, fname)
            self.grammar = None


# Generated at 2022-06-11 19:59:57.522483
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    import pytest
    from .pgen2.token import tokenize_new, NAME
    from .pgen2.grammar import Grammar

    _, tokens = tokenize_new("def test(): pass")
    p = Grammar(tokenize_new).parse(tokens)
    assert len(p.children) == 1
    node = Node(NAME, p.children)


# Generated at 2022-06-11 20:00:13.766443
# Unit test for method post_order of class Node
def test_Node_post_order():
    assert False, "Implement the test!"

# Generated at 2022-06-11 20:00:24.444217
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    x = WildcardPattern([[NodePattern(), NodePattern(), NodePattern()]], min=1, max=1)
    x = WildcardPattern([x], min=1, max=1)
    x = WildcardPattern([x], min=1, max=1)
    x = WildcardPattern([x], min=1, max=1)
    y = x.optimize()
    assert y == x
    x = WildcardPattern([[NodePattern()]], min=1, max=1)
    x = WildcardPattern([x], min=1, max=1)
    y = x.optimize()
    assert y == x
    x = WildcardPattern([[NodePattern()]], min=1, max=1)
    y = x.optimize()
    assert y == NodePattern()

# Generated at 2022-06-11 20:00:34.849131
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    import pickle
    from .pgen2.pgen import (
        BasePattern,
        PatternTreeBuilder,
        NodePattern,
        LeafPattern,
        WildcardPattern,
    )
    from .pgen2.token import tok_name

    assert BasePattern.optimize is not object.__init__
    tree_builder = PatternTreeBuilder(None)

    n1 = tree_builder.build_pattern(
        "if_stmt",
        [
            "NAME",
            ["test", "or_test", ["and_test", "not_test", "comparison", "expr"]],
            ["NAME", "test"],
        ],
    )
    assert isinstance(n1, NodePattern)

# Generated at 2022-06-11 20:00:43.822394
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pgen2 import token
    tree = Node(token.IF, [Leaf(token.NAME, 'a'), Leaf(token.NAME, 'b')])
    result = []
    for t in tree.post_order():
        result.append(t)
    assert result == [Leaf(token.NAME, 'a'), Leaf(token.NAME, 'b'),
                      Node(token.IF, [Leaf(token.NAME, 'a'),
                                      Leaf(token.NAME, 'b')])]

# Generated at 2022-06-11 20:00:54.151068
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    import unittest
    from test.support import captured_stdout
    from .pgen2.token import tok_name

    class MyTestCase(unittest.TestCase):
        def test_Leaf(self):
            l = Leaf(1, "abc")
            with captured_stdout() as output:
                for x in l.pre_order():
                    print(tok_name.get(x.type, "<unknown>"), end="\n")
            output.seek(0)
            data = output.read()
            self.assertEqual(data, "\n\n")

    MyTestCase().test_Leaf()



# Generated at 2022-06-11 20:00:54.924401
# Unit test for method depth of class Base
def test_Base_depth():
    pass



# Generated at 2022-06-11 20:01:06.131131
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.file_input) == "file_input"
    assert type_repr(python_symbols.comp_op) == "comp_op"
    # Test both branches
    assert type_repr(HUGE) == HUGE
    assert type_repr(HUGE + 1) == (HUGE + 1)


# This can be used to add fields to the tree nodes.
# (The field names must start with an underscore.)
_extra_types: Dict[int, Set[str]] = {}

# A simple tree type: a list of children.
# Note that the nodes in a sequence are restricted to a single type.
_fields: Dict[int, Sequence[int]] = {}

# Add extra fields to a node type.  Use a list because we support
# multiple inheritance.  The

# Generated at 2022-06-11 20:01:18.452566
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import pytest
    
    class Node(Base):
        def __init__(self, children):
            self.children = children
            for child in children:
                child.parent = self
        def _eq(self, other): return (type(self) == type(other) and
                                      self.children == other.children)
        def clone(self):
            return type(self)([child.clone() for child in self.children])
        def post_order(self): return (child.post_order() for child in self.children)
        def pre_order(self): return iter([self] + [child for child in self.children])
    
    class Leaf(Base):
        def __init__(self, value):
            self.value = value
        def _eq(self, other): return type(self) == type(other)

# Generated at 2022-06-11 20:01:26.302865
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name  # NOQA

    def test(operator, pattern, case):
        expected, node = case
        actual = operator(pattern, node)
        if actual != expected:
            print(
                f"operator={operator!r}, pattern={pattern!r}, node={node!r}, "
                f"expected={expected!r}, actual={actual!r}"
            )

    # LeafPattern
    pattern = LeafPattern(op.COMMA)  # NOQA
    for operator in [pattern.match, pattern.match_seq, pattern.generate_matches]:
        yield test, operator, pattern, (False, Node(1, []))
        yield test, operator, pattern, (False, Leaf(op.PLUS, ""))

# Generated at 2022-06-11 20:01:29.156375
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    lf = Leaf(1, "")
    assert list(lf.leaves()) == [lf]


# Generated at 2022-06-11 20:03:14.237407
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import token

    OPEN_BRACKET = token.OPEN_BRACKET
    NUMBER = token.NUMBER
    COMMA = token.COMMA

    for pattern_class in LeafPattern, NodePattern:
        for nodes in [[Leaf(OPEN_BRACKET, "(")]]:
            pattern = pattern_class(OPEN_BRACKET)
            assert list(pattern.generate_matches(nodes)) == [(1, {})]

# Generated at 2022-06-11 20:03:24.169499
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    class Leaf(Base):
        def __init__(self, type, value, context):
            self.type = type
            self.value = value
            self.context = context
        def _eq(a, b):
            return a.type == b.type and a.value == b.value
        def clone(self):
            return Leaf(self.type, self.value, self.context)
        pre_order = post_order = lambda self: iter([self])
        def __repr__(self):
            return 'Leaf(%r, %r)' % (self.type, self.value)
        @property
        def prefix(self):
            return self.value
    class Node(Base):
        def __init__(self, type, children=None):
            self.type = type

# Generated at 2022-06-11 20:03:25.219451
# Unit test for method remove of class Base
def test_Base_remove():
    assert "Base.remove"



# Generated at 2022-06-11 20:03:36.172836
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from . import pytree
    from .pygram import python_symbols as sympy
    from .pygram import python_grammar as pgen_gram

    tree_str = "if True:\n\tpass\nelse:\n\traise"
    pgen_grammar = pgen_gram.pgen_grammar
    py_gram = Grammar(pgen_grammar, pgen_grammar_re, {}, type_repr)
    py_gram.add_module(pytree)
    py_gram.build()
    t = py_gram.parse_string(tree_str, "file_input")
    # This is equivalent to Base.pre_order, but we want to explicitly test
    # this method.
    def pre_order_iter(top: Node) -> Iterator["Leaf"]:
        yield

# Generated at 2022-06-11 20:03:42.097064
# Unit test for method replace of class Base
def test_Base_replace():
    # Test case where there's just one child
    class Example1(Node):
        """Example where the Node contains a single child."""

    tree = Example1(Example1(Leaf(1, "")), Example1(Leaf(2, "")))

# Generated at 2022-06-11 20:03:53.287795
# Unit test for method match_seq of class WildcardPattern

# Generated at 2022-06-11 20:04:05.509610
# Unit test for function generate_matches
def test_generate_matches():

    class A(Node):
        pass

    class B(Node):
        pass

    class C(Node):
        pass

    class D(Node):
        pass

    class E(Node):
        pass

    class F(Node):
        pass

    class G(Node):
        pass

    class H(Node):
        pass

    class I(Node):
        pass

    class About(Node):
        pass

    class You(Node):
        pass

    class Me(Node):
        pass


# Generated at 2022-06-11 20:04:10.785323
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():

    # The method is called here.
    l = Leaf(0, 1)
    leaves = l.post_order()
    assert l in leaves

    # The method is called here.
    l = Leaf(0, 1)
    leaves = l.pre_order()
    assert l in leaves

    # The method is called here.
    l = Leaf(0, 1)
    leaves = l.leaves()
    assert l in leaves

# Generated at 2022-06-11 20:04:17.177510
# Unit test for function generate_matches
def test_generate_matches():
    patterns = [
        NodePattern(type=syms.number),
        NodePattern(type=token.PLUS),
        NodePattern(type=syms.number),
    ]

    nodes = [
        NL(type=syms.number, value=10),
        NL(type=token.PLUS, value="+"),
        NL(type=syms.number, value=20),
    ]

    assert list(generate_matches(patterns, nodes)) == [(3, {})]



# Generated at 2022-06-11 20:04:20.066637
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    l = Leaf(2, "abcd")
    basePattern = BasePattern()
    it = basePattern.generate_matches([l])
    assert type(it) == types.GeneratorType



# Generated at 2022-06-11 20:04:54.523552
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    plist = [syms.classdef, syms.async_stmt, syms.funcdef]
    pattern = NegatedPattern(
        WildcardPattern(
            [
                [LeafPattern(token.NAME)],
                [LeafPattern(token.NAME), NodePattern(syms.dotted_name)],
            ],
            min=0,
            max=1,
            name="bare_name",
        )
    )
    node = [Leaf(1, "async"), Leaf(4, "def"), Leaf(0, "fname"), Leaf(1, "(")]
    result = pattern.match_seq(node)
    assert result, "Negated pattern failed to match: {}".format(node)



# Generated at 2022-06-11 20:05:00.277620
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import driver

    gr = driver.load_grammar("simple2.cfg")
    p = LeafPattern(type=1)
    assert p.match_seq([Leaf(type=1, value="int", prefix=" ")])
    assert not p.match_seq([Leaf(type=2, value="int", prefix=" ")])
    assert not p.match_seq([])



# Generated at 2022-06-11 20:05:06.563179
# Unit test for method replace of class Base
def test_Base_replace():
    test_node = Node()
    test_node.changed()
    new_node = Node()
    new_node.children.append(Node())
    new_node.children[0].parent = new_node
    for item in new_node.children:
        assert item.parent == new_node
    test_node.replace(new_node)
    assert test_node.parent is None
    assert new_node.parent is not None



# Generated at 2022-06-11 20:05:10.925291
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    """
    >>> p = LeafPattern(TOKEN.NAME, "x")
    >>> list(p.generate_matches([Leaf(TOKEN.NAME, "x")]))
    [(1, {'x': Leaf(1, 'x')})]
    """



# Generated at 2022-06-11 20:05:19.955734
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    assert NodePattern(type=1).match_seq([Leaf(1, "x")])
    assert not NodePattern(type=1).match_seq([Leaf(2, "x")])
    assert WildcardPattern().match_seq([Leaf(1, "x")])
    assert WildcardPattern().match_seq([])
    assert WildcardPattern(min=1).match_seq([Leaf(1, "x")])
    assert not WildcardPattern(min=1).match_seq([])
    assert WildcardPattern(min=2).match_seq([Leaf(1, "x"), Leaf(2, "x")])
    assert not WildcardPattern(min=2).match_seq([])
    assert WildcardPattern(min=2).match_seq([Leaf(1, "x")])

# Generated at 2022-06-11 20:05:26.074680
# Unit test for method remove of class Base
def test_Base_remove():
    from .pgen2 import token
    root = Node(token.one, [Leaf(token.two, "two"), Leaf(token.three, "three")])
    child2 = root.children[1]
    assert child2.remove() == 1
    assert child2.parent is None
    assert child2.next_sibling is None
    assert child2.prev_sibling is None
    assert child2.depth() == 0



# Generated at 2022-06-11 20:05:28.431398
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "x")
    assert leaf.post_order() == [leaf]
    

# Generated at 2022-06-11 20:05:38.494483
# Unit test for method depth of class Base
def test_Base_depth():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.pgen import Tokenizer
    import re

    # Initialization

    class Tree_Structure_Error(Exception):
        """Exception raised when a tree structure is unexpected."""
        pass

    # Utility functions

    def show_tree(node, indent=""):
        """Show a tree."""
        print(indent + repr(node))
        for ch in node.children:
            show_tree(ch, indent + "  ")

    def check_tree(node, expected_node, expected_children):
        """Check the tree structure."""

# Generated at 2022-06-11 20:05:40.640423
# Unit test for method post_order of class Base
def test_Base_post_order():
    '''Unit test for method post_order of class Base'''
    assert 1

# Generated at 2022-06-11 20:05:43.850950
# Unit test for method replace of class Base
def test_Base_replace():
    a = Leaf(1, "abc")
    a.parent = Node(2, [])
    a.replace(a)
    assert a.parent is None, a.parent

