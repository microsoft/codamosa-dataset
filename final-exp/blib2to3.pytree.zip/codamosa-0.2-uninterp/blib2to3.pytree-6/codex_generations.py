

# Generated at 2022-06-17 17:02:49.412565
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import dump
    from . import findall
    from . import find
    from . import search
    from . import match
    from . import compile
    from . import walk
    from . import visit
    from . import visit_all
    from . import visit_all_postorder
    from . import visit_all_topdown
    from . import visit_all_topdown_postorder
    from . import visit_all_topdown_postorder_filtered
    from . import visit_all_topdown_postorder_filtered_with_children
    from . import visit_all_topdown_postorder_with_children
    from . import visit_all_topdown_with_children
    from . import visit_all_with_children
    from . import visit_filtered
    from . import visit_filtered

# Generated at 2022-06-17 17:03:01.824797
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import pretty_tree
    from . import tree_format
    from . import tree_pattern
    from . import tree_transform
    from . import tree_utils
    import io
    import sys

    def test(pattern, tree):
        print("pattern:", pattern)
        print("tree:", pretty_tree.pretty_tree(tree))
        p = tree_pattern.parse_pattern(pattern)
        print("p:", p)
        for c, r in p.generate_matches([tree]):
            print("c:", c)
            print("r:", r)
            print()

    test("!(a)", parse.parse("a"))
    test("!(a)", parse.parse("b"))
    test("!(a b)", parse.parse("a"))

# Generated at 2022-06-17 17:03:13.041698
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    p = LeafPattern(1, "foo")
    assert repr(p) == "LeafPattern(NUMBER, 'foo')"
    p = LeafPattern(1, "foo", "bar")
    assert repr(p) == "LeafPattern(NUMBER, 'foo', 'bar')"
    p = NodePattern(2, "foo")
    assert repr(p) == "NodePattern(NAME, 'foo')"
    p = NodePattern(2, "foo", "bar")
    assert repr(p) == "NodePattern(NAME, 'foo', 'bar')"
    p = WildcardPattern(2, "foo")
    assert repr(p) == "WildcardPattern(NAME, 'foo')"
    p = WildcardPattern(2, "foo", "bar")
   

# Generated at 2022-06-17 17:03:20.110168
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node

    n = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert n.children[1].remove() == 1
    assert n.children == [Leaf(1, "a"), Leaf(1, "c")]
    assert n.children[1].remove() == 1
    assert n.children == [Leaf(1, "a")]
    assert n.children[0].remove() == 0
    assert n.children == []



# Generated at 2022-06-17 17:03:27.779676
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.token import tok_name

    # Test that optimize() works
    g = generate_grammar("""
    expr:
        | expr '+' expr
        | expr '*' expr
        | '(' expr ')'
        | NAME
    """)
    d = Driver(g, convert)
    try:
        tree = d.parse("a + b * c", "expr")
    except ParseError:
        pass
    else:
        assert tree.type == g.symbol2number["expr"]
        assert tree.children[0].type == g.symbol2

# Generated at 2022-06-17 17:03:32.343981
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2.grammar import Grammar

    g = Grammar()
    p = NodePattern(g.number2symbol[g.symbol2number["file_input"]])
    assert p.type == g.symbol2number["file_input"]
    assert p.content is None
    assert p.name is None
    p = NodePattern(g.number2symbol[g.symbol2number["file_input"]], [])
    assert p.type == g.symbol2number["file_input"]
    assert p.content == []
    assert p.name is None
    p = NodePattern(g.number2symbol[g.symbol2number["file_input"]], [], "foo")
    assert p.type == g.symbol2number["file_input"]
    assert p.content == []


# Generated at 2022-06-17 17:03:43.801506
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    n = Node(0, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    n.update_sibling_maps()
    assert n.prev_sibling_map[id(n.children[0])] is None
    assert n.prev_sibling_map[id(n.children[1])] is n.children[0]
    assert n.prev_sibling_map[id(n.children[2])] is n.children[1]
    assert n.next_sibling_map[id(n.children[0])] is n.children[1]
    assert n.next_sibling_map[id(n.children[1])] is n.children[2]

# Generated at 2022-06-17 17:03:51.630852
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree

# Generated at 2022-06-17 17:03:54.701820
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2.grammar import Grammar

    g = Grammar()
    p = NodePattern(g.number2symbol[g.symbol2number["file_input"]])



# Generated at 2022-06-17 17:04:05.361865
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2.token import Token
    from .pgen2 import token
    from . import fixer_base
    from .fixer_util import Name, Call, Comma, String, ArgList, Dot, Number
    from .fixer_util import LParen, RParen, Newline, KeywordArg, ArgList
    from .fixer_util import Attr, Node, Leaf
    from .fixer_util import syms
    from .fixer_util import token
    from .fixer_util import String, Number, Name, KeywordArg, Comma, RParen
    from .fixer_util import LParen, RParen, ArgList, Node, Leaf
    from .fixer_util import sy

# Generated at 2022-06-17 17:04:28.019557
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytokenize

# Generated at 2022-06-17 17:04:39.926510
# Unit test for constructor of class NodePattern
def test_NodePattern():
    import pytest
    from .pgen2.token import tok_name

    # Test that NodePattern() raises an exception if the content
    # argument is a string
    with pytest.raises(AssertionError):
        NodePattern(content="foo")

    # Test that NodePattern() raises an exception if the content
    # argument is not a sequence of Patterns
    with pytest.raises(AssertionError):
        NodePattern(content=["foo"])

    # Test that NodePattern() raises an exception if the type
    # argument is not a symbol type
    with pytest.raises(AssertionError):
        NodePattern(type=tok_name["NAME"])

    # Test that NodePattern() raises an exception if the type
    # argument is None and the content argument is not None

# Generated at 2022-06-17 17:04:51.380032
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert repr(LeafPattern(1, "foo")) == "LeafPattern(NUMBER, 'foo')"
    assert repr(LeafPattern(1, "foo", "bar")) == "LeafPattern(NUMBER, 'foo', 'bar')"
    assert repr(LeafPattern(1, "foo", None)) == "LeafPattern(NUMBER, 'foo')"
    assert repr(LeafPattern(1, None, "bar")) == "LeafPattern(NUMBER, None, 'bar')"
    assert repr(LeafPattern(1, None, None)) == "LeafPattern(NUMBER)"
    assert repr(NodePattern(257, "foo")) == "NodePattern(NAME, 'foo')"

# Generated at 2022-06-17 17:05:00.053815
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node

    tree = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert list(tree.post_order()) == [tree.children[0], tree.children[1], tree.children[2], tree]
    tree = Node(1, [Leaf(1, "a"), Node(1, [Leaf(1, "b"), Leaf(1, "c")]), Leaf(1, "d")])
    assert list(tree.post_order()) == [tree.children[0], tree.children[1].children[0], tree.children[1].children[1], tree.children[1], tree.children[2], tree]

# Generated at 2022-06-17 17:05:12.118137
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.grammar import Grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import Lark
    from .pgen2.pgen import Nonterminal
    from .pgen2.pgen import Symbol
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import convert
    from .pgen2.pgen import _Results
    from .pgen2.pgen import _match_seq
    from .pgen2.pgen import _match_seq_gre

# Generated at 2022-06-17 17:05:24.418449
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    def _test(s, expected):
        try:
            driver = Driver(Grammar(StringIO(s)), convert)
            tree = driver.parse_tokens(driver.tokenize(StringIO(s)))
        except ParseError:
            tree = None
        if tree is None:
            tree = []
        else:
            tree = list(tree.pre_order())
        pattern = LeafPattern(tok_name["NAME"])
        matches = list(pattern.generate_matches(tree))
        assert matches == expected, repr(matches)

    _test("", [])

# Generated at 2022-06-17 17:05:30.739997
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import Nonterminal
    from .pgen2.pgen import Pattern
    from .pgen2.pgen import Token
    from .pgen2.pgen import Wildcard
    from .pgen2.pgen import generate_matches
    from .pgen2.pgen import match_seq
    from .pgen2.pgen import match_seq_with_results
    from .pgen2.pgen import match_with_results
    from .pgen2.pgen import parse_grammar

# Generated at 2022-06-17 17:05:40.312968
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import py

# Generated at 2022-06-17 17:05:50.728064
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def check(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        result = list(pattern.generate_matches(nodes))
        assert result == expected, (pattern, nodes, result)

    check(".*", "", [(0, {})])
    check(".*", "a", [(1, {})])
    check(".*", "a b", [(2, {})])
    check(".*", "a b c", [(3, {})])
    check(".+", "", [])
    check(".+", "a", [(1, {})])
    check(".+", "a b", [(2, {})])
    check(".+", "a b c", [(3, {})])

# Generated at 2022-06-17 17:06:00.919324
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        assert node.get_suffix() == expected

    def check_all(node, expected):
        check(node, expected)
        for child in node.children:
            check_all(child, expected)

    # Test a simple case
    tree = pytree.Node(syms.simple_stmt, [
        Leaf(1, "x"),
        Leaf(1, "="),
        Leaf(1, "1"),
        Leaf(1, ";"),
        Leaf(1, "y"),
        Leaf(1, "="),
        Leaf(1, "2"),
        Leaf(1, ";"),
    ])
    check_all(tree, ";")

# Generated at 2022-06-17 17:07:02.168690
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test that the node is removed from its parent's children list
    node = Leaf(1, "test")
    parent = Node(syms.simple_stmt, [node])
    assert parent.children == [node]
    node.remove()
    assert parent.children == []

    # Test that the node's parent is set to None
    node = Leaf(1, "test")
    parent = Node(syms.simple_stmt, [node])
    assert node.parent is parent
    node.remove()
    assert node.parent is None

    # Test that the node is removed from its parent's children list
    # even if it's not the first child
    node = Leaf(1, "test")


# Generated at 2022-06-17 17:07:13.153789
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def test_eq(a, b):
        assert a == b
        assert not (a != b)
        assert not (a < b)
        assert a <= b
        assert not (a > b)
        assert a >= b

    def test_ne(a, b):
        assert not (a == b)
        assert a != b
        assert a < b or b < a
        assert a <= b or b <= a
        assert a > b or b > a
        assert a >= b or b >= a

    def test_lt(a, b):
        assert not (a == b)
        assert a != b
        assert a < b

# Generated at 2022-06-17 17:07:17.241467
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    import sys
    import os
    import unittest
    from .pgen2.token import tok_name
    from .pgen2.parse import parse_file
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import generate_grammar
    from .pgen2.pgen import driver
    from .pgen2.pgen import main
    from .pgen2.pgen import _main
    from .pgen2.pgen import _parse_args
    from .pgen2.pgen import _parse_grammar
    from .pgen2.pgen import _generate_grammar
    from .pgen2.pgen import _generate_tables
    from .pgen2.pgen import _generate_parser
    from .pgen2.pgen import _gener

# Generated at 2022-06-17 17:07:29.040606
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    g = Grammar()
    g.add_production("a", ("b",))
    g.add_production("b", ("c",))
    g.add_production("c", ("d",))
    g.add_production("d", ("e",))
    g.add_production("e", ("f",))
    g.add_production("f", ("g",))
    g.add_production("g", ("h",))
    g.add_production("h", ("i",))
    g.add_production("i", ("j",))
    g.add_production("j", ("k",))
    g.add_production("k", ("l",))
    g.add_production("l", ("m",))

# Generated at 2022-06-17 17:07:33.257818
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    l = Leaf(1, "a")
    l.prefix = "b"
    l.lineno = 1
    l.column = 2
    l.fixers_applied = [1, 2, 3]
    l2 = l.clone()
    assert l2.type == 1
    assert l2.value == "a"
    assert l2.prefix == "b"
    assert l2.lineno == 1
    assert l2.column == 2
    assert l2.fixers_applied == [1, 2, 3]
    assert l2.parent is None
    assert l2.children == []
    assert l2.was_changed is False
    assert l2.prev_sibling_map is None
    assert l2.next_sibling_map is None
    assert l2.bracket_depth == 0


# Generated at 2022-06-17 17:07:43.782625
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import convert
    from .pgen2.pgen import type_repr
    from .pgen2.pgen import _Results
    from .pgen2.pgen import _Results
    from .pgen2.pgen import _Results

# Generated at 2022-06-17 17:07:51.706170
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test replacement of a leaf
    leaf = Leaf(1, "foo")
    leaf.parent = Node(syms.simple_stmt, [leaf])
    leaf.replace(Leaf(1, "bar"))
    assert leaf.parent is None
    assert leaf.next_sibling is None
    assert leaf.prev_sibling is None
    assert leaf.prefix == "foo"
    assert leaf.value == "foo"
    assert leaf.changed() is None
    assert leaf.remove() is None
    assert leaf.get_lineno() is None
    assert leaf.get_suffix() == ""
    assert leaf.depth() == 0
    assert leaf.leaves() == []

# Generated at 2022-06-17 17:08:04.541731
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.token import tok_name

    class LeafPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            if self.content is None:
                return True
            if not isinstance(node, Leaf):
                return False
            if self.content == node.value:
                return True
            return False

        def match(self, node, results=None):
            if not isinstance(node, Leaf):
                return False
            return BasePattern.match(self, node, results)

        def match_seq(self, nodes, results=None):
            if len(nodes) != 1:
                return False
            return

# Generated at 2022-06-17 17:08:17.571778
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import_statement_no_assert_statement
    from . import python_grammar_no_print_statement

# Generated at 2022-06-17 17:08:19.855007
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "a")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-17 17:08:44.122193
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver

# Generated at 2022-06-17 17:08:49.419440
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram

    def _test_leaves(node, expected):
        result = list(node.leaves())
        assert result == expected, (result, expected)

    def _test_leaves_str(node, expected):
        result = list(node.leaves())
        assert [leaf.value for leaf in result] == expected, (result, expected)

    def _test_leaves_type(node, expected):
        result = list(node.leaves())
        assert [leaf.type for leaf in result] == expected, (result, expected)

    def _test_leaves_prefix(node, expected):
        result = list(node.leaves())

# Generated at 2022-06-17 17:08:53.942198
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        assert list(node.leaves()) == expected

    check(pytree.Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")]), [Leaf(1, "a"), Leaf(1, "b")])
    check(pytree.Node(syms.file_input, [Leaf(1, "a"), pytree.Node(syms.simple_stmt, [Leaf(1, "b")])]), [Leaf(1, "a"), Leaf(1, "b")])

# Generated at 2022-06-17 17:08:58.295455
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2 import token

    # Test that the constructor of class NodePattern works
    # correctly.
    assert NodePattern(token.NAME, ["a", "b", "c"])
    assert NodePattern(token.NAME, ["a", "b", "c"], "name")
    assert NodePattern(token.NAME, name="name")
    assert NodePattern(token.NAME, content=["a", "b", "c"], name="name")
    assert NodePattern(token.NAME, content=["a", "b", "c"])
    assert NodePattern(token.NAME, content=["a", "b", "c"], name="name")
    assert NodePattern(token.NAME, content=["a", "b", "c"])

# Generated at 2022-06-17 17:09:10.743726
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    class TestNode(Node):
        def _eq(self, other):
            return self.type == other.type and self.children == other.children

        def clone(self):
            return TestNode(self.type, self.children)

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

    class TestLeaf(Leaf):
        def _eq(self, other):
            return self.type == other.type and self.value == other.value

        def clone(self):
            return TestLeaf(self.type, self.value)


# Generated at 2022-06-17 17:09:21.059048
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import pretty_tree
    from . import tree_to_str
    from . import tree_to_str_with_name
    from . import tree_to_str_with_name_and_type
    from . import tree_to_str_with_type
    from . import tree_to_str_with_type_and_name
    from . import tree_to_str_with_type_and_value
    from . import tree_to_str_with_value
    from . import tree_to_str_with_value_and_name
    from . import tree_to_str_with_value_and_type
    from . import tree_to_str_with_value_and_type_and_name
    from . import tree_to_str_with_value_and_type_and_name

# Generated at 2022-06-17 17:09:31.242508
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import generate_matches
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import convert
    from .pgen2.pgen import Leaf
    from .pgen2.pgen import Node
    from .pgen2.pgen import NL
    from .pgen2.pgen import _Results

# Generated at 2022-06-17 17:09:41.770821
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:09:53.765749
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(1, ""), None)
    check(Leaf(1, "", (1, 0)), 1)
    check(Leaf(1, "", (1, 0), prefix=""), 1)
    check(Leaf(1, "", (1, 0), prefix="\n"), 1)
    check(Leaf(1, "", (1, 0), prefix="\n\n"), 2)
    check(Leaf(1, "", (1, 0), prefix="\n\n\n"), 3)

# Generated at 2022-06-17 17:10:01.606265
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    n = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    n.children[1].replace([Leaf(1, "d"), Leaf(1, "e")])
    assert n.children == [Leaf(1, "a"), Leaf(1, "d"), Leaf(1, "e"), Leaf(1, "c")]



# Generated at 2022-06-17 17:10:28.768561
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test_clone(node):
        cloned = node.clone()
        assert cloned == node
        assert cloned is not node
        assert cloned.parent is None
        assert cloned.children == node.children
        assert cloned.children is not node.children
        for child, cloned_child in zip(node.children, cloned.children):
            assert cloned_child.parent is cloned
            assert cloned_child.parent is not child.parent
            test_clone(child)

    test_clone(Leaf(1, "foo"))
    test_clone(Node(syms.simple_stmt, [Leaf(1, "foo")]))

# Generated at 2022-06-17 17:10:40.756578
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def check(patterns, nodes, expected):
        result = list(generate_matches(patterns, nodes))
        assert result == expected, (patterns, nodes, expected, result)

    check([], [], [(0, {})])
    check([NodePattern(type=1)], [], [])
    check([NodePattern(type=1)], [ast.Expr(ast.Const(1))], [(1, {})])
    check([NodePattern(type=1), NodePattern(type=2)], [ast.Expr(ast.Const(1))], [])

# Generated at 2022-06-17 17:10:53.973015
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test_post_order(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    def test_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def test_leaves(node, expected):
        result = list(node.leaves())
        assert result == expected, (result, expected)

    def test_depth(node, expected):
        result = node.depth()
        assert result == expected, (result, expected)

    def test_get_suffix(node, expected):
        result = node.get_suffix()