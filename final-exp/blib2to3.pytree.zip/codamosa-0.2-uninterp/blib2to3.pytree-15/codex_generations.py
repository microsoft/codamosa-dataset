

# Generated at 2022-06-17 17:03:22.335353
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(s, expected):
        t = pytree.convert_str_to_node(s)
        t.replace(Leaf(1, "foo"))
        assert str(t) == expected

    check("1", "foo")
    check("1 + 2", "foo + 2")
    check("1 + 2 + 3", "foo + 2 + 3")
    check("1 + 2 + 3 + 4", "foo + 2 + 3 + 4")
    check("1 + 2 + 3 + 4 + 5", "foo + 2 + 3 + 4 + 5")
    check("1 + 2 + 3 + 4 + 5 + 6", "foo + 2 + 3 + 4 + 5 + 6")

# Generated at 2022-06-17 17:03:32.422822
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import python_tree

    def check(node, expected_depth):
        assert node.depth() == expected_depth

    check(Leaf(1, ""), 0)
    check(Node(syms.simple_stmt, [Leaf(1, "")]), 1)
    check(
        Node(
            syms.file_input,
            [
                Node(
                    syms.stmt,
                    [
                        Node(
                            syms.simple_stmt,
                            [
                                Leaf(1, ""),
                            ],
                        ),
                    ],
                ),
            ],
        ),
        3,
    )
    check(python_tree.parse("x = 1"), 1)




# Generated at 2022-06-17 17:03:36.819299
# Unit test for function generate_matches

# Generated at 2022-06-17 17:03:50.306603
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    def assert_str(node, expected):
        assert str(node) == expected

    def assert_repr(node, expected):
        assert repr(node) == expected

    def assert_repr_equal(node, expected):
        assert repr(node) == repr(expected)

    def assert_str_equal(node, expected):
        assert str(node) == str(expected)

    def assert_prefix(node, expected):
        assert node.prefix == expected

    def assert_type(node, expected):
        assert node.type == expected

    def assert_parent(node, expected):
        assert node.parent == expected


# Generated at 2022-06-17 17:03:59.596876
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    # Test a simple tree
    node = Node(syms.file_input, [Leaf(1, "a"), Leaf(2, "b")])
    check(node, [Leaf(1, "a"), Leaf(2, "b"), node])

    # Test a more complex tree

# Generated at 2022-06-17 17:04:11.046061
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node

    class A(Base):
        def _eq(self, other):
            return True

    class B(Base):
        def _eq(self, other):
            return False

    a = A()
    b = B()
    assert a == a
    assert not a != a
    assert not a == b
    assert a != b
    assert not a == None
    assert a != None
    assert not a == 1
    assert a != 1
    assert not a == "a"
    assert a != "a"
    assert not a == Leaf(1, "")
    assert a != Leaf(1, "")
    assert not a == Node(1, [])
    assert a != Node(1, [])


# Generated at 2022-06-17 17:04:15.134531
# Unit test for function generate_matches

# Generated at 2022-06-17 17:04:27.055735
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import_no_assert
    from . import python_grammar_no_print_statement_no_exec_statement

# Generated at 2022-06-17 17:04:31.023346
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:04:40.706489
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2, name="name")
    assert repr(pattern) == "BasePattern(1, 2, 'name')"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2)
    assert repr(pattern) == "BasePattern(1, 2)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, name="name")
    assert repr(pattern) == "BasePattern(1, None, 'name')"
    # Test with

# Generated at 2022-06-17 17:04:58.830996
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "1")
    assert list(leaf.post_order()) == [leaf]


# Generated at 2022-06-17 17:05:11.137354
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class Pattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

    p = Pattern(tok_name["NAME"], "foo")
    assert p.match(Leaf(tok_name["NAME"], "foo"))
    assert not p.match(Leaf(tok_name["NAME"], "bar"))
    assert not p.match(Leaf(tok_name["NUMBER"], "42"))
    assert not p.match(Node(tok_name["NAME"], []))

    p = Pattern(tok_name["NAME"], "foo", "foo")

# Generated at 2022-06-17 17:05:16.051692
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test with default values for instance variables
    bp = BasePattern()
    assert repr(bp) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    bp = BasePattern(1, 2, 3)
    assert repr(bp) == "BasePattern(1, 2, 3)"
    # Test with non-default values for instance variables
    bp = BasePattern(1, 2, None)
    assert repr(bp) == "BasePattern(1, 2)"
    # Test with non-default values for instance variables
    bp = BasePattern(1, None, None)
    assert repr(bp) == "BasePattern(1)"
    # Test with non-default values for instance variables

# Generated at 2022-06-17 17:05:26.580921
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from . import pytree
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pygram
    from .pgen2 import driver
    from .pygram import python_grammar_no_print_statement
    from .pygram import python_grammar
    from .pygram import python_grammar_all_features
    from .pygram import python_grammar_no_print_statement_no_exec_statement
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile
    from .pygram import python_grammar_no_print_statement_no_exec_statement_

# Generated at 2022-06-17 17:05:34.655497
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from . import parse
    from . import compile
    from . import walk

    def check(pattern, nodes, expected):
        p = parse.parse(pattern)
        c = compile.compile(p)
        n = ast.parse(nodes)
        w = walk.Walker(c)
        for result in w.generate_matches(n):
            assert result == expected
            return
        assert False, "No match found"

    check("a", "a", (1, {}))
    check("a", "b", (0, {}))
    check("a", "", (0, {}))
    check("a b", "a b", (2, {}))
    check("a b", "a", (0, {}))
    check("a b", "b", (0, {}))
   

# Generated at 2022-06-17 17:05:48.863385
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test depth of a leaf
    leaf = Leaf(1, "foo")
    assert leaf.depth() == 0

    # Test depth of a node
    node = Node(syms.simple_stmt, [leaf])
    assert node.depth() == 1

    # Test depth of a node with a parent
    node2 = Node(syms.simple_stmt, [node])
    assert node2.depth() == 2

    # Test depth of a node with a parent and a grandparent
    node3 = Node(syms.simple_stmt, [node2])
    assert node3.depth() == 3

    # Test depth of a node with a parent and a grandparent and a greatgrandparent
    node

# Generated at 2022-06-17 17:05:57.142076
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def _test(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def _test_all(node, expected):
        _test(node, expected)
        _test(node.clone(), expected)

    _test_all(Leaf(1, ""), [Leaf(1, "")])

# Generated at 2022-06-17 17:06:08.981196
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.token import tok_name
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.token import tok_name
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.token import tok_name
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
   

# Generated at 2022-06-17 17:06:19.185636
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import pretty_tree
    from . import tree_to_str
    from . import tree_to_str_with_name

    def test(pattern, text, expected):
        tree = parse.parse(text)
        print(pretty_tree.pretty_tree(tree))
        matches = list(pattern.generate_matches(tree.children))
        print(matches)
        assert matches == expected

    # Test 1
    pattern = NegatedPattern()
    text = "1"
    expected = []
    test(pattern, text, expected)

    # Test 2
    pattern = NegatedPattern(NodePattern(type=token.NAME))
    text = "1"
    expected = [(0, {})]
    test(pattern, text, expected)

    # Test 3

# Generated at 2022-06-17 17:06:30.314035
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node1, node2, expected):
        assert (node1 == node2) == expected
        assert (node2 == node1) == expected

    check(Leaf(1, "foo"), Leaf(1, "foo"), True)
    check(Leaf(1, "foo"), Leaf(1, "bar"), False)
    check(Leaf(1, "foo"), Leaf(2, "foo"), False)
    check(Leaf(1, "foo"), Leaf(2, "bar"), False)
    check(Leaf(1, "foo"), Node(syms.simple_stmt, [Leaf(1, "foo")]), False)

# Generated at 2022-06-17 17:07:02.308992
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import pygram
    from . import pytoken

    pygram.init_grammar(python_grammar)
    pygram.python_grammar.check_all()
    pytoken.assert_equals(pytoken.NUMBER, "1")
    pytoken.assert_equals(pytoken.NAME, "a")
    pytoken.assert_equals(pytoken.PLUS, "+")
    pytoken.assert_equals(pytoken.NEWLINE, "\n")
    pytoken.assert_equals(pytoken.INDENT, "  ")

# Generated at 2022-06-17 17:07:04.252516
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(type=1, content=[LeafPattern(type=2)])
    assert p.type == 1
    assert p.content == [LeafPattern(type=2)]
    assert p.name is None



# Generated at 2022-06-17 17:07:09.291902
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    check(Leaf(1, ""), [Leaf(1, "")])
    check(
        Node(syms.simple_stmt, [Leaf(1, "x")]),
        [Node(syms.simple_stmt, [Leaf(1, "x")]), Leaf(1, "x")],
    )

# Generated at 2022-06-17 17:07:16.962805
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(pytoken.NAME, "foo", (1, 0)), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "foo", (1, 0))]), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "foo", (1, 0)), Leaf(pytoken.NEWLINE, "\n", (1, 3))]), 1)

# Generated at 2022-06-17 17:07:28.832179
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from . import python_tree
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import_no_exec
    from . import python_grammar_no_print_statement_no_exec_

# Generated at 2022-06-17 17:07:41.209038
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:07:54.324515
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test case 1
    # Test case 2
    # Test case 3
    # Test case 4
    # Test case 5
    # Test case 6
    # Test case 7
    # Test case 8
    # Test case 9
    # Test case 10
    # Test case 11
    # Test case 12
    # Test case 13
    # Test case 14
    # Test case 15
    # Test case 16
    # Test case 17
    # Test case 18
    # Test case 19
    # Test case 20
    # Test case 21
    # Test case 22
    # Test case 23
    # Test case 24
    # Test case 25
    # Test case 26
    # Test case 27
    # Test case 28
    # Test case 29
    # Test case 30
   

# Generated at 2022-06-17 17:08:05.963769
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    g = Grammar()
    g.add_production("start", ["a", "b", "c"])
    g.add_production("a", ["d", "e", "f"])
    g.add_production("b", ["g", "h", "i"])
    g.add_production("c", ["j", "k", "l"])
    g.add_production("d", ["m", "n", "o"])
    g.add_production("e", ["p", "q", "r"])
    g.add_production("f", ["s", "t", "u"])
    g.add_production("g", ["v", "w", "x"])
    g.add_

# Generated at 2022-06-17 17:08:11.349536
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    # Test for a node with no children
    node = pytree.Node(syms.simple_stmt, [])
    assert node.get_lineno() is None

    # Test for a node with a child
    node = pytree.Node(syms.simple_stmt, [Leaf(1, "print")])
    assert node.get_lineno() == 1

    # Test for a node with multiple children
    node = pytree.Node(syms.simple_stmt, [Leaf(1, "print"), Leaf(2, "x")])
    assert node.get_lineno() == 1

    # Test for a node with a child that has children

# Generated at 2022-06-17 17:08:21.773462
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar_no_print_statement as python_grammar
    from . import python_grammar_no_print_statement

    def _test_get_suffix(src, expected_suffix):
        tree = pytree.Node(syms.file_input, [Leaf(token.ENDMARKER, "")])
        tree = pytree.Node(syms.file_input, [Leaf(token.ENDMARKER, "")])
        tree = pytree.Node(syms.file_input, [Leaf(token.ENDMARKER, "")])

# Generated at 2022-06-17 17:08:46.717819
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from .parse import Parser

    p = Parser()
    pattern = p.parse("~(a b)")
    assert isinstance(pattern, NegatedPattern)
    assert pattern.content is not None
    assert isinstance(pattern.content, NodePattern)
    assert pattern.content.type is None
    assert len(pattern.content.content) == 2
    assert isinstance(pattern.content.content[0], LeafPattern)
    assert pattern.content.content[0].type == token.NAME
    assert pattern.content.content[0].value == "a"
    assert isinstance(pattern.content.content[1], LeafPattern)
    assert pattern.content.content[1].type == token.NAME
    assert pattern.content.content[1].value == "b"

    # Test the case where the pattern matches

# Generated at 2022-06-17 17:08:50.097470
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.NAME) == "NAME"



# Generated at 2022-06-17 17:08:52.123156
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(type=1, content=[LeafPattern(type=2), LeafPattern(type=3)])
    assert p.type == 1
    assert p.content[0].type == 2
    assert p.content[1].type == 3
    assert p.name is None



# Generated at 2022-06-17 17:09:04.909960
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_parent, expected_pos):
        assert node.parent is expected_parent
        if expected_parent is None:
            assert node.remove() is None
        else:
            assert node.remove() == expected_pos
            assert node.parent is None
            assert expected_parent.children[expected_pos] is not node

    # Test removing a leaf
    leaf = Leaf(1, "foo")
    check(leaf, None, None)

    # Test removing a node
    node = Node(syms.simple_stmt, [leaf])
    check(node, None, None)
    check(leaf, node, 0)

    # Test removing a node with multiple children
    leaf2

# Generated at 2022-06-17 17:09:17.602767
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test with default values for all instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with non-default values for all instance variables
    pattern = BasePattern(type=1, content=2, name="3")
    assert repr(pattern) == "BasePattern(1, 2, '3')"
    # Test with non-default values for some instance variables
    pattern = BasePattern(type=1, content=2)
    assert repr(pattern) == "BasePattern(1, 2)"
    pattern = BasePattern(type=1, name="3")
    assert repr(pattern) == "BasePattern(1, None, '3')"
    pattern = BasePattern(content=2, name="3")

# Generated at 2022-06-17 17:09:27.190998
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern().min == 0
    assert WildcardPattern().max == HUGE
    assert WildcardPattern(min=1).min == 1
    assert WildcardPattern(min=1).max == HUGE
    assert WildcardPattern(max=1).min == 0
    assert WildcardPattern(max=1).max == 1
    assert WildcardPattern(min=1, max=1).min == 1
    assert WildcardPattern(min=1, max=1).max == 1
    assert WildcardPattern(min=1, max=2).min == 1
    assert WildcardPattern(min=1, max=2).max == 2
    assert WildcardPattern(min=1, max=2).min == 1
    assert WildcardPattern(min=1, max=2).max == 2
    assert WildcardPattern(min=1, max=2).min

# Generated at 2022-06-17 17:09:31.709931
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert repr(LeafPattern(1, "foo")) == "LeafPattern(NUMBER, 'foo')"
    assert repr(LeafPattern(1, "foo", "bar")) == "LeafPattern(NUMBER, 'foo', 'bar')"
    assert repr(LeafPattern(1, "foo", None)) == "LeafPattern(NUMBER, 'foo')"
    assert repr(LeafPattern(1, None, "bar")) == "LeafPattern(NUMBER, None, 'bar')"
    assert repr(LeafPattern(1, None, None)) == "LeafPattern(NUMBER)"
    assert repr(LeafPattern(1)) == "LeafPattern(NUMBER)"
    assert repr(LeafPattern(1, None)) == "LeafPattern(NUMBER)"

# Generated at 2022-06-17 17:09:42.161616
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from .pygram import python_grammar
    from .pygram import python_grammar_no_print_statement
    from .pygram import python_grammar_no_print_statement_no_exec_statement
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_exec

# Generated at 2022-06-17 17:09:49.816927
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test for issue #15
    p = WildcardPattern(
        [
            [
                NodePattern(
                    type=token.NAME,
                    content=[
                        LeafPattern(type=token.NAME, content="a"),
                        LeafPattern(type=token.NAME, content="b"),
                    ],
                )
            ]
        ],
        min=1,
        max=1,
        name="bare_name",
    )
    assert p.optimize() == p

# Generated at 2022-06-17 17:09:57.268284
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def test_leaves(node, expected):
        leaves = list(node.leaves())
        assert len(leaves) == len(expected)
        for leaf, expected in zip(leaves, expected):
            assert leaf.value == expected

    def test_leaves_with_type(node, expected):
        leaves = list(node.leaves())
        assert len(leaves) == len(expected)
        for leaf, expected in zip(leaves, expected):
            assert leaf.value == expected[0]
            assert leaf.type == expected[1]

    def test_leaves_with_prefix(node, expected):
        leaves = list(node.leaves())