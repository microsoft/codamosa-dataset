

# Generated at 2022-06-17 17:02:18.676704
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import python_grammar_no_print_statement
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_

# Generated at 2022-06-17 17:02:29.626766
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import driver
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:02:40.068387
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern(1, 2, 3)
    assert repr(pattern) == "BasePattern(1, 2, 3)"
    # Test with non-default values for instance variables
    pattern = BasePattern(1, 2)
    assert repr(pattern) == "BasePattern(1, 2, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern(1)
    assert repr(pattern) == "BasePattern(1, None, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern()
    assert repr

# Generated at 2022-06-17 17:02:52.589558
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:02:54.417326
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert Leaf(1, "a").pre_order() == [Leaf(1, "a")]


# Generated at 2022-06-17 17:03:05.086974
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    pytree.test_utils.assert_equals(
        list(Leaf(1, "a").leaves()),
        [Leaf(1, "a")]
    )

    pytree.test_utils.assert_equals(
        list(Node(syms.simple_stmt, [Leaf(1, "a")]).leaves()),
        [Leaf(1, "a")]
    )


# Generated at 2022-06-17 17:03:10.705705
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    assert Leaf(1, "").depth() == 0
    assert Node(1, [Leaf(1, "")]).depth() == 1
    assert Node(1, [Node(1, [Leaf(1, "")])]).depth() == 2
    assert Node(1, [Node(1, [Node(1, [Leaf(1, "")])])]).depth() == 3



# Generated at 2022-06-17 17:03:21.423520
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        assert node.remove() == expected
        assert node.parent is None

    # Test removing a leaf
    leaf = Leaf(1, "test")
    node = Node(syms.simple_stmt, [leaf])
    check(leaf, 0)
    assert node.children == []

    # Test removing a node
    node = Node(syms.simple_stmt, [Node(syms.expr_stmt, [leaf])])
    check(node.children[0], 0)
    assert node.children == []

    # Test removing a node in the middle of a list

# Generated at 2022-06-17 17:03:22.577940
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:03:32.919227
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test_set_child(node, i, child):
        node.set_child(i, child)
        assert node.children[i] is child
        assert child.parent is node
        assert node.changed()

    def test_insert_child(node, i, child):
        node.insert_child(i, child)
        assert node.children[i] is child
        assert child.parent is node
        assert node.changed()

    def test_append_child(node, child):
        node.append_child(child)
        assert node.children[-1] is child
        assert child.parent is node
        assert node.changed()


# Generated at 2022-06-17 17:04:11.785405
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import pretty_tree
    from . import tree_to_str
    from . import tree_to_list
    from . import tree_to_tuple
    from . import tree_to_dict
    from . import tree_to_html
    from . import tree_to_xml
    from . import tree_to_json
    from . import tree_to_yaml
    from . import tree_to_pickle
    from . import tree_to_csv
    from . import tree_to_table
    from . import tree_to_latex
    from . import tree_to_dot
    from . import tree_to_svg
    from . import tree_to_png
    from . import tree_to_pdf
    from . import tree_to_tikz
    from . import tree_to_

# Generated at 2022-06-17 17:04:24.658068
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def test(node, expected):
        result = list(node.leaves())
        assert result == expected, (result, expected)

    test(Leaf(1, ""), [])
    test(Leaf(1, "a"), [Leaf(1, "a")])
    test(Node(syms.exprlist, [Leaf(1, "a")]), [Leaf(1, "a")])
    test(Node(syms.exprlist, [Leaf(1, "a"), Leaf(1, "b")]), [Leaf(1, "a"), Leaf(1, "b")])

# Generated at 2022-06-17 17:04:37.738019
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class TestPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            if self.content is None:
                return True
            if node.value != self.content:
                return False
            if results is not None:
                results[self.name] = node
            return True

    def test(pattern, node, expected):
        results = {}
        assert pattern.match(node, results) == expected
        if expected:
            assert results == expected
        else:
            assert not results

    # Test leaf patterns

# Generated at 2022-06-17 17:04:50.713247
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("file_input", [("NEWLINE", ""), ("stmt", "*")])
    gr.add_production("stmt", [("simple_stmt", "")])
    gr.add_production("simple_stmt", [("small_stmt", ""), ("NEWLINE", "")])
    gr.add_production("small_stmt", [("expr_stmt", "")])
    gr.add_production("expr_stmt", [("testlist", "")])
    gr.add_production("testlist", [("test", ""), ("COMMA", ""), ("test", "*")])

# Generated at 2022-06-17 17:04:59.291119
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pgen2
    from . import pgen2_parse
    from . import pgen2_tokenize
    from . import pgen2_grammar
    from . import pgen2_driver
    from . import pgen2_parse
    from . import pgen2_convert
    from . import pgen2_generate
    from . import pgen2_literals
    from . import pgen2_token
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_convert
    from . import pgen2_generate
    from . import pgen2_literals

# Generated at 2022-06-17 17:05:11.979956
# Unit test for function generate_matches
def test_generate_matches():
    # Test 1
    p = NodePattern(type=token.NAME)
    assert list(generate_matches([p], [NL(type=token.NAME)])) == [(1, {})]
    assert list(generate_matches([p], [NL(type=token.NUMBER)])) == []
    assert list(generate_matches([p], [NL(type=token.NAME), NL(type=token.NAME)])) == []
    # Test 2
    p = NodePattern(type=token.NAME, name="x")
    assert list(generate_matches([p], [NL(type=token.NAME)])) == [(1, {"x": [NL(type=token.NAME)]})]
    assert list(generate_matches([p], [NL(type=token.NUMBER)])) == []

# Generated at 2022-06-17 17:05:24.294470
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def test_leaves(node, expected):
        assert list(node.leaves()) == expected

    test_leaves(Node(syms.file_input, [Leaf(token.ENDMARKER, "")]), [Leaf(token.ENDMARKER, "")])
    test_leaves(Node(syms.file_input, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]), [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])

# Generated at 2022-06-17 17:05:33.690412
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test with default arguments
    # Test with one argument
    # Test with two arguments
    # Test with three arguments
    # Test with four arguments
    # Test with five arguments
    # Test with six arguments
    # Test with seven arguments
    # Test with eight arguments
    # Test with nine arguments
    # Test with ten arguments
    # Test with eleven arguments
    # Test with twelve arguments
    # Test with thirteen arguments
    # Test with fourteen arguments
    # Test with fifteen arguments
    # Test with sixteen arguments
    # Test with seventeen arguments
    # Test with eighteen arguments
    # Test with nineteen arguments
    # Test with twenty arguments
    # Test with twenty-one arguments
    # Test with twenty-two arguments
    # Test with twenty-three arguments
    # Test with twenty-four

# Generated at 2022-06-17 17:05:46.430151
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree

# Generated at 2022-06-17 17:05:52.666910
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("start", ["a", "b", "c"])
    gr.add_production("a", ["a", "a"])
    gr.add_production("a", ["a"])
    gr.add_production("a", ["A"])
    gr.add_production("b", ["b", "b"])
    gr.add_production("b", ["b"])
    gr.add_production("b", ["B"])
    gr.add_production("c", ["c", "c"])
    gr.add_production("c", ["c"])
    gr.add_production("c", ["C"])

# Generated at 2022-06-17 17:06:12.192125
# Unit test for method replace of class Base
def test_Base_replace():
    class Node(Base):
        def __init__(self, children):
            self.children = children
            for child in children:
                child.parent = self
        def _eq(self, other):
            return self.children == other.children
        def clone(self):
            return Node(self.children)
        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()
        def __repr__(self):
            return "Node(%s)" % self.children
        @property
        def prefix(self):
            return ""

    class Leaf(Base):
        def __init__(self, value):
            self.value

# Generated at 2022-06-17 17:06:18.616395
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern(type=1, content=[], name="foo")
    assert n.type == 1
    assert n.content == []
    assert n.name == "foo"
    n = NodePattern(type=1, content=[LeafPattern(type=1)], name="foo")
    assert n.type == 1
    assert len(n.content) == 1
    assert isinstance(n.content[0], LeafPattern)
    assert n.name == "foo"
    n = NodePattern(type=1, content=[LeafPattern(type=1), LeafPattern(type=2)], name="foo")
    assert n.type == 1
    assert len(n.content) == 2
    assert isinstance(n.content[0], LeafPattern)
    assert isinstance(n.content[1], LeafPattern)
    assert n

# Generated at 2022-06-17 17:06:29.909612
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:06:41.548803
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    pytree.main()
    # Test that the sibling maps are updated correctly when a child is added
    # to a node
    n = Node(syms.simple_stmt, [Leaf(token.NAME, "a")])
    n.update_sibling_maps()
    assert n.prev_sibling_map[id(n.children[0])] is None
    assert n.next_sibling_map[id(n.children[0])] is None
    n.append_child(Leaf(token.NAME, "b"))
    assert n.prev_sibling_map[id(n.children[0])] is None
    assert n.next

# Generated at 2022-06-17 17:06:49.049150
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def test_str(node, expected):
        result = "".join(str(n) for n in node.pre_order())
        assert result == expected, (result, expected)

    def test_repr(node, expected):
        result = "".join(repr(n) for n in node.pre_order())
        assert result == expected, (result, expected)

    def test_prefix(node, expected):
        result = "".join(n.prefix for n in node.pre_order())
        assert result == expected, (result, expected)

   

# Generated at 2022-06-17 17:06:55.589500
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        assert list(node.post_order()) == expected

    def check_all(node, expected):
        check(node, expected)
        check(node.clone(), expected)

    check_all(Leaf(1, ""), [])
    check_all(Node(syms.expr, [Leaf(1, "")]), [Leaf(1, "")])
    check_all(
        Node(syms.expr, [Leaf(1, ""), Leaf(2, "")]),
        [Leaf(1, ""), Leaf(2, "")],
    )

# Generated at 2022-06-17 17:07:02.087216
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_pre_order(node, expected):
        check(node, expected)
        check(node.clone(), expected)

    # Test a simple tree
    node = Node(syms.file_input, [Leaf(1, "a"), Leaf(2, "b")])
    check_pre_order(node, [node, node.children[0], node.children[1]])

    # Test a tree with a subnode

# Generated at 2022-06-17 17:07:07.499008
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver
    from .pgen2 import token
    from . import tokenize

    def _convert(type, value, context, children):
        return convert(gr, (type, value, context, children))

    gr = Driver(convert=_convert, tokenizer=tokenize.generate_tokens)
    gr.build()

    # Test that convert() returns the child if there's only one child
    assert _convert(
        gr.symbol2number["file_input"],
        "",
        None,
        [_convert(token.NAME, "spam", None, [])],
    ) == _convert(token.NAME, "spam", None, [])

    # Test that convert() returns a Node instance

# Generated at 2022-06-17 17:07:15.808959
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from . import pytree
    from .pgen2 import token

    # Test for a leaf node
    leaf = Leaf(token.NAME, "foo")
    assert list(leaf.leaves()) == [leaf]

    # Test for a node with no children
    node = Node(syms.simple_stmt, [])
    assert list(node.leaves()) == []

    # Test for a node with a single child
    node = Node(syms.simple_stmt, [leaf])
    assert list(node.leaves()) == [leaf]

    # Test for a node with multiple children
    node = Node(syms.simple_stmt, [leaf, leaf])

# Generated at 2022-06-17 17:07:27.867501
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import patcomp
    from . import pat

# Generated at 2022-06-17 17:08:20.625448
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf

    l1 = Leaf(1, "foo")
    l2 = Leaf(1, "foo")
    l3 = Leaf(1, "bar")
    l4 = Leaf(2, "foo")
    assert l1 == l2
    assert l1 != l3
    assert l1 != l4
    assert l1 != object()



# Generated at 2022-06-17 17:08:31.088023
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util

# Generated at 2022-06-17 17:08:42.220427
# Unit test for function generate_matches
def test_generate_matches():
    # Test that generate_matches works correctly
    # The test is a bit contrived, but it does the job
    p = NodePattern(type=1)
    q = NodePattern(type=2)
    r = NodePattern(type=3)
    s = NodePattern(type=4)
    t = NodePattern(type=5)
    u = NodePattern(type=6)
    v = NodePattern(type=7)
    w = NodePattern(type=8)
    x = NodePattern(type=9)
    y = NodePattern(type=10)
    z = NodePattern(type=11)
    a = NodePattern(type=12)
    b = NodePattern(type=13)
    c = NodePattern(type=14)
    d = NodePattern(type=15)

# Generated at 2022-06-17 17:08:55.592082
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar

    def check(node, expected):
        assert list(node.pre_order()) == expected

    check(Leaf(1, ""), [Leaf(1, "")])
    check(
        Node(syms.file_input, [Leaf(1, ""), Leaf(2, "")]),
        [Node(syms.file_input, [Leaf(1, ""), Leaf(2, "")]), Leaf(1, ""), Leaf(2, "")],
    )

# Generated at 2022-06-17 17:08:59.769506
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_parent, expected_index):
        assert node.parent is expected_parent
        if expected_parent is None:
            assert node.remove() is None
        else:
            assert node.remove() == expected_index
            assert node.parent is None
            assert expected_parent.children[expected_index] is not node

    # Test that removing a leaf works
    leaf = Leaf(1, "leaf")
    check(leaf, None, None)
    leaf.parent = Node(syms.simple_stmt, [leaf])
    check(leaf, None, None)
    leaf.parent = Node(syms.simple_stmt, [leaf])

# Generated at 2022-06-17 17:09:12.682524
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    class TestPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return True

    def test(pattern, nodes, expected):
        actual = list(pattern.generate_matches(nodes))
        assert actual == expected, (actual, expected)

    def test_error(pattern, nodes):
        try:
            list(pattern.generate_matches(nodes))
        except ParseError:
            pass


# Generated at 2022-06-17 17:09:25.302454
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    def check(node, expected):
        result = [x.type for x in node.post_order()]
        assert result == expected, (result, expected)

    check(Leaf(1, ""), [1])
    check(Node(syms.simple_stmt, [Leaf(1, ""), Leaf(2, "")]), [1, 2, syms.simple_stmt])

# Generated at 2022-06-17 17:09:37.184235
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import fixer_base
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
   

# Generated at 2022-06-17 17:09:52.040649
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def _check(node1, node2, expected):
        actual = node1 == node2
        assert actual == expected, (actual, expected)

    def _check_all(node1, node2, expected):
        _check(node1, node2, expected)
        _check(node2, node1, expected)

    _check_all(Leaf(1, "foo"), Leaf(1, "foo"), True)
    _check_all(Leaf(1, "foo"), Leaf(1, "bar"), False)
    _check_all(Leaf(1, "foo"), Leaf(2, "foo"), False)

# Generated at 2022-06-17 17:09:59.251394
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import python_grammar as grammar

    def check_eq(n1, n2):
        assert n1 == n2
        assert n2 == n1
        assert not n1 != n2
        assert not n2 != n1

    def check_ne(n1, n2):
        assert not n1 == n2
        assert not n2 == n1
        assert n1 != n2
        assert n2 != n1

    # Test equality of leaves
    l1 = Leaf(1, "foo")
    l2 = Leaf(1, "foo")
    l3 = Leaf(1, "bar")
    l4 = Leaf(2, "foo")
    check_eq(l1, l2)
    check