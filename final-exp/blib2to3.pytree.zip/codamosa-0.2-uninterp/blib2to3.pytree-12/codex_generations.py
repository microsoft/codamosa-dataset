

# Generated at 2022-06-17 17:02:53.304040
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    g = Grammar()
    p = BasePattern(type=tok_name["NAME"])
    assert p.match(Leaf(tok_name["NAME"], "foo"))
    assert not p.match(Leaf(tok_name["NAME"], "bar"))
    assert not p.match(Leaf(tok_name["NUMBER"], "42"))
    assert not p.match(Leaf(tok_name["STRING"], "spam"))
    assert not p.match(Leaf(tok_name["NEWLINE"], "\n"))
    assert not p.match(Leaf(tok_name["INDENT"], ""))

# Generated at 2022-06-17 17:03:04.234989
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    root = Node(syms.file_input, [
        Node(syms.stmt, [
            Leaf(1, "a"),
            Leaf(1, "b"),
            Leaf(1, "c"),
        ]),
        Node(syms.stmt, [
            Leaf(1, "d"),
            Leaf(1, "e"),
            Leaf(1, "f"),
        ]),
    ])
    assert list(root.leaves()) == [
        Leaf(1, "a"),
        Leaf(1, "b"),
        Leaf(1, "c"),
        Leaf(1, "d"),
        Leaf(1, "e"),
        Leaf(1, "f"),
    ]



# Generated at 2022-06-17 17:03:14.753379
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(tree, expected):
        assert list(tree.leaves()) == expected

    check(Leaf(1, ""), [])
    check(Leaf(1, "a"), [Leaf(1, "a")])
    check(Node(syms.simple_stmt, [Leaf(1, "a")]), [Leaf(1, "a")])
    check(Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")]), [Leaf(1, "a"), Leaf(1, "b")])

# Generated at 2022-06-17 17:03:24.370541
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram

# Generated at 2022-06-17 17:03:29.526913
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    wp = WildcardPattern(content=[(NodePattern(type=NAME),)], min=1, max=1)
    assert wp.match_seq([Leaf(1, "a")])
    assert not wp.match_seq([Leaf(1, "a"), Leaf(1, "b")])
    assert not wp.match_seq([Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert wp.match_seq([Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), Leaf(1, "d")])
    assert not wp.match_seq([Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), Leaf(1, "d"), Leaf(1, "e")])

# Generated at 2022-06-17 17:03:34.586962
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.token import tok_name
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    grammar = generate_grammar()
    driver = Driver(grammar, convert)
    try:
        tree = driver.parse_tokens(
            [
                (1, "def"),
                (1, "f"),
                (11, "("),
                (1, "x"),
                (11, ","),
                (1, "y"),
                (11, ")"),
                (4, ":"),
                (1, "pass"),
                (0, ""),
            ]
        )
    except ParseError:
        print

# Generated at 2022-06-17 17:03:37.026536
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "a")
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-17 17:03:50.350492
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:03:59.645893
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    # Test replacing a leaf with a leaf
    leaf = Leaf(1, "foo")
    leaf.replace(Leaf(1, "bar"))
    assert leaf.prefix == "bar"

    # Test replacing a leaf with a node
    leaf = Leaf(1, "foo")
    leaf.replace(Node(syms.simple_stmt, [Leaf(1, "bar")]))
    assert leaf.prefix == "bar"

    # Test replacing a node with a leaf
    node = Node(syms.simple_stmt, [Leaf(1, "foo")])
    node.replace(Leaf(1, "bar"))
    assert node.prefix == "bar"

    # Test replacing a node with a node

# Generated at 2022-06-17 17:04:11.742051
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_token("NAME", r"\w+")
    gr.add_token("NUMBER", r"\d+")
    gr.add_token("PLUS", r"\+")
    gr.add_token("MINUS", r"-")
    gr.add_token("TIMES", r"\*")
    gr.add_token("DIVIDE", r"/")
    gr.add_token("LPAR", r"\(")
    gr.add_token("RPAR", r"\)")
    gr.add_token("EQUAL", r"=")
    gr.add_token("NEWLINE", r"\n")

# Generated at 2022-06-17 17:05:08.792513
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("x", ["x", "y"])
    gr.add_production("x", ["y", "x"])
    gr.add_production("x", ["y", "y"])
    gr.add_production("y", ["y", "y"])
    gr.add_production("y", ["y", "x"])
    gr.add_production("y", ["x", "y"])
    gr.add_production("y", ["x", "x"])
    gr.add_production("y", ["a"])
    gr.add_production("y", ["b"])
    gr.add_production("y", ["c"])
    gr.add_production("y", ["d"])
    gr.add

# Generated at 2022-06-17 17:05:22.044630
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    g = Grammar()
    g.add_production("start", [("a", "b")])
    g.add_production("a", [("a", "b")])
    g.add_production("a", [("a", "c")])
    g.add_production("a", [("d",)])
    g.add_production("b", [("b", "b")])
    g.add_production("b", [("b", "c")])
    g.add_production("b", [("d",)])
    g.add_production("c", [("c", "c")])
    g.add_production("c", [("d",)])
    g.add_production("d", [("e",)])

# Generated at 2022-06-17 17:05:30.553559
# Unit test for method optimize of class WildcardPattern

# Generated at 2022-06-17 17:05:39.932061
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def test(node, expected_parent, expected_pos):
        node.remove()
        assert node.parent is None
        assert expected_parent.children[expected_pos] is node
        assert expected_parent.children[expected_pos + 1].parent is expected_parent

    # Test removing a leaf
    tree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    test(tree.children[1], tree, 1)

    # Test removing a node

# Generated at 2022-06-17 17:05:54.220875
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens, untokenize, TokenError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer

# Generated at 2022-06-17 17:06:02.028395
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("s", ("a", "b"))
    gr.add_production("a", ("a", "a"))
    gr.add_production("a", ("A",))
    gr.add_production("b", ("b", "b"))
    gr.add_production("b", ("B",))
    gr.add_production("A", ("a",))
    gr.add_production("B", ("b",))
    gr.compile()
    p = NodePattern(gr, "s")
    assert p.match(Node(gr.symbol2number["s"], []))
    assert p.match(Node(gr.symbol2number["s"], [Leaf(1, "a"), Leaf(1, "b")]))


# Generated at 2022-06-17 17:06:11.420185
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def _check_leaves(node, expected):
        assert list(node.leaves()) == expected

    _check_leaves(Leaf(1, ""), [])
    _check_leaves(Node(syms.file_input, [Leaf(1, "")]), [Leaf(1, "")])
    _check_leaves(Node(syms.file_input, [Leaf(1, ""), Leaf(2, "")]), [Leaf(1, ""), Leaf(2, "")])

# Generated at 2022-06-17 17:06:23.058222
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken

    # Test case 1
    #
    #   foo
    #   bar
    #
    #   baz
    #
    #   qux
    #
    #   quux
    #
    #   corge
    #
    #   grault
    #
    #   garply
    #
    #   waldo
    #
    #   fred
    #
    #   plugh
    #
    #   xyzzy
    #
    #   thud
    #
    #   foo
    #   bar
    #
    #   baz
    #


# Generated at 2022-06-17 17:06:32.548781
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def check(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        expected = [parse(s) for s in expected]
        actual = [nodes[:c] for c, r in pattern.generate_matches(nodes)]
        assert actual == expected, (actual, expected)

    check(".*", "a b c", ["", "a", "a b", "a b c"])
    check(".+", "a b c", ["a", "a b", "a b c"])
    check(".?", "a b c", ["", "a"])
    check(".{2,3}", "a b c", ["a b", "a b c"])

# Generated at 2022-06-17 17:06:44.326629
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    class TestNode(Node):
        def __init__(self, lineno):
            self.lineno = lineno
            self.children = []
    class TestLeaf(Leaf):
        def __init__(self, lineno):
            self.lineno = lineno
    class TestNode2(Node):
        def __init__(self, lineno):
            self.lineno = lineno
            self.children = []
    class TestLeaf2(Leaf):
        def __init__(self, lineno):
            self.lineno = lineno
    class TestNode3(Node):
        def __init__(self, lineno):
            self.lineno = lineno
            self.children = []

# Generated at 2022-06-17 17:07:39.405105
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import LST
    from .pgen2.pgen import LST_END
    from .pgen2.pgen import LST_NAMED
    from .pgen2.pgen import LST_SEQ
    from .pgen2.pgen import LST_OR
    from .pgen2.pgen import LST_ZEROORMORE
    from .pgen2.pgen import LST_ONEORMORE
    from .pgen2.pgen import LST_OPTIONAL
    from .pgen2.pgen import LST_N

# Generated at 2022-06-17 17:07:53.468454
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def check_get_lineno(node, lineno):
        assert node.get_lineno() == lineno

    check_get_lineno(pytree.Node(syms.simple_stmt, [Leaf(1, "x")]), 1)
    check_get_lineno(pytree.Node(syms.simple_stmt, [Leaf(1, "x"), Leaf(1, "y")]), 1)
    check_get_lineno(pytree.Node(syms.simple_stmt, [Leaf(1, "x"), Leaf(2, "y")]), 1)

# Generated at 2022-06-17 17:08:05.645179
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree
    from .pgen2 import token

    def _test_leaves(node, expected_leaves):
        leaves = list(node.leaves())
        assert len(leaves) == len(expected_leaves)
        for leaf, expected_leaf in zip(leaves, expected_leaves):
            assert leaf.type == expected_leaf[0]
            assert leaf.value == expected_leaf[1]

    # Test leaves of a leaf
    leaf = Leaf(token.NAME, "foo")
    _test_leaves(leaf, [(token.NAME, "foo")])

    # Test leaves of a node
    node = Node(python_symbols.simple_stmt, [leaf])
    _test_le

# Generated at 2022-06-17 17:08:18.223324
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    g = Grammar()
    p = g.pattern("a")
    assert p.optimize() is p
    p = g.pattern("a", "b")
    assert p.optimize() is p
    p = g.pattern("a", "b", "c")
    assert p.optimize() is p
    p = g.pattern("a", "b", "c", "d")
    assert p.optimize() is p
    p = g.pattern("a", "b", "c", "d", "e")
    assert p.optimize() is p
    p = g.pattern("a", "b", "c", "d", "e", "f")
    assert p.optimize() is p

# Generated at 2022-06-17 17:08:27.010220
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Test method __repr__ of class BasePattern"""
    from .pgen2.parse import BasePattern
    from .pgen2.parse import LeafPattern
    from .pgen2.parse import NodePattern
    from .pgen2.parse import WildcardPattern
    from .pgen2.parse import type_repr
    from .pgen2.parse import _token_type_repr
    from .pgen2.parse import _symbol_type_repr
    from .pgen2.parse import _token_type_repr
    from .pgen2.parse import _symbol_type_repr
    from .pgen2.parse import _token_type_repr
    from .pgen2.parse import _symbol_type_repr
    from .pgen2.parse import _token_type_repr


# Generated at 2022-06-17 17:08:38.077242
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    node = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert node.depth() == 0
    node.children[0].parent = node
    node.children[1].parent = node
    assert node.children[0].depth() == 1
    assert node.children[1].depth() == 1
    node.children[0].children[0].parent = node.children[0]
    node.children[1].children[0].parent = node.children[1]
    assert node.children[0].children[0].depth() == 2
    assert node.children[1].children[0].depth() == 2


# Generated at 2022-06-17 17:08:53.072131
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pgen2

# Generated at 2022-06-17 17:08:58.834485
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.grammar import Grammar

    g = Grammar()
    d = driver.Driver(g, convert)

# Generated at 2022-06-17 17:09:11.405502
# Unit test for function generate_matches
def test_generate_matches():
    # Test that the function works at all
    p = NodePattern(type=token.NAME)
    n = NL(type=token.NAME, children=[])
    assert list(generate_matches([p], [n])) == [(1, {})]
    # Test that it works with multiple patterns
    p1 = NodePattern(type=token.NAME)
    p2 = NodePattern(type=token.NAME)
    n1 = NL(type=token.NAME, children=[])
    n2 = NL(type=token.NAME, children=[])
    assert list(generate_matches([p1, p2], [n1, n2])) == [(2, {})]
    # Test that it works with multiple nodes
    p1 = NodePattern(type=token.NAME)
    p2 = NodePattern(type=token.NAME)

# Generated at 2022-06-17 17:09:21.410647
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_matches
    from .pgen2.pgen import convert
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import Pattern
    from .pgen2.pgen import _Results
    from .pgen2.pgen import NL
    from .pgen2.pgen import type_repr
    from .pgen2.pgen import _Results

# Generated at 2022-06-17 17:09:53.710711
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.grammar import Symbol

    assert repr(LeafPattern(1, "abc")) == "LeafPattern(NUMBER, 'abc')"
    assert repr(LeafPattern(1, "abc", "foo")) == "LeafPattern(NUMBER, 'abc', 'foo')"
    assert repr(NodePattern(Symbol.expr_stmt)) == "NodePattern(expr_stmt)"
    assert repr(NodePattern(Symbol.expr_stmt, "foo")) == "NodePattern(expr_stmt, 'foo')"
    assert repr(WildcardPattern()) == "WildcardPattern()"
    assert repr(WildcardPattern("foo")) == "WildcardPattern('foo')"
    assert repr(WildcardPattern(min=1)) == "WildcardPattern(min=1)"

# Generated at 2022-06-17 17:10:05.752266
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.token import tok_name

    class LeafPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            if self.content is None:
                return True
            if isinstance(self.content, str):
                return self.content == node.value
            return self.content.match(node.value)

        def __repr__(self):
            args = [tok_name[self.type], self.content, self.name]
            while args and args[-1] is None:
                del args[-1]

# Generated at 2022-06-17 17:10:17.265669
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:10:18.630745
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "a")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-17 17:10:29.542137
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    # Test set_child
    n = Node(syms.file_input, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])
    n.set_child(0, Leaf(token.NAME, "c"))
    assert n == Node(syms.file_input, [Leaf(token.NAME, "c"), Leaf(token.NAME, "b")])
    n.set_child(1, Leaf(token.NAME, "d"))
    assert n == Node(syms.file_input, [Leaf(token.NAME, "c"), Leaf(token.NAME, "d")])

# Generated at 2022-06-17 17:10:41.339690
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree

# Generated at 2022-06-17 17:10:44.851733
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "a")
    assert list(leaf.post_order()) == [leaf]


# Generated at 2022-06-17 17:10:53.160788
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import unittest
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    class TestBase(unittest.TestCase):
        def test_pre_order(self):
            tree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")])
            self.assertEqual(list(tree.pre_order()), [tree, tree.children[0], tree.children[1]])

    unittest.main()

