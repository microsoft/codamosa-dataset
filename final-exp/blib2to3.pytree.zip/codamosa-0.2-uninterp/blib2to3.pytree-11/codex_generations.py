

# Generated at 2022-06-17 17:02:34.542954
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_symbols
    node = Node(python_symbols.file_input, [Leaf(1, "foo"), Leaf(1, "bar")])
    node.update_sibling_maps()
    assert node.prev_sibling_map[id(node.children[0])] is None
    assert node.next_sibling_map[id(node.children[0])] is node.children[1]
    assert node.prev_sibling_map[id(node.children[1])] is node.children[0]
    assert node.next_sibling_map[id(node.children[1])] is None
    assert node.prev_sibling_map[id(node)] is None
    assert node.next_sibling_map[id(node)]

# Generated at 2022-06-17 17:02:42.465497
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Test that NodePattern() raises an exception if type is not None
    # and content is None.
    try:
        NodePattern(type=1)
    except AssertionError:
        pass
    else:
        raise AssertionError("NodePattern(type=1) should fail")

    # Test that NodePattern() raises an exception if type is None
    # and content is not None.
    try:
        NodePattern(content=[])
    except AssertionError:
        pass
    else:
        raise AssertionError("NodePattern(content=[]) should fail")

    # Test that NodePattern() raises an exception if type is not None
    # and content is not None and type is not a symbol.
    try:
        NodePattern(type=1, content=[])
    except AssertionError:
        pass

# Generated at 2022-06-17 17:02:53.775135
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("a", ["b"])
    gr.add_production("b", ["c"])
    gr.add_production("c", ["d"])
    gr.add_production("d", ["e"])
    gr.add_production("e", ["f"])
    gr.add_production("f", ["g"])
    gr.add_production("g", ["h"])
    gr.add_production("h", ["i"])
    gr.add_production("i", ["j"])
    gr.add_production("j", ["k"])
    gr.add_production("k", ["l"])
    gr.add_production("l", ["m"])

# Generated at 2022-06-17 17:03:02.080475
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def test(patterns, nodes, expected):
        actual = list(generate_matches(patterns, nodes))
        assert actual == expected, (actual, expected)

    # Test empty patterns
    test([], [], [(0, {})])
    test([], [ast.Pass()], [(0, {})])
    test([], [ast.Pass(), ast.Pass()], [(0, {})])

    # Test empty nodes
    test([NodePattern(ast.Pass)], [], [(0, {})])
    test([NodePattern(ast.Pass), NodePattern(ast.Pass)], [], [(0, {})])

    # Test single pattern
    test([NodePattern(ast.Pass)], [ast.Pass()], [(1, {})])

# Generated at 2022-06-17 17:03:13.337938
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node

    def check(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    # Test a single leaf
    check(Leaf(1, "foo"), [Leaf(1, "foo")])

    # Test a single node
    check(Node(1, [Leaf(1, "foo")]), [Leaf(1, "foo"), Node(1, [Leaf(1, "foo")])])

    # Test a node with two children
    check(
        Node(1, [Leaf(1, "foo"), Leaf(1, "bar")]),
        [Leaf(1, "foo"), Leaf(1, "bar"), Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])],
    )

# Generated at 2022-06-17 17:03:23.239824
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    import unittest
    class TestNode(unittest.TestCase):
        def test_update_sibling_maps(self):
            def _test_update_sibling_maps(node):
                node.update_sibling_maps()
                for child in node.children:
                    self.assertEqual(child.prev_sibling, node.prev_sibling_map[id(child)])
                    self.assertEqual(child.next_sibling, node.next_sibling_map[id(child)])

# Generated at 2022-06-17 17:03:24.227511
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, 'a')
    assert list(l.leaves()) == [l]


# Generated at 2022-06-17 17:03:29.694644
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2, name=3)
    assert repr(pattern) == "BasePattern(1, 2, 3)"



# Generated at 2022-06-17 17:03:42.302112
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import pygram
    from .pgen2 import driver
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pytoken
    from . import pygram
    from . import pytree

# Generated at 2022-06-17 17:03:50.329736
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    g = Grammar()
    g.add_production("a", ["b"])
    g.add_production("b", ["c"])
    g.add_production("c", ["d"])
    g.add_production("d", ["e"])
    g.add_production("e", ["f"])
    g.add_production("f", ["g"])
    g.add_production("g", ["h"])
    g.add_production("h", ["i"])
    g.add_production("i", ["j"])
    g.add_production("j", ["k"])
    g.add_production("k", ["l"])
    g.add_production("l", ["m"])

# Generated at 2022-06-17 17:04:52.600838
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    grammar = pygram.python_grammar_no_print_statement

# Generated at 2022-06-17 17:05:05.137008
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from astroid import test_utils
    from astroid.builder import AstroidBuilder
    builder = AstroidBuilder()
    builder.string_build("""
    def f(x):
        if x:
            return 1
        else:
            return 2
    """)
    module = builder.file_build()
    f = module["f"]
    # Test the case where the argument pattern has no matches
    pattern = NegatedPattern(NodePattern(type=syms.return_stmt))
    matches = list(pattern.generate_matches(f.body))
    assert len(matches) == 1
    assert matches[0][0] == 0
    assert len(matches[0][1]) == 0
    # Test the case where the argument pattern has matches

# Generated at 2022-06-17 17:05:10.846688
# Unit test for method remove of class Base
def test_Base_remove():
    class Node(Base):
        def __init__(self, children):
            self.children = children
        def _eq(self, other):
            return self.children == other.children
        def clone(self):
            return Node(self.children)
        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()
    class Leaf(Base):
        def __init__(self, value):
            self.value = value
        def _eq(self, other):
            return self.value == other.value
        def clone(self):
            return Leaf(self.value)
        def post_order(self):
            yield self


# Generated at 2022-06-17 17:05:15.745790
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from . import grammar

    def test(pattern, nodes, expected):
        result = pattern.match_seq(nodes)
        assert result == expected, (pattern, nodes, result)

    def test_all(pattern, nodes, expected):
        for i in range(len(nodes)):
            test(pattern, nodes[:i], expected)

    def test_all_all(pattern, nodes, expected):
        for i in range(len(nodes)):
            test_all(pattern, nodes[:i], expected)

    def test_all_all_all(pattern, nodes, expected):
        for i in range(len(nodes)):
            test_all_all(pattern, nodes[:i], expected)


# Generated at 2022-06-17 17:05:20.308831
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import generate_grammar

    g = Grammar(generate_grammar)
    p = LeafPattern(type=tok_name["NAME"])
    assert p.match(Leaf(tok_name["NAME"], "foo"))
    assert not p.match(Leaf(tok_name["NAME"], "bar"))
    assert not p.match(Leaf(tok_name["NUMBER"], "42"))
    assert not p.match(Node(g.number2symbol[g.symbol2number["atom"]]))

# Generated at 2022-06-17 17:05:32.900876
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    def _test(node, expected_types):
        types = [n.type for n in node.post_order()]
        assert types == expected_types

    # Test a simple tree

# Generated at 2022-06-17 17:05:41.641232
# Unit test for method post_order of class Base
def test_Base_post_order():
    import unittest
    from .pytree import Leaf, Node
    from . import pygram

    class TestBase(unittest.TestCase):
        def test_post_order(self):
            grammar = pygram.python_grammar_no_print_statement
            tree = grammar.parsed("x = 1 + 2")

# Generated at 2022-06-17 17:05:55.217682
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class Pattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return True

    p = Pattern(tok_name["NAME"])
    assert p.match(Leaf(tok_name["NAME"], "foo"))
    assert not p.match(Leaf(tok_name["NAME"], "bar"))
    assert not p.match(Leaf(tok_name["NUMBER"], "42"))
    assert not p.match(Leaf(tok_name["NAME"], "foo", prefix=" "))

# Generated at 2022-06-17 17:06:06.883437
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from . import pytoken
    from .pgen2 import token
    from .pgen2 import driver
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fix

# Generated at 2022-06-17 17:06:14.517251
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert repr(LeafPattern(1)) == "LeafPattern(1, None, None)"
    assert repr(LeafPattern(1, "foo")) == "LeafPattern(1, 'foo', None)"
    assert repr(LeafPattern(1, "foo", "bar")) == "LeafPattern(1, 'foo', 'bar')"
    assert repr(LeafPattern(1, name="bar")) == "LeafPattern(1, None, 'bar')"
    assert repr(LeafPattern(1, "foo", name="bar")) == "LeafPattern(1, 'foo', 'bar')"
    assert repr(NodePattern(1)) == "NodePattern(1, None, None)"

# Generated at 2022-06-17 17:06:39.880914
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree


# Generated at 2022-06-17 17:06:48.367135
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(0, [])
    assert repr(n) == "Node(0, [])"
    n = Node(0, [Leaf(1, ""), Leaf(2, "")])
    assert repr(n) == "Node(0, [Leaf(1, ''), Leaf(2, '')])"

# Generated at 2022-06-17 17:06:52.796197
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import generate_grammar

    g = Grammar(generate_grammar)
    lp = LeafPattern(type=tok_name["NAME"], content="foo")
    n = Node(tok_name["NAME"], [Leaf(tok_name["NAME"], "foo")])
    assert lp.match(n)
    lp = LeafPattern(type=tok_name["NAME"], content="bar")
    assert not lp.match(n)
    lp = LeafPattern(type=tok_name["NAME"], content="foo", name="foo")
    r = {}
    assert lp.match(n, r)

# Generated at 2022-06-17 17:06:58.269144
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar

    def test_remove(node):
        node.remove()
        assert node.parent is None

    def test_remove_parent(node):
        parent = node.parent
        node.remove()
        assert node not in parent.children

    def test_remove_parent_changed(node):
        parent = node.parent
        node.remove()
        assert parent.was_changed

    def test_remove_siblings(node):
        parent = node.parent
        node.remove()
        assert node.next_sibling is None
        assert node.prev_sibling is None

    def test_remove_siblings_next(node):
        parent = node.parent
        node.remove()

# Generated at 2022-06-17 17:07:04.325849
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern(type=1, content=[])
    assert n.type == 1
    assert n.content == []
    assert n.name is None
    n = NodePattern(type=1, content=[], name="foo")
    assert n.type == 1
    assert n.content == []
    assert n.name == "foo"
    n = NodePattern(type=1, content=[LeafPattern(type=1)])
    assert n.type == 1
    assert n.content == [LeafPattern(type=1)]
    assert n.name is None
    n = NodePattern(type=1, content=[LeafPattern(type=1)], name="foo")
    assert n.type == 1
    assert n.content == [LeafPattern(type=1)]
    assert n.name == "foo"

# Generated at 2022-06-17 17:07:10.035557
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token
    n = Node(python_symbols.power, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])
    assert repr(n) == "Node(power, [Leaf(1, 'a'), Leaf(1, 'b')])"


# Generated at 2022-06-17 17:07:17.441049
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(tree, expected):
        tree.remove()
        assert tree.parent is None
        assert pytree.convert_tree(tree) == expected

    tree = Leaf(1, "foo")
    check(tree, "")

    tree = Node(syms.simple_stmt, [Leaf(1, "foo")])
    check(tree, "")

    tree = Node(syms.simple_stmt, [Leaf(1, "foo"), Leaf(1, "bar")])
    check(tree, "bar")

    tree = Node(syms.simple_stmt, [Leaf(1, "foo"), Leaf(1, "bar"), Leaf(1, "baz")])

# Generated at 2022-06-17 17:07:29.331595
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree

    def check(a, b, eq):
        if eq:
            assert a == b
            assert b == a
            assert not (a != b)
            assert not (b != a)
        else:
            assert a != b
            assert b != a
            assert not (a == b)
            assert not (b == a)

    # Check that the __eq__ method is symmetric.
    check(Leaf(1, "foo"), Leaf(1, "foo"), True)
    check(Leaf(1, "foo"), Leaf(1, "bar"), False)
    check(Leaf(1, "foo"), Leaf(2, "foo"), False)

# Generated at 2022-06-17 17:07:33.616934
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    import ast
    from asttokens import ASTTokens
    from asttokens.util import ast_matches
    from asttokens.util import ast_matches_seq
    from asttokens.util import ast_matches_seq_iter
    from asttokens.util import ast_matches_seq_rec
    from asttokens.util import ast_matches_seq_rec_iter
    from asttokens.util import ast_matches_seq_rec_iter_opt
    from asttokens.util import ast_matches_seq_rec_opt
    from asttokens.util import ast_matches_seq_rec_opt_iter
    from asttokens.util import ast_matches_seq_rec_opt_iter_opt
    from asttokens.util import ast_

# Generated at 2022-06-17 17:07:43.986861
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_post_order(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    def check_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_leaves(node, expected):
        result = list(node.leaves())
        assert result == expected, (result, expected)

    def check_depth(node, expected):
        result = node.depth()
        assert result == expected, (result, expected)

    def check_get_suffix(node, expected):
        result = node.get_suffix()

# Generated at 2022-06-17 17:09:25.625759
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "test")
    assert list(leaf.post_order()) == [leaf]


# Generated at 2022-06-17 17:09:37.498120
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(pytoken.NAME, "foo", (1, 0)), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "foo", (1, 0))]), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "foo", (1, 0)),
                                  Leaf(pytoken.NEWLINE, "\n", (1, 3))]), 1)

# Generated at 2022-06-17 17:09:52.191044
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected_pos):
        pos = node.remove()
        assert pos == expected_pos
        assert node.parent is None

    # Test removal of a leaf
    node = Leaf(1, "foo")
    parent = Node(syms.simple_stmt, [node])
    check(node, 0)
    assert parent.children == []

    # Test removal of a node
    node = Node(syms.simple_stmt, [Leaf(1, "foo")])
    parent = Node(syms.file_input, [node])
    check(node, 0)
    assert parent.children == []

    # Test removal of a node in the middle of a list

# Generated at 2022-06-17 17:10:03.356018
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.token import tok_name

    gr = Grammar(parse_grammar(StringIO(GRAMMAR), "exec"))
    p = LeafPattern(tok_name["NAME"], "foo")
    assert p.match_seq([Leaf(tok_name["NAME"], "foo")])
    assert not p.match_seq([Leaf(tok_name["NAME"], "bar")])
    assert not p.match_seq([Leaf(tok_name["NAME"], "foo"), Leaf(tok_name["NAME"], "bar")])
    assert not p.match_seq([])



# Generated at 2022-06-17 17:10:05.299338
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "a")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-17 17:10:16.860275
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(tree, expected):
        assert list(tree.leaves()) == expected

    check(Leaf(1, ""), [])
    check(Node(syms.file_input, [Leaf(1, ""), Leaf(1, "")]), [Leaf(1, ""), Leaf(1, "")])
    check(Node(syms.file_input, [Leaf(1, ""), Node(syms.file_input, [Leaf(1, "")])]), [Leaf(1, ""), Leaf(1, "")])

# Generated at 2022-06-17 17:10:27.576511
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from .pygram import python_grammar
    from .pgen2 import driver
    from . import fixer_base
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util

# Generated at 2022-06-17 17:10:39.818359
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar
    from .pgen2 import driver
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2

# Generated at 2022-06-17 17:10:46.129470
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    def check(node, parent):
        assert node.parent is parent
        assert parent.children[0] is node

    def check_none(node, parent):
        assert node.parent is None
        assert parent.children == []

    def check_removed(node, parent):
        assert node.parent is None
        assert parent.children == []

    # Test a leaf
    node = Leaf(1, "test")
    parent = Node(syms.simple_stmt, [node])
    check(node, parent)
    assert node.remove() == 0
    check_removed(node, parent)

    # Test a node
    node = Node(syms.simple_stmt, [Leaf(1, "test")])
   

# Generated at 2022-06-17 17:10:56.983949
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse
    from . import tokenize

    def test(pattern, text, expected):
        pattern = parse(pattern, mode="eval")
        text = tokenize.generate_tokens(StringIO(text).readline)
        actual = list(pattern.generate_matches(text))
        assert actual == expected, (actual, expected)

    test(".*", "", [(0, {})])
    test(".*", "1", [(1, {})])
    test(".*", "12", [(2, {})])
    test(".*", "123", [(3, {})])
    test(".+", "", [])
    test(".+", "1", [(1, {})])
    test(".+", "12", [(2, {})])