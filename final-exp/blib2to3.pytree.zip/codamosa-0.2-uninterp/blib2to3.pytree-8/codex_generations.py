

# Generated at 2022-06-17 17:03:24.334110
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import dump
    from . import findall
    from . import find
    from . import search
    from . import match
    from . import compile
    from . import visit

    # Test 1
    pattern = compile.compile("(a b c | d e | f g h)*")
    nodes = parse.parse("a b c d e f g h a b c d e f g h")
    for c, r in pattern.generate_matches(nodes):
        print(c, dump.dump(nodes[:c]), r)
    # Test 2
    pattern = compile.compile("(a b c | d e | f g h)*")
    nodes = parse.parse("a b c d e f g h a b c d e f g h")

# Generated at 2022-06-17 17:03:29.509292
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import grammar
    import sys

    def check(pattern, expected):
        optimized = pattern.optimize()
        if optimized != expected:
            print("pattern:", pattern)
            print("expected:", expected)
            print("optimized:", optimized)
            raise AssertionError("optimize() failed")

    check(WildcardPattern(min=0, max=1), WildcardPattern(min=0, max=1))
    check(WildcardPattern(min=1, max=1), NodePattern())
    check(WildcardPattern(min=1, max=1, name="x"), NodePattern(name="x"))
    check(
        WildcardPattern(min=1, max=1, name="x"),
        WildcardPattern(min=1, max=1, name="x"),
    )

# Generated at 2022-06-17 17:03:34.566891
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with values for instance variables
    pattern = BasePattern(type=1, content=2, name="name")
    assert repr(pattern) == "BasePattern(1, 2, 'name')"
    # Test with values for instance variables
    pattern = BasePattern(type=1, content=2)
    assert repr(pattern) == "BasePattern(1, 2)"
    # Test with values for instance variables
    pattern = BasePattern(type=1, name="name")
    assert repr(pattern) == "BasePattern(1, None, 'name')"
    # Test with values for instance variables
    pattern = BasePattern

# Generated at 2022-06-17 17:03:45.166233
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"

# Generated at 2022-06-17 17:03:56.990547
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_post_order(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    def check_both(node, expected_pre, expected_post):
        check_pre_order(node, expected_pre)
        check_post_order(node, expected_post)


# Generated at 2022-06-17 17:04:07.031772
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    node = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    node.update_sibling_maps()
    assert node.prev_sibling_map[id(node.children[0])] is None
    assert node.prev_sibling_map[id(node.children[1])] is node.children[0]
    assert node.prev_sibling_map[id(node.children[2])] is node.children[1]
    assert node.next_sibling_map[id(node.children[0])] is node.children[1]
    assert node.next_sibling_map[id(node.children[1])] is node.children[2]

# Generated at 2022-06-17 17:04:15.530735
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern(type=1, content=[LeafPattern(type=2), LeafPattern(type=3)])
    assert n.type == 1
    assert n.content == [LeafPattern(type=2), LeafPattern(type=3)]
    assert n.name is None
    n = NodePattern(type=1, content=[LeafPattern(type=2), LeafPattern(type=3)], name="foo")
    assert n.type == 1
    assert n.content == [LeafPattern(type=2), LeafPattern(type=3)]
    assert n.name == "foo"



# Generated at 2022-06-17 17:04:27.315041
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pgen2

# Generated at 2022-06-17 17:04:33.977125
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test(node, expected):
        result = list(node.leaves())
        assert result == expected, (result, expected)

    test(Leaf(1, ""), [])
    test(Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")]), [Leaf(1, "a"), Leaf(1, "b")])
    test(Node(syms.simple_stmt, [Leaf(1, "a"), Node(syms.expr_stmt, [Leaf(1, "b")])]), [Leaf(1, "a"), Leaf(1, "b")])

# Generated at 2022-06-17 17:04:39.640017
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from . import grammar

    def test(pattern, string, expected):
        assert pattern.match_seq(grammar.parse(string)) == expected

    test(WildcardPattern(), "", True)
    test(WildcardPattern(), "a", True)
    test(WildcardPattern(), "a b", True)
    test(WildcardPattern(), "a b c", True)
    test(WildcardPattern(min=1), "", False)
    test(WildcardPattern(min=1), "a", True)
    test(WildcardPattern(min=1), "a b", True)
    test(WildcardPattern(min=1), "a b c", True)
    test(WildcardPattern(max=1), "", True)
    test(WildcardPattern(max=1), "a", True)

# Generated at 2022-06-17 17:05:00.354411
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import python_tree
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_function
    from . import python_grammar_no_print_function_no_exec_statement
    from . import python_grammar_no_print_function_no_exec_statement_no_trailing_comma
    from . import python_grammar_no_print_function_no_exec_statement_no_trailing_comma_no_backtick

# Generated at 2022-06-17 17:05:12.358270
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_leaves(tree, expected):
        leaves = list(tree.leaves())
        assert len(leaves) == len(expected)
        for leaf, expected in zip(leaves, expected):
            assert leaf.value == expected

    tree = pytree.Node(syms.file_input, [
        pytree.Leaf(1, "a"),
        pytree.Node(syms.simple_stmt, [
            pytree.Leaf(1, "b"),
            pytree.Leaf(1, "c"),
            pytree.Leaf(1, "d"),
        ]),
        pytree.Leaf(1, "e"),
    ])
    check_le

# Generated at 2022-06-17 17:05:24.621613
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    # Test a simple tree
    node = Node(syms.file_input, [Leaf(1, "a"), Leaf(2, "b")])
    check(node, [Leaf(1, "a"), Leaf(2, "b"), node])

    # Test a more complex tree

# Generated at 2022-06-17 17:05:27.512776
# Unit test for method leaves of class Base
def test_Base_leaves():
    class TestNode(Node):
        def __init__(self, children):
            super().__init__(None, children)

    class TestLeaf(Leaf):
        def __init__(self, value):
            super().__init__(None, value)

    n = TestNode([TestLeaf("a"), TestNode([TestLeaf("b"), TestLeaf("c")])])
    assert list(n.leaves()) == [TestLeaf("a"), TestLeaf("b"), TestLeaf("c")]



# Generated at 2022-06-17 17:05:35.234345
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree_builder
    from . import pytree_utils
    from . import pytree_visitor
    from . import pytree_matcher
    from . import pytree_transforms
    from . import pytree_unparser
    from . import pytree_resolver
    from . import pytree_to_asm
    from . import pytree_to_c
    from . import pytree_to_js
    from . import pytree_to_pyc
    from . import pytree_to_pyx
    from . import py

# Generated at 2022-06-17 17:05:44.502846
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import unittest
    from . import parse


# Generated at 2022-06-17 17:05:53.792044
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected_parent, expected_index):
        assert node.remove() == expected_index
        assert node.parent is None
        assert expected_parent.children[expected_index] is not node

    # Test removing a leaf
    leaf = Leaf(1, "foo")
    parent = Node(syms.simple_stmt, [leaf])
    check(leaf, parent, 0)

    # Test removing a node
    node = Node(syms.simple_stmt, [Leaf(1, "foo")])
    parent = Node(syms.file_input, [node])
    check(node, parent, 0)

    # Test removing a node with multiple children

# Generated at 2022-06-17 17:06:01.650836
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree

    def check(node, expected):
        assert node.depth() == expected

    check(Node(python_symbols.file_input, [Leaf(1, "a"), Leaf(1, "b")]), 0)
    check(Node(python_symbols.file_input, [Leaf(1, "a"), Node(2, [Leaf(1, "b")])]), 0)
    check(Node(python_symbols.file_input, [Leaf(1, "a"), Node(2, [Node(3, [Leaf(1, "b")])])]), 0)

# Generated at 2022-06-17 17:06:11.175258
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w = WildcardPattern(min=1, max=1)
    assert w.min == 1
    assert w.max == 1
    assert w.content is None
    assert w.name is None
    w = WildcardPattern(min=0, max=1)
    assert w.min == 0
    assert w.max == 1
    assert w.content is None
    assert w.name is None
    w = WildcardPattern(min=1, max=2)
    assert w.min == 1
    assert w.max == 2
    assert w.content is None
    assert w.name is None
    w = WildcardPattern(min=0, max=2)
    assert w.min == 0
    assert w.max == 2
    assert w.content is None
    assert w.name is None

# Generated at 2022-06-17 17:06:18.031420
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, expected):
        assert list(node.leaves()) == expected

    check(Leaf(token.NAME, "foo"), [Leaf(token.NAME, "foo")])
    check(
        Node(syms.simple_stmt, [Leaf(token.NAME, "foo")]),
        [Leaf(token.NAME, "foo")],
    )
    check(
        Node(syms.simple_stmt, [Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")]),
        [Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")],
    )

# Generated at 2022-06-17 17:07:12.267957
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token

    def test_post_order(node, expected):
        actual = [x.type for x in node.post_order()]
        assert actual == expected, (actual, expected)


# Generated at 2022-06-17 17:07:24.457136
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse
    from . import dump

    def test(pattern, string, expected):
        tree = parse(string)
        result = list(pattern.generate_matches(tree.children))
        assert result == expected, (result, expected)

    # Test the special case of a single node
    test(WildcardPattern(), "a", [(1, {})])
    test(WildcardPattern(), "a b", [(1, {})])
    test(WildcardPattern(), "a b c", [(1, {})])
    test(WildcardPattern(min=1), "a", [(1, {})])
    test(WildcardPattern(min=1), "a b", [(1, {})])
    test(WildcardPattern(min=1), "a b c", [(1, {})])

# Generated at 2022-06-17 17:07:36.520553
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("file_input", ("NEWLINE",))
    gr.add_production("file_input", ("stmt", "file_input"))
    gr.add_production("stmt", ("simple_stmt",))
    gr.add_production("stmt", ("compound_stmt",))
    gr.add_production("simple_stmt", ("small_stmt", "NEWLINE"))
    gr.add_production("simple_stmt", ("small_stmt", "SEMI", "NEWLINE"))
    gr.add_production("simple_stmt", ("small_stmt", "SEMI", "small_stmt", "NEWLINE"))
    gr.add_production("small_stmt", ("expr_stmt",))

# Generated at 2022-06-17 17:07:38.991252
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Test that the optimize method returns self by default
    class Pattern(BasePattern):
        pass
    p = Pattern()
    assert p.optimize() is p


# Generated at 2022-06-17 17:07:53.265725
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_post_order(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    def check_both(node, expected_pre, expected_post):
        check_pre_order(node, expected_pre)
        check_post_order(node, expected_post)


# Generated at 2022-06-17 17:08:01.988280
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """
    Unit test for method __repr__ of class Node
    """
    from .pytree import Leaf
    from .pygram import python_symbols
    node = Node(python_symbols.testlist_star_expr, [Leaf(1, "a"), Leaf(1, "b")])
    assert repr(node) == "Node(testlist_star_expr, [Leaf(1, 'a'), Leaf(1, 'b')])"

# Generated at 2022-06-17 17:08:03.798784
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "a")
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-17 17:08:17.116450
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(n1, n2, eq):
        assert (n1 == n2) == eq
        assert (n2 == n1) == eq
        assert (n1 != n2) != eq
        assert (n2 != n1) != eq

    check(Leaf(1, ""), Leaf(1, ""), True)
    check(Leaf(1, ""), Leaf(2, ""), False)
    check(Leaf(1, ""), Leaf(1, "x"), False)
    check(Leaf(1, "x"), Leaf(1, ""), False)
    check(Leaf(1, "x"), Leaf(1, "x"), True)

# Generated at 2022-06-17 17:08:29.127409
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(a, b, eq):
        assert (a == b) == eq, (a, b, eq)
        assert (b == a) == eq, (b, a, eq)
        assert (a != b) != eq, (a, b, eq)
        assert (b != a) != eq, (b, a, eq)

    # Test Leaf
    check(Leaf(1, ""), Leaf(1, ""), True)
    check(Leaf(1, ""), Leaf(1, "x"), False)
    check(Leaf(1, ""), Leaf(2, ""), False)
    check(Leaf(1, ""), Leaf(2, "x"), False)
   

# Generated at 2022-06-17 17:08:41.013504
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def check(patterns, nodes, expected):
        result = list(generate_matches(patterns, nodes))
        assert result == expected, (patterns, nodes, expected, result)

    # Test a single pattern
    check([NodePattern(type=ast.expr)], [], [])
    check([NodePattern(type=ast.expr)], [ast.Expr()], [(1, {})])
    check([NodePattern(type=ast.expr)], [ast.Expr(), ast.Expr()], [(1, {})])
    check([NodePattern(type=ast.expr)], [ast.Expr(), ast.Expr(), ast.Expr()], [(1, {})])

# Generated at 2022-06-17 17:09:38.343887
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar

# Generated at 2022-06-17 17:09:52.428608
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import dump
    from . import findall
    from . import find
    from . import find_data
    from . import find_all_data
    from . import find_all
    from . import find_one
    from . import find_one_data
    from . import search
    from . import search_data
    from . import search_all
    from . import search_all_data
    from . import search_one
    from . import search_one_data
    from . import visit
    from . import visit_data
    from . import visit_all
    from . import visit_all_data
    from . import visit_one
    from . import visit_one_data
    from . import visit_values
    from . import visit_values_data
    from . import visit_all_values

# Generated at 2022-06-17 17:10:04.927374
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from . import grammar

    def _test(pattern, nodes, expected):
        actual = pattern.match_seq(nodes)
        assert actual == expected, (pattern, nodes, actual)

    def _test_all(pattern, nodes, expected):
        actual = list(pattern.generate_matches(nodes))
        assert actual == expected, (pattern, nodes, actual)

    # Test the special case of a single node
    _test(WildcardPattern(), [Leaf(1, "a")], True)
    _test(WildcardPattern(), [Leaf(1, "b")], False)
    _test(WildcardPattern(name="x"), [Leaf(1, "a")], True)
    _test(WildcardPattern(name="x"), [Leaf(1, "b")], False)

# Generated at 2022-06-17 17:10:16.817661
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test for empty sequence
    pattern = NegatedPattern()
    for c, r in pattern.generate_matches([]):
        assert c == 0
        assert r == {}
    # Test for non-empty sequence
    pattern = NegatedPattern()
    for c, r in pattern.generate_matches([1, 2, 3]):
        assert False
    # Test for empty sequence
    pattern = NegatedPattern(NodePattern(type=1))
    for c, r in pattern.generate_matches([]):
        assert c == 0
        assert r == {}
    # Test for non-empty sequence
    pattern = NegatedPattern(NodePattern(type=1))
    for c, r in pattern.generate_matches([1, 2, 3]):
        assert False
    # Test for empty sequence
    pattern = Neg

# Generated at 2022-06-17 17:10:27.525077
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_clone(node):
        clone = node.clone()
        assert node == clone
        assert node is not clone
        assert node.parent is None
        assert clone.parent is None
        assert node.children == clone.children
        for child, clone_child in zip(node.children, clone.children):
            assert child is not clone_child
            assert child.parent is node
            assert clone_child.parent is clone
            check_clone(child)

    check_clone(pytree.Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")]))

# Generated at 2022-06-17 17:10:39.732621
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from . import pytree
    from .pgen2 import driver
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree


# Generated at 2022-06-17 17:10:46.111386
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree
    from . import pygram


# Generated at 2022-06-17 17:10:56.927294
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        assert node.clone() == expected
        assert node.clone() is not expected

    check(Leaf(1, ""), Leaf(1, ""))
    check(Leaf(1, "a"), Leaf(1, "a"))
    check(Leaf(1, "a", (1, 2)), Leaf(1, "a", (1, 2)))
    check(Leaf(1, "a", (1, 2), prefix="b"), Leaf(1, "a", (1, 2), prefix="b"))