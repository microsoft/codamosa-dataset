

# Generated at 2022-06-17 17:03:03.046194
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.pgen import Pgen
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    def parse(s: Text) -> NL:
        driver = Driver(Grammar(), convert)
        try:
            return driver.parse_tokens(tokenize.generate_tokens(StringIO(s).readline))
        except ParseError as e:
            print(e.args[0])
            raise

    def test(s: Text, expected: Text) -> None:
        t = parse(s)
        assert str(t) == expected

    test("a", "a")
    test("a b", "a b")

# Generated at 2022-06-17 17:03:08.107174
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def test(pattern, text, expected):
        tree = parse(text)
        assert list(pattern.generate_matches(tree.children)) == expected

    test(
        WildcardPattern(),
        "a",
        [(1, {})],
    )
    test(
        WildcardPattern(min=2),
        "a",
        [],
    )
    test(
        WildcardPattern(min=2),
        "a b",
        [(2, {})],
    )
    test(
        WildcardPattern(min=2),
        "a b c",
        [(2, {}), (3, {})],
    )
    test(
        WildcardPattern(min=2, max=2),
        "a b c",
        [(2, {})],
    )

# Generated at 2022-06-17 17:03:19.008076
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_grammar
    from .pgen2.pgen import generate_tokens
    from .pgen2.pgen import generate_grammar_tokens
    from .pgen2.pgen import generate_grammar_ast
    from .pgen2.pgen import generate_grammar_ast_tokens
    from .pgen2.pgen import generate_grammar_ast_tokens_ast
    from .pgen2.pgen import generate_grammar_ast_tokens_ast_tokens

# Generated at 2022-06-17 17:03:26.076010
# Unit test for method set_child of class Node
def test_Node_set_child():
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.driver as driver
    import lib2to3.pygram as pygram
    import lib2to3.pytree as pytree
    import lib2to3.fixer_base as fixer_base
    import lib2to3.fixer_util as fixer_util
    import lib2to3.patcomp as patcomp
    import lib2to3.pgen2.convert as convert
    import lib2to3.pgen2.tokenize as tokenize
    import lib2to3.refactor as refactor
    import libfuturize.fixes.fix_basestring as fix_basestring
    import libfuturize.fixes.fix_dict

# Generated at 2022-06-17 17:03:29.593354
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"



# Generated at 2022-06-17 17:03:38.332226
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    root = Node(1, [Leaf(1, "a"), Node(1, [Leaf(1, "b"), Leaf(1, "c")])])
    assert root.depth() == 0
    assert root.children[0].depth() == 1
    assert root.children[1].depth() == 1
    assert root.children[1].children[0].depth() == 2
    assert root.children[1].children[1].depth() == 2



# Generated at 2022-06-17 17:03:42.746026
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern(
        [
            [
                NodePattern(type=token.NAME),
                WildcardPattern(
                    [
                        [
                            NodePattern(type=token.NAME),
                            NodePattern(type=token.NAME),
                        ]
                    ],
                    min=0,
                    max=1,
                ),
            ]
        ],
        min=1,
        max=1,
    )
    assert p.optimize() == WildcardPattern(
        [
            [
                NodePattern(type=token.NAME),
                NodePattern(type=token.NAME),
            ]
        ],
        min=1,
        max=1,
    )



# Generated at 2022-06-17 17:03:50.630686
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert repr(LeafPattern(1)) == "LeafPattern(1, None, None)"
    assert repr(LeafPattern(1, "foo")) == "LeafPattern(1, 'foo', None)"
    assert repr(LeafPattern(1, "foo", "bar")) == "LeafPattern(1, 'foo', 'bar')"
    assert repr(NodePattern(1)) == "NodePattern(1, None, None)"
    assert repr(NodePattern(1, "foo")) == "NodePattern(1, 'foo', None)"
    assert repr(NodePattern(1, "foo", "bar")) == "NodePattern(1, 'foo', 'bar')"
    assert repr(WildcardPattern()) == "WildcardPattern(None, None, None)"

# Generated at 2022-06-17 17:03:59.813029
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf

    class Node(Base):
        def __init__(self, children):
            self.children = children

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def _eq(self, other):
            return self.children == other.children

        def clone(self):
            return Node(self.children)

    class Leaf(Base):
        def __init__(self, value):
            self.value = value

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

        def _eq(self, other):
            return self.value

# Generated at 2022-06-17 17:04:11.790551
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    # Test with a LeafPattern
    p = LeafPattern(token.NAME)
    assert repr(p) == "LeafPattern(NAME, None, None)"
    # Test with a NodePattern
    p = NodePattern(syms.expr)
    assert repr(p) == "NodePattern(expr, None, None)"
    # Test with a WildcardPattern
    p = WildcardPattern()
    assert repr(p) == "WildcardPattern(None, None, None)"
    # Test with a WildcardPattern with a name
    p = WildcardPattern(name="foo")
    assert repr(p) == "WildcardPattern(None, None, 'foo')"
    # Test with a WildcardPattern with a content

# Generated at 2022-06-17 17:04:40.375602
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver

    # Generate a grammar from the Python grammar file
    g = generate_grammar("Grammar.txt")

    # Create a parser driver
    d = Driver(g, convert)

    # Parse a couple of test cases
    for s in ["1 + 2", "1 + 2 + 3"]:
        try:
            tree = d.parse(s, start="eval_input")
        except ParseError as err:
            print("Error:", err)
            continue
        print("Input:", s)
        print("Tree:", tree)

# Generated at 2022-06-17 17:04:42.247131
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, "a")
    assert list(l.leaves()) == [l]


# Generated at 2022-06-17 17:04:53.710656
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import tokenize
    from . import token
    from . import grammar
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import tokenize
    from . import token
    from . import grammar
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import tokenize
    from . import token
    from . import grammar
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pytoken
   

# Generated at 2022-06-17 17:04:55.341496
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "test")
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-17 17:05:07.780628
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def assert_depth(node, expected_depth):
        assert node.depth() == expected_depth

    assert_depth(Leaf(1, ""), 0)
    assert_depth(Node(syms.file_input, [Leaf(1, "")]), 1)
    assert_depth(Node(syms.file_input, [Node(syms.file_input, [Leaf(1, "")])]), 2)
    assert_depth(Node(syms.file_input, [Node(syms.file_input, [Node(syms.file_input, [Leaf(1, "")])])]), 3)



# Generated at 2022-06-17 17:05:21.247327
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from .pygram import python_grammar
    from .pgen2 import driver
    from . import pygram
    from .pygram import python_grammar_no_print_statement
    from .pgen2 import tokenize
    from .pgen2 import parse
    from .pgen2 import driver
    from .pgen2 import grammar
    from .pygram import python_symbols
    from .pgen2 import pgen
    from .pgen2 import token
    from .pgen2 import driver
    from .pgen2 import parse
    from .pgen2 import grammar
    from .pygram import python_grammar
    from .pygram import python_

# Generated at 2022-06-17 17:05:28.913332
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"

# Generated at 2022-06-17 17:05:39.294670
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def test_leaves(tree, expected):
        leaves = list(tree.leaves())
        assert len(leaves) == len(expected)
        for leaf, expected_value in zip(leaves, expected):
            assert isinstance(leaf, Leaf)
            assert leaf.value == expected_value

    tree = pytree.Node(syms.file_input, [
        pytree.Leaf(1, "a"),
        pytree.Node(syms.stmt, [
            pytree.Leaf(1, "b"),
            pytree.Leaf(1, "c"),
        ]),
        pytree.Leaf(1, "d"),
    ])

# Generated at 2022-06-17 17:05:49.603666
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern([[LeafPattern(token.NAME, "foo")]], min=1, max=1)
    assert p.optimize() == LeafPattern(token.NAME, "foo")
    p = WildcardPattern([[LeafPattern(token.NAME, "foo")]], min=1, max=2)
    assert p.optimize() == WildcardPattern([[LeafPattern(token.NAME, "foo")]], min=1, max=2)
    p = WildcardPattern([[LeafPattern(token.NAME, "foo")]], min=2, max=2)
    assert p.optimize() == WildcardPattern([[LeafPattern(token.NAME, "foo")]], min=2, max=2)

# Generated at 2022-06-17 17:05:53.389461
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    n = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    n.children[0].replace(Leaf(1, "baz"))
    assert n.children == [Leaf(1, "baz"), Leaf(1, "bar")]



# Generated at 2022-06-17 17:06:30.683515
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree_utils
    from .pytree import type_repr

    def assert_eq(node1, node2):
        assert node1 == node2
        assert node2 == node1
        assert not (node1 != node2)
        assert not (node2 != node1)
        assert hash(node1) == hash(node2)

    def assert_ne(node1, node2):
        assert node1 != node2
        assert node2 != node1
        assert not (node1 == node2)
        assert not (node2 == node1)

    # Test Leaf
    leaf1 = Leaf(token.NAME, "foo")

# Generated at 2022-06-17 17:06:43.051462
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        result = node.clone()
        assert result == expected, (result, expected)
        assert result is not node
        assert result.parent is None
        assert result.children != node.children
        for i, ch in enumerate(result.children):
            assert ch is not node.children[i]
            assert ch.parent is result

    def check_prefix(node, expected):
        result = node.clone()
        assert result.prefix == expected
        assert result.children[0].prefix == expected


# Generated at 2022-06-17 17:06:55.209511
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node1, node2, expected):
        assert (node1 == node2) == expected
        assert (node2 == node1) == expected

    # Test Leaf
    l1 = Leaf(1, "foo")
    l2 = Leaf(1, "foo")
    l3 = Leaf(1, "bar")
    l4 = Leaf(2, "foo")
    check(l1, l1, True)
    check(l1, l2, True)
    check(l1, l3, False)
    check(l1, l4, False)

    # Test Node
    n1 = Node(syms.simple_stmt, [l1])

# Generated at 2022-06-17 17:07:07.044651
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    # Test removing a leaf
    leaf = Leaf(1, "foo")
    assert leaf.remove() is None
    leaf.parent = Node(syms.simple_stmt, [leaf])
    assert leaf.remove() == 0
    assert leaf.parent is None

    # Test removing a node
    node = Node(syms.simple_stmt, [leaf])
    node.parent = Node(syms.file_input, [node])
    assert node.remove() == 0
    assert node.parent is None

    # Test removing a node with multiple children
    node = Node(syms.simple_stmt, [Leaf(1, "foo"), Leaf(1, "bar")])

# Generated at 2022-06-17 17:07:15.591176
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, new, expected):
        node.replace(new)
        assert node.parent is None
        assert expected == node.parent.children

    # Replace a leaf with a leaf
    leaf = Leaf(1, "foo")
    new = Leaf(1, "bar")
    check(leaf, new, [new])

    # Replace a leaf with a node
    leaf = Leaf(1, "foo")
    new = Node(syms.simple_stmt, [Leaf(1, "bar")])
    check(leaf, new, [new])

    # Replace a node with a leaf
    node = Node(syms.simple_stmt, [Leaf(1, "foo")])

# Generated at 2022-06-17 17:07:27.649158
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_parent, expected_pos):
        assert node.parent is expected_parent
        if expected_parent is None:
            assert node.remove() is None
        else:
            assert node.remove() == expected_pos
            assert node.parent is None
            assert expected_parent.children[expected_pos] is not node

    def check_all(node, expected_parent, expected_pos):
        check(node, expected_parent, expected_pos)
        for child in node.children:
            check_all(child, node, node.children.index(child))

    def check_tree(tree):
        check_all(tree, None, None)


# Generated at 2022-06-17 17:07:39.034926
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    grammar = pygram.python_grammar
    pytree = Node(syms.file_input, [
        Node(syms.stmt, [
            Leaf(token.NAME, "print"),
            Leaf(token.LPAR, "("),
            Leaf(token.STRING, '"Hello, world!"'),
            Leaf(token.RPAR, ")"),
            Leaf(token.NEWLINE, "\n"),
        ]),
        Leaf(token.ENDMARKER, ""),
    ])

# Generated at 2022-06-17 17:07:53.266464
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:08:04.284614
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf
    n = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    n2 = n.clone()
    assert n == n2
    assert n is not n2
    assert n.children[0] is not n2.children[0]
    assert n.children[1] is not n2.children[1]
    assert n.children[2] is not n2.children[2]
    assert n.children[0].parent is n2
    assert n.children[1].parent is n2
    assert n.children[2].parent is n2



# Generated at 2022-06-17 17:08:17.526771
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, cloned):
        assert node.type == cloned.type
        assert node.children == cloned.children
        assert node.prefix == cloned.prefix
        assert node.parent is None
        assert cloned.parent is None
        assert node.changed() == cloned.changed()
        assert node.was_changed == cloned.was_changed
        assert node.was_checked == cloned.was_checked

    leaf = Leaf(1, "foo")
    check(leaf, leaf.clone())

    node = Node(syms.simple_stmt, [leaf])
    check(node, node.clone())

    node = Node(syms.file_input, [node])

# Generated at 2022-06-17 17:08:48.331848
# Unit test for method depth of class Base
def test_Base_depth():
    class Node(Base):
        def __init__(self, children):
            self.children = children
        def _eq(self, other):
            return self.children == other.children
        def clone(self):
            return Node(self.children)
        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()
    class Leaf(Base):
        def __init__(self, value):
            self.value = value
        def _eq(self, other):
            return self.value == other.value
        def clone(self):
            return Leaf(self.value)
        def post_order(self):
            yield self


# Generated at 2022-06-17 17:09:00.805185
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:09:02.570258
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(256, [])
    assert repr(node) == "Node(256, [])"


# Generated at 2022-06-17 17:09:15.967603
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:09:25.665223
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(tree, expected):
        result = [x.type for x in tree.post_order()]
        assert result == expected, (result, expected)

    def check_str(tree, expected):
        result = [x.value for x in tree.post_order()]
        assert result == expected, (result, expected)

    def check_prefix(tree, expected):
        result = [x.prefix for x in tree.post_order()]
        assert result == expected, (result, expected)

    def check_suffix(tree, expected):
        result = [x.get_suffix() for x in tree.post_order()]
        assert result == expected, (result, expected)



# Generated at 2022-06-17 17:09:37.541608
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

# Generated at 2022-06-17 17:09:52.195618
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token

    # Test equality of two leaf nodes
    l1 = Leaf(token.NAME, "foo")
    l2 = Leaf(token.NAME, "foo")
    assert l1 == l2

    # Test inequality of two leaf nodes
    l1 = Leaf(token.NAME, "foo")
    l2 = Leaf(token.NAME, "bar")
    assert l1 != l2

    # Test equality of two node nodes
    n1 = Node(python_symbols.power, [Leaf(token.NAME, "foo")])
    n2 = Node(python_symbols.power, [Leaf(token.NAME, "foo")])
    assert n1 == n2

    # Test inequality of two node

# Generated at 2022-06-17 17:09:57.793773
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    p = NegatedPattern()
    assert list(p.generate_matches([])) == [(0, {})]
    assert list(p.generate_matches(["a"])) == []
    p = NegatedPattern(WildcardPattern())
    assert list(p.generate_matches([])) == []
    assert list(p.generate_matches(["a"])) == [(0, {})]
    p = NegatedPattern(WildcardPattern(min=2))
    assert list(p.generate_matches([])) == []
    assert list(p.generate_matches(["a"])) == []
    assert list(p.generate_matches(["a", "b"])) == [(0, {})]
    p = NegatedPattern(WildcardPattern(min=2, max=2))
   

# Generated at 2022-06-17 17:10:07.173502
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(token.NAME, "foo", (1, 0)), 1)
    check(Leaf(token.NAME, "foo", (1, 0)), 1)
    check(Node(syms.simple_stmt, [Leaf(token.NAME, "foo", (1, 0))]), 1)
    check(Node(syms.simple_stmt, [Leaf(token.NAME, "foo", (1, 0))]), 1)

# Generated at 2022-06-17 17:10:14.743228
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(1, [])
    assert repr(node) == "Node(1, [])"
    node = Node(1, [Leaf(1, "")])
    assert repr(node) == "Node(1, [Leaf(1, '')])"
    node = Node(1, [Leaf(1, ""), Leaf(1, "")])
    assert repr(node) == "Node(1, [Leaf(1, ''), Leaf(1, '')])"


# Generated at 2022-06-17 17:10:38.046844
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pygram

    def test_get_lineno(node, lineno):
        assert node.get_lineno() == lineno

    # Test a simple leaf
    test_get_lineno(Leaf(1, "foo"), None)

    # Test a simple node
    test_get_lineno(Node(syms.simple_stmt, [Leaf(1, "foo")]), None)

    # Test a node with a lineno
    test_get_lineno(
        Node(syms.simple_stmt, [Leaf(1, "foo", (1, 1))]),
        1
    )

    # Test a node with a lineno and prefix

# Generated at 2022-06-17 17:10:50.429139
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import LST
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer
    from .pgen2.pgen import PgenPrinter
    from .pgen2.pgen import PgenGenerator
    from .pgen2.pgen import PgenGlobal
    from .pgen2.pgen import Pgen
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer
    from .pgen2.pgen import PgenPrinter