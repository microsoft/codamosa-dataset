

# Generated at 2022-06-17 17:03:44.641535
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_with_statement
    from . import python_grammar_no_async_keywords
    from . import python_grammar_no_async_keywords_no_print_statement
    from . import python_grammar_no_async_keywords_no_with_statement
    from . import python_grammar_no_keywords
    from . import python_grammar_no_keywords_no_print_statement
    from . import python_grammar_no_keywords_no_with_statement

# Generated at 2022-06-17 17:03:56.788691
# Unit test for method clone of class Base
def test_Base_clone():
    import unittest
    from .pytree import Leaf, Node

    class TestBase(unittest.TestCase):
        def test_clone(self):
            # Test that clone() works for both Leaf and Node.
            l = Leaf(1, "foo")
            l2 = l.clone()
            self.assertEqual(l2.type, 1)
            self.assertEqual(l2.value, "foo")
            self.assertEqual(l2.prefix, "")
            self.assertEqual(l2.parent, None)
            self.assertEqual(l2.children, [])
            n = Node(2, [l])
            n2 = n.clone()
            self.assertEqual(n2.type, 2)
            self.assertEqual(n2.children, [l2])

# Generated at 2022-06-17 17:04:03.615520
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    tree = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    tree.children[1].replace([Leaf(1, "x"), Leaf(1, "y")])
    assert tree.children == [Leaf(1, "a"), Leaf(1, "x"), Leaf(1, "y"), Leaf(1, "c")]



# Generated at 2022-06-17 17:04:15.682608
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from . import pygram
    from .pgen2 import token
    from . import python_symbols as syms
    from . import pytree
    from .fixer_util import Name
    from .fixer_util import Comma
    from .fixer_util import Newline
    from .fixer_util import Token
    from .fixer_util import Number
    from .fixer_util import String
    from .fixer_util import Keyword
    from .fixer_util import LParen
    from .fixer_util import RParen
    from .fixer_util import Dot
    from .fixer_util import Assign
    from .fixer_util import Attr
    from .fixer_util import Add
    from .fixer_util import Sub

# Generated at 2022-06-17 17:04:27.475632
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:04:39.700516
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import LST
    from .pgen2.pgen import LST_END
    from .pgen2.pgen import LST_SEP
    from .pgen2.pgen import NAME
    from .pgen2.pgen import NUMBER
    from .pgen2.pgen import OP
    from .pgen2.pgen import STRING
    from .pgen2.pgen import SUBSCRIPTS
    from .pgen2.pgen import SYM_EOF
    from .pgen2.pgen import SYM_NAME

# Generated at 2022-06-17 17:04:51.053397
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.ERRORTOKEN) == "ERRORTOKEN"
    assert type_repr(python_symbols.N_TOKENS) == "N_TOKENS"
    assert type_repr(python_symbols.NT_OFFSET) == "NT_OFFSET"
    assert type_re

# Generated at 2022-06-17 17:04:59.570945
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    l1 = Leaf(1, "a")
    l2 = Leaf(1, "b")
    l3 = Leaf(1, "c")
    l4 = Leaf(1, "d")
    l5 = Leaf(1, "e")
    l6 = Leaf(1, "f")
    l7 = Leaf(1, "g")
    l8 = Leaf(1, "h")
    l9 = Leaf(1, "i")
    l10 = Leaf(1, "j")
    l11 = Leaf(1, "k")
    l12 = Leaf(1, "l")
    l13 = Leaf(1, "m")
    l14 = Leaf(1, "n")
    l15 = Leaf(1, "o")

# Generated at 2022-06-17 17:05:12.025331
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def _test(node, i, child):
        node.set_child(i, child)
        assert node.children[i] is child
        assert child.parent is node

    def _test_all(node, i, child):
        _test(node, i, child)
        _test(node.clone(), i, child.clone())

    _test_all(Node(syms.file_input, [Leaf(token.INDENT, "")]), 0, Leaf(token.INDENT, ""))

# Generated at 2022-06-17 17:05:13.854327
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:05:52.367920
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver

# Generated at 2022-06-17 17:06:01.530073
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def test(node, lineno):
        assert node.get_lineno() == lineno

    test(Leaf(1, ""), None)
    test(Leaf(1, "", (1, 0)), 1)
    test(Leaf(1, "", (2, 0)), 2)
    test(Leaf(1, "", (1, 0), parent=pytree.Node(syms.simple_stmt, [])), 1)
    test(Leaf(1, "", (2, 0), parent=pytree.Node(syms.simple_stmt, [])), 2)

# Generated at 2022-06-17 17:06:10.824616
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token

    def _test(a, b, eq):
        if eq:
            assert a == b
            assert b == a
            assert not (a != b)
            assert not (b != a)
        else:
            assert not (a == b)
            assert not (b == a)
            assert a != b
            assert b != a

    _test(Leaf(1, ""), Leaf(1, ""), True)
    _test(Leaf(1, ""), Leaf(1, "x"), False)
    _test(Leaf(1, ""), Leaf(2, ""), False)
    _test(Leaf(1, ""), Leaf(2, "x"), False)

# Generated at 2022-06-17 17:06:22.732516
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node

    class MyNode(Node):
        def _eq(self, other):
            return self.type == other.type and self.children == other.children

        def clone(self):
            return MyNode(self.type, [child.clone() for child in self.children])

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

    class MyLeaf(Leaf):
        def _eq(self, other):
            return self.type == other.type and self.value == other.value

        def clone(self):
            return MyLeaf(self.type, self.value)



# Generated at 2022-06-17 17:06:31.560449
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    check(Leaf(token.NAME, "a"), [Leaf(token.NAME, "a")])
    check(
        Node(syms.expr_stmt, [Leaf(token.NAME, "a"), Leaf(token.EQUAL, "=")]),
        [
            Leaf(token.NAME, "a"),
            Leaf(token.EQUAL, "="),
            Node(syms.expr_stmt, [Leaf(token.NAME, "a"), Leaf(token.EQUAL, "=")]),
        ],
    )

# Generated at 2022-06-17 17:06:43.514437
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree

    def check(a, b, eq):
        assert (a == b) == eq
        assert (b == a) == eq
        assert (a != b) != eq
        assert (b != a) != eq

    def check_node(a, b, eq):
        check(a, b, eq)
        check(Node(a.type, [a]), Node(b.type, [b]), eq)

    def check_leaf(a, b, eq):
        check(a, b, eq)
        check(Leaf(a.type, a.value), Leaf(b.type, b.value), eq)


# Generated at 2022-06-17 17:06:55.467327
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from .pgen2 import driver
    from . import pytoken
    from .pgen2 import tokenize
    from . import pytokenize
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six
    from . import six

# Generated at 2022-06-17 17:07:07.395903
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import driver

    gr = driver.load_grammar("Grammar/Grammar")
    p = NodePattern(gr.symbol2number["expr_stmt"], name="expr_stmt")
    p = p.optimize()
    p.generate_matches([])
    p.generate_matches([1])
    p.generate_matches([1, 2])
    p.generate_matches([1, 2, 3])
    p.generate_matches([1, 2, 3, 4])
    p.generate_matches([1, 2, 3, 4, 5])
    p.generate_matches([1, 2, 3, 4, 5, 6])
    p.generate_matches([1, 2, 3, 4, 5, 6, 7])

# Generated at 2022-06-17 17:07:15.748345
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, new, expected):
        node.replace(new)
        assert node.parent is None
        assert expected == node.parent.children
        for n in expected:
            assert n.parent is node.parent

    def check_all(node, new, expected):
        check(node, new, expected)
        check(node.clone(), new, expected)

    def check_all_list(node, new, expected):
        check_all(node, new, expected)
        check_all(node, [new], expected)

    def check_all_list_list(node, new, expected):
        check_all_list(node, new, expected)

# Generated at 2022-06-17 17:07:27.824141
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util

# Generated at 2022-06-17 17:08:05.531911
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, new, expected):
        node.replace(new)
        assert node.parent is None
        assert node.children == []
        assert expected == node.parent.children

    def check_exception(node, new):
        try:
            node.replace(new)
        except AssertionError:
            pass
        else:
            assert False, "Expected AssertionError"

    # Replace a leaf with a leaf
    node = Leaf(1, "a")
    new = Leaf(1, "b")
    check(node, new, [new])

    # Replace a leaf with a node
    node = Leaf(1, "a")

# Generated at 2022-06-17 17:08:18.185702
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp = WildcardPattern(min=1, max=1)
    assert wp.optimize() == NodePattern()
    wp = WildcardPattern(min=1, max=1, name="foo")
    assert wp.optimize() == NodePattern(name="foo")
    wp = WildcardPattern(min=1, max=1, name="foo")
    assert wp.optimize() == NodePattern(name="foo")
    wp = WildcardPattern(min=1, max=1, name="foo")
    assert wp.optimize() == NodePattern(name="foo")
    wp = WildcardPattern(min=1, max=1, name="foo")
    assert wp.optimize() == NodePattern(name="foo")

# Generated at 2022-06-17 17:08:29.460348
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import tree

    def test(pattern, nodes):
        pattern = parse.parse(pattern)
        nodes = tree.build_from_tokens(nodes)
        for c, r in pattern.generate_matches(nodes):
            print(c, r)
        print()

    test("!.", [])
    test("!.", [1])
    test("!.", [1, 2])
    test("!.", [1, 2, 3])
    test("!(.)", [])
    test("!(.)", [1])
    test("!(.)", [1, 2])
    test("!(.)", [1, 2, 3])
    test("!(. .)", [])
    test("!(. .)", [1])

# Generated at 2022-06-17 17:08:41.046199
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:08:41.927574
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "a")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-17 17:08:55.291129
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    def check(node, expected):
        assert node.get_suffix() == expected

    # Test a simple case
    check(Leaf(token.NAME, "foo"), "")

    # Test a more complicated case
    tree = pytree.Node(syms.simple_stmt, [
        Leaf(token.NAME, "foo"),
        Leaf(token.EQUAL, "="),
        Leaf(token.NAME, "bar"),
        Leaf(token.NEWLINE, "\n"),
    ])
    check(tree.children[0], "=")
    check(tree.children[1], "bar")
    check(tree.children[2], "\n")
   

# Generated at 2022-06-17 17:09:08.061306
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test for the case where the content is None
    pattern = NegatedPattern()
    for c, r in pattern.generate_matches([]):
        assert c == 0
        assert r == {}
    for c, r in pattern.generate_matches([1, 2, 3]):
        assert False, "Should not have matched"
    # Test for the case where the content is not None
    pattern = NegatedPattern(NodePattern(type=1))
    for c, r in pattern.generate_matches([]):
        assert c == 0
        assert r == {}
    for c, r in pattern.generate_matches([1, 2, 3]):
        assert False, "Should not have matched"

# Generated at 2022-06-17 17:09:16.151206
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    n = Node(1, [Leaf(1, ""), Leaf(1, "")])
    assert n.depth() == 0
    n.children[0].parent = n
    n.children[1].parent = n
    assert n.children[0].depth() == 1
    assert n.children[1].depth() == 1
    n.parent = n
    assert n.depth() == 1



# Generated at 2022-06-17 17:09:23.695878
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytoken
    from .pgen2 import token

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(token.NAME, "x", (1, 0)), 1)
    check(Leaf(token.NAME, "x", (1, 0)), 1)
    check(Leaf(token.NAME, "x", (1, 0)), 1)
    check(Leaf(token.NAME, "x", (1, 0)), 1)
    check(Leaf(token.NAME, "x", (1, 0)), 1)
    check(Leaf(token.NAME, "x", (1, 0)), 1)

# Generated at 2022-06-17 17:09:35.543220
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import grammar

    def check(pattern, expected):
        optimized = pattern.optimize()
        assert optimized == expected, (optimized, expected)

    check(WildcardPattern(min=1, max=1), NodePattern())
    check(WildcardPattern(min=1, max=1, name="foo"), NodePattern(name="foo"))

# Generated at 2022-06-17 17:10:38.027722
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test the optimization of a simple pattern
    pattern = WildcardPattern(min=1, max=1)
    assert pattern.optimize() == NodePattern()
    # Test the optimization of a pattern with a name
    pattern = WildcardPattern(min=1, max=1, name="foo")
    assert pattern.optimize() == NodePattern(name="foo")
    # Test the optimization of a pattern with a subpattern
    pattern = WildcardPattern(content=[["a"]], min=1, max=1)
    assert pattern.optimize() == NodePattern(content=["a"])
    # Test the optimization of a pattern with a subpattern and a name
    pattern = WildcardPattern(content=[["a"]], min=1, max=1, name="foo")

# Generated at 2022-06-17 17:10:50.385715
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    def test(pattern, text):
        tokens = list(generate_tokens(StringIO(text).readline))
        try:
            tree = Driver(Grammar(), convert).parse_tokens(tokens)
        except ParseError:
            tree = None
        if tree is None:
            return
        matches = list(pattern.generate_matches(tree.leaves()))
        if matches:
            return matches[0][0]
        return 0

    assert test(LeafPattern(token.NAME, "foo"), "foo") == 1