

# Generated at 2022-06-17 17:02:24.906504
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf

    node = Leaf(1, "foo")
    assert node.get_lineno() is None
    node.lineno = 5
    assert node.get_lineno() == 5



# Generated at 2022-06-17 17:02:35.912377
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(1, ""), None)
    check(Leaf(1, "", (1, 0)), 1)
    check(Leaf(1, "", (1, 0), prefix=""), 1)
    check(Leaf(1, "", (1, 0), prefix=" "), 1)
    check(Leaf(1, "", (1, 0), prefix="\n"), 1)
    check(Leaf(1, "", (1, 0), prefix="\n\n"), 1)

# Generated at 2022-06-17 17:02:43.293441
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected.parent is not None
        assert expected.parent.children == [expected]

    def check_list(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected[0].parent is not None
        assert expected[0].parent.children == expected

    # Replace with a leaf
    node = Leaf(1, "foo")
    expected = Leaf(1, "bar")
    check(node, expected)

    # Replace with a node
    node = Leaf(1, "foo")

# Generated at 2022-06-17 17:02:55.173359
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.NAME) == "NAME"


# The following classes are used to represent a parse tree.
#
# The tree is represented as a tree of nodes.  Each node has a type
# (which is the grammar symbol it represents), a value (which is the
# actual token string), and a list of children (which are the
# subtrees).
#
# The type is an integer representing a grammar symbol; see
# pygram.py for the list of symbols.  The value is a string.  The
# children are a sequence of nodes.
#
# The leaves of the tree are token nodes; these have no children.
# Their type is the integer token number, and their value is the
# string corresponding to the token.
#
# The internal nodes are non-termin

# Generated at 2022-06-17 17:03:05.478880
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def _test(node):
        assert list(node.leaves()) == [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]

    _test(Node(syms.expr_stmt, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]))
    _test(Node(syms.expr_stmt, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b"), Leaf(token.NAME, "c")]))

# Generated at 2022-06-17 17:03:06.726346
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, "a")
    assert list(l.leaves()) == [l]


# Generated at 2022-06-17 17:03:14.062754
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        assert node.depth() == expected

    check(Leaf(1, ""), 0)
    check(Node(syms.simple_stmt, [Leaf(1, "")]), 1)
    check(Node(syms.simple_stmt, [Node(syms.small_stmt, [Leaf(1, "")])]), 2)



# Generated at 2022-06-17 17:03:23.850700
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    def _test(s, expected):
        try:
            driver = Driver(Grammar(), convert)
            tree = driver.parse_string(s)
        except ParseError:
            tree = None
        if tree is None:
            assert expected is None
        else:
            assert tree.type == expected

    _test("1", 1)
    _test("1 + 2", 2)
    _test("1 + 2 + 3", 3)
    _test("1 + 2 + 3 + 4", 4)
    _test("1 + 2 + 3 + 4 + 5", 5)

# Generated at 2022-06-17 17:03:35.252651
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    def test(pattern, input, expected):
        driver = Driver(Grammar(), convert)
        try:
            tree = driver.parse_string(input)
        except ParseError as err:
            print("ParseError:", err)
            return
        print("tree:", tree)
        print("pattern:", pattern)
        print("input:", input)
        print("expected:", expected)
        result = pattern.match_seq(list(tree.post_order()))
        print("result:", result)
        assert result == expected


# Generated at 2022-06-17 17:03:45.780582
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2 import token
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import convert
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import Pattern
    from .pgen2.pgen import PatternSequence
    from .pgen2.pgen import PatternAlternative
    from .pgen2.pgen import PatternRepetition
    from .pgen2.pgen import PatternOptional
    from .pgen2.pgen import PatternGroup

# Generated at 2022-06-17 17:04:17.626018
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_depth):
        assert node.depth() == expected_depth

    check(Leaf(1, ""), 0)
    check(Node(syms.simple_stmt, [Leaf(1, "")]), 1)
    check(Node(syms.simple_stmt, [Node(syms.small_stmt, [Leaf(1, "")])]), 2)

    # Test that the depth of a node is the same as the depth of its first
    # child.
    node = pytree.Node(syms.simple_stmt, [])
    node.children.append(node)
    check(node, 0)

    # Test that the depth of a node

# Generated at 2022-06-17 17:04:28.904099
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    def test_append_child(node, child, expected_str):
        node.append_child(child)
        assert str(node) == expected_str

    def test_append_child_with_prefix(node, child, expected_str):
        child.prefix = " "
        node.append_child(child)
        assert str(node) == expected_str

    def test_append_child_with_prefix_and_newline(node, child, expected_str):
        child.prefix = " \n"
        node.append_child(child)
        assert str(node) == expected_str


# Generated at 2022-06-17 17:04:40.097694
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    # Test __eq__
    def check(a, b, eq):
        assert (a == b) == eq, (a, b, eq)
        assert (b == a) == eq, (b, a, eq)
        assert (a != b) != eq, (a, b, eq)
        assert (b != a) != eq, (b, a, eq)

    check(Leaf(1, ""), Leaf(1, ""), True)
    check(Leaf(1, ""), Leaf(2, ""), False)
    check(Leaf(1, ""), Leaf(1, "x"), False)

# Generated at 2022-06-17 17:04:42.476799
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "a")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-17 17:04:53.922558
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_clone(node):
        clone = node.clone()
        assert clone == node
        assert clone is not node
        assert clone.parent is None
        assert clone.children == node.children
        for child in clone.children:
            assert child.parent is clone
        return clone

    # Test cloning of a Leaf
    leaf = Leaf(1, "foo")
    clone = check_clone(leaf)
    assert clone.value == "foo"

    # Test cloning of a Node
    node = Node(syms.simple_stmt, [leaf])
    clone = check_clone(node)
    assert clone.type == syms.simple_stmt

    # Test cloning of a Node with a parent

# Generated at 2022-06-17 17:05:01.851028
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2 import token

    assert repr(LeafPattern(token.NAME)) == "LeafPattern(NAME, None, None)"
    assert repr(LeafPattern(token.NAME, "foo")) == "LeafPattern(NAME, 'foo', None)"
    assert repr(LeafPattern(token.NAME, "foo", "bar")) == "LeafPattern(NAME, 'foo', 'bar')"
    assert repr(NodePattern(token.expr_stmt)) == "NodePattern(expr_stmt, None, None)"
    assert repr(NodePattern(token.expr_stmt, "foo")) == "NodePattern(expr_stmt, 'foo', None)"
    assert repr(NodePattern(token.expr_stmt, "foo", "bar")) == "NodePattern(expr_stmt, 'foo', 'bar')"

# Generated at 2022-06-17 17:05:13.350120
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class NodePattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class LeafPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class WildcardPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class TestPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    # Test NodePattern
    p = NodePattern(257)
    assert p.match(Node(257, []))
    assert not p.match(Leaf(257, ""))
    assert not p.match(Node(258, []))
    assert not p.match(Leaf(258, ""))



# Generated at 2022-06-17 17:05:25.371449
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node

    def check(node, parent=None):
        assert node.parent is parent
        for child in node.children:
            check(child, node)

    for cls in Node, Leaf:
        node = cls(1, "foo")
        node.children = [cls(2, "bar"), cls(3, "baz")]
        node.children[0].children = [cls(4, "quux")]
        node.children[1].children = [cls(5, "xyzzy")]
        node2 = node.clone()
        check(node2)
        assert node2 is not node
        assert node2.children is not node.children
        assert node2.children[0] is not node.children[0]

# Generated at 2022-06-17 17:05:34.081080
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2, name=3)
    assert repr(pattern) == "BasePattern(1, 2, 3)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2)
    assert repr(pattern) == "BasePattern(1, 2)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1)
    assert repr(pattern) == "BasePattern(1)"
    # Test with non-default values for instance variables
    pattern = Base

# Generated at 2022-06-17 17:05:42.734184
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import python_grammar_no_print_statement
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement
    from . import python_grammar_

# Generated at 2022-06-17 17:06:08.981491
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, type, children, prefix, fixers_applied):
        assert node.type == type
        assert node.children == children
        assert node.prefix == prefix
        assert node.fixers_applied == fixers_applied

    def check_leaf(node, type, value, prefix):
        assert isinstance(node, Leaf)
        assert node.type == type
        assert node.value == value
        assert node.prefix == prefix

    def check_node(node, type, children, prefix, fixers_applied):
        assert isinstance(node, Node)
        check(node, type, children, prefix, fixers_applied)


# Generated at 2022-06-17 17:06:15.843509
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree

    def check_clone(node):
        clone = node.clone()
        assert node == clone
        assert node is not clone
        assert node.parent is None
        assert clone.parent is None
        assert node.children == clone.children
        for child, clone_child in zip(node.children, clone.children):
            assert child is not clone_child
            assert child.parent is node
            assert clone_child.parent is clone
            check_clone(child)


# Generated at 2022-06-17 17:06:28.710984
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import python_tree
    from . import pytree_utils
    from . import pytree_visitor
    from . import pytree_builder
    from . import pytree_to_string
    from . import pytree_to_code
    from . import pytree_to_cst
    from . import pytree_to_asdl
    from . import pytree_to_ast
    from . import pytree_to_pyc
    from . import pytree_to_pyc_ast
    from . import pytree_to_pyc_ast_visitor
    from . import pytree_to_pyc_ast_builder
    from . import pytree_to_pyc_ast_transformer
    from . import py

# Generated at 2022-06-17 17:06:32.943229
# Unit test for method leaves of class Base
def test_Base_leaves():
    # Test that leaves() works on a simple tree
    tree = Node(1, [Leaf(1, "foo"), Node(2, [Leaf(3, "bar")])])
    assert list(tree.leaves()) == [Leaf(1, "foo"), Leaf(3, "bar")]



# Generated at 2022-06-17 17:06:44.614951
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree_builder
    from . import pygram_util
    from . import pgen2_util
    from . import pytree_util
    from . import pytree_builder_util
    from . import pygram_util
    from . import pgen2_util
    from . import pytree_util
    from . import pytree_builder_util
    from . import pytree_builder_util
    from . import pytree_builder_util
    from . import pytree_builder_util
    from . import pytree_builder_util

# Generated at 2022-06-17 17:06:56.045475
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    g = pygram.python_grammar
    g.check_all()

    def check(s, expected):
        t = g.parse(s)
        assert t.type == syms.file_input
        assert t.children[0].type == token.NEWLINE
        assert t.children[1].type == syms.stmt
        assert t.children[1].children[0].type == syms.simple_stmt
        assert t.children[1].children[0].children[0].type == syms.small_stmt
        assert t.children[1].children[0].children[0].children[0].type == syms.expr_st

# Generated at 2022-06-17 17:07:08.045180
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    check(Leaf(1, ""), [])
    check(Node(syms.expr, [Leaf(1, "")]), [Leaf(1, ""), Node(syms.expr, [Leaf(1, "")])])

# Generated at 2022-06-17 17:07:16.192352
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Leaf(1, "c")
    d = Leaf(1, "d")
    e = Leaf(1, "e")
    f = Leaf(1, "f")
    g = Leaf(1, "g")
    h = Leaf(1, "h")
    i = Leaf(1, "i")
    j = Leaf(1, "j")
    k = Leaf(1, "k")
    l = Leaf(1, "l")
    m = Leaf(1, "m")
    n = Leaf(1, "n")
    o = Leaf(1, "o")

# Generated at 2022-06-17 17:07:28.240953
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pgen2
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_tokenize
    from . import pgen2_driver
    from . import pgen2_generate
    from . import pgen2_convert
    from . import pgen2_pickle
    from . import pgen2_grammar_wrapper
    from . import pgen2_literals
    from . import pgen2_token
    from . import pgen2_regex
    from . import pgen2_pattern
    from . import pgen2_matcher

# Generated at 2022-06-17 17:07:32.731027
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import unittest

    class TestCase(unittest.TestCase):
        def test_match_seq(self):
            p = WildcardPattern()
            self.assertTrue(p.match_seq([Leaf(1, "a")]))
            self.assertTrue(p.match_seq([Leaf(1, "a"), Leaf(2, "b")]))
            self.assertTrue(p.match_seq([Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c")]))
            self.assertFalse(p.match_seq([]))
            self.assertFalse(p.match_seq([Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c"), Leaf(4, "d")]))

            p = WildcardPattern(min=1)


# Generated at 2022-06-17 17:08:28.135463
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def test_clone(node):
        node2 = node.clone()
        assert node == node2
        assert node is not node2
        assert node.parent is None
        assert node2.parent is None
        assert node.children == node2.children
        for child1, child2 in zip(node.children, node2.children):
            assert child1 == child2
            assert child1 is not child2
            assert child1.parent is node
            assert child2.parent is node2

    test_clone(Leaf(1, "foo"))
    test_clone(Node(syms.simple_stmt, [Leaf(1, "foo")]))

# Generated at 2022-06-17 17:08:34.829383
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from .parse import parse

    # Test case 1
    pattern = NegatedPattern(None)
    nodes = [ast.Node(type=1, children=[])]
    result = list(pattern.generate_matches(nodes))
    assert result == []

    # Test case 2
    pattern = NegatedPattern(None)
    nodes = []
    result = list(pattern.generate_matches(nodes))
    assert result == [(0, {})]

    # Test case 3
    pattern = NegatedPattern(parse("a"))
    nodes = [ast.Node(type=1, children=[])]
    result = list(pattern.generate_matches(nodes))
    assert result == [(0, {})]

    # Test case 4
    pattern = NegatedPattern(parse("a"))
    nodes

# Generated at 2022-06-17 17:08:43.664829
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import driver
    from . import fixer_base
    from . import fixer_util
    from . import fixer_util as fut
    from . import patcomp
    from . import token
    from . import tokenize
    from . import tokenize as tokenize
    from . import token
    from . import token as token
    from . import future
    from . import future as future
    from . import pgen2
    from . import pgen2 as pgen2
    from . import pygram
    from . import pygram as pygram
    from . import pytree
    from . import pytree as pytree
    from . import fixer_base
   

# Generated at 2022-06-17 17:08:57.181309
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms


# Generated at 2022-06-17 17:09:09.284575
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver

    g = Grammar()
    g.type2name = tok_name
    g.symbol2number = {}
    g.number2symbol = {}
    g.keywords = {}
    g.tokens = {}
    g.start = 257
    g.dfas = {}
    g.states = {}
    g.literals = {}
    g.error_func = None
    g.parse_tokens = {}
    g.parse_start = None
    g.productions = []
    g.p_error = None
    g.p_accept = None
    g.p_accept

# Generated at 2022-06-17 17:09:20.800691
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar


# Generated at 2022-06-17 17:09:31.146735
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern(NodePattern(type=token.NAME))

# Generated at 2022-06-17 17:09:41.739038
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, new, expected):
        node.replace(new)
        assert node.parent is None
        assert node.children == []
        assert expected == node.parent.children

    # Replace a leaf with a leaf
    node = Leaf(1, "foo")
    new = Leaf(1, "bar")
    check(node, new, [new])

    # Replace a leaf with a node
    node = Leaf(1, "foo")
    new = Node(syms.simple_stmt, [Leaf(1, "bar")])
    check(node, new, [new])

    # Replace a node with a leaf
    node = Node(syms.simple_stmt, [Leaf(1, "foo")])

# Generated at 2022-06-17 17:09:49.540736
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(a, b, eq):
        assert (a == b) == eq
        assert (b == a) == eq
        assert (a != b) != eq
        assert (b != a) != eq

    check(Leaf(1, ""), Leaf(1, ""), True)
    check(Leaf(1, ""), Leaf(1, "x"), False)
    check(Leaf(1, ""), Leaf(2, ""), False)
    check(Leaf(1, ""), Node(syms.expr, [Leaf(1, "")]), False)

# Generated at 2022-06-17 17:09:57.031827
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_with_print_function
    from . import python_grammar_no_print_statement_with_print_function_3_2
    from . import python_grammar_no_print_statement_with_print_function_3_5
    from . import python_grammar_no_print_statement_with_print_function_3_6
    from . import python_grammar_no_print_statement_with_print_function_3_7
   

# Generated at 2022-06-17 17:10:50.687717
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    assert repr(LeafPattern(1)) == "LeafPattern(NUMBER)"
    assert repr(LeafPattern(1, "42")) == "LeafPattern(NUMBER, '42')"
    assert repr(LeafPattern(1, "42", "foo")) == "LeafPattern(NUMBER, '42', 'foo')"
    assert repr(NodePattern(1)) == "NodePattern(NAME)"
    assert repr(NodePattern(1, "foo")) == "NodePattern(NAME, 'foo')"
    assert repr(NodePattern(1, "foo", "bar")) == "NodePattern(NAME, 'foo', 'bar')"
    assert repr(WildcardPattern()) == "WildcardPattern()"
    assert repr(WildcardPattern(None)) == "WildcardPattern()"
