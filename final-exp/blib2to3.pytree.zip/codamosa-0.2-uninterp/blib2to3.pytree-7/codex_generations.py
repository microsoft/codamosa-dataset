

# Generated at 2022-06-17 17:03:32.670578
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected.parent is not None
        assert expected.parent.children == [expected]

    # Replace a leaf with a leaf
    leaf = Leaf(1, "a")
    leaf.parent = Node(syms.simple_stmt, [leaf])
    expected = Leaf(1, "b")
    check(leaf, expected)

    # Replace a leaf with a node
    leaf = Leaf(1, "a")
    leaf.parent = Node(syms.simple_stmt, [leaf])
    expected = Node(syms.expr_stmt, [Leaf(1, "b")])


# Generated at 2022-06-17 17:03:39.298365
# Unit test for function generate_matches
def test_generate_matches():
    from . import parse

    def check(pattern, nodes, expected):
        pattern = parse(pattern)
        result = list(generate_matches(pattern, nodes))
        assert result == expected, (pattern, nodes, result)

    check(".*", [], [(0, {})])
    check(".*", [1], [(1, {})])
    check(".*", [1, 2], [(2, {})])
    check(".*", [1, 2, 3], [(3, {})])
    check("a b c", [1, 2, 3], [(3, {})])
    check("a b c", [1, 2], [])
    check("a b c", [1], [])
    check("a b c", [], [])

# Generated at 2022-06-17 17:03:48.539208
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token

    def _test(node, expected_pos):
        pos = node.remove()
        assert pos == expected_pos
        assert node.parent is None
        assert node.next_sibling is None
        assert node.prev_sibling is None

    def _test_remove_leaf(node, expected_pos):
        _test(node, expected_pos)
        assert node.prefix == ""

    def _test_remove_node(node, expected_pos):
        _test(node, expected_pos)
        assert node.prefix == ""
        for child in node.children:
            assert child.parent is None
            assert child.next_sibling

# Generated at 2022-06-17 17:03:53.633533
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import unittest

    class TestWildcardPattern(unittest.TestCase):
        def test_match_seq(self):
            w = WildcardPattern()
            self.assertTrue(w.match_seq([]))
            self.assertTrue(w.match_seq([Leaf(1, "a")]))
            self.assertTrue(w.match_seq([Leaf(1, "a"), Leaf(1, "b")]))
            self.assertFalse(w.match_seq([Leaf(1, "a"), Leaf(2, "b")]))
            w = WildcardPattern(min=1)
            self.assertFalse(w.match_seq([]))
            self.assertTrue(w.match_seq([Leaf(1, "a")]))

# Generated at 2022-06-17 17:03:55.177828
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "a")
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-17 17:04:05.891778
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    def test_remove(node):
        assert node.remove() is None
        assert node.parent is None
        assert node.remove() is None
        assert node.parent is None

        parent = Node(syms.simple_stmt, [node])
        assert node.parent is parent
        assert node.remove() == 0
        assert node.parent is None
        assert parent.children == []

        parent = Node(syms.simple_stmt, [Leaf(token.NAME, "a"), node])
        assert node.parent is parent
        assert node.remove() == 1
        assert node.parent is None

# Generated at 2022-06-17 17:04:17.058516
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node, Base
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pgen2
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_with_statement
    from . import python_grammar_no_async_await
    from . import python_grammar_no_async_await_no_print_statement
    from . import python_grammar_no_async_await_no_with_statement
    from . import python_grammar_no_print_statement_no_

# Generated at 2022-06-17 17:04:28.472891
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from .parse import parse

    # Test case 1:
    #   pattern = NegatedPattern(NodePattern(type=ast.Name, content=[LeafPattern(value='a')]))
    #   nodes = [ast.Name(value='a', lineno=1, col_offset=0)]
    #   expected = []
    pattern = NegatedPattern(NodePattern(type=ast.Name, content=[LeafPattern(value='a')]))
    nodes = [ast.Name(value='a', lineno=1, col_offset=0)]
    expected = []
    actual = list(pattern.generate_matches(nodes))
    assert actual == expected, (actual, expected)

    # Test case 2:
    #   pattern = NegatedPattern(NodePattern(type=ast.Name, content=[Le

# Generated at 2022-06-17 17:04:39.964306
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree

# Generated at 2022-06-17 17:04:51.425049
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from . import grammar

    def test(pattern, nodes, expected):
        result = pattern.match_seq(nodes)
        assert result == expected, (pattern, nodes, result)

    test(WildcardPattern(), [], False)
    test(WildcardPattern(), [Leaf(1, "a")], False)
    test(WildcardPattern(), [Leaf(1, "a"), Leaf(1, "b")], False)
    test(WildcardPattern(min=0), [], True)
    test(WildcardPattern(min=0), [Leaf(1, "a")], True)
    test(WildcardPattern(min=0), [Leaf(1, "a"), Leaf(1, "b")], True)
    test(WildcardPattern(min=1), [], False)

# Generated at 2022-06-17 17:05:24.621474
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with default values for instance variables
    bp = BasePattern()
    assert repr(bp) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    bp = BasePattern(1, 2, 3)
    assert repr(bp) == "BasePattern(1, 2, 3)"
    # Test with non-default values for instance variables
    bp = BasePattern(1, 2)
    assert repr(bp) == "BasePattern(1, 2)"
    # Test with non-default values for instance variables
    bp = BasePattern(1)
    assert repr(bp) == "BasePattern(1)"
    # Test with non-default values for instance variables
    bp = BasePattern()

# Generated at 2022-06-17 17:05:28.702738
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected.parent is not None
        assert expected.parent.children == [expected]

    def check_error(node, expected):
        try:
            node.replace(expected)
        except AssertionError:
            pass
        else:
            assert False, "Expected AssertionError"

    check(Leaf(1, ""), Leaf(2, ""))
    check(Leaf(1, ""), [Leaf(2, ""), Leaf(3, "")])

# Generated at 2022-06-17 17:05:39.099041
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse
    from . import dump
    from . import compile
    from . import parse_grammar
    from . import dump_grammar
    from . import compile_grammar
    from . import generate_parser
    from . import generate_parser_source
    from . import generate_parser_source_file
    from . import generate_parser_source_file_with_tokens
    from . import generate_parser_source_file_with_tokens_and_grammar
    from . import generate_parser_source_file_with_tokens_and_grammar_and_tree
    from . import generate_parser_source_file_with_tokens_and_tree
    from . import generate_parser_source_file_with_tree
    from . import generate_parser_source_with_tokens

# Generated at 2022-06-17 17:05:49.324785
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        assert node.remove() == expected
        assert node.parent is None

    def check_all(node, expected):
        check(node, expected)
        for child in node.children:
            check_all(child, expected)

    def check_siblings(node, expected_next, expected_prev):
        assert node.next_sibling == expected_next
        assert node.prev_sibling == expected_prev

    def check_all_siblings(node, expected_next, expected_prev):
        check_siblings(node, expected_next, expected_prev)

# Generated at 2022-06-17 17:05:58.171315
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    def check(node, new, expected):
        node.replace(new)
        assert node.parent is None
        assert expected == node.parent.children

    def check_all(node, new, expected):
        check(node, new, expected)
        check(node.children[0], new, expected)
        check(node.children[1], new, expected)

    def check_all_list(node, new, expected):
        check(node, new, expected)
        check(node.children[0], new, expected)
        check(node.children[1], new, expected)
        check(node.children[2], new, expected)

    # Replace a leaf
    node = Leaf(1, "foo")
    new = Leaf

# Generated at 2022-06-17 17:06:09.174690
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar

# Generated at 2022-06-17 17:06:13.493068
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from . import parse
    from . import tokenize
    from . import util

    def test(pattern, text):
        pattern = parse.parse(pattern)
        text = tokenize.generate_tokens(StringIO(text).readline)
        tree = ast.parse(text)
        matches = list(pattern.generate_matches(tree.children))
        return matches

    def test_match(pattern, text):
        matches = test(pattern, text)
        assert len(matches) == 1
        return matches[0]

    def test_no_match(pattern, text):
        matches = test(pattern, text)
        assert len(matches) == 0

    def test_match_count(pattern, text, count):
        matches = test(pattern, text)

# Generated at 2022-06-17 17:06:14.940576
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:06:27.855560
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:06:39.748306
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile_no_future

# Generated at 2022-06-17 17:07:13.192609
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_matches
    from .pgen2.pgen import convert
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import _Results
    from .pgen2.pgen import _Leaf
    from .pgen2.pgen import _Node
    from .pgen2.pgen import _Base
    from .pgen2.pgen import _NL
   

# Generated at 2022-06-17 17:07:26.151782
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols

    def _test(node1, node2, expected):
        actual = node1 == node2
        assert actual == expected, (actual, expected)

    _test(Leaf(1, "foo"), Leaf(1, "foo"), True)
    _test(Leaf(1, "foo"), Leaf(1, "bar"), False)
    _test(Leaf(1, "foo"), Leaf(2, "foo"), False)
    _test(Leaf(1, "foo"), Leaf(2, "bar"), False)
    _test(Leaf(1, "foo"), Node(1, [Leaf(1, "foo")]), False)

# Generated at 2022-06-17 17:07:30.911194
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.token import tok_name

    class LeafPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return self.content is None or node.value == self.content

    class NodePattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return self.content is None or node.children == self.content


# Generated at 2022-06-17 17:07:42.291883
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    def test(pattern, node, expected):
        result = pattern.match(node)
        assert result == expected, (
            "Expected %s.match(%r) to return %r, got %r"
            % (pattern, node, expected, result)
        )

    def test_seq(pattern, nodes, expected):
        result = pattern.match_seq(nodes)
        assert result == expected, (
            "Expected %s.match_seq(%r) to return %r, got %r"
            % (pattern, nodes, expected, result)
        )

    def test_gen(pattern, nodes, expected):
        result = list(pattern.generate_matches(nodes))

# Generated at 2022-06-17 17:07:54.793576
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import python_tree

    def check(node, expected):
        assert node.get_suffix() == expected

    # Test a simple case
    check(Leaf(1, "foo"), "")
    check(Leaf(1, "foo", prefix=" "), " ")
    check(Leaf(1, "foo", prefix="\n"), "\n")

    # Test a more complex case
    node = Node(syms.simple_stmt, [
        Leaf(1, "foo", prefix="\n"),
        Leaf(1, "bar", prefix=" "),
        Leaf(1, "baz", prefix=" "),
        Leaf(1, "qux", prefix="\n"),
    ])

# Generated at 2022-06-17 17:08:05.989465
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_grammar

    g = Grammar()
    g.load(parse_grammar(generate_grammar("Grammar"), g))
    d = Driver(g, convert)

# Generated at 2022-06-17 17:08:11.350728
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_with_statement
    from . import python_grammar_no_future
    from . import python_grammar_no_print_statement_no_future
    from . import python_grammar_no_with_statement_no_future
    from . import python_grammar_only_future
    from . import python_grammar_no_async_keywords
    from . import python_grammar_no_async_keywords_no_print_statement
    from . import python_grammar_no_async_keywords_

# Generated at 2022-06-17 17:08:21.774254
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree
    from .fixer_util import Name
    from . import patcomp
    from . import fixer_base
    from . import fixer_util
    from . import pgen2
    from . import tokenize
    from . import future
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fix

# Generated at 2022-06-17 17:08:31.885143
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pyparse
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pyparse
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pyparse
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pyparse
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import p

# Generated at 2022-06-17 17:08:36.101697
# Unit test for function generate_matches
def test_generate_matches():
    # Test that the function works with a simple pattern.
    pattern = NodePattern(type=tokenize.NAME)
    nodes = [NL(type=tokenize.NAME, value="foo")]
    assert list(generate_matches([pattern], nodes)) == [(1, {})]

    # Test that the function works with a simple pattern that doesn't match.
    pattern = NodePattern(type=tokenize.NAME)
    nodes = [NL(type=tokenize.NUMBER, value="1")]
    assert list(generate_matches([pattern], nodes)) == []

    # Test that the function works with a simple pattern that matches
    # multiple nodes.
    pattern = NodePattern(type=tokenize.NAME)

# Generated at 2022-06-17 17:09:22.626068
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree

    def test_eq(a, b):
        assert a == b
        assert b == a
        assert not a != b
        assert not b != a

    def test_ne(a, b):
        assert a != b
        assert b != a
        assert not a == b
        assert not b == a

    test_eq(Leaf(1, "a"), Leaf(1, "a"))
    test_ne(Leaf(1, "a"), Leaf(1, "b"))
    test_ne(Leaf(1, "a"), Leaf(2, "a"))
    test_ne(Leaf(1, "a"), Node(1, [Leaf(1, "a")]))
    test_ne

# Generated at 2022-06-17 17:09:33.982575
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    # Test replacing a leaf
    leaf = Leaf(1, "foo")
    leaf.replace(Leaf(1, "bar"))
    assert leaf.parent is None
    assert leaf.prefix == "foo"

    # Test replacing a node
    node = Node(syms.simple_stmt, [leaf])
    leaf.parent = node
    leaf.replace(Leaf(1, "bar"))
    assert leaf.parent is None
    assert leaf.prefix == "foo"
    assert node.children == [Leaf(1, "bar")]

    # Test replacing a node with a list of nodes
    node = Node(syms.simple_stmt, [leaf])
    leaf.parent = node

# Generated at 2022-06-17 17:09:43.030400
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    pytree.Base._validate_invariants = True
    n = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")])
    assert n.depth() == 0
    n2 = Node(syms.file_input, [n])
    assert n2.depth() == 1
    n3 = Node(syms.file_input, [n2])
    assert n3.depth() == 2
    n4 = Node(syms.file_input, [n3])
    assert n4.depth() == 3
    n5 = Node(syms.file_input, [n4])
    assert n5.depth() == 4
    n

# Generated at 2022-06-17 17:09:54.405461
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Test method __repr__ of class BasePattern."""
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with values for instance variables
    pattern = BasePattern(type=1, content=2, name=3)
    assert repr(pattern) == "BasePattern(1, 2, 3)"
    # Test with values for instance variables
    pattern = BasePattern(type=1, content=2)
    assert repr(pattern) == "BasePattern(1, 2)"
    # Test with values for instance variables
    pattern = BasePattern(type=1)
    assert repr(pattern) == "BasePattern(1)"
    # Test with values for instance variables
    pattern = BasePattern(content=2, name=3)

# Generated at 2022-06-17 17:10:05.788844
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse
    from . import dump

    def test(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        expected = parse(expected)
        for c, r in pattern.generate_matches(nodes):
            assert c == len(nodes)
            assert dump(r["x"]) == dump(expected)

    test(".*", "a b c", "a b c")
    test(".+", "a b c", "a b c")
    test(".?", "a b c", "a")
    test(".{2,3}", "a b c", "a b")
    test(".{2,3}", "a b c d", "a b c")

# Generated at 2022-06-17 17:10:17.306033
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    from . import pygram
    from . import pytree

    def _test_eq(a, b):
        assert a == b
        assert not (a != b)
        assert not (a < b)
        assert a <= b
        assert not (a > b)
        assert a >= b

    def _test_ne(a, b):
        assert a != b
        assert not (a == b)
        assert a < b
        assert a <= b
        assert b > a
        assert b >= a

    def _test_lt(a, b):
        assert a < b
        assert a <= b
        assert not (a == b)
        assert not (a > b)

# Generated at 2022-06-17 17:10:28.305052
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("a", ["b", "c"])
    gr.add_production("b", ["d", "e"])
    gr.add_production("c", ["f", "g"])
    gr.add_production("d", ["h", "i"])
    gr.add_production("e", ["j", "k"])
    gr.add_production("f", ["l", "m"])
    gr.add_production("g", ["n", "o"])
    gr.add_production("h", ["p", "q"])
    gr.add_production("i", ["r", "s"])
    gr.add_production("j", ["t", "u"])

# Generated at 2022-06-17 17:10:40.389409
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def assert_leaves(node, expected):
        assert list(node.leaves()) == expected

    assert_leaves(Leaf(1, ""), [])
    assert_leaves(Node(syms.simple_stmt, [Leaf(1, "")]), [])
    assert_leaves(Node(syms.simple_stmt, [Leaf(1, ""), Leaf(1, "")]), [])
    assert_leaves(Node(syms.simple_stmt, [Leaf(1, ""), Leaf(1, ""), Leaf(1, "")]), [])

# Generated at 2022-06-17 17:10:53.740054
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def test(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        expected = parse(expected)
        result = list(pattern.generate_matches(nodes))
        assert result == expected, (result, expected)

    test("a", "a", [])
    test("a", "b", [])
    test("a", "a b", [(1, {})])
    test("a", "b a", [(1, {})])
    test("a", "a b c", [(1, {})])
    test("a", "b a c", [(1, {})])
    test("a", "a b c d", [(1, {}), (2, {})])