

# Generated at 2022-06-17 17:02:35.225313
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def test(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        result = list(pattern.generate_matches(nodes))
        assert result == expected, (pattern, nodes, result)

    test(".*", "", [(0, {})])
    test(".*", "a", [(1, {})])
    test(".*", "a b", [(2, {})])
    test(".*", "a b c", [(3, {})])
    test(".+", "", [])
    test(".+", "a", [(1, {})])
    test(".+", "a b", [(2, {})])
    test(".+", "a b c", [(3, {})])

# Generated at 2022-06-17 17:02:42.519366
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    # Test that get_lineno works for a leaf
    leaf = Leaf(syms.name, "foo", prefix=" ")
    assert leaf.get_lineno() == 1
    # Test that get_lineno works for a node with a leaf child
    node = pytree.Node(syms.expr_stmt, [leaf])
    assert node.get_lineno() == 1
    # Test that get_lineno works for a node with a node child
    node2 = pytree.Node(syms.expr_stmt, [node])
    assert node2.get_lineno() == 1
    # Test that get_lineno works for a node with no children

# Generated at 2022-06-17 17:02:53.774226
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree
    from . import pytokenize
    from . import pygram
    from . import pytree


# Generated at 2022-06-17 17:03:04.602277
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:03:15.254399
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    g = Grammar()
    p = NodePattern(g, g.symbol2number["testlist"], [LeafPattern(g, 1, "1")])
    assert p.optimize() is p
    p = NodePattern(g, g.symbol2number["testlist"], [LeafPattern(g, 1, "1"), LeafPattern(g, 1, "2")])
    assert p.optimize() is p
    p = NodePattern(g, g.symbol2number["testlist"], [LeafPattern(g, 1, "1"), LeafPattern(g, 1, "2"), LeafPattern(g, 1, "3")])
    assert p.optimize() is p

# Generated at 2022-06-17 17:03:24.747120
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import tree

    def test(pattern, nodes):
        p = parse.parse(pattern, pattern_type=parse.Pattern)
        n = tree.Node(0, nodes)
        for c, r in p.generate_matches(n.children):
            print(c, r)

    test("~(a b)", ["a", "b"])
    test("~(a b)", ["a", "c"])
    test("~(a b)", ["a", "b", "c"])
    test("~(a b)", ["a", "c", "b"])
    test("~(a b)", ["a", "c", "b", "d"])
    test("~(a b)", ["a", "c", "d", "b"])

# Generated at 2022-06-17 17:03:26.107105
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "a")
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-17 17:03:31.061649
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def test(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        expected = parse(expected)
        result = list(pattern.generate_matches(nodes))
        assert result == expected, (pattern, nodes, result, expected)

    test(".*", "a b c", [("a b c", {}), ("a b", {}), ("a", {}), ("", {})])
    test(".+", "a b c", [("a b c", {}), ("a b", {}), ("a", {})])
    test(".?", "a b c", [("a", {}), ("", {})])
    test(".{2,3}", "a b c", [("a b", {}), ("a", {})])

# Generated at 2022-06-17 17:03:43.010691
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from . import pygram

    def test_leaves(node, expected):
        leaves = list(node.leaves())
        assert len(leaves) == len(expected)
        for leaf, expected in zip(leaves, expected):
            assert leaf.value == expected

    test_leaves(
        Node(pygram.python_symbols.file_input,
             [Leaf(1, "a"),
              Node(pygram.python_symbols.simple_stmt,
                   [Leaf(1, "b"),
                    Leaf(1, "c"),
                    Leaf(1, "d")]),
              Leaf(1, "e")]),
        ["a", "b", "c", "d", "e"])


# Generated at 2022-06-17 17:03:50.779425
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(a, b, eq):
        assert (a == b) == eq, (a, b, eq)
        assert (b == a) == eq, (a, b, eq)
        assert (a != b) != eq, (a, b, eq)
        assert (b != a) != eq, (a, b, eq)

    def check_all(a, b, eq):
        check(a, b, eq)
        check(a.clone(), b.clone(), eq)

    def check_all_seq(a, b, eq):
        check_all(a, b, eq)

# Generated at 2022-06-17 17:05:06.971212
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(1, ""), None)
    check(Leaf(1, "", (1, 0)), 1)
    check(Leaf(1, "", (1, 0), prefix=""), 1)
    check(Leaf(1, "", (1, 0), prefix="\n"), 1)
    check(Leaf(1, "", (1, 0), prefix="\n\n"), 2)
    check(Leaf(1, "", (1, 0), prefix="\n\n\n"), 3)

# Generated at 2022-06-17 17:05:12.316069
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import parse

    def test(pattern, expected):
        actual = pattern.optimize()
        assert actual == expected, (actual, expected)

    test(WildcardPattern(), NodePattern())
    test(WildcardPattern(min=1), NodePattern())
    test(WildcardPattern(max=1), NodePattern())
    test(WildcardPattern(min=1, max=1), NodePattern())
    test(WildcardPattern(min=2, max=2), WildcardPattern(min=2, max=2))

# Generated at 2022-06-17 17:05:24.581328
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse
    from . import pretty_printer

    def check(patterns, nodes, expected):
        actual = list(generate_matches(patterns, nodes))
        if actual != expected:
            print("Patterns:", pretty_printer.pformat(patterns))
            print("Nodes:", pretty_printer.pformat(nodes))
            print("Expected:", expected)
            print("Actual:", actual)
            assert False

    def check_parse(patterns, nodes, expected):
        check(parse(patterns), nodes, expected)

    def check_parse_expr(patterns, nodes, expected):
        check(parse(patterns, mode="eval"), nodes, expected)


# Generated at 2022-06-17 17:05:30.809218
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"

# Generated at 2022-06-17 17:05:40.463113
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        result = [x.type for x in node.post_order()]
        assert result == expected, (result, expected)

    check(Leaf(1, ""), [1])
    check(Node(syms.file_input, [Leaf(1, ""), Leaf(2, "")]), [1, 2, syms.file_input])

# Generated at 2022-06-17 17:05:50.948435
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    grammar = pygram.python_grammar_no_print_statement
    pytree = Node(syms.file_input, [Leaf(1, "x"), Leaf(1, "\n"), Leaf(1, "y")])
    assert pytree.depth() == 0
    assert pytree.children[0].depth() == 1
    assert pytree.children[1].depth() == 1
    assert pytree.children[2].depth() == 1



# Generated at 2022-06-17 17:06:00.416445
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    def _test_get_suffix(node, expected_suffix):
        assert node.get_suffix() == expected_suffix

    # Test a simple case
    node = pytree.Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")])
    _test_get_suffix(node.children[0], "b")

    # Test a simple case with a newline
    node = pytree.Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "\n"), Leaf(1, "b")])
    _test_get_suffix(node.children[0], "\nb")

    # Test a simple

# Generated at 2022-06-17 17:06:01.480988
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:06:11.140015
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen

# Generated at 2022-06-17 17:06:12.684885
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:06:56.443551
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, cloned):
        assert node.type == cloned.type
        assert node.children == cloned.children
        assert node.parent is None
        assert cloned.parent is None
        assert node.prefix == cloned.prefix
        assert node.changed() == cloned.changed()
        assert node.was_changed == cloned.was_changed
        assert node.was_checked == cloned.was_checked
        assert node.get_lineno() == cloned.get_lineno()
        assert node.remove() == cloned.remove()
        assert node.next_sibling == cloned.next_sibling
        assert node.prev_sibling == cloned.prev

# Generated at 2022-06-17 17:07:08.544625
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    def check(node, expected):
        assert node.get_suffix() == expected

    # Test a leaf node
    leaf = Leaf(token.NAME, "foo")
    check(leaf, "")

    # Test a node with a single child
    node = Node(syms.simple_stmt, [leaf])
    check(node, "")

    # Test a node with multiple children
    leaf2 = Leaf(token.NAME, "bar")
    node.append_child(leaf2)
    check(node, "")
    check(leaf, "bar")
    check(leaf2, "")

    # Test a node with multiple children and a trailing newline


# Generated at 2022-06-17 17:07:20.996684
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern(
        [
            [
                WildcardPattern(
                    [
                        [
                            NodePattern(type=token.NAME, name="a"),
                            NodePattern(type=token.NAME, name="b"),
                        ],
                        [
                            NodePattern(type=token.NAME, name="c"),
                            NodePattern(type=token.NAME, name="d"),
                        ],
                    ],
                    min=1,
                    max=1,
                    name="abcd",
                )
            ]
        ],
        min=1,
        max=1,
        name="abcd",
    )
    q = p.optimize()
    assert q == p

# Generated at 2022-06-17 17:07:32.954268
# Unit test for method post_order of class Node
def test_Node_post_order():
    import sys
    import StringIO
    import unittest
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2.pgen import driver
    from blib2to3.pgen2.pgen import _parse_grammar
    from blib2to3.pgen2.pgen import _generate_tokens
    from blib2to3.pgen2.pgen import _generate_grammar_pickle
    from blib2to3.pgen2.pgen import _generate_pgen

# Generated at 2022-06-17 17:07:37.599204
# Unit test for function generate_matches
def test_generate_matches():
    # Test that the function works for the empty sequence of patterns
    assert list(generate_matches([], [])) == [(0, {})]
    assert list(generate_matches([], [1])) == []
    # Test that the function works for a single pattern
    assert list(generate_matches([NodePattern(1)], [])) == []
    assert list(generate_matches([NodePattern(1)], [1])) == [(1, {})]
    assert list(generate_matches([NodePattern(1)], [1, 2])) == []
    assert list(generate_matches([NodePattern(1)], [2])) == []
    assert list(generate_matches([NodePattern(1, name="x")], [1])) == [(1, {"x": 1})]

# Generated at 2022-06-17 17:07:52.360273
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from . import grammar
    from . import parser

    def test(pattern, text, expected):
        p = parser.Parser(grammar.Grammar(), parser.Parser.START)
        tree = p.parse(text)
        assert tree is not None, text
        assert pattern.match_seq(tree.children) == expected, (pattern, text, expected)

    test(WildcardPattern(), "", True)
    test(WildcardPattern(), "a", True)
    test(WildcardPattern(), "a b", True)
    test(WildcardPattern(), "a b c", True)
    test(WildcardPattern(min=1), "", False)
    test(WildcardPattern(min=1), "a", True)
    test(WildcardPattern(min=1), "a b", True)

# Generated at 2022-06-17 17:07:58.329720
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test removing a leaf
    leaf = Leaf(1, "test")
    assert leaf.remove() is None
    node = Node(syms.simple_stmt, [leaf])
    assert leaf.remove() == 0
    assert leaf.parent is None
    assert node.children == []

    # Test removing a node
    node = Node(syms.simple_stmt, [leaf])
    leaf.parent = node
    assert node.remove() is None
    node2 = Node(syms.file_input, [node])
    assert node.remove() == 0
    assert node.parent is None
    assert node2.children == []

    # Test removing a node with multiple children

# Generated at 2022-06-17 17:08:07.549194
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    from . import pygram
    from .pgen2 import tokenize
    from . import pytree

    # Create a simple tree
    tree = Node(syms.file_input, [
        Node(syms.stmt, [
            Node(syms.simple_stmt, [
                Leaf(pytoken.NAME, "print", prefix=" "),
                Leaf(pytoken.NAME, "x", prefix=" "),
                Leaf(pytoken.NEWLINE, "\n", prefix=""),
            ]),
        ]),
    ])

# Generated at 2022-06-17 17:08:18.885964
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test depth of a leaf
    leaf = Leaf(1, "foo")
    assert leaf.depth() == 0

    # Test depth of a node
    node = Node(syms.simple_stmt, [leaf])
    assert node.depth() == 1

    # Test depth of a node with a parent
    node2 = Node(syms.simple_stmt, [node])
    assert node.depth() == 2

    # Test depth of a node with a parent
    node3 = Node(syms.simple_stmt, [node2])
    assert node.depth() == 3

    # Test depth of a node with a parent

# Generated at 2022-06-17 17:08:29.905449
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(type=1, content=[])
    assert p.type == 1
    assert p.content == []
    assert p.name is None
    p = NodePattern(type=1, content=[LeafPattern(type=1)])
    assert p.type == 1
    assert p.content == [LeafPattern(type=1)]
    assert p.name is None
    p = NodePattern(type=1, content=[LeafPattern(type=1)], name="foo")
    assert p.type == 1
    assert p.content == [LeafPattern(type=1)]
    assert p.name == "foo"
    pytest.raises(AssertionError, NodePattern, type=1, content="foo")
    pytest.raises(AssertionError, NodePattern, type=1, content=[1])

# Generated at 2022-06-17 17:08:56.277010
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with a LeafPattern
    pattern = LeafPattern(token.NAME, "foo")
    assert repr(pattern) == "LeafPattern(NAME, 'foo')"
    # Test with a NodePattern
    pattern = NodePattern(syms.expr, "foo")
    assert repr(pattern) == "NodePattern(expr, 'foo')"
    # Test with a WildcardPattern
    pattern = WildcardPattern()
    assert repr(pattern) == "WildcardPattern()"

# Generated at 2022-06-17 17:09:08.456531
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree

    def check(node, lineno):
        assert node.get_lineno() == lineno

    def check_all(node, lineno):
        check(node, lineno)
        for child in node.children:
            check_all(child, lineno)

    # Check that get_lineno() works for a simple node
    check(pytree.Node(python_symbols.simple_stmt, [Leaf(1, "x", lineno=42)]), 42)

    # Check that get_lineno() works for a node with multiple children

# Generated at 2022-06-17 17:09:20.344083
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from . import pygram

    def check(tree, expected):
        result = list(tree.leaves())
        assert result == expected, (result, expected)

    check(Leaf(1, ""), [])
    check(Leaf(1, "a"), [Leaf(1, "a")])
    check(Node(pygram.syms.file_input, [Leaf(1, "a")]), [Leaf(1, "a")])
    check(
        Node(pygram.syms.file_input, [Leaf(1, "a"), Leaf(1, "b")]),
        [Leaf(1, "a"), Leaf(1, "b")],
    )

# Generated at 2022-06-17 17:09:29.789786
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def test_clone(node):
        node2 = node.clone()
        assert node2 == node
        assert node2 is not node
        assert node2.parent is None
        assert node2.children == node.children
        for child1, child2 in zip(node.children, node2.children):
            assert child1 is not child2
            assert child1.parent is node
            assert child2.parent is node2
            if isinstance(child1, Node):
                test_clone(child1)

    test_clone(Node(syms.file_input, [Leaf(1, "x"), Leaf(1, "y")]))



# Generated at 2022-06-17 17:09:41.090597
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from . import fixer_base
    from . import fixer_util
    from . import fixer_namespace
    from . import fixer_import
    from . import fixer_print
    from . import fixer_except
    from . import fixer_dict
    from . import fixer_except
    from . import fixer_future
    from . import fixer_funcattrs
    from . import fixer_has_key
    from . import fixer_idioms
    from . import fixer_import
    from . import fixer

# Generated at 2022-06-17 17:09:53.503691
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from . import pygram

    def test_pre_order(node, expected):
        result = [n.type for n in node.pre_order()]
        assert result == expected, (result, expected)

    def test_pre_order_str(node, expected):
        result = [str(n) for n in node.pre_order()]
        assert result == expected, (result, expected)

    def test_pre_order_type(node, expected):
        result = [type(n) for n in node.pre_order()]
        assert result == expected, (result, expected)

    def test_pre_order_depth(node, expected):
        result = [n.depth() for n in node.pre_order()]
        assert result == expected, (result, expected)

   

# Generated at 2022-06-17 17:10:05.751755
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def check(patterns, nodes, expected):
        actual = list(generate_matches(patterns, nodes))
        assert actual == expected, (actual, expected)

    # Test empty pattern
    check([], [], [(0, {})])
    check([], [ast.Pass()], [(0, {})])
    check([], [ast.Pass(), ast.Pass()], [(0, {})])

    # Test empty node sequence
    check([NodePattern(type=ast.Pass)], [], [])
    check([NodePattern(type=ast.Pass), NodePattern(type=ast.Pass)], [], [])

    # Test single pattern

# Generated at 2022-06-17 17:10:17.306183
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def check(patterns, nodes, expected):
        actual = list(generate_matches(patterns, nodes))
        assert actual == expected, (actual, expected)

    check([], [], [(0, {})])
    check([], [ast.Name("a", ast.Load())], [(0, {})])
    check([NodePattern(type=ast.Name)], [ast.Name("a", ast.Load())], [(1, {})])
    check(
        [NodePattern(type=ast.Name), NodePattern(type=ast.Name)],
        [ast.Name("a", ast.Load()), ast.Name("b", ast.Load())],
        [(2, {})],
    )

# Generated at 2022-06-17 17:10:27.759133
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_clone(node):
        clone = node.clone()
        assert clone == node
        assert clone is not node
        assert clone.parent is None
        assert clone.children == node.children
        assert clone.prefix == node.prefix
        assert clone.type == node.type
        assert clone.context == node.context

    def check_clone_tree(node):
        check_clone(node)
        for child in node.children:
            check_clone_tree(child)

    check_clone_tree(pytree.Node(syms.file_input, [Leaf(1, "foo")]))



# Generated at 2022-06-17 17:10:39.945315
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name

    class LeafPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            if self.content is not None and node.value != self.content:
                return False
            if results is not None and self.name:
                results[self.name] = node
            return True

    class NodePattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name
