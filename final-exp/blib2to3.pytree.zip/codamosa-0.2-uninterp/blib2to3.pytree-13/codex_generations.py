

# Generated at 2022-06-17 17:02:12.233682
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    import unittest
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    class TestNode(unittest.TestCase):
        def test_update_sibling_maps(self):
            node = Node(syms.file_input, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])
            node.update_sibling_maps()
            self.assertEqual(node.prev_sibling_map[id(node.children[0])], None)

# Generated at 2022-06-17 17:02:22.019603
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == "NAME"
    assert type_repr(2) == "NUMBER"
    assert type_repr(3) == "STRING"
    assert type_repr(4) == "NEWLINE"
    assert type_repr(5) == "INDENT"
    assert type_repr(6) == "DEDENT"
    assert type_repr(7) == "LPAR"
    assert type_repr(8) == "RPAR"
    assert type_repr(9) == "LSQB"
    assert type_repr(10) == "RSQB"
    assert type_repr(11) == "COLON"
    assert type_repr(12) == "COMMA"
    assert type_repr(13) == "SEMI"
    assert type

# Generated at 2022-06-17 17:02:28.823766
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    n = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    assert n.depth() == 0
    n2 = Node(1, [n])
    assert n2.depth() == 1
    n3 = Node(1, [n2])
    assert n3.depth() == 2
    n4 = Node(1, [n3])
    assert n4.depth() == 3



# Generated at 2022-06-17 17:02:31.530610
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "a")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-17 17:02:38.424841
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.grammar import Grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import parse_grammar
    from .pgen2.pgen import tokenize
    from .pgen2.pgen import write_grammar
    from .pgen2.pgen import yacc
    from .pgen2.pgen import yacc_grammar
    from .pgen2.pgen import yacc_parse
    from .pgen2.pgen import yacc_validate
    from .pgen2.pgen import yacc_validate_all

# Generated at 2022-06-17 17:02:51.492347
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test_leaves(node, expected_leaves):
        leaves = list(node.leaves())
        assert len(leaves) == len(expected_leaves)
        for leaf, expected_leaf in zip(leaves, expected_leaves):
            assert leaf == expected_leaf

    def test_leaves_with_prefix(node, expected_leaves):
        leaves = list(node.leaves())
        assert len(leaves) == len(expected_leaves)
        for leaf, expected_leaf in zip(leaves, expected_leaves):
            assert leaf.prefix == expected_leaf.prefix
            assert leaf.value == expected_leaf.value
            assert leaf.type == expected_leaf

# Generated at 2022-06-17 17:02:53.818464
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "a")
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-17 17:03:04.637625
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import unittest
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

# Generated at 2022-06-17 17:03:15.297561
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree_utils

# Generated at 2022-06-17 17:03:24.782572
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import compile
    from . import tree

    # Test case 1
    pattern = compile.compile("a")
    node = parse.parse("a")
    assert not list(NegatedPattern(pattern).generate_matches(node))

    # Test case 2
    pattern = compile.compile("a")
    node = parse.parse("b")
    assert list(NegatedPattern(pattern).generate_matches(node))

    # Test case 3
    pattern = compile.compile("a")
    node = parse.parse("")
    assert not list(NegatedPattern(pattern).generate_matches(node))

    # Test case 4
    pattern = compile.compile("a")
    node = parse.parse("a b")

# Generated at 2022-06-17 17:03:48.474791
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import PgenParser
    from .pgen2.pgen import PgenLexer
    from .pgen2.pgen import PgenError
    from .pgen2.pgen import PgenHeader
    from .pgen2.pgen import PgenMain
    from .pgen2.pgen import PgenMain
    from .pgen2.pgen import PgenMain
    from .pgen2.pgen import PgenMain


# Generated at 2022-06-17 17:03:58.796304
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test that optimize() does the right thing for a few simple cases
    assert WildcardPattern().optimize() == NodePattern()
    assert WildcardPattern(min=1).optimize() == NodePattern()
    assert WildcardPattern(max=1).optimize() == NodePattern()
    assert WildcardPattern(min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(min=2).optimize() == WildcardPattern(min=2)
    assert WildcardPattern(max=2).optimize() == WildcardPattern(max=2)
    assert WildcardPattern(min=2, max=2).optimize() == WildcardPattern(min=2, max=2)
    assert WildcardPattern(min=2, max=3).optimize() == WildcardPattern(min=2, max=3)
    assert Wild

# Generated at 2022-06-17 17:04:07.579181
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node

    class TestNode(Node):
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

    class TestLeaf(Leaf):
        def pre_order(self):
            yield self

    n = TestNode(1, [TestLeaf(1, "foo"), TestLeaf(1, "bar")])
    assert list(n.pre_order()) == [n, n.children[0], n.children[1]]



# Generated at 2022-06-17 17:04:18.808448
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Leaf(1, "c")
    d = Leaf(1, "d")
    e = Leaf(1, "e")
    f = Leaf(1, "f")
    g = Leaf(1, "g")
    h = Leaf(1, "h")
    i = Leaf(1, "i")
    j = Leaf(1, "j")
    k = Leaf(1, "k")
    l = Leaf(1, "l")
    m = Leaf(1, "m")
    n = Leaf(1, "n")
    o = Leaf(1, "o")
    p = Leaf(1, "p")


# Generated at 2022-06-17 17:04:27.790067
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with an instance of class LeafPattern
    pattern = LeafPattern(token.NAME, "foo")
    assert repr(pattern) == "LeafPattern(NAME, 'foo')"
    # Test with an instance of class NodePattern
    pattern = NodePattern(syms.expr_stmt)
    assert repr(pattern) == "NodePattern(expr_stmt)"
    # Test with an instance of class WildcardPattern
    pattern = WildcardPattern()
    assert repr(pattern) == "WildcardPattern()"

# Generated at 2022-06-17 17:04:34.282512
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import compile

    # Test for the case where the argument pattern has no matches
    pattern = compile.compile("a")
    negated_pattern = NegatedPattern(pattern)
    for c, r in negated_pattern.generate_matches(parse.parse("b")):
        assert c == 0
        assert r == {}

    # Test for the case where the argument pattern has a match
    pattern = compile.compile("a")
    negated_pattern = NegatedPattern(pattern)
    for c, r in negated_pattern.generate_matches(parse.parse("a")):
        assert False

    # Test for the case where the argument pattern is None
    negated_pattern = NegatedPattern()

# Generated at 2022-06-17 17:04:43.611150
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

# Generated at 2022-06-17 17:04:51.925237
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_pos):
        pos = node.remove()
        assert pos == expected_pos
        assert node.parent is None
        assert node not in node.parent.children

    def check_not_in_tree(node):
        pos = node.remove()
        assert pos is None
        assert node.parent is None

    # Test a leaf
    leaf = Leaf(1, "foo")
    check_not_in_tree(leaf)

    # Test a node with no children
    node = Node(syms.simple_stmt, [])
    check_not_in_tree(node)

    # Test a node with children

# Generated at 2022-06-17 17:05:00.449084
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def test_post_order(tree):
        # type: (Node) -> None
        """
        Test the post_order method of class Base.

        This is a recursive function that traverses the tree in post-order.
        """
        for child in tree.children:
            test_post_order(child)
        assert tree.type == syms.testlist_star_expr
        assert isinstance(tree, Node)
        assert tree.children[0].type == token.NAME
        assert isinstance(tree.children[0], Leaf)
        assert tree.children[1].type == token.COMMA
        assert isinstance(tree.children[1], Leaf)


# Generated at 2022-06-17 17:05:10.322322
# Unit test for method clone of class Base
def test_Base_clone():
    import unittest
    from .pytree import Leaf, Node

    class TestBase(unittest.TestCase):
        def test_clone(self):
            n = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
            n2 = n.clone()
            self.assertEqual(n, n2)
            self.assertIsNot(n, n2)
            self.assertIsNot(n.children[0], n2.children[0])
            self.assertIsNot(n.children[1], n2.children[1])

    unittest.main(TestBase, verbosity=2, exit=False)



# Generated at 2022-06-17 17:06:00.292508
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class LeafPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class NodePattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class WildcardPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class TestPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class TestPattern2(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class TestPattern3(BasePattern):
        def _submatch(self, node, results=None):
            return True


# Generated at 2022-06-17 17:06:10.055216
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    from . import pygram
    from .pgen2 import token

    def get_lineno(node):
        return node.get_lineno()

    def check(s, lineno):
        t = pygram.python_grammar.parse(s)
        assert get_lineno(t) == lineno

    check("x = 1", 1)
    check("x = 1\ny = 2", 1)
    check("x = 1\ny = 2\n", 1)
    check("\nx = 1", 2)
    check("\nx = 1\n", 2)
    check("\n\nx = 1", 3)

# Generated at 2022-06-17 17:06:16.474233
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, cloned):
        assert node.type == cloned.type
        assert node.children == cloned.children
        assert node.prefix == cloned.prefix
        assert node.parent is None
        assert cloned.parent is None
        assert node.was_changed == cloned.was_changed
        assert node.was_checked == cloned.was_checked

    def check_node(node):
        cloned = node.clone()
        check(node, cloned)

    def check_leaf(leaf):
        cloned = leaf.clone()
        check(leaf, cloned)

    check_leaf(Leaf(token.NAME, "foo"))

# Generated at 2022-06-17 17:06:29.437899
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import py

# Generated at 2022-06-17 17:06:41.135316
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("file_input", [("NEWLINE",), ("stmt", "*")])
    gr.add_production("stmt", [("simple_stmt",)])
    gr.add_production("simple_stmt", [("small_stmt", "*"), ("NEWLINE",)])
    gr.add_production("small_stmt", [("expr_stmt",)])
    gr.add_production("expr_stmt", [("testlist", "*"), ("augassign", "?"), ("yield_expr", "?")])
    gr.add_production("augassign", [("PLUS_EQUAL",)])

# Generated at 2022-06-17 17:06:54.482515
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import python_grammar

    # Create a simple tree
    tree = pytree.Node(syms.file_input, [
        pytree.Leaf(token.NAME, 'a'),
        pytree.Leaf(token.NEWLINE, '\n'),
        pytree.Leaf(token.NAME, 'b'),
        pytree.Leaf(token.NEWLINE, '\n'),
        pytree.Leaf(token.NAME, 'c'),
        pytree.Leaf(token.NEWLINE, '\n'),
    ])

    # Check that leaves() returns the expected leaves

# Generated at 2022-06-17 17:06:59.469822
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pygram import python_grammar_no_print_statement as grammar_no_print
    from .pygram import python_grammar_no_print_statement as grammar_no_print
    from .pygram import python_grammar_no_print_statement as grammar_no_print
    from .pygram import python_grammar_no_print_statement as grammar_no_print
    from .pygram import python_grammar

# Generated at 2022-06-17 17:07:11.219136
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"

# Generated at 2022-06-17 17:07:18.222543
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with default values for instance variables
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2, name=3)
    assert repr(pattern) == "BasePattern(1, 2, 3)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1, content=2)
    assert repr(pattern) == "BasePattern(1, 2)"
    # Test with non-default values for instance variables
    pattern = BasePattern(type=1)
    assert repr(pattern) == "BasePattern(1)"
    # Test with non-default values for instance variables
    pattern = Base

# Generated at 2022-06-17 17:07:25.287301
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from . import grammar

    def test(pattern, nodes, expected):
        pattern = grammar.sympy_grammar.parse(pattern)
        nodes = grammar.sympy_grammar.parse(nodes)
        assert pattern.match_seq(nodes) == expected

    test(".*", "a b c", True)
    test(".*", "", True)
    test(".+", "a b c", True)
    test(".+", "", False)
    test(".?", "a b c", False)
    test(".?", "", True)
    test(".{2,3}", "a b c", True)
    test(".{2,3}", "a b c d", False)
    test(".{2,3}", "", False)

# Generated at 2022-06-17 17:08:43.336687
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from .pgen2 import driver
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:08:57.088469
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import grammar
    from .parser import Parser
    from .symbols import symbol_map
    from .tokenizer import tokenize

    def test_generate_matches(pattern, text, expected):
        parser = Parser(grammar.grammar, symbol_map, tokenize)
        tree = parser.parse(text)
        matches = list(pattern.generate_matches(tree.children))
        assert matches == expected, (matches, expected)

    test_generate_matches(
        NegatedPattern(),
        "",
        [(0, {})],
    )
    test_generate_matches(
        NegatedPattern(),
        "a",
        [],
    )

# Generated at 2022-06-17 17:08:59.723160
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    pattern = BasePattern()
    assert repr(pattern) == 'BasePattern()'


# Generated at 2022-06-17 17:09:12.418079
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import python_tree

    def check(expected, tree):
        assert expected == tree.get_suffix()

    # Test a leaf node
    check("", Leaf(1, "foo"))

    # Test a node with a single child
    check("", Node(syms.simple_stmt, [Leaf(1, "foo")]))

    # Test a node with multiple children
    check("", Node(syms.simple_stmt, [Leaf(1, "foo"), Leaf(1, "bar")]))

    # Test a node with a single child and a suffix
    check("bar", Node(syms.simple_stmt, [Leaf(1, "foo")], suffix="bar"))

    # Test a node

# Generated at 2022-06-17 17:09:25.299860
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_post_order(tree, expected):
        result = [x.type for x in tree.post_order()]
        assert result == expected, (result, expected)

    check_post_order(
        Leaf(1, ""),
        [1],
    )
    check_post_order(
        Node(syms.simple_stmt, [Leaf(1, "")]),
        [1, syms.simple_stmt],
    )
    check_post_order(
        Node(syms.simple_stmt, [Leaf(1, ""), Leaf(2, "")]),
        [1, 2, syms.simple_stmt],
    )
    check

# Generated at 2022-06-17 17:09:37.138781
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    def check(node, expected_parent, expected_pos):
        assert node.parent is expected_parent
        if expected_parent is None:
            assert node.remove() is None
        else:
            assert node.remove() == expected_pos

    # Test a node with no parent
    node = Leaf(syms.test, "test")
    check(node, None, None)

    # Test a node with a parent
    parent = Node(syms.testlist, [node])
    check(node, parent, 0)

    # Test a node with a parent and a sibling
    sibling = Leaf(syms.test, "test")
    parent.append_child(sibling)
    check(node, parent, 0)

    # Test a

# Generated at 2022-06-17 17:09:51.998906
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.ERRORTOKEN) == "ERRORTOKEN"
    assert type_repr(python_symbols.N_TOKENS) == "N_TOKENS"
    assert type_repr(python_symbols.NT_OFFSET) == "NT_OFFSET"
    assert type_re

# Generated at 2022-06-17 17:09:59.222763
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import token
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile_no_future
    from . import python_gram

# Generated at 2022-06-17 17:10:08.132906
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(pytoken.NAME, "foo", (1, 0)), 1)
    check(Leaf(pytoken.NAME, "foo", (1, 0), parent=Node(syms.simple_stmt, [])), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "foo", (1, 0))]), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "foo", (1, 0)), Leaf(pytoken.NAME, "bar", (1, 3))]), 1)
    check

# Generated at 2022-06-17 17:10:18.600398
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    import sys
    import StringIO
    import unittest
