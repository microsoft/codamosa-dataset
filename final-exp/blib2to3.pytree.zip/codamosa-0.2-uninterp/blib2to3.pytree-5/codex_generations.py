

# Generated at 2022-06-17 17:03:01.483292
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from . import pytree_utils
    from . import pytree_builder

    # Test case 1
    # Create a simple tree
    tree = pytree_builder.PyTreeBuilder(python_grammar_no_print_statement, python_grammar_no_print_statement.syms.file_input)
    tree.add_token(pytoken.NAME, "a")
    tree.add_token(pytoken.NEWLINE, "\n")

# Generated at 2022-06-17 17:03:08.750196
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
   

# Generated at 2022-06-17 17:03:19.621957
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_grammar
    from .pgen2.pgen import LEXER, PARSER, GRAMMAR

    g = Grammar()

# Generated at 2022-06-17 17:03:27.545674
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def check(patterns, nodes, expected):
        actual = list(generate_matches(patterns, nodes))
        assert actual == expected, (actual, expected)

    check([], [], [(0, {})])
    check([NodePattern(type=1)], [], [])
    check([NodePattern(type=1)], [ast.Node(1)], [(1, {})])
    check([NodePattern(type=1)], [ast.Node(2)], [])
    check([NodePattern(type=1), NodePattern(type=2)], [ast.Node(1), ast.Node(2)], [(2, {})])

# Generated at 2022-06-17 17:03:36.979757
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    # Test depth of a leaf
    leaf = Leaf(token.NAME, "foo")
    assert leaf.depth() == 0

    # Test depth of a node
    node = Node(syms.simple_stmt, [leaf])
    assert node.depth() == 1

    # Test depth of a node with a parent
    node2 = Node(syms.simple_stmt, [node])
    assert node2.depth() == 2



# Generated at 2022-06-17 17:03:50.350466
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import pretty_tree
    from . import tree_format
    from . import tree_to_code
    from . import tree_to_string
    from . import tree_to_xml
    from . import tree_to_xml_string
    from . import tree_to_yaml
    from . import tree_to_yaml_string
    from . import tree_to_yaml_string_with_comments
    from . import tree_to_yaml_with_comments
    from . import tree_to_yaml_with_comments_string
    from . import tree_to_yaml_with_comments_string_with_comments
    from . import tree_to_yaml_with_comments_string_with_comments_string
    from . import tree_to_yaml_with_comments_string_with

# Generated at 2022-06-17 17:03:57.803960
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    import sys
    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO
    out = StringIO()
    def print_node(node, indent=0):
        print(' ' * indent, end='', file=out)
        if isinstance(node, Leaf):
            print(repr(node.value), file=out)
        else:
            print(type_repr(node.type), file=out)
            for child in node.children:
                print_node(child, indent + 2)
    def test_node(node):
        print_node(node)
        print(file=out)
       

# Generated at 2022-06-17 17:04:07.651048
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from .pgen2 import driver
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_symbols
    from . import python_symbols_no_print_statement
    from . import token
    from . import tokenize
    from . import tree
    from . import tree_build
    from . import tree_transform
    from . import tree_util
    from . import util
    from . import version
    from . import version_

# Generated at 2022-06-17 17:04:18.856426
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def test_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def test_pre_order_str(node, expected):
        result = list(node.pre_order())
        result = [str(x) for x in result]
        assert result == expected, (result, expected)

    def test_pre_order_type(node, expected):
        result = list(node.pre_order())
        result = [x.type for x in result]
        assert result == expected, (result, expected)


# Generated at 2022-06-17 17:04:25.450546
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    n = Node(1, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    n.children[1].replace(Leaf(1, "d"))
    assert n.children == [Leaf(1, "a"), Leaf(1, "d"), Leaf(1, "c")]



# Generated at 2022-06-17 17:04:44.312869
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    from .pgen2.parse import ParseError
    from .pgen2.pgen import Grammar
    from .pgen2.token import Token

    g = Grammar()
    g.load(StringIO("""
    s: a b c
    a: 'a'
    b: 'b'
    c: 'c'
    """))
    d = driver.Driver(g, convert)
    try:
        d.parse("abc", "s")
    except ParseError:
        pass
    else:
        assert False, "expected ParseError"
    assert d.root.type == g.symbol2number["s"]

# Generated at 2022-06-17 17:04:50.482637
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    import sys
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

# Generated at 2022-06-17 17:04:59.392764
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2 import token

    class NodePattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class LeafPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    class WildcardPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    # Test that the default implementation of optimize() returns self.
    for cls in NodePattern, LeafPattern, WildcardPattern:
        p = cls(token.NAME)
        assert p.optimize() is p



# Generated at 2022-06-17 17:05:02.351931
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "a")
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-17 17:05:13.809490
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class TestPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return True

    p = TestPattern(tok_name["NAME"])
    assert p.match(Leaf(tok_name["NAME"], "foo"))
    assert not p.match(Leaf(tok_name["NAME"], "bar"))
    assert not p.match(Leaf(tok_name["NUMBER"], "42"))
    assert not p.match(Leaf(tok_name["STRING"], "spam"))

# Generated at 2022-06-17 17:05:25.739494
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test that removing a node from a tree works
    tree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert tree.children[1].remove() == 1
    assert tree.children == [Leaf(1, "a"), Leaf(1, "c")]

    # Test that removing a node from a tree works when the node is the first
    # child
    tree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert tree.children[0].remove() == 0

# Generated at 2022-06-17 17:05:34.241950
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    node = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    assert node.depth() == 0
    node.parent = Node(1, [node])
    assert node.depth() == 1
    node.parent.parent = Node(1, [node.parent])
    assert node.depth() == 2
    node.parent.parent.parent = Node(1, [node.parent.parent])
    assert node.depth() == 3
    node.parent.parent.parent.parent = Node(1, [node.parent.parent.parent])
    assert node.depth() == 4
    node.parent.parent.parent.parent.parent = Node(1, [node.parent.parent.parent.parent])
    assert node.depth() == 5

# Generated at 2022-06-17 17:05:42.872790
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected.parent is not None
        assert expected.parent.children == [expected]
        assert expected.parent.was_changed

    def check_list(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected[0].parent is not None
        assert expected[0].parent.children == expected
        assert expected[0].parent.was_changed

    def check_fail(node, expected):
        try:
            node.replace(expected)
        except AssertionError:
            pass
        else:
            assert False, "should have failed"

   

# Generated at 2022-06-17 17:05:55.829287
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:06:04.739272
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import tree

    def check(pattern, nodes, expected):
        pattern = parse.parse(pattern, mode="eval")
        nodes = tree.build_tuple(nodes)
        actual = list(pattern.generate_matches(nodes))
        assert actual == expected, (actual, expected)

    check("~.", [], [(0, {})])
    check("~.", [1], [])
    check("~.", [1, 2], [])
    check("~.", [1, 2, 3], [])
    check("~(.)", [], [(0, {})])
    check("~(.)", [1], [])
    check("~(.)", [1, 2], [])
    check("~(.)", [1, 2, 3], [])

# Generated at 2022-06-17 17:06:28.074093
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    from .pygram import python_symbols
    node = Node(python_symbols.file_input, [])
    node.set_child(0, Leaf(1, "test"))
    assert node.children[0].value == "test"


# Generated at 2022-06-17 17:06:39.476942
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern(
        [
            [
                WildcardPattern(
                    [
                        [
                            NodePattern(type=NAME, name="name"),
                            NodePattern(type=DOT),
                            NodePattern(type=NAME, name="name"),
                        ]
                    ],
                    min=1,
                    max=1,
                )
            ]
        ],
        min=1,
        max=1,
    )
    assert p.optimize() == WildcardPattern(
        [
            [
                NodePattern(type=NAME, name="name"),
                NodePattern(type=DOT),
                NodePattern(type=NAME, name="name"),
            ]
        ],
        min=1,
        max=1,
    )



# Generated at 2022-06-17 17:06:53.625190
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, new, expected):
        node.replace(new)
        assert node.parent is None
        assert expected == node.parent.children

    def check_all(node, new, expected):
        check(node, new, expected)
        check(node, [new], expected)

    # Replace a leaf
    leaf = Leaf(1, "foo")
    new = Leaf(1, "bar")
    check_all(leaf, new, [new])

    # Replace a node with a leaf
    node = Node(syms.simple_stmt, [leaf])
    check_all(leaf, new, [new])

    # Replace a node with a node

# Generated at 2022-06-17 17:07:05.152927
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.parse import ParseError
    from .pgen2.grammar import Grammar
    from .pgen2.token import Token
    from .pgen2.pgen import generate_grammar

    g = Grammar(generate_grammar)
    t = Token("test", "test")
    t.prefix = " "
    t.lineno = 1
    t.column = 1
    n = Node(g.symbol2number["test"], [t])
    n.prefix = " "
    n.lineno = 1
    n.column = 1
    n.used_names = set()
    n.bracket_depth = 0
    n.opening_bracket = None
    n.fixers_applied = []
    n.parent = None
    n.prev_sibling_map = {}

# Generated at 2022-06-17 17:07:10.599207
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    from .pygram import python_symbols
    n = Node(python_symbols.testlist, [Leaf(1, "a"), Leaf(1, "b")])
    n.set_child(0, Leaf(1, "c"))
    assert n.children[0].value == "c"
    assert n.children[0].parent == n


# Generated at 2022-06-17 17:07:17.783092
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def test(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    test(Leaf(1, ""), [])
    test(Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")]), [Leaf(1, "a"), Leaf(1, "b")])
    test(Node(syms.simple_stmt, [Leaf(1, "a"), Node(syms.simple_stmt, [Leaf(1, "b")])]), [Leaf(1, "b"), Leaf(1, "a")])

# Generated at 2022-06-17 17:07:29.642947
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_post_order(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    def check_both(node, expected_pre, expected_post):
        check_pre_order(node, expected_pre)
        check_post_order(node, expected_post)


# Generated at 2022-06-17 17:07:41.699352
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from . import pygram

    def check(tree, expected):
        result = []
        for node in tree.post_order():
            result.append(node)
        assert result == expected

    def check_all(tree, expected):
        check(tree, expected)
        for node in tree.post_order():
            check(node, expected)


# Generated at 2022-06-17 17:07:53.664558
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def _test(node, expected):
        assert node.depth() == expected

    _test(Leaf(1, ""), 0)
    _test(Node(syms.file_input, [Leaf(1, "")]), 1)
    _test(Node(syms.file_input, [Node(syms.stmt, [Leaf(1, "")])]), 2)
    _test(Node(syms.file_input, [Node(syms.stmt, [Node(syms.simple_stmt, [Leaf(1, "")])])]), 3)



# Generated at 2022-06-17 17:08:05.758169
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def check(node, expected):
        result = [n.type for n in node.pre_order()]
        assert result == expected, (result, expected)

    def check_str(node, expected):
        result = [n.type for n in node.pre_order()]
        assert result == expected, (result, expected)

    def check_prefix(node, expected):
        result = [n.prefix for n in node.pre_order()]
        assert result == expected, (result, expected)

    def check_prefix_str(node, expected):
        result = [n.prefix for n in node.pre_order()]

# Generated at 2022-06-17 17:08:41.007934
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:08:48.973594
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree
    from .fixer_util import Name, Call, Comma, Dot, ArgList, Arg, String
    from .fixer_util import LParen, RParen, Number, Newline, Leaf
    from .fixer_util import token
    from .fixer_util import syms
    from .fixer_util import Node
    from .fixer_util import LParen, RParen, Number, Newline, Leaf
    from .fixer_util import token
    from .fixer_util import syms
    from .fixer_util import Node
    from .fixer_util import LParen, RParen, Number, Newline, Leaf

# Generated at 2022-06-17 17:09:01.274476
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree
    from .pgen2 import driver
    from . import pygram
    from . import pytree
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_import
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_

# Generated at 2022-06-17 17:09:04.464544
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class TestPattern(BasePattern):
        def optimize(self):
            return self
    t = TestPattern()
    assert t.optimize() is t

# Generated at 2022-06-17 17:09:17.364774
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import tokenize

    def _test_remove(node, expected_parent_children, expected_parent_changed):
        parent = node.parent
        removed_pos = node.remove()
        assert parent.children == expected_parent_children
        assert parent.was_changed == expected_parent_changed
        assert node.parent is None
        return removed_pos

    def _test_remove_from_leaf(node, expected_parent_children, expected_parent_changed):
        removed_pos = _test_remove(node, expected_parent_children, expected_parent_changed)
        assert removed_pos == 0


# Generated at 2022-06-17 17:09:26.862893
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:09:38.549301
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree

# Generated at 2022-06-17 17:09:52.570515
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import LarkError
    from .pgen2.pgen import Nonterminal
    from .pgen2.pgen import Pattern
    from .pgen2.pgen import Token
    from .pgen2.pgen import Wildcard
    from .pgen2.pgen import _Results
    from .pgen2.pgen import convert
    from .pgen2.pgen import generate_matches
    from .pgen2.pgen import generate_matches_iter
    from .pgen2.pgen import generate

# Generated at 2022-06-17 17:09:59.669957
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import pygram
    from . import pytree
    from . import pgen2
    from . import pygram

# Generated at 2022-06-17 17:10:08.437873
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(pytoken.NAME, "x", (1, 0)), 1)
    check(Node(syms.expr_stmt, [Leaf(pytoken.NAME, "x", (1, 0))]), 1)
    check(Node(syms.expr_stmt, [Leaf(pytoken.NAME, "x", (1, 0)), Leaf(pytoken.EQUAL, "=", (1, 2))]), 1)

# Generated at 2022-06-17 17:10:41.108482
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_parent, expected_pos):
        assert node.parent is expected_parent
        if expected_parent is None:
            assert node.remove() is None
        else:
            assert node.remove() == expected_pos

    def check_all(node, expected_parent, expected_pos):
        check(node, expected_parent, expected_pos)
        for child in node.children:
            check_all(child, node, node.children.index(child))

    # Test a simple tree
    tree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")])
    check_all(tree, None, None)

    #

# Generated at 2022-06-17 17:10:54.164008
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import python_grammar
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import python_grammar
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import python_grammar
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import python_grammar
    from . import pytoken
    from . import pytree
    from . import pygram
   