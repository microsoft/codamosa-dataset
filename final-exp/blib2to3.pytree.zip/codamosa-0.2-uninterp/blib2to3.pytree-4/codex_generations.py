

# Generated at 2022-06-17 17:02:38.891946
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    grammar = Grammar()
    grammar.parse("""
    a: 'a'
    b: 'b'
    c: 'c'
    """)
    tree = grammar.number2symbol[256]
    assert tree.type == 256
    assert tree.children == [
        Leaf(257, "a", fixers_applied=[]),
        Leaf(258, "b", fixers_applied=[]),
        Leaf(259, "c", fixers_applied=[]),
    ]
    assert list(tree.pre_order()) == [
        tree,
        tree.children[0],
        tree.children[1],
        tree.children[2],
    ]

# Generated at 2022-06-17 17:02:51.570374
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast
    from . import parse

    def check(pattern, string, expected):
        tree = parse.parse(string, "<test>", "exec")
        assert len(tree.body) == 1
        node = tree.body[0]
        p = pattern.parse(pattern)
        result = list(generate_matches([p], [node]))
        assert result == expected, (result, expected)

    check(
        "stmt",
        "x = 1",
        [(1, {"stmt": [ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())], value=ast.Num(n=1))]})],
    )

# Generated at 2022-06-17 17:03:01.816889
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    from . import pretty_tree
    from . import tree_to_str
    from . import tree_to_str_with_name
    from . import tree_to_str_with_name_and_type
    from . import tree_to_str_with_type
    from . import tree_to_str_with_type_and_name
    from . import tree_to_str_with_type_and_value
    from . import tree_to_str_with_value
    from . import tree_to_str_with_value_and_name
    from . import tree_to_str_with_value_and_type
    from . import tree_to_str_with_value_and_type_and_name
    from . import tree_to_str_with_value_and_name_and_type

# Generated at 2022-06-17 17:03:12.995210
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(tree, expected_pos):
        pos = tree.remove()
        assert pos == expected_pos
        assert tree.parent is None
        assert tree not in tree.parent.children

    # Test removal of a leaf
    tree = Leaf(1, "foo")
    parent = Node(syms.simple_stmt, [tree])
    check(tree, 0)
    assert parent.children == []

    # Test removal of a leaf with a next sibling
    tree = Leaf(1, "foo")
    next_sib = Leaf(1, "bar")
    parent = Node(syms.simple_stmt, [tree, next_sib])
    check(tree, 0)

# Generated at 2022-06-17 17:03:22.926395
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import driver
    from . import fixer_base
    from . import fixer_util
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
    from . import fixer_util as futil
   

# Generated at 2022-06-17 17:03:32.225485
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test for empty sequence
    pattern = NegatedPattern()
    for c, r in pattern.generate_matches([]):
        assert c == 0
        assert r == {}
    for c, r in pattern.generate_matches(["a"]):
        assert False, "Should not match"
    # Test for non-empty sequence
    pattern = NegatedPattern(NodePattern(type=token.NAME, content=[LeafPattern(value="a")]))
    for c, r in pattern.generate_matches(["a"]):
        assert False, "Should not match"
    for c, r in pattern.generate_matches(["b"]):
        assert c == 0
        assert r == {}



# Generated at 2022-06-17 17:03:43.668647
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def test_post_order(node, expected):
        result = list(node.post_order())
        assert result == expected, (result, expected)

    def test_pre_order(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def test_leaves(node, expected):
        result = list(node.leaves())
        assert result == expected, (result, expected)

    def test_depth(node, expected):
        result = node.depth()
        assert result == expected, (result, expected)

    def test_get_suffix(node, expected):
        result = node

# Generated at 2022-06-17 17:03:51.265896
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens
    from .pgen2.grammar import Grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import Lark
    from .pgen2.pgen import LarkError
    from .pgen2.pgen import LarkOptions
    from .pgen2.pgen import LarkTransformer
    from .pgen2.pgen import LarkVisitor
    from .pgen2.pgen import Nonterminal
    from .pgen2.pgen import Token
    from .pgen2.pgen import TokenStream
    from .pgen2.pgen import _TokenType
    from .pgen2.pgen import _TokenTypeAlias

# Generated at 2022-06-17 17:04:01.749673
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pattern = WildcardPattern(
        [
            [NodePattern(type=token.NAME), NodePattern(type=token.EQUAL)],
            [NodePattern(type=token.NAME), NodePattern(type=token.PLUSEQUAL)],
        ],
        min=1,
        max=HUGE,
    )
    nodes = [
        Leaf(token.NAME, "a"),
        Leaf(token.EQUAL, "="),
        Leaf(token.NAME, "b"),
        Leaf(token.PLUSEQUAL, "+="),
        Leaf(token.NAME, "c"),
    ]
    assert pattern.match_seq(nodes)

# Generated at 2022-06-17 17:04:08.781688
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(a, b, eq):
        if eq:
            assert a == b
            assert b == a
            assert not (a != b)
            assert not (b != a)
        else:
            assert a != b
            assert b != a
            assert not (a == b)
            assert not (b == a)

    def check_all(a, b, eq):
        check(a, b, eq)
        check(a.clone(), b.clone(), eq)

    check_all(Leaf(1, "a"), Leaf(1, "a"), True)
    check_all(Leaf(1, "a"), Leaf(1, "b"), False)

# Generated at 2022-06-17 17:05:04.057811
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from . import pytoken
    from . import pygram
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:05:10.241759
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile
    from . import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile_no_trailer

# Generated at 2022-06-17 17:05:23.226611
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(tree, type_, children=None, prefix=None):
        assert isinstance(tree, pytree.Base)
        assert tree.type == type_
        if children is not None:
            assert len(tree.children) == len(children)
            for i, ch in enumerate(tree.children):
                check(ch, *children[i])
        else:
            assert not tree.children
        if prefix is not None:
            assert tree.prefix == prefix

    def check_clone(tree, type_, children=None, prefix=None):
        check(tree, type_, children, prefix)
        clone = tree.clone()
        check(clone, type_, children, prefix)

# Generated at 2022-06-17 17:05:33.407154
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import Lark
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import convert
    from .pgen2.pgen import Leaf
    from .pgen2.pgen import Node
    from .pgen2.pgen import NL
    from .pgen2.pgen import _Results
    from .pgen2.pgen import type_repr
    from .pgen2.pgen import type_str
    from .pgen2.pgen import type_name
    from .pgen2.pgen import type_

# Generated at 2022-06-17 17:05:42.013487
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check_leaves(tree, expected):
        result = [leaf.value for leaf in tree.leaves()]
        assert result == expected

    check_leaves(
        Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")]),
        ["a", "b"]
    )
    check_leaves(
        Node(syms.simple_stmt, [
            Node(syms.small_stmt, [Leaf(1, "a")]),
            Node(syms.small_stmt, [Leaf(1, "b")]),
        ]),
        ["a", "b"]
    )

# Generated at 2022-06-17 17:05:55.412818
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from .parse import Parser
    from .unparse import Unparser

    p = Parser()
    u = Unparser()

    # Test for an empty sequence
    pattern = NegatedPattern()
    for c, r in pattern.generate_matches([]):
        assert c == 0
        assert r == {}
    for c, r in pattern.generate_matches([ast.Leaf(1, "a")]):
        assert False, "Should not match"

    # Test for a non-empty sequence
    pattern = NegatedPattern(NodePattern(type=1))
    for c, r in pattern.generate_matches([ast.Leaf(1, "a")]):
        assert False, "Should not match"

# Generated at 2022-06-17 17:06:06.964489
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, expected):
        assert list(node.leaves()) == expected

    check(Leaf(1, ""), [])
    check(Node(syms.simple_stmt, [Leaf(1, "")]), [])
    check(Node(syms.simple_stmt, [Leaf(1, ""), Leaf(1, "")]), [Leaf(1, ""), Leaf(1, "")])
    check(Node(syms.simple_stmt, [Leaf(1, ""), Node(syms.expr_stmt, [Leaf(1, "")])]), [Leaf(1, ""), Leaf(1, "")])

# Generated at 2022-06-17 17:06:14.575892
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    import sys
    import io
    import unittest

    class TestBaseDepth(unittest.TestCase):
        def test_depth(self):
            tree = pytree.Node(python_symbols.file_input, [Leaf(1, "a")])
            self.assertEqual(tree.depth(), 0)
            tree.children[0].parent = tree
            self.assertEqual(tree.children[0].depth(), 1)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestBaseDepth)
    result = unittest.TextTestRunner(stream=io.StringIO(), verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-17 17:06:19.524704
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    def check_pre_order(s):
        g = pygram.python_grammar
        g.check_str(s)
        t = g.parse_string(s)
        check(t, t.pre_order())

    check_pre_order("a")
    check_pre_order("a b")
    check_pre_order("a b c")
    check_pre_order("a b c d")
    check_pre_order("a b c d e")

# Generated at 2022-06-17 17:06:30.378213
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        node.changed()
        assert node.was_changed == expected
        for child in node.children:
            check(child, expected)


# Generated at 2022-06-17 17:06:55.320653
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import token
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import generate_matches
    from .pgen2.pgen import generate_matches_iter
    from .pgen2.pgen import generate_matches_seq
    from .pgen2.pgen import generate_matches_seq_iter
    from .pgen2.pgen import generate_matches_seq_iter_old
    from .pgen2.pgen import generate_matches_seq_old
    from .pgen2.pgen import generate_matches_seq_old_iter
    from .pgen2.pgen import generate_matches_seq_old_iter_old
   

# Generated at 2022-06-17 17:07:07.152492
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, cloned):
        assert node.type == cloned.type
        assert node.children == cloned.children
        assert node.prefix == cloned.prefix
        assert node.parent is None
        assert cloned.parent is None
        assert node.next_sibling is None
        assert cloned.next_sibling is None
        assert node.prev_sibling is None
        assert cloned.prev_sibling is None

    def check_all(node, cloned):
        check(node, cloned)
        for n, c in zip(node.children, cloned.children):
            check_all(n, c)

    def check_clone(node):
        cloned

# Generated at 2022-06-17 17:07:15.622521
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"

# Generated at 2022-06-17 17:07:21.234486
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test for empty sequence
    pattern = NegatedPattern()
    assert list(pattern.generate_matches([])) == [(0, {})]
    assert list(pattern.generate_matches([1])) == []
    assert list(pattern.generate_matches([1, 2])) == []

    # Test for non-empty sequence
    pattern = NegatedPattern(WildcardPattern())
    assert list(pattern.generate_matches([])) == []
    assert list(pattern.generate_matches([1])) == [(0, {})]
    assert list(pattern.generate_matches([1, 2])) == [(0, {})]
    assert list(pattern.generate_matches([1, 2, 3])) == [(0, {})]

    # Test for non-empty sequence
    pattern = NegatedPattern

# Generated at 2022-06-17 17:07:32.813806
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern
    """
    pattern = BasePattern()
    assert repr(pattern) == "BasePattern(None, None, None)"
    pattern.type = 1
    assert repr(pattern) == "BasePattern(1, None, None)"
    pattern.content = 2
    assert repr(pattern) == "BasePattern(1, 2, None)"
    pattern.name = "name"
    assert repr(pattern) == "BasePattern(1, 2, 'name')"
    pattern.name = None
    assert repr(pattern) == "BasePattern(1, 2)"
    pattern.content = None
    assert repr(pattern) == "BasePattern(1)"
    pattern.type = None
    assert repr(pattern) == "BasePattern(None)"

# Generated at 2022-06-17 17:07:43.499404
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    def check(node, expected_pos):
        pos = node.remove()
        assert pos == expected_pos
        assert node.parent is None

    # Test removal of a leaf
    leaf = Leaf(1, "foo")
    node = Node(syms.simple_stmt, [leaf])
    check(leaf, 0)
    assert node.children == []

    # Test removal of a node
    leaf = Leaf(1, "foo")
    node = Node(syms.simple_stmt, [leaf])
    check(node, 0)
    assert node.children == []

    # Test removal of a node with multiple children
    leaf1 = Leaf(1, "foo")
    leaf2 = Leaf

# Generated at 2022-06-17 17:07:55.195834
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class TestPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            if self.content is None:
                return True
            return self.content == node.value

    t = TestPattern(tok_name["NAME"], "foo")
    assert t.match(Leaf(tok_name["NAME"], "foo"))
    assert not t.match(Leaf(tok_name["NAME"], "bar"))
    assert not t.match(Leaf(tok_name["NUMBER"], "foo"))

# Generated at 2022-06-17 17:08:06.075288
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from . import fixer_base
    from . import fixer_util
    from . import patcomp
    from . import pygram
    from . import tokenize
    from . import token
    from . import pytree
    from . import pytoken
    from . import pgen2

# Generated at 2022-06-17 17:08:18.251367
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"

# Generated at 2022-06-17 17:08:29.497280
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree
    from .pygram import python_symbols
    from .pgen2 import token

    def check(tree, expected):
        result = [node.type for node in tree.post_order()]
        assert result == expected, (result, expected)

    # Test a simple tree
    tree = pytree.Node(python_symbols.file_input, [
        pytree.Leaf(token.NAME, "a"),
        pytree.Node(python_symbols.simple_stmt, [
            pytree.Leaf(token.NAME, "b"),
            pytree.Leaf(token.NEWLINE, "\n"),
        ]),
    ])

# Generated at 2022-06-17 17:09:19.000181
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Test for method __repr__ (BasePattern)
    p = LeafPattern(token.NAME)
    assert repr(p) == "LeafPattern(NAME, None, None)"
    p = LeafPattern(token.NAME, "foo")
    assert repr(p) == "LeafPattern(NAME, 'foo', None)"
    p = LeafPattern(token.NAME, "foo", "bar")
    assert repr(p) == "LeafPattern(NAME, 'foo', 'bar')"
    p = NodePattern(syms.expr)
    assert repr(p) == "NodePattern(expr, None, None)"
    p = NodePattern(syms.expr, "foo")
    assert repr(p) == "NodePattern(expr, 'foo', None)"
    p = NodePattern(syms.expr, "foo", "bar")


# Generated at 2022-06-17 17:09:22.035039
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NAME) == "NAME"



# Generated at 2022-06-17 17:09:33.316697
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def check(pattern, text, expected):
        tree = parse(text)
        result = list(pattern.generate_matches(tree.children))
        assert result == expected, (pattern, text, result, expected)

    def check_fail(pattern, text):
        tree = parse(text)
        result = list(pattern.generate_matches(tree.children))
        assert not result, (pattern, text, result)

    check(WildcardPattern(), "", [(0, {})])
    check(WildcardPattern(), "a", [(1, {})])
    check(WildcardPattern(), "a b", [(2, {})])
    check(WildcardPattern(), "a b c", [(3, {})])
    check(WildcardPattern(), "a b c d", [(4, {})])


# Generated at 2022-06-17 17:09:40.554985
# Unit test for function generate_matches
def test_generate_matches():
    from astroid import test_utils
    from astroid.node_classes import NodeNG, Const

    class TestNode(NodeNG):
        def __init__(self, value):
            self.value = value

    def test_generate_matches_helper(patterns, nodes, expected):
        result = list(generate_matches(patterns, nodes))
        assert result == expected, (result, expected)

    def test_generate_matches_helper_with_wildcards(patterns, nodes, expected):
        result = list(generate_matches(patterns, nodes))
        assert result == expected, (result, expected)

    def test_generate_matches_helper_with_negated(patterns, nodes, expected):
        result = list(generate_matches(patterns, nodes))
       

# Generated at 2022-06-17 17:09:53.321838
# Unit test for method post_order of class Node
def test_Node_post_order():
    import unittest
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:10:00.245835
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import python_grammar
    from . import python_grammar_no_print_statement
    from . import python_grammar_no_print_statement_no_exec_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_assert_statement
    from . import python_grammar_no_print_statement_no_exec_statement_no_raise_statement_no_assert_statement_no_import_statement
    from . import python_grammar_no_print_statement

# Generated at 2022-06-17 17:10:08.940816
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    assert Leaf(1, "a", prefix="b", fixers_applied=[]).__repr__() == "Leaf(NAME, 'a')"
    assert Leaf(1, "a", prefix="b", fixers_applied=[]).__repr__() == "Leaf(NAME, 'a')"
    assert Leaf(1, "a", prefix="b", fixers_applied=[]).__repr__() == "Leaf(NAME, 'a')"
    assert Leaf(1, "a", prefix="b", fixers_applied=[]).__repr__() == "Leaf(NAME, 'a')"

# Generated at 2022-06-17 17:10:19.094847
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def test(pattern, nodes, expected):
        actual = list(pattern.generate_matches(nodes))
        assert actual == expected, (actual, expected)

    test(
        WildcardPattern(),
        parse("a b c"),
        [
            (0, {}),
            (1, {}),
            (2, {}),
            (3, {}),
            (1, {"bare_name": [Leaf(1, "a")]}),
            (2, {"bare_name": [Leaf(1, "a"), Leaf(1, "b")]}),
            (3, {"bare_name": [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]}),
        ],
    )

# Generated at 2022-06-17 17:10:30.791454
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar
    from .pgen2.pgen import L, N, P, S, T, V, _generate_matches
    from .pgen2.pgen import _generate_matches_seq
    from .pgen2.pgen import _generate_matches_seq_iter
    from .pgen2.pgen import _generate_matches_seq_iter_rec
    from .pgen2.pgen import _generate_matches_seq_rec
    from .pgen2.pgen import _generate_matches_seq_rec_iter

# Generated at 2022-06-17 17:10:41.560826
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.ENDMARKER) == "ENDMARKER"
    assert type_repr(python_symbols.ERRORTOKEN) == "ERRORTOKEN"
    assert type_repr(python_symbols.N_TOKENS) == "N_TOKENS"
    assert type_repr(python_symbols.NT_OFFSET) == "NT_OFFSET"
    assert type_re