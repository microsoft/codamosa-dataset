

# Generated at 2022-06-17 17:03:16.728529
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytree_unpickle
    from . import pytree_to_str
    from . import pytree_to_str_with_comments
    from . import pytree_to_str_with_comments_and_parens
    from . import pytree_to_str_with_parens
    from . import pytree_to_str_with_whitespace
    from . import pytree_to_str_with_whitespace_and_parens
    from . import pytree_to_str_with_whitespace_and_comments
    from . import pytree_to_str

# Generated at 2022-06-17 17:03:25.827207
# Unit test for function generate_matches
def test_generate_matches():
    # Test that generate_matches works correctly with empty patterns
    assert list(generate_matches([], [])) == [(0, {})]
    assert list(generate_matches([], [1, 2, 3])) == [(0, {})]
    # Test that generate_matches works correctly with a single pattern
    assert list(generate_matches([NodePattern(1)], [])) == []
    assert list(generate_matches([NodePattern(1)], [1, 2, 3])) == [(1, {})]
    assert list(generate_matches([NodePattern(1)], [2, 3])) == []
    assert list(generate_matches([WildcardPattern()], [])) == [(0, {})]
    assert list(generate_matches([WildcardPattern()], [1, 2, 3]))

# Generated at 2022-06-17 17:03:38.646773
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def test(node, expected):
        assert node.depth() == expected

    test(Leaf(1, ""), 0)
    test(Node(syms.funcdef, [Leaf(1, "def"), Leaf(1, "f"), Leaf(1, "(")]), 0)

# Generated at 2022-06-17 17:03:48.200795
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.
    """
    # Test with a LeafPattern
    pattern = LeafPattern(token.NAME)
    assert repr(pattern) == "LeafPattern(NAME, None, None)"
    # Test with a NodePattern
    pattern = NodePattern(syms.expr)
    assert repr(pattern) == "NodePattern(expr, None, None)"
    # Test with a WildcardPattern
    pattern = WildcardPattern()
    assert repr(pattern) == "WildcardPattern(None, None, None)"
    # Test with a LeafPattern with a content
    pattern = LeafPattern(token.NAME, "foo")
    assert repr(pattern) == "LeafPattern(NAME, 'foo', None)"
    # Test with a NodePattern with a content

# Generated at 2022-06-17 17:03:58.795802
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from .parse import ParserError

    def check(pattern, nodes, expected):
        p = ast.parse(pattern)
        if isinstance(p, ast.ErrorNode):
            raise ParserError(p.error)
        if not isinstance(p, ast.Pattern):
            raise ValueError(p)
        result = list(p.generate_matches(nodes))
        assert result == expected, (pattern, nodes, result)

    check(".*", [], [(0, {})])
    check(".*", [1], [(1, {})])
    check(".*", [1, 2], [(2, {})])
    check(".*", [1, 2, 3], [(3, {})])

# Generated at 2022-06-17 17:04:07.992869
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.driver import Driver
    from .pgen2 import token
    from . import tokenize
    from . import ast
    import io
    import sys
    import unittest
    import warnings
    import tokenize as tokenize_stdlib
    import ast as ast_stdlib
    import sys
    import unittest
    import warnings
    import tokenize as tokenize_stdlib
    import ast as ast_stdlib
    import sys
    import unittest
    import warnings
    import tokenize as tokenize_stdlib
    import ast as ast_stdlib
    import sys
    import unittest
    import warnings
    import tokenize as tokenize_stdlib

# Generated at 2022-06-17 17:04:12.843550
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pygram

# Generated at 2022-06-17 17:04:25.536873
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import ast
    from .parse import Parser

    p = Parser()

# Generated at 2022-06-17 17:04:38.162352
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf, Node

    # Test Leaf
    l1 = Leaf(1, "")
    l2 = Leaf(1, "")
    assert l1 == l2
    l3 = Leaf(1, "", (1, 0))
    assert l1 == l3
    l4 = Leaf(1, "", (1, 1))
    assert l1 != l4
    l5 = Leaf(2, "")
    assert l1 != l5
    l6 = Leaf(1, "x")
    assert l1 != l6

    # Test Node
    n1 = Node(1, [])
    n2 = Node(1, [])
    assert n1 == n2
    n3 = Node(1, [], (1, 0))
    assert n1 == n3

# Generated at 2022-06-17 17:04:50.760652
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from .pgen2 import driver
    from . import fixer_base
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util
    from . import fixer_util

# Generated at 2022-06-17 17:05:33.045181
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(tree, expected):
        result = list(tree.leaves())
        assert result == expected

    check(Leaf(1, ""), [])
    check(Node(syms.exprlist, [Leaf(1, ""), Leaf(1, "")]), [Leaf(1, ""), Leaf(1, "")])
    check(Node(syms.exprlist, [Leaf(1, ""), Node(syms.exprlist, [Leaf(1, ""), Leaf(1, "")])]),
          [Leaf(1, ""), Leaf(1, ""), Leaf(1, "")])



# Generated at 2022-06-17 17:05:44.970499
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(node, expected):
        assert list(node.leaves()) == expected

    check(Leaf(1, ""), [])
    check(Node(syms.file_input, [Leaf(1, "")]), [Leaf(1, "")])
    check(
        Node(syms.file_input, [Leaf(1, ""), Leaf(2, "")]),
        [Leaf(1, ""), Leaf(2, "")],
    )
    check(
        Node(syms.file_input, [Node(syms.stmt, [Leaf(1, "")])]),
        [Leaf(1, "")],
    )

# Generated at 2022-06-17 17:05:54.002957
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:05:55.111102
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, "test")
    assert list(l.leaves()) == [l]


# Generated at 2022-06-17 17:06:02.647716
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    def check(tree, expected):
        result = [x.type for x in tree.post_order()]
        assert result == expected, (result, expected)

    check(Leaf(1, ""), [1])
    check(Node(syms.exprlist, [Leaf(1, ""), Leaf(2, "")]), [1, 2, syms.exprlist])

# Generated at 2022-06-17 17:06:11.863975
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def test(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    test(Leaf(token.NAME, "foo"), [Leaf(token.NAME, "foo")])
    test(
        Node(syms.simple_stmt, [Leaf(token.NAME, "foo")]),
        [Node(syms.simple_stmt, [Leaf(token.NAME, "foo")]), Leaf(token.NAME, "foo")],
    )

# Generated at 2022-06-17 17:06:23.613552
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    grammar = pygram.python_grammar
    tokens = pygram.python_symbols

    def test_remove(node):
        node.remove()
        assert node.parent is None

    def test_remove_from_leaf(node):
        node.remove()
        assert node.parent is None

    def test_remove_from_node(node):
        node.remove()
        assert node.parent is None

    def test_remove_from_node_with_children(node):
        node.remove()
        assert node.parent is None

    def test_remove_from_node_with_children_and_siblings(node):
        node.remove()
        assert node.parent is None



# Generated at 2022-06-17 17:06:27.322693
# Unit test for constructor of class Node
def test_Node():
    n = Node(1, [])
    assert n.type == 1
    assert n.children == []
    assert n.parent is None
    assert n.prefix == ""
    assert n.fixers_applied is None



# Generated at 2022-06-17 17:06:39.702501
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected_suffix):
        actual_suffix = node.get_suffix()
        assert actual_suffix == expected_suffix, (
            "Expected suffix '%s' but got '%s' for node %s" %
            (expected_suffix, actual_suffix, node))

    # Test a node with no next sibling
    node = Node(syms.simple_stmt, [Leaf(1, "a")])
    check(node, "")

    # Test a node with a next sibling
    node = Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")])

# Generated at 2022-06-17 17:06:53.076973
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols
    from .pgen2 import token
    import unittest

    class TestBase(unittest.TestCase):
        def test_get_lineno(self):
            node = Leaf(token.NAME, "foo", (1, 0))
            self.assertEqual(node.get_lineno(), 1)
            node = Node(python_symbols.power, [node])
            self.assertEqual(node.get_lineno(), 1)
            node = Node(python_symbols.power, [node, node])
            self.assertEqual(node.get_lineno(), 1)

    unittest.main()



# Generated at 2022-06-17 17:07:12.184460
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    tree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")])
    assert list(tree.pre_order()) == [tree, tree.children[0], tree.children[1]]



# Generated at 2022-06-17 17:07:24.101522
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token

    # Test replacing a leaf with a leaf
    leaf = Leaf(token.NAME, "foo")
    leaf.replace(Leaf(token.NAME, "bar"))
    assert leaf.parent is None
    assert leaf.prefix == "foo"

    # Test replacing a leaf with a node
    leaf = Leaf(token.NAME, "foo")
    leaf.replace(Node(syms.expr_stmt, [Leaf(token.NAME, "bar")]))
    assert leaf.parent is None
    assert leaf.prefix == "foo"

    # Test replacing a node with a leaf

# Generated at 2022-06-17 17:07:36.467394
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar

    g = Grammar(parse_grammar(StringIO(GRAMMAR), "exec", "single"))
    p = NodePattern(g.symbol2number["expr"], [LeafPattern(tok_name["NAME"])])
    assert p.match_seq([Leaf(tok_name["NAME"], "foo")])
    assert not p.match_seq([Leaf(tok_name["NAME"], "foo"), Leaf(tok_name["NAME"], "bar")])
    assert not p.match_seq([])
    assert not p.match_seq([Leaf(tok_name["NUMBER"], "42")])



# Generated at 2022-06-17 17:07:46.201099
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util
    from . import fixer_base
    from . import fixer_util

# Generated at 2022-06-17 17:07:52.781149
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar

    gr = Grammar()
    gr.add_production("file_input", [("NEWLINE", "?"), ("stmt", "*"), ("ENDMARKER", "?")])
    gr.add_production("stmt", [("simple_stmt", "|"), ("compound_stmt", "")])
    gr.add_production("simple_stmt", [("small_stmt", "*"), ("NEWLINE", ""), ("ENDMARKER", "?")])
    gr.add_production("small_stmt", [("expr_stmt", "|"), ("print_stmt", "|"), ("del_stmt", "")])

# Generated at 2022-06-17 17:08:05.530383
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2 import driver
    from . import pytree

    def parse(s):
        return driver.parse_string(s, grammar, pytree.convert)

    def test_clone(s):
        t = parse(s)
        t2 = t.clone()
        assert t == t2
        assert t is not t2
        assert t.children[0] is not t2.children[0]
        assert t.children[1] is not t2.children[1]
        assert t.children[1].children[0] is not t2.children[1].children[0]
        assert t.children[1].children[1] is not t2.children

# Generated at 2022-06-17 17:08:18.186063
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:08:26.919584
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    n = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    assert n.depth() == 0
    n2 = Node(1, [n, Leaf(1, "c")])
    assert n.depth() == 1
    assert n2.depth() == 0
    n3 = Node(1, [n2, Leaf(1, "d")])
    assert n.depth() == 2
    assert n2.depth() == 1
    assert n3.depth() == 0



# Generated at 2022-06-17 17:08:39.069045
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:08:53.542660
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2.pgen import generate_grammar

    g = Grammar()
    g.type2name[1] = "foo"
    g.type2name[2] = "bar"
    g.type2name[3] = "baz"
    g.number2symbol[1] = "foo"
    g.number2symbol[2] = "bar"
    g.number2symbol[3] = "baz"
    g.symbol2number["foo"] = 1
    g.symbol2number["bar"] = 2

# Generated at 2022-06-17 17:09:17.320646
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from .pgen2 import token

    def check(node, expected):
        result = list(node.pre_order())
        assert result == expected, (result, expected)

    check(Leaf(token.NAME, "foo"), [Leaf(token.NAME, "foo")])
    check(
        Node(syms.simple_stmt, [Leaf(token.NAME, "foo")]),
        [Node(syms.simple_stmt, [Leaf(token.NAME, "foo")]), Leaf(token.NAME, "foo")],
    )

# Generated at 2022-06-17 17:09:26.819710
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    # Test replacing a leaf with a leaf
    leaf1 = Leaf(1, "leaf1")
    leaf2 = Leaf(1, "leaf2")
    leaf1.replace(leaf2)
    assert leaf1.parent is None
    assert leaf2.parent is None

    # Test replacing a leaf with a node
    leaf1 = Leaf(1, "leaf1")
    node1 = Node(syms.testlist, [leaf1])
    leaf2 = Leaf(1, "leaf2")
    leaf1.replace(leaf2)
    assert leaf1.parent is None
    assert leaf2.parent is node1
    assert node1.children == [leaf2]

    # Test replacing a node with a leaf

# Generated at 2022-06-17 17:09:38.507182
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    # Test case 1
    #
    # Test that get_suffix returns the prefix of the next sibling
    #
    #   x = 1
    #   y = 2
    #
    #   x.get_suffix() == " = 2"
    #
    #
    x = Leaf(1, "x")
    y = Leaf(1, "y")
    equals_1 = Leaf(61, "=")
    equals_2 = Leaf(61, "=")
    one = Leaf(1, "1")
    two = Leaf(1, "2")
    x_assign = Node(syms.expr_stmt, [x, equals_1, one])

# Generated at 2022-06-17 17:09:52.491864
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytoken

    def check(node, lineno):
        assert node.get_lineno() == lineno

    check(Leaf(pytoken.NAME, "x", (1, 0)), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "x", (1, 0))]), 1)
    check(Node(syms.simple_stmt, [Leaf(pytoken.NAME, "x", (1, 0)), Leaf(pytoken.NEWLINE, "\n", (1, 2))]), 1)

# Generated at 2022-06-17 17:10:04.760774
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar
    from .pgen2.driver import Driver
    from .pgen2 import token

    g = Grammar()
    g.type2name[token.NAME] = "NAME"
    g.type2name[token.NUMBER] = "NUMBER"
    g.symbol2number["expr"] = 256
    g.symbol2number["term"] = 257
    g.symbol2number["factor"] = 258
    g.symbol2number["atom"] = 259
    g.symbol2number["NAME"] = 260
    g.symbol2number["NUMBER"] = 261
    g.symbol2number["LPAR"] = 262
    g.sy

# Generated at 2022-06-17 17:10:12.607694
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    import pytest
    from . import parse

    def check(pattern, expected):
        result = pattern.optimize()
        assert result == expected, (result, expected)

    def check_parse(pattern, expected):
        result = parse(pattern).optimize()
        assert result == expected, (result, expected)

    check(WildcardPattern(min=1, max=1), NodePattern())
    check(WildcardPattern(min=1, max=1, name="foo"), NodePattern(name="foo"))
    check(WildcardPattern(min=1, max=1, name="foo"), NodePattern(name="foo"))
    check(
        WildcardPattern(min=1, max=1, name="foo"),
        WildcardPattern(min=1, max=1, name="foo"),
    )

# Generated at 2022-06-17 17:10:23.254416
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import driver
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.token import tok_name

    def _test(pattern, input):
        tokens = list(generate_tokens(StringIO(input).readline))
        try:
            tree = driver.parse_tokens(tokens)
        except ParseError:
            tree = None
        if tree is None:
            print("Parse error")
            return
        for i, r in pattern.generate_matches(tree.leaves()):
            print("%d: %s" % (i, r))

    def test(pattern, input):
        print("pattern: %r" % pattern)

# Generated at 2022-06-17 17:10:36.669423
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2 import tokenize
    from .pgen2 import grammar
    from .pgen2 import pgen
    from .pgen2 import token
    from .pgen2 import parse
    from .pgen2 import driver
    from .pgen2 import pgen
    from .pgen2 import token
    from .pgen2 import parse
    from .pgen2 import driver
    from .pgen2 import pgen
    from .pgen2 import token
    from .pgen2 import parse
    from .pgen2 import driver
    from .pgen2 import pgen
    from .pgen2 import token
    from .pgen2 import parse

# Generated at 2022-06-17 17:10:47.667793
# Unit test for method generate_matches of class WildcardPattern

# Generated at 2022-06-17 17:10:58.216885
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from . import pytree
    from . import pytoken
    from . import pgen2
    from . import pgen2_parse
    from . import pgen2_tokenize
    from . import pgen2_grammar

    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test for method leaves of class Base
    # Test