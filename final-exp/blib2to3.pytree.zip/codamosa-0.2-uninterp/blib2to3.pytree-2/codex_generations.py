

# Generated at 2022-06-17 17:02:49.991824
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "a")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-17 17:02:57.426168
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node
    n = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    n2 = n.clone()
    assert n == n2
    assert n is not n2
    assert n.children[0] is not n2.children[0]
    assert n.children[1] is not n2.children[1]

# Generated at 2022-06-17 17:03:09.228399
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Symbol

    assert repr(LeafPattern(Symbol.testlist_comp)) == "LeafPattern(testlist_comp)"
    assert repr(LeafPattern(Symbol.testlist_comp, "foo")) == "LeafPattern(testlist_comp, 'foo')"
    assert repr(LeafPattern(Symbol.testlist_comp, "foo", "bar")) == "LeafPattern(testlist_comp, 'foo', 'bar')"
    assert repr(LeafPattern(Symbol.testlist_comp, name="bar")) == "LeafPattern(testlist_comp, name='bar')"

# Generated at 2022-06-17 17:03:20.066049
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    from . import pygram
    from .pgen2 import driver
    from . import python_symbols as syms
    from . import token

    grammar = driver.load_grammar("Grammar.txt")
    driver.initialize_grammar(grammar)
    pygram.init_grammar(grammar)

    def test_leaves(s):
        t = driver.parse_string(s, grammar, "single_input")
        assert t.type == syms.single_input
        assert t.children[0].type == token.NEWLINE
        assert t.children[1].type == syms.simple_stmt
        assert t.children[1].children[0].type == syms.small_stmt

# Generated at 2022-06-17 17:03:27.752365
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        node.changed()
        assert node.was_changed == expected

    # Leaf
    leaf = Leaf(1, "")
    check(leaf, True)

    # Node
    node = Node(syms.simple_stmt, [leaf])
    check(node, True)

    # Parent
    parent = Node(syms.simple_stmt, [node])
    check(node, True)
    check(parent, True)

    # Grandparent
    grandparent = Node(syms.simple_stmt, [parent])
    check(node, True)
    check(parent, True)
    check(grandparent, True)

    # Test that the flag

# Generated at 2022-06-17 17:03:33.046392
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from .pgen2 import driver
    from .pgen2 import tokenize
    from .pgen2 import parse
    from .pgen2 import pgen
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram
    from . import pygram

# Generated at 2022-06-17 17:03:44.380364
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    def check(node, clone):
        assert node.type == clone.type
        assert node.children == clone.children
        assert node.prefix == clone.prefix
        assert node.parent is None
        assert clone.parent is None
        assert node.was_changed == clone.was_changed
        assert node.was_checked == clone.was_checked
        assert node.next_sibling is None
        assert clone.next_sibling is None
        assert node.prev_sibling is None
        assert clone.prev_sibling is None

    def check_node(node):
        clone = node.clone()
        check(node, clone)

    def check_leaf(leaf):
        clone = leaf.clone

# Generated at 2022-06-17 17:03:51.680729
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token
    from . import pytree
    from .fixer_util import Name
    n = Node(python_symbols.power, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])
    n.fixers_applied = [Name("a", "b")]
    n2 = n.clone()
    assert n2.type == n.type
    assert n2.children == n.children
    assert n2.fixers_applied == n.fixers_applied
    assert n2.parent is None
    assert n2.children[0].parent is n2
    assert n2.children[1].parent is n2

# Generated at 2022-06-17 17:04:01.987203
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pgen2 import token
    from . import pytree
    from .fixer_util import Name
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    out = StringIO()

# Generated at 2022-06-17 17:04:08.944739
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse_grammar

    g = Grammar()
    g.type2name = tok_name

# Generated at 2022-06-17 17:04:25.427681
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, 'a')
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-17 17:04:32.807598
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern(NodePattern(type=token.NAME))
    nodes = [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]
    assert list(pattern.generate_matches(nodes)) == [(0, {})]
    nodes = [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c"), Leaf(1, "d")]
    assert list(pattern.generate_matches(nodes)) == []
    pattern = NegatedPattern(None)
    nodes = [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]
    assert list(pattern.generate_matches(nodes)) == []
    nodes = []

# Generated at 2022-06-17 17:04:36.880177
# Unit test for function generate_matches
def test_generate_matches():
    p = NodePattern(type=token.NAME)
    q = NodePattern(type=token.NUMBER)
    r = NodePattern(type=token.STRING)
    s = NodePattern(type=token.NAME, name="name")
    t = NodePattern(type=token.NUMBER, name="number")
    u = NodePattern(type=token.STRING, name="string")
    w = WildcardPattern()
    x = WildcardPattern(min=1)
    y = WildcardPattern(min=1, name="wild")
    z = WildcardPattern(content=[(p, q)], min=1, name="wild")
    a = NegatedPattern()
    b = NegatedPattern(p)
    c = NegatedPattern(w)
    d = NegatedPattern(z)


# Generated at 2022-06-17 17:04:50.589170
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar
    from .pygram import python_grammar_no_print_statement
    from .pygram import python_grammar_no_print_statement_no_exec_statement
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no_eval_input_no_execfile_no_future
    from .pygram import python_grammar_no_print_statement_no_exec_statement_no

# Generated at 2022-06-17 17:04:59.253037
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from .pgen2 import token
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from . import fixer_base
    from .fixer_util import Name, Call, Comma, String, Newline, Number, syms
    from .fixer_util import LParen, RParen, ArgList, Dot, Attr, Node
    from .fixer_util import token
    from .fixer_util import Leaf, Node, String, Number, Syms, Keyword, Name
    from .fixer_util import Newline, Comma, LParen, RParen, ArgList, Dot
    from .fixer_util import Attr

# Generated at 2022-06-17 17:05:11.809749
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:05:24.128454
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import python_grammar as grammar
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree

# Generated at 2022-06-17 17:05:31.528252
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree

    # Test for a node with a next sibling
    node = pytree.Node(syms.simple_stmt, [Leaf(1, "a"), Leaf(1, "b")])
    assert node.get_suffix() == "b"

    # Test for a node without a next sibling
    node = pytree.Node(syms.simple_stmt, [Leaf(1, "a")])
    assert node.get_suffix() == ""



# Generated at 2022-06-17 17:05:41.867379
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2 import token

    class NodePattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return True

    class LeafPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

        def _submatch(self, node, results=None):
            return True

    class WildcardPattern(BasePattern):
        def __init__(self, type, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name


# Generated at 2022-06-17 17:05:52.101377
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    class DummyNode(Node):
        def __init__(self, type, children=None):
            super().__init__(type, children)

        def _eq(self, other):
            return self.type == other.type

        def clone(self):
            return DummyNode(self.type, [child.clone() for child in self.children])

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()


# Generated at 2022-06-17 17:06:54.482012
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Unit test for method __repr__ of class BasePattern
    """
    # Test with a LeafPattern
    p = LeafPattern(token.NAME)
    assert repr(p) == "LeafPattern(NAME, None, None)"
    # Test with a NodePattern
    p = NodePattern(syms.expr)
    assert repr(p) == "NodePattern(expr, None, None)"
    # Test with a WildcardPattern
    p = WildcardPattern()
    assert repr(p) == "WildcardPattern(None, None, None)"
    # Test with a WildcardPattern with a name
    p = WildcardPattern(name="foo")
    assert repr(p) == "WildcardPattern(None, None, foo)"
    # Test with a WildcardPattern with a content

# Generated at 2022-06-17 17:07:06.117335
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:07:13.284046
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import parse

    def check(pattern, nodes, expected):
        pattern = parse(pattern)
        nodes = parse(nodes)
        result = list(pattern.generate_matches(nodes))
        assert result == expected, (pattern, nodes, result, expected)

    check(".*", "", [(0, {})])
    check(".*", "a", [(1, {})])
    check(".*", "ab", [(2, {})])
    check(".*", "abc", [(3, {})])
    check(".*", "abcd", [(4, {})])
    check(".*", "abcde", [(5, {})])
    check(".+", "", [])
    check(".+", "a", [(1, {})])

# Generated at 2022-06-17 17:07:26.244161
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def check(node, expected):
        node.replace(expected)
        assert node.parent is None
        assert expected.parent is parent
        assert parent.children == [expected]

    parent = Node(syms.simple_stmt, [Leaf(1, "a")])
    node = parent.children[0]
    check(node, Leaf(1, "b"))
    check(node, Node(syms.expr_stmt, [Leaf(1, "b")]))
    check(node, [Leaf(1, "b")])
    check(node, [Node(syms.expr_stmt, [Leaf(1, "b")])])

# Generated at 2022-06-17 17:07:37.689775
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

# Generated at 2022-06-17 17:07:52.361183
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram

# Generated at 2022-06-17 17:08:05.456621
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:08:18.108894
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram

    grammar = pygram.python_grammar
    pytree = Node(syms.file_input, [Leaf(1, "a"), Leaf(1, "b")])
    pytree.replace(Leaf(1, "c"))
    assert pytree.children == [Leaf(1, "c")]
    pytree.replace([Leaf(1, "d"), Leaf(1, "e")])
    assert pytree.children == [Leaf(1, "d"), Leaf(1, "e")]
    pytree.replace(None)
    assert pytree.children == []
    pytree.replace([Leaf(1, "f"), Leaf(1, "g")])
    assert py

# Generated at 2022-06-17 17:08:29.420411
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar

    def test_remove(node):
        # Remove the node from the tree.
        node.remove()
        # Check that the node is not in the tree.
        assert node.parent is None
        assert node not in node.root().post_order()
        assert node not in node.root().pre_order()

    def test_remove_with_siblings(node):
        # Remove the node from the tree.
        node.remove()
        # Check that the node is not in the tree.
        assert node.parent is None
        assert node not in node.root().post_order()
        assert node not in node.root().pre_order()
        # Check that the node's siblings are still

# Generated at 2022-06-17 17:08:41.046710
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from .pgen2 import token
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram

# Generated at 2022-06-17 17:08:55.655695
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pygram
    from .pgen2 import token

    def test_clone(node):
        clone = node.clone()
        assert node == clone
        assert node is not clone
        assert node.parent is None
        assert clone.parent is None
        assert node.children == clone.children
        assert node.children is not clone.children
        for child, clone_child in zip(node.children, clone.children):
            assert child == clone_child
            assert child is not clone_child
            assert child.parent is node
            assert clone_child.parent is clone

    def test_clone_with_parent(node):
        parent = Node(syms.file_input, [node])
        clone = node.clone()


# Generated at 2022-06-17 17:09:08.363927
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pytokenize
    from . import pytree
   

# Generated at 2022-06-17 17:09:20.275501
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree


# Generated at 2022-06-17 17:09:25.300495
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Grammar

    g = Grammar()
    p = g.pattern("foo")
    assert p.optimize() is p
    p = g.pattern("foo", "bar")
    assert p.optimize() is p
    p = g.pattern("foo", "bar", "baz")
    assert p.optimize() is p



# Generated at 2022-06-17 17:09:30.726673
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar
    from .pgen2.token import tok_name
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar


# Generated at 2022-06-17 17:09:41.461080
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.INDENT) == "INDENT"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_symbols.LPAR) == "LPAR"
    assert type_repr(python_symbols.RPAR) == "RPAR"
    assert type_repr(python_symbols.LSQB) == "LSQB"
   

# Generated at 2022-06-17 17:09:48.495568
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern(min=1, max=1, content=[["a"]])
    assert p.optimize() == NodePattern(content=[["a"]])
    p = WildcardPattern(min=1, max=1, content=[["a"]], name="foo")
    assert p.optimize() == NodePattern(content=[["a"]], name="foo")
    p = WildcardPattern(min=1, max=1, content=[["a"]], name="a")
    assert p.optimize() == NodePattern(content=[["a"]], name="a")
    p = WildcardPattern(min=1, max=1, content=[["a"]], name="a")
    assert p.optimize() == NodePattern(content=[["a"]], name="a")

# Generated at 2022-06-17 17:09:56.590390
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols
    from .pgen2 import token
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2
    from . import pytoken
    from . import pytokenize
    from . import pytree
    from . import pygram
    from . import pgen2


# Generated at 2022-06-17 17:10:02.672353
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree

    def _test_remove(node, expected_parent_children, expected_parent_changed):
        parent = node.parent
        parent_children = parent.children
        parent_changed = parent.was_changed
        node.remove()
        assert parent_children == expected_parent_children
        assert parent_changed == expected_parent_changed

    # Test removing a leaf
    leaf = Leaf(1, "leaf")
    node = Node(syms.simple_stmt, [leaf])
    _test_remove(leaf, [], True)

    # Test removing a node with children
    leaf1 = Leaf(1, "leaf1")
    leaf2 = Leaf(1, "leaf2")
    leaf3 = Leaf

# Generated at 2022-06-17 17:10:10.084595
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern(min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(min=1, max=1, name="foo").optimize() == NodePattern(name="foo")
    assert WildcardPattern(min=1, max=1, name="foo").optimize() == NodePattern(name="foo")
    assert WildcardPattern(min=1, max=1, name="foo").optimize() == NodePattern(name="foo")
    assert WildcardPattern(min=1, max=1, name="foo").optimize() == NodePattern(name="foo")
    assert WildcardPattern(min=1, max=1, name="foo").optimize() == NodePattern(name="foo")

# Generated at 2022-06-17 17:10:34.071340
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken

# Generated at 2022-06-17 17:10:43.059924
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def test(pattern, nodes, expected):
        result = list(pattern.generate_matches(nodes))
        assert result == expected, (result, expected)

    def test_fail(pattern, nodes):
        try:
            list(pattern.generate_matches(nodes))
        except AssertionError:
            pass
        else:
            assert False, "expected AssertionError"

    # Test the special case of a single node
    test(WildcardPattern(), [Leaf(1, "a")], [(1, {})])
    test(WildcardPattern(name="a"), [Leaf(1, "a")], [(1, {"a": [Leaf(1, "a")]})])
    test(WildcardPattern(min=1), [Leaf(1, "a")], [(1, {})])