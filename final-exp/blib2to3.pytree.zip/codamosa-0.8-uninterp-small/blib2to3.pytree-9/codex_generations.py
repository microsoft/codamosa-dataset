

# Generated at 2022-06-25 15:12:37.904550
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_pattern_0 = BasePattern()
    base_node_0 = BaseNode()
    leaves_0 = []
    leaves_1 = base_node_0.leaves()
    while leaves_1.hasNext():
        leaves_0.append(leaves_1.next())


# Generated at 2022-06-25 15:12:40.075427
# Unit test for method replace of class Base
def test_Base_replace():
    node_obj = Base()
    node_obj.replace(Node(1, 'test'))

# Function to unit test the method get_suffix of class Base

# Generated at 2022-06-25 15:12:42.559388
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test case 1
    base_pattern_1 = BasePattern()
    node_pattern_1 = NodePattern()
    wildcard_pattern_1 = WildcardPa

# Generated at 2022-06-25 15:12:51.572325
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    result_list_0 = list(NegatedPattern().generate_matches(list()))
    assert len(result_list_0) == 1
    result_list_1 = list(NegatedPattern(WildcardPattern()).generate_matches(list(range(0,10))))
    assert len(result_list_1) == 0
    result_list_2 = list(NegatedPattern(WildcardPattern()).generate_matches([]))
    assert len(result_list_2) == 1
    result_list_3 = list(NegatedPattern(WildcardPattern()).generate_matches([1]))
    assert len(result_list_3) == 0


# Generated at 2022-06-25 15:12:57.183037
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_pattern_0 = WildcardPattern()
    base_pattern_0.optimize()


# Generated at 2022-06-25 15:12:58.523102
# Unit test for method replace of class Base
def test_Base_replace():
    base_instance_0 = Base()
    base_instance_0.replace(base_instance_0)


# Generated at 2022-06-25 15:13:01.930027
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_instance_0 = Base()
    from blib2to3.pgen2.parse import ParseError
    try:
        base_pre_order_0 = base_instance_0.pre_order()
    except ParseError as e:
        print(e)



# Generated at 2022-06-25 15:13:11.398793
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from collections import defaultdict
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.parse import parse_module
    from blib2to3.pgen2.pgen import grammar
    from blib2to3.pytree import Node, Leaf
    from blib2to3.fixer_base import BaseFix

    source = """\
    any_code = 2

    def test(arg1, arg2):
        print('test')
    """
    node_0 = grammar.ext_grammar.parse(source)
    node_0.update_sibling_maps()
    assert node_0.prev_sibling_map is not None
    assert node_0.next_sibling_map is not None

# Generated at 2022-06-25 15:13:15.745324
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    wp_0 = WildcardPattern()
    wp_0.content = [[Leaf(2, ""), Leaf(2, "")], [Node(2, 2, [], 2)]]
    wp_0.min = 2
    wp_0.max = 2
    nl_0 = Leaf(2, "")
    assert not wp_0.match_seq([nl_0])


# Generated at 2022-06-25 15:13:22.358673
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    negated_pattern_0 = NegatedPattern()
    # Verify that the method generate_matches handles the following arguments:
    # nodes = {'name': 'expr_stmt'}
    arg_0 = {'name': 'expr_stmt'}
    result_0 = negated_pattern_0.generate_matches(arg_0)
    assert result_0 != False


# Generated at 2022-06-25 15:14:12.407783
# Unit test for method remove of class Base
def test_Base_remove():
    base_remove_0 = Base()
    assert base_remove_0.remove() is None


# Generated at 2022-06-25 15:14:18.202590
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    test_case_0()
    from .pgen2.token import Token as BaseToken
    from .pgen2.tokenize import generate_tokens
    from .pgen2.parse import ParseError

    class Token(BaseToken):
        def __eq__(self, other):
            try:
                return self.type == other.type and self.string == other.string
            except AttributeError:
                return False

    def print_result(result, inputstring):
        for n in result:
            print(str(n.type) + " " + n.string)
        print("\n")
        print("inputstring:")
        print(inputstring)

    def test_inner_comments(inputstring, expected_result):
        print("inputstring:")
        print(inputstring)

# Generated at 2022-06-25 15:14:22.391286
# Unit test for method remove of class Base
def test_Base_remove():
    # Test variables
    leaf_0 = Leaf(256, "", None, None)
    node_0 = Node(257, None, [leaf_0])
    node_1 = Node(257, None, [leaf_0])
    node_2 = Node(257, None, [leaf_0])

    # Test method
    assert node_0.remove() == 0
    assert node_2.remove() == 0
    assert node_1.remove() == 0



# Generated at 2022-06-25 15:14:24.734599
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    base_pattern_0 = BasePattern()
    for x in base_pattern_0.pre_order():
        print(x)


# Generated at 2022-06-25 15:14:27.971543
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_base_type = Leaf()
    try:
        leaf_post_order = leaf_base_type.post_order()
    except NotImplementedError:
        logging.exception("Exception thrown in not implemented method post_order of class Leaf")


# Generated at 2022-06-25 15:14:37.197053
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_pattern_1 = BasePattern(1)
    nodes = []
    result = base_pattern_1.match_seq(nodes)
    assert not result
    leaf_pattern_0 = LeafPattern(1)
    result = leaf_pattern_0.match_seq(nodes)
    assert not result
    wildcard_pattern_0 = WildcardPattern()
    result = wildcard_pattern_0.match_seq(nodes)
    assert result
    nodes = [Leaf(1, "")]
    result = base_pattern_1.match_seq(nodes)
    assert result
    result = leaf_pattern_0.match_seq(nodes)
    assert result
    result = wildcard_pattern_0.match_seq(nodes)
    assert result
    # Issue #67: WildcardPattern.match_

# Generated at 2022-06-25 15:14:40.535671
# Unit test for method post_order of class Node
def test_Node_post_order():
    base_pattern_1 = BasePattern()
    node_0 = Node(257, [], "")
    children = [base_pattern_1, node_0]
    node_1 = Node(257, children, "")
    iterator = node_1.post_order()
    tuple_0 = ()
    value = tuple(iterator)
    assert value == tuple_0


# Generated at 2022-06-25 15:14:52.400153
# Unit test for method remove of class Base
def test_Base_remove():
    node = Base()
    node.parent = Base()
    node.next_sibling = Base()
    node.prev_sibling = Base()
    node.children = [Base(), Base(), Base()]
    parent = node.parent
    parent.children = node.children
    parent.prev_sibling_map = {id(node): node.prev_sibling}
    parent.next_sibling_map = {id(node): node.next_sibling}
    parent.children[0].next_sibling = parent.children[1]
    parent.children[1].prev_sibling = parent.children[0]
    parent.children[1].next_sibling = parent.children[2]
    parent.children[2].prev_sibling = parent.children[1]
    parent.children[2].next_sibling

# Generated at 2022-06-25 15:14:55.081382
# Unit test for method clone of class Base
def test_Base_clone():
    pat = NodePattern(op=python_symbols.expr_stmt, children=[LeafPattern(value='a')])
    base_pattern_1 = pat
    assert(base_pattern_1.clone())



# Generated at 2022-06-25 15:14:56.085056
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_pattern_0 = BasePattern()
    test_case_0(base_pattern_0)


# Generated at 2022-06-25 15:15:24.567669
# Unit test for function generate_matches
def test_generate_matches():
    class FakePattern:
        def generate_matches(self, nodes):
            return [(len(nodes), {})]
    class FakePattern2:
        def generate_matches(self, nodes):
            if len(nodes) > 1:
                yield (1, {})
    fake_pattern_0 = FakePattern()
    fake_pattern_1 = fake_pattern_0
    fake_pattern_2 = FakePattern2()
    base_pattern_0 = BasePattern()
    node_pattern_0 = NodePattern()
    wildcard_pattern_0 = WildcardPattern()
    negated_pattern_0 = NegatedPattern()
    # Testing whether the returned type is correct
    # Testing for case when len(patterns) == 0

# Generated at 2022-06-25 15:15:34.665001
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    x = WildcardPattern(None, 1, 1)
    node_pattern_0 = NodePattern()
    p = NL(0)
    l = NL(1)
    l2 = NL(1)
    l3 = NL(5)
    p.children.append(l)
    p.children.append(l2)
    p.children.append(l3)
    assert len(x.generate_matches([p])) == 0
    assert len(x.generate_matches([l])) == 1
    assert len(x.generate_matches([p, l])) == 0
    assert len(node_pattern_0.generate_matches([p, l])) == 0


# Generated at 2022-06-25 15:15:44.988272
# Unit test for method __repr__ of class Node

# Generated at 2022-06-25 15:15:46.087990
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    assert Base.pre_order is base_pattern_0.pre_order


# Generated at 2022-06-25 15:15:51.186067
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    # Test for method __repr__ of class Node
    assert Node(1, [Node(3, []), Node(4, [])]).__repr__() == 'Node(1, [Node(3, []), Node(4, [])])'
    assert Node(
        4, [Leaf(1, 'a'), Leaf(2, 'b'), Leaf(3, 'c')]).__repr__() == 'Node(4, [Leaf(1, \'a\'), Leaf(2, \'b\'), Leaf(3, \'c\')])'



# Generated at 2022-06-25 15:16:00.393034
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pgen2 import token
    a = Base(token.NAME)
    b = Base(token.NAME)
    for src, expected in [
        (a, True),
        (b, True),
        (Base(token.STRING), False)
    ]:
        actual = a.__eq__(src)
        assert actual == expected
    a.children = [Leaf(0, "a"), Node(2, [Leaf(0, "b")], prefix="c")]
    b.children = [Leaf(0, "a"), Node(2, [Leaf(0, "b")], prefix="c")]

# Generated at 2022-06-25 15:16:04.105605
# Unit test for method replace of class Base
def test_Base_replace():
    node_0 = Base()
    node_1 = Base()
    node_1.parent = node_0
    node_0.children = [node_1]
    node_2 = Base()
    node_0.replace(node_2)
    # AssertionError: (Base(Base()), Base(), Base())


# Generated at 2022-06-25 15:16:14.325324
# Unit test for method clone of class Node
def test_Node_clone():
    node = Node(
        type=257,
        children=[
            Leaf(
                type=512,
                value='foo',
                context=None,
                prefix='',
            ),
            Node(
                type=258,
                children=[
                    Leaf(
                        type=512,
                        value='bar',
                        context=None,
                        prefix=' ',
                    ),
                    Leaf(
                        type=512,
                        value='baz',
                        context=None,
                        prefix=' ',
                    ),
                ],
                context=None,
                prefix=' ',
                fixers_applied=None,
            ),
        ],
        context=None,
        prefix='# hello world\n',
        fixers_applied=None,
    )

# Generated at 2022-06-25 15:16:26.501506
# Unit test for function generate_matches
def test_generate_matches():
    N1 = Node(NL.NT.NAME, [Leaf(NL.T.NAME, 'foo', prefix='', suffix='')])
    N2 = Node(NL.NT.NAME, [Leaf(NL.T.NAME, 'bar', prefix='', suffix='')])
    N3 = Node(NL.NT.NAME, [Leaf(NL.T.NAME, 'baz', prefix='', suffix='')])
    P1 = NodePattern(NL.NT.NAME)
    P2 = NodePattern(NL.NT.NAME, name='foo')
    P3 = NodePattern(NL.NT.NAME, name='bar')

# Generated at 2022-06-25 15:16:35.064438
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_pattern_1 = BasePattern()
    base_pattern_1.type = 1
    base_pattern_1.parent = 1
    base_pattern_1.children = (1, 2)
    base_pattern_1.was_checked = False

    base_pattern_2 = BasePattern()
    base_pattern_2.type = 1
    base_pattern_2.parent = 1
    base_pattern_2.children = (1, 2)
    base_pattern_2.was_checked = False

    assert base_pattern_1 == base_pattern_2



# Generated at 2022-06-25 15:16:51.235068
# Unit test for method remove of class Base
def test_Base_remove():
    node_1 = Leaf()
    assert node_1.remove() is None
    node_2 = Leaf()
    node_2.parent = node_1
    assert node_2.parent is not None
    assert node_2.remove() == 0
    assert node_2.parent is None


# Generated at 2022-06-25 15:16:58.891133
# Unit test for method leaves of class Base
def test_Base_leaves():
    """Test the leaves method: return all leaves of a tree"""
    root = Node(1, "", None, [])
    root.children = [Node(1, "", None, []) for i in range(2)]
    root.children[0].children = [Node(1, "", None, []) for j in range(2)]
    root.children[1].children = [Node(1, "", None, []) for j in range(2)]

    leaves = [Leaf(1, ""), Leaf(1, ""), Leaf(1, ""), Leaf(1, "")]
    root.children[0].children[0].children = [leaves[0]]
    root.children[0].children[1].children = [leaves[1]]
    root.children[1].children[0].children = [leaves[2]]

# Generated at 2022-06-25 15:17:01.260769
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    leaf_0 = Leaf()
    assert leaf_0.get_suffix() == ''


# Generated at 2022-06-25 15:17:04.594926
# Unit test for method post_order of class Base
def test_Base_post_order():
    leaf_0 = Leaf()
    node_0 = Node()
    node_0.children = [leaf_0]
    node_0.inner_node_order(node_0)
    leaf_0.post_order()


# Generated at 2022-06-25 15:17:06.972793
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_0 = Base()
    sequence_0 = base_0.pre_order()
    for value_0 in sequence_0:
        assert True


# Generated at 2022-06-25 15:17:13.861610
# Unit test for method depth of class Base
def test_Base_depth():
    leaf_0 = Leaf(0, "0.0", (2, 3))
    assert leaf_0.depth() == 0
    node_0 = Node(0, [])
    leaf_0.parent = node_0

    assert leaf_0.depth() == 1
    node_1 = Node(0, [])
    node_2 = Node(0, [])
    node_3 = Node(0, [])
    node_1.children = [node_2]
    node_2.children = [node_3]
    node_3.children = [node_0]

    assert leaf_0.depth() == 4


# Generated at 2022-06-25 15:17:14.483658
# Unit test for constructor of class NodePattern
def test_NodePattern():
    global NodePattern
    NodePattern()


# Generated at 2022-06-25 15:17:17.927402
# Unit test for method clone of class Base
def test_Base_clone(): # 100% coverage for Base._eq
    # test_case_0
    leaf_0 = Leaf()
    leaf_0.prefix = "def"
    leaf_0.suffix = " {b}"
    leaf_0.value = "def"
    leaf_0.value = None
    leaf_0.changed()
    leaf_0_clone = leaf_0.clone()
    assert isinstance(leaf_0_clone, Base)


# Generated at 2022-06-25 15:17:24.902584
# Unit test for function type_repr
def test_type_repr():
    # assert False, 'Unimplemented'
    leaf = Leaf()
    assert leaf.value == "", "Leaf() value should be blank"
    assert leaf.type == -1, "Leaf() type should be -1"
    assert leaf.context is None, "Leaf() context should be None"
    assert leaf.prefix == "", "Leaf() prefix should be blank"
    assert leaf.lineno == 1, "Leaf() lineno should be 1"
    assert leaf.column == 0, "Leaf() column should be 0"


# Generated at 2022-06-25 15:17:28.984222
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern = WildcardPattern([[WildcardPattern()]], 1, 1)
    optimized_pattern = pattern.optimize()
    if not isinstance(optimized_pattern, NodePattern):
        print("optimized_pattern is ", optimized_pattern)
        raise AssertionError(optimized_pattern)


# Generated at 2022-06-25 15:17:53.704627
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_0 = Leaf(0, 'a')
    expected_result = {0: 'a'}
    actual_result = {}
    for leaf in leaf_0.pre_order():
        actual_result[leaf.type] = leaf.value
    assert actual_result == expected_result


# Generated at 2022-06-25 15:17:59.070700
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    leaf_0 = Leaf()
    leaf_0.lineno = 1
    node_1 = Node(children=[leaf_0], type=1)
    assert node_1.get_lineno() == 1


# Generated at 2022-06-25 15:18:05.749080
# Unit test for method post_order of class Node
def test_Node_post_order():
    # Setup
    root = Node(123, [Leaf(), Leaf(), Leaf()])

    # Invocation
    postorder = root.post_order()
    postorder_list = list(postorder)

    # Checking/Asserting
    assert len(postorder_list) == 4
    assert postorder_list[0].parent is root
    assert postorder_list[1].parent is root
    assert postorder_list[2].parent is root
    assert postorder_list[3] is root



# Generated at 2022-06-25 15:18:15.957841
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    root_node = Node()
    l_0 = Leaf()
    l_1 = Leaf()
    l_2 = Leaf()
    l_3 = Leaf()
    l_4 = Leaf()
    l_5 = Leaf()
    l_6 = Leaf()
    l_7 = Leaf()
    l_8 = Leaf()
    l_9 = Leaf()
    l_10 = Leaf()
    l_11 = Leaf()
    l_12 = Leaf()
    l_13 = Leaf()
    l_14 = Leaf()
    l_15 = Leaf()
    l_16 = Leaf()
    l_17 = Leaf()
    l_18 = Leaf()
    l_19 = Leaf()
    l_20 = Leaf()
    l_21 = Leaf()
    l_22 = Leaf()
    l_23 = Leaf()

# Generated at 2022-06-25 15:18:18.228573
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    leaf_0 = Leaf()
    node_0 = Node()
    node_0.children = [leaf_0]
    out_0 = node_0.pre_order()
    assert str(sys.version_info[0]) == '3'
    assert str(sys.version_info[1]) == '7'


# Generated at 2022-06-25 15:18:20.307799
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    leaf_0 = Leaf()
    assert str(Node(0, [leaf_0])) == str(Node(0, [leaf_0]))


# Generated at 2022-06-25 15:18:27.370561
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    v0 = BasePattern()
    v1 = BasePattern()
    v1.type = 0
    v2 = BasePattern()
    v2.type = 1
    v0.content = v1
    v2.content = v0
    v2.type = 2
    v3 = BasePattern()
    v3.type = 2
    v3.content = v2
    v3.generate_matches(None)
    v3.generate_matches(None)
    v3.generate_matches(None)
    v3.generate_matches(None)
    v3.generate_matches(None)
    v3.generate_matches(None)
    v3.generate_matches(None)
    v3.generate_matches(None)

# Generated at 2022-06-25 15:18:29.782964
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    leaf_0 = Leaf()
    assert leaf_0.__repr__() == 'Leaf(None, None, None)'


# Generated at 2022-06-25 15:18:34.842563
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    # Create an instance of class Leaf
    leaf_0 = Leaf(149, "k", (0, 0))
    # Call method post_order of class Leaf
    retval_0 = leaf_0.post_order()
    # Check return value of method post_order

# Generated at 2022-06-25 15:18:35.745097
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    ...

# Generated at 2022-06-25 15:19:50.244686
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    nud_tokens = [Leaf(token, 'bar') for token in ['id', 'id', 'id', 'break', 'id', 'id', 'id', 'break']]
    patterns = [NodePattern(type = 260, name = 'bare_name', content = [WildcardPattern(name = 'bare_name', content = [Leaf(token = 257, name = 'name') for token in ['id']])])]
    results = {}
    # self.assertTrue(patterns[0].match(nud_tokens[0], results) and results == {'bare_name': [nud_tokens[0]], 'name': nud_tokens[0]})
    # self.assertTrue(patterns[0].match(nud_tokens[1], results) and results == {'bare_name

# Generated at 2022-06-25 15:19:54.153466
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_0 = Leaf()
    assert len(list(leaf_0.pre_order())) == 1
    assert list(leaf_0.pre_order())[0].__class__ == Leaf


# Generated at 2022-06-25 15:19:56.457812
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    leaf_0 = Leaf()
    leaf_1 = Leaf()
    result = leaf_0.__eq__(leaf_1)
    assert result == True



# Generated at 2022-06-25 15:19:58.242449
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_0 = Leaf()
    output = leaf_0.post_order()
    assert [leaf_0] == list(output), output


# Generated at 2022-06-25 15:20:03.169116
# Unit test for method replace of class Base
def test_Base_replace():
    leaf_0 = Leaf()
    leaf_1 = Leaf()
    leaf_2 = Leaf()
    node_0 = Node(249, [leaf_0, leaf_1])
    node_1 = Node(256, [node_0, leaf_2])
    node_0.parent = node_1
    node_0.replace([leaf_0, leaf_2])
    assert node_1.children == [leaf_0, leaf_2]


# Generated at 2022-06-25 15:20:06.581102
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    test_case_0()



# Generated at 2022-06-25 15:20:14.594392
# Unit test for method post_order of class Base
def test_Base_post_order():
    leaf_0 = Leaf()
    leaf_1 = Leaf()
    node_0 = Node()
    if node_0.children is None:
        node_0.children = []
    node_0.children.append(leaf_0)
    node_0.children.append(leaf_1)
    if node_0.children is not None and node_0.children:
        for child in node_0.children:
            child.parent = node_0


# Generated at 2022-06-25 15:20:22.037991
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node
    
    # Build sample tree
    leaf_0 = Leaf('leaf0',0)
    leaf_1 = Leaf('leaf1',1)
    leaf_2 = Leaf('leaf2',2)
    leaf_3 = Leaf('leaf3',3)
    leaf_4 = Leaf('leaf4',4)
    leaf_5 = Leaf('leaf5',5)
    leaf_6 = Leaf('leaf6',6)
    leaf_7 = Leaf('leaf7',7)
    leaf_8 = Leaf('leaf8',8)
    leaf_9 = Leaf('leaf9',9)
    leaf_10 = Leaf('leaf10',10)
    leaf_11 = Leaf('leaf11',11)
    leaf_12 = Leaf('leaf12',12)
    leaf_13 = Leaf('leaf13',13)

# Generated at 2022-06-25 15:20:26.042023
# Unit test for method post_order of class Base
def test_Base_post_order():
    leaf_0 = Leaf()
    leaf_1 = Leaf()
    node_0 = Node(children=[leaf_0, leaf_1])
    leaf_2 = Leaf()
    node_1 = Node(children=[node_0, leaf_2])
    node_2 = Node(children=[node_1])
    iter_0 = node_2.post_order()
    iter_1 = node_2.post_order()
    value_0 = next(iter_0, None)
    value_1 = next(iter_1, None)
    value_2 = next(iter_0, None)
    value_3 = next(iter_1, None)


# Generated at 2022-06-25 15:20:27.573493
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    leaf_0 = Leaf()

    assert leaf_0.get_suffix() == ""

