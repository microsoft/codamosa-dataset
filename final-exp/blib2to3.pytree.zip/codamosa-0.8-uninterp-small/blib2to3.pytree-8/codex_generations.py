

# Generated at 2022-06-25 15:13:06.634808
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Test for constructor of class NodePattern
    node_pattern = NodePattern(1, '', '')


# Generated at 2022-06-25 15:13:12.277125
# Unit test for method clone of class Node
def test_Node_clone():
    try:
        temp_var_0__node_0 = Node(type, [ch.clone() for ch in children])
    except AssertionError:
        print("AssertionError")
    try:
        temp_var_0__node_1 = Node(type, [ch.clone() for ch in children])
    except AssertionError:
        print("AssertionError")

# Generated at 2022-06-25 15:13:17.237687
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    name = "foo"
    lineno = 1
    base = Base()
    leaf = Leaf(1, name, (1, 1), lineno, None)
    #
    # Test that the Node method calls the Leaf method
    #
    base.children = [leaf]
    assert base.get_lineno() == 1


# Generated at 2022-06-25 15:13:27.786620
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    first_python_symbol = "SYMBOL"
    # Test an empty node
    assert Base().pre_order() == []
    # Test a node with one child
    assert Base(first_python_symbol, Base(first_python_symbol)).pre_order() == [
        Base(first_python_symbol, Base(first_python_symbol)),
        Base(first_python_symbol),
    ]
    # Test a node with several children
    # Test a node with two children that are lists.
    # Test a node with two children that are lists.
    # Test a node with several children that are lists.
    # Test a node with several children that are lists.



# Generated at 2022-06-25 15:13:39.324069
# Unit test for method leaves of class Base
def test_Base_leaves():
    b_obj_0 = Base(None, None, None)
    b_list_0 = [b_obj_0]
    n_obj_0 = Node(None, b_list_0)
    if (negated_pattern_0.test(n_obj_0)):
        n_obj_0 = None
    elif (negated_pattern_1.test(n_obj_0)):
        n_obj_0 = None
    l_obj_0 = Leaf(None, None)
    t_seq_0 = [n_obj_0, l_obj_0]
    t_seq_1 = [n_obj_0, l_obj_0]
    f_bool_0 = None

# Generated at 2022-06-25 15:13:42.324918
# Unit test for method post_order of class Node
def test_Node_post_order():
    node = Node(1, [Leaf(394, "")])
    assert node.post_order() == [
        node,
        node.children[0],
    ], "Incorrect post_order ordering"


# Generated at 2022-06-25 15:13:42.976653
# Unit test for function type_repr
def test_type_repr():
    type_repr(1)


# Generated at 2022-06-25 15:13:51.437500
# Unit test for method leaves of class Base
def test_Base_leaves():
    node_tree_0 = Node()
    node_tree_1 = Node()
    node_tree_1.parent = node_tree_0
    leaf_3 = Leaf()
    leaf_3.parent = node_tree_1
    leaf_4 = Leaf()
    leaf_4.parent = node_tree_1
    node_tree_1.children = [leaf_3, leaf_4]
    assert node_tree_0.leaves() == [leaf_3, leaf_4]


# Generated at 2022-06-25 15:14:02.770672
# Unit test for method generate_matches of class NegatedPattern

# Generated at 2022-06-25 15:14:06.426256
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    negated_pattern_0 = None
    negated_pattern_1 = None
    result = negated_pattern_0.generate_matches(None)
    assert result is not None
    result = negated_pattern_1.generate_matches(None)
    assert result is not None


# Generated at 2022-06-25 15:14:30.224542
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # test basic usage

    pattern = NodePattern(type=token.NAME)
    nodes = [
        Leaf(token.NAME, "a", prefix="",),
        Leaf(token.NAME, "b", prefix="",),
        Leaf(token.NAME, "c", prefix="",),
        Leaf(token.NAME, "d", prefix="",),
    ]
    assert pattern.match_seq(nodes) == False
    pattern = NodePattern(type=token.NAME)
    nodes = [
        Leaf(token.NAME, "a", prefix="",),
        Leaf(token.NAME, "b", prefix="",),
        Leaf(token.NAME, "c", prefix="",),
        Leaf(token.NAME, "d", prefix="",),
        Leaf(token.NAME, "e", prefix="",),
    ]

# Generated at 2022-06-25 15:14:31.774146
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    node_pattern_0 = NodePattern()
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_0.optimize()



# Generated at 2022-06-25 15:14:32.886876
# Unit test for method replace of class Base
def test_Base_replace():
    assert False # Stub


# Generated at 2022-06-25 15:14:41.536240
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import pytree
    from .pgen2 import token

    class X:
        pass
    x = X()


# Generated at 2022-06-25 15:14:47.797110
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    assert node_pattern_0.__eq__(node_pattern_1) is NotImplemented
    try:
        node_pattern_0.__eq__(node_pattern_1)
    except:
        assert False


# Generated at 2022-06-25 15:14:51.547281
# Unit test for function type_repr
def test_type_repr():
    type_repr(1)
    type_repr(2)
    type_repr(3)
    from .pygram import python_symbols
    type_repr(python_symbols.single_input)
    type_repr(python_symbols.eval_input)


# Generated at 2022-06-25 15:15:01.020946
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_matches(['listcomp_as'])
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_matches(['test_test', 'Mul', 'expr_context', 'test_test', 'VarargsList', 'test_test'])
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_matches([[]])
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_matches(['star_expr', 'comp_for'])
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_matches([])
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_mat

# Generated at 2022-06-25 15:15:07.547070
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    node_0 = Node(type=0, children=0)
    # Assertion fails because the assertion condition is false
    # assert node_0.get_lineno() == None, "Expected type None but got type " + str(type(node_0.get_lineno()))

    node_1 = Node(type=0, children=[Leaf(type=0, value='foo')])
    # Assertion fails because the assertion condition is false
    # assert node_1.get_lineno() == 0, "Expected type int but got type " + str(type(node_1.get_lineno()))

    node_2 = Node(type=0, children=[Node(type=0, children=[Leaf(type=0, value='foo')])])
    # Assertion fails because the assertion condition is false
    # assert

# Generated at 2022-06-25 15:15:12.799288
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    node_pattern_0 = NodePattern()
    node_pattern_0.type = 0
    node_pattern_0.content = 0
    node_pattern_0.name = '0'
    node_pattern_0_optimize = node_pattern_0.optimize()
    assert node_pattern_0 == node_pattern_0_optimize


# Generated at 2022-06-25 15:15:23.083448
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Node, Leaf
    from .pygram import python_symbols
    tp = Node(type=python_symbols.funcdef, children=[Leaf(type=1, value=u"def")])
    assert list(tp.leaves()) == [Leaf(type=1, value=u"def")]

# Generated at 2022-06-25 15:15:45.287370
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    """Unit test for method get_lineno of class Base"""
    node_pattern_0 = NodePattern()
    dummy = '''def roman_to_decimal(roman_input):
    literal_values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    output = 0
    prev = 0
    for char in reversed(roman_input):
        curr = literal_values[char]
        if curr < prev:
            output -= curr
        else:
            output += curr
        prev = curr
    return output'''
    if (node_pattern_0.type == python_symbols.funcdef):
        func_name_0 = ""
        arg_list_0 = []

# Generated at 2022-06-25 15:15:50.783240
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_pre_order = Base()
    test_pattern = NodePattern()
    class NodePattern(object):
        """pattern matching on abstract syntax trees"""
        def __init__(self):
            self._cache = {}  # key: (pattern, grammar, index); value: NodePattern instance

    test_case = (test_pattern, base_pre_order)
    if test_case == 0:
        assert False
    else:
        assert True


# Generated at 2022-06-25 15:15:57.866102
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # 1
    node_pattern_1 = NodePattern()
    assert node_pattern_1.type == None
    assert node_pattern_1.content == None
    assert node_pattern_1.name == None
    assert node_pattern_1.wildcards == False
    # 2
    node_pattern_2 = NodePattern(256)
    assert node_pattern_2.type == 256
    assert node_pattern_2.content == None
    assert node_pattern_2.name == None
    assert node_pattern_2.wildcards == False
    # 3
    node_pattern_3 = NodePattern(256, 'a', 'name')
    assert node_pattern_3.type == 256
    assert node_pattern_3.content == 'a'
    assert node_pattern_3.name == 'name'
    assert node_pattern_

# Generated at 2022-06-25 15:16:02.018979
# Unit test for function type_repr
def test_type_repr():
    print("test_type_repr")
    assert type_repr(1) == 'NAME'
    assert type_repr(2) == 2
    test_case_0()
    test_visit()
    test_visit_or_as_class()
    test_extract_node_text()
    test_parse_string()


# Generated at 2022-06-25 15:16:04.106443
# Unit test for method post_order of class Base
def test_Base_post_order():
    root = Base()
    test_case = [root]
    assert sorted(root.post_order()) == sorted(test_case)


# Generated at 2022-06-25 15:16:06.670969
# Unit test for method depth of class Base
def test_Base_depth():
    node_pattern_0 = NodePattern()
    with pytest.raises(NotImplementedError):
        node_pattern_0.depth(self)


# Generated at 2022-06-25 15:16:09.023940
# Unit test for method replace of class Base
def test_Base_replace():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    NodePattern.replace(node_pattern_0, node_pattern_1)
    print("Test successful!")


# Generated at 2022-06-25 15:16:14.919053
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    node_pattern_1 = NodePattern()

    result_1 = node_pattern_1._submatch()
    assert result_1 == None

    result_2 = node_pattern_1._submatch()
    assert result_2 == None

    result_3 = node_pattern_1._submatch()
    assert result_3 == None

    result_4 = node_pattern_1._submatch()
    assert result_4 == None

    result_5 = node_pattern_1._submatch()
    assert result_5 == None



# Generated at 2022-06-25 15:16:24.720236
# Unit test for method clone of class Base
def test_Base_clone():
    test_node = Node(None, None, None)
    test_node.changed()
    test_clone_node = test_node.clone()
    assert test_clone_node is not test_node
    # test_clone_node.parent == test_node
    # test_clone_node.parent == None
    # assert test_clone_node.children != test_node.children
    # assert test_clone_node.was_changed == test_node.was_changed
    # assert test_clone_node.was_checked == test_node.was_checked


# Generated at 2022-06-25 15:16:28.221819
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    node_pattern_0 = NodePattern()
    wildcard_pattern_0 = WildcardPattern()
    negated_pattern_0 = NegatedPattern(wildcard_pattern_0)
    for c, r in negated_pattern_0.generate_matches([node_pattern_0]):
        print(c)
    return


# Generated at 2022-06-25 15:17:53.204587
# Unit test for method post_order of class Base
def test_Base_post_order():
    node_pattern_1 = NodePattern()
    assert not node_pattern_1.match(node_pattern_1)
    node_pattern_2 = NodePattern()
    assert not node_pattern_2.match(node_pattern_1)


# Generated at 2022-06-25 15:17:59.072576
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    test_code_0 = """
        node = Node(symbol.power,
                    [Leaf(token.NAME, '2'),
                     Leaf(token.NAME, '**'),
                     Leaf(token.NAME, '3')])
    """
    node_pattern_0 = NodePattern()
    for node in node_pattern_0.pre_order():
        pass
    # Should raise NotImplementedError
    node_pattern_0.clone()
    node_pattern_1 = NodePattern()
    for node in node_pattern_1.post_order():
        pass
    node_pattern_1.clone()


# Generated at 2022-06-25 15:18:09.715955
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_pattern_0 = NodePattern()

    n = Node(syms.node, [Leaf(0)])
    assert n.type == syms.node
    assert n.parent is None
    assert n.changed() is None
    assert n.next_sibling is None
    assert n.prev_sibling is None
    assert n.fixers_applied is None
    assert n.used_names is None
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None

    assert n.post_order() is not None
    assert n.pre_order() is not None
    assert n.leaves() is not None
    assert n.depth() == 1
    assert n.get_suffix() == ""

    assert n.get_lineno() is not None
    assert n

# Generated at 2022-06-25 15:18:14.219023
# Unit test for method remove of class Base
def test_Base_remove():
    # Initializing the object
    first_node = Node(type=10)
    parent = Node()
    parent.children = [first_node]
    first_node.parent = parent
    # Calling the method
    first_node.remove()
    # Asserting the results
    assert first_node.parent == None


# Generated at 2022-06-25 15:18:17.897235
# Unit test for method replace of class Base
def test_Base_replace():
    node = Node()
    node2 = Node()
    leaf = Leaf()
    leaf2 = Leaf()
    node.replace(node2)
    node.replace(leaf)
    node.replace(leaf2)
    node.replace([node2, leaf])
    node.replace([node, leaf2])


# Generated at 2022-06-25 15:18:24.199757
# Unit test for method clone of class Base
def test_Base_clone():
    f = file('samples/tree.typed.py', 'r')
    st = list(f)
    print(st)
    f.close()
    grammar = Grammar()
    st = grammar.parse(st)
    print(st)
    st = Node(python_symbols.file_input, st)
    # st = Node(python_symbols.file_input, [Leaf(1, 'print')])
    print(st)
    st_clone = st.clone()
    print(st_clone)
    print(st == st_clone)
    print(st is st_clone)
 


# Generated at 2022-06-25 15:18:33.351184
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    NodePattern().generate_matches([])
    NodePattern().generate_matches([1])
    NodePattern().generate_matches([1, 2])
    NodePattern().generate_matches(["a", 2])
    NodePattern().generate_matches([Node(1, [], 1)])
    NodePattern().generate_matches([Node(1, [], 1), 2])
    NodePattern().generate_matches([Node(1, [], 1), Node(2, [], 2)])
    NodePattern().generate_matches(
        [Node(NodePattern(), [], None), Node(NodePattern(), [], None), Node(NodePattern(), [], None)]
    )

# Generated at 2022-06-25 15:18:34.881166
# Unit test for method post_order of class Base
def test_Base_post_order():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    pass


# Generated at 2022-06-25 15:18:40.460504
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wildcard_pattern_0 = WildcardPattern(None, 0, 1, None)
    node_pattern_0 = NodePattern(None, None, None)
    node_pattern_0_copy = node_pattern_0.optimize()
    assert type(wildcard_pattern_0.optimize()) == type(node_pattern_0_copy), "optimize failed"
    

# Generated at 2022-06-25 15:18:43.959201
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_0 = Node(0, None)
    node_pattern_0 = NodePattern(NodeType(0))
    assert node_pattern_0.match(node_0)
