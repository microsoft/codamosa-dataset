

# Generated at 2022-06-25 15:13:08.985255
# Unit test for method replace of class Base
def test_Base_replace():
    node = NegatedPattern()
    l_children = [None]

    node.replace(l_children)
    assert node.children == l_children


# Generated at 2022-06-25 15:13:17.662727
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    pattern1 = WildcardPattern([[Leaf(1)], [Leaf(2)]], 1, 2)
    node1 = Leaf(1)
    node2 = Leaf(2)
    node3 = Leaf(3)
    node4 = Leaf(4)
    # test 1
    nodes = [node1, node2]
    matches = []
    for count, results in pattern1.generate_matches(nodes):
        matches.append((count, results))
    assert matches == [(1, {})] # this assumption will fail
    matches = []
    # test 2
    nodes = [node1, node2, node3]
    for count, results in pattern1.generate_matches(nodes):
        matches.append((count, results))
    assert matches == [(2, {})] # this assumption will fail

# Generated at 2022-06-25 15:13:25.001398
# Unit test for method post_order of class Node
def test_Node_post_order():
    n = Node(0, [Leaf(1, 'foo'), Leaf(2, 'bar'), Node(3, [])])
    assert list(n.post_order()) == [Leaf(1, 'foo'), Leaf(2, 'bar'),
                                    Node(3, []), Node(0, [Leaf(1, 'foo'), Leaf(2, 'bar'), Node(3, [])])]


# Generated at 2022-06-25 15:13:27.121129
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    r"""Test Case: 
    Returns a canonical string representation."""
    BasePattern.__repr__()


# Generated at 2022-06-25 15:13:38.796888
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    pattern_0 = LeafPattern(type=1)
    nodes_0 = []
    b = pattern_0.match_seq(nodes_0)
    assert b == False
    pattern_0 = LeafPattern(type=1)
    nodes_0 = [Leaf(1, '')]
    b = pattern_0.match_seq(nodes_0)
    assert b == True
    pattern_0 = LeafPattern(type=1)
    nodes_0 = [Leaf(1, ''), Leaf(1, '')]
    b = pattern_0.match_seq(nodes_0)
    assert b == False
    pattern_0 = LeafPattern(type=1)
    nodes_0 = [Leaf(1, ''), Leaf(2, '')]
    b = pattern_0.match_seq(nodes_0)


# Generated at 2022-06-25 15:13:46.560178
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # Test for valid parent and child nodes
    parent_node = Node('parent_node', None, None, None, None, None,
        None, parent=None)
    child_node = Node('child_node', 'somewords', None, None, None,
            None, None, parent=parent_node)
    assert parent_node.get_lineno() == None
    assert child_node.get_lineno() == None
    assert parent_node.get_lineno() == None
    assert child_node.get_lineno() == None

    # Test for no children
    no_children = Node('no_children', None, None, None, None, None,
            None, parent=parent_node)
    assert no_children.get_lineno() == None
    assert parent_node.get_lineno() == None

   

# Generated at 2022-06-25 15:13:48.886515
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # optimization of empty pattern
    pattern_0 = BasePattern()
    assert pattern_0 is pattern_0.optimize()



# Generated at 2022-06-25 15:13:52.327305
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(11) == 11
    assert type_repr(1001) == 1001

# ______________________________________________________________________
# Parsing


# Generated at 2022-06-25 15:14:03.569904
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    if Base.get_lineno() is None:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass
    if Base.get_lineno() == 5:
        pass

# Generated at 2022-06-25 15:14:10.219329
# Unit test for method remove of class Base
def test_Base_remove():
    node_0 = Base()
    node_0.parent = Node(0, None, None, [Leaf(1, "a", (1, 1), None), Leaf(2, "b", (1, 1), None), Leaf(3, "c", (1, 1), None)])
    node_0.type = 0
    node_0.children = []
    node_0.was_changed = False
    node_0.was_checked = False
    assert node_0.remove() == 2
    assert node_0.parent.children[-1].value == 'b'
    assert node_0.parent.next_sibling_map[id(node_0.parent.children[-1])] is None


# Generated at 2022-06-25 15:14:47.476975
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # There is no test for this method, because it is not
    # used by any other method in the file.
    pass


# Generated at 2022-06-25 15:14:48.748519
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # Verify the type of the return variable
    assert isinstance(Leaf.pre_order(Leaf(0, 'asdf')), Iterator)


# Generated at 2022-06-25 15:14:50.817460
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Tests for BasePattern.optimize
    BASE_PATTERN_0 = BasePattern()  # This should fail


# Generated at 2022-06-25 15:15:00.424352
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.pgen import BasePattern
    from .pgen2.pgen import LeafPattern
    from .pgen2.pgen import NodePattern
    from .pgen2.pgen import Pattern
    from .pgen2.pgen import WildcardPattern
    from .pgen2.pgen import OrPattern
    from .pgen2.pgen import AndPattern
    from .pgen2.pgen import OptionalPattern
    from .pgen2.pgen import NegatedPattern

    assert BasePattern().optimize() == BasePattern()
    assert LeafPattern(1).optimize() == LeafPattern(1)
    assert NodePattern(1).optimize() == NodePattern(1)
    assert WildcardPattern(1).optimize() == WildcardPattern(1)

# Generated at 2022-06-25 15:15:03.210572
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Test for method __repr__ of class BasePattern"""
    # test_case_0
    negated_pattern_0 = NegatedPattern()
    assert negated_pattern_0.__repr__() == 'NegatedPattern()'


# Generated at 2022-06-25 15:15:04.890374
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_case = Base()
    assert test_case.get_suffix() == ""



# Generated at 2022-06-25 15:15:08.050457
# Unit test for method replace of class Base
def test_Base_replace():
    leaf_0 = Leaf()
    leaf_1 = Leaf()
    node_0 = Node()
    node_0.children = [leaf_0, leaf_1]
    leaf_0.replace(node_0)


# Generated at 2022-06-25 15:15:11.762583
# Unit test for method clone of class Node
def test_Node_clone():
    import pytree
    a = pytree.Node(1, [])
    b = a.clone()
    assert a != b
    assert a.type == b.type
    assert a.children == b.children
    assert a.parent == b.parent


# Generated at 2022-06-25 15:15:13.084693
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    test_case_0()


# Generated at 2022-06-25 15:15:15.338460
# Unit test for constructor of class NodePattern
def test_NodePattern():
    try:
        NodePattern()
    except TypeError:
        pass


# Generated at 2022-06-25 15:16:02.084229
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    root = Node(0, [Leaf(1, "a"), Leaf(2, "b")])
    pattern_1 = NodePattern(type=0, children=[NodePattern(type=1), NodePattern(type=2)])
    pattern_2 = NodePattern(type=0, children=[NodePattern(type=1), NodePattern(type=2)])
    results_1 = {}
    result_1 = pattern_2.match(node=root, results=results_1)
    assert result_1 == pattern_1.match(node=root, results=results_1)


# Generated at 2022-06-25 15:16:10.472726
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # TODO: care about subpatterns
    pattern = NegatedPattern()

# Generated at 2022-06-25 15:16:11.777296
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    BasePattern.generate_matches()


# Generated at 2022-06-25 15:16:15.883178
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    negated_pattern_0 = NegatedPattern()
    assert negated_pattern_0.get_suffix() == ""


# Generated at 2022-06-25 15:16:22.754298
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.div_op) == "div_op"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"


# Generated at 2022-06-25 15:16:25.337703
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    node_1 = Base()
    sib_1 = Leaf()
    node_1.next_sibling = sib_1
    sib_1.prefix = "pass"
    assert node_1.get_suffix() == "pass"


# Generated at 2022-06-25 15:16:28.864129
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    n = Node(0, [])
    p = BasePattern()
    assert not p.match(n)

    p2 = BasePattern()
    p2.type = 0
    assert p2.match(n)


# Generated at 2022-06-25 15:16:29.759991
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    raise NotImplementedError()

# Generated at 2022-06-25 15:16:32.976258
# Unit test for method remove of class Base
def test_Base_remove():
    b = Base()
    assert b.remove() == None
    assert b.parent == None


# Generated at 2022-06-25 15:16:37.697408
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(0, [Leaf(0, "")])
    child = Leaf(0, "")
    node.set_child(0, child)
    assert node.children[0] is child


# Generated at 2022-06-25 15:16:48.754135
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern_0 = WildcardPattern(min=1, max=1, content=[[NodePattern()]])
    pattern_0 = pattern_0.optimize()
    assert isinstance(pattern_0, NodePattern)


# Generated at 2022-06-25 15:16:57.918034
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pattern_0 = WildcardPattern([NodePattern(type=256), NodePattern(type=257)], 1, 2)
    pattern_0 = WildcardPattern([NodePattern(type=256), NodePattern(type=257), NodePattern(type=258)], 1, 2)
    pattern_0 = WildcardPattern([NodePattern(type=256), NodePattern(type=257), NodePattern(type=259)], 1, 2)
    pattern_0 = WildcardPattern([NodePattern(type=256), NodePattern(type=258), NodePattern(type=259)], 1, 2)
    pattern_0 = WildcardPattern([NodePattern(type=257), NodePattern(type=258), NodePattern(type=259)], 1, 2)

# Generated at 2022-06-25 15:16:58.939117
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_case_0()


# Generated at 2022-06-25 15:17:08.450033
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    print('Testing generate_matches of NegatedPattern...')
    # Test without content
    negated_pattern_0 = NegatedPattern()
    assert negated_pattern_0.generate_matches(['a'])!=(0,{})
    assert negated_pattern_0.generate_matches([])==(0,{})
    # Test with content
    leaf_pattern_0 = LeafPattern()
    negated_pattern_0 = NegatedPattern(leaf_pattern_0)
    assert negated_pattern_0.generate_matches(['a'])==(0,{}) 
    assert negated_pattern_0.generate_matches([])!=(0,{})
    print('Done.')


# Generated at 2022-06-25 15:17:16.515479
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    pos0 = Forward()
    pos1 = Forward()
    pos0 << Group(pos1 << Lazy(lambda: Node(1, [])))
    pos0 <<= Node(2, [Leaf(3, "c"), Leaf(4, "d"), pos0])
    start_rule = pos0
    end_rule = pos0
    grammar = Grammar(start_rule, end_rule, {})
    pos0_tokens = [
        (0, Leaf(1, "a")),
        (0, Leaf(2, "b")),
        (0, Leaf(3, "c")),
        (0, Leaf(4, "d")),
        (0, pos1),
    ]

# Generated at 2022-06-25 15:17:18.215894
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    assert Base.__eq__(Base(), Base()) == NotImplemented


# Generated at 2022-06-25 15:17:21.639806
# Unit test for method replace of class Base
def test_Base_replace():
    negated_pattern_1 = NegatedPattern()
    replacement_1 = []
    negated_pattern_1.replace(replacement_1)


# Generated at 2022-06-25 15:17:31.406369
# Unit test for function type_repr
def test_type_repr():
    test_cases = [
        (-1, -1),
        (0, "EMPTY"),
        (1, "NEWLINE"),
        (2, "INDENT"),
        (3, "DEDENT"),
        (4, "ENDMARKER"),
        (5, "NAME"),
        (6, "NUMBER"),
        (7, "STRING"),
        (8, "ASYNC"),
        (9, "AWAIT"),
    ]
    for type_num, expected_value in test_cases:
        assert type_repr(type_num) == expected_value


REPR_INDENT = ""  # indentation and whether we're copying

# Nodes

# Generated at 2022-06-25 15:17:36.336309
# Unit test for method clone of class Base
def test_Base_clone():
    """assert Base.clone() is abstract"""
    test_case = Base()
    try:
        test_case.clone()
    except NotImplementedError:
        pass
    else:
        assert False, "Base.clone() should be abstract"

from blib2to3.fixes.fix_next import FixNext


# Generated at 2022-06-25 15:17:42.341969
# Unit test for method post_order of class Base
def test_Base_post_order():
    root_0 = Node()
    root_1 = Node()
    root_0.parent = root_1
    next_sibling_1 = root_1.next_sibling
    root_0.next_sibling = next_sibling_1
    prev_sibling_1 = root_1.prev_sibling
    root_0.prev_sibling = prev_sibling_1
    post_order_0 = root_1.post_order()


# Generated at 2022-06-25 15:17:56.636909
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    BasePattern_gen0 = WildcardPattern()
    BasePattern_gen0.type = 256
    BasePattern_gen0.content = None
    BasePattern_gen0.name = None
    BasePattern_gen1 = WildcardPattern()
    BasePattern_gen1.type = 256
    BasePattern_gen1.content = None
    BasePattern_gen1.name = None
    BasePattern_gen2 = WildcardPattern()
    BasePattern_gen2.type = 256
    BasePattern_gen2.content = None
    BasePattern_gen2.name = None


# Generated at 2022-06-25 15:18:06.948839
# Unit test for method replace of class Base
def test_Base_replace():
    root_0 = Node(python_symbols.file_input, [])
    leaf_0 = Leaf(6, "def", (1,0))
    leaf_1 = Leaf(0, " ", (1,4))
    node_0 = Node(python_symbols.funcdef, [leaf_0, leaf_1])
    root_0.children.append(node_0)
    leaf_2 = Leaf(0, "\n", (1,5))
    root_0.children.append(leaf_2)
    root_0.changed()
    root_0.invalidate_sibling_maps()
    #assert root_0.parent is None
    def test_case_0():
        node_0.replace(None)
    test_case_0()



# Generated at 2022-06-25 15:18:09.843395
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    x = BasePattern()
    node = Node(0, [])
    results = {}
    result = x.match(node, results)
    assert result



# Generated at 2022-06-25 15:18:19.134068
# Unit test for method leaves of class Base
def test_Base_leaves():
    pattern = Base()
    if 5 == pattern.leaves():
        pattern = Base()
        if 5 == pattern.leaves():
            pattern = Base()
            if 5 == pattern.leaves():
                pattern = Base()
                if 5 == pattern.leaves():
                    pattern = Base()
                    if 5 == pattern.leaves():
                        pattern = Base()
                        if 5 == pattern.leaves():
                            pattern = Base()
                            if 5 == pattern.leaves():
                                pattern = Base()
                                if 5 == pattern.leaves():
                                    pattern = Base()
                                    if 5 == pattern.leaves():
                                        pattern = Base()
                                        if 5 == pattern.leaves():
                                            pattern = Base()
                                            if 5 == pattern.leaves():
                                                pattern = Base()
                                               

# Generated at 2022-06-25 15:18:21.802323
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_0 = Base()
    base_1 = Base()
    if base_0 == base_1:
        print("True")
    else:
        print("False")


# Generated at 2022-06-25 15:18:29.629726
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pattern = WildcardPattern()
    nodes = extract("foo bar spam eggs")
    if not pattern.match_seq(nodes):
        print("test_WildcardPattern_match_seq exit 1")
        sys.exit(1)
    nodes = extract("foo")
    if not pattern.match_seq(nodes):
        print("test_WildcardPattern_match_seq exit 2")
        sys.exit(2)
    nodes = extract(" ")
    if not pattern.match_seq(nodes):
        print("test_WildcardPattern_match_seq exit 3")
        sys.exit(3)
    nodes = extract("")
    if not pattern.match_seq(nodes):
        print("test_WildcardPattern_match_seq exit 4")
        sys.exit(4)

# Generated at 2022-06-25 15:18:32.846340
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    # Tested method: leaves
    # Tested method: __init__
    leaf_0 = Leaf(0, "")
    for leaf in leaf_0.leaves():
        pass


# Generated at 2022-06-25 15:18:42.728678
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    pattern_0 = Base()
    pattern_1 = Base()
    pattern_2 = Base()
    pattern_3 = Base()
    pattern_4 = Base()
    pattern_5 = Base()
    pattern_6 = Base()
    pattern_7 = Base()
    pattern_8 = Base()
    pattern_9 = Base()
    pattern_10 = Base()
    pattern_11 = Base()
    pattern_12 = Base()
    pattern_13 = Base()
    pattern_14 = Base()
    pattern_15 = Base()
    pattern_16 = Base()
    pattern_17 = Base()
    pattern_18 = Base()
    pattern_19 = Base()
    pattern_20 = Base()
    pattern_21 = Base()
    pattern_22 = Base()
    pattern_23 = Base()
    pattern_24 = Base()

# Generated at 2022-06-25 15:18:51.921828
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    bp = BasePattern()
    bp.content = None
    bp.type = 1
    bp.name = None
    r = {}
    assert bp.generate_matches(['hello']) == [(1, {})]
    bp.content = None
    bp.type = 208
    bp.name = 'classdef_test'
    assert bp.generate_matches([208]) == [(1, {'classdef_test': 208})]
    bp.content = None
    bp.type = 'kwarg'
    bp.name = None
    assert bp.generate_matches([]) == []
    bp.content = 'hello'
    bp.type = None
    bp.name = None

# Generated at 2022-06-25 15:18:53.400955
# Unit test for method replace of class Base
def test_Base_replace():
    test_Base = Base()
    test_Base.replace(None)


# Generated at 2022-06-25 15:19:19.080061
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    node_0 = _0 = Base()
    assert _0.get_suffix() == ""
    node_1 = _1 = Base()
    node_0.next_sibling = node_1
    node_1.prefix = "node_1"
    assert _0.get_suffix() == "node_1"
    node_1.prefix = ""
    assert _0.get_suffix() == ""
    node_0.next_sibling = None
    assert _0.get_suffix() == ""
    return


# Generated at 2022-06-25 15:19:26.960517
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    negated_pattern_0 = NegatedPattern()
    pattern_0 = Leaf(negated_pattern_0.args[0], "foo")
    leaf_0 = Leaf(negated_pattern_0.args[1], "bar")
    leaf_1 = Leaf(negated_pattern_0.args[2], "baz")
    node_2 = Node(299, None, [leaf_0, leaf_1])
    node_0 = Node(negated_pattern_0.symbol, "", [pattern_0, node_2])
    expected = "baz"
    actual = node_0.get_suffix()
    assert actual == expected


# Generated at 2022-06-25 15:19:30.416960
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # This is a side effect free port of the test_generate_matches
    # unit test for the wildcard module.
    pattern = WildcardPattern()
    for i in range(4):
        for expected, input in ((0, ""), (1, "a"), (1, "b"), (2, "ab")):
            assert list(pattern.generate_matches(input)) == [(expected, {})]

# Generated at 2022-06-25 15:19:32.496013
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    print("pre_order")
    negated_pattern_0 = NegatedPattern()
    assert_equal(negated_pattern_0.pre_order, None)


# Generated at 2022-06-25 15:19:33.607896
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    n = NegatedPattern()
    n.get_suffix()


# Generated at 2022-06-25 15:19:44.602518
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    negated_pattern_0 = NegatedPattern()
    leaf_pattern_0 = LeafPattern()
    node_pattern_0 = NodePattern()
    wildcard_pattern_0 = WildcardPattern()
    spec_0 = LeafPattern()
    spec_1 = NodePattern()
    spec_2 = WildcardPattern()

    assert not negated_pattern_0.match(leaf_pattern_0)
    assert not negated_pattern_0.match(node_pattern_0)
    assert not negated_pattern_0.match(wildcard_pattern_0)
    assert not negated_pattern_0.match(spec_0)
    assert not negated_pattern_0.match(spec_1)
    assert not negated_pattern_0.match(spec_2)


# Generated at 2022-06-25 15:19:54.885438
# Unit test for function generate_matches
def test_generate_matches():
    # Test case 1
    pattern_0 = NegatedPattern()
    list_0 = [NegatedPattern()]
    list_1 = []
    result = generate_matches(list_0, list_1)
    assert result == [(0, {})]
    # Test case 2
    pattern_1 = SkippedWhitespacePattern()
    pattern_2 = TextPattern('test')
    pattern_3 = SkippedWhitespacePattern()
    list_0 = [pattern_1, pattern_2, pattern_3]
    list_1 = [SkippedWhitespacePattern(), TextPattern('test'), SkippedWhitespacePattern()]
    result = generate_matches(list_0, list_1)
    assert result == [(3, {})]
    # Test case 3
    pattern_1 = TextPattern('test')
    list_0

# Generated at 2022-06-25 15:20:01.200235
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Test case 0
    # Method get_suffix of class Base
    #
    # test.py:145: error: Method body missing
    #         :                                                                      ^

    # Tests for method get_suffix of class Base
    # test.py:154: error: Method body missing
    #         :                                                                      ^
    # test.py:157: error: Method body missing
    #         :                                                                      ^
    # test.py:160: error: Method body missing
    #         :                                                                      ^
    # test.py:164: error: Method body missing
    #         :                                                                      ^
    test_case_0()



# Generated at 2022-06-25 15:20:04.768226
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    test_obj_0 = Node(256, [])
    assert list(test_obj_0.pre_order()) == [test_obj_0,]


# Generated at 2022-06-25 15:20:07.541495
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    negated_pattern_0 = NegatedPattern()
    nodes_0 = []
    assert not list(negated_pattern_0.generate_matches(nodes_0))



# Generated at 2022-06-25 15:20:44.094323
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    negated_pattern_0 = NegatedPattern()
    assert repr(negated_pattern_0) == "NegatedPattern(<negated>)", repr(negated_pattern_0)


# Generated at 2022-06-25 15:20:46.247740
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    negated_pattern_0 = NegatedPattern()
    negated_pattern_0.get_suffix()


# Generated at 2022-06-25 15:20:48.563525
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    t_0 = Leaf(1, "abc")
    t_1 = t_0.pre_order()
    t_2 = t_1.__next__()
    assert t_2 == t_0
    t_3 = t_1.__next__()
    raise AssertionError("No exception was raised.")

# Generated at 2022-06-25 15:20:55.378504
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    '''
    # _P is not used in the function.
    negated_pattern_0 = NegatedPattern()
    next_sibling_0 = negated_pattern_0.next_sibling
    prefix_0 = next_sibling_0.prefix
    print(prefix_0)
    suffix_0 = negated_pattern_0.get_suffix()
    assert suffix_0 == prefix_0
    '''
    class Node_0(Base):
        def __init__(self):
            self.parent = None
            self.children = []
            self.type = 1
            self.prefix = "word"
    node_0 = Node_0()
    # The function get_suffix belongs to class Base and it is not overriden in
    # class Node_0. Thus, the behavior of get_suffix should

# Generated at 2022-06-25 15:21:03.735228
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Create a new node
    x = Node(1, None)
    # Set the children of x
    assert isinstance(x.children, list)
    x.children.append(Leaf(2, None))
    # Create a new node and set it as child of x
    child = Node(3, None)
    child.children.append(Leaf(4, None))
    child.children.append(Leaf(5, None))
    x.children.append(child)
    # Create a new node and set it as child of x
    child = Node(6, None)
    child.children.append(Leaf(7, None))
    x.children.append(child)
    # Assert that post_order will find nodes in correct order
    nodes = []

# Generated at 2022-06-25 15:21:09.909953
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Create the following node:
    # (n1 (n2 (n3 "leafA") "leafB") "leafC")
    n3 = Node(0, [Leaf(1, "leafA")])
    n3.changed()
    n2 = Node(0, [n3, Leaf(1, "leafB")])
    n2.changed()
    n1 = Node(0, [n2, Leaf(1, "leafC")])
    n1.changed()

    # Check that the post-order iterator works (it yields all leaves first,
    # then all nodes).
    post_order_leaves = [leaf for leaf in n1.post_order() if isinstance(leaf, Leaf)]
    post_order_nodes = [node for node in n1.post_order() if isinstance(node, Node)]

# Generated at 2022-06-25 15:21:16.231828
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    negated_pattern_0 = NegatedPattern()
    nodes_0 = (Leaf(1, ''), Leaf(1, ''), Leaf(1, ''))
    result_0 = negated_pattern_0.generate_matches(nodes_0)
    assert isinstance(result_0, Iterator)



# Generated at 2022-06-25 15:21:28.379320
# Unit test for method replace of class Base
def test_Base_replace():
    negated_pattern_1 = NegatedPattern()
    assert(negated_pattern_1.parent == None)
    assert(negated_pattern_1.children == [])
    assert(negated_pattern_1.was_changed == False)
    assert(negated_pattern_1.was_checked == False)
    assert(negated_pattern_1.prefix == "")

    classes_0 = Node(591, None, None, [])
    assert(classes_0.parent == None)
    assert(classes_0.children == [])
    assert(classes_0.was_changed == False)
    assert(classes_0.was_checked == False)
    assert(classes_0.prefix == "")

    assert(negated_pattern_1.replace(classes_0) == None)

# Generated at 2022-06-25 15:21:32.069438
# Unit test for method depth of class Base
def test_Base_depth():
    node0 = Base()
    node1 = Base()
    # assert depth == 0
    assert node0.depth() == 0
    # assert depth == 1
    node1.parent = node0
    assert node1.depth() == 1


# Generated at 2022-06-25 15:21:35.527581
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    negated_pattern_0 = NegatedPattern()
    negated_pattern_0._eq(negated_pattern_0)

