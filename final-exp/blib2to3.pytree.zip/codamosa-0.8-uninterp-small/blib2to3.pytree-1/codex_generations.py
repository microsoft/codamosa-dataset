

# Generated at 2022-06-25 15:12:34.657850
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    for x in Leaf(1, 'abc').pre_order():
        print(x)


# Generated at 2022-06-25 15:12:35.519847
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_case_0()



# Generated at 2022-06-25 15:12:39.760661
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    # this should not fail
    base_pattern_0 = BasePattern()
    nodes = [NL(token.NAME, "ast", None, [])]
    for i, results in base_pattern_0.generate_matches(nodes):
        print(i, results)


# Generated at 2022-06-25 15:12:41.659546
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_pattern_1 = BasePattern()
    raise Exception("Missing test case for method optimize of class BasePattern")


# Generated at 2022-06-25 15:12:45.565961
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    node_0 = Node(256, [Leaf(0, "")])
    node_1 = Node(256, [Leaf(0, "")])
    node_0.insert_child(0, node_1)

test_case_0()
test_Node_insert_child()


# Generated at 2022-06-25 15:12:53.083125
# Unit test for method remove of class Base
def test_Base_remove():
    test_case = [None]
    def test_callback():
        test_case[0] = True

    class FakeParent(object):
        def __init__(self):
            self.children = [
                1,
                2,
                FakeChild(FakeParent()),
                3,
                FakeChild(None),
            ]
        def changed(self):
            test_callback()

    class FakeChild(Base):
        def __init__(self, parent):
            self.parent = parent
        def _eq(self, other):
            return NotImplemented
        def clone(self):
            return NotImplemented
        def post_order(self):
            return NotImplemented
        def pre_order(self):
            return NotImplemented

    parent = FakeParent()
    child = FakeChild(parent)


# Generated at 2022-06-25 15:12:59.596484
# Unit test for method replace of class Base
def test_Base_replace():
    base_pattern_0 = BasePattern()
    node_0 = Node(0, (), (), [])
    node_0.parent = base_pattern_0
    base_pattern_0.children = [node_0]
    new_0 = [Node(0, (), (), [])]
    base_pattern_0.replace(new_0)



# Generated at 2022-06-25 15:13:09.458270
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from .tokens import NUMBER
    from .parseengine import Parser, ParserElement

    pat_0 =  WildcardPattern([])
    pat_1 =  WildcardPattern([[Leaf(1, '1')]], 0, 1)
    pat_2 =  WildcardPattern([[Leaf(1, '1')]], 0, 1, 'bare_name')
    pat_3 =  WildcardPattern([[Leaf(1, '1')]], 0, 1, 'bare_name')
    pat_4 =  WildcardPattern([[Leaf(1, '1')]], 0, 1, 'bare_name')
    pat_5 =  WildcardPattern([[Leaf(1, '1')]], 0, 1, 'bare_name')

# Generated at 2022-06-25 15:13:12.066443
# Unit test for method depth of class Base
def test_Base_depth():
    base_instance  = Base()
    base_depth_ret = base_instance.depth()
    assert(base_depth_ret == 0)


# Generated at 2022-06-25 15:13:14.566899
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():

    # Create an instance of Leaf
    test_Leaf = Leaf(0, "test_Leaf")

    # Invoke method leaves of Leaf
    test_Leaf.leaves()


# Generated at 2022-06-25 15:14:09.479460
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_0 = Node(0, None)
    node_1 = Node(1, None)
    node_2 = Node(2, None)
    node_3 = Node(3, None)
    node_4 = Node(4, None)
    node_5 = Node(5, None)
    node_6 = Node(6, None)
    node_7 = Node(7, None)
    node_8 = Node(8, None)
    node_9 = Node(9, None)
    node_10 = Node(10, None)
    node_11 = Node(11, None)
    node_12 = Node(12, None)
    node_13 = Node(13, None)
    node_14 = Node(14, None)
    node_15 = Node(15, None)

# Generated at 2022-06-25 15:14:16.365201
# Unit test for method leaves of class Base
def test_Base_leaves():
    class TempNode(Base):
        def __init__(self, children):
            self.children = children

    not_a_leaf = TempNode([
        Leaf(1, '1', None, None),
        Leaf(2, '2', None, None)
    ])

    p = not_a_leaf.leaves()
    next(p)
    next(p)
    try:
        next(p)
    except StopIteration:
        pass
    else:
        raise Exception('Test failed')



# Generated at 2022-06-25 15:14:19.338059
# Unit test for method clone of class Base
def test_Base_clone():
    base_pattern_0 = BasePattern()
    new_pattern = base_pattern_0.clone()
    assert isinstance(new_pattern, BasePattern)
    assert base_pattern_0.__repr__() == new_pattern.__repr__()


# Generated at 2022-06-25 15:14:25.470247
# Unit test for method depth of class Base
def test_Base_depth():
    node_a = Leaf(0, "I am a leaf")
    node_b = Leaf(0, "I am a leaf")
    assert node_a.depth() == 0

    parent_node = Node(0, "", [node_a, node_b])

    assert parent_node.depth() == 0
    assert node_a.depth() == 1
    assert node_b.depth() == 1



# Generated at 2022-06-25 15:14:33.483768
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_pattern_0 = BasePattern()
    base_pattern_1 = BasePattern()
    base_pattern_1.types = 0
    base_pattern_1.prefix = ''
    base_pattern_1.lineno = 0
    base_pattern_1.column = 0
    base_pattern_1.changed = lambda: None
    base_pattern_1.clone = lambda: base_pattern_0
    base_pattern_1.post_order = lambda: [base_pattern_0]
    base_pattern_1.pre_order = lambda: [base_pattern_0]
    base_pattern_1.replace = lambda new: None
    base_pattern_1.get_lineno = lambda: base_pattern_1.lineno
    base_pattern_1.get_suffix = lambda: base_pattern_1.prefix
   

# Generated at 2022-06-25 15:14:40.772769
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_pattern_0 = BasePattern()
    depth_0_type = int
    depth_0_value = base_pattern_0.depth()
    assert depth_0_type == int
    assert depth_0_value == 0
    base_pattern_1 = BasePattern()
    base_pattern_2 = BasePattern()
    next_sibling_0_type = BasePattern
    next_sibling_0_value = base_pattern_2.next_sibling
    assert next_sibling_0_type == BasePattern
    assert next_sibling_0_value == None
    next_sibling_1_type = int
    next_sibling_1_value = base_pattern_0.next_sibling
    assert next_sibling_1_type == int
    next_sibling_2_type = BasePattern
   

# Generated at 2022-06-25 15:14:42.339066
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_object = Leaf(1, "Value")
    result = leaf_object.pre_order()
    assert result is not None


# Generated at 2022-06-25 15:14:45.690072
# Unit test for method clone of class Base
def test_Base_clone():
    test_Base = Base()
    test_Base._clone = BasePattern()
    assert(test_Base.clone() == BasePattern)


# Generated at 2022-06-25 15:14:46.930002
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "hi")
    assert list(leaf.post_order())[0] is leaf


# Generated at 2022-06-25 15:14:56.355488
# Unit test for function generate_matches
def test_generate_matches():
    pattern_1 = NodePattern(type = 258)
    pattern_2 = NodePattern(type = 259)
    pattern_3 = NodePattern(type = 260)
    pattern_4 = NodePattern(type = 261)
    pattern_5 = NodePattern(type = 262)
    pattern_6 = NodePattern(type = 263)
    pattern_7 = NodePattern(type = 264)
    pattern_8 = NodePattern(type = 265)
    pattern_9 = NodePattern(type = 266)
    pattern_10 = NodePattern(type = 267)
    pattern_11 = NodePattern(type = 268)
    pattern_12 = NodePattern(type = 269)
    pattern_13 = NodePattern(type = 270)
    pattern_14 = NodePattern(type = 271)
    pattern_15 = NodePattern(type = 272)
    pattern_16

# Generated at 2022-06-25 15:15:12.669326
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    a = _symbol("a")
    b = _symbol("b")
    
    pattern = NegatedPattern(LeafPattern(a))
    nodes = [Node(1, [a, a, b, a]), Node(1, [a, a, b])]
    
    _generate_matches_helper(pattern, nodes)



# Generated at 2022-06-25 15:15:18.470341
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    apattern = BasePattern()
    abase_pattern = BasePattern()
    anode = Node(1, [])
    aList = [anode]
    for b in apattern.generate_matches(aList):
        assert(b[0] == 1)
    for b in abase_pattern.generate_matches(aList):
        assert(b[0] == 1)


# Generated at 2022-06-25 15:15:27.985219
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from docutils.parsers.rst.languages import de
    assert de.labels == {
        "abstract": "abstract",
        "attention": "Attention",
        "caution": "Caution",
        "danger": "Danger",
        "error": "Error",
        "hint": "Hint",
        "important": "Important",
        "note": "Note",
        "tip": "Tip",
        "warning": "Warning",
    }

# Generated at 2022-06-25 15:15:36.575533
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    for iter in range(100):
        # Create a random string whose length is between 0 and 100
        value = ''.join(random.choice(string.ascii_letters + string.digits)
                        for _ in range(random.randint(1, 100)))
        leaf_node = Leaf(random.randint(0, 256), value)
        result = []
        for child in leaf_node.leaves():
            result.append(child)
        if not len(result) == 1:
            return False
        if not result[0] == leaf_node:
            return False
    return True


# Generated at 2022-06-25 15:15:39.667930
# Unit test for method append_child of class Node
def test_Node_append_child():
    children = [Leaf(0, '1'), Leaf(0, '2')]
    node = Node(257, children)
    for i in range(len(children)):
        children[i].parent = node

    child = Leaf(0, '3')
    node.append_child(child)
    assert child in node.children
    assert node == child.parent


# Generated at 2022-06-25 15:15:41.324452
# Unit test for constructor of class NodePattern
def test_NodePattern():
    nodePattern = NodePattern(
        type=257, content=[(LeafPattern(type=1, content='hello'))], name='foo')


# Generated at 2022-06-25 15:15:42.278241
# Unit test for method clone of class Base
def test_Base_clone():
    base_pattern_0 = BasePattern()
    base_pattern_0.clone()


# Generated at 2022-06-25 15:15:45.360350
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_0 = Base()

    try:
        base_0.get_lineno()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 15:15:49.948100
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp_0 = WildcardPattern(min=0, max=0)
    assert isinstance(wp_0, BasePattern)
    assert isinstance(wp_0, WildcardPattern)
    assert isinstance(wp_0, NodePattern)
    assert isinstance(wp_0, LeafPattern)
    assert isinstance(wp_0.optimize(), NodePattern)


# Generated at 2022-06-25 15:15:54.484500
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    'optimize' method of BasePattern always exists and the result has the same 'type'
    """
    base_pattern_3 = BasePattern()
    assert base_pattern_3.optimize() == base_pattern_3
    assert base_pattern_3.optimize().type == base_pattern_3.type


# Generated at 2022-06-25 15:16:11.982186
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_0 = Leaf(1, 'hi')
    assert leaf_0.pre_order() == [leaf_0], 'leaf_0.pre_order() == [leaf_0]'
# if __name__ == '__main__':
#     test_case_0()
#     test_case_1()
#     test_case_2()
#     test_case_3()
#     test_case_4()
#     test_case_5()
#     test_case_6()
#     test_case_7()
#     test_case_8()
#     test_case_9()
#     test_case_10()
#     test_case_11()
#     test_case_12()
#     test_case_13()
#     test_case_14()
#     test_case_15

# Generated at 2022-06-25 15:16:24.284850
# Unit test for function generate_matches
def test_generate_matches():
    wildcard_pattern_0 = WildcardPattern()
    node_pattern_1 = NodePattern()
    leaf_pattern_2 = LeafPattern()
    leaf_pattern_3 = LeafPattern()
    leaf_pattern_4 = LeafPattern(type=1)
    node_pattern_5 = NodePattern(type=1)

    generate_matches([wildcard_pattern_0], [])
    generate_matches([wildcard_pattern_0, node_pattern_5, ], [])
    generate_matches([wildcard_pattern_0, node_pattern_5, ], [])
    generate_matches([wildcard_pattern_0, node_pattern_5, ], [])
    generate_matches([wildcard_pattern_0, node_pattern_5, ], [])

# Generated at 2022-06-25 15:16:34.089052
# Unit test for method post_order of class Base
def test_Base_post_order():
    POST_ORDER_0 = Node(-1, [Leaf(0, ""), Node(-1, [])])
    POST_ORDER_1 = Node(-1, [Leaf(0, ""), Node(-1, []), Leaf(1, "\n")])
    POST_ORDER_2 = Node(-1, [Node(-1, []), Leaf(0, ""), Node(-1, [])])
    POST_ORDER_3 = Node(-1, [Leaf(0, "")])
    POST_ORDER_4 = Node(-1, [Leaf(0, ""), Leaf(1, "\n")])
    POST_ORDER_5 = Node(-1, [Leaf(0, ""), Leaf(1, ""), Leaf(0, "")])

# Generated at 2022-06-25 15:16:39.241177
# Unit test for method post_order of class Node
def test_Node_post_order():
    wildcard_pattern_0 = WildcardPattern()
    sequence_pattern_1 = SequencePattern((wildcard_pattern_0,))
    wildcard_pattern_0.next_pattern = sequence_pattern_1
    assert isinstance(wildcard_pattern_0.post_order(), Iterator)
    assert isinstance(sequence_pattern_1.post_order(), Iterator)



# Generated at 2022-06-25 15:16:45.749294
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_1 = WildcardPattern()
    nodePattern_0 = NodePattern()
    nodePattern_1 = NodePattern()
    nodePattern_2 = NodePattern()
    nodePattern_3 = NodePattern()
    nodePattern_4 = NodePattern()
    nodePattern_5 = NodePattern()
    leaf_0 = Leaf(None, None)
    leaf_1 = Leaf(None, None)
    leaf_2 = Leaf(None, None)
    leaf_3 = Leaf(None, None)
    leaf_4 = Leaf(None, None)
    leaf_5 = Leaf(None, None)
    leaf_6 = Leaf(None, None)
    leaf_7 = Leaf(None, None)
    leaf_8 = Leaf(None, None)

# Generated at 2022-06-25 15:16:48.274991
# Unit test for method leaves of class Base
def test_Base_leaves():
   for test in range(0, 1):
      node_0 = Node()
      # Alternatively, call node_0.leaves()
      Base().leaves()


# Generated at 2022-06-25 15:16:50.326986
# Unit test for method post_order of class Base
def test_Base_post_order():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_1 = WildcardPattern()



# Generated at 2022-06-25 15:16:57.455059
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    line_no = 1
    test_value, test_prefix, test_context, test_children = Base._test_values()
    test_leaf = Leaf(test_value, test_prefix, test_context, test_children)
    test_leaf.lineno = line_no
    test_node = Node(test_value, test_prefix, test_context, test_children)
    test_node.children = [test_leaf]
    test_node.lineno = line_no
    assert test_leaf.get_lineno() == line_no
    assert test_node.get_lineno() == line_no



# Generated at 2022-06-25 15:17:07.620560
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # The invocant is a Leaf.
    test_base_0 = Leaf(0, "", (1, 1), [])
    lineno_0 = test_base_0.get_lineno()
    assert lineno_0 == 1, "assertion 'lineno_0 == 1' failed"

    # The invocant is a Node; its children is empty.
    test_base_1 = Node(0, [])
    lineno_1 = test_base_1.get_lineno()
    assert lineno_1 is None, "assertion 'lineno_1 is None' failed"

    # The invocant is a Node; its children is not empty; the first child is a
    # Leaf.
    test_base_2 = Node(0, [test_base_0])
    lineno_2 = test_base

# Generated at 2022-06-25 15:17:09.674916
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    wildcard_pattern_0 = WildcardPattern()
    assert wildcard_pattern_0.generate_matches is not None



# Generated at 2022-06-25 15:18:13.228282
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    leaf_pattern_0 = LeafPattern(131)
    leaf_pattern_1 = LeafPattern(0)
    test_list_0 = [leaf_pattern_0, leaf_pattern_1]
    for item_0 in test_list_0:
        for item_1 in item_0.generate_matches([]):
            pass
    node_pattern_0 = NodePattern(0, [leaf_pattern_0, leaf_pattern_1])
    for item_2 in node_pattern_0.generate_matches([]):
        pass
    node_pattern_1 = NodePattern(0, [])
    for item_3 in node_pattern_1.generate_matches([]):
        pass


# Generated at 2022-06-25 15:18:21.190706
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    negated_pattern_0 = NegatedPattern()
    list_0 = []
    list_1 = []
    assert not negated_pattern_0.generate_matches(list_0)
    assert not negated_pattern_0.generate_matches(list_1)

# Generated at 2022-06-25 15:18:26.361637
# Unit test for method leaves of class Base
def test_Base_leaves():
    node = Node(1, None, None, [])
    node.children = [
            Node(2, None, None, []),
            Node(3, None, None, []),
            Node(4, None, None, [
                    Leaf(5, None, None, "abc"),
                    Leaf(6, None, None, "def")]),
            Node(7, None, None, [])]
    assert list(node.leaves()) == [
            Leaf(5, None, None, "abc"),
            Leaf(6, None, None, "def")]



# Generated at 2022-06-25 15:18:32.298872
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wildcard_pattern_0 = NodePattern()
    wildcard_pattern_1 = NodePattern()
    wildcard_pattern_2 = WildcardPattern()
    wildcard_pattern_0.content.append(wildcard_pattern_1)
    wildcard_pattern_2.content = wildcard_pattern_0.content
    wildcard_pattern_2.optimize()
    return

# These are the examples from the test suite

# Generated at 2022-06-25 15:18:38.778489
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    negated_pattern_1 = NegatedPattern([None])
    negated_pattern_2 = NegatedPattern(None)
    negated_pattern_1.generate_matches('wz')
    negated_pattern_2.generate_matches(['m5'])
    # Test that we handle multiple sequences of nodes
    negated_pattern_1.generate_matches(['+', '^'])
    # Test that we handle empty sequences of nodes
    negated_pattern_2.generate_matches([])



# Generated at 2022-06-25 15:18:46.678685
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    # Code for testing method pre_order for class Node
    wildcard_pattern_0 = WildcardPattern()
    result_0 = Node(0, wildcard_pattern_0, wildcard_pattern_0)

    result_1 = {result_0.pre_order()}
    expected_1 = 0
    assert expected_1 == result_1

    result_2 = {result_0.pre_order()}
    expected_2 = 0
    assert expected_2 == result_2

    result_3 = {result_0.pre_order()}
    expected_3 = 0
    assert expected_3 == result_3

    result_4 = {result_0.pre_order()}
    expected_4 = 0
    assert expected_4 == result_4

    result_5 = {result_0.pre_order()}
   

# Generated at 2022-06-25 15:18:54.594233
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_1 = WildcardPattern()
    wildcard_pattern_2 = WildcardPattern()
    wildcard_pattern_3 = WildcardPattern()
    wildcard_pattern_4 = WildcardPattern()
    node_0 = Node(0, [wildcard_pattern_0, wildcard_pattern_1, wildcard_pattern_2, wildcard_pattern_3, wildcard_pattern_4])
    node_0.pre_order()


# Generated at 2022-06-25 15:18:55.346266
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1


# Generated at 2022-06-25 15:18:57.450904
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_1 = Node(0, [])
    assert node_1.post_order() == [node_1]


# Generated at 2022-06-25 15:19:00.626524
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_0
    assert wildcard_pattern_0.__eq__(wildcard_pattern_0)


# Generated at 2022-06-25 15:19:37.672524
# Unit test for method leaves of class Base
def test_Base_leaves():
    wildcard_pattern_0 = WildcardPattern()
    list_str_0 = [""]
    node_0 = Node(type_int_1, list_str_0)
    node_0.leaves()


# Generated at 2022-06-25 15:19:39.322491
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == 'NAME'
    assert type_repr(python_symbols.EQUAL) == '='



# Generated at 2022-06-25 15:19:46.058850
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    wildcard_pattern = WildcardPattern()
    raw_node = (1, "1", (None, (1, 1)), [])
    node = convert(raw_node)
    assert wildcard_pattern.generate_matches([node]) == [(1, {})]


# Generated at 2022-06-25 15:19:48.812817
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node_0 = Node(260, [])
    test_repr = "Node(python_symbols.test, [])"
    assert repr(node_0) == test_repr


# Generated at 2022-06-25 15:19:52.522987
# Unit test for method remove of class Base
def test_Base_remove():
    root = Node(1)
    leaf = Leaf(1, 'leaf')
    root.append_child(leaf)
    leaf.remove()


# Generated at 2022-06-25 15:19:55.133004
# Unit test for method leaves of class Base
def test_Base_leaves():
    # Setup
    wildcard_pattern_0 = WildcardPattern()
    base_0 = Base()
    # Verification
    wildcard_pattern_0.test_case_0()


# Generated at 2022-06-25 15:19:58.032994
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    nodes = []
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_0.generate_matches(nodes)
    # Expected Exception: NotImplementedError
    #     raise NotImplementedError


# Generated at 2022-06-25 15:20:04.128588
# Unit test for method leaves of class Base
def test_Base_leaves():
    node_0 = Node()
    node_0.parent = None
    node_0.children = []

    node_1 = Node()
    node_1.parent = None
    node_1.children = []

    node_0.children += [node_1]
    node_1.parent = node_0

    node_2 = Node()
    node_2.parent = None
    node_2.children = []

    node_0.children += [node_2]
    node_2.parent = node_0

    node_3 = Leaf()
    node_3.parent = None
    node_3.children = []

    node_1.children = [node_3]
    node_3.parent = node_1

    node_4 = Leaf()
    node_4.parent = None
    node_4.children

# Generated at 2022-06-25 15:20:16.118022
# Unit test for function generate_matches
def test_generate_matches():
    node_0 = NL(NL([NL('data', -1)]))
    assert list(generate_matches([NodePattern()], node_0.children)) == [(1, {})]
    wildcard_pattern_0 = WildcardPattern()
    assert list(generate_matches([wildcard_pattern_0], node_0.children)) == [(1, {})]
    node_1 = NL(NL([NL('data', -1), NL([], -1)]))
    assert list(generate_matches([wildcard_pattern_0], node_1.children)) == [(2, {})]
    node_2 = NL(NL([NL('data', -1), NL([], -1), NL([], -1)]))

# Generated at 2022-06-25 15:20:18.313401
# Unit test for method clone of class Base
def test_Base_clone():
    Base_obj = Base()
    # assert Base_obj.clone() == is_equal_to
    print(type(Base_obj.clone()))



# Generated at 2022-06-25 15:21:25.350864
# Unit test for method leaves of class Base
def test_Base_leaves():
    leaf_1 = Leaf(0, "", 0, None)
    assert list(leaf_1.leaves()) == [leaf_1]
    leaf_2 = Leaf(0, "", 0, None)
    pattern_leaf_3 = LeafPattern(0)
    pattern_wildcard_4 = WildcardPattern()
    node_5 = Node(0, [leaf_2, pattern_leaf_3, pattern_wildcard_4, leaf_1])
    assert list(node_5.leaves()) == [leaf_2, leaf_1]
    leaf_6 = Leaf(0, "", 0, None)
    pattern_leaf_7 = LeafPattern(0)
    pattern_wildcard_8 = WildcardPattern()
    pattern_node_9 = NodePattern(0, [pattern_leaf_7, pattern_wildcard_8])


# Generated at 2022-06-25 15:21:29.485523
# Unit test for function generate_matches
def test_generate_matches():
    patterns = [WildcardPattern(), NodePattern(type=2)]
    nodes = [
        NL(symbol=2, children=[]),
        NL(symbol=3, children=[]),
        NL(symbol=3, children=[]),
        NL(symbol=3, children=[]),
    ]
    result = [
        (1, {}),
        (2, {}),
        (3, {}),
        (4, {}),
        (1, {'p1': NL(symbol=2, children=[])}),
        (3, {'p1': NL(symbol=2, children=[])}),
    ]
    for i, (count, r) in enumerate(generate_matches(patterns, nodes)):
        assert count == result[i][0]

# Generated at 2022-06-25 15:21:32.347819
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_1 = WildcardPattern()
    assert (wildcard_pattern_0 == wildcard_pattern_1)


# Generated at 2022-06-25 15:21:37.020939
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    wildcard_pattern_0 = WildcardPattern()
    nodes = [Leaf(1, "")]
    for i, r in wildcard_pattern_0.generate_matches(nodes):
        assert i != i
        assert r == r
