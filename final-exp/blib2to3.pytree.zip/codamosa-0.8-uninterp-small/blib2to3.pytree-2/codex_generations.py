

# Generated at 2022-06-25 15:13:15.453760
# Unit test for function convert
def test_convert():
    assert isinstance(convert(Grammar(), (0, None, None, [])), Leaf)
    assert isinstance(convert(Grammar(), (0, None, None, [Node(0, [])])), Node)


# Generated at 2022-06-25 15:13:17.339677
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert '__repr__' in BasePattern.__dict__


# Generated at 2022-06-25 15:13:19.680290
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "value")
    assert leaf.pre_order() == [leaf]


# Generated at 2022-06-25 15:13:25.624172
# Unit test for method replace of class Base
def test_Base_replace():
    node_1 = Node()
    lst_1 = [Leaf()]
    assert node_1.parent is None
    assert node_1.children == []
    node_1.replace(lst_1)
    assert node_1.children == lst_1
    assert node_1.parent == None


# Generated at 2022-06-25 15:13:28.156406
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf1 = Leaf(0, "value1")
    list1 = [leaf1]
    assert list(leaf1.pre_order()) == list1


# Generated at 2022-06-25 15:13:29.977501
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_pattern_0 = BasePattern()
    # No assertions for method match_seq.


# Generated at 2022-06-25 15:13:41.365444
# Unit test for method match_seq of class WildcardPattern

# Generated at 2022-06-25 15:13:42.585102
# Unit test for method post_order of class Node
def test_Node_post_order():
    for node in Node.post_order():
        pass


# Generated at 2022-06-25 15:13:45.412476
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():

    # Test first use case
    leaf_0 = Leaf(
        type=12,
        value="",
        context=None,
        prefix=None,
        fixers_applied=[]
    )
    assert leaf_0.leaves() == [leaf_0]



# Generated at 2022-06-25 15:13:54.361084
# Unit test for function generate_matches
def test_generate_matches():
    import ast
    # First test case (no patterns, no nodes)
    test_no_patterns_no_nodes = ([], [])
    assert ([], {}) == next(generate_matches(*test_no_patterns_no_nodes))
    with pytest.raises(StopIteration):
        next(generate_matches(*test_no_patterns_no_nodes))
    # Second test case (a single node pattern, no nodes)
    test_single_node_no_nodes = ([NodePattern()], [])
    with pytest.raises(StopIteration):
        next(generate_matches(*test_single_node_no_nodes))
    # Third test case (a single node pattern, single node)
    single_node = ast.parse("0", mode='eval').body


# Generated at 2022-06-25 15:14:10.322736
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    test = Node(1, [])
    test_pre = test.pre_order()
    assert(isinstance(test_pre, type(iter([]))))
    next(test_pre)
    next(test_pre)
    next(test_pre)
    assert(next(test_pre) == None)


# Generated at 2022-06-25 15:14:11.728875
# Unit test for method clone of class Base
def test_Base_clone():
    base_0 = Base()
    # assert False  # TODO: implement test


# Generated at 2022-06-25 15:14:16.164123
# Unit test for method replace of class Base
def test_Base_replace():
    print("Testing method replace of class Base...")
    try:
        parsed_sample_0 = Node(0, "node_name")
        parsed_sample_0.replace(None)
        print("Test Passed!")
    except:
        print("Failed!")
    return


# Generated at 2022-06-25 15:14:17.027867
# Unit test for method leaves of class Base
def test_Base_leaves():
    test_case_0()


# Generated at 2022-06-25 15:14:22.848812
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    nodes = []
    results = None
    base_pattern_0 = BasePattern()
    res = base_pattern_0.match_seq(nodes, results)
    assert res is False
    test_case_0()
    nodes = [1, 2, 3]
    results = None
    negated_pattern_1 = NegatedPattern()
    res = negated_pattern_1.match_seq(nodes, results)
    assert res is False
    nodes = [1, 2]
    results = None
    negated_pattern_2 = NegatedPattern()
    res = negated_pattern_2.match_seq(nodes, results)
    assert res is False



# Generated at 2022-06-25 15:14:26.232060
# Unit test for method clone of class Base
def test_Base_clone():
    def sample_function_0():
        return Leaf(10)
    import copy
    sample_0 = sample_function_0()
    sample_1 = copy.deepcopy(sample_0)
    assert sample_0 == sample_1


# Generated at 2022-06-25 15:14:28.092429
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    try:
        Leaf(1, "f", (1, 1))
    except Exception:
        raise RuntimeError("Exception raised")


# Generated at 2022-06-25 15:14:31.287321
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    b = Base()
    result = b.pre_order()
    if not result is None :
        raise TypeError('pre_order not return None: Result: ' + str(result))


# Generated at 2022-06-25 15:14:39.365472
# Unit test for method post_order of class Node
def test_Node_post_order():
    test_case_0()
    def test_string_Node(str_param: str) -> Any:
        try:
            return Node(str_param, [], "", "")
        except TypeError:
            return str_param
    def test_Node_Node(dict_param: Dict[str, Any]) -> Dict[str, Any]:
        try:
            return Node(dict_param, [], "", "")
        except TypeError:
            return dict_param

# Generated at 2022-06-25 15:14:47.785524
# Unit test for function generate_matches
def test_generate_matches():
    patterns = [
        NodePattern(5),
        NodePattern(6),
        NodePattern(7),
        NodePattern(8),
    ]
    nodes = [
        NL(5),
        NL(6),
        NL(7),
        NL(8),
    ]
    assert list(generate_matches(patterns, nodes)) == [(len(nodes), {})]

    nodes[0] = NL(7)
    assert list(generate_matches(patterns, nodes)) == []


# Generated at 2022-06-25 15:15:21.436737
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    # Test 1: No children
    test_Leaf = Leaf(258, "*")
    expected_result = []
    assert [l.value for l in test_Leaf.leaves()] == expected_result



# Generated at 2022-06-25 15:15:24.402150
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    import pgen2.grammar as grammar

    identifier_pattern_0 = LeafPattern(type=(grammar.token.NAME), name=(None))


# Generated at 2022-06-25 15:15:35.996950
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    negated_pattern_0 = NegatedPattern()
    negated_pattern_1 = NegatedPattern()
    negated_pattern_2 = NegatedPattern()
    negated_pattern_3 = NegatedPattern()
    negated_pattern_4 = NegatedPattern()
    
    final_0 = diff()
    final_1 = diff()
    final_2 = diff()
    final_3 = diff()
    final_4 = diff()
    
    final_5 = diff()
    final_6 = diff()
    final_7 = diff()
    final_8 = diff()
    
    
    
    
    
    
    
    
    
    
    
    
    negated_pattern_0.get_children()
    negated_pattern_1.get_children()

# Generated at 2022-06-25 15:15:37.050634
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    optimized_BasePattern = BasePattern().optimize()

# Generated at 2022-06-25 15:15:39.990174
# Unit test for method set_child of class Node
def test_Node_set_child():
    """
    Testing: Setting child 0 of node raises exception, node.set_child(0, child)
    """
    node = Node(1, [1, 2, 3])
    child = 2
    try:
        node.set_child(0, child)
        assert False, "Child 0 of node should be immutable"
    except ValueError:
        pass


# Generated at 2022-06-25 15:15:47.925131
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    Base_instance0 = Base()
    Node_instance0 = Node(0)
    Node_instance1 = Node(0)
    Node_instance2 = Node(1)
    Leaf_instance0 = Leaf(0)
    Leaf_instance1 = Leaf(0)
    Leaf_instance2 = Leaf(1)
    assert Base_instance0.__eq__(Base_instance0) == True
    assert Base_instance0.__eq__(Node_instance0) == True
    assert Base_instance0.__eq__(Node_instance1) == True
    assert Base_instance0.__eq__(Node_instance2) == True
    assert Base_instance0.__eq__(Leaf_instance0) == True
    assert Base_instance0.__eq__(Leaf_instance1) == True
    assert Base_instance0.__

# Generated at 2022-06-25 15:15:48.556029
# Unit test for function convert
def test_convert():
    test_case_0()


# Generated at 2022-06-25 15:15:55.523218
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    a_pattern_0 = LeafPattern()
    list_type_0 = [a_pattern_0 for x_index_0 in range(4)]
    a_pattern_1 = LeafPattern()
    list_type_1 = [a_pattern_1 for x_index_1 in range(4)]
    a_pattern_2 = LeafPattern()
    list_type_2 = [a_pattern_2 for x_index_2 in range(4)]
    a_pattern_3 = LeafPattern()
    list_type_3 = [a_pattern_3 for x_index_3 in range(4)]
    a_pattern_4 = LeafPattern()
    list_type_4 = [a_pattern_4 for x_index_4 in range(4)]
    a_pattern_5 = LeafPattern()

# Generated at 2022-06-25 15:16:02.826795
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test if the method works properly when the 'content' is None
    negated_pattern_0 = NegatedPattern()
    nodes = [
        ast.Name(id="name_0", ctx=ast.Load()),
        ast.Num(n=1),
        ast.Load(),
        ast.MatMult(),
        ast.IfExp(),
        ast.BoolOp(),
        ast.Lambda(),
        ast.Modulo(),
    ]
    gen = negated_pattern_0.generate_matches(nodes)
    count, results = next(gen)
    # Check if the generated count, which should be 0, is equal to 0
    assert count == 0
    # Check if the generated results dict is empty
    assert len(results) == 0


# Generated at 2022-06-25 15:16:05.232691
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    ba = Base()
    pre_order_0 = ba.pre_order()
    print(pre_order_0)



# Generated at 2022-06-25 15:19:23.030276
# Unit test for method replace of class Base
def test_Base_replace():
    def new_negated_pattern_0():
        return Node(syms.not_test, [Leaf(token.NAME, "x"), Leaf(token.NAME, "y")])
    negated_pattern_0 = new_negated_pattern_0()
    negated_pattern_0.replace(new_negated_pattern_0())


# Generated at 2022-06-25 15:19:29.217868
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    class TestGenerateMatches(unittest.TestCase):

        def test_case_0(self):
            negated_pattern_0 = NegatedPattern()
            negated_pattern_0.content = negated_pattern_0.content = BasePattern()
            negated_pattern_0.content = negated_pattern_0.content
            negated_pattern_0.content.match = lambda x: False
            with self.assertRaises(TypeError):
                negated_pattern_0.generate_matches()

        # __main__

# Generated at 2022-06-25 15:19:31.196530
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    negated_pattern_0 = NegatedPattern()
    leaf_0 = Leaf(negated_pattern_0, "")
    assert leaf_0.post_order() == [leaf_0]


# Generated at 2022-06-25 15:19:33.737276
# Unit test for function generate_matches
def test_generate_matches():
    p1 = NodePattern(type="int_literal")
    p2 = NodePattern(type="int_literal")
    p3 = NodePattern(type="string_literal")
    result = [t for t in generate_matches([p1, p2, p3], [
        NL(type="int_literal"),
        NL(type="int_literal"),
        NL(type="string_literal")])]
    assert result == [(3, {})]


# Generated at 2022-06-25 15:19:36.055448
# Unit test for constructor of class NodePattern
def test_NodePattern():
    node_pattern_0 = NodePattern()


# Generated at 2022-06-25 15:19:41.966698
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    """
    Test that the method generate_matches of class WildcardPattern
    operates properly.

    To do this, we test that the pattern matches the desired
    sequences of nodes, for at least one choice of pattern.
    """
    # Test that the pattern matches the desired sequences of nodes,
    # for at least one choice of pattern.
    pattern = WildcardPattern(((NodePattern(type=57),), (NodePattern(type=556),)))
    nodes = (Node(type=57), Node(type=556))
    pattern.match(nodes)
    expected = 1, {}
    result = pattern.match(nodes)
    assert result == expected, result
    # Test that the pattern matches the desired sequences of nodes,
    # for one more choice of pattern.
    pattern = WildcardPattern(min=1, max=2)
    nodes

# Generated at 2022-06-25 15:19:45.553396
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    not_pattern_0 = NotPattern()
    not_pattern_1 = NotPattern()
    assert not_pattern_0.match_seq([1]) == not_pattern_1.match_seq([1])


# Generated at 2022-06-25 15:19:47.401172
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    assert base_0.depth() == 0


# Generated at 2022-06-25 15:19:57.744354
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test case where the content is not None and the name is not None and
    # the content is a list with a single item that is a list with a single
    # item that is a type NodePattern.
    negated_pattern_0 = NegatedPattern()
    wildcard_pattern_0 = WildcardPattern(
        [
            [
                NodePattern()
            ]
        ]
    ,
        name="an_int"
    )
    assert isinstance(wildcard_pattern_0.optimize(), NodePattern) == True
    assert wildcard_pattern_0.optimize().name == "an_int"

    # Test case where the content is not None and the name is None and the
    # content is a list with a single item that is a list with a single item
    # that is a type NodePattern.
    negated_pattern_

# Generated at 2022-06-25 15:20:07.612353
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    negated_pattern_0 = NegatedPattern()
    l_0 = Leaf(257, "    ", (negated_pattern_0, (1, 0)), [], [])
    l_1 = Leaf(257, " ", (negated_pattern_0, (1, 4)), [], [])
    l_2 = Leaf(258, "foo", (negated_pattern_0, (1, 5)), [], [])
    l_3 = Leaf(1, None, (negated_pattern_0, (1, 8)), [], [])
    l_4 = Leaf(257, " ", (negated_pattern_0, (1, 9)), [], [])
    l_5 = Leaf(257, "bar", (negated_pattern_0, (1, 10)), [], [])

# Generated at 2022-06-25 15:21:37.936438
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    pass
