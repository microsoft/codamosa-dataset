

# Generated at 2022-06-25 15:12:58.600513
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    test_case_0()
    negated_pattern_0 = NegatedPattern()
    assert list(negated_pattern_0.post_order()) == [negated_pattern_0]


# Generated at 2022-06-25 15:13:02.690162
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    print("test_BasePattern_match()")
    c = BasePattern()
    c.type = 256
    c.child = 0
    c.match([1, 2, 3, 4])
    assert c.type == 257


# Generated at 2022-06-25 15:13:12.143345
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # Expected no. of matches: 1
    root_0 = Node("+")
    name_0 = WildcardPattern(None, min=1, max=1, name="name")
    remain_0 = WildcardPattern(None, min=0, max=HUGE)
    expr_0 = SequencePattern(
        [name_0, remain_0],
    )
    try:
        assert expr_0.match_seq([root_0])
    except AssertionError as e:
        stypy.reporting.localization.Localization(stypy.reporting.localization.Localization(__file__, 155, 8), 'raise', AssertionError('match_seq() assertion failed') + str(e),)
      

# Generated at 2022-06-25 15:13:13.400111
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    for i in bas():
        print("hi,i")


# Generated at 2022-06-25 15:13:14.804411
# Unit test for function convert
def test_convert():
    _convert = convert(*test_case_0())
    assert False


# Generated at 2022-06-25 15:13:20.544302
# Unit test for method leaves of class Base
def test_Base_leaves():
    out = StringIO()
    sys.stdout = out
    # create an object
    obj = Base()
    #call the method on the obj
    obj.leaves()
    output = out.getvalue().strip()
    sys.stdout=sys.__stdout__
    assert output == "(<generator object Base.leaves at 0x000001D5B43B1C40>)"


# Generated at 2022-06-25 15:13:29.630941
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # Setup code
    leaf_0 = Leaf(1, "a")
    leaf_0.prefix = "b"
    # Unit test code
    leaf_1 = next(leaf_0.pre_order())
    # Assertions
    assert leaf_1 is leaf_0
    leaf_2 = next(leaf_0.pre_order())
    try:
        next(leaf_0.pre_order())
    except StopIteration:
        pass
    else:
        raise AssertionError
    # Teardown code
    del leaf_0
    del leaf_1
    del leaf_2


# Generated at 2022-06-25 15:13:33.207895
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Tests with empty argument list
    _arg_0 = []
    _expect_0 = False
    _got_0 = BasePattern.match_seq(_arg_0)
    assert _got_0 == _expect_0


# Generated at 2022-06-25 15:13:43.850902
# Unit test for method clone of class Base
def test_Base_clone():
    # Create a test fixture
    base_0 = Base()
    base_0.type = 4
    base_0.parent = Node(type=0)
    base_0.children = [Leaf(type=1, value="a", prefix=" "), Leaf(type=2, value="\n",
                        prefix="\n"), Node(type=3, children=[Leaf(type=1, value="a",
                        prefix=" ")]), Leaf(type=4, value=" ", prefix=" "), Leaf(type=1,
                        value="a", prefix=" "), Leaf(type=6, value="\n", prefix="\n")]
    base_0.was_changed = False
    base_0.was_checked = False

    # Invoke the method under test
    result = base_0.clone()

    # Verify the results


# Generated at 2022-06-25 15:13:45.239235
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pat = TreePattern(WildcardPattern())
    pat.match_seq([Leaf(1, 'a')])


# Generated at 2022-06-25 15:14:18.771522
# Unit test for method leaves of class Base
def test_Base_leaves():
    cls = Base()
    cls.leaves()


# Generated at 2022-06-25 15:14:24.588614
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    # Test with valid value
    num_0 = Node(256, [Leaf(1, [])])
    # Call method
    Node_pre_order_ret = Node.pre_order(num_0)
    Node_pre_order_ret_1 = Node.pre_order(num_0)
    if(sys.version_info < (3, 0)):
        if not(isinstance(Node_pre_order_ret, types.GeneratorType)
                and isinstance(Node_pre_order_ret_1, types.GeneratorType)):
            print("pre_order does not return a generator")
            return
    else:

        if not(isinstance(Node_pre_order_ret, types.GeneratorType)):
            print("pre_order does not return a generator")
            return


# Generated at 2022-06-25 15:14:35.885040
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    test_data_0 = []
    test_data_1 = [1]
    test_data_2 = [1, 2, 3]
    test_data_3 = [(0, 0), (0, 0), (0, 0)]
    test_data_4 = [(0, 0), (1, 1), (0, 0), (0, 0)]
    node_pattern_0 = NodePattern()
    node_pattern_0.match_seq(test_data_0)
    node_pattern_0.match_seq(test_data_1)
    node_pattern_0.match_seq(test_data_2)
    node_pattern_0.match_seq(test_data_3)
    node_pattern_0.match_seq(test_data_4)


# Generated at 2022-06-25 15:14:39.740497
# Unit test for method post_order of class Node
def test_Node_post_order():

    # Test case for a non empty tree
    test_case_0 = Node(
        0, [Node(
            1, [Node(
                2, [Leaf(3, "a", (0, 0), (0, 1))])])])
    test_case_0.post_order()


# Generated at 2022-06-25 15:14:43.087813
# Unit test for method clone of class Base
def test_Base_clone():
    obj_0 = Base()
    obj_1 = obj_0.clone()
    assert obj_1 == obj_0, "Base.clone: Failed Unit Test"


# Generated at 2022-06-25 15:14:46.932499
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    negated_pattern_0 = NegatedPattern()
    result = negated_pattern_0.generate_matches([])
    assert len(list(result)) == 0


# Generated at 2022-06-25 15:14:51.148500
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from .parser import NL


# Generated at 2022-06-25 15:14:53.744100
# Unit test for method clone of class Base
def test_Base_clone():
    # See issue #22232
    # This method should not recurse infinitely
    negated_pattern_0 = NegatedPattern()
    negated_pattern_0.clone()


# Generated at 2022-06-25 15:14:57.420783
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    # one leaf node
    node = Leaf(1, "leaf")

    # method post_order generator is called, list is the result
    node_list = list(node.post_order())

    # compare the number of nodes
    assert len(node_list) == 1

    # compare if the node is the same
    assert node_list[0] == node

    # compare the type of the node
    assert node_list[0].type == node.type

    # compare the value of the node
    assert node_list[0].value == node.value


# Generated at 2022-06-25 15:15:03.537237
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    BasePattern_instance_0 = BasePattern()
    # Assign parameters for test case
    # node_0 is the first argument
    Leaf_instance_0 = Leaf()

    Leaf_instance_1 = Leaf()
    Leaf_instance_1.parent = Leaf_instance_0
    Leaf_instance_0.children = [Leaf_instance_1]
    nodes_0 = [Leaf_instance_0]

    # Call the method to test with parameters
    BasePattern_instance_0.match_seq(nodes_0)



# Generated at 2022-06-25 15:15:33.161608
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    base_pattern_0 = BasePattern()
    node_0 = Leaf(0, '', None, None)
    assert base_pattern_0.match(node_0) == False


# Generated at 2022-06-25 15:15:36.164252
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_0 = Base()
    base_1 = Base()
    assert base_0.__eq__(base_1) == NotImplemented


# Generated at 2022-06-25 15:15:45.840973
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_1 = Base()
    base_1.children = Node(1, 0, 4, [Leaf(0, 'def', (1, 0)), Leaf(16, '(', (1, 4)), Leaf(1, 'test_case_0', (1, 5)), Leaf(22, ')', (1, 17)), Leaf(4, ':', (1, 18)), Leaf(0, '\n', (2, 0)), Leaf(0, '    ', (3, 0)), Leaf(1, 'base_0', (3, 4)), Leaf(3, ' = ', (3, 11)), Leaf(1, 'Base', (3, 14)), Leaf(16, '(', (3, 18)), Leaf(22, ')', (3, 19)), Leaf(0, '\n', (3, 20))])

# Generated at 2022-06-25 15:15:51.705505
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    try:
        print("Testing Node.__repr__...")
 
        test_node = Node(0, [Leaf(1, 'a'), Leaf(2, 'b')])

        assert str(test_node) == "ab"
        assert repr(test_node) == "Node(0, ['a', 'b'])"

        print("Node.__repr__ test passed.")
    except AssertionError:
        print("Node.__repr__ test failed.")



# Generated at 2022-06-25 15:15:53.393707
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # optimization is optional, so don't do anything if not implemented
    pass


# Generated at 2022-06-25 15:16:02.228547
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    w = WildcardPattern()
    assert isinstance(w.optimize(), NodePattern)
    w = WildcardPattern(name="x")
    assert isinstance(w.optimize(), NodePattern)
    w = WildcardPattern(min=10)
    assert isinstance(w.optimize(), WildcardPattern)
    w = WildcardPattern(min=10, name="x")
    assert isinstance(w.optimize(), WildcardPattern)
    w = WildcardPattern(max=1, name="x")
    assert isinstance(w.optimize(), NodePattern)
    w = WildcardPattern(max=1)
    assert isinstance(w.optimize(), NodePattern)
    w = WildcardPattern(content=[[NodePattern(name="x")]])
    assert isinstance(w.optimize(), WildcardPattern)
    w

# Generated at 2022-06-25 15:16:10.581830
# Unit test for method leaves of class Base
def test_Base_leaves():
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.parse import (
        generate_tokens,
        tok_name,
        untokenize,
        untokenize_find,
    )

    import io
    import sys
    import tokenize
    from io import BytesIO, StringIO
    from typing import Text
    from typing import Tuple
    from typing import List
    from typing import Generator
    from typing import Iterator
    from typing import Union
    import io
    import sys
    import tokenize
    from io import BytesIO, StringIO
    from typing import Text
    from typing import Tuple
    from typing import List
    from typing import Generator
    from typing import Iterator
   

# Generated at 2022-06-25 15:16:18.297400
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    print('execute test_BasePattern_generate_matches')

    # Initialization
    import matplotlib.pylab as plt
    from .pgen2.tokenize import generate_tokens, untokenize
    import ast
    import os
    import sys

    # Get the path of the test file
    test_file_path = os.path.join(os.path.dirname(__file__), 'remove_parentheses.py')

    # Edit the test file to delete a character at the end of line 15
    file = open(test_file_path, 'r')
    file_content = file.readlines()
    file_content[14] = file_content[14][:-1]
    file = open(test_file_path, 'w')
    file.writelines(file_content)

# Generated at 2022-06-25 15:16:22.471449
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    nodeList = list()
    cmp_method = BasePattern.match_seq
    b = BasePattern()
    cmp_method(b, nodeList)


# Generated at 2022-06-25 15:16:26.697477
# Unit test for method replace of class Base
def test_Base_replace():
    base_0 = Base()
    base_0.replace([base_0])


# Generated at 2022-06-25 15:16:52.773592
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    # TODO Add unit tests
    node = Node(258, [])
    _pre_order_result = node.pre_order()
    _pre_order_result = list(_pre_order_result)
    _pre_order_result = _pre_order_result[0]
    assert _pre_order_result == node


# Generated at 2022-06-25 15:16:55.670671
# Unit test for method depth of class Base
def test_Base_depth():
    expected = 0
    base_0 = Base()
    actual = base_0.depth()
    assert actual == expected, 'Test failed: expected: ' + str(expected) + ', actual: ' + str(actual)


# Generated at 2022-06-25 15:16:59.111212
# Unit test for method leaves of class Base
def test_Base_leaves():
    base = Base()
    assert base.leaves() == iter(base.leaves())
    assert base.leaves() == iter((child for child in base.children))


# Generated at 2022-06-25 15:17:08.317964
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_0 = Base()
    base_1 = Base()
    base_2 = Base()
    results = {
        'Base': [base_0, base_1],
        'BasePattern': [base_2],
    }
    if all(
        expect == getattr(item, result)
        for item, result, expect in [
            (base_0, 'match_seq', []),
            (base_1, 'match_seq', []),
            (base_2, 'match_seq', []),
        ]
    ):
        base_2.match_seq(base_0, results)
    else:
        base_2.match_seq(base_0, results)


# Generated at 2022-06-25 15:17:09.914730
# Unit test for method set_child of class Node
def test_Node_set_child():
    i = 0
    base_2 = Node(0, [])
    child = Leaf(0, '', 0)
    base_2.set_child(i, child)


# Generated at 2022-06-25 15:17:14.095760
# Unit test for method set_child of class Node
def test_Node_set_child():
    _node = Node(type = 10, children = [Node(type = 27, children = [Leaf(type = 1, value = 'a'), Leaf(type = 30, value = '[')]), Node(type = 28, children = [])], prefix = '', fixers_applied = [])
    _child = [Node(type = 10, children = [], prefix = '', fixers_applied = []), Node(type = 10, children = [], prefix = '', fixers_applied = []), Node(type = 10, children = [], prefix = '', fixers_applied = [])]
    _node.set_child(0, _child)
    _node.append_child(_child)
    _node.insert_child(0, _child)
    _node.remove()
    _node.replace(_child)
    _

# Generated at 2022-06-25 15:17:16.677911
# Unit test for method set_child of class Node
def test_Node_set_child():
    # Instantiate a new Node object
    node_obj = Node(type=256, children=[])

    # Invoke the set_child method with test parameter
    node_obj.set_child(0, node_obj)



# Generated at 2022-06-25 15:17:22.538582
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test 1
    wildcard_pattern_1 = WildcardPattern(content='', max=2147483647, min=1, name=None)

    # Test 2
    wildcard_pattern_2 = WildcardPattern(content='', max=2147483647, min=1, name=None)
    wildcard_pattern_2.optimize()

    # Test 3
    wildcard_pattern_3 = WildcardPattern(content='', max=2147483647, min=0, name=None)
    wildcard_pattern_3.optimize()

    # Test 4
    wildcard_pattern_4 = WildcardPattern(content='', max=2147483647, min=0, name=None)
    wildcard_pattern_4.optimize()

    # Test 5
    wildcard_pattern_5 = Wildcard

# Generated at 2022-06-25 15:17:25.311050
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    w = WildcardPattern(content = [[LeafPattern("ABC")]])
    assert w.match_seq([Leaf("ABC"), Leaf("ABC")]) == True
    assert w.match_seq([Leaf("ABC"), Leaf("DEF")]) == False


# Generated at 2022-06-25 15:17:29.988111
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base = Base()
    gen = base.pre_order()
    try:
        test_case_1(gen)
    except NotImplementedError as e:
        pass
    except Exception as e:
            raise e


# Generated at 2022-06-25 15:17:49.956926
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    node = Leaf(1, "A")
    node_clone = node.clone()


# Generated at 2022-06-25 15:17:52.060997
# Unit test for method leaves of class Base
def test_Base_leaves():
    base = Base()
    leaf = Leaf(0, '')
    node = Node(0, [leaf])
    assert next(base.leaves()) is None
    assert next(leaf.leaves()) == leaf
    assert next(node.leaves()) == leaf


# Generated at 2022-06-25 15:17:53.608558
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    base_0.get_suffix()


# Generated at 2022-06-25 15:17:56.054234
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_0 = Base()
    # assert base_0._eq(base_0)
    # assert base_0 == base_0
    # assert not (base_0 != base_0)


# Generated at 2022-06-25 15:18:00.959319
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == "NAME"


# A few aliases to make the parse tree more self-documenting
NAME = 1  # a token integer
alias = NAME

# We also need a few types that we don't need to expose
# to the outside, but which we need to refer to here.



# Generated at 2022-06-25 15:18:03.042053
# Unit test for method set_child of class Node
def test_Node_set_child():
    test = Node(0, None)
    child = Leaf(0, None)
    test.set_child(0, child)


# Generated at 2022-06-25 15:18:08.913503
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    base_pattern_1 = BasePattern()
    base_pattern_1.type = 257
    base_pattern_1.content = 1
    base_pattern_1.name = 'name'

    with pytest.raises(NotImplementedError) as excinfo:
        base_pattern_1._submatch(base_pattern_1, base_pattern_1.name)


# Generated at 2022-06-25 15:18:14.969572
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    t_0 = """n = BasePattern()
n._repr__()"""
    # Testing the return value of a method
    from astroid import test_utils
    from astroid import builder, nodes
    builder = builder.AstroidBuilder(None)
    module = builder.string_build(t_0)
    function = module.body[0].value
    result = test_utils.run_function_block_body(function)
    assert result == 'BasePattern()'


# Generated at 2022-06-25 15:18:23.190417
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    if __name__ == "__main__":
        test_WildcardPattern_generate_matches()
    """
    This function tests the following usage of method generate_matches of class WildcardPattern:

    If content is not None, replace the dot with the parenthesized
    list of alternatives, e.g. (a b c | d e | f g h)*

    The test checks that results of the generate_matches(self, nodes) 
    when offered with a tuple of three lists as input are correct. 
    """
    # Define the input
    input = (["a", "b", "c"], ["d", "e"], ["f", "g", "h"])
    
    # Define the expected result
    expected_result = (3, {"bare_name": ["a", "b", "c"]})
    
   

# Generated at 2022-06-25 15:18:24.505609
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_0 = Base()
    assert base_0._eq(base_0) == False


# Generated at 2022-06-25 15:19:04.010287
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from lib2to3.pgen2.pgen import Leaf
    from lib2to3.pygram import python_grammar
    x = Leaf(0, 'a', None, [])
    assert x.get_lineno() is None
    base_1 = Base()
    base_1.lineno = 34
    x.add_child(base_1)
    assert x.get_lineno() == 34
    x2 = Leaf(0, 'b', None, [])
    x2.add_child(base_1)
    assert x2.get_lineno() == 34

    y = Leaf(0, 'a', None, [])
    base_1 = Base()
    base_1.lineno = 56
    y.add_child(base_1)
    assert y.get_lineno() == 56


# Generated at 2022-06-25 15:19:05.850605
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    pattern = BasePattern()
    assert pattern.match_seq([]) == False
    assert pattern.match_seq([Base()]) == False


# Generated at 2022-06-25 15:19:10.754222
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    base_0 = Node(type=int(), children=list, context=None, prefix=None, fixers_applied=None)
    try:
        assert str(base_0) == "Node(0, [])"
    except AssertionError as e:
        print(e)
        print("AssertionError raised by test_Node___repr__")
    else:
        print("Test for method __repr__ of class Node passed")


# Generated at 2022-06-25 15:19:17.049083
# Unit test for method replace of class Base
def test_Base_replace():
    base_1 = Base()
    try:
        assert hasattr(base_1, 'replace')
        assert callable(base_1.replace)
    except AssertionError:
        return False
    base_1.replace('_P')
    return True


# Generated at 2022-06-25 15:19:21.084975
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # The following is a helper function to test the method
    def pre_order_helper(node):
        if (node is None):
            return (None)
        return (node.type)

    # Main test:
    base_1 = Base()
    pre_order_helper(base_1)


# Generated at 2022-06-25 15:19:24.130947
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    lhs = Node(python_symbols.atom, []).clone()
    rhs = Node(python_symbols.atom, []).clone()
    expected_result = True
    assert lhs == rhs


# Generated at 2022-06-25 15:19:28.084120
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    nodes = [base_0]
    results = {}
    # base_pattern_0 is an instance of class BasePattern
    base_pattern_0 = BasePattern()
    # assert base_pattern_0.match_seq(nodes, results) returns False
    assert False == base_pattern_0.match_seq(nodes, results)


# Generated at 2022-06-25 15:19:32.862682
# Unit test for method set_child of class Node
def test_Node_set_child():
    node_0 = Node(0, [])
    node_1 = Node(0, [])
    node_0.set_child(0, node_1)
    assert node_0.children[0] is node_1, "object attribute children is not node_1"
    assert node_1.parent is node_0, "object attribute parent is not node_0"
    assert node_0.was_changed is True, "object attribute was_changed is not True"


# Generated at 2022-06-25 15:19:33.911231
# Unit test for method remove of class Base
def test_Base_remove():
    b = Base()
    assert b.parent is None
    assert b.remove() is None


# Generated at 2022-06-25 15:19:42.812284
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    assert Node(256, []) == Node(256, [])
    assert Node(256, [Leaf(1), Leaf(2), Leaf(3)]) == Node(256, [Leaf(1), Leaf(2), Leaf(3)])
    assert Node(256, [Leaf(1), Leaf(2), Leaf(3)]) != Node(256, [Leaf(2), Leaf(3), Leaf(3)])


# Generated at 2022-06-25 15:20:08.918958
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_0 = Base()
    base_0.match_seq([])

# Generated at 2022-06-25 15:20:17.078831
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    def try_it(self):
        # State 0
        if test_BasePattern___repr__.st == 0:
            if callfunc == "__repr__":
                test_BasePattern___repr__.st = 1
        elif test_BasePattern___repr__.st == 1:
            #assert callfunc == "type_repr"
            test_BasePattern___repr__.st = 2
        elif test_BasePattern___repr__.st == 2:
            if callfunc == "repr":
                test_BasePattern___repr__.st = 3
        elif test_BasePattern___repr__.st == 3:
            #assert callfunc == "repr"
            test_BasePattern___repr__.st = 4

# Generated at 2022-06-25 15:20:20.741998
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(0) == 0
    assert type_repr(1) == 1
    assert type_repr(10) == 10
    assert type_repr(-1) == -1
    assert type_repr(-10) == -10
    assert type_repr(100000) == 100000
    assert type_repr(-100000) == -100000


# Generated at 2022-06-25 15:20:25.743164
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pattern = WildcardPattern(([Leaf(token.COMMA, ","), Name()],))
    leaf_1 = Leaf(1, "one")
    leaf_2 = Leaf(token.COMMA, ",")
    leaf_3 = Leaf(3, "two")
    node_1 = Node(2, [leaf_1, leaf_2, leaf_3])
    assert pattern.match_seq([leaf_2]) == True
    assert pattern.match_seq([leaf_1, leaf_2, leaf_3]) == True
    assert pattern.match_seq([leaf_2, leaf_3]) == False
    assert pattern.match_seq([node_1]) == False


# Generated at 2022-06-25 15:20:29.353226
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    obj = BasePattern()
    base_0 = obj.optimize()


# Generated at 2022-06-25 15:20:32.166727
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(1, [])
    node.set_child(0, 1)
    node.set_child(0, None)
    node.set_child(0, node)


# Generated at 2022-06-25 15:20:32.864558
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_pattern_0 = BasePattern()

# Generated at 2022-06-25 15:20:35.355220
# Unit test for method post_order of class Base
def test_Base_post_order():
    # assert not hasattr(Base, 'post_order')
    # Base.post_order()
    assert False # TODO: implement your test here


# Generated at 2022-06-25 15:20:36.766172
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    basePattern_0 = BasePattern()
    assert basePattern_0.optimize() is basePattern_0

# Generated at 2022-06-25 15:20:40.332699
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    assert base_0.get_suffix() is None
