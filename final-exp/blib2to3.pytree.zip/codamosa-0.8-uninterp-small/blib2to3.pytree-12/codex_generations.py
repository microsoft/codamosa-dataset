

# Generated at 2022-06-25 15:13:09.381467
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    class NodePattern_0(NodePattern):
        def optimize(self):
            return LeafPattern(0, "")

    wildcard_pattern_0 = WildcardPattern()
    class NodePattern_1(NodePattern):
        def optimize(self):
            return LeafPattern(0, "")

    wildcard_pattern_1 = WildcardPattern(None, 1, 1)
    assert not isinstance(wildcard_pattern_1, NodePattern)
    wildcard_pattern_0 = WildcardPattern(name="bare_name")
    assert wildcard_pattern_0.content is not None
    node_pattern_0 = NodePattern(256, [])
    wildcard_pattern_2 = WildcardPattern(node_pattern_0.content)
    wildcard_pattern_3 = WildcardPattern(node_pattern_0.content, 1, 1)


# Generated at 2022-06-25 15:13:10.248425
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    test_case_0()


# Generated at 2022-06-25 15:13:15.791056
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_a = Node(0, [])
    node_a.post_order()
    node_a.post_order()  # Get Iterator
    node_a.post_order()  # Get Iterator
    node_a.post_order()  # Get Iterator
    node_a.post_order()  # Get Iterator
    node_a.post_order()  # Get Iterator


# Generated at 2022-06-25 15:13:17.411119
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    pass


# Generated at 2022-06-25 15:13:20.101108
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node_0 = Node()
    assert node_0.__repr__() == "Node(None, [])"


# Generated at 2022-06-25 15:13:31.764971
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    # Construct an instance of Node
    # The following try/except statement is used for unit test
    # initialization. You do not need to understand the details.
    try:
        type_0 = 'type_0'
        children_0 = ['children_0']
        context_0 = 'context_0'
        prefix_0 = 'prefix_0'
        fixers_applied_0 = 'fixers_applied_0'
        node_0 = Node(type_0, children_0, context_0, prefix_0, fixers_applied_0)
    except:
        node_0 = None
    # The following try/except statement is used for unit test
    # initialization. You do not need to understand the details.

# Generated at 2022-06-25 15:13:32.986056
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    assert_equal(Base().pre_order(), None)


# Generated at 2022-06-25 15:13:36.858533
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    pattern_0 = BasePattern()
    nodes_0 = []
    pattern_0.generate_matches(nodes_0)


# Generated at 2022-06-25 15:13:43.667540
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    negated_pattern_1 = NegatedPattern()
    node_2 = Node(5, [])
    node_3 = Node(4, [])
    def f_4(results):
        return (results)

    res_5 = negated_pattern_1.generate_matches([node_2, node_3])
    assert isinstance(next(res_5), tuple)
    assert next(res_5) == (2, {})
    try:
        next(res_5)
    except StopIteration:
        pass
    else:
        assert False and "Wrong test"



# Generated at 2022-06-25 15:13:46.159617
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    negated_pattern_0 = NegatedPattern()


# Generated at 2022-06-25 15:14:43.967603
# Unit test for method post_order of class Node

# Generated at 2022-06-25 15:14:48.015695
# Unit test for method replace of class Base
def test_Base_replace():
    pattern_0 = Base()
    pattern_0.replace(pattern_0) or pattern_0.replace(pattern_0)
    pattern_0.replace(pattern_0.children) or pattern_0.replace(pattern_0.children)



# Generated at 2022-06-25 15:14:57.206866
# Unit test for method depth of class Base
def test_Base_depth():

    # Create a new node that is a first child of a parent node
    firstChild = Base()
    parent = Base()
    children = [firstChild]
    parent.children = parent.children + children

    # Create a new node that is a second child of a parent node
    secondChild = Base()
    children = [secondChild]
    parent.children = parent.children + children

    # Create a new node that is a third child of the parent node
    thirdChild = Base()
    children = [thirdChild]
    parent.children = parent.children + children

    # Check that each child's depth is 1
    assert firstChild.depth() == 1
    assert secondChild.depth() == 1
    assert thirdChild.depth() == 1

    # Check that each child's parent's depth is 2
    assert parent.depth() == 2

    # Check that

# Generated at 2022-06-25 15:15:00.926186
# Unit test for method post_order of class Node
def test_Node_post_order():
    children = []
    children.append(Leaf(value="j"))
    children.append(Leaf(value="j"))
    node = Node(type=1, children=children)
    for child in node.post_order():
        print(child)


# Generated at 2022-06-25 15:15:01.802584
# Unit test for method post_order of class Base
def test_Base_post_order():
    test_case_0()


# Generated at 2022-06-25 15:15:03.834778
# Unit test for method depth of class Base
def test_Base_depth():
    test_case_0()
    node_0 = Node()
    node_0.parent = node_0
    assert node_0.depth() == 0


# Generated at 2022-06-25 15:15:07.613313
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    type = 256
    content = "test_content"
    name = "test_name"
    node_pattern_0 = NodePattern(256, test_content, test_name)
    assert repr(node_pattern_0) == "NodePattern(test_name)"


# Generated at 2022-06-25 15:15:09.713560
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    test_Leaf = Leaf(0, "x")
    test_Leaf.post_order()


# Generated at 2022-06-25 15:15:14.503481
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    # Test case 0
    L = globals()["Leaf"]
    negated_pattern_0 = L(1, '1')
    expected_0 = ['1']
    actual_0 = negated_pattern_0.leaves()
    assert expecting(actual_0, expected_0)

    return



# Generated at 2022-06-25 15:15:16.570628
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    pattern_0 = Node()
    pattern_0.update_sibling_maps()


# Generated at 2022-06-25 15:16:04.164833
# Unit test for method remove of class Base
def test_Base_remove():
    context_0 = Context()
    context_1 = Context()
    context_2 = Context()
    context_3 = Context()
    context_4 = Context()
    context_5 = Context()
    node_0 = Base(context_0, children=[
        Node(context_1, children=[
            Leaf(context_2),
            Leaf(context_3)
        ]),
        Node(context_4, children=[
            Leaf(context_5)
        ]) ])
    Base.children = [
        Node(context_0, children=[
            Leaf(context_1),
            Leaf(context_2)
        ]),
        Node(context_3, children=[
            Leaf(context_4)
        ]) ]

# Generated at 2022-06-25 15:16:06.748896
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == "NAME"
    assert type_repr(56) == 56

# End unit test

# This class is just for documentation purposes

# Generated at 2022-06-25 15:16:10.384868
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    contents = [[]]
    min = 0
    max = 100
    name = "name"
    wild = WildcardPattern(contents, min, max, name)
    w2 = wild.optimize()
    assert w2.content is None
    assert w2.min == 0
    assert w2.max == 100
    assert w2.name == "name"


# Generated at 2022-06-25 15:16:12.962552
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    pattern_0 = BasePattern()
    nodes_0 = [fake_node_0]
    results_0 = {}
    assert not pattern_0.match_seq(nodes_0, results_0)


# Generated at 2022-06-25 15:16:15.317947
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    expected = "base_pattern(test, foo, bar)"
    object_0 = BasePattern("test", "foo", "bar")
    result = object_0.__repr__()
    assert result == expected


# Generated at 2022-06-25 15:16:17.083512
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    pattern_0 = BasePattern()
    nodes_0 = []
    results_0 = {}
    result = pattern_0.match_seq(nodes_0, results_0)
    assert False == result


# Generated at 2022-06-25 15:16:26.595846
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    result1 = []
    result2 = []
    result3 = []
    result4 = []
    result5 = []

    # Test case with content None and no name given
    try:
        import nl
    except ImportError:
        return
    p = WildcardPattern()
    # Result is a generator, so must consume it before we can test it
    for c, r in p.generate_matches([nl.Node(type=15, children=[nl.Leaf(type=1, value='a')])]):
        result1.append((c, r))
    assert result1 == [(1, {})]
    p = WildcardPattern(min=0, max=1000)

# Generated at 2022-06-25 15:16:33.283726
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    pattern_0 = LeafPattern(4)
    pattern_0.generate_matches([])
    pattern_1 = LeafPattern(4, "hi")
    pattern_1.generate_matches([])
    pattern_2 = NodePattern(5)
    pattern_2.generate_matches([])
    pattern_3 = NodePattern(5, "hi")
    pattern_3.generate_matches([])


# Generated at 2022-06-25 15:16:37.732414
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_0 = Leaf(0, "")
    # try calling the method of Leaf
    result_0 = leaf_0.pre_order()
    # then check its result
    if (result_0 != leaf_0):
        print("Error in Leaf.pre_order. Leaf.pre_order returned \
{}, but should have returned {}".format(result_0, leaf_0))


# Generated at 2022-06-25 15:16:40.656582
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    negated_pattern_0 = NegatedPattern()
    # Test function is not yet defined.
    try:
        negated_pattern_0.get_suffix()
    except NotImplementedError:
        pass



# Generated at 2022-06-25 15:18:43.653819
# Unit test for function type_repr
def test_type_repr():
    from .pgen2 import token
    from .pygram import python_symbols

    for name in dir(python_symbols):
        val = getattr(python_symbols, name)
        if type(val) == int:
            assert type_repr(val) is name
    for name in dir(token):
        val = getattr(token, name)
        if type(val) == int:
            assert type_repr(val) is name


# Generated at 2022-06-25 15:18:44.179541
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    pass



# Generated at 2022-06-25 15:18:46.863637
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # Nodes that have one child should return their child's lineno
    assert Base().get_lineno() is None

    leaf_1 = Leaf(1, "text")
    leaf_1.lineno = 2
    node_1 = Node(257, [leaf_1])
    assert node_1.get_lineno() == 2


# Generated at 2022-06-25 15:18:50.757122
# Unit test for method clone of class Base
def test_Base_clone():
    try:
        Base().clone()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:18:52.682082
# Unit test for method set_child of class Node
def test_Node_set_child():
    n = Node(0, [])
    n.set_child(0, n)


# Generated at 2022-06-25 15:18:59.088420
# Unit test for method post_order of class Base

# Generated at 2022-06-25 15:19:02.049351
# Unit test for method leaves of class Base
def test_Base_leaves():
    arg0 = Node()
    arg1 = Leaf()
    arg0.children = [arg1]

    res = arg0.leaves()
    assert isinstance(res, Iterator)


# Generated at 2022-06-25 15:19:04.120351
# Unit test for method remove of class Base
def test_Base_remove():
    Base_instance_0 = Base()
    Base_instance_0.remove()
    Base_instance_1 = Base()
    Base_instance_1.remove()

# Generated at 2022-06-25 15:19:05.281983
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    _Base = Base()
    value = _Base.get_suffix()

# Generated at 2022-06-25 15:19:15.211909
# Unit test for function convert
def test_convert():
    gr = Grammar()
    #  Function that creates a new instance of the node class
    def node_class(type: int, children: List[NL]) -> NL:
        return Node(type, children)

    #  Production initialization
    gr.add_production('compound_stmt', ('if_stmt',))
    gr.add_production('compound_stmt', ('while_stmt',))
    gr.add_production('compound_stmt', ('for_stmt',))
    gr.add_production('compound_stmt', ('try_stmt',))
    gr.add_production('compound_stmt', ('with_stmt',))
    gr.add_production('compound_stmt', ('funcdef',))
    gr.add_production('compound_stmt', ('classdef',))
