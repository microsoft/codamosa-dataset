

# Generated at 2022-06-25 15:13:15.815997
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    leaf_wildcard_pattern_0 = LeafPattern()
    # print(leaf_wildcard_pattern_0)
    leaf_wildcard_pattern_0.optimize()
    # print(leaf_wildcard_pattern_0)
    node_pattern_0 = NodePattern()
    # print(node_pattern_0)
    node_pattern_0.optimize()
    # print(node_pattern_0)
    wildcard_pattern_0 = WildcardPattern()
    # print(wildcard_pattern_0)
    wildcard_pattern_0.optimize()
    # print(wildcard_pattern_0)
    wildcard_pattern_1 = WildcardPattern()
    # print(wildcard_pattern_1)
    wildcard_pattern_1.optimize()
    # print(wildcard_pattern_1)



# Generated at 2022-06-25 15:13:25.547355
# Unit test for method replace of class Base
def test_Base_replace():
    leaf_pattern_1 = LeafPattern()
    leaf_pattern_2 = LeafPattern()
    leaf_pattern_3 = LeafPattern()
    leaf_pattern_4 = LeafPattern()
    leaf_pattern_1.replace(leaf_pattern_3)
    leaf_pattern_2.replace([leaf_pattern_1, leaf_pattern_4])
    leaf_pattern_4.replace(leaf_pattern_1)
    leaf_pattern_1.replace([leaf_pattern_2, leaf_pattern_3])
    leaf_pattern_3.replace(leaf_pattern_2)


# Generated at 2022-06-25 15:13:27.696703
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    with pytest.raises(NotImplementedError):
        Node(0, []).pre_order()


# Generated at 2022-06-25 15:13:29.117683
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    n = Node(0, [])
    n.__eq__(0)



# Generated at 2022-06-25 15:13:40.525047
# Unit test for method remove of class Base
def test_Base_remove():
    n = Node(python_symbols.expr_stmt, [Leaf(1), Leaf(1), Leaf(1)])
    n_parent = Node(python_symbols.file_input, [n])
    n.parent = n_parent
    n_parent.changed()
    assert n_parent.children == [n]
    assert n_parent.was_changed
    assert n.parent == n_parent
    assert n.next_sibling == None
    assert n.prev_sibling == None
    assert n.remove() == 0
    assert n_parent.children == []
    assert n.parent == None
    assert n_parent.was_changed
    assert n.next_sibling == None
    assert n.prev_sibling == None
    assert n.remove() == None


# Generated at 2022-06-25 15:13:48.504347
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    node1 = Node(1, None, None, [])
    node2 = Node(2, None, None, [])
    leaf = Leaf(1, "prefix", (1, 2))
    assert node1.get_lineno() is None
    assert node2.get_lineno() is None
    assert leaf.get_lineno() == 1
    node1.children = [leaf]
    node2.children = [node1]
    assert node1.get_lineno() == 1
    assert node2.get_lineno() == 1
    assert leaf.get_lineno() == 1


# Generated at 2022-06-25 15:13:50.143727
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    leaf_pattern_0 = LeafPattern()
    leaf_0 = Leaf(0, "")
    leaf_1 = leaf_0.clone()
    assert leaf_0 == leaf_1


# Generated at 2022-06-25 15:13:53.342235
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():

    test_Leaf = Leaf(1, "test_value")
    test_leaves = test_Leaf.leaves()

    if (test_leaves.__next__() == test_Leaf):
        print(True)


# Generated at 2022-06-25 15:13:57.222292
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    root = Node(3, [Node(4, [Leaf(0, ":")]), Leaf(2, "pass")])
    assert list(root.pre_order())[0] is root


# Generated at 2022-06-25 15:13:58.488456
# Unit test for method depth of class Base
def test_Base_depth():
    node = Node('test', [])
    node.depth()


# Generated at 2022-06-25 15:14:38.858482
# Unit test for method post_order of class Node
def test_Node_post_order():
    child_00 = test_case_0()
    child_01 = test_case_1()
    child_02 = test_case_2()
    children = [child_00]
    node = Node(type_, children)
    for i in node.post_order() :
        print(i)


# Generated at 2022-06-25 15:14:41.170887
# Unit test for method remove of class Base
def test_Base_remove():
    node = Base()
    node.children = None
    node.parent = None
    assert node.remove() is None


# Generated at 2022-06-25 15:14:43.841455
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    '''
    test_Leaf_pre_order
    '''
    # Create test object and test pre_order method
    test_object = Leaf(token.NAME,"test_Leaf_pre_order",context=None)
    test_object.parse_tree_to_file("test_Leaf_pre_order.txt")


# Generated at 2022-06-25 15:14:49.688547
# Unit test for function type_repr
def test_type_repr():
    # print(type_repr(1))
    assert type_repr(1) == "NAME"
    # print(type_repr(2))
    assert type_repr(2) == "NUMBER"
    # print(type_repr(3))
    assert type_repr(3) == "STRING"
    # print(type_repr(4))


# Generated at 2022-06-25 15:14:57.459008
# Unit test for method post_order of class Base
def test_Base_post_order():
    tree = Node(0, [Leaf(1, 'a'), Node(2, [Leaf(3, 'b'), Leaf(4, 'c')]), Leaf(5, 'd')])
    actual = list(tree.post_order())
    expected = [Leaf(1, 'a'), Leaf(3, 'b'), Leaf(4, 'c'), Node(2, [Leaf(3, 'b'), Leaf(4, 'c')]), Leaf(5, 'd'), Node(0, [Leaf(1, 'a'), Node(2, [Leaf(3, 'b'), Leaf(4, 'c')]), Leaf(5, 'd')])]
    assert actual == expected

# Generated at 2022-06-25 15:15:05.594822
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    leaf_pattern_1 = LeafPattern(value_re=r"\s+")
    leaf_pattern_2 = LeafPattern(value_re=r"\s+")
    leaf_pattern_3 = LeafPattern(value_re=r"\s*#.*\n")
    leaf_pattern_4 = LeafPattern(value_re=r"\s+")
    leaf_pattern_5 = LeafPattern(value_re=r"\s+")
    leaf_pattern_6 = LeafPattern(value_re=r"\s+")
    leaf_pattern_7 = LeafPattern(value_re=r"\s*#.*\n")
    leaf_pattern_8 = LeafPattern(value_re=r"\s+")
    leaf_pattern_9 = LeafPattern(value_re=r"\s+")
    Leaf

# Generated at 2022-06-25 15:15:16.525718
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_0 = Node(0, [], [])
    iter_0 = node_0.pre_order()
    if next(iter_0) is not node_0:
        raise TestFailure(
            "Node.pre_order test failed, expected "
            + "node_0 to yield itself as the first element of the iterator"
        )

    if next(iter_0) is not None:
        raise TestFailure(
            "Node.pre_order test failed, expected "
            + "node_0 to yield None as the second element of the iterator"
        )

    if next(iter_0) is not None:
        raise TestFailure(
            "Node.pre_order test failed, expected None as the third element"
        )


# Generated at 2022-06-25 15:15:20.208417
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    leaf_0 = Leaf()
    leaf_1 = Leaf()
    leaf_pattern_0 = LeafPattern()
    leaf_pattern_0.add(leaf_0, leaf_1)
    node_pattern_0 = NodePattern(leaf_pattern_0)
    leaf_pattern_1 = LeafPattern()
    leaf_pattern_1.add(leaf_0)
    leaf_pattern_2 = LeafPattern()
    leaf_pattern_2.add(leaf_1)
    node_pattern_1 = NodePattern(leaf_pattern_0, leaf_pattern_1, leaf_pattern_2)


# Generated at 2022-06-25 15:15:30.798908
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern(["a", "b", "c"])
    assert p.match_seq(["a", "b", "c"])
    assert not p.match_seq(["a", "b", "c", "d"])
    p = WildcardPattern(["a", "b", "c"], min=1, max=3)
    assert p.match_seq(["a", "b", "c"])
    assert not p.match_seq(["a", "b", "c", "d"])
    p = WildcardPattern(["a", "b", "c"], min=1)
    assert p.match_seq(["a", "b", "c"])
    assert p.match_seq(["a", "b", "c", "d"])

# Generated at 2022-06-25 15:15:32.205921
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_case_0()


# Generated at 2022-06-25 15:16:29.543030
# Unit test for method remove of class Base
def test_Base_remove():
    if __name__ == "__main__":
        test_nodes = [Leaf, Node]
        local_parent = Node()
        for test_node in test_nodes:
            local_child = test_node()
            local_child.parent = local_parent

            local_parent.children = [local_child]
            local_child.remove()

            assert local_child.parent is None
            assert local_parent.children == []


# Generated at 2022-06-25 15:16:35.639373
# Unit test for method remove of class Base
def test_Base_remove():
    print("Testing method 'remove' of class 'Base'...")
    leaf_pattern_0 = LeafPattern()
    print("Checking if raising error when trying to remove a node that has no parent...")
    try:
        leaf_pattern_0.remove()
    except:
        print("It raised.")
    print("Testing done.")



# Generated at 2022-06-25 15:16:38.620745
# Unit test for method replace of class Base
def test_Base_replace():
    root_pattern_0 = NodePattern()
    leaf_pattern_0 = LeafPattern(parent=root_pattern_0)
    leaf_pattern_0.replace(new=leaf_pattern_1)


# Generated at 2022-06-25 15:16:45.367222
# Unit test for function generate_matches

# Generated at 2022-06-25 15:16:55.523313
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p1 = WildcardPattern(content=[[LeafPattern(type=NUMBER)]], min=0, max=1)
    p1 = p1.optimize()
    assert p1.content == ([(LeafPattern(type=NUMBER),)],)
    assert p1.min == 0
    assert p1.max == 1

    p2 = WildcardPattern(content=[[LeafPattern(type=NAME)]], min=1, max=1)
    p2 = p2.optimize()
    assert p2.content == None
    assert p2.min == 1
    assert p2.max == 1

    p3 = WildcardPattern(content=[[WildcardPattern(content=[[LeafPattern(type=NUMBER)]], min=0, max=1)]], min=1, max=1)
    p3 = p

# Generated at 2022-06-25 15:17:01.600903
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Local variables:
    nodes = []
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    # Setup
    nodes.append(node_pattern_0)
    nodes.append(node_pattern_1)
    # Test
    # Method generate_matches, line 325
    assert True


# Generated at 2022-06-25 15:17:05.183619
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    Node_instance_0 = Node(256, [])
    # AssertionError: Node('python_symbols.NAME', []) != "Node(257, '[]')"
    assert repr(Node_instance_0) == "Node(257, '[]')"


# Generated at 2022-06-25 15:17:08.313499
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base = Base()
    base.post_order = MagicMock(return_value=iter(['a', 'b', 'c']))
    assert list(base.pre_order()) == ['a', 'b', 'c']


# Generated at 2022-06-25 15:17:10.310603
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_0 = Base()
    result = base_0.get_lineno()
    assert result is None


# Generated at 2022-06-25 15:17:10.831865
# Unit test for function type_repr
def test_type_repr(): assert type_repr(1) == "NAME"

# Generated at 2022-06-25 15:17:31.464747
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_pattern_0 = LeafPattern()
    nl_0 = NodePattern()
    nl_0.post_order()
    leaf_pattern_0.post_order()


# Generated at 2022-06-25 15:17:41.864154
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == "NAME"
    assert type_repr(2) == "NUMBER"
    assert type_repr(3) == "STRING"
    assert type_repr(4) == "NEWLINE"
    assert type_repr(5) == "INDENT"
    assert type_repr(6) == "DEDENT"
    assert type_repr(7) == "ENDMARKER"
    assert type_repr(8) == "LPAR"
    assert type_repr(9) == "RPAR"
    assert type_repr(10) == "LSQB"
    assert type_repr(11) == "RSQB"
    assert type_repr(12) == "COLON"
    assert type_repr(13) == "COMMA"

# Generated at 2022-06-25 15:17:48.728123
# Unit test for method post_order of class Base
def test_Base_post_order():
    test = Leaf('type', 'TEST', (1, 1), 'prefix')
    leaf_pattern_0 = LeafPattern()
    leaf_pattern_1 = LeafPattern(leaf_pattern_0, test)

    leaf_pattern_2 = LeafPattern(
        leaf_pattern_1, type_ = test.type, value = None, context = None, prefix = None
    )
    # BEGIN FOR LOOP
    for i in leaf_pattern_2.post_order():
        pass
    # END FOR LOOP


# Generated at 2022-06-25 15:17:49.872711
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    test_case_0()


# Generated at 2022-06-25 15:17:51.470061
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 15:17:53.677933
# Unit test for method clone of class Base
def test_Base_clone():
    class BaseB:
        pass
    base_b = BaseB()
    base_clone = base_b.clone()
    assert base_clone is None


# Generated at 2022-06-25 15:18:03.278862
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # (1)
    leaf_pattern_0 = LeafPattern()
    leaf_pattern_0._eq()
    # (2)
    leaf_pattern_1 = LeafPattern()
    leaf_pattern_1._eq(True)
    # (3)
    leaf_pattern_2 = LeafPattern()
    leaf_pattern_2._eq("")
    # (4)
    leaf_pattern_3 = LeafPattern()
    leaf_pattern_3._eq("")
    # (5)
    leaf_pattern_4 = LeafPattern()
    leaf_pattern_4._eq(None)
    # (6)
    leaf_pattern_5 = LeafPattern()
    leaf_pattern_5._eq(None)
    # (7)
    leaf_pattern_6 = LeafPattern()
    leaf_pattern_6._eq(None)


# Generated at 2022-06-25 15:18:14.219419
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    leaf_pattern_0 = LeafPattern()
    leaf_1 = Leaf(1, "", (0, 0), [])
    leaf_2 = Leaf(2, "", (1, 1), [])
    leaf_3 = Leaf(3, "", (0, 0), [])
    node_0 = Node(0, None, [], True, False)
    node_0.children = [leaf_1, leaf_2]
    node_0.parent = node_3
    node_0.prev_sibling = leaf_3
    leaf_1.parent = node_0
    leaf_1.prev_sibling = leaf_2
    leaf_2.parent = node_0
    node_3.children = [node_0, leaf_3]
    node_3.parent = node_0

# Generated at 2022-06-25 15:18:18.874628
# Unit test for function generate_matches
def test_generate_matches():
    data = [0, 1, 2, 3]
    data_tuple = tuple(data)

    # Test iterable sequence type
    patterns = (LeafPattern(), NodePattern(), WildcardPattern())
    results = generate_matches(patterns, data)
    assert next(results) == (1, {})
    results = generate_matches(patterns, data_tuple)
    assert next(results) == (1, {})

    # Test for non-empty sequence of patterns and nodes
    results = generate_matches([LeafPattern(), NodePattern()], data)
    assert next(results) == (1, {})
    assert next(results) == (2, {})

    # Test for empty sequence of patterns and nodes
    results = generate_matches([], data)
    assert next(results) == (0, {})


# Generated at 2022-06-25 15:18:24.033372
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    leaf_pattern_0 = LeafPattern()
    assert 'LeafPattern()' == leaf_pattern_0.__repr__()
    leaf_pattern_1 = LeafPattern(0)
    assert 'LeafPattern(0)' == leaf_pattern_1.__repr__()
    leaf_pattern_2 = LeafPattern(0, 'a', 'b')
    assert 'LeafPattern(0, \'a\', \'b\')' == leaf_pattern_2.__repr__()



# Generated at 2022-06-25 15:19:23.169575
# Unit test for method clone of class Base
def test_Base_clone():
    leaf_pattern_0 = LeafPattern()
    cloned = leaf_pattern_0.clone()
    assert cloned.__class__ is LeafPattern, repr(cloned.__class__)


# Generated at 2022-06-25 15:19:31.438124
# Unit test for function generate_matches
def test_generate_matches():
    assert list(generate_matches([], [])) == [(0, {})]
    assert list(generate_matches([LeafPattern()], [])) == []
    assert list(generate_matches(
        [NodePattern(content=[LeafPattern()])], [])) == []
    assert list(generate_matches([NodePattern(content=[LeafPattern()])],
        [Leaf(None, "")])) == [(1, {})]
    # tests from bug 1341870
    assert list(generate_matches([LeafPattern(name='test')],
        [Leaf(None, 'test')])) == [(1, {'test': [Leaf(None, 'test')]})]

# Generated at 2022-06-25 15:19:35.952063
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Create the root node
    root = Node(0, [Leaf(1, "def"), Leaf(1, " "), Node(1, [Leaf(1, "test_func")]), Leaf(1, ":")])
    # Call method post_order of class Base on root
    result = list(root.post_order())
    assert len(result) == 7
    assert all(isinstance(x, (Node, Leaf)) for x in result)


# Generated at 2022-06-25 15:19:45.982172
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf1 = Leaf(token.NAME, 'abc')
    leaf2 = Leaf(token.NAME, 'def')
    leaf3 = Leaf(token.NAME, 'ghi')
    node_pattern = NodePattern(list_of_children=[leaf1, leaf2, leaf3])
    list_nodes_pre_order = list(node_pattern.pre_order())
    assert(list_nodes_pre_order[0].value == 'abc')
    assert(list_nodes_pre_order[1].value == 'def')
    assert(list_nodes_pre_order[2].value == 'ghi')


# Generated at 2022-06-25 15:19:53.330348
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # leaf_pattern_0 = LeafPattern()
    # leaf_pattern_0 = LeafPattern(None)
    leaf_pattern_0 = LeafPattern(None, None, None, None)
    # leaf_pattern_1 = LeafPattern()
    # leaf_pattern_1 = LeafPattern(None)
    leaf_pattern_1 = LeafPattern(None, None, None, None)
    var_0 = leaf_pattern_0 == leaf_pattern_1
    var_1 = False
    assert var_0 == var_1


# Generated at 2022-06-25 15:19:56.651907
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    node = Leaf(1, "")
    assert isinstance(node.pre_order(), Iterator)
    node_list = list(node.pre_order())
    assert len(node_list) == 1
    assert isinstance(node_list[0], Leaf)


# Generated at 2022-06-25 15:20:03.317799
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_pattern_0 = LeafPattern()
    leaf_pattern_1 = LeafPattern()
    leaf_pattern_2 = LeafPattern()
    leaf_pattern_3 = LeafPattern()
    leaf_pattern_4 = LeafPattern()
    leaf_pattern_5 = LeafPattern()
    leaf_pattern_6 = LeafPattern()
    leaf_pattern_7 = LeafPattern()
    leaf_pattern_8 = LeafPattern()
    leaf_pattern_9 = LeafPattern()
    node_pattern_0 = NodePattern([leaf_pattern_1, leaf_pattern_2, leaf_pattern_3])
    leaf_pattern_10 = LeafPattern()
    leaf_pattern_11 = LeafPattern()
    leaf_pattern_12 = LeafPattern()
    leaf_pattern_13 = LeafPattern()
    leaf_pattern_14 = LeafPattern()
    node_pattern_

# Generated at 2022-06-25 15:20:08.391114
# Unit test for method remove of class Base
def test_Base_remove():
    # Setup
    leaf_pattern_0 = LeafPattern()

    # Verify
    assert leaf_pattern_0.remove() is None


# Generated at 2022-06-25 15:20:13.350273
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    leaf_pattern_0 = LeafPattern()
    node_pattern_1 = NodePattern()
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_1 = WildcardPattern()
    base_pattern_0 = WildcardPattern()
    base_pattern_1 = WildcardPattern()
    base_pattern_2 = WildcardPattern()
    base_pattern_3 = WildcardPattern()
    base_pattern_4 = WildcardPattern()
    base_pattern_5 = WildcardPattern()



# Generated at 2022-06-25 15:20:15.722721
# Unit test for method clone of class Base
def test_Base_clone():
    leaf_pattern_0 = LeafPattern()
    leaf_pattern_1 = leaf_pattern_0.clone()
    assert leaf_pattern_1 == leaf_pattern_0


# Generated at 2022-06-25 15:21:27.517750
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    m_1 = NodePattern()
    m_2 = NodePattern()
    result_1 = m_1._eq(m_2)
    assert result_1
    result_2 = m_2._eq(m_1)
    assert result_2


# Generated at 2022-06-25 15:21:38.813065
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():

    # Base case for the recursive method
    assert WildcardPattern().optimize() == WildcardPattern(min=1, max=1)

    # Base case for the recursive method

    assert WildcardPattern(min=1, max=1).optimize() == WildcardPattern(min=1, max=1)

    # Inductive case for the recursive method
    assert WildcardPattern(min=1, max=HUGE, content=((WildcardPattern(min=1, max=1),),)).optimize() == \
        WildcardPattern(min=1, max=HUGE, content=((WildcardPattern(min=1, max=1),),))

    # Inductive case for the recursive method