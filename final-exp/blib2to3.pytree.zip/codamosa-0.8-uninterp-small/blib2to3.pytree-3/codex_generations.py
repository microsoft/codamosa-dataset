

# Generated at 2022-06-25 15:14:01.249542
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.print_stmt) == "print_stmt"
    assert type_repr(38) == 38

_short_type_reprs: Dict[int, Union[Text, int]] = {}


# Generated at 2022-06-25 15:14:09.898617
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Arguments to constructor.
    node_pattern_0 = NodePattern(type_=13, children=(), prefix='', context=())
    # Field values to compare.
    type_0 = 13
    children_0 = ()
    prefix_0 = ''
    # Actual results.
    result_0 = node_pattern_0.__eq__(type_0)
    result_1 = node_pattern_0.__eq__(children_0)
    result_2 = node_pattern_0.__eq__(prefix_0)
    # Expected results.
    expected_0 = NotImplemented
    expected_1 = NotImplemented
    expected_2 = NotImplemented
    # Test method.

# Generated at 2022-06-25 15:14:19.191583
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    for _i in range(1000):
        node_pattern_0 = NodePattern()
        node_pattern_1 = NodePattern()
        node_pattern_2 = NodePattern()

        # Call method __repr__ of node_pattern_0 and check its result
        if node_pattern_0.__repr__() != "NodePattern(None, None, None)":
            print("Error: node_pattern_0.__repr__() == \"%s\" instead of \"%s\"" % (node_pattern_0.__repr__(), "NodePattern(None, None, None)"))
            return False

        # Call method __repr__ of node_pattern_1 and check its result

# Generated at 2022-06-25 15:14:22.720801
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    node_pattern_0 = NodePattern()
    node_pattern_0.type = 258
    node_pattern_0.content = None
    node_pattern_0.name = None
    expected_result_0 = "NodePattern(258, None, None)"
    actual_result_0 = node_pattern_0.__repr__()
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-25 15:14:31.775979
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # Testcase 1
    stmt = [Leaf(1, 'x = y + z'),
            Leaf(59, '\n'),
            Leaf(1, 'x = y + z'),
            Leaf(59, '\n'),
            Leaf(1, 'x = y + z')]
    pat = WildcardPattern(None, 0, HUGE, 'stmt_list')
    c, r = next(pat.generate_matches(stmt))
    assert c == len(stmt)
    assert r['stmt_list'] == stmt
    # Testcase 2

# Generated at 2022-06-25 15:14:40.317155
# Unit test for method replace of class Base
def test_Base_replace():
    from .pygram import Grammar, python_symbols as syms
    from .pytree import Leaf
    from .pgen2 import token

    g = Grammar(StringIO(''))

    def assert_replace(node, replacement, expected):
        node.replace(replacement)
        assert node.parent is None
        assert node.children == []
        assert node.prefix == ''
        assert expected == node.parent.children

    n = Node(syms.expr_stmt, [
        Leaf(token.NAME, 'a'),
        Leaf(token.EQUAL, '='),
        Leaf(token.NUMBER, '1')])

    assert_replace(n, None, [])

    assert_replace(n, [], [])


# Generated at 2022-06-25 15:14:41.977665
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(123, "hello world")
    assert [l] == list(l.pre_order())


# Generated at 2022-06-25 15:14:45.387690
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_node = Node(int, list)
    post_order_iterable = node_node.post_order()



# Generated at 2022-06-25 15:14:55.040546
# Unit test for method replace of class Base
def test_Base_replace():
    # Test case 1
    node_pattern_0 = NodePattern()
    node_pattern_0.subnodes = ((262, None, None, (269, None, None, ())),)
    node_pattern_0.symbol = 263
    node_pattern_0.subpatterns = (
        '"if" test "else" ":" suite',
    )
    node_pattern_0.type = 262
    node_pattern_0.value = 'suite'
    node_pattern_1 = NodePattern()
    node_pattern_1.subnodes = ((262, None, None, (269, None, None, ())),)
    node_pattern_1.symbol = 263
    node_pattern_1.subpatterns = (
        '"if" test "else" ":" suite',
    )
    node_pattern

# Generated at 2022-06-25 15:14:55.697136
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(0) == 0


# Generated at 2022-06-25 15:15:14.678653
# Unit test for function type_repr
def test_type_repr():
    """test_type_repr()"""
    node_pattern_0 = NodePattern()
    testing_0 = type_repr(testing_0)
    if "FAILED" in testing_0:
        print("Error, type_repr()")
    else:
        print("Success, type_repr()")


# Generated at 2022-06-25 15:15:24.058241
# Unit test for function generate_matches
def test_generate_matches():
    generate_matches()
    str = ''
    node_pattern_1 = NodePattern()
    node_pattern_2 = NodePattern()
    node_pattern_3 = NodePattern()
    node_pattern_4 = NodePattern()
    node_pattern_5 = NodePattern()
    node_pattern_6 = NodePattern()
    node_pattern_7 = NodePattern()
    node_pattern_8 = NodePattern()
    node_pattern_9 = NodePattern()
    node_pattern_10 = NodePattern()
    node_pattern_11 = NodePattern()
    node_pattern_12 = NodePattern()
    node_pattern_13 = NodePattern()
    node_pattern_14 = NodePattern()
    node_pattern_15 = NodePattern()
    node_pattern_16 = NodePattern()
    node_pattern_17 = NodePattern()


# Generated at 2022-06-25 15:15:26.218691
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    n_0 = 0
    node_pattern_0 = NodePattern()
    n_1 = 0
    for n_2 in node_pattern_0.generate_matches(n_1):
        n_0 += n_2
    assert n_0 > 0


# Generated at 2022-06-25 15:15:37.301955
# Unit test for method leaves of class Base
def test_Base_leaves():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    node_pattern_0.children.append(node_pattern_1)
    node_pattern_2 = NodePattern()
    node_pattern_1.children.append(node_pattern_2)
    node_pattern_3 = NodePattern()
    node_pattern_2.children.append(node_pattern_3)
    leaf_pattern_0 = LeafPattern(None, None)
    node_pattern_3.children.append(leaf_pattern_0)
    leaf_pattern_1 = LeafPattern(None, None)
    node_pattern_2.children.append(leaf_pattern_1)
    leaf_pattern_2 = LeafPattern(None, None)
    node_pattern_1.children.append(leaf_pattern_2)
    leaf

# Generated at 2022-06-25 15:15:46.753317
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    assert WildcardPattern(None).match_seq([Leaf(token.NAME, "foo")])
    assert not WildcardPattern(None).match_seq([Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")])
    assert WildcardPattern([]).match_seq([])
    assert WildcardPattern([LeafPattern(token.NAME, "foo")]).match_seq([Leaf(token.NAME, "foo")])
    assert WildcardPattern([LeafPattern(token.NAME, "foo"), LeafPattern(token.NAME, "bar")]).match_seq(
      [Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")])

# Generated at 2022-06-25 15:15:49.303673
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_pattern_0 = NodePattern()
    for child in node_pattern_0.children:
        yield from child.post_order()
    yield node_pattern_0


# Generated at 2022-06-25 15:15:56.082604
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pygram import python_symbols
    from .pytree import Leaf, Node

    lineno = 0
    column = 0
    context = (None, (lineno, column))
    l_leaf = Leaf(37, None, context)
    l_leaf.changed()
    l_nodes = [l_leaf]
    l_node = Node(403, None, context, l_nodes)
    l_node2 = Node(403, None, context, l_nodes)
    l_nodes2 = [l_node, l_node2]
    l_node3 = Node(403, None, context, l_nodes2)
    l_nodes3 = [l_node3]
    l_node4 = Node(403, None, context, l_nodes3)

# Generated at 2022-06-25 15:16:01.044476
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    assert () == Node("a").pre_order()
    assert ("b", "c") == Node("a", ("b", "c")).pre_order()
    assert ("b", "c", "d", "e", "f") == Node("a", ("b",("c","d"),("e","f"))).pre_order()
    assert ("b", "c", "d", "e", "f") == Node("a", ("b",("e","c",("d","f")))).pre_order()



# Generated at 2022-06-25 15:16:02.121496
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    """This method has not been implemented. Please complete it."""
    pass



# Generated at 2022-06-25 15:16:03.903637
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_pattern_0 = BasePattern()
    assert base_pattern_0.__class__ is BasePattern


# Generated at 2022-06-25 15:16:25.617840
# Unit test for method leaves of class Base
def test_Base_leaves():
    if node_pattern_0.parent is None:
        return True

    if node_pattern_0.children is None:
        return True

    for child in node_pattern_0.children:
        if not isinstance(child, Leaf):
            return False

    return True



# Generated at 2022-06-25 15:16:29.839594
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    new_node = Node(1, None, None, [])
    next_sib = Leaf(1, "ABC", None, None)
    new_node.next_sibling = next_sib
    ret_val = new_node.get_suffix()
    #assert new_node.get_suffix() == "ABC"


# Class Leaf
# ==========

# Generated at 2022-06-25 15:16:30.718558
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    pass


# Generated at 2022-06-25 15:16:40.888360
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    node_pattern_0 = WildcardPattern(name='a')
    node_pattern_0.match_seq([Node(type=0, children=[Leaf(type=1, value=' ')])])
    node_pattern_1 = WildcardPattern()
    node_pattern_1.match_seq([Node(type=0, children=[Leaf(type=1, value=' ')])])
    node_pattern_2 = WildcardPattern(min=0, max=2, name='a')
    node_pattern_2.match_seq([Node(type=0, children=[Leaf(type=1, value=' ')])])
    node_pattern_3 = WildcardPattern(min=1, max=2, name='a')

# Generated at 2022-06-25 15:16:44.743675
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(1, [])
    child = Leaf(2, "")

    node.set_child(0, child)

    assert node.children[0] == child

    return



# Generated at 2022-06-25 15:16:48.317057
# Unit test for method set_child of class Node
def test_Node_set_child():
    node_pattern_1 = Node(type=0, children=[Node(type=1, children=[]),
                                            Node(type=1, children=[])])
    node_pattern_1.set_child(0, Node(type=2, children=[]))


# Generated at 2022-06-25 15:16:57.656659
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    node_pattern_0 = NodePattern(0, None, None)
    match_list_0 = [Leaf(0, "1"), Leaf(1, "3"), Leaf(3, "5"), Leaf(5, "7")]
    match_res_0 = node_pattern_0.match_seq(match_list_0)
    assert match_res_0 == False

    node_pattern_1 = NodePattern(3, None, None)
    match_list_1 = [Leaf(0, "1"), Leaf(1, "3"), Leaf(3, "5"), Leaf(5, "7")]
    match_res_1 = node_pattern_1.match_seq(match_list_1)
    assert match_res_1 == False

    node_pattern_2 = NodePattern(60, None, None)
    match

# Generated at 2022-06-25 15:17:01.495042
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    t = Node(type = 0, children = [Leaf(3, ""), Node(type = 0, children = [Node(type = 0, children = [Leaf(3, "")])])])
    t.get_lineno()


# Generated at 2022-06-25 15:17:02.618184
# Unit test for constructor of class NodePattern
def test_NodePattern():
    assert NodePattern


# Generated at 2022-06-25 15:17:03.881991
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node_pattern_0 = NodePattern()
    repr_0 = repr(node_pattern_0)
    print(repr_0)


# Generated at 2022-06-25 15:17:15.454948
# Unit test for constructor of class NodePattern
def test_NodePattern():
    test_case_0()


# Generated at 2022-06-25 15:17:20.292724
# Unit test for method post_order of class Node
def test_Node_post_order():
    N = Node
    L = Leaf
    a = L(0, "a")
    b = L(0, "b")
    c = L(0, "c")
    d = L(0, "d")
    e = L(0, "e")
    f = L(0, "f")
    g = L(0, "g")
    h = L(0, "h")
    i = L(0, "i")
    j = L(0, "j")
    k = L(0, "k")
    l = L(0, "l")
    m = L(0, "m")
    n = L(0, "n")
    o = L(0, "o")
    p = L(0, "p")
    q = L(0, "q")
    r

# Generated at 2022-06-25 15:17:24.237563
# Unit test for method replace of class Base
def test_Base_replace():
    leaf = Leaf(1, "")
    node = Node(1, [leaf])

    leaf.replace(None)
    assert leaf.get_lineno() is None


# Generated at 2022-06-25 15:17:34.431124
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    node_pattern_0 = NodePattern()
    # Test attribute type with a value of None
    # Test attribute content with a value of None
    # Test attribute name with a value of None
    assert node_pattern_0.__repr__() == 'NodePattern(None)'
    node_pattern_1 = NodePattern()
    node_pattern_1.type = 256
    # Test attribute type with a value of 256
    node_pattern_1.content = 'literal_param{'
    # Test attribute content with a value of 'literal_param{'
    # Test attribute name with a value of None
    assert node_pattern_1.__repr__() == "NodePattern(256, 'literal_param{')"


# Generated at 2022-06-25 15:17:44.832814
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_0_optimized = wildcard_pattern_0.optimize()
    assert wildcard_pattern_0_optimized == wildcard_pattern_0
    node_pattern_0 = NodePattern()
    wildcard_pattern_2 = WildcardPattern(content=((node_pattern_0),))
    wildcard_pattern_2_optimized = wildcard_pattern_2.optimize()
    assert wildcard_pattern_2_optimized == node_pattern_0
    wildcard_pattern_2 = WildcardPattern(content=((node_pattern_0),))
    wildcard_pattern_2_optimized = wildcard_pattern_2.optimize()
    assert wildcard_pattern_2_optimized == node_pattern_0

# Generated at 2022-06-25 15:17:47.786213
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    temp_str = ['This', 'is', 'a', 'test', '.']
    temp_pattern = WildcardPattern()

    temp_results = temp_pattern.match_seq(temp_str)
    print(temp_results)
    print("Success")
    return


# Generated at 2022-06-25 15:17:51.582897
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    root = parse(text="""
        def function_name(parameters):
            pass
    """)
    node = Node("BLOCK_STATEMENT_BODY", [root])
    node.get_suffix()
    node.get_suffix()
    node.get_suffix()


# Generated at 2022-06-25 15:17:52.473674
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_case_0()



# Generated at 2022-06-25 15:17:58.530790
# Unit test for method replace of class Base
def test_Base_replace():
    node_0 = Node("test_type", [])
    node_0.parent = Node("test_type_1", [])
    node_1 = Node("test_type_2", [])
    node_2 = Node("test_type_3", [])
    node_0.replace([node_1, node_2])
    assert node_0.parent is None
    assert node_0.children == []
    assert node_1.parent == node_0.parent.parent
    assert node_2.parent == node_0.parent.parent
    assert node_0.parent.parent.children == [node_1, node_2]


# Generated at 2022-06-25 15:18:04.270900
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Initialization
    node_pattern_0 = test_case_0()
    node_pattern_1 = test_case_0()
    node_pattern_2 = test_case_0()
    node_pattern_3 = test_case_0()
    # Testing
    node_pattern_1.children.append(node_pattern_0)
    node_pattern_2.children.append(node_pattern_1)
    node_pattern_3.children.append(node_pattern_2)
    node_pattern_3.children.append(node_pattern_0)
    node_pattern_1.children.append(node_pattern_3)
    result_0 = node_pattern_3.get_suffix()
    assert result_0 == "trailing_text"



# Generated at 2022-06-25 15:18:38.106263
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node_pattern_0 = NodePattern()
    # noinspection PyPep8Naming
    node_pattern_1 = NodePattern()
    assert node_pattern_0.__repr__() == "NodePattern([], **None)"
    assert node_pattern_1.__repr__() == "NodePattern([], **None)"



# Generated at 2022-06-25 15:18:42.902702
# Unit test for method remove of class Base
def test_Base_remove():
    node = Base("node")
    node = node.remove(node)
    assert (node is None)



# Generated at 2022-06-25 15:18:52.021248
# Unit test for method post_order of class Base
def test_Base_post_order():
    if True:
        node_pattern_0 = NodePattern()
        node_0 = Node(1, (1, 1), [node_pattern_0])
        node_0.post_order()
    if True:
        node_pattern_0_1 = NodePattern()
        node_0 = Node(1, (1, 1), [node_pattern_0_1])
        node_0.post_order()
    if True:
        node_pattern_0_2 = NodePattern()
        node_pattern_0_2.set_children([])
        node_pattern_0_1 = NodePattern()
        node_pattern_0_1.set_children([node_pattern_0_2])
        node_0 = Node(1, (1, 1), [node_pattern_0_1])

# Generated at 2022-06-25 15:18:55.686109
# Unit test for method set_child of class Node
def test_Node_set_child():
    # create a set of mocks
    mock_child = Mock(Node)
    mock_node = Mock(Node)
    mock_node.children = []

    mock_child.parent = None
    mock_node.children.append(mock_child)

    mock_node.set_child(0, mock_child)


# Generated at 2022-06-25 15:18:57.814211
# Unit test for method post_order of class Base
def test_Base_post_order():
    node_pattern_0 = NodePattern()
    assert node_pattern_0.post_order() == 'iterator'


# Generated at 2022-06-25 15:19:00.182070
# Unit test for method depth of class Base
def test_Base_depth():
    node_pattern_0 = NodePattern()
    assert node_pattern_0.depth() == 0


# Generated at 2022-06-25 15:19:08.472792
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """Test that NegatedPattern's generate_matches() method works correctly."""
    # Test 1: Test with a pattern that doesn't match anything
    p = NegatedPattern(NodePattern(type=syms.name))
    assert list(p.generate_matches([Name("for"), Name("a")])) == []

    # Test 2: Test with a pattern that matches everything
    p = NegatedPattern(BasePattern())
    assert list(p.generate_matches([Name("for"), Name("a")])) == []

    # Test 3: Test with a pattern that matches something, but doesn't match the entire sequence
    p = NegatedPattern(WildcardPattern(WildcardPattern(NodePattern(type=syms.name))))

# Generated at 2022-06-25 15:19:17.674412
# Unit test for function generate_matches
def test_generate_matches():

    node_pattern_0 = NodePattern(name='a')
    patterns_0 = [node_pattern_0,node_pattern_0,node_pattern_0]
    nodes_0 = [Node(1),Node(1),Node(1)]
    print("generate_matches(patterns_0, nodes_0) =", generate_matches(patterns_0, nodes_0))

    # expected [(3, {'a': [Node(1), Node(1), Node(1)]})]

    node_pattern_1 = NodePattern(type=1,name='a')
    patterns_1 = [node_pattern_1,node_pattern_1,node_pattern_1]
    nodes_1 = [Node(1),Node(1),Node(1)]

# Generated at 2022-06-25 15:19:26.999259
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    node_pattern_0 = LeafPattern()
    node_pattern_1 = NodePattern()
    node_pattern_2 = LeafPattern()
    node_pattern_3 = LeafPattern()
    node_pattern_4 = LeafPattern()
    node_pattern_5 = LeafPattern()
    node_pattern_6 = NodePattern()
    node_pattern_7 = LeafPattern()
    node_pattern_8 = LeafPattern()
    node_pattern_9 = LeafPattern()
    node_pattern_10 = NodePattern()
    node_pattern_11 = LeafPattern()
    node_pattern_12 = LeafPattern()
    node_pattern_13 = LeafPattern()
    node_pattern_14 = NodePattern()
    node_pattern_15 = LeafPattern()
    node_pattern_16 = LeafPattern()
    node_pattern_17 = LeafPattern()
   

# Generated at 2022-06-25 15:19:30.041163
# Unit test for method depth of class Base
def test_Base_depth():
    node_0 = Node()
    node_1 = Node()
    node_0.addkid(node_1)
    node_1.addkid(node_0)
    node_pattern_0 = NodePattern()
    leaf_pattern_0 = LeafPattern()
    assert (node_0.depth() == 2)


# Generated at 2022-06-25 15:20:16.075293
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import token
    # code in this block will be executed only if the module is run standalone
    if __name__ == "__main__":
        import random
        import unittest


        class Node(object):
            def __init__(self, type_, children=()):
                self.type = type_
                self.children = list(children)


        class Leaf(object):
            def __init__(self, type_, value):
                self.type = type_
                self.value = value

        class BasePatternTests(unittest.TestCase):
            """Base tests on BasePattern"""

            def test_generate_matches(self):
                '''[UNIT TEST] BasePattern.generate_matches'''
                n = Node(token.NAME)

# Generated at 2022-06-25 15:20:20.546421
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    node_pattern_2 = NodePattern()
    negated_pattern_0 = NegatedPattern(node_pattern_2)
    list_0 = [node_pattern_0, node_pattern_1, node_pattern_2]
    results = {}
    negated_pattern_0.generate_matches(list_0)


# Generated at 2022-06-25 15:20:22.595270
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    node_pattern_0 = NodePattern(type = 256, content = {}, name = "")
    for i in range(0,10):
        node_pattern_0.generate_matches([])


# Generated at 2022-06-25 15:20:27.276078
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    node_pattern_0 = NodePattern()
    # Expects no exception
    type(node_pattern_0).clone(node_pattern_0)


# Generated at 2022-06-25 15:20:29.338257
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_pattern_0 = NodePattern()
    node_list_0 = node_pattern_0.post_order()
    node_string_0 = str(node_list_0)
    assert (node_string_0 == "[]"), f"expected \'[], got {node_string_0}"


# Generated at 2022-06-25 15:20:35.732563
# Unit test for function convert
def test_convert():
    from pegen.driver import generate_grammar
    from pegen.grammar import Grammar, Symbol

    gr = generate_grammar()
    any_col_suffix = Symbol("any_col_suffix", is_terminal=True)
    any_simple_stmt = Symbol("any_simple_stmt", is_terminal=False)
    any_stmt = Symbol("any_stmt", is_terminal=False)
    and_test = Symbol("and_test", is_terminal=False)
    arglist = Symbol("arglist", is_terminal=False)
    argument = Symbol("argument", is_terminal=False)
    arglist.symbols = [(argument,), (arglist, ",", argument), (arglist, ",")]

# Generated at 2022-06-25 15:20:44.193458
# Unit test for method clone of class Base
def test_Base_clone():
    parent_node_0 = Node()
    node_pattern_0 = NodePattern(parent_node_0)
    clone_node_1 = node_pattern_0.clone()
    clone_node_2 = node_pattern_0.clone()
    assert parent_node_0 is clone_node_1.parent
    assert parent_node_0 is clone_node_2.parent

    parent_node_2 = Node()
    node_pattern_1 = NodePattern(parent_node_2)
    clone_node_0 = node_pattern_1.clone()
    assert node_pattern_0 is clone_node_0
    assert node_pattern_1 is clone_node_0
    assert parent_node_0 is clone_node_0.parent

    parent_node_1 = Node()

# Generated at 2022-06-25 15:20:47.398722
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    n = NodePattern()
    node_pattern_0 = NodePattern()
    assert not node_pattern_0.match_seq(None)
    assert not node_pattern_0.match_seq([])


# Generated at 2022-06-25 15:20:51.177602
# Unit test for method post_order of class Base
def test_Base_post_order():
    L = []
    class N(Base):
        children = ()
        def post_order(self):
            L.append(self)
    class L(Base):
        children = ()

    n = N()
    n.post_order()
    assert L == [n]


# Generated at 2022-06-25 15:20:53.448633
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    node_pattern_0 = NodePattern()
    node_list_0 = [NodePattern(), NodePattern()]
    # node_list_0 = [NodePattern]
    node_pattern_0.generate_matches(node_list_0)


