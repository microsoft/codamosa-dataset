

# Generated at 2022-06-25 15:12:41.742952
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    base_0 = Base()


# Generated at 2022-06-25 15:12:44.011363
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "hello")
    assert leaf.pre_order().__next__().value == "hello"


# Generated at 2022-06-25 15:12:45.227021
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    p = BasePattern()
    assert isinstance(p.match(None), bool)

# Generated at 2022-06-25 15:12:46.100476
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    pattern = BasePattern()


# Generated at 2022-06-25 15:12:49.202072
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    # Should return "Leaf(1, 0, 1, '1', '11')"
    node = Leaf(1, 0, 1, "1", "11")
    assert repr(node) == "Leaf(1, 0, 1, '1', '11')"


# Generated at 2022-06-25 15:12:52.208459
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    test_case_0()
    test_Leaf_leaves_obj = Leaf(0,"")
    result = test_Leaf_leaves_obj.leaves()
    expected = []
    assert result == expected


# Generated at 2022-06-25 15:13:02.428507
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    # Preconditions
    type = 174
    content = "3"
    name = ""
    node = Leaf(type, content, context=None, prefix=None, fixers_applied=[])
    node2 = Leaf(173, "4", context=None, prefix=None, fixers_applied=[])
    # Execution
    leaf_pattern = LeafPattern(type, content, name)
    result = leaf_pattern.match(node)
    result2 = leaf_pattern.match(node2)
    # Postconditions
    assert result
    assert not result2
    # Cleanup
    del leaf_pattern



# Generated at 2022-06-25 15:13:04.801511
# Unit test for method replace of class Base
def test_Base_replace():
    new_0 = [Leaf()]
    base_0 = Base()
    base_0.replace(new_0)


# Generated at 2022-06-25 15:13:14.552533
# Unit test for method append_child of class Node
def test_Node_append_child():
    global _prev
    global _next
    base_0 = Base()
    _prev = {}
    _next = {}
    base_0.prev_sibling_map = _prev
    base_0.next_sibling_map = _next
    current = None
    base_0.children = [current]
    base_0.changed()
    base_0.invalidate_sibling_maps()
    assert base_0.prev_sibling_map is not None
    assert base_0.next_sibling_map is not None
    assert id(current) in base_0.prev_sibling_map
    assert id(current) in base_0.next_sibling_map


# Generated at 2022-06-25 15:13:25.710232
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(1, [])
    assert n.__repr__() == "Node(1, [])"
    n = Node(1, [])
    n.children.append(Node(None, []))
    n.children.append(Leaf(None, "a"))
    assert n.__repr__() == "Node(1, [Node(None, []), Leaf(None, 'a')])"
    n = Node(1, [])
    n.children.append(Node(None, []))
    n.children.append(Leaf(None, "a"))
    assert n.__repr__() == "Node(1, [Node(None, []), Leaf(None, 'a')])"


# Generated at 2022-06-25 15:14:04.819985
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    p1 = NodePattern(type=1)
    p2 = NegatedPattern(content=p1)

    root = Node(type=0)
    root.children.append(Node(type=1))

    result = p2.generate_matches(root.children)
    result = list(result)
    assert len(result) == 0


# Generated at 2022-06-25 15:14:07.924815
# Unit test for method post_order of class Node
def test_Node_post_order():
    nodes = [Node(1, [], []), Node(1, [], []), Node(1, [], [])]
    gen = Node(1, nodes, [])
    assert list(gen.post_order()) == nodes


# Generated at 2022-06-25 15:14:08.672767
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    basepattern_0 = BasePattern()


# Generated at 2022-06-25 15:14:11.834293
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test case 0
    base_0 = Base()
    # Testing if the first yield raises StopIteration
    try:
        for e in base_0.generate_matches([base_0, base_0]):
            break
    except StopIteration:
        pass


# Generated at 2022-06-25 15:14:15.419600
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    nodes = [1,2]
    obj = NegatedPattern()
    result = obj.generate_matches(nodes)
    if isinstance(result, types.GeneratorType):
        num_of_matches = 0
        for match in result:
            num_of_matches += 1
        assert num_of_matches == 0, num_of_matches
    else:
        assert False, "generate_matches does not return a generator object"


# Generated at 2022-06-25 15:14:16.915478
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    node_0 = Base()
    assert list(node_0.pre_order()) == []



# Generated at 2022-06-25 15:14:23.536976
# Unit test for function generate_matches
def test_generate_matches():
    base_0 = Base()
    base_1 = Base()
    base_2 = Base()
    base_3 = Base()
    base_4 = Base()
    base_5 = Base()
    base_6 = Base()
    # Test 0:
    wp0 = WildcardPattern(None)
    wp1 = WildcardPattern(None)
    wp2 = WildcardPattern(None)
    wp3 = WildcardPattern(None)
    wp4 = WildcardPattern(None)
    assert list(generate_matches([wp0, wp1, wp2, wp3, wp4], [base_0, base_1, base_2, base_3, base_4])) == [(5, {})]
    # Test 1:
    wp0 = WildcardPattern(None)
   

# Generated at 2022-06-25 15:14:26.854822
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    nodes = [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]
    for c, r in WildcardPattern().generate_matches(nodes):
        print(c, r)


# Generated at 2022-06-25 15:14:33.461363
# Unit test for method replace of class Base
def test_Base_replace():
    class_name = "Base"
    method_name = "replace"
    node_0 = Base()
    node_0.parent = Base()
    node_0.parent.children = [node_0]
    node_1 = Node(123, [], None)
    node_0.replace(node_1)
    assert node_0.parent == None
    assert node_1.parent == node_0.parent.children[0]


# Generated at 2022-06-25 15:14:36.809224
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    global _type_reprs
    _type_reprs = {}
    base_1 = Base()
    type_repr(256)
    base_1._eq(0)
    assert base_1.type == 0


# Generated at 2022-06-25 15:14:57.085769
# Unit test for function type_repr
def test_type_repr():
    # pylint: disable=missing-function-docstring,redefined-outer-name,no-py3-none-equal
    assert type_repr(0x0000) == "NT_OFFSET"
    assert type_repr(0x0001) == "NAME"
    assert type_repr(0x0002) == "NUMBER"
    assert type_repr(0x0003) == "STRING"
    assert type_repr(0x0004) == "NEWLINE"
    assert type_repr(0x0005) == "INDENT"
    assert type_repr(0x0006) == "DEDENT"
    assert type_repr(0x0007) == "LPAR"
    assert type_repr(0x0008) == "RPAR"

# Generated at 2022-06-25 15:14:58.955354
# Unit test for method depth of class Base
def test_Base_depth():
    depth_0 = Base()
    depth_1 = depth_0.depth()
    assert depth_1 == 0


# Generated at 2022-06-25 15:15:04.125481
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    class T(NodePattern):
        pass

    class LeafPattern(LeafPattern):
        pass
    
    # Test 1. Constructing a WildcardPattern with content = None, min = 0, max = 1
    pattern_01 = WildcardPattern(None, 0, 1)

    # Test 1.1. Matching with the given node pattern: one child
    nodes_01_1 = [Child(0, "child1")]
    print("\nTest 1.1: node pattern with 1 child")
    print(pattern_01.match_seq(nodes_01_1))

    # Test 1.2. Matching with the given node pattern: two children
    nodes_01_2 = [Child(0, "child1"), Child(1, "child2")]
    print("\nTest 1.2: node pattern with 2 children")


# Generated at 2022-06-25 15:15:05.630478
# Unit test for method replace of class Base
def test_Base_replace():
    assert Base().replace(Node(0, [])) is None


# Generated at 2022-06-25 15:15:06.793172
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
	pass


# Generated at 2022-06-25 15:15:17.503834
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    np_ = NegatedPattern()
    np2 = NegatedPattern(np_)
    np3 = NegatedPattern(np2)
    assert list(np3.generate_matches([])) == [
        (0, {})
    ], list(np3.generate_matches([]))
    assert list(np3.generate_matches([1])) == [], list(np3.generate_matches([1]))
    assert list(np2.generate_matches([1])) == [
        (0, {})
    ], list(np2.generate_matches([1]))
    assert list(np_.generate_matches([1])) == [], list(np_.generate_matches([1]))


# Generated at 2022-06-25 15:15:21.565655
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():

    for arg in [0.743, 0.5, 0.5]:
        if arg > 2.0:
            continue
        try:
            base_pattern_0 = BasePattern()
            assert False
        except NotImplementedError:
            pass


# Generated at 2022-06-25 15:15:23.210683
# Unit test for function type_repr
def test_type_repr():
    print(type_repr(3))



# Generated at 2022-06-25 15:15:26.617341
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    expected = '''
    Leaf(1, "1")
    '''
    l = Leaf(1, "1")
    actual = '\n'.join(map(str, l.pre_order()))
    assert expected == actual


# Generated at 2022-06-25 15:15:31.020690
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """Unit test for method generate_matches of class NegatedPattern."""
    from . import compile_pattern
    p = compile_pattern("(1 [2-4] | 1 [5-9] [10-13])")
    assert len(list(NegatedPattern(content=p).generate_matches([1, 2, 3, 5]))) == 0
    assert len(list(NegatedPattern(content=p).generate_matches([1, 2, 3, 5, 10, 11])))\
           == 1
    assert len(list(NegatedPattern(content=p).generate_matches([1, 2, 3, 5, 10, 11, 7]))) == 0
    assert len(list(NegatedPattern(NegatedPattern(content=p)).generate_matches([1, 2, 3, 5]))) == 1


# Generated at 2022-06-25 15:15:50.831603
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_1 = Base()
    base_1_pre_order = base_1.pre_order()
    for base_1_pre_order_item in base_1_pre_order:
        assert isinstance(base_1_pre_order_item, Base)


# Generated at 2022-06-25 15:15:54.962893
# Unit test for function convert
def test_convert():
    base_0 = Base()
    id(base_0.children) == id(base_0.children)
    #assert isinstance(base_0.children, list)
    #assert isinstance(base_0.children, list)
    #assert base_0.children[0] is None
    #assert base_0.children[0] is None
    #assert base_0.children[0] is None
    #assert base_0.children[0] is None
    assert base_0.children[0] is None
    assert base_0.children[0] is None
    assert base_0.children[0] is None
    assert base_0.children[0] is None
    assert base_0.children[0] is None
    assert base_0.children[0] is None

# Generated at 2022-06-25 15:15:56.614456
# Unit test for method replace of class Base
def test_Base_replace():
    b = Base()
    assert (b.replace(Base()) == None)


# Generated at 2022-06-25 15:15:58.863299
# Unit test for method clone of class Base
def test_Base_clone():
    base_0 = Base()
    # The class Base should have the __init__ method.
    assert hasattr(base_0.__class__, '__init__')


# Generated at 2022-06-25 15:15:59.568122
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    pass


# Generated at 2022-06-25 15:16:00.826639
# Unit test for method post_order of class Base
def test_Base_post_order():
    base_0 = Base()
    base_0.post_order()


# Generated at 2022-06-25 15:16:02.448430
# Unit test for method replace of class Base
def test_Base_replace():
    # Initialize an object
    base_0 = Base()

    # Call method
    base_0.replace([0])


# Generated at 2022-06-25 15:16:07.533137
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_0 = Node(12, [Leaf(11, "pre"), Leaf(13, "post")])
    output = "pre,12,post"
    output_0 = ""
    for node in node_0.post_order():
        output_0 += str(node.type) + ','
    output_0 = output_0[:-1]
    assert output == output_0


# Generated at 2022-06-25 15:16:08.441181
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_0 = Base()
    base_0.pre_order()


# Generated at 2022-06-25 15:16:14.880496
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test case 1
    base_1 = WildcardPattern((NodePattern(),), 0, 1)
    base_1.optimize()
    # Test case 2
    base_2 = WildcardPattern(0, 0, "test")
    base_2.optimize()
    # Test case 3
    base_3 = WildcardPattern(NodePattern(), 0, "test")
    base_3.optimize()
    # Test case 4
    base_4 = WildcardPattern(min = 0, name = "test", content = NodePattern())
    base_4.optimize()


# Generated at 2022-06-25 15:16:28.148445
# Unit test for method post_order of class Base
def test_Base_post_order():
    base_0 = Base()
    try:
        base_0.post_order()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:16:29.104897
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    assert not isinstance(Base(), Iterable)



# Generated at 2022-06-25 15:16:32.063082
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node = Node(1034, [])
    pre_order = node.pre_order()
    assert pre_order


# Generated at 2022-06-25 15:16:41.075628
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    base_0 = Base()
    base_0.type = 256
    base_0.content = None
    base_0.name = ''
    node_0 = Node(base_0.type, [])
    node_0.type = 257
    node_0.content = None
    node_0.name = ''
    node_1 = Node(base_0.type, [])
    node_1.type = 256
    node_1.content = None
    node_1.name = ''
    assert base_0.match(node_0) == True
    assert base_0.match(node_1) == False


# Generated at 2022-06-25 15:16:42.980134
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    leaf_pattern_0 = LeafPattern()


# Generated at 2022-06-25 15:16:45.441354
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base_pattern = BasePattern()
    nodes = []
    assert list(base_pattern.generate_matches(nodes)) == []


# Generated at 2022-06-25 15:16:47.530484
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    base_0.parent = None
    x = base_0.depth()
    assert x == 0


# Generated at 2022-06-25 15:16:57.076252
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_2 = Base()
    # list_of_nodes
    nodes = [
        "Expression node, containing a single leaf node",
        "Expression node, containing a pair of leaf nodes",
        "An expression with a single leaf, plus two subexpressions, each of which has a single leaf",
    ]
    input_3 = nodes[0]
    match_3 = Leaf(1, input_3, (1, 1))
    base_2.children = [match_3]
    input_4 = nodes[1]
    match_4 = Leaf(1, input_4, (1, 1))
    base_2.children.append(match_4)
    input_5 = nodes[2]
    match_5 = Leaf(1, input_5, (1, 1))

# Generated at 2022-06-25 15:16:59.162672
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Test if using abstract class raises NotImplementedError
    test_case_BasePattern_optimize_0()


# Generated at 2022-06-25 15:17:09.377137
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    base_0 = Base()
    node_0 = Node(
        0,
        [
            Leaf(
                0, "", (1, 0), prefix="\n",
            ),
            Leaf(
                0, "", (1, 0), prefix="\n",
            ),
            Leaf(
                0, "", (1, 0), prefix="\n",
            ),
            Node(
                0,
                [
                    Leaf(
                        0, "", (1, 0), prefix="\n",
                    ),
                    Leaf(
                        0, "", (1, 0), prefix="\n",
                    ),
                ],
            ),
        ],
    )
    l_retval = node_0.pre_order()
    assert l_retval is not None

# Generated at 2022-06-25 15:17:31.987213
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    test_case_0()


# Generated at 2022-06-25 15:17:35.842466
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    case_0 = WildcardPattern(None, 0, 1)
    case_1 = WildcardPattern(None, 1, 2)
    case_2 = WildcardPattern(None, 1, 1)
    case_3 = WildcardPattern(None, 0, 2)
    case_4 = WildcardPattern(None, 0, 1, "test")
    case_5 = WildcardPattern(None, 1, 2, "test")
    case_6 = WildcardPattern(None, 1, 1, "test")
    case_7 = WildcardPattern(None, 0, 2, "test")


# Generated at 2022-06-25 15:17:38.280436
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_0 = Base()
    nodes = (base_0,)
    def f(nodes):
        return len([e for e in nodes if e.__class__ is Base])
    if f(nodes) != 1:
        print("""Error: expected "%r", got "%r" """ % (1, f(nodes)))
        return False
    return True


# Generated at 2022-06-25 15:17:47.201456
# Unit test for function generate_matches
def test_generate_matches():
    # Test case 1
    root = Base()
    p1 = root.patterns(NodePattern(type=NAME))
    p2 = root.patterns(NodePattern(type=STR))
    p3 = root.patterns([p1, p2])
    p4 = root.patterns(NodePattern(type=NAME, name="__field__"))
    p5 = root.patterns(WildcardPattern(max=1, name="__default__"))
    p6 = root.patterns([p4, p5])
    p7 = root.patterns([p3, p6])
    p8 = root.patterns(WildcardPattern(min=1))
    p9 = root.patterns(p7)
    p10 = root.patterns([p8, p9])

# Generated at 2022-06-25 15:17:49.309838
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_0 = Base()
    ret_0 = base_0.get_lineno()
    assert ret_0 == None


# Generated at 2022-06-25 15:17:50.937766
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_0 = Base()
    assert isinstance(base_0.leaves(), Iterator)


# Generated at 2022-06-25 15:17:57.908514
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Set node size to sample of 100
    node_size = 100
    _BasePattern = BasePattern()
    base_1 = Base()
    nodes_1 = []
    for i in range(node_size):
        node_i = Node(257, [Leaf(1, "", (0, 0))], prefix="     ")
        nodes_1.append(node_i)
    result = _BasePattern.match_seq(nodes_1)
    assert result == False

    nodes_2 = [Leaf(1, "", (0, 0))]*node_size
    result = _BasePattern.match_seq(nodes_2)
    assert result == False



# Generated at 2022-06-25 15:17:58.937094
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node = Node(0,[])


# Generated at 2022-06-25 15:18:05.537866
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    base_0 = Base()
    wildcard_pattern_0 = WildcardPattern(None)
    assert wildcard_pattern_0.generate_matches([base_0]) == [(0, {}), (1, {})]
    concrete_pattern_0 = ConcretePattern()
    wildcard_pattern_1 = WildcardPattern([[concrete_pattern_0, base_0]])
    assert wildcard_pattern_1.generate_matches([base_0, base_0]) == [(2, {})]


# Generated at 2022-06-25 15:18:10.552337
# Unit test for method replace of class Base
def test_Base_replace():
    base_0 = Base()
    child = Leaf(1, "test")
    parent = Node(1, [child])
    child.parent = parent
    new_child = Node(2, [Leaf(1, "test2")])
    new_child.parent = parent
    parent.replace(new_child)



# Generated at 2022-06-25 15:20:44.625711
# Unit test for method post_order of class Base
def test_Base_post_order():
    base_1 = Base()
    base_1_post_order = base_1.post_order
    assert (None is type(base_1_post_order))
    assert (None is base_1_post_order())


# Generated at 2022-06-25 15:20:46.364112
# Unit test for constructor of class NodePattern
def test_NodePattern():
    base = Base()
    assert base.type != None


# Generated at 2022-06-25 15:20:52.274105
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Default implementation for non-wildcard patterns.
    # Do not define a match_seq method for LeafPattern, NodePattern,
    # and WildcardPattern.
    # This should raise a NotImplementedError
    try:
        base_pattern_0 = BasePattern()
        nodes_0 = [Leaf(-239, 'dfd', (1, 0)), Leaf(-264, 'df')]
        base_pattern_0.match_seq(nodes_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 15:20:55.303347
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    nl_0 = Node(1, [])
    # This is just a simple stub. Ideally this would test that the
    # generator returns unique results with equal probability
    bp_0 = BasePattern()
    result = bp_0.generate_matches([nl_0])
    assert isinstance(result, types.GeneratorType)
    assert next(result) == (1, {})


# Generated at 2022-06-25 15:21:03.662814
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    '''
    Test leaves
    '''
    # Test no_of_children = 0
    l_0 = Leaf('1', '2', '3')
    assert l_0.leaves() == iter([l_0])

    # Test no_of_children = 1
    l_1 = Leaf('1', '2', '3')
    l_11 = Leaf('1', '2', '3')
    l_1.children.append(l_11)
    assert l_1.leaves() == iter([l_11])

    # Test no_of_children = 2
    l_2 = Leaf('1', '2', '3')
    l_21 = Leaf('1', '2', '3')
    l_22 = Leaf('1', '2', '3')

# Generated at 2022-06-25 15:21:10.002975
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    w = WildcardPattern(content = [[Leaf(251, "a"), Leaf(250, "b"), Leaf(249, "c")],
                                   [Leaf(248, "d"), Leaf(247, "e")],
                                   [Leaf(246, "f"), Leaf(245, "g"), Leaf(244, "h")]],
                        min = 0,
                        max = 1,
                        name = "wild_pattern_0")
    lst = [Leaf(251, "a"),
           Leaf(250, "b"),
           Leaf(249, "c"),
           Leaf(248, "d"),
           Leaf(247, "e"),
           Leaf(246, "f"),
           Leaf(245, "g"),
           Leaf(244, "h")]

# Generated at 2022-06-25 15:21:11.260278
# Unit test for method leaves of class Base
def test_Base_leaves():
    assert False


# Generated at 2022-06-25 15:21:17.943895
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from . import pytree
    from .pygram import python_symbols
    from .pgen2 import token
    from .pgen2 import parse as pgen2_parse
    from . import fixer_base
    global type_repr
    global _type_reprs
    orig_type_repr = type_repr
    type_repr = test_case_0
    orig_type_reprs = _type_reprs

# Generated at 2022-06-25 15:21:19.170373
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    assert Base().__eq__(Base())


# Generated at 2022-06-25 15:21:30.173872
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    x = Node(10, [])
    y = Node(10, [])
    r = Node(10, [])
    z = Node(10, [])
    i = Node(10, [])
    k = Node(10, [])
    j = Node(10, [])
    o = Node(10, [])
    m = Node(10, [])
    n = Node(10, [])
    t = Node(10, [])
    u = Node(10, [])
    s = Node(10, [])
    p = Node(10, [])
    a = Node(10, [])
    l = Node(10, [])
    q = Node(10, [])
    h = Node(10, [])
    g = Node(10, [])
    f = Node(10, [])