

# Generated at 2022-06-25 15:12:38.797114
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    assert BasePattern.optimize is BasePattern.optimize
    """
    pass


# Generated at 2022-06-25 15:12:40.638756
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_0 = Leaf(0, '')
    assert list(leaf_0.pre_order()) == [leaf_0]



# Generated at 2022-06-25 15:12:43.971054
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base = Base()
    children = [base]
    pre_order_result = base.pre_order()
    assert next(pre_order_result) == base
    assert list(pre_order_result) == []


# Generated at 2022-06-25 15:12:46.099391
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    base_0 = Leaf(258, 'def')
    var_0 = base_0.leaves()
    var_0 = next(var_0)


# Generated at 2022-06-25 15:12:54.549002
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern = WildcardPattern([[NodePattern(type=1)]], min=1, max=1)
    pattern = pattern.optimize()
    assert pattern == NodePattern(type=1)
    pattern = WildcardPattern([[NodePattern(type=1)]], min=0, max=1)
    pattern = pattern.optimize()
    assert pattern == NodePattern(type=1)
    pattern = WildcardPattern([[NodePattern(type=1)]], min=1, max=1, name="foo")
    pattern = pattern.optimize()
    assert pattern == NodePattern(type=1, name="foo")
    pattern = WildcardPattern(None, min=1, max=1, name="foo")
    pattern = pattern.optimize()
    assert pattern == NodePattern(name="foo")

# Generated at 2022-06-25 15:12:56.562062
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf_0 = Leaf(0, "")
    lst_0 = list(leaf_0.leaves())
    assert len(lst_0) == 1
    assert lst_0[0] == leaf_0


# Generated at 2022-06-25 15:12:57.658462
# Unit test for method clone of class Node
def test_Node_clone():
    base_0 = Node(0, [])
    var_0 = base_0.clone()


# Generated at 2022-06-25 15:13:07.321892
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    a = LeafPattern(ord('a'))
    w = WildcardPattern([a], min=2, max=2)
    m = NegatedPattern(w)
    g = m.generate_matches(map(Leaf, "abcdcbeadcbead"))
    assert next(g) == (0, {})
    assert next(g) == (1, {})
    #assert next(g) == (3, {})
    assert next(g) == (4, {})
    assert next(g) == (5, {})
    assert next(g) == (7, {})

    # Test for empty sequence
    m = NegatedPattern()
    g = m.generate_matches(map(Leaf, "abcdcbeadcbead"))
    assert next(g) == (0, {})


#

# Generated at 2022-06-25 15:13:10.478027
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_0 = Leaf(90, 'a')
    assert leaf_0.post_order() == [leaf_0]


# Generated at 2022-06-25 15:13:15.273400
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    print("Testing match of BasePattern")

    leaf_0 = Leaf(42, "bogus")
    base_pattern_0 = BasePattern()

    base_pattern_0.type = 42

    test_results = base_pattern_0.match(leaf_0)
    if test_results:
        print("BasePattern match: SUCCESS")
    else:
        print("BasePattern match: FAIL")


# Generated at 2022-06-25 15:14:11.745051
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    # Assert: AssertionError: assert <Node>: <Node>
    str_1 = 'str_1'
    str_2 = 'str_2'
    str_3 = 'str_3'
    str_4 = 'str_4'
    str_5 = 'str_5'
    # State: (unreachable) def test_Node_pre_order():
    # State: (unreachable)     str_1 = 'str_1'
    # State: (unreachable)     str_2 = 'str_2'
    # State: (unreachable)     str_3 = 'str_3'
    # State: (unreachable)     str_4 = 'str_4'
    # State: (unreachable)     str_5 = 'str_5'
    # State: (unreach

# Generated at 2022-06-25 15:14:12.816823
# Unit test for method set_child of class Node
def test_Node_set_child():
    test_case_0()



# Generated at 2022-06-25 15:14:21.584915
# Unit test for method set_child of class Node
def test_Node_set_child():
    _str = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    str_0 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    str_1 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    str_2 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    str_3 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    str_4 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    str_5 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '

# Generated at 2022-06-25 15:14:25.161643
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    source = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    grammar = Grammar(source)
    grammar.parse_all()
    tree = grammar.tree
    assert tree.get_lineno() == 2


# Generated at 2022-06-25 15:14:26.390669
# Unit test for function type_repr
def test_type_repr():
    assert BasePattern.optimize is BasePattern.optimize



# Generated at 2022-06-25 15:14:29.926470
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    assert BasePattern.optimize is BasePattern.optimize
    assert BasePattern.match_seq is not BasePattern.match_seq


# Generated at 2022-06-25 15:14:38.197651
# Unit test for method remove of class Base
def test_Base_remove():
    str_0 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    NL_0 = Node(0, 'NL')
    int_0 = 0
    tuple_0 = (str_0, int_0)
    list_0 = [tuple_0]
    Leaf_0 = Leaf(0, list_0)
    NL_0.children.append(Leaf_0)
    list_1 = []
    NL_0.children.append(list_1)
    Leaf_1 = Leaf(1, list_1)
    NL_0.children.append(Leaf_1)
    tuple_1 = ('int', '_eof')
    tuple_2 = (0, 0)
    tuple_3 = (tuple_1, tuple_2)

# Generated at 2022-06-25 15:14:39.443121
# Unit test for method remove of class Base
def test_Base_remove():
    let0 = Base()
    let1 = let0.remove()
    assert let1 is None


# Generated at 2022-06-25 15:14:45.186012
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    method_name = "Base.get_suffix()"

# Generated at 2022-06-25 15:14:49.336365
# Unit test for method leaves of class Base
def test_Base_leaves():
    str_1 = '\n    assert BasePattern.optimize is BasePattern.optimize\n    '
    test_list_0 = []
    assert (Base.leaves(test_list_0[0]) is Base.leaves(test_list_0[1])), str_1


# Generated at 2022-06-25 15:15:07.483840
# Unit test for function type_repr
def test_type_repr():
  assert type_repr(2) == 'SYM'
  assert type_repr(2) == 'SYM'
  assert type_repr(3) == 'SYM'


# Generated at 2022-06-25 15:15:18.329991
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    negated_pattern_0 = NegatedPattern()
    length_0 = len(negated_pattern_0.items)
    pattern_0 = NodePattern(type=305)
    length_0 = length_0 + len(pattern_0.items)
    pattern_0 = LeafPattern(type=302)
    length_0 = length_0 + len(pattern_0.items)
    found = False
    for item in pattern_0.items:
        if (
            (item.type == 305)
            and (item.content == None)
            and (item.name == None)
        ):
            found = True
            break
    assert found
    length_0 = length_0 + len(pattern_0.items)
    sequence_0 = SequencePattern()

# Generated at 2022-06-25 15:15:19.948231
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    test_case_0()


# Generated at 2022-06-25 15:15:25.165685
# Unit test for method replace of class Base
def test_Base_replace():
    tree = Leaf(4, '4', (1, 4), prefix='4')
    tree1 = Leaf(4, '4', (1, 4), prefix='4')
    tree2 = Leaf(4, '4', (1, 4), prefix='4')
    assert tree.parent is None
    tree.replace([tree1, tree2])
    assert tree1.parent is tree
    assert tree2.parent is tree
    assert tree.parent is None
    assert tree1.next_sibling is tree2
    assert tree2.prev_sibling is tree1


# Generated at 2022-06-25 15:15:28.320805
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_0 = Node(0, [])
    try:
        node_0.pre_order()
    except:
        raise Exception("method pre_order of the class Node raised an error")


# Generated at 2022-06-25 15:15:32.332193
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    base_0.parent = Node()
    base_0.parent.parent = Node()
    expected_result = 2
    result = base_0.depth()
    assert result == expected_result, "Unexpected result of Base.depth()"


# Generated at 2022-06-25 15:15:43.313930
# Unit test for method post_order of class Base
def test_Base_post_order():
    """
    Unit test for method post_order of class Base
    """
    comments_0 = []

    new_line_0 = Leaf(PythonSymbols.newline, [], 0, 0)
    none = Leaf(PythonSymbols.NAME, ["None"], 0, -1)
    newline_1 = Leaf(PythonSymbols.newline, [], 0, -1)
    newline_2 = Leaf(PythonSymbols.newline, [], 0, -1)
    endmarker_0 = Leaf(PythonSymbols.ENDMARKER, [], 0, -1)
    test_case_0 = [
        comments_0,
        new_line_0,
        none,
        newline_1,
        newline_2,
        endmarker_0,
    ]
    #

# Generated at 2022-06-25 15:15:52.818337
# Unit test for function generate_matches
def test_generate_matches():
    pattern_0 = NodePattern(name="name_0")
    pattern_1 = NodePattern(name="name_1")
    pattern_2 = NodePattern(name="name_2")
    pattern_3 = NodePattern(name="name_3")
    pattern_4 = NodePattern(name="name_4")
    pattern_5 = NodePattern(name="name_5")
    pattern_6 = NodePattern(name="name_6")
    pattern_7 = NodePattern(name="name_7")
    pattern_8 = NodePattern(name="name_8")
    pattern_9 = NodePattern(name="name_9")
    pattern_10 = NodePattern(name="name_10")
    pattern_11 = NodePattern(name="name_11")
    pattern_12 = NodePattern(name="name_12")


# Generated at 2022-06-25 15:15:57.807335
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "a")
    assert leaf.post_order() == [leaf]
    leaf = Leaf(1, "b")
    assert leaf.post_order() == [leaf]
    leaf = Leaf(1, "c")
    assert leaf.post_order() == [leaf]
    leaf = Leaf(1, "d")
    assert leaf.post_order() == [leaf]


# Generated at 2022-06-25 15:15:59.740774
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    for pattern in test_case_0():
        matches = pattern.match(nodes)
        assert matches == expected_matches



# Generated at 2022-06-25 15:16:24.909966
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    ctxt = Context(min(0, 0), min(0, 0))
    nd_obj_0 = NodePattern(min(0, 0), ctxt)
    def func_0():
        return nd_obj_0.optimize()
    def func_1():
        return nd_obj_0.__dict__
    def func_2():
        return nd_obj_0.__dict__
    assert func_0() is nd_obj_0
    assert id(func_1()) == id(func_2()), "dicts changed after calling optimize"


# Generated at 2022-06-25 15:16:28.348698
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    base_0.parent = Base()
    base_0.parent.parent = Base()
    depth = base_0.depth()
    assert depth == 2



# Generated at 2022-06-25 15:16:29.302837
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    BasePattern().optimize()



# Generated at 2022-06-25 15:16:32.838374
# Unit test for method changed of class Base
def test_Base_changed():
    base_0 = Base()
    base_0.changed()
    assert base_0.was_changed == True


# Generated at 2022-06-25 15:16:42.184913
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():

    # Function to return a list of 1 or 2 strings
    def _string_list():
        # Create a list of 1 or 2 strings
        ret_list = []
        ret_list.append("0")
        if rnd.random() < 0.5:
            ret_list.append("9")
        return ret_list

    # Function to return a Pattern instance
    def _pattern_instance(level):
        if 0 == level:
            # Return a LeafPattern instance
            return LeafPattern(rnd.randint(0, 255),
                               rnd.choice(_string_list()))
        else:
            # Return a NodePattern instance
            return NodePattern(rnd.randint(256, 511),
                               rnd.randint(0, level-1),
                               rnd.choice(_string_list()))

   

# Generated at 2022-06-25 15:16:53.147836
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    base_pattern_0 = BasePattern()
    node_1 = Node(257, [Leaf(1, '#'), Leaf(3, 'bar'), Leaf(4, '\n')])
    results_2 = {}
    if base_pattern_0.match(node_1, results_2) != None:
        raise AssertionError
    # Test case where node.type != self.type
    base_pattern_0.type = 258
    if base_pattern_0.match(node_1, results_2) != False:
        raise AssertionError
    # Test case where self.content is not None
    base_pattern_0.type = 257
    base_pattern_0.content = '#'
    if base_pattern_0.match(node_1, results_2) != False:
        raise AssertionError

# Generated at 2022-06-25 15:16:54.431170
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    Base_obj = Base()
    Base_obj.get_suffix()


# Generated at 2022-06-25 15:17:05.097822
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    def test_case_0():
        negated_pattern_0 = NegatedPattern()
        leaf_0 = Leaf(2, "   ")
        leaf_1 = Leaf(1, "\n")
        node_0 = Node(syms.testlist_comp, [leaf_0, leaf_1])
        leaf_2 = Leaf(1, "\n")
        node_1 = Node(syms.testlist_comp, [node_0, leaf_2])
        assert negated_pattern_0.get_lineno() == 1, "get_lineno() == 1"
        assert node_0.get_lineno() == 1, "get_lineno() == 1"
        assert node_1.get_lineno() == 1, "get_lineno() == 1"
    test_case_0()

# Unit test

# Generated at 2022-06-25 15:17:10.112910
# Unit test for function generate_matches
def test_generate_matches():
    # Create a pattern matching an expression whose first element is not a number
    pattern = NegatedPattern(WildcardPattern(
        [NodePattern(type=token.NUMBER)]
    ))

    # Create sequence of numbers
    nodes = []
    for num in range(4):
        node = NL()
        node.type = token.NUMBER
        node.value = num
        nodes.append(node)

    # Test 1: Test matching two nodes
    matches = list(pattern.generate_matches(nodes[:2]))
    assert matches == [], matches

    # Test 2: Test matching four nodes
    matches = list(pattern.generate_matches(nodes))
    assert matches == [], matches

    # Test 3: Test matching zero nodes
    matches = list(pattern.generate_matches([]))
    assert matches

# Generated at 2022-06-25 15:17:19.493192
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    negated_pattern_0 = NegatedPattern()
    nodes_0 = [Dummy(), Dummy()]
    results_0 = {}
    result_0 = negated_pattern_0.match_seq(nodes_0, results_0)
    assert result_0 == True


# Generated at 2022-06-25 15:18:20.240723
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    pattern_0 = NodePattern()
    pattern_1 = pattern_0.optimize()
    assert pattern_0 is pattern_1

    # Optimize a simple name
    pattern_2 = NodePattern(name="name_0")
    pattern_3 = pattern_2.optimize()
    assert pattern_2 is not pattern_3
    assert isinstance(pattern_3, NamePattern)
    assert pattern_3.name == "name_0"
    assert len(pattern_3.patterns) == 1
    assert isinstance(pattern_3.patterns[0], NodePattern)

    # Optimize a complex name
    pattern_4 = NodePattern(name="name_1", content=['content_1'])
    pattern_5 = pattern_4.optimize()
    assert pattern_4 is not pattern_5

# Generated at 2022-06-25 15:18:27.282568
# Unit test for function type_repr
def test_type_repr():
    print('type_repr(1)')
    print(type_repr(1))
    print('type_repr(2)')
    print(type_repr(2))
    print('type_repr(3)')
    print(type_repr(3))
    print('type_repr(4)')
    print(type_repr(4))
    print('type_repr(5)')
    print(type_repr(5))
    print('type_repr(6)')
    print(type_repr(6))
    print('type_repr(7)')
    print(type_repr(7))
    print('type_repr(8)')
    print(type_repr(8))
    print('type_repr(9)')

# Generated at 2022-06-25 15:18:29.342939
# Unit test for method leaves of class Base
def test_Base_leaves():
    node_0 = Node()
    for child in node_0.children:
        yield from child.leaves()



# Generated at 2022-06-25 15:18:32.923265
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    def_0 = BasePattern()
    try:
        def_0.match(def_0)
    except Exception as exception_0:
        match_0 = exception_0
    assert type(match_0) == NotImplementedError


# Generated at 2022-06-25 15:18:37.863308
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    # Generate test cases
    test_cases = [
        (
            BasePattern(),
            [],
        ),
    ]
    for x, y in test_cases:
        for i in range(len(y)):
            for j in range(i, len(y)):
                yield (x, y[i:j+1])
    return



# Generated at 2022-06-25 15:18:43.867951
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    negated_pattern_0 = NegatedPattern()
    node_0 = Node(0, [])
    negated_pattern_0.match_seq([node_0])


# Generated at 2022-06-25 15:18:45.074492
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(2, 3)
    node.set_child(1, 2)


# Generated at 2022-06-25 15:18:53.006004
# Unit test for method replace of class Base
def test_Base_replace():
    # Arguments and expected results
    tree = Node(1, [Leaf(2, "hello"), Leaf(3, "world")])
    new = Leaf(4, "foo")
    old = tree.children[0]
    tree.replace(new)

    assert old.parent is None
    assert new.parent is tree
    assert tree.children == [new, tree.children[1]]


# Generated at 2022-06-25 15:18:57.541355
# Unit test for method remove of class Base
def test_Base_remove():
    test_case_0()
    assert True



# Generated at 2022-06-25 15:18:58.625240
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    assert False


# Generated at 2022-06-25 15:19:22.631127
# Unit test for method post_order of class Node
def test_Node_post_order():
    l = []
    for x in n:
        l.append(x)
    assert l == [n[0], n[1][0], n[1][1], n[1], n[2], n]


# Generated at 2022-06-25 15:19:24.606865
# Unit test for method post_order of class Base
def test_Base_post_order():
    negated_pattern_0 = NegatedPattern()
    post_order_0 = negated_pattern_0.post_order()


# Generated at 2022-06-25 15:19:26.248025
# Unit test for method clone of class Base
def test_Base_clone():
    base_0 = Base()
    result = base_0.clone()
    print(result)


# Generated at 2022-06-25 15:19:31.360374
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Test case 1: get_suffix method is called on a Nonterminal object
    try:
        result = t.get_suffix()

    except Exception:
        raise AssertionError("get_suffix method threw an exception on a Nonterminal object")

    # Test case 2: get_suffix method is called on a Leaf object
    try:
        result = f.get_suffix()

    except Exception:
        raise AssertionError("get_suffix method threw an exception on a Leaf object")



# Generated at 2022-06-25 15:19:33.274972
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.atom) == "atom"
    assert type_repr(python_symbols.STRING) == "STRING"
    assert type_repr(python_symbols.STRING2) == "STRING2"


# Generated at 2022-06-25 15:19:42.550428
# Unit test for function type_repr
def test_type_repr():
    # Verify that type_repr returns the type name given a type number
    # E.g. a token
    assert type_repr(6) == "NEWLINE"
    # Verifies that type_repr returns the number given a number
    assert type_repr(1000) == 1000

# Used for capturing unused arguments in functions
_ = Ellipsis

PYTHON_VERSION = sys.version_info[:2]

# Abstract base classes for all patterns

T = TypeVar("T")


# Generated at 2022-06-25 15:19:45.223497
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    negated_pattern_0 = NegatedPattern()
    assert type(negated_pattern_0.__repr__()) == str


# Generated at 2022-06-25 15:19:46.560760
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    pass


# Generated at 2022-06-25 15:19:47.078934
# Unit test for method replace of class Base
def test_Base_replace():
    pass


# Generated at 2022-06-25 15:19:57.367075
# Unit test for method remove of class Base
def test_Base_remove():
    root = Node(type = 0)
    node = Node()
    assert node.remove() is None
    assert node.parent is None
    assert node.remove() is None
    root.append_child(node)
    assert node.remove() is 0
    assert node.parent is None
    root.append_child(node)
    assert node.remove() is 0
    assert node.parent is None
    root.append_child(Node(type = 0))
    root.append_child(node)
    assert node.remove() is 1
    assert node.parent is None
    root.append_child(node)
    assert node.remove() is 2
    assert node.parent is None
    root.append_child(node)
    assert node.remove() is 2
    assert node.parent is None


# Generated at 2022-06-25 15:20:20.617718
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from .grammar import Nonterminal
    from .parser import Parser

    parser = Parser(None, None)
    pattern = NodePattern(Nonterminal.file_input, None)
    pattern.wildcards = True
    wildcard_pattern = WildcardPattern()
    wildcard_pattern.content = [pattern]
    wildcard_pattern.min = 0
    wildcard_pattern.max = HUGE
    wildcard_pattern.name = None

    nodes = [(1, "b'#!/usr/bin/python3\\n'"), (2, "b''"), (3, "b''"), (4, "b'import sys'")]
    wildcard_pattern.generate_matches(nodes)


# Generated at 2022-06-25 15:20:21.359528
# Unit test for method depth of class Base
def test_Base_depth():
    assert Base().depth() == 0


# Generated at 2022-06-25 15:20:30.595136
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    pattern_0 = Pattern()
    next_sib = None
    pattern_0.next_sibling = next_sib
    next_sib = pattern_0.next_sibling
    assert next_sib is None
    pattern_0 = Pattern()
    suffix = pattern_0.get_suffix()
    assert suffix == ""
    pattern_0.next_sibling = None
    suffix = pattern_0.get_suffix()
    assert suffix == ""
    pattern_0.next_sibling = next_sib
    suffix = pattern_0.get_suffix()
    assert suffix == ""


# Generated at 2022-06-25 15:20:31.913517
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    negated_pattern_0 = NegatedPattern()
    negated_pattern_0-pre_order()


# Generated at 2022-06-25 15:20:41.597894
# Unit test for method clone of class Base
def test_Base_clone():
    root_node_0 = Node(0)
    node_1 = Node(1)
    node_2 = Node(2)
    node_3 = Node(3)
    node_4 = Node(4)
    node_5 = Node(5)
    node_6 = Node(6)
    node_7 = Node(7, [node_5])
    leaf_8 = Leaf(8, " ")
    leaf_9 = Leaf(9, "\n")
    leaf_10 = Leaf(10, "def")
    leaf_11 = Leaf(11, " ")
    leaf_12 = Leaf(12, "f")
    leaf_13 = Leaf(13, " ")
    leaf_14 = Leaf(14, "(")
    leaf_15 = Leaf(15, ")")

# Generated at 2022-06-25 15:20:51.200061
# Unit test for method insert_child of class Node
def test_Node_insert_child():

    # Test correct implementation of method insert_child
    def test_0():
        # Setup fresh Node
        new_node = Node(python_symbols.testlist_star_expr, [], None, None)
        # Insert a test node at position 0
        new_node.insert_child(0, Node(python_symbols.test, [], None, None))
        # Test if node is at position 0 of the list
        assert new_node.children[0].type == python_symbols.test
        # Insert a test node at position 1
        new_node.insert_child(1, Node(python_symbols.test, [], None, None))
        # Test if both nodes are added to the list
        assert new_node.children[0].type == python_symbols.test
        assert new_node.children

# Generated at 2022-06-25 15:20:56.536856
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    pattern_6 = Pattern()
    pattern_6.set_pattern(")")
    pattern_6.set_pattern(" ")
    pattern_6.set_pattern("]")
    pattern_6.set_pattern(" ")
    pattern_6.set_pattern("??")
    pattern_6.set_pattern("}")
    pattern_6.set_pattern(" ")
    pattern_6.set_pattern("+")
    pattern_6.set_pattern(" ")
    pattern_6.set_pattern("-")
    pattern_6.set_pattern(" ")
    pattern_6.set_pattern("%")
    pattern_6.set_pattern(" ")
    pattern_6.set_pattern("&")
    pattern_6.set_pattern(" ")

# Generated at 2022-06-25 15:20:58.697128
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    test_0 = Base()
    with pytest.raises(NotImplementedError):
        test_0.pre_order()


# Generated at 2022-06-25 15:21:00.863165
# Unit test for method set_child of class Node
def test_Node_set_child():
    pattern_0 = Node(0, [])
    pattern_1 = Leaf(0, "")
    pattern_0.set_child(0, pattern_1)
    pass



# Generated at 2022-06-25 15:21:02.684091
# Unit test for method remove of class Base
def test_Base_remove():
    for i in range(100):
        node = Base()
        test_case_0()
        assert node.remove() is None
        assert node.remove() is None

