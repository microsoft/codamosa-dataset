

# Generated at 2022-06-25 15:13:30.286300
# Unit test for method replace of class Base
def test_Base_replace():
    test_pattern_1 = Base()
    test_pattern_2 = Node()
    test_pattern_3 = Base()
    test_pattern_4 = Node()
    test_pattern_5 = Leaf()
    test_pattern_6 = Node()
    test_pattern_7 = Leaf()
    test_pattern_8 = Node()
    test_pattern_9 = Leaf()
    test_pattern_10 = Node()
    test_pattern_11 = Leaf()
    test_pattern_12 = Node()
    test_pattern_13 = Leaf()
    test_pattern_14 = Node()
    test_pattern_15 = Leaf()
    test_pattern_16 = Node()
    test_pattern_17 = Leaf()
    test_pattern_18 = Node()
    test_pattern_19 = Leaf()
    test_pattern_20 = Node()

# Generated at 2022-06-25 15:13:34.972978
# Unit test for method remove of class Base
def test_Base_remove():
    node_0 = Base()
    parent_1 = Node(None, [node_0])
    node_0_copy = node_0.clone()
    node_0_copy.remove()
    node_0_copy.remove()


# Generated at 2022-06-25 15:13:36.395992
# Unit test for method __eq__ of class Base
def test_Base___eq__():
  pass # FIXME


# Generated at 2022-06-25 15:13:38.195211
# Unit test for method replace of class Base
def test_Base_replace():
    node_0 = Base(0, None, None, None)
    node_0.replace(None)


# Generated at 2022-06-25 15:13:46.065706
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    tp = TuplePattern()
    fp = LeafPattern()

    pattern = WildcardPattern([[tp, fp]])

    # Loop over all posible nodes and assert that the match_seq()
    # fails or succeeds as expected.
    for i in range(8):
        node = tuple(i)
        assert pattern.match_seq([node]) == (i & 1) == 1
    for i in range(8):
        node = tuple(i)
        assert pattern.match_seq([node, node]) == (i & 1) == 1

    # Test to make sure the match_seq() function is recursive.
    for i in range(8):
        node = tuple(i)
        assert pattern.match_seq([node] * (i + 1)) == (i & 1) == 1

# Generated at 2022-06-25 15:13:48.078485
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    negated_pattern_0 = NegatedPattern()
    assert negated_pattern_0.get_lineno() is None


# Generated at 2022-06-25 15:13:52.821159
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Since attributes `type` and `content` are not declared with type
    # annotations, they are implicitly declared to be of type `Any`.
    pattern_0 = BasePattern(type=None, content=None)
    # Test method __repr__
    assert pattern_0.__repr__() == "BasePattern(None, None, None)"


# Generated at 2022-06-25 15:14:03.487149
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
  print('Testing get_lineno')
  base = Base()
  node = Node()
  leaf = Leaf()
  node = Node()

  node.children = [1,2,3]
  leaf.children = [1]

#  assert base.get_lineno() == None, "Either node or leaf is None"
#  assert node.get_lineno() == None, "Node is None"
#  assert leaf.get_lineno() == None, "Leaf is None"

  node.lineno = 12
  leaf.lineno = 15

  assert node.get_lineno() == 12, "Node is not None"
  assert leaf.get_lineno() == 15, "Leaf is not None"


# Generated at 2022-06-25 15:14:05.849098
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Raise AssertionError if __repr__ isn't called
    with pytest.raises(AssertionError):
        test_case_0()


# Generated at 2022-06-25 15:14:07.564582
# Unit test for method depth of class Base
def test_Base_depth():
    self = Base()
    p = self.depth()
    assert p == 0


# Generated at 2022-06-25 15:14:22.146047
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base = Base()
    assert base.get_lineno() is None, "Base.get_lineno()"


# Generated at 2022-06-25 15:14:24.974592
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    try:
        base_0.get_suffix()
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-25 15:14:26.894187
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_0 = Base()
    result = base_0.get_lineno()
    assert result == None


# Generated at 2022-06-25 15:14:29.755161
# Unit test for constructor of class NodePattern
def test_NodePattern():
  pattern_0 = NodePattern()
  assert pattern_0 is not None


# Generated at 2022-06-25 15:14:31.596646
# Unit test for method remove of class Base
def test_Base_remove():
    base_0 = Leaf(1, 'a')
    assert base_0.parent == None
    assert base_0.remove() == None


# Generated at 2022-06-25 15:14:40.141058
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    base_0 = Base()
    node_pattern = NodePattern()
    wildcard_pattern = WildcardPattern(name="bare_name")
    assert(wildcard_pattern.optimize() == wildcard_pattern)
    wildcard_pattern_0 = WildcardPattern(
        content=[
            [
                NodePattern(),
                NodePattern()
            ],
            [
                NodePattern(),
                NodePattern()
            ]
        ],
        max=1,
        name="bare_name"
    )
    wildcard_pattern.content = (
        wildcard_pattern_0,
    )
    wildcard_pattern_1 = WildcardPattern(
        content=(
            wildcard_pattern_0,
        ),
        min=1,
        max=2
    )

# Generated at 2022-06-25 15:14:44.369541
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    token_0 = Base(next_sibling = None, parent = None, children = [])
    # Do nothing
    assert token_0.get_suffix() == ""


# Generated at 2022-06-25 15:14:47.522442
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base_0 = Base()
    nodes = [base_0]
    res = base_0.generate_matches(nodes)
    assert len(res) == 0


# Generated at 2022-06-25 15:14:50.290304
# Unit test for method set_child of class Node
def test_Node_set_child():
    base_0 = Base()
    node_0 = Node(0, None, None, None)
    node_0.set_child(0, Node(0, None, None, None))


# Generated at 2022-06-25 15:14:59.647504
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_0 = Base()
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()
    text_6 = Text()
    text_7 = Text()
    text_8 = Text()
    text_9 = Text()
    text_10 = Text()
    text_11 = Text()
    text_12 = Text()
    text_13 = Text()
    text_14 = Text()
    text_15 = Text()
    text_16 = Text()
    text_17 = Text()
    text_18 = Text()
    text_19 = Text()
    text_20 = Text()
    text_21 = Text()
    text_22 = Text()
    text_23 = Text()

# Generated at 2022-06-25 15:15:34.022814
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node_0 = Node(None, None)


# Generated at 2022-06-25 15:15:38.661485
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base_0 = Base()
    base_pattern_0 = BasePattern()
    nodes = [base_0]
    matches = base_pattern_0.generate_matches(nodes)
    for match in matches:
        print(match)

# Generated at 2022-06-25 15:15:41.133084
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert Leaf(1, "test", None, None, []).pre_order()


# Generated at 2022-06-25 15:15:43.432366
# Unit test for method clone of class Base
def test_Base_clone():
    base_0 = Base()
    assert base_0.clone().__class__ == Base
    assert base_0.clone() is base_0


# Generated at 2022-06-25 15:15:46.414579
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    base_0 = Base()
    base_pre_order_0 = base_0.pre_order()
    assert type(base_pre_order_0) == Iterator


# Generated at 2022-06-25 15:15:49.466661
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(0, "")
    pre = l.pre_order()
    assert pre is not None
    assert len(list(pre)) == 1
    assert list(pre)[0] is l


# Generated at 2022-06-25 15:15:52.977500
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_p = BasePattern()
    node_l = [Node(21, [Leaf(1, 'a')])]
    r = base_p.match_seq(node_l)
    assert r is False
    assert node_l == [Node(21, [Leaf(1, 'a')])]


# Generated at 2022-06-25 15:15:56.174569
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf
    leaf_1 = Leaf(42, "")
    leaf_2 = Leaf(42, "")
    equal_result = (leaf_1 == leaf_2)
    assert equal_result == True


# Generated at 2022-06-25 15:16:04.183066
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    for min_val in range(2):
        for max_val in range(2):
            # test when content is not None
            assert WildcardPattern(min=min_val, max=max_val, content=[['a', 'b', 'c']]).optimize() == WildcardPattern(min=min_val, max=max_val, content=[['a', 'b', 'c']])

            # test when min = 1, max = 1
            assert WildcardPattern(min=1, max=1, content=[['a', 'b', 'c']]).optimize() == NodePattern(content=[['a', 'b', 'c']])
            assert WildcardPattern(min=1, max=1, content=None).optimize() == NodePattern(content=None)

            # test when min = 1 and subpattern is Wildcard

# Generated at 2022-06-25 15:16:08.632428
# Unit test for method post_order of class Node
def test_Node_post_order():
    try:
        node = Node(
            type = 256,
            children = [
            ],
        )
        assert (None,) == node.post_order.__defaults__
        value = node.post_order()
        assert isinstance(value, Iterator)
    except:
        print("An exception occurred when testing method post_order of class Node")
        raise


# Generated at 2022-06-25 15:16:34.811107
# Unit test for method clone of class Node
def test_Node_clone():
    '''
    Invokes clone method on Node object
    '''
    node_0 = Node(1, [1])
    node_0.clone()


# Generated at 2022-06-25 15:16:41.658058
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    def test(pattern, nodes):
        return pattern.match_seq(nodes)

    base_pattern_0 = BasePattern()
    test(base_pattern_0, [])
    base_pattern_1 = BasePattern()
    test(base_pattern_1, [])
    base_pattern_2 = BasePattern()
    test(base_pattern_2, [])
    base_pattern_3 = BasePattern()
    test(base_pattern_3, [])
    base_pattern_4 = BasePattern()
    test(base_pattern_4, [])
    base_pattern_5 = BasePattern()
    test(base_pattern_5, [])


# Generated at 2022-06-25 15:16:42.334114
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    pass



# Generated at 2022-06-25 15:16:44.694135
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    assert base_0.depth() == 0


# Generated at 2022-06-25 15:16:46.966576
# Unit test for method post_order of class Node
def test_Node_post_order():
    i = 0
    for node in base_0.post_order():
        if (i == 5):
            assert node == base_0
        i += 1


# Generated at 2022-06-25 15:16:48.728247
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    m = NodePattern(type=1)
    p = WildcardPattern(content=[m])
    n = NegatedPattern(content=p)

    with pytest.raises(AssertionError):
        n.generate_matches([1, 2, 3])


# Generated at 2022-06-25 15:16:57.917101
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test cases:
    # 0. default init
    # 1. None content
    # 2. WildcardPattern content
    # 3. NodePattern content
    # 4. LeafPattern content

    def base_0():
        # 0. default init
        for l in [None, '', 'a', 'ab', 'abc']:
            a = NegatedPattern()
            for count, r in a.generate_matches(l):
                raise RuntimeError('Failure at case 0 test 0.')
            for c, r in a.generate_matches(l[:0]):
                if count != 0 or r:
                    raise RuntimeError('Failure at case 0 test 1.')

    def base_1():
        # 1. None content
        for l in ['', 'a', 'ab', 'abc']:
            a = NegatedPattern

# Generated at 2022-06-25 15:16:59.929221
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    assert base_0.get_suffix() == "", "get_suffix() is broken"



# Generated at 2022-06-25 15:17:02.572421
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # The base class should always just return itself
    assert BasePattern().optimize() is BasePattern()


# Generated at 2022-06-25 15:17:03.942201
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(0, 0)
    leaf.post_order()


# Generated at 2022-06-25 15:17:42.179123
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    """
    Test for method post_order on class Leaf.
    """
    test_L = Leaf(0,0)
    test_L.location = (1,1)
    assert test_L.post_order() == [test_L]



# Generated at 2022-06-25 15:17:43.235418
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_0 = Base()


# Generated at 2022-06-25 15:17:49.874117
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    """Unit test for method match_seq of class WildcardPattern"""
    wildcard = WildcardPattern()
    pattern = r"""
    """
    result = wildcard.match_seq(
        [
            Node(257),
            Node(258),
            Node(258),
            Node(261),
            Node(263),
            Node(264),
            Leaf(1, "\n"),
            Leaf(1, "\n"),
            Leaf(1, "\n"),
            Node(265),
            Node(262),
        ]
    )
    if result != True:
        print("test_WildcardPattern_match_seq:FAILED")



# Generated at 2022-06-25 15:17:50.888779
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    test_case_0()


# Generated at 2022-06-25 15:17:51.798478
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_0 = Base()


# Generated at 2022-06-25 15:17:59.236404
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    name = None
    wildcard = WildcardPattern(name)
    wildcard_optimized = wildcard.optimize()
    assert wildcard_optimized != wildcard
    assert wildcard_optimized.name == name
    name = "bare_name"
    wildcard = WildcardPattern(name)
    wildcard_optimized = wildcard.optimize()
    assert wildcard_optimized == wildcard
    assert wildcard_optimized.name == name
    wildcard_min_0_max_HUGE = WildcardPattern(min = 0, max = HUGE)
    wildcard_min_0_max_HUGE_optimized = wildcard_min_0_max_HUGE.optimize()
    assert wildcard_min_0_max_HUGE_optimized != wildcard_min_0_max_HUGE

# Generated at 2022-06-25 15:18:00.589123
# Unit test for method leaves of class Base
def test_Base_leaves():
    base = Base()
    assert next(base.leaves()) is None

# Generated at 2022-06-25 15:18:06.279095
# Unit test for method replace of class Base
def test_Base_replace():
    base_0 = Base()
    node_0 = Node()
    node_1 = Node()
    node_0.children.append(base_0)
    base_0.parent = node_0
    base_0.replace(node_1)
    assert node_0.children == [node_1]
    assert node_1.parent == node_0
    assert base_0.parent is None


# Generated at 2022-06-25 15:18:10.321885
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    t=Leaf(1,'value',context=(None,(0,0)),fixers_applied=[])
    it=t.post_order()
    #print(it)
    for node in it:
        print(node)

#

# Generated at 2022-06-25 15:18:13.861480
# Unit test for method replace of class Base
def test_Base_replace():
    base_0 = Base()
    node_0 = Node(python_symbols.comp_iter, [], None)
    node_1 = Node(python_symbols.comp_iter, [], None)
    node_0.replace(node_1)


# Generated at 2022-06-25 15:20:54.757602
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_0 = Node(type=0, children=[])
    print(list(node_0.post_order()))


# Generated at 2022-06-25 15:21:02.831192
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    base_1 = Leaf(ord("d"), "d")
    test_case_0()
    base_2 = Leaf(ord("c"), "c")
    test_case_0()
    base_3 = Leaf(ord("e"), "e")
    test_case_0()
    base_4 = Leaf(ord("b"), "b")
    test_case_0()
    base_5 = Node(256, [base_1, base_2, base_3])
    test_case_0()
    base_6 = Leaf(ord("a"), "a")
    test_case_0()
    base_7 = Node(256, [base_4, base_5, base_6])
    test_case_0()
    base_8 = base_7.post_order()
    test_case_0()


# Generated at 2022-06-25 15:21:12.784171
# Unit test for function convert
def test_convert():
    base_0 = Base()
    # A grammar for unit testing
    import io
    import tokenize


# Generated at 2022-06-25 15:21:18.694060
# Unit test for method set_child of class Node
def test_Node_set_child():
    # Declaration of node object of class Base
    test_Base_0 = Base()
    # Declaration of node object of class Base with type int
    test_Base_1 = Base()
    test_Base_1.type = 2
    # Declaration of node object of class Base with type int
    test_Base_2 = Base()
    test_Base_2.type = 999
    test_Base_2.children = [test_Base_1]
    test_Base_2.parent = test_Base_0
    test_Base_2.was_changed = False
    test_Base_2.was_checked = True
    # Declaration of node object of class Node
    test_Node_0 = Node(test_Base_1, [test_Base_1], None)

# Generated at 2022-06-25 15:21:21.408807
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    wc = WildcardPattern()
    wc.match_seq([base_0])
    wc.match_seq([base_0, base_0])

# Generated at 2022-06-25 15:21:30.925137
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # Initialization
    test_node_0 = Leaf()
    test_node_1 = Leaf()
    test_node_2 = Node()
    test_node_2.children.append(test_node_1)
    test_node_2.children.append(test_node_0)
    test_node_3 = Leaf()
    test_node_4 = Node()
    test_node_4.children.append(test_node_2)
    test_node_4.children.append(test_node_3)
    # Empty test_node_5
    # Empty test_node_6
    test_node_2.parent = test_node_4
    test_node_1.parent = test_node_2
    test_node_0.parent = test_node_2

# Generated at 2022-06-25 15:21:36.079060
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base_0 = Base()
    base_1 = Base()
    base_2 = Base()
    base_1.set_child(0, base_2)
    base_2.set_child(0, base_0)
    base_3 = Leaf(0, "")

# Generated at 2022-06-25 15:21:38.241268
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    base_0 = Base()
    assert isinstance(base_0.post_order(), Iterator)
