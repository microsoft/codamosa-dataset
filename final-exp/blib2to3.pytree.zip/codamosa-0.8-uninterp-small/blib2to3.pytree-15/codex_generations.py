

# Generated at 2022-06-25 15:12:58.816817
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    base_0.parent = Node(0, None, None, None)
    base_0.parent.parent = Node(0, None, None, None)
    actual = base_0.depth()
    assert actual == 2, f"actual {actual}, expected 2"


# Generated at 2022-06-25 15:13:03.053661
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    not_implemented_0 = Base()
    not_implemented_1 = Base()
    not_implemented_0.__eq__(not_implemented_1)
    not_implemented_0 = Base()
    not_implemented_1 = int()
    not_implemented_0.__eq__(not_implemented_1)


# Generated at 2022-06-25 15:13:11.037521
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern(((Leaf(1), Leaf(2), Leaf(3)), (NodePattern(name='hello'), Leaf(4), Leaf(5), Leaf(6))), min=0, max=1, name='test')
    assert p.content[0][0].type == 1
    assert p.content[0][1].type == 2
    assert p.content[0][2].type == 3

    p.optimize()
    assert p.content[0][0].type == 1
    assert p.content[0][1].type == 2
    assert p.content[0][2].type == 3


# Generated at 2022-06-25 15:13:12.220869
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(-1) == -1


# Generated at 2022-06-25 15:13:16.991093
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    # Create a Leaf with default parameters
    leaf_0 = Leaf(31, "fvC%cN")
    # Get a iterator over post order iteration
    iterator_0 = leaf_0.post_order()
    # Verify next
    item_0 = next(iterator_0)
    assert item_0 is leaf_0
    # Verify StopIteration is raised
    with pytest.raises(StopIteration):
        next(iterator_0)


# Generated at 2022-06-25 15:13:20.808747
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    leaf_pattern_0 = LeafPattern(257, "*")
    leaf_pattern_1 = LeafPattern(257, "*")
    leaf_pattern_0._submatch(leaf_pattern_1, None)

    wildcard_pattern_0 = WildcardPattern(257, None)
    wildcard_pattern_0._submatch(leaf_pattern_1, None)
    wildcard_pattern_0.optimize()
    wildcard_pattern_0._submatch(leaf_pattern_1, None)



# Generated at 2022-06-25 15:13:23.132583
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    assert base_0.depth() == 0
    return



# Generated at 2022-06-25 15:13:35.240994
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():

    # Create a list of nodes
    nodes = []
    for i in range(10):
        nodes.append(Node(i))

    # Create an empty sub pattern
    content = None
    np = NegatedPattern(content)

    for c, r in np.generate_matches(nodes):
        assert c == 0, ("Pattern did not match empty sequence of nodes", c)
        assert len(r) == 0, ("Results should be an empty dictionary", r)

    # Create a sub pattern
    content = NodePattern()
    np = NegatedPattern(content)

    for c, r in np.generate_matches(nodes):
        assert c == 0, ("Pattern did not match empty sequence of nodes", c)
        assert len(r) == 0, ("Results should be an empty dictionary", r)


# Generated at 2022-06-25 15:13:38.755136
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern_0 = WildcardPattern([])
    pattern_0 = pattern_0.optimize()
    assert pattern_0.min == 0 and pattern_0.max == HUGE, pattern_0


# Generated at 2022-06-25 15:13:46.534302
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    base_0 = Base()
    sequence_0 = ()
    string_0 = "tuple(%s)"
    string_1 = "node(%s, %s)"
    tuple_0 = (base_0, base_0)
    pattern_0 = NodePattern(type=0)
    tuple_1 = ()
    wildcard_pattern_0 = WildcardPattern(tuple_1)
    tuple_2 = (wildcard_pattern_0,)
    wildcard_pattern_1 = WildcardPattern(tuple_2)
    tuple_3 = (wildcard_pattern_1, NodePattern(type=0))
    wildcard_pattern_2 = WildcardPattern(tuple_3)
    tuple_4 = (wildcard_pattern_2, wildcard_pattern_2)
    wildcard_pattern_3 = WildcardPattern

# Generated at 2022-06-25 15:14:42.456926
# Unit test for method clone of class Base
def test_Base_clone():
    assert base_0.clone() is None


# Generated at 2022-06-25 15:14:45.417342
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    base_pattern = BasePattern()
    repr_ = repr(base_pattern)


# Generated at 2022-06-25 15:14:55.041700
# Unit test for method pre_order of class Base
def test_Base_pre_order():
  # Create a new empty Node instance
  # Set the value of the {} in Node
  node_0 = Node(0, None, None, [])
  # Create a new empty Leaf instance
  leaf_0 = Leaf(0, None, None, [])
  # Create a new empty Leaf instance
  leaf_1 = Leaf(0, None, None, [])
  # Create a new empty Leaf instance
  leaf_2 = Leaf(0, None, None, [])
  try:
    for child in (leaf_0, leaf_1, leaf_2):
      node_0.append_child(child)
  except:
    # Pass
    pass
  # Create a new empty Node instance
  node_1 = Node(0, None, None, [])
  # Create a new empty Leaf instance

# Generated at 2022-06-25 15:14:55.975698
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    test_case_0()

# Generated at 2022-06-25 15:15:00.294546
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # A simple case
    alt = [NodePattern(), NodePattern()]
    alt1 = [NodePattern(), NodePattern()]
    pattern = WildcardPattern([alt, alt1], 2, 2, "name")
    nodes = [Base(), Base()]
    ans = pattern.generate_matches(nodes)
    res = list(ans)
    assert res == [(2, {"name":nodes})]
    # A more complex case
    alt = [NodePattern(), NodePattern()]
    alt1 = [NodePattern(), WildcardPattern([alt], 2, 2, "subname")]
    pattern = WildcardPattern([alt1, alt], 2, 2, "name")
    nodes = [Base(), Base(), Base(), Base()]
    ans = pattern.generate_matches(nodes)
    res = list(ans)


# Generated at 2022-06-25 15:15:02.049541
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(0,"")
    leaves = l.leaves()
    assert leaves.__next__() == l
    try:
        leaves.__next__()
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-25 15:15:10.948622
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():

    def _make_node(name, children):
        return Node(
            type=name,
            children=children,
            lineno=0,
            column=0,
            filename="",
            prefix="",
        )

    # Assert that two WildcardPattern objects are same
    def assert_equal_wildcard(expected, received):
        assert isinstance(expected, WildcardPattern)
        assert isinstance(received, WildcardPattern)
        assert expected.type == received.type
        assert expected.min == received.min
        assert expected.max == received.max
        assert expected.name == received.name
        assert expected.wildcards == received.wildcards
        if expected.content is None:
            assert received.content is None
        else:
            assert len(expected.content) == len(received.content)

# Generated at 2022-06-25 15:15:13.029018
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_0 = Base()
    assert base_0.get_lineno() == None


# Generated at 2022-06-25 15:15:14.858909
# Unit test for method remove of class Base
def test_Base_remove():
    base_0 = Base()
    base_0.remove()


# Generated at 2022-06-25 15:15:20.673343
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    this_node = Leaf(1, "alpha")
    assert this_node.get_suffix() == ""

    # Test for Node object
    child_0 = Node(1, None, None, None)
    child_1 = Node(2, None, None, None)
    this_node = Node(2, [child_0, child_1])
    assert this_node.get_suffix() == ""


# Generated at 2022-06-25 15:15:37.391995
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    nodes = [1, 2, 3, 4, 5]
    pat = NegatedPattern()
    m = pat.generate_matches(nodes)
    assert(len(list(m)) == 1)


# Generated at 2022-06-25 15:15:41.500298
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    assert type_repr(python_symbols.DOUBLESTAR) == "DOUBLESTAR"
    assert type_repr("Foo") == "Foo"


# Generated at 2022-06-25 15:15:44.713905
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    def test_func(nodes):
        return BasePattern.generate_matches(nodes)

    # Test with an empty node list
    nodes = []
    # Expected result:
    expected = iter([])
    assert test_func(nodes) == expected

# Generated at 2022-06-25 15:15:46.123211
# Unit test for method depth of class Base
def test_Base_depth():
    base_0 = Base()
    assert 0 == base_0.depth()


# Generated at 2022-06-25 15:15:53.040954
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    test_node_obj = Node(
        1,
        [
            Leaf(2, "test"),
            Leaf(3, " "),
            Leaf(4, "input"),
            Leaf(5, " "),
            Node(6, [Leaf(7, "test1")]),
            Leaf(8, " "),
            Node(9, [Leaf(10, "test2")]),
        ],
    )
    res = list(test_node_obj.pre_order())
    assert res[0] == test_node_obj
    assert res[-1] == Leaf(10, "test2")


# Generated at 2022-06-25 15:15:55.951021
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base_pattern_0 = BasePattern()
    nodes = []
    with pytest.raises(NotImplementedError):
        base_pattern_0.generate_matches(nodes)


# Generated at 2022-06-25 15:15:57.930973
# Unit test for method __repr__ of class Node

# Generated at 2022-06-25 15:16:00.811702
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    pattern = WildcardPattern([], 0, 1, "Num")
    optimized_pattern = pattern.optimize()
    assert isinstance(optimized_pattern, NodePattern)
    assert optimized_pattern.name == "Num"


# Generated at 2022-06-25 15:16:09.331883
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    
    # Test for Node.pre_order() with valid input
    def test_Node_pre_order_valid_input():
        #create tree
        test_tree = Node(
            symbol=0, children=[
                Node(
                    symbol=1, children=[
                        Node(
                            symbol=2, children=[
                                Leaf(value='1'),
                                Leaf(value='2')
                            ]
                        ),
                        Node(
                            symbol=3, children=[
                                Leaf(value='3')
                            ]
                        )
                    ]
                )
            ]
        )
        #create iterator
        it = iter(test_tree.pre_order())
        #run tests
        assert next(it) == test_tree
        assert next(it) == test_tree.children[0]

# Generated at 2022-06-25 15:16:17.093580
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    """
    Method pre_order of class Leaf should return a pre-order iterator for the tree
    """
    method = Leaf.pre_order.__func__
    # Test 1
    base = Leaf.__init__
    base.__defaults__ = (None, [], 0, (), None)
    leaf = Leaf(262, 'a')

    def test_1():
        assert next(leaf.pre_order()) is leaf

    # Test 2
    def test_2():
        assert next(leaf.pre_order()) is leaf

    # Test 3
    def test_3():
        assert next(leaf.pre_order()) is leaf

    # Test 4
    def test_4():
        assert next(leaf.pre_order()) is leaf


# Generated at 2022-06-25 15:16:47.832229
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    base_0 = BasePattern()
    try:
        assert repr(base_0) == "<BasePattern>"
    except:
        assert repr(base_0) == "<BasePattern at 0x7f1d8c8a7d30>"

# Generated at 2022-06-25 15:16:54.063950
# Unit test for method leaves of class Base
def test_Base_leaves():
    m = Match()
    base_1 = Leaf(1, 'hi')
    base_2 = Leaf(2, 'lo')
    base_3 = Node(3, None, [base_1, base_2])
    # test case: base_3
    # test case result: [base_1, base_2]
    assert (list(base_3.leaves()) == [base_1, base_2])


# Generated at 2022-06-25 15:16:56.210394
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    base_pattern_0 = BasePattern()
    # Test for base case.
    assert type(base_pattern_0.match_seq([], None)) == bool


# Generated at 2022-06-25 15:16:58.803888
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf_0 = Leaf(3, "abc")
    assert leaf_0.leaves() == [leaf_0]


# Generated at 2022-06-25 15:17:00.103711
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_0 = Base()
    assert False


# Generated at 2022-06-25 15:17:05.975206
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp_0 = WildcardPattern()
    assert(wp_0.optimize() == wp_0)

    wp_1 = WildcardPattern(content=[[LeafPattern(type=10, content='11')]], min=1, max=1)
    assert(wp_1.optimize() == LeafPattern(type=10, content='11'))

    wp_2 = WildcardPatt

# Generated at 2022-06-25 15:17:09.504861
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Setup
    base_0 = Base()
    # Test
    example = base_0.generate_matches()
    # Comparing types
    assert type(example) == list
    # Comparing sizes
    assert len(example) == 0



# Generated at 2022-06-25 15:17:11.393079
# Unit test for method post_order of class Node
def test_Node_post_order():
    node = Node(256, [Node(256, None), Leaf(256, None)])
    node.post_order()


# Generated at 2022-06-25 15:17:11.996974
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern()


# Generated at 2022-06-25 15:17:17.066487
# Unit test for method clone of class Base
def test_Base_clone():
    from copy import deepcopy
    instance_0 = Node(type=0, children=[Leaf(type=0, value='0'), Node(type=1, children=[Leaf(type=1, value='1'), Leaf(type=1, value='1')]), Leaf(type=0, value='0')])
    children_0 = [instance_0]
    instance_1 = Node(type=0, children=children_0)
    Base_clone = instance_1.clone()
    assert (Base_clone == deepcopy(instance_1))



# Generated at 2022-06-25 15:17:46.658116
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from blib2to3.pygram import python_symbols as syms
    from .pytree import Leaf, Node
    from . import pytree
    # Concrete class
    base_post_order = Base()
    expected_return = None

    # Manual test
    node_1 = pytree.Node(syms.expr_stmt, [])
    node_1.children = [Leaf(token_type=1, value='x'), Leaf(token_type=1, value='='), Leaf(token_type=1, value='y')]
    expected_return = node_1.pre_order()
    actual_return = base_post_order.pre_order()
    assert actual_return == expected_return


# Generated at 2022-06-25 15:17:49.956596
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"
    assert type_repr(python_symbols.SPACE) == "SPACE"
    assert type_repr(python_symbols.INDENT) == "INDENT"


# Generated at 2022-06-25 15:17:52.631965
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    base_0 = Base()
    nodes = ["Node"]
    result_generator = base_0.generate_matches(nodes)
    result_list = list(result_generator)
    assert len(result_list) == 1
    assert result_list[0][1] == {}
    assert result_list[0][0] == 1



# Generated at 2022-06-25 15:17:53.964230
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    test_leaf = Leaf(1,"")
    assert len(list(test_leaf.leaves())) == 1


# Generated at 2022-06-25 15:18:00.426259
# Unit test for method replace of class Base
def test_Base_replace():
    if not callable(Base.replace):
        raise Exception(
            "Method 'replace' not defined for type %s" % type(Base),
        )
    node_0 = Node()
    node_0.type = 4
    node_0.children = []
    node_0.children.append(Leaf())
    node_0.children[0].type = 270
    node_0.children[0].value = "print"
    node_0.children.append(Leaf())
    node_0.children[1].type = 57
    node_0.children[1].value = "("
    node_0.children.append(Node())
    node_0.children[2].type = 4
    node_0.children[2].children = []
    node_0.children[2].children.append(Leaf())

# Generated at 2022-06-25 15:18:04.568973
# Unit test for function generate_matches
def test_generate_matches():
    t = Text()
    t.value = "test"
    leafs = [t, t]
    base_0 = Base()
    base_1 = Base()
    base_0.children = leafs
    base_1.children = [base_0]
    pattern = BasePattern()
    pattern.type = Pattern.TEXT
    pattern_2 = BasePattern()
    pattern_2.type = Pattern.TEXT
    pattern_2.content = [pattern]
    results = []
    for _ in generate_matches([pattern_2], base_1.children):
        results.append(_)
    assert len(results) != 0
    assert results[0][0] == 1
    assert results[0][1] == {}

# Generated at 2022-06-25 15:18:12.595872
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms

    for n in [Leaf(1, ""), Leaf(1, "", (1, 2)),
              Node(syms.decorator, [Leaf(1, ""), Leaf(1, "", (1, 2))]),
              Node(syms.decorator, [Leaf(1, "", (1, 2))])]:
        assert n.get_lineno() == 1
    assert Node(syms.decorator, [Leaf(1, "")]).get_lineno() is None


# Generated at 2022-06-25 15:18:15.957894
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_0 = Node(256, [Leaf(1, "")])
    node_1 = PreOrderNodeGenerator(node_0)
    node_2 = next(node_1)
    assert node_2 is node_0


# Generated at 2022-06-25 15:18:18.566148
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_0 = BasePattern()
    # This is actually wrong, but ok for now
    if (base_0.optimize() != base_0):
        raise AssertionError()


# Generated at 2022-06-25 15:18:21.226381
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_0 = Base()
    base_1 = Base()
    base_0.children = [base_1]
    base_0.leaves()


# Generated at 2022-06-25 15:19:36.689825
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_0 = BasePattern()
    base_1 = BasePattern()
    base_pattern = base_1.optimize(base_0)
    assert base_pattern == base_0


# Generated at 2022-06-25 15:19:37.822575
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    base_1 = Base()
    base_1.get_lineno()



# Generated at 2022-06-25 15:19:43.511720
# Unit test for function generate_matches
def test_generate_matches():
    # Test with empty sequence
    test_nodes = []
    test_patterns = []
    # Check first case
    assert list(generate_matches(test_patterns, test_nodes)) == [(0, {})]
    # Test with sequence of nodes
    test_nodes = list(range(3))
    test_patterns = [1, 2, 3]
    assert list(generate_matches(test_patterns, test_nodes)) == []
    # Test with sequence of patterns
    test_nodes = list(range(3))
    test_patterns = [1, 2, 3]
    assert list(generate_matches(test_patterns, test_nodes)) == []
    # Test with sequence of nodes and patterns
    test_nodes = list(range(5))
    test_pattern

# Generated at 2022-06-25 15:19:45.181515
# Unit test for method replace of class Base
def test_Base_replace():
    base_0 = Base()
    base_0.replace('=')


# Generated at 2022-06-25 15:19:46.738303
# Unit test for method clone of class Base
def test_Base_clone():
    clone_0 = Base.clone(base_0)


# Generated at 2022-06-25 15:19:49.115890
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_0 = Base()
    case_0 = base_0.__eq__(base_0)
    print("case_0: " + str(case_0))


# Generated at 2022-06-25 15:19:58.988883
# Unit test for function generate_matches
def test_generate_matches():
    node1 = NL(0, None, [], None)
    node2 = NL(0, None, [], None)
    node3 = NL(0, None, [], None)
    node4 = NL(0, None, [], None)
    node5 = NL(0, None, [], None)
    node6 = NL(0, None, [], None)
    node7 = NL(0, None, [], None)
    node8 = NL(0, None, [], None)
    node9 = NL(0, None, [], None)
    node10 = NL(0, None, [], None)
    node11 = NL(0, None, [], None)
    node12 = NL(0, None, [], None)
    pattern1 = NodePattern()
    pattern2 = NodePattern()
    pattern3

# Generated at 2022-06-25 15:20:02.622236
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    # Test case for method generate_matches of class BasePattern
    base_0 = Base()
    nodes = []
    gen_matches = base_0.generate_matches(nodes)
    assert isinstance(gen_matches, Iterator[Tuple[int, _Results]])


# Generated at 2022-06-25 15:20:08.498270
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    """Unit test for method match_seq of class BasePattern."""
    wildcard_pattern_0 = BasePattern()
    wildcard_pattern_0.type = 256
    wildcard_pattern_0.content = {}
    wildcard_pattern_0.name = 'foo'
    nodes = [0]
    results = wildcard_pattern_0.match_seq(nodes)
    assert results == False


# Generated at 2022-06-25 15:20:11.122734
# Unit test for method post_order of class Base
def test_Base_post_order():
    base_0 = Base()
    try:
        base_0.post_order()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:20:36.188639
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    base_0.next_sibling = "!@#$%^&*()"
    assert base_0.get_suffix() == "!@#$%^&*()"


NodeType = TypeVar("NodeType", bound="Node")



# Generated at 2022-06-25 15:20:40.183246
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    assert base_0.get_suffix() == "", "get_suffix() failed"


# Generated at 2022-06-25 15:20:49.729221
# Unit test for method depth of class Base
def test_Base_depth():
    # Testing instance method 'depth' of class 'Base'
    #
    # Tests that the method returns 0 if no parent.
    base_0 = Base()
    base_0.parent = None
    assert base_0.depth() == 0, "Error: Test 1 failed"
    #
    # Tests that the parent depth is accounted for.
    base_1 = Base()
    base_0.parent = base_1
    base_1.parent = base_1
    base_1.parent = None
    assert base_0.depth() == 2, "Error: Test 2 failed"


X = TypeVar("X")

NodeType = TypeVar("NodeType", bound="Node")  # typing.overload doesn't work



# Generated at 2022-06-25 15:20:55.661832
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_0 = Base()
    for i in base_0.leaves():
        print(i)

if __name__ == '__main__':
    test_case_0()
    test_Base_leaves()



# Generated at 2022-06-25 15:20:56.212137
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    pass



# Generated at 2022-06-25 15:20:58.519856
# Unit test for method set_child of class Node
def test_Node_set_child():
    c = Node(1, [])
    n = Leaf(1, 'a')
    c.set_child(0, n)


# Generated at 2022-06-25 15:21:01.115215
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_1 = Base()
    base_2 = Base()
    res_3 = base_1.__eq__(base_2)
    assert res_3 == NotImplemented



# Generated at 2022-06-25 15:21:02.979320
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    b = BasePattern()
    assert b.match_seq([]) == False
    assert b.match_seq([Leaf(0, '')]) == False


# Generated at 2022-06-25 15:21:06.379682
# Unit test for method post_order of class Node
def test_Node_post_order():
    # Unit test for method of class Node
    # Instantiating a Tree
    tree = Node(1, [])
    # Test whether the method post_order is returning a post-order iterator
    # of the tree
    assert list(tree.post_order()) == [tree]


# Generated at 2022-06-25 15:21:16.995469
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    nodes = [Base(), Base(type=1, pos=0), Base(type=259, pos=1)]
    results = [None, None, None]
    results[0] = {'name': nodes[1], 'content': '0'}
    results[1] = {'name': nodes[2], 'content': '1'}

    # Test case with n==0
    # n==0, nodes and results are empty lists.
    with pytest.raises(IndexError):
        nodes[0].match(nodes, results[0])

    # Test case with n==1
    assert nodes[0].match(nodes[1:], results[0]) == False
    assert nodes[1].match(nodes[1:], results[0]) == True