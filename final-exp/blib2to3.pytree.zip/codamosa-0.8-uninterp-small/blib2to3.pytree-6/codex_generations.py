

# Generated at 2022-06-25 15:13:17.286252
# Unit test for function generate_matches
def test_generate_matches():
    # Empty patten and empty node sequence - should return True
    test_case = ([], [])
    expected_output = [(0, {})]
    actual_output = [x for x in generate_matches(*test_case)]
    assert actual_output == expected_output, (
        "Test case: " + str(tuple(test_case)) + "\n"
        + "Expected output: " + str(tuple(expected_output)) + "\n"
        + "Actual output: " + str(tuple(actual_output)) + "\n"
    )

    # Empty patten and non-empty node string - should return False
    test_case = ([], [test_case_0])
    expected_output = []
    actual_output = [x for x in generate_matches(*test_case)]
    assert actual_

# Generated at 2022-06-25 15:13:19.322336
# Unit test for method remove of class Base
def test_Base_remove():
    # Setting up the test case
    Base_instance_0 = Base()
    # Calling method remove of class Base
    Base_instance_0.remove()
    # Checking if the test case succeeded
    assert Base_instance_0.parent == None


# Generated at 2022-06-25 15:13:30.496262
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2 import token

    node_pattern_0 = NodePattern(
        token.DOT,
        (LeafPattern(token.NAME, "x"), WildcardPattern()),
        "x",
    )
    node_pattern_0_opy_0 = node_pattern_0.match(Node(256, []))
    assert node_pattern_0_opy_0 == False
    node_pattern_0_opy_1 = node_pattern_0.match(Node(token.DOT, [Node(256, [])]))
    assert node_pattern_0_opy_1 == False
    node_pattern_0_opy_2 = node_pattern_0.match(Node(token.DOT, [Leaf(1, "x")]))
    assert node_pattern_0_opy_2 == False
    node_

# Generated at 2022-06-25 15:13:35.514346
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_1 = WildcardPattern()
    assert wildcard_pattern_0.__eq__(wildcard_pattern_1), "Expected \\'True\\', but got \\'False\\'"


# Generated at 2022-06-25 15:13:39.186186
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    wildcard_pattern_0 = WildcardPattern()
    nodes_0 = []
    results_0 = None
    assert wildcard_pattern_0.match_seq(nodes_0, results_0) == True, "match_seq"


# Generated at 2022-06-25 15:13:41.533575
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf_0 = Leaf(
        None, None, None
    )
    suite_0__p = suite_0(leaf_0)
    assert suite_0__p


# Generated at 2022-06-25 15:13:46.743951
# Unit test for method remove of class Base
def test_Base_remove():
    node0 = Node(0, children=[Leaf(4, ""), Leaf(4, ""), Leaf(4, ""), Leaf(4, "")])
    node1 = Leaf(4, "")
    node0.children.append(node1)
    assert node0.remove() == 4
    assert node0.children[-1] is not node1


# Generated at 2022-06-25 15:13:49.104691
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    wildcard_pattern_2 = WildcardPattern()
    negated_pattern_3 = NegatedPattern(wildcard_pattern_2)

    # Test exception thrown from generate_matches of NegatedPattern
    try:
        negated_pattern_3.generate_matches('foo')
    except TypeError:
        pass


# Generated at 2022-06-25 15:13:58.698524
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test case 0
    wildcard_pattern_0 = WildcardPattern()
    wildcard_pattern_0.optimize()

    # Test case 1
    wildcard_pattern_1 = WildcardPattern(min=1, max=1)
    wildcard_pattern_1.optimize()

    # Test case 2
    wildcard_pattern_2 = WildcardPattern(min=1, max=1)
    wildcard_pattern_2.optimize()

    # Test case 3
    wildcard_pattern_3 = WildcardPattern(min=1, max=1)
    wildcard_pattern_3.type = 0
    wildcard_pattern_3.content = None
    node_pattern_0 = NodePattern()
    wildcard_pattern_3.optimize()

    # Test case 4
    wildcard_pattern_4 = Wildcard

# Generated at 2022-06-25 15:14:02.359523
# Unit test for method clone of class Base
def test_Base_clone():
    obj_0 = Node(type_0, children_0)
    obj_1 = obj_0.clone()
    assert obj_1 == obj_0



# Generated at 2022-06-25 15:15:21.930321
# Unit test for method post_order of class Base
def test_Base_post_order():
    root = Node(1, [Leaf(2, "1"), Node(3, [Leaf(4, "2")]), Leaf(5, "3")])
    children = []
    for node in root.post_order():
        children.append(node)
    assert children[0] == Leaf(5, "3")
    assert children[1] == Leaf(4, "2")
    assert children[2] == Node(3, [Leaf(4, "2")])
    assert children[3] == Leaf(2, "1")
    assert children[4] == Node(1, [Leaf(2, "1"), Node(3, [Leaf(4, "2")]), Leaf(5, "3")])



# Generated at 2022-06-25 15:15:26.029718
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():


    class BH:

        def __init__(self, child):
            self.child = child

        def __repr__(self):
            return "BH(%r)" % (self.child,)

    bh = BH("foo")

    class BP(BasePattern):
        type: int
        type = 42

        def match(self, node):
            return node is bh

    bp = BP()
    assert list(bp.generate_matches([bh])) == [(1, {})]



# Generated at 2022-06-25 15:15:28.314467
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    len_0 = 0
    wildcard_pattern_0 = WildcardPattern()
    nodes_0 = []
    it_0 = wildcard_pattern_0.generate_matches(nodes_0)
    while 1:
        try:
            assert len_0 == next(it_0)
        except StopIteration:
            break


# Generated at 2022-06-25 15:15:39.614087
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Setup
    dt = Leaf(1, "")
    stmnt = Leaf(1, "")
    stmnt.suffix = ""
    func_def = Node(syms.funcdef, [Leaf(1, "def"), Node(syms.parameters, [Leaf(1, "("), Leaf(1, ")")]), Leaf(1, ":"), Node(syms.suite, [Leaf(1, "pass")])])
    func_def.prefix = ""
    mod = Node(syms.file_input, [stmnt, dt, func_def])
    dt.parent = mod
    stmnt.parent = mod
    func_def.parent = mod
    # Exercise & Verify
    assert "+" + mod.get_suffix() == mod.children[0].suffix


# Generated at 2022-06-25 15:15:40.895869
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    wildcard_pattern_0 = WildcardPattern()
    Node(0, [])



# Generated at 2022-06-25 15:15:44.254913
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    wildcard_pattern_13 = WildcardPattern()
    assert wildcard_pattern_13.optimize() is wildcard_pattern_13
    wildcard_pattern_8 = WildcardPattern()
    assert wildcard_pattern_8.optimize() is wildcard_pattern_8


# Generated at 2022-06-25 15:15:46.288653
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_0 = Leaf(0, "")
    test_Leaf_post_order_verdict_0 = leaf_0.post_order()


# Generated at 2022-06-25 15:15:52.956102
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_pattern_0 = BasePattern('WildcardPattern', {"a", "b", "c"})
    wildcard_pattern_0 = WildcardPattern('c', 'd')
    wildcard_pattern_1 = WildcardPattern()
    result_0 = base_pattern_0.optimize()
    result_1 = wildcard_pattern_0.optimize()
    result_2 = wildcard_pattern_1.optimize()
    assert result_0 == base_pattern_0
    assert result_1 == wildcard_pattern_0
    assert result_2 == wildcard_pattern_1


# Generated at 2022-06-25 15:15:55.528942
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    wildcard_pattern_0 = WildcardPattern()
    assert wildcard_pattern_0.case_matches(Leaf(0,"value",None,"prefix"))


# Generated at 2022-06-25 15:15:56.182982
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    pass


# Generated at 2022-06-25 15:16:53.622527
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wildcard_pattern = WildcardPattern(min=1)
    assert wildcard_pattern.optimize() == wildcard_pattern
    wildcard_pattern = WildcardPattern(content=[[NodePattern()]], min=5, max=8)
    assert wildcard_pattern.optimize() == wildcard_pattern
    wildcard_pattern = WildcardPattern(content=[[NodePattern()]], min=1, max=2)
    assert wildcard_pattern.optimize() == NodePattern()
    wildcard_pattern = WildcardPattern(content=[[NodePattern()]], min=4, max=4)
    assert wildcard_pattern.optimize() == WildcardPattern(min=4, max=4, content=[[NodePattern()]])

# Generated at 2022-06-25 15:16:55.254646
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    base_pattern_obj = BasePattern()
    assert base_pattern_obj.__repr__() is not None



# Generated at 2022-06-25 15:16:57.695203
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    basePattern = BasePattern()
    print(basePattern.__repr__())


# Generated at 2022-06-25 15:17:00.061894
# Unit test for method leaves of class Base
def test_Base_leaves():
    base_0 = Base()
    base_0.children = []
    iter_0 = base_0.leaves()
    assert not next(iter_0, None)



# Generated at 2022-06-25 15:17:09.546611
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l_0 = Leaf(0,"hello")
    l_1 = Leaf(1, "world")
    l_2 = Leaf(2, "nice")
    l_3 = Leaf(3, "to")
    l_4 = Leaf(4, "meet")
    l_5 = Leaf(5, "you")
    l_6 = Leaf(6, "!")
    sequence_compare([l_0, l_1, l_2, l_3, l_4, l_5, l_6],
                     l_0.pre_order(), lambda x, y : x == y)
    assert l_0.pre_order() == [l_0]
    assert l_1.pre_order() == [l_1]


# Generated at 2022-06-25 15:17:14.265845
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Assigning values to variables
    pattern = Base()
    nodes = nodes = [Leaf(0,"",0),Leaf(0,"",0),Node(0,[Leaf(0,"",0),Leaf(0,"",0),Leaf(0,"",0)],0)]
    # Call the function
    result = pattern.generate_matches(nodes)
    # Check the expected result against the actual result
    assert [], result


# Generated at 2022-06-25 15:17:18.758608
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Test case 1
    from . import pgen2
    from .tokenize import TokenInfo
    base_0 = Base()
    wildcardpattern_0 = WildcardPattern(content=None, min=1, max=1, name=None)
    node_3 = Node(type=258, children=[], context=base_0.context)
    nodepattern_0 = NodePattern(type=258, content=None, name=None)
    assert wildcardpattern_0.optimize() == nodepattern_0

# Generated at 2022-06-25 15:17:20.634467
# Unit test for constructor of class NodePattern
def test_NodePattern():
    node_0 = NodePattern()



# Generated at 2022-06-25 15:17:23.343467
# Unit test for method clone of class Base
def test_Base_clone():
    base_0 = Base()
    try:
        base_0.clone()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-25 15:17:25.710077
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    base_pattern = BasePattern()
    base_pattern_repr = base_pattern.__repr__()
    assert base_pattern_repr == "BasePattern()"



# Generated at 2022-06-25 15:17:59.744870
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_0 = Base()
    base_0.get_suffix()


# Generated at 2022-06-25 15:18:07.050337
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from .pytree import Leaf, Node
    from .pgen2 import token

    a = Leaf(token.NAME, 'a')
    b = Leaf(token.NAME, 'b')
    c = Leaf(token.NAME, 'c')
    n = Node(sym.foo, [a, b, c])
    if repr(n) != "Node(foo, [Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c')])":
        sys.exit(-1)

    sys.exit(0)


# Generated at 2022-06-25 15:18:09.892940
# Unit test for method post_order of class Base
def test_Base_post_order():
    assert isinstance(Base.post_order(Base()), Iterator)
    assert isinstance(Base.post_order(Base()), Iterator[NL])


# Generated at 2022-06-25 15:18:19.134327
# Unit test for method replace of class Base
def test_Base_replace():
    parent = Node(type=0, children=[Leaf(type=1, value=1), Leaf(type=3, value=3), Leaf(type=2, value=2)], parent=None)
    leaf = Leaf(type=4, value=4)
    parent.replace(leaf)
    assert parent.children == [leaf]
    leaf.replace(None)
    assert parent.children == []
    node = Node(type=5, children=[Leaf(type=6, value=6), Leaf(type=7, value=7), Leaf(type=8, value=8)], parent=None)
    leaf.replace([Leaf(type=9, value=9), Leaf(type=10, value=10)])

# Generated at 2022-06-25 15:18:22.121222
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    base_0 = Base()
    leaf_1 = Leaf(1,"2")
    base_0.append_child(leaf_1)
    assert base_0.leaves() == leaf_1.leaves()


# Generated at 2022-06-25 15:18:23.770261
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    c = Leaf(0,"print1",None,None)
    assert list(c.pre_order()) == [c]


# Generated at 2022-06-25 15:18:25.562158
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # Create a Leaf object for testing
    leaf = Leaf(1, 'foo')

    # Call the method pre_order of the object for testing
    leaf.pre_order()


# Generated at 2022-06-25 15:18:28.564282
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    try:
        base_0 = Base()
        base_0.get_suffix()
    # The exception thrown must be of class "Exception"
    except Exception as exception:
        return True
    else:
        return False


# Generated at 2022-06-25 15:18:31.166925
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    def test_generate_matches():
        base_1 = Base()
        assert base_1.generate_matches([]) == iter([])


# Generated at 2022-06-25 15:18:33.286367
# Unit test for method set_child of class Node
def test_Node_set_child():
    node_set_child = Node()
    node_set_child.set_child(1, '')


# Generated at 2022-06-25 15:19:33.064072
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_get_suffix = Base()
    base_get_suffix_0 = base_get_suffix.get_suffix()


# Generated at 2022-06-25 15:19:44.136889
# Unit test for method pre_order of class Base
def test_Base_pre_order():

    # Test case 0
    base_0 = Base()
    post_order_iter = iter(base_0.pre_order())
    assert next(post_order_iter) == base_0
    try:
        next(post_order_iter)
        assert False
    except StopIteration:
        assert True

    # Test case 1
    base_1 = Base()
    leaf_0 = Leaf(4, '', (4, 4), None)
    node_0 = Node(4, '', (4, 4), [leaf_0])
    leaf_1 = Leaf(4, '', (4, 4), None)
    node_1 = Node(4, '', (4, 4), [leaf_1])

# Generated at 2022-06-25 15:19:50.573438
# Unit test for function generate_matches
def test_generate_matches():
    case_0 = [NodePattern(name = 'aa'),
              NodePattern(name = 'bb'),
              WildcardPattern([None], name = 'cc')]
    case_1 = [NodePattern(name = 'aa'),
              NodePattern(name = 'bb'),
              WildcardPattern([[NodePattern(name = 'cc')]], name = 'dd')]
    case_2 = [WildcardPattern([[NodePattern(name = 'aa')]], name = 'aa'),
              WildcardPattern([[NodePattern(name = 'bb')]], name = 'bb')]
    case_3 = [WildcardPattern([[NodePattern(name = 'aa')]], name = 'aa'),
              WildcardPattern([[NodePattern(name = 'bb')]], name = 'bb')]

# Generated at 2022-06-25 15:19:53.845265
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    # Sample data
    node = Node(0, [])
    results = {}
    # Call method
    BasePattern().match(node, results)


# Generated at 2022-06-25 15:19:55.131432
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 15:19:57.672018
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    base_0 = BasePattern()
    return base_0.optimize()

###########
# Test to check if method optimize of class BasePattern returns a value
# matching the type of the method it overrides


# Generated at 2022-06-25 15:20:02.053412
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    base_1 = Base()
    assert base_1.get_suffix() == ''
    base_2 = Base()
    assert base_2.get_suffix() == ''
    #
    # Test if get_suffix method works even if next_sibling is None
    #
    base_1.next_sibling = None
    base_2.next_sibling = None
    assert base_1.get_suffix() == ''
    assert base_2.get_suffix() == ''



# Generated at 2022-06-25 15:20:11.744464
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    match_0 = BasePattern()
    nodes_0 = []
    # Test matched (the if-expression)
    for match in match_0.generate_matches(nodes_0):
        pass
    # Test body of if-expression
    # Test matched (the while-expression)
    while match_0.generate_matches(nodes_0):
        # Test body of while-expression
        # Test condition of while-expression
        pass
    # Test matched (the while-expression)
    while match_0.generate_matches(nodes_0):
        # Test body of while-expression
        # Test body of while-expression
        # Test condition of while-expression
        pass
    # Test matched (the if-expression)

# Generated at 2022-06-25 15:20:19.710888
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols
    from .python_grammar import PythonGrammar

    # Test data
    py_gram_grammar = PythonGrammar
    py_gram_symbols = python_symbols
    py_gram_token = py_gram_grammar.token
    print("py_gram_symbols.suite = {}".format(py_gram_symbols.suite))
    simple_node_1 = Node(py_gram_symbols.suite, [Leaf(py_gram_token.NAME, 'def'), Leaf(py_gram_token.NAME, 'f')])
    # Test execution
    # Test assert_1 = simple_node_1.pre_order()

# Generated at 2022-06-25 15:20:25.560650
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    """Tests the method __repr__ of class Leaf
    """
    from .pgen2.token import tok_name

    # [[[cog
    # cog.outl("# Start of tests for method __repr__ of class Leaf")
    # cog.outl()
    # ]]]
    # [[[end]]] (checksum: d10c35e0b594f898d8cc9e1e97c1f468)
    # [[[cog
    # cog.outl("# Start of tests for method __repr__ of class Leaf")
    # cog.outl()
    # ]]]
    # [[[end]]] (checksum: d10c35e0b594f898d8cc9e1e97c1f468)