

# Generated at 2022-06-25 15:13:06.685055
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf_0 = Leaf(1, '2')
    node_0 = Node(1, [leaf_0])
    iter_0 = leaf_0.leaves()
    node_1 = next(iter_0)
    print(node_0.__dict__, node_1.__dict__)
    #assert(node_1 == node_0)


# Generated at 2022-06-25 15:13:16.246528
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    bytes_0 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    node_pattern_0 = NodePattern()
    text_0 = "aaaaa"
    bytes_1 = b'\x15\xa4\x0c\xce\x02\x0b\xa4\x10\x02\x08\xa4\x14\x02\x06\xa4\x18\x02'
    # build a sequence of nodes from a list strings and bytes
    nodes = [Leaf(a, b) for a, b in zip([text_0] * 5, [bytes_1] * 5)]
    negated_pattern_0 = NegatedPattern(node_pattern_0)
    #

# Generated at 2022-06-25 15:13:17.810731
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    assert node_pattern_0.pre_order()


# Generated at 2022-06-25 15:13:20.754009
# Unit test for function type_repr
def test_type_repr():
    # Input params
    type_num_0 = 10

    # Function call
    if (type_repr(type_num_0)):
        return 0

    return 1



# Generated at 2022-06-25 15:13:26.459982
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Setup
    bytes_0 = b'\x91\xaf\xed\xde\xab\xf3\xde\xf7\x10\x1f2\xcfA\x1f\x9d\xac'
    node_pattern_0 = NodePattern()



# Generated at 2022-06-25 15:13:38.030283
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    bytes_0 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    leaf_0 = Leaf(0, bytes_0[:1])
    bytes_1 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    leaf_1 = Leaf(0, bytes_1[:1])
    bytes_2 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    leaf_2 = Leaf(0, bytes_2[:1])

# Generated at 2022-06-25 15:13:47.759575
# Unit test for function generate_matches
def test_generate_matches():
    bytes_0 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    int_0 = NodePattern()
    int_1 = NodePattern()
    int_2 = NodePattern()
    list_0 = [(int_0, ), (int_1, ), (int_2, )]
    wildcard_pattern_0 = WildcardPattern(list_0, 1, 1, "bare_name")
    wildcard_pattern_1 = WildcardPattern(None, 0, 1, "bare_name")
    bytes_1 = b'\xe4k/\xbb\xbc\x07\xee\x1c\x8f\x80\x0f\x9f\x8b'
    list

# Generated at 2022-06-25 15:13:49.341649
# Unit test for method post_order of class Node
def test_Node_post_order():
    print(Node.post_order())



# Generated at 2022-06-25 15:13:56.672571
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """Unit test for method generate_matches of class NegatedPattern"""
    bytes_0 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    node_pattern_0 = NodePattern()
    negated_pattern_0 = NegatedPattern(node_pattern_0)
    generator = negated_pattern_0.generate_matches(bytes_0)
    assert len([val for val in generator]) == 0
    return


# Generated at 2022-06-25 15:14:02.809929
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    bytes_0 = b' \xee[A\xf7\x8b\xf8\xff\x18 \x01T\x087\xc0)\x10(\x8b'
    node_pattern_0 = NodePattern()
    node_pattern_0._submatch = lambda x: (True, None)
    node_pattern_0.match_seq([], None)


# Generated at 2022-06-25 15:14:18.508363
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    pass


# Generated at 2022-06-25 15:14:20.506874
# Unit test for method clone of class Node
def test_Node_clone():
    test_0 = Node(1, [Leaf(1, "", (1, 1), prefix="")], None)
    test_0.clone()


# Generated at 2022-06-25 15:14:25.854275
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    class MockLeaf(Leaf):
        def __init__(self, value, lineno=None, column=None):
            self.was_changed = False
            self.type = int
            self.value = value
            self.lineno = lineno
            self.column = column
    leaf = MockLeaf(value = 5)
    assert list(leaf.leaves()) == [leaf]


# Generated at 2022-06-25 15:14:35.206401
# Unit test for function convert
def test_convert():
    gr = Grammar()
    raw_node = (0, '', None, [(1, '', None, [(2, '', None, [])])])
    converted_node = convert(gr, raw_node)
    assert isinstance(converted_node, Node)
    # assert converted_node.type == 1
    # assert converted_node.value == ''
    # assert converted_node.context == None
    assert isinstance(converted_node.children[0], Node)
    # assert converted_node.children[0].type == 2
    # assert converted_node.children[0].value == ''
    # assert converted_node.children[0].context == None


# Generated at 2022-06-25 15:14:37.641279
# Unit test for method post_order of class Base
def test_Base_post_order():
    parent = Base()
    parent.children = []
    iter_0 = parent.post_order()
    pass


# Generated at 2022-06-25 15:14:49.732749
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import unittest
    from .pgen2.parse import ParseError
    from .pgen2.pgen import driver
    from .pgen2.pgen import token, symbol
    from .pgen2.token import tok_name
    from .pgen2.token import generate_tok_name

    class TestCase(unittest.TestCase):

        @staticmethod
        def get_error_message(node):
            try:
                node.type
            except AttributeError:
                try:
                    node.type
                except AttributeError:
                    try:
                        return node.value
                    except AttributeError:
                        pass
                else:
                    return tok_name[node.type]
            else:
                return symbol.sym_name[node.type]
            return node


# Generated at 2022-06-25 15:14:50.688125
# Unit test for method clone of class Base
def test_Base_clone():
    pass


# Generated at 2022-06-25 15:14:52.169738
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf_0 = Leaf(0, "value")
    leaf_leaves_result_0 = leaf_0.leaves()
    assert (leaf_leaves_result_0.__class__.__name__ == "generator");


# Generated at 2022-06-25 15:15:01.379682
# Unit test for method depth of class Base
def test_Base_depth():
    #
    # Node pattern that matches any expression
    #
    node_pattern_0 = NodePattern()
    node_pattern_0.is_expression = True
    node0 = Node(syms.term, [node_pattern_0])
    node1 = Node(syms.expr, [node0])

    #
    # Make a test expr
    #
    node2 = Leaf(token.EQUAL, "==")
    node3 = Leaf(token.NAME, "x")
    node4 = Node(syms.term, [node3])
    node5 = Node(syms.factor, [node2, node4])
    node6 = Node(syms.factor, [node5])
    node7 = Node(syms.arith_expr, [node6])

# Generated at 2022-06-25 15:15:03.373077
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    node_pattern_0 = NodePattern()
    wildcard_pattern_0 = WildcardPattern()
    patterns = [WildcardPattern(), WildcardPattern()]
    wildcard_pattern_0.match_seq(patterns)


# Generated at 2022-06-25 15:15:23.791676
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    global node_pattern_0
    node_pattern_0 = NodePattern()
    try:
        node_pattern_0.pre_order()
        try:
            raise NoSuchAttributeException("pre_order")
        except NoSuchAttributeException:
            pass
    except NotImplementedError:
        pass
    node_pattern_0 = Leaf(0, "")
    try:
        node_pattern_0.pre_order()
        try:
            raise NoSuchAttributeException("pre_order")
        except NoSuchAttributeException:
            pass
    except NotImplementedError:
        pass


# Generated at 2022-06-25 15:15:28.065568
# Unit test for method post_order of class Node
def test_Node_post_order():
    children_0: List[NL] = []
    node_0: Node = Node(256, children_0)
    node_0_iterator_0: Iterator[NL] = node_0.post_order()
    node_0_iterator_0.has_next()



# Generated at 2022-06-25 15:15:30.660916
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    instance = Leaf(257, "25")
    expected = 'Leaf(NAME, "25")'
    assert str(instance) == expected, "Wrong string representation"


# Generated at 2022-06-25 15:15:31.712909
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    node_pattern_0 = NodePattern()
    assert repr(node_pattern_0) == 'NodePattern(None, None, None)'


# Generated at 2022-06-25 15:15:42.271072
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    node_pattern_2 = NodePattern()
    node_pattern_3 = NodePattern()
    
    node_pattern_0.type = -1
    node_pattern_0.children = (node_pattern_1, node_pattern_2, node_pattern_3)
    node_pattern_1.type = -1
    node_pattern_1.children = ()
    node_pattern_2.type = -1
    node_pattern_2.children = ()
    node_pattern_3.type = -1
    node_pattern_3.children = ()
    
    assert isinstance(node_pattern_0.pre_order(), Sequence)


# Generated at 2022-06-25 15:15:45.360502
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    base_pattern_0 = Base()
    base_pattern_1 = Base()
    assert base_pattern_0._eq(base_pattern_1) == True


# Generated at 2022-06-25 15:15:49.211402
# Unit test for method changed of class Base
def test_Base_changed():
    node_pattern_0 = NodePattern()
    node_pattern_0.was_changed = False
    node_pattern_0.was_changed = node_pattern_0.was_changed or node_pattern_0.was_changed
    assert node_pattern_0.was_changed == False


# Generated at 2022-06-25 15:15:56.057006
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    node_pattern_2 = NodePattern()
    negated_pattern_0 = NegatedPattern(node_pattern_0)
    negated_pattern_1 = NegatedPattern(node_pattern_1)
    negated_pattern_2 = NegatedPattern(node_pattern_2)
    negated_pattern_3 = NegatedPattern(node_pattern_0)
    negated_pattern_4 = NegatedPattern(node_pattern_1)
    negated_pattern_5 = NegatedPattern(node_pattern_2)

    # Testing a test case with coverage
    assert negated_pattern_0.generate_matches([]) is not None

    assert negated_pattern_1.generate_matches(node_pattern_2) != None

# Generated at 2022-06-25 15:15:58.025855
# Unit test for method replace of class Base
def test_Base_replace():
    node_pattern_0 = NodePattern()
    node_0 = Base()
    node_0.replace(node_pattern_0)


# Generated at 2022-06-25 15:15:59.201100
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    with pytest.raises(NotImplementedError):
        Leaf(0, '').post_order()


# Generated at 2022-06-25 15:17:07.886934
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node_0_0 = Node(0, [])
    node_0_1 = Node(0, [])
    node_0_2 = Node(0, [])
    node_0_3 = Node(0, [node_0_0, node_0_1])
    node_0_4 = Node(0, [node_0_2, node_0_3])
    # node_0_3.pre_order() should return node_0_3, node_0_0, node_0_1
    assert [n for n in node_0_3.pre_order()] == [node_0_3, node_0_0, node_0_1]
    # node_0_4.pre_order() should return node_0_4, node_0_2, node_0_3, node_0_

# Generated at 2022-06-25 15:17:16.108633
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    w1 = WildcardPattern(((NodePattern(),),), 1, 2)
    w2 = WildcardPattern(None, 5, 6)

    assert (w1.optimize() ==
            WildcardPattern(((NodePattern(),),), 1, 2))
    assert (w2.optimize() ==
            WildcardPattern(((NodePattern(),),), 5, 6))
    assert (WildcardPattern(((NodePattern(),),), 1, 1).optimize() ==
            NodePattern())
    assert (WildcardPattern(((WildcardPattern(None, 1, 2),),), 1, 1).optimize() ==
            WildcardPattern(((WildcardPattern(None, 1, 2),),), 1, 2))

# Generated at 2022-06-25 15:17:24.236554
# Unit test for function convert
def test_convert():
    # Create a grammar object and a parser object
    grammar = gram1.grammar1() 
    parser = ParserDriver(grammar, convert)
    parser.setup_parse_tables()
    parse_tree = parser.parse('1 +2* 3', tracking=False)
    # Expected output
    assert  parse_tree.clone() ==  Node(256, [Leaf(1, '1'), Leaf(1, '+'), Node(256, [Leaf(1, '2'), Leaf(2, '*'), Leaf(1, '3')])])


# Generated at 2022-06-25 15:17:35.782875
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Creating object of class NodePattern with arguments
    node_pattern_1 = NodePattern()
    # Calling method __repr__ of class NodePattern on object node_pattern_1 and storing its return value
    ret_1 = node_pattern_1.__repr__()
    # Creating object of class NodePattern with arguments
    node_pattern_2 = NodePattern(content={})
    # Calling method __repr__ of class NodePattern on object node_pattern_2 and storing its return value
    ret_2 = node_pattern_2.__repr__()
    # Creating object of class NodePattern with arguments
    node_pattern_3 = NodePattern(name="foo")
    # Calling method __repr__ of class NodePattern on object node_pattern_3 and storing its return value
    ret_3 = node_pattern_3.__repr__()


# Generated at 2022-06-25 15:17:36.463950
# Unit test for method post_order of class Node
def test_Node_post_order():
    pass



# Generated at 2022-06-25 15:17:43.071063
# Unit test for method clone of class Base
def test_Base_clone():
    from .pygram import python_symbols
    node_pattern_0 = NodePattern()
    node_pattern_0.type = python_symbols.test
    node_pattern_0.children = []
    leaf_pattern_0 = LeafPattern()
    leaf_pattern_0.value = "1"
    leaf_pattern_0.type = token.NUMBER
    node_pattern_0.append_child(leaf_pattern_0)
    assert [node_pattern_0.clone()]



# Generated at 2022-06-25 15:17:49.437106
# Unit test for method post_order of class Node
def test_Node_post_order():
    child_0 = LeafPattern()
    child_1 = LeafPattern()
    node_0 = NodePattern(
        children=[child_0, child_1]
    )
    post_order_result = node_0.post_order()
    assert(isinstance(post_order_result, Iterator))
    assert(isinstance(next(post_order_result), LeafPattern))
    assert(isinstance(next(post_order_result), LeafPattern))
    assert(isinstance(next(post_order_result), NodePattern))
    assert(list(post_order_result) == [])


# Generated at 2022-06-25 15:17:57.563886
# Unit test for method clone of class Base
def test_Base_clone():
    # Make sure the method works when called with no arguments
    # Create a node whose children are a leaf, a node, and another leaf
    node_pattern_1 = NodePattern()
    pattern_1 = LeafPattern(1, "foo", "prefix", None)
    pattern_2 = LeafPattern(2, "bar", "", None)
    pattern_3 = LeafPattern(3, "baz", "", None)
    node_pattern_1.addkid(pattern_1)
    node_pattern_1.addkid(pattern_2)
    node_pattern_1.addkid(pattern_3)

    # Create a node whose children are a leaf, a node, and another leaf
    node_pattern_2 = NodePattern()
    pattern_1 = LeafPattern(1, "foo", "prefix", None)

# Generated at 2022-06-25 15:17:59.595313
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    node_pattern_0 = NodePattern()
    node_pattern_0.get_suffix()


# Generated at 2022-06-25 15:18:07.626570
# Unit test for method post_order of class Base
def test_Base_post_order():
    node_pattern_0 = NodePattern()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()
    node_pattern_0.post_order()


# Generated at 2022-06-25 15:18:53.582490
# Unit test for method remove of class Base
def test_Base_remove():
    x = Base()
    x.remove()


# Generated at 2022-06-25 15:18:59.454338
# Unit test for method post_order of class Node
def test_Node_post_order():
    test_node0 = Node(256, [])
    test_node1 = Node(256, [])
    test_node2 = Node(256, [])
    test_node3 = Node(256, [])
    test_node4 = Node(256, [])
    test_node5 = Node(256, [])
    test_node6 = Node(256, [])


    assert test_node0.post_order(test_node0) == Node, "post_order returned incorrect type"
    assert test_node0.post_order(test_node1) == Node, "post_order returned incorrect type"
    assert test_node0.post_order(test_node2) == Node, "post_order returned incorrect type"

# Generated at 2022-06-25 15:19:01.257818
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.testlist) == "testlist"


# Generated at 2022-06-25 15:19:03.288419
# Unit test for method post_order of class Node
def test_Node_post_order():
    # Testing post_order of Node.children[0]
    assert node_pattern_0.children[0].post_order() == node_pattern_0.children[0]


# Generated at 2022-06-25 15:19:04.857351
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    node_pattern_0 = NodePattern()
    node_pattern_0.generate_matches([])



# Generated at 2022-06-25 15:19:12.167203
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2 import token

    when(LeafPattern).__new__.thenReturn(LeafPattern())
    when(LeafPattern)._submatch.thenReturn(None)
    when(NodePattern).__new__.thenReturn(NodePattern())
    when(NodePattern)._submatch.thenReturn(None)
    when(WildcardPattern).__new__.thenReturn(WildcardPattern())
    when(WildcardPattern)._submatch.thenReturn(None)
    when(BasePattern).optimize.thenReturn(BasePattern())
    when(BasePattern).match.thenReturn(None)
    when(BasePattern).match_seq.thenReturn(None)

# Generated at 2022-06-25 15:19:14.040543
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_0 = Leaf(0, '0')
    # There are no assertions
    leaf_0.post_order()


# Generated at 2022-06-25 15:19:20.110882
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pgen2 import token
    from ..pytree import Leaf
    node = Node(token.TYPE_IGNORE, [Leaf(token.COMMENT, "comment")])
    assert node.prev_sibling is None
    node.update_sibling_maps()
    assert node.prev_sibling is None
    assert node.next_sibling is None
    second_leaf = Leaf(token.COMMENT, "comment")
    node.children.append(second_leaf)
    assert node.prev_sibling_map[id(second_leaf)] is None
    assert node.next_sibling_map[id(second_leaf)] is None



# Generated at 2022-06-25 15:19:24.255291
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    node_pattern_1 = NodePattern()
    nodes_1 = []
    # Check that the next statement doesn't raise an exception
    node_pattern_1.generate_matches(nodes_1)
    # Check that the next statement doesn't raise an exception
    node_pattern_1.generate_matches(nodes_1)



# Generated at 2022-06-25 15:19:26.285823
# Unit test for method clone of class Base
def test_Base_clone():
    obj_0 = Base()
    unittest.expectedFailure
    obj_1 = obj_0.clone()


# Generated at 2022-06-25 15:20:40.142152
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    bp_0 = BasePattern()
    assert bp_0.optimize() is bp_0


# Generated at 2022-06-25 15:20:49.371238
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_pattern_1 = NodePattern()
    assert node_pattern_1.post_order() == node_pattern_1.post_order()

    node_pattern_2 = NodePattern()
    assert node_pattern_2.post_order() == node_pattern_2.post_order()

    node_pattern_3 = NodePattern()
    assert node_pattern_3.post_order() == node_pattern_3.post_order()

    def test_Node_post_order_0(self):
        node_pattern_4 = NodePattern()
        assert node_pattern_4.post_order() == node_pattern_4.post_order()


# Generated at 2022-06-25 15:21:01.424542
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    """
    Test the method get_suffix of class Base.
    """
    node_pattern_0 = NodePattern()
    node_pattern_1 = NodePattern()
    node_pattern_2 = NodePattern()
    node_pattern_3 = NodePattern()
    node_pattern_4 = NodePattern()
    node_pattern_5 = NodePattern()
    node_pattern_6 = NodePattern()
    node_pattern_7 = NodePattern()
    node_pattern_8 = NodePattern()
    node_pattern_9 = NodePattern()
    node_pattern_10 = NodePattern()
    node_pattern_11 = NodePattern()
    node_pattern_12 = NodePattern()
    node_pattern_13 = NodePattern()
    node_pattern_14 = NodePattern()
    node_pattern_15 = NodePattern()
    node_pattern

# Generated at 2022-06-25 15:21:03.315024
# Unit test for method set_child of class Node
def test_Node_set_child():
    node_pat_0 = NodePattern(None, None, None)
    node_pat_1 = NodePattern(None, None, None)
    node_pat_0.set_child(0, node_pat_1)


# Generated at 2022-06-25 15:21:04.868581
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern_0 = NegatedPattern()
    args_0 = [tuple()]
    eq_(pattern_0.generate_matches(args_0), [(0, {})])



# Generated at 2022-06-25 15:21:07.020560
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    node_pattern_0 = NodePattern()
    negated_pattern_0 = NegatedPattern()
    result_0 = negated_pattern_0.generate_matches([])
    result_count_0 = 0

    for _ in result_0:
        result_count_0 += 1

    assert result_count_0 == 1



# Generated at 2022-06-25 15:21:13.240997
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    node = Leaf(12, 'my_token')
    iter = node.post_order()
    result = next(iter)
    assert result == node
    with pytest.raises(StopIteration):
        next(iter)


# Generated at 2022-06-25 15:21:16.161641
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    """Unit test for method generate_matches of class BasePattern"""
    node_pattern_0 = NodePattern()
# End of test case 0



# Generated at 2022-06-25 15:21:18.163942
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    node_pattern_0 = NodePattern()
    assert repr(node_pattern_0) == 'NodePattern(None, None, None)'


# Generated at 2022-06-25 15:21:27.534683
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    tree = Node(...)
    leaf_0 = Leaf(...)
    parent = Node(...)
    leaf_0.append_child(parent)
    node_pattern_0 = Node(...)
    leaf_0.append_child(node_pattern_0)
    node_pattern_1 = Node(...)
    parent.append_child(node_pattern_1)
    leaf_0.post_order()
    for node in leaf_0.post_order():
        node.clone()
