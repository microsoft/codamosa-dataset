

# Generated at 2022-06-23 16:01:57.457164
# Unit test for method set_child of class Node
def test_Node_set_child():
    import typing
    a = Node(1, [])
    b = Leaf(2, 3, 8)
    a.set_child(0, b)
    # 'a.children[0] == b'
    assert a.children[0] == b

    # 'b.parent == a'
    assert b.parent == a
    return



# Generated at 2022-06-23 16:02:01.657112
# Unit test for method clone of class Base
def test_Base_clone():
    r"""
    Test that Base.clone() raises an exception.
    """
    instance = Base()
    raises = exc = None
    try:
        instance.clone()
    except Exception as err:
        raises = True
        exc = err
    assert raises and str(exc) == "clone() not defined in class Base"

# Generated at 2022-06-23 16:02:06.556135
# Unit test for constructor of class BasePattern
def test_BasePattern():
    # This pattern matches a NAME leaf followed by an INDENT leaf
    pattern = NodePattern(NAME, [LeafPattern(INDENT)])
    assert pattern.type == NAME
    assert len(pattern.children) == 1
    assert pattern.content == ()
    assert pattern.name is None
    assert pattern.children[0].type == INDENT
    assert len(pattern.children[0].children) == 0
    assert pattern.children[0].content == ()
    assert pattern.children[0].name is None



# Generated at 2022-06-23 16:02:07.462988
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    LeafPattern(type=token.STRING, content="foo")

# Unit tests for method LeafPattern.match

# Generated at 2022-06-23 16:02:08.735465
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    l = Leaf(0, "test")
    l.parent = None
    l1 = l.clone()
    assert l == l1
test_Leaf_clone()


# Generated at 2022-06-23 16:02:13.572723
# Unit test for method leaves of class Base
def test_Base_leaves():
    # FIXME: This does not test anything.
    from .pytree import Leaf

    l1 = Leaf(1, u"leaf1")
    l2 = Leaf(2, u"leaf2")
    tree = Node(3, [l1])
    tree.append_child(l2)
    for leaf in tree.leaves():
        print(leaf)


# Generated at 2022-06-23 16:02:24.168529
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
  from .pygram import python_grammar
  from .pgen2 import tokenize

  def check_node(node):
    line = node.get_lineno()
    for child in node.children:
      assert line == child.get_lineno()

  def check_line(line):
    p = python_grammar.parser(python_grammar.start)
    try:
      node = p.parse(line)
    except SyntaxError:
      if 0:
        tokenize.detect_encoding(StringIO(line).readline)
        print(line)
      return
    check_node(node)

  line = 'x = "a"'
  check_line(line)
  line = '@x\nclass C:\n  pass'
  check_line(line)


# Generated at 2022-06-23 16:02:36.085858
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import parse

    def print_matches(pattern, src):
        tree = NL(parse(src, "test", "exec"))
        print("matches for", repr(pattern))
        matches = list(pattern.generate_matches(tree.leaves()))
        for count, results in matches:
            print("  ", count, results)

    tree = NL(parse("(x) or (y)"))
    p_or = tree.children[1]
    p_x = tree.children[0].children[0]
    p_y = tree.children[2].children[0]
    print_matches(LeafPattern(OP, "or"), "a or b")
    print_matches(LeafPattern(OP, "or"), "(x) or b")

# Generated at 2022-06-23 16:02:45.262792
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Test without argument
    # raises an NotImplementedError as we do not implement all abstract methods
    with pytest.raises(NotImplementedError):
        Base()
    # raises an NotImplementedError as we do not implement all abstract methods
    with pytest.raises(NotImplementedError):
        Base(None)
    # raises an NotImplementedError as we do not implement all abstract methods
    with pytest.raises(NotImplementedError):
        Base(1)
    # raises an NotImplementedError as we do not implement all abstract methods
    with pytest.raises(NotImplementedError):
        Base(None, None)
    # raises an NotImplementedError as we do not implement all abstract methods

# Generated at 2022-06-23 16:02:48.908072
# Unit test for method post_order of class Node
def test_Node_post_order():
    p1 = parse_str("x y")
    assert list(p1.post_order()) == [p1.children[1], p1.children[0], p1]



# Generated at 2022-06-23 16:02:53.074673
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern([[NodePattern(NAME), NodePattern(NAME)]])
    assert p.min == 1, p.min
    assert p.max == 1, p.max
    assert p.content == ((NodePattern(NAME), NodePattern(NAME)),), p.content

# Unit tests for WildcardPattern.match()

# Generated at 2022-06-23 16:02:59.988767
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import unittest

    class SamplePattern(BasePattern):
        type = 1
        content = "foo"

    for nargs in range(2):
        for nmatches in range(2):
            for args in itertools.product((0, 1), repeat=nargs):
                nodes = [Node(0, ())] * nargs
                if args == (1, 0):
                    nodes = nodes + [Leaf(1, "foo")]
                elif args == (1,):
                    nodes = [Leaf(1, "foo")] + nodes
                else:
                    nodes = nodes + [Leaf(2, "not foo")]
                for n in range(nmatches):
                    assert SamplePattern.match_seq(nodes) == bool(args)
                    nodes = nodes[1:]



# Generated at 2022-06-23 16:03:09.713803
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import random
    import itertools
    for _ in range(100):
        for num_children in itertools.chain([0,1],range(5,random.randint(8,15))):
            children=[]
            for _ in range(num_children):
                children.append(Leaf(1,""))
            node=Node(2,children)
            node.update_sibling_maps()
            assert node.next_sibling_map[1]==node.children[0]
            for i in range(num_children-1):
                assert node.next_sibling_map[id(node.children[i])]==node.children[i+1]

# Generated at 2022-06-23 16:03:11.753639
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    pattern = NegatedPattern(content=None)
    assert pattern.match(None) == False
    pattern2 = NegatedPattern(content=WildcardPattern())
    assert pattern2.match(None) == False


# Generated at 2022-06-23 16:03:15.238992
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    pattern = BasePattern()
    assert pattern.match_seq([]) == False
    assert pattern.match_seq([Node(257, [])]) == False

# Generated at 2022-06-23 16:03:19.973345
# Unit test for method clone of class Node
def test_Node_clone():
    from .pygram import python_symbols

    if python_symbols.__dict__.get("simple_stmt2") is None:
        return
    tree = python_grammar.parse("1")
    tree.prefix = "/* hi */"
    tree2 = tree.clone()
    assert repr(tree) == repr(tree2)

# Generated at 2022-06-23 16:03:26.342094
# Unit test for constructor of class Node
def test_Node():
    x1 = Leaf(1, "x")
    x2 = Leaf(1, "x")
    node = Node(257, [x1, x2])
    assert node.type == 257
    assert node.children == [x1, x2]
    assert x1.parent is node
    assert x2.parent is node
    assert node.parent is None



# Generated at 2022-06-23 16:03:29.258665
# Unit test for method __new__ of class Base
def test_Base___new__():
    # class Base
    # Base subclass must override constructor
    with pytest.raises(TypeError):
        Base()

# Generated at 2022-06-23 16:03:31.454293
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # Setup
    t = None
    p = NegatedPattern(t)

    # Exercise
    result = p.match(None)

    # Verify
    assert result

    # Cleanup - none necessary


# Generated at 2022-06-23 16:03:36.567810
# Unit test for method clone of class Node
def test_Node_clone():
    """Test Node.clone()"""
    class Node:
        def __init__(self, children=None, type=None, context=None):
            self.type = type
            self.children = children or [ ]
        def clone(self):
            n = Node()
            n.type = self.type
            n.children = [ c.clone() for c in self.children ]
            return n
    n = Node(type="NT")
    n.children.append(Node(type="NT"))
    n.children.append(Node(type="NT"))
    n2 = n.children[0]
    n2.children.append(Node(type="NT"))
    n.children.append(Node(type="NT"))
    n3 = n.children[3]
    n3.children.append(Node(type="NT"))

# Generated at 2022-06-23 16:03:40.880637
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    def t(node, other, expected):
        node = parse(node, mode='exec')
        other = parse(other, mode='exec')
        assert (node == other) == expected
    t('x', 'x', True)
    t('x', 'y', False)
    t('x + y', 'x + y', True)
    t('x + y', 'x + z', False)

# Generated at 2022-06-23 16:03:43.099209
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    # Create a new instance of class BasePattern
    assert_raises(AssertionError, BasePattern)

# Generated at 2022-06-23 16:03:51.088921
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Create a class of the same name as the parent
    class BadBase(Base):
        def __new__(cls):
            return object.__new__(BadBase)

    # This should fail!
    try:
        BadBase()
    except TypeError:
        pass
    else:
        assert 0, "__new__ didn't fail"

    # Now create a class that inherits from the bad class. This should fail!
    class BadBase2(Base):
        def __new__(cls):
            return object.__new__(BadBase2)

    try:
        BadBase2()
    except TypeError:
        pass
    else:
        assert 0, "__new__ didn't fail"



# Generated at 2022-06-23 16:03:57.217100
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from . import pytree

    def assert_lineno(s, lineno):
        tree = pytree.tolist(pytree.MultiLineString(s)())
        n = pytree.Node(type=0, children=[tree])
        assert n.get_lineno() == lineno


# Generated at 2022-06-23 16:04:06.624070
# Unit test for method depth of class Base
def test_Base_depth():
    class Foo(Base):
        def __init__(self, children=None):
            self.children = children or []

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def _eq(self, other):
            if len(self.children) != len(other.children):
                return False
            for child1, child2 in zip(self.children, other.children):
                if child1 != child2:
                    return False
            return True

        def clone(self):
            return Foo([child.clone() for child in self.children])

        def changed(self):
            return


# Generated at 2022-06-23 16:04:11.696955
# Unit test for method append_child of class Node
def test_Node_append_child():
  node1 = Node(257,[])
  node2 = Node(257,[])
  node1.append_child(Node(257,[]))
  node2.append_child(node1.children[0])
  assert node1.__eq__(node2)


# Generated at 2022-06-23 16:04:23.893952
# Unit test for method post_order of class Node
def test_Node_post_order():
    """
    def post_order(self) -> Iterator[NL]:
        for child in self.children:
            yield from child.post_order()
        yield self
    """
    from . import pytree


# Generated at 2022-06-23 16:04:28.227177
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class DummyPattern(BasePattern):
        def _submatch(self, node, results):
            return True
    #
    # Check that optimize() doesn't change the pattern
    #
    pattern = DummyPattern(42, 'abc')
    assert pattern.optimize() is pattern

# Generated at 2022-06-23 16:04:38.003562
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from . import pygram
    from .pgen2 import token

    def make_tree(string):
        return pytree.Node(
            pygram.python_symbols.file_input,
            [Leaf(token.NEWLINE, "\n"), Leaf(token.NEWLINE, "\n")],
            prefix=string,
        )

    tree = make_tree("foo\nbar\n")
    node = tree.children[0]  # node == "foo\n"
    assert node.get_suffix() == "bar\n"
    node = tree.children[1]  # node == "bar\n"
    assert node.get_suffix() == ""

    tree = make_tree("foo\nbar")
    node = tree.children[0]  # node == "foo

# Generated at 2022-06-23 16:04:45.669199
# Unit test for function generate_matches
def test_generate_matches():
    from typing import Tuple
    from .tool import LexerBase

    def get_generator(
        pattern: Pattern, nodes: List[NL], lexer: LexerBase
    ) -> Iterator[Tuple[int, Dict]]:
        return generate_matches(pattern.pattern.get_pattern(lexer), nodes)

    def check_generator(
        pattern: Pattern,
        nodes: List[NL],
        lexer: LexerBase,
        expected: Iterator[Tuple[int, Dict]],
    ) -> None:
        if isinstance(expected, str):
            assert get_generator(pattern, nodes, lexer) is None, get_generator(
                pattern, nodes, lexer
            )
        else:
            got = list(get_generator(pattern, nodes, lexer))
           

# Generated at 2022-06-23 16:04:56.860733
# Unit test for function generate_matches

# Generated at 2022-06-23 16:05:02.171056
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    node = Leaf(1, 'foo')
    next_node = Leaf(2, 'bar')
    assert node.get_suffix() == node.get_suffix()
    assert node.get_suffix() == ''

    test_parent = Node(3)
    test_parent.append_child(node)
    node.parent = test_parent

    assert node.get_suffix() is None

    test_parent.append_child(next_node)
    next_node.parent = test_parent

    assert node.get_suffix() == next_node.prefix


# Generated at 2022-06-23 16:05:07.224059
# Unit test for constructor of class Node
def test_Node():
    a = Leaf(258, "")
    b = Leaf(260, "")
    c = Leaf(262, "")
    n = Node(259, [a, b, c])
    assert n.parent is None
    assert n.children == [a, b, c]
    assert a.parent is n
    assert b.parent is n
    assert c.parent is n



# Generated at 2022-06-23 16:05:13.106537
# Unit test for method __str__ of class Node
def test_Node___str__():

    # pylint: disable=bare-except

    try:
        assert False
    except:
        __context__ = 'assert'

    __tracebackhide__ = True

    node = Node(2, ['a', 'b'])
    assert __str__(node) == 'ab'
    node = Node(2, ['a', 'b', Node(3, ['c', 'd'])])
    assert __str__(node) == 'abcd'



# Generated at 2022-06-23 16:05:21.607860
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    """Test method Node.invalidate_sibling_maps"""
    import lib2to3.btm_utils
    import lib2to3.pgen2.token
    import lib2to3.pytree as pytree
    import lib2to3.pygram as pygram
    import lib2to3.patcomp as patcomp
    import lib2to3.fixer_util as fixer_util
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.driver as driver
    from lib2to3.pgen2.grammar import Grammar
    import lib2to3.refactor as refactor
    import lib2to3.btm_matcher as btm_matcher
    import lib2to3.fixer_base as fixer_base
    import lib2to3

# Generated at 2022-06-23 16:05:29.225945
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    """Test case for method __repr__ of class Leaf."""
    # Imports
    from sys import version as __version
    from pgen2.token import tok_name
    # Body
    assert repr(Leaf(256, "python")) == "Leaf(256, 'python')"
    assert repr(Leaf(256, "python", fixers_applied=[1])) == "Leaf(256, 'python', fixers_applied=[1])"
    assert repr(Leaf(257, "python")) == "Leaf(257, 'python')"
    assert repr(Leaf(257, "", fixers_applied=[1])) == "Leaf(257, '', fixers_applied=[1])"
    assert repr(Leaf(258, "python")) == "Leaf(258, 'python')"


# Generated at 2022-06-23 16:05:33.930141
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    p = NodePattern(None)
    q = NegatedPattern(p)
    assert q.content == p
    p = NegatedPattern()
    assert p.content is None



# Generated at 2022-06-23 16:05:39.449370
# Unit test for constructor of class Node
def test_Node():
    class X:

        def __eq__(self, other):
            return id(self) == id(other)

    a = X()
    b = X()
    node = Node(0, [a, b])
    assert a.parent is node
    assert b.parent is node
    assert node.children == [a, b]
    node2 = Node(0, [])
    assert node2.children == []



# Generated at 2022-06-23 16:05:45.620551
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pygram import python_symbols as syms, python_grammar as grammar
    from .pgen import token

    class DummyGrammar(Grammar):
        def __init__(self):
            self.symbol2number = syms.symbol2number.copy()
            self.number2symbol = syms.number2symbol.copy()

    pgen = DummyGrammar()

    start = pgen.number2symbol[syms.file_input]
    tree = Node(start, [Leaf(token.NAME, 'def'), Leaf(token.NAME, 'f'), Leaf(token.COLON)])

    assert tree.next_sibling == None
    assert tree.prev_sibling == None

    # assert _next.get == None
    assert _prev.get == None
# Unit

# Generated at 2022-06-23 16:05:55.438445
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import textwrap
    from .pgen2 import driver, parse

    s = textwrap.dedent(
        """
        def foo():
            return 42
    """
    )
    result = parse(s, debug=0)
    assert result is not None, result
    from .pgen2 import token


# Generated at 2022-06-23 16:06:05.828569
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import driver, token

    def test(pat: BasePattern, nodes: List[NL]) -> None:
        for n, r in pat.generate_matches(nodes):
            print("+%d %r" % (len(nodes[:n]), r))
            nodes = nodes[n:]
        assert not nodes

    test(
        LeafPattern(token.NAME),
        [
            Leaf(token.NAME, "a", (None, (1, 0))),
            Leaf(token.NAME, "b", (None, (1, 0))),
            Leaf(token.NAME, "c", (None, (1, 0))),
        ],
    )


# Generated at 2022-06-23 16:06:08.052491
# Unit test for method __new__ of class Base
def test_Base___new__():
    """Unit test for method __new__ of class Base."""

    # Test that the method raises an exception if Base is instantiated.
    instance = Base()



# Generated at 2022-06-23 16:06:16.257049
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    s = "unit.test.match_seq()"
    print("In unit.test.match_seq()")
    p = NegatedPattern()
    nodes = parser.parse(s)
    print("nodes = {}".format(nodes))
    result = p.match_seq(nodes)
    print("result = {}".format(result))
    return result
test_NegatedPattern_match_seq()

test_NegatedPattern_match_seq()

test_NegatedPattern_match_seq()

test_NegatedPattern_match_seq()

# Generated at 2022-06-23 16:06:19.951487
# Unit test for constructor of class BasePattern
def test_BasePattern():
    class SubClass1(BasePattern):
        pass

    class SubClass2(BasePattern):
        type = 1

    with pytest.raises(AssertionError):
        SubClass1()  # type: ignore
    sub2 = SubClass2()  # type: ignore



# Generated at 2022-06-23 16:06:28.747412
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    class Leaf(Leaf):
        def __init__(self, value: Any, type: int) -> None:
            self.value = value
            self.type = type
    node0 = Leaf("a", 1)
    node1 = Leaf("b", 2)
    node2 = Leaf("c", 3)
    node3 = Leaf("d", 4)
    node4 = Leaf("e", 5)
    node5 = Leaf("f", 6)
    node6 = Leaf("g", 7)


# Generated at 2022-06-23 16:06:32.984991
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "()")
    assert l.type == 1
    assert l.value == "()"
    assert l.prefix == ""
    assert l.children == []
    l = Leaf(1, "()", "This is a test")
    assert l.type == 1
    assert l.value == "()"
    assert l.prefix == "This is a test"
    assert l.children == []
    l = Leaf(1, "()", ("This is a test", (1, 0)))
    assert l.type == 1
    assert l.value == "()"
    assert l.prefix == "This is a test"
    assert l.children == []
    assert l.get_lineno() == 1


# Generated at 2022-06-23 16:06:43.291896
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    def test(type, value, prefix):
        tok = Leaf(type=type, value=value, prefix=prefix)
        return tok.__str__()

    assert test(1, '\n', '') == '\n'
    assert test(1, '\n', '   ') == '   \n'
    assert test(1, '\t', '') == '\t'
    assert test(1, '\t', '   ') == '   \t'
    assert test(1, '\n\n', '') == '\n\n'
    assert test(1, '\n\n', '   ') == '   \n\n'
    assert test(1, '\n\n\n', '') == '\n\n\n'

# Generated at 2022-06-23 16:06:46.252595
# Unit test for method changed of class Base
def test_Base_changed():
    from blib2to3.pytree import Leaf

    stmt = Leaf(1, "foo")
    assert not stmt.was_changed
    stmt.changed()
    assert stmt.was_changed



# Generated at 2022-06-23 16:06:49.594125
# Unit test for method remove of class Base
def test_Base_remove():
    from . import pytree

    s = pytree.Leaf("x", "xyz")
    t = pytree.Node(
        pygram.python_symbols.simple_stmt,
        [s])
    u = pytree.Node(
        pygram.python_symbols.small_stmt,
        [t])
    s.remove()
    assert u.children == []



# Generated at 2022-06-23 16:07:01.152495
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pygram import python_symbols as syms
    from .pgen2 import parse
    from .pytree import Leaf, Node, type_repr, convert_tree
    from lib2to3.pytree import convert
    from pprint import pprint
    from io import StringIO

    test_input = u"""
            def func(a, b=1, c='a', d=3):
                pass
            """
    test_tree = parse(test_input, start='funcdef')

    # Set one argument to a new value
    # Get the second positional argument
    pos_arg = test_tree.children[2].children[0]
    # Set it to a new keyword argument
    pos_arg.set_child(0, Leaf(syms.argument, u'newarg=3'))
    # Get the defun

# Generated at 2022-06-23 16:07:01.892357
# Unit test for method post_order of class Node
def test_Node_post_order():
    pass

# Generated at 2022-06-23 16:07:11.528535
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    source = ["class Test:", "    pass"]
    node = new_module("".join(source))
    assert isinstance(node, Node)
    assert isinstance(node, Base)
    assert isinstance(node.children[1], Node)
    assert isinstance(node.children[1], Base)
    assert isinstance(node.children[1].children[0], Leaf)
    assert isinstance(node.children[1].children[0], Base)
    assert isinstance(node.children[1].children[0].leaves(), iterator)
    assert isinstance(node.children[1].children[0].leaves().__iter__(), iterator)
    assert isinstance(node.children[1].children[0].leaves().__next__(), Leaf)

# Generated at 2022-06-23 16:07:14.180032
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    assert Leaf(1, "foo").post_order() == [Leaf(1, "foo")]

# Generated at 2022-06-23 16:07:20.630710
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from . import pytree

    FileInput = pytree.type_repr(python_symbols.file_input)
    VarArgsList = pytree.type_repr(python_symbols.varargslist)
    Name = pytree.Leaf
    Num = pytree.Leaf
    Str = pytree.Leaf


# Generated at 2022-06-23 16:07:28.225331
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import sys

    from .pgen2.tokenize import generate_tokens
    from .pgen2.parse import tokenize

    if sys.argv[1:]:
        filename = sys.argv[1]
    else:
        filename = __file__  # Test this script
    with open(filename) as fp:
        tokens = list(tokenize(fp.readline))
    for n, (t, v, s, e, l) in enumerate(generate_tokens(
        tokens.__next__
    )):
        print("    %2d   %3d %3d %3d %3d  %-15s %s" % ((n,) + s + (t, v)))
        pass



# Generated at 2022-06-23 16:07:29.727546
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp = WildcardPattern([[LeafPattern(type='NAME', content='x')]])
    wp = wp.optimize()
    assert wp == LeafPattern(type='NAME', content='x')

# Generated at 2022-06-23 16:07:38.841766
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node(python_symbols.testlist, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert str(node) == "foobar"
    node = Node(python_symbols.dotted_name, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert str(node) == "foo.bar"
    node = Node(python_symbols.dotted_name, [Leaf(1, "foo"), Leaf(1, "<")])
    assert str(node) == "foo<"
    node = Node(python_symbols.dotted_as_name, [Leaf(1, "foo"), Leaf(1, "as"), Leaf(1, "bar")])
    assert str(node) == "foo as bar"
    # Test a del_st

# Generated at 2022-06-23 16:07:45.275429
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    bp = BasePattern(type=1, name='test')
    class TestNode(NL):
        def __init__(self, type, name=None):
            self.type = type
            self.node_name = name
            self.children = []
            self.used_names = set()
        def __repr__(self):
            return '<Node type=%s name=%s>' % \
                (type_repr(self.type), self.node_name)
        def _eq(self, other):
            return self.type == other.type
    node = TestNode(1)
    assert list(bp.generate_matches([node])) == [(1, {'test': node})]
    class TestNode(NL):
        def __init__(self, type, name=None):
            self

# Generated at 2022-06-23 16:07:55.273284
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf

    assert list(Node(0, [Leaf(1, ""), Leaf(2, "")]).pre_order()) == [Node(0, [Leaf(1, ""), Leaf(2, "")]), Leaf(1, ""), Leaf(2, "")]
    assert list(Node(0, [Leaf(1, ""), Leaf(2, ""), Leaf(3, "")]).pre_order()) == [Node(0, [Leaf(1, ""), Leaf(2, ""), Leaf(3, "")]), Leaf(1, ""), Leaf(2, ""), Leaf(3, "")]

# Generated at 2022-06-23 16:08:00.522155
# Unit test for method match_seq of class WildcardPattern

# Generated at 2022-06-23 16:08:11.144904
# Unit test for constructor of class Base
def test_Base():
    class TBase(Base):
        def _eq(self, other):
            return True

        def __repr__(self):
            return "TBase()"

        def clone(self):
            return TBase()

        def post_order(self):
            return []

        def pre_order(self):
            return []

        @property
        def prefix(self):
            return ""

    try:
        Base()
    except AssertionError:
        pass
    else:
        raise Exception("expected AssertionError")
    try:
        TBase().__new__(Base)
    except AssertionError:
        pass
    else:
        raise Exception("expected AssertionError")
    assert isinstance(TBase(), TBase)
    t = TBase()
    assert t == t

# Generated at 2022-06-23 16:08:15.229316
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node

    root = Node(1, [Leaf(1, "one"), Node(2, [Leaf(1, "two"), Node(2, [Leaf(1, "three")])])])
    assert list(root.leaves()) == [Leaf(1, "one"), Leaf(1, "two"), Leaf(1, "three")]



# Generated at 2022-06-23 16:08:26.212514
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    assert WildcardPattern().match_seq([])
    assert WildcardPattern().match_seq([Leaf(1, "abc")])
    assert WildcardPattern().match_seq([Leaf(1, "abc"), Leaf(2, "def")])
    assert not WildcardPattern().match_seq([Leaf(1, "abc"), Leaf(2, "def"), Leaf(3, "ghi")])
    for n in range(0, 4):
        for i in range(0, 4):
            assert WildcardPattern(max=n).match_seq([Leaf(1, "abc")] * i)
    for n in range(1, 4):
        for i in range(0, 4):
            assert WildcardPattern(min=n).match_seq([Leaf(1, "abc")] * i)
    assert not WildcardPattern

# Generated at 2022-06-23 16:08:30.589268
# Unit test for constructor of class BasePattern
def test_BasePattern():
    """Test BasePattern constructor."""
    p = BasePattern()
    assert p.type is None
    assert p.content is None
    assert p.name is None
    assert len(repr(p)) > len(p.__class__.__name__)



# Generated at 2022-06-23 16:08:39.095068
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import unittest
    from .pygram import python_symbols, python_grammar
    from . import token
    from .tokenize import generate_tokens
    from io import StringIO
    class Test_Node_update_sibling_maps_TestCase(unittest.TestCase):
        def test_1(self):
            # Test that a change to a node's children invalidates the sibling
            # maps.
            node = parse("from astroid import builtins")
            node.update_sibling_maps()
            node.append_child(Leaf(token.NAME, 'foo'))
            self.assertIsNone(node.prev_sibling_map)
            self.assertIsNone(node.next_sibling_map)

    # Unit test for method update_sibling_maps of class Node

# Generated at 2022-06-23 16:08:42.058902
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf = Leaf(1, "a")
    list(leaf.post_order()) == [leaf]


# Generated at 2022-06-23 16:08:44.565205
# Unit test for constructor of class Base
def test_Base():
    test_base = Base()  # type: ignore
    assert test_base is not None


# A node containing Python tokens.

# Generated at 2022-06-23 16:08:47.317741
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    pattern = BasePattern()
    node = Node(257, [])
    assert not pattern.match(node)
assert not test_BasePattern_match()


# Class LeafPattern

# Generated at 2022-06-23 16:08:57.176480
# Unit test for method depth of class Base
def test_Base_depth():
    from . import parse
    from . import pytree
    mod = parse.parse("x = 1")
    t = pytree.type_repr(mod.children[0].type)
    assert t == 'file_input'
    assert mod.depth() == 0
    n = mod.children[0].children[0]
    assert n.depth() == 1
    t = pytree.type_repr(n.type)
    assert t == 'simple_stmt'
    n = n.children[0]
    assert n.depth() == 2
    t = pytree.type_repr(n.type)
    assert t == 'expr_stmt'
    n = n.children[0]
    assert n.depth() == 3
    t = pytree.type_repr(n.type)

# Generated at 2022-06-23 16:09:08.239365
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import sys
    import pytree
    from blib2to3.fixer_util import Name
    from grammar_parser.gparser import mktree
    def check_siblings(root, list_of_strs, next_sibs_dict, prev_sibs_dict):
        for str_, node in zip(list_of_strs, root.post_order()):
            next_sib = next_sibs_dict.get(node, "")
            prev_sib = prev_sibs_dict.get(node, "")
            next_id = None if next_sib == "" else next_sib.node_id
            prev_id = None if prev_sib == "" else prev_sib.node_id
            assert str_ == node.str_with_next_prev_sibs

# Generated at 2022-06-23 16:09:14.112397
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    a = Leaf(1, "a")
    b = Leaf(1, "b", prefix="\n")
    c = Node(1, [])
    d = Node(1, [a, b])
    assert a.get_lineno() == 1
    assert b.get_lineno() == 2
    assert c.get_lineno() == 1
    assert d.get_lineno() == 1



# Generated at 2022-06-23 16:09:16.132174
# Unit test for constructor of class Base
def test_Base():
    x = Base()
    try:
        x.clone()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-23 16:09:27.521027
# Unit test for method set_child of class Node
def test_Node_set_child():
    tree = (
        Node(1, [
            Node(2, [
                Leaf(3, "a"),
                Leaf(4, "b")
            ]),
            Leaf(5, "c"),
            Leaf(6, "d"),
            Leaf(7, "e")
        ]))
    tree.set_child(1, Leaf(8, "f"))
    assert tree == (Node(1, [
        Node(2, [
            Leaf(3, "a"),
            Leaf(4, "b")
        ]),
        Leaf(8, "f"),
        Leaf(6, "d"),
        Leaf(7, "e")
    ]))

test_Node_set_child()

# Generated at 2022-06-23 16:09:32.452588
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
  from .pgen2 import token
  from . import pytree
  leaf_object = pytree.Leaf(token.NAME, 'x')
  return 'x' == leaf_object.__str__()
# __str__ is used in a context where it must return a string
test_Leaf___str__()


# Generated at 2022-06-23 16:09:40.655914
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from pgen2.parse import PatternParser as P
    from pgen2.lexer import Lexer
    from pgen2.grammar import Grammar
    from pgen2.pgen import convert
    from pgen2.parse import ParseError
    from pgen2.pgen import generate_matches
    from pgen2.pgen import match_seq
    from test.support import no_tracing
    with no_tracing():
        p = P()
        p.pattern = P([
        'a ', # ignored
        P('a'),
        P('b'),
        ' c', # ignored
        P('c')],
        'a b c'
        )
        g = Grammar(p)
        l = Lexer(g)
        l.input("a b c")

# Generated at 2022-06-23 16:09:51.416514
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # Test method generate_matches of class WildcardPattern
    # First, we test that the method returns the right set of (count, results)
    # tuples. To do this, we create a tree of the form (prefix + struct),
    # where struct is a sequence of tokens and prefix is a sequence of symbols.
    # We then test if the results returned by the method match this structure.
    tk = Leaf
    sym = Node
    # Test trees of the form (tk ... tk sym ... sym tk ... tk), where there are
    # n (tk ... tk) sequences and m (sym ... sym) sequences. The case n == 0 is
    # tested in a separate function: test_bare_name_matches.

# Generated at 2022-06-23 16:09:54.826287
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    t = Leaf(1, "")
    t1 = t.clone()
    assert t1 is not t
    assert t1.type == t.type
    assert t1.value == t.value
    assert t1.children == []

# Generated at 2022-06-23 16:10:03.852934
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    pattern = WildcardPattern(None)
    matches = list(pattern.generate_matches([]))
    assert matches == [(0, {})], matches

    # Simple test
    nodes = NL(12, NL(256, NL(257, Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c'))), Leaf(2, 'd'))
    pattern = WildcardPattern(None)
    matches = list(pattern.generate_matches(nodes))
    assert matches == [(0, {}), (1, {}), (2, {}), (3, {}), (4, {})], matches

    # Simple test with a name
    pattern = WildcardPattern(None, name='x')
    matches = list(pattern.generate_matches(nodes))

# Generated at 2022-06-23 16:10:12.542625
# Unit test for method replace of class Base
def test_Base_replace():
    class MockNode(Node):
        # An override of the Node constructor
        def __init__(self, type, children=None, prefix="", parent=None):
            super(MockNode, self).__init__(type, children, prefix, parent)
    N = MockNode
    # Set up some nodes
    a = N(1, [N(0, [Leaf(1, "if"), Leaf(1, " ")]), N(2, [])])
    b = Leaf(1, "else")
    c = Leaf(1, "\n")
    d = N(1, [N(0, []), N(2, [])])
    e = Leaf(1, ":")
    a.children.extend([b,c,d,e])
    b.parent, c.parent, d.parent, e.parent

# Generated at 2022-06-23 16:10:19.641874
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    """Unit test for constructor of class WildcardPattern"""
    print("Testing WildcardPattern")
    w = WildcardPattern([[Leaf(token.NAME, "a"), Leaf(token.NAME, "b")], [Leaf(token.NAME, "c")]])
    r = w.optimize()
    assert not isinstance(r, WildcardPattern), r
    assert r.match(Node(symbol.testlist, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")])), r
    assert r.match(Node(symbol.testlist, [Leaf(token.NAME, "c")])), r
    assert not r.match(Node(symbol.testlist, [Leaf(token.NAME, "a")])), r
    print("Done testing WildcardPattern")



# Generated at 2022-06-23 16:10:22.752414
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert str(BasePattern(1)) == "BasePattern(1)"
    assert str(BasePattern(1, 2)) == "BasePattern(1, 2)"



# Generated at 2022-06-23 16:10:26.521197
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    bp = BasePattern(1)
    assert list(bp.generate_matches([Leaf(1, "a")])) == [(1, {})]
test_BasePattern_generate_matches()

_WILDCARD = "..."



# Generated at 2022-06-23 16:10:30.040459
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    t = Leaf(1, 'value', context=('prefix', (1, 1)))
    a = []
    for i in t.pre_order():
        a.append(i)
    assert a == [t], a



# Generated at 2022-06-23 16:10:35.962219
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    node = Leaf(1, 'It was the best of times, it was the worse of times')
    lp = LeafPattern(1, 'It was the best of times')
    results = {}
    assert lp.match(node, results) == True
    assert results == {None: node}
# Test for method _submatch of class LeafPattern

# Generated at 2022-06-23 16:10:41.195254
# Unit test for function generate_matches
def test_generate_matches():
    p = NodePattern(type=tokenize.NAME)
    p2 = WildcardPattern()

    # No match
    nodes = [NL(type=tokenize.NEWLINE)]
    patterns = [p]
    assert not list(generate_matches(patterns, nodes))

    # One match
    nodes = [NL(type=tokenize.NAME), NL(type=tokenize.NEWLINE)]
    patterns = [p, p2]
    assert list(generate_matches(patterns, nodes))

    # Many matches
    nodes = [NL(type=tokenize.NAME), NL(type=tokenize.NAME)]
    patterns = [p, p2]
    assert list(generate_matches(patterns, nodes))


# TODO: Change this to a subclass of 'list', so that we can use
#       .

# Generated at 2022-06-23 16:10:44.808570
# Unit test for constructor of class BasePattern
def test_BasePattern():
    """ Tests constructor for class BasePattern

    >>> bp = BasePattern()
    Traceback (most recent call last):
    TypeError: Cannot instantiate BasePattern
    """

# Generated at 2022-06-23 16:10:56.017974
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    from .pygram import python_grammar
    from .pgen2 import token

    indent = Leaf(token.INDENT, "    ")
    # leaf (token.INDENT, "    ")
    left = Leaf(token.NAME, "left")
    # leaf (token.NAME, "left")
    new_line = Leaf(token.NEWLINE, "\n")
    # leaf (token.NEWLINE, "\n")
    right = Leaf(token.NAME, "right")
    # leaf (token.NAME, "right")
    node = Node(python_grammar.suite, [indent, left, new_line, right])
    # stmt <suite> (leaf (token.INDENT, "    "), leaf (token.NAME, "left"),
    # leaf (token.NEW

# Generated at 2022-06-23 16:10:57.947236
# Unit test for method leaves of class Base
def test_Base_leaves():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 16:10:59.698715
# Unit test for constructor of class Base
def test_Base():
    try:
        b = Base()
    except TypeError:
        pass
    else:
        raise RuntimeError("Base() should be abstract")



# Generated at 2022-06-23 16:11:07.107595
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    class IntLeafPattern(BasePattern):
        def __init__(self, content):
            self.type = token.NUMBER
            self.content = re.compile(content)
        def _submatch(self, node, results):
            return self.content.search(node.value)
    bp = IntLeafPattern('\d+')
    n = Leaf(token.NUMBER, '42')
    assert bp.match(n)
    assert list(bp.generate_matches([n])) == [(1, {})]
test_BasePattern_generate_matches()


# Generated at 2022-06-23 16:11:14.493440
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    assert (
        repr(NodePattern(sym.simple_stmt)) == "NodePattern(simple_stmt, None)"
    ), repr(NodePattern(sym.simple_stmt))
    assert (
        repr(NodePattern(sym.expr_stmt, results={sym.expr: "expr"}))
        == "NodePattern(expr_stmt, {expr: 'expr'})"
    ), repr(NodePattern(sym.expr_stmt, results={sym.expr: "expr"}))



# Generated at 2022-06-23 16:11:26.578597
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node
    t1 = Leaf(1, "text1")
    t2 = Leaf(1, "text2")
    t3 = Node(2, [t1, t2])
    assert t1.parent is t3
    t1.replace(t2)
    assert t3.children == [t2]
    assert t2.parent is t3

    t1 = Leaf(1, "text1")
    t2 = Leaf(1, "text2")
    t3 = Node(2, [t1, t2])
    t4 = Leaf(1, "text4")
    assert t1.parent is t3
    t1.replace([t2, t4])
    assert t3.children == [t2, t4]
    assert t2.parent is t3

# Generated at 2022-06-23 16:11:35.971284
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Node
    from .pygram import python_symbols

    root = Node(python_symbols.simple_stmt, [])
    root.was_changed = False
    root.children = [Node(python_symbols.small_stmt, [])]
    for node in root.pre_order():
        # If node.parent is not None, it would change anyway
        node.parent = None
        node.was_changed = False

    child = root.children[0]
    child.changed()
    assert child.was_changed
    assert root.was_changed
    assert not root.children[0].was_changed


# Generated at 2022-06-23 16:11:44.483777
# Unit test for method remove of class Base
def test_Base_remove():
    print("testing remove of class Base")
    try:
        a = Leaf(1, "hello")
        b = Leaf(1, "hello")
        c = Leaf(1, "hello")
        n = Node(1, [a, b, c])
        assert n.children == [a, b, c]
        a.remove()
        assert n.children == [b, c]
        b.remove()
        assert n.children == [c]
        c.remove()
        assert n.children == []
    except Exception:
        print(sys.exc_info()[1])
        assert False



# Generated at 2022-06-23 16:11:55.990363
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    np = NegatedPattern()
    assert np != None
    #
    #  Args:
    #      content: optional sequence of subsequences of patterns;
    #               if absent, matches one node;
    #               if present, each subsequence is an alternative [*]
    #      min: optional minimum number of times to match, default 0
    #      max: optional maximum number of times to match, default HUGE
    #      name: optional name assigned to this match
    #
    #  [*] Thus, if content is [[a, b, c], [d, e], [f, g, h]] this is
    #      equivalent to (a b c | d e | f g h); if content is None,
    #      this is equivalent to '.' in regular expression terms.
    #      The min and max parameters work as follows:
    #          min=0,