

# Generated at 2022-06-23 16:02:00.468011
# Unit test for constructor of class Base
def test_Base():  # pragma: no cover
    import pytree  # Avoid cycles

    class NodeImpl(Base):
        def __init__(self) -> None:
            pass

    class LeafImpl(Base):
        def __init__(self) -> None:
            pass

    node = NodeImpl()
    leaf = LeafImpl()

    def call(n: Base) -> None:
        n.clone()
        n.post_order()
        n.get_lineno()
        n.changed()
        n.remove()
        n.leaves()
        n.depth()
        n.replace(leaf)
        n.replace(node)
        n.replace([node, leaf])
        n.replace([node, node, leaf])
        n.replace([node, node, leaf, node])

# Generated at 2022-06-23 16:02:04.063980
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    p = LeafPattern(7, "test")
    assert p.type == 7
    assert p.content == "test"
    assert p.name is None
    p = LeafPattern(7, "test", "name")
    assert p.type == 7
    assert p.content == "test"
    assert p.name == "name"
    assert_raises(AssertionError, LeafPattern, -1)
    assert_raises(AssertionError, LeafPattern, 256)
    assert_raises(AssertionError, LeafPattern, content=1)


# Generated at 2022-06-23 16:02:13.838904
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    print(test_get_lineno.__doc__)

    class DummyLeaf(Leaf):
        def __init__(self, val: Text, lineno: int) -> None:
            super().__init__(0, val)
            self.lineno = lineno

    class DummyNode(Node):
        def __init__(self, lineno: int) -> None:
            super().__init__(0, [])
            self.lineno = lineno

    #
    # Create test tree
    #
    tree = DummyNode(1)
    root = tree

    t = DummyNode(2)
    tree.append_child(t)
    tree = t
    leaf = DummyLeaf("token 1", 3)
    tree.append_child(leaf)


# Generated at 2022-06-23 16:02:19.411320
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def check(pattern, nodes, expected):
        result = [x for x in pattern.generate_matches(nodes)]
        assert result == expected, result
    pat = WildcardPattern()
    check(pat, [], [(0, {})])
    check(pat, ["a"], [(1, {})])
    check(pat, ["a", "b"], [(2, {})])
    check(pat, ["a", "b", "c"], [(3, {})])
    pat = WildcardPattern(min=1)
    check(pat, [], [])
    check(pat, ["a"], [(1, {})])
    check(pat, ["a", "b"], [(2, {})])
    check(pat, ["a", "b", "c"], [(3, {})])

# Generated at 2022-06-23 16:02:20.528927
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    a = Node(257, [])
    assert repr(a) == "Node(test, [])"

# Generated at 2022-06-23 16:02:26.235605
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    a = Leaf(syms.expr_stmt, "x")
    b = Leaf(syms.expr_stmt, "y")

    tree = Node(syms.file_input, [])
    tree.append_child(a)
    tree.append_child(b)

    assert b.get_suffix() == ""
    assert a.get_suffix() == "    y"



# Generated at 2022-06-23 16:02:32.732160
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Node, Leaf

    tree = Node(0, [Node(0, [Leaf(1, 'foo'), Leaf(1, 'bar')]), Leaf(1, 'baz')])
    assert [type(x) for x in tree.post_order()] == [Leaf, Leaf, Node, Leaf, Node]

# Generated at 2022-06-23 16:02:35.706422
# Unit test for method depth of class Base
def test_Base_depth():
    def assert_node(node, depth):
        assert node.depth() == depth, node.depth()
    # test depth of the root node
    root = Node(0, parent=None)
    assert_node(root, 0)
    # test depth of a single subnode
    parent = Node(0, parent=root)
    assert_node(parent, 1)
    # test depth of a level 2 subnode
    parent2 = Node(0, parent=parent)
    assert_node(parent2, 2)



# Generated at 2022-06-23 16:02:45.089434
# Unit test for method set_child of class Node
def test_Node_set_child():
    def check_node(node, expected_type, expected_children, expected_parent, expected_prefix, expected_was_changed, expected_was_checked):
        # Check if node is an instance of class Node and if the type of node is
        # equal to expected_type.
        assert isinstance(node, Node)
        assert node.type == expected_type
        # Check if the children of node are equal to expected_children.
        assert node.children == expected_children
        # Check if the parent of node is equal to expected_parent.
        assert node.parent == expected_parent
        # Check if the field prefix of node is equal to expected_prefix.
        assert node.prefix == expected_prefix
        # Check if the field was_changed of node is equal to expected_was_changed.
        assert node.was_changed == expected_was_changed


# Generated at 2022-06-23 16:02:50.361822
# Unit test for method __str__ of class Node
def test_Node___str__():
    grammar = Grammar(r"""
    foo: bar | baz
    """)
    n = grammar.parser.parse("foo", "bar")
    assert n.__str__() == "bar"
    n = grammar.parser.parse("foo", "baz")
    assert n.__str__() == "baz"


# Generated at 2022-06-23 16:02:53.269760
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    pattern = NodePattern(type=Symbol)
    print(pattern.match_seq([1]))



# Generated at 2022-06-23 16:03:04.055128
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    """Unit test for method generate_matches of class BasePattern."""
    # This test is just to make sure the default implementation works.
    # The default implementation is used by LeafPattern and NodePattern.
    from .pgen2 import token
    from .pgen2 import driver

    def t_NAME(tokenizer, token):
        return token.type == token.NAME

    def t_DIGITS(tokenizer, token):
        return token.type == token.NUMBER

    def t_PLUS(tokenizer, token):
        return token.type == token.PLUS

    pytree = driver.parse_string("a + b", "simple_expr", convert)
    _, nodes = pytree.children[0].asList()
    name_pattern = NodePattern(type=token.NAME, name="name")
    expr_pattern = Node

# Generated at 2022-06-23 16:03:13.038917
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():

    t = ast.parse(
        'def f(x):\n'
        '    try:\n'
        '        statement\n'
        '    except Exception as e:\n'
        '        print(e)\n'
        '    finally:\n'
        '        statement',
        'f.py',
        'exec',
    )

    p = ast.parse('def x(): pass', 'x.py', 'exec')

    assert NegatedPattern().match_seq(t.body) is True
    assert NegatedPattern().match(p.body[0]) is False

    def is_except_handler(node):
        return isinstance(node, ast.ExceptHandler)

    assert NegatedPattern(content=is_except_handler).match_seq(t.body) is False

# Generated at 2022-06-23 16:03:16.395354
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import unittest
    self = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    assert str(self) == "ab"


# Generated at 2022-06-23 16:03:21.999206
# Unit test for constructor of class Base
def test_Base():
    """Test constructor of class Base"""

    def test_type_error(args):
        """Test that constructor raises TypeError"""
        try:
            Node(*args)
            assert False, "TypeError not raised"
        except TypeError:
            pass

    test_type_error((1,))
    test_type_error((None,))
    test_type_error((1, "a"))
    test_type_error((1, [2, 3]))


# Node is the superclass of InternalNode and Tree
# Node is an abstract base class that must be subclassed.

# Generated at 2022-06-23 16:03:32.072434
# Unit test for method generate_matches of class WildcardPattern

# Generated at 2022-06-23 16:03:40.976559
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from parser import parse, dump_tree

    assert list(NegatedPattern().generate_matches([parse('1+2')])) == []
    assert list(NegatedPattern().generate_matches([])) == [(0, {})]
    assert list(NegatedPattern(NodePattern(content=[NodePattern()])).generate_matches([])) == []
    assert list(NegatedPattern(NodePattern(content=[NodePattern()])).generate_matches([parse('1+2')])) == [(0, {})]
    assert list(NegatedPattern(NodePattern(content=[NodePattern()])).generate_matches([parse('42')])) == []

# Generated at 2022-06-23 16:03:46.101703
# Unit test for method clone of class Node
def test_Node_clone():
    grammar = Grammar()
    pgen = grammar.parser.parse_string('x = "foo"')
    pgen_copy = pgen.clone()
    assert isinstance(pgen_copy, Node)
    assert pgen_copy.type == symbol.file_input
    assert pgen_copy.children[0].type == token.NAME
    pgen_copy.children[0].type = token.NUMBER  # does not affect pgen
    assert pgen.children[0].type == token.NAME
    assert pgen_copy != pgen



# Generated at 2022-06-23 16:03:50.843362
# Unit test for method __str__ of class Node
def test_Node___str__():
    # test no children
    n = Node(255, [])
    assert str(n) == ""
    # test one child
    m = Leaf(255)
    n = Node(255, [m])
    assert str(n) == str(m)
    # test multiple children
    n = Node(255, [m, m])
    assert str(n) == str(m) + str(m)
    # test invalid type
    assert raises(AssertionError, Node, 256, [])
    # test invalid children
    assert raises(AssertionError, Node, 255, [m, n])

# Generated at 2022-06-23 16:03:57.216807
# Unit test for method post_order of class Node
def test_Node_post_order():
    from . import pytree

    tree = pytree.Node(1, [pytree.Node(2, [pytree.Leaf(3, "")]), pytree.Leaf(4, "")])
    assert [n.type for n in tree.post_order()] == [3, 4, 2, 1]


# Generated at 2022-06-23 16:04:00.443816
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(type=0, content=[])
    assert p.type == 0
    assert p.content == []
    with pytest.raises(AssertionError):
        NodePattern(type=0, content=["a"])



# Generated at 2022-06-23 16:04:05.889514
# Unit test for function generate_matches
def test_generate_matches():
    # Some handy shorthands
    literal = LiteralPattern
    wildcard = WildcardPattern
    blt = NodePattern(type=token.ENDMARKER)
    m = NodePattern(type=tokenize.NAME, name="name")
    m1 = NodePattern(type=tokenize.NAME)
    m2 = NodePattern(type=tokenize.NAME)
    m3 = NodePattern(type=tokenize.NAME)

    # Note: the list of tuples looks a lot like the input to generate_matches!
    # In a sense, this is a kind of round-trip test.

# Generated at 2022-06-23 16:04:12.764900
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pygram import python_symbols

    class LeafTest(Leaf):
        pass

    class NodeTest(Node):
        pass

    l = LeafTest(python_symbols.test, "test")
    n = NodeTest(python_symbols.testlist, None, None, [l])

    assert list(n.leaves()) == [l]


# Unit tests for method next_sibling and prev_sibling of class Base



# Generated at 2022-06-23 16:04:14.565653
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    l = Leaf(255, "42")
    assert "42" in repr(l), repr(l)



# Generated at 2022-06-23 16:04:26.480496
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node

    def tt(tree, expected):
        result = []
        for node in tree.post_order():
            result.append(node)
        assert result == expected

    tt(Node(1, []), [])
    tt(Node(1, [Leaf(1, "A")]), [Leaf(1, "A"), Node(1, [Leaf(1, "A")])])
    tt(
        Node(1, [Leaf(1, "A"), Leaf(1, "B")]),
        [Leaf(1, "A"), Leaf(1, "B"), Node(1, [Leaf(1, "A"), Leaf(1, "B")])],
    )

# Generated at 2022-06-23 16:04:35.149362
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from . import pytree
    from .parse import driver

    node = driver.parse_string("print('hello')\n", debug=True)
    print(repr(node))
    print(node.get_lineno())
    node = driver.parse_string("print('hello')\n", debug=False)
    print(repr(node))
    print(node.get_lineno())
    node = pytree.Leaf(1, "x", "x")
    print(repr(node))
    print(node.get_lineno())
    print(isinstance(node, pytree.Base))


# Generated at 2022-06-23 16:04:45.071490
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    n = Node(TYPE_NAME, [])
    p = NegatedPattern()
    assert p.match(n)
    p = NegatedPattern(NodePattern(type=TYPE_NAME))
    assert p.match (n)
    p = NegatedPattern(NodePattern(type=TYPE_NAME, content=[NodePattern(type=TYPE_NAME)]))
    assert not p.match(n)
    #
    # Issue 17984: A bug in the logic of the match() method of class
    #              NegatedPattern would cause it to loop forever
    p = NegatedPattern(WildcardPattern(content=[
        [NodePattern(type=TYPE_NAME)],
        [NegatedPattern(NodePattern(type=TYPE_NAME))]
        ]))
    assert p.match(n)
    assert not p.match_seq([n])


# Generated at 2022-06-23 16:04:49.766489
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    grammar = Grammar()
    tree = grammar.parse("print(1)")
    print_node = tree.children[0]
    assert print_node.get_suffix() == "("



# Generated at 2022-06-23 16:04:54.777221
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    pat = LeafPattern(123)
    assert repr(pat) == "LeafPattern(123, None, None)"
    from .pgen2.token import tok_name

    pat = LeafPattern(123, "123")
    assert repr(pat) == "LeafPattern(NUMBER, '123', None)"
    pat = NodePattern(123, "123")
    assert repr(pat) == "NodePattern(%s, ['123'], None)" % tok_name[123]
    pat = NodePattern(123, "123", "def")
    assert repr(pat) == "NodePattern(%s, ['123'], 'def')" % tok_name[123]



# Generated at 2022-06-23 16:04:59.609897
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    """Check Base.get_lineno()."""

    _sample_leaf = parse("a = 1\n").children[0].children[0]
    assert _sample_leaf.get_lineno() == 1



# Generated at 2022-06-23 16:05:07.618515
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import Token
    p1 = LeafPattern(Token.NAME, "yada")
    nodes = [Leaf(Token.NAME, "yada")]
    assert tuple(p1.generate_matches(nodes)) == ((1, {}),)
    p1 = LeafPattern(Token.NAME, "yada", name="yada")
    nodes = [Leaf(Token.NAME, "yada")]
    assert tuple(p1.generate_matches(nodes)) == ((1, {"yada": Leaf(Token.NAME, "yada")}),)



# Generated at 2022-06-23 16:05:13.103445
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver
    from .pygram import python_symbols as syms, python_grammar as _python_grammar
    from .pgen2 import literals
    d = Driver(
        _python_grammar, convert,
        python_grammar_repr, str,
        literals,
        _python_grammar._monolithic_parsing_table
    )
    root = d.parse_file("test/test_ast.py")
    assert root.children[1].children[0].children[2].prefix.endswith("\n  ")
    assert root.children[1].children[0].children[2].value == "eventually_fail"
    assert root.children[1].children[0].children[3].value == "("

# Generated at 2022-06-23 16:05:14.325632
# Unit test for constructor of class BasePattern
def test_BasePattern():
    BasePattern(3)



# Generated at 2022-06-23 16:05:24.598733
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """
    1
    2
    3
    4
    5
    6
    7
    8
    9
    10
    11
    12
    13
    14
    15
    16
    17
    18
    19
    20
    21
    22
    23
    24
    25
    26
    27
    28
    29
    30
    """
    from .pytree import Leaf, Node


# Generated at 2022-06-23 16:05:26.731934
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(123, [LeafPattern(1)], "name")
    assert repr(p) == "NodePattern(123, [LeafPattern(1, None)], 'name')"

patterns = (LeafPattern, NodePattern, WildcardPattern)
patterns = dict((c.__name__, c) for c in patterns)


# Generated at 2022-06-23 16:05:28.269163
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    test_string = 'a = "test string"'
    leaf = Leaf(3, test_string)
    assert leaf.leaves() == [(3, test_string)]
test_Leaf_leaves()
#Unit test for method depth of class Leaf

# Generated at 2022-06-23 16:05:29.120130
# Unit test for constructor of class Leaf
def test_Leaf():
    Leaf(0, "value", context=None, prefix=None, fixers_applied=None)

# Generated at 2022-06-23 16:05:40.885980
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():

    import textwrap

    from .pgen2 import driver, tokenize

    from .pytree import Leaf as L

    from . import patcomp

    from .patcomp import LeafPattern, NodePattern, WildcardPattern

    assert LeafPattern(1, 'hello').match(L(1, 'hello'))

    # Test string pattern
    p = LeafPattern(1, 'hello')
    assert p.match(L(1, 'hello'))
    assert not p.match(L(1, 'world'))
    assert not p.match(L(2, 'hello'))

    # Test name capturing
    p = LeafPattern(1, 'hello', 'foo')
    assert p.match(L(1, 'hello'), {})
    assert p.match(L(1, 'hello'), {'foo': L(1, 'hello')})


# Generated at 2022-06-23 16:05:41.932152
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    Leaf(1,2)


# Generated at 2022-06-23 16:05:52.052966
# Unit test for function convert
def test_convert():
    from .pgen2 import driver

    gr = driver.load_grammar("Grammar/Grammar", "Grammar/ast.txt", convert)
    l1 = Leaf(1, "a")
    l2 = Leaf(1, "a")
    l3 = Leaf(2, "b")
    l4 = Leaf(2, "c")
    l5 = Leaf(3, "d")
    l6 = Leaf(3, "e")

    def t(i, o):
        return o in list(i.pre_order())

    n = convert(gr, (257, None, None, [l1, l2, l3, l4, l5, l6]))
    assert t(n, l1)
    assert t(n, l2)
    assert t(n, l3)
   

# Generated at 2022-06-23 16:05:54.811494
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(token.NAME, "name", prefix="prefix ")
    assert list(l.pre_order()) == [l]


# Generated at 2022-06-23 16:05:58.730873
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, 'a', (1,2))
    assert l.type == 1
    assert l.value == 'a'
    assert l.prefix == '', l.prefix
    assert l.lineno == 1
    assert l.column == 2


# Generated at 2022-06-23 16:06:09.399191
# Unit test for function convert
def test_convert():
    class DummyGrammar:
        number2symbol = {}

    class DummyNode:
        children: List[Text] = []
        type: Text = "DUMMY"


    for raw_node, expect in [
        ([None, "foo", None, [Node(1, "bar", [Node(2, "baz")])]], "baz"),
        ([None, "foo", None, [Node(1, "bar", [Node(2, "baz", [Leaf(None, None)])])]], "baz"),
        ([None, "foo", None, [Node(1, "bar", [Node(2, "baz", [Leaf(3, "baz")])])]], "baz"),
    ]:
        dummy_node = DummyNode()

# Generated at 2022-06-23 16:06:10.434317
# Unit test for method get_suffix of class Base

# Generated at 2022-06-23 16:06:17.788827
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    def test_empty_nodes():
        p = LeafPattern(token.NAME)
        assert not list(p.generate_matches([]))
    test_empty_nodes()
    def test_single_node():
        p = LeafPattern(token.NAME)
        n = Leaf(token.NAME, "foo")
        m = list(p.generate_matches([n]))
        assert m == [(1, {"NAME": n})]
    test_single_node()



# Generated at 2022-06-23 16:06:27.840085
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import token

    r0 = LeafPattern(token.NAME)
    assert r0.match(Leaf(token.NAME, None, ""))
    assert not r0.match(Leaf(token.NUMBER, None, ""))
    r1 = LeafPattern(token.NAME, "async")
    assert r1.match(Leaf(token.NAME, "async", ""))
    assert not r1.match(Leaf(token.NAME, "await", ""))
    # Test that named patterns are stored in the results dict
    r2 = LeafPattern(token.NAME, name="node")
    r3 = LeafPattern(token.NAME, "async", name="token")
    r4 = LeafPattern(token.NAME, name="token")
    results = {}

# Generated at 2022-06-23 16:06:33.492333
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    child0 = Leaf(1, "spam")
    child1 = Leaf(1, "eggs")
    child2 = Leaf(1, "toast")
    node = Node(1, [child0, child1, child2])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map == None
    assert node.next_sibling_map == None
    return 0



# Generated at 2022-06-23 16:06:43.980336
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert issubclass(LeafPattern, BasePattern)
    leaf_pattern = LeafPattern(1, 32)
    assert isinstance(leaf_pattern, BasePattern)
    assert isinstance(leaf_pattern, LeafPattern)
    assert not isinstance(leaf_pattern, NodePattern)
    assert not isinstance(leaf_pattern, WildcardPattern)
    assert not isinstance(leaf_pattern, Pattern)
    assert not isinstance(leaf_pattern, object)
    assert isinstance(leaf_pattern, BasePattern)
    assert not issubclass(LeafPattern, NodePattern)
    assert not issubclass(LeafPattern, WildcardPattern)
    assert not issubclass(LeafPattern, Pattern)
    assert not issubclass(LeafPattern, object)
    assert issubclass(LeafPattern, BasePattern)
    assert issubclass

# Generated at 2022-06-23 16:06:54.918264
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    for type, content, name in ((None, None, "bare_name"),):
        n = NodePattern(type, content, name)
        for expected, match_string in (
            (True, """def f(x):
    return x + 1
"""),
            (False, """"""),
            (False, """def f():
    return x + 1
"""),
            (False, """def f(x):
    print(x)
"""),
            (False, """def f(x):
    return x
"""),
            (False, """def f(x):
    return x + 2
"""),
        ):
            assert expected == WildcardPattern(min=1, max=1, content=n).match(
                parse(match_string)
            )



# Generated at 2022-06-23 16:07:03.916836
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # test of the pattern '.+'
    str = '  private static final String[] _keywords = {'
    statements = parser.parse(str)
    wp = WildcardPattern(min=1)
    nodes = statements[0].getChildNodes()
    matches = list(wp.generate_matches(nodes))
    assert len(matches) == 1
    # test of the pattern '(.|\n)+'
    str = """
    private static final String[] _keywords = {
        """
    statements = parser.parse(str)
    wp = WildcardPattern(((NodePattern(),), (Leaf(token.NEWLINE),)), min=1)
    nodes = statements[0].getChildNodes()
    matches = list(wp.generate_matches(nodes))
    assert len(matches)

# Generated at 2022-06-23 16:07:11.501009
# Unit test for method post_order of class Base
def test_Base_post_order():
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.token as token
    g = Grammar()
    tree = parse.parse(
        """\
s = '''
  a = 3
  b = 4
'''
""", g, token.Token)
    assert list(tree.post_order()) == [
        tree.children[1].children[1],
        tree.children[1].children[0].children[1],
        tree.children[1].children[0].children[0],
        tree.children[1].children[0],
        tree.children[1],
        tree,
    ]



# Generated at 2022-06-23 16:07:16.647444
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from . import parsetokens

    class DummyNode:
        def __init__(self, value):
            self.value = value

    n = DummyNode(1)
    p = NodePattern()
    p.match(n)
    n = DummyNode(2)
    p.match(n)
    n = DummyNode(3)
    p.match(n)
test_NegatedPattern_match()

# Generated at 2022-06-23 16:07:26.610081
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern()
    assert WildcardPattern(None)
    assert WildcardPattern(min=0)
    assert WildcardPattern(max=HUGE)
    assert WildcardPattern(min=0, max=HUGE)
    assert WildcardPattern(None, 0, HUGE)
    assert WildcardPattern(NodePattern(), 1, 1)
    assert WildcardPattern(None, 0, 1)
    assert WildcardPattern(None, 1, HUGE)
    assert WildcardPattern(None, 0, HUGE)
    assert WildcardPattern([], 0, HUGE)
    assert WildcardPattern((), 0, HUGE)
    assert WildcardPattern((), 0, HUGE)
    assert WildcardPattern(((NodePattern(),),), 0, HUGE)
    assert WildcardPattern(((NodePattern(),),), 1, HUGE)

# Generated at 2022-06-23 16:07:37.641970
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    def check_matches(pattern, nodes, expect):
        yield from check_match(pattern, nodes, expect, expect)

    def check_match(pattern, nodes, expect_matches, expect_counts):
        actual_matches, actual_counts = set(), set()
        for c, r in pattern.generate_matches(nodes):
            actual_matches.add(r)
            actual_counts.add(c)
        assert actual_matches == expect_matches, (
            "pattern.generate_matches(%s) returned %s, expected %s"
            % (nodes, actual_matches, expect_matches)
        )

# Generated at 2022-06-23 16:07:39.155938
# Unit test for constructor of class BasePattern
def test_BasePattern():
    class DummyPattern(BasePattern):
        pass

    DummyPattern(12, "something", "name")



# Generated at 2022-06-23 16:07:42.942681
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    t = Leaf(1, 'x', fixers_applied=[])
    assert list(t.pre_order()) == [t]


# Generated at 2022-06-23 16:07:47.943666
# Unit test for constructor of class BasePattern
def test_BasePattern():
    p = BasePattern()
    assert p.type is None
    assert p.content is None
    assert p.name is None
    assert p.match(None) is False
    assert p.match_seq([]) is False
    assert list(p.generate_matches([])) == []



# Generated at 2022-06-23 16:07:50.084594
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    a = Node(0,[])
    b = Leaf(0,1)
    a.insert_child(0,b)
    return a.children


# Generated at 2022-06-23 16:07:51.077595
# Unit test for constructor of class BasePattern
def test_BasePattern():
    pat = BasePattern()


# Generated at 2022-06-23 16:07:53.235214
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """No tests yet"""
    pass # Don't know how to test __repr__

# Generated at 2022-06-23 16:08:00.837556
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():

    class TestPattern(NodePattern):
        def __init__(self, content=None, name=None):
            super(TestPattern, self).__init__(type=token.TEST, content=content, name=name)

    s = 'def func(a, b, c=1, *args, **kwargs): pass'
    before = TestPattern(
        content=  [WildcardPattern(type=token.TEST),
                   SequencePattern(
                       LeafPattern(type=token.COMMA),
                       LeafPattern(type=token.LPAR),
                       LeafPattern(type=token.RPAR),
                   ),
               ],
        name=None
    )


# Generated at 2022-06-23 16:08:10.527306
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf, Node
    from .pygram import python_grammar
    from . import pytoken

    names = python_grammar.names

    n = Node(python_grammar.syms.newline, [Leaf(pytoken.NEWLINE, "\n")])
    n.changed()
    assert n.was_changed
    assert not n.was_checked
    assert not n.children[0].was_changed

    m = n.clone(parent=None)
    assert m.children[0].prefix == n.children[0].prefix
    assert m.children[0].value == n.children[0].value
    assert m.children[0].changed == n.children[0].changed
    assert names[m.type] == names[n.type]
    assert m.was_changed == n.was_

# Generated at 2022-06-23 16:08:16.142592
# Unit test for method __eq__ of class Base
def test_Base___eq__():
  assert Base().__eq__(Leaf(1, "")) == NotImplemented
  assert Base(1).__eq__(Leaf(1, "")) == NotImplemented
  assert Base(1, 2).__eq__(Leaf(1, "")) == NotImplemented
  assert Base(1, 2, 3).__eq__(Leaf(1, "")) == NotImplemented
  assert Base(1, 2, 3, 4).__eq__(Leaf(1, "")) == NotImplemented



# Generated at 2022-06-23 16:08:24.591786
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern()
    assert p
    assert not p.content
    p = WildcardPattern([[0], [1]])
    assert p.content
    p = WildcardPattern([[0], [1]], min=1, max=2)
    assert p.min == 1
    assert p.max == 2
    assert p.name is None
    p = WildcardPattern([[0], [1]], min=1, max=2, name="foo")
    assert p.min == 1
    assert p.max == 2
    assert p.name == "foo"



# Generated at 2022-06-23 16:08:26.679730
# Unit test for method leaves of class Base
def test_Base_leaves():
  base = Base()
  result = base.leaves()
  assert False

# Generated at 2022-06-23 16:08:29.017829
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    bp = BasePattern()
    bp.type
    bp.content
    bp.name

# Generated at 2022-06-23 16:08:30.924592
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    a = Node(0, [])
    assert repr(a) == "Node(0, [])"


# Generated at 2022-06-23 16:08:35.685462
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    def check_string(content, expected):
        result = repr(NegatedPattern(content))
        assert result == expected, (result, expected)
    check_string(None, "NegatedPattern(None)")
    check_string("abc", "NegatedPattern('abc')")
    check_string(WildcardPattern(None), "NegatedPattern(WildcardPattern(None))")


# Generated at 2022-06-23 16:08:42.594548
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    print("Running test Node insert_child")
    t = translator.Translator("from __future__ import print_function")
    t.driver.grammar = get_grammar()
    input = "from __future__ import print_function"
    tree = t.parse_string(input)
    x = Node(100, [], None, None)
    tree.children[0].insert_child(0, x)
    print(tree.children[0].children[0].type == 100)
    print(tree.children[0].children[0].parent == tree.children[0])
    print(tree.children[0].children[0].children == [])
    print(tree.children[0].children[0].prefix == None)
    print(tree.children[0].children == [x, tree.children[1]])


# Generated at 2022-06-23 16:08:53.838300
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():

    def test(n, l):
        l1 = n.get_lineno()
        assert l is None or l1 == l, str((n, l, l1))
        l1 = n.get_lineno()
        assert l is None or l1 == l, str((n, l, l1))

    a = Leaf(1, "")
    test(a, None)
    a.lineno = 3
    test(a, 3)
    b = Node(1, [a])
    test(b, 3)
    a.lineno = 4
    test(b, 4)
    b.children.append(Leaf(1, "", (1, 4)))
    test(b, 4)
    b.children.append(Leaf(1, "", (1, 5)))
    test(b, 5)

# Generated at 2022-06-23 16:08:58.353719
# Unit test for function generate_matches
def test_generate_matches():
    p = WildcardPattern(None, min=1, max=1)  # literal dot
    #                      ^-- must match at least once
    #                         ^-- must match at most once
    n = [1, 2, 3, 4]
    pn = WildcardPattern([
        [NodePattern(type=1), NodePattern(type=2), p, NodePattern(type=3)],
        [NodePattern(type=1), NodePattern(type=2), p, NodePattern(type=4)],
    ], min=1, max=1)
    pn.wildcards = True
    for r in generate_matches([pn], n):
        print(f"PN: {r}")

# Generated at 2022-06-23 16:08:59.344650
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert isinstance(BasePattern(), BasePattern)



# Generated at 2022-06-23 16:09:08.290648
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    node = Node(0, [])
    node.append_child(Leaf(0, ''))
    node.insert_child(0, Leaf(0, ''))
    node.insert_child(1, Leaf(0, ''))
    node.insert_child(2, Leaf(0, ''))
    if ((len(node.children) == 4) and (node.children[0].prefix == '') and (node.children[1].prefix == '') and (node.children[2].prefix == '') and (node.children[3].prefix == '')):
        return 0
    return 1

# Generated at 2022-06-23 16:09:18.274020
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Base, Leaf, Node

    class MyNode(Node):
        def _eq(self, other):
            return self.children == other.children

        def clone(self):
            return MyNode(self.children)

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

    class MyLeaf(Leaf):
        def _eq(self, other):
            return self.value == other.value

        def clone(self):
            return MyLeaf(self.value, self.prefix)

        def post_order(self):
            yield self

        def pre_order(self):
            yield self



# Generated at 2022-06-23 16:09:29.620586
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from .nodes import NL

    node = NL(1)
    pat = WildcardPattern()
    for c, r in pat.generate_matches([node]):
        print(c, r)

    import sys
    import types

    if type(sys.getrefcount) == types.BuiltinMethodType:
        print("Testing recursion limit...")
        import io

        pat = WildcardPattern(min=1, max=20)
        node = NL(1)
        nodes = [node] * 21
        buf = io.StringIO()
        save_stderr = sys.stderr
        sys.stderr = buf

# Generated at 2022-06-23 16:09:30.534653
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    assert not BasePattern.match_seq(None, None)


# Generated at 2022-06-23 16:09:39.639484
# Unit test for method remove of class Base
def test_Base_remove():
    # test a Leaf
    l = Leaf(1, 'leaf1')
    l.remove()
    assert l.parent is None

    # test a Node
    n = Node(1, 'node1')
    n.remove()
    assert n.parent is None

    # test a Leaf with a parent
    l1 = Leaf(1, 'leaf1')
    l2 = Leaf(1, 'leaf2')
    l1.add_child(l2)
    l2.remove()
    assert l2.parent is None
    assert l1.children == []

    # test a Node with a parent
    n1 = Node(1, 'node1')
    n2 = Node(1, 'node2')
    n1.add_child(n2)
    n2.remove()
    assert n2.parent is None


# Generated at 2022-06-23 16:09:49.533381
# Unit test for method post_order of class Node
def test_Node_post_order():
    from . import pytree


# Generated at 2022-06-23 16:09:53.777732
# Unit test for method clone of class Node
def test_Node_clone():
    node1 = Node(0, [Leaf(1, ""), Leaf(2, "")])
    node2 = Node(0, [Leaf(1, ""), Leaf(2, "")])
    assert (node1 == node2)
    assert (node1.clone() == node2)
    return

# Generated at 2022-06-23 16:10:01.210746
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    import textwrap
    from grako.parser import ModelBuilderSemantics
    import grako.tools

# Generated at 2022-06-23 16:10:12.654229
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    n = Node(syms.file_input, [], prefix="")
    assert n.get_lineno() == 0

    n = Node(syms.file_input,
             [Leaf(1, "one", (0, 0), prefix=""),
              Leaf(2, "two", (0, 0), prefix="")],
             prefix="")
    assert n.get_lineno() == 0

    n = Node(syms.file_input,
             [Leaf(1, "one", (0, 0), prefix=""),
              Leaf(2, "two", (1, 2), prefix="")],
             prefix="")
    assert n.get_lineno() == 0


# Generated at 2022-06-23 16:10:15.751733
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    # assert False # TODO: implement your test here
    raise NotImplementedError()


# Generated at 2022-06-23 16:10:20.559235
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    # Creating a node 
    node = Node(1,None,None) # pylint: disable=E1136
    # Creating a child 
    child = Node(2,None,None) # pylint: disable=E1136
    # Inserting the new child 
    node.insert_child(0,child)

# Generated at 2022-06-23 16:10:29.822108
# Unit test for constructor of class Node
def test_Node():
    # Note: don't use a doctest here, because we need to silence warnings
    # emitted by the code below during testing.  (When run with the -3 flag,
    # the code that follows is indeed an error.)
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        n = Node(1, [])
        assert n.type == 1
        assert len(n.children) == 0
        assert n.prefix == ""
        assert n.parent is None
        l = Leaf(
            1,
            "",
            (1, 0),
        )
        n.append_child(l)
        assert len(n.children) == 1
        assert l.parent is n
        m = Leaf(
            1,
            "",
            (2, 0),
        )
        n

# Generated at 2022-06-23 16:10:32.698178
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(0) == 0
    assert type_repr(python_symbols.NAME) == "NAME"



# Generated at 2022-06-23 16:10:42.353186
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from pprint import pprint

    grammar = """
        a : b c e
        ;
        b : 'b' | 'B'
        ;
        c : 'c' | 'C'
        ;
        d : 'd' | 'D'
        ;
        e : 'e'
        | 'e' d
        ;
    """

    g = Grammar()
    g.parse_grammar(grammar)
    g.process_subscripts()
    pt = g.pgen.parsers["start"].parse_string(
        "b c e", "a", debug=None
    )

    pprint(list(pt.pre_order()))



# Generated at 2022-06-23 16:10:45.274896
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    cls = BasePattern

    assert cls is not BasePattern
    assert cls.__new__ is not BasePattern.__new__



# Generated at 2022-06-23 16:10:50.490769
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # Test for correct handling of the empty string
    for pattern in [WildcardPattern(name="p"), WildcardPattern((), name="p"), WildcardPattern(((NodePattern(),),), name="p")]:
        assert pattern.match_seq([])
        assert pattern.match_seq([Leaf(0, "")])
    # Test for correct handling of newlines
    pattern = WildcardPattern(((NodePattern(type=token.NEWLINE),),), name="p")
    assert pattern.match_seq([Leaf(token.NEWLINE, "\n")])
    assert pattern.match_seq([Leaf(token.NEWLINE, "\r\n")])
    assert not pattern.match_seq([])
    assert not pattern.match_seq([Leaf(0, "")])
    # Test for correct handling of no newlines
    pattern = Wild

# Generated at 2022-06-23 16:10:57.632482
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Node, Leaf
    from ..pygram import python_symbols as syms

    def make_node(level, val):
        if level == 0:
            return Leaf(val)
        else:
            return Node(syms.listmaker, [make_node(level - 1, val)])

    def count(tree):
        return sum(1 + count(child) for child in tree.children)

    tree = make_node(5, 1)
    total = count(tree)
    assert len(list(tree.post_order())) == total



# Generated at 2022-06-23 16:10:59.735571
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    assert Base(type=None,
                parent=None,
                children=[]) == Base(type=None,
                                     parent=None,
                                     children=[])



# Generated at 2022-06-23 16:11:09.200487
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    def assert_optimize(pattern, expected):
        result = pattern.optimize()
        assert expected == result, "{} != {}".format(repr(expected), repr(result))
    assert_optimize(AltPattern(NodePattern(SYNC, ""), NodePattern(SYNC, "")), NodePattern(SYNC, ""))
    assert_optimize(AltPattern(NodePattern(SYNC, "a"), NodePattern(SYNC, "")), NodePattern(SYNC, "a"))
    assert_optimize(AltPattern(NodePattern(SYNC, ""), NodePattern(SYNC, "b")), NodePattern(SYNC, "b"))

# Generated at 2022-06-23 16:11:18.188455
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import token
    import unittest
    from . import tokenize  # for side effect of filling token.tok_name

    class TestPattern(BasePattern):
        def _submatch(self, node, results=None):
            return node.value == "substring"

    class MatchesTests(unittest.TestCase):
        def test_no_content(self):
            p = BasePattern(token.NAME)
            self.assertTrue(p.match(Leaf(token.NAME, "spam")))
            self.assertFalse(p.match(Leaf(token.NAME, "eggs")))
            self.assertFalse(p.match(Leaf(token.NAME + 256, "spam")))


# Generated at 2022-06-23 16:11:26.751090
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    class TestNode(Node):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.tokens: List[Leaf] = []

        def leaves(self):
            return self.tokens

    t = TestNode(58, [
        Token(58, '(', prefix=' '),
        Token(1, 'x', prefix=' '),
    ])
    t.tokens = list(t.leaves())
    assert len(t.tokens) == 2


# Generated at 2022-06-23 16:11:31.438449
# Unit test for method remove of class Base
def test_Base_remove():
    """
    Test method Base.remove
    :return: None
    """
    bn = Base()
    assert bn.remove() is None
    print("test_Base_remove ok")



# Generated at 2022-06-23 16:11:38.764275
# Unit test for method remove of class Base
def test_Base_remove():
    class TestNode (Node):
        def _eq(self, other): return True
    class TestLeaf (Leaf): pass
    class TestPyTree (PyTree):
        def _eq(self, other): return True
    pyTree = TestPyTree("a b", [[TestNode("1 2")], [TestNode("3 4")]],
                        [TestLeaf("a b c", False, True),
                         TestLeaf("x y z", True, True)])
    node = pyTree.children[0].children[0]
    assert node.type == "1", node.type
    i = node.remove()
    assert i == 0, i
    assert pyTree.children[0].type == "2", pyTree.children[0].type

    leaf = pyTree.leaves[0]

# Generated at 2022-06-23 16:11:41.632177
# Unit test for constructor of class Node
def test_Node():
    node = Node(256, [])
    assert node.prefix is not None


T = TypeVar("T", bound=Base)



# Generated at 2022-06-23 16:11:47.868593
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf

    root = Node(syms.foo, [Node(syms.bar, [Leaf(1, "a"), Leaf(1, "b")]), Leaf(1, "c")])
    for ch in root.leaves():
        ch.value = ch.value.upper()
    assert str(root) == "foo(bar('A', 'B'), 'C')"



# Generated at 2022-06-23 16:11:57.892079
# Unit test for method changed of class Base
def test_Base_changed():
    import copy
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.pgen as pgen
    import lib2to3.pygram as pygram

    # Test that the changed method is propagated up the tree as expected.
    def test(source: Text) -> Iterator[Node]:
        # Test that changed() is propagated up the tree correctly
        tree = test_parse_tree(source)
        tree.children[0].children[1].children[0].changed()
        yield tree.children[0].children[1].children[0]
        yield tree.children[0].children[1]
        yield tree.children[0]
        yield tree

    for node in test("def f(): pass"):
        assert node