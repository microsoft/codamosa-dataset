

# Generated at 2022-06-23 16:01:54.914935
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf1 = Leaf(1, "test")
    assert leaf1.leaves() == iter([leaf1])


# Generated at 2022-06-23 16:01:58.145694
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    tree = parse_string("#!hello\nf = 42")
    tree.children[0].prefix = ' '
    tree.insert_child(1, Leaf(token.NEWLINE, '\n'))
    assert str(tree) == "\n f = 42"


# Generated at 2022-06-23 16:02:01.883101
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "Hello")
    assert l.type == 1
    assert l.value == "Hello"



# Generated at 2022-06-23 16:02:08.953053
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    l = Leaf(token.NAME, "MYNAME", prefix="a b c ", fixers_applied=["MyFixer"])
    l.parent = None
    l2 = l.clone()
    assert l2.value == "MYNAME"
    assert l2.prefix == "a b c "
    assert l2.fixers_applied == ["MyFixer"]
    assert l2.parent is None
    assert l2.parent == l.parent
    assert l2 != l
    assert not l2 != l2



# Generated at 2022-06-23 16:02:14.069581
# Unit test for constructor of class Node
def test_Node():
    class A(Node):
        pass

    class B(Leaf):
        pass

    B.type = 1
    A.type = 2
    a = A([B([])], None)
    assert a.type == 2
    assert len(a.children) == 1
    assert a.children[0].type == 1
    b = a.children[0]
    assert b.parent is a
    b.parent = None



# Generated at 2022-06-23 16:02:16.412287
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    tree = Leaf(1, "value")
    assert list(tree.pre_order()) == [tree]


# Generated at 2022-06-23 16:02:21.821941
# Unit test for function convert
def test_convert():
    from .pgen2 import driver

    # Test without children
    g = driver.load_grammar("Grammar/Grammar", "Grammar/Grammar", {})
    n = convert(g, (0, "", None, None))
    assert isinstance(n, Leaf) and n.value == "" and not n.children

    # Test with children
    g = driver.load_grammar("Grammar/Grammar", "Grammar/Grammar", {})
    c1 = Leaf(1, "foo")
    c2 = Leaf(1, "bar")
    n = convert(g, (0, "", None, [c1, c2]))
    assert isinstance(n, Node) and not n.value and n.children == [c1, c2]
    assert n is c1

# Generated at 2022-06-23 16:02:28.559183
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    Checks that optimizations are applied in a pattern.
    """
    pattern = OrPattern(
        [
            LeafPattern(token.NAME, "abc"),
            LeafPattern(token.NAME, "def"),
            LeafPattern(token.NAME, "ghi"),
        ]
    )
    assert pattern is not pattern.optimize()
    assert len(pattern.optimize().patterns) == 1


# Concrete subclasses

# Generated at 2022-06-23 16:02:35.257998
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Test a node pattern with 1 subpattern
    # Test a node pattern with 2 subpatterns
    x = NodePattern(content=[NodePattern(content=[LeafPattern()])])
    y = NodePattern(content=[LeafPattern()])
    z = NodePattern(content=[y, x])
    assert y == NodePattern(content=[LeafPattern()])
    assert x == NodePattern(content=[LeafPattern()])
    assert y != x
    assert z == NodePattern(content=[LeafPattern(), NodePattern(content=[LeafPattern()])])



# Generated at 2022-06-23 16:02:43.703526
# Unit test for method clone of class Base
def test_Base_clone():
    from .pgen2.token import Token

    class FakeNode(Base, Node):
        # Fake a Node since we're not testing Base in context of a
        # real tree.
        type = 14
        children = [Leaf(1, "some prefix"), Leaf(2, "some suffix")]

    n = FakeNode()
    c = n.clone()
    assert (n.type, "some prefix", "some suffix") == (
        c.type,
        c.children[0].prefix,
        c.children[1].prefix,
    )
    assert c.type is FakeNode.type
    assert c.children[0].type is Token.LBRACE



# Generated at 2022-06-23 16:02:46.480979
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.token import tok_name

    l = Leaf(1, "a")
    print(l)
    print(repr(l))
    l.post_order()
    l.pre_order()

    l2 = Leaf(1, "b")
    l.replace(l2)
    print(l2)
    print(repr(l2))
    l2.post_order()
    l2.pre_order()



# Generated at 2022-06-23 16:02:52.744481
# Unit test for method depth of class Base
def test_Base_depth():
    class Node(Base):
        def _eq(self, other):
            raise NotImplementedError
        def clone(self):
            raise NotImplementedError
        def post_order(self):
            raise NotImplementedError
        def pre_order(self):
            raise NotImplementedError

    root = Node()
    assert root.depth() == 0
    root.parent = Node()
    assert root.parent.depth() == 1



# Generated at 2022-06-23 16:02:58.328394
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern([[LeafPattern("x")], [LeafPattern("y")]], 2, 2, "foo")
    assert p.optimize() == p
    p = WildcardPattern([[LeafPattern("x")], [LeafPattern("y")]], 2, 2)
    assert p.optimize() == p
    p = WildcardPattern([[LeafPattern("x")], [LeafPattern("y")]], 1, 1)
    assert p.optimize() == WildcardPattern(
        [[LeafPattern("x")], [LeafPattern("y")]]
    )
    p = WildcardPattern([[LeafPattern("x")], [LeafPattern("y")]], 0, 1)

# Generated at 2022-06-23 16:03:08.444648
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf

    class MyNode(Base):
        def __init__(self, prefix=""):
            self.children = []
            self.prefix = prefix

        def __repr__(self):
            return "M"

        def _eq(self, other):
            return True

        def clone(self):
            return self

        def post_order(self):
            return iter(self.children)

        def pre_order(self):
            return iter(self.children)

    class MyLeaf(Leaf):
        def __init__(self, prefix=""):
            self.prefix = prefix

        def __repr__(self):
            return "L"

        def _eq(self, other):
            return True

        def clone(self):
            return self

    root = MyNode(prefix="")


# Generated at 2022-06-23 16:03:20.152389
# Unit test for method post_order of class Node
def test_Node_post_order():
    # default argument values
    assert repr(_Node__post_order_0()) == "1"
    assert repr(_Node__post_order_1()) == "2"
    assert repr(_Node__post_order_2()) == "3"
    assert repr(_Node__post_order_3()) == "4"
    assert repr(_Node__post_order_4()) == "5"
    assert repr(_Node__post_order_5()) == "6"
    # no argument given
    assert repr(_Node__post_order_6()) == "7"
    # positional argument
    assert repr(_Node__post_order_7()) == "8"
    assert repr(_Node__post_order_8()) == "9"
    assert repr(_Node__post_order_9()) == "10"
    # keyword argument

# Generated at 2022-06-23 16:03:22.101691
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    x = LeafPattern(1, "abc")
    assert x.type == 1
    assert x.content == "abc"
    assert x.name is None
    assert repr(x) == "LeafPattern(NUMBER, 'abc')"



# Generated at 2022-06-23 16:03:23.611546
# Unit test for constructor of class Base
def test_Base():
    # Test default values
    obj = Base()
    assert obj.children is None



# Generated at 2022-06-23 16:03:28.966365
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from lib2to3.pgen2.token import tok_name # imported from pgen2 to speedup loading
    from . import parse, r_elem

# Generated at 2022-06-23 16:03:37.369607
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import BaseBox
    from .pygram import python_symbols
    from .pygram import python_grammar
    p = BaseBox('x', "if 4:\n    x\n")
    assert p.test(python_grammar.simple_stmt, "simple_stmt")
    assert p.children[0].type == python_symbols.expr_stmt
    node = p.children[0]
    node.set_child(1, BaseBox('x', "4"))
    assert p.children[0].children[1].type == python_symbols.testlist
    assert p.children[0].children[1].children[0].value == "4"
    #    print(p)
    node.set_child(1, BaseBox('x', "4+4"))
    assert p

# Generated at 2022-06-23 16:03:48.568916
# Unit test for method invalidate_sibling_maps of class Node

# Generated at 2022-06-23 16:03:53.806892
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from .misc import dump_tree

    pat = NegatedPattern(None)
    tree = StringNode(1, "a")
    assert not pat.match_seq([tree])
    assert pat.match_seq([])

    pat = NegatedPattern(LeafPattern(1, "a"))
    tree = StringNode(1, "a")
    assert not pat.match_seq([tree])

    pat = NegatedPattern(NodePattern(1, [LeafPattern(1, "a")]))
    tree = StringNode(1, "a")
    assert not pat.match_seq([tree])
    tree = Node(1, [StringNode(1, "a")])
    assert not pat.match_seq([tree])


# Generated at 2022-06-23 16:04:00.491583
# Unit test for constructor of class Base
def test_Base():
    # pylint: disable=unused-variable
    class BaseTest(Base):
        def _eq(self, other):
            return self is other

        def clone(self):
            return object.__new__(BaseTest)

        def pre_order(self):
            yield self

        def post_order(self):
            yield self

    BaseTest()  # Expected not to crash
    # pylint: enable=unused-variable



# Generated at 2022-06-23 16:04:09.582203
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    """
    If a Node's children change, then the sibling maps must be invalidated.
    """
    from .pytree import Node, Leaf
    node1 = Node(1, [Leaf(1, 'a')])
    node2 = Node(2, [Leaf(1, 'b'), Leaf(2, 'c')])
    assert node1.prev_sibling_map is None
    assert node1.next_sibling_map is None
    assert node2.prev_sibling_map is None
    assert node2.next_sibling_map is None
    node1.append_child(node2)
    assert node1.prev_sibling_map is not None
    assert node1.next_sibling_map is not None
    assert node2.prev_sibling_map is not None
    assert node2.next_

# Generated at 2022-06-23 16:04:12.705224
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.grammar import Symbol

    def _gen(n):
        return _DummySymbol(n)

    class DummyPattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    p = DummyPattern(Symbol.dummy, None)
    assert p.match(_gen(Symbol.dummy))
    assert not p.match(_gen(Symbol.foo))



# Generated at 2022-06-23 16:04:17.728205
# Unit test for method append_child of class Node
def test_Node_append_child():
    # fixme: NameError: name 'Node' is not defined
    node = Node(0, [])
    node.append_child(Leaf(0, ""))
    node.append_child(Leaf(0, ""))
    assert len(node.children) == 2
test_Node_append_child()



# Generated at 2022-06-23 16:04:28.092524
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import unittest

    class WildcardPatternTest(unittest.TestCase):

        def check(self, wildcard, pattern, seq, num_matches=None):
            print("Checking", wildcard, "and", pattern, "with", seq, end=" -> ")
            wildcard = WildcardPattern(content=pattern)
            matcher = NL.from_iterable(seq)
            matches = list(wildcard.generate_matches(matcher))
            print("Got", matches)
            if num_matches is not None:
                self.assertEqual(
                    num_matches,
                    len(matches),
                    msg="wrong number of matches %d != %d" % (len(matches), num_matches),
                )
            for i, t in enumerate(matches):
                j, r

# Generated at 2022-06-23 16:04:32.069977
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    pattern = LeafPattern(1)
    pattern = pattern.optimize()
    assert pattern is not None
    assert pattern is not False
    assert pattern is not True
    assert not isinstance(pattern, str)

# Generated at 2022-06-23 16:04:39.919060
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    m = Leaf(type=8, value="123")
    assert repr(m) == "Leaf(NUMBER, '123')"

    m = Leaf(type=8, value=1)
    assert repr(m) == "Leaf(NUMBER, 1)"

    m = Leaf(type=8, value=1.0)
    assert repr(m) == "Leaf(NUMBER, 1.0)"

    m = Leaf(type=8, value=None)
    assert repr(m) == "Leaf(NUMBER, None)"

    m = Leaf(type=8, value=True)
    assert repr(m) == "Leaf(NUMBER, True)"

    m = Leaf(type=8, value=False)
    assert repr(m) == "Leaf(NUMBER, False)"


# Generated at 2022-06-23 16:04:40.696500
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    lp = LeafPattern()



# Generated at 2022-06-23 16:04:48.939075
# Unit test for method clone of class Node
def test_Node_clone():

    from .pytree import Node
    from .pygram import python_symbols

    assert Node(python_symbols.funcdef, []).clone() == Node(
        python_symbols.funcdef, []
    )
    assert Node(python_symbols.funcdef, []).clone() is not Node(python_symbols.funcdef, [])
    assert Node(python_symbols.funcdef, [Node(python_symbols.stmt, [])]).clone() == Node(
        python_symbols.funcdef, [Node(python_symbols.stmt, [])]
    )

# Generated at 2022-06-23 16:04:52.109594
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    ok = []
    try:
        x = LeafPattern(type=1)
    except AssertionError:
        ok.append("type")
    try:
        x = LeafPattern(type=1, content="xyz")
    except AssertionError:
        ok.append("content")
    try:
        x = LeafPattern(type=257)
    except AssertionError:
        ok.append("type-range")
    if ok != ["type", "content", "type-range"]:
        print("LeafPattern(type=...) failed to check arguments:", ok)



# Generated at 2022-06-23 16:04:56.766056
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    print("test_Leaf___repr__")
    l1 = Leaf(1, "123")
    l2 = Leaf(2, "456")
    l3 = Leaf(1, "789")

    assert l1.__repr__() == "Leaf(NUMBER, '123')"
    assert l2.__repr__() == "Leaf(STRING, '456')"

    assert l1.__eq__(l3)
    assert l1.__eq__(l3)

    assert l1.__eq__(l1)
    assert l2.__eq__(l2)
    #Unit test for method __str__ of class Leaf

# Generated at 2022-06-23 16:05:07.944342
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    # the case when the index is of type `int`
    try:
        a = Node(0, [])
        b = Leaf(0, "")
        a.insert_child(0, b)
        assert(True)
    except:
        assert(False)
    # the case when the index is of different type
    try:
        a = Node(0, [])
        b = Leaf(0, "")
        a.insert_child(1.1, b)
        assert(False)
    except:
        assert(True)
    # the case when the index is of different type
    try:
        a = Node(0, [])
        b = Leaf(0, "")
        a.insert_child("a", b)
        assert(False)
    except:
        assert(True)

# Unit

# Generated at 2022-06-23 16:05:11.119085
# Unit test for method depth of class Base
def test_Base_depth():
    x = Base()
    x.parent = None
    assert x.depth() == 0
    b = Base()
    b.parent = x
    assert b.depth() == 1


# Generated at 2022-06-23 16:05:22.341383
# Unit test for method get_suffix of class Base

# Generated at 2022-06-23 16:05:30.895517
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    # Empty pattern
    p = LeafPattern()
    assert p.type is None
    assert p.content is None
    assert p.name is None

    # Pattern with type only
    p = LeafPattern(type=token.INDENT)
    assert p.type == token.INDENT
    assert p.content is None
    assert p.name is None

    # Pattern with type and content
    p = LeafPattern(type=token.INDENT, content='    ')
    assert p.type == token.INDENT
    assert p.content == '    '
    assert p.name is None

    # Pattern with type and name
    p = LeafPattern(type=token.INDENT, name='name')
    assert p.type == token.INDENT
    assert p.content is None
    assert p.name == 'name'

    # Pattern with

# Generated at 2022-06-23 16:05:41.102880
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from . import pygram
    from .pgen2 import token
    from . import parse
    from blib2to3.pytree import type_repr
    from io import StringIO
    import sys
    import unittest
    import pickle
    import copy

    class BaseTest(unittest.TestCase):

        def test_get_suffix(self):
            s = "a = b+c"
            t = parse(s)
            eq = self.assertEqual
            save = sys.stdout
            sys.stdout = StringIO()
            t.pretty_print()
            output = sys.stdout.getvalue()

# Generated at 2022-06-23 16:05:44.408324
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(0) == 0
    assert type_repr(1) == 1
    assert type_repr(100) == 100
    assert type_repr(python_symbols.NAME) == "NAME"
    assert type_repr(python_symbols.NUMBER) == "NUMBER"
    assert type_repr(python_symbols.STRING) == "STRING"



# Generated at 2022-06-23 16:05:53.424921
# Unit test for method remove of class Base
def test_Base_remove():
    from ..pygram import python_symbols as syms

    class Node(Base):
        type = syms.my_node
        was_checked = False

        def _eq(self, other):
            return False

        def clone(self):
            return Node()

        def post_order(self):
            return iter([self])

        def pre_order(self):
            return iter([self])

    parent = Node()
    child = Node()

    def test_remove(child, parent):
        child.parent = parent
        parent.children = [child]
        position = child.remove()
        assert position == 0
        assert child.parent is None
        assert parent.children == []

    test_remove(child, parent)
    child.parent = None
    child.children = []
    test_remove(child, parent)

# Generated at 2022-06-23 16:05:58.631196
# Unit test for constructor of class Base
def test_Base():  # pragma: no cover
    # check boilerplate
    d = Base()
    assert d.type is None
    assert d.children == []
    assert d.parent is None
    assert d.changed() is None
    try:
        d.clone()
        raise AssertionError()
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:06:01.486236
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    leaf = Leaf(255,"hi")
    assert repr(leaf) == "Leaf(255, 'hi')" 

# Generated at 2022-06-23 16:06:03.186754
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    t = Leaf(1, "a")
    assert list(t.post_order()) == [t]

# Generated at 2022-06-23 16:06:10.325036
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    content = "x"
    type = 1
    node = Leaf(type, content)
    assert LeafPattern(content=content, type=type).match(node)
    assert not LeafPattern(content=content).match(node)
    assert LeafPattern(type=type).match(node)


    assert not LeafPattern(type=type, content="").match(node)
    assert not LeafPattern(content="t").match(node)
    assert LeafPattern(type=0, content="").match(Leaf(0, ""))


# Generated at 2022-06-23 16:06:12.587228
# Unit test for constructor of class Base
def test_Base():
    # Don't try to do a full test of the constructor; that's just too
    # much boilerplate.
    pass



# Generated at 2022-06-23 16:06:19.951513
# Unit test for constructor of class Leaf
def test_Leaf():
    # Test the constructor of Leaf
    l = Leaf(0, "")
    assert l.type == 0
    assert l.value == ""
    assert not l.children
    assert not l.fixers_applied
    l = Leaf(0, "", fixers_applied=["a", "b"])
    # Check that we can set the prefix
    l.prefix = "prefix"
    assert l.prefix == "prefix"
    # Check that we can get the line number
    assert l.get_lineno() == 0



# Generated at 2022-06-23 16:06:28.299813
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    class TestPattern(BasePattern):

        def __init__(self, type, content):
            self.type = type
            self.content = content

        def _submatch(self, node, results=None):
            return node.value == self.content

    l = Leaf(3, "xyzzy")
    pattern = TestPattern(3, "xyzzy")
    result = pattern.match(l)
    assert result, result

    assert not pattern.match(Leaf(3, "xyzxy"))
    assert not pattern.match(Leaf(1, "xyzzy"))

    pattern = TestPattern(42, "xyzzy")
    assert pattern.match(l)



# Generated at 2022-06-23 16:06:38.123784
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pygram import python_symbols
    from .pgen2 import token

    NODE = python_symbols.funcdef
    LEAF = token.NAME

# Generated at 2022-06-23 16:06:47.202890
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from pprint import pprint

    def test_match(pattern, s):
        tree = ast.parse(s)
        pprint(tree)
        result = pattern.match(tree)
        s = str(s)
        s = s[0:20] + (s[20:] and '...')
        print(f"{str(pattern):25}{s:20} -> {result}")

    test_match(WildcardPattern(), 'a')
    test_match(WildcardPattern(), 'a b')
    test_match(WildcardPattern(min=2), 'a')
    test_match(WildcardPattern(min=2), 'a b')
    test_match(
        WildcardPattern(content=((LeafPattern(token.NAME),),)), 'a')

# Generated at 2022-06-23 16:06:59.977974
# Unit test for method set_child of class Node
def test_Node_set_child():
    import astor
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import parse_string
    from lib2to3.pgen2.tokenize import generate_tokens
    import sys
    import io
    code = """x = 1"""
    code_object = compile(code, filename="<string>", mode="exec")
    tree = parse_string(code, generate_tokens, start="file_input")
    print(tree)
    tree.children[0].children[2].set_child(0, Leaf(1, "2"))
    print(tree)
    print(astor.to_source(tree))
    sys.stdout = orig_stdout
    sys.stderr = orig_stderr
    test

# Generated at 2022-06-23 16:07:09.160593
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    import unittest

    import astor

    code = "a1 = (a + b)"
    tree = astor.parse_file(StringIO(code))
    a1 = tree.body[0].value
    node = a1.left
    pattern = NegatedPattern(WildcardPattern())
    for c, _ in pattern.generate_matches([node]):
        if c == 0:
            return
    raise unittest.TestCase().fail(
        "NegatedPattern.generate_matches({}) did not generate a match. Expected count 0.".format(
            [node]
        )
    )



# Generated at 2022-06-23 16:07:15.055044
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import unittest

    class TestCase(unittest.TestCase):
        def test_match_seq(self):
            pattern = WildcardPattern(min=2, max=2, content=[["*"]])
            self.assertTrue(pattern.match_seq(["a", "b"]))
            self.assertFalse(pattern.match_seq(["a"]))
            self.assertFalse(pattern.match_seq(["a", "b", "c"]))

    unittest.main(argv=[__file__])



# Generated at 2022-06-23 16:07:17.663537
# Unit test for constructor of class BasePattern
def test_BasePattern():
    bp = BasePattern()
    assert bp.type is None
    assert bp.content is None
    assert bp.name is None



# Generated at 2022-06-23 16:07:26.876194
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    """
    Unit test for method generate_matches of class WildcardPattern.
    Exercises a number of corner cases.
    """

    p1 = WildcardPattern()  # matches any node
    p2 = WildcardPattern((p1,), 0, HUGE, name="p2")
    p3 = WildcardPattern((p1, p2), 0, HUGE, name="p3")

    nodes = (
        Node(257),
        Node(258),
        Node(258),
        Node(259),
        Node(259),
        Node(259),
        Node(260),
    )

    # Test that we get the right number of matches
    for n, rhs in enumerate(p1.generate_matches(nodes)):
        assert n == rhs[0], (n, rhs)

    # Test that

# Generated at 2022-06-23 16:07:35.651827
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # what a user should pass in
    cases = [
        (Node(1, []), Node(1, [])),
        (Node(1, []), Node(2, [])),
        (Leaf(1, "" , None), Leaf(1, "" , None)),
        (Leaf(1, "" , None), Leaf(2, "" , None)),
        (Leaf(1, "1", None), Leaf(1, "" , None)),
    ]
    for a, b in cases:
        assert a == b == a
        assert hash(a) == hash(b) == hash(a)



# Generated at 2022-06-23 16:07:38.705967
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    >>> BasePattern().optimize()
    ... #doctest: +ELLIPSIS
    Traceback (most recent call last):
    ...
    NotImplementedError: ...
    """



# Generated at 2022-06-23 16:07:42.296217
# Unit test for constructor of class Base
def test_Base():
    # Constructor is protected:
    # Base()
    b = Base()
    assert b is not None



# Generated at 2022-06-23 16:07:43.882145
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert LeafPattern().content is None
    assert LeafPattern(NAME, "foo").content == "foo"

# Unit tests for _submatch method of class LeafPattern

# Generated at 2022-06-23 16:07:53.722619
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    import unittest
    import ast

    # The assert statement below would blow up the test,
    # so we decorate it to actually skip the test
    def has_ast_parseerror(f):
        try:
            f()
        except SyntaxError:
            return True
        else:
            return False

    @unittest.skipIf(has_ast_parseerror(lambda: ast.parse("")), "ast.parse fails in this python version")
    def test_identity():
        tree = ast.parse("").body[0]
        res = next(tree.pre_order())
        assert res is tree
    test_identity()


# Generated at 2022-06-23 16:08:01.290815
# Unit test for method leaves of class Base
def test_Base_leaves():
    import unittest
    import StringIO
    import sys

    # These tests are very incomplete
    class TestLeaves(unittest.TestCase):
        def test_normal(self):
            tree = Node(1, [Leaf(1, "x"), Leaf(1, "y")])
            self.assertEqual([l.value for l in tree.leaves()], ["x", "y"])

        def test_subtree(self):
            tree = Node(1, [Node(1, [Leaf(1, "x"), Leaf(1, "y")])])
            self.assertEqual([l.value for l in tree.leaves()], ["x", "y"])

    old_stdout, sys.stdout = sys.stdout, StringIO.StringIO()

# Generated at 2022-06-23 16:08:11.226495
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    import ast

    class Expr(ast.AST):
        pass

    class Bop(Expr):
        _fields = ("l", "op", "r")
        _astname = "Bop"
        _attributes = ("lineno", "col_offset")

    class LeafPattern(BasePattern):
        """Nonterminal"""

        type = Bop
        content = "l"

    class NodePattern(BasePattern):
        """Nonterminal"""

        type = Bop
        content = ("l", LeafPattern())

    class WildcardPattern(BasePattern):
        """Nonterminal"""

        type = Bop
        content = ("l", _Star(LeafPattern()))

    class LeafPattern(BasePattern):
        """Nonterminal"""

        type = Bop
        name = "l"


# Generated at 2022-06-23 16:08:18.218810
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import os.path
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import lib2to3

    filename = os.path.join(os.path.dirname(__file__), "tests/node_tests.py")
    s = open(filename, "rb").read()
    nodes = lib2to3.pgen2.parse(s)
    print(nodes)
    assert len(list(nodes.pre_order())) == 29


# Generated at 2022-06-23 16:08:28.670878
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from . import parse, _tokenize
    from .pgen2 import driver

# Generated at 2022-06-23 16:08:31.253854
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.COMMENT) == "COMMENT"
    assert type_repr(999) == 999



# Generated at 2022-06-23 16:08:32.952834
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    a = Leaf(0, "")
    assert str(a) == "Leaf(0, '')"


# Generated at 2022-06-23 16:08:40.759255
# Unit test for method post_order of class Base
def test_Base_post_order():

    import sys
    import unittest
    import textwrap
    import lib2to3.pytree as pytree
    #from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2.tokenize import generate_tokens, TokenInfo
    from lib2to3.pgen2.parse import ParseError

    class SillyGrammar(object):
        symbols = "a b a_list a_list_star a_list_plus b_list".split()
        # pylint: disable=no-self-argument
        def p_a(self, p):
            """a : A"""
            p[0] = pytree.Leaf(p.type, p.value)
        def p_b(self, p):
            """b : B"""
            p[0]

# Generated at 2022-06-23 16:08:49.591957
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    from .pgen2.token import tok_name

    p = LeafPattern(tok_name["NAME"], "a")
    assert repr(p) == "LeafPattern(NAME, 'a')"
    assert p.type == tok_name["NAME"]
    assert p.content == "a"
    assert p.name is None
    p = LeafPattern(content="a")
    assert repr(p) == "LeafPattern(None, 'a')"
    assert p.type is None
    assert p.content == "a"
    assert p.name is None



# Generated at 2022-06-23 16:09:01.926160
# Unit test for function convert
def test_convert():
    from .pgen2 import driver, grammar
    import unittest
    import token
    from .pgen2.pgen import (
        Grammar,
        Token,
        generic_build_tokens,
        generic_build_grammar,
        generic_parse_input,
    )

    #
    # A simple grammar to test convert
    #

    EBNF_GRAMMAR = """
    START: x | atom | number
    x : 'x'
    atom : 'a'
    number : '1'
    """

    class TestGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: List[str] = []


# Generated at 2022-06-23 16:09:07.991854
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert repr(BasePattern(0)) == "BasePattern(0, None, None)"
    assert repr(BasePattern(1, 2, 3)) == "BasePattern(1, 2, 3)"
    assert repr(BasePattern(1, None, 3)) == "BasePattern(1, 3)"
    assert repr(BasePattern(1, 2)) == "BasePattern(1, 2, None)"



# Generated at 2022-06-23 16:09:12.675035
# Unit test for constructor of class Node
def test_Node():
    class YeahNode(Node):
        def __init__(self, *args, **kwds):
            Node.__init__(self, *args, **kwds)
            self.yeah = True

    n = YeahNode(42, [], prefix="")
    assert n.yeah
    assert n.parent is None



# Generated at 2022-06-23 16:09:19.029245
# Unit test for method clone of class Base
def test_Base_clone():
    """
    >>> n = Leaf(1, "abc")
    >>> n.next_sibling = Leaf(1, "def")
    >>> c = n.clone()
    >>> c.next_sibling
    Leaf(1, 'def')
    >>> n.next_sibling = None
    >>> c.next_sibling
    Leaf(1, 'def')
    >>> c.next_sibling = None
    >>> n.next_sibling
    Leaf(1, 'def')
    >>> n.next_sibling = None
    """



# Generated at 2022-06-23 16:09:22.480455
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    leaf = Leaf(1, "hello")
    assert repr(leaf) == "Leaf(NAME, 'hello')"



# Generated at 2022-06-23 16:09:31.601699
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern(min=2, max=2)
    assert WildcardPattern(min=2, max=2) == WildcardPattern(min=2, max=2)
    assert WildcardPattern(min=2, max=3) != WildcardPattern(min=2, max=2)
    assert WildcardPattern(min=2, max=3) == WildcardPattern(min=2, max=3)
    assert WildcardPattern(min=2, max=5) != WildcardPattern(min=2, max=3)
    assert WildcardPattern(min=2, max=5, name="x") == WildcardPattern(
        min=2, max=5, name="x"
    )

# Generated at 2022-06-23 16:09:40.200988
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from .find_patterns import traverse, ASTPatternBuilder
    import ast

    astp = ASTPatternBuilder()

    ast.parse('f(a, b)')
    match_f = astp.match_f
    match_a = astp.match_a
    match_b = astp.match_b
    match_c = astp.match_c
    match_d = astp.match_d
    match_e = astp.match_e
    match_bare_name = astp.match_bare_name

    match_stmt = astp.match_stmt
    match_expr = astp.match_expr
    match_call = astp.match_call
    match_name = astp.match_name
    match_keyword = astp.match_keyword

    # check empty input
   

# Generated at 2022-06-23 16:09:48.901859
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    test_str = '''def foo(bar):
        pass'''
    grammar = Grammar(r"../grammar.txt")
    tree = grammar.parse(test_str)
    result = [type_repr(x.type) for x in tree.pre_order()]
    assert result == [
        "file_input",
        "funcdef",
        "NAME",
        "parameters",
        "typedargslist",
        "tfpdef",
        "NAME",
        "suite",
        "simple_stmt",
        "small_stmt",
        "pass_stmt",
        "pass",
        "NEWLINE",
    ]


# Generated at 2022-06-23 16:09:57.754712
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern()
    assert WildcardPattern("a b c", 0, 1)
    assert WildcardPattern("d e f", 0, 1)
    assert WildcardPattern([["a b c"], ["d e f"]], 0, 1)
    assert WildcardPattern("a b c", 0, 2)
    assert WildcardPattern("d e f", 0, 2)
    assert WildcardPattern([["a b c"], ["d e f"]], 0, 2)
    assert WildcardPattern("a b c", 1, 2)
    assert WildcardPattern("d e f", 1, 2)
    assert WildcardPattern([["a b c"], ["d e f"]], 1, 2)
    assert WildcardPattern("a b c", 1, HUGE)
    assert WildcardPattern("d e f", 1, HUGE)

# Generated at 2022-06-23 16:10:01.308086
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    root = Leaf(1, 1, None)
    Leaf(2, 2, None)
    Leaf(3, 3, None)
    assert root.children[0].next_sibling  # None is false
    root.invalidate_sibling_maps()
    with pytest.raises(AttributeError):
        root.children[0].next_sibling



# Generated at 2022-06-23 16:10:06.088752
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    n = Node(1, [])
    assert not n.children
    n.insert_child(0, Node(1, []))
    assert len(n.children) == 1
test_Node_insert_child()

# Generated at 2022-06-23 16:10:11.049974
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.NAME) == "NAME"


# Types of node
#
#   == type(node)
#
# == NodeType
#
#   == NodeType(node)

NodeType = type_repr  # mapping from node to a name used in __repr__



# Generated at 2022-06-23 16:10:11.920325
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    pass


# Generated at 2022-06-23 16:10:19.195923
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2.token import tok_name
    from .pgen2.grammar import Grammar
    p = LeafPattern(tok_name["NAME"], "foo")
    g = Grammar()
    parser = g.parser("", convert=convert)
    node = parser.parse("foo")
    assert p.match_seq([node])
    assert maybe_search(p, node)
    node = parser.parse("foo bar")
    assert not p.match_seq([node])
    assert maybe_search(p, node) is None
    node = parser.parse("bar foo")
    assert not p.match_seq([node])
    assert maybe_search(p, node) is None
    node = parser.parse("")
    assert not p.match_seq([node])

# Generated at 2022-06-23 16:10:29.047778
# Unit test for function generate_matches
def test_generate_matches():
    from ..pgen2 import token

    pat = [
        NodePattern(token.NAME, [NodePattern(token.NAME)], "var"),
        NodePattern(token.NAME),
        NodePattern(token.NAME),
        NodePattern(token.NAME),
        NodePattern(token.NAME),
        NodePattern(token.NAME),
    ]

    tree = [
        [token.NAME, "a"],
        [token.NAME, "b"],
        [token.NAME, "c"],
        [token.NAME, "d"],
        [token.NAME, "e"],
        [token.NAME, "f"],
        [token.NAME, "g"],
        [token.NAME, "h"],
    ]

    def check(count, results):
        assert results["var"] == [tree[0], tree[1]]

# Generated at 2022-06-23 16:10:36.542681
# Unit test for constructor of class BasePattern

# Generated at 2022-06-23 16:10:38.772519
# Unit test for method post_order of class Node
def test_Node_post_order():
    a = Node(python_symbols.test, [])
    a.post_order()


# Generated at 2022-06-23 16:10:50.853948
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    def check_node_attrs(node, prefix="", type=0, children=()):
        """Checks attributes of a parse tree node"""
        assert node.prefix == prefix
        assert node.type == type
        assert node.children == list(children)

    import re

    def check_node_siblings(node, prev_sibling=None, next_sibling=None):
        """Checks the sibling attributes of a parse tree node."""
        assert node.prev_sibling is prev_sibling
        assert node.next_sibling is next_sibling

    # Setup
    node1 = Leaf(0, "")
    node2 = Leaf(0, "")
    nodes = [node1, node2]
    parent = Node(0, nodes)

    # Test 1
    # Inserting at the end (append)
   

# Generated at 2022-06-23 16:11:00.116838
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from . import nltk_lite as nltk
    from .nodes import Tree
    from nltk.tree import Tree as ntk_Tree

    # Create a new parser for the tree
    grammar = nltk.parse_cfg("S -> A B C", trace=0)

    # Create a new tree
    t = Tree.fromstring("(S (A (B foo) (C bar)) (A (B foo) (C baz)))")

    # Create a new pattern and assign it the tree
    # p = Pattern.fromstring("(A (B /foo/) (C /bar/))")
    a = NodePattern(type=256, content=[WildcardPattern(name="C")])
    b = NodePattern(type=257, content=[WildcardPattern(name="B")])

# Generated at 2022-06-23 16:11:01.991323
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(0,0)
    assert list(l.post_order()) == [l]

# Generated at 2022-06-23 16:11:06.319118
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """
    # Tests for method __repr__ of class Node
    """
    assert Node(4, []).__repr__() == "Node(4, [])"



# Generated at 2022-06-23 16:11:12.817942
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf

    pos = (1, 2)
    base = Leaf(1, "fname", pos)
    assert isinstance(base, Base)
    assert base.clone() is not base
    assert base.clone().type == 1
    assert base.clone().value == "fname"
    assert base.clone().context == pos
    assert isinstance(base.clone(), Leaf)

# Generated at 2022-06-23 16:11:20.903707
# Unit test for method leaves of class Base
def test_Base_leaves():
    # node.leaves must return an iterator
    def assert_iterable(node):
        i = node.leaves()
        assert iter(i) is i
        # iterating over i twice should work as expected
        assert list(i) == list(i)

    assert_iterable(Module([]))
    assert_iterable(Node(syms.simple_stmt, []))
    assert_iterable(Node(syms.expr_stmt, []))
    assert_iterable(Leaf(1, "0"))

    source = dedent("""\
        def f():
            pass
        """)

    tree = parse(source)
    assert_iterable(tree)
    functions = list(tree.leaves())
    assert len(functions) == 1
    assert functions[0].value == "f"




# Generated at 2022-06-23 16:11:24.646743
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    a = Leaf(1, "a")
    assert list(a.pre_order()) == [a]

a = Leaf(1, "a")

assert list(a.pre_order()) == [a]

# Generated at 2022-06-23 16:11:33.148763
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    p0 = NodePattern(type="LPAR")
    p1 = NodePattern(type="RPAR")
    p2 = NodePattern(type="RPAR")
    p3 = WildcardPattern(content=[[p0], [p1]])
    p = NegatedPattern(content=p3)
    # Check empty sequence
    res = list(p.generate_matches([]))
    assert res == [(0, {})], res
    # Check no matches
    res = list(p.generate_matches([p0, p1, p1]))
    assert res == [(0, {})], res
    # Check single match
    res = list(p.generate_matches([p0, p1, p1, p0, p1, p1]))
    assert res == [], res
    # Check multiple

# Generated at 2022-06-23 16:11:45.901863
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node, Leaf
    from .pgen2 import token

    class TestBase(Base):
        def __init__(self):
            self.children = []
            self.next_sibling_map = None
            self.prev_sibling_map = None
        def changed(self):
            pass
        def invalidate_sibling_maps(self):
            pass
        def post_order(self):
            yield self
        def _eq(self, other):
            return self == other

    Base.register(TestBase)

    n = Node(syms.dotted_name, [Leaf(token.NAME, 'a'), Leaf(token.DOT, '.'), Leaf(token.NAME, 'b')])
    s = 'a'
    n.post_order()
    # assert_equal(n.

# Generated at 2022-06-23 16:11:50.343309
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    leaf = Leaf(tok_name.COMMA, ",")
    assert repr(leaf) == "Leaf(COMMA, ',')"
# test for method __str__ of class Leaf

# Generated at 2022-06-23 16:11:55.448452
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern([[NodePattern(type=NAME),
                          LeafPattern(type=OP, content="=")]],
                        min=1, max=1)
    assert len(list(p.generate_matches([Leaf(NAME, "x"),
                                        Leaf(OP, "=")]))) == 1
