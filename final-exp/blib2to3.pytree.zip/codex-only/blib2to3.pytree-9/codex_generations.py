

# Generated at 2022-06-23 16:02:00.938322
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from ...patcomp import compile_pattern as compile
    from ...pgen2 import token

    pat = compile(r"x")

    leaf = Leaf(token.NAME, "x", (1, 0))
    res = leaf.get_lineno()
    assert res == leaf.lineno

    leaf = Leaf(token.NAME, "x", None)
    res = leaf.get_lineno()
    assert res is None

    leaf = Leaf(token.NAME, "x", None, parent=pat.root)
    res = leaf.get_lineno()
    assert res is None

    leaf = Leaf(token.NAME, "x", None, parent=pat.root)
    res = leaf.get_lineno()
    assert res is None

    leaf = Leaf(token.NAME, "x", None, parent=pat.root)
   

# Generated at 2022-06-23 16:02:07.940971
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf
    x = Leaf(42, "test")
    assert not x.was_changed
    x.changed()
    assert x.was_changed
    assert not x.parent
    n = Node(1, [x])
    assert not n.was_changed
    n.changed()
    assert n.was_changed
    x.changed()
    assert n.was_changed
    n.was_changed = False
    x.parent = None
    x.changed()
    assert not n.was_changed

# Generated at 2022-06-23 16:02:15.949458
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Node
    from .pygram import python_symbols as syms

    # Test pre-order iteration
    tree = Node(syms.argument, [Leaf(token.NAME, "spam"), Leaf(token.NAME, "eggs")])
    path = [type_repr(x.type) for x in tree.pre_order()]
    assert path == ["argument", "NAME", "NAME"], path

    tree = Node(syms.power, [Leaf(token.NAME, "x"), Leaf(token.NAME, "y")])
    path = [type_repr(x.type) for x in tree.pre_order()]
    assert path == ["power", "NAME", "NAME"], path

    tree = Node(syms.atom, [Leaf(token.NAME, "x")])
   

# Generated at 2022-06-23 16:02:21.428243
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern()
    assert list(pattern.generate_matches([symbol.reserved])) == []
    assert list(pattern.generate_matches([])) == [(0, {})]
    pattern = NegatedPattern(NodePattern(type=symbol.reserved))
    assert list(pattern.generate_matches([symbol.reserved])) == []
    assert list(pattern.generate_matches([symbol.Name])) == [(0, {})]


if __name__ == "__main__":
    import sys

    def p(nodes, pattern, name=None):
        if name:
            print(name, ":", end=" ")
        else:
            print("Pattern :", pattern)
        print("Match" if pattern.match(nodes[0]) else "No match")


# Generated at 2022-06-23 16:02:28.877229
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    class P1(BasePattern):
        type = 1
    class P2(BasePattern):
        type = 2
    class P3(BasePattern):
        type = 3
    class P4(P2):
        pass
    class P5(P4):
        type = 4
    nodes = [1, 2, 3]

    pattern = P1()
    assert list(pattern.generate_matches(nodes)) == [(1, {})]

    pattern = P2()
    assert list(pattern.generate_matches(nodes)) == [(1, {})]

    pattern = P3()
    assert list(pattern.generate_matches(nodes)) == [(1, {})]

    pattern = P4()
    assert list(pattern.generate_matches(nodes)) == [(1, {})]

    pattern = P

# Generated at 2022-06-23 16:02:30.754820
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l1 = Leaf(1, "l1")
    assert [l1] == list(l1.post_order())


# Generated at 2022-06-23 16:02:41.230341
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    assert Leaf(1, "abc").__repr__() == "Leaf(1, 'abc')"
    assert Leaf(2, "").__repr__() == "Leaf(2, '')"
    assert Leaf(256, "abc").__repr__() == "Leaf(256, 'abc')"
    assert Leaf(257, "").__repr__() == "Leaf(257, '')"
    from .pgen2.token import tok_name
    assert Leaf(257, "").__repr__() == "Leaf(257, '')"
    assert Leaf(258, "abc").__repr__() == "Leaf(258, 'abc')"

# Generated at 2022-06-23 16:02:42.438027
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    b = BasePattern()
    assert b.optimize() is b

# Generated at 2022-06-23 16:02:47.171987
# Unit test for method depth of class Base
def test_Base_depth():
    from . import pytree

    v = pytree.FlatList(pytree.Leaf(0, u"A"))
    assert v.depth() == 0
    v = pytree.Node(0, v)
    assert v.depth() == 1



# Generated at 2022-06-23 16:02:55.402197
# Unit test for method __str__ of class Node
def test_Node___str__():
    from .pgen2.tokenize import generate_tokens, untokenize
    from . import pygram, pytree
    from .pgen2 import token
    from io import BytesIO
    s = b'''def a(b):
    # comment
    return #comment
    '''
    result = untokenize(list(generate_tokens(BytesIO(s).readline)))
    n = pygram.python_symbols.file_input
    t = pytree.convert_tokens_to_tree(list(generate_tokens(BytesIO(s).readline)), n)
    assert list(t.post_order())[0].prefix == result


# Generated at 2022-06-23 16:03:03.062205
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node, type_repr as _type_repr
    l1=Leaf(1, '')
    l2=Leaf(1, '')
    n1=Node(2, [l1, l2])
    l3=Leaf(1, '')
    n2=Node(2, [n1, l3])
    assert n1.get_suffix()==''
    assert l3.get_suffix()==''
    assert l2.get_suffix()==l3.prefix


# Generated at 2022-06-23 16:03:10.660269
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    leaf = Leaf(1, 'value', ('prefix', (0, 0)), ['fixer'])
    leaf.used_names = set()
    leaf.bracket_depth = 1
    leaf.opening_bracket = leaf
    leaf2 = leaf.clone()
    assert leaf2.type == 1
    assert leaf2.value == 'value'
    assert leaf2.prefix == 'prefix'
    assert leaf2.lineno == 0
    assert leaf2.column == 0
    assert leaf2.fixers_applied == ['fixer']
    assert leaf2.children == []
    assert leaf2.parent is None
    assert leaf2.used_names == set()
    assert leaf2.bracket_depth == 1
    assert leaf2.opening_bracket == leaf2


# Generated at 2022-06-23 16:03:21.055425
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    #if sys is not None:
    #    sys.setrecursionlimit(20)
    pattern_bare_name = WildcardPattern(
        (
            (
                LeafPattern(type=NAME),
                WildcardPattern(
                    (
                        (
                            LeafPattern(type=NAME),
                            LeafPattern(type=NAME, content="."),
                            LeafPattern(type=NAME),
                        ),
                    ),
                    name="bare_name",
                ),
            ),
        ),
        name="bare_name",
    )
    pattern_bare_name = pattern_bare_name.optimize()
    assert isinstance(pattern_bare_name.content[0][0], LeafPattern)
    assert isinstance(pattern_bare_name.content[0][1], WildcardPattern)

# Generated at 2022-06-23 16:03:26.058714
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import ast

    t1 = ast.parse("a = 2")
    t2 = ast.parse("a = 2", type_comments=True)
    t3 = ast.parse("a = 2", type_comments=True, feature_version=(3, 9))

    def check_match(node, p, expected) -> None:
        m = p.match(node)
        assert m == expected, repr(p) + " with " + repr(node)

    def check(p, values) -> None:
        for v in values:
            check_match(v, p, True)
        for v in values:
            for i in range(len(ast.walk(v))):
                n = ast.parse(ast.dump(v))
                m = list(ast.walk(n))[i]

# Generated at 2022-06-23 16:03:32.445573
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    import sys
    print(Leaf(3, '3'))
    print(Leaf(tok_name['COMMA'], '3'))
    if sys.version_info[0] == 2 and sys.version_info[1] < 5:
        print(Leaf(None, '3'))
        print(Leaf(None, None))

# Generated at 2022-06-23 16:03:38.392413
# Unit test for function generate_matches
def test_generate_matches():
    import pytest
    from .basic import Leaf, Node

    a = Leaf("a")
    b = Leaf("b")
    c = Leaf("c")
    d = Leaf("d")
    e = Leaf("e")
    ab = Node("ab", [a, b])
    abc = Node("abc", [a, b, c])
    abcde = Node("abcde", [a, b, c, d, e])
    abcab = Node("abcab", [a, b, c, a, b])
    abcabc = Node("abcabc", [a, b, c, a, b, c])
    abcabde = Node("abcabde", [a, b, c, a, b, d, e])

# Generated at 2022-06-23 16:03:49.351052
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    import random
    from blib2to3.pygram import python_symbols
    s = "test"
    node = Node(python_symbols.dotted_name, [Leaf(token.NAME, s[0])])
    for c in s[1:]:
        node.append_child(Leaf(token.NAME, c))
    while s:
        idx = random.randint(0, len(s))
        if idx != 0 and idx != len(s):
            d = random.choice([True, False])
            node.insert_child(idx, Leaf(token.DOT, "."))
            if d:
                s = s[:idx] + "." + s[idx:]
            else:
                s = s[:idx] + s[idx+1:]

# Generated at 2022-06-23 16:03:54.690657
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(None, [])
    node.invalidate_sibling_maps()
    assert issubclass(node.prev_sibling_map.__class__, dict),  \
        node.prev_sibling_map.__class__
    assert issubclass(node.next_sibling_map.__class__, dict),  \
        node.next_sibling_map.__class__

# Generated at 2022-06-23 16:04:05.374569
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Test with nodes = []
    empty_pattern = Pattern()
    not_empty_pattern = Pattern(NAME)
    neg_pattern = NegatedPattern(empty_pattern)
    assert not neg_pattern.match_seq([], {})
    neg_pattern = NegatedPattern(not_empty_pattern)
    assert neg_pattern.match_seq([], {})
    neg_pattern = NegatedPattern()
    assert neg_pattern.match_seq([], {})
    # Test with nodes
    neg_pattern = NegatedPattern(empty_pattern)
    assert not neg_pattern.match_seq([NAME], {})
    neg_pattern = NegatedPattern(not_empty_pattern)
    assert neg_pattern.match_seq([NAME], {})
    neg_pattern = NegatedPattern()

# Generated at 2022-06-23 16:04:15.334593
# Unit test for method replace of class Base
def test_Base_replace():
    from blib2to3.pgen2 import driver

    gr = driver.load_grammar(StringIO(grammar_str), 'x.txt')
    root = gr.parse("a = b")
    root.replace(root.children[1])
    assert root.children[0].type == python_symbols.term



# Generated at 2022-06-23 16:04:20.740470
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.power) == "power"
    assert isinstance(type_repr(9999), int)
    assert type_repr(9999) == 9999


# Convenience functions to convert a sequence of symbols to strings

# Generated at 2022-06-23 16:04:29.554822
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    a = NodePattern(type=token.NAME, content=[LeafPattern(value='a')])
    b = NodePattern(type=token.NAME, content=[LeafPattern(value='b')])

    ab = ConcatenatedPattern(a, b)
    ba = ConcatenatedPattern(b, a)

    # The following two are the same regexp pattern:
    #     (a b)$|(b a)$
    # (here dollar sign stands for the end of the string)
    p1 = ConcatenatedPattern(ab, NegatedPattern())
    p2 = ConcatenatedPattern(ba, NegatedPattern())
    p = AlternativesPattern(p1, p2)

    return p

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-23 16:04:38.709059
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    import pytest

    # The pattern must be initialized with a token type
    with pytest.raises(AssertionError):
        LeafPattern(0, "NUMBER")
    assert LeafPattern(token.NUMBER, "NUMBER")
    # The pattern may not be initialized with a symbol type
    with pytest.raises(AssertionError):
        LeafPattern(syms.testlist, "testlist")
    # The pattern must be initialized with a string for content
    with pytest.raises(AssertionError):
        LeafPattern(token.NUMBER, 42)
    assert LeafPattern(token.NUMBER, "42")
    # The pattern's name must be a string
    with pytest.raises(AssertionError):
        LeafPattern(token.NUMBER, "NUMBER", 42)

# Generated at 2022-06-23 16:04:40.943935
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Method __repr__ returns a readable string representation"""
    obj = BasePattern(22)
    assert obj.__repr__() == "BasePattern(22)"

# Generated at 2022-06-23 16:04:44.656299
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    lp = LeafPattern(100, "spam")
    assert lp.match(Leaf(100, "spam"))
    assert not lp.match(Leaf(100, "eggs"))
    assert not lp.match(Leaf(101, "spam"))
    assert not lp.match(Leaf(101, "eggs"))
    assert not lp.match(Node(100, [Leaf(100, "spam")]))
    assert not lp.match(Node(100, [Leaf(101, "spam")]))



# Generated at 2022-06-23 16:04:56.147439
# Unit test for method remove of class Base
def test_Base_remove():

    from lib2to3 import fixer_base

    class DummyFixer(fixer_base.BaseFix):
        pass

    d = DummyFixer()

    class DummyNode(Base):
        def _eq(self, other):
            return 1

        def clone(self):
            return 2

        def post_order(self):
            return 3

        def pre_order(self):
            return 4

    def _check(n):
        nonlocal d
        nonlocal vals

        vals = []
        d.node = n

        print(d.node.remove())
        assert d.node.remove() == None

    class Node(DummyNode):

        def __init__(self, children):
            self.children = children
            self.parent = None


# Generated at 2022-06-23 16:05:00.832144
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class Dummy(BasePattern):
        def optimize(self) -> BasePattern:
            return LeafPattern(1)
    x = Dummy()
    assert x.optimize() is not x


# Subclass for patterns matching a single leaf.

# Generated at 2022-06-23 16:05:01.596838
# Unit test for method remove of class Base
def test_Base_remove():
    assert False


# Generated at 2022-06-23 16:05:09.832549
# Unit test for method leaves of class Base
def test_Base_leaves():
    """Test case for method leaves of Base."""
    from .pytree import Node, Leaf

    tree = Node(1, [Leaf(1, "hello "), Leaf(1, "world")])
    assert list(tree.leaves()) == [Leaf(1, "hello "), Leaf(1, "world")]

    tree = Node(1, [
        Leaf(1, "hello "),
        Node(2, [Node(3, [Leaf(4, "nested")])]),
        Leaf(5, "world"),
    ])
    assert list(tree.leaves()) == [Leaf(1, "hello "), Leaf(4, "nested"), Leaf(5, "world")]



# Generated at 2022-06-23 16:05:21.744094
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def T(n):
        "Convenience function for a node pattern of token type n"
        return NodePattern(n)
    def L(s):
        "Convenience function for a leaf pattern with the given value"
        return LeafPattern(content=s)
    def W(*args, **kwargs):
        """Convenience function for a wildcard pattern;
        all args besides max are passed to the initializer as content,
        if it's not None; the max argument, if present, is passed to
        the initializer too.
        """
        if len(args) == 1 and isinstance(args[0], tuple):
            # For backwards compatibility
            args = args[0]
        kwargs["content"] = args
        if "max" not in kwargs:
            kwargs["max"] = HUGE
        return Wild

# Generated at 2022-06-23 16:05:24.678091
# Unit test for method __new__ of class Base
def test_Base___new__():
    name = 'Base.__new__'
    assert globals().get(name) == getattr(Base, name), 'Cannot find %s. Did you rename it?' % name
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    # Do not allow instantiation of the Base class
    with unittest.TestCase():
        pass

# Generated at 2022-06-23 16:05:33.225895
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import pytest
    class B(BasePattern):
        def _submatch(self, node, results):
            return True
    p = B(token.NAME)
    class A(Leaf):
        pass
    a = A(token.NAME, "foo")
    assert not p.match(a, results={})
    assert not p.match(None)
    assert p.match(Leaf(token.NAME, "foo"))
    assert not p.match(Leaf(token.NAME, "bar"))
    assert not p.match(Node(syms.x, []))

# Generated at 2022-06-23 16:05:38.141604
# Unit test for method post_order of class Base
def test_Base_post_order():
    grammar = Grammar.from_file(
        '/private/var/folders/9t/wk8yhkwn0f7dww1dpkbdg8xm0000gn/T/tmpb0zrb_er/grammar.txt')
    node = grammar.number('3')
    node.post_order()

# Generated at 2022-06-23 16:05:43.786258
# Unit test for method post_order of class Node
def test_Node_post_order():
    tree = Leaf(0)
    assert list(tree.post_order()) == [tree]
try:
    import unittest2 as unittest
except ImportError:
    import unittest
if __name__ == '__main__':
    unittest.main()
# End unit test for method post_order of class Node

# Generated at 2022-06-23 16:05:45.845885
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.and_expr) == "and_expr"



# Generated at 2022-06-23 16:05:54.663298
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.parse import ParseError

    try:
        from .pgen2 import token

        from .pgen2 import driver
    except ImportError:
        return

    with open(token.__file__, "rb") as f:
        try:
            g = driver.load_grammar(f)
        except ParseError:
            return
    pat = LeafPattern(type=token.NUMBER, name="num")
    assert pat.match(g.number2symbol[57], {"num": g.number2symbol[56]}) is True
    assert pat.match(g.number2symbol[56], {"num": g.number2symbol[56]}) is False



# Generated at 2022-06-23 16:06:05.707826
# Unit test for method __new__ of class Base
def test_Base___new__():
    import sys
    import __future__
    from .pytree import Leaf, Node
    from .python_grammar import python_grammar, python_grammar_no_print_statement
    # Test for existence of trivial method.
    assert Base.__new__
    # Test for existence of method that uses template pattern.
    assert Base.changed
    # Test subclass.
    assert issubclass(Node, Base)
    # Test instantiation.
    if sys.version_info[:2] in ((2, 6), (2, 7)):
        gr = python_grammar_no_print_statement
    else:
        gr = python_grammar
    tree = gr.parses("x")
    assert isinstance(tree, Node)
    # Test equality implementation.
    b = tree.children[0]
    assert b is b

# Generated at 2022-06-23 16:06:09.353430
# Unit test for method append_child of class Node
def test_Node_append_child():
    a = Node(1, children=[])
    b = Leaf(1, 'test')
    a.append_child(b)
    assert a.children[0] is b


# Generated at 2022-06-23 16:06:10.581197
# Unit test for constructor of class BasePattern
def test_BasePattern():
    BasePattern()



# Generated at 2022-06-23 16:06:19.198463
# Unit test for method depth of class Base
def test_Base_depth():
    a = Node(1, None, None)
    b = Node(1, None, None)
    c = Node(1, None, None)
    d = Node(1, None, None)
    e = Node(1, None, None)
    a.append_child(b)
    b.append_child(c)
    c.append_child(d)
    d.append_child(e)
    assert a.depth() == 0
    assert b.depth() == 1
    assert c.depth() == 2
    assert d.depth() == 3
    assert e.depth() == 4
    assert e.depth() == 4



# Generated at 2022-06-23 16:06:28.533504
# Unit test for method post_order of class Node
def test_Node_post_order():
    import random
    from . import pytree


# Generated at 2022-06-23 16:06:31.705939
# Unit test for method depth of class Base
def test_Base_depth():
    assert 1 == Node(0, None, None, [Node(1, None, None, [Leaf(1, ""),Node(2, None, None, [Leaf(2, "")]),Leaf(3, "")])]).depth()


# Generated at 2022-06-23 16:06:37.382644
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    ws = "    "
    t = Leaf(1, "def", None, prefix=ws)
    assert t.clone() == t
    #
    # Check that a clone changes if the original changes
    #
    t.value = "newdef"
    assert t.clone().value == "newdef"
    t.prefix = " "
    assert t.clone().prefix == " "



# Generated at 2022-06-23 16:06:46.594489
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    def test(pat, seq):
        counts = []
        for c, r in pat.generate_matches(seq):
            counts.append(c)
            print("c, r =", c, repr(r))
        return counts
    assert test(WildcardPattern([["1"], ["2"]]), []) == [0]
    assert test(WildcardPattern([["1"], ["2"]]), ["1"]) == [1]
    assert test(WildcardPattern([["1"], ["2"]]), ["2"]) == [1]
    assert test(WildcardPattern([["1"], ["2"]]), ["1", "2"]) == [2]
    assert test(WildcardPattern([["1"], ["2"]]), ["2", "1"]) == [2]

# Generated at 2022-06-23 16:06:50.965744
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    a = Leaf(0, 'foo')

    assert str(a)=='foo'
    assert repr(a)=="Leaf(0, 'foo')"

# Generated at 2022-06-23 16:07:01.633888
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Only the default implementation is tested so far.
    # If a subclass overrides method match_seq, this test will
    # not cover it.
    # Create a node of a somewhat more complex type
    class Node(object):
        def __init__(self, type, value, children):
            self.type = type
            self.value = value
            self.children = children
        def __repr__(self):
            return 'Node(%r, %r, %r)' % (self.type, self.value, self.children)

    # Create a pattern to be used in the tests
    class Pattern(BasePattern):
        def __init__(self, type=None, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name

    # Leaf patterns

# Generated at 2022-06-23 16:07:04.110605
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Unit test for method __repr__ of class BasePattern
    """
    BasePattern()



# Generated at 2022-06-23 16:07:10.547220
# Unit test for method leaves of class Base
def test_Base_leaves():
    n = Node(1, children=[Node(2, children=[Leaf(1, "a"), Leaf(1, "b")]), Leaf(1, "c")])
    assert list(n.leaves()) == [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]
    assert list(n[0].leaves()) == [Leaf(1, "a"), Leaf(1, "b")]
    assert list(n[0][0].leaves()) == [Leaf(1, "a")]



# Generated at 2022-06-23 16:07:18.315000
# Unit test for method append_child of class Node
def test_Node_append_child():
    import copy
    import tempfile
    from lib2to3.pgen2 import token
    from lib2to3.pgen2 import driver

    tree = driver.parse_string("if True:\n    pass\n")
    assert tree.type == token.FILE_INPUT
    assert tree.children[0].type == token.IF_STMT
    assert tree.children[0].children[0].type == token.NAME
    new_child = copy.deepcopy(tree.children[0].children[0])
    assert new_child.type == token.NAME
    assert new_child.prefix == " "
    new_child.prefix = "foo"
    new_child.value = "elif"
    assert new_child.prefix == "foo"
    assert new_child.value == "elif"
    assert new_child

# Generated at 2022-06-23 16:07:21.762293
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, "foo")
    assert leaf.type == 1
    assert leaf.value == "foo"
    assert leaf._prefix == ""
    assert leaf.lineno == 0
    assert leaf.column == 0
    assert leaf.children == []



# Generated at 2022-06-23 16:07:25.897984
# Unit test for method replace of class Base
def test_Base_replace():
    # Constructor test
    Base()
    # Method tests
    Base.replace(None, None)
    Base.get_lineno(None)
    Base.remove(None)
    Base.leaves(None)
    Base.depth(None)
    Base.get_suffix(None)



# Generated at 2022-06-23 16:07:29.595703
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(256, [])
    assert repr(node) == "Node(test_Node, [])"

# Generated at 2022-06-23 16:07:34.865464
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    myclass = LeafPattern()
    assert myclass.match(Leaf(1, 'test'))
    assert not myclass.match(Node(1, [Leaf(1, 'test')]))
    assert myclass.match(Leaf(1, 'test2', ('', (1,1))), {'test2':Leaf(1, 'test2', ('', (1,1)))})



# Generated at 2022-06-23 16:07:42.416611
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from . import pytree
    from .pgen2 import parse

    pygram = parse.load_grammar("Grammar/Grammar", 'exec', optimize=False)
    pytree.token_rules = pygram.token2symbol
    pattern = Pattern('X')
    assert pattern.optimize() is pattern
    pattern = Pattern('X').discard()
    assert pattern.optimize() is pattern
    pattern = Pattern('X', 'x')
    pattern2 = pattern.optimize()
    assert pattern2 is not pattern
    assert pattern2.type == pattern.type
    assert pattern2.content == 'x'
    assert pattern2.name is None
    pattern = Pattern('X', 'x', 'y')
    pattern2 = pattern.optimize()
    assert pattern2 is not pattern

# Generated at 2022-06-23 16:07:48.186721
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # A Node subclass should be used as the argument in constructors.
    node = Node(0, None, children=[Leaf(1, 'f'), Node(2, None, children=[Leaf(3, 'o'), Node(4, None, children=[Leaf(5, 'o')])])])
    assert node.get_suffix() == 'o'

# Generated at 2022-06-23 16:07:51.608427
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from .nodes import List, Symbol

    nodes = [List((Symbol("a"), Symbol("b"))), Symbol("b")]
    pattern = NodePattern(content=[SubPattern(min=1, content=[LeafPattern(content="a")])])
    assert pattern.match_seq(nodes)


# Generated at 2022-06-23 16:07:53.638091
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    # Arrange
    # Act
    with pytest.raises(NotImplementedError):
        Base().pre_order()

# Generated at 2022-06-23 16:07:56.541319
# Unit test for method replace of class Base
def test_Base_replace():
    # Base class, should not be able to instantiate.
    try:
        Base()
        assert 0, "Should not be able to instantiate Base."
    except AssertionError:
        assert 1, "Should not be able to instantiate Base."



# Generated at 2022-06-23 16:08:03.490228
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def assert_matches(
        pattern: WildcardPattern, sequence: List[NL], expected: List[Tuple[int, _Results]]
    ) -> None:
        assert list(pattern.generate_matches(sequence)) == expected

    # (a b c | d e | f g h)*
    a_b_c = NodePattern("a", [NodePattern("b"), NodePattern("c")])
    d_e = NodePattern("d", [NodePattern("e")])
    f_g_h = NodePattern("f", [NodePattern("g"), NodePattern("h")])
    pattern = WildcardPattern([[a_b_c], [d_e], [f_g_h]])
    assert_matches(pattern, [], [(0, {})])

# Generated at 2022-06-23 16:08:07.047495
# Unit test for method post_order of class Base
def test_Base_post_order():
    n = Leaf(1, "spam")
    m = Leaf(2, "eggs")
    k = Node(3, [n, m])
    assert list(k.post_order()) == [n, m, k]



# Generated at 2022-06-23 16:08:10.003598
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    node = Node(1, [], None)
    n = Node(2, [], None)
    node.insert_child(0, n)
    assert node.children[0] == n

# Generated at 2022-06-23 16:08:20.274618
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name
    from .pgen2 import token
    from .symbol import symbol_lookup
    p = BasePattern()
    assert not p.match(Leaf(0, ""))
    assert not p.match(Leaf(0, "x"))
    assert not p.match(Node(0, []))
    assert not p.match(Node(0, [Leaf(0, "")]))
    assert not p.match(Node(0, [Leaf(0, "x")]))
    p = BasePattern(type=token.NAME)
    assert not p.match(Leaf(0, ""))
    assert p.match(Leaf(token.NAME, ""))
    assert not p.match(Leaf(token.NAME, "x"))
    assert not p.match

# Generated at 2022-06-23 16:08:28.313837
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    _test_case_name = 'test_Node_insert_child'
    _test_node = Node(0,[])
    _test_child1 = Leaf(0,0,0)
    _test_child2 = Leaf(0,0,0)
    _test_child3 = Leaf(0,0,0)
    _test_child4 = Leaf(0,0,0)
    _test_child5 = Leaf(0,0,0)
    _test_child6 = Leaf(0,0,0)
    _test_child7 = Leaf(0,0,0)
    _test_child8 = Leaf(0,0,0)
    _test_child9 = Leaf(0,0,0)
    _test_node.append_child(_test_child1)
    _test_node.append_child

# Generated at 2022-06-23 16:08:32.453566
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    class B: pass
    node = B()
    node.type = 0
    node.value = "A"
    node.children = []
    P = NegatedPattern()
    assert P.match(node) == False


# Generated at 2022-06-23 16:08:37.739869
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert LeafPattern().type is None
    assert LeafPattern().content is None
    assert LeafPattern().name is None
    n = LeafPattern(1, "abc")
    assert n.type == 1
    assert n.content == "abc"
    assert n.name is None
    n = LeafPattern(type=2, content="def", name="name")
    assert n.type == 2
    assert n.content == "def"
    assert n.name == "name"



# Generated at 2022-06-23 16:08:50.810965
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    class Mock(Node):
        def __init__(self, type: int, children: List[NL], context = None, prefix = None, fixers_applied = None) -> None:
            self.parent: Optional["Node"] = parent
            self.type: int = type
            self.children: List[NL] = children
            self.was_changed: bool = False
            self.was_checked: bool = False
            self.fixers_applied: Optional[List[Any]] = None
            self.used_names: Optional[Set[Text]] = None
            self.prev_sibling_map: Optional[Dict[int, Optional[NL]]] = None
            self.next_sibling_map: Optional[Dict[int, Optional[NL]]] = None
            self.next_sibling_map = self.next_s

# Generated at 2022-06-23 16:09:01.712816
# Unit test for constructor of class Leaf
def test_Leaf():
    from .pgen2.token import tok_name
    print(Leaf(tok_name["NAME"], "name"))
    assert Leaf(tok_name["NAME"], "name") == Leaf(tok_name["NAME"], "name")
    assert Leaf(tok_name["NUMBER"], "123") == Leaf(tok_name["NUMBER"], "123")
    assert Leaf(tok_name["NUMBER"], "123") != Leaf(tok_name["NUMBER"], "456")
    assert Leaf(tok_name["NAME"], "abc") != Leaf(tok_name["NAME"], "def")
    assert Leaf(tok_name["NAME"], "abc") != Leaf(tok_name["NUMBER"], "abc")



# Generated at 2022-06-23 16:09:08.139930
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from blib2to3.pytree import Leaf, Node
    l1 = Leaf(1, "string")
    l2 = Leaf(2, "another string")
    n = Node(3, [l1, l2])
    l3 = Leaf(4, "last string")
    n.insert_child(0, l3)
    assert n.children == [l3, l1, l2]


# Generated at 2022-06-23 16:09:18.169579
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from . import Leaf
    from . import Node

    def test(pattern, nodes):
        # Verify the generator behaves as expected.
        matches = list(pattern.generate_matches(nodes))
        assert all(isinstance(m, tuple) for m in matches)
        assert all(isinstance(m[0], int) for m in matches)
        assert all(isinstance(m[1], dict) for m in matches)
        assert all(m[0] <= len(nodes) for m in matches)
        return matches

    def test_file(pattern, n):
        from . import from_file

        f = from_file("Grammar.txt")
        nodes = list(f.children[0].children[0].children[:n])
        matches = test(pattern, nodes)

# Generated at 2022-06-23 16:09:29.549662
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import driver

    import unittest

    class Test(unittest.TestCase):
        def _check_match(self, pat, s):
            n = driver.parse_string(s)
            self.assertTrue(pat.match(n), s)

    t = Test()
    t._check_match(WildcardPattern(42), "foo")
    t._check_match(WildcardPattern(42), "42")
    t._check_match(WildcardPattern(42), "'42'")
    t._check_match(WildcardPattern(42), '"42"')
    t._check_match(WildcardPattern(42, 42), 'foo(42)')
    t._check_match(WildcardPattern(42, 42, 42), 'foo(bar, 42, spam)')
    t._check

# Generated at 2022-06-23 16:09:39.147828
# Unit test for constructor of class Node
def test_Node():
    from .pygram import python_symbols

    def test(items, node_type):
        for i in items:
            assert isinstance(i, Node)
            assert i.type == node_type
            assert i.children == []

    test([Node(python_symbols.dotted_name)], python_symbols.dotted_name)
    test(
        [Node(python_symbols.dotted_name, ())], python_symbols.dotted_name
    )
    test(
        [Node(python_symbols.dotted_name, [])], python_symbols.dotted_name
    )

# Generated at 2022-06-23 16:09:41.213001
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    a = Leaf(256, 'a')
    assert a.post_order() == a


# Generated at 2022-06-23 16:09:48.064904
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Testing with a WildcardPattern as content
    # Should return match (0,{})
    pattern = NegatedPattern(WildcardPattern())
    nodes = [1, 2, 3]
    assert next(pattern.generate_matches(nodes)) == (0, {})
    # Testing with None as content
    # Should return match (0,{})
    pattern = NegatedPattern()
    nodes = [1, 2, 3]
    assert next(pattern.generate_matches(nodes)) == (0, {})


# Generated at 2022-06-23 16:09:49.774564
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    assert BasePattern(value="1").optimize() is \
        BasePattern(value="1")


# Generated at 2022-06-23 16:09:57.569211
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    assert not NegatedPattern().match_seq([])
    assert not NegatedPattern().match_seq([1])
    assert not NegatedPattern(WildcardPattern()).match_seq([])
    assert not NegatedPattern(WildcardPattern()).match_seq([1])
    assert NegatedPattern(NegatedPattern()).match_seq([])
    assert not NegatedPattern(NegatedPattern()).match_seq([1])


# Generated at 2022-06-23 16:10:00.801693
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    x = Base()
    y = Base()
    assert not(x == y)

    class my_class(Base):
        def _eq(self, other):
            return True

    x = my_class()
    assert x == y



# Generated at 2022-06-23 16:10:12.164263
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern(type=10, content=[])
    n = NodePattern(type=10, content=[LeafPattern()])
    n = NodePattern(type=10, content=[LeafPattern(), LeafPattern()])
    # Test that the constructor raises an exception in case of errors
    from pytype import typeanno
    with pytest.raises(AssertionError):
        n = NodePattern(type=10, content=typeanno.Any)
    with pytest.raises(AssertionError):
        n = NodePattern(type=10)
    with pytest.raises(AssertionError):
        n = NodePattern(type=0)
    n = NodePattern(content=[LeafPattern(), LeafPattern()])
    n = NodePattern(content=[])



# Generated at 2022-06-23 16:10:19.392328
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import unittest
    import pprint

    class TestSupport(unittest.TestCase):
        """Support class for testing method BasePattern.generate_matches."""

        def test_BasePattern_generate_matches(self):
            """Unit test for method BasePattern.generate_matches."""
            from .pgen2 import driver

            import string
            import random

            def build_pattern(pattern):
                grammar = driver.prepare_grammar_pattern(pattern)
                return driver.compile_grammar_pattern(grammar, pattern)

            for n in range(10000):
                if n % 1000 == 0:
                    print("n =", n)
                # Create a random string of random length
                length = random.randint(0, 5)

# Generated at 2022-06-23 16:10:21.371607
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    #
    # No tests for an abstract base class.
    #
    pass


# Generated at 2022-06-23 16:10:24.416213
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree

    t = pytree.Node(type=0, children=[])
    assert list(t.post_order()) == [t]



# Generated at 2022-06-23 16:10:34.221096
# Unit test for function convert
def test_convert():
    def verify(l_node, *expect):
        assert len(l_node) == len(expect), (l_node, expect)
        for i, node in enumerate(l_node):
            if isinstance(node, Leaf):
                assert isinstance(expect[i], tuple), (node, expect[i])
                t, v = expect[i]
                assert node.type == t, (node.type, t)
                assert node.value == v, (node.value, v)
            else:
                assert not isinstance(expect[i], tuple), (node, expect[i])
                assert node.type == expect[i], (node.type, expect[i])
                verify(node.children, *expect[i + 1])


# Generated at 2022-06-23 16:10:44.420972
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from . import pytree

    def test_pre_order(node):
        # type: (pytree.Base) -> Iterator[pytree.Leaf]
        return list(node.pre_order())

    # No children.
    assert test_pre_order(pytree.Leaf(0, "")) == [pytree.Leaf(0, "")]
    # One child.
    assert test_pre_order(pytree.Node(0, [pytree.Leaf(0, "")])) == [
        pytree.Node(0, [pytree.Leaf(0, "")]),
        pytree.Leaf(0, ""),
    ]
    # Two children.

# Generated at 2022-06-23 16:10:47.135984
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf1 = Leaf(1, "5")
    assert len(list(leaf1.post_order())) == 1

# Generated at 2022-06-23 16:10:53.700503
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p0 = WildcardPattern(min=0, max=1, name="bare_name", content=[[NodePattern(type=257)]])
    p1 = WildcardPattern(min=1, max=1, name="bare_name", content=[[NodePattern(type=257)]])
    assert p0.optimize() == NodePattern(type=257)
    assert p1.optimize() == NodePattern(type=257)


# Generated at 2022-06-23 16:11:00.104036
# Unit test for method depth of class Base
def test_Base_depth():
    t = Node(0, [Leaf("a", linenum=1), Leaf("b", linenum=1)])
    assert t.depth() == 1
    u = Node(0, [t, Leaf("c", linenum=1)])
    assert u.depth() == 2
    v = Node(0, [u, Leaf("d", linenum=1)])
    assert v.depth() == 3



# Generated at 2022-06-23 16:11:06.165737
# Unit test for method leaves of class Base
def test_Base_leaves():
    l1 = Leaf(1, 'foo')
    l2 = Leaf(1, 'bar')
    l3 = Leaf(1, 'baz')
    n1 = Node(1, [l1, l2, l3])
    l4 = Leaf(1, 'quux')
    n2 = Node(1, [n1, l4])
    assert list(n2.leaves()) == [l1, l2, l3, l4]



# Generated at 2022-06-23 16:11:16.167534
# Unit test for method append_child of class Node
def test_Node_append_child():
    # Find parent method
    orig_method = Node.append_child

    # Create method that replaces parent
    def sample_method(self, child):
        print(child.type)
        orig_method(self, child)
        print('Sibling update')
        print(id(self.next_sibling_map))

    # Replace parent with child
    Node.append_child = sample_method

    node = Node(256, [])
    node.append_child(Leaf(258))
    node.append_child(Leaf(258))
    print(id(node.next_sibling_map))
    print(id(node.next_sibling_map))
    Node.append_child = orig_method


# Generated at 2022-06-23 16:11:27.981463
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    # Create a sample node tree
    node = Node(python_symbols.power, [],
        fixers_applied={'python_symbols.fix_docstring_indentation',
        'python_symbols.fix_bom_and_whitespace', 'python_symbols.fix_indentation',
        'python_symbols.fix_missing_whitespace', 'python_symbols.fix_comma_spacing',
        'python_symbols.fix_backticks', 'python_symbols.fix_negate_in_paren'},
        used_names={'import_name', 'f'})
    expected1_attr1 = None
    expected1_attr2 = None
    expected1_attr3 = None
    expected1_attr4 = None
    expected2

# Generated at 2022-06-23 16:11:37.243838
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar

    # Load the grammar
    f = io.StringIO(_GRAMMAR)
    gr = generate_grammar(f)
    f.close()

    # Parse some test source
    p = Parser(gr)
    s = """\
        def foo(arg1, arg2,
              arg3, arg4):
            pass
    """
    t = p.parse(s)
    assert t is not None, "Unable to parse test source"
    assert isinstance(t, Node) and t.type == symbol.file_input

    # Test for match against empty parser
    pm = PatternMatch(grammar=gr)
    r = pm.match(t)
    assert not r, "Test 1 failed"

# Generated at 2022-06-23 16:11:44.625107
# Unit test for method clone of class Node
def test_Node_clone():
    node = Node(4, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    cloned = node.clone()
    assert node == cloned
    assert cloned.children[0].parent is cloned
    assert cloned.children[1].parent is cloned
    assert cloned.children[2].parent is cloned
    assert node != cloned
    node.children[0].value = "d"
    assert node != cloned



# Generated at 2022-06-23 16:11:53.474458
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import string
    _g = Grammar()
    _g.initialize_tokens()
    g = _g.grammar
    import blib2to3.pgen2.token
    def f(t):
        if isinstance(t, str): return t
        return getattr(blib2to3.pgen2.token, t)
    def test_sibs(s):
        import blib2to3.pgen2
        c = blib2to3.pgen2.parse(s, "test", grammar=g)
        c[1].update_sibling_maps()
        return map(repr,[c[1].prev_sibling, c[1].next_sibling])
    assert list(test_sibs('a(b, c, d)')) == ["c", None]
