

# Generated at 2022-06-23 16:02:00.378722
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2.grammar import Symbol, STORE

    def p(s):
        return NodePattern(Symbol, [s], symbol_name="symbol")
    assert p("single")
    assert p("single").content == ["single"]
    assert p("single").name == "symbol"
    assert p("single").type == Symbol
    assert p("single").wildcards is False
    assert p("single").match(Node(Symbol, [Leaf(STORE, "single")]))
    assert not p("single").match(Node(Symbol, [Leaf(STORE, "single0")]))
    assert p("?").match(Node(Symbol, []))
    assert p("?").match(Node(Symbol, [Leaf(STORE, "single")]))



# Generated at 2022-06-23 16:02:09.653251
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node
    a = Leaf(0)
    a.was_changed = True
    a.changed()
    assert a.was_changed
    b = Node(0)
    b.was_changed = True
    b.changed()
    assert b.was_changed
    b.was_changed = False
    b.children = [Leaf(0)]
    b.children[0].was_changed = True
    b.changed()
    assert b.was_changed
    a.children = [Leaf(0)]
    a.children[0].was_changed = True
    a.changed()
    assert a.children[0].was_changed
    assert not a.was_changed


# Generated at 2022-06-23 16:02:17.103986
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import convert 
    from .pytree import Leaf, Node
    from .pygram import python_symbols as syms
    import types
    import unittest
    class T(unittest.TestCase):
        def test_leaves(self):
            tree = Node(syms.file_input,[Node(syms.classdef,[Leaf(1,"class"),Leaf(1," "),Leaf(1,"A"),Leaf(1,":"),Leaf(57,"\n"),Leaf(1,"    "),Leaf(51,"pass")])])
            l = list(tree.leaves())

# Generated at 2022-06-23 16:02:20.789067
# Unit test for function convert
def test_convert():
    from pytree import PythonParser

    parser = PythonParser()
    source = "spam(eggs)"
    node = parser.parse_string(source)
    assert node.children[0].children[0].value == "spam"
    assert node.children[0].children[1].value == "eggs"
    assert node.children[0].children[2].value == ""
    assert node.children[0].children[3].value == ""

# TODO: test tree building properly.



# Generated at 2022-06-23 16:02:22.316447
# Unit test for method set_child of class Node
def test_Node_set_child():
    assert False, 'Unimplemented'

# Generated at 2022-06-23 16:02:25.012439
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    p = BasePattern()
    assert not p.match(1)
    assert not p.match('')


# Note that results is optional, so not a problem there...
# pylint: disable=arguments-differ

# Generated at 2022-06-23 16:02:27.637056
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    child = Leaf(1, "test", None)
    node = Node(2, [child])
    node.insert_child(0, Leaf(3, "test", None))
    assert not node.children[0].parent
    assert node.children[1].parent is node



# Generated at 2022-06-23 16:02:30.029856
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    """
    >>> n = Leaf(1, 'a')
    >>> n.pre_order()
    [Leaf(1, 'a')]
    """



# Generated at 2022-06-23 16:02:32.477834
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    L = Leaf(0, "foo")
    assert list(L.post_order()) == [L]

# Generated at 2022-06-23 16:02:43.485012
# Unit test for method remove of class Base
def test_Base_remove():
    body = Node(sym.funcdef, [Leaf(token.NAME, "f"), Leaf(token.OPEN_PAREN, "("), Leaf(token.CLOSE_PAREN, ")"), Leaf(token.COLON, ":"), Leaf(token.NEWLINE, "\n"), Node(sym.suite, [Leaf(token.INDENT, "    "), Node(sym.stmt, [Node(sym.simple_stmt, [Node(sym.small_stmt, [Leaf(1, "pass")]), Leaf(token.SEMI_COLON, ";")])]), Leaf(token.DEDENT, "")])])
    pass_node = body.children[5].children[1].children[0].children[0]
    assert pass_node.remove() == 0

# Generated at 2022-06-23 16:02:45.114748
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver
    from .pgen2.parse import parse_grammar

    import os, sys

    _p = Driver(convert, parse_grammar(sys.modules[__name__].__file__), sys.modules[__name__])



# Generated at 2022-06-23 16:02:49.990632
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
  leaf1 = Leaf(4, 'foo')
  leaf2 = Leaf(4, 'bar')
  node = Node(3, [leaf1, leaf2])
  node.update_sibling_maps()
  assert leaf1.next_sibling == leaf2
  assert leaf2.prev_sibling == leaf1
  assert node.prev_sibling_map[id(leaf1)] == None
  assert node.prev_sibling_map[id(leaf2)] == leaf1
  assert node.next_sibling_map[id(leaf1)] == leaf2
  assert node.next_sibling_map[id(leaf2)] == None



# Generated at 2022-06-23 16:02:53.865371
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node(1, [Leaf(2, "2"), Leaf(2, "2")])
    str(node) == "22"



# Generated at 2022-06-23 16:03:04.577039
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from blib2to3.pygram import python_grammar
    from .pgen2 import driver
    from .pgen2.token import generate_tokens
    from .pgen2.parse import ParseError
    from .pytree import Leaf as L, Node as N
    from . import pytree

    parse, targt, tmplt = None, None, None
    def parse_string(s):
        # pylint: disable=nonlocal-statement
        nonlocal parse, targt, tmplt
        if parse is None:
            parse = driver.Driver(grammar=python_grammar, convert=pytree.convert)

# Generated at 2022-06-23 16:03:11.172475
# Unit test for method depth of class Base
def test_Base_depth():
    node = Node(1, None, None, None)
    assert node.depth() == 0
    node = Node(1, None, None, [Leaf(1, "  ")])
    assert node.depth() == 1
    node = Node(1, None, None, [node])
    assert node.depth() == 2
    node = Node(1, None, None, [node])
    assert node.depth() == 3
    node = Node(1, None, None, [node])
    assert node.depth() == 4


# Generated at 2022-06-23 16:03:13.273645
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # Add a few tests here
    p = NegatedPattern() # Test for contructor of class NegatedPattern
    assert p.match_seq([])
    assert not p.match_seq([Leaf(3)])


# Generated at 2022-06-23 16:03:15.969653
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    BasePattern()
    LeafPattern()
    NodePattern()
    WildcardPattern()



# Generated at 2022-06-23 16:03:17.884339
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "one")
    assert [leaf] == list(leaf.pre_order())


# Generated at 2022-06-23 16:03:29.721465
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from . import pytree
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as pgen
    from .pygram import python_grammar as pgen2
    from . import pygram
    from .pgen2 import driver
    from .pgen2.parse import ParseError
    from .pytoken import generate_tokens
    from .pgen2 import token
    import io
    import datetime
    from typing import Dict, List, Set, Tuple, Union, Iterable


    class _Leaf(Base):
        _NODE_CLASSES = (Leaf, Node, Base) # type: Iterable[Any]

# Generated at 2022-06-23 16:03:37.831323
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():

    def wc(*args, **kwargs):
        """Construct a wildcard pattern."""
        return WildcardPattern(*args, **kwargs).optimize()

    def np(*args, **kwargs):
        """Construct a node pattern."""
        return NodePattern(*args, **kwargs).optimize()

    assert wc().match_seq([]) is False
    assert wc().match_seq([Leaf(1, 'x')]) is False
    assert wc().match_seq([Leaf(1, 'x'), Leaf(2, 'y')]) is False
    assert wc().match_seq([Leaf(1, 'x'), Leaf(2, 'y'), Leaf(3, 'z')]) is True

    assert wc(1).match_seq([Leaf(1, 'x')]) is True

# Generated at 2022-06-23 16:03:49.108203
# Unit test for method __str__ of class Node
def test_Node___str__():
    print("test_Node___str__")
    node = Node(0, [])
    assert str(node) == ""

    def _test_str(node):
        print("test_Node___str__: %s" % node)
        assert str(node) == "".join([str(child) for child in node.children])

    node = Node(0, [Leaf(1, "foo"), Leaf(1, "bar")])
    _test_str(node)

    node = Node(0, [Leaf(1, "foo "), Leaf(1, "bar")])
    _test_str(node)

    node = Node(0, [Leaf(1, "foo "), Leaf(1, "bar ")])
    _test_str(node)


# Generated at 2022-06-23 16:03:51.743874
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    assert Leaf(
        0,
        'value',
        (0, 1, 2),
        'prefix',
        ['fixers_applied']
    ).__repr__() == "Leaf(0, 'value')"


# Generated at 2022-06-23 16:04:03.112451
# Unit test for method append_child of class Node
def test_Node_append_child():
    """ Test append_child method of Node class.
    """
    #  Test case

    node = Node(256, [])
    node.append_child(Leaf(1, ""))
    assert node.children[0].prefix == ""
    assert node.children[0].parent == node
    node.append_child(Leaf(1, ""))
    assert node.children[1].prefix == ""
    assert node.children[1].parent == node

    # My Test case

    node = Node(256, [])
    node.append_child(Leaf(1, "a"))
    assert node.children[0].prefix == ""
    assert node.children[0].parent == node
    node.append_child(Leaf(1, "a"))
    assert node.children[1].prefix == ""

# Generated at 2022-06-23 16:04:11.245523
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    p = NegatedPattern()
    print(list(p.generate_matches([])))
    p = NegatedPattern(WildcardPattern(min=2))
    print(list(p.generate_matches([])))
    p = NegatedPattern(NodePattern(type=tokenize.NAME, content=[WildcardPattern()]))
    print(list(p.generate_matches([Node(type=tokenize.NAME, value="x")])))
    print(list(p.generate_matches([Node(type=tokenize.NAME, value="x"), Node(type=tokenize.NAME, value="y")])))

# Generated at 2022-06-23 16:04:18.368648
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import difflib
    import inspect
    import sys
    import re
    import os
    import ast
    import random
    import copy
    import time

    import astor  # type: ignore
    from flake8_polyfill import options  # type: ignore
    from flake8_polyfill import pycodestyle  # type: ignore

    from lib2to3.pgen2.tokenize import generate_tokens  # type: ignore
    from lib2to3.pgen2.parse import ParseError  # type: ignore
    from lib2to3.pgen2.grammar import Grammar  # type: ignore
    from lib2to3.pgen2 import parse as lib2to3_parse  # type: ignore
    from lib2to3.pygram import python_symbols  # type: ignore

# Generated at 2022-06-23 16:04:25.178387
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    """Tests for Base.__eq__"""
    from .pytree import Leaf, Node

    l = Leaf(0, "")
    ll = Leaf(1, "", prefix="\n")
    n = Node(0, [l])
    assert l == l
    assert l != ll
    assert [l] == [l]
    assert [l] != [ll]
    assert l != ll
    assert l != n



# Generated at 2022-06-23 16:04:36.002521
# Unit test for function type_repr
def test_type_repr():
    import pygram
    # Nodes in pygram.python_symbols.__dict__ are int
    int_node_names = [node_name
                      for node_name in dir(pygram.python_symbols)
                      if isinstance(getattr(pygram.python_symbols, node_name),
                                    int)]
    for int_node_name in int_node_names:
        type_num = getattr(pygram.python_symbols, int_node_name)
        assert type_repr(type_num) == int_node_name
    # There are some integers that do not appear in the symbol table
    type_num = -3
    assert type_repr(type_num) == type_num

# The type of Token is T_TYPE = TypeVar("T_TYPE", bound=int

# Generated at 2022-06-23 16:04:41.435201
# Unit test for method depth of class Base
def test_Base_depth():
    import sys
    import io
    from io import StringIO, BytesIO
    import unittest

    class Base_depthTest(unittest.TestCase):
        def test1(self):
            self.assertTrue(False, 'This should not be executed')

    def main(out=sys.stderr, verbosity=2):
        loader = unittest.TestLoader()
        suite = unittest.TestSuite()
        # suite.addTest(Base_depthTest('test1'))
        unittest.TextTestRunner(out,verbosity=verbosity).run(suite)

    main()


# Generated at 2022-06-23 16:04:49.504339
# Unit test for method match of class WildcardPattern

# Generated at 2022-06-23 16:04:51.003614
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern()



# Generated at 2022-06-23 16:04:52.384445
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert BasePattern(1) is not None
    assert BasePattern(1) is not None
    assert BasePattern(1) is not None


# Generated at 2022-06-23 16:05:03.591160
# Unit test for method get_suffix of class Base

# Generated at 2022-06-23 16:05:05.815126
# Unit test for method changed of class Base
def test_Base_changed():
    pos = (1, 0)
    n = Node(1, None, pos)
    n.changed()
    assert n.was_changed



# Generated at 2022-06-23 16:05:14.768869
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # Match with no arguments
    n = NegatedPattern()
    # Match only an empty sequence
    assert n.match_seq([BareName([Token(Symbol, "bare-name")]), Num(1)]) is False
    assert n.match_seq([]) is True
    # Match with arguments
    m = NodePattern(Symbol.funcdef, [String("def"), BareName("f"), EqPlus(3)])
    n = NegatedPattern(m)
    # Match if the argument sequence does not
    assert n.match_seq([BareName([Token(Symbol, "bare-name")]), Num(1)]) is True
    assert n.match_seq([String("def"), BareName("f"), Num(3)]) is True

# Generated at 2022-06-23 16:05:25.013846
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    leaf = Leaf(1, "")
    child_1 = Node(2, [leaf])
    child_2 = Node(3, [])
    parent = Node(4, [child_1, child_2])
    leaf.parent = child_1
    assert child_1.parent is parent
    assert child_2.parent is parent
    assert leaf.parent is child_1
    assert parent.children[0] is child_1
    assert parent.children[1] is child_2

    leaf.replace(Node(5, []))
    assert child_1.parent is None
    assert child_2.parent is parent
    assert leaf.parent is None
    assert parent.children[0] is child_2
    assert len(parent.children) is 1


# Generated at 2022-06-23 16:05:33.121602
# Unit test for method append_child of class Node
def test_Node_append_child():
    class Foo(Node):
        def __init__(self, foo):
            self.foo = foo
            self.children = []
        def bar(self):
            self.append_child(self.foo)
    x = Foo(9)
    y = Foo(8)
    z = Foo(7)
    y.bar()
    z.bar()
    y.children[0] = z
    z.children[0] = x
    assert x.children[0] == y.children[0] == z.children[0]

# Generated at 2022-06-23 16:05:35.599119
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    l = Leaf(1, 'a')
    assert l.__repr__() == "Leaf({}, 'a')".format(tok_name.get(1, 1)), 'Leaf.__repr__()'


# Generated at 2022-06-23 16:05:44.651815
# Unit test for method insert_child of class Node
def test_Node_insert_child():
	import pprint
	from pgen2 import driver
	driver.build_parse_tables()  # build parse tables
	from pgen2 import tokenizer
	from pgen2 import parse
	from pgen2.pgen import PgenRule as Rule
	from pgen2 import grammar

	p = parse.Parser(driver.grammar, tokenizer.detect_encoding, parse.DEFAULT_DEBUG)
	p.setup()
	driver.grammar.parse_tables.load()
	from pgen2.parse import ParseError

	try:
		t = p.parse("a = 1\n")
	except ParseError:
		assert False
	rule = Rule("file_input", *t)
	rule
	print(rule)
	import copy
	t2 = copy.deepcopy(t)


# Generated at 2022-06-23 16:05:52.412959
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf

    def check(node, parent):
        assert node.parent is parent
        for child in node.children:
            check(child, node)

    node = Node(1, [Leaf(2, "abc"), Leaf(3, "def")])
    cloned_node = node.clone()
    # Make sure the tree is different from the original
    node.set_child(0, Leaf(4, "changed"))
    cloned_node.set_child(1, Leaf(5, "changed"))
    # Check consistency
    check(node, None)
    check(cloned_node, None)



# Generated at 2022-06-23 16:05:59.173885
# Unit test for method leaves of class Base
def test_Base_leaves():
    import random.random as r

    def insert_random_nodes(n):
        t = Node(r.choice([0, 1]))
        for i in range(n - 2):
            t = Node(r.choice([0, 1]), [t], prefix=str(r.randint(1, 9)))
        t = Node(
            r.choice([0, 1]),
            [t],
            prefix=str(r.randint(1, 9)) + str(r.randint(1, 9))
        )
        return t

    for i in range(100):
        n = r.randint(1000, 5000)
        t1 = insert_random_nodes(n)
        leaves = list(t1.leaves())
        assert len(leaves) == n, (i, n, len(leaves))

# Generated at 2022-06-23 16:06:06.581583
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from ..pgen2 import token

    tokens = token.tok_name

    class S(LeafPattern):

        type = tokens["STRING"]

    class C(LeafPattern):

        type = tokens["COMMENT"]

    class W(LeafPattern):

        type = tokens["NEWLINE"]

    class O(LeafPattern):

        type = tokens["OP"]

    class W(LeafPattern):

        type = tokens["NAME"]

    n = Node(tokens["expr_stmt"], [Leaf(tokens["NAME"], "x"), Leaf(tokens["NUMBER"], "1")])
    assert C().match(n) is False
    assert S().match(n) is False
    assert W().match(n) is False
    assert O().match(n) is False

# Generated at 2022-06-23 16:06:11.991151
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import unittest

    class TestCase(unittest.TestCase):

        def test(self):
            p = BasePattern()
            self.assertRaisesRegexp(
                NotImplementedError,
                ".*BasePattern._submatch.*",
                p.generate_matches,
                [],
            )

    unittest.main()



# Generated at 2022-06-23 16:06:21.752677
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    class MockNode:
        def __init__(self, id):
            self.id = id
    node1 = MockNode(1)
    node2 = MockNode(2)
    node3 = MockNode(3)
    parent = Node(0, [node1, node2, node3])
    assert parent.prev_sibling_map is None
    assert parent.next_sibling_map is None
    parent.update_sibling_maps()
    assert parent.prev_sibling_map is not None
    assert parent.next_sibling_map is not None
    assert parent.prev_sibling_map[id(node1)] is None
    assert parent.next_sibling_map[id(node1)] is node2
    assert parent.prev_sibling_map[id(node2)] is node1
    assert parent

# Generated at 2022-06-23 16:06:25.794329
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    l = Leaf(0, '*')
    print(l)
    #
    l = Leaf(0, '*', prefix=' ')
    print(l)
    #
    l = Leaf(0, '*', prefix=' #comment\n')
    print(l)
    return


# Generated at 2022-06-23 16:06:35.839279
# Unit test for method set_child of class Node
def test_Node_set_child():
    # In this unit test, we will test method set_child of class Node.
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.parse as parse

    # First, we will instantiate a Node instance.
    # We must set the node's attribute type.
    # Also we must set the node's attribute parent.
    # For your convenience, we have prepared a python grammar file for you.
    # The code is as follows:
    py_grammar_file = open("data/grammar.txt", "r")
    py_grammar_file_lines = py_grammar_file.readlines()
    py_grammar_file.close()
    py_grammar_lines = []

# Generated at 2022-06-23 16:06:38.860797
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Check that the content argument can be any sequence (not just a
    # tuple or list).
    NodePattern(type=1, content=(LeafPattern(),))
    NodePattern(type=1, content=iter((LeafPattern(),)))



# Generated at 2022-06-23 16:06:42.106330
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    node = Node(0, [])
    node.insert_child(1, 1)
    assert node.children == [1]
# Unit tests for method append_child of class Node

# Generated at 2022-06-23 16:06:48.164652
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_1 = Leaf(1, "Leaf1")
    result_1 = list(leaf_1.post_order())
    assert leaf_1.__class__.__name__ == 'Leaf', "Incorrect type for leaf_1:%s"%leaf_1.__class__.__name__
    assert 'Leaf' == result_1[0].__class__.__name__, "Incorrect type for result_1[0]%s"%result_1[0].__class__.__name__


# Unit tests for method post_order of class Node

# Generated at 2022-06-23 16:06:56.979508
# Unit test for constructor of class Node
def test_Node():
    from .pygram import python_symbols

    gram = Grammar()
    with open(gram.grammar_file) as f:
        gr = gram.parse_grammar(f.read(), f.name)
        pdict, tdict = gr.prepare_grammar_tokens()
    test_grammar = gram.pgen.generate_grammar(pdict, "root", tdict, "file")
    test_grammar



# Generated at 2022-06-23 16:07:05.925897
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import tok_name
    import re

    pattern = re.compile("(\.\w+)+")
    var_name = "var_name"
    test_type = tok_name["DOT"]
    test_value = "."
    test_prefix = ""
    test_fixers_applied = []

    node = Leaf(test_type, test_value,
                prefix=test_prefix,
                fixers_applied=test_fixers_applied,
                )
    node.bracket_depth = 1
    node.used_names = pattern.findall(var_name)
    clone_node = node.clone()

    # Check if the cloned node is not equal to the original node
    assert clone_node != node

    assert clone_node.bracket_depth == node

# Generated at 2022-06-23 16:07:08.861818
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(3, "test")
    assert l.type == 3
    assert l.value == "test"
    assert not l.children


# Generated at 2022-06-23 16:07:17.969926
# Unit test for method remove of class Base
def test_Base_remove():
    class TestBase1(Base):
        children = None
        def depth(self):
            return 0

    # Test for Base.remove
    # Test for Base.remove: Test when parent has no children
    test_base1_instance0 = TestBase1()
    assert test_base1_instance0.remove() == None
    # Test for Base.remove: Test removal when parent and children are not none
    test_base1_instance1 = TestBase1()
    test_base1_instance2 = TestBase1()
    test_base1_instance3 = TestBase1()
    test_base1_instance4 = TestBase1()
    test_base1_instance5 = TestBase1()
    test_base1_instance6 = TestBase1()
    test_base1_instance7 = TestBase1()
    test_base1_

# Generated at 2022-06-23 16:07:19.566755
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    test = LeafPattern("test")
    assert test.match("test")


# Generated at 2022-06-23 16:07:28.431957
# Unit test for method append_child of class Node
def test_Node_append_child():
    root_node: Node = Node(1, [])
    parent_node: Node = Node(2, [])
    root_node.append_child(parent_node)
    node_to_append: Leaf = Leaf(3, "")
    parent_node.append_child(node_to_append)

    assert root_node.prefix == ""
    assert parent_node.prefix == ""
    assert node_to_append.prefix == ""

    root_node.prefix = "a"
    parent_node.prefix = "b"
    node_to_append.prefix = "c"

    assert root_node.prefix == "a"
    assert parent_node.prefix == "b"
    assert node_to_append.prefix == "c"

    root_node.append_child(Leaf(0, "d"))
    parent

# Generated at 2022-06-23 16:07:30.503671
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, "a")
    leaf.prefix = "b"
    assert leaf.prefix == "b"



# Generated at 2022-06-23 16:07:38.183786
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    l = [Leaf(3, "three"), Leaf(4, "four"), Leaf(5, "five"), Leaf(6, "six")]
    n = [Node(1, l), Node(2, l)]
    p = NegatedPattern(NodePattern(content=[LeafPattern(value=3)]))
    assert list(p.generate_matches(n)) == [(2, {})]


# Utility functions for applying patterns


# Generated at 2022-06-23 16:07:50.893760
# Unit test for method remove of class Base
def test_Base_remove():
    import StringIO

    stream = StringIO.StringIO(u"")
    stream.write(u"import")
    stream.write(u" ")
    stream.write(u"os")
    stream.write(u" ")
    stream.write(u"as")
    stream.write(u" ")
    stream.write(u"os")
    stream.seek(0)
    from .pgen2 import driver

    grammar = driver.load_grammar('Grammar.txt', '2.7')
    from .pgen2 import tokenize

    gen = tokenize.generate_tokens(stream.readline)
    from .pytree import convert

    node = convert(grammar, gen)
    assert node.type == 1
    assert node.next_sibling.type == 2
    assert node

# Generated at 2022-06-23 16:07:52.256906
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    Leaf(1,"test_value").pre_order()
    pass

# Generated at 2022-06-23 16:08:00.527906
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pygram import python_grammar
    from .pytree import Leaf, Node
    from .pgen2 import token

    def tree_to_str(tree: Node) -> Text:
        return "".join(t.value for t in tree.leaves())

    grammar = python_grammar


# Generated at 2022-06-23 16:08:02.724118
# Unit test for constructor of class Base
def test_Base():
    f = Leaf(1, "test")
    b = Base()
    assert type(b) is Base



# Generated at 2022-06-23 16:08:04.326016
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert type(b) is Base



# Generated at 2022-06-23 16:08:07.589427
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert Leaf(0, "").pre_order() == [Leaf(0, "")]
if __name__ == "__main__":
    test_Leaf_pre_order()


# Generated at 2022-06-23 16:08:14.154943
# Unit test for constructor of class Node
def test_Node():
    n = Node(256, [])
    assert n.type == 256 and not n.children
    Leaf(1, "a", (1, 0)).parent = n
    Leaf(1, "b", (1, 1)).parent = n
    Leaf(1, "c", (1, 2)).parent = n
    assert n == Node(256, [Leaf(1, "a", (1, 0)), Leaf(1, "b", (1, 1)), Leaf(1, "c", (1, 2))])



# Generated at 2022-06-23 16:08:23.849479
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    B = BasePattern
    b = B(0, "s")
    assert b.match_seq([Leaf(0, "s")])
    assert not b.match_seq([Leaf(0, "x")])
    assert not b.match_seq([])
    x = B(0, None)
    assert x.match_seq([Leaf(0, "s")])
    assert x.match_seq([Leaf(0, "x")])
    assert not x.match_seq([])
    x = B(0)
    assert x.match_seq([Leaf(0, "s")])
    assert x.match_seq([Leaf(0, "x")])
    assert not x.match_seq([])
    x = B(256)

# Generated at 2022-06-23 16:08:25.241057
# Unit test for method changed of class Base
def test_Base_changed():
    i = 0
    while i < 9:
        i = i + 1

# Generated at 2022-06-23 16:08:30.969822
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf
    node = Node(1, [Leaf(1,'l')])
    node.append_child(Leaf(1,'append'))
    assert(len(node.children) == 2)
    node.append_child(Leaf(1,'append2'))
    assert(len(node.children) == 3)

# Generated at 2022-06-23 16:08:36.397024
# Unit test for method replace of class Base
def test_Base_replace():
    l1 = Leaf(1, "1")
    l2 = Leaf(1, "2")
    n = Node(3, [l1, l2])
    l11 = Leaf(1, "11")
    l12 = Leaf(1, "12")
    l1.replace([l11, l12])
    assert n.to_tuple() == (3, None, None, [(1, "11"), (1, "2"), (1, "12")])



# Generated at 2022-06-23 16:08:43.763621
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree
    from . import pygram
    from . import python_symbols as syms
    from .pgen2 import parsetok

    class DummyOptions(object):
        def __init__(self):
            self.indentation_level = 0
            self.indentation_string = "  "
            self.input_encoding = "utf8"
            self.output_encoding = "utf8"

    class DummyLog(object):
        def __init__(self):
            self.logs = []

        def info(self, msg: str) -> None:
            self.logs.append(msg)


# Generated at 2022-06-23 16:08:54.609653
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    a = LeafPattern(2, "foo")
    assert a.type == 2
    assert a.content == "foo"
    assert a.name is None
    a = LeafPattern(2, "foo", "result")
    assert a.type == 2
    assert a.content == "foo"
    assert a.name == "result"
    a = LeafPattern(2)
    assert a.type == 2
    assert a.content is None
    assert a.name is None
    a = LeafPattern(content="foo")
    assert a.type is None
    assert a.content == "foo"
    assert a.name is None
    a = LeafPattern(content="foo", name="result")
    assert a.type is None
    assert a.content == "foo"
    assert a.name == "result"
    a = LeafPattern

# Generated at 2022-06-23 16:09:04.368095
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from . import pytree
    from . import pygram
    from .pgen2 import parse
    import copy
    import io
    import unittest
    import sys

    class TestTree(pytree.Base):

        def _eq(self, other):
            return False

        def clone(self):
            return TestTree()

        def post_order(self):
            return []

        def pre_order(self):
            return []

    class TestTreeTest(unittest.TestCase):

        def setUp(self):
            # Constants
            self.tree_string = "tree_string"
            self.suffix = "suffix"
            # Set up
            self.tree = TestTree()
            self.tree.set_suffix(self.suffix)
            self.tree.parent = TestTree()
            self

# Generated at 2022-06-23 16:09:11.005772
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    class TestNode(Node):
        pass
    # 1.
    insert_child_node = TestNode(1, [])
    child_node = TestNode(2, [])
    insert_child_node.insert_child(0, child_node)
    assert insert_child_node.children[0] == child_node
    assert insert_child_node.children[0].parent == insert_child_node


# Generated at 2022-06-23 16:09:19.629350
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    np = NegatedPattern()
    assert list(np.generate_matches([])) == [(0, {})]
    assert list(np.generate_matches([1])) == []
    np = NegatedPattern(LiteralPattern(123))
    assert list(np.generate_matches([1])) == [(0, {})]
    assert list(np.generate_matches([123])) == []
    np = NegatedPattern(NodePattern(1, [LiteralPattern(123)]))
    assert list(np.generate_matches([1, 123])) == []
    assert list(np.generate_matches([1, 456])) == [(0, {})]


_NG = "NegatedPattern._generate_matches(): "



# Generated at 2022-06-23 16:09:30.549971
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    p = LeafPattern(0)
    assert p.type is None or p.type == 0
    assert p.content is None
    assert p.name is None
    q = p.optimize()
    assert p is q
    assert p.type is None or p.type == 0
    assert p.content is None
    assert p.name is None

    p = LeafPattern(0, "+")
    assert p.type is None or p.type == 0
    assert p.content == "+"
    assert p.name is None
    q = p.optimize()
    assert p is q
    assert p.type is None or p.type == 0
    assert p.content == "+"
    assert p.name is None

    p = LeafPattern(0, "+", "x")
    assert p.type is None or p.type == 0

# Generated at 2022-06-23 16:09:39.666912
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from pegen.grammar import RE_DEDENT, RE_INDENT
    from pegen.grammar import RE_LITERAL_REF, RE_OPERATOR, RE_NAME
    from pegen.grammar import RE_SYMBOL, RE_STRING_PREFIX, RE_STRING_LITERAL
    from pegen.grammar import RE_DECORATOR
    from pegen.grammar import t, TOKEN, SYMBOL, NAME, STRING
    from pegen.grammar import NEWLINE, INDENT, DEDENT
    from pegen.grammar import Op, Keyword
    from pegen.grammar import EndMarker
    from pegen.ast2 import Leaf, Node
    def myassert(test: bool, msg: Text) -> None:
        assert test or msg

# Generated at 2022-06-23 16:09:43.702756
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    """Unit test for method __eq__ of class Base"""
    class A(Base):
        def _eq(self, other):
            return True

    inst = A()
    assert (inst == A())
# Creates an error if Base's initialiser signature is changed.

# Generated at 2022-06-23 16:09:49.418117
# Unit test for function generate_matches
def test_generate_matches():
    # generate_matches has been copied from stdlib, so this is just a smoke
    # test to make sure the unit doesn't break
    simple_pattern = NodePattern(type=token.STRING)
    simple_nodes = [NL(type=token.STRING)]
    for _, _ in generate_matches([simple_pattern], simple_nodes):
        pass



# Generated at 2022-06-23 16:09:58.139660
# Unit test for method clone of class Leaf

# Generated at 2022-06-23 16:10:04.704449
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    test_patterns = [
        NodePattern("Bare_name"),
        NodePattern("Bare_name", name="bare"),
        NodePattern("Bare_name", [WildcardPattern(name="bare")]),
        WildcardPattern([NodePattern("Bare_name", name="bare")]),
        WildcardPattern([WildcardPattern([NodePattern("Bare_name", name="bare")])]),
    ]
    test_strings = ["a", "b", "c", "d", "e"]
    for p in test_patterns:
        assert p.match_seq(test_strings)
        assert p.match_seq([Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])

# Generated at 2022-06-23 16:10:12.206762
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node

    node = Node(1, [
        Leaf(1, ""),
        Leaf(2, ""),
        Leaf(1, ""),
        Leaf(1, ""),
        Leaf(2, ""),
    ])

    assert node[0].get_suffix() == ""
    assert node[1].get_suffix() == "e"
    assert node[2].get_suffix() == "e"
    assert node[3].get_suffix() == "e"
    assert node[4].get_suffix() == ""

# Unit tests for class Base

# Generated at 2022-06-23 16:10:15.705603
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    o = BasePattern(TYPE,CONTENT,NAME) 
    assert TYPE == o.type, TYPE
    assert NAME == o.name, NAME
    assert CONTENT == o.content, CONTENT
    assert o is o.optimize(), o
    assert o is not o.optimize(), o


# Generated at 2022-06-23 16:10:26.343079
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf, Node

    # Test 1.
    parent = Node(1, [1, 2, 3])
    child = parent.children[1]
    assert child.parent == parent
    child.replace([4, 5, 6])
    assert child.parent is None
    assert parent.children == [1, 4, 5, 6, 3]

    # Test 2.
    parent = Node(1, [1, 2, 3])
    child = parent.children[1]
    assert child.parent == parent
    child.replace([4])
    assert child.parent is None
    assert parent.children == [1, 4, 3]

    # Test 3.
    parent = Node(1, [1, 2, 3])
    child = parent.children[1]
    assert child.parent == parent
    child.replace

# Generated at 2022-06-23 16:10:29.547018
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    leaf = Leaf(1, 'a')
    matches = list(BasePattern().generate_matches([leaf]))
    assert matches == [(1, {})]
test_BasePattern_generate_matches()



# Generated at 2022-06-23 16:10:31.745900
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert repr(BasePattern()) is not None
    BasePattern()



# Generated at 2022-06-23 16:10:42.985593
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    parse1 = compile_pattern('-a')
    parse2 = compile_pattern('-')
    parse3 = compile_pattern('-ab')
    parse4 = compile_pattern('-^')
    parse5 = compile_pattern('-c')
    parse6 = compile_pattern('-')
    parse7 = compile_pattern('-')
    parse8 = compile_pattern('-')
    parse9 = compile_pattern('-d')
    parse10 = compile_pattern('-')
    parse11 = compile_pattern('-e')
    parse12 = compile_pattern('-')
    parse13 = compile_pattern('-f')
    parse14 = compile_pattern('-')
    parse15 = compile_pattern('-h')
    parse16 = compile_pattern('-')
    parse17 = compile_pattern('-i')
    parse18

# Generated at 2022-06-23 16:10:48.381952
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    wild = WildcardPattern(content=[[Leaf(token.NAME, "a")], [Leaf(token.NAME, "b")]])
    assert wild.content[0][0].match(Leaf(token.NAME, "a"))

# ------------------
# Helper functions
# ------------------



# Generated at 2022-06-23 16:10:58.563260
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf

    # The structure of the following tree was taken from Python 2.7 grammar:
    #   power: atom trailer* ('**' factor)*
    # This test case covers all possible uses of get_lineno for that rule:

    # 0. Test for get_lineno on a leaf
    leaf = Leaf(token.NUMBER, "5", None, prefix="5")
    assert leaf.get_lineno() is None

    leaf = Leaf(token.NUMBER, "5", (1, 10), prefix="5")
    assert leaf.get_lineno() == 1

    # 1. Test for get_lineno on a node with only one child
    parent = Node(syms.power, [leaf], prefix="5")
    assert parent.get_lineno() == 1

    # 2. Test for get_lineno on

# Generated at 2022-06-23 16:11:02.978331
# Unit test for method __str__ of class Node
def test_Node___str__():
    # XXX It would be nice to have a more general test suite
    # for the functionality implemented by Node
    test_node = Node(
        type = 256,
        children = [],
    )
    # Calling the __str__ method on node
    assert isinstance(test_node.__str__(), str)

test_Node___str__()


# Generated at 2022-06-23 16:11:10.105828
# Unit test for method depth of class Base
def test_Base_depth():
    assert Base().depth() == 0
    class Fake(Base):
        parent = Base()
    assert Fake().depth() == 1
    assert Fake().parent.depth() == 0
    class Fake2(Base):
        parent = Fake()
    assert Fake2().depth() == 2
    assert Fake2().parent.depth() == 1

# Generated at 2022-06-23 16:11:12.074346
# Unit test for constructor of class Base
def test_Base():
    import pytest
    with pytest.raises(AssertionError):
        Base()



# Generated at 2022-06-23 16:11:19.610696
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # test nodes with a lineno
    tree = parse("""
    a = 5
    b = 7
    c = 9
    """)
    assert tree.get_lineno() == 1
    assert tree.children[0].get_lineno() == 1
    assert tree.children[0].children[0].get_lineno() == 1
    assert tree.children[1].get_lineno() == 2
    assert tree.children[1].children[0].get_lineno() == 2
    assert tree.children[2].get_lineno() == 3
    assert tree.children[2].children[0].get_lineno() == 3
    # test node without a lineno
    tree = parse("a = 5\nb = 7\nc = 9")
    assert tree.get_lineno() is None
    assert tree.children

# Generated at 2022-06-23 16:11:22.857993
# Unit test for method set_child of class Node
def test_Node_set_child():
    from refactorlib.tokenize import generate_tokens, untokenize
    from .pytree import Leaf, Node


# Generated at 2022-06-23 16:11:31.720859
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    bp = BasePattern()
    bp.type = 65
    bp.content = 66
    bp.name = 67
    assert bp.match_seq([]) == False
    assert bp.match_seq([node(68)]) == False
    assert bp.match_seq([node(65)]) == False
    assert bp.match_seq([node(65, 66)]) == False
    assert bp.match_seq([node(65, 66, 67)]) == False
    assert bp.match_seq([node(65, 66, 67, node(68))]) == False
    assert bp.match_seq([node(65, 66, 68)]) == True
    assert bp.match_seq([node(65, 66, 68, node(67))]) == True

# Generated at 2022-06-23 16:11:38.724951
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from . pytree import Node, Leaf
    from . pygram import python_symbols as syms
    from . pygram import python_grammar
    from . pygram import python_grammar_no_print_statement
    from io import StringIO
    import unittest

    # Create a Python grammar object so we can compare the histogram later
    grammar = python_grammar

    # Create a Python grammar object so we can compare the histogram later
    grammar_no_print_statement = python_grammar_no_print_statement

    class TestNodePreorder(unittest.TestCase):

        def setUp(self):
            self.stream = StringIO()
            self.node = None
            self.node_no_print_statement = None

        def test_pre_order_empty_input(self):
            self.node = Node

# Generated at 2022-06-23 16:11:43.513501
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf, Node
    a = Leaf(1, "a")
    b = Leaf(1, "b")
    n = Node(2, [a, b])
    assert list(n.pre_order()) == [n, a, b]


# Generated at 2022-06-23 16:11:46.549982
# Unit test for constructor of class BasePattern
def test_BasePattern():
    m = BasePattern(0)
    assert not hasattr(m, "type")
    assert not hasattr(m, "content")
    assert not hasattr(m, "name")



# Generated at 2022-06-23 16:11:49.819368
# Unit test for constructor of class BasePattern
def test_BasePattern():
    class TestPattern(BasePattern):
        pass
    with pytest.raises(AssertionError):
        TestPattern()
