

# Generated at 2022-06-23 16:01:55.775715
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import token

    n = Node(token.COMMENT, [Leaf(token.COMMENT, "# blah blah"),])
    m = LeafPattern(token.COMMENT)
    assert m.match_seq([n])



# Generated at 2022-06-23 16:01:58.853817
# Unit test for method append_child of class Node
def test_Node_append_child():
    children = [Leaf(11, "", (1, 1), (1, 1))]
    child = Leaf(12, "", (1, 1), (1, 1))
    node = Node(13, children)
    node.append_child(child)



# Generated at 2022-06-23 16:02:10.145264
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2.token import tok_name

    t1 = NodePattern(tok_name["STRING"])
    # yapf: disable
    t2 = NodePattern(tok_name["NAME"], [
        LeafPattern(tok_name["STRING"]),
        LeafPattern(tok_name["NAME"]),
        LeafPattern(tok_name["NAME"]),
    ])
    # yapf: enable
    t3 = NodePattern(tok_name["NAME"], [
        LeafPattern(tok_name["STRING"]),
        WildcardPattern(tok_name["NAME"]),
        LeafPattern(tok_name["NAME"]),
    ])
    assert t1.type == t2.type == t3.type == tok_name["NAME"]
    assert t1.content is None

# Generated at 2022-06-23 16:02:17.944132
# Unit test for method leaves of class Base
def test_Base_leaves():
    root = Node(0, "")
    rn1 = Node(1, root, [], [], 0, (), rn1_prefix, rn1_children)
    root.children = [rn1]
    rn2 = Node(0, rn1, [], [], 0, (), rn2_prefix, rn2_children)
    rn3 = Node(2, rn1, [], [], 0, (), rn3_prefix, rn3_children)
    rn1.children = [rn2, rn3]
    ll = Leaf(3, rn2, [], [], 0, (), ll_prefix)
    lr = Leaf(4, rn2, [], [], 0, (), lr_prefix)
    rn2.children = [ll, lr]
    rn4

# Generated at 2022-06-23 16:02:24.906916
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from . import pytree

    # todo: use a better fixture
    # a = pytree.Node(1, [])
    # b = pytree.Node(2, [])
    # c = pytree.Node(3, [])
    # t = pytree.Node(4, [a, b, c])

    # a.parent = t
    # b.parent = t
    # c.parent = t

    # expected = [t, a, b, c]

    # assert list(t.pre_order()) == expected

    assert True



# Generated at 2022-06-23 16:02:36.437897
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    """
    Unit tests for the match method of BasePattern.
    """
    import pickle

    # Pickle the class attribute type of this class.
    # This used to fail.
    pickle.dumps(BasePattern.type)

    # With no type specified, it should match any node type.
    assert BasePattern(None).match(Leaf(token.NAME, "name"))
    assert BasePattern(None).match(Node(syms.test, []))

    # Now try with a specific type.  It should only match when the node
    # types match.
    assert not BasePattern(token.NAME).match(Leaf(token.NUMBER, "3"))
    assert not BasePattern(token.NAME).match(Node(syms.test, []))

# Generated at 2022-06-23 16:02:37.113232
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    pass

# Generated at 2022-06-23 16:02:41.410591
# Unit test for constructor of class Node
def test_Node():
    def chk(node):
        if node.parent is not None:
            assert node in node.parent.children, (node, node.parent)
        return node

    chk(Node(1, [chk(Leaf(1, "foo")), chk(Leaf(1, "bar"))]))



# Generated at 2022-06-23 16:02:52.744415
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import blib2to3.pytree
    # Test for method Node.update_sibling_maps
    # (self)
    # Ensure that after calling update_sibling_maps, the next_sibling and
    # prev_sibling properties return the correct nodes
    n1 = blib2to3.pytree.Leaf(1, "A")
    n2 = blib2to3.pytree.Leaf(1, "B")
    parent = blib2to3.pytree.Node(2, [n1, n2])
    assert n1.next_sibling is None
    assert n2.prev_sibling is None

    parent.update_sibling_maps()
    assert n1.next_sibling is n2
    assert n2.prev_sibling is n1

    n3 = blib2

# Generated at 2022-06-23 16:02:59.728490
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from .pytree import Node, type_repr
    assert isinstance(Node.__repr__.__get__(Node), Callable)
    assert Node.__repr__.__get__(Node)(Node(1, [], None)) == "Node(1, [])"
    assert isinstance(type_repr(0), int)
    assert Node.__repr__.__get__(Node)(Node(257, [], None)) == "Node(257, [])"
    assert isinstance(type_repr(257), str)
    assert Node.__repr__.__get__(Node)(Node(258, [], None)) == "Node(258, [])"
    assert isinstance(type_repr(258), str)

# Generated at 2022-06-23 16:03:03.340560
# Unit test for method replace of class Base
def test_Base_replace():
    x = Leaf(3, "[")
    x.parent = True
    assert x.parent is True
    x.replace("foo")
    assert x.parent is None



# Generated at 2022-06-23 16:03:05.332890
# Unit test for constructor of class BasePattern
def test_BasePattern():
    c = BasePattern()
    assert c.type is None
    assert c.content is None
    assert c.name is None



# Generated at 2022-06-23 16:03:12.201623
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import types
    from .pytree import Node # pyre-ignore[21]
    from .pygram import python_symbols # pyre-ignore[21]
    from .pgen2 import token # pyre-ignore[21]

# Generated at 2022-06-23 16:03:18.052058
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    # Test empty sequence
    p = LeafPattern(type=token.NAME)
    np = NegatedPattern(p)
    assert list(np.generate_matches([])) == [(0, {})]
    assert list(np.generate_matches([Leaf(1, 'a'), Leaf(1, 'a')])) == []

    # Test singleton sequence with non-matching type
    assert list(np.generate_matches([Leaf(token.NUMBER, '2')])) == [(0, {})]

    # Test singleton sequence with matching type
    assert list(np.generate_matches([Leaf(token.NAME, 'a')])) == []

    # Test multiple-element sequence with non-matching type

# Generated at 2022-06-23 16:03:19.531841
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    n = BasePattern(3, 4, 5)
    assert n.__repr__() == "BasePattern(3, 4, 5)"

# Generated at 2022-06-23 16:03:24.477056
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    code = [
        "a = 10",
        "b = 20",
        "and",
        "c = 30",
        "d = 40",
        "or",
        "e = 50",
        "f = 60",
        "endif",
    ]
    syntax_tree = parse(code)
    ast_matcher = NegatedPattern(NodePattern(content=[NodePattern(content="int")]))
    match = ast_matcher.match(syntax_tree)
    assert match == False
    match = ast_matcher.match(syntax_tree.children[0][1])
    assert match == False
    match = ast_matcher.match(syntax_tree.children[0][0])
    assert match == False

# Generated at 2022-06-23 16:03:28.662868
# Unit test for method __str__ of class Node
def test_Node___str__():
    myNode = Node(1, [1,2,3,4])
    print(str(myNode))
    assert str(myNode) == "1234"



# Generated at 2022-06-23 16:03:37.222319
# Unit test for method replace of class Base
def test_Base_replace():
    class Node(Base):
        def __init__(self, children):
            self.children = children
            for child in children:
                child.parent = self

        def _eq(self, other):
            return self.children == other.children

        def clone(self):
            return Node(self.children[:])

        def post_order(self):
            for child in self.children:
                for x in child.post_order():
                    yield x
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                for x in child.pre_order():
                    yield x

    class Leaf(Base):
        def __init__(self, value):
            self.value = value

        def _eq(self, other):
            return self.value == other.value


# Generated at 2022-06-23 16:03:38.988976
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    f = Leaf(0, "foo")
    assert list(f.leaves()) == [f]

# Generated at 2022-06-23 16:03:49.984711
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    """
    Generated code for method match of class LeafPattern

    Test for both default implementation and override implementation of
    the method match in class LeafPattern
    """
    # Create instances
    test_LeafPattern_match_instance_0 = LeafPattern(type = None, content = None, name = None)
    test_LeafPattern_match_instance_1 = LeafPattern(type = None, content = "abc", name = None)
    # Setting up test node
    test_LeafPattern_match_instance_test_node___init__ = Leaf(type = None, value = "def", context = None, prefix = None, fixers_applied = [])
    test_LeafPattern_match_instance_test_node = test_LeafPattern_match_instance_test_node___init__
    # Setting up test results
    test_Leaf

# Generated at 2022-06-23 16:03:54.782245
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    """Test for method clone of class Leaf.

    Method clone of class Leaf creates a shallow copy of input.
    """
    from .pgen2.token import OP, COMMA
    leaf1 = Leaf(OP, "(")
    leaf2 = Leaf(COMMA, ",")
    leaf1.append_child(leaf2)
    leaf3 = leaf1.append_child(leaf2)
    assert leaf1.clone() is not leaf1
    assert leaf1.clone().children is not leaf1.children
    assert leaf1.clone().children[-1] is not leaf1.children[-1]


# Generated at 2022-06-23 16:04:00.683501
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from . import pytree
    from .pgen2 import token

    class Foo(Base):
        _fields = ["bar"]
        _attributes = ["baz"]
        _other_fields = ["qux"]

        def __init__(self, node_type, bar, baz, qux, prefix: Text = "") -> None:
            assert isinstance(bar, list)
            Base.__init__(self)
            self.type = node_type
            self.children = bar
            self.baz = baz
            self.qux = qux
            self.prefix = prefix


# Generated at 2022-06-23 16:04:05.761259
# Unit test for method remove of class Base
def test_Base_remove():
    n = Node(1, [Leaf(1, "is"), Leaf(1, "not"), Leaf(1, "None")])
    assert 2 == n.children[1].remove()
    assert [Leaf(1, "is"), Leaf(1, "None")] == n.children
    assert n.children[1].parent is n
    assert n.children[1].next_sibling is None


# Generated at 2022-06-23 16:04:15.647572
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    """Unit tests of Node.insert_child()"""
    # Insert a new child at the start of the list
    n = Node(0, [Leaf(3, "a"), Leaf(3, "b")])
    n.insert_child(0, Leaf(3, "c"))
    if not isinstance(n, Node): return False
    if len(n.children) != 3: return False
    if not isinstance(n.children[0], Leaf): return False
    if not isinstance(n.children[1], Leaf): return False
    if not isinstance(n.children[2], Leaf): return False
    if n.children[0].value != "c": return False
    if n.children[1].value != "a": return False
    if n.children[2].value != "b": return False
    return True
#

# Generated at 2022-06-23 16:04:23.390981
# Unit test for method post_order of class Base
def test_Base_post_order():
    class Foo(Node):
        def _eq(self, other):
            return True
        def clone(self):
            return Foo()
        def post_order(self):
            yield self
        def pre_order(self):
            yield self
    root = Foo()
    for x in range(20):
        root.append_child(Foo())
    assert list(root.post_order()) == list(root.children)



# Generated at 2022-06-23 16:04:31.039769
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    pattern = NegatedPattern()
    assert pattern.match_seq([])
    assert not pattern.match_seq([1])
    assert not pattern.match_seq([1, 2])
    assert not pattern.match_seq([1, 2, 3])

    pattern = NegatedPattern(NodePattern(type=1, content=[LeafPattern()]))
    assert pattern.match_seq([])
    assert pattern.match_seq([1])
    assert not pattern.match_seq([Symbol(1)])
    assert pattern.match_seq([1, 2])
    assert not pattern.match_seq([Symbol(1, [Symbol(2)]), 2])
    assert pattern.match_seq([1, 2, 3])

# Generated at 2022-06-23 16:04:37.755508
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    LeafPattern()
    LeafPattern(type=1)
    LeafPattern(type=1, content='x')
    LeafPattern(content='x')
    LeafPattern(content='x', name='y')

    try:
        LeafPattern(type=-1)
        assert False, "Expected SyntaxError"
    except AssertionError:
        raise
    except SyntaxError:
        pass

    try:
        LeafPattern(type=1, content=2)
        assert False, "Expected SyntaxError"
    except AssertionError:
        raise
    except SyntaxError:
        pass



# Generated at 2022-06-23 16:04:42.299122
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .tree import Leaf, Node
    from .pygram import python_symbols as syms

    PROGRAM = syms.file_input
    result = Node(PROGRAM, [])
    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Leaf(1, "c")
    result.append_child(a)
    result.append_child(b)
    result.append_child(c)
    assert [x.value for x in result.children] == ["a", "b", "c"]



# Generated at 2022-06-23 16:04:43.624735
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node(0, [])
    str(node)


# Generated at 2022-06-23 16:04:51.005357
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w = WildcardPattern()
    assert w.content is None
    assert w.min == 0
    assert w.max == HUGE
    w = WildcardPattern(None, 3, 5)
    assert w.content is None
    assert w.min == 3
    assert w.max == 5
    assert repr(w) == "WildcardPattern(min=3, max=5)"
    w = WildcardPattern([[Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]])
    assert w.content == ((NodePattern(token.NAME, "a"), NodePattern(token.NAME, "b")),)
    w = WildcardPattern(
        [[Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]], name="node"
    )
    assert w.name == "node"

# Generated at 2022-06-23 16:04:54.441095
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    p = Pattern(NUMBER)
    assert repr(p) == "LeafPattern(NUMBER, None, None)"
    p = Pattern(NUMBER, "1")
    assert repr(p) == "LeafPattern(NUMBER, '1', None)"
    p = Pattern(NUMBER, "1", name="foo")
    assert repr(p) == "LeafPattern(NUMBER, '1', 'foo')"



# Generated at 2022-06-23 16:04:56.316394
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    leaf = Leaf(1, '+')

    assert str(leaf.__repr__()) == "Leaf(1, '+')"
    assert repr(leaf) == "Leaf(1, '+')"


# Generated at 2022-06-23 16:05:04.308231
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """Test the Node.pre_order() interpretation."""
    from .pytree import Node

    node = Node(1, [Leaf(1, ()), Node(2, [Leaf(3, ())])], ())
    assert list(node.pre_order()) == [node, node.children[0], node.children[1], node.children[1].children[0]]
    assert list(node.children[0].pre_order()) == [node.children[0]]

# Generated at 2022-06-23 16:05:11.478363
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():

    # check if constr works with valid arguments
    def _check_getitem(node, list_of_indices):
        for i in list_of_indices:
            node = node[i]
        return node

    def test_node(node):
        pattern = NegatedPattern()
        assert pattern.match_seq([node])
        pattern = NegatedPattern(NodePattern(name="hello"))
        assert not pattern.match_seq([node])
        pattern = NegatedPattern(NodePattern(name="hello"))
        assert not pattern.match_seq([node, node])
        pattern = NegatedPattern(NodePattern(type=pygram.syms.decorator, name="hello"))
        assert not pattern.match_seq([node])

# Generated at 2022-06-23 16:05:22.565998
# Unit test for method replace of class Base
def test_Base_replace():
    from . import tree

    def test(n: NL, new: Union[NL, List[NL]]) -> None:
        m = n.clone()
        m.replace(new)
        tree.dump(n)
        tree.dump(m)

    test(Leaf("z", 1), Leaf("a", 1))
    test(Leaf("z", 1), [Leaf("a", 1), Leaf("b", 1)])
    test(Leaf("z", 1), [])

    test(Node("z", 1, [Leaf("z", 1)]), Leaf("a", 1))
    test(Node("z", 1, [Leaf("z", 1)]), [Leaf("a", 1), Leaf("b", 1)])
    test(Node("z", 1, [Leaf("z", 1)]), [])



# Generated at 2022-06-23 16:05:31.095002
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import DOUBLESLASHEQUAL
    from .pgen2.token import ELLIPSIS
    from .pgen2.token import EQUAL
    from .pgen2.token import LBRACE
    from .pgen2.token import LBRACKET
    from .pgen2.token import LPAR
    from .pgen2.token import NAME
    from .pgen2.token import NUMBER
    from .pgen2.token import PLUSEQUAL
    from .pgen2.token import POWER
    from .pgen2.token import RBRACE
    from .pgen2.token import RBRACKET
    from .pgen2.token import RPAR
    from .pgen2.token import SLASHEQUAL
    from .pgen2.token import VBAREQU

# Generated at 2022-06-23 16:05:41.137764
# Unit test for method post_order of class Node
def test_Node_post_order():
    from blib2to3.pytree import Node
    from blib2to3.pgen2.token import Token
    from .pygram import python_symbols
    token1 = Token("if", python_symbols.if_stmt)
    token2 = Token("(", python_symbols.import_from)
    token3 = Token("i", python_symbols.comp_op)
    token4 = Token("in", python_symbols.import_from)
    token5 = Token("sys.stdin", python_symbols.import_from)
    token6 = Token("):", python_symbols.import_from)
    token7 = Token("\n", python_symbols.import_from)

# Generated at 2022-06-23 16:05:46.158707
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class DummyPattern(BasePattern):
        def match(self, node, r):
            return node.type == 1
    b = DummyPattern(1)
    n = Node(1, [])
    assert b.match_seq([n])
    assert b.match_seq([n, n]) == False
    assert b.match_seq([]) == False



# Generated at 2022-06-23 16:05:53.320389
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    a = Leaf(1, "text")
    assert isinstance(a, Leaf)
    assert a.type == 1
    assert a.value == "text"
    assert a.parent is None
    assert str(a) == "text"
    a.prefix = " "
    assert str(a) == " text"
    a.fixers_applied = ["fixer1"]
    assert str(a) == " text"
    a.fixers_applied = None
    assert str(a) == " text"


# Generated at 2022-06-23 16:05:56.141657
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    try:
        Base().get_lineno()
        assert False
    except NotImplementedError:
        assert True



# Generated at 2022-06-23 16:06:03.811189
# Unit test for method __repr__ of class Node
def test_Node___repr__():

    from .pytree import Node

    n = Node(1, [])
    assert repr(n) == "Node(1, [])"

    assert str(n) == ""

    n = Node(2, [Leaf(3, "foo"), Leaf(3, "bar")])  # type: ignore
    assert repr(n) == "Node(2, [Leaf(3, 'foo'), Leaf(3, 'bar')])"

    assert str(n) == "foobar"



# Generated at 2022-06-23 16:06:10.948005
# Unit test for method replace of class Base
def test_Base_replace():
    from pytree import Leaf
    base = Base()
    base.children = [Leaf(1, 'a'), Leaf(2, 'b'), Leaf(3, 'c')]
    base.children[1].parent = base
    base.children[0].parent, base.children[2].parent = base, base
    base.replace(base.children[:2])
    assert base.children[0].value == 'a'
    assert base.children[1].value == 'b'
    assert len(base.children) == 2


# Generated at 2022-06-23 16:06:16.589810
# Unit test for constructor of class Node
def test_Node():
    ch1 = Leaf(1, "")
    ch2 = Leaf(1, "")
    ch3 = Leaf(1, "")
    n = Node(3, (ch1, ch2, ch3))
    assert len(n.children) == 3
    assert ch1.parent is n
    assert ch2.parent is n
    assert ch3.parent is n



# Generated at 2022-06-23 16:06:19.276273
# Unit test for method append_child of class Node
def test_Node_append_child():
    #Implementation of test case append_child for class Node
    o = Node(1,2, 3, 4)
    o.append_child(child = 5)
    return o


# Generated at 2022-06-23 16:06:23.821315
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    return (
        (
            # Test (1)
            None,
            "",
            (),
            True
        ), (
            # Test (2)
            None,
            "",
            (1,),
            False
        )
    )


# Generated at 2022-06-23 16:06:35.558340
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Leaf
    from .pygram import python_symbols as syms

    l = Leaf(token=1, value="x", context=None)
    assert l.type == 1
    assert l.value == "x"
    l2 = l.clone()
    assert isinstance(l2, Leaf)
    assert l2 is not l
    assert l2.type == 1
    assert l2.value == "x"

    l = Leaf(token=syms.test, value="x", context=None)
    assert l.type == syms.test
    l2 = l.clone()
    assert isinstance(l2, Leaf)
    assert l2 is not l
    assert l2.type == syms.test

    l = Leaf(token=syms.test, value="", context=None)


# Generated at 2022-06-23 16:06:45.161685
# Unit test for method replace of class Base
def test_Base_replace():
    # Construct a single-parented tree to test the functionality
    n1 = Leaf(1, "a")
    n2 = Leaf(2, "b")
    n3 = Leaf(3, "c")
    n4 = Leaf(4, "d")
    n5 = Leaf(5, "e")
    n6 = Leaf(6, "f")
    n7 = Leaf(7, "g")
    n8 = Leaf(8, "h")
    n9 = Leaf(9, "i")

    n1.parent = n2.parent = n3.parent = n4.parent = n7
    n5.parent = n6.parent = n8
    n9.parent = n7.parent = n10 = Node(10, [n7, n8])

    n11 = Leaf(11, "j")
   

# Generated at 2022-06-23 16:06:49.978829
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Node, Leaf
    from .pygram import python_grammar_no_print_statement

    n = Node(python_grammar_no_print_statement.syms.power, [])
    n.set_child(0, Leaf(token.NAME, "foo"))
    assert n.children[0].value == "foo"
    try:
        n.set_child(1, Leaf(token.NAME, "bar"))
    except IndexError as e:
        print(e)


# Generated at 2022-06-23 16:06:57.188009
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    assert BasePattern(1, 2).match_seq([Leaf(1, "2")])
    assert not BasePattern(1, 2).match_seq([Leaf(1, "3")])
    assert not BasePattern(1, 2).match_seq([Leaf(1, ""), Leaf(1, "2")])
    assert not BasePattern(1, 2).match_seq([])

# Generated at 2022-06-23 16:07:02.829666
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # [0]
    # [1]
    # [2]
    # [3]
    q1 = (258, 2, (1,))
    q2 = (257, 1, (q1,))
    q3 = (256, 1, (q2,))
    parser = ParserPython(q3, 0)
    parser.setup([1], None)
    parser.set_root(0)
    pattern = NegatedPattern()
    result = pattern.match_seq([257, 258, 1])
    assert result is False

# Generated at 2022-06-23 16:07:07.232516
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as syms
    from .patcomp import PatternCompiler

    leaf = Leaf(1, ' ')
    leaf.changed()
    assert leaf.was_changed == True



# Generated at 2022-06-23 16:07:15.653178
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import unittest
    import asttokens

    class Test_Leaf_post_order(unittest.TestCase):
        def test_Leaf_post_order(self):
            source = "a + b"
            module, _ = asttokens.ASTTokens(source, parse=True).tree
            atok = asttokens.ASTTokens(source, tree=module)
            first = atok.get_text(module.body[0].value)
            first_leaf = first.node.leaves().__next__()
            result = first_leaf.post_order()
            self.assertEqual([first_leaf], list(result))
    return unittest.TestLoader().loadTestsFromTestCase(Test_Leaf_post_order)


# Generated at 2022-06-23 16:07:20.216436
# Unit test for constructor of class Node
def test_Node():
    n = Node(0, [], None, None)
    assert n.type == 0
    assert n.children == []
    assert n.parent is None
    assert n.was_changed is False
    assert n.was_checked is False
    assert n.fixers_applied is None



# Generated at 2022-06-23 16:07:21.247101
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
   pass  # TODO: Implement test.

# Generated at 2022-06-23 16:07:29.979419
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf

    def assert_equal(a, b):
        from pytest import raises
        if a != b:
            raise raises(AssertionError, f"{a!r} != {b!r}")

    def assert_not_equal(a, b):
        from pytest import raises
        if a == b:
            raise raises(AssertionError, f"{a!r} == {b!r}")

    def assert_is(a, b):
        from pytest import raises
        if a is not b:
            raise raises(AssertionError, f"{a!r} is not {b!r}")

    def assert_is_not(a, b):
        from pytest import raises

# Generated at 2022-06-23 16:07:32.281167
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert not(hasattr(BasePattern, '__new__'))


# Generated at 2022-06-23 16:07:34.734805
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    from .pgen2.token import tok_name

    assert tok_name[256] == "NAME", tok_name[256]



# Generated at 2022-06-23 16:07:42.266726
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import lib2to3.patcomp

    class Leaf(Base):
        __metaclass__ = lib2to3.patcomp.pattern_class_meta(
            "Leaf", (_LeafUtil,), {"_eq"},
        )

        def __init__(self, value: int) -> None:
            self.value = value

        def __str__(self) -> Text:
            return str(self.value)

        def clone(self) -> "Leaf":
            return self

        def post_order(self) -> Iterator["Leaf"]:
            yield self

        def pre_order(self) -> Iterator["Leaf"]:
            yield self

    assert Leaf(1) == Leaf(1)
    assert not (Leaf(1) == Leaf(2))

# Generated at 2022-06-23 16:07:52.409013
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver, parse_string
    from .pgen2 import token

    gr = Driver(convert=convert).grammar

    def _test(s):
        return parse_string(gr, token.OP, s)

    # See also: Grammar.parsing
    assert _test(")") is None
    assert _test("1") == Leaf(token.NUMBER, 1)
    assert _test("(+ 1 2)") == Node(
        gr.symbol2number[")"],
        [
            Leaf(token.OP, "+"),
            Leaf(token.NUMBER, 1),
            Leaf(token.NUMBER, 2),
        ],
    )

# Generated at 2022-06-23 16:07:57.163087
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """
    This function tests the method __repr__ of class Node
    """
    # Initialization
    node = Node(0, [Leaf('a', 1, [1, 2])])
    # Test __repr__
    assert node.__repr__() == 'Node(0, [Leaf(1, (1, 2))])'


# Generated at 2022-06-23 16:07:59.649553
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    _l = Leaf(1, 'a')
    assert list(_l.post_order()) == [_l]


# Generated at 2022-06-23 16:08:06.032315
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    n = Node(3,[Leaf(4, 'cd')],fixers_applied=[3])
    n.prev_sibling_map = {1:2}
    n.next_sibling_map = {2:3}
    n.invalidate_sibling_maps()
    assert n.prev_sibling_map == None and n.next_sibling_map == None


# Generated at 2022-06-23 16:08:08.684212
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    def check(leaf, child):
        assert child is leaf
    leaf = Leaf(0, "")
    leaf.pre_order(check)



# Generated at 2022-06-23 16:08:10.889047
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # simple test case

    # all tests done
    print('test_NegatedPattern_match_seq: all tests done')


# Generated at 2022-06-23 16:08:16.002128
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf

    node = Node(1, [Leaf(1, "one"), Leaf(1, "two")])
    assert list(node.leaves()) == [Leaf(1, "one"), Leaf(1, "two")]
    leaf = node.children[1]
    assert list(leaf.leaves()) == [Leaf(1, "two")]



# Generated at 2022-06-23 16:08:20.790321
# Unit test for method changed of class Base
def test_Base_changed():
    stmt = Node(syms.simple_stmt, [Leaf(1, ""), Leaf(1, "")])
    stmt2 = stmt.clone()
    assert stmt == stmt2
    stmt.changed()
    assert stmt != stmt2



# Generated at 2022-06-23 16:08:29.065751
# Unit test for method __str__ of class Node

# Generated at 2022-06-23 16:08:40.328806
# Unit test for method changed of class Base
def test_Base_changed():
    # Verifies bug #1363761.
    class A(Base):
        def __init__(self, x):
            Base.__init__(self)
            self.x = x
        def _eq(self, other): return self.x == other.x
        def clone(self):
            return A(self.x)

    a1 = A(1)
    a2 = A(2)
    a3 = A(3)
    a4 = A(4)
    a1.child = a3
    a3.parent = a1
    a1.parent = a2
    a2.children = [a1, a4]
    a4.parent = a2
    a1.replace(a4)
    a4.replace(a3)
    assert a3.parent is a4
    assert a

# Generated at 2022-06-23 16:08:44.671252
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # NegatedPattern_match_seq(self, nodes, results) -> bool
    pattern = NegatedPattern(None)
    nodes = [1, 2]
    result = pattern.match_seq(nodes)
    expected = False
    assert result == expected

# Generated at 2022-06-23 16:08:53.227536
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert repr(BasePattern()) == "BasePattern()"
    assert repr(BasePattern(1)) == "BasePattern(1)"
    assert repr(BasePattern(1, 2)) == "BasePattern(1, 2)"
    assert repr(BasePattern(1, 2, 3)) == "BasePattern(1, 2, 3)"
    assert repr(BasePattern(1, name="name")) == "BasePattern(1, name='name')"
    assert repr(BasePattern(1, 2, name="name")) == "BasePattern(1, 2, name='name')"



# Generated at 2022-06-23 16:08:57.211852
# Unit test for method append_child of class Node
def test_Node_append_child():
    node = Node(10, [Leaf(10, "FFF")])
    node.append_child(Leaf(10, "GGG"))
    assert node.children[-1].value == "GGG"
# test_Node_append_child()


# Generated at 2022-06-23 16:08:59.601887
# Unit test for constructor of class Node
def test_Node():
    test_tree = Node(python_symbols.file_input, [])
    assert test_tree.type == python_symbols.file_input



# Generated at 2022-06-23 16:09:04.854908
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    # Default arguments for method
    bp = BasePattern(type=0, content=0, name="")
    # Multiple argument instantiation
    bp = BasePattern(0, 0, "")
    with pytest.raises(AssertionError):
        # Too many arguments
        bp = BasePattern(0, 0, 0, 0)

# Generated at 2022-06-23 16:09:08.530897
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # test one known WildcardPattern optimization case
    w = WildcardPattern(name="a", min=1, max=1, content=[[Leaf(0, "a")]])
    assert isinstance(w.optimize(), NodePattern)


#
# Matcher class
#

# Generated at 2022-06-23 16:09:14.388745
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Node
    n = Node(1, [Node(2), Node(3)])
    n.children[0].remove()
    assert not n.children[0].parent
    assert n.children[0].children == [Node(3)]
    null = object()
    assert n.parent is null
    assert n.children[0].parent is n

_RE = TypeVar("_RE")



# Generated at 2022-06-23 16:09:21.168112
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    """NegatedPattern matches iff argument does not match."""
    p = NegatedPattern(NodePattern(1, [LeafPattern(2), LeafPattern(3)]))
    # Match on .
    assert not p.match(Node(1, []))
    # Match on .[2]
    assert not p.match(Node(1, [Leaf(2)]))
    # Match on .[2, 3]
    assert p.match(Node(1, [Leaf(2), Leaf(3)]))

    # Match on []
    assert p.match_seq([])
    # Match on [2]
    assert not p.match_seq([Leaf(2)])
    # Match on [2, 3]
    assert not p.match_seq([Leaf(2), Leaf(3)])



# Generated at 2022-06-23 16:09:24.520003
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf

    tree = Leaf(0, "foo")
    tree.lineno = 2
    assert tree.get_lineno() == 2

    tree = Leaf(0, "foo")
    tree.lineno = None
    tree.parent = Leaf(0, "bar")
    tree.parent.lineno = 2
    assert tree.get_lineno() == 2



# Generated at 2022-06-23 16:09:34.942536
# Unit test for method clone of class Node
def test_Node_clone():
    print("test_Node_clone")
    import lib2to3.fixer_base
    import lib2to3.fixer_util

    class DummyFix(lib2to3.fixer_base.BaseFix):

        def match(self, node):
            pass

        def transform(self, node, results):
            return

    # Testing the clone method for a node
    # with no children
    dummy_fix = DummyFix("dummy_fix")

# Generated at 2022-06-23 16:09:36.761169
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()

# Generated at 2022-06-23 16:09:40.686745
# Unit test for method set_child of class Node
def test_Node_set_child():
    import ast
    node = ast.parse('p.append(1)')
    node.body[0].value.func.value.attr = 'insert'
    assert str(node) == "p.insert(1)"



# Generated at 2022-06-23 16:09:47.068658
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Node, Leaf, string_repr
    from .pygram import python_symbols as syms

    node = Node(syms.simple_stmt, [Leaf(1, "foo"), Leaf(3, "0.2")])
    node.replace(Leaf(3, "0.5"))
    assert string_repr(node) == "[1,'foo',3,'0.5']"


# pylint: enable=redefined-outer-name

# Generated at 2022-06-23 16:09:55.587580
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    gr = driver.load_grammar("Grammar/Grammar")
    assert isinstance(convert(gr, (1, "", "", "")), Leaf)
    assert isinstance(convert(gr, (1, "a", "", "")), Leaf)
    assert isinstance(convert(gr, (1, "a", None, None)), Leaf)
    assert isinstance(convert(gr, (1, "a", None, ["b"])), Node)
    assert isinstance(convert(gr, (1, "a", None, ["c"])), Leaf)
    assert isinstance(convert(gr, (1, "a", None, ["b", "c"])), Node)



# Generated at 2022-06-23 16:10:02.207758
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    import pprint
    import textwrap
    import unittest
    import string
    import random
    import sys
    import time
    import os

    from lib2to3.pgen2 import token
    from lib2to3.pgen2.grammar import Grammar
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2.driver import Driver, parse_tokens
    from lib2to3 import fixer_base, pytree, pygram
    from lib2to3.pygram import python_grammar_no_print_statement
    from lib2to3.pytree import Leaf, Node
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pygram import python_grammar as src_grammar

    import lib

# Generated at 2022-06-23 16:10:05.775635
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Testing super

    # Testing simple cases
    assert Base() is not None


# Unit tests for method __init__ of class Base

# Generated at 2022-06-23 16:10:12.124640
# Unit test for function generate_matches
def test_generate_matches():
    class MyPattern(BasePattern):
        def __init__(self, count):
            self.count = count
        def generate_matches(self, nodes):
            if self.count > len(nodes):
                return
            yield self.count, None
    p = MyPattern(2)
    for c, r in generate_matches([p], "abcd"):
        break
    assert c == 2, c
    assert r is None, r



# Generated at 2022-06-23 16:10:15.884841
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.pgen import BaseGrammar

    class Grammar(BaseGrammar):

        pass

    g = Grammar()
    g.number2symbol = {1: "foo"}
    pattern = NodePattern(1, ())
    assert pattern.optimize() is pattern
test_BasePattern_optimize()


# Generated at 2022-06-23 16:10:21.630986
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2 import token

    # If the parser encounters a 'print' statement in Python 2, it will turn
    # it into a 'print()' call. Test that we can round-trip this.
    leaf = Leaf(token.NAME, 'print', (
        '', (1, 1)
    ), fixers_applied=['print_function'])
    assert leaf.clone() == leaf


# Generated at 2022-06-23 16:10:29.203094
# Unit test for method pre_order of class Base
def test_Base_pre_order():
  t = Leaf(1, "")
  assert [t] == list(t.pre_order())
  #
  t = Node(2, [Leaf(1, ""), Leaf(3, "")])
  assert [t, t.children[0], t.children[1]] == list(t.pre_order())
  #
  t = Node(2, [Leaf(1, ""), Node(3, [Leaf(4, "")])])
  assert [t, t.children[0], t.children[1], t.children[1].children[0]] == list(t.pre_order())

# Generated at 2022-06-23 16:10:30.772760
# Unit test for method clone of class Base
def test_Base_clone(): pass



# Generated at 2022-06-23 16:10:41.537669
# Unit test for method pre_order of class Node
def test_Node_pre_order():
  from blib2to3.pygram import python_symbols as syms
  from blib2to3.pgen2 import token

  assert list(Node(syms.expr_stmt, []).pre_order()) == [Node(syms.expr_stmt, [])]
  assert list(Node(syms.expr_stmt, [Leaf(token.INTEGER, "10"), Leaf(token.EQ, "=")])
           .pre_order()) == [Node(syms.expr_stmt, [Leaf(token.INTEGER, "10"), Leaf(token.EQ, "=")]), Leaf(token.INTEGER, "10"), Leaf(token.EQ, "=")]


# Generated at 2022-06-23 16:10:42.769968
# Unit test for function convert
def test_convert():
  # The function is tested indirectly by test_driver()
  pass

# Generated at 2022-06-23 16:10:45.189631
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    l = Leaf(1, "abc")
    assert l.__str__() == "abc"

# Generated at 2022-06-23 16:10:56.223254
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf, Node
    from .pygram import python_grammar

    grammar = Grammar(python_grammar)

    root_node = Node(grammar.symbol2number["file_input"], [], prefix="")
    for line_no in range(5):
        leaf = Leaf(
            grammar.token2number["NEWLINE"],
            "\n",
            (str(line_no), (1, line_no + 1)),
        )
        root_node.append_child(leaf)

    assert len(list(root_node.post_order())) == 6
    assert len(list(root_node.pre_order())) == 6

    root_node = Node(grammar.symbol2number["file_input"], [], prefix="")

# Generated at 2022-06-23 16:11:06.662837
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import tok_name
    
    for name in tok_name.keys():
        # only clone the `simple literals`
        if name not in [
            None,
            'false',
            'true',
            'none',
            'ellipsis',
            'suite',
            'finally',
        ]:
            continue
        # testing
        node = Leaf(
            name,
            repr(name),
            (repr(name), (0, 0)),
            prefix='<' + repr(name) + '>',
        )
        copy = node.clone()
        assert node.type == name
        assert node.value == repr(name)
        assert node.prefix == '<' + repr(name) + '>'
        assert node.lineno == 0

# Generated at 2022-06-23 16:11:14.115788
# Unit test for method match of class WildcardPattern

# Generated at 2022-06-23 16:11:15.661994
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert Leaf(1, 'a').pre_order() == (Leaf(1, 'a'),)


# Generated at 2022-06-23 16:11:18.516869
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    assert Leaf(1, "", (1, 1)).get_lineno() == 1

# Generated at 2022-06-23 16:11:23.463722
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_grammar

    n = Node(0,[Leaf(0, '1', (1, 0))])
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None
    n.prev_sibling_map = {0:0}
    n.next_sibling_map = {0:0}
    assert n.prev_sibling_map == {0:0}
    assert n.next_sibling_map == {0:0}
    n.invalidate_sibling_maps()
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None
test_Node_invalidate_sibling_maps()

# Generated at 2022-06-23 16:11:33.693769
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Test a single LeafPattern.
    p = LeafPattern(token.NAME)
    assert p.optimize() is p
    # Test a single NodePattern.
    p = NodePattern(SYMBOL.atom)
    assert p.optimize() is p
    # Test a single WildcardPattern.
    p = WildcardPattern(SYMBOL.atom, 'test', '*')
    assert p.optimize() is p
    # Test a simple pattern with a WildcardPattern
    p1 = LeafPattern(token.NAME)
    p2 = WildcardPattern(SYMBOL.atom, 'test', '*')
    p = AndPattern([p1, p2])
    assert p.optimize() is p
    # Test a WildcardPattern that is optimized away.
    p1 = LeafPattern(token.NAME)

# Generated at 2022-06-23 16:11:45.990903
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import unittest
    from unittest import mock

    class MockNode(object):
        """A mock type for use in testing."""

        def __init__(self, type, content):
            self.type = type
            self.content = content

    class BasePatternTest(unittest.TestCase):
        def test_match_1(self):
            """
            Ensures _submatch method is called and results dict
            is updated when results is not None.
            """
            submatch: mock.MagicMock
            pattern = BasePattern()
            pattern.type = 1
            pattern.content = "foo"
            pattern.name = "bar"

            pattern._submatch = submatch = mock.MagicMock()
            pattern.match(MockNode(1, "foo"), {})

            submatch.assert_called_once

# Generated at 2022-06-23 16:11:57.092081
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    import ast
    from .pgen2 import driver

    gr = driver.load_grammar("Grammar/Grammar")
    gr.optimize()
    # Test optimized pattern for ast.With
    p = ast.With._patterns[0]
    assert p.__class__ is ast.NodePattern
    assert p.name is None
    assert p.content == [("items", [("context_expr", "expr()"), "optional_comma"])]
    assert p.type == gr.number2symbol["with_stmt"]
    # Test optimized pattern for ast.ExceptHandler
    p = ast.ExceptHandler._patterns[0]
    assert p.__class__ is ast.NodePattern
    assert p.name is None