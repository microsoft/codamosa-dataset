

# Generated at 2022-06-23 16:01:55.760048
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    tok_name[1] = 'NAME'
    l = Leaf(1, 'a')
    assert repr(l) == "Leaf(NAME, 'a')"


# Generated at 2022-06-23 16:01:59.320407
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf, Node

    n = Node(1, [])
    n.append_child(Leaf(1, "a"))
    n.append_child(Leaf(1, "b"))
    assert str(n) == "ab"


LeafOrNode = Union["Node", "Leaf"]



# Generated at 2022-06-23 16:02:08.953381
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node
    from .pygram import python_symbols as symbols

    def check_clone(node):
        node2 = node.clone()
        assert node2 == node
        assert repr(node2) == repr(node)
        assert node2.prefix == node.prefix
        assert node2 is not node

    check_clone(Leaf(1, "a"))
    n = Node(symbols.a_stmt, [Leaf(1, "a")])
    check_clone(n)
    n.append_child(Leaf(1, "b"))
    n.insert_child(1, Leaf(1, "c"))
    check_clone(n)

# Generated at 2022-06-23 16:02:11.280578
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    assert not LeafPattern(token.NAME)._submatch(Leaf(token.COMMENT, "comment"))
    assert not LeafPattern(token.NAME)._submatch(Leaf("x", "name"))



# Generated at 2022-06-23 16:02:18.319940
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    from lepl._test.graph.graph import Graph, graph
    from lepl._test.graph.writer import write_png
    from lepl._test.graph.parser import build_parser
    e = graph(write_png('/tmp/test_negpatt.png'))
    p = build_parser(graph=Graph, parser_type=r'lepl.matchers.core.TraceableRegexpMatcher', match_type=r'lepl.matchers.core.RegexpMatch')
    np1 = NegatedPattern(p('(a|b)+'))
    np2 = NegatedPattern(None)
    for match in np1.generate_matches("baba"):
        e("{} {}" . format("match1", match))

# Generated at 2022-06-23 16:02:27.058386
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Node, Leaf
    tree = Node(1, [
        # 1
        Node(2, [
            Leaf(2, "import"),
            Leaf(2, " "),
            Leaf(2, "os"),
            Leaf(2, "\n"),
            Leaf(2, "import"),
            Leaf(2, " "),
            Leaf(2, "sys"),
            Leaf(2, "\n"),
        ]),
        # 2
        Node(2, [
            Leaf(3, "import"),
            Leaf(3, " "),
            Leaf(3, "os"),
            Leaf(3, "\n"),
            Leaf(3, "import"),
            Leaf(3, " "),
            Leaf(3, "sys"),
            Leaf(3, "\n"),
        ])
    ])

    leaves = tree

# Generated at 2022-06-23 16:02:36.647995
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import ast
    import marshal
    from pgen2.grammar import Grammar
    from pgen2.token import *

    grammar = Grammar()
    rule = 'exprlist: expr ("," expr)* [","]'
    grammar.add_rule(rule, ast.exprlist)
    lp = grammar.pattern_parse(rule).children[0].children[0]
    assert lp.type == token.NAME
    assert str(lp) == 'NAME'
    assert lp.match(Leaf(token.NAME, '')) == True
    assert lp.match(Leaf(token.STRING, '')) == False
    assert lp.match(Leaf(token.NAME, '', fixers_applied=[])) == True

# Generated at 2022-06-23 16:02:39.333579
# Unit test for function type_repr
def test_type_repr():
    global _type_reprs
    _type_reprs = {}
    assert type_repr(1) == 1
    assert type_repr(3) == 3



# Generated at 2022-06-23 16:02:45.322839
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    node_symbol = 256
    prefix = ""
    child_symbol = 258
    child_prefix = ""
    n = Node(node_symbol, [Leaf(child_symbol, child_prefix)])
    node_symbol = 257
    child_symbol = 259
    n.set_child(0, Leaf(child_symbol, child_prefix))
    assert n.type == node_symbol
    assert n.children[0].type == child_symbol
    assert n.children[0].prefix == child_prefix


# Generated at 2022-06-23 16:02:55.223409
# Unit test for constructor of class Node
def test_Node():
    from .pytree import Leaf

    st1 = Leaf(1, "asdf")
    st2 = Leaf(1, "qwer")
    st3 = Leaf(1, "zxcv")

    node = Node(257, [st1, st2])
    assert node.children == [st1, st2]
    assert node.type == 257
    assert node.parent is None
    assert node.children[0] is st1
    assert node.children[0].parent is node

    node.append_child(st3)
    assert node.children == [st1, st2, st3]
    assert node.children[1] is st2
    assert node.children[2] is st3
    assert node.children[2].parent is node

    node.insert_child(1, st1)
    assert node.children

# Generated at 2022-06-23 16:02:56.859815
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1,2)
    assert list(l.post_order()) == [l]

# Generated at 2022-06-23 16:03:03.004900
# Unit test for constructor of class Leaf
def test_Leaf():
    """
    >>> import lib2to3.pytree
    >>> t = lib2to3.pytree.Leaf(1, u"a")
    >>> type(t)
    <class 'lib2to3.pytree.Leaf'>
    >>> str(t)
    'a'
    >>> t = lib2to3.pytree.Leaf(1, u"a", u"b")
    >>> str(t)
    'ba'
    >>> t = lib2to3.pytree.Leaf(1, u"a", (1, 2))
    >>> t.lineno, t.column
    (1, 2)
    """



# Generated at 2022-06-23 16:03:10.822661
# Unit test for method clone of class Node
def test_Node_clone():
    import inspect
    import ast
    import sys
    import pickle
    from unittest import TestSuite, TestCase

    from typing import Iterator, Set, Tuple

    from .pytree import Leaf, Node, InternalStr
    from .pygram import python_symbols
    from .pygram import python_grammar
    from .parse import Parser

    class _TestNodeClone(TestCase):

        # Create a set of test cases
        def create_cases(self):
            # type: () -> Iterator[Tuple[Leaf, Leaf]]
            parser = Parser(python_grammar)

# Generated at 2022-06-23 16:03:21.111673
# Unit test for method set_child of class Node
def test_Node_set_child():
    def test_Node_set_child_0():
        class my_cls_Node_0(Node):
            def __init__(self, name, lineno, column):
                self.name = name
                self.lineno = lineno
                self.column = column
                self.parent = None
                self.children = [ ]
                self.was_changed = False
                self.was_checked = False
        obj_ = my_cls_Node_0(name='', lineno=0, column=0)
        obj_.set_child(0, child=0)
    def test_Node_set_child_1():
        class my_cls_Node_1(Node):
            def __init__(self, name, lineno, column):
                self.name = name
                self.lineno = lineno
               

# Generated at 2022-06-23 16:03:25.708711
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    # Variables
    mock_child = Leaf(1, 'text')
    mock_node = Node(1, [])
    mock_i = 1

    mock_node.insert_child(mock_i, mock_child)

# Test function for Node.insert_child()

# Generated at 2022-06-23 16:03:35.981526
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    """Test the WildcardPattern.generate_matches method."""
    import doctest
    import sys
    # The doctest module scans this module looking for docstrings, and
    # then executes them as tests.  Here, we only want the test in the
    # class above, so we tell doctest to scan just the class.  Note
    # that the class, if created here, won't have the necessary code
    # for the optimize method.  So we create the class after importing
    # and freezing bytecode.
    from . import grammar

    # Py3 doesn't have doctest.OutputChecker as a separate class, so we
    # can't subclass it.  Instead, we define default_checker in the
    # doctest module to be our subclass, and it will be used for all
    # doctests.

# Generated at 2022-06-23 16:03:39.366415
# Unit test for method depth of class Base
def test_Base_depth():
    b = Base()
    assert b.depth() == 0
    a = Base()
    b.parent = a
    assert b.depth() == 1
    a.parent = Base()
    assert b.depth() == 2


# Generated at 2022-06-23 16:03:47.636756
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Node, Leaf
    from .pgen2 import token
    from . import pytoken

    n = Node(111, children=[])
    n.changed()

    n.changed()
    # n.changed()
    n.changed()

    l = Leaf(1, "2", (1, 0))
    l.changed()
    l.changed()

    l = Leaf(pytoken.NAME, "a", (3, 0))
    l.changed()
    l.changed()
    l.changed()



# Generated at 2022-06-23 16:03:52.583937
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    wcp = WildcardPattern(min=1,max=1)
    assert wcp.match(
        Node(0, NL(Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c')), NL(Leaf(1, '1'), Leaf(1, '2'), Leaf(1, '3')))
    )
    assert not wcp.match(Leaf(1, 'a'))
    assert not wcp.match(Node(1, NL(Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c')), NL(Leaf(1, '1'), Leaf(1, '2'), Leaf(1, '3'))))

# Generated at 2022-06-23 16:03:58.400192
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # "." matches any single node
    p1 = WildcardPattern()
    assert p1.optimize() == NodePattern()
    # "a b c" matches a sequence of exactly three nodes, with contents "a",
    # "b" and "c"
    p2 = WildcardPattern([[Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]])
    assert p2.optimize() == WildcardPattern([[Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]])
    # "(a b | c d)" matches either "a b" or "c d"
    p3 = WildcardPattern([[Leaf(1, "a"), Leaf(1, "b")], [Leaf(1, "c"), Leaf(1, "d")]])

# Generated at 2022-06-23 16:04:07.005569
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import token
    from .pgen2.driver import Driver

    driver = Driver(convert, [])
    grammar = driver.load_grammar("Grammar/Grammar")

    tree = driver.parse(
        """
    float
    double
    char
    int
    unsigned
    long
    short
    """,
        "simple_stmt",
        grammar,
    )

    idpat = NodePattern(token.NAME)
    r: _Results = {}
    assert next(idpat.generate_matches(list(tree.leaves())), None) == (1, r)
    assert r["id"].type == token.NAME
    assert r["id"].value == "float"



# Generated at 2022-06-23 16:04:15.987042
# Unit test for method post_order of class Base
def test_Base_post_order():
    import ast
    py3_code = "print(1)"
    tree = ast.parse(py3_code)
    s = [node.__class__.__name__ for node in tree.post_order()]
    assert "Module" in s
    assert "Expr" in s
    assert "Call" in s
    assert "Name" in s
    assert "Load" in s
    assert "Num" in s
    assert s.index("Expr") < s.index("Call")
    assert s.index("Call") < s.index("Name")
    assert s.index("Name") < s.index("Load")
    assert s.index("Load") < s.index("Num")



# Generated at 2022-06-23 16:04:19.618726
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    assert NegatedPattern().match_seq([])
    assert not NegatedPattern().match_seq([1, 2, 3])


# Generated at 2022-06-23 16:04:25.311235
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    assert BasePattern(NUMBER).match_seq([Leaf(NUMBER)])
    assert BasePattern(NUMBER).match_seq([Leaf(STRING)]) == False
    assert BasePattern().match_seq([Leaf(NUMBER)])


#
#  +------------------------+
#  |                        |
#  |   WildcardPattern      |
#  |                        |
#  +------------------------+
#



# Generated at 2022-06-23 16:04:27.590403
# Unit test for constructor of class Leaf
def test_Leaf():
    Leaf(1, "a")
    Leaf(1, "a", prefix=" ")


# Generated at 2022-06-23 16:04:33.401402
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    b = Node(
        1,
        [
            Leaf(1, ""),
            Node(
                1,
                [
                    Leaf(1, ""),
                    Leaf(1, ""),
                    Leaf(1, ""),
                ],
            ),
            Leaf(1, ""),
        ],
    )
    b.invalidate_sibling_maps()


# Generated at 2022-06-23 16:04:34.754007
# Unit test for method depth of class Base
def test_Base_depth():
    class node(Base):
        type = 1
        children = [2, 3, 4]
        parent = 5
        was_changed = True
        was_checked = True
    assert node().depth() == 1



# Generated at 2022-06-23 16:04:40.240962
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pytree import Leaf
    node = Node(1, [], None, b"test")
    leaf = Leaf(None, 1, None)
    for i in range(4):
        node.insert_child(i, leaf)



# Generated at 2022-06-23 16:04:45.952929
# Unit test for constructor of class Node
def test_Node():
    class DummyLeaf(Text):
        pass

    test_input = '"spam" "eggs" "toast"'
    test_tokens = []
    for token in test_input.split():
        n = DummyLeaf(token)
        test_tokens.append(n)
    node = Node(python_symbols.testlist, test_tokens)
    assert node.type == python_symbols.testlist
    assert node.children[0].prefix == ""



# Generated at 2022-06-23 16:04:56.933150
# Unit test for method __str__ of class Node
def test_Node___str__():
    import pgen2.driver
    from .pytree import convert
    from .pygram import python_symbols
    from .pygram import python_grammar_no_print_statement
    pytree = convert("1 + 1")
    driver = pgen2.driver.Driver(python_grammar_no_print_statement, convert=0)
    assert str(pytree) == "1 + 1"
    tree = driver.parse_tokens(pytree.leaves())
    assert str(tree) == "1 + 1"
    pytree = convert("1 + 1")
    pytree.children[0].prefix = " "
    tree = driver.parse_tokens(pytree.leaves())
    assert str(tree) == " 1 + 1"
    pytree = convert("1 + 1")

# Generated at 2022-06-23 16:05:00.373205
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base() == Base()
    Base() == 1
    repr(Base())
    str(Base()) == "<test_Base.test_Base___new__.<locals>.B instance at 0x7ff5435c6830>"
    hash(Base)
    Base() != Base()
    Base() != 1


# Generated at 2022-06-23 16:05:10.060019
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    a = WildcardPattern([("a",)])
    assert a.min == 1
    assert a.max == 1
    assert a.content == (("a",),)

    a = WildcardPattern([("a",), ("b",)])
    assert a.min == 1
    assert a.max == 1
    assert a.content == (("a",), ("b",))

    a = WildcardPattern(["a", "b", "c"])
    assert a.min == 1
    assert a.max == 1
    assert a.content == (("a",), ("b",), ("c",))

    a = WildcardPattern(["a", "b", "c"], 0)
    assert a.min == 0
    assert a.max == 1
    assert a.content == (("a", "b", "c"),)

   

# Generated at 2022-06-23 16:05:15.215631
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """Unit test for method '__new__' of class BasePattern."""
    try:
        bp = BasePattern()
    except NotImplementedError:
        pass
    else:
        assert False, "Failed to raise NotImplementedError"



# Generated at 2022-06-23 16:05:25.446150
# Unit test for method clone of class Node
def test_Node_clone():
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.token import (
        NAME,
        WHITESPACE,
        NEWLINE,
        INDENT,
        DEDENT,
    )

    # Make a tree: a = 'foo'
    a = Leaf(NAME, "a")
    eql = Leaf(NAME, "=")
    a.prefix = ' '
    eql.prefix = ' '
    q = Leaf(NAME, "'")
    oo = Leaf(NAME, "foo")
    q.prefix = "'"
    oo.prefix = ' '
    a.next_sibling = eql
    eql.next_sibling = q
    q.next_sibling = oo

    # Make a tree: b = 'bar'
   

# Generated at 2022-06-23 16:05:27.972215
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    n = Base()
    n.type = 1
    n.parent = None
    n1 = Base()
    n1.type = 1
    n1.parent = None
    assert n == n1

# Generated at 2022-06-23 16:05:32.922618
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    """
    >>> a = Leaf(1, "x")
    >>> b = Leaf(2, "y")
    >>> c = Leaf(3, "z")
    >>> print([x for x in a.pre_order()])
    [Leaf(1, 'x')]
    >>> print([x for x in b.pre_order()])
    [Leaf(2, 'y')]
    >>> print([x for x in c.pre_order()])
    [Leaf(3, 'z')]
    """



# Generated at 2022-06-23 16:05:42.889058
# Unit test for method clone of class Node
def test_Node_clone():
    """
    Test that a cloned tree can be pretty-printed and the result
    is the same as the original source.
    """
    import re
    import sys
    from os import path
    this_file = path.split(path.abspath(__file__))[1]
    this_module = this_file.rsplit(".", 1)[0]
    err = StringIO()
    from .pgen2 import driver
    from .parse import Parser

    grammar = driver.load_grammar(
        "",  # no Python source
        "",  # no grammar source
        err,
        optimize=1,
        build_parser=False,
    )
    if err.getvalue():
        raise AssertionError(err.getvalue())
    p = Parser(grammar, convert=converter)


# Generated at 2022-06-23 16:05:45.031399
# Unit test for method changed of class Base
def test_Base_changed():
    b = Base()
    assert not b.was_changed
    b.changed()
    assert b.was_changed


# Generated at 2022-06-23 16:05:50.905268
# Unit test for method set_child of class Node
def test_Node_set_child():
    greeter = Node(1,[Leaf(2,"Hello",None,None),Leaf(3,None,None,None),Leaf(4,None,None,None)])
    greeter.set_child(2,Leaf(4,"Hi",None,None))
        #assert was_checked == False
    assert greeter.children[2].type == 4
    assert greeter.children[2].value == "Hi"

# Generated at 2022-06-23 16:05:54.662259
# Unit test for method __str__ of class Node
def test_Node___str__():
    from .pygram import python_grammar
    from .pgen2 import driver

    d = driver.Driver(python_grammar, convert=pytree.convert)
    g = d.parse_string("a = 1 + 2\n")
    assert str(g) == "a = 1 + 2\n"


# Generated at 2022-06-23 16:05:56.389156
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    obj = BasePattern(None, None)
    if isinstance(obj, BasePattern):
        obj.optimize()



# Generated at 2022-06-23 16:06:07.156731
# Unit test for method leaves of class Base
def test_Base_leaves():
    from blib2to3.pytree import Leaf, Node
    from copy import deepcopy
    # Test 1
    t = Leaf(1, "hello")
    assert list(t.leaves()) == [t]
    # Test 2
    t = Node(1, [])
    assert list(t.leaves()) == []
    # Test 3
    t = Node(1, [])
    t.append_child(Leaf(2, "hello"))
    t.append_child(Leaf(2, "goodbye"))
    assert list(t.leaves()) == [Leaf(2, "hello"), Leaf(2, "goodbye")]
    # Test 4
    t = Node(1, [])
    t.append_child(Node(2, []))

# Generated at 2022-06-23 16:06:08.391073
# Unit test for method post_order of class Base
def test_Base_post_order():
    pass


# Generated at 2022-06-23 16:06:09.501251
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    subclasses = [LeafPattern, NodePattern, WildcardPattern]
    for subclass in subclasses:
        bp = BasePattern()



# Generated at 2022-06-23 16:06:11.942685
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(token.NAME, 'x')
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-23 16:06:16.028398
# Unit test for method append_child of class Node
def test_Node_append_child():
    node = Node(5, [Leaf(5, 'abc', (1, 5))])
    node.append_child(Leaf(5, '5', (1, 7)))
    assert node.children[1].value == '5'



# Generated at 2022-06-23 16:06:20.923170
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Symbol

    Symbol("X")
    bp = BasePattern()
    bp.type = Symbol("X")

    # Check that optimize() throws exception
    with raises(NotImplementedError):
        bp.optimize()

    # Check that the type attribute gets set correctly
    bp.type = 2
    assert bp.type == 2



# Generated at 2022-06-23 16:06:28.614115
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    """
    This is a hack to create the Leaf class as a scope.
    Leaf is a nested class, and is thus not in scope at the module level.
    """
    class FakeLeaf(Leaf):
        pass
    t = FakeLeaf(0, '+')
    p = FakeLeaf(0, '-')
    m = Node(258, [p, t])
    l = Leaf(258, '', prefix=' ')
    assert list(l.pre_order()) == [l]
    assert list(p.pre_order()) == [p]
    assert list(t.pre_order()) == [t]
    assert list(m.pre_order()) == [m, p, t]


# Generated at 2022-06-23 16:06:29.863634
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    test_pattern = WildcardPattern(content=((((LeafPattern(),)),),), name="name")
    assert test_pattern.match_seq([Leaf()])

# Generated at 2022-06-23 16:06:31.952347
# Unit test for method post_order of class Base
def test_Base_post_order():
    try:
        Base().post_order()
        raise AssertionError
    except NotImplementedError:
        pass


# Generated at 2022-06-23 16:06:41.996782
# Unit test for function generate_matches
def test_generate_matches():
    s = "a b c d e f g h i j"
    patterns = [
        [
            NodePattern("a"),
            NodePattern("b"),
            NodePattern("c"),
            NegatedPattern(
                [
                    NodePattern("b"),
                    NodePattern("c"),
                    NodePattern("d"),
                    NodePattern("e"),
                ]
            ),
            NodePattern("d"),
            NodePattern("e"),
        ],
        [
            NegatedPattern(
                [
                    NodePattern("e"),
                    NodePattern("f"),
                    NodePattern("g"),
                    NodePattern("h"),
                ]
            ),
            NodePattern("f"),
            NegatedPattern(
                [NodePattern("h"), NodePattern("i"), NodePattern("j")]
            ),
        ],
    ]

# Generated at 2022-06-23 16:06:44.684438
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    assert Leaf(1, "").depth() == 0
    assert Leaf(1, "").clone().depth() == 0

# Generated at 2022-06-23 16:06:47.524452
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.classdef) == "classdef"
    assert type_repr(255) == 255


_symbol_reprs: Dict[Union[Text, int], Union[Text, int]] = {}



# Generated at 2022-06-23 16:06:52.923152
# Unit test for method post_order of class Node
def test_Node_post_order():
    node1 = Node(257, [])
    node2 = Node(257, [])
    node3 = Node(257, [])

    node1.changed()
    node1.changed()


# Generated at 2022-06-23 16:06:59.856105
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    x = NodePattern(type=1, name="x")
    y = NodePattern(type=2, name="y")
    z = NodePattern(type=3, name="z")
    w = WildcardPattern(content=[[x, y], [z]], name="w")
    nodes = [Node(1), Node(2), Node(3), Node(3), Node(1), Node(2), Node(3)]
    assert w.match_seq(nodes) == True


# Generated at 2022-06-23 16:07:10.656581
# Unit test for method post_order of class Base
def test_Base_post_order():
    class Node(Base):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.children = []

    root = Node()
    child1 = Node()
    child2 = Leaf(2, "a")
    child3 = Leaf(4, "b")
    child4 = Leaf(1, "c")
    root.children.append(child1)
    root.children.append(child2)
    child1.children.append(child3)
    child1.children.append(child4)

    assert list(root.post_order()) == [child4, child3, child1, child2, root]
    assert list(child1.post_order()) == [child4, child3, child1]

# Generated at 2022-06-23 16:07:18.315454
# Unit test for function generate_matches
def test_generate_matches():
    from . parse import parse, Node

    def gen(patterns, nodes):
        # From the documentation:
        #  Yields:
        #    (count, results) tuples where:
        #    count: the entire sequence of patterns matches nodes[:count];
        #    results: dict containing named submatches.
        for count, results in generate_matches(patterns, nodes):
            assert count <= len(nodes), 'count=%s, len(nodes)=%s' % (count, len(nodes))
            assert count == len(nodes) or results == {}, str((count, results, nodes[count:]))
            yield count, results


# Generated at 2022-06-23 16:07:27.258051
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.token import tok_name
    leaf = Node(257, [], context=(
        '', (1, 0)), prefix='')
    assert leaf.parent is None
    assert leaf.type == 257
    assert not leaf.children
    assert leaf.context == ('', (1, 0))
    assert leaf.prefix == ''
    leaf.parent = 'parent'
    assert leaf.parent == 'parent'
    assert leaf.type == 257
    assert not leaf.children
    assert leaf.context == ('', (1, 0))
    assert leaf.prefix == ''
    leaf.type = 258
    assert leaf.type == 258
    assert not leaf.children
    assert leaf.context == ('', (1, 0))
    assert leaf.prefix == ''
    leaf.children = 'children'

# Generated at 2022-06-23 16:07:37.716530
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import unittest
    import pickle
    import tempfile

    class TestWildcardPattern(unittest.TestCase):
        def test_match_seq(self):
            # Issue #133: WildcardPattern.match_seq() fails when called
            # twice.
            p1 = WildcardPattern()
            p2 = WildcardPattern()

            with tempfile.TemporaryDirectory() as tempdir:
                with open(os.path.join(tempdir, "test.pickle"), "wb") as f:
                    pickle.dump(p1, f)
                with open(os.path.join(tempdir, "test.pickle"), "rb") as f:
                    p1 = pickle.load(f)


# Generated at 2022-06-23 16:07:38.931927
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()  # TypeError: Cannot instantiate Base



# Generated at 2022-06-23 16:07:44.865940
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    def check(A, B):
        assert list(A.pre_order()) == list(B.pre_order())

    def n(type, children, **kwds):
        return Node(type, children, **kwds)

    def l(type, value, **kwds):
        return Leaf(type, value, **kwds)

    check(
        n(1, [n(2, []), n(3, [n(4, []), l(5, "bbb"), l(6, "ccc")])]),
        n(1, [n(2, []), n(3, [l(5, "aaa"), n(4, []), l(6, "ccc")])], prefix="aaa"),
    )



# Generated at 2022-06-23 16:07:53.729946
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # test Star & StarStar for bare_name
    pattern = WildcardPattern(
        content=[
            [
                Leaf(1, "a"),
                Leaf(1, "b"),
                Leaf(1, "c"),
            ],
            [
                Leaf(1, "d"),
                Leaf(1, "e"),
            ],
            [
                Leaf(1, "f"),
                Leaf(1, "g"),
                Leaf(1, "h"),
            ],
        ], name="bare_name",
    )
    expected = [(2, {}), (2, {'bare_name': [Leaf(1, 'a'), Leaf(1, 'b')]}), (3, {'bare_name': [Leaf(1, 'a'), Leaf(1, 'b'), Leaf(1, 'c')]})]
    assert list

# Generated at 2022-06-23 16:07:54.351256
# Unit test for method match of class NegatedPattern

# Generated at 2022-06-23 16:08:06.032150
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # Test for empty pattern object
    p = NegatedPattern()
    assert p.content is None
    assert p.match(None) == False
    assert p.match_seq([]) == True
    assert list(p.generate_matches([])) == [(0, {})]
    assert p.match_seq(["a"]) == False
    assert list(p.generate_matches(["a"])) == []
    # Test for non-empty pattern object
    p = NegatedPattern(NodePattern(None, [LeafPattern('a')], 'a_leaf'))
    assert isinstance(p.content, NodePattern)
    assert p.match(None) == False
    # Test generation of matches
    assert list(p.generate_matches([])) == [(0, {})]

# Generated at 2022-06-23 16:08:09.444251
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    lp = LeafPattern(type=1, content="A")
    l = Leaf(1, "A")
    assert lp.match(l)



# Generated at 2022-06-23 16:08:10.024672
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    assert True  # Used when testing abstract base class



# Generated at 2022-06-23 16:08:19.005309
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    """Unit test for method pre_order of class Base"""
    from .python_tree import PythonNode

    loc = (1, None)
    node = PythonNode(
            "node",
            ("1", "2", "3", "4", "5"),
            prefix="",
            context_str="",
            context_expr=loc)
    assert node.children[0].prefix == "1"
    assert node.children[4].prefix == "5"
    assert node.children[4].next_sibling is None
    assert node.children[4].prev_sibling.prefix == "4"
    assert node.children[0].next_sibling.prefix == "2"
    assert node.children[0].prev_sibling is None

    # Compute and test pre_order.

# Generated at 2022-06-23 16:08:23.884184
# Unit test for constructor of class Node
def test_Node():
    # test constructor
    n1 = Node(256, [])
    n2 = Node(256, [])
    assert n1 == n2
    assert n1.type == 256
    assert n1.parent is None
    assert str(n1) == ""
    assert repr(n1) == "Node(256, [])"



# Generated at 2022-06-23 16:08:29.604913
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import types
    import sys

    def test(nodes: List[Union[Leaf, Node]], ordered: List[Union[Leaf, Node]]) -> bool:
        for node in nodes:
            if node.type == 1:
                node.type = 256
        for node in ordered:
            if node.type == 1:
                node.type = 256
        for node in nodes:
            for child in node.children:
                if child.type == 1:
                    child.type = 256
        for node in ordered:
            for child in node.children:
                if child.type == 1:
                    child.type = 256
        import pytest
        from .pgen2.pgen import tokenizer
        from .pgen2.parse import Parser as NewParser
        from .ast import parseFile as NewParseFile


# Generated at 2022-06-23 16:08:34.277840
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    # Create a Leaf instance
    from .pgen2.token import LPAR, RPAR, NAME
    leaf = Leaf(LPAR, "(", fixers_applied=[])
    leaf.parent = Node(NAME, [leaf, Leaf(RPAR, ")", fixers_applied=[])])
    # Test the method
    assert str(leaf.clone())=="("



# Generated at 2022-06-23 16:08:41.618290
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Create the AST for 'a = 1 + 2\n'
    root = Node(python_symbols.file_input, [
        Node(python_symbols.stmt, [
            Leaf(token.EQUAL, '=', (1, 0)),
            Node(python_symbols.testlist, [
                Leaf(token.NAME, 'a', (1, 0)),
            ]),
            Leaf(token.PLUS, '+', (1, 4)),
            Node(python_symbols.testlist, [
                Leaf(token.NUMBER, '1', (1, 6)),
            ]),
            Leaf(token.NEWLINE, '\n', (1, 7)),
        ]),
    ])
    result = list(root.post_order())

# Generated at 2022-06-23 16:08:53.264326
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pytree import Leaf
    from .pygram import python_symbols
    from io import StringIO
    from unittest.mock import patch

    class MyFakeStdOut(StringIO):
        def __init__(self):
            self.content = ''

        def write(self, val):
            self.content += str(val)

        def get_content(self):
            return self.content

    old_stdout = sys.stdout
    fake_stdout = MyFakeStdOut()
    sys.stdout = fake_stdout

    node1 = Node(python_symbols.funcdef, [])
    node2 = Leaf(1, 'string')
    node1.insert_child(0, node2)
    node2.parent = node1  # Shouldn't need to set node2.parent

# Generated at 2022-06-23 16:09:02.031573
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    cls = Node
    node = object.__new__(cls)
    node.type = 256
    node.children = [Leaf(0, "with", (1, 0), "", None), Leaf(0, "a", (1, 4), "", None), Leaf(0, "bunch", (1, 6), "", None), Leaf(0, "of", (1, 12), "", None), Leaf(0, "text", (1, 14), "", None)]
    node.fixers_applied = None

# Generated at 2022-06-23 16:09:07.652385
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    n = LeafPattern(4, "foo")
    assert n.type == 4
    assert n.content == "foo"
    assert n.name is None
    n = LeafPattern(4, "foo", "bar")
    assert n.type == 4
    assert n.content == "foo"
    assert n.name == "bar"



# Generated at 2022-06-23 16:09:17.854540
# Unit test for method clone of class Node
def test_Node_clone():
    (type_, type_children) = (256, [(Leaf(0, 'a'),), (Leaf(1, 'b'),)])
    obj = Node(type_, type_children)
    result = []
    # check obj
    assert obj.clone() == obj
    assert repr(obj) == "Node(256, [(Leaf(0, 'a'),), (Leaf(1, 'b'),)])"
    assert str(obj) == "ab"
    assert obj.next_sibling is None
    assert obj.prev_sibling is None
    assert obj.was_checked == False
    for i in obj.post_order():
        result.append(repr(i))

# Generated at 2022-06-23 16:09:29.479283
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from lib2to3 import pgen2
    from lib2to3.pgen2.token import NUMBER
    from lib2to3.pgen2 import driver
    from lib2to3.pygram import python_symbols
    from lib2to3.pytree import Leaf
    from lib2to3.pytree import Node
    from lib2to3.pytree import type_repr
    from logilab.common.testlib import TestCase, unittest_main
    from StringIO import StringIO
    reload(pgen2)
    reload(driver)
    reload(python_symbols)
    reload(Leaf)
    reload(Node)

    # Testing Node.__repr__
    # XXX Do not compare reprs they changed recently

# Generated at 2022-06-23 16:09:39.068567
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    import unittest

    class Test_WildcardPattern_match(unittest.TestCase):
        def test1(self):
            data = "ABC\nDE"
            pat = WildcardPattern(None, min=1, max=1)
            self.assertTrue(pat.match(Leaf(token.NAME, "ABC")))
            self.assertTrue(pat.match(Leaf(token.NAME, "DE")))
            self.assertFalse(pat.match(Leaf(token.NAME, "ABCDE")))
            self.assertFalse(pat.match(Node(syms.file_input, [Leaf(token.NAME, "DE")])))
            self.assertFalse(pat.match(Leaf(token.NAME, "abc")))

# Generated at 2022-06-23 16:09:46.597951
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import driver

    gr = driver.load_grammar("Python.asdl")
    test_BasePattern_generate_matches.funcdef = gr.symbol2number["funcdef"]
    p = LeafPattern(test_BasePattern_generate_matches.funcdef)
    matches = [m for m in p.generate_matches([])]
    assert matches == []
test_BasePattern_generate_matches()
test_BasePattern_generate_matches.funcdef = None



# Generated at 2022-06-23 16:09:49.151546
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    try:
        b.children = []
        assert False, "Base() did not raise TypeError"
    except TypeError:
        pass



# Generated at 2022-06-23 16:09:57.587629
# Unit test for function generate_matches
def test_generate_matches():

    def pp(generator):
        return tuple(generator)

    def ppall(seq):
        return tuple(tuple(i) for i in seq)

    assert pp(generate_matches([], [])) == ()
    assert pp(generate_matches([], [T(1)])) == ()
    assert pp(generate_matches([T(1)], [])) == ()
    assert pp(generate_matches([T(1)], [T(2)])) == ()
    assert pp(generate_matches([T(1)], [T(1)])) == ((1, {}),)
    assert ppall(generate_matches([DotPattern(1)], [T(1), T(1)])) == ((1, {}),)

# Generated at 2022-06-23 16:10:03.096641
# Unit test for method leaves of class Base
def test_Base_leaves():
    from lib2to3.pgen2.token import Name, String
    from .pytree import Leaf, Node
    n = Node(python_symbols.file_input, [
        Node(python_symbols.stmt, [
            Node(python_symbols.simple_stmt, [
                Leaf(Name, "x"),
                Leaf(Name, "="),
                Node(python_symbols.testlist, [
                    Node(python_symbols.test, [
                        Leaf(String, "'a'")]
                    )
                ])
            ])
        ])
    ])
    leaves = "".join(map(str, n.leaves()))
    assert leaves == "x='a'"



# Generated at 2022-06-23 16:10:13.576668
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.token import tok_name, NUMBER, STRING, NAME

    leaf = Leaf(NUMBER, "1", (b"prefix", (0, 0)), fixers_applied=[])
    assert next(leaf.post_order()) == leaf, leaf.post_order()
    try:
        next(leaf.post_order())
    except StopIteration:
        pass
    else:
        raise AssertionError
    leaf = Leaf(NUMBER, "1", (b"prefix", (0, 0)), fixers_applied=[])
    assert str(leaf) == "prefix1"
    assert repr(leaf) == "Leaf(NUMBER, '1')"

# Generated at 2022-06-23 16:10:21.525761
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    tok = Leaf(1, "abc")
    tok.prefix = "  "
    tok.lineno = 3
    tok.column = 4
    tok.fixers_applied = ["f1", "f2"]
    clone = tok.clone()
    assert tok == clone
    assert tok.prefix == clone.prefix
    assert tok.lineno == clone.lineno
    assert tok.column == clone.column
    assert tok.fixers_applied == clone.fixers_applied

# Generated at 2022-06-23 16:10:30.233067
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    n = Symbol(0, None, None, [])
    n.children = [Leaf(1, 'a', (1, 0), None)]
    assert n.get_lineno() == 1

    n1 = Symbol(0, None, None, [])
    n1.children = [Leaf(1, 'a', (1, 0), None)]

    n2 = Symbol(0, None, None, [])
    n2.children = [n1]

    assert n2.get_lineno() == 1

    l = Leaf(1, 'a', (1, 0), None)
    assert l.get_lineno() == 1

    m = Symbol(0, None, None, [])
    m.children = [n1, n2]

    assert m.get_lineno() == 1

    # TODO:

# Generated at 2022-06-23 16:10:33.538631
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    bp = BasePattern()
    bp.match_seq([], None)
    bp.match_seq([Leaf('1', 'a')], None)

# Generated at 2022-06-23 16:10:42.024883
# Unit test for method clone of class Node
def test_Node_clone():
    assert Node(256, []).clone() == Node(256, [])
    assert Node(256, [Leaf(257, 'hello')]).clone() == Node(256, [Leaf(257, 'hello')])
    a1 = Node(256, [Leaf(257, 'hello')])
    a2 = Node(256, [Leaf(257, 'hello')])
    assert a1.clone() == a2
    assert a1.clone() is not a2
    assert a1.clone().children[0] is not a2.children[0]


# Generated at 2022-06-23 16:10:53.649398
# Unit test for method post_order of class Node
def test_Node_post_order():
    n = Node(33, [Leaf(1, "hello"), Leaf(1, "\n"), Leaf(1, "world")])
    assert tuple(x.value for x in n.post_order()) == ("hello", "\n", "world", "\n")
    assert [x.parent for x in n.post_order()] == [n, n, n, None]
    for x in n.post_order():
        if isinstance(x, Leaf):
            assert x.lineno == 1
        elif isinstance(x, Node):
            assert x.type == 33
try:
    test_Node_post_order()
except:
    print("test_Node_post_order() failed")
    import traceback
    traceback.print_exc()


# Generated at 2022-06-23 16:11:02.612657
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    import unittest
    import blib2to3.pytree as pytree
    import StringIO
    root = pytree.Node(1, [pytree.Leaf(2, "hello", [4, 4], prefix=" "),
                           pytree.Leaf(1, "world", [4, 4])])
    new_leaf = pytree.Leaf(2, "!", [4, 4])
    root.insert_child(1, new_leaf)
    assert root.type == 1
    assert root.children[0].value == "hello"
    assert root.children[0].type == 2
    assert root.children[1].value == "!"
    assert root.children[1].type == 2
    assert root.children[2].value == "world"
    assert root.children[2].type == 1

# Generated at 2022-06-23 16:11:12.426423
# Unit test for method remove of class Base
def test_Base_remove():
    global parent
    global children
    global was_changed
    global was_checked
    global NL
    global Context
    global RawNode
    node_inst = Base()
    node_inst.children = [1, 2, 3]
    node_inst.parent = 'Node'
    node_inst.remove()
    assert node_inst.__class__ is not Base, "Cannot instantiate Base"
    assert node_inst.parent is None
    assert node_inst.children == [1, 2, 3]



# Generated at 2022-06-23 16:11:18.920918
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pgen2.tokenize import tokenize_initialize, untokenize
    from .pygram import python_symbols
    from .pgen2 import token
    tokenize_initialize()
    f, _ = untokenize(tokens)
    grammar = Grammar(StringIO(f.read()))

    n = grammar.p_node_or_leaf(0, python_symbols.stmt)
    def _check_maps():
        if n.prev_sibling_map is None:
            return
        assert sorted(n.prev_sibling_map.items()) == [(id(child), None)
                                                      for child in n.children]
        assert sorted(n.next_sibling_map.items()) == [(id(child), None)
                                                      for child in n.children]
   

# Generated at 2022-06-23 16:11:23.720650
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    # I have no idea how to test this.

    # this will fail unless the calling code sets up the lineno
    # attribute correctly.
    test_node = Base()
    test_node.lineno = 0

    assert test_node.get_lineno() == 0



# Generated at 2022-06-23 16:11:28.625888
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    p = Python3Parser(Grammar(), convert=True)
    src = "1+2"
    node = p.parse(src)
    node.update_sibling_maps()
    assert node.next_sibling_map is not None
    assert node.prev_sibling_map is not None
    assert node.prev_sibling_map == node.next_sibling_map



# Generated at 2022-06-23 16:11:29.897979
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    BasePattern()


# Generated at 2022-06-23 16:11:32.629589
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    a = Leaf(1, 'abc', (None, (0, 0)))
    assert next(a.pre_order()) is a


# Generated at 2022-06-23 16:11:45.214544
# Unit test for function generate_matches
def test_generate_matches():
    class XX(BasePattern):

        def match(self, node, results=None):
            return True

        def generate_matches(self, nodes):
            for i in range(len(nodes) + 1):
                yield i, {}

    for seq in [], [XX()], [XX(), XX()], [XX(), XX(), XX()]:
        assert list(generate_matches(seq, [])) == [(0, {})]
        assert list(generate_matches(seq, [None])) == [(0, {}), (1, {})]

        # Test stack overflow handling.
        # Pattern matches a sequence of 0 - inf nodes, but we have
        # a limited number of nodes to match.
        assert list(generate_matches(seq, [object])) == [(1, {})]

# Generated at 2022-06-23 16:11:56.584971
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from test.libregrtest.refleak import dash_R

    class Result:
        def __init__(self, match, unmatched):
            self.match = match
            self.unmatched = unmatched

    class _WildcardPattern(WildcardPattern):
        def __init__(self, *args, **kwds):
            WildcardPattern.__init__(self, *args, **kwds)
            self.seen = []  # type: List[Result]

        def match_seq(self, items, results=None):
            if results is not None:
                self.seen.append(Result(items[:], results.get("test")))
            return WildcardPattern.match_seq(self, items, results)

    ss = "abcdefg"
    s = "(abc) test (def) (g)"