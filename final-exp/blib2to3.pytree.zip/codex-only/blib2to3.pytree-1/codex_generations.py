

# Generated at 2022-06-23 16:01:55.676602
# Unit test for function convert
def test_convert():
    assert("1" == convert(grammar.Grammar(""), (1,1,1,1)).value)

# Generated at 2022-06-23 16:02:02.352841
# Unit test for method __str__ of class Node
def test_Node___str__():
  r"""Test method __str__ in class Node"""
  from .pgen2.token import tok_name
  from .pgen2 import grammar, token

  # code to be tested
  parser = grammar.grammar(grammar.syms.file_input)

  # helper functions
  def check(s, expected):
    res = parser.parse_string(s)
    s2 = res.__str__()
    assert s2 == expected, (":%r:\n!=\n:%r: " % (s2, expected))
 
  # testing code
  check("""def f():
    pass
""", """def f():
    pass
""")
  check('''def f(x):
  print x
''', '''def f(x):
  print x
''')

# Generated at 2022-06-23 16:02:12.096062
# Unit test for function convert
def test_convert():
    from .pgen2.pgen import Grammar

    gr = Grammar()

    def check(raw_node) -> None:
        nl = convert(gr, raw_node)
        if nl.type in gr.number2symbol:
            assert isinstance(nl, Node)
        else:
            assert isinstance(nl, Leaf)

    check((1, "1", (1, 1), []))
    check((1, "1", (1, 1), [Leaf(1, "1", (1, 1))]))
    check((2, "2", (2, 2), [Leaf(1, "1", (1, 1))]))

# Generated at 2022-06-23 16:02:17.090125
# Unit test for method replace of class Base
def test_Base_replace():
    class Child(object):
        parent = None
        type = 0

    class Node(Base):
        children = [Child()]
        type = 0
        next_sibling_map = None
        prev_sibling_map = None

    n = Node()
    n.children[0].parent = n
    n.replace(None)
    assert n.parent is None, n.parent
    assert n.children == [], n.children
    assert n.was_changed, n.was_changed



# Generated at 2022-06-23 16:02:18.462578
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    print("test_NegatedPattern_match()")


# Generated at 2022-06-23 16:02:23.212738
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.token import LPAR, NAME
    from .pgen2.grammar import BaseGrammar, Grammar

    class Pattern(BasePattern):
        def __init__(self, *args):
            BasePattern.__init__(self, *args)
            self._optimized = False

        def optimize(self):
            if self._optimized:
                return self
            self._optimized = True
            return BasePattern.optimize(self)

    class PatSequence(BasePattern):
        def __init__(self, *subpatterns):
            self.subpatterns = subpatterns

        def _submatch(self, node, results=None):
            nodes = node.children
            if len(nodes) != len(self.subpatterns):
                return False

# Generated at 2022-06-23 16:02:35.232231
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar, temp_grammar
    from .pgen2.tokenize import generate_tokens
    from .pgen2.pgen import generate_grammar

    with temp_grammar(
        generate_tokens,
        generate_grammar,
        driver=Driver,
        token_types={
            "name": 1,
            "number": 2,
            "string": 3,
            "equals": 11,
            "plus": 12,
            "newline": 4,
        },
    ) as gr:
        LeafPattern = gr.LeafPattern
        NodePattern = gr.NodePattern
        WildcardPattern = gr.WildcardPattern

# Generated at 2022-06-23 16:02:44.779950
# Unit test for method post_order of class Node
def test_Node_post_order():
    import unittest
    import sys
    import io
    import os
    import re
    import pickle
    import types
    import py_compile
    import tempfile
    import shutil
    from test.support import captured_stdout, captured_stdin, start_threads
    from test.support.script_helper import assert_python_ok
    from .pytree import Node, Leaf

    def make_node(type, *args):
        return Node(type, args)

    def make_leaf(type, value, prefix=""):
        return Leaf(type, value, prefix)

    class NodeTest(unittest.TestCase):

        def test_basic_node(self):
            tree = Node(1, [make_leaf(2, "a"), make_leaf(2, "b")])

# Generated at 2022-06-23 16:02:54.910416
# Unit test for method depth of class Base
def test_Base_depth():
    import lib2to3.pgen2.pgen
    import lib2to3.pgen2.parse
    import lib2to3.pgen2.tokenize
    import lib2to3.pgen2.driver
    g = lib2to3.pgen2.pgen.Pgen(lib2to3.pgen2.parse.grammar, lib2to3.pgen2.parse.driver, 
      lib2to3.pgen2.tokenize.driver)

    grammar = g.parse_grammar(lib2to3.pgen2.parse.grammar, "file.txt")
    assert grammar.type == 256
    assert grammar.depth() == 0
    assert grammar.children[0].type == 257
    assert grammar.children[0].depth() == 1

# Generated at 2022-06-23 16:02:59.279812
# Unit test for constructor of class Leaf

# Generated at 2022-06-23 16:03:04.953199
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import ast
    import sys
    import traceback
    try:
        ast.parse("print(1 + 2)")
    except:
        exc_type, exc_value, exc0 = sys.exc_info()
        exc = traceback.format_exception_only(exc_type, exc_value)[-1]
        raise AssertionError(exc)

# Generated at 2022-06-23 16:03:10.302766
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    pattern = LeafPattern(token.NAME)
    assert pattern.match(Leaf(token.NAME, "name"))

# Generated at 2022-06-23 16:03:15.918854
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Node, Leaf
    from .pygram import python_symbols
    a = Node(python_symbols.file_input, [])
    b = Leaf(1, "foo")
    a.append_child(b)
    c = Leaf(2, "bar")
    a.append_child(c)
    assert str(a) == "(file_input (1 foo) (2 bar))"
    b.remove()
    assert str(a) == "(file_input (2 bar))"
    b.remove()
    assert str(a) == "(file_input (2 bar))"
    c.remove()
    assert str(a) == "(file_input)"



# Generated at 2022-06-23 16:03:19.538344
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(2, "2", prefix=" ")
    result = list(l.post_order())

    assert result[0] == l
    assert result[0].prefix == " "
    assert result[0].value == "2"


# Generated at 2022-06-23 16:03:31.141129
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    wp = WildcardPattern(None)
    assert wp.content is None, repr(wp.content)
    assert wp.min == 0, repr(wp.min)
    assert wp.max == HUGE, repr(wp.max)
    assert wp.name is None, repr(wp.name)

    wp = WildcardPattern(None, 1)
    assert wp.content is None, repr(wp.content)
    assert wp.min == 1, repr(wp.min)
    assert wp.max == HUGE, repr(wp.max)
    assert wp.name is None, repr(wp.name)

    wp = WildcardPattern(None, 1, 1)
    assert wp.content is None, repr(wp.content)
    assert wp.min == 1, repr(wp.min)


# Generated at 2022-06-23 16:03:38.609359
# Unit test for method depth of class Base
def test_Base_depth():
    # Test 1: Simple leaf node
    leaf = Leaf(1,None,None)
    assert leaf.depth() == 0
    # Test 2: Simple node
    node = Node(1,None,[leaf,leaf])
    assert node.depth() == 1
    # Test 3: Leaf node w/ parent
    leaf.parent = node
    assert leaf.depth() == 1
    # Test 4: Nested node
    node2 = Node(1,None,[leaf])
    leaf.parent = node2
    assert leaf.depth() == 2
    # Test 4: Root node
    root = Node(1,None,[node2])
    node2.parent = root
    assert node2.depth() == 1
    assert root.depth() == 0
    # Test 5: parent=None
    node2.parent = None
    assert node2.depth()

# Generated at 2022-06-23 16:03:39.456718
# Unit test for method clone of class Base
def test_Base_clone():
    r = Base()
    r.clone()


# Generated at 2022-06-23 16:03:50.439636
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    """
    The method NegatedPattern.match_seq(self, nodes, results)
    is to invoke the method generate_matches of class NegatedPattern,
    with the sequence of nodes and results being passed as the arguments.
    """
    for i in range(0, 100):
        p = NegatedPattern()
        assert p.match_seq(nodes=list(range(0, i)), results=None) == (i == 0)
        assert p.match_seq(nodes=list(range(0, i)), results={}) == (i == 0)
        assert p.match_seq(nodes=list(range(0, i)), results={i: i}) == (i == 0)

    p = NegatedPattern([])

# Generated at 2022-06-23 16:03:57.264279
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    assert BasePattern(NUMBER).match(Leaf(NUMBER, "1"))
    assert not BasePattern(NUMBER).match(Leaf(STRING, "1"))
    assert not BasePattern(NUMBER, "1").match(Leaf(NUMBER, "2"))
    assert BasePattern(NUMBER, "1").match(Leaf(NUMBER, "1"))



# Generated at 2022-06-23 16:04:06.702321
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # test 1
    i = NegatedPattern()
    j = NegatedPattern(content = [])
    k = NegatedPattern(content = None)
    l = NegatedPattern(content = "[]")

    # test 2
    i = NegatedPattern(content = [1,2,3])

    # test 3
    list1 = [1,2,3]
    try:
        i = NegatedPattern(content = list1)
    except AssertionError:
        pass
    else:
        raise AssertionError("test 3 failed")

    # test 4
    class TestClass1:
        def __init__(self):
            pass
    test_class1 = TestClass1()
    try:
        i = NegatedPattern(content = test_class1)
    except AssertionError:
        pass
   

# Generated at 2022-06-23 16:04:09.482771
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    leaf = Leaf(None, None)
    assert leaf.clone() == leaf


# Generated at 2022-06-23 16:04:12.611520
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf
    a = Leaf(1, "abc")
    b = Leaf(1, "def")
    a.parent = b
    assert a.depth() == 1
    assert b.depth() == 0

    c = Leaf(1, "ghi")
    b.parent = c
    assert a.depth() == 2
    assert b.depth() == 1
    assert c.depth() == 0


# Generated at 2022-06-23 16:04:19.984652
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Node, Leaf
    assert Node(1, [Leaf(1, "foo"), Leaf(1, "bar")]).clone() == Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert Node(2, [Leaf(1, "foo"), Leaf(1, "bar")]).clone() == Node(2, [Leaf(1, "foo"), Leaf(1, "bar")])


# Generated at 2022-06-23 16:04:27.526009
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, Node

    class Leaf_test_Base_get_lineno(Leaf):
        lineno = 1

    class Node_test_Base_get_lineno(Node):
        lineno = 1

    assert Leaf_test_Base_get_lineno().get_lineno() == 1
    assert Node_test_Base_get_lineno().get_lineno() is None
    assert Node_test_Base_get_lineno([Leaf_test_Base_get_lineno()]).get_lineno() == 1
test_Base_get_lineno()



# Generated at 2022-06-23 16:04:37.540873
# Unit test for method set_child of class Node
def test_Node_set_child():
    test_string = '[a b c d e]'
    gram = Grammar(grammar)
    t = gram.parse(test_string)
    assert t.type == grammar.file_input
    assert str(t) == test_string
    test_string = '[a b a b a b]'
    t = gram.parse(test_string)
    assert t.type == grammar.file_input
    assert str(t) == test_string
    for i in range(len(t.children)):
        old_node = t.children[i]
        new_node = Leaf(old_node.type, old_node.value, old_node.prefix)
        t.set_child(i, new_node)
        c = t.children[i]
        assert c is new_node

# Generated at 2022-06-23 16:04:42.376771
# Unit test for method depth of class Base
def test_Base_depth():
    # Create a new empty node with no parent
    base = Base()
    assert base.depth() == 0
    # Create a non-empty node
    node = Node(1, children = [Leaf(1, 'a')])
    # Set the node's parent
    node.parent = node
    assert node.depth() == 1


# Generated at 2022-06-23 16:04:45.783805
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, "value")  # noqa: F841
    leaf = Leaf(1, "value", prefix="prefix")  # noqa: F841
    leaf = Leaf(1, "value", prefix=None)  # noqa: F841



# Generated at 2022-06-23 16:04:50.480595
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pytree import Leaf, test_Leaf
    node = Node(6, [])
    test_Leaf_invalidate_sibling_maps(node)


# Generated at 2022-06-23 16:04:56.225188
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import grammar, token

    class X(BasePattern):
        def __init__(self, type):
            self.type = type

        def __repr__(self):
            return "X(%r)" % self.type

        def match(self, node, results=None):
            return node.type in self.type

        def match_seq(self, nodes, results=None):
            if len(nodes) == 1:
                return self.match(nodes[0], results)
            return False

    g = grammar.Grammar()
    root = g.symbol2number["root"]
    Plus = g.symbol2number["+"]
    Comma = g.symbol2number[","]
    FNAME = token.NAME
    fred = leaf(FNAME, "fred")
   

# Generated at 2022-06-23 16:05:05.141418
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    children = []
    node = Node(257, children)
    assert repr(node) == "Node(257, [])"
    child = Leaf(1, "a")
    node = Node(257, [child])
    assert repr(node) == "Node(257, [Leaf(1, 'a')])"
    child = Leaf(1, "a")
    node = Node(257, [child])
    assert repr(node) == "Node(257, [Leaf(1, 'a')])"


# Generated at 2022-06-23 16:05:14.652305
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import pytest
    from textx import metamodel_from_str

    mm = metamodel_from_str(r"")
    tree = mm.model_from_str("a b c a b c a b c b d f b c")
    p = WildcardPattern(min=2, max=8)
    # Various patterns to match
    w1 = WildcardPattern(min=3, max=3)
    w2 = WildcardPattern(min=2, max=2)
    w3 = WildcardPattern(min=1, max=1)
    p1 = NodePattern(content=[w1, w2, w3])
    p2 = NodePattern(content=[w1, w1, w1])
    p3 = NodePattern(content=[w2, w2, w2])
    p4 = NodePattern

# Generated at 2022-06-23 16:05:24.925234
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def test(cls, args, expected):
        actual = list(cls(*args).generate_matches(iter((1, 2, 3, 4, 5))))
        assert actual == expected, "%s(%s).generate_matches(%s)->%s expected %s" % (
            cls.__name__,
            args,
            (1, 2, 3, 4, 5),
            actual,
            expected,
        )

    test(WildcardPattern, [], [(0, {}), (1, {}), (2, {}), (3, {}), (4, {}), (5, {})])

# Generated at 2022-06-23 16:05:32.661769
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    def _test(string: str) -> None:
        t = ast27.parse(string)
        if isinstance(t, ast27.Module):
            t = t.body[0]
        checker(t.leaves())

    def checker(gen: Iterator[Leaf]):
        assert_equal(next(gen).value, "def")
        assert_equal(next(gen).value, "foo")
        assert_equal(next(gen).value, "(")
        assert_equal(next(gen).value, ")")
        assert_equal(next(gen).value, ":")
        assert_equal(next(gen).value, "pass")
        with assert_raises(StopIteration):
            next(gen)

    _test("def foo(): pass")

test_Leaf_leaves()


# Generated at 2022-06-23 16:05:39.052942
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf as L

    def t(expected, tree):
        assert expected == tree.depth()
    t(0, L(0, ""))
    t(1, Node(0, [L(0, "")]))
    t(2, Node(0, [Node(0, [L(0, "")])]))
    t(3, Node(0, [Node(0, [Node(0, [L(0, "")])])]))



# Generated at 2022-06-23 16:05:50.198467
# Unit test for method post_order of class Node
def test_Node_post_order():
    # This is a method of class Node
    code = """if True:
        pass
    elif False:
        pass"""
    grammar = Grammar()
    tree = grammar.parse_string(code)
    result = list(tree.post_order())

# Generated at 2022-06-23 16:05:58.018341
# Unit test for method insert_child of class Node
def test_Node_insert_child():

    from .pytree import Leaf, Node
    from .python_tree import (
        alias, arguments, arglist, arg, comprehension, comp_for, comp_if,
        decorators, decorator, dotted_name, expr_stmt, import_from, import_name,
        keyword, pass_stmt, parameters, power, slice, trailer, try_stmt,
        with_item)

    def _l(s):
        return Leaf(token.NAME, s, prefix=" ")

    def _n(type, *children):
        return Node(type, children)

    # Name
    assert _n(expr_stmt, _l("a")).insert_child(0, _l("1+")) == None

# Generated at 2022-06-23 16:06:04.769442
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(0, "foo")
    assert l.type == 0
    assert l.value == "foo"
    assert l.parent is None
    assert l.prefix == ""
    l = Leaf(0, "foo", prefix=" ")
    assert l.prefix == " "
    l = Leaf(0, "foo", fixers_applied=["foo"])
    assert l.fixers_applied == ["foo"]


# Generated at 2022-06-23 16:06:08.803044
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    a = SymbolPattern(token.NAME)
    n = NegatedPattern(a)
    assert n.content == a

    b = NegatedPattern()
    assert isinstance(b, NegatedPattern) is True

# Generated at 2022-06-23 16:06:19.670043
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node

    n = Node(3, [Leaf(1, "x"), Leaf(2, "y")])
    n.set_child(1, Leaf(4, "z"))
    assert n == Node(3, [Leaf(1, "x"), Leaf(4, "z")])
    n = Node(3, [Leaf(1, "x"), Leaf(2, "y")])
    n.set_child(0, Node(5, [Leaf(1, "x")]))
    assert n == Node(3, [Node(5, [Leaf(1, "x")]), Leaf(2, "y")])
    n = Node(3, [], prefix="")
    n.set_child(0, Leaf(1, "x"))

# Generated at 2022-06-23 16:06:21.586401
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    Test that BasePattern.optimize() returns self.
    """
    p = BasePattern()
    assert p.optimize() is p

# Generated at 2022-06-23 16:06:27.252375
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    def f(t):
        u = t.clone()
        assert_equal(repr(u), repr(t))
    f(Leaf(1, "a", ("", (1, 1))))
    f(Leaf(1, "a", ("b", (1, 1))))
    f(Leaf(2, "", fixers_applied=[1], prefix="a", context=("b", (1, 1))))

# Unit tests for class Leaf


# Generated at 2022-06-23 16:06:37.096427
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols
    import sys

    if sys.version_info[0] >= 3:
        def make_leaf(type, value):
            return Leaf(type, value)
    else:
        def make_leaf(type, value):
            return Leaf(type, value)

    a = make_leaf(python_symbols.NAME, 'a')
    b = make_leaf(python_symbols.NAME, 'b')
    c = make_leaf(python_symbols.NAME, 'c')
    d = make_leaf(python_symbols.NAME, 'd')
    e = make_leaf(python_symbols.NAME, 'e')

    tree = Base()
    tree.children = [a, b, c, d, e]

# Generated at 2022-06-23 16:06:41.056865
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    o1 = Base("first")
    o2 = Base("second")
    assert not (o1 == o2)
    assert not (o2 == o1)
    o2 = Base("first")
    assert (o1 == o2)
    assert (o2 == o1)



# Generated at 2022-06-23 16:06:49.421120
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Node
    from .pygram import python_symbols

    tree = Node(
        python_symbols.file_input,
        [
            Node(python_symbols.stmt, [Leaf(1, "1")]),
            Node(python_symbols.stmt, [Leaf(1, "2")]),
            Node(python_symbols.stmt, [Leaf(1, "3")]),
        ],
    )
    assert str(tree) == "123", str(tree)
    leaf = Leaf(1, "4")
    tree.set_child(1, leaf)
    assert str(tree) == "143", str(tree)
    assert leaf.parent is not None, leaf.parent



# Generated at 2022-06-23 16:07:00.184856
# Unit test for method changed of class Base
def test_Base_changed():
    from .pygram import python_grammar, python_grammar_no_print_statement

    if sys.version_info < (3, 7):
        gram = python_grammar_no_print_statement
    else:
        gram = python_grammar

    f = open(gram.grammar, "r", encoding="utf-8")
    g = Grammar(f, "Grammar", python_grammar.symbol2number)
    f.close()
    p = g.parse("class Foo:\n def bar(self):\n pass\n")
    assert p.was_changed is False
    p.children[0].children[0].changed()
    assert p.was_changed is True



# Generated at 2022-06-23 16:07:08.548596
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(257, [
        LeafPattern(token.NAME),
        NodePattern(258, [WildcardPattern()]),
        LeafPattern(token.RPAR)]
    )
    node = Node(257, [Leaf(token.NAME, "foo"), Leaf(token.LPAR, "("), Leaf(token.RPAR, ")")])
    assert p.match(node)
    p = NodePattern(259, [NodePattern(258, [WildcardPattern()]), LeafPattern(token.RPAR)])
    assert not p.match(node)



# Generated at 2022-06-23 16:07:12.468745
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """
    Test the method optimize of class BasePattern
    """
    from . import token
    from . import symbol

    EMPTY = BasePattern()
    LPAR = LeafPattern(token.LPAR, "(")
    STAR = BasePattern(symbol.star_expr, content=EMPTY)
    assert EMPTY.optimize() is EMPTY
    assert LPAR.optimize() is LPAR
    assert STAR.optimize() is EMPTY

# Generated at 2022-06-23 16:07:17.326505
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Unit test for method __repr__ of class BasePattern."""
    # Test with a trivial pattern, matching a token.
    p = LeafPattern(token.NAME, "foo")
    assert repr(p) == "LeafPattern(NAME, 'foo')"
    # Test a non-trivial pattern.
    p = NodePattern(expr, content=any)
    assert repr(p) == "NodePattern(expr, <function any at 0x%x>)" % id(any)

# Generated at 2022-06-23 16:07:26.463231
# Unit test for method replace of class Base
def test_Base_replace():

    import pytest

    from .driver import Driver
    from .pgen2 import driver, tokenize, token

    class Node(Base):
        def __init__(self, type, children):
            self.type = type
            self.children = children

        def depth(self):
            return 1 + max([0] + [child.depth() for child in self.children])

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def _eq(self, other):
            return self.type == other.type and self.children == other.children


# Generated at 2022-06-23 16:07:34.465254
# Unit test for constructor of class Node
def test_Node():
    a = Node(1, [])
    assert a.type == 1
    assert a.children == []
    assert a.parent is None
    assert a.prefix == ""
    b = Node(1, [Leaf(2, "foo")])
    assert b.prefix == "foo"
    assert b.type == 1
    assert b.children == [Leaf(2, "foo")]
    assert b.parent is None
    assert b.children[0].parent is b


# Generated at 2022-06-23 16:07:42.633533
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    try:
        #from . import pytree
        from .pytree import Leaf
        from .pygram import python_symbols
        def foo(x): pass
    except:
        return

    tree = pytree.from_str("x = [\n'a',\n'b',\n'c']")
    stmts = tree.stream()
    #print(list(stmts))

    assert len(list(stmts)) == 1
    assert isinstance(stmts.send(None), Leaf)
    assert stmts.send(None).type == token.INDENT
    assert isinstance(stmts.send(None), Leaf)
    assert stmts.send(None).type == token.NAME
    assert isinstance(stmts.send(None), Leaf)
    assert stmts.send

# Generated at 2022-06-23 16:07:52.684762
# Unit test for method set_child of class Node
def test_Node_set_child():
    import unittest

    import ast

    import astunparse


# Generated at 2022-06-23 16:08:03.960187
# Unit test for method post_order of class Node
def test_Node_post_order():
    s = """if 1:
    pass
"""
    # Use it!
    from pytree import Leaf, Node
    from io import StringIO
    from blib2to3.pgen2.tokenize import (
        untokenize,
    )
    from blib2to3.pgen2.parse import (
        parse_grammar,
        driver,
    )
    from blib2to3.pgen2.token import (
        generate_tokens,
    )
    from blib2to3.pgen2.pgen import (
        generate_grammar,
    )
    t = generate_tokens(StringIO(s).readline) # type: Iterator
    stream = list(t) # type: List
    # Need to create a grammar

# Generated at 2022-06-23 16:08:14.763150
# Unit test for method set_child of class Node
def test_Node_set_child():
    """
    unit test of Node.set_child() method
    """
    from .pygram import python_symbols as syms
    from .pytree import Leaf, Node


# Generated at 2022-06-23 16:08:17.033563
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    assert repr(Node(0, [])) == "Node(0, [])"



# Generated at 2022-06-23 16:08:21.566559
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    n = Node(1, [Leaf(2, "["), Leaf(3, "]"), Leaf(4, ".")])
    assert list(map(type, n.post_order())) == [Leaf, Leaf, Leaf, Node]


# Generated at 2022-06-23 16:08:26.167419
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    root = parse("1 + 1\n", mode="exec")
    for child in root.children:
        if child.type == token.NEWLINE:
            assert child.get_lineno() == 2
            break
    # If the node isn't found, assert will throw an exception
    else:
        assert False
test_Base_get_lineno()


# Generated at 2022-06-23 16:08:36.022341
# Unit test for method post_order of class Node
def test_Node_post_order():
    import nbimporter
    nbimporter.options["only_defs"] = False
    from . import pytree
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as grammar
    from .pgen2.parse import parse_grammar_text
    grammar_obj = parse_grammar_text(grammar)
    g = Grammar(grammar_obj)
    a = pytree.Node(syms.file_input, [])
    b = pytree.Node(syms.simple_stmt, [])
    c = pytree.Node(syms.small_stmt, [])
    d = pytree.Node(syms.expr_stmt, [])
    e = pytree.Leaf(1, "x")
    f = pytree.Le

# Generated at 2022-06-23 16:08:38.464787
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "foo")
    assert l.type == 1
    assert l.value == "foo"
    assert l.prefix == ""
    assert l.fixers_applied == []


# Generated at 2022-06-23 16:08:51.068661
# Unit test for method depth of class Base

# Generated at 2022-06-23 16:09:02.459287
# Unit test for constructor of class Base
def test_Base():
    class Concrete(Base):
        def __init__(self, prefix):
            self.prefix = prefix

        def _eq(self, other):
            return self.prefix == other.prefix

        def __ne__(self, other):
            if self.__class__ is not other.__class__:
                return NotImplemented
            return not self._eq(other)

        def clone(self):
            return Concrete(self.prefix)

        def pre_order(self):
            yield self

    c1 = Concrete("test")
    c2 = Concrete("test")
    c3 = Concrete("testx")

    assert c1 == c2
    assert c1 != c3
    assert c2 != c3
    assert c1.clone() == c1


T = TypeVar("T")



# Generated at 2022-06-23 16:09:14.158863
# Unit test for method optimize of class BasePattern

# Generated at 2022-06-23 16:09:21.095905
# Unit test for function generate_matches
def test_generate_matches():
    # Simple test
    def g() -> Iterator[Tuple[int, _Results]]:
        return generate_matches([NodePattern(type=1), NodePattern(type=2)], [NL(1), NL(2)])
    assert list(g()) == [(2, {})]

    # Test with wildcard in middle
    def f() -> Iterator[Tuple[int, _Results]]:
        return generate_matches(
            [
                NodePattern(type=1),
                WildcardPattern(min=0, max=1),
                NodePattern(type=2),
            ],
            [NL(1), NL(2)],
        )
    assert list(f()) == [(2, {})]

    # Test with wildcard on end
    def e() -> Iterator[Tuple[int, _Results]]:
        return

# Generated at 2022-06-23 16:09:27.677897
# Unit test for method clone of class Base
def test_Base_clone():
    """
    Test the Base.clone method
    """
    n = Node(4, [Leaf(1, "test"), Leaf(2, "data")])
    m = n.clone()
    assert n == m, "Cloned tree should equal original"
    n.children[1].value = "bar"
    assert n != m, "Changing a copy should not affect the original"
    n.children[1].value = "data"
    assert n == m, "Original tree should be restored"

# Generated at 2022-06-23 16:09:38.044464
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from .util import dump
    from .parse import Numbers, Grammar, Line

    # Single node
    pattern = WildcardPattern()
    assert pattern.match(Leaf(Numbers.INT, "42", "42"))

    # Node sequence
    pattern = WildcardPattern(min=1, max=1)
    assert pattern.match_seq([Leaf(Numbers.INT, "42", "42")])

    # Node sequence, multiple matches
    pattern = WildcardPattern(min=2)
    assert pattern.match_seq([Leaf(Numbers.INT, "1", "1"), Leaf(Numbers.INT, "2", "2")])

    # Node sequence, too short
    pattern = WildcardPattern(min=3)

# Generated at 2022-06-23 16:09:43.480459
# Unit test for method depth of class Base
def test_Base_depth():
    class TestBase(Base):
        def __init__(self, children, parent):
            self.children = children
            self.parent = parent

    a = TestBase([], None)
    b = TestBase([], a)
    c = TestBase([], b)
    assert a.depth() == 0
    assert b.depth() == 1
    assert c.depth() == 2



# Generated at 2022-06-23 16:09:53.740538
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    with tempfile.TemporaryDirectory() as tmpdir:
        p = tmpdir + os.sep + "test_Leaf_clone"
        outfile = open(p, "w")

# Generated at 2022-06-23 16:10:01.193791
# Unit test for function generate_matches
def test_generate_matches():
    from . import ast  # Avoid circular imports
    from .pytree import Leaf, Node

    def check(all_matches, expected):
        assert all(tuple(p) == t for p, t in zip(all_matches, expected))

    def assert_raises(exc, f, *args, **kwargs):
        try:
            f(*args, **kwargs)
        except exc:
            pass
        else:
            assert False, f"{f} did not raise {exc}"

    # The simplest match
    check(
        generate_matches([NodePattern(ast.expr_context),], (Node(ast.expr_context),)),
        [(1, {})],
    )

    # The simplest match using a wildcard

# Generated at 2022-06-23 16:10:12.690699
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from .syntax import Lib2to3SyntaxError
    from .grammar import Symbol, SType, BaseGrammar, parse_grammar, grammar_parse_file
    from .pgen2.parse import ParseError
    from .pgen2 import token

    class TestGrammar(BaseGrammar):
        """Dummy grammar used in the unit test of method match of class NegatedPattern."""

        def __init__(self) -> None:
            """Creates the TestGrammar instance."""
            super().__init__()
            self.tok_name = token.NAME
            self.tok_number = token.NUMBER
            self.tok_lpar = token.LPAR
            self.tok_rpar = token.RPAR
            self.tok_strip = token.STRING

# Generated at 2022-06-23 16:10:21.576522
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Node, Leaf, Internal
    Internal(type=42, 
        children=[
            Leaf(type=42, 
                value='1', 
                context=('"1"', (1, 6)), 
                prefix='', 
                prefix_context=None),
            Leaf(type=42, 
                value='2', 
                context=('1', (1, 6)), 
                prefix='', 
                prefix_context=None)
        ], 
        context=("...", (1, 6)), 
        prefix='')

# Generated at 2022-06-23 16:10:30.257692
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    import lib2to3.pgen2.parse,lib2to3.pgen2.token
    grammar = Grammar(lib2to3.pgen2.parse.grammar)
    generator = lib2to3.pgen2.token.generate_tokens(StringIO('a = 1').readline)
    a = grammar.parse(generator)
    a.invalidate_sibling_maps()
    assert a.prev_sibling_map is None, \
        "Failed to invalidate sibling maps"
    assert a.next_sibling_map is None, \
        "Failed to invalidate sibling maps"
    a.update_sibling_maps()
    assert a.prev_sibling_map is not None, \
        "Failed to update sibling maps"
    assert a.next_sibling_

# Generated at 2022-06-23 16:10:33.747415
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Tests for a bug where an assertion error popped up when
    # pattern.match_seq was called on an empty list
    tokens = LeafPattern(value=')')
    assert not tokens.match_seq([])


# Generated at 2022-06-23 16:10:44.196525
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    nodes = [Dummy(0, 'a'), Dummy(0, 'b'), Dummy(0, 'c')]
    results = {}
    # The list of patterns is empty but the first element of nodes is 'a'.
    # Since any empty sequence is obviously included, the result is non-empty.
    n = NegatedPattern()
    for c,r in n.generate_matches(nodes):
        results = r
    assert results == {}, results
    # The pattern [a,b] is not in the nodes because it does not start with 'a'
    # but with 'b'.
    # The pattern [a] is included, thus the result is still empty.
    n = NegatedPattern(NodePattern(content=[LeafPattern(content='a'), LeafPattern(content='b')]))

# Generated at 2022-06-23 16:10:45.486659
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # may not be called!
    assert False



# Generated at 2022-06-23 16:10:55.026038
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # BasePattern itself is abstract, so that these tests are
    # actually run against the LeafPattern subclass.
    pattern = LeafPattern(token.NUMBER, 42)
    assert pattern.optimize() is pattern
    pattern = LeafPattern(42, 42)
    assert pattern.optimize() is not pattern
    assert pattern.optimize().type == token.NUMBER
    assert pattern.optimize().content is None
    pattern = LeafPattern(token.NUMBER, 42, "x")
    assert pattern.optimize() is not pattern
    assert pattern.optimize().type == token.NUMBER
    assert pattern.optimize().content is None
    assert pattern.optimize().name == "x"



# Generated at 2022-06-23 16:11:00.929155
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    a_leaf = Leaf(1, "a")
    assert a_leaf.pre_order() == [a_leaf]
    assert list(a_leaf.pre_order()) == [a_leaf]

    a_node = Node(1, (a_leaf,))
    assert a_node.pre_order() == [a_node, a_leaf]


# Generated at 2022-06-23 16:11:02.940862
# Unit test for method __str__ of class Node
def test_Node___str__():
    current = Node(257, [])
    returned = current.__str__()
    expected = ""
    assert returned == expected

# Generated at 2022-06-23 16:11:06.361940
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Test: Returns false if the sequence is of length other than 1.
    bTN = BasePattern(type=1)
    nodes = [1, 1]
    with pytest.raises(AssertionError):
        bTN.match_seq(nodes)



# Generated at 2022-06-23 16:11:07.690528
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    BasePattern()


# Generated at 2022-06-23 16:11:17.592137
# Unit test for method depth of class Base
def test_Base_depth():
    # class DummyNode(Node): pass
    from .pytree import Node, Leaf

    # class DummyLeaf(DummyNode, Leaf): pass
    class DummyLeaf(Leaf):
        def type(self):
            return 1

    c1 = DummyLeaf()
    c2 = DummyLeaf()
    c3 = DummyLeaf()
    c4 = DummyLeaf()
    c5 = DummyLeaf()
    sibs = [c1, c2, c3, c4, c5]
    n1 = Node(1, [c1, c2])
    n2 = Node(1, [n1, c3, c4])
    n3 = Node(1, [n1, n2, c5])
    n1.parent = n2
    n2.parent

# Generated at 2022-06-23 16:11:27.330361
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    valorEsperado = '"hi"'
    token = Leaf(token.STRING, "hi")
    res = list(i for i in token.leaves())
    assert res[0].value == valorEsperado, "FALLA"
        
"""
    # Unit test for method leaves of class Leaf
    def test_Leaf_leaves (self):
        valorEsperado = '"hi"'
        token = Leaf(token.STRING, "hi")
        res = list(i for i in token.leaves())
        self.assertEqual(valorEsperado, res[0].value, "FALLA")
"""
# APA

# Generated at 2022-06-23 16:11:37.132539
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    sample_tree =  Node(258, [ Leaf(1, 'def'), Leaf(1, ' '), Leaf(1, 'f'), Leaf(40, '('), 
        Node(259, [ Leaf(1, 'a'), Leaf(1, ' '), Leaf(1, '='), Leaf(1, ' '), Leaf(3, '1'), Leaf(44, ','), Leaf(1, ' '), 
        Leaf(1, 'b'), Leaf(1, ' '), Leaf(1, '='), Leaf(1, ' '), Leaf(3, '2')]), Leaf(41, ')'), Leaf(1, ':')]), 

# Generated at 2022-06-23 16:11:44.506174
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    result = {}
    assert not WildcardPattern(content=("1",)).match(Leaf("1", "c", "1"))
    assert WildcardPattern(content=("1",)).match(Leaf("1", "c", "1"), result)
    assert not result
    assert WildcardPattern(content=("1",), name="key").match(Leaf("1", "c", "1"), result)
    assert result == {"key": Leaf("1", "c", "1")}
    assert WildcardPattern(content=("1",), name="1").match(Leaf("1", "c", "1"), result)
    assert result == {"1": Leaf("1", "c", "1")}

# Generated at 2022-06-23 16:11:46.530072
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    a = Leaf(1, "", (0,0))
    for item in a.pre_order():
        assert item == a

# Generated at 2022-06-23 16:11:56.292427
# Unit test for method depth of class Base
def test_Base_depth():
    class FakeParent(Base):
        def __init__(self, children):
            self.children = children
    class FakeChild(Base):
        parent = None
    node = FakeChild()
    assert node.depth() == 0
    node = FakeChild()
    p = FakeParent([node])
    assert node.depth() == 1
    node = FakeChild()
    p = FakeParent([node])
    pp = FakeParent([p])
    assert node.depth() == 2
    node = FakeChild()
    p = FakeParent([node])
    pp = FakeParent([p])
    ppp = FakeParent([pp])
    assert node.depth() == 3
