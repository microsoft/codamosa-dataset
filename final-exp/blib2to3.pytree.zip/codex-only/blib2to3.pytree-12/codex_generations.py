

# Generated at 2022-06-23 16:01:58.857418
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    print('inside {0}'.format(sys._getframe().f_code.co_name))
    pattern = NegatedPattern()
    nodes = {'foo', 'bar'}
    matched = pattern.match_seq(nodes, results=None)
    assert matched == True

    pattern.content = NodePattern(type=1)
    nodes = {'foo', 'bar'}
    matched = pattern.match_seq(nodes, results=None)
    assert matched == False

test_NegatedPattern_match_seq()



# Generated at 2022-06-23 16:02:10.004105
# Unit test for method clone of class Base
def test_Base_clone():
    global test_Base_clone; test_Base_clone = lambda: None
    # Verify that clone() returns a copy of the tree

    def _test(s, f=lambda tree: tree.clone()):
        from .pgen2 import driver

        g = driver.load_grammar("Grammar.txt")
        p = driver.ParserDriver(g, convert=f)
        tree = p.parse_string(s)
        assert tree == f(tree)

    _test("x = 1")
    _test("x = 1; y =2; z = 3;")
    _test("x = 1; y =2; z = 3;", f=lambda tree: tree.clone().children[0].clone())

# Generated at 2022-06-23 16:02:17.885372
# Unit test for method __str__ of class Node
def test_Node___str__():
    """Test __str__."""
    import StringIO

    a = Node(257, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert str(a) == "abc"

    b = Node(257, [Leaf(1, "a"), Node(258, [Leaf(1, "b"), Leaf(1, "c")]), Leaf(1, "d")])
    assert str(b) == "abcd"

    c = Node(257, [Leaf(1, "a"), Leaf(1, "b")])
    d = Node(258, [Leaf(1, "c"), Leaf(1, "d")])
    e = Node(257, [c, d, Leaf(1, "e")])
    assert str(e) == "abcde"

   

# Generated at 2022-06-23 16:02:23.075595
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    class Foo:
        pass

# Generated at 2022-06-23 16:02:23.932634
# Unit test for constructor of class Node
def test_Node():
    print(Node(0, []))



# Generated at 2022-06-23 16:02:30.312444
# Unit test for method post_order of class Base

# Generated at 2022-06-23 16:02:32.117520
# Unit test for method __str__ of class Node
def test_Node___str__():
    n = Node(1, [Leaf(1, "")])
    assert str(n) == ""
    n = Node(1, [Leaf(1, "def"), Leaf(1, " "), Leaf(1, "foo")])
    assert str(n) == "def foo"



# Generated at 2022-06-23 16:02:34.999162
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(257, ['children'])
    assert repr(node) == "Node(file_input, ['children'])"

# Generated at 2022-06-23 16:02:44.716331
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import tempfile
    from blib2to3.pgen2 import token

    fp = tempfile.NamedTemporaryFile('w+')
    fp.write('a\nb\nc')
    fp.flush()
    from blib2to3 import pytree
    tree = pytree.from_file(fp.name)

    assert isinstance(list(tree.leaves())[0], Leaf)
    assert isinstance(list(tree.leaves())[1], Leaf)
    assert isinstance(list(tree.leaves())[2], Leaf)

    # Test get_suffix between all the leaves
    assert list(tree.leaves())[0].get_suffix() == '\nb'
    assert list(tree.leaves())[1].get_suffix() == '\nc'

# Generated at 2022-06-23 16:02:54.606354
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    class DummyLeaf(Leaf):
        type = 1

    a = DummyLeaf('a')
    b = DummyLeaf('b')
    assert LeafPattern(1, 'a').match(a)
    assert LeafPattern(1, 'b').match(b)
    assert not LeafPattern(2, 'a').match(a)
    assert not LeafPattern(1, 'b').match(a)
    assert not LeafPattern(2, 'b').match(a)

    results = {}
    assert LeafPattern(1, 'a', name='a').match(a, results)
    assert results == {'a': a}
    results = {}
    assert not LeafPattern(1, 'b', name='b').match(a, results)
    assert not results



# Generated at 2022-06-23 16:02:59.661173
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pgen2 import token
    from . import pytree
    from .pygram import python_symbols as syms

    one = pytree.Leaf(1, "1", prefix=" ")
    two = pytree.Leaf(1, "2", prefix="\t")
    three = pytree.Leaf(1, "3", prefix="\n\t\n")
    node = pytree.Node(syms.expr_stmt, [one, two, three])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map is None, node.next_sibling_map



# Generated at 2022-06-23 16:03:08.937800
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    LeafPattern()
    LeafPattern(type=1)
    LeafPattern(content="abc")
    LeafPattern(type=1, content="abc")
    LeafPattern(name="x")
    LeafPattern(type=1, name="x")
    LeafPattern(content="abc", name="x")
    LeafPattern(type=1, content="abc", name="x")
    # Test for error
    try:
        LeafPattern(type=257)
    except AssertionError:
        pass
    else:
        assert 0, "should have raised AssertionError"
    try:
        LeafPattern(content=1)
    except AssertionError:
        pass
    else:
        assert 0, "should have raised AssertionError"



# Generated at 2022-06-23 16:03:13.792205
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    p = NegatedPattern()
    assert p.content is None
    assert p.match_seq([])
    assert not p.match_seq([Leaf(1, "A")])

    q = NegatedPattern(LeafPattern(1, "A"))
    assert q.content is not None
    assert not q.match_seq([])
    assert q.match_seq([Leaf(1, "B")])
    assert not q.match_seq([Leaf(1, "A")])
    assert not q.match_seq([Leaf(1, "A"), Leaf(1, "B")])



# Generated at 2022-06-23 16:03:17.435595
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import test_Base
    n = test_Base()
    n.replace(None)
    n.replace([])
    n.replace([1])
    n.replace([1, 2])



# Generated at 2022-06-23 16:03:18.570092
# Unit test for constructor of class LeafPattern
def test_LeafPattern():  # pragma: no cover
    assert LeafPattern()
    assert not LeafPattern(type=0)



# Generated at 2022-06-23 16:03:30.601009
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    import lib2to3.pgen2.tokenize as tokenize
    import lib2to3.pgen2.parse as parse
    import lib2to3.pygram as pygram
    import lib2to3.pytree as pytree
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.convert as convert
    import six
    
    def get_source(tree):
        output = StringIO()
        tree.totestring(output, convert.NO_NEWLINE | convert.NO_NESTED_PARENS)
        assert output.getvalue() != ""
        return output.getvalue().encode('utf-8').decode(tokenize.detect_encoding(output.getvalue().encode('utf-8'))[0])

    pygrm = py

# Generated at 2022-06-23 16:03:34.680938
# Unit test for method append_child of class Node
def test_Node_append_child():
    node = Node(1, []) # node.children = [] => first execution of append_child works
    node.append_child(Leaf(1, 'a'))
    assert node.children[0].value == 'a'
    node.append_child(Leaf(1, 'b'))
    assert node.children[1].value == 'b'


# Generated at 2022-06-23 16:03:42.002103
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import ast
    from . import dump, FROM2TO3

    pattern = ast.parse(
        dump(ast.parse("def f(x): return x**2\n"), version=FROM2TO3), version=FROM2TO3
    )
    pat = ast.parse("dummy", "<input>", "funcdef")

# Generated at 2022-06-23 16:03:49.632657
# Unit test for method clone of class Base
def test_Base_clone():
    from .node_util import Node, Leaf

    test_params = [
        (Base, False),
        (Node, False),
        (Leaf, True),
    ]

    for test_param in test_params:
        cls = test_param[0]
        try:
            cls.clone()
        except NotImplementedError:
            if test_param[1] is False:
                assert False, "Failed on %r" % str(test_param)
        else:
            if test_param[1] is True:
                assert False, "Failed on %r" % str(test_param)

# Generated at 2022-06-23 16:03:54.812399
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    import hypothesis

    @hypothesis.given(hypothesis.strategies.text())
    def test_one_node(pattern):
        p = NodePattern(content=pattern, name='test').optimize()
        assert isinstance(p, LeafPattern)
        assert p.content == pattern
        assert p.name == 'test'

    @hypothesis.given(hypothesis.strategies.text())
    def test_one_wildcard(pattern):
        p = WildcardPattern(content=[[LeafPattern(content=pattern)]], name='test').optimize()
        assert isinstance(p, WildcardPattern)
        assert p.content == [[LeafPattern(content=pattern)]]
        assert p.name == 'test'


# Generated at 2022-06-23 16:03:56.853987
# Unit test for method append_child of class Node
def test_Node_append_child():
    '''
    >>> a = Node(0,[])
    >>> b = Leaf(1,[])
    >>> a.append_child(b)
    >>> a.children
    [Leaf(1, [], prefix='')]
    '''

# Generated at 2022-06-23 16:04:01.213002
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.comma) == "comma"
    assert type_repr(1) == 1
    assert type_repr(HUGE) == HUGE

# For the moment, ignore type checker errors on the next line.
AnyStr = Union[str, bytes]  # noqa: F821



# Generated at 2022-06-23 16:04:04.677599
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    import ast
    from asttokens import ASTTokens
    at = ASTTokens(
        """
    foo(
        a, b,
        c, d
    )
""",
        parse=True,
    )
    # we expect to match a node of type 'ast.Tuple'
    tree = at.tree
    p = NegatedPattern(NodePattern(type=ast.Tuple))
    assert p.match(tree) is True


# Generated at 2022-06-23 16:04:12.227156
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pygram import python_symbols
    from .pytree import Leaf

    def _check(node):
        assert len(node.children) == 2
        assert node.children[0].type == 1
        assert node.children[1].type == 2
        assert node.parent is None

    node = Node(python_symbols.testlist, [])
    node.insert_child(0, Leaf(1, "1"))
    _check(node)
    node.insert_child(0, Leaf(2, "2"))
    _check(node)
    node.insert_child(2, Leaf(3, "3"))
    assert len(node.children) == 3
    assert node.children[0].type == 2
    assert node.children[1].type == 1
    assert node.children[2].type == 3

# Generated at 2022-06-23 16:04:14.134434
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert not b
    assert not getattr(b, "children", None)



# Generated at 2022-06-23 16:04:25.982352
# Unit test for method replace of class Base
def test_Base_replace():
    node1_1 = Leaf(0, 'A', (1, 0))
    node1_2 = Leaf(0, 'B', (1, 1))
    node1_3 = Leaf(0, 'C', (1, 2))
    node1_4 = Leaf(0, 'D', (1, 3))
    node2_1 = Node(0, [node1_1, node1_2])
    node2_2 = Node(0, [node1_3, node1_4])
    node3 = Node(0, [node2_1, node2_2])
    node3.replace(node1_3)

# Generated at 2022-06-23 16:04:33.040266
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    wc = WildcardPattern([])
    assert wc.match([])
    assert not wc.match([Leaf(token.NAME, "foo")])
    wc = WildcardPattern([["foo"]])
    assert not wc.match([])
    assert wc.match([Leaf(token.NAME, "foo")])
    assert not wc.match([Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")])
    assert not wc.match([Leaf(token.NAME, "bar")])
    wc = WildcardPattern([["foo", "bar"]])
    assert not wc.match([])
    assert not wc.match([Leaf(token.NAME, "foo")])

# Generated at 2022-06-23 16:04:40.584010
# Unit test for method depth of class Base
def test_Base_depth():
    from .pygram import python_symbols
    from .pgen2 import token
    import unittest

    class TestNode(Node):
        def _eq(self, other):
            if isinstance(other, TestNode):
                return type(self) == type(other)
            return False

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

        def clone(self):
            return TestNode()

    class TestTree(unittest.TestCase):
        def test_Base_depth(self):
            # test tree:
            #           1
            #          / \
            #         2   3
            #               \
            #                4
            t1 = TestNode()
            t1.type = 1
            t2 = TestNode()

# Generated at 2022-06-23 16:04:48.874402
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    import sys
    import io
    from io import StringIO
    import unittest

    class Test_Node_insert_child(unittest.TestCase):
        def test_1(self):
            from . import pytree

            t = pytree.Node(1, [])
            t.insert_child(0, pytree.Node(2, []))
            t.insert_child(0, pytree.Node(3, []))
            t.insert_child(0, pytree.Node(4, []))
            t.insert_child(1, pytree.Node(5, []))
            self.assertEqual(repr(t), 'Node(1, [Node(4, []), Node(5, []), Node(3, []), Node(2, [])])')


# Generated at 2022-06-23 16:04:54.834646
# Unit test for method depth of class Base
def test_Base_depth():
    # testing node: foo
    foo = Node(1, [], prefix="foo")
    assert foo.depth() == 0
    # testing node: foo (2, [(0, '\n'), (1, 'def'), (1, 'f'), (1, '('), (0, '\n'),
    # (2, [(0, '\n'), (3, [(1, 'return')]), (0, '\n')]), (1, ')'), (0, '\n')])

# Generated at 2022-06-23 16:04:59.169749
# Unit test for method __str__ of class Node
def test_Node___str__():
    import py_dev
    _str = py_dev.Node.__str__
    assert _str(py_dev.Node(1, [])) == '', py_dev.Node(1, [])


# Generated at 2022-06-23 16:05:02.045867
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    from .pgen2 import token

    t = Leaf(token.NAME, "ABC", prefix="  ", fixers_applied=[])
    assert str(t) == "  ABC"
    t.value = "DEF"
    assert str(t) == "  DEF"
    t.prefix = " "
    assert str(t) == " DEF"



# Generated at 2022-06-23 16:05:10.512240
# Unit test for method changed of class Base
def test_Base_changed():
    from io import StringIO
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    for args in [
            (1, "a", (1, 1), []),
            (1, "a", (1, 1), None),
            (1, None),
            (1, "a"),
            (1, "a", (1, 1)),
            (1, None, None, None),
            ]:
        node = Leaf(*args)
        assert node.was_changed is False
        node.changed()
        assert node.was_changed is True
    node = Leaf(syms.integer, "1")
    assert node.was_changed is False
    node.changed()
    assert node.was_changed is True
    assert node.parent is None
    node_list = [node]

# Generated at 2022-06-23 16:05:22.255267
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import lib2to3_parse
    from .pgen2 import token, tokenize
    from .pytree import Leaf, Node, type_repr
    from .pygram import python_symbols as syms

    def nodes_from_parse(s: str) -> Iterator[Leaf]:
        """Helper to generate nodes from the output of lib2to3_parse.parse."""
        for node in lib2to3_parse.parse(s):
            if isinstance(node, Leaf):
                yield node
            else:
                assert isinstance(node, Node), node
                for child in node.children:
                    assert isinstance(child, Leaf), child
                    yield child

    def def_pattern(s: str) -> NegatedPattern:
        """Helper to create a NegatedPattern from a string."""
        return NegatedPattern

# Generated at 2022-06-23 16:05:25.445210
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    a = Leaf(1, "")
    b = Leaf(1, "")
    c = Leaf(1, "")
    l = [a,b,c]
    assert l == list(Leaf(1, "").leaves())


# Generated at 2022-06-23 16:05:28.169999
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(1, [Leaf(2, 'a'), Leaf(3, 'b')])
    assert repr(n) == "Node(1, [Leaf(2, 'a'), Leaf(3, 'b')])"


# Generated at 2022-06-23 16:05:33.200668
# Unit test for method post_order of class Base
def test_Base_post_order():
    def check_post_order(input_, expected_output):
        n = n_gen(input_)
        seen = set()
        result = []

        def f(node):
            seen.add(id(node))
            result.append(node)

        for x in n.post_order():
            f(x)

        if len(n.post_order()) != 1:
            raise AssertionError("%s.post_order() didn't yield exactly 1 value" % repr(n))
        if result != expected_output:
            raise AssertionError("%s.post_order() didn't yield %s" % (repr(n), repr(expected_output)))

# Generated at 2022-06-23 16:05:43.029232
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pygram import python_grammar
    from .pytree import Leaf

    # grammar = Grammar(grammar_file)
    grammar = python_grammar
    root = Leaf(55, 'root')
    a = Leaf(55, 'a')
    b = Leaf(55, 'b')
    c = Leaf(55, 'c')
    d = Leaf(55, 'd')

    A = Node(55, [a, b])
    B = Node(55, [c])
    C = Node(55, [d, A, B])

    root.append_child(A)
    A.append_child(B)
    B.append_child(C)

    # a.show()
    # assert [x.value for x in root.pre_order()] == ['a','b','c','d']


# Generated at 2022-06-23 16:05:53.192950
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import unittest
    from .pgen2.tokenize import NAME, COMMENT, ERRORTOKEN, tokenize_lines
    from .pgen2 import token
    
    # toke_name is used in repr of Leaf.
    from .pgen2 import tok_name

    class Tests(unittest.TestCase):
        def test_leaf_post_order(self):
            """test case for method post_order of class Leaf"""
            lines = ["abcd"]
            gen = tokenize_lines(lines)
            tk = next(gen)
            self.assertEqual(tk, (NAME, "abcd", (1, 0), (1, 4), lines[0]))
            self.assertEqual(tk[0], token.NAME)
            self.assertEqual(tk[3][0], 1)

# Generated at 2022-06-23 16:06:04.871621
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from . import python_grammar_no_print_statement
    from .pgen2.parse import ParseError
    from .fixer_util import Node
    import traceback
    # pass
    def get_symbol_names(tree):
        try:
            return [(node.type, node.value)
                    for node in tree.pre_order()]
        except AttributeError:
            return []
    def check_symbol_names(t, expected_symbol_names):
        # pass
        actual = get_symbol_names(t)
        if actual != expected_symbol_names:
            print("Symbol names do not match", file=sys.stderr)

# Generated at 2022-06-23 16:06:17.004784
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    LeafPattern(type=0)
    LeafPattern(type=255)
    LeafPattern(type=0, content='1')
    try:
        LeafPattern(type=256)
    except AssertionError:
        pass
    else:
        assert 0, 'Expected an exception'
    try:
        LeafPattern(type=-1)
    except AssertionError:
        pass
    else:
        assert 0, 'Expected an exception'
    try:
        LeafPattern(type=0.0)
    except AssertionError:
        pass
    else:
        assert 0, 'Expected an exception'
    try:
        LeafPattern(content='1')
    except AssertionError:
        pass
    else:
        assert 0, 'Expected an exception'

# Generated at 2022-06-23 16:06:24.655990
# Unit test for constructor of class NodePattern
def test_NodePattern():
    from .pgen2 import token

    for t in (None, token.NAME, token.NUMBER):
        for c in ("foo", "bar", "baz"):
            for n in (None, "n"):
                p = NodePattern(t, [LeafPattern(token.NAME, c)], n)
                assert p.type == t
                assert p.content == [LeafPattern(token.NAME, c)]
                assert p.name == n



# Generated at 2022-06-23 16:06:33.329802
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    pattern = NegatedPattern()
    assert pattern.match_seq([]) == True
    assert pattern.match_seq(['a']) == False
    assert pattern.match_seq('a') == False
    pattern2 = NegatedPattern(NodePattern(1))
    assert pattern2.match_seq(['a']) == False
    assert pattern2.match_seq('a') == False
    pattern3 = NegatedPattern(WildcardPattern(NodePattern(1)))
    assert pattern3.match_seq(['a']) == False
    assert pattern3.match_seq('a') == False



# Generated at 2022-06-23 16:06:37.815550
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import random
    from .pgen2 import token, driver

    type = random.randrange(256)
    content = random.randrange(256)
    name = random.choice(["name1", "name2", "name3"])
    p1 = (token.NAME, content, name)
    p2 = NodePattern(type, content, name)
    p3 = LeafPattern(type, content, name)
    for pattern in (p1, p2, p3):
        # no match
        for nodes in ([], [1, 2], [1, 2, 3]):
            assert tuple(pattern.generate_matches(nodes)) == ()
        # basic match
        for nodes in ([0], [0, 1], [0, 1, 2]):
            assert tuple(pattern.generate_matches(nodes))

# Generated at 2022-06-23 16:06:46.987844
# Unit test for method clone of class Node
def test_Node_clone():
    n = Node(
        python_symbols.if_stmt,
        [
            Leaf(
                token.NAME, "a", (1, 0), (1, 1), (1, 1),
            ),
            Node(
                python_symbols.suite,
                [
                    Leaf(
                        token.NEWLINE, "\n", (2, 0), (2, 0), (2, 1),
                    ),
                    Leaf(
                        token.NAME, "b", (3, 4), (3, 4), (3, 5),
                    ),
                    Leaf(
                        token.NEWLINE, "\n", (4, 0), (4, 0), (4, 1),
                    ),
                ],
                (2, 0),
            ),
        ],
        (1, 0),
    )
    c = n.clone()

# Generated at 2022-06-23 16:06:47.607735
# Unit test for method replace of class Base
def test_Base_replace():
    pass



# Generated at 2022-06-23 16:07:00.346019
# Unit test for method leaves of class Base

# Generated at 2022-06-23 16:07:10.726763
# Unit test for method remove of class Base
def test_Base_remove():
    """
    Test removing a node from the tree.
    """
    class MockNode(Base):
        def __init__(self, *children):
            self.children = list(children)
            for child in children:
                child.parent = self

        def depth(self):
            return 1

    class MockLeaf(Base):
        def depth(self):
            return 0

    class NotANode(object):
        pass

    def mktree(args):
        """
        Given a nested structure of arguments, return a tree of nodes.
        """
        if not isinstance(args, (tuple, list)):
            return MockLeaf(args)
        return MockNode(*[mktree(arg) for arg in args])


# Generated at 2022-06-23 16:07:13.946326
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    tree = parse_string("a and b")
    assert [t.value for t in tree.pre_order()] == ["a", "and", "b"]



# Generated at 2022-06-23 16:07:19.661908
# Unit test for method set_child of class Node
def test_Node_set_child():
    node = Node(1, [Leaf(1, "2"), Leaf(1, "3")])
    node.set_child(0, Leaf(1, "4"))
    assert node.children[0].value == "4"
    assert node.children[0].parent == node
    

# Generated at 2022-06-23 16:07:27.510201
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    """
    Simple test for bug that doesn't appear in the wild, but does occur in
    our tests.
    """

    grammar = """
    list_item.1: rule
    rule: KEYWORD
    """

    import blib2to3.pgen2.driver

    driver = blib2to3.pgen2.driver.Driver(grammar, "list_item", convert=False)
    pattern = driver.parse("KEYWORD", "list_item")
    nodes = list(pattern.pre_order())
    assert len(nodes) == 1
    assert not nodes[0].children
    assert nodes[0].type == 1
    assert nodes[0].parent is None



# Generated at 2022-06-23 16:07:39.408618
# Unit test for method clone of class Node
def test_Node_clone():
    """
    Unit test for method clone of class Node
    """
    from .pytree import Leaf, Node
    from .python_tree import CONVERT, DOT, NAME, STAR, STRING

    t = Node(
        CONVERT,
        [
            Node(
                DOT,
                [
                    Leaf(NAME, "a", prefix=" "),
                    Leaf(NAME, "b"),
                ],
            ),
            Leaf(STAR, "*", prefix=" "),
            Leaf(STRING, "'string'", prefix=" "),
        ],
    )
    t.changed()

# Generated at 2022-06-23 16:07:41.598746
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    assert(str(Base().get_suffix()) == "")


# Generated at 2022-06-23 16:07:46.970969
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    a=Node(258, [])
    b=Leaf(258, 'abc')
    try:
        a.insert_child(0, b)
        print("insert child has completed successfully")
    except:
        print("Insert child has failed")

# Generated at 2022-06-23 16:07:55.488070
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    source = FileSourceWrap("from foo import (", "test_input")
    file = FileInput(source)
    t = find_module("grammar", [os.path.split(__file__)[0]])
    gr = load_grammar(t)
    parser = Parser(gr, file)
    tree = parser.parse()
    n = Node(syms.importfrom, [])
    for i in range(100):
        n.append_child(Leaf(token.NAME, "from", (0, 4)))
        n.invalidate_sibling_maps()
        assert n.prev_sibling_map == None
        assert n.next_sibling_map == None

# Generated at 2022-06-23 16:08:00.707601
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    line_positions = [(1, 1)]
    name_mapping = {"a": 1}

# Generated at 2022-06-23 16:08:10.343787
# Unit test for constructor of class Leaf
def test_Leaf():
    # test input string
    leaf_str = '\t  /* comment */ "\""  '
    # test for context
    context: Context = (leaf_str[:10], (1, 10))
    # test for value
    value = leaf_str[10:].strip()
    # test for type
    type_ = token.STRING
    # test for prefix
    prefix = leaf_str[:10]

    leaf = Leaf(type_, value, context)
    assert leaf == (
        Leaf(type_, value, (prefix, (1, 10)), fixers_applied=[])
    ), f"\n{repr(leaf)},\n{repr(Leaf(type_, value, (prefix, (1, 10)), fixers_applied=[]))}"

# Generated at 2022-06-23 16:08:13.901764
# Unit test for constructor of class BasePattern
def test_BasePattern():
    import io
    import unittest
    p = BasePattern()
    s = io.StringIO()
    s.write(repr(p))
    unittest.TestCase().assertEqual(s.getvalue(), "BasePattern()")
    s.close()


# Generated at 2022-06-23 16:08:23.318386
# Unit test for constructor of class BasePattern
def test_BasePattern():
    def _check(pat, type, content, name):
        assert pat.type == type
        assert pat.content == content
        assert pat.name == name

    _check(BasePattern(10, 'foo'), 10, 'foo', None)
    _check(BasePattern(10, 'foo', 'FOO'), 10, 'foo', 'FOO')
    _check(BasePattern(10, 'foo', name='FOO'), 10, 'foo', 'FOO')
    _check(BasePattern(None), None, None, None)
    _check(BasePattern(), None, None, None)



# Generated at 2022-06-23 16:08:29.872090
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    # empty content
    pattern = WildcardPattern()
    assert pattern.min == 0
    assert pattern.max == HUGE
    assert pattern.content == None
    # content with one alternative
    pattern = WildcardPattern([WildcardPattern()])
    assert pattern.min == 0
    assert pattern.max == HUGE
    assert pattern.content == ([WildcardPattern()],)
    for min, max in [(1, 1), (0, 1), (1, HUGE), (2, 3)]:
        pattern = WildcardPattern(min=min, max=max)
        assert pattern.min == min
        assert pattern.max == max



# Generated at 2022-06-23 16:08:37.724851
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(type=123, content=["hello", "world"])
    assert p.type == 123
    assert p.content == ["hello", "world"]
    assert p.wildcards is False
    p = NodePattern(type=123, content=["hello", WildcardPattern()])
    assert p.type == 123
    assert p.content == ["hello", WildcardPattern()]
    assert p.wildcards is True



# Generated at 2022-06-23 16:08:43.723164
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "hello")
    assert l.type == 1
    assert l.value == "hello"
    l = Leaf(1, "hello", (None, (2, 3)))
    assert l._prefix is None
    assert l.lineno == 2
    assert l.column == 3


# Generated at 2022-06-23 16:08:51.611719
# Unit test for method depth of class Base
def test_Base_depth():
    class Node(Base): ...
    class Leaf(Base): ...

    node = Node()
    assert node.depth() == 0
    leaf = Leaf()
    leaf.parent = node
    assert leaf.depth() == 1
    leaf2 = Leaf()
    leaf2.parent = leaf
    assert leaf2.depth() == 2
    leaf3 = Leaf()
    leaf3.parent = leaf2
    assert leaf3.depth() == 3
    leaf4 = Leaf()
    leaf4.parent = leaf3
    assert leaf4.depth() == 4




# Generated at 2022-06-23 16:08:54.671972
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    leaf_node=Leaf(256,'one')
    assert list(leaf_node.post_order())==[leaf_node]


# Generated at 2022-06-23 16:08:58.766827
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w = WildcardPattern([[Leaf(token.NAME, "aaa")]], name="foo")
    assert w.content == ([(Leaf(token.NAME, "aaa"),)],)
    assert w.name == "foo"
    assert w.min == 0
    assert w.max == HUGE



# Generated at 2022-06-23 16:09:10.093368
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    # .*
    assert WildcardPattern().min == 0 and WildcardPattern().max == HUGE
    assert len(list(WildcardPattern().generate_matches([1, 2, 3]))) == 4
    assert len(list(WildcardPattern().generate_matches([]))) == 1
    # .+
    assert WildcardPattern(min=1).min == 1 and WildcardPattern(min=1).max == HUGE
    assert len(list(WildcardPattern(min=1).generate_matches([1, 2, 3]))) == 4
    assert len(list(WildcardPattern(min=1).generate_matches([]))) == 0
    # .?
    assert WildcardPattern(max=1).min == 0 and WildcardPattern(max=1).max == 1

# Generated at 2022-06-23 16:09:17.855034
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    for c in (None, [1, 2, 3], [[], [], []], [[], [1], []]):
        for min in (0, 1):
            for max in (HUGE, 1, 2, 3):
                wp = WildcardPattern(c, min, max)
                assert wp.min == min
                assert wp.max == max
                assert wp.content == c
                if c is None:
                    assert wp.name == "."
                else:
                    assert wp.name == None


#
# Functions that make it easier to build the grammar
#


# Generated at 2022-06-23 16:09:22.954037
# Unit test for method __str__ of class Node
def test_Node___str__():
    no = Node(0, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    assert str(no) == "abc"



# Generated at 2022-06-23 16:09:32.159739
# Unit test for method insert_child of class Node

# Generated at 2022-06-23 16:09:43.480320
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    # match is really a wrapper for match_seq, so not much to test here
    from .tree import Node, Leaf
    from .parser import OP, NAME
    from . import patterns

    W = patterns.WildcardPattern

    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Leaf(1, "c")
    a_ = Node(OP, [a])
    b_ = Node(OP, [b])
    c_ = Node(OP, [c])
    a__ = Node(OP, [a_])
    b__ = Node(OP, [b_])
    ab_ = Node(OP, [a, b])
    bc_ = Node(OP, [b, c])
    abc = Node(OP, [a, b, c])

    # Should return false because a wild

# Generated at 2022-06-23 16:09:53.090841
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern() == WildcardPattern(None, 0, HUGE)
    assert WildcardPattern(None, 1, HUGE) == WildcardPattern(None, 1, HUGE, None)
    assert WildcardPattern(None, 0, 1) == WildcardPattern(None, 0, 1, None)
    assert WildcardPattern(min=1, max=1) == WildcardPattern(None, 1, 1, None)
    assert WildcardPattern(None).__class__ == WildcardPattern
    assert WildcardPattern(None, 1, 3).__class__ == WildcardPattern
    assert WildcardPattern(None, 1, 1).__class__ == NodePattern
    assert WildcardPattern([[1, 2], [3]]).__class__ == WildcardPattern



# Generated at 2022-06-23 16:09:57.156729
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    name = 'Leaf'
    def_arg = 'test'
    def_res = "{}({}, {})".format(name, 'test', str(repr('')))
    try:
        assert def_res == def_arg
    except AssertionError:
        print('AssertionError: ', def_res, '!=', def_arg)


# Generated at 2022-06-23 16:10:01.098667
# Unit test for method clone of class Base
def test_Base_clone():
    #
    # Test methods in class Base.
    #
    b0 = Base()
    # Clone of Base class should fail
    try:
        b1 = b0.clone()
    except NotImplementedError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 16:10:12.581148
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from . import pygram
    from blib2to3.pgen2 import token

    begin_tok = [(token.NAME, "begin_func"),
         (token.INDENT, "    "),
         (token.NAME, "done_func"),
         (token.DEDENT, "")]

    pytree = Leaf(begin_tok[0][0], begin_tok[0][1], prefix = "")
    pytree.add_prefix("  ")
    pytree.add_child(Leaf(begin_tok[1][0], begin_tok[1][1], prefix = ""))
    test_node = pytree.children[0]
    test_node.add_prefix("  ")

# Generated at 2022-06-23 16:10:16.339611
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node = Node(260, [Leaf(1, '', (0, 0), prefix=''), Node(268, [Leaf(3, '', (2, 2), prefix='')]), Leaf(4, '', (0, 0), prefix='')])
    assert 1==1
# unit test for method clone of class Node

# Generated at 2022-06-23 16:10:27.061570
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
  import unittest
  from grako.tool import compile
  ns = compile(
      "expr = '(' expr ')';"
      "expr = expr '+' expr;"
      "expr = expr '*' expr;"
      "expr = [0-9]+;"
      "expr = '.';"
  )
  t = ns.expr

# Generated at 2022-06-23 16:10:35.572146
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp = WildcardPattern((), 1, 1)
    np = NodePattern()
    assert wp.optimize() == np
    wp2 = WildcardPattern((), 0, 1)
    assert wp2.optimize() == WildcardPattern((), 0, 1, None)
    np2 = NodePattern(None, None, 'x')
    wp3 = WildcardPattern((), 1, 1, 'x')
    assert wp3.optimize() == np2
    wp4 = WildcardPattern((), 0, 1, 'x')
    assert wp4.optimize() == WildcardPattern((), 0, 1, 'x')
    wp5 = WildcardPattern((), 0, HUGE, 'x')
    assert wp5.optimize() == WildcardPattern((), 0, HUGE, 'x')
    sub

# Generated at 2022-06-23 16:10:40.789666
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(0, [])
    # Verify that repr(obj) works
    assert repr(node)
    # Verify that repr() returns a str type
    assert isinstance(repr(node), str)
    # Verify that repr() returns a str that looks like a valid constructor
    assert 'Node' in repr(node)



# Generated at 2022-06-23 16:10:53.083958
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Testing BasePattern.optimize

    class Foo(BasePattern):
        def match(self, node, results=None):
            return False

    assert Foo(0).optimize() is Foo(0)
    assert Foo(0, 'bar').optimize() is Foo(0, 'bar')
    assert Foo(0, content=['bar']).optimize() is Foo(0, ['bar'])
    assert Foo(0, 'bar', 'baz').optimize() is Foo(0, 'bar', 'baz')
    assert Foo(0, content=['bar'], name='baz').optimize() is Foo(0, ['bar'], 'baz')
    assert Foo(0, 'bar', name='baz').optimize() is Foo(0, 'bar', 'baz')

# Generated at 2022-06-23 16:11:02.150558
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .patcomp import PatternCompiler
    from .pytree import Leaf, Node
    from .pygram import python_grammar
    from . import pytree
    from . import pygram

    class AbstractMatcher(object):

        def __init__(self, pattern: Sequence[str]) -> None:
            self.grammar = python_grammar
            self.pattern_compiler = PatternCompiler(self.grammar)
            self.pattern_compiler.compile_literals(pattern)

        def match(self, tree: NL) -> bool:
            return self._match(tree)

        def _match(self, tree: NL) -> bool:
            return False


# Generated at 2022-06-23 16:11:14.958322
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node, Internal

    class L(Leaf):
        def leaves(self):
            return [self]

    class N(Node):
        def leaves(self):
            return [self]

    class I(Internal):
        def leaves(self):
            return [self]


# Generated at 2022-06-23 16:11:26.839064
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    """
    Test that WildcardPattern.generate_matches implements all requirements
    specified in its docstring.  See also test_match.
    """
    # Match a single node
    p = WildcardPattern(min=1, max=1)
    assert list(p.generate_matches([42])) == [(1, {})]
    assert not list(p.generate_matches([]))
    assert not list(p.generate_matches([42, 24]))

    # Match two nodes
    p = WildcardPattern(min=2, max=2)
    assert list(p.generate_matches([42, 24])) == [(2, {})]
    assert not list(p.generate_matches([42]))

# Generated at 2022-06-23 16:11:34.917526
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # Note "bare_name" is the name of the first argument to the
    # original pattern.
    p = WildcardPattern([NodePattern(name="bare_name")])
    p = p.optimize()
    p = p.optimize()
    p = p.optimize()
    assert p.name == "bare_name", repr(p.name)
    assert p.min == 1, repr(p.min)
    assert p.max == 1, repr(p.max)
    assert p.content is None, repr(p.content)



# Generated at 2022-06-23 16:11:41.995188
# Unit test for method append_child of class Node
def test_Node_append_child():
    import re
    import os
    os.system("start cmd /C python pgen2/driver.py test.py 2> result.txt")
    f = open("D:\\test.txt", "r")
    if len(f.readlines())>0:
        print ("test_Node_append_child PASSED")
    else:
        print("test_Node_append_child FAILED")

test_Node_append_child()


# Generated at 2022-06-23 16:11:53.474794
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    ## Base
    class A(Base):
        def __init__(self, *args):
            self.args = args
        def pre_order(self):
            yield self, self.args
            for a in self.args:
                if isinstance(a, Base):
                    yield from a.pre_order()
    a1, a2, a3 = A(1), A(2), A(3)
    b1 = A(a1, a2, a3)
    c1 = A(a2, b1)
    test = list(c1.pre_order())
    assert len(test) == 9, test
    assert test[0][0] is c1, test[0][0]
    assert test[0][1] == (a2, b1), test[0][1]