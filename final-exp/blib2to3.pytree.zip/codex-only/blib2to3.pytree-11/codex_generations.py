

# Generated at 2022-06-23 16:01:58.204056
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    pat = LeafPattern(1, "foo")
    assert pat.type == 1
    assert pat.content == "foo"
    assert pat.name is None
    pat = LeafPattern(1, content="foo")
    assert pat.type == 1
    assert pat.content == "foo"
    assert pat.name is None
    pat = LeafPattern(type=1, content="foo")
    assert pat.type == 1
    assert pat.content == "foo"
    assert pat.name is None



# Generated at 2022-06-23 16:02:01.631306
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    node = Leaf(1, "x")
    assert str(node) == 'x'


# Generated at 2022-06-23 16:02:03.590744
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(3, "a")
    #print(list(leaf.leaves()))
    #pass


# Generated at 2022-06-23 16:02:10.686764
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
     assert WildcardPattern(name = "bare_name").optimize() == WildcardPattern(name = "bare_name")
     assert WildcardPattern(name = "bare_name", min = 1).optimize() == WildcardPattern(name = "bare_name", content = None)
     assert WildcardPattern(name = "bare_name", content = [[WildcardPattern(name = "bare_name")]]).optimize() == WildcardPattern(name = "bare_name", content = [[WildcardPattern(name = "bare_name")]], min = 2)
     assert WildcardPattern(name = "bare_name", min = 3).optimize() == WildcardPattern(name = "bare_name", min = 3)

# Generated at 2022-06-23 16:02:13.916158
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(256, [Leaf(1, '', (1, 2))])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map == None
    assert node.next_sibling_map == None


# Generated at 2022-06-23 16:02:21.054206
# Unit test for method __str__ of class Node
def test_Node___str__():
    import unittest
    from . import pytree

    class NodeTest(unittest.TestCase):
        def test___str__(self):
            self.assertEqual(
                pytree.Node(symbol.foo, []).__str__(), "")
            self.assertEqual(
                pytree.Node(symbol.foo, [Leaf(1, "23"), Leaf(1, "45")]).__str__(), "2345")

    unittest.main()



# Generated at 2022-06-23 16:02:23.823412
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """Unit test for method __new__ of class BasePattern"""
    with pytest.raises(AssertionError):
        BasePattern()



# Generated at 2022-06-23 16:02:35.751533
# Unit test for function generate_matches
def test_generate_matches():
    # p1 matches "a"
    p1 = NodePattern(type=tokenize.NAME)
    # p2 matches "b"
    p2 = NodePattern(type=tokenize.NAME)
    # p3 matches "c"
    p3 = NodePattern(type=tokenize.NAME)
    # p4 matches "d"
    p4 = NodePattern(type=tokenize.NAME)
    # p5 matches "e"
    p5 = NodePattern(type=tokenize.NAME)
    # p6 matches "f"
    p6 = NodePattern(type=tokenize.NAME)

    # 1. a b c
    for x in generate_matches([p1, p2, p3], [NL(tokenize.NAME), NL(tokenize.NAME), NL(tokenize.NAME)]):
        print(x)

# Generated at 2022-06-23 16:02:39.182512
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1, "token.NEWLINE"
    assert type_repr(python_symbols.NEWLINE) == "NEWLINE"


# Abstract classes


# Generated at 2022-06-23 16:02:43.065451
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    node = Node(python_symbols.file_input, [])
    child = Leaf(token.NAME, "foo")
    node.insert_child(0, child)
    assert child.parent is node
    assert node.children == [child]
    assert node.was_changed


# Generated at 2022-06-23 16:02:52.325916
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert LeafPattern(1, "a", "x").type == 1
    assert LeafPattern(1, "a", "x").content == "a"
    assert LeafPattern(1, "a", "x").name == "x"
    assert LeafPattern(1, None).content is None
    assert LeafPattern(1).type == 1
    assert LeafPattern().type is None

    def f():
        LeafPattern(257)

    raises(AssertionError)(f)()
    raises(AssertionError)(LeafPattern)(1, 3)
    raises(AssertionError)(LeafPattern)(1, "a", 3)



# Generated at 2022-06-23 16:03:03.109813
# Unit test for method post_order of class Node
def test_Node_post_order():
    from blib2to3.pgen2.pgen import _add_grammar_rules, _add_grammar_pickles
    import pgen2
    _add_grammar_rules(pgen2.python_grammar_no_print_statement,
                        pgen2.python_grammar_no_print_statement_2to3_conversions)
    _add_grammar_pickles(pgen2.pickle, pgen2.pickle2)
    from pgen2 import driver
    from . import pytree
    from .fixer_util import Constant

    kwargs = {'print_statement': False}
    grammar = driver.load_grammar(**kwargs)
    tr = pytree.Node(-1, [], prefix='', values={'type':'test_type'})
    n = pytree

# Generated at 2022-06-23 16:03:04.276938
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(0, '0')
    assert l.leaves() == [l]

# Generated at 2022-06-23 16:03:12.141663
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert not LeafPattern(type=1).content
    assert not isinstance(LeafPattern(type=1), WildcardPattern)
    assert LeafPattern(type=1).type == 1
    assert LeafPattern(content="x").type is None
    assert LeafPattern(content="x").content == "x"
    assert LeafPattern(type=2, content="x").type == 2
    assert LeafPattern(type=2, content="x").content == "x"
    assert not LeafPattern(type=1, content="x").type == 1
    assert not LeafPattern(type=1, content="x").content == "x"
# /Unit test for constructor of class LeafPattern



# Generated at 2022-06-23 16:03:16.749099
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    class Node1:
        def _eq(self, other):
            return True

    class Node2:
        def _eq(self, other):
            return True

    n1 = Node1()
    n2 = Node2()
    assert n1 != n2

# Generated at 2022-06-23 16:03:27.166993
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    from . import token

    g = driver.load_grammar("Grammar/Grammar", convert)
    # input = "a + b"
    input = "a + b * c"
    t = g.parse(input)
    assert t.type == token.FILE_INPUT
    assert t.children[1].type == token.NEWLINE
    assert t.children[1].children[1].value == '\n'
    t.children[1].value = ' '
    assert input == str(t)
    print("finished test_convert()")


# Generated at 2022-06-23 16:03:34.231902
# Unit test for function convert
def test_convert():
    import pytest
    from .pgen2 import pgen
    gr = pgen.driver.load_grammar()
    tree = pytest.importorskip('mypy.test.data')
    assert isinstance(convert(gr, tree.break_stmt), Node)
    assert isinstance(convert(gr, tree.else_suite), Node)
    assert isinstance(convert(gr, tree.if_stmt_no_else), Node)
    assert isinstance(convert(gr, tree.for_stmt_pre_expr), Node)
    assert isinstance(convert(gr, tree.dot), Leaf)



# Generated at 2022-06-23 16:03:42.677051
# Unit test for method leaves of class Base
def test_Base_leaves():

    from .pygram import python_symbols as syms

    pr = Parser(Grammar, python_grammar)

    # test root.leaves()
    t = pr.parse_string(b"x = 1\n", "exec")
    xid = Node(syms.file_input, [Leaf(1, b"x"), Leaf(11, b"="), Leaf(1, b"1")])
    assert t == xid
    assert list(xid.leaves()) == list(t.leaves())

    # test inner.leaves()
    t = pr.parse_string(b"x = [1, 2, 3]\n", "exec")

# Generated at 2022-06-23 16:03:51.620121
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    # Default constructor
    pattern = LeafPattern()
    assert pattern.type is None
    assert pattern.content == None
    assert pattern.name == None

    # two-arg constructor
    pattern = LeafPattern(token.NAME, "foo")
    assert pattern.type == token.NAME
    assert pattern.content == "foo"
    assert pattern.name == None

    # three-arg constructor
    pattern = LeafPattern(token.NAME, "foo", "name")
    assert pattern.type == token.NAME
    assert pattern.content == "foo"
    assert pattern.name == "name"

    # four-arg constructor
    pattern = LeafPattern(token.NAME, "foo", "name", "foo")
    assert pattern.type == token.NAME
    assert pattern.content == "foo"
    assert pattern.name == None

    # Match a node

# Generated at 2022-06-23 16:03:59.146652
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node

    a = Node(0, [Leaf(0)])
    b = Node(0, [Leaf(0), Leaf(0), Leaf(0)])
    c = Node(0, [a, b, Leaf(0)])
    d = Node(0, [b, c, a])
    assert list(d.leaves()) == [Leaf(0), Leaf(0), Leaf(0), Leaf(0), Leaf(0)]



# Generated at 2022-06-23 16:04:08.357713
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import libcst as cst
    assert cst.parse_statement("a; b").get_suffix() == "b"
    assert cst.parse_statement("a; b;").get_suffix() == ""

    # Test a node which is not a leaf, but has a leaf as a next sibling.
    assert cst.parse_statement("b; a").body[1].get_suffix() == "a"

    # Test a node which is not a leaf and has no next sibling.
    assert cst.parse_statement("a").body[0].get_suffix() == ""

    # Test a node which is not a leaf and has no next sibling.
    assert cst.parse_expression("1+2").get_suffix() == ""

    # Test a node which has a parent, but no next sibling.
    assert c

# Generated at 2022-06-23 16:04:17.054656
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    import pytest
    from typing import List

    from grako.tool import compile_bnf, parse
    from grako.model import ModelBuilderSemantics
    from grako.parsing import EarleyParser
    from grako.util import trim, dedent, asjson

    class AST:
        def __init__(self, *args, **kwargs):
            self.children = []
            for key, value in kwargs.items():
                setattr(self, key, value)
                self.children.append(value)

        def __repr__(self):
            return 'AST({})'.format(', '.join(f'{key}={value!r}'
                                              for key, value in self.__dict__.items()))


# Generated at 2022-06-23 16:04:27.665029
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf
    from . import pygram

    def _iter_nodes(node):
        yield node
        for child in node.children:
            yield from _iter_nodes(child)

    class Node(Base):
        """Fake Node class for testing purposes."""

        def __init__(self, type, child1, child2):
            self.type = type
            self.children = [child1, child2]

        def _eq(self, other):
            return self.type == other.type

        def clone(self):
            return self

        def post_order(self):
            return _iter_nodes(self)

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

    # Build a simple parse tree
    #

# Generated at 2022-06-23 16:04:31.150053
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l1 = Leaf(1, "l1")
    res = list(l1.post_order())
    assert res == [l1], res


# Generated at 2022-06-23 16:04:39.370500
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    from .tokenize import tokenize
    from sys import version_info
    import re
    import builtins
    try:
        from . import pytoken
    except ImportError:
        pytoken = None
    if version_info >= (3, 6):
        # From the Python code, we know that python_symbols.OP maps to
        # the integer token.OP, which is an int.  But we don't know
        # that python_symbols.STRING for example maps to token.STRING.
        # Let's find out what token.STRING is.
        token_STRING = None
        for (name, val) in pytoken.__dict__.items():
            if name == "STRING":
                token_STRING = val
                break
        assert token_STR

# Generated at 2022-06-23 16:04:40.517377
# Unit test for function convert
def test_convert():
    input_ = (1, 'foo', None, [])
    expected = Leaf(1, 'foo')
    actual = convert(None, input_)
    assert actual == expected


# Generated at 2022-06-23 16:04:48.839279
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    python_symbols = Grammar().python_symbols
    test_list = [Leaf(type=python_symbols.NAME, value='a'),
                 Node(type=python_symbols.simple_stmt,
                      children=[Leaf(type=python_symbols.NAME, value='b'),
                                Leaf(type=python_symbols.EQUAL, value='='),
                                Leaf(type=python_symbols.NAME, value='c')])]
    test_Node = Node(type=python_symbols.compound_stmt,
                     children=test_list)
    test_Node.invalidate_sibling_maps()
    assert test_Node.prev_sibling_map is None
    assert test_Node.next_sibling_map is None


# Unit test

# Generated at 2022-06-23 16:04:57.855558
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import type_repr
    from .pygram import python_symbols as syms
    from .pygram import python_operators as ops
    from .pygram import make_grammar
    import re
    import unittest

    class TestNode(unittest.TestCase):
        def test_empty_children(self):
            node = Node(syms.file_input, [])
            node.update_sibling_maps()
            self.assertEqual(node.prev_sibling_map, {})
            self.assertEqual(node.next_sibling_map, {})

        def test_single_child(self):
            node = Node(syms.file_input, [Leaf(1, "x")])
            node.update_sibling_maps()
            self.assertEqual

# Generated at 2022-06-23 16:04:58.443497
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    Leaf(0, "").leaves()

# Generated at 2022-06-23 16:05:03.438493
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1,'a');
    result = l.post_order();

# Generated at 2022-06-23 16:05:04.559171
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "leaf")
    assert list(leaf.leaves()) == [leaf]

# Generated at 2022-06-23 16:05:06.802049
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(lambda x: x)
    p = NodePattern(None, None)
    p = NodePattern(None)
    p = NodePattern(None, tuple())
    p = NodePattern(None, [])
    p = NodePattern(None, [lambda x: x])
    p = NodePattern(None, [(lambda x: x)])



# Generated at 2022-06-23 16:05:15.341658
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    w = WildcardPattern()
    assert w.match(pygram.python_symbols.simple_stmt)
    assert w.match(pygram.python_symbols.compound_stmt)
    assert w.match(pygram.python_symbols.eval_input)
    assert not w.match(pygram.python_symbols.subscript_list)
    assert not w.match(pygram.python_symbols.subscript_list_not_name)
    assert not w.match(pygram.python_symbols.subscript_list_not_name_list)
    assert w.match(pygram.python_symbols.subscript_list_not_name2)

# Generated at 2022-06-23 16:05:21.844947
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    for c in range(1, 5):
        for n in range(1, 5):
            np = NegatedPattern(WildcardPattern(None, min=c))
            assert not np.match_seq([None] * n)
            if n < c:
                assert np.match_seq([None] * (n - 1))
    np = NegatedPattern()
    assert np.match_seq([])
    assert not np.match_seq([None])



# Generated at 2022-06-23 16:05:30.512837
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import tok_name

    # Test for class 'BasePattern'
    pat1 = LeafPattern(1)
    pat2 = NodePattern(2)
    pat3 = LeafPattern(3)
    leaf1 = Leaf(1, "leaf1")
    leaf2 = Leaf(2, "leaf2")
    leaf3 = Leaf(3, "leaf3")
    leaf4 = Leaf(4, "leaf4")
    node1 = Node(1, [leaf1, leaf2])
    node2 = Node(2, [leaf2, leaf3])
    node3 = Node(3, [leaf3, leaf4])
    node4 = Node(4, [leaf4, leaf1])
    r = {}
    assert pat1.match(leaf1, r)
    assert len(r) == 1

# Generated at 2022-06-23 16:05:41.067911
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.parse import parse
    from .pgen2.tokenize import generate_tokens, untokenize, TokenInfo
    from .pgen2 import token


# Generated at 2022-06-23 16:05:51.515632
# Unit test for method depth of class Base
def test_Base_depth():
    class Derived(Base):
        def __init__(self):
            Base.__init__(self)
    def make_obj():
        node = Derived()
        node.type = 3
        node.parent = None
        node.children = []
        node.was_changed = True
        node.was_checked = True
        return node
    assert isinstance(Base.depth(make_obj()), int)

    class Derived(Base):
        def __init__(self):
            Base.__init__(self)
    def make_obj():
        node = Derived()
        node.type = 3
        node.parent = None
        node.children = []
        node.was_changed = True
        node.was_checked = True
        return node

# Generated at 2022-06-23 16:05:58.751487
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    from . import ast

    n1 = ast.parse("1")
    n2 = ast.parse("2")
    n3 = ast.parse("1 + 2")
    n4 = ast.parse("1 + 2 + 3")
    n5 = ast.parse("1 + 3")
    n6 = ast.parse("1 + 2 + 4")
    n7 = ast.parse("4")
    n8 = ast.parse("4 + 5")
    n9 = ast.parse("5")

    p1 = NodePattern(type=token.PLUS, name="PLUS")
    p_ = NodePattern(type=token.PLUS)

    p2 = WildcardPattern([p1, p_], min=1, name="plus")

# Generated at 2022-06-23 16:06:09.437088
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w = WildcardPattern(((Leaf(token.NAME, "func"),),), name="decorator")
    tail = WildcardPattern(((Leaf(token.NAME, "func"),),), name="decorator")
    w = WildcardPattern(((Leaf(token.NAME, "func"),),), min=1, max=1, name="decorator")
    assert w == WildcardPattern(((Leaf(token.NAME, "func"),),), min=1, max=1, name="decorator")
    w = WildcardPattern(min=2, max=2, name="decorator")
    assert w == WildcardPattern(min=2, max=2, name="decorator")
    w = WildcardPattern(min=1, max=1, name="decorator")
    assert w == WildcardPattern

# Generated at 2022-06-23 16:06:20.193704
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import unittest
    class TestNodeUpdateSiblingMaps(unittest.TestCase):
        def setUp(self):
            self.node = Node(
                python_symbols.file_input,
                [None, None]
            )
            self.node.children[0] = Node(
                python_symbols.simple_stmt,
                [Leaf(1, "a"), Leaf(2, "b")]
            )
            self.node.children[1] = Node(
                python_symbols.simple_stmt,
                [Leaf(1, "c"), Leaf(2, "d")]
            )
            self.node.children[0].children[0].parent = self.node.children[0]
            self.node.children[0].children[1].parent = self.node

# Generated at 2022-06-23 16:06:28.870999
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    n = nltk.grammar.Nonterminal("A")
    vb = nltk.grammar.Nonterminal("VB")
    to = nltk.grammar.Nonterminal("TO")
    print(n, vb, to)
    nodes = [Leaf(0, "'play'", 0), Leaf(0, "'football'", 0)]
    content = [[LeafPattern(n)], [LeafPattern(vb), LeafPattern(to)]]
    max = 5
    min = 2
    name = "bare_name"
    wildcard = WildcardPattern(content, min, max, name)

# Generated at 2022-06-23 16:06:33.697563
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern()
    assert p.optimize() is p
    p = WildcardPattern(min=4, max=4)
    assert p.optimize() is p
    p = WildcardPattern(min=0, max=0)
    assert isinstance(p.optimize(), EmptyPattern)
    p = WildcardPattern(min=1, max=1)
    assert isinstance(p.optimize(), NodePattern)
    p = WildcardPattern(((LeafPattern(1, 'a'), ), ))
    assert isinstance(p.optimize(), NodePattern)
    p = WildcardPattern(((LeafPattern(1, 'a'), ), ), 1, 1)
    assert isinstance(p.optimize(), NodePattern)
    p = WildcardPattern(min=1, max=1)

# Generated at 2022-06-23 16:06:40.921149
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern()
    assert n.type is None
    assert n.content is None
    n = NodePattern(1)
    assert n.type == 1
    assert n.content is None
    n = NodePattern(content=(LeafPattern(1),))
    assert n.type is None
    assert n.content == (LeafPattern(1),)
    n = NodePattern(1, (LeafPattern(1),))
    assert n.type == 1
    assert n.content == (LeafPattern(1),)



# Generated at 2022-06-23 16:06:49.637405
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    def only_0(nodes):
        yield 0, nodes
    def nothing(nodes):
        return
    class Type:
        def match(self, node, results=None):
            return False
        def match_seq(self, nodes, results=None):
            return False
        def generate_matches(self, nodes):
            return
    class Type2:
        def match(self, node, results=None):
            return True
        def match_seq(self, nodes, results=None):
            return True
        def generate_matches(self, nodes):
            yield 0, nodes

    def test(a, b):
        res0 = list(a.generate_matches(b))
        res1 = list(a.generate_matches(b))

# Generated at 2022-06-23 16:06:54.389913
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pygram import python_symbols as syms
    from . import pytree
    from itertools import islice
    from io import StringIO

# Generated at 2022-06-23 16:07:03.390684
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.grammar import Symbol

    class X(BasePattern):
        pass

    class Y(X):
        optimize = X.optimize

    try:
        X(Symbol.expr)
    except TypeError:
        pass
    else:
        raise AssertionError

    assert Y(Symbol.expr).optimize().type == Symbol.expr
    assert Y(Symbol.expr, "foo").optimize().content == "foo"
    assert Y(Symbol.expr, "foo", "name").optimize().name == "name"
    assert Y(Symbol.expr).optimize() is Y(Symbol.expr)
    assert isinstance(X(Symbol.expr), Y)

    # Make sure that a subclass can define its own constructor:

# Generated at 2022-06-23 16:07:13.698786
# Unit test for function generate_matches
def test_generate_matches():
    import _ast

    def check(pat, nodes, results):
        print(pat)
        g = generate_matches(pat, nodes)
        if results is None:
            assert next(g, None) is None
        else:
            assert results[0] == next(g)
    p = NodePattern()
    e = [_ast.Expr()]
    assert next(generate_matches([], [])) == (0, {})
    assert next(generate_matches([], e)) == (0, {})
    assert next(generate_matches([p], [])) is None
    assert next(generate_matches([p], e)) == (1, {})

# Generated at 2022-06-23 16:07:24.775079
# Unit test for method __str__ of class Node

# Generated at 2022-06-23 16:07:29.035721
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    try:
        LeafPattern('x')
    except AssertionError:
        pass
    else:
        raise AssertionError
test_LeafPattern.unittest = [] # type: ignore



# Generated at 2022-06-23 16:07:40.732663
# Unit test for method generate_matches of class NegatedPattern

# Generated at 2022-06-23 16:07:45.251604
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(3, [Leaf(2, 'hello'), Leaf(1, 'world')])
    assert repr(n) == 'Node(2, [Leaf(2, \'hello\'), Leaf(1, \'world\')])'



# Generated at 2022-06-23 16:07:49.707312
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    def test(self, other, result):
        l = Leaf(self, other, context=None)
        r = LeafPattern(self, other, name=None)
        return r.match(l) == result

    assert test(1, 1, True)
    assert test(1, 0, False)
    assert test(2, 1, False)



# Generated at 2022-06-23 16:07:55.491973
# Unit test for method pre_order of class Base
def test_Base_pre_order():

    # two composite nodes
    n = Node(1, "foo", None, [Leaf(1, "bar"), Leaf(2, "baz")])
    n2 = Node(1, "", None, [Leaf(1, "bar")])
    # one leaf
    l = Leaf(1, "bar")

    # iterate over each node, in pre-order
    assert list(n.pre_order()) == [n, n.children[0], n.children[1]]
    assert list(l.pre_order()) == [l]
    assert list(n2.pre_order()) == [n2, n2.children[0]]



# Generated at 2022-06-23 16:08:03.151696
# Unit test for method __new__ of class Base
def test_Base___new__():
    """Test method Base.__new__ of class Base"""

    from .pytree import Leaf

    # XXX insert your test code here.
    # def __new__(cls, *args, **kwds) above should be tested.
    # See the print in __new__ for info on arguments.
    assert Base is not Base
    assert Base() is not Base()
    assert Base() is not Leaf()
    assert Base(Leaf(), Leaf()).children == [Leaf(), Leaf()]


# Generated at 2022-06-23 16:08:05.674402
# Unit test for method leaves of class Base
def test_Base_leaves():
    b = Base()
    b.children = [1, 2]
    assert list(b.leaves()) == [1, 2]



# Generated at 2022-06-23 16:08:10.443024
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    cts = ['a', 'b', 'c']
    ts = [Leaf(1, x) for x in cts]
    ls = [x.leaves() for x in ts]
    assert ls == [[Leaf(1, cts[0])], [Leaf(1, cts[1])], [Leaf(1, cts[2])]]

# Generated at 2022-06-23 16:08:16.313904
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Base subclass with __new__
    class SpecialNode(Node):

        def __new__(cls, *args, **kwds):
            return Node.__new__(cls, *args, **kwds)

        def __init__(self, *args, **kwds):
            pass

    class SpecialLeaf(Leaf):

        def __new__(cls, *args, **kwds):
            return Leaf.__new__(cls, *args, **kwds)

        def __init__(self, *args, **kwds):
            pass

# Generated at 2022-06-23 16:08:21.513697
# Unit test for method __str__ of class Node
def test_Node___str__():
    from .pytree import Leaf
    n = Node(
        1,
        [
            Leaf(1, "test"),
            Leaf(2, ":"),
            Leaf(3, "test"),
        ]
    )
    assert str(n) == "test:test"


# Generated at 2022-06-23 16:08:25.868559
# Unit test for function convert
def test_convert():
    gr = Grammar()
    node1 = RawNode(1, "", "", [1, 2])
    assert convert(gr, node1) == Node(1, [1, 2], "")
    node2 = RawNode(1, "", "", [])
    assert convert(gr, node2) == Leaf(1, "")

# Generated at 2022-06-23 16:08:26.775734
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()



# Generated at 2022-06-23 16:08:28.342420
# Unit test for constructor of class BasePattern
def test_BasePattern():
    BasePattern()



# Generated at 2022-06-23 16:08:32.557537
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2 import token
    from .pgen2 import driver

    test_grammar = """
        stmt: simple_stmt | compound_stmt
        simple_stmt: NAME NEWLINE
        compound_stmt: pass_stmt
        pass_stmt: "pass" NEWLINE
    """
    test_input = "var = 42\n"
    node = driver.parse_string(test_grammar, test_input, convert=convert)
    assert node.type == token.NEWLINE
    assert node.type == 256

    r = Results()
    pattern = LeafPattern(type=token.NAME)
    assert pattern.match_seq([node], r)
    assert r == {'%leaf': node}
    assert r['%leaf'].value == 'var'


# Generated at 2022-06-23 16:08:42.300318
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    _arguments = {}
    _arguments['type'] = 1
    _arguments['value'] = '+'
    _arguments['context'] = ('[', (1, 0))
    _arguments['prefix'] = ' '
    _arguments['fixers_applied'] = [
  'dummy',
]
    _cloned = Leaf(**_arguments)
    assert _cloned is _arguments['type']
    _cloned = Leaf(**_arguments)
    assert _cloned is _arguments['value']
    _cloned = Leaf(**_arguments)
    assert _cloned is _arguments['context']
    _cloned = Leaf(**_arguments)
    assert _cloned is _arguments['prefix']
    _cloned = Leaf(**_arguments)
    assert _

# Generated at 2022-06-23 16:08:52.162007
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    nodes = [1,2,3]
    try:
        assert(NegatedPattern().match_seq(nodes))
    except Exception as e:
        print("AssertionError in case 1 ",e)
    nodes1 = []
    try:
        assert(NegatedPattern().match_seq(nodes1))
    except Exception as e:
        print("AssertionError in case 2 ",e)
    nodes2 = [1,2,3,4,5]
    try:
        assert(NegatedPattern().match_seq(nodes2) == False)
    except Exception as e:
        print("AssertionError in case 3 ",e)
test_NegatedPattern_match_seq()


# Generated at 2022-06-23 16:09:03.403879
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from . import parsetokens as PT

    np = NegatedPattern(WildcardPattern())

    assert list(np.match(PT.Leaf())) == []
    assert list(np.match(PT.Node(1))) == []

    np1 = NP.NegatedPattern(NP.WildcardPattern())

    assert np1.match(PT.Leaf()) is False
    assert np1.match_seq([]) is True
    assert np1.match_seq([PT.Node(1)]) is False

    np2 = NP.NegatedPattern(NP.NodePattern(type=1))
    assert np2.match(PT.Leaf()) is False
    assert np2.match(PT.Node(1)) is False
    assert np2.match_seq([]) is True

# Generated at 2022-06-23 16:09:14.795006
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    pattern = NegatedPattern()
    assert pattern.generate_matches([]) == [(0, {})]
    assert pattern.generate_matches([Leaf(1, "x")]) == []
    pattern = NegatedPattern(WildcardPattern())
    assert pattern.generate_matches([]) == []
    assert pattern.generate_matches([Leaf(1, "x")]) == [(0, {})]
    pattern = NegatedPattern(WildcardPattern(min=1))
    assert pattern.generate_matches([]) == []
    assert pattern.generate_matches([Leaf(1, "x")]) == [(0, {})]
    pattern = NegatedPattern(WildcardPattern(min=2))
    assert pattern.generate_matches([]) == []

# Generated at 2022-06-23 16:09:16.047305
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    assert Leaf(1,'1').__str__() == '1'


# Generated at 2022-06-23 16:09:22.209413
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    print(WildcardPattern(min=1, max=1, name="bare_name", content=((NodePattern(type=1),),)).optimize())
    print(WildcardPattern(min=2, max=2, name="bare_name", content=((NodePattern(type=1),),)).optimize())
    print(WildcardPattern(min=1, max=3, name="bare_name", content=((NodePattern(type=1),),)).optimize())
    print(WildcardPattern(min=1, max=1, name="bare_name", content=((NodePattern(type=1),),)).optimize())
    print(WildcardPattern(min=1, max=1, name="bare_name", content=((NodePattern(type=1),),)).optimize())

# Generated at 2022-06-23 16:09:24.134278
# Unit test for method __str__ of class Node
def test_Node___str__():
    r = Node(1, [])
    assert str(r) == "", "Unexpected output"


# Generated at 2022-06-23 16:09:32.921480
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():

    def _test_generate_matches(content, nodes):
        """Test the generate_matches method with one argument."""
        pattern = NegatedPattern(content)
        it = pattern.generate_matches(nodes)
        try:
            output = []
            while True:
                res = next(it)
                output.append(res)
        except StopIteration:
            return output

    # Test with content being None
    nodes = [1, 2, 3]
    content = None
    assert _test_generate_matches(content, nodes) == list(
        set([0, 1, 2, 3]) & set(range(len(nodes) + 1))
    )
    # Test with content being a pattern
    nodes = [1, 2, 3]
    content = NodePattern()
    assert _test

# Generated at 2022-06-23 16:09:34.301402
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    p = BasePattern()
    assert not isinstance(p, BasePattern)



# Generated at 2022-06-23 16:09:46.384657
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    # Unit test
    import unittest

    # test_Node_invalidate_sibling_maps
    class TestNode_invalidate_sibling_maps(unittest.TestCase):
        def runTest(self):
            self.assertRaises(AttributeError, getattr, n0, "prev_sibling_map")            # Line 25
            self.assertRaises(AttributeError, getattr, n0, "next_sibling_map")            # Line 26
            n1.invalidate_sibling_maps()                                                  # Line 27
            self.assertEqual(n1.prev_sibling_map, None)                                   # Line 28
            self.assertEqual(n1.next_sibling_map, None)                                   # Line 29
    

# Generated at 2022-06-23 16:09:49.680081
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # from tests.test_parse.test_basic import (tree_compare, space_before,
    #                                          space_after, substring)
    obj = Leaf(1, "abcd")
    assert obj.pre_order() == [obj]

# Generated at 2022-06-23 16:09:52.391906
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node(256, [Leaf(1, "foo"), Leaf(1, "bar")], None, "")
    assert str(node) == "foobar", str(node)


# Generated at 2022-06-23 16:10:00.135182
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from .grammar import AbstractBasicGrammar

    grammar = AbstractBasicGrammar

    # Test for method match of class NegatedPattern
    # test for empty pattern, testing method match_seq
    p = NegatedPattern()
    assert p.match(grammar.parse("()"))
    assert p.match(grammar.parse(",,"))
    assert p.match(grammar.parse("x"))
    # test for non-empty pattern, testing method match_seq
    p = NegatedPattern(NodePattern(type=grammar.Name, content=[LeafPattern(value="x")]))
    assert p.match(grammar.parse("()"))
    assert p.match(grammar.parse(",,"))
    assert not p.match(grammar.parse("x"))

# Generated at 2022-06-23 16:10:04.686781
# Unit test for method depth of class Base
def test_Base_depth():
    assert 1 == Node(1,[]).depth()
    assert 5 == Node(1,[Node(1,[Node(1,[Node(1,[Node(1,[])])])])]).depth()



# Generated at 2022-06-23 16:10:10.277988
# Unit test for constructor of class Base
def test_Base():
    # test __new__
    assert Base() is not Base()
    try:
        Base()
    except Exception:
        pass
    else:
        raise AssertionError("Base() should raise exception")
    try:
        Base().__init__()
    except Exception:
        pass
    else:
        raise AssertionError("Base().__init__() should raise exception")



# Generated at 2022-06-23 16:10:17.937826
# Unit test for method remove of class Base
def test_Base_remove():
    # Node
    def check(node):
        if node.parent is not None:
            assert node in node.parent.children
        for child in node.children:
            assert child.parent is node
            check(child)

    root = Node(2, [Leaf(1, 'def'), Node(3, [Leaf(1, 'foo'), Node(4, [Leaf(1, 'a=1')]), Node(4, [Leaf(1, 'b=2')]), Node(4, [Leaf(1, 'c=3')])]), Leaf(1, 'x=4')])
    check(root)
    pos = root.children[1].children[2].remove()
    assert pos == 2
    assert root.children[1].children[2].type == 4

# Generated at 2022-06-23 16:10:23.457595
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    # Case when self is not BasePattern
    c = C0()
    assert c is not None
    assert c.__class__.__name__ == "C0"
    # Case when self is BasePattern
    with pytest.raises(AssertionError):
        assert BasePattern() is not None
    return None


# Generated at 2022-06-23 16:10:34.090196
# Unit test for method clone of class Node
def test_Node_clone():
    """Unit test for Node.clone."""
    import blib2to3.pgen2.token
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.convert
    import blib2to3.fixer_base
    import blib2to3.pygram
    import blib2to3.pgen2.tokenize
    import blib2to3.pgen2.pgen

    # Test that cloning a node preserves the parent attribute.
    from . import pytree

    def build_tree(grammar):
        l = Leaf(0, "foo")
        n = Node(1, [l])
        n.children = [n, l]
        return n


# Generated at 2022-06-23 16:10:43.610601
# Unit test for method post_order of class Node
def test_Node_post_order():
    assert Node(
        1, [Node(2, [Leaf('"a"', 1), Leaf('"b"', 1), Leaf('"c"', 1)]), Leaf('"d"', 1)]
    ).post_order() == [Leaf('"a"', 1), Leaf('"b"', 1), Leaf('"c"', 1), Node(2, [Leaf('"a"', 1), Leaf('"b"', 1), Leaf('"c"', 1)]), Leaf('"d"', 1), Node(1, [Node(2, [Leaf('"a"', 1), Leaf('"b"', 1), Leaf('"c"', 1)]), Leaf('"d"', 1)])]


# Generated at 2022-06-23 16:10:49.344906
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # bug
    p = parse("-abc")
    print("the bug: ", p.match("aaabbc"))
    p = parse("x-abc")
    print("the bug: ", p.match("xaaabbc"))
    p = parse("x-abc y")
    print("the bug: ", p.match("xaaabbc yy"))
    p = parse("x -abc y")
    print("the bug: ", p.match("x yy"))
    p = parse("x -abc y")
    print("the bug: ", p.match("x aaabbc yy"))
    p = parse("x -abc y")
    print("the bug: ", p.match("x aaa yy"))
    p = parse("x -(abc) y")

# Generated at 2022-06-23 16:10:59.292559
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf, Node, symbol_map
    from .python_tree import Name
    from .fixer_util import Name

    def test_Node_clone():
        from .pytree import Leaf, Node, symbol_map
        from .python_tree import Name
        from .fixer_util import Name

        n1 = Node(symbol_map["testlist_star_expr"], [Name("a"), Name("b")])
        n2 = n1.clone()
        assert n1.type == n2.type
        assert n1.children == n2.children
        assert n1.children[0] is not n2.children[0]
        assert n1.children[1].prefix == n2.children[1].prefix
        assert n1 is not n2
        leaf1 = n1.children[0]
       

# Generated at 2022-06-23 16:11:01.310272
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "value")
    
    assert list(leaf.pre_order()) == list([leaf]) 

# Generated at 2022-06-23 16:11:09.271885
# Unit test for method post_order of class Node
def test_Node_post_order():
    node = Node(1,
                [Leaf(1, 'foo'),
                 Node(2,
                      [Leaf(1, 'foo'),
                       Leaf(2, 'bar')])])
    expected = [Leaf(1, 'foo'), Leaf(1, 'foo'), Leaf(2, 'bar'),
                Node(2,
                     [Leaf(1, 'foo'),
                      Leaf(2, 'bar')]),
                Node(1,
                     [Leaf(1, 'foo'),
                      Node(2,
                           [Leaf(1, 'foo'),
                            Leaf(2, 'bar')])])]
    result = list(node.post_order())
    assert result == expected
    return


# Generated at 2022-06-23 16:11:14.516968
# Unit test for method changed of class Base
def test_Base_changed():
    from .pgen2 import token
    from .pgen2.parse import ParseError
    from .pygram import python_symbols as syms
    from .pytree import Leaf, Node


# Generated at 2022-06-23 16:11:26.575714
# Unit test for method post_order of class Node
def test_Node_post_order():
    global _type_reprs, _P
    # Test if the post_order method will return a correct list of node.
    def mock_type_repr(type_num):
        # Mock the type_repr of type_num
        return type_num
    _type_reprs = {}
    _type_reprs[1] = mock_type_repr(1)
    _type_reprs[2] = mock_type_repr(2)
    _type_reprs[3] = mock_type_repr(3)
    _type_reprs[4] = mock_type_repr(4)
    _type_reprs[5] = mock_type_repr(5)
    _type_reprs[6] = mock_type_repr(6)


# Generated at 2022-06-23 16:11:30.110140
# Unit test for constructor of class BasePattern
def test_BasePattern():
    # No instances of BasePattern should ever be created
    with pytest.raises(AssertionError):
        bp = BasePattern()



# Generated at 2022-06-23 16:11:33.530257
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    n = Node(0, [])
    n.invalidate_sibling_maps()
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None

# Generated at 2022-06-23 16:11:45.946797
# Unit test for method set_child of class Node
def test_Node_set_child():
    print('test_set_child')
    t = Node(0, [Leaf(1,1),Leaf(1,2),Leaf(1,3),Leaf(1,4),Leaf(1,5)], None, None)
    t.set_child(0,Leaf(1,1))
    t.set_child(1,Leaf(1,2))
    t.set_child(2,Leaf(1,3))
    t.set_child(3,Leaf(1,4))
    t.set_child(4,Leaf(1,5))
    assert id(t.children[0]) != id(Leaf(1,1)), "Child updated incorrectly"
    print("test_set_child passed!")
# test_Node_set_child()

#Unit test for method clone

# Generated at 2022-06-23 16:11:57.055809
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    print("In test_Base_get_lineno")

    # Test case 1: Node
    node = test_Base_gen_node1()
    line_no = node.get_lineno()
    assert line_no == 1

    # Test case 2: Node
    node = test_Base_gen_node2()
    line_no = node.get_lineno()
    assert line_no == 2

    # Test case 3: Node
    node = test_Base_gen_node3()
    line_no = node.get_lineno()
    assert line_no == 3

    # Test case 4: Node
    node = test_Base_gen_node4()
    line_no = node.get_lineno()
    assert line_no == 4

    # Test case 5: Node
    node = test_Base_gen_