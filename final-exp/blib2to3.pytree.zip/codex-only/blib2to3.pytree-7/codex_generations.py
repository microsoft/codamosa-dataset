

# Generated at 2022-06-23 16:02:00.400755
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def test_generate_matches(pattern, inp, out):
        result = tuple(pattern.generate_matches(inp))
        assert result == out, (result, out)

    test_generate_matches(WildcardPattern([NodePattern(name="a")], min=1, max=2),
                          [Leaf(1, "a")], ((1, {"a": [Leaf(1, "a")]}),))
    test_generate_matches(WildcardPattern([NodePattern(name="a")], min=0, max=2),
                          [Leaf(1, "a")], ((1, {"a": [Leaf(1, "a")]}), (0, {})))

# Generated at 2022-06-23 16:02:08.281028
# Unit test for function generate_matches

# Generated at 2022-06-23 16:02:17.100227
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    """
    Test the method pre_order of class Leaf
    """
    def test_method(prefix: Text, lineno: int, column: int) -> None:
        node = Leaf(0, "", prefix=prefix, lineno=lineno, column=column)
        assert list(node.pre_order()) == [node]

    test_method(prefix=" ", lineno=0, column=0)
    test_method(prefix="\n", lineno=0, column=0)
    test_method(prefix="", lineno=0, column=0)
    test_method(prefix=" ", lineno=0, column=1)
    test_method(prefix="\n", lineno=1, column=0)
    test_method(prefix="", lineno=2, column=0)


# Generated at 2022-06-23 16:02:19.887819
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    import copy
    assert copy.deepcopy(Leaf(1,1)) == Leaf(1,1)
type(Node(1,[Leaf(2,2)]))


# Generated at 2022-06-23 16:02:23.114878
# Unit test for constructor of class Node
def test_Node():
    n = Node(3, [])
    assert n.type == 3
    assert n.parent is None
    assert not n.children
    assert not n.was_changed
    assert not n.was_checked



# Generated at 2022-06-23 16:02:29.810483
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    class Dummy:
        pass

    def _test(type, content, name, expected_type, expected_content, expected_name):
        p = LeafPattern(type, content, name)
        assert p.type == expected_type, (type, p.type)
        assert p.content == expected_content, (content, p.content)
        assert p.name == expected_name, (name, p.name)

    _test(None, None, None, None, None, None)
    _test(1, None, None, 1, None, None)
    _test(1, "2", None, 1, "2", None)
    _test(1, "2", "3", 1, "2", "3")

    _test(1, 2, None, 1, "2", None)

# Generated at 2022-06-23 16:02:37.440356
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():

    def _check_matches(pattern, nodes, result):
        matches = list(pattern.generate_matches(nodes))
        assert matches == result, (pattern, nodes, matches)

    pattern = Pattern(
        content=[[LeafPattern(name="A"), LeafPattern(value=",")], [LeafPattern(name="B")]]
    )
    _check_matches(pattern, [Leaf(1, "A"), Leaf(1, ","), Leaf(1, "B")], [(3, {"A": [Leaf(1, "A")], "B": [Leaf(1, "B")]}), (1, {"A": [Leaf(1, "A")]}), (2, {"B": [Leaf(1, "B")]})])


# Generated at 2022-06-23 16:02:41.973127
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .node import Node, Leaf
    leaf01 = Leaf(1, "aa")
    leaf02 = Leaf(2, "bb")
    node01 = Node(3, [leaf01, leaf02])
    expected = [leaf01, leaf02, node01]
    assert list(node01.post_order()) == expected

# Generated at 2022-06-23 16:02:52.796042
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import re
    nodes = [Leaf(0, 'test')]
    patterns = [LeafPattern(0)]
    pattern = patterns[0]
    assert list(pattern.generate_matches(nodes)) == [(1, {None: Leaf(0, 'test')})]
    assert list(pattern.generate_matches([])) == []
    nodes = [Leaf(0, 'test')]
    patterns = [LeafPattern(1)]
    pattern = patterns[0]
    assert list(pattern.generate_matches(nodes)) == []
    nodes = [Leaf(0, 'test')]
    patterns = [LeafPattern(1, 'test')]
    pattern = patterns[0]
    assert list(pattern.generate_matches(nodes)) == []

# Generated at 2022-06-23 16:02:59.427336
# Unit test for method clone of class Base
def test_Base_clone():
    from . import pytree
    from .pygram import python_symbols
    from .pgen2 import token

    p = pytree.Node(type=python_symbols.single_input)
    p.append_child(
        pytree.Leaf(type=token.NAME, value="x", context=(1, 2))
    )
    p.append_child(
        pytree.Leaf(type=token.COMMA, value=",", context=(1, 3))
    )
    q = p.clone()
    assert p == q
    assert p.children[0].value == "x"
    q.children[0].value = "y"
    assert p.children[0].value == "x"



# Generated at 2022-06-23 16:03:09.281151
# Unit test for method match of class BasePattern

# Generated at 2022-06-23 16:03:20.567899
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    NORMAL_SYMBOL = 256
    SPECIAL_SYMBOL = 257
    assert WildcardPattern().optimize() == NodePattern()
    assert WildcardPattern(None, min=0, max=2).optimize() == WildcardPattern(
        None, min=0, max=2
    )
    assert WildcardPattern(None, min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(
        [[NodePattern(NORMAL_SYMBOL), WildcardPattern(None, min=0, max=2)]], min=1, max=1
    ).optimize() == WildcardPattern(
        None, min=0, max=2
    )

# Generated at 2022-06-23 16:03:23.609605
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    LeafPattern()
    LeafPattern(type=1)

# Test for constructor of class LeafPattern
# with invalid arguments

# Generated at 2022-06-23 16:03:27.662524
# Unit test for function convert
def test_convert():
    from .pgen2 import parse
    from .pgen2.parse import convert as real_convert
    parser = parse.ParserGenerator(["abc"])
    assert convert is not real_convert
    assert convert(parser.p_grammar, (1, None, None, [])) == Leaf(1, "")
    assert convert(parser.p_grammar, (2, None, None, [Leaf(3, "")])) == Leaf(3, "")
    assert convert(parser.p_grammar, (2, None, None, [Node(3, [Leaf(4, "")])])) == Node(3, [Leaf(4, "")])

# Generated at 2022-06-23 16:03:36.713237
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import astroid
    from astroid import marshal_astroid


# Generated at 2022-06-23 16:03:41.888236
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    gr = driver.load_grammar("Grammar/Grammar")
    raw_node = 2, 'a', (), []
    node1 = convert(gr, raw_node)
    raw_node = 2, 'b', (), []
    node2 = convert(gr, raw_node)
    raw_node = 3, '', (), [node1]
    node3 = convert(gr, raw_node)
    assert isinstance(node3, Node)
    assert node3.children == [node1]
    raw_node = 4, '', (), [node3, node2]
    node4 = convert(gr, raw_node)
    assert isinstance(node4, Node)
    assert node4.children == [node3, node2]
    assert node3.parent == node4
   

# Generated at 2022-06-23 16:03:44.571586
# Unit test for constructor of class BasePattern
def test_BasePattern():
    p = BasePattern()
    assert isinstance(p, BasePattern)
    assert repr(p) == "BasePattern(None, None, None)"



# Generated at 2022-06-23 16:03:48.734482
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    node = Node(syms.file_input, [], prefix = '')
    node.append_child(Leaf(syms.NEWLINE, '\n', prefix = ' '))
    node.append_child(Leaf(syms.NEWLINE, '\n', prefix = ' '))
    assert node.children[1].prefix == ' '
    assert node.children[2].prefix == ' '

# Generated at 2022-06-23 16:03:53.644378
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Base = pytree.Base
    import unittest
    import pickle
    try:
        # Python 2
        unichr
    except NameError:

        # Python 3
        unichr = chr

    class TestBase(unittest.TestCase):

        def test_non_instantiable(self):
            with self.assertRaises(AssertionError) as cm:
                node = Base()
            assert str(cm.exception) == "Cannot instantiate Base"

        def test_eq_rules(self):
            a = Base()
            b = Base()

            # Equivalence
            self.assertNotEqual(a, None)
            self.assertNotEqual(a, 42)
            self.assertNotEqual(a, [])

# Generated at 2022-06-23 16:04:04.578960
# Unit test for constructor of class Node
def test_Node():
    class TestNode(Node):
        def __init__(self, *args, **kwds) -> None:
            self.parent = None
            super().__init__(*args, **kwds)
            if self.parent:
                raise RuntimeError("didn't clear parent")

    x = TestNode('foo', [1, 2, 3])
    y = TestNode('foo', [1, 2, 3])
    assert x == y
    assert repr(x) == repr(y)
    assert x != TestNode('foo', [1])
    assert x != TestNode('foo', [1, 2])
    assert x != TestNode('foo', [1, 2, 3, 4])
    assert x != TestNode('foo', [1, 2, 3, 3])
    assert x != TestNode('foo', [1, 2, 4])


# Generated at 2022-06-23 16:04:12.162988
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Node, Leaf

    test_tree = Node(1, [
        Node(2, [
            Leaf(1, "a"),
        ]),
        Node(3, [
            Leaf(1, "b"),
        ]),
        Node(4, [
            Leaf(1, "c"),
        ]),
    ])

    assert test_tree.children[0].get_suffix() == "b"
    assert test_tree.children[1].get_suffix() == "c"
    assert test_tree.children[2].get_suffix() == ""

    test_tree.children[0].replace(
        [
            Leaf(1, "x"),
            Leaf(1, "y"),
        ]
    )


# Generated at 2022-06-23 16:04:22.495498
# Unit test for constructor of class Leaf
def test_Leaf():
    a = Leaf(1, "", context=("#", (4, 5)))
    assert a.type == 1 and a.value == "" and a.prefix == "#" and a.lineno == 4 and a.column == 5

    b = Leaf(1, "", context=("", (4, 5)))
    assert b.type == 1 and b.value == "" and b.prefix == "" and b.lineno == 4 and b.column == 5

    c = Leaf(1, "", context=("#", (4, 5)))
    d = Leaf(1, "", context=("#", (4, 5)))
    assert c == d

# Generated at 2022-06-23 16:04:30.362463
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    import ast
    import textwrap
    from ast_tools.patterns.dsl import TreePattern, transformers

    def test(pattern, nodes, expected_results):
        p = ast.parse(pattern).body[0].value
        n = ast.parse(nodes).body[0]
        r = {}
        assert p.match(n, r) == expected_results, repr((p, n, r))

    test("a ? b", "b ? a", False)
    test("a ? b", "c ? a", True)
    test("a & b", "a ? b", False)
    test("a & b", "a ? c", False)
    test("a & b", "c ? d", True)
    test("!(a | b)", "c ? d", False)

# Generated at 2022-06-23 16:04:33.132017
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    assert Base(type=0).__eq__(Base(type=0))
    assert not Base(type=0).__eq__(Base(type=1))



# Generated at 2022-06-23 16:04:35.772610
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    a = Leaf(0, "")
    assert list(a.leaves()) == [a]
    assert list(a.leaves()) == [a]
test_Leaf_leaves()

# Generated at 2022-06-23 16:04:42.349719
# Unit test for method depth of class Base
def test_Base_depth():
    # Create a test tree with depth at least 2.
    # depth(tree.children[0]) is 0
    # depth(tree.children[1]) is 1
    # depth(tree.children[2]) is 2
    # depth(tree.children[3]) is 2
    tree = Node(sym.test, [
        Leaf(1, "test"),
        Node(sym.test, [
            Leaf(1, "test")
        ]),
        Node(sym.test, [
            Node(sym.test, [
                Leaf(1, "test")
            ])
        ]),
        Node(sym.test, [
            Node(sym.test, [
                Node(sym.test, [
                    Leaf(1, "test")
                ])
            ])
        ])
    ])
    assert tree.depth() == 0
   

# Generated at 2022-06-23 16:04:49.227419
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pygram import python_symbols
    from .pgen2 import token

    leaf1 = Leaf(token.NAME, "hello", lineno=1)
    leaf2 = Leaf(token.NAME, "goodbye", lineno=2)
    stmt = Node(python_symbols.stmt, [leaf1, leaf2])
    expr = Node(python_symbols.expr, [leaf2, leaf1])
    assert leaf1.get_lineno() == 1
    assert leaf2.get_lineno() == 2
    assert stmt.get_lineno() == 1
    assert expr.get_lineno() == 2


# Unit tests for class Base

# Generated at 2022-06-23 16:04:58.475116
# Unit test for function generate_matches
def test_generate_matches():
    pat = WildcardPattern([[WildcardPattern([[NodePattern(1)],
                                             [WildcardPattern([[NodePattern(2)],
                                                               [NodePattern(3)]])]])],
                          [NodePattern(0)],
                          [NodePattern(2)]])
    tree1 = NL('f', [NL(1, []), NL(2, [])])
    tree2 = NL('f', [NL(1, []), NL(2, [NL(3, [])])])
    tree3 = NL('f', [NL(2, [])])
    tree4 = NL('f', [NL(0, []), NL(2, [])])
    tree5 = NL('f', [NL(0, []), NL(2, [NL(3, [])])])
    tree6 = NL

# Generated at 2022-06-23 16:05:00.756797
# Unit test for method depth of class Base
def test_Base_depth():
    g = Grammar()
    p = g.parse("a=b")
    d = p.depth()

    assert d == 3



# Generated at 2022-06-23 16:05:09.379438
# Unit test for method __str__ of class Node
def test_Node___str__():
    # This can be used to test this class.
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2 import tokenize
    from .pygram import python_grammar
    for i, case in enumerate([",,,"]):
        try:
            toks = tokenize.generate_tokens(StringIO(case).readline)
            try:
                tree = list(python_grammar.parser.parse_tokens(toks))
            except ParseError as err:
                tree = err.args[0]
            assert str(tree[0]) == case
        except Exception:
            print(case)
            raise

# Generated at 2022-06-23 16:05:16.896963
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from .syms import test_syms
    n = Node(test_syms.arbitrary_node_type,
             [Leaf(test_syms.arbitrary_leaf_type, "foo")])
    assert n.depth() == 0
    n2 = Node(test_syms.arbitrary_node_type, [n])
    assert n.depth() == 1
    assert n2.depth() == 0



# Generated at 2022-06-23 16:05:21.383351
# Unit test for method clone of class Base
def test_Base_clone():
    from pgen2.parser import Parser

    grammar = Parser.parse_grammar(StringIO("""\
        foo: bar baz
        bar: 'a'
        baz: 'b'
        """))
    tree = grammar.pgen.run("ab")
    tree.clone()



# Generated at 2022-06-23 16:05:28.228443
# Unit test for function convert
def test_convert():

    from .pgen2.driver import Driver
    from .pgen2.grammar import Grammar

    gr = Grammar()
    d = Driver(gr, convert)
    result = d.parse("a + b", start=gr.symbol2number["expr_stmt"])
    assert result.children == gr.type2tokens["expr_stmt"]
    assert len(result.children) == 1
    assert result.children[0].children == gr.type2tokens["testlist_star_expr"]
    assert len(result.children[0].children) == 3
    assert result.children[0].children[0].children == gr.type2tokens["term"]
    with pytest.raises(ValueError):
        assert result.children[0].children[0].children[0].children

    tuple_term

# Generated at 2022-06-23 16:05:32.724541
# Unit test for constructor of class Node
def test_Node():
    n = Node(1, [], None)
    assert n.children == []
    assert n.fixers_applied == None
    assert n.used_names == None



# Generated at 2022-06-23 16:05:42.228014
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w1 = WildcardPattern(min=0, max=HUGE)
    assert w1.content is None
    assert w1.min == 0
    assert w1.max == HUGE

    w2 = WildcardPattern(min=1, max=HUGE)
    assert w2.min == 1
    assert w2.max == HUGE
    assert w2.content is None

    w3 = WildcardPattern(min=0, max=1)
    assert w3.min == 0
    assert w3.max == 1
    assert w3.content is None

    w4 = WildcardPattern(min=1, max=1)
    assert w4.min == 1
    assert w4.max == 1
    assert w4.content is None


# Generated at 2022-06-23 16:05:52.429491
# Unit test for method __str__ of class Node
def test_Node___str__():
    L = Leaf(token.NAME, "spam", prefix=" ")
    assert str(L) == "spam"
    N = Node(syms.expr_stmt, [L])
    assert str(N) == "spam"
    L = Leaf(token.NAME, "spam")
    N = Node(syms.simple_stmt, [L])
    assert str(N) == "\nspam"
    L = Leaf(token.INDENT, "")
    N = Node(syms.simple_stmt, [L, L])
    assert str(N) == "\n    \n"
    N = Node(syms.expr_stmt, [Leaf(token.NAME, "spam")])
    print(N)
    assert str(N) == "spam"

# Generated at 2022-06-23 16:06:04.220029
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Node, Leaf
    from . import pytoken
    from .pgen2 import token
    from . import python_grammar

    grammar = python_grammar.load_grammar()

    node = Node(token.NAME, [Leaf(1, "foo")])
    assert node.was_changed is False
    assert node.parent is None
    node.was_changed = True
    assert node.was_changed is True

    node2 = Node(token.NAME, [Leaf(1, "bar")])
    node.append_child(node2)
    assert node2.parent is node
    assert node.was_changed is False
    node2.changed()
    assert node.was_changed is True
    node.was_changed = False
    assert node.was_changed is False

    node.changed()


# Generated at 2022-06-23 16:06:06.965029
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    n = Leaf(1, 2, 3)
    assert list(n.leaves()) == [n]

# Generated at 2022-06-23 16:06:15.718243
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    # This is not a proper unit test, but rather a demo of Node.insert_child
    from blib2to3.pytree import Leaf

    source = "print(42)\n"
    tree = compile(source, "<test>", "exec", _ast.PyCF_ONLY_AST)
    print(tree)
    print("---------------------------")
    tree.children[-1].insert_child(
        0, Leaf(token.NL, "\n".join(["inserted line %d" % i for i in range(2)]) + "\n")
    )
    print(tree)
    del tree



# Generated at 2022-06-23 16:06:27.105806
# Unit test for method clone of class Base
def test_Base_clone():
    from .pytree import Node, Leaf, build_tree

    test_tree_1 = build_tree(
        "one two three four five six seven eight nine ten",
        "one two three four five six seven eight nine ten"
    )
    test_tree_2 = test_tree_1.clone()
    # Make sure test_tree_2 is distinct from test_tree_1
    test_tree_2.children[0].children[0].children[0].value += "Y"
    assert test_tree_1.children[0].children[0].children[0].value == "oneY"
    assert test_tree_2.children[0].children[0].children[0].value == "one"
    # Make sure test_tree_1 is unchanged

# Generated at 2022-06-23 16:06:36.988203
# Unit test for function generate_matches
def test_generate_matches():
    # Test that a '.' and a pattern that always matches consume one node
    p = WildcardPattern()
    assert list(generate_matches([p], [NL(0, "a_node"), NL(0, "another_node")])) == [
        (1, {})
    ]
    p = NodePattern(type=-1)
    assert list(generate_matches([p], [NL(0, "a_node"), NL(0, "another_node")])) == [
        (1, {})
    ]
    # Test that a negated pattern of None doesn't match a non-empty node
    p = NegatedPattern()
    assert list(generate_matches([p], [NL(0, "a_node"), NL(0, "another_node")])) == []
    # Test that a negated pattern

# Generated at 2022-06-23 16:06:38.334353
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    import doctest
    doctest.testmod(WildcardPattern)



# Generated at 2022-06-23 16:06:47.095307
# Unit test for method __str__ of class Node
def test_Node___str__():
    node = Node(1, [])
    assert str(node) == ""
    node = Node(1, [Leaf(1, "hello")])
    assert str(node) == "hello"
    node = Node(1, [Leaf(1, "hello"), Leaf(1, "there")])
    assert str(node) == "hellothere"
    node = Node(1, [Node(1, [Leaf(1, "hello")]), Leaf(1, "there")])
    assert str(node) == "hellothere"
    node = Node(1, [Node(1, [Leaf(1, "hello"), Node(1, [Leaf(1, "there")])])])
    assert str(node) == "hellothere"


# Generated at 2022-06-23 16:06:54.702995
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert repr(BasePattern(3, 4, 5)) == "BasePattern(3, 4, 5)"
    from .pgen2 import token

    assert repr(BasePattern(token.NAME, "foo")) == "BasePattern(NAME, 'foo')"
    try:
        BasePattern()
    except AssertionError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 16:06:57.579494
# Unit test for method post_order of class Node
def test_Node_post_order():
    e1 = Leaf(0, "")
    sorted_node = sorted(e1.post_order())
    assert sorted_node == [e1]

# Generated at 2022-06-23 16:07:00.308906
# Unit test for method remove of class Base
def test_Base_remove():
    from .pgen2 import driver

    source = """if True:
    pass
"""
    tr = driver.parse_string(source)
    tr.remove()
    assert tr.next_sibling is None



# Generated at 2022-06-23 16:07:07.644669
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    LeafPattern()
    LeafPattern(type=token.NAME)
    LeafPattern(content="foo")
    LeafPattern(content=1)
    LeafPattern(type=token.NAME, content="foo")
    LeafPattern(type=token.NAME, name="bar")
    LeafPattern(content="foo", name="bar")
    LeafPattern(type=token.NAME, content="foo", name="bar")


_ContentMapping = Dict[Text, Any]



# Generated at 2022-06-23 16:07:14.410116
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    import ast
    import typing
    import unittest

    # This class tests the method Leaf.__str__()
    class Test__str__(unittest.TestCase):

        def test__str__1(self):
            f = ast.dump
            node = ast.parse("a = 1\n")
            self.assertEqual(f(node), "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])")

    unittest.main(module="test_Leaf___str__", exit=False)


# Generated at 2022-06-23 16:07:25.438066
# Unit test for function convert
def test_convert():
    """Test convert."""
    class MockGrammar(object):
        """Return the symbol number."""
        def __init__(self):
            self.number2symbol = {}

    grammar = MockGrammar()
    node = convert(grammar, (0, '', None, []))
    assert node.type == 0
    assert node.value == ''
    assert node.children == []

    node = convert(grammar, (1, None, None, [Node(2, [])]))
    assert node.type == 2
    assert node.value is None
    assert node.children == []

    node = convert(grammar, (1, None, None, [Leaf(2, '')]))
    assert node.type == 2
    assert node.value == ''
    assert node.children == []


# Generated at 2022-06-23 16:07:36.666092
# Unit test for constructor of class NodePattern
def test_NodePattern():
    import tokenize
    import sys

    print("testing NodePattern...")

    p = NodePattern(type=tokenize.NAME, content=[LeafPattern(type=tokenize.NAME)])
    node = Node(
        type=tokenize.NAME,
        children=[Leaf(type=tokenize.NAME, value="abc", prefix="x")],
    )
    assert p.match(node)
    node = Node(
        type=tokenize.NAME,
        children=[Leaf(type=tokenize.NAME, value="abc", prefix="x")],
    )
    assert p.match(node)

    p = NodePattern(type=tokenize.NAME, content=[LeafPattern(type=tokenize.NAME)])

# Generated at 2022-06-23 16:07:38.769763
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    t = Leaf(1, "hi")
    assert [t] == list(t.pre_order())

test_Leaf_pre_order()

# Generated at 2022-06-23 16:07:50.931191
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    li = Leaf(3, "l1")
    lj = Leaf(3, "l2")
    lk = Leaf(3, "l3")
    la = Leaf(3, "l4")
    lb = Leaf(3, "l5")
    c = [li, lj, lk, la, lb]
    for x in c:
        x.parent = None
    assert list(li.pre_order()) == [li]
    assert list(lj.pre_order()) == [lj]
    assert list(lk.pre_order()) == [lk]
    assert list(la.pre_order()) == [la]
    assert list(lb.pre_order()) == [lb]
    n = Node(3, c)
    for x in c:
        assert x.parent == n

# Generated at 2022-06-23 16:07:59.804240
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    bp = BasePattern()
    bp.type = 1
    bp.content = None
    bp.name = None
    node = Leaf(1, '')
    results = None
    assert bp.match(node, results)
    assert results == {}
    results = {}
    assert bp.match(node, results)
    assert results == {}
    bp.content = '1'
    assert not bp.match(node, results)
    assert results == {}
    bp.content = None
    bp.name = 'name'
    assert bp.match(node, results)
    assert results == {'name': node}
    bp.type = 2
    assert not bp.match(node, results)
    assert results == {'name': node}
    bp.type = 1
   

# Generated at 2022-06-23 16:08:08.841135
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pgen2.parse import parse
    import unittest
    import sys
    _source = "1+2"
    tree = parse(_source, mode="exec")
    if sys.version_info < (3, 6):
        tree = tree[0]
    else:
        tree = tree[0].children[1]
    assert next(tree.leaves()).value == "1"
    assert next(tree.leaves()).value == "+"
    assert next(tree.leaves()).value == "2"
    with unittest.expectedFailure():
        next(tree.leaves())
    return

# Generated at 2022-06-23 16:08:12.402317
# Unit test for method clone of class Node
def test_Node_clone():
    o = Node(0, [])
    # FIXME: The following only tests is the clone
    # method doesn't fail outright and returns something
    # The actual test should verify that the object is actually
    # a clone
    o.clone()

# Generated at 2022-06-23 16:08:14.913546
# Unit test for constructor of class Base
def test_Base():
    assert Base().__class__ is Base



# Generated at 2022-06-23 16:08:18.742385
# Unit test for method set_child of class Node
def test_Node_set_child():
    a = Node(1, [])
    a.set_child(0, Leaf(2, '3'))
    assert a.changed() == a
    assert a.invalidate_sibling_maps() == a

# Generated at 2022-06-23 16:08:28.850931
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Node, Leaf
    from . import pygram
    from .parser import Parser

    grammar = Grammar(pygram.python_grammar_no_print_statement)
    p = Parser(grammar, start="file_input")
    n = p.parse("x = 3")
    n.changed()

    # Test that pre-order is correctly iterated.
    niter = n.pre_order()
    assert niter.__next__() is n
    assert niter.__next__() is n.children[0]
    assert niter.__next__() is n.children[1]
    assert niter.__next__() is n.children[2]
    with pytest.raises(StopIteration):
        niter.__next__()

    # Test that it's possible to clone a

# Generated at 2022-06-23 16:08:37.604273
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    from . import parser

    # test empty pattern
    p = NegatedPattern()
    t = parser.expr("()")
    assert p.match(t), t
    t = parser.expr("(a)")
    assert not p.match(t), t

    # test not empty pattern
    p = NegatedPattern(NodePattern())
    t = parser.expr("()")
    assert not p.match(t), t
    t = parser.expr("(a)")
    assert p.match(t), t



# Generated at 2022-06-23 16:08:49.812580
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    n = Node(1, [Leaf(1, "x"), Leaf(1, "y")])
    assert list(n.pre_order()) == [n, n.children[0], n.children[1]]
    assert list(n.post_order()) == [n.children[0], n.children[1], n]

    # Test for leaving off parens in list comp
    # Removed: does not parse under Py3.
    # n = parse3("x[x*y for x in y[1:] for y in range(6)]")
    # assert list(n.pre_order()) == n.post_order()
    # assert [type(n)]*3 == [type(x) for x in n.post_order()]



# Generated at 2022-06-23 16:08:56.606244
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # Test that the method match_seq raises an AssertionError when
    # the pattern is not a wildcard pattern.  (These patterns
    # don't make sense to match a sequence of nodes.)
    from .pgen2 import token

    assert not BasePattern.match_seq([])
    assert not BasePattern.match_seq([Leaf(0, "")])



# Generated at 2022-06-23 16:09:05.448923
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import Rule

    class TestWildcardPattern(WildcardPattern):
        def __init__(self, content, min, max, name):
            super().__init__(content, min, max, name)

    assert TestWildcardPattern(None, min=1, max=1).optimize() == \
        NodePattern()
    assert TestWildcardPattern(None, min=0, max=1).optimize() == \
        NodePattern()
    assert TestWildcardPattern(None, min=1, max=2).optimize() == \
        NodePattern()
    assert TestWildcardPattern(None, min=0, max=2).optimize() == \
        NodePattern()

# Generated at 2022-06-23 16:09:07.884502
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(OP, 'OP')
    assert l.pre_order() == [l]


# Generated at 2022-06-23 16:09:13.752281
# Unit test for method clone of class Base
def test_Base_clone():
    # Create a node
    node = Node(0, [])
    # Create a copy of the node
    node_copy1 = node.clone()
    assert node_copy1 is not node
    assert node_copy1 == node
    # Create a second copy of the node
    node_copy2 = node.clone()
    assert node_copy2 is not node_copy1
    assert node_copy2 == node


# Generated at 2022-06-23 16:09:20.933693
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    """
    Unit test for method match_seq of class BasePattern
    """
    # Pickling
    import pickle

    p1 = LeafPattern(10, "abc")
    assert p1.match_seq([Leaf(10, "abc")]) is True
    assert p1.match_seq([Leaf(10, "def")]) is False
    assert p1.match_seq([Leaf(20, "abc")]) is False
    assert p1.match_seq([Leaf(10, "abc"), Leaf(20, "def")]) is False
    p2 = LeafPattern(10)
    assert p2.match_seq([Leaf(10, "abc")]) is True
    assert p2.match_seq([Leaf(10, "def")]) is True

# Generated at 2022-06-23 16:09:30.856491
# Unit test for method clone of class Node
def test_Node_clone():
    global _testmgr
    _testmgr = htf.TestManager()
    global _testlist
    _testlist = htf.TestList()

    from blib2to3.pgen2.token import ENDMARKER, NAME, NUMBER, OP, STRING
    from blib2to3.pgen2.parse import ParseError

    def do(s, tp=None):
        if tp is None:
            tp = NAME
        try:
            n = p.parse(s)
        except ParseError:
            htf.assert_equal(tp, None)
            return
        htf.assert_equal(n.type, tp)
        m = n.clone()
        htf.assert_equal(n.type, m.type)

# Generated at 2022-06-23 16:09:39.852547
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    import difflib
    import unittest

    class TestCase(unittest.TestCase):
        def check_match(self, pattern, nodes, expected):
            actual = pattern.match_seq(nodes)
            self.assertEqual(
                actual,
                expected,
                "match_seq({!r}, {!r})\nExpected: {}\nActual:   {}".format(
                    pattern, nodes, expected, actual
                ),
            )

    class TestPattern(TestCase):
        def test_match(self):
            self.check_match(WildcardPattern(), [], False)
            self.check_match(WildcardPattern(), [Leaf(0, "")], False)

# Generated at 2022-06-23 16:09:43.146842
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert LeafPattern(None, None, None)
    assert LeafPattern(1, None, None)
    assert LeafPattern(None, "foo", None)
    assert LeafPattern(None, None, "foo")



# Generated at 2022-06-23 16:09:49.194067
# Unit test for constructor of class Base
def test_Base():
    class Node(Base):
        def _eq(self, other):
            return True

        def clone(self):
            return Node()

        def post_order(self):
            return iter([])

        def pre_order(self):
            return iter([])

    e = Node()

    assert e._eq(e)
    assert not e.__eq__(None)



# Generated at 2022-06-23 16:09:55.806921
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    np = LeafPattern(type=1, content="1")
    assert np.match(Leaf(1, "1")) == True
    assert np.match(Leaf(1, "2")) == False
    assert np.match(Node(1, [])) == False
    np = LeafPattern(type=1, name="test")
    assert np.match(Leaf(1, "1")) == True
    assert np.match(Leaf(1, "2")) == False
    assert np.match(Node(1, [])) == False



# Generated at 2022-06-23 16:10:02.257692
# Unit test for method replace of class Base
def test_Base_replace():
    exec('''n = ast.parse("x = 1 + 2")
assert n.children[0] == Name(id="x", ctx=Load())
assert n.body[0].value == BinOp(left=Name(id="x", ctx=Load()), op=Add(), right=Num(n=2))
n.body[0].replace(Num(n=3))
assert n.children[0] == Num(n=3)
assert n.body[0].value == Num(n=3)
''', globals(), locals())



# Generated at 2022-06-23 16:10:13.362444
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from . import parse
    # utility function to test a pattern
    def test(pattern, text, expected):
        pattern = parse(pattern)
        trees = list(pattern.generate_matches(parse(text)))
        eq_(trees, expected)
    # test cases
    test("~(a)", "a", [])
    test("~(a)", "b", [(0, {})])
    test("~(a c)", "b c", [(0, {})])
    test("~(a c)", "a b c", [(2, {})])
    test("~(a b c)", "a b c", [])
    test("~(a b c)", "a b d c", [(3, {})])


# Given a sequence of patterns, one of which may be a NegatedPattern,
# make a new pattern that

# Generated at 2022-06-23 16:10:24.905905
# Unit test for method post_order of class Base
def test_Base_post_order():
    import collections
    import random
    import unittest

    class TestCase(unittest.TestCase):

        def test(self, tree):
            expected = collections.Counter(tree.leaves())
            actual = collections.Counter(tree.post_order())
            self.assertEqual(expected, actual)
            return tree

    def _test_Base_post_order(self):
        # Test a tree of mixed Leaf and Node instances.
        tree = Node(0, [Node(1, [Leaf(2, ""), Leaf(3)]), Leaf(4, ""), Node(5)])
        tree = self.test(tree)

        # Test a tree with a single leaf.
        tree = tree.leaves()[0]
        tree = self.test(tree)

        # Test an empty tree.

# Generated at 2022-06-23 16:10:26.958361
# Unit test for constructor of class Node
def test_Node():
    t = Node(0, [Leaf(1, "")])
    assert t.type == 0
    assert t.children == [Leaf(1, "")]
    assert t.parent is None



# Generated at 2022-06-23 16:10:35.475680
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    pat = WildcardPattern([[NodePattern(STORE)], [Leaf(NAME, "x")]])
    pat.name = "x"
    names = [NodePattern(NAME, name) for name in ["f", "g", "h", "x", "y", "z"]]

# Generated at 2022-06-23 16:10:40.005840
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    neg_pattern = NegatedPattern(NodePattern(type='SYMBOL', content=['\n'], name='k'))
    test_nodes = ['\n']
    assert neg_pattern.match_seq(test_nodes)==False
# Unit tests for class BasePattern

# Generated at 2022-06-23 16:10:44.954565
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.grammar as grammar
    BasePattern.__init__(token.STRING)
    BasePattern.generate_matches(grammar.Grammar)


# Generated at 2022-06-23 16:10:53.019794
# Unit test for constructor of class Base
def test_Base():
    # noinspection PyUnusedLocal
    class A(Base):
        def __init__(self) -> None:
            pass

    # noinspection PyUnusedLocal
    class B(Base):
        def __init__(self) -> None:
            pass

    # noinspection PyUnusedLocal
    class C(Base):
        def __init__(self) -> None:
            pass

    # noinspection PyUnusedLocal
    class D(Base):
        def __init__(self) -> None:
            pass



# Generated at 2022-06-23 16:11:04.047851
# Unit test for function generate_matches
def test_generate_matches():
    pl = parse("a [b c]* d")
    assert list(generate_matches(pl[0].patterns, pl[1:])) == [
        (4, {}),
        (2, {}),
        (1, {}),
        (0, {}),
    ]
    pl = parse("a [b c]* [d e]*")
    assert list(generate_matches(pl[0].patterns, pl[1:])) == [
        (5, {}),
        (3, {}),
        (2, {}),
        (1, {}),
        (0, {}),
    ]
    pl = parse("a [b c]* [d e]* f")

# Generated at 2022-06-23 16:11:09.782435
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    bp = BasePattern()
    bp.match_seq = lambda n, r=None: n and n[0] == 1 and bp.match(n[0], r)
    assert list(bp.generate_matches([1])) == [(1, {})]



# Generated at 2022-06-23 16:11:18.474185
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    from .pygram import python_symbols
    from .pygram import python_grammar

    grammar = python_grammar
    grammar.initialize()
    tokens = python_symbols
    base_types = {
        tokens.simple_stmt: "simple_stmt",
        tokens.file_input: "file_input",
        tokens.compound_stmt: "compound_stmt",
        tokens.stmt: "stmt",
        tokens.suite: "suite",
    }
    production_rules = grammar.rules


# Generated at 2022-06-23 16:11:22.938581
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(python_symbols.old_test,[])
    assert node.__class__.__name__ + '(' + repr(python_symbols.old_test) + ', [])' == node.__repr__()

# Generated at 2022-06-23 16:11:24.853588
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    _t = Leaf(0, "")
    assert list(_t.leaves()) == [_t]

# Generated at 2022-06-23 16:11:33.297687
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import token
    from .pgen2.driver import Driver
    from . import tokenize
    from .tokenize import TokenInfo

    class BasePattern(BasePattern):
        def __init__(self, type=None, content=None, name=None):
            self.type = type
            self.content = content
            self.name = name
    b = BasePattern(token.NUMBER, "314")
    assert b.generate_matches([
        TokenInfo(token.NUMBER, "314", start=(0, 0), end=(0, 3), line='')
    ]).__next__() == (1, {})

    tokens = [TokenInfo(token.NAME, 'x'),
              TokenInfo(token.EQUAL, '='),
              TokenInfo(token.NAME, 'y')]

   

# Generated at 2022-06-23 16:11:36.951297
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    node = Node(0, [])
    assert repr(node) == "Node(0, [])"


# Generated at 2022-06-23 16:11:48.525035
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    class Context:
        def __init__(self, str_content, lineno=0, column=0):
            self.content = str_content
            self.lineno = lineno
            self.column = column
    class FileInput:
        def __init__(self, str_content):
            self.content = str_content
    class Compile:
        def __init__(self, str_content, str_filename, str_symbol):
            self.content = str_content
            self.filename = str_filename
            self.symbol = str_symbol
    class Suite:
        def __init__(self, context_input):
            self.input = context_input
    class Parser:
        def parse(self, content, filename):
            x = content
            return Suite(x)

# Generated at 2022-06-23 16:11:51.009143
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(0, 'lvalue')
    l.set_child(0, l)
    l.pre_order()


# Generated at 2022-06-23 16:11:58.137737
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    leaf1 = Leaf(1, "text1", (None, 1))
    assert leaf1.get_lineno() == 1
    node1 = Node(syms.funcdef, [leaf1])
    assert node1.get_lineno() == 1
    leaf2 = Leaf(1, "text2", (None, 2))
    leaf3 = Leaf(1, "text3", (None, 3))
    node2 = Node(syms.funcdef, [leaf2, node1, leaf3])
    assert node2.get_lineno() == 2

