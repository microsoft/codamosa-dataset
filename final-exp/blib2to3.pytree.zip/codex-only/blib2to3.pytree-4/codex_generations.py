

# Generated at 2022-06-23 16:01:56.813420
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    p = Node(0, [Leaf(1, ""), Leaf(2, ""), Leaf(3, "")])
    res = list(p.pre_order())
    assert res[0] == p
    assert res[1].type == 1
    assert res[2].type == 2
    assert res[3].type == 3


# Generated at 2022-06-23 16:01:59.073569
# Unit test for constructor of class NodePattern
def test_NodePattern():
    def test_content():
        NodePattern(content=[1, 2])  # No TypeError
        NodePattern(type=24, content=[1, 2])  # No TypeError

    test_content()



# Generated at 2022-06-23 16:02:06.376856
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():

    def check(p, count, results):
        for c, r in p.generate_matches(["a", "b", "c", "d", "e", "f", "g", "h"]):
            assert c == count, (c, count)
            assert r == results, (r, results)

    check(WildcardPattern(), 0, {})
    check(WildcardPattern(name="foo"), 0, {"foo": []})
    check(WildcardPattern([["c"]]), 3, {})
    check(WildcardPattern([["a"]]), 1, {})
    check(WildcardPattern([["a", "b"]]), 2, {})
    check(WildcardPattern([["a", "b"]], name="foo"), 2, {"foo": ["a", "b"]})

# Generated at 2022-06-23 16:02:08.237125
# Unit test for method __repr__ of class Node
def test_Node___repr__():

    assert repr(Node(1, [])) == "Node(1, [])"


# Generated at 2022-06-23 16:02:11.833775
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    """
    Test function for Node.__repr__

    See the examples/README file for more information.
    """
    target = Node(
        type = 0,
        children = [],
        context = None,
    )
    target.__repr__()


# Generated at 2022-06-23 16:02:13.019123
# Unit test for method __new__ of class Base
def test_Base___new__():
    f = Base(*(1, 2))

    assert f is not None

# Generated at 2022-06-23 16:02:23.598962
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Node
    from .pygram import python_grammar

    # test 1
    # Testing simple case, when the transformer does not change the tree
    node = Node(python_grammar.syms.file_input, [])
    assert node.was_changed == False
    assert node.was_checked == False
    node.changed()
    assert node.was_changed == True
    node.was_changed == False
    node.was_checked == False

    # test 2
    # Testing the effect of calling changed() when the parent is changed
    parent = Node(python_grammar.syms.file_input, [])
    node = Node(python_grammar.syms.funcdef, [], parent=parent)
    node.changed()
    assert node.was_changed == True
    assert parent.was_changed

# Generated at 2022-06-23 16:02:26.504737
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Class Base should not be instantiated
    obj = Base()
    obj.children = []
    with pytest.raises(NotImplementedError):
        obj.post_order()

# Generated at 2022-06-23 16:02:30.791222
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    node = Node(0, [])
    node.update_sibling_maps()
    assert node.prev_sibling_map, "n.prev_sibling_map should be a dict"
    assert node.next_sibling_map, "n.next_sibling_map should be a dict"
    assert len(node.prev_sibling_map) == 0, "n should have no prev_siblings"
    assert len(node.next_sibling_map) == 0, "n should have no next_siblings"

    node = Node(0, [Leaf(0, "foo"), Leaf(0, "bar")])
    node.update_sibling_maps()
    assert node.prev_sibling_map, "n.prev_sibling_map should be a dict"
    assert node.next_sibling_map

# Generated at 2022-06-23 16:02:42.633777
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    '''
    >>> import io
    >>> from pprint import pprint
    >>> from list_parser import get_parser
    >>> select = '''

# Generated at 2022-06-23 16:02:46.006926
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    t = Leaf(1, '9', prefix=' ')
    r = {}
    assert t.match(t, r)
    assert r == {'9': t}


# Generated at 2022-06-23 16:02:48.395124
# Unit test for constructor of class Base
def test_Base():
    nod = Base()
    assert nod.type == nod.parent is nod.children is nod.prefix is None



# Generated at 2022-06-23 16:02:57.209892
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    def check(children, i, child, expected_children):
        n = Node(0, children)
        n.insert_child(i, child)
        assert n.children == expected_children
    check([Leaf(0, "a")], 0, Leaf(0, "b"), [Leaf(0, "b"), Leaf(0, "a")])
    check([Leaf(0, "a")], 1, Leaf(0, "b"), [Leaf(0, "a"), Leaf(0, "b")])
    check([Leaf(0, "a"), Leaf(0, "b")], 0, Leaf(0, "c"), [Leaf(0, "c"), Leaf(0, "a"), Leaf(0, "b")])

# Generated at 2022-06-23 16:03:02.547254
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # Test some of the special cases.
    p1 = WildcardPattern((('a',), ('b',), ('c',)), min=0, max=HUGE, name=None)
    assert p1.match_seq([Leaf('a', 5), Leaf('b', 5), Leaf('c', 5)])
    assert p1.match_seq([])
    assert not p1.match_seq([Leaf('a', 5)])
    assert not p1.match_seq([Leaf('a', 5), Leaf('a', 4)])
    assert not p1.match_seq([Leaf('a', 5), Leaf('b', 5), Leaf('c', 5), Leaf('d', 5)])

    p2 = WildcardPattern((('a',), ('b',), ('c',)), min=1, max=HUGE, name=None)

# Generated at 2022-06-23 16:03:07.688798
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    p = NegatedPattern()
    assert p.match_seq([])
    assert p.match_seq(None) is False
    assert p.match_seq([1, 2, 3]) is False

    p = NegatedPattern((NodePattern(),))
    assert p.match_seq([])
    assert p.match_seq([1, 2, 3])
    assert p.match_seq([Node(1)]) is False



# Generated at 2022-06-23 16:03:17.991213
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    s = StringIO()
    # Define some nodes of class Leaf
    l1 = Leaf(1, "print")
    l2 = Leaf(1, "(")
    l3 = Leaf(1, ")")
    # Define a node of class Node
    n1 = Node(1, [l1, l2, l3])
    # Insert two nodes of class Leaf
    n1.insert_child(1, Leaf(2, "0"))
    n1.insert_child(2, Leaf(3, "0"))
    # Test the method get_lineno
    assert n1.get_lineno() == 1

# Generated at 2022-06-23 16:03:29.803202
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    myfile = StringIO(
        '''
    def test():
        a = 1
        b = 2
        return a
    '''
    )

    import six
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2.tokenize import tokenize
    from lib2to3.pgen2.driver import Driver
    from blib2to3.grammar import python_grammar
    from blib2to3.pgen2.grammar import Grammar

    global parser
    parser = Driver(python_grammar, convert=False)

# Generated at 2022-06-23 16:03:37.394038
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .parse import pickle_subcst, unpickle_subcst
    from .pgen2 import driver
    if sys.version_info.major >= 3:
        from pickle import Unpickler
    else:
        from pickle import Unpickler as Unpickler

    grammar = driver.load_grammar("Examples/simple.py")
    src = '''
if 1:
    if 1:
        x = 1
    else:
        x = 2
    if 1:
        y = 3
    else:
        y = 4
    if 1:
        z = 5
    else:
        z = 6
else:
    print(2)

print(3)
'''

    subcst = unpickle_subcst(StringIO(pickle_subcst(grammar, src)))

    expected

# Generated at 2022-06-23 16:03:48.611662
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern(
        content=None, min=0, max=HUGE, name=None
    ).optimize() == NodePattern(type=None, content=None, name=None)
    assert WildcardPattern(
        content=None, min=1, max=HUGE, name=None
    ).optimize() == NodePattern(type=None, content=None, name=None)
    assert WildcardPattern(
        content=None, min=0, max=1, name=None
    ).optimize() == NodePattern(type=None, content=None, name=None)
    assert WildcardPattern(
        content=None, min=1, max=1, name=None
    ).optimize() == NodePattern(type=None, content=None, name=None)

# Generated at 2022-06-23 16:03:51.896110
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.token import tok_name

    bp = BasePattern()
    assert repr(bp) == "BasePattern()"
    bp.type = 2
    assert repr(bp) == "BasePattern(NAME)"
    bp.type = 257
    assert repr(bp) == "BasePattern(file_input)"
    bp.type = 256 if sys.version_info[0] < 3 else 257
    assert repr(bp) == "BasePattern(256)"



# Generated at 2022-06-23 16:03:55.387424
# Unit test for function convert
def test_convert():
    from .parser import Grammar, Driver
    from .pgen2.parse import ParseError, parse_grammar_source

    driver = Driver(Grammar(parse_grammar_source(grammar_nt_rules)), convert)
    r = driver.parse_string("3")
    assert isinstance(r, Leaf)
    assert r.value == "3"
    assert r.type == token.NUMBER
    try:
        driver.parse_string("3 + 4 * x")
    except ParseError as e:
        assert e.lineno == 1
        assert e.column == 8
    else:
        assert False, "Expected ParseError"

# Generated at 2022-06-23 16:03:59.199893
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    wp = WildcardPattern(name="test")
    assert str(wp) == "test", repr(wp)
    wp = WildcardPattern(content=[["a", "b", "c"]], name="test")
    assert str(wp) == "(a b c) test", repr(wp)
    wp = WildcardPattern(content=[["a"], ["b"], ["c"]], name="test")
    assert str(wp) == "(a | b | c) test", repr(wp)



# Generated at 2022-06-23 16:04:06.123359
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class LeafPattern(BasePattern):
        def _submatch(self, node, results=None):
            return self.content == node.value

    pattern = LeafPattern(45)
    result = pattern.match_seq(nodes=[Leaf(45, "a")])
    assert result
    result = pattern.match_seq(nodes=[Leaf(44, "b")])
    assert not result

    pattern.content = "b"
    result = pattern.match_seq(nodes=[Leaf(45, "b")])
    assert result



# Generated at 2022-06-23 16:04:13.090342
# Unit test for method post_order of class Node
def test_Node_post_order():
    import libfoolang

    ctx = libfoolang.AnalysisContext()
    u = ctx.get_from_buffer('main.txt', '''
define test {
    x + 1
}
''')
    if u.diagnostics:
        for d in u.diagnostics:
            print(d)
        raise Exception()
    # Debug
    print('1 post_order:', list(u.root.post_order()))



# Generated at 2022-06-23 16:04:20.952127
# Unit test for method clone of class Base
def test_Base_clone():
    from io import StringIO
    from pickle import load, dump

    s = StringIO()
    old_stdout = sys.stdout
    try:
        sys.stdout = s
        dump({}, s)
        s.seek(0)
        d = load(s)
        print(d)
    finally:
        sys.stdout = old_stdout
    assert s.getvalue() == "{}\n"

test_Base_clone()

# Generated at 2022-06-23 16:04:31.679295
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    for cls, args, n in [
        (WildcardPattern, [], 2),
        (LeafPattern, [token.NAME], 1),
        (LeafPattern, [token.NAME, "foo"], 1),
        (LeafPattern, [token.NAME, "foo", "bar"], 1),
    ]:
        p = cls(*args)
        assert p.match_seq([Leaf(200, "foo"), Leaf(201, "bar")]) == True
        assert list(p.generate_matches([Leaf(200, "foo"), Leaf(201, "bar")])) == [(n, {})]
        assert p.match_seq([Leaf(200, "foo")]) == False
        assert list(p.generate_matches([Leaf(200, "foo")])) == []



# Generated at 2022-06-23 16:04:39.424280
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    def _repl(matchobj):
        return " " * (len(matchobj.group(0)) - 1)

    def _test(pattern, input, output):
        r = re.compile(_repl(r"\s*").join(pattern.split()))
        assert r.match(input)

        r = re.compile(_repl(r"\s*").join(pattern.split()), re.DOTALL)
        assert r.match(input)

    def _testall(pattern, input, output):
        r = re.compile(_repl(r"\s*").join(pattern.split()))
        m = r.match(input)
        assert m

        r = re.compile(_repl(r"\s*").join(pattern.split()), re.DOTALL)
        m = r.match

# Generated at 2022-06-23 16:04:40.282836
# Unit test for method match of class BasePattern
def test_BasePattern_match():
  pass # skipped

# Generated at 2022-06-23 16:04:42.524855
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # Test that pattern is None
    p1 = NegatedPattern()
    # Test that pattern is not None
    p2 = NegatedPattern(content=NodePattern())



# Generated at 2022-06-23 16:04:44.192435
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(1, "")
    assert list(l.leaves()) == [l]


# Generated at 2022-06-23 16:04:51.385952
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Node, Leaf
    root = Node(1, [
        Node(2, [Leaf(1, 'expr'), Node(6, [])]),
        Node(3, [Node(4, []), Node(5, [])])
    ])

# Generated at 2022-06-23 16:04:52.103026
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    _ = BasePattern


# Generated at 2022-06-23 16:05:00.415868
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pygram import python_symbols
    from .pgen2 import driver
    from .pgen2.token import LPAR, COMMA, NAME, NUMBER

    src = "foo 100, (1, (2, 3), 4, 5), 200"
    gr = driver.load_grammar("Grammar.txt")
    t = gr.parse(src, start=python_symbols.file_input)
    # tree printing
    stream = StringIO()
    t.pretty_print(stream=stream)
    print(stream.getvalue())
    # node tests
    foo = t.children[0]

    assert foo.type == NAME
    assert foo.value == "foo"

    num1 = t.children[1]
    assert num1.type == NUMBER
    assert num1.value == "100"

# Generated at 2022-06-23 16:05:10.110484
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2 import driver as pgen2_driver
    from . import util

    grammar = pgen2_driver.load_grammar(util.find_grammar("Grammar"), "Grammar")

    for source in (
        "if 1: pass",
        "if 1: pass\nif 1: pass",
        "if 1: pass\nif 1: pass\nif 1: pass",
    ):
        p = grammar.parse(source)
        n = p.children[0]
        r : List[Tuple[int, _Results]] = list(WildcardPattern(grammar.symbol2number["stmt"]).generate_matches(n.children[1].children))
        assert r == [(1, {})]

# Generated at 2022-06-23 16:05:20.932883
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree

    n1 = pytree.Node(pytree.syms.power,
                     [pytree.Leaf(1, "a"), pytree.Leaf(2, "b")])
    n2 = pytree.Node(pytree.syms.power,
                     [pytree.Leaf(3, "c"), pytree.Leaf(4, "d")])
    n3 = pytree.Node(pytree.syms.power, [n1, n2])
    it = n3.post_order()
    assert next(it) is n1
    assert next(it) is n2
    assert next(it) is n3
    assert next(it, None) is None

# Generated at 2022-06-23 16:05:24.360475
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, "potato")
    assert leaf.type == 1
    assert leaf.value == "potato"
    assert leaf.prefix == ""
    assert leaf.children == []
    assert leaf.parent is None



# Generated at 2022-06-23 16:05:32.246536
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    import unittest


    class TestWildcardPattern(unittest.TestCase):
        def test_optimize(self):
            pattern1 = WildcardPattern()
            self.assertEqual(pattern1.optimize(), NodePattern())
            pattern2 = WildcardPattern(content=[[LeafPattern()]])
            self.assertEqual(pattern2.optimize(), NodePattern())
            pattern3 = WildcardPattern(min=1, max=1, content=[[LeafPattern()]])
            self.assertEqual(pattern3.optimize(), NodePattern())
            pattern4 = WildcardPattern(
                min=1, max=1, content=[[LeafPattern()]], name="foo"
            )
            self.assertEqual(pattern4.optimize(), NodePattern(name="foo"))
            pattern5 = WildcardPattern

# Generated at 2022-06-23 16:05:33.422225
# Unit test for constructor of class BasePattern
def test_BasePattern():
    a = BasePattern()



# Generated at 2022-06-23 16:05:36.285164
# Unit test for method remove of class Base
def test_Base_remove():
    from . import driver
    from . import patcomp

    # The following 6 lines were added for the new method Base.remove
    node = driver.ast
    node.remove()
    assert node.parent is None
    assert node.children == []

    def _callback(pattern, tree):
        patcomp._callback(pattern, tree)
        node = driver.ast
        node.remove()
        assert node.parent is None
        assert node.children == []

    patcomp.register_callback(_callback)
    driver.parse_string("")
    print("ok")



# Generated at 2022-06-23 16:05:42.985146
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node

    n = Node(1, [Leaf(1, "f"), Leaf(1, "oo"), Leaf(1, "bar")])
    n[1].changed()
    assert len(n.changed_descendants()) == 1
    assert n[1] in n.changed_descendants()



# Generated at 2022-06-23 16:05:50.922292
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import doctest, blib2to3.pgen2.tree

    globs = blib2to3.pgen2.tree.__dict__.copy()
    globs.update(globals())
    failure_count, test_count = doctest.testmod(globs=globs, optionflags=doctest.NORMALIZE_WHITESPACE)
    assert test_count > 0, "Zero tests found."
    if failure_count:
        raise TestFailed(str(failure_count) + " of " + str(test_count) + " doctests failed")

# Generated at 2022-06-23 16:05:52.906323
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    class N(Node):
        pass

    class L(Leaf):
        pass

    bp = BasePattern()
    assert not bp.match_seq([N(0, [])], {})


# Generated at 2022-06-23 16:05:57.784369
# Unit test for method remove of class Base
def test_Base_remove():
    from . import pytree
    t = pytree.Node(5, [pytree.Leaf(1, "a"),
                        pytree.Leaf(2, "b"),
                        pytree.Leaf(3, "c")])
    t.remove()
    assert t.parent == None


# Generated at 2022-06-23 16:06:03.990851
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from ..pgen2 import token, tokenize
    test_str = b"'''"
    test_token_list = list(tokenize.tokenize(BytesIO(test_str).readline))
    test_leaf = Leaf(test_token_list[0].type, test_token_list[0].string)
    assert repr(test_leaf) == "Leaf(STRING, '''')"

# Generated at 2022-06-23 16:06:09.030791
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    x = NegatedPattern(LeafPattern(2))
    assert x.match(Leaf(1, "a"))
    assert not x.match(Leaf(2, "b"))
    assert not x.match(Node(1, []))


# Generated at 2022-06-23 16:06:13.918421
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """BasePattern - def __new__(cls, *args, **kwds):"""
    cls = BasePattern
    exc = """Cannot instantiate BasePattern"""
    cls = BasePattern(cls)
    assert cls is BasePattern
    cls = BasePattern(cls)
    assert cls is BasePattern


# Generated at 2022-06-23 16:06:22.769887
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import unittest
    from blib2to3.pgen2.pgen import token
    from blib2to3.pytree import Leaf, Node
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tree = Node(token.FILE_INPUT, [
                Leaf(token.INDENT, ''),
                Node(token.FOR_STMT, [
                    Leaf(token.NAME, 'for'),
                    Leaf(token.NAME, 'x'),
                    ]),
                Node(token.EXPR_STMT, [
                    Leaf(token.NAME, 'x'),
                    Leaf(token.EQUAL, '='),
                    Leaf(token.NUMBER, '0'),
                    ]),
                Leaf(token.DEDENT, ''),
                ])

# Generated at 2022-06-23 16:06:28.952404
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    negPat = NegatedPattern(None)
    assert type(negPat) == NegatedPattern
    assert negPat.content == None
    assert negPat.match(None) == False
    assert negPat.match_seq(None) == False
    assert negPat.generate_matches(None) == [0, {}]


# Generated at 2022-06-23 16:06:33.746811
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    node = Node(1, [])
    node2 = Node(2, [Leaf("def")])
    node3 = Node(3, [])
    node4 = Node(4, [])
    node5 = Node(5, [])
    node6 = Node(6, [Leaf("def")])
    node7 = Node(7, [])
    node8 = Node(8, [])
    node9 = Node(9, [Leaf("def")])
    node10 = Node(10, [])
    node11 = Node(11, [])
    node12 = Node(12, [Leaf("def")])
    node13 = Node(13, [])
    node14 = Node(14, [])
    node15 = Node(15, [Leaf("def")])
    node16 = Node(16, [])

# Generated at 2022-06-23 16:06:40.437989
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():

    # Check constructor of class NegatedPattern
    p1 = NegatedPattern()
    assert p1.content is None, repr(p1.content)
    p1 = NegatedPattern(NodePattern())
    assert isinstance(p1.content, NodePattern), repr(p1.content)
    try:
        p1 = NegatedPattern(1)
        raise AssertionError("Badly initialized pattern should raise an exception")
    except AssertionError:
        pass
# ------------------------------------------------------------------------------
# Tests: ignore
# ------------------------------------------------------------------------------



# Generated at 2022-06-23 16:06:41.050607
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    LeafPattern()



# Generated at 2022-06-23 16:06:45.317691
# Unit test for constructor of class Node
def test_Node():
    a = Leaf(1, "")
    b = Leaf(2, "")
    c = Leaf(3, "")
    parent = Node(4, [a, b, c])
    assert a.parent is parent
    assert b.parent is parent
    assert c.parent is parent
    assert parent.children == [a, b, c]



# Generated at 2022-06-23 16:06:58.256573
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .. import parse
    from .. import tokenize
    from .pgen2.token import N_TOKENS, NAME
    for type_number in range(N_TOKENS):
        if type_number != NAME:
            token = tokenize.tok_name[type_number]
            name_node = parse.extract_node(token)
            leaf_list = list(name_node.leaves())
            assert len(leaf_list) == 1
            assert leaf_list[0] is name_node
    token = tokenize.tok_name[NAME]
    value = '"baz"'
    name_node = parse.extract_node(token + value)
    leaf_list = list(name_node.leaves())
    assert len(leaf_list) == 1
    assert leaf_list[0].type

# Generated at 2022-06-23 16:07:01.665792
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    l=Leaf(256, "test")
    assert l.clone() == l


# Generated at 2022-06-23 16:07:06.350496
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    leaf = Leaf(NUMBER, "1")
    p = LeafPattern(NUMBER)
    assert list(p.generate_matches([leaf])) == [(1, {})]
    assert list(p.generate_matches([])) == []


# Generated at 2022-06-23 16:07:13.136540
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    >>> repr(BasePattern(type=1, content='foo', name='bar'))
    'BasePattern(1, 'foo', 'bar')'
    >>> repr(BasePattern(type=1, content='foo'))
    'BasePattern(1, 'foo')'
    >>> repr(BasePattern(type=1, name='bar'))
    'BasePattern(1, None, 'bar')'
    >>> repr(BasePattern(type=1))
    'BasePattern(1)'
# -- END: test_BasePattern___repr__
    """



# Generated at 2022-06-23 16:07:19.136227
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import driver

    class Pattern(BasePattern):
        def _submatch(self, node, results):
            return True

    gr = driver.load_grammar("Grammar/Grammar")

    def test(pattern, node, expected):
        # Ensure we're testing an exact match
        if expected:
            assert pattern.type is None or pattern.type == node.type
            assert pattern.content is None or pattern.content in node.value
            assert pattern.name is None or pattern.name.startswith('<')
        m = pattern.match(node)
        assert m == expected, (
            "BasePattern(%d, %r).match(Node(%d, ...)) == %r != %r"
            % (pattern.type, pattern.content, node.type, m, expected)
        )



# Generated at 2022-06-23 16:07:20.965382
# Unit test for method __new__ of class Base
def test_Base___new__():
    import Base
    testcase_1 = Base(  )
    assert isinstance(testcase_1, Base)


# Generated at 2022-06-23 16:07:28.808291
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern((("a",), ("b",), ("c",)), 0, 1, "bare_name")
    assert p.content == (("a",), ("b",), ("c",))
    assert p.min == 0
    assert p.max == 1
    assert p.name == "bare_name"

    p = WildcardPattern((("a",), ("b",), ("c",)))
    assert p.content == (("a",), ("b",), ("c",))
    assert p.min == 0
    assert p.max == HUGE

    p = WildcardPattern(("a", "b", "c"))
    assert p.content == (("a", "b", "c"),)
    assert p.min == 0
    assert p.max == HUGE

    p = WildcardPattern("a")
    assert p.content

# Generated at 2022-06-23 16:07:32.970577
# Unit test for method match_seq of class BasePattern

# Generated at 2022-06-23 16:07:41.071058
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pygram import python_symbols
    from .pgen2 import token

    b = Base()
    b1 = Base()
    b2 = Base()
    b2.type = python_symbols.power
    b2.parent = b1
    b2.children = [Leaf(token.POW, "**"), Leaf(token.DOUBLESTAR, "**")]
    b2.was_changed = False
    b2.was_checked = True

    assert b == b, "Equality not reflexive"
    assert b1 == b1, "Equality not reflexive"
    assert b2 == b2, "Equality not reflexive"
    assert not (b == b1), "Equality not symmetric"
    assert not (b1 == b2), "Equality not transitive"
   

# Generated at 2022-06-23 16:07:44.483375
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(python_symbols.COMMA) == "COMMA"
    assert type_repr(python_symbols.PLUS) == "PLUS"



# Generated at 2022-06-23 16:07:46.880375
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert BasePattern().type is None
    assert BasePattern().content is None
    assert BasePattern().name is None



# Generated at 2022-06-23 16:07:53.680910
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Leaf, Node

    tree = Node(1, [
        Leaf(1, "foo"),
        Node(1, [
            Leaf(1, "bar"),
            Leaf(1, "baz"),
            Node(1, [
                Leaf(1, "qux"),
            ]),
        ]),
        Leaf(1, "spam"),
    ])
    assert [x.value for x in tree.post_order()] == ['foo', 'bar', 'baz', 'qux', 'spam']



# Generated at 2022-06-23 16:07:55.062833
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    try:
        node = BasePattern()
    except TypeError:
        pass


# Generated at 2022-06-23 16:08:06.925505
# Unit test for method replace of class Base
def test_Base_replace():
    from lib2to3.pytree import Leaf, Node
    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Node(1, [a, b])
    assert c.parent is None
    d = Node(2, [c])
    assert c.parent is d
    assert b.parent is c
    assert a.parent is c
    assert d == Node(2, [Node(1, [Leaf(1, "a"), Leaf(1, "b")])])
    b.replace(Leaf(1, "c"))
    assert d == Node(2, [Node(1, [Leaf(1, "a"), Leaf(1, "c")])])
    d.children[0].type = 3

# Generated at 2022-06-23 16:08:09.081531
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    import ast
    # AsssertionError
    l = ast.Leaf()
    assert l.clone == l

# Generated at 2022-06-23 16:08:13.862432
# Unit test for method append_child of class Node
def test_Node_append_child(): # IGNORE:C01111
    '''Unit test for method append_child of class Node'''
    n = Node(0, [])
    n.append_child(Leaf(0, ""))
    assert n.children[0] == Leaf(0, "")


# Generated at 2022-06-23 16:08:17.617613
# Unit test for function type_repr
def test_type_repr():
    assert type(type_repr(2)) == type("")
    assert type_repr(2) == "NAME"
    assert type_repr(3) == 3



# Generated at 2022-06-23 16:08:26.822146
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from .pgen2.driver import Driver

    class Pattern(BasePattern):

        def __init__(self, x):
            self.x = x

        def optimize(self):
            if self.x == 0:
                return None
            elif self.x == 1:
                return LeafPattern(token.NAME, "foo")
            else:
                return self

        def _submatch(self, node, results):
            return False

    p = Pattern(0).optimize()
    assert p is None

    p = Pattern(1).optimize()
    assert p.type == token.NAME
    assert p.value == "foo"

    p = Pattern(2).optimize()
    assert p.x == 2



# Generated at 2022-06-23 16:08:35.029072
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    # Create nodes for testing.
    t1 = Leaf(1, "a")
    t2 = Leaf(2, "b")
    # Create tree for testing.
    tree = Node(3, [t1, t2])
    # Unit test for method __str__ of class Leaf
    assert t1.__str__() == "a"
    assert t2.__str__() == "b"
    assert tree.__str__() == "ab"


# If a class has a special method `__bool__` python will call it in case of
# 'if class', so we need to check it seperately.


# Generated at 2022-06-23 16:08:43.286842
# Unit test for method remove of class Base
def test_Base_remove():
    class Node(Base):
        def _eq(self, other: "Node") -> bool:
            return True
        def clone(self: "Node") -> "Node":
            return Node()
        def post_order(self) -> Iterator["Node"]:
            for n in self.children:
                yield from n.post_order()
            yield self
        def pre_order(self) -> Iterator["Node"]:
            yield self
            for n in self.children:
                yield from n.post_order()

    class Leaf(Base):
        def _eq(self, other: "Leaf") -> bool:
            return True
        def clone(self: "Leaf") -> "Leaf":
            return Leaf()
        def post_order(self) -> Iterator["Leaf"]:
            yield self

# Generated at 2022-06-23 16:08:54.320513
# Unit test for method set_child of class Node
def test_Node_set_child():
    import blib2to3.io as io
    from blib2to3.pytree import Leaf
    from typing import Tuple
    from .pygram import python_grammar
    from .pgen2 import token
    with io.StringIO() as f:
        f.write('if 1:pass\n')
        s = f.getvalue()
        st = python_grammar.parse_string(s)
        st.set_lineno(3,10)
        (file_input, [if_stmt, pass_stmt]) = st.children
        if_stmt.set_child(1,pass_stmt)
        import pytest
        excinfo = pytest.raises(IndexError, if_stmt.set_child, 2, pass_stmt)

# Generated at 2022-06-23 16:09:04.287883
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    from .grammar import Symbol, Nonterminal
    from .tree import Node, Leaf

    # test empty negated pattern
    p = NegatedPattern()
    assert p.match_seq([])
    assert not p.match_seq([Leaf(1, 'a')])
    assert not p.match_seq([Node(Nonterminal('foo'), []), Node(Nonterminal(
        'bar'), [Leaf(2, 'b')]), Leaf(1, 'a')])

    # test negated pattern with content
    p = NegatedPattern(NodePattern(type=Nonterminal, content=[
                       LeafPattern(type=Symbol, value='a'), LeafPattern(value='b')]))
    assert not p.match_seq([])
    assert not p.match_seq([Leaf(1, 'a')])

# Generated at 2022-06-23 16:09:15.717126
# Unit test for function convert
def test_convert():
    from . import parsetok
    from .pgen2.grammar import Grammar

    def _convert(gr, raw_node):
        return convert(gr, raw_node)


# Generated at 2022-06-23 16:09:25.347110
# Unit test for method leaves of class Base
def test_Base_leaves():
    class C(Base): pass
    class L(Leaf): pass
    l = L("")
    c = C(NL, [C(NL, [L("")]), L("")])
    leaves = list(c.leaves())
    assert leaves == [L(""), L("")]
    assert leaves[0].parent.parent is c
    assert leaves[0].parent is not c
    assert leaves[1].parent is c
    assert l.next_sibling is None
    assert l.prev_sibling is None


# Generated at 2022-06-23 16:09:35.380569
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    p = NegatedPattern(content=WildcardPattern(content=[NodePattern(type=256)]))
    g = p.generate_matches([])
    if not next(g,False):
        raise RuntimeError('NegatedPattern.generate_matches() produced no output')
    try:
        next(g)
        raise RuntimeError('NegatedPattern.generate_matches() produced too much output')
    except StopIteration:
        pass
    g = p.generate_matches([symbol.number])
    if not next(g,False):
        raise RuntimeError('NegatedPattern.generate_matches() produced no output')
    try:
        next(g)
        raise RuntimeError('NegatedPattern.generate_matches() produced too much output')
    except StopIteration:
        pass

# Generated at 2022-06-23 16:09:46.676243
# Unit test for method post_order of class Node
def test_Node_post_order():
    from libcst.testing.utils import data_provider
    import libcst as cst


# Generated at 2022-06-23 16:09:48.817797
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from . import pytree

    leaf = pytree.Leaf(1, 2)
    assert list(leaf.post_order()) == [leaf]


# Generated at 2022-06-23 16:09:57.156646
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.token import LPAR, NAME, RPAR

    p1 = Leaf(LPAR, "("); p2 = Leaf(NAME, "foo"); p3 = Leaf(RPAR, ")")
    parent = Node(syms.simple_stmt, [p1, p2, p3])
    assert [p1, p2, p3] == list(parent.post_order())
    assert [p3, p2, p1] == list(reversed(list(parent.post_order())))
    assert [parent] == list(parent.post_order(include_parents=True))
    assert [p3, parent] == list(reversed(list(parent.post_order(include_parents=True))))



# Generated at 2022-06-23 16:10:04.437912
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from pickle import loads, dumps
    from .pgen2 import tokenize

    for i in range(4):
        for j in range(4):
            for k in range(4):
                p = WildcardPattern(((Leaf(2, "abc"),),), i, j, "abc")
                q = loads(dumps(p))
                assert q.min == p.min == i
                assert q.max == p.max == j
                assert q.name == p.name == "abc"

                n = [Leaf(2, "def"), Leaf(2, "abc"), Leaf(2, "def")]
                m = 1 + (k % len(n))
                assert q.match_seq(n[:m]) == (m == 2)

# Generated at 2022-06-23 16:10:13.915200
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    p = NegatedPattern(NodePattern(type=token.NAME, name="var"))
    n = generator.generate_tokens([token.NAME])[0]
    # We never match a node in its entirety
    assert not p.match(n)
    # We only match an empty sequence of nodes in its entirety
    assert p.match_seq([])
    assert not p.match_seq([n])
    assert not p.match_seq([n, n])
    # Our argument pattern has no matches
    assert p.generate_matches([]) == [(0, {})]
    assert list(p.generate_matches([n])) == []
    assert list(p.generate_matches([n, n])) == []
    p = NegatedPattern()
    # Our argument pattern has no matches
    assert p.gener

# Generated at 2022-06-23 16:10:25.166761
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    import unittest


# Generated at 2022-06-23 16:10:29.508932
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf, Node
    from .pgen2 import tokenize

    # This test works by tokenizing a string, then reconstructing the parsed
    # tree and using get_suffix.
    test_string = "1 + 1"

    tree = Node(python_symbols.testlist_star_expr, [
        Leaf(tokenize.NUMBER, "1"),
        Leaf(tokenize.PLUS, "+"),
        Leaf(tokenize.NUMBER, "1")])

    assert tree.children[0].get_suffix() == " + 1", "Base_get_suffix failed."
    assert tree.children[1].get_suffix() == " 1"
    assert tree.children[2].get_suffix() == ""



# Generated at 2022-06-23 16:10:41.801274
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf

    class Node(Base):
        def __init__(self, children=None):
            self.children = children or []
            for c in self.children:
                c.parent = self

    class SomeOtherNode(Base):
        pass

    node1 = Node([Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c")])
    assert node1.remove() == 0
    assert node1.parent is None

    node1.parent = Node([node1])
    assert node1.replace(None) == 0
    assert node1.parent is None
    assert node1.remove() is None

    node2 = Node()
    node2.parent = node1
    node1.children = [node2]
    # assert node1.children[0].remove() == 0


# Generated at 2022-06-23 16:10:44.348336
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    assert repr(Leaf(1, "foo")) == "Leaf(NAME, 'foo')"

# Generated at 2022-06-23 16:10:46.069830
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    lp = LeafPattern(0, "abcd")
    assert lp.type == 0
    assert lp.content == "abcd"
    assert lp.name is None



# Generated at 2022-06-23 16:10:51.703611
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    def remove_whitespace(source) -> Iterator[Any]:
        for tp in source:
            if tp.type != token.INDENT:
                yield tp
    foo = Leaf(token.NAME, "foo")
    for tp in remove_whitespace(foo.post_order()):
        assert_equal(tp, foo)


# Generated at 2022-06-23 16:11:00.928885
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    o = BasePattern.optimize(BasePattern())
    assert o is BasePattern
    p = LeafPattern(1, "foo")
    o = p.optimize()
    assert o is p

# class BasePattern(object):
#     type = None
#     content = None
#     name = None

#     def __new__(cls, *args, **kwds):
#         assert cls is not BasePattern, "Cannot instantiate BasePattern"
#         return object.__new__(cls)

#     def __init__(self, type, content=None, name=None):
#         self.type = type
#         self.content = content
#         self.name = name

#     def __repr__(self):
#         args = [type_repr(self.type), self.content

# Generated at 2022-06-23 16:11:04.947483
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import pytest
    from .pgen2 import driver
    from . import token

    gr = driver.load_grammar("nonterminal")
    p = BasePattern(token.NAME)
    with pytest.raises(NotImplementedError):
        p.match_seq([])



# Generated at 2022-06-23 16:11:14.493147
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from typing import Any
    from .pgen2.token import Token

    class MyBasePattern(BasePattern):
        def _submatch(self, node, results=None):
            return True

    t = MyBasePattern("a", "b")
    assert isinstance(t, MyBasePattern)

    def test_match(obj, type, content):
        assert t.match(Token(type, content))

    test_match(None, "a", "b")
    test_match(None, "a", None)
    test_match(None, None, "b")
    test_match(None, None, None)



# Generated at 2022-06-23 16:11:26.576768
# Unit test for function convert
def test_convert():
    from .pgen2.grammar import Grammar
    from .pgen2.parse import Parser
    from .pgen2.token import LPAR, INT, RPAR, NAME

    gr = Grammar(grammar_fixture)
    parser = Parser(gr)
    result = list(parser.parse("(1)", convert))
    assert len(result) == 1
    top_node = result[0]
    assert top_node.type == gr.number2symbol[gr.symbol2number["factor"]]
    assert len(top_node.children) == 3
    left_paren = top_node.children[0]
    assert left_paren.type == gr.number2symbol[gr.symbol2number[")"]]
    assert left_paren.value == "("

# Generated at 2022-06-23 16:11:33.611919
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    v = [(0, {}), (1, {'a': [Leaf(1, 'a')]}), (2, {'a': [Leaf(1, 'a'), Leaf(2, 'a')]})]
    assert list(WildcardPattern(min=0, max=2, name='a').match_seq([Leaf(1, 'a'), Leaf(2, 'a')])) == v

# Generated at 2022-06-23 16:11:36.953036
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    for cls in LeafPattern, NodePattern:
        assert cls.optimize() is cls



# Generated at 2022-06-23 16:11:48.470092
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree
    from .grammar import Whitespace, newline

    tree = pytree.Node(1, [pytree.Node(2, [pytree.Leaf(3, "x"), Whitespace(),
                                          pytree.Leaf(4, "y"), Whitespace(),
                                          pytree.Leaf(5, "z"), newline()]),
                           pytree.Leaf(6, "a")])

# Generated at 2022-06-23 16:11:58.193882
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf
    from .pygram import python_symbols as syms
    from blib2to3.fixer_util import Name

    class node(Base):
        pass

    # Test 1: check lineno for a Leaf
    l = Leaf(type=Name, value="print", parent=None)
    assert l.get_lineno() == None

    # Test 2: check lineno for a leaf inside a Node
    n = node(type=syms.funcdef, children=[l], parent=None)
    assert n.get_lineno() == None

    # Test 3: check lineno for a multi-level node, with linenos
    l1 = Leaf(type=Name, value="foo", parent=None)
    l2 = Leaf(type=Name, value="bar", parent=None)
    l1