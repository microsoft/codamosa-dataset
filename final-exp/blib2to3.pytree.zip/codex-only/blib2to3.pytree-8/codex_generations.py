

# Generated at 2022-06-23 16:02:01.610644
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # The following test case was added because it was
    # failing at one time.  It should pass.
    #
    # The pattern matches any sequence that is not x or y.
    # This includes the empty sequence, which is required by
    # the implementation of match().
    pattern = NegatedPattern(PatternUnion(
        NodePattern(1, NodePattern(2)),
        NodePattern(2, NodePattern(1))))
    # Test it, using Node(type) as a shortcut for a sequence
    # of one NodePattern(type)
    assert pattern.match(Node(3))
    assert not pattern.match(Node(1, Node(2)))
    assert not pattern.match(Node(2, Node(1)))
    pattern = PatternUnion(
        NodePattern(1, NodePattern(2)),
        NodePattern(2, NodePattern(1)))

# Generated at 2022-06-23 16:02:09.192595
# Unit test for method __str__ of class Node
def test_Node___str__():
    """Class Node method __str__."""
    print((Node(python_symbols.keyword, [Leaf(token.IF, "if")]).__str__() == "if"))
    print((Node(python_symbols.keyword, [Leaf(token.IF, "if"), Leaf(token.NAME, "assert")]).__str__() == "ifassert"))
    print((Node(python_symbols.keyword, [Leaf(token.IF, "if"), Leaf(token.NAME, "assert"), Leaf(token.NAME, "assert")]).__str__() == "ifassertassert"))



# Generated at 2022-06-23 16:02:15.342474
# Unit test for function generate_matches
def test_generate_matches():
    p1 = NodePattern(type=1)
    p2 = NodePattern(type=2)
    p3 = NodePattern(type=3)
    p4 = NodePattern(type=4)
    p5 = NodePattern(type=5)
    p6 = NodePattern(type=6)
    p7 = NodePattern(type=7)
    p8 = NodePattern(type=8)
    p9 = NodePattern(type=9)
    p10 = NodePattern(type=10)
    n1 = NL(1)
    n2 = NL(2)
    n3 = NL(3)
    n4 = NL(4)
    n5 = NL(5)
    n6 = NL(6)
    n7 = NL(7)
    n8 = NL(8)

# Generated at 2022-06-23 16:02:20.597672
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    assert NegatedPattern()
    assert NegatedPattern(NodePattern())
    assert NegatedPattern(LeafPattern(""))
    assert NegatedPattern(WildcardPattern())
    assert NegatedPattern(NodePattern(name="foo"))
    assert NegatedPattern(LeafPattern("", name="bar"))
    assert NegatedPattern(WildcardPattern(name="baz"))



# Generated at 2022-06-23 16:02:22.816213
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    assert Leaf(123, '456').__repr__() == 'Leaf(123, \'456\')'

# Generated at 2022-06-23 16:02:29.652163
# Unit test for method post_order of class Node
def test_Node_post_order():
    program = n('module', [
        n('simple_stmt', [
            n('small_stmt', [
                l(2, 's'),
            ]),
            l(3, '\n'),
            n('small_stmt', [
                l(4, 't'),
            ]),
            l(5, '\n'),
        ]),
        l(6, '\n'),
        n('simple_stmt', [
            n('small_stmt', [
                l(8, 'u'),
            ]),
            l(9, '\n'),
            n('small_stmt', [
                l(10, 'v'),
            ]),
            l(11, '\n'),
        ]),
        l(12, '\n'),
    ])
    result = []

# Generated at 2022-06-23 16:02:32.102675
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    l = Leaf(0, '')
    assert list(l.leaves()) == [l]


# Generated at 2022-06-23 16:02:40.493938
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    input = 'class C:\n    x="7"'
    t = ast27.parse(input)
    t.body[0].body[0].value.s += ",8"
    assert t.body[0].body[0].value.s == "7,8"
    assert ast27.dump(t) == input.replace("7", "7,8") # but what about the .eol?
test_Leaf___str__()
#@+node:ekr.20180410091658.1: ** class State

# Generated at 2022-06-23 16:02:45.634019
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    #Implicit is the return of the function pre_order in the class Node
    #Given a Node
    Node_pre_order = Node(1,[])
    #When calling pre_order on Node_pre_order
    result = Node_pre_order.pre_order()
    #Then result should be the same Node_pre_order
    assert result == Node_pre_order

# Generated at 2022-06-23 16:02:51.399092
# Unit test for method pre_order of class Leaf

# Generated at 2022-06-23 16:02:53.744527
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # Tested implicitly by all other unit tests

    # The _eq method of Base can't be tested because it is abstract
    pass


# Generated at 2022-06-23 16:02:56.733034
# Unit test for method __str__ of class Node
def test_Node___str__():
  n = Node(1, [1, 2, 3])
  for _ in n.children:
    _.prefix = "a"
  assert n.__str__() == "aaa123"

# Generated at 2022-06-23 16:02:58.152153
# Unit test for method remove of class Base
def test_Base_remove():
    node = Node(1, [Leaf(1, 'a')])
    assert node.remove() == 0


# Generated at 2022-06-23 16:03:02.888410
# Unit test for method __new__ of class Base
def test_Base___new__():
    # type: () -> None
    class MyBase(Base):
        pass
    class MyClass(MyBase):
        def __init__(self, x):
            self.x = x
    a = MyClass(42)
    assert isinstance(a, Base)


# Generated at 2022-06-23 16:03:05.630840
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    p = BasePattern()
    l = []
    assert not p.match_seq(l)
    l = [Leaf(1, "foo")]
    assert not p.match_seq(l)

# Generated at 2022-06-23 16:03:12.396942
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.token import tok_name

    my_leaf = Leaf(1,"2",(3,(4,5)),[])
    assert tok_name.get(my_leaf.type, my_leaf.type) == 'NUMBER'
    assert my_leaf.value == '2'
    assert tok_name.get(my_leaf.next_sibling, my_leaf.next_sibling) == 'None'
    assert tok_name.get(my_leaf.prev_sibling, my_leaf.prev_sibling) == 'None'
    assert my_leaf.children == []
    assert my_leaf.parent == None
    assert my_leaf.fixers_applied == []
    assert my_leaf.prefix == '3'
    assert my_leaf.lineno == 4
    assert my

# Generated at 2022-06-23 16:03:21.750319
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from . import parse
    from .pgen2 import tokenize

    # The following asserts the following:
    # 1. The parse tree is unchanged before and after the optimizations have been performed
    # 2. The number of wildcard patterns has been reduced
    old_tree = parse.suite('a + b + c')
    p = parse.pattern('a + b + c')
    new_tree = p.match(old_tree)
    assert new_tree == old_tree
    old_pattern = p._flatten_tree(p.tree)
    new_pattern = p._flatten_tree(parse.pattern('a + b + c').tree.optimize())
    assert len(new_pattern) < len(old_pattern)

    # The following asserts the following:
    # 1. The parse tree is unchanged before and after the optimizations have been performed

# Generated at 2022-06-23 16:03:31.857411
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    g = Grammar()
    g.symbol2number = {'s1': 1, 's2': 2}
    g.number2symbol = [None, 's1', 's2']
    l1 = Leaf(7,0,'')
    l2 = Leaf(7,0,'')
    l3 = Leaf(7,0,'')
    l4 = Leaf(7,0,'')
    l5 = Leaf(7,0,'')
    l6 = Leaf(7,0,'')
    l7 = Leaf(7,0,'')
    l8 = Leaf(7,0,'')
    l9 = Leaf(7,0,'')
    l10 = Leaf(7,0,'')
    l11 = Leaf(7,0,'')
    l12 = Leaf(7,0,'')

# Generated at 2022-06-23 16:03:32.645059
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """Method __new__ of class BasePattern"""
    BasePattern()



# Generated at 2022-06-23 16:03:36.003547
# Unit test for method append_child of class Node
def test_Node_append_child():
  n = Node(256, [])
  n.append_child(Node(256, []))
  assert len(n.children) == 1
  assert n.children[0].__class__.__name__ == 'Node'
  assert n.children[0].type == 256
  assert n.children[0].parent == n


# Generated at 2022-06-23 16:03:42.721300
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node

    node = Node(1, [Leaf(1, "foo"), Leaf(1, "bar")])
    assert not node.was_changed
    assert not node.children[0].was_changed
    node.changed()
    assert node.was_changed
    assert node.children[0].was_changed
    # Test resetting
    node.was_checked = True
    node.was_changed = False
    node.children[0].was_checked = True
    node.children[0].was_changed = False
    node.changed()
    assert node.was_changed
    assert node.children[0].was_changed
    assert node.was_checked
    assert node.children[0].was_checked



# Generated at 2022-06-23 16:03:51.124421
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    node = Node(1, [Leaf(1, 'a'), Leaf(2, 'b')])
    p1 = NegatedPattern(NodePattern(content=[TextPattern('a'), TextPattern('b')]))
    p2 = NodePattern(content=[TextPattern('a'), TextPattern('b')])
    p3 = NegatedPattern()
    p4 = NegatedPattern(NodePattern(content=[TextPattern('A'), TextPattern('B')]))
    assert p1.match(node, results=None) == True
    assert p2.match(node, results=None) == True
    assert p3.match(node, results=None) == False
    assert p4.match(node, results=None) == False



# Generated at 2022-06-23 16:04:02.522960
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pgen2.token import OP, NAME, NUMBER

    grammar = Grammar(StringIO(r"""
    file_input: (NEWLINE | stmt)* ENDMARKER
    stmt: simple_stmt | compound_stmt
    simple_stmt: NAME '=' NAME
    compound_stmt: GROUP NEWLINE* NAME END
    """))
    root_node = grammar.number2symbol[grammar.start]
    expected = [
        NAME,
        "<",
        NAME,
        "=",
        NAME,
        ">",
        OP,
        OP,
        OP,
        OP,
        GROUP,
        NEWLINE,
        NEWLINE,
        NAME,
        END,
    ]
    expected_str = "".join(type_repr(type) for type in expected)


# Generated at 2022-06-23 16:04:11.358325
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    import re
    txt = """
    # This file contains the Python codes from Program 9.1 of
    # "Data Structures and Algorithms
    # with Object-Oriented Design Patterns in Python"
    # by Bruno R. Preiss.
    # Copyright (c) 2003 by Bruno R. Preiss, P.Eng.  All rights reserved.
    #
    # http://www.brpreiss.com/books/opus7/programs/pgm09_01.txt
    """

    p = Parser(scanner.Scanner(txt))
    t = p.parse()
    assert txt.strip() == str(t).strip()



# Generated at 2022-06-23 16:04:18.397076
# Unit test for method clone of class Node
def test_Node_clone():
    def _deep_eq(node1, node2):
        assert type(node1) == type(node2)
        if isinstance(node1, Node):
            assert node1.type == node2.type
            assert len(node1.children) == len(node2.children)
            for ch1, ch2 in zip(node1.children, node2.children):
                _deep_eq(ch1, ch2)
        else:
            assert node1.value == node2.value
            assert node1.type == node2.type
            assert node1.context == node2.context

    n1 = Node(1, [Leaf(1, "a"), Leaf(1, "b")])
    n1.used_names = set(["a", "b"])

# Generated at 2022-06-23 16:04:24.915044
# Unit test for constructor of class BasePattern
def test_BasePattern():

    class A(BasePattern):
        pass

    with pytest.raises(TypeError):
        A()

    class B(A):
        pass

    with pytest.raises(TypeError):
        B()

    class C(A):
        def _submatch(self, node, results=None):
            return True

    assert C(name="foo", type=42)



# Generated at 2022-06-23 16:04:35.742712
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.tokenize import tokenize, OP

    from .pgen2 import _generate_tokens

    class Foo(BasePattern):
        type = OP

    for i in (1, 2, 3):
        s = "x = 1"
        tokens1 = list(tokenize(StringIO(s).readline))
        tokens2 = list(_generate_tokens(StringIO(s).readline))
        assert list(Foo().generate_matches(tokens1[1:i])) == list(
            Foo().generate_matches(tokens2[1:i])
        )
    assert list(Foo().generate_matches([])) == []
    assert list(Foo().generate_matches([tokens1[0]])) == []
test_BasePattern

# Generated at 2022-06-23 16:04:41.597539
# Unit test for method append_child of class Node
def test_Node_append_child():
    b = Base()
    b.parent = None
    b.children = []
    b.was_changed = False
    b.was_checked = False
    b.type = None
    n = Node(1, b.children)
    n.fixers_applied = None
    n.used_names = None
    n.type = 1
    n.parent = None
    n.children = b.children
    n.was_changed = False
    n.was_checked = False
    n.append_child(b)

# Generated at 2022-06-23 16:04:49.626844
# Unit test for method post_order of class Base
def test_Base_post_order():

    import unittest
    import sys

    ############################################################################
    # test_Base_post_order.TestLeaf
    ############################################################################
    class TestLeaf(Leaf):

        def __init__(self, type, value, context):
            super().__init__(type, value, context)
            self._counter = 0

        def post_order(self):

            self._counter += 1
            yield self

        def get_counter(self):
            return self._counter
    ############################################################################
    # test_Base_post_order.TestNode
    ############################################################################
    class TestNode(Node):

        def __init__(self, type, children, context):
            super().__init__(type, children, context)
            self._counter = 0


# Generated at 2022-06-23 16:04:58.432806
# Unit test for function generate_matches
def test_generate_matches():
    from . import pytree

    def check(patterns, nodes, expected):
        actual = list(generate_matches(list(patterns), list(nodes)))
        assert actual == expected, (actual, expected)

    check(
        [], [], [(0, {})]
    )  # empty pattern matches anything
    check([WildcardPattern(min=1, max=1)], [], [])
    check([WildcardPattern(min=1, max=1)], [pytree.Leaf(1, "1")], [(1, {})])
    check(
        [WildcardPattern(min=2, max=2)], [pytree.Leaf(1, "1")], []
    )  # pattern has unsatisfied min

# Generated at 2022-06-23 16:05:04.896339
# Unit test for method changed of class Base
def test_Base_changed():
    l1 = Leaf(1, "")
    l2 = Leaf(2, "")
    l3 = Leaf(3, "")
    n = Node(4, [l1, l2, l3])
    assert not n.was_changed
    l1.changed()
    assert n.was_changed
    assert not l2.was_changed
    assert not l3.was_changed
test_Base_changed()


# Generated at 2022-06-23 16:05:10.772887
# Unit test for method clone of class Node
def test_Node_clone():
    n = Node(0, [])
    # test basic sanity of clone
    n_clone = n.clone()
    assert n == n_clone
    assert n is not n_clone
    # test parent attribute not cloned
    n.parent = n
    assert n.parent == n
    assert n_clone.parent is None

# Generated at 2022-06-23 16:05:15.215597
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    for content in (None, LeafPattern()):
        pat = NegatedPattern(content)
        if content is None:
            assert pat.match_seq([])
        else:
            assert pat.match_seq([1])



# Generated at 2022-06-23 16:05:24.699153
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    def t0(c: Base, other: Any) -> bool:
        return c.__eq__(other)
    class DummyBase(Base):
        def _eq(self, other) -> bool:
            return True
    d = DummyBase()
    assert t0(d, d)
    assert not t0(d, None)
    class DummyBase1(Base):
        def _eq(self, other) -> bool:
            return isinstance(other, self.__class__)
    d1 = DummyBase1()
    d2 = DummyBase1()
    assert t0(d1, d1)
    assert t0(d1, d2)
    assert not t0(d1, d)

# Generated at 2022-06-23 16:05:27.460471
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    assert LeafPattern(1, "foo").match(Leaf(1, "foo"))
    assert not LeafPattern(1, "foo").match(Leaf(1, "bar"))
    assert not LeafPattern(2, "foo").match(Leaf(1, "foo"))
    assert not LeafPattern(1, "fOo").match(Leaf(1, "foo"))
    assert not LeafPattern(1, "foo").match(Node(1, []))


# Generated at 2022-06-23 16:05:28.664286
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    x = NegatedPattern()
    assert x.content is None


#
# Support for pickling
#

# Generated at 2022-06-23 16:05:40.521404
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import token
    root = Leaf(token.NAME, "abc")

    # LeafPattern(NAME)
    p = LeafPattern(type=token.NAME)
    assert p.match(root)
    assert p.match(root)
    assert not p.match(root, {p.name: root})

    # LeafPattern(NAME, "abc")
    p = LeafPattern(type=token.NAME, content="abc")
    assert p.match(root)
    assert p.match(root)
    assert not p.match(root, {p.name: root})

    # LeafPattern(NAME, "abc", "root")
    p = LeafPattern(type=token.NAME, content="abc", name="root")
    r = {}
    assert p.match(root, r)

# Generated at 2022-06-23 16:05:47.028157
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Node, Leaf
    from .pygram import python_symbols as syms
    parent = Node(syms.simple_stmt, [Leaf(1, 'a'), Leaf(1, 'b')])
    child = parent.children[1]
    child.replace([Leaf(1, 'c'), Leaf(1, 'd')])
    assert parent.children == [Leaf(1, 'a'), Leaf(1, 'c'), Leaf(1, 'd')]


# Generated at 2022-06-23 16:05:47.987907
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    assert NegatedPattern().match_seq([])



# Generated at 2022-06-23 16:05:51.559033
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
  print("Testing Base.get_suffix")
  # test that the get_suffix method can be used without raising an exception
  # (this will fail if get_suffix is not implemented correctly)


# Generated at 2022-06-23 16:05:55.547224
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    # Unit test for method __repr__ of class Leaf
    # Initialization
    # Function to be tested
    from .pgen2.pgen import Leaf

    l = Leaf(1, "test")
    # Check
    assert l.__repr__() == 'Leaf(1, \'test\')'



# Generated at 2022-06-23 16:06:06.446706
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    if __name__ == '__main__':
        print("\n===== testing method Base.get_suffix")
    import sys
    from lib2to3 import pgen2
    from lib2to3.pgen2 import tokenize, token
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2.tokenize import generate_tokens
    from lib2to3.pgen2.driver import Driver
    from lib2to3.pygram import python_grammar_no_print_statement
    from lib2to3.pytree import Leaf
    def get_tokens(t):
        tokens = []
        # Use a dummy source string to keep generate_tokens happy

# Generated at 2022-06-23 16:06:14.055711
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    p = (
        WildcardPattern(min=1, max=1),
        LeafPattern(type=token.DOT),
        WildcardPattern(min=0, max=HUGE),
    )
    n = (
        Node(syms.power, [Leaf(token.ID, "a"), Leaf(token.DOT)]),
        Node(syms.power, [Leaf(token.ID, "a"), Leaf(token.DOT)]),
        Node(syms.power, [Leaf(token.ID, "a"), Leaf(token.DOT)]),
    )
    #
    # Unit test for method generate_matches of class WildcardPattern
    #
    def check_gen(p, n, len_exp=1):
        len_act = 0

# Generated at 2022-06-23 16:06:22.866997
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.token import tok_name
    for x in ('=', '=spam', '=spam(eggs)', '=spam(eggs,bacon)'):
        n = Node(1, [Leaf(1, x)])
        p = LeafPattern(1, x)
        assert p.match(n)
        assert p.match_seq([n])
        assert p.match_seq(n.pre_order())
        p = LeafPattern(1)
        assert not p.match(n)
        assert p.match_seq([n])
        assert p.match_seq(n.pre_order())
    for x in range(256):
        if x not in tok_name:
            continue
        n = Leaf(x, tok_name[x])
        p = LeafPattern

# Generated at 2022-06-23 16:06:27.768184
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import ParseError
    from .pgen2 import driver
    from .parser import Parser
    from .syms import NAME, LPAR, NEWLINE, INDENT, DEDENT
    pgen = driver.Driver(Parser, "grammar")
    n = None
    assert [m for m in n.generate_matches([])] == []
    assert [m for m in n.generate_matches([n])] == []
    assert [m for m in n.generate_matches([n, n])] == []
    try:
        t = pgen("name = 'a'", "test")
    except ParseError:
        pass
    else:
        assert [m for m in t.generate_matches([])] == []

# Generated at 2022-06-23 16:06:28.903446
# Unit test for method set_child of class Node
def test_Node_set_child():
    assert True


# Generated at 2022-06-23 16:06:29.888659
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(257, 'test')
    assert list(leaf.leaves()) == [leaf]

# Generated at 2022-06-23 16:06:41.361262
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    from .pytree import Leaf
    from .pygram import python_grammar
    from . import parse
    grammar = python_grammar

    def test(s, expected):
        tree = parse.parse(s, python_grammar)
        leaves = list(tree.leaves())
        # Remove line number and column offset
        leaves = [Leaf(type=leaf.type, value=leaf.value,
                       context=None) for leaf in leaves]
        calculated = [leaf.get_suffix() for leaf in leaves]
        assert list(expected) == calculated

    test('x + y', ['', '+', '', '', '', '', ''])
    test('x(y)', ['', '', '', '', '', '', ''])

# Generated at 2022-06-23 16:06:42.304776
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1,"a")
    leaf.pre_order() # returns an iterator for leaf


# Generated at 2022-06-23 16:06:49.725650
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    import unittest
    from .pgen2.parse import ParseError
    from .pygram import python_symbols
    from .pytree import Leaf, Node, Base
    from .pyparse import ParseError
    class Test(unittest.TestCase):
        def test_Base___eq___0(self):
            self.assertRaises(TypeError, Base.__eq__, Node(1001), Node(1001))
        def test_Base___eq___1(self):
            self.assertRaises(TypeError, Base.__eq__, Leaf(1002, ""), Leaf(1002, ""))
        def test_Base___eq___2(self):
            self.assertRaises(TypeError, Base.__eq__, Node(1003), Leaf(1004, ""))
    return Test


NodeType

# Generated at 2022-06-23 16:06:54.739798
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    def check(type, content, name) -> None:
        l = LeafPattern(type, content, name)
        assert l.type == type, l.type
        assert l.content == content, l.content
        assert l.name == name, l.name

    check(1, "abc", "name")
    check(None, "abc", None)
    check(1, None, None)
    check(None, None, "name")
    check(None, None, None)
    check(255, None, None)
    check(256, None, None)

    try:
        LeafPattern(-1, None, None)
    except AssertionError:
        pass
    else:
        raise AssertionError("did not detect type too small")


# Generated at 2022-06-23 16:06:58.730016
# Unit test for method post_order of class Base
def test_Base_post_order():
    # type: () -> None
    from .pytree import Node
    from .pygram import python_grammar

    tree = Node(grammar=python_grammar, type=1)
    tree.append_child(Node(type=2))
    tree.append_child(Node(type=3))
    tree.children[0].append_child(Node(type=4))
    tree.children[0].append_child(Node(type=5))
    tree.children[0].children[0].append_child(Node(type=6))
    tree.children[0].children[1].append_child(Node(type=7))
    tree.children[0].children[1].append_child(Node(type=8))
    tree.children[1].append_child(Node(type=9))

# Generated at 2022-06-23 16:07:10.619687
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # First, try with an empty ast
    nodes = []
    p = NegatedPattern()
    # (1) Match an empty sequence
    assert(p.match_seq(nodes))
    # (2) Match the child of an ast with one child
    nodes = [ast.Test("foo")]
    assert(p.match_seq(nodes))
    # (3) Match the children of an ast with two children
    nodes = [ast.Test("foo"), ast.Test("bar")]
    assert(p.match_seq(nodes))
    # (4) Match the children of an ast with three children
    nodes = [ast.Test("foo"), ast.Test("bar"), ast.Test("baz")]
    assert(p.match_seq(nodes))
    # (5) Match the children of an ast with four children

# Generated at 2022-06-23 16:07:14.800509
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    assert Leaf(0, "").__repr__() == "Leaf(0, '')"
    assert Leaf(257, "").__repr__() == "Leaf(257, '')"
    assert Leaf(255, "").__repr__() == "Leaf(255, '')"

# Generated at 2022-06-23 16:07:18.314615
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    obj = Leaf(1, 'value')
    assert list(obj.pre_order()) == [obj]

# Generated at 2022-06-23 16:07:23.133709
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    assert Leaf(1, '2').__repr__() == "Leaf(1, '2')"
    assert Leaf(1, '2', fixers_applied=[]).__repr__() == "Leaf(1, '2')"


# Generated at 2022-06-23 16:07:32.007708
# Unit test for method post_order of class Node
def test_Node_post_order():
    node_1 = Node(1,[Node(2,[Node(3,[Node(5,[])]),Node(4,[])]),Node(6,[])])
    node_3 = Node(3,[Node(5,[])])
    node_5 = Node(5,[])
    node_4 = Node(4,[])
    node_2 = Node(2,[node_3,node_4])
    node_6 = Node(6,[])
    exp_node_list = [node_5,node_3,node_4,node_2,node_6,node_1]
    act_node_list = list(node_1.post_order())
    assert exp_node_list == act_node_list


# Generated at 2022-06-23 16:07:37.363312
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pytree import Leaf

    n = Node(1, [
        Leaf(1, "a"),
        Leaf(1, "b"),
        ])
    n.prefix = ' '
    n.pre_order()
test_Node_pre_order()


# Generated at 2022-06-23 16:07:41.242022
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(0,[Leaf(0,"",None)])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map == None
    assert node.next_sibling_map == None
    node.update_sibling_maps()
    assert node.prev_sibling_map != None
    assert node.next_sibling_map != None


# Generated at 2022-06-23 16:07:51.735424
# Unit test for method remove of class Base
def test_Base_remove():
    a = Base()
    b = Base()
    c = Base()
    a.children = [b, c]
    b.parent = a
    c.parent = a
    b.remove()
    assert c.parent is a
    assert c.prev_sibling is None
    assert c.next_sibling is None
    a.children = [b, c]
    b.parent = a
    c.parent = a
    c.remove()
    assert b.parent is a
    assert b.prev_sibling is None
    assert b.next_sibling is None
    a.children = [b, c]
    b.parent = a
    c.parent = a
    assert b.remove() == 0
    assert c.remove() == 1
    assert a.children == []


# Generated at 2022-06-23 16:07:57.584471
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    from .parser import ast
    from .parser import ParserError
    from . import parser


# Generated at 2022-06-23 16:08:08.964914
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree
    from .pygram import python_grammar
    from .pgen2 import driver
    from .token import tok_name

    def _post_order(node):
        return [x.type for x in node.post_order()]

    def _pre_order(node):
        return [x.type for x in node.pre_order()]

    def _clone(node):
        return node.clone()

    def _flatten(lst):
        return [item for sublist in lst for item in sublist]

    def _test_post_order(src, expected_post_order, expected_pre_order=None):
        got = driver.parse_string(src, python_grammar)
        assert _post_order(got) == expected_post_order, _post_order(got)

# Generated at 2022-06-23 16:08:14.622522
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    T = Leaf(0, '')
    assert str(T) == 'Leaf(0, \'\')'
    T = Leaf(0, 'a')
    assert str(T) == 'Leaf(0, \'a\')'
    T = Leaf(0, 'abc')
    assert str(T) == 'Leaf(0, \'abc\')'

# Generated at 2022-06-23 16:08:25.823868
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    from . import grammar

    def test(source):
        # Compile source into a pattern
        p = WildcardPattern(grammar.expr(source).content)
        # Check for basic consistency
        assert p.min <= p.max <= HUGE
        # Check that this compiles back into the same source
        # (The "pattern" rule has a few ambiguities, so we might not get
        # exactly the same source, but it should parse the same.  If we
        # ever need to test more precisely, we should fix the ambiguities.)
        assert source == str(p).replace(" ", "")

    test(".")
    test("..")
    test("(a|b)")
    test("(a|b)..")
    test("(a|b|c)..")
    test("(a|b|c)....")

# Generated at 2022-06-23 16:08:32.211022
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token
    assert token.IF == python_symbols.if_stmt
    if_ = Node(python_symbols.if_stmt, [Leaf(token.NAME, "a")])
    assert not if_.was_changed
    if_.changed()
    assert if_.was_changed
    assert not if_.children[0].was_changed

# Generated at 2022-06-23 16:08:40.338766
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    "Unit test for method insert_child of class Node"
    n = Node(0, [Leaf(0, "f"), Leaf(0, "o"), Leaf(0, "o"), Leaf(0, "b")])
    for i in range(1, 6):
        n.insert_child(i, Leaf(0, "a"))
        assert len(n.children) == i + 4
        assert "".join(map(str, n.children)) == "faabcabcabcabcabooob"
        assert n.next_sibling_map is not None
        assert n.prev_sibling_map is not None
        for ch in n.children:
            assert ch.parent is n

# Generated at 2022-06-23 16:08:45.739750
# Unit test for method clone of class Node

# Generated at 2022-06-23 16:08:51.466445
# Unit test for method leaves of class Base
def test_Base_leaves():
    class Foo(object):
        pass
    foo = Foo()
    foo.bar = 42
    foo_ref = foo
    foo = None

    class Root(Base):
        def post_order(self):
            yield self

    root = Root()
    root.changed = lambda: 42

    class Node(Base):
        def __init__(self):
            self.children = []

        def post_order(self):
            parent = self.parent
            if parent is None:
                parent = Root()
            yield from parent.post_order()
            yield self

        def _eq(self, other):
            return True

        def clone(self):
            clone = Node()
            return clone

    root.children = [root]
    assert list(root.leaves()) == [root]


# Generated at 2022-06-23 16:09:00.002957
# Unit test for method replace of class Base
def test_Base_replace():
    import lib2to3
    grammar = lib2to3.pgen2.parse.load_grammar(lib2to3.pgen2.Grammar)
    root_node = lib2to3.pgen2.parse.parse_string(grammar, "1 + 2")
    root_node.replace([Leaf(grammar.number, "3"), Leaf(grammar.number, "4")])
    assert root_node.children[1].value == "3"
    assert root_node.children[2].value == "4"

test_Base_replace()



# Generated at 2022-06-23 16:09:10.156572
# Unit test for method clone of class Base
def test_Base_clone():
    import blib2to3.pytree

    grammar = blib2to3.pgen2.grammar.Grammar()
    grammar.load_grammar("Grammar.txt")
    parser = blib2to3.pgen2.pgen.ParserGenerator(grammar, [])
    parser.parse("'abc'")
    tree = parser.result.root
    assert tree is not None and isinstance(tree, blib2to3.pytree.Node)
    cloned_tree = tree.clone()
    assert tree == cloned_tree
    assert tree is not cloned_tree
    assert tree.children[0] is not cloned_tree.children[0]



# Generated at 2022-06-23 16:09:19.423428
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern(min=2, max=2).optimize() == WildcardPattern(min=2, max=2)
    assert WildcardPattern(min=0, max=1).optimize() == WildcardPattern(min=0, max=1)
    assert WildcardPattern(min=0, max=2).optimize() == WildcardPattern(min=0, max=2)
    assert WildcardPattern(min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern([[NodePattern()]], min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern([[NodePattern()]], min=2, max=2).optimize() == WildcardPattern(
        [[NodePattern()]], min=2, max=2
    )

# Generated at 2022-06-23 16:09:28.128681
# Unit test for function convert
def test_convert():
    gr = load_grammar()
    from pgen2.driver import Driver

    parser = Driver(gr, convert)
    parser.parse_tokens([("NUMBER", "3", (1,0,1,1))])

    assert len(parser.result) == 1
    assert isinstance(parser.result[0], Leaf)
    assert parser.result[0].value == "3"
    assert parser.result[0].prefix == ""
    assert parser.result[0].type == NUMBER
    assert parser.result[0].lineno == 1
    assert parser.result[0].column == 0




# Generated at 2022-06-23 16:09:38.391507
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Given a String pointing to a Python program
    string = "1 + (2 + 3 * 4)"
    # Given a valid Grammar
    grammar = Grammar(r"""
        expr ::= term (('+' | '-') term)*
        term ::= factor (('*' | '/') factor)*
        factor ::= ('+' | '-')? atom
        atom ::= NAME | NUMBER | '(' expr ')'
    """)
    # When we parse the String using the Grammar into a tree
    tree = grammar.parse(string)
    # Then tree.post_order() should be equal to [(NUMBER, 1), (NAME, +), (NUMBER, 2), (NAME, +), (NUMBER, 3), (NAME, *), (NUMBER, 4), (NAME, )]
    t = []

# Generated at 2022-06-23 16:09:48.607907
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pattern = NegatedPattern()
    # All methods should match an empty sequence.
    for method in [pattern.generate_matches, pattern.match_seq, pattern.match]:
        results = list(method([], {}))
        assert len(results) == 1
        assert results[0][0] == 0

    pattern = NegatedPattern(pattern)
    assert list(pattern.generate_matches([]))
    assert not list(pattern.generate_matches([1]))

    if True:
        pattern = NegatedPattern(NodePattern())
        assert not list(pattern.generate_matches([]))
        assert not list(pattern.generate_matches(["a"]))

    if True:
        pattern = NegatedPattern(NodePattern(type=token.NAME))

# Generated at 2022-06-23 16:09:52.334795
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    """
    Test constructor of BasePattern

    This constructor prevents BasePattern from being instantiated
    directly.
    """
    try:
        assert BasePattern() is None
    except AssertionError:
        pass
    else:
        raise AssertionError("Testcase failed")

# Generated at 2022-06-23 16:10:00.362580
# Unit test for method post_order of class Base
def test_Base_post_order():
    s = u"a = 1 + 2"
    n = Node(python_symbols.simple_stmt, [Leaf(token.NAME, u"a"),
                                          Leaf(token.EQUAL, u"="),
                                          Node(python_symbols.testlist,
                                               [Leaf(token.NUMBER, u"1"),
                                                Leaf(token.PLUS, u"+"),
                                                Leaf(token.NUMBER, u"2")])])
    for node in n.post_order():
        if isinstance(node, Node):
            node.prefix = u" "
        else:
            node.prefix = u""
    assert s == n.get_suffix(), s
    assert s == n.next_sibling.prefix, s



# Generated at 2022-06-23 16:10:03.257694
# Unit test for function type_repr
def test_type_repr():
    # We'll just call it and see if it throws an exception.
    type_repr(0)

# -- Support classes ---------------------------------------------------



# Generated at 2022-06-23 16:10:05.521079
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    x = NegatedPattern()
    assert x.match_seq([])



# Generated at 2022-06-23 16:10:08.574570
# Unit test for method append_child of class Node
def test_Node_append_child():
    n = Node(1, [])
    n.append_child(Leaf(type=1, value=None))
    assert n is not None

# Generated at 2022-06-23 16:10:12.657642
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    import unittest
    class TestNode___repr__(unittest.TestCase):
        def test_1(self):
            n = Node(1, [])
            self.assertEqual(repr(n), "Node(1, [])")
    unittest.main()


# Generated at 2022-06-23 16:10:19.731902
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    w = WildcardPattern([[Leaf(1)]]).optimize()
    assert isinstance(w, NodePattern)

    w = (WildcardPattern([[Leaf(1)], [Leaf(2)]], min=1).optimize())
    assert isinstance(w, WildcardPattern)

    w = WildcardPattern([[Leaf(1)], [Leaf(2)]]).optimize()
    assert isinstance(w, WildcardPattern)

    w = WildcardPattern([[[Leaf(1)]], [[Leaf(2)]]]).optimize()
    assert isinstance(w, WildcardPattern)

    w = WildcardPattern([NodePattern(), NodePattern()]).optimize()
    assert isinstance(w, WildcardPattern)


# Generated at 2022-06-23 16:10:29.386025
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    wp = WildcardPattern(max=1)
    assert wp.optimize() is wp

    wp = WildcardPattern(None, min=1, max=1)
    assert wp.optimize() is not wp
    np = wp.optimize()
    assert np.type is None
    assert np.content is None
    assert np.name is None

    wp = WildcardPattern(None, min=1, max=1, name="FOO")
    assert wp.optimize() is not wp
    np = wp.optimize()
    assert np.type is None
    assert np.content is None
    assert np.name == "FOO"

    wp = WildcardPattern(None, min=0, max=1)
    assert wp.optimize() is wp

    wp

# Generated at 2022-06-23 16:10:36.919831
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    s = """\
        b = c + d
        """
    gr = parse_grammar(s)
    pattern = gr.patterns["test"][0]
    node = gr.number2symbol.get(pattern.type)
    ast = parse_string(s, gr, {}, debug=True)
    assert pattern.match(ast) is False
    assert pattern.match(ast.children[0])



# Generated at 2022-06-23 16:10:45.663047
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.token import tok_name
    assert Leaf(0, "a").__repr__() == 'Leaf(ENDMARKER, \'a\')'
    assert Leaf(257, "a").__repr__() == 'Leaf(NAME, \'a\')'
    assert Leaf(42, "a").__repr__() == 'Leaf(42, \'a\')'
    tok_name[42] = 'Foo'
    assert Leaf(42, "a").__repr__() == 'Leaf(Foo, \'a\')'
    tok_name[42] = 'Foo\nbar'
    assert Leaf(42, "a").__repr__() == 'Leaf(Foo\nbar, \'a\')'

# Generated at 2022-06-23 16:10:49.053788
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    pattern = WildcardPattern(None)
    assert pattern.match(Leaf(1, "one"))
    assert not pattern.match(Node(3, [Leaf(1, "one")]))

# Generated at 2022-06-23 16:10:53.901825
# Unit test for method clone of class Base
def test_Base_clone():
    import pytree

    def check(s1):
        t1 = pytree.build_tree_from_string(s1)
        t2 = t1.clone()
        assert t1 != t2
        assert str(t1) == str(t2)

    check("1 + (2 + 3)")



# Generated at 2022-06-23 16:10:55.295367
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Just to suppress pyflakes
    Base()


# Generated at 2022-06-23 16:10:57.408500
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    leaf = Leaf(1,"1")
    assert leaf.__str__() == "1"


# Generated at 2022-06-23 16:11:00.624436
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    # With no argument, the function
    # should do nothing, just return None.
    assert Node.invalidate_sibling_maps() is None



# Generated at 2022-06-23 16:11:08.752067
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    assert True
    return None

    # Workaround for mypy bug #731: https://github.com/python/mypy/issues/731
    from typing import IO
    import sys

    class FakeStdout:
        def write(self, msg):  # type: ignore
            pass

    class NullDevice:
        def write(self, s):  # type: ignore
            pass

        def flush(self):  # type: ignore
            pass

    saved_stdout = sys.stdout
    sys.stdout = NullDevice()  # type: ignore
    try:
        test_Base_get_suffix()
    finally:
        sys.stdout = saved_stdout  # type: ignore



# Generated at 2022-06-23 16:11:14.288767
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import pytest
    bp = BasePattern()
    with pytest.raises(AttributeError):
        bp.match(None, None)
    with pytest.raises(AttributeError):
        bp.match_seq(None, None)
    with pytest.raises(AttributeError):
        bp.generate_matches(None)



# Generated at 2022-06-23 16:11:22.170655
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from . import pygram
    from . import pytree
    from .pgen2 import driver
    from .pgen2 import tokenize

    def pygram_and_pytree():
        pygram.python_grammar.initialize()
        pygram.python_grammar_no_print_statement.initialize()
        pygram.python_grammar_no_conditional_statements.initialize()
        pygram.python_grammar_no_while_statements.initialize()
        pygram.python_grammar_no_with_statement.initialize()
        pygram.python_grammar_no_future.initialize()
        pygram.python_grammar_no_except_clause.initialize()
        pygram.python_grammar_no_raise_statement.initialize()
        pygram.python_gram

# Generated at 2022-06-23 16:11:31.397997
# Unit test for constructor of class Leaf
def test_Leaf():
    from .pgen2.token import tok_name

    #Test constructor and getters: __init__, get_type, get_value, get_prefix
    le = Leaf(1, 2, context=("prefix", (0, 0)), fixers_applied=["fixer1", "fixer2"])
    assert le.type == 1
    assert le.value == 2
    assert le.prefix == "prefix"
    assert le.fixers_applied == ["fixer1", "fixer2"]
    assert le.lineno == 0
    assert le.column == 0

    assert repr(le) == "Leaf(" + repr(tok_name[1]) + ", " + repr(2) + ")"

    #Test setters: set_type, set_value, set_prefix
    le.type = 3

# Generated at 2022-06-23 16:11:38.574411
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    w = WildcardPattern([[Identifier("a")], [Identifier("b")]], 0, 2, "name")
    n1 = Node(1, [Leaf(2, "a")])
    n2 = Node(1, [Leaf(2, "b")])
    n3 = Node(1, [Leaf(2, "a"), Leaf(2, "a")])
    n4 = Node(1, [Leaf(2, "b"), Leaf(2, "a")])
    n5 = Node(1, [Leaf(2, "a"), Leaf(2, "b")])
    n6 = Node(1, [Leaf(2, "b"), Leaf(2, "a"), Leaf(2, "a")])

# Generated at 2022-06-23 16:11:50.621559
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    np1 = NegatedPattern()
    np2 = NegatedPattern(np1)

    # check if match matches the empty sequence
    if not np1.match_seq([]):
        print("np1 incorrect, did not match empty sequence")
    else:
        print("np1 matches empty sequence")

    # check if match does not match any sequence
    if np1.match_seq([""]):
        print("np1 incorrect, matched a non-empty sequence")
    else:
        print("np1 does not match non-empty sequence")

    # check if match does not match any sequence
    if np2.match_seq([""]):
        print("np2 incorrect, matched a non-empty sequence")
    else:
        print("np2 does not match non-empty sequence")

    # check if match matches the empty sequence

# Generated at 2022-06-23 16:11:59.245557
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    import ast
    tn = ast.parse('''def f(a, b):\n    c = a + b\n    # comment\nif True:\n    pass''', mode='exec')
    tn.update_sibling_maps()
    assert tn.children[0].prev_sibling==None
    assert tn.children[0].next_sibling==tn.children[1]
    assert tn.children[1].prev_sibling==tn.children[0]
    assert tn.children[1].next_sibling==tn.children[1].children[0].next_sibling
    assert tn.children[1].children[0].prev_sibling==tn.children[1]