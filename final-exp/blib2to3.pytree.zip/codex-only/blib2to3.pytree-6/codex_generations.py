

# Generated at 2022-06-23 16:02:00.607403
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf
    from .pygram import python_symbols as symbols
    l = Leaf(symbols.number, '1')
    l2 = Leaf(symbols.number, '2')
    l.replace(l2)
    assert l.parent is None and l.next_sibling is None
    assert l2.parent is None and l2.next_sibling is None
    l = Leaf(symbols.number, '1')
    lp = Leaf(symbols.number, '3')
    l2 = Leaf(symbols.number, '2')
    l3 = Leaf(symbols.number, '4')
    n = Node(symbols.power, [l, lp])
    n.replace([l2, l3])

# Generated at 2022-06-23 16:02:10.403092
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Testcases
    # This testcase is wrong, a negated Pattern shouldn't match an empty string
    #assert not NegatedPattern(content=None).match_seq([])
    assert not NegatedPattern(content=None).match_seq([Symbol(u"a")])
    assert not NegatedPattern(content=NodePattern(type=257)).match_seq([Symbol(u"a")])
    assert NegatedPattern(content=NodePattern(type=257)).match_seq([])
    assert NodePattern(type=257).match_seq([Symbol(u"a")])
    assert not NodePattern(type=257).match_seq([])
    assert NegatedPattern(content=NodePattern(type=257)).match_seq([Symbol(u"a")])
    assert not NegatedPattern(content=NodePattern(type=257)).match

# Generated at 2022-06-23 16:02:17.469827
# Unit test for method match_seq of class WildcardPattern

# Generated at 2022-06-23 16:02:26.058766
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    a = Leaf(0, "test")
    b = Leaf(0, "test")
    c = Node(1, [a,b])
    d = Leaf(0, "test")
    e = Node(1, [d,c])
    e.update_sibling_maps()
    assert e.prev_sibling_map[id(c)] == d
    assert e.next_sibling_map[id(d)] == c
    assert e.prev_sibling_map[id(b)] == a
    assert e.next_sibling_map[id(a)] == b
    assert e.next_sibling_map[id(b)] == None
    assert e.prev_sibling_map[id(d)] == None


# Generated at 2022-06-23 16:02:36.597899
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    # This function tests the Base.__eq__ method.

    def _eq(n1, n2, expect):
        n1c = n1.clone()
        n2c = n2.clone()
        if not expect:
            # Try == and !=
            assert n1c == n1c
            assert n1c != n2c
        if expect:
            # Try == and !=
            assert n1c == n2c
            assert n1c != n1c
        if expect:
            # Try hash
            d = {n1c: 1}
            d[n2c] = 2
            # Try __cmp__
            assert not (n1c < n2c)
            assert not (n1c > n2c)

    from .pytree import Node, Leaf, dump


# Generated at 2022-06-23 16:02:37.460389
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Generates a representation string for this pattern."""
    pass



# Generated at 2022-06-23 16:02:45.866754
# Unit test for method remove of class Base
def test_Base_remove():
    import io
    import sys
    import unittest


    class BaseTest(unittest.TestCase):
        def test_remove(self):
            import blib2to3.pgen2.pgen as pgen
            from blib2to3.pgen2.tokenize import tokenize, untokenize
            from blib2to3.pgen2 import driver

            s = """\
                # a = 1
                a == 'foo'
            """
            driver.load_grammar("Grammar.txt")
            parser = driver.Parser("file_input")
            g = parser.parse(s)
            number = tokenize(io.StringIO(s).readline)[0][0]
            e1 = g.children[0].children[1]

# Generated at 2022-06-23 16:02:49.098016
# Unit test for method depth of class Base
def test_Base_depth():
    import unittest
    unittest.TestCase().assertEqual(
        Base().depth(),
        0,
        "Wrong default value for depth"
    )

# Generated at 2022-06-23 16:02:57.595384
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import sys
    import astroid
    from astroid import builder
    from astroid import nodes
    from astroid import parse
    from pprint import pprint
    from blib2to3.pygram import python_grammar
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pygram import python_symbols
    from typing import List, Union
    from .leaf import Mark, Leaf
    from .node import Node  # NOQA
    from .tree import Base  # NOQA
    print('Test that class Base has the method get_suffix')
    leaf = Leaf(0,1,1, 'a')
    a_other = Base()
    leaf.next_sibling = a_other
    a_other

# Generated at 2022-06-23 16:03:02.855540
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from .tree import Nonterminal, Terminal, Node
    from .lexer import Lexer

    pattern = WildcardPattern(
        name = "bare_name",
        content = [
            [NodePattern(type=Token.NAME)],
            [NodePattern(type=Token.NAME), WildcardPattern(
                name = "optional_slice",
                content = [[NodePattern(type=Token.SLICE)]]
            )]
        ]
    )

    lex = Lexer([
        ('NAME', '[a-zA-Z_]\w*'),
        ('OP', '\+|-|\*|//|/|%|<<|>>|&|\||\^|~'),
        ('SLICE', '\[([^\[\]=]+|\[[^\[\]=]*\])*\]'),
    ])



# Generated at 2022-06-23 16:03:03.484498
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()



# Generated at 2022-06-23 16:03:12.958819
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    from .pgen2 import tokenize
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.parse import parse_grammar

    grammar = parse_grammar(GRAMMAR)

    driver = Driver(grammar, convert)
    file = "foo.py"
    text = "a+b"
    result = driver.parse_tokens(tokenize.generate_tokens(iter(text).__next__, file), file)

    assert result.type == 367
    assert len(result.children) == 3
    assert result.children[0].type == 1
    assert result.children[1].type == 43
    assert result.children[2].type == 1

    _t = BasePattern()
    _t.type = 367
    _t_

# Generated at 2022-06-23 16:03:15.239382
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    t = Leaf(1, "test")
    assert list(t.leaves()) == [t]

# Generated at 2022-06-23 16:03:23.269430
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Leaf, Node
    from . import pygram
    from io import StringIO
    grammar = pygram.python_grammar_no_print_statement
    pytree = grammar.parse("x = 'foo'")
    pytree.pretty_print(buf=StringIO())
    l = [x.value for x in pytree.pre_order()]

# Generated at 2022-06-23 16:03:25.941693
# Unit test for method changed of class Base
def test_Base_changed():
    import doctest
    doctest.run_docstring_examples(Base.changed, globals(), verbose=True)



# Generated at 2022-06-23 16:03:28.269499
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert LeafPattern()
    assert LeafPattern(45)
    assert LeafPattern(45, "hello")
    assert LeafPattern(45, name="hello")



# Generated at 2022-06-23 16:03:30.749734
# Unit test for method __new__ of class Base
def test_Base___new__():
    r1 = Base()
    print(bool(r1))
    assert False # TODO: implement your test here


# Generated at 2022-06-23 16:03:33.908523
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    l = Leaf(2, '')
    assert repr(l) == "Leaf(2, '')"  # Pass
    l = Leaf(1, 'abc')
    assert repr(l) == "Leaf(1, 'abc')"  # Pass


# Generated at 2022-06-23 16:03:35.099145
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    with pytest.raises(AssertionError):
        BasePattern()
    assert BasePattern is not BasePattern()

# Generated at 2022-06-23 16:03:35.692262
# Unit test for constructor of class BasePattern
def test_BasePattern():
    BasePattern(1)



# Generated at 2022-06-23 16:03:37.290500
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    return NotImplemented

# Generated at 2022-06-23 16:03:42.415034
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(57, 'test', prefix=' ', lineno=10, column=20)
    assert l.type == 57
    assert l.value == 'test'
    assert l.prefix == ' '
    assert l.lineno == 10
    assert l.column == 20


# Generated at 2022-06-23 16:03:51.462741
# Unit test for method __str__ of class Node

# Generated at 2022-06-23 16:04:02.704947
# Unit test for function type_repr
def test_type_repr():
    assert "NAME" == type_repr(1)
    assert "comment" == type_repr(int("#", 35))
    assert "undefined" == type_repr(9999)


# The grammar file used to create this parser is Grammar/Grammar with the
# following modifications:
#
# The file is encoded in UTF-8.
#
# Long strings are made into raw strings (much easier in Python 3 than in 2).
#
# The encoding declaration is changed from iso-8859-1 to UTF-8.
#
# The following modifications are made to the grammar itself:
#
# A number of productions are defined that are used for error recovery.
# These are "error_whatever" and appear at the ends of error-recovery
# alternatives in the grammar (e.g. after "except" and "finally" clauses).

# Generated at 2022-06-23 16:04:04.837883
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    x = Leaf(1, 'a', prefix="  ")
    assert list(x.leaves()) == [x]


# Generated at 2022-06-23 16:04:07.790039
# Unit test for constructor of class Node
def test_Node():
    t = Node(syms.funcdef, [])
    assert t.type == syms.funcdef, "Node.__init__ failed"
    assert t.children == [], "Node.__init__ failed"



# Generated at 2022-06-23 16:04:08.649987
# Unit test for constructor of class BasePattern
def test_BasePattern():
    with pytest.raises(TypeError):
        BasePattern()



# Generated at 2022-06-23 16:04:16.540694
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from astroid import builder, nodes

    builder = builder.ASTNGBuilder()
    body = builder.string_build(
        """if a:
        f(True, 3)
    """
    )
    if_node = body[0]
    p0 = IfPattern(content=[NodePattern(type=nodes.Name), WildcardPattern()], min=1)
    p1 = IfPattern(content=[NodePattern(type=nodes.Name), NodePattern()], min=1)
    assert p0.match(if_node)
    assert not p1.match(if_node)


# TODO(cpopa): add the same test for match_seq

#
# Main classes
#


# Generated at 2022-06-23 16:04:23.069370
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    with open("/Users/nolaurenhenderson/Desktop/workspace/blib2to3/Lib/typing.pyi", "r") as f:
        t = tree.parse(f.read())
    g = t.pre_order()
    type(g)
    x = list(g)
    assert (len(x) == 158)


# Generated at 2022-06-23 16:04:30.768766
# Unit test for method replace of class Base
def test_Base_replace():
    # Unit test for method replace of class Base
    root = Node(0, None)  # Dummy root node
    node = Node(0, None, None, [Leaf(1, 'foo'), Leaf(1, 'bar')])
    leaf = Leaf(1, 'baz')
    node.parent = root
    root.children = [node]
    # Replace with a leaf
    node.replace(leaf)
    assert root.children == [leaf]
    assert leaf.parent is root
    # Replace with a node
    node = Leaf(0, None)
    root.children = [node]
    new_node = Node(0, None, None, [Leaf(1, 'a'), Leaf(1, 'b')])
    node.replace(new_node)
    assert root.children == [new_node]
    assert new

# Generated at 2022-06-23 16:04:37.496708
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pattern = WildcardPattern([[Leaf(11, 'a'), Leaf(12, 'b')], [Leaf(13, 'c')]])
    assert pattern.match_seq([Leaf(11, 'a'), Leaf(12, 'b'), Leaf(13, 'c')])
    assert pattern.match_seq([Leaf(11, 'a'), Leaf(12, 'b'), Leaf(13, 'c'), Leaf(14, 'd')])
    assert not pattern.match_seq([Leaf(13, 'c'), Leaf(12, 'b')])
    assert not pattern.match_seq([Leaf(11, 'a'), Leaf(13, 'c'), Leaf(12, 'b')])
    assert not pattern.match_seq([Leaf(11, 'a')])



# Generated at 2022-06-23 16:04:41.930968
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2 import tokenize

    text = "def foo(a, b, c=42, *, d=None, **kwargs):\n    pass"
    for type, token, begin, end, line in tokenize.generate_tokens(StringIO(text).readline):
        if type != tokenize.COMMENT:
            print(f"({type}, {token!r:<30}, ({begin[0]}, {begin[1]}), ({end[0]}, {end[1]}), {line!r})")

# Generated at 2022-06-23 16:04:49.894045
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    from .pygram import python_symbols

    def gen_node(*children) -> Node:
        raise NotImplementedError("Use Node(python_symbols.funcdef,children)")

    def gen_leaf(value, type=None) -> Leaf:
        raise NotImplementedError("Use Leaf(value,type)")

    # this is a simple method body
    a = gen_leaf("f")
    b = gen_leaf("(")
    c = gen_leaf(")")
    d = gen_leaf(":")
    e = gen_leaf("pass")
    f = Leaf("# yadda", python_symbols.comment)
    g = gen_leaf("\n")
    h = gen_leaf("  ")
    i = gen_leaf("pass")


# Generated at 2022-06-23 16:04:52.578699
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    import ast
    import StringIO
    import sys
    #s = StringIO.StringIO("print(2 + 3)")
    s = StringIO.StringIO("""
print(2 + 3)
print(2 + 3)
""")
    mm = ast.parse(s.readline())
    print(mm)

if __name__ == '__main__':
    test_Node___repr__()


# Generated at 2022-06-23 16:05:00.638442
# Unit test for method clone of class Base
def test_Base_clone():
    class X(Base):
        def _eq(self, other):
            return (self.__class__ is other.__class__ and
                    self.children == other.children)

        def post_order(self):
            yield self
            for child in self.children:
                yield from child.post_order()

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def clone(self):
            return X(self.children)

    for constructor in (X, Leaf):
        n = constructor()
        n.children = [constructor() for i in range(5)]
        n2 = n.clone()
        assert n is not n2
        assert n._eq(n2)

# Generated at 2022-06-23 16:05:07.846993
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    for content in [
        None,
        LeafPattern(type=1),
        NodePattern(type=1),
        LeafPattern(type=1, content="A"),
        NodePattern(type=1, content=[LeafPattern(type=1, content="A")]),
        WildcardPattern(content=[LeafPattern(type=1, content="A")]),
        WildcardPattern(content=[[LeafPattern(type=1, content="A")]]),
    ]:
        assert NegatedPattern(content).content == content



# Generated at 2022-06-23 16:05:15.654622
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    # Test inputs
    _Node_pre_order_input0 = Node(5,())
    _Node_pre_order_input1 = Node(5,(Leaf(1,u'foo'), Leaf(1,u'bar')))
    _Node_pre_order_input2 = Node(5,(Leaf(1,u'foo'), Node(5,(Leaf(1,u'bar'),)), Leaf(1,u'baz')))
    _Node_pre_order_input3 = Node(5,(Node(5,(Leaf(1,u'foo'),)), Leaf(1,u'bar')))
    _Node_pre_order_input4 = Node(5,(Node(5,(Leaf(1,u'foo'),)), Node(5,(Leaf(1,u'bar'),)),))
    _

# Generated at 2022-06-23 16:05:22.206204
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    """Unit test for method match_seq of class WildcardPattern"""
    p = WildcardPattern(content=((NodePattern(type=token.NAME),),))

    def test(s, expected):
        nodes = parser.parse(s)
        assert p.match_seq(nodes) == expected, s

    test("a", True)
    test("a b", False)
    test("a b c", False)
    test("a (b c)", False)



# Generated at 2022-06-23 16:05:30.796681
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    from .pgen2 import token

    # Default arguments
    p = LeafPattern()
    assert p.type is None
    assert p.content is None
    assert p.name is None

    # Some keyword arguments
    p = LeafPattern(token.NAME, "foo", "NAME")
    assert p.type == token.NAME
    assert p.content == "foo"
    assert p.name == "NAME"

    p = LeafPattern(type=token.NAME, content="foo")
    assert p.type == token.NAME
    assert p.content == "foo"
    assert p.name is None

    # Default for content is None
    p = LeafPattern(token.NAME, "foo")
    assert p.type == token.NAME
    assert p.content == "foo"
    assert p.name is None



# Generated at 2022-06-23 16:05:32.046424
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert Leaf(1, "test").leaves() == [Leaf(1, "test")]

# Generated at 2022-06-23 16:05:37.936631
# Unit test for method set_child of class Node
def test_Node_set_child():
    from . import pytree

    node = pytree.Node(1, [
        pytree.Leaf(2, '#'),
        pytree.Leaf(3, 'e'),
        pytree.Leaf(4, 'xample')
    ])

    node.set_child(1, pytree.Leaf(2, '-'))
    assert str(node) == '#-xample'

# Generated at 2022-06-23 16:05:47.349065
# Unit test for method remove of class Base
def test_Base_remove():
    stream = Stream("""
    hello world
    {
        i = 2
    }""")
    tokenizer = tree_compile(stream)
    assert isinstance(tokenizer, Tokenizer)
    print(tokenizer)
    node = tokenizer.parse()
    print(node)
    node_list = []
    for n in node.pre_order():
        node_list.append(n)

    assert node_list[0] == node
    node_list[0].remove()

    for n in node.post_order():
        node_list.append(n)
    print(node_list[0])
    assert node_list[0] != node



# Generated at 2022-06-23 16:05:48.291085
# Unit test for method __new__ of class Base
def test_Base___new__():
    pass



# Generated at 2022-06-23 16:05:52.926934
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    for i in range(100):
        leaf = Leaf(1, '1')
        for i in leaf.leaves():
            for j in leaf.leaves():
                if i is not j:
                    raise ValueError(
                        'Non-identical elements: {} {}'.format(i, j))

# Generated at 2022-06-23 16:06:04.669458
# Unit test for constructor of class NodePattern
def test_NodePattern():
    exceptions = ExceptionPattern("exceptions")
    context = ExceptionHandlerPattern("context", exceptions, "name")
    pattern0 = NodePattern("try_stmt", [], "try")
    pattern1 = NodePattern("try_stmt", [context], "try")
    pattern2 = NodePattern("try_stmt", [context, context], "try")
    pattern3 = NodePattern("try_stmt", [context, context, context], "try")
    pattern4 = NodePattern("try_stmt", [context, context, context, context], "try")
    pattern5 = NodePattern("try_stmt", [context, context, context, context, context], "try")
    pattern6 = NodePattern("try_stmt", [context, context, context, context, context, context], "try")

# Generated at 2022-06-23 16:06:07.311121
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    with pytest.raises(NotImplementedError):
        BasePattern().optimize()



# Generated at 2022-06-23 16:06:18.496626
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    p = NegatedPattern()
    assert p.content is None
    assert len(tuple(p.generate_matches([]))) == 1
    assert not tuple(p.generate_matches([1]))
    p = NegatedPattern(ContentPattern(1))
    assert len(tuple(p.generate_matches([2]))) == 1
    assert not tuple(p.generate_matches([1]))
    p = NegatedPattern(WildcardPattern(None, min=2))
    assert not tuple(p.generate_matches([]))
    assert not tuple(p.generate_matches([1]))
    assert len(tuple(p.generate_matches([1, 2]))) == 1
    assert not tuple(p.generate_matches([1, 2, 3]))


# Generated at 2022-06-23 16:06:28.239427
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    #! /usr/bin/env python
    # file: test/test_LeafPattern_match.py
    # unit test for method match() of class LeafPattern
    #
    # Before you start, make sure you can `import lib2to3.pgen2.parse`
    #
    # This is free software, see the source for copying conditions.
    # There is NO warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    from lib2to3 import pgen2
    import unittest

    class LeafPatternTest(unittest.TestCase):
        def setUp(self):
            self.p = pgen2.parse.LeafPattern(42, 'fake')

        def test_matches(self):
            n = pgen2.parse.Leaf(42, 'fake')

# Generated at 2022-06-23 16:06:32.655526
# Unit test for constructor of class Base
def test_Base():
    """
    Ensure Base cannot be instantiated.

    This is a catch-all unit test for class Base.
    """
    assert not issubclass(Base, Node)
    assert not issubclass(Base, Leaf)

    try:
        Base()
        assert False, "expected error"
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:06:38.539521
# Unit test for method set_child of class Node
def test_Node_set_child():
    grammar_file = sys.argv[1]
    input_file = sys.argv[2]
    with open(input_file) as f:
        input_string = f.read()
    grammar = Grammar(grammar_file, optimize=0)
    root = grammar.parse(input_string)
    # To fix the bug "AttributeError: 'NoneType' object has no attribute 'changed'"
    assert root.changed() == None



# Generated at 2022-06-23 16:06:39.271623
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    assert Leaf(1, "val").pre_order()


# Generated at 2022-06-23 16:06:43.662689
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import unittest

    class TestPattern(BasePattern):
        type = None
        content = None
        name = None
        def _submatch(self, node, results=None):
            return True

    class TestPattern2(TestPattern):
        type = None
        content = 1
        name = None

    class TestPattern3(TestPattern):
        type = 1
        content = None
        name = None

    class TestPattern4(TestPattern):
        type = 1
        content = 1
        name = None

    class TestPattern5(TestPattern):
        type = None
        content = 1
        name = 'a'

    class TestPattern6(TestPattern):
        type = 1
        content = 1
        name = 'a'

    node = Leaf(1, "a")
    pattern = TestPattern()
    assert pattern

# Generated at 2022-06-23 16:06:50.411093
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Node
    from .pygram import python_grammar
    from .pgen2 import token
    from . import py3_ast
    py3_ast.fix_missing_locations(Node(python_grammar.syms.file_input, [Node(1, [Leaf(token.INDENT, '  '), Node(2, [Node(3, [Leaf(4, 'x'), Leaf(5, ' '), Leaf(6, '='), Leaf(7, ' '), Leaf(8, '0'), Leaf(9, '\n')])]), Leaf(token.DEDENT, '')]), Leaf(10, '\n')]))

# Generated at 2022-06-23 16:06:54.802493
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    tree = Leaf(1, "foo", (" ", (1, 1)))
    assert list(tree.pre_order()) == [tree]

# Unit-test for method post_order of class Leaf

# Generated at 2022-06-23 16:07:03.665416
# Unit test for method replace of class Base
def test_Base_replace():
    l1 = Leaf(1, 1, (1, 1))
    l2 = Leaf(1, 1, (1, 1))
    l3 = Leaf(1, 1, (1, 1))

    l2.replace(l3)

    n = Node(1, None, (1, 1), [l1])
    n.children.append(l2)
    n2 = Node(2, None, (1, 1))
    n3 = Node(3, None, (1, 1))

    n.replace(n3)
    assert n3.parent == n.parent
    assert n3.parent is None

    n.replace([n2, n3])
    assert n2.parent == n.parent
    assert n3.parent == n.parent
    assert n2.parent is None



# Generated at 2022-06-23 16:07:05.543454
# Unit test for method __new__ of class Base
def test_Base___new__():
    obj = Base()
    assert isinstance(obj, object)



# Generated at 2022-06-23 16:07:10.286970
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from . import pgen2

    gram = pgen2.driver.load_grammar("Python.asdl")
    pattern = LeafPattern(type=gram.number2symbol["import_name"], content="import")
    assert pattern.match(Leaf(type=gram.number2symbol["import_name"], value="import"))


# Generated at 2022-06-23 16:07:13.259397
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    assert Leaf(
        type=1,
        value='a',
        context=(None, (0, 0)),
        prefix='',
        fixers_applied=[]
    ).__str__() == 'a'


# Generated at 2022-06-23 16:07:17.726915
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import parsers.python.ast as ast
    inner_node1 = ast.Node(python_symbols.expr_stmt, [])
    inner_node2 = ast.Node(python_symbols.expr_stmt, [])
    node = ast.Node(python_symbols.simple_stmt, [inner_node1, inner_node2])
    assert list(map(id, node.pre_order())) == [id(node), id(inner_node1), id(inner_node2)]

# Generated at 2022-06-23 16:07:26.934237
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
  t = LeafPattern(type=1, content="1", name="t")
  r = t.match(Leaf(type=1, value="1", prefix="", fixers_applied=[]))
  assert r == True, "LeafPattern.match() 1,1"
  r = t.match(Leaf(type=1, value="2", prefix="", fixers_applied=[]))
  assert r == False, "LeafPattern.match() 1,2"
  r = t.match(Leaf(type=1, value="", prefix="", fixers_applied=[]))
  assert r == False, "LeafPattern.match() 1,"
  r = t.match(Leaf(type=1, value="1", prefix="", fixers_applied=[]))

# Generated at 2022-06-23 16:07:30.857377
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    try:
        assert LeafPattern(10, "print")
        assert LeafPattern(10)
    except:
        print(traceback.format_exc());
        assert False


# Generated at 2022-06-23 16:07:38.151529
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    node_list = [Node(1, []), Node(2, []), Node(3, [])]
    Node(0, node_list).update_sibling_maps()
    assert node_list[0].next_sibling is node_list[1]
    assert node_list[1].next_sibling is node_list[2]
    assert node_list[2].next_sibling is None
    assert node_list[1].prev_sibling is node_list[0]
    assert node_list[2].prev_sibling is node_list[1]
    assert node_list[0].prev_sibling is None


# Generated at 2022-06-23 16:07:44.861366
# Unit test for method replace of class Base
def test_Base_replace():
    n = Leaf(0, "")
    assert n.replace(NL()) is None
    nn = Node(0)
    n.replace(nn)
    assert n.parent is None
    assert nn.parent.children[0] is nn



# Generated at 2022-06-23 16:07:47.624647
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    result = str(Node(1, [Leaf(1, 'foo')]))
    expected = "foo"
    assert result == expected



# Generated at 2022-06-23 16:07:57.826811
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    nodes = Node(1, [Leaf(2, 'hello'), Leaf(2, 'world'), Node(1, [Leaf(2, "how")])])

    # NegatedPattern match any sequence that is not yielded by the other pattern.
    pattern = NegatedPattern(NodePattern(2, ['hello', 'world']))

    assert pattern.match(nodes[0]) == False
    assert pattern.match(nodes[1]) == False
    assert pattern.match(nodes[2]) == False
    assert pattern.match(nodes) == False

    # At least one of them should match.
    assert pattern.match_seq([nodes[0]]) == False
    assert pattern.match_seq([nodes[1]]) == False
    assert pattern.match_seq([nodes[2]]) == False

    assert pattern.match_

# Generated at 2022-06-23 16:08:04.404589
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import parse
    from .pgen2.token import tok_name
    from .pytree import Leaf

    root = parse("x = 1 + 2", "single_input") # type: Ignore
    p = BasePattern(tok_name["NAME"], "x")

    node = Leaf(1, "x")
    name = "x"
    assert node.value == name
    assert p._submatch(node, {})
    assert p.match(node, {})

    assert p.match_seq([root])
    assert p.match_seq([root, root])
    assert not p.match_seq([])
    assert not p.match_seq([root, root, root])

    leaf = Leaf(1, "x")
    p = BasePattern(tok_name["NAME"], "x")


# Generated at 2022-06-23 16:08:15.264175
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    for min, max in (
        (0, 1),
        (0, 2),
        (1, 1),
        (1, 2),
        (2, 2),
    ):
        for inner in (
            WildcardPattern(min=min, max=max),
            NodePattern(),
            LeafPattern(47),
        ):
            for outer in (
                WildcardPattern(min=min, max=max, content=[inner]),
                WildcardPattern(min=min, max=max, content=[inner], name="foo"),
            ):
                assert outer.optimize() is outer
        for max in (0, 1):
            inner = WildcardPattern(min=0, max=1, content=[LeafPattern(47)])

# Generated at 2022-06-23 16:08:18.188701
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    from .pytree import Node
    node = Node(123, [])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map == None
    assert node.next_sibling_map == None



# Generated at 2022-06-23 16:08:24.496976
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Test the case where self.content is None
    p = NegatedPattern()
    assert not p.match_seq([])
    assert not p.match_seq(["a"])

    # Test the case where self.content is not None
    p = NegatedPattern(NodePattern(type=NAME))
    assert p.match_seq([])
    assert not p.match_seq([Leaf(token_type=NAME, value="x")])

# Generated at 2022-06-23 16:08:28.583252
# Unit test for function generate_matches
def test_generate_matches():
    from . import builder

    def check(s, t):
        tree = builder.parse(s)
        result = list(generate_matches([tree.pattern], [tree]))
        assert result == t, result

    check("a", [(1, {})])
    check("a b", [(1, {}), (2, {})])
    check("(a b)", [(1, {}), (2, {})])
    check("(a | b)", [(1, {}), (2, {})])
    check("a*", [(0, {}), (1, {}), (2, {}), (3, {})])
    check("(a b)?", [(0, {}), (1, {}), (2, {})])
    check("a | b", [(1, {}), (2, {})])

# Generated at 2022-06-23 16:08:39.893773
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Leaf, Node
    from . import six

    def tester(node):
        if node.parent:
            assert node.parent.depth() == node.depth() - 1
        for child in node.children:
            if not isinstance(child, Leaf):
                tester(child)

    testnode = Node(1, [Node(2, [Leaf(5, 'd'), Leaf(5, 'e'), Leaf(5, 'f')]), Node(2, [Leaf(5, 'g'), Leaf(5, 'h'), Leaf(5, 'i')])])
    assert testnode.depth() == 0
    assert testnode.children[1].depth() == 1
    assert testnode.children[0].children[1].depth() == 2

# Generated at 2022-06-23 16:08:51.567501
# Unit test for method changed of class Base
def test_Base_changed():
    from .pytree import Leaf, Node

    class A(Base):
        pass

    class B(Node):
        def compare_structure(self, other):
            return True

    n = B(type=0)

# Generated at 2022-06-23 16:08:54.189190
# Unit test for constructor of class NodePattern
def test_NodePattern():
    NodePattern()  # Check that it works without arguments
    NodePattern(None, ["*"])



# Generated at 2022-06-23 16:09:04.176247
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    l1 = Leaf(0, 'print')
    l2 = Leaf(0, '(')
    l3 = Leaf(0, '2')
    l4 = Leaf(0, '+')
    l5 = Leaf(0, '2')
    l6 = Leaf(0, ')')
    l7 = Leaf(0, '\n')
    chs = [l1, l2, l3, l4, l5, l6, l7]
    n = Node(0, chs)
    n.update_sibling_maps()
    ps = n.prev_sibling_map
    ns = n.next_sibling_map

# Generated at 2022-06-23 16:09:15.578770
# Unit test for method remove of class Base
def test_Base_remove():
    """Test support for node removal"""
    from .pytree import Leaf

    def t_node_remove(node, expected_pos, expected_size):
        pos = node.remove()
        assert pos == expected_pos
        assert len(node) == expected_size

    def t_node(node, expected_size):
        assert len(node) == expected_size

    t_node(Leaf(1, "a"), 1)
    # remove middle leaf
    t_node_remove(Leaf(2, "b"), 1, 2)
    # remove first leaf
    t_node_remove(Leaf(1, "a"), 0, 1)
    # remove last leaf
    t_node_remove(Leaf(3, "c"), 0, 0)

    # remove middle leaf, try other function

# Generated at 2022-06-23 16:09:21.125485
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    pattern = NegatedPattern()
    assert pattern.match_seq(["anything"]) == False
    assert pattern.match_seq([]) == True
    assert list(pattern.generate_matches(["anything"])) == []
    assert list(pattern.generate_matches([])) == [(0, {})]
    pattern = NegatedPattern("anything")
    assert pattern.match_seq(["anything"]) == True
    assert pattern.match_seq([]) == False
    assert list(pattern.generate_matches(["anything"])) == [(0, {})]
    assert list(pattern.generate_matches([])) == []


# Generated at 2022-06-23 16:09:24.311864
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, "value", (None, None))
    assert leaf.type == 1
    assert leaf.value == "value"
    assert leaf.fixers_applied is None



# Generated at 2022-06-23 16:09:31.029729
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    node = Node(256, [])
    node._next = {"a": "b"}
    node._prev = {"b": "c"}
    d = {"a": "b"}
    e = {"b": "c"}
    node.update_sibling_maps()
    print(node._next)
    print(node._prev)
    print(d)
    print(e)
    assert(node._next == d)
    assert(node._next is not d)
    assert(node._prev == e)
    assert(node._prev is not e)

# Generated at 2022-06-23 16:09:39.953898
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.pgen import BasePattern as Pattern

    class TestPattern(Pattern):
        def __init__(self, *args, **kwds):
            Pattern.__init__(self)
            self.args = args
            self.kwds = kwds

    # Regular usage
    p = TestPattern(1, 2, 3, a=4, b=5, c=6)
    assert p == TestPattern(1, 2, 3, a=4, b=5, c=6)
    assert p != TestPattern(1, 2, 3, a=4, b=5)
    assert p != TestPattern(1, 2, 3, a=4, b=5, c=6, d=7)
    assert p != TestPattern(1, 2, 3, a=4, b=5, c=7)

# Generated at 2022-06-23 16:09:44.241866
# Unit test for function generate_matches
def test_generate_matches():
    assert len(list(generate_matches([], []))) == 1
    assert len(list(generate_matches([[]], []))) == 1
    assert len(list(generate_matches([NodePattern()], []))) == 0
    assert len(list(generate_matches([], [Node()]))) == 0
    assert len(list(generate_matches([[]], [Node()]))) == 0
    assert len(list(generate_matches([NodePattern()], [Node()]))) == 1
    assert len(list(generate_matches([[[]], NodePattern()], [Node()]))) == 1
    assert len(list(generate_matches([[[]], NodePattern()], [Node(), Node()]))) == 0

# Generated at 2022-06-23 16:09:46.971937
# Unit test for constructor of class BasePattern
def test_BasePattern():
    try:
        BasePattern()
    except AssertionError:
        pass
    else:
        assert 0, "Did not raise exception"



# Generated at 2022-06-23 16:09:55.863043
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import sys

    import pattern_grammar  # Will create _pattern_grammar

    assert sys.getrefcount(_pattern_grammar) <= 2, sys.getrefcount(_pattern_grammar)
    name = WildcardPattern([[NodePattern(type=NAME)]], name="name")
    number = WildcardPattern([[NodePattern(type=NUMBER)]], name="number")
    binop = NodePattern(type=BINOP)

    pattern = WildcardPattern([[name, number, binop, number], [name]])
    number.content = "0"

    count, r = next(pattern.generate_matches([Leaf(NAME, "a"), Leaf(NUMBER, "0")]))
    assert count == 2, count
    assert r["name"] == [Leaf(NAME, "a")], r["name"]

# Generated at 2022-06-23 16:10:04.020550
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    import sys
    import StringIO

    save_stdout = sys.stdout
    output = StringIO.StringIO()

# Generated at 2022-06-23 16:10:09.607458
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    return
    #import parser
    #pat = parser.Pattern("dictcomp")
    #pat.match_seq([]) # Expected type 'list', got 'NoneType' instead
    #nodes = [] # Type list doesn't match expected type 'Union[Leaf, Node]'
    #pat.match_seq(nodes)
    return

# Generated at 2022-06-23 16:10:12.119812
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    node = Node(0, [Leaf(0, "a")])
    assert node.pre_order() == [node]
    assert list(node.pre_order()) == [node]

# Generated at 2022-06-23 16:10:16.432971
# Unit test for method clone of class Node
def test_Node_clone():
    from .pytree import Leaf
    from .pygram import python_symbols
    t = Node(
        python_symbols.power,
        [Leaf(1, "abc"), Leaf(2, "def")],
        prefix=" ",
    )
    t2 = t.clone()
    assert t is not t2 and t == t2
    assert t.prefix == t2.prefix
    assert t2.children == [Leaf(1, "abc"), Leaf(2, "def")]
    assert t2.children[0].parent is t2
    assert t2.children[1].parent is t2



# Generated at 2022-06-23 16:10:20.100061
# Unit test for method changed of class Base
def test_Base_changed():
    x = Leaf(1, "", (0, 0))
    y = Node(2, [x])
    x.parent = y
    x.changed()
    assert x.was_changed
    assert y.was_changed


# Generated at 2022-06-23 16:10:28.563752
# Unit test for method clone of class Node
def test_Node_clone():
    for type in range(256):
        n = Node(type, [Leaf(1, "line 1"), Leaf(2, "line 2")])
        assert str(n) == "line 1line 2", repr(n)
        c = n.clone()
        assert str(c) == "line 1line 2", repr(c)
        s = repr(n)
        assert repr(c) == s, (s, str(c))
        assert len(c.children) == 2, c.children
        assert str(c.children[0]) == "line 1", c.children
        assert str(c.children[1]) == "line 2", c.children



# Generated at 2022-06-23 16:10:31.993227
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf('test_type', 'test_value')
    p = l.pre_order()
    assert next(p) is l


# Generated at 2022-06-23 16:10:37.322075
# Unit test for constructor of class Base
def test_Base():
    # Check that Base is an abstract class
    class C(Base):

        def __init__(self):
            pass

    try:
        x = Base()
    except TypeError:
        pass
    else:
        raise AssertionError("Base() should have failed")
    x = C()



# Generated at 2022-06-23 16:10:41.334765
# Unit test for method __str__ of class Node
def test_Node___str__():
  # (FIXME: Constructor Node.__init__() not yet implemented)
  a = Node(0, []) # type: Node
  r = str(a) # type: Text
  if False:
    assert r == "", "Value of: str(a)"


# Generated at 2022-06-23 16:10:46.622901
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    # Spot check that BasePattern cannot be instantiated
    with pytest.raises(AssertionError):
        BasePattern()
    # Spot check that BasePattern is a superclass of LeafPattern
    leaf_pattern = LeafPattern()
    assert isinstance(leaf_pattern, BasePattern)
    # Spot check that BasePattern is a superclass of NodePattern
    node_pattern = NodePattern()
    assert isinstance(node_pattern, BasePattern)
    # Spot check that BasePattern is a superclass of WildcardPattern
    wildcard_pattern = WildcardPattern()
    assert isinstance(wildcard_pattern, BasePattern)


# Generated at 2022-06-23 16:10:51.425465
# Unit test for function generate_matches
def test_generate_matches():
    assert not list(generate_matches([a], []))
    assert [(3, {})] == list(generate_matches([a, a, a], [1, 2, 3]))
    assert [] == list(generate_matches([a, a, a], [1, 2]))
    assert [(5, {})] == list(generate_matches([a, a, a, a, a], [1, 2, 3, 4, 5]))
    assert [] == list(generate_matches([a, a, a, a, a], [1, 2, 3, 4]))
    assert [(3, {})] == list(generate_matches([a, a, a, b], [1, 2, 3]))

# Generated at 2022-06-23 16:11:00.722300
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Test with a complete, small tree
    tree = Node(0, [Leaf(1, "a"), Leaf(2, "b")],
                context=("bbb", (0, 0)))
    tree.children[1].next_leaf = tree.children[0]
    tree.children[0].prev_leaf = tree.children[1]
    tree.children[0].next_leaf = tree.children[1]
    tree.children[1].prev_leaf = tree.children[0]
    assert tree.children[0].get_suffix() == "b"
    assert tree.children[0].next_sibling.prefix == "b"
    assert tree.children[1].get_suffix() == ""
    assert tree.children[1].next_sibling is None
    assert tree.children[1].prev_s

# Generated at 2022-06-23 16:11:04.047688
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols

    assert type_repr(python_symbols.plusequals) == "+="
    assert type_repr(python_symbols.blah) == "blah"



# Generated at 2022-06-23 16:11:09.843400
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
  assert LeafPattern(3, "a").match(Leaf(3, "a"))
  assert not LeafPattern(3, "a").match(Leaf(3, "b"))
  assert not LeafPattern(0, "a").match(Leaf(3, "b"))
  assert not LeafPattern(0, "a").match(Node(3, []))
  assert LeafPattern(0, "a").match(Leaf(3, "a"))
  assert not LeafPattern(0, "").match(Node(3, []))
  return


# Generated at 2022-06-23 16:11:16.779341
# Unit test for function generate_matches
def test_generate_matches():
    import unittest
    import parser

    # Exercise the function with a simple case.
    # Start with a pattern like (.  .)
    # and a node like ('hello', 'world')
    # We should get back (1, {}) and (5, {})
    # So the match is 'hell' and 'world'
    p1 = NodePattern(type=parser.token.NAME)
    p2 = NodePattern(type=parser.token.NAME)
    p = [p1, p2]  # type: PatternSequence
    n = parser.sequence2ast(['hello', 'world'])  # type: NL
    for c, r in generate_matches(p, n.children):
        print(c, r)


# Generated at 2022-06-23 16:11:18.140117
# Unit test for method post_order of class Base
def test_Base_post_order():
    assert False, "Test not implemented."

# Generated at 2022-06-23 16:11:28.798709
# Unit test for method leaves of class Base
def test_Base_leaves():
    root = Node(python_symbols.file_input, [])
    root.append_child(Node(python_symbols.make_function_defn))
    root.append_child(Leaf(0, "def"))
    root.append_child(Leaf(0, "function"))
    root.append_child(Leaf(0, "("))
    root.append_child(Leaf(0, "*"))
    root.append_child(Leaf(0, "args"))
    root.append_child(Leaf(0, ","))
    root.append_child(Leaf(0, "**"))
    root.append_child(Leaf(0, "kwargs"))
    root.append_child(Leaf(0, "):"))

# Generated at 2022-06-23 16:11:34.550409
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    pattern = BasePattern(type=42)
    assert repr(pattern) == "BasePattern(42, None, None)"
    pattern = BasePattern(type=42, name="foo")
    assert repr(pattern) == "BasePattern(42, None, 'foo')"
    pattern = BasePattern(type=42, content=23)
    assert repr(pattern) == "BasePattern(42, 23, None)"
    pattern = BasePattern(type=42, content=23, name="bar")
    assert repr(pattern) == "BasePattern(42, 23, 'bar')"



# Generated at 2022-06-23 16:11:46.075237
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # text = "a b c d e"
    # p = parse(text, "expr_stmt")
    # neg = NegatedPattern(p)
    # for n in p.generate_matches(p.children):
    #     # print("NegatedPattern(%s).generate_matches(%s)" % (p, p.children))
    #     print("NegatedPattern(%s).generate_matches(%s) = %s" % (p, p.children, list(neg.generate_matches(p.children))))
    #     break
    # The above works
    text = "a b c d e"
    p = parse(text, "expr_stmt")

# Generated at 2022-06-23 16:11:51.229320
# Unit test for method append_child of class Node
def test_Node_append_child():
    """
    Unit tests for method append_child of class Node
    """
    from .pytree import Leaf

    tree = Node(1, [])
    child = Leaf(1, "child")
    tree.append_child(child)
    assert tree.children == [child]
    assert child.parent == tree

