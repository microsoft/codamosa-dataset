

# Generated at 2022-06-23 16:01:55.839245
# Unit test for constructor of class Leaf
def test_Leaf():
    # We only really care about the type of the argument for the second parameter.
    # We don't care about the value.
    l = Leaf(LBRACE, None)


# Generated at 2022-06-23 16:02:06.892440
# Unit test for method remove of class Base
def test_Base_remove():
    pass
    # from lib2to3.pgen2.grammar import *
    # from lib2to3.pgen2.token import *
    # from lib2to3.pytree import *
    # from lib2to3.pygram import *
    # from lib2to3.pgen2.parse import *
    # from lib2to3.pgen2.driver import *
    # import io
    # g = Grammar()
    # d = Driver(g, convert=False)
    # f = io.StringIO("1")
    # t = d.parse_tokens(f.readline)
    # n = n2t(t[0])
    # assert n.remove() == 0
    # assert n.parent is None
    # assert t[0][0] == DEDENT
    # f

# Generated at 2022-06-23 16:02:08.672488
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    import test  # type: ignore
    test.test_Base_get_lineno()



# Generated at 2022-06-23 16:02:14.402766
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    if not isinstance(test_BasePattern___repr__(), unittest.TestCase):
        raise TypeError
    t0 = BasePattern()
    def test_BasePattern___repr__1():
        if not isinstance(test_BasePattern___repr__1(), unittest.TestCase):
            raise TypeError
        t0.type = 0
        return repr(t0)

    assert test_BasePattern___repr__1() == "BasePattern(0, None, None)"
    t0.type = 256
    t0.content = 'test'
    t0.name = "b"
    assert repr(t0) == "BasePattern('test', b)"
    return

# Generated at 2022-06-23 16:02:19.144782
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    from .pytree import Leaf
    node1 = Node(257, [])
    node_leaf = Leaf(257, "hello")
    node1.insert_child(0, node_leaf)
    #print(node1)

test_Node_insert_child()

# Generated at 2022-06-23 16:02:27.576964
# Unit test for method post_order of class Node
def test_Node_post_order():
    def get_node(name):
        """
        :type name: str
        :rtype: blib2to3.pytree.Node
        """
        n = Node(python_symbols.power, [])
        n.used_names = []
        n.fixers_applied = []
        n_name = Leaf(1, name)
        n_name.used_names = []
        n_name.fixers_applied = []
        n.append_child(n_name)
        return n

    def test(subj, *args):
        """
        :type subj: blib2to3.pytree.Node
        :type args: str
        :rtype: None
        """
        # Test that post_order returns the right thing

# Generated at 2022-06-23 16:02:29.287118
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    pattern_1 = ast.parse('[1, 2, 3]')
    assert NegatedPattern().match(pattern_1) == False


# Generated at 2022-06-23 16:02:41.366871
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
  from .pgen2.token import tok_name

  # Call the method on a nominal instance
  t = Leaf(0, "")
  str1 = repr(t)
  # Check that the result is a well-formed string
  assert isinstance(str1, str)
  t = Leaf(1, "")
  str1 = repr(t)
  # Check that the result is a well-formed string
  assert isinstance(str1, str)
  t = Leaf(2, "")
  str1 = repr(t)
  # Check that the result is a well-formed string
  assert isinstance(str1, str)
  t = Leaf(3, "")
  str1 = repr(t)
  # Check that the result is a well-formed string
  assert isinstance(str1, str)

# Generated at 2022-06-23 16:02:52.086224
# Unit test for method depth of class Base
def test_Base_depth():
    import unittest
    from typed_ast.ast3 import (
        parse,
        Str,
        Expr,
        Module,
        FunctionDef,
        arguments
    )

    # Basic Structures
    class A(Node):
        def _eq(self, other):
            return True

        def clone(self):
            return A(self.prefix, self.children)

        def post_order(self):
            return []

        def pre_order(self):
            return []

    A_node=A("TEST", ["TEST", "CHILD"])
    Expected_depth=1

    # Test
    class Test(unittest.TestCase):
        def test_depth(self):
            self.assertEqual(A_node.depth(),Expected_depth)

    unittest.main()




# Generated at 2022-06-23 16:02:57.203382
# Unit test for method replace of class Base
def test_Base_replace():
    from .pytree import Leaf
    a = Leaf(1, "a")
    c = Leaf(1, "c")
    assert a.parent is None
    assert c.parent is None
    a.parent = c
    assert a.parent is c
    assert a in c.children
    a.replace(None)
    assert a.parent is None
    assert a not in c.children



# Generated at 2022-06-23 16:03:07.611210
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # Create a one-node tree
    tree = Leaf(1, "")
    # Check that the tree's suffix is the empty string
    assert tree.get_suffix() == ""
    # Check that the tree's parent is 'None'.
    assert tree.parent is None
    # Create a two-node tree with a parent node and a child node.
    tree = Node(0, None, children=[Leaf(1, ""), Leaf(2, "")])
    # Create another two-node tree:
    tree2 = Node(0, None, children=[Leaf(1, ""), Leaf(2, "")])
    # Check that the parent's suffix is not the empty string.
    assert tree.get_suffix() == ""
    # Check that tree2 is not equal to tree.
    assert not tree2 == tree
    # Make tree2

# Generated at 2022-06-23 16:03:13.425899
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    assert eval("Node(1, [])").__repr__() == "Node(1, [])"
    assert eval("Node(1, [Leaf(1, 'a')])").__repr__() == "Node(1, [Leaf(1, 'a')])"


# Generated at 2022-06-23 16:03:19.396234
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    lst = list(NegatedPattern().generate_matches([1, 1, 1, 1]))
    assert lst == [(0, {})], lst

    lst = list(
        NegatedPattern()
        .generate_matches([])
    )
    assert lst == [(0, {})], lst

    lst = list(
        NegatedPattern(NodePattern(type=token.NAME, content=[LeafPattern(value=b"x")]))
        .generate_matches([Name(1, b"x")])
    )
    assert lst == [], lst


# Generated at 2022-06-23 16:03:23.433434
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern().optimize() == NodePattern()
    assert WildcardPattern(name="m").optimize() == NodePattern(name="m")
    assert WildcardPattern(min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(min=1, max=1, name="m").optimize() == NodePattern(name="m")
    assert WildcardPattern(min=2).optimize() == WildcardPattern(min=2) # untransformable
    assert WildcardPattern(min=1, max=1).optimize().name == ""


# Generated at 2022-06-23 16:03:30.118721
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    for type in -10, 256, -sys.maxsize, sys.maxsize:
        try:
            LeafPattern(type)
        except AssertionError:
            pass
        else:
            assert False, "LeafPattern(%r) should have failed" % type
    try:
        LeafPattern(1, "a", 1)
    except AssertionError:
        pass
    else:
        assert False, "LeafPattern(1, 'a', 1) should have failed"


# Generated at 2022-06-23 16:03:31.052171
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Base()
    pass


# Generated at 2022-06-23 16:03:35.900543
# Unit test for function generate_matches
def test_generate_matches():
    def check(patterns, nodes, result_strings):
        results = []
        for count, r in generate_matches(patterns, nodes):
            results.append((count, r))
        if len(results) == len(result_strings):
            for i, (count, r) in enumerate(results):
                if "%d:%r" % (count, r) != result_strings[i]:
                    break
            else:
                return
        raise AssertionError("%r did not give %r" % (patterns, result_strings))

    from pythonparser import python_grammar

    a = NamePattern("a")
    b = NamePattern("b")
    check([a], [], ["%d:%r" % (0, {})])

# Generated at 2022-06-23 16:03:46.929597
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2 import token

    def test_grammar() -> Grammar:
        driver = Driver(convert)
        try:
            return driver.parse_string("""
            start: atom (u"+" atom)*
            atom: u"(" start u")" | u"foo"
            """)
        except ParseError as e:
            # Unwrap the exception which is wrapped inside a ParseError
            raise e.__cause__

    grammar = test_grammar()
    pattern = NodePattern(grammar.symbol2number["start"], [
        NodePattern(grammar.symbol2number["atom"], [
            LeafPattern(token.NAME, "foo"),
        ]),
    ])


# Generated at 2022-06-23 16:03:48.069279
# Unit test for constructor of class BasePattern
def test_BasePattern():
    """
    >>> BasePattern()
    Traceback (most recent call last):
    TypeError: BasePattern is an abstract base class
    """



# Generated at 2022-06-23 16:03:54.557346
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(1, "", None, "")
    assert list(l.post_order()) == [l]
    n = Node(257, [])
    assert list(n.post_order()) == [n]
    m = Node(258, [])
    n.append_child(m)
    assert list(n.post_order()) == [m, n]
    k = Node(258, [])
    m_prime = Node(258, [k])
    m.append_child(m_prime)
    assert list(n.post_order()) == [k, m_prime, m, n]


# Generated at 2022-06-23 16:04:05.374823
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # function name: test_BasePattern_optimize
    global test_BasePattern_optimize_call_count
    test_BasePattern_optimize_call_count += 1
    if not hasattr(test_BasePattern_optimize, "call_count"):
        test_BasePattern_optimize.call_count = 0
    test_BasePattern_optimize.call_count += 1

    # Test simple case
    p = LeafPattern(5)
    assert p.optimize() is p

    # Test wildcard pattern
    p = WildcardPattern()
    assert p.optimize() is p

    # Test (nested) repetition pattern
    p = RepeatPattern(LeafPattern(5), 0, None)
    assert p.optimize() is p
    p = RepeatPattern(LeafPattern(5), 0, 1)
    q

# Generated at 2022-06-23 16:04:09.435467
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    from . import token

    x = token.Token("x")
    y = token.Token("y")
    tokens = [x, y]

# Generated at 2022-06-23 16:04:14.500166
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    """Test LeafPattern match"""
    import os
    import sys
    import unittest
    from collections import namedtuple

    module = sys.modules["__main__"]
    class TestCase(unittest.TestCase):
        def test_match(self):
            self.assertFalse(LeafPattern().match(None))
            class Bad(object):
                pass
            bad = Bad()
            self.assertFalse(LeafPattern().match(bad))
            class Good(Leaf):
                pass
            good = Good(1, "foo")
            self.assertFalse(LeafPattern(2).match(good))
            self.assertFalse(LeafPattern(1, "bar").match(good))
            self.assertTrue(LeafPattern().match(good))

# Generated at 2022-06-23 16:04:22.554479
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    import pprint
    r1 = 'Node(SYM.test, [Leaf(1, ""), Leaf(1, "")])'
    r2 = pprint.pformat(r1)
    x = Node(
        257,
        [Leaf(1, ""), Leaf(1, "")])
    assert repr(x) == r1
    assert pprint.pformat(repr(x)) == r2

# Generated at 2022-06-23 16:04:28.130008
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    # The following assumes that LeafPattern() successfully matches an empty
    # list of nodes. This is true because LeafPattern() only matches a single
    # node, which will never be an empty list.
    assert_equal(LeafPattern().match_seq([]), False)
    assert_equal(LeafPattern().match_seq([Leaf(1, "foo")]), True)
    assert_equal(LeafPattern().match_seq([Leaf(1, "foo"), Leaf(2, "bar")]), False)

# Generated at 2022-06-23 16:04:32.112894
# Unit test for method set_child of class Node
def test_Node_set_child():
    x = new_test_node()
    x.set_child(3, Leaf(1, "Hello, world!"))
    assert x.children[3].value == "Hello, world!"


# Generated at 2022-06-23 16:04:39.707291
# Unit test for method post_order of class Base
def test_Base_post_order():
    from .pytree import Node, Leaf
    from .pygram import python_grammar, python_symbols  # type: ignore

    a = Leaf(1, "first")
    b = Node(python_symbols.vfpdef, [Leaf(1, "VAR")])
    c = Leaf(1, "second")
    d = Node(python_symbols.vfpdef, [Leaf(1, "X")])
    e = Node(python_symbols.vfpdef, [Leaf(1, "Y")])
    f = Node(python_symbols.parameters, [b, c, d, e])
    n = Node(python_grammar.number2int(python_symbols.funcdef), [a, f])

# Generated at 2022-06-23 16:04:47.059832
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.grammar import Grammar
    from .pgen2.parse import Driver, parse_tokens
    from .pgen2.tokenize import generate_tokens
    p = Grammar(r"""
        start: foo
        foo: foo 'a'
        | 'a'
    """)

    def test(test_string: str) -> None:
        tokens = generate_tokens(StringIO(test_string).readline)
        d = Driver(p)
        node = d.parse(tokens)
        assert node is not None

    test("")
    test("a")
    test("aa")
    test("aaa")



# Generated at 2022-06-23 16:04:48.159800
# Unit test for constructor of class BasePattern
def test_BasePattern():
    assert repr(BasePattern) == "BasePattern[...]"



# Generated at 2022-06-23 16:04:57.373609
# Unit test for method post_order of class Node
def test_Node_post_order():
    import sys
    import re
    symtbl = {}
    grammar = Grammar(re.match(r'#!.*python.*\n', sys.argv[0]) is not None)
    def parse_test_Node_post_order(grammar, input, nodes):
        module = grammar.parse(input=input, start="file_input")
        p = module.post_order()
        for x in nodes:
            assert next(p) == x, "Expected %s on post_order" % x
        try:
            next(p)
            assert False, "Expected StopIteration on post_order"
        except StopIteration:
            pass
        try:
            next(p)
            assert False, "Expected StopIteration on post_order"
        except StopIteration:
            pass

# Generated at 2022-06-23 16:05:07.979589
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from blib2to3.pgen2 import token

    def pre_order(node):
        # type: (Base) -> Optional[Text]
        if isinstance(node, Leaf):
            return node.value
        else:
            return "".join(filter(None, (pre_order(child) for child in node.children)))

    for t in (token.NAME, token.NUMBER, token.STRING):
        tree = Leaf(t, "yada")  # type: ignore
        assert pre_order(tree) == "yada"


# Generated at 2022-06-23 16:05:14.589664
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from . import pygram
    from .pygram import python_symbols as symbols

    g = pygram.python_grammar
    for type, *kids in (
        ("x", "1", "2", "3"),
        ("[x, y]", "[", "x", ",", "y", "]"),
    ):
        t = g.sym2number[type]
        kids = [Leaf(g.sym2number[k], k) for k in kids]
        node = Node(t, kids)
        assert repr(node).startswith("Node(%s," % type_repr(t))

# Generated at 2022-06-23 16:05:22.656012
# Unit test for method post_order of class Node
def test_Node_post_order():
    l1 = Leaf(1, "foo")
    l2 = Leaf(2, "bar")
    l3 = Leaf(3, "42")
    l4 = Leaf(4, "!")
    l5 = Leaf(5, "baz")

    n1 = Node(1, [l1, l2, l3])
    n2 = Node(2, [n1, l4])
    n3 = Node(3, [n2, l5])

    assert [n.type for n in n3.post_order()] == [2, 3, 1, 5, 4, 2, 3]



# Generated at 2022-06-23 16:05:31.125717
# Unit test for method append_child of class Node
def test_Node_append_child():
    from .pytree import Leaf
    from .pygram import python_symbols
    from blib2to3.pgen2.token import Token
    from .pytree import Node as pyNode
    from .six import StringIO
    from contextlib import redirect_stdout
    from . import pytree
    ns:Dict[str, Any] = {'x': "foo"}
    s = 'x'
    symbol_number = python_symbols.sym_name
    n = pyNode(symbol_number, [Leaf(Token.NAME, s)], prefix="    ")
    ns['no'] = n
    t = pyNode(python_symbols.simple_stmt, [n])
    t.set_lineno(1, 2)
    t.changed()
    print(t)

# Generated at 2022-06-23 16:05:31.566376
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pass



# Generated at 2022-06-23 16:05:35.085896
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    node = Node(0, [])
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map is None
    assert node.next_sibling_map is None

# Generated at 2022-06-23 16:05:38.644193
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2 import token
    lp = LeafPattern()
    lp.type = token.NAME
    lp.content = 'test'
    lp.name = 'test'
    assert lp.match(Leaf(token.NAME, 'test'))


# Generated at 2022-06-23 16:05:46.523841
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    from .pgen2.parse import _build_lexer

    lexer = _build_lexer("")
    def test(type, value):
        """
        Test that cloning a node returns a copy that's equal.
        """
        n = Leaf(type, value)
        n2 = n.clone()
        assert n == n2
        assert n is not n2
        assert n.prefix == n2.prefix

    for type in range(256):
        test(type, "")
        test(type, "x")



# Generated at 2022-06-23 16:05:56.141757
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    K = NodePattern
    L = LeafPattern
    w = WildcardPattern
    p = K(
        SYMBOL,
        [
            K(
                POWER,
                [
                    K(SYMBOL, [L(token.NAME, "x")]),
                    w(
                        [
                            [
                                K(SYMBOL, [L(token.NAME, "n")]),
                                K(SYMBOL, [L(token.NAME, "m")]),
                            ]
                        ]
                    ),
                ],
            ),
            K(
                POWER,
                [
                    K(MUL, [L(token.NAME, "a"), L(token.NAME, "b")]),
                    K(NAME, [L(token.NAME, "n")]),
                ],
            ),
        ],
    )
   

# Generated at 2022-06-23 16:05:57.919125
# Unit test for function convert

# Generated at 2022-06-23 16:06:08.379685
# Unit test for function convert
def test_convert():
    from .pgen2.grammar import Grammar
    from .pgen2.parsers import Parser

    def atom(name: Text) -> int:
        return g.symbol2number[name]

    g = Grammar()
    p = Parser(g, convert)
    p.setup()

    # A simple grammar for testing.
    g.symbol2number = {"atom": 1, "S": 2, "list": 3}
    g.number2symbol = {1: "atom", 2: "S", 3: "list"}
    g.states = ((1, 2, 3), ({}, {3: [[0, 2, 1]]}, {1: [[0, -1]]}))

# Generated at 2022-06-23 16:06:10.778834
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    root = Leaf(0, "", prefix="prefix")
    assert list(root.leaves()) == [root]

# Generated at 2022-06-23 16:06:14.317342
# Unit test for method append_child of class Node
def test_Node_append_child():
    import dumptree
    op = Node(1, [])
    op.append_child(Leaf(2, ""))
    print(op)
    print(dumptree.dumptree(op))



# Generated at 2022-06-23 16:06:20.689627
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    # Empty
    assert isinstance(BasePattern().optimize(), BasePattern)
    # Non-empty
    pattern = BasePattern(type=1, content=2, name=3)
    assert isinstance(pattern.optimize(), BasePattern)
    assert pattern.optimize() is not pattern
# Test case for class BasePattern

# Generated at 2022-06-23 16:06:24.445689
# Unit test for method set_child of class Node
def test_Node_set_child():
    # Initialization
    node = Node(0, [])
    i = 0
    child = Leaf(0, "")
    # Method call
    node.set_child(i, child)
    assert node.children[i] == child



# Generated at 2022-06-23 16:06:35.681552
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    n = parser_driver(grammar).parse_string("a and b or c")
    assert n.type == grammar.syms.eval_input
    n.update_sibling_maps()
    assert n.next_sibling is None
    assert n.prev_sibling is None
    assert n.prev_sibling_map is not None
    assert n.next_sibling_map is not None
    c = n.children
    for i in range(len(c)):
        j = i + 1
        if j == len(c):
            j = None
        for k in range(len(c)):
            if k == j:
                assert k == n.next_sibling_map[id(c[i])]
                assert i == n.prev_sibling_map[id(c[k])]
           

# Generated at 2022-06-23 16:06:45.161612
# Unit test for method generate_matches of class WildcardPattern

# Generated at 2022-06-23 16:06:46.387166
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    assert (str(Leaf(1, 'hi ')) == "hi ")



# Generated at 2022-06-23 16:06:50.800628
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():

    x = Leaf(0, 'a')
    y = Leaf(0, 'b')
    z = Leaf(0, 'c')

    root = Node(python_symbols.simple_stmt, [x, y, z])
    assert x.get_suffix() == 'b'
    assert y.get_suffix() == 'c'
    assert z.get_suffix() == ''

    root.remove()

    assert x.get_suffix() is None
    assert y.get_suffix() is None
    assert z.get_suffix() is None


# Generated at 2022-06-23 16:06:58.020233
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.parse import Driver

    cls, = Driver(grammar, convert).parse_string("pass")
    pattern = cls.pattern()
    assert tuple(pattern.generate_matches([cls])) == ((1, {}),)
    assert tuple(pattern.generate_matches([])) == ()
    assert tuple(pattern.generate_matches([cls, cls])) == ()

# Generated at 2022-06-23 16:07:06.178711
# Unit test for constructor of class Leaf
def test_Leaf():
    # Literal token
    leaf = Leaf(0, "blah")
    assert leaf.value == "blah"
    assert leaf.children == []

    # Newline
    leaf = Leaf(0, "\n")
    assert leaf.value == "\n"
    assert leaf.children == []

    # Empty string
    leaf = Leaf(0, "")
    assert leaf.value == ""
    assert leaf.children == []



# Generated at 2022-06-23 16:07:15.231421
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from .grammar import EmptyGrammar
    from .parse import Parser
    from .parser import Nonterminal
    from .symbol import Symbol


    g = EmptyGrammar()
    n = Nonterminal(g, "foo")
    p = Parser(g)
    s = Symbol(g, "a")
    assert not NegatedPattern(None).match(n)
    assert not NegatedPattern(None).match(p)
    assert not NegatedPattern(None).match(s)
    assert not NegatedPattern(NodePattern(type=g.grammar_start)).match(n)
    assert not NegatedPattern(NodePattern(type=g.grammar_start)).match(p)
    assert not NegatedPattern(NodePattern(type=g.grammar_start)).match(s)


# Generated at 2022-06-23 16:07:19.449124
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from lib2to3.pgen2 import token
    node = Node(token.NAME, [Leaf(token.NAME, "aaa")])
    for x in node.pre_order():
        assert x is node


# Generated at 2022-06-23 16:07:27.950250
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    """Unit test for method match_seq of class WildcardPattern."""
    # matcher = WildcardPattern(max=1)
    # Test input:
    # self.content = None
    # nodes = []
    matcher = WildcardPattern()
    nodes = []
    for count, result in matcher.generate_matches(nodes):
        print(count, result)
    assert [] == list(matcher.generate_matches(nodes))
    nodes = [Leaf(1, '1')]
    for count, result in matcher.generate_matches(nodes):
        print(count, result)
    assert [(1, {})] == list(matcher.generate_matches(nodes))
    # Test input:
    # self.content = None
    # self.min > 0
    mat

# Generated at 2022-06-23 16:07:36.461647
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    """Test Base.get_suffix()."""
    import sys

    sys.stderr.write("Testing Base.get_suffix()...")
    tree = parse_str("x+y")
    assert tree.get_suffix() == "+"
    assert tree.children[0].get_suffix() == "+y"
    assert tree.children[1].get_suffix() == ""
    assert tree.children[0].children[0].get_suffix() == "+"
    assert tree.children[0].children[0].children[0].get_suffix() == "y"
    sys.stderr.write(" done.\n")



# Generated at 2022-06-23 16:07:43.308015
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import unittest
    import types
    import dataclasses
    import ast

    # class Leaf():
    #     def __init__(self, type, value, context=None, prefix=None, fixers_applied=[]):
    #         self.type = type
    #         self.value = value
    #         if prefix is not None:
    #             self._prefix = prefix
    #         else:
    #             self._prefix = ''
    #         self._postfix = ''
    #         self.bracket_depth = 0
    #         self.fixers_applied = fixers_applied
    #         self.children = []
    #     def post_order(self):
    #         yield self

    @dataclasses.dataclass
    class LeafStub():
        type: int

# Generated at 2022-06-23 16:07:52.925684
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    class Node:
        def __init__(self, value):
            self.value = value

        def is_leaf(self):
            return isinstance(self.value, str)

        def get_children(self):
            return self.value

    p = NegatedPattern(WildcardPattern([[NodePattern()], [LeafPattern()]]))
    r = list(p.generate_matches([Node(1), Node(2), Node(3), Node(4), Node(5)]))
    assert r == [(0, {})]
    r = list(p.generate_matches([Node(1), Node(2)]))
    assert r == [(0, {})]

# Generated at 2022-06-23 16:08:04.231464
# Unit test for constructor of class Node
def test_Node():
    from .pygram import python_symbols as syms
    from .pytree import Leaf

    a = Leaf(1, "foo")
    b = Leaf(1, "bar")
    n = Node(syms.bar, [a, b])
    assert n.type == syms.bar
    assert n.children == [a, b]
    assert a.parent is n
    assert b.parent is n

    # Test __str__
    assert str(n) == "foobar"

    # Test invalidate_sibling_maps
    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Leaf(1, "c")
    d = Leaf(1, "d")
    n = Node(syms.bar, [a, b, c, d])
    n.invalid

# Generated at 2022-06-23 16:08:12.402185
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    test_pattern = (NegatedPattern()).match_seq(nodes=[])
    assert test_pattern == True, test_pattern
    test_pattern = (NegatedPattern()).match_seq(nodes=[(1, 2)])
    assert test_pattern == False, test_pattern
    test_pattern = (NegatedPattern()).match_seq(nodes=[(1, 2, 1, True)])
    assert test_pattern == False, test_pattern
## Unit test for method generate_matches of class NegatedPattern

# Generated at 2022-06-23 16:08:25.112975
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    a = NodePattern(type=token.NAME, content=LeafPattern(value='a'), name='a')
    b = NodePattern(type=token.NAME, content=LeafPattern(value='b'), name='b')
    c = NodePattern(type=token.NAME, content=LeafPattern(value='c'), name='c')

    neg_a = NegatedPattern(content=a)
    neg_ab = NegatedPattern(content=NodePattern(content=(a, b)))
    neg_ab_ab_ab = NegatedPattern(content=WildcardPattern(content=(neg_ab, neg_ab, neg_ab)))

    np = neg_ab_ab_ab.generate_matches([Leaf(t.NAME, 'a') for _ in range(2)])
    assert next(np) == (0, {})


# Generated at 2022-06-23 16:08:30.201154
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    n = Node (1, [Leaf (10, 'a'), Leaf (10, 'b'), Leaf (10, 'c')])
    n.invalidate_sibling_maps()
    assert n.prev_sibling_map == None
    assert n.next_sibling_map == None


# Generated at 2022-06-23 16:08:34.052572
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    f = Leaf(0, "")
    f.prefix = "a"
    f.clone().prefix == "a"


# Generated at 2022-06-23 16:08:37.725505
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    n = Node(1, [Leaf(2, "hi")], None)
    n.insert_child(0, Leaf(3, "hey"))
    assert n is not None
test_Node_insert_child()

# Generated at 2022-06-23 16:08:44.194101
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Check if match_seq works on an empty list of nodes
    np = NegatedPattern()
    assert np.match_seq([], None) == False
    # Check if match_seq works on a list of nodes
    np2 = NegatedPattern([NodePattern(TYPE_NAME)])
    assert np2.match_seq([], None) == False

# Generated at 2022-06-23 16:08:54.825125
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    """
    Tests for method match of class LeafPattern.
    """
    from .pgen2.grammar import Grammar
    from .pgen2.parse import ParseError
    from .pgen2.pgen import generate_grammar

    g = Grammar(
        r"""
    start = simple
    simple = "simple"
    """,
        start="start",
    )

    def _parse(symbol, text):
        try:
            tree = g.parse(text)
        except ParseError:
            print(f"Could not parse text {text!r}")
            raise
        node = tree.children[0]
        assert node.type == symbol
        return tree, node

    tree, node = _parse("start", "simple")

    r = node.match(LeafPattern("simple"))

# Generated at 2022-06-23 16:08:56.934432
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    assert list(Leaf(token.NAME, "a").leaves()) == [Leaf(token.NAME, "a")]

# Generated at 2022-06-23 16:09:05.615805
# Unit test for constructor of class NodePattern
def test_NodePattern():
    s = Symbol
    l = LeafPattern
    w = WildcardPattern
    n = NodePattern
    n(s.a, [l(1), (l(2) | l(3))])
    n(s.a, [(l(2) | l(3)), l(1)])
    n(s.a, [w()])
    n(s.a, [w(), w()])
    n(s.a, [w(max=2), l(4), l(4), l(4)])
    n(s.a, [w(max=2), l(4), l(4), l(4), l(4)])
    n(s.a, [w(max=3), l(4), l(4), l(4), l(4)])

# Generated at 2022-06-23 16:09:16.741562
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    """Test optimize method of class WildcardPattern"""
    # Test that the base case works
    assert WildcardPattern().optimize() == WildcardPattern()
    assert WildcardPattern(name="a").optimize() == WildcardPattern(name="a")
    assert WildcardPattern(name="a", min=1).optimize() == WildcardPattern(name="a", min=1)
    assert WildcardPattern(name="a", min=1, max=1).optimize() == WildcardPattern(name="a", min=1, max=1)

    # Test that optimize works with content
    assert WildcardPattern(content="").optimize() == WildcardPattern(content="")
    assert WildcardPattern(content="", name="a").optimize() == WildcardPattern(content="", name="a")

# Generated at 2022-06-23 16:09:19.165425
# Unit test for method depth of class Base
def test_Base_depth():
    assert Base.depth(Leaf(0, "", None, None)) == 0


# Generated at 2022-06-23 16:09:23.007724
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf
    node = Node(1, [Leaf(1, 1)])
    node.set_child(0, Leaf(2, 2))



# Generated at 2022-06-23 16:09:32.191539
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # The following are actually defined in a more general form in
    # test_pattern_matcher(), but this is faster to run and uses
    # specific nodes instead of strings.
    qa = Node("QA")
    node1 = Node("assign", "name", Node("NAME", "x"), Node("PLUS"))
    node2 = Node("assign", "name", Node("NAME", "x"), Node("MINUS"))
    node3 = Node("assign", "name", Node("NAME", "x"), Node("TIMES"))
    node4 = Node("assign", "name", Node("NAME", "y"), Node("TIMES"))
    node5 = Node("assign", "name", Node("NAME", "z"), Node("PLUS"))

    # Test 1

# Generated at 2022-06-23 16:09:33.761971
# Unit test for method __str__ of class Node
def test_Node___str__():
    n = Node(1, [Leaf(1, 'foo'), Leaf(1, 'bar')])
    assert str(n) == 'foobar'



# Generated at 2022-06-23 16:09:42.313654
# Unit test for function type_repr
def test_type_repr():
    import sys
    from .pygram import python_symbols, python_grammar

    assert type_repr(python_symbols.keyword) == "keyword"
    assert type_repr(python_symbols.DEDENT) == "DEDENT"
    assert type_repr(python_grammar.number) == "number"
    assert type_repr(sys.maxsize) == sys.maxsize
test_type_repr()



# Generated at 2022-06-23 16:09:44.439053
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(None, None, None)
    # Empty generator
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-23 16:09:54.068470
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    from pprint import pprint

    # Unit test for the ! operator
    assert (
        list(
            NegatedPattern(NodePattern(type=token.STRING, name="s0")).generate_matches(
                [Leaf(token.STRING, "a"), Leaf(token.STRING, "b")]
            )
        )
        == []
    )
    assert (
        list(
            NegatedPattern(NodePattern(type=token.STRING, name="s0")).generate_matches(
                []
            )
        )
        == [(0, {})]
    )

    # Unit test for the ! operator  (!Alt)

# Generated at 2022-06-23 16:10:03.576442
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    """Test match_seq."""

# Generated at 2022-06-23 16:10:06.246381
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(1, "x")
    assert l.pre_order() == iter([l])

# Generated at 2022-06-23 16:10:14.736959
# Unit test for method depth of class Base
def test_Base_depth():
    t = Node(0, "", [Leaf(0, "a"), Leaf(0, "b")])
    assert t.depth() == 0
    x = Node(0, "", [])
    t.children[0].parent = t
    t.children[1].parent = t
    assert t.children[0].depth() == 1
    t.children[0].children = [Node(0, "", [Leaf(0, "c")]), Leaf(0, "d")]
    t.children[0].children[0].parent = t.children[0]
    t.children[0].children[1].parent = t.children[0]
    assert t.children[0].depth() == 1
    assert t.children[0].children[0].depth() == 2

# Generated at 2022-06-23 16:10:25.438785
# Unit test for method replace of class Base
def test_Base_replace():
    import unittest

    class Case(unittest.TestCase):

        def test_replace(self):
            a = Node(0, None, None, [])
            b = Leaf(0, 'a', (1, 1))
            c = Leaf(0, 'b', (1, 2))
            d = Leaf(0, 'c', (1, 3))
            e = Leaf(0, 'd', (1, 4))
            a.append_child(b)
            a.append_child(c)
            a.append_child(d)
            a.append_child(e)
            b.replace_with([c, d])
            assert [b, c, d, e] == a.children
            assert a is b.parent
            assert a is c.parent
            assert a is d.parent

# Generated at 2022-06-23 16:10:34.649352
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    from .pgen2 import driver

    # Simple case
    pattern = driver.parse_pattern("(~ . . . . . . .)")
    pattern.content.content[0].content.content[0].content.content[0].content.content[0]
    nodes = [1, 2, 3, 4, 5, 6, 7]
    assert pattern.match_seq(nodes) == False
    nodes = [1, 2, 3, 4, 5, 6, 8]
    assert pattern.match_seq(nodes) == True
    nodes = [1, 1, 1, 1, 1, 1, 1]
    assert pattern.match_seq(nodes) == False
    nodes = [1, 2, 1, 2, 1, 2, 1]
    assert pattern.match_seq(nodes) == False

# Generated at 2022-06-23 16:10:44.479592
# Unit test for method set_child of class Node
def test_Node_set_child():
    g = Grammar()
    g.add_production("file_input", ("stmt", "['\\n', <EOF>]"))
    g.add_production("stmt", ("simple_stmt",))
    g.add_production("stmt", ("compound_stmt",))
    g.add_production("simple_stmt", "small_stmt", "[';']", "[NEWLINE]")
    g.add_production("small_stmt", ("expr_stmt",))
    g.add_production("small_stmt", ("del_stmt",))
    g.add_production("small_stmt", ("pass_stmt",))
    g.add_production("small_stmt", ("flow_stmt",))
    g.add_production("small_stmt", ("import_stmt",))


# Generated at 2022-06-23 16:10:51.283557
# Unit test for method clone of class Node
def test_Node_clone():
    n = Node(0, [])
    n_clone = n.clone()

    n.type = 0
    assert n.type == n_clone.type

    n.parent = None
    assert n.parent == n_clone.parent

    n.children = []
    assert n.children == n_clone.children

    n.was_changed = False
    assert n.was_changed == n_clone.was_changed

# Generated at 2022-06-23 16:10:58.954227
# Unit test for constructor of class Base
def test_Base():
    import unittest

    class BaseTest(unittest.TestCase):
        def test_constructor(self):
            class Node(Base):
                pass

            class Leaf(Base):
                pass

            self.assertRaises(AssertionError, Base)

            n = Node()
            self.assertIsInstance(n, Node)
            self.assertIsInstance(n, Base)
            self.assertIsInstance(n, object)

            l = Leaf()
            self.assertIsInstance(l, Leaf)
            self.assertIsInstance(l, Base)
            self.assertIsInstance(l, object)

    unittest.main()



# Generated at 2022-06-23 16:11:02.421995
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    assert repr(NegatedPattern()) == "NegatedPattern(None)"
    assert repr(NegatedPattern(None)) == "NegatedPattern(None)"
    assert repr(NegatedPattern(LeafPattern())) == "NegatedPattern(LeafPattern(None))"



# Generated at 2022-06-23 16:11:09.289040
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():

    l = Leaf(1, "b", fixers_applied=[])
    l.type = 1
    l._prefix = "a"
    l.value = "b"
    l.fixers_applied = []
    l.children = []

    return l.__str__()

# Generated at 2022-06-23 16:11:18.220926
# Unit test for method __new__ of class Base
def test_Base___new__():
    from .pytree import Leaf, Node
    from .pygram import python_symbols
    from .pgen2 import token
    #
    # Base can't be instantiated directly.
    #
    b = Base()
    try:
        b = Base()
    except AssertionError:
        pass
    #
    # Test leaf.
    #
    l = Leaf(token.NAME, "foo", (1, 0), (1, 3))
    assert l is not None
    assert isinstance(l, Base)
    assert not isinstance(l, Node)
    assert l.type == token.NAME
    assert l.value == "foo"
    assert l.context == (1, 0)
    assert l.prefix == "foo"
    assert l.parent is None
    assert l.changed() is None

# Generated at 2022-06-23 16:11:19.460718
# Unit test for method insert_child of class Node
def test_Node_insert_child():
  pass


# Generated at 2022-06-23 16:11:29.694383
# Unit test for method append_child of class Node
def test_Node_append_child():
    from ...pgen2 import token

    def build_file_input(s: Text) -> Node:
        from ...pgen2.parse import ParseError

        tokens = list(tokenize.generate_tokens(StringIO(s).readline))
        try:
            return Grammar().parse(tokens, error_recovery=False)
        except ParseError:
            print(tokens)
            raise

    # Test 1: Append to a list
    code1 = """x = [1, 2, 3]"""
    ast1 = build_file_input(code1)
    ast_list1 = ast1.children[1].children[2]
    newleaf = Leaf(token.NUMBER, "4")
    ast_list1.append_child(newleaf)
    assert str(ast1)

# Generated at 2022-06-23 16:11:33.156044
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
  from .pgen2.token import tok_name

  f = Leaf(1, "x")
  f.prefix = ' '
  assert str(f) == " x"



# Generated at 2022-06-23 16:11:45.946131
# Unit test for function convert
def test_convert():
    from .pgen2.driver import Driver
    from .pgen2.parse import parse_string, ParseError
    from .pgen2.tokenize import generate_tokens, TokenError

    gr = Driver()

    def dump_node(node: NL) -> Text:
        if isinstance(node, Leaf):
            return f"Leaf({node.type}, {node.value})"
        else:
            return f"Node({node.type}, {[dump_node(x) for x in node.children]})"

    def test_conversion(source: str) -> None:
        tree = parse_string(gr, source)
        expected = dump_node(tree)
        tree = parse_string(gr, source, convert=convert)
        actual = dump_node(tree)

# Generated at 2022-06-23 16:11:48.032412
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Base instantiation should fail
    Base()



# Generated at 2022-06-23 16:11:57.224208
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Unary tests
    def test_1(x: "BasePattern") -> bool:
        return str(repr(x)) == str(x)

    # Basis tests
    n1: "BasePattern" = LeafPattern(token.NAME)
    assert test_1(n1)

    n2: "BasePattern" = NodePattern(sym.dotted_name, name="module_name")
    assert test_1(n2)

    # Inductive tests
    def test_2(x: "BasePattern") -> bool:
        return test_1(x)

    # Use a function for a recursive call
    assert test_2(n1)
    assert test_2(n2)

