

# Generated at 2022-06-23 16:02:00.525030
# Unit test for constructor of class NodePattern
def test_NodePattern():
    import sys
    from . import pgen2
    from .pgen2.parse import ParseError
    from . import token
    import io

    def make_pattern(s, type=None, name=None, content=None):
        return NodePattern(type, content, name)

    def compare_patterns(s, t):
        assert t[0] is t[1]
        assert t[0].__class__ is t[1].__class__
        assert t[0] == t[1]

    try:
        make_pattern(None)
    except AssertionError:
        pass
    else:
        raise AssertionError
    try:
        make_pattern(None, content=None)
    except AssertionError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-23 16:02:07.957361
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    funcName = sys._getframe().f_code.co_name
    print("\n{}:".format(funcName))

    node = Node(type=256, children=[])
    assert node.prev_sibling_map is None
    assert node.next_sibling_map is None

    node.prev_sibling_map = {}
    node.next_sibling_map = {}
    node.invalidate_sibling_maps()
    assert node.prev_sibling_map is None
    assert node.next_sibling_map is None


# Generated at 2022-06-23 16:02:16.512712
# Unit test for method __str__ of class Leaf

# Generated at 2022-06-23 16:02:22.113453
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    # create a Leaf object
    leaf_obj = Leaf(type=1, value='hi', context=None, prefix=None, fixers_applied=[])
    # call the function
    result = leaf_obj.post_order()
    # print(result)
    # assert result[0] == 1
    assert result == [leaf_obj]


# Generated at 2022-06-23 16:02:29.192758
# Unit test for method set_child of class Node
def test_Node_set_child():
    import unittest
    from .pytree import convert
    import libcst as cst
    class NodeTest(unittest.TestCase):
        def test_set_child(self):
            # We have to use the internal API because libcst.CSTNode doesn't let
            # you set the children.
            node = cst.parse_module("a = b")
            node.children[0].children[0]._set_child(
                1,
                convert(cst.parse_expression("b.c")),
            )
            self.assertEqual(node.code, "a.c = b")
            # We're testing the internals here, so we have to know how it's
            # actually implemented.
            self.assertIsNone(node.children[0].children[0].children[1].parent)


# Generated at 2022-06-23 16:02:31.282071
# Unit test for constructor of class NodePattern
def test_NodePattern():
    assert NodePattern(264, ("foo",), "testvar").content == ("foo",)



# Generated at 2022-06-23 16:02:36.492004
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    p = WildcardPattern([["a"], ["b", "c"]])
    assert isinstance(p, WildcardPattern)
    assert isinstance(p.content, tuple)
    assert len(p.content) == 2
    assert isinstance(p.content[0], tuple)
    assert len(p.content[0]) == 1
    assert isinstance(p.content[0][0], LeafPattern)
    assert p.content[0][0].type == _sym.NAME
    assert p.content[0][0].content == "a"


# Generated at 2022-06-23 16:02:44.220869
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    p = WildcardPattern([Leaf(token.NAME, "a")], name="foo")
    assert p.optimize() is p
    p = WildcardPattern([[Leaf(token.NAME, "a")]], name="foo")
    assert p.optimize() is p
    p = WildcardPattern([[Leaf(token.NAME, "a")]], name="foo", min=1, max=1)
    assert p.optimize() is not p
    q = p.optimize()
    assert isinstance(q, LeafPattern)
    assert q.name == "foo"
    p = WildcardPattern([[Leaf(token.NAME, "a")]], name="foo", min=1, max=2)
    assert p.optimize() is not p
    q = p.optimize()
    assert isinstance

# Generated at 2022-06-23 16:02:50.751979
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.pgen import BasePattern as P
    p = P(42)
    assert repr(p) == "BasePattern(42, None, None)"
    p = P(43, "foo")
    assert repr(p) == "BasePattern(43, 'foo', None)"
    p = P(44, "foo", "bar")
    assert repr(p) == "BasePattern(44, 'foo', 'bar')"


# Generated at 2022-06-23 16:02:54.178143
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(3, "hi")
    assert l.type == 3
    assert l.value == "hi"
    assert not l.children


# Generated at 2022-06-23 16:03:04.804983
# Unit test for method __str__ of class Node
def test_Node___str__():
    """Unit test for method __str__ of class Node"""

    def check(node, expected_result):
        result = str(node)
        assert result == expected_result, f"""Return value: {result!r}
Expected: {expected_result!r}"""

    from .pytree import BaseBox
    from .pygram import python_symbols
    from . import pytoken

    token_str = "name   =       'x'"
    token_str2 = "name   =       'y'"
    token_str3 = "name   =       'z'"
    base_box = BaseBox("%s\n%s\n%s" % (token_str, token_str2, token_str3))
    leafs = list(base_box.leaves())

# Generated at 2022-06-23 16:03:09.931814
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    # Successful match
    nodes = [visual.Frame(1, 1)]
    assert WildcardPattern(min=1, max=2).match_seq(nodes)
    # No match
    nodes = [visual.Frame(1, 1)]
    assert not WildcardPattern(min=2, max=2).match_seq(nodes)


# Generated at 2022-06-23 16:03:17.990923
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    import pgen2.pgen
    node_2: pgen2.pgen.Leaf = pgen2.pgen.Leaf(1, 'duck')
    assert repr(node_2) == "Leaf(NAME, 'duck')"
    node_3: pgen2.pgen.Leaf = pgen2.pgen.Leaf(1, 'dog')
    assert repr(node_3) == "Leaf(NAME, 'dog')"


# Generated at 2022-06-23 16:03:23.606766
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern(None, 1, 1).optimize() == NodePattern()
    assert WildcardPattern(([LeafPattern('a')], [LeafPattern('b')]), 1, 1).optimize() == NodePattern()
    assert WildcardPattern(([LeafPattern('a')], [LeafPattern('b')]), 2, 2).optimize() == WildcardPattern(([LeafPattern('a'), LeafPattern('a')], [LeafPattern('b'), LeafPattern('b')]), 1, 1)
    assert WildcardPattern(([WildcardPattern(([LeafPattern('a')],), 1, 1)], [WildcardPattern(([LeafPattern('b')],), 1, 1)]), 1, 1).optimize() == WildcardPattern(([LeafPattern('a')], [LeafPattern('b')]), 1, 1)
    assert Wild

# Generated at 2022-06-23 16:03:32.076283
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(1, "foo", fixers_applied = [], context = None, prefix = None)
    assert l.type == 1
    assert l.value == "foo"
    assert l.children == []
    assert l.prefix == ""
    assert l.fixers_applied == None
    assert l.bracket_depth == 0
    assert l.opening_bracket == None
    assert l.lineno == 0
    assert l.column == 0
    assert l.parent == None


# Generated at 2022-06-23 16:03:39.166029
# Unit test for method leaves of class Base
def test_Base_leaves():
    class Node(Base):
        def __init__(self, type, children=[]):
            self.type = type
            self.children = children
            self.prefix = ""
            self.parent = None
        def __eq__(self, other):
            return self.type == other.type and self.children == other.children
        def clone(self):
            return Node(self.type, [child.clone() for child in self.children])
        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self
        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

    class Leaf(Base):
        def __init__(self, type, value, context):
            self.type = type

# Generated at 2022-06-23 16:03:50.136372
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import re
    import types
    from .pgen2.parse import parse, make_parser
    from .pgen2.generator import Generator
    from .pgen2.pgen import tokenize, token, driver
    from .pgen2.pgen import (
        Literal,
        NotAny,
        Lookahead,
        Repetition,
        Optional,
        ZeroOrMore,
        Forward,
        OneOrMore,
        Group,
        SubPattern,
        ParseException,
        Sequence,
        Empty,
        Combine,
    )
    from .pgen2.pgen import _flatten, _combine
    from .pgen2.pgen import _is_consumed, _token


# Generated at 2022-06-23 16:04:01.526496
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    def eq(node, expected):
        node.update_sibling_maps()
        assert node.prev_sibling_map == expected[0]
        assert node.next_sibling_map == expected[1]

    node = Node(1, [Leaf(1, ""), Leaf(2, "")])
    eq(node, ({id(node.children[1]): None}, {id(node.children[0]): node.children[1]}))

    node = Node(1, [Leaf(1, ""), Leaf(2, ""), Leaf(3, "")])

# Generated at 2022-06-23 16:04:07.408273
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from pytree import LeafPattern as lp; from pytree import NodePattern as np

    assert repr(lp(1)) == "LeafPattern(None)"
    assert repr(lp(1, "abc")) == "LeafPattern(1, 'abc')"
    assert repr(np(1, "def")) == "NodePattern(1, 'def')"
    assert repr(np(2, None, "g")) == "NodePattern(2, None, 'g')"



# Generated at 2022-06-23 16:04:11.283395
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    pattern = NegatedPattern(NodePattern(type=1))
    assert pattern.content is not None
    assert isinstance(pattern.content, NodePattern)
    pattern = NegatedPattern()
    assert pattern.content is None
    assert pattern.generate_matches(None) == iter([(0, {})])
    assert pattern.generate_matches([1, 2, 3]) == iter([])
    assert pattern.generate_matches([]) == iter([(0, {})])



# Generated at 2022-06-23 16:04:15.745684
# Unit test for function generate_matches
def test_generate_matches():
    def test(patterns, nodes):
        return list(generate_matches(patterns, nodes))

    empty = test([], [])
    assert empty == [(0, {})], (empty, test([expr], []))
    assert test([expr], [expr]) == [(1, {})], test([expr], [expr])
    assert test([expr], [expr, expr]) == [(1, {})], test([expr], [expr, expr])

    assert test([expr, expr], [expr, expr]) == [(2, {})], test([expr, expr], [expr, expr])
    assert test([expr, expr], [expr, expr, expr]) == [(2, {})], test([expr, expr], [expr, expr, expr])
    assert test([expr, expr], [expr]) == [], test([expr, expr], [expr])



# Generated at 2022-06-23 16:04:27.196379
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import unittest
    import re
    import random

    class Test(unittest.TestCase):
        def test_simple(self):
            w = WildcardPattern(min=0, max=HUGE)
            nl = parse(
                "(a b c) (d e f) (g h i) (j k l) (m n o) (p q r) (s t u) (v w x) (y z)"
            )
            good = []
            for c, r in w.generate_matches(nl.children):
                good.append(nl.children[:c])
            self.assertEqual(good, [nl.children])

        def test_plus(self):
            w = WildcardPattern(min=1, max=HUGE)

# Generated at 2022-06-23 16:04:35.505928
# Unit test for method clone of class Node
def test_Node_clone():
    node = Node(1, [Leaf(1, 'a'), Node(2, [Leaf(2, 'b')])])
    node_clone = node.clone()
    assert (node is not node_clone)
    assert (node.children is not node_clone.children)
    assert (node.children[0] is not node_clone.children[0])
    assert (node.children[1] is not node_clone.children[1])
    assert (node.children[1].children[0] is not node_clone.children[1].children[0])
    assert (node == node_clone)

# Generated at 2022-06-23 16:04:42.197363
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from lib2to3 import pytree
    node1 = pytree.Node(5, [pytree.Leaf(1, "test1"),
                            pytree.Leaf(1, "test2"),
                            pytree.Leaf(1, "test3")])
    node1.update_sibling_maps()
    assert node1.prev_sibling_map[id(node1.children[0])] == None
    assert node1.next_sibling_map[id(node1.children[0])] == node1.children[1]
    assert node1.prev_sibling_map[id(node1.children[1])] == node1.children[0]
    assert node1.next_sibling_map[id(node1.children[1])] == node1.children[2]
    assert node

# Generated at 2022-06-23 16:04:50.099189
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    # exercise special cases of WildcardPattern.optimize()
    p = WildcardPattern()
    assert p.optimize() is p

    p = WildcardPattern(min=1, max=1)
    assert p.optimize() == NodePattern()

    p = WildcardPattern(min=0, max=1)
    assert p.optimize() is p

    p = WildcardPattern(min=1, max=2)
    assert p.optimize() is p

    p = WildcardPattern([[LeafPattern()]])
    assert p.optimize() is p

    p = WildcardPattern([[LeafPattern()]], name="x")
    assert p.optimize() is p

    p = WildcardPattern([[LeafPattern()]], min=1, max=1)
    assert p.optimize() == LeafPattern

# Generated at 2022-06-23 16:04:54.231554
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Verify that NodePattern can be instantiated with no arguments
    np = NodePattern()
    assert np.type is None
    assert np.content == []
    assert np.name is None
    # Verify that NodePattern can be instantiated with only a type
    np = NodePattern(type=syms.expr)
    assert np.type == syms.expr
    assert np.content == []
    assert np.name is None
    # Verify that NodePattern can be instantiated with only a content
    # Verify that NodePattern can be instantiated with only a name
    np = NodePattern(content=[])
    assert np.type is None
    assert np.content == []
    assert np.name is None
    # Verify that NodePattern can be instantiated with a type and content
    np = NodePattern(type=syms.term, content=[])
   

# Generated at 2022-06-23 16:04:59.099994
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    import sys
    from .pgen2.parse import ParseError

    print('Testing for method match_seq of class BasePattern:\n%s' % ('*' * 70,))
    print('>>> from .pgen2.tokenize import driver')
    print('>>> from .pgen2.parse import parse_grammar')
    print('>>> from .pgen2.pgen import BasePattern, convert')
    print('>>> from io import StringIO')
    print('>>> stream = StringIO("a = 2")')
    print('>>> try:')
    print('...     root = driver(source=stream, token_names=["NAME", "NUMBER", "NEWLINE", "INDENT", "DEDENT", "NL", "ENDMARKER"], convert=convert)')
    print('... except ParseError:')

# Generated at 2022-06-23 16:05:09.009914
# Unit test for method post_order of class Node
def test_Node_post_order():
    # type: () -> None

    grammar = blib2to3.pgen2.grammar.Grammar()
    parser = Parser(blib2to3.pgen2.driver.PgenParser(grammar,{}))
    result = parser.parse(grammar, "a = b\n")
    assert result.type == grammar.number2symbol[grammar.start]
    assert result.parent is None
    assert len(result.children) == 1
    assert len(result.children[0].children) == 1  # stmt
    assert len(result.children[0].children[0].children) == 3
    assert repr(result) == "SyntaxNode(%r, [%r])" % (
        "file_input",
        "simple_stmt",
    )
    assert str(result)

# Generated at 2022-06-23 16:05:16.111790
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    import operator

    import pytest

    from .pgen2 import token

    from . import parse

    from . import tokenize

    from . import driver

    from . import pytree

    from .pgen2 import grammar

    from .pgen2 import pgen

    from .pgen2 import token

    from .pgen2.tokenize import String

    from .pgen2.pgen import (
        BasePattern as _BasePattern,
        convert,
    )

    from .pytree import Leaf

    from rply.error import ParsingError


# Generated at 2022-06-23 16:05:24.323512
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node
    from .pygram import python_symbols as syms
    n = Node(syms.trailer, [])
    assert(n.depth() == 0)
    t = Node(syms.test, [])
    n.children.append(t)
    assert(n.depth() == 1)
    assert(t.depth() == 2)
    def t_depth():
        return t.depth()
    assert_raises(AssertionError, t_depth)
    # ... so we should be able to get away with setting the parent to None
    t.parent = None
    assert(t.depth() == 0)



# Generated at 2022-06-23 16:05:32.220092
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """Unit test for BasePattern.optimize()"""
    class Patterns(object):
        """Concrete subclasses of BasePattern"""

        class P1(BasePattern):
            """Subclass with no optimizations"""

            def __init__(self, value):
                assert self.type is None
                assert self.content is None
                assert self.name is None
                self.value = value

            def _submatch(self, node, results=None):
                assert results is None
                return node.value == self.value

        class P2(BasePattern):
            """Subclass that performs a single optimization"""

            def __init__(self, value):
                assert self.type is None
                assert self.content is None
                assert self.name is None
                self.value = value


# Generated at 2022-06-23 16:05:33.373807
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    BasePattern.optimize()


# Generated at 2022-06-23 16:05:37.572826
# Unit test for method clone of class Node
def test_Node_clone():
    prog = grammar.opener.parse("x = 1")[0]
    clone = prog.clone()
    clone.children[1].value = "2"
    assert str(prog) == "x = 1"
    assert str(clone) == "x = 2"

# Generated at 2022-06-23 16:05:49.013914
# Unit test for method clone of class Node
def test_Node_clone():
    """
    I'm #not sure what to test here. Let's test some things by making sure the
    (deep) copy is properly altered when the original is altered.
    """
    import blib2to3.pgen2.parse as parse

    def get_tuple(a, b, c):
        return a, b, c

    root = parse.parse("get_tuple(1, 2, 3)")
    assert root is not None

    # Test that the clone has the same number of children and that
    # the parent attributes of the children are correct.
    clone = root.clone()
    assert len(root.children) == len(clone.children)
    for child1, child2 in zip(root.children, clone.children):
        assert child1.parent is root
        assert child2.parent is clone

    # Test that

# Generated at 2022-06-23 16:05:50.005684
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()



# Generated at 2022-06-23 16:05:57.910063
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .pgen2.tokenize import tokenize, untokenize
    from .pgen2 import token
    from io import BytesIO
    from six import PY3
    from .compile import Compile
    from . import pytree
    from .pygram import python_symbols as syms
    from .pygram import python_grammar
    from . import fixer_base
    from .pgen2.token import tok_name

    def assert_LeafRepr(string, expected):
        '''
        Perform the following:
            1) Tokenize string and untokenize back to str
            2) Compile str to grammar, create a pytree
            3) Get expected
            4) Compare expected to actual

        '''
        string = string.encode('utf8')
        if not PY3:
            string

# Generated at 2022-06-23 16:06:07.482306
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern(
        type=1,
        content=[
            LeafPattern(type=2),
            NodePattern(type=3, content=[LeafPattern(type=4), LeafPattern(type=5)]),
        ],
        name="N",
    )
    assert n.type == 1
    assert len(n.content) == 2
    assert n.content[0].type == 2
    assert n.content[1].type == 3
    assert n.content[1].content[0].type == 4
    assert n.content[1].content[1].type == 5
    assert n.name == "N"

_WildcardPattern = TypeVar("_WildcardPattern", bound="WildcardPattern")


# Generated at 2022-06-23 16:06:16.257407
# Unit test for method pre_order of class Base
def test_Base_pre_order():

    files = [
  "src/main/resources/parser/tree.py",
  "src/main/resources/parser/pytree.py",
  "src/main/resources/parser/python.tree",
    ]

    for file in files:

        with open(file, encoding="utf-8") as f:
            input = f.read()

        from .pytree import hacky_stuff_to_get_pytree_for_source

        tree = hacky_stuff_to_get_pytree_for_source(input)

        for node in tree.pre_order():
            pass



# Generated at 2022-06-23 16:06:27.361024
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    When `args = [type_repr(self.type), self.content, self.name]` contains
    `None` at the end, `args` should be truncated until it does not contain
    `None` at the end.  This test is for this part.
    """
    from .pgen2.tokenize import generate_tokens

    __pychecker__ = "no-classobj"

    class BasePattern(object):

        """A pattern is a tree matching pattern."""

        # Defaults for instance variables
        type = None  # Node type (token if < 256, symbol if >= 256)
        content = None  # Optional content matching pattern
        name = None  # Optional name used to store match in results dict


# Generated at 2022-06-23 16:06:37.169719
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    # Simple test for class NegatedPattern
    pat = NegatedPattern(None)
    assert pat.match_seq([])
    assert not pat.match_seq([Node(1, [])])
    pat = NegatedPattern(NodePattern(1))
    assert pat.match_seq([])

# Generated at 2022-06-23 16:06:40.426156
# Unit test for method __str__ of class Node
def test_Node___str__():
    from .leaf import Leaf
    n = Node(0, [Leaf(1, "foo"), Leaf(2, "bar"), Leaf(3, "baz")])
    assert str(n) == "foobarbaz"

# Generated at 2022-06-23 16:06:44.905643
# Unit test for constructor of class NodePattern
def test_NodePattern():
    NodePattern()
    NodePattern(type=256)
    NodePattern(content=[Leaf(1, "")])
    NodePattern(type=256, content=[Leaf(1, "")])
    NodePattern(content=[Leaf(1, ""), Leaf(2, "")])
    NodePattern(type=256, content=[Leaf(1, ""), Leaf(2, "")])
    NodePattern(name="foo")
    NodePattern(content=[Leaf(1, "")], name="foo")
    NodePattern(type=256, content=[Leaf(1, "")], name="foo")
    NodePattern(content=[Leaf(1, ""), Leaf(2, "")], name="foo")
    NodePattern(type=256, content=[Leaf(1, ""), Leaf(2, "")], name="foo")


# Generated at 2022-06-23 16:06:48.220897
# Unit test for method changed of class Base
def test_Base_changed():
    print('test_Base_changed')
    leaf1 = Leaf(1, 'sample')
    leaf2 = Leaf(2, 'leaf2')
    tree = Node(1, children=[leaf1, leaf2])
    assert tree.was_changed is False
    leaf1.changed()
    assert tree.was_changed is True


# Generated at 2022-06-23 16:06:52.976683
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from .pgen2.token import NUMBER
    x = Leaf(NUMBER, "7")
    assert x.pre_order() == [x]


# Generated at 2022-06-23 16:06:54.586831
# Unit test for constructor of class Base
def test_Base():
    try:
        b = Base()  # All attempts to instantiate should fail
    except AssertionError:
        pass
    else:
        assert 0, "Expected AssertionError"



# Generated at 2022-06-23 16:07:03.551261
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    """
    Test method generate_matches of class NegatedPattern.
    """
    from test_pattern_matcher import _make_nodes

    # Test when content is not None.
    nodes = _make_nodes([1, 2, 3])

    # Test when the argument pattern has matches
    p = NodePattern(type=1)
    result = list(p.generate_matches(nodes))
    assert result == [(1, {})], result

    n = NegatedPattern(p)
    result = list(n.generate_matches(nodes))
    assert result == [], result

    # Test when the argument pattern has no matches
    p = NodePattern(type=4)
    result = list(p.generate_matches(nodes))
    assert result == [], result

    n = NegatedPattern

# Generated at 2022-06-23 16:07:11.835590
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    from astroid import nodes
    from astroid import test_utils
    from astroid import builder
    from astroid import exceptions
    """
    Test pre_order method.
    """
    r = test_utils.build_module('''
    def func(x):
        return x * 3
    \n''', __name__)
    testnode = r.body[0]
    testnode_method_pre_order = list(testnode.pre_order())
    assert testnode_method_pre_order[0].__class__ == nodes.FunctionDef
    assert testnode_method_pre_order[0].root() is testnode
    assert testnode_method_pre_order[1].__class__ == nodes.Assign

# Generated at 2022-06-23 16:07:14.446363
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """
    Test method __repr__ of class BasePattern.

    """
    pass



# Generated at 2022-06-23 16:07:20.453159
# Unit test for constructor of class Leaf
def test_Leaf():
    leaf = Leaf(1, 'test')

    assert leaf.type == 1
    assert leaf.value == 'test'
    assert leaf.prefix == ''
    assert leaf.fixers_applied == None
    assert leaf.children == []
    #assert leaf.parent == None

    return leaf

# Module test for class Leaf methods

# Generated at 2022-06-23 16:07:24.734506
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    x = Node(255, [Leaf(0, "abc")])
    y = Leaf(0, "d")
    x.insert_child(0, y)
    assert y.parent is x
    assert y.prefix == "abc"
    assert x.children[0] is y
    assert x.children[1].prefix == ""



# Generated at 2022-06-23 16:07:31.461990
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    from . import pgen2
    from .pgen2.parser import Parser

    pgen = Parser()
    g = pgen.parse('if 1: pass')
    tree = g.st2t(g.symtable["file_input"], pgen.number2symbol)
    for pat in tree.post_order():
        pat.optimize()
    print(tree)



# Generated at 2022-06-23 16:07:39.971220
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    _Leaf = Leaf(13, 'x')
    _Leaf.parent = Node(15, [])
    _Leaf.bracket_depth = 1
    _Leaf.opening_bracket = Leaf(11, 'y')
    _Leaf.fixers_applied = ['f']
    _Leaf.used_names = {'a'}
    _Leaf._prefix = 'z'
    _Leaf.lineno = 1
    _Leaf.column = 13
    assert _Leaf.type == 13
    assert _Leaf.value == 'x'
    assert _Leaf.parent == Node(15, [])
    assert _Leaf.children == []
    assert _Leaf.bracket_depth == 1
    assert _Leaf.opening_bracket == Leaf(11, 'y')
    assert _

# Generated at 2022-06-23 16:07:41.325741
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    l = Leaf(0, "")
    assert list(l.pre_order()) == [l]

# Generated at 2022-06-23 16:07:45.406324
# Unit test for constructor of class BasePattern
def test_BasePattern():
    try:
        BasePattern()
    except TypeError as e:
        assert "Cannot instantiate BasePattern" == str(e)
    else:
        assert False, "Expected TypeError"



# Generated at 2022-06-23 16:07:53.952580
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    assert WildcardPattern().optimize() == NodePattern()
    assert WildcardPattern(content=None, min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(content=[[NodePattern()]], min=1, max=1).optimize() == NodePattern()
    assert WildcardPattern(content=[[NodePattern()]], min=1, max=3).optimize() == WildcardPattern(
        content=[[NodePattern()]], min=1, max=3
    )
    assert WildcardPattern(content=[[NodePattern()]], min=2, max=2).optimize() == WildcardPattern(
        content=[[NodePattern()]], min=2, max=2
    )

# Generated at 2022-06-23 16:08:05.629353
# Unit test for method depth of class Base
def test_Base_depth():
    from . import pytree
    from .pygram import python_symbols
    from .pgen2 import driver

    grow_grammar = driver.load_grammar("Growable.gram")
    grow_parser = driver.Parser(grow_grammar, "expr_context")

# Generated at 2022-06-23 16:08:08.180800
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # We never match a node in its entirety
    assert not NegatedPattern().match(None)
    assert not NegatedPattern().match(Node(type=1))

# Generated at 2022-06-23 16:08:15.666410
# Unit test for constructor of class NodePattern
def test_NodePattern():
    n = NodePattern(type=257, content=[LeafPattern(type=1, name='a'),
                                       LeafPattern(type=1, name='b'),
                                       LeafPattern(type=1, name='c')])
    assert n.type == 257
    assert len(n.content) == 3
    assert n.content[0].type == 1
    assert n.content[0].name == 'a'
    assert n.content[1].type == 1
    assert n.content[1].name == 'b'
    assert n.content[2].type == 1
    assert n.content[2].name == 'c'



# Generated at 2022-06-23 16:08:21.255053
# Unit test for constructor of class Node
def test_Node():
    # Almost trivial -- just test the two values set by the constructor
    node = Node(257, [])
    assert node.type == 257
    assert node.children == []

    # Test that invalid type raises an exception
    with pytest.raises(AssertionError, match="< 256"):
        node = Node(256, [])



# Generated at 2022-06-23 16:08:28.677674
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    # Test for method __repr__ (BasePattern.__repr__)
    assert repr(NodePattern(TEST)) == 'NodePattern(TEST)'
    assert repr(NodePattern(TEST, 'foo')) == 'NodePattern(TEST, \'foo\')'
    assert repr(NodePattern(TEST, NAME)) == 'NodePattern(TEST, NAME)'
    assert repr(NodePattern(TEST, 'foo', 'bar')) == 'NodePattern(TEST, \'foo\', \'bar\')'
    assert repr(NodePattern(TEST, NAME, 'bar')) == 'NodePattern(TEST, NAME, \'bar\')'
    assert repr(LeafPattern('x')) == "LeafPattern('x')"

# Generated at 2022-06-23 16:08:36.731713
# Unit test for method clone of class Node
def test_Node_clone():

    from .pytree import Leaf, Node

    n = Node(0, [Leaf(1, 'a'), Leaf(2, 'b'), Leaf(3, 'c')])
    m = n.clone()
    assert n is not m
    assert n == m
    assert n[0] is not m[0]
    assert n[1] is not m[1]
    assert n[2] is not m[2]



# Generated at 2022-06-23 16:08:41.420557
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    class_name = Node.__name__
    node = Node(1, [])
    assert repr(node) == f"{class_name}(1, [])"
    node1 = Node(1, [])
    return node

# Generated at 2022-06-23 16:08:53.154144
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from .compile import p_node

    s = p_node("foo", "bar", "baz")
    w1 = WildcardPattern([[s], [s], [s]], min=0, max=HUGE)
    assert isinstance(w1.content[0][0], NodePattern)
    w2 = WildcardPattern([[w1], [w1], [w1]], min=0, max=HUGE)
    assert isinstance(w2.content[0][0], WildcardPattern)
    w3 = w2.optimize()
    assert isinstance(w3.content[0][0], NodePattern)
    w4 = WildcardPattern([[s], [s], [s]], min=1, max=1)
    assert isinstance(w4.content[0][0], NodePattern)
    w

# Generated at 2022-06-23 16:08:57.705304
# Unit test for function generate_matches
def test_generate_matches():
    import _ast
    from collections import Counter
    from typing import Iterable


# Generated at 2022-06-23 16:09:03.691717
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pgen2.parse import ParseError
    import sys, os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), "lib2to3"))
    from . import pytree, pygram, pytoken
    from .pygram import python_symbols as syms
    from .pgen2 import driver, token
    from io import StringIO

# Generated at 2022-06-23 16:09:08.291476
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    bp = BasePattern()
    assert not bp.match_seq([])
    assert not bp.match_seq([Leaf(1, "")])
    assert bp.match_seq([Leaf(1, ""), Leaf(1, "")])

# Generated at 2022-06-23 16:09:18.307269
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from .pgen2 import token

    t1, t2, t3, t4 = [Leaf(token.NAME, "x") for i in range(4)]
    assert list(
        WildcardPattern().generate_matches([t1, t1])
    ) == [(0, {}), (1, {}), (2, {})]

    assert list(
        WildcardPattern(min=1).generate_matches([t1, t1])
    ) == [(0, {}), (1, {}), (2, {})]

    assert list(
        WildcardPattern(min=2).generate_matches([t1, t1])
    ) == [(2, {})]


# Generated at 2022-06-23 16:09:24.051464
# Unit test for function generate_matches
def test_generate_matches():
    q = {}
    p1 = NodePattern(type=token.NAME)
    p2 = NodePattern(type=token.NAME)
    p = WildcardPattern([p1, p2])
    c = compile("x = 1", "?", "exec")

# Generated at 2022-06-23 16:09:34.859341
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    pattern = WildcardPattern(content=[[Leaf(token.NAME, 'fred')],
                                       [Leaf(token.NAME, 'wilma'),
                                        Leaf(token.NAME, 'betty')]])
    nodes = [Leaf(token.NAME, 'fred'),
             Leaf(token.NAME, 'wilma'),
             Leaf(token.NAME, 'betty'),
             Leaf(token.NAME, 'fred'),
             Leaf(token.NAME, 'wilma'),
             Leaf(token.NAME, 'betty'),
             Leaf(token.NAME, 'betty')]
    got = [m[0] for m in pattern.generate_matches(nodes)]
    expected = [0, 1, 2, 3, 4, 5, 6]
    assert expected == got, (expected, got)



# Generated at 2022-06-23 16:09:38.874276
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.parse import BasePattern
    bp = BasePattern()
    try:
        bp.__repr__()
    except NotImplementedError:
        pass



# Generated at 2022-06-23 16:09:43.148744
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    tree = pytree.Node(0, [])
    tree.invalidate_sibling_maps()
    assert not hasattr(tree, 'prev_sibling_map')
    assert not hasattr(tree, 'next_sibling_map')


# Generated at 2022-06-23 16:09:53.697800
# Unit test for method set_child of class Node
def test_Node_set_child():
    from lib2to3.pgen2 import token
    from lib2to3.pygram import python_symbols
    from lib2to3.pgen2 import driver
    from lib2to3.pgen2 import parse
    from pytree import Leaf, Node, type_repr
    import io
    import unittest
    class Test(unittest.TestCase):
        def test_Node_set_child_1(self):
            p = driver.Driver(grammar=parse.grammar, convert=parse.convert)
            f = io.StringIO('x = 1')
            t = p.parse_tokens(f.readline)
            node = t.children[0]
            child = Leaf(token.EQUAL, '=')
            node.set_child(1, child)

# Generated at 2022-06-23 16:09:55.990893
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    p = LeafPattern(1, "foo", "bar")
    assert p.type == 1
    assert p.content == "foo"
    assert p.name == "bar"



# Generated at 2022-06-23 16:10:02.362873
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    assert BasePattern().optimize() is BasePattern()
    assert NodePattern(1).optimize() is NodePattern(1)
    assert LeafPattern(1).optimize() is LeafPattern(1)
    assert WildcardPattern().optimize() is WildcardPattern()
    assert AndPattern(1).optimize() is AndPattern(1)
    assert NotPattern(1).optimize() is NotPattern(1)
    assert ComparePattern(1).optimize() is ComparePattern(1)
    assert CallbackPattern(1).optimize() is CallbackPattern(1)


# Generated at 2022-06-23 16:10:11.006850
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    assert LeafPattern(token.NAME, "foo").type == token.NAME
    assert LeafPattern(content="foo").type is None
    assert LeafPattern(content="foo").content == "foo"
    assert LeafPattern(name="foo").name == "foo"
    for arg in (42, {}, (1, 2)):
        try:
            LeafPattern(arg)
        except (TypeError, AssertionError):
            pass
        else:
            raise AssertionError("LeafPattern(%r) didn't fail" % (arg,))



# Generated at 2022-06-23 16:10:18.473813
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    import ast
    import six

    def get_ast(source) -> ast.AST:
        "Compile the source, return the resulting AST node."
        gr = driver.Driver(grammar=ast.grammar, convert=convert).grammar
        parser = gr.parser("eval")
        return cast(ast.AST, parser.parse(source))

    assert isinstance(get_ast("2"), Leaf)
    assert isinstance(get_ast("2 + 3"), Node)

    # Expression has one child
    expr = get_ast("(2)")
    assert isinstance(expr.children[0], Leaf)

    # Expression has three children
    stmt = get_ast("expr1; expr2; expr3")
    assert len(stmt.children) == 3



# Generated at 2022-06-23 16:10:23.693833
# Unit test for constructor of class Base
def test_Base():
    class FakeNode(Base):
        def __init__(self):
            self.parent = None
            self.children = []

        def _eq(self, other):
            return False

        def clone(self):
            return FakeNode()

        def post_order(self):
            yield self

        def pre_order(self):
            yield self

        @property
        def prefix(self):
            return ""

    FakeNode()

    class FakeLeaf(Base):
        type = 1

        def __init__(self, value):
            self.value = value
            self.parent = None
            self.children = []

        def _eq(self, other):
            return self.value == other.value

        def clone(self):
            return FakeLeaf(self.value)

        def post_order(self):
            yield

# Generated at 2022-06-23 16:10:27.340009
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    Node._test_changed = False
    Node._test_children = [1,2,3]
    Node._test_parent = None
    Node.invalidate_sibling_maps()
    print("PASS: test_Node_invalidate_sibling_maps")



# Generated at 2022-06-23 16:10:35.701907
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    c2c = LeafPattern.match
    from .pgen2.token import tok_name

    assert c2c(Leaf(1, "a"), None) is False  # Type does not match
    assert c2c(Leaf(2, "a"), None) is False  # Content does not match
    assert c2c(Leaf(2, "b"), None) is True
    assert c2c(Leaf(2, "b", name="a"), {"a": None}) is False  # Name already exists
    assert c2c(Leaf(2, "b", name="b"), {"a": None}) is True  # Name does not exist
    # Should return True and update results with Leaf(b, "b", None)

# Generated at 2022-06-23 16:10:45.043613
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    n1 = LeafPattern(type=DEDENT)
    n2 = LeafPattern(type=NEWLINE)
    p1 = NodePattern(type=expr_context, content=[n1, n2])
    p2 = NodePattern(type=stmt, content=[p1])
    p3 = NegatedPattern()
    p4 = NegatedPattern(p2)
    test_nodes = [
        [DEDENT, NEWLINE, NEWLINE, NEWLINE],
        [DEDENT, NEWLINE, NEWLINE, ELLIPSIS, NEWLINE, NEWLINE],
        [DEDENT, NEWLINE, NEWLINE, ELLIPSIS, NEWLINE, NEWLINE, ELLIPSIS, NEWLINE],
    ]
    for nodes in test_nodes:
        print(p3.generate_matches(nodes))
        print

# Generated at 2022-06-23 16:10:56.181865
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    # Should return false
    assert NegatedPattern().match(
                Node(1, [
                    Node(3, [
                        Leaf(2, "This"),
                        Leaf(2, "is"),
                        Leaf(2, "not"),
                        Leaf(2, "empty")
                    ])
                ]),
                None
            ) == False, "Should return false"
    # Should return false

# Generated at 2022-06-23 16:10:58.540793
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    pat = BasePattern()
    assert repr(pat) == 'BasePattern(None, None, None)'



# Generated at 2022-06-23 16:11:05.565277
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    try:
        b.clone()
        raise AssertionError("Clone failed to raise exception!")
    except NotImplementedError as e:
        pass
    try:
        b.post_order()
        raise AssertionError("post_order failed to raise exception!")
    except NotImplementedError as e:
        pass
    try:
        b.pre_order()
        raise AssertionError("pre_order failed to raise exception!")
    except NotImplementedError as e:
        pass



# Generated at 2022-06-23 16:11:11.761221
# Unit test for constructor of class NodePattern
def test_NodePattern():
    class MyList(list):
        """Dummy class to check that NodePattern constructor accepts lists."""
    dummy = [None]
    p = NodePattern(content=dummy)
    assert p.content is dummy

    p = NodePattern(content=MyList(dummy))
    assert isinstance(p.content, list)
    assert p.content == dummy


# Generated at 2022-06-23 16:11:18.423557
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    from .pytree import Leaf
    node = Node(0, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")])
    node.update_sibling_maps()
    assert node.prev_sibling_map[id(node.children[1])] is node.children[0]
    assert node.next_sibling_map[id(node.children[1])] is node.children[2]
    assert node.prev_sibling_map[id(node.children[2])] is node.children[1]
    assert node.next_sibling_map[id(node.children[2])] is None
    assert node.prev_sibling_map[id(node.children[0])] is None

# Generated at 2022-06-23 16:11:29.031288
# Unit test for method optimize of class WildcardPattern
def test_WildcardPattern_optimize():
    from .nodes import Name

    p = WildcardPattern([[WildcardPattern()]], min=1, max=2, name="name")
    assert p.optimize() == WildcardPattern(None, min=1, max=2, name="name")

    p = WildcardPattern([[WildcardPattern(Name)]], min=1, max=2, name="name")
    assert p.optimize() == WildcardPattern(
        [[NodePattern(type=token.NAME, name="name")]],
        min=1,
        max=2,
        name="name",
    )


# A "positive lookahead assertion" pattern only matches if the
# subpattern matches.  It consumes no nodes.
#
# Originally this was implemented via a negative lookahead assertion
# (starts with '~').  However, this can yield counterintuitive

# Generated at 2022-06-23 16:11:37.131710
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    assert LeafPattern(type=1).match(Leaf(1, ""))
    assert not LeafPattern(type=2).match(Leaf(1, ""))
    assert not LeafPattern(type=1).match(Node(1, []))
    assert LeafPattern(1).match(Leaf(1, ""))
    assert not LeafPattern(1).match(Leaf(2, ""))
    assert not LeafPattern(1).match(Node(1, []))
    assert LeafPattern(1, "", "name").match(Leaf(1, ""), {})
    assert LeafPattern(1, "").match(Leaf(1, ""), {})
    assert not LeafPattern(1, "").match(Leaf(1, "2"), {})
    assert LeafPattern(1, "").match(Leaf(1, "2"), {})

# Generated at 2022-06-23 16:11:48.788409
# Unit test for method post_order of class Base
def test_Base_post_order():
    root = ast.parse('[x for x in range(10)]')
    l = list(root.post_order())

# Generated at 2022-06-23 16:11:53.345426
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    x = NodePattern(foo, 1, 2)
    assert x.optimize() is x
    assert isinstance(x.optimize(), NodePattern)
    assert x.optimize().type == foo
    assert x.optimize().content == (1, 2)
    assert x.optimize().name is None

