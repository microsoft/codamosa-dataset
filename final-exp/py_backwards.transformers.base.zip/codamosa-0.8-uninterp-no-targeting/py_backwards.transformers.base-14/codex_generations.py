

# Generated at 2022-06-21 17:24:15.152152
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert BaseNodeTransformer.transform is BaseTransformer.transform
    assert BaseNodeTransformer.transform is not ast.NodeTransformer.transform
    assert isinstance(BaseNodeTransformer().__init__, ast.NodeTransformer.__init__)
    assert BaseNodeTransformer.dependencies == []
    assert BaseNodeTransformer._tree_changed is False

# Generated at 2022-06-21 17:24:20.449174
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('_py2to3', '_six'),
        ]
    tree = ast.parse('''
    from py2to3.something import a, b, c''')
    expected = ast.parse('''
    try:
        from py2to3.something import a, b, c
    except ImportError:
        from six.something import a, b, c''')
    result = TestImportRewrite.transform(tree)
    assert result.tree == expected.body[0]



# Generated at 2022-06-21 17:24:21.992383
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer()
    assert obj.target == None
    assert BaseTransformer.transform(obj, ast.AST) == TransformationResult(ast.AST, False, [])


# Generated at 2022-06-21 17:24:25.495712
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ast import parse
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from ..visitors.visitor import Visitor

    tree = parse("""
import asyncio
from asyncio import Queue
async def foo():
    pass
    """)

    class TestTransformer(BaseNodeTransformer):
        def visit_AsyncFunctionDef(self, node):
            node.name = "bar"
            return node

    tr_node: 'Visitor' = TestTransformer(tree)
    tr_node.visit(tree)

# Generated at 2022-06-21 17:24:26.271067
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:24:31.253312
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    expected = """dependencies = []
    target = None
    @classmethod
    @abstractmethod
    def transform(cls, tree: ast.AST) -> TransformationResult:
        ...
    """

    actual = astunparse.unparse(ast.parse(inspect.getsource(BaseTransformer)))
    assert expected == actual



# Generated at 2022-06-21 17:24:32.714573
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None


# Generated at 2022-06-21 17:24:33.868306
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None


# Generated at 2022-06-21 17:24:44.250066
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import types
    import sys
    import astor

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PY2
        rewrites = [
            ('os', 'os'),
            ('sys', 'sys')]

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

    # Prepare tree
    source = '''\
import os
from os.path import join
import sys

os.path.join("support4py3k")
'''

    tree = ast.parse(source)

    # Test if replace import works
    result = TestTransformer.transform(tree)
    tree = result.tree
    assert result.tree_changed is True
    assert TestTransformer.dependencies == ['types']

# Generated at 2022-06-21 17:24:47.254617
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        pass

    assert Test.transform(ast.parse('', mode='exec')).changed is False

# Generated at 2022-06-21 17:24:54.811907
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()

# Generated at 2022-06-21 17:25:03.368444
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    assert 'from distutils.dep_util import newer_group' == ast.dump(
        ast.parse(
            'from distutils.dep_util import newer_group',
            mode='exec'))
    assert 'from setuptools.dep_util import newer_group' == ast.dump(
        ast.parse(
            'from setuptools.dep_util import newer_group',
            mode='exec'))

    class MockImportRewrite(BaseImportRewrite):
        rewrites = [('distutils', 'setuptools')]


# Generated at 2022-06-21 17:25:10.924290
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from ..transformers.imports import typed_ast

    # example
    code = """
import math
from math import cos, sin, pi
import numpy as np
from numpy import array
from numpy import asarray
"""

    # Initialization
    tree = ast3.parse(code)
    # trans = BaseImportRewrite()

    # # exeption
    # try:
    #     trans.visit_Import(node = tree.body[0])
    # except Exception as ex:
    #     print(ex)
    # # result
    # node = tree.body[0]
    # print(node)
    # print(node.names[0].asname)

    # exeption
    # try:
    #     trans.visit_ImportFrom(node = tree

# Generated at 2022-06-21 17:25:12.073077
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    base_import_rewrite = BaseImportRewrite()
    assert base_import_rewrite is not None, 'BaseImportRewrite constructor should return a class instance.'

# Generated at 2022-06-21 17:25:16.965644
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Rewrite1(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib2')]

    class Rewrite2(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib2')]

    class Rewrite3(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib2')]

    class Rewrite4(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib2')]

    class Rewrite5(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib2')]

    class Rewrite6(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib2')]

   

# Generated at 2022-06-21 17:25:17.829589
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target is None



# Generated at 2022-06-21 17:25:29.559906
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-21 17:25:32.606618
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert not callable(BaseTransformer.transform)


# Generated at 2022-06-21 17:25:40.663386
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import typed_ast.ast3 as typed_ast

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('requests', 'urllib.request'),
        ]

    class Test(ImportRewrite):
        pass

    source = """
        import a.b as c
        from d import e
        from d.f.g import h as i, j
        from d.f.g import k
        from d.f.g import l as m
        from d import o, p
        import q.r as s
        import t
    """

    tree = typed_ast.parse(source)
    assert not astor.to_source(Test.transform(tree).tree)

    source = """
        from requests import get
        from requests.exceptions import RequestException
    """

   

# Generated at 2022-06-21 17:25:41.793288
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer
    assert transformer.target == None

# Generated at 2022-06-21 17:26:00.218279
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from textwrap import dedent

    from ..utils.ast import parse_ast, unparse

    class ExampleTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('bar', 'baz')]

    class_source = dedent('''
        import foo
        def test():
            import bar
        ''')

    expected = dedent('''
        try:
            import foo
        except ImportError:
            import bar
        def test():
            try:
                import bar
            except ImportError:
                import baz
        ''')

    tree = parse_ast(class_source)
    res = ExampleTransformer.transform(tree)

    assert res.tree_changed
    assert unparse(res.tree) == expected



# Generated at 2022-06-21 17:26:05.901732
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.codetree import from_snippet
    from astunparse import unparse

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves')
        ]

    tree = from_snippet("""
        import six
        """)

    tree = Rewrite.transform(tree).tree
    assert unparse(tree) == """
try:
    import six
except ImportError:
    import six.moves as six
""".strip()



# Generated at 2022-06-21 17:26:07.320449
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-21 17:26:18.431404
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    from future.utils import with_metaclass

    class RealBaseImportRewrite(with_metaclass(BaseImportRewrite, object)):
        rewrites = [
            ('foo', 'bar')
        ]

    class TestBaseImportRewriteModule(unittest.TestCase):
        def test_base_base_import_rewrite(self):
            tree = ast.parse(
                """
try:
    import foo
except ImportError:
    import bar
""")
            transformer = RealBaseImportRewrite(tree)
            rewrited = transformer.visit_Import(tree.body[0].body[0])
            self.assertEqual(rewrited, tree)


# Generated at 2022-06-21 17:26:27.977933
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [("scipy.spatial.distance", "scipy.spatial.dist")]
        def visit_FunctionDef(self, node):
            return node
        def visit_Assign(self, node):
            return node
        def visit_AugAssign(self, node):
            return node
        def visit_Print(self, node):
            return node
        def visit_For(self, node):
            return node
        def visit_While(self, node):
            return node
        def visit_If(self, node):
            return node
        def visit_With(self, node):
            return node
        def visit_Raise(self, node):
            return node

# Generated at 2022-06-21 17:26:38.571837
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import enum
    import enum34
    import typing
    import typing_extensions
    from enum import IntEnum as base_IntEnum
    from enum import Enum as base_Enum
    from enum34 import IntEnum as enum34_IntEnum
    from enum34 import Enum as enum34_Enum
    from typing import Dict as typing_Dict
    from typing import List as typing_List
    from typing import Tuple as typing_Tuple
    from typing import Union as typing_Union
    from typing_extensions import Dict as typing_extensions_Dict
    from typing_extensions import List as typing_extensions_List
    from typing_extensions import Tuple as typing_extensions_Tuple
    from typing_extensions import Union as typing_extensions_Union

# Generated at 2022-06-21 17:26:45.528297
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from lib2to3.fixer_util import Name
    from typing import List

    class Rewrite(BaseImportRewrite):
        rewrites = [('x', 'y')]

    node = ast.Import(names=[ast.alias(name='x')])

    expected = ast.Try(
        body=[ast.Import(names=[ast.alias(name='y')])],
        handlers=[ast.ExceptHandler(type=Name('ImportError', prefix=' '),
                                    name=Name('e', prefix=' '),
                                    body=[ast.Import(names=[ast.alias(name='x')])])],
        orelse=[],
        finalbody=[])

    actual = Rewrite.transform(node).tree
    assert actual == expected



# Generated at 2022-06-21 17:26:53.946716
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    cls = BaseImportRewrite()
    assert isinstance(cls, BaseImportRewrite)
    assert not hasattr(cls, 'visit')
    assert not hasattr(cls, 'visit_Call')
    assert not hasattr(cls, 'visit_ImportFrom')
    assert isinstance(cls, ast.NodeTransformer)
    assert hasattr(cls, 'generic_visit')

# Generated at 2022-06-21 17:27:06.355310
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from collections import OrderedDict
    from ..compilation_targets import PY35

    class TestImportRewrite(BaseImportRewrite):
        target = PY35
        rewrites = [('copyreg', 'pickle')]

    node = ast.Import(names=[ast.alias(name="copyreg",
                                       asname="copyreg")])

# Generated at 2022-06-21 17:27:10.341148
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Example(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]

    assert Example.__name__ == 'Example'

# Generated at 2022-06-21 17:27:35.951774
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import get_node_snapshot

    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = [
        ('from_import', 'to_import')]

    before = ast.parse('from from_import import name1 as name2')
    after = ast.parse('from to_import import name1 as name2')

    import_rewrite.visit(before)

    assert get_node_snapshot(before) == get_node_snapshot(after)

    before = ast.parse('from from_import.submodule import name1 as name2')
    after = ast.parse('from to_import.submodule import name1 as name2')

    import_rewrite.visit(before)


# Generated at 2022-06-21 17:27:49.175272
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest

    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [('sys', 'os')]

    class TestBaseImportRewrite(unittest.TestCase):
        def test_module_rewrite(self):
            # Using from module import *
            node = ast.ImportFrom(module='sys', names=[ast.alias(name='*', asname=None)], level=0)
            expected_module_rewrite = 'os'
            # Using from module import name
            node_names = ast.ImportFrom(module='sys', names=[ast.alias(name='version', asname=None)], level=0)
            expected_names_rewrite_module = 'os'
            expected_names_rewrite_name = 'version'
            # Using from module import name as alias
            node_

# Generated at 2022-06-21 17:27:58.673919
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..test_utils import transform, assert_equal

    tree = ast.parse("from foo import bar")
    transformer = BaseImportRewrite()
    transform(transformer, tree, BaseImportRewrite.rewrites, [("foo", "x")])
    assert_equal(astor.to_source(tree),
                 """import_rewrite(
    previous=ast.ImportFrom(
        module='foo',
        names=[
            ast.alias(
                name='bar',
                asname=None)],
        level=0),
    current=ast.ImportFrom(
        module='x',
        names=[
            ast.alias(
                name='bar',
                asname=None)],
        level=0))
""")

# Generated at 2022-06-21 17:28:05.619402
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    from ..utils.nodes import ImportFrom

    class TestableImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]


# Generated at 2022-06-21 17:28:07.177201
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    try:
        BaseNodeTransformer(ast.parse(''))
    except TypeError:
        pytest.fail('Unexpected failure in BaseNodeTransformer constructor')

# Generated at 2022-06-21 17:28:19.864150
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    ast_module = ast.parse('from foo import a, b, c\nfrom foo import *\nimport foo')
    result = TestRewrite.transform(ast_module)
    assert result.changed

    expected = ['try:\n',
                '    from foo import a, b, c\n',
                'except ImportError:\n',
                '    from bar import a, b, c\n',
                'try:\n',
                '    from foo import *\n',
                'except ImportError:\n',
                '    from bar import *\n',
                'try:\n',
                '    import foo\n',
                'except ImportError:\n',
                '    import bar']
    assert astor.to

# Generated at 2022-06-21 17:28:30.468069
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def check(original, expected):
        # type: (str, str) -> None
        node = ast.parse(original).body[0]  # type: ast.ImportFrom
        assert isinstance(node, ast.ImportFrom)
        transformer = BaseImportRewrite(ast.parse(''))
        new_node = transformer.visit_ImportFrom(node)
        assert isinstance(new_node, ast.ImportFrom)
        assert ast.dump(new_node) == expected

    check("from six import moves", "from six import moves")
    check("from six.moves import urllib", "from urllib import urllib")
    check("from six import moves as six_moves", "from six import moves as six_moves")

# Generated at 2022-06-21 17:28:33.811507
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer()
    assert transformer._tree is None
    assert transformer._tree_changed is False


# Generated at 2022-06-21 17:28:42.454745
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__doc__ == 'BaseImportRewrite(tree) -> None\n'
    assert BaseImportRewrite.transform.__doc__ == 'transform(cls, tree: ast.AST) -> TransformationResult\n'

    assert BaseImportRewrite.rewrites == []
    assert BaseImportRewrite.dependencies == []
    assert BaseImportRewrite.target == None
    assert BaseImportRewrite.__bases__ == (BaseNodeTransformer,)

    # Test inherited methods
    tr = BaseImportRewrite
    tr.rewrites = ['previous', 'current']
    assert tr._get_matched_rewrite('previous') == ('previous', 'current')

# Generated at 2022-06-21 17:28:49.222254
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    def _test_BaseTransformer(test_instance, target, other_attrs=None):
        assert isinstance(test_instance, BaseTransformer)
        assert test_instance.target == target
        if other_attrs:
            for attr in other_attrs:
                assert hasattr(test_instance, attr)
        return True
    
    class BaseTransformerSubclass(BaseTransformer):
        target = 'example'
        def transform(self, tree):
            return tree
    test_instance = BaseTransformerSubclass()
    assert _test_BaseTransformer(test_instance, target='example')

# Generated at 2022-06-21 17:29:40.039783
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO: Write unit test for method visit_Import of class BaseImportRewrite
    pass


# Generated at 2022-06-21 17:29:40.846750
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-21 17:29:48.811244
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_rewrite = [
        ('a', 'b')
    ]
    import_from = ast.ImportFrom(
        module='a.c',
        names=[
            ast.alias(name='Foo', asname='Bar'),
            ast.alias(name='Baz'),
            ast.alias(name='Qux', asname='Quux')],
        level=0)

    class TestRewrite(BaseImportRewrite):
        rewrites = import_from_rewrite
        dependencies = []  # type: List[str]

    tree = ast.parse('a = object()')
    tree.body.insert(1, import_from)
    result = TestRewrite.transform(tree)
    rewrote = result.tree.body[1]

    assert isinstance(rewrote, ast.Try)

# Generated at 2022-06-21 17:29:58.611459
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import functools")
    original_tree = ast.copy_location(ast.Module(body=[tree]))

    result = BaseImportRewrite.transform(original_tree)

    assert result.tree == original_tree
    assert result.changed is False

    tree = ast.parse("import asyncio.futures")
    original_tree = ast.copy_location(ast.Module(body=[tree]))

    result = BaseImportRewrite.transform(original_tree)

    assert result.tree == original_tree
    assert result.changed is False



# Generated at 2022-06-21 17:29:59.392631
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-21 17:30:01.865003
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('x=1')
    cls = BaseNodeTransformer(tree)



# Generated at 2022-06-21 17:30:10.552277
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    import json

    node = ast.parse('import module')
    rewrites = [('module1', 'module1.new')]
    result = astunparse.unparse(BaseImportRewrite(node).visit_Import(node.body[0]))

# Generated at 2022-06-21 17:30:17.117482
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # Instantiate a class that derives BaseNodeTransformer
    class DerivedClass(BaseNodeTransformer):
        pass
    tree = ast.parse("a = 1")
    derived = DerivedClass(tree)
    assert isinstance(derived._tree, ast.AST)
    assert derived._tree == tree

# Unit tests for class BaseImportRewrite

# Generated at 2022-06-21 17:30:26.262643
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BaseImportRewrite2(BaseImportRewrite):
        rewrites = []

    # Testing if BaseNodeTransformer is parent class of BaseImportRewrite
    assert issubclass(BaseImportRewrite2, BaseNodeTransformer)
    # Testing constructor
    BaseImportRewrite2("a")
    # Testing instance
    assert isinstance(BaseImportRewrite2("a"), BaseImportRewrite)


# Generated at 2022-06-21 17:30:27.339581
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer


# Generated at 2022-06-21 17:31:08.226137
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()


# Generated at 2022-06-21 17:31:20.472487
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    from typed_ast.ast3 import Import, alias
    from ..utils.test_utils import TTransformerTestCase

    import_node = Import(names=[alias(name='foo', asname='bar')])
    tree = ast.Module(body=[import_node])

    class ImportRewrite1(BaseImportRewrite):
        target = 1
        rewrites = [('foo', 'foo1')]

    class ImportRewrite2(BaseImportRewrite):
        target = 1
        rewrites = [('foo', 'foo1'), ('bar', 'bar1')]

    class ImportRewrite3(BaseImportRewrite):
        target = 1
        rewrites = [('foo.bar', 'foo1.bar1')]


# Generated at 2022-06-21 17:31:32.111340
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Unit test for method visit_ImportFrom of class BaseImportRewrite"""
    class_ = BaseImportRewrite
    tree = ast.parse('from re import match, search')
    class_._get_matched_rewrite = lambda self, name: ('re', '_re') if name == 're' else None
    node = tree.body[0]

# Generated at 2022-06-21 17:31:40.070360
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-21 17:31:44.490519
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass
    assert TestTransformer.transform(None) == TransformationResult(None, False, [])

# Generated at 2022-06-21 17:31:45.854280
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # TODO:
    pass

# Generated at 2022-06-21 17:31:51.124841
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..transformer import BaseNodeTransformer
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)

    bnt = BaseNodeTransformer()
    assert bnt is not None

    # tree gets a value when it is initialized
    assert bnt._tree
    assert issubclass(BaseNodeTransformer, BaseTransformer)


#Unit test for the constructor of class BaseTransformer

# Generated at 2022-06-21 17:31:58.991125
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest

    class TestClass(unittest.TestCase):
        def test_before(self):
            orig = ast.parse("from Test import Test1, Test2")
            transformer = BaseImportRewrite()
            result = transformer.visit_ImportFrom(orig.body[0])
            expected = ast.parse("from Test import Test1, Test2")
            self.assertEqual(ast.dump(result,
                                      include_attributes=True),
                             ast.dump(expected,
                                      include_attributes=True))

        def test_before_ast3(self):
            orig = ast.parse("from Test import Test1, Test2")
            transformer = BaseImportRewrite()
            result = ast.fix_missing_locations(transformer.visit_ImportFrom(orig.body[0]))


# Generated at 2022-06-21 17:32:04.341970
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert not BaseImportRewrite.rewrites
    assert not BaseImportRewrite.dependencies
    assert BaseImportRewrite.target is None
    assert BaseImportRewrite.transform is BaseNodeTransformer.transform

# Generated at 2022-06-21 17:32:15.505442
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-21 17:33:52.483052
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # assert BaseTransformer()
    assert BaseTransformer.transform is BaseTransformer.transform

# Generated at 2022-06-21 17:34:00.963377
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from pprint import pprint

    class Test(BaseImportRewrite):
        target = CompilationTarget('.')
        rewrites = [
            ('a.b', 'x.y'),
            ('a.b.c', 'x.y.z')
        ]

    class NewModuleForTest:
        def __init__(self, tree: ast.AST) -> None:
            self.node = ast.parse(
                """import a.b
                from a.b.c import c
                from a.b.c import x
                from a.b import x
                import a.b.x
                """)

    test = NewModuleForTest(None)
    pprint(Test.transform(test.node))

# Generated at 2022-06-21 17:34:04.137189
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class SampleImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
