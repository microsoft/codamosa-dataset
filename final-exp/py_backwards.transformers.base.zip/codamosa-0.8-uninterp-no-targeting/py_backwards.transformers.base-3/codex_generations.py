

# Generated at 2022-06-21 17:24:17.412673
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-21 17:24:18.260744
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    print(BaseNodeTransformer)

# Generated at 2022-06-21 17:24:23.508763
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # class BaseNodeTransformer(BaseTransformer, ast.NodeTransformer):
    #     dependencies = []  # type: List[str]
    #     def __init__(self, tree: ast.AST) -> None:
    #         super().__init__()
    #         self._tree = tree
    #         self._tree_changed = False
    # class BaseImportRewrite(BaseNodeTransformer):
    #     rewrites = []  # type: List[Tuple[str, str]]
    BaseImportRewrite({})

# Generated at 2022-06-21 17:24:34.369121
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import textwrap
    from ..typing import Text

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]

    class List:
        pass

    code = textwrap.dedent("""
    from a.b import c
    from a.b.d import e, f as f_
    """)

    result = textwrap.dedent("""
    from a.b import c
    from a.b.d import e, f as f_
    """)

    ast_tree = ast.parse(code)

    tr = TestImportRewrite(ast_tree)
    tr.visit(ast_tree)

    ast.fix_missing_locations(ast_tree)

# Generated at 2022-06-21 17:24:42.384468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # type: () -> None
    class TestNodeTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz.qux')]

    tree = ast.parse('''
import foo.bar
bar.baz()
''')
    TestNodeTransformer.transform(tree)

    assert ast.dump(tree) == dedent('''
    try:
        import foo.bar as bar
    except ImportError:
        import baz.qux as bar

    bar.baz()
    ''')



# Generated at 2022-06-21 17:24:43.932923
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('12', '<stdin>', 'eval')
    BaseNodeTransformer(tree)

# Generated at 2022-06-21 17:24:49.876805
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..version import get_version
    __version__ = get_version()

    class SomeTransformer(BaseImportRewrite):
        rewrites = [('base', 'new_base')]

    code = """
    from base.base2 import f1, f2
    import base.base2.f3
    from base.base2 import f4
    from base.base2 import f5 as f5_alias
    from base import base2
    from . import base2
    """
    tree = ast.parse(code)
    SomeTransformer.transform(tree)
    code_result = astor.to_source(tree)


# Generated at 2022-06-21 17:24:51.894110
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .builtin_classes import BaseBuiltinClass
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)


# Generated at 2022-06-21 17:24:58.360002
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from ..utils.ast import node_from_string

    import_from = node_from_string('''
        from fcntl import lockf
    ''') # type: ast.ImportFrom

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ("fcntl", "fcntl-redone")
        ]

    result = Rewrite.transform(import_from)
    print(result.root)
    print(result.changed)
    assert result.changed


# Generated at 2022-06-21 17:24:59.848950
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    #Test constructor
    obj = BaseTransformer()
    assert obj != None


# Generated at 2022-06-21 17:25:16.878571
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as std_ast
    import typing

    def set_source(node, source):
        node._source = source
        return node


# Generated at 2022-06-21 17:25:22.183384
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            return ast.Name(id='user',
                            ctx=ast.Load())

    tree = ast.parse("""
    import os
    import json as json

    a = os.path.join(1)
    b = json.loads()
    """, '<string>', 'exec')
    res = TestTransformer.transform(tree)
    assert res.tree == ast.parse("""
    import os
    import json as json

    a = user()
    b = user()
    """, '<string>', 'exec')



# Generated at 2022-06-21 17:25:34.211760
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import delete, extend
    from ..utils.tests import assert_transform, parse

    class Transformer(BaseImportRewrite):
        rewrites = [('os', 'posix')]

    before_str = """\
import os
import sys
"""
    expected_str = """\
try:
    import os
except ImportError:
    import posix as os
import sys
"""
    actual_str = assert_transform(Transformer, before_str, expected_str)

    actual = parse(actual_str)
    expected = parse(before_str + '\n' + expected_str)
    delete(expected, 'Import', lambda node: node.names[0].name == 'os')

    assert astor.to_source(actual) == astor.to_source(expected)

# Generated at 2022-06-21 17:25:36.163133
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = None  # type: ast.AST
    trans = BaseNodeTransformer(tree)

# Generated at 2022-06-21 17:25:47.447027
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typing
    import six
    tree = ast.parse(
        """
        import typing
        import six
        """)

    class Mock(BaseImportRewrite):
        rewrites = [
            ('typing', 'typing_extensions')
        ]

    transformer = Mock(tree)
    transformer.visit(tree)

    assert transformer._get_matched_rewrite('typing') == ('typing', 'typing_extensions')
    assert transformer._get_matched_rewrite('six') is None
    assert transformer._tree_changed is True

    expected = ast.parse(
        """
        try:
            import typing
        except ImportError:
            import typing_extensions as typing
        import six
        """)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-21 17:25:48.307502
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass

# Generated at 2022-06-21 17:25:49.720307
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1')
    assert BaseNodeTransformer(tree)._tree is tree
    # we can visit tree
    assert BaseNodeTransformer(tree).visit(tree) is tree


# Generated at 2022-06-21 17:25:54.424710
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    with pytest.raises(TypeError) as excinfo:
        BaseNodeTransformer()
    assert 'Can\'t instantiate abstract class BaseNodeTransformer' in str(excinfo.value)


# Generated at 2022-06-21 17:25:58.127837
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None

    transformer = BaseTransformer(CompilationTarget.PYPY)
    assert transformer.target is CompilationTarget.PYPY



# Generated at 2022-06-21 17:26:04.958122
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("""
    from django.db.models import *
    from django.db import models
    import models""")
    result = BaseImportRewrite.transform(tree)
    assert result.tree == ast.parse("""
    try:
        from django.db.models import *
    except ImportError:
        from django.apps.models import *

    try:
        from django.db import models
    except ImportError:
        from django.apps import models

    import models""")

# Generated at 2022-06-21 17:26:17.831872
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer is BaseTransformer
    assert BaseTransformer.target is None
    assert BaseTransformer.transform is BaseTransformer.transform


# Generated at 2022-06-21 17:26:23.033653
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('module_a', 'module_b'),
            ('module_c', 'module_d')]

    tree = ast.parse('import module_a')
    result = TestTransformer.transform(tree)
    assert result.changed


# Generated at 2022-06-21 17:26:27.230145
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from .utils import get_node
    
    # Checks if module name is changed
    node = get_node("from xxx import yyy as zzz")
    rewrites = [('xxx', 'kkk')]
    
    class ImportRewrite(BaseImportRewrite):
        rewrites = rewrites
    
    result = astor.to_source(ImportRewrite(node).visit(node), indent_with=' ' * 4)
    expectation = textwrap.dedent("""
    try:
        from xxx import yyy as zzz
    except ImportError:
        from kkk import yyy as zzz
    """).strip()
    
    assert result == expectation

    # Checks if module + name is changed

# Generated at 2022-06-21 17:26:38.271839
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    @snippet
    def test_visit_Import_rewrite_import():
        # input
        import previous
        # expected
        try:
            extend(previous)
        except ImportError:
            extend(current)

    @snippet
    def test_visit_Import_rewrite_import_as():
        # input
        import previous as backported
        # expected
        try:
            extend(previous)
        except ImportError:
            extend(current)

    @snippet
    def test_visit_Import_rewrite_import_nested_module():
        # input
        import previous.nested
        # expected
        try:
            extend(previous.nested)
        except ImportError:
            extend(current.nested)


# Generated at 2022-06-21 17:26:44.403941
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..compiler import Compiler
    from ..utils.source import source

    tree = ast.parse(source("""
from typed_ast.ast3 import  # noqa
import typing
from typing import Optional
from os.path import join
from  typing import Dict, List
from django.conf import settings
"""))
    compiler = Compiler(target=CompilationTarget.PY35)
    compiler._compilers.append(BaseImportRewrite)
    compiler.transpile_tree(tree)

# Generated at 2022-06-21 17:26:49.611665
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        target = 'dummy'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    assert DummyTransformer.target == 'dummy'

# Generated at 2022-06-21 17:26:56.215894
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import astropy

    class T(BaseImportRewrite):
        rewrites = [('astropy', 'astropy.units')]

    T.transform(ast.parse('import astropy')) == TransformationResult(
        tree = ast.parse('try:\n    import astropy\nexcept ImportError:\n    import astropy.units'),
        tree_changed = True,
        dependencies = [],
    )



# Generated at 2022-06-21 17:27:00.835564
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .transformer_test import _test_BaseImportRewrite_visit_Import

    _test_BaseImportRewrite_visit_Import(BaseImportRewrite, lambda: import_rewrite)


# Generated at 2022-06-21 17:27:05.328003
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    base_import_rewrite = BaseImportRewrite()
    assert base_import_rewrite.rewrites == []
    assert base_import_rewrite.dependencies == []
    assert isinstance(base_import_rewrite, BaseNodeTransformer)

# Generated at 2022-06-21 17:27:10.227837
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import astor
    source = '''
    import flask
    import flask.blueprints
    from flask import (
        app,
        json_response,
    )
    '''
    tree = ast.parse(source)
    node_transformer = BaseImportRewrite(tree)
    node_transformer.visit(tree)

    print(astor.to_source(tree))
    assert False

# Generated at 2022-06-21 17:27:40.493355
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from .test_utils import CodegenAstVisitor

    old_name = 'old_name'
    new_name = 'new_name'

    rewriter = BaseImportRewrite([])
    rewriter.rewrites = [old_name, new_name]

    tree = ast3.parse(
        'import old_name\n'
    )

    rewriter.visit(tree)
    cg = CodegenAstVisitor()
    rewriter.visit(tree)
    assert cg.code == (
        'try:\n' +
        '    import old_name as old_name\n' +
        'except ImportError:\n' +
        '    import new_name as old_name\n'
    )

# Generated at 2022-06-21 17:27:44.461281
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    try:
        BaseNodeTransformer(1)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 17:27:56.746862
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    node = ast.ImportFrom(
        module='my_module',
        names=[ast.alias(name='my_name', asname='my_asname')],
        level=1)
    BaseImportRewrite.rewrites = [('.*', 'foo.$2')]
    BaseImportRewrite.transform(node)
    assert isinstance(node, ast.Try)
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == 'foo.my_module'
    assert node.body[0].names[0].name == 'my_name'
    assert node.body[0].names[0].asname == 'my_asname'
    assert node.body[1].body[0].value.func.id == 'ImportError'

# Generated at 2022-06-21 17:27:58.758280
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None


# Generated at 2022-06-21 17:28:01.853726
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..ast import def_ast
    import ast
    assert isinstance(BaseImportRewrite(def_ast), ast.AST)


# Generated at 2022-06-21 17:28:04.059588
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__doc__ is not None


# Generated at 2022-06-21 17:28:12.502794
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import_from_original = ast.ImportFrom(
        module='test.module',
        names=[
            ast.alias(name='test_import')
        ],
        level=0)

    import_from_rewrite_module = ast.ImportFrom(
        module='new.module',
        names=[
            ast.alias(name='test_import')
        ],
        level=0)
    
    import_from_rewrite_name = ast.ImportFrom(
        module='new.module',
        names=[
            ast.alias(name='new_import')
        ],
        level=0)

    import_from_rewrite_module_and_name = ast.ImportFrom(
        module='new.module',
        names=[
            ast.alias(name='new_import')
        ],
        level=0)



# Generated at 2022-06-21 17:28:13.913257
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite


# Generated at 2022-06-21 17:28:20.948405
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [('previous.module', 'current.module')]
    test_code = ast.parse('import previous.module')
    target = CompilationTarget.CPython

    class TestTransformer(BaseImportRewrite):
        target = target
        rewrites = rewrites

    transformed = TestTransformer.transform(test_code)[0]
    expected = ast.parse('try:\n    import previous.module\nexcept ImportError:\n    import current.module')
    assert ast.dump(transformed) == ast.dump(expected)


# Generated at 2022-06-21 17:28:22.627113
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert "from sys import *" == str(BaseImportRewrite().visit_ImportFrom(ast.parse("from sys import *").body[0]))



# Generated at 2022-06-21 17:28:46.981884
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            if node.id == 'hello':
                return ast.Str(s='world')
            return node

    tree = ast.parse('hello')
    transformer = MyTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer._tree_changed != tree

# Generated at 2022-06-21 17:28:58.476418
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse("""
        import old

        import old.submodule.subsubmodule

        import not-rewritten

        import not-rewritten.submodule.subsubmodule
    """)

    result = TestImportRewrite.transform(tree)

    assert result.tree == ast.parse("""
        try:
            import old
        except ImportError:
            import new

        try:
            import old.submodule.subsubmodule
        except ImportError:
            import new.submodule.subsubmodule

        import not-rewritten

        import not-rewritten.submodule.subsubmodule
    """)



# Generated at 2022-06-21 17:28:59.578609
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert BaseTransformer.transform(None) is None

# Generated at 2022-06-21 17:29:06.297319
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor

    result = astor.to_source(ast.parse('import urllib.parse'))
    expected = 'import urllib.parse\n'
    assert result == expected

    result = astor.to_source(ast.parse('import urllib.parse as parse'))
    expected = 'import urllib.parse as parse\n'
    assert result == expected

    class Transformer(BaseImportRewrite):
        rewrites = [('urllib', 'urllib3')]

    result = astor.to_source(Transformer.transform(ast.parse('import urllib.parse')).tree)
    expected = 'try:\n    import urllib.parse\n' \
               'except ImportError:\n    import urllib3.parse\n'

# Generated at 2022-06-21 17:29:10.726598
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    src1 = 'from re import search'
    src2 = 'from re import findall'
    src3 = 'from re import (search, findall)'
    src4 = 'from re import *'
    src5 = 'from regex import regex, regexp'
    src6 = 'from regex import regex as regexp'
    src7 = 'from regex import regex, regex as regexp'
    src8 = 'from regex import (regex, regex as regexp)'
    src9 = 'from regex import regex, regexp'
    src10 = 'from regex import regex as regexp, regexp'
    src11 = 'from regex import regex, regex as regexp, regexp'
    src12 = 'from regex import (regex, regex as regexp, regexp)'
    src13 = 'from regex import regex'
   

# Generated at 2022-06-21 17:29:15.313750
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """Simple test to check that constructor of class BaseNodeTransformer"""
    """returns instance of BaseNodeTransformer"""
    src = "print('Hello World')"
    tree = ast.parse(src)
    assert isinstance(BaseNodeTransformer(tree), BaseNodeTransformer)


# Generated at 2022-06-21 17:29:26.971898
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestRewrite(BaseImportRewrite):
        rewrites = [('a', 'b'), ('d', 'e')]

    import_node = ast.parse("import a.b").body[0]
    actual = TestRewrite.transform(import_node)

    # check that rewrite is successful
    import_node = ast.parse("try:\n  import a.b\nexcept ImportError:\n  import b.b").body[0]
    expected = TestRewrite.transform(import_node)

    assert isinstance(actual.tree, ast.Try)
    assert actual == expected

    # check that rewrite is not successful
    import_node = ast.parse("import c.b").body[0]
    expected = TestRewrite.transform(import_node)

    assert not isinstance(actual.tree, ast.Try)


# Generated at 2022-06-21 17:29:37.976490
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    import typed_ast.ast3 as ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module'),
            ('old_module.submodule', 'new_module.submodule')]

    class TestCase(unittest.TestCase):
        tree = ast.parse("import old_module\n")

        def test_rewrite_import(self):
            new_tree = TestImportRewrite.transform(self.tree).tree
            self.assertEqual(ast.dump(self.tree), "Module(body=[Import(names=[alias(name='old_module', asname=None)])])")

# Generated at 2022-06-21 17:29:41.304290
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer._tree == None
    assert BaseNodeTransformer._tree_changed == False

# Unit tests for class BaseImportRewrite

# Generated at 2022-06-21 17:29:48.958286
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Example(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('bar', 'baz')
        ]

    # test 1, simple module name change
    tree = ast.parse("import foo")
    result, _, _ = Example.transform(tree)
    rewritten = ast.parse("""try:
    extend(import foo)
except ImportError:
    extend(import bar)""")
    assert ast.dump(result) == ast.dump(rewritten)

    # test 2, simple module name change with alias
    tree = ast.parse("import baz as foo")
    result, _, _ = Example.transform(tree)
    rewritten = ast.parse("""try:
    extend(import baz as foo)
except ImportError:
    extend(import bar as foo)""")
   

# Generated at 2022-06-21 17:30:29.920861
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  BaseTransformer()

# Generated at 2022-06-21 17:30:31.464769
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite()

# Generated at 2022-06-21 17:30:38.438644
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class ExternalTransformer(BaseNodeTransformer):
        dependencies = []

        def visit_FunctionDef(self, node):
            return node

    tree = ast.parse('pass')

    result = ExternalTransformer.transform(tree)

    assert isinstance(result, TransformationResult)
    assert result.changed is False
    assert result.dependencies == []


# Generated at 2022-06-21 17:30:41.741956
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # pylint: disable=no-value-for-parameter
    assert BaseImportRewrite()

# Generated at 2022-06-21 17:30:49.257535
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor

    class testnode (BaseNodeTransformer):
        def visit_Print(self, node):
            self._tree_changed = True
            return ast.Import(names=[ast.alias(name='os', asname='o')])

    module = ast.parse('''print('name')''')
    module = testnode.transform(module)
    assert(str(module.tree) == "import os as o")
    assert(module.dependencies == [])
    assert(module.changed)

# Generated at 2022-06-21 17:30:53.031679
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class T(BaseTransformer):
        @classmethod
        def transform(cls, tree):
            return "transform"
    assert T.transform("test") == "transform"

# Generated at 2022-06-21 17:30:58.528661
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestClass(BaseTransformer):
    # Check that the abstract method is there
        assert 'transform' in BaseTransformer.__abstractmethods__
        assert 'transform' in TestClass.__abstractmethods__
        # Check attribute exists
        assert hasattr(TestClass, 'target')

# Generated at 2022-06-21 17:31:10.272427
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class TestTransformer(BaseImportRewrite):

        rewrites = [('a.b.c', 'z.y.x')]


# Generated at 2022-06-21 17:31:20.858973
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    module = ast.parse('''
from mockito import mockito
from mockito.mockito import VerificationError
from ast import ast
from astor import super_ast
''')

    transformer = BaseImportRewrite()
    assert astor.to_source(transformer.visit(module)) == '''
try:
    from mockito import mockito
except ImportError:
    from mockito_apt import mockito
try:
    from mockito.mockito import VerificationError
except ImportError:
    from mockito_apt.mockito import VerificationError
try:
    from ast import ast
except ImportError:
    from astor import ast
from astor import super_ast
'''


# Generated at 2022-06-21 17:31:32.265260
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from textwrap import dedent

    class ImportsRewrite(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    class ImportRewriteTest(unittest.TestCase):
        def test_Import(self):
            code = dedent('''
                import six.moves
            ''')
            tree = ast.parse(code)
            result = ImportsRewrite.transform(tree)
            self.assertTrue(result.transformed)
            self.assertEqual(result.dependencies, ['six'])

# Generated at 2022-06-21 17:33:25.680911
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        pass

    with pytest.raises(TypeError):
        A()

# Generated at 2022-06-21 17:33:27.038944
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    BaseTransformer()

# Generated at 2022-06-21 17:33:31.364539
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse('from os.path import join, isabs')
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('os.path', 'pathlib'),
        ]
    transformer = Transformer(node)
    result = transformer.visit_ImportFrom(node.body[0])
    assert ast.dump(result) == "try:\n    from os.path import join, isabs\nexcept ImportError:\n    from pathlib import join, isabs"

# Generated at 2022-06-21 17:33:32.687075
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import numpy as np")
    assert isinstance(BaseImportRewrite.transform(tree), TransformationResult)



# Generated at 2022-06-21 17:33:41.882047
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import mymodule
    class Test(BaseImportRewrite):
        rewrites = [('mymodule', 'newmodule')]

    node = ast.parse("import mymodule").body[0]
    assert isinstance(node, ast.Import)

    try:
        mymodule.exit
    except AttributeError:
        exception_raised = True
    else:
        exception_raised = False

    new_node = Test.visit_Import(Test(None), node)
    # assert is equal because old and new names are the same
    assert str(new_node) == str(node)
    assert not exception_raised
    assert Test._tree_changed



# Generated at 2022-06-21 17:33:46.108063
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    import os  # noqa
    sys.path.append(os.path.dirname(__file__))
    import BaseImportRewrite

# Generated at 2022-06-21 17:33:54.469631
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = ast.parse('import foo')
    transformer = BaseImportRewrite(module)
    tranformer._get_matched_rewrite = lambda x: ('foo', 'bar')
    rewrite = transformer.visit_Import(module.body[0])
    assert type(rewrite) == ast.Try
    assert type(rewrite.body[0]) == ast.Import
    assert rewrite.body[0].names[0].name == 'bar'
    assert rewrite.handlers[0].type.id == 'ImportError'
    assert type(rewrite.handlers[0].body[0]) == ast.Import
    assert rewrite.handlers[0].body[0].names[0].name == 'foo'


# Generated at 2022-06-21 17:33:58.767084
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # create_BaseImportRewrite
    try:
        BaseImportRewrite()
    except TypeError:
        pass
    else:
        raise AssertionError
    # test_BaseImportRewrite
test_BaseImportRewrite()