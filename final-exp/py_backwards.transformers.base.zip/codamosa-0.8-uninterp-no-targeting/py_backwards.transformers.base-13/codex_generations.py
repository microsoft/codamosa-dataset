

# Generated at 2022-06-21 17:24:25.271727
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from . import lib
    node = ast.ImportFrom(level=0, module='_io', names=[ast.alias(name='FileIO', asname=None)])
    a = lib.BaseImportRewrite(node)
    a._get_matched_rewrite('_io.FileIO')
    BaseImportRewrite.rewrites = [('_io', 'io')]
    b = lib.BaseImportRewrite(node)
    b._get_matched_rewrite('_io.FileIO')


# Generated at 2022-06-21 17:24:32.273974
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from tests.test_transformer import TestTransformer
    from ..types import CompilationTarget
    from ..utils.ast import find_classes, find_class

    # prepare
    t = TestTransformer()

    # act
    b = BaseNodeTransformer(None)
    b._tree_changed = True

    # assert
    classes = find_classes(t.transform(b._tree),
                           CompilationTarget.python,
                           BaseNodeTransformer)
    assert b.__class__ in classes



# Generated at 2022-06-21 17:24:42.987594
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class A(BaseImportRewrite):
        rewrites = [
            ('pyschool.foo', 'pyschool.bar')
        ]

    assert ast.dump(
        A.transform(ast.parse('''
        import pyschool.foo
        ''')).tree) == 'Module(body=[Try(body=[Import(names=[[alias(name=\'pyschool.bar\', asname=None)]])], orelse=[], finalbody=[], handlers=[ImportError(name=None, lineno=2, col_offset=4)], lineno=2, col_offset=4)])'


# Generated at 2022-06-21 17:24:45.692831
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class test_BaseTransformer(BaseTransformer):
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass
    tree = ast.AST()
    result = test_BaseTransformer.transform(tree)
    assert(result != None)


# Generated at 2022-06-21 17:24:56.043087
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('.foo', '.bar')]


# Generated at 2022-06-21 17:24:56.570410
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:24:57.840395
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-21 17:25:05.498974
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typing

    # method visit_ImportFrom returns ast.Try node with try statement that
    # contains original ImportFrom node and except ImportError branch with
    # transformed ImportFrom node
    cls = BaseImportRewrite  # type: ignore
    cls.rewrites = [('django', 'dummy')]
    node = ast.parse('''from django.db.models import *''').body[0]
    
    output = cls.visit_ImportFrom(cls, node)
    assert isinstance(output, ast.Try)
    assert len(output.body) == 1
    assert isinstance(output.body[0], ast.ImportFrom)
    assert output.body[0].module == 'django.db.models'
    assert output.body[0].names == node.names


# Generated at 2022-06-21 17:25:07.493110
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('print(1)')
    assert BaseNodeTransformer(tree=tree) is not None



# Generated at 2022-06-21 17:25:08.162816
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:25:19.937894
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer 


# Generated at 2022-06-21 17:25:21.366315
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(None)



# Generated at 2022-06-21 17:25:34.189948
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class A(BaseImportRewrite):
        rewrites = [('b.c', 'd.e')]

    class B(BaseImportRewrite):
        rewrites = [('b.c', 'd.e')]

    class C(BaseImportRewrite):
        rewrites = [('b.c', 'd.e')]

    tree = ast.parse("""
from b import c
from b import d
from d.e import f
from d.e import f as g
""")

# Generated at 2022-06-21 17:25:37.241458
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    b = BaseTransformer()
    assert b.target == None
    assert isinstance(b, BaseTransformer)


# Generated at 2022-06-21 17:25:37.993548
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass



# Generated at 2022-06-21 17:25:39.007778
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert type(bt) == BaseTransformer

# Generated at 2022-06-21 17:25:40.082183
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None



# Generated at 2022-06-21 17:25:48.679459
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO: Move unit tests somewhere else
    import astor
    rewrite = BaseImportRewrite()
    assert astor.to_source(rewrite.visit(ast.parse("import foo"))) == "import foo"
    assert astor.to_source(rewrite.visit(ast.parse("import foo as bar"))) == "import foo as bar"

    rewrite.rewrites = [('foo', 'bar')]
    assert astor.to_source(rewrite.visit(ast.parse("import foo"))) == \
    """
    try:
        import foo
    except ImportError:
        import bar
    """

# Generated at 2022-06-21 17:25:50.132548
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(ast.Pass())

# Generated at 2022-06-21 17:26:00.293822
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..base import BaseImportRewrite, TransformError
    from ..types import CompilationTarget
    class MyTransformer(BaseImportRewrite):
        rewrites = [
            ('__future__', 'future'),
            ('future.builtins', 'builtins')
        ]

    inst = MyTransformer({})
    tests = [
        ast.parse('import __future__', mode='exec').body[0],
        ast.parse('import future.builtins', mode='exec').body[0],
        ast.parse('import __future__ as __f_bar__', mode='exec').body[0],
        ast.parse('import future.builtins as b', mode='exec').body[0],
        ast.parse('import unknown', mode='exec').body[0],
    ]


# Generated at 2022-06-21 17:26:14.382925
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.mock import mock
    from ..utils.mock import PropertyMock
    from ..utils.mock import call

    BaseNodeTransformer.__init__ = mock.Mock(return_value=None)

    BaseNodeTransformer(None)

    BaseNodeTransformer.__init__.assert_called_once_with(BaseNodeTransformer, None)
    assert BaseNodeTransformer.__init__.call_count == 1

# Generated at 2022-06-21 17:26:18.452485
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Foo(BaseNodeTransformer):
        pass
    assert Foo.__init__.__code__.co_varnames[1] == "tree"


# Generated at 2022-06-21 17:26:28.006842
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .rewrite_stdlib import BaseStdlibRewrite
    import typing

    class Rewrite(BaseImportRewrite):
        rewrites = [('six', 'six')]

    class StdlibRewrite(BaseStdlibRewrite):
        rewrites = [('six', 'six')]

    class StdlibRewriteWithAlias(BaseStdlibRewrite):
        rewrites = [('six', 'six')]

    class StdlibRewriteWithAlias2(BaseStdlibRewrite):
        rewrites = [('six', 'six')]


# Generated at 2022-06-21 17:26:29.034031
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-21 17:26:38.886094
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from .test_utils import parse, compare_ast

    class A(BaseImportRewrite):
        rewrites = [
            ('previous', 'current'),
        ]

    tree = parse('''
        from previous import import_name as alias
        from previous.subimport import name as alias
        from previous.subimport.subsub import name as alias
    ''')
    target = A()
    result = target.visit(tree)

# Generated at 2022-06-21 17:26:40.292688
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-21 17:26:42.207196
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    with pytest.raises(TypeError):
        BaseImportRewrite(0)

# Generated at 2022-06-21 17:26:44.626630
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        pass

    assert not DummyTransformer.target


# Generated at 2022-06-21 17:26:46.030823
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite('test')

# Generated at 2022-06-21 17:26:58.200666
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import re
    import sys
    # Method visit_Import with name
    rewriter = BaseImportRewrite()
    node = ast.parse('import re').body[0]
    node.names[0].name = 're'
    check = rewriter._replace_import(node, 're', 'regex')
    expected = ast.parse('''try:
    import re
except ImportError:
    import regex''').body[0]
    assert (check == expected)
    assert rewriter._tree_changed
    # Method visit_Import with name and alias
    node = ast.parse('import re as regex').body[0]
    node.names[0].name = 're'
    node.names[0].asname = 'regex'
    check = rewriter._replace_import(node, 're', 'regex')


# Generated at 2022-06-21 17:27:08.437847
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("""
import datetime
from os import *
from subprocess import *""")
    target = CompilationTarget.PY_3_3
    result = BaseNodeTransformer.transform(tree)
    assert not result.tree_changed
    assert result.dependencies == []
    assert result.tree == tree

# Generated at 2022-06-21 17:27:10.765723
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__subclasscheck__(BaseNodeTransformer)



# Generated at 2022-06-21 17:27:19.623903
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('''
from module import *
from module import a
from module import b as c
from module import a, b as c
from module import a as b, c as d
from module import a, b as c, d as e
from module import a as b, c as d, e as f
''')

# Generated at 2022-06-21 17:27:28.533827
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('old.module', 'new.module')
        ]

    import_stmt = ast.Import(
        names=[ast.alias(name='old.module')])
    result = TestTransformer.transform(import_stmt)
    assert result.tree.body[0].body[0].body[0].body[0].value.names[0].name == 'new.module'

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('old.module', 'new.module')
        ]

    import_stmt = ast.Import(
        names=[ast.alias(name='subold.module')])
    result = TestTransformer.transform(import_stmt)

# Generated at 2022-06-21 17:27:32.005124
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    t = BaseImportRewrite(None)
    assert t.rewrites == []



# Generated at 2022-06-21 17:27:36.877494
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse('a = 1 + 1')
    t = TestTransformer(tree)

    assert t._tree == tree
    assert not t._tree_changed

# Unit tests for method BaseNodeTransformer._get_matched_rewrite

# Generated at 2022-06-21 17:27:49.507335
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewrite_visit_Import_Transformer(BaseImportRewrite):
        rewrites = [('from_module', 'to_module')]


# Generated at 2022-06-21 17:27:53.977314
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-21 17:27:55.335998
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()



# Generated at 2022-06-21 17:28:02.425290
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._tree = tree
            self._tree_changed = False
        
        def visit(self, tree: ast.AST) -> TransformationResult:
            pass
        
        def generic_visit(self, tree: ast.AST) -> TransformationResult:
            pass
        
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)


# Generated at 2022-06-21 17:28:15.957271
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    print('Hello World')
    pass

# Generated at 2022-06-21 17:28:18.025535
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    new_cls = type('NewCls', (BaseTransformer,), {})
    assert new_cls


# Generated at 2022-06-21 17:28:23.571775
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Instantiate a BaseImportRewrite class
    import_rewrite = BaseImportRewrite()
    # Check the class attributes
    assert import_rewrite.rewrites is BaseImportRewrite.rewrites

test_BaseImportRewrite()

# Generated at 2022-06-21 17:28:34.461809
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from typed_ast import ast3 as ast
    import re
    from .transformer import BaseTransformer, BaseNodeTransformer
    from ..types import CompilationTarget, TransformationResult

    class FooTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON_27

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)

    tree = ast.parse('1 + 1')
    FooTransformer.transform(tree)

    class FooTransformer2(BaseNodeTransformer):
        target = CompilationTarget.PYTHON_27
        pass

# Generated at 2022-06-21 17:28:44.086142
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.Import(names=[
        ast.alias(name='foo.bar', asname='BAR')])

    rewriter = BaseImportRewrite([
        ('foo', 'foo_rewritten')])
    result = rewriter.visit_Import(node)

    expected = ast.Try(body=[
        ast.Import(names=[
                  ast.alias(name='foo.bar', asname='BAR')
              ])],
              handlers=[
                  ast.ExceptHandler(type=None, name=None, body=[
                      ast.Import(names=[
                          ast.alias(name='foo_rewritten.bar', asname='BAR')
                      ])
                  ])
              ],
              orelse=[],
              finalbody=[])


# Generated at 2022-06-21 17:28:47.611697
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            return 'constant'

    tree = ast.parse('1')
    result = TestTransformer.transform(tree)
    assert isinstance(result, TransformationResult)
    assert result.tree == tree

# Generated at 2022-06-21 17:28:56.142149
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from io import StringIO
    from test.test_utils import module_source, module_from_str

    source = 'from ast import parse'
    tree = module_from_str(source)

    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = [('ast', 'ast2')]

    MockBaseImportRewrite.transform(tree)

    assert module_source(tree) == 'from ast2 import parse'



# Generated at 2022-06-21 17:29:05.307709
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        class B(BaseTransformer):
            def method(self, arg:int) -> str:
                return 'test'

        class C(B):
            def method(self, arg:int) -> str:
                return super().method(arg)

    b = B()
    c = C()
    assert b.method(10) == 'test'
    assert c.method(10) == 'test'

# Generated at 2022-06-21 17:29:06.815481
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, ast.NodeTransformer)



# Generated at 2022-06-21 17:29:17.091298
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import compile_source
    from ..types import CompilationTarget

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.parse('''
from foo import x, a as b
from foo.bar import y
__all__ = ['x', 'y']
    ''')
    tree = ImportRewrite.transform(node).tree
    code = astor.to_source(tree)

    assert code == '''
try:
    from foo import x, a as b
except ImportError:
    from bar import x, a as b
try:
    from foo.bar import y
except ImportError:
    from bar.bar import y
__all__ = ['x', 'y']
    '''


# Generated at 2022-06-21 17:29:53.348659
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert str(BaseNodeTransformer(tree=None)) == '<BaseNodeTransformer _tree: None, _tree_changed: False>'


# Generated at 2022-06-21 17:30:01.024190
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import Snippet
    import textwrap
    import astor

    test_snippet = Snippet.find_snippet('test_BaseNodeTransformer.py')

    class TestNodeTransformer(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node.id += 'Transformed'
            self._tree_changed = True
            return node

    result = TestNodeTransformer.transform(ast.parse(textwrap.dedent(test_snippet.payload)))
    assert astor.to_source(result.tree) == """
    def aFunction():
        nameTransformed = 'Name'
        nameTransformed = 'Name'
    """.lstrip()
    assert result.tree

# Generated at 2022-06-21 17:30:04.271026
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
   # tree = ast.parse("print('Hello World!')")
    #assert BaseNodeTransformer.transform(tree) == None
    assert True

# Generated at 2022-06-21 17:30:09.992689
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test_str = """
    import ast
    import x
    from typing import List, Tuple, Union
    from .utils import copy_node
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    def f():
         pass
    """
    node = ast.parse(test_str)
    BaseNodeTransformer.visit(node)


if __name__ == '__main__':
    test_BaseNodeTransformer()

# Generated at 2022-06-21 17:30:13.633302
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    assert TestTransformer(None)._tree_changed == False


# Generated at 2022-06-21 17:30:21.175351
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from . import BaseImportRewrite
    from ..stubs import ast3 as ast
    # 1) Test for a return value of method _get_matched_rewrite
    BaseImportRewrite.rewrites = [('a', 'b')]
    BaseImportRewrite.target = CompilationTarget(3, 6)
    assert BaseImportRewrite._get_matched_rewrite(name=None) is None
    assert BaseImportRewrite._get_matched_rewrite(name='a') == ('a', 'b')
    assert BaseImportRewrite._get_matched_rewrite(name='a.b') == ('a', 'b')
    assert BaseImportRewrite._get_matched_rewrite(name='b') is None
    # 2) Test for a return value of method _get_names_to_replace
    import_ = ast.Import.parse

# Generated at 2022-06-21 17:30:28.125997
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import astunparse
    import textwrap
    node = ast.parse('from typing import *')
    transformer = BaseImportRewrite(None)
    new_node = transformer.visit(node)
    assert astunparse.unparse(node).strip() == textwrap.dedent('''
    from typing import *
    ''').strip()
    assert astunparse.unparse(new_node).strip() == textwrap.dedent('''
    try:
        from typing import *
    except ImportError:
        from typing_extensions import *''').strip()



# Generated at 2022-06-21 17:30:32.747317
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert not hasattr(BaseImportRewrite, 'target')
    assert not hasattr(BaseImportRewrite, 'rewrites')
    assert not hasattr(BaseImportRewrite, 'dependencies')

# Generated at 2022-06-21 17:30:38.451597
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Foo(BaseTransformer):
        pass
    assert Foo.target is None
    with pytest.raises(TypeError, match='Can\'t instantiate abstract class Foo'):
        _ = Foo()
    with pytest.raises(TypeError, match='Can\'t instantiate abstract class Foo'):
        Foo.transform(None)


# Generated at 2022-06-21 17:30:41.741985
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(None)
    assert issubclass(transformer.__class__, ast.NodeTransformer)

# Generated at 2022-06-21 17:31:21.261185
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    tree = astor.parse('import test')
    rewrite = BaseImportRewrite(tree)
    assert rewrite.visit(tree) == 'import test'

    tree = astor.parse('import test2 as test')
    rewrite = BaseImportRewrite(tree)
    assert rewrite.visit(tree) == 'import test2 as test'

    tree = astor.parse('import test as new_test')
    rewrite = BaseImportRewrite(tree)
    assert rewrite.visit(tree) == 'import test as new_test'

    tree = astor.parse('import test.test2')
    rewrite = BaseImportRewrite(tree)
    assert rewrite.visit(tree) == 'import test.test2'

    tree = astor.parse('import test.test2 as test')
    rewrite = BaseImport

# Generated at 2022-06-21 17:31:30.293656
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTestRewrite(BaseImportRewrite):
        rewrites = [('six', 'six1')]

    tree = ast.parse('import six')
    ImportTestRewrite.transform(tree)
    assert ast.dump(tree) == '''
    Try()
    ExceptHandler(type=None, name=None, body=[Import(names=[alias(name='six', asname=None)])])
    Import(names=[alias(name='six1', asname=None)])
    '''



# Generated at 2022-06-21 17:31:42.470242
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse('''
from module import foo
from module import bar as bar
from module import *
from package import module2
from package import module3 as module3
from package import *
from module import baz
from package.module2 import qux
''')
    assert BaseImportRewrite.transform(module).changed is False

    module = ast.parse('''
from ..module import foo
from ..module import bar as bar
from ..module import baz
from ..package import module2
from ..package.module2 import qux
from ..package import module3 as module3
from ..package import *
''')
    assert BaseImportRewrite.transform(module).changed is False


# Generated at 2022-06-21 17:31:44.650105
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite



# Generated at 2022-06-21 17:31:54.075953
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = '''
    from collections import namedtuple, defaultdict  # noqa
    from imports_to_rewrite import module_a
    from imports_to_rewrite.module_b import method_b
    from other_module import namedtuple
    '''
    tree = ast.parse(code)

    class ImportRewriter(BaseImportRewrite):
        rewrites = [
            ('imports_to_rewrite', 'rewritten_imports'),
            ('imports_to_rewrite.module_b', 'rewritten_imports.module_c'),
        ]

    rewriter = ImportRewriter(tree)
    rewriter.visit(tree)


# Generated at 2022-06-21 17:31:56.041716
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from . import ast_transformer
    BaseNodeTransformer(ast_transformer.get_tree())

# Generated at 2022-06-21 17:31:57.216084
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('x = 5')
    BaseNodeTransformer(tree)

# Generated at 2022-06-21 17:32:03.870415
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]

    tree = ast.parse('''
import foo
from a import bar, baz
from c import *
from a.a1 import a1
from unrewriten import *
''')

    expected = '''
try:
    import foo
except ImportError:
    pass
try:
    from b import bar
    from b import baz
except ImportError:
    from a import bar
    from a import baz
try:
    from d import *
except ImportError:
    from c import *
try:
    from b.a1 import a1
except ImportError:
    from a.a1 import a1
from unrewriten import *
'''


# Generated at 2022-06-21 17:32:07.555221
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    with pytest.raises(TypeError):
        BaseNodeTransformer()

    dummy = BaseNodeTransformer(None)
    assert dummy._tree is None

# Generated at 2022-06-21 17:32:13.902714
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import assert_transform
    import_ = ast.parse('import unittest').body[0]
    from_ = 'unittest'
    to = 'unittest.mock'
    rewrote = ast.parse('import unittest.mock').body[0]
    assert_transform(BaseImportRewrite(None), ast.Import, import_, rewrote, rewrites=[(from_, to)])


# Generated at 2022-06-21 17:32:53.063612
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import types
    import sys

    node = ast.parse('import foo.bar')
    transform = BaseImportRewrite(tree=None)
    transform.rewrites = [('foo.bar', 'foo.baz')]
    new_node = transform.visit_Import(node)

    assert isinstance(new_node, ast.Try)

    try_body = new_node.body
    assert len(try_body) == 1
    assert isinstance(try_body[0], ast.Import)
    import_node = try_body[0]
    assert len(import_node.names) == 1
    assert import_node.names[0].name == 'foo.baz'
    assert import_node.names[0].asname == 'bar'

    excepts = new_node.handlers

# Generated at 2022-06-21 17:33:03.731048
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse as unparser
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import ImportFrom

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo.utils', 'bar.utils')]

    node = ImportFrom(module='foo.utils', names=[ast.alias(name='whatever')], level=0)
    tree_changed, result = TestTransformer.transform(node)
    assert not tree_changed
    assert unparser.unparse(node) == unparser.unparse(result)

    node = ImportFrom(module='foo', names=[ast.alias(name='utils')], level=0)
    tree_changed, result = TestTransformer.transform(node)
    assert tree_changed

# Generated at 2022-06-21 17:33:10.493979
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import x')
    transformer = BaseImportRewrite(tree)
    assert isinstance(transformer.visit(tree), ast.Import)

    class T(BaseImportRewrite):
        rewrites = [('x', 'y')]

    tree = ast.parse('import x')
    transformer = T(tree)
    assert isinstance(transformer.visit(tree), ast.Try)



# Generated at 2022-06-21 17:33:22.566095
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..vendor.typed_ast import ast3 as ast

    class Test(BaseImportRewrite):
        rewrites = [('old_namespace', 'new_namespace')]
        target = CompilationTarget.PY_35

    # Simple import from
    module = ast.parse('from old_namespace import foo')

    Test.transform(module)

    assert(isinstance(module.body[0], ast.Try))
    assert(isinstance(module.body[0].body[0], ast.ImportFrom))
    assert(module.body[0].body[0].module == 'new_namespace')
    assert(module.body[0].body[0].names[0].name == 'foo')
    assert(isinstance(module.body[0].body[1], ast.ImportFrom))

# Generated at 2022-06-21 17:33:27.793249
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Foo(BaseNodeTransformer):
        pass
    inst = Foo(1)
    assert isinstance(inst, Foo)
    assert isinstance(inst, BaseNodeTransformer)
    assert inst.__class__.__name__ == "Foo"



# Generated at 2022-06-21 17:33:40.630921
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast as _ast # type: ignore
    import inspect

    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert hasattr(BaseNodeTransformer, 'transform')
    assert callable(BaseNodeTransformer.transform)

    assert issubclass(BaseNodeTransformer, _ast.NodeTransformer)

    assert hasattr(BaseNodeTransformer, '_get_matched_rewrite')
    assert hasattr(BaseNodeTransformer, '_replace_import')
    assert hasattr(BaseNodeTransformer, 'visit_Import')
    assert hasattr(BaseNodeTransformer, '_replace_import_from_module')
    assert hasattr(BaseNodeTransformer, '_get_names_to_replace')
    assert hasattr(BaseNodeTransformer, '_get_replaced_import_from_part')

# Generated at 2022-06-21 17:33:52.732601
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..bases import BaseImportRewrite
    import_from = ast.ImportFrom(module='six',
                                 names=[ast.alias(name='PY2', asname='PY2'),
                                        ast.alias(name='PY3', asname='PY3')],
                                 level=0)
    class rw(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    import_from_rewrite = rw.visit_ImportFrom(import_from)

# Generated at 2022-06-21 17:34:01.486030
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_2
        rewrites = [('some', 'com.example.some'), ('other', 'com.example.other')]

    tree = ast.parse(
"""
import mymodule
import othermodule


from mo.package import Class1, Class2
import sys

from mo.package import *
import os
""")

    res = MyTransformer.transform(tree)
    assert res.changed


# Generated at 2022-06-21 17:34:11.527611
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformers.sixer import six_import_rename_map
    from ..utils.visitor import print_node
    import six

    class ImportTransformer(BaseImportRewrite):
        rewrites = six_import_rename_map

    snippet = 'import six'
    tree = ast.parse(snippet)
    result = ImportTransformer.transform(tree)
    print_node(result.tree)

    snippet = 'import six as s'
    tree = ast.parse(snippet)
    result = ImportTransformer.transform(tree)
    print_node(result.tree)

    snippet = 'from six.moves import html_parser'
    tree = ast.parse(snippet)
    result = ImportTransformer.transform(tree)
    print_node(result.tree)
