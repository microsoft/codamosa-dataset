

# Generated at 2022-06-21 17:24:20.392641
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    AST = ast.parse(
        'import os',
        '<test_visit_Import>',
        'exec')

    class Rewrites(BaseImportRewrite):
        rewrites = [('os', 'importlib')]

    results = Rewrites().transform(AST)
    assert len(results) == 1
    assert results[0] == (
        'try:\n'
        '    import os\n'
        'except ImportError:\n'
        '    import importlib as os'
    )

    AST = ast.parse(
        'import os.path',
        '<test_visit_Import>',
        'exec')

    results = Rewrites().transform(AST)
    assert len(results) == 1

# Generated at 2022-06-21 17:24:23.827313
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTestTransformer(BaseTransformer):
        target = CompilationTarget.Python27

    class TestTransformer(BaseTestTransformer):
        @classmethod
        def transform(cls, tree):
            return

    assert TestTransformer.transform is not BaseTransformer.transform
    assert TestTransformer.target == CompilationTarget.Python27

# Generated at 2022-06-21 17:24:25.295100
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        def test(self):
            pass
    assert Transformer.target == 'base'
    assert Transformer().test() is None


# Generated at 2022-06-21 17:24:26.194342
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('')
    bnt = BaseNodeTransformer(tree)
    assert bnt._tree is tree

# Generated at 2022-06-21 17:24:29.735512
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import sys
    import ast
    target_tree = ast.parse(sys.getsource(BaseNodeTransformer))
    assert target_tree
    assert target_tree.body[0].lineno == 4

# Generated at 2022-06-21 17:24:41.580857
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    import ast
    # creating nodes
    node1 = ast3.ImportFrom(module='typing',
                            names=[ast3.alias(name='Optional', asname=None)],
                            level=0)
    node2 = ast3.ImportFrom(module='typing',
                            names=[ast3.alias(name='Callable', asname=None)],
                            level=0)
    node3 = ast3.ImportFrom(module='typing',
                            names=[ast3.alias(name='Union', asname=None)],
                            level=0)
    node4 = ast3.ImportFrom(module='typing',
                            names=[ast3.alias(name='Text', asname=None)],
                            level=0)
    node5 = ast3.Import

# Generated at 2022-06-21 17:24:43.527308
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class MyTransformer(BaseTransformer):
        target = 'python'

    transformer = MyTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:24:48.855033
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Replaces import re with try/except with import re and regex
    import astor
    import ast
    import re

    module = ast.parse('import re')
    expected_module = ast.parse('try:\n    import re\nexcept:\n    import regex')
    transformer = BaseImportRewrite(module)
    transformer.rewrites = [('re', 'regex')]
    transformer.visit(module)
    assert astor.to_source(module) == astor.to_source(expected_module)

    # Replacement works only when the module name is matched exactly
    module = ast.parse('import abc')
    expected_module = ast.parse('import abc')
    transformer = BaseImportRewrite(module)
    transformer.rewrites = [('re', 'regex')]
    transformer.visit(module)

# Generated at 2022-06-21 17:24:52.992279
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    A = BaseImportRewrite()
    assert type(A) is BaseImportRewrite
    assert A.rewrites == []
    assert A.dependencies == []

# Test for BaseImportRewrite.visit_Import
# This test checks if visit_Import works propertly when there is no
# match

# Generated at 2022-06-21 17:24:53.929975
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.transform(None).changed is False

# Generated at 2022-06-21 17:25:05.889346
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    rewrites = [("abc", "abc.def")]
    rewrites_extra = [("abc.extra", "abc.extra.def")]

    class _Mock(BaseImportRewrite):
        rewrites = rewrites

    class _MockExtra(BaseImportRewrite):
        rewrites = rewrites_extra


    # Check ImportFrom not changed
    module = ast.parse("import abc.extra")
    res = _Mock.transform(module)
    assert res.changed is False
    assert module == res.module

    # Check ImportFrom changed
    module = ast.parse("import abc.extra")
    res = _MockExtra.transform(module)
    assert res.changed is True
    assert modu

# Generated at 2022-06-21 17:25:06.448112
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:25:12.049617
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..tests.test_classes.test_transformers import BaseImportRewrite
    import ast
    import marshal
    original_ast = ast.parse("""
import datetime.time
from datetime import time
from datetime import time as t
from datetime import time, datetime
from datetime import *
from pkg.subpkg import submod
from pkg.subpkg.submod import *
from pkg.subpkg import *
import pkg.subpkg
import pkg.subpkg.submod as sm
from pkg.subpkg.submod import Class as Cls
from pkg.subpkg.submod import (Class as Cls, otherClass)
""")
    original_ast.body[-1].body[-1].body[-1] = ast.Expr(ast.Str('abc'))
    as_

# Generated at 2022-06-21 17:25:16.944646
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    current_script_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(current_script_dir, 'test_data/try_except/__init__.py'), 'rt') as f:
        test_data = ast.parse(f.read())

    # in __init__.py
    test_class = test_data.body[0]
    # in test_class
    function_a = test_class.body[0]
    # in function_a
    import_from = function_a.body[0]
    import_from_module = import_from.value
    assert type(import_from_module) == ast.ImportFrom


# Generated at 2022-06-21 17:25:28.535837
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astunparse
    from ..utils.typing import TypingSuite
    from ..transformers.stdlib import StdlibTransformer

    test_tree = ast.parse(TypingSuite.untyped_method)
    test_tree = StdlibTransformer.transform(test_tree).tree

    class Test(BaseNodeTransformer):
        def visit_Num(self, node):  # type: ignore
            self._tree_changed = True
            return ast.Str(s='visit_Num')

    test = Test(test_tree)
    test.visit(test_tree)

    # pylint: disable=no-member
    assert isinstance(test_tree.body[0].args.args[0], ast.Str)

# Generated at 2022-06-21 17:25:36.045114
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.mock import MockFile
    from .django_auth_users import DjangoAuthUsersImport
    
    
    source = '''
from django.contrib.auth.models import User
    '''
    expected = '''
try:
    from django.contrib.auth.models import User
except ImportError:
    from django.contrib.auth.models import User
    '''
    tree = ast.parse(source)

    with MockFile(DjangoAuthUsersImport.dependencies[0], 'contrib\n'):
        res = BaseImportRewrite.transform(tree)
        assert res.tree_changed and astor.to_source(res.tree) == expected

# Generated at 2022-06-21 17:25:47.395652
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Annotation types are not supported yet.
    from typed_ast.ast3 import AST

    rewrites = [('.py2', '.py3')]
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = rewrites
    import_tree = ast.parse('import typing.py2.A') # type: AST
    transformed_tree = TestBaseImportRewrite.transform(import_tree).tree
    expected_tree = ast.parse('try:\n    import typing.py2.A\nexcept ImportError:\n    import typing.py3.A')
    assert ast.dump(transformed_tree) == ast.dump(expected_tree)

    import_tree = ast.parse('import typing.py2') # type: AST
    transformed_tree = TestBaseImportRewrite.transform(import_tree).tree


# Generated at 2022-06-21 17:25:59.246201
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("from a.b.c import d as e")
    inst = BaseImportRewrite(tree)
    inst.rewrites = [('a.b', 'b.a')]
    res = inst.visit_ImportFrom(tree.body[0])
    assert isinstance(res, ast.Try)
    assert isinstance(res.body[0], ast.ImportFrom)
    assert res.body[0].module == 'b.a.c'
    assert res.body[0].names[0].name == 'd'
    assert res.body[0].names[0].asname == 'e'

    assert isinstance(res.body[1], ast.ImportFrom)
    assert res.body[1].module == 'b.a.c'
    assert res.body[1].names[0].name

# Generated at 2022-06-21 17:26:00.638197
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-21 17:26:06.820553
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typing import Tuple
    import astor
    from .base import make_tree

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('email', 'emails')]

    test_cases = [
        (
            'import email.mime.text',
            'import email.mime.text'
        ),
        (
            'import email',
            'try:\n    import email\nexcept ImportError:\n    import emails'
        )
    ]

    for code, expected in test_cases:
        tree = make_tree(code)
        tree = ImportRewrite.transform(tree)[0]
        assert astor.to_source(tree) == expected


# Generated at 2022-06-21 17:26:16.462738
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .python import PythonTransformer
    from .python.parser import PythonParser
    from ..utils import get_backend_name, get_backend_loader

    loader = get_backend_loader(get_backend_name())
    tree = PythonParser().get_ast('def hello(): print("hello")')
    PythonTransformer(loader=loader).transform(tree)
    assert isinstance(tree, ast.Module)

# Generated at 2022-06-21 17:26:19.520650
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
   pass
   # TODO: Write unit test for constructor of class BaseTransformer


# Generated at 2022-06-21 17:26:27.250514
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..tests.utils import compile_snippet
    from ..utils import get_logger
    logger = get_logger(__name__)
    target = CompilationTarget.PYTHON

# Generated at 2022-06-21 17:26:27.690284
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:26:34.822358
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  assert issubclass(BaseTransformer, ABCMeta)
  assert BaseTransformer.target == None

  tree = ast.parse("print(1)")
  class TestTransformer(BaseTransformer):
    @classmethod
    def transform(cls, tree: ast.AST) -> TransformationResult:
      return tree
  assert TestTransformer.transform(tree) == tree



# Generated at 2022-06-21 17:26:38.140813
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert_is_instance(BaseNodeTransformer(None), ast.NodeTransformer)

# Generated at 2022-06-21 17:26:45.864379
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transformer = BaseImportRewrite()

    node = ast.ImportFrom(module='os',
                          names=[ast.alias(name='path', asname='path')],
                          level=0)
    transformer.rewrites = [('os.path', 'os.path.x')]
    new_node = transformer.visit_ImportFrom(node)
    assert isinstance(new_node, ast.Try)
    assert new_node.body[0].names == [ast.alias(name='os.path.x', asname='path')]

    node = ast.ImportFrom(module='os',
                          names=[ast.alias(name='path', asname='path')],
                          level=0)
    transformer.rewrites = [('os', 'os.x')]
    new_node = transformer.visit_ImportFrom

# Generated at 2022-06-21 17:26:58.107426
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from genty import genty, genty_dataset
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget

    # I couldn't get mypy to work with this, so as a workaround
    # I use ast.parse and use its result as type information.
    tree = ast.parse('from dateutil import parser')

    @genty
    class Test(object):
        def test_no_rewrite_needed(self):
            # Test simple case, when no rewrite is needed.
            class RewriteTransformer(BaseImportRewrite):
                rewrites = [('a', 'b')]

            tree_ = RewriteTransformer.transform(tree).tree

            assert str(tree_) == str(tree)


# Generated at 2022-06-21 17:26:58.575673
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass

# Generated at 2022-06-21 17:27:01.869013
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]  # noqa
    
    nodes = ast.parse("import abc; import abcde")
    Transformer.transform(nodes)
    assert nodes == ast.parse("""try:
    import abc
except ImportError:
    import c.d

import abcde""")

# Generated at 2022-06-21 17:27:09.510558
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..js_converter import transform
    from ..js_types import JsCompiler

    input_ = 'import cv2'
    res = JsCompiler.compile(input_, "file.py")
    print(res)
    assert res == input_

# Generated at 2022-06-21 17:27:16.589605
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'foobar')]
        dependencies = ['foobar']

    tree = ast.parse("from foo.bar import a, b")
    result = ast.parse("from foobar import a, b")

    assert result == MyImportRewrite.transform(tree).tree



# Generated at 2022-06-21 17:27:19.564927
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    b = BaseNodeTransformer("")
    assert b._tree_changed == False
    assert b._tree == ""

# Generated at 2022-06-21 17:27:20.374634
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-21 17:27:24.728853
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(ast.parse('x'))
    assert isinstance(t, BaseNodeTransformer)
    assert t._tree_changed == False

# Unit tests for class BaseImportRewrite

# Generated at 2022-06-21 17:27:25.533364
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:27:31.108997
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert BaseTransformer.__abstractmethods__ == {'transform'}
    with pytest.raises(NotImplementedError):
        BaseTransformer.transform(None)


# Generated at 2022-06-21 17:27:40.367934
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('example.old', 'example.new')]

    tree = ast.parse('import example.old.foo')
    tree = ast.fix_missing_locations(tree)
    tree = ImportRewrite.transform(tree).tree
    assert ast.dump(tree) == 'import example.old.foo\n'

    tree = ast.parse('import example.old.foo as bar')
    tree = ast.fix_missing_locations(tree)
    tree = ImportRewrite.transform(tree).tree
    assert ast.dump(tree) == 'try:\n    import example.old.foo as bar\n' \
                             'except ModuleNotFoundError:\n    ' \
                             'import example.new.foo as bar\n'


# Generated at 2022-06-21 17:27:43.777681
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BaseImportRewriteTest(BaseImportRewrite):
        pass
    BaseImportRewriteTest()



# Generated at 2022-06-21 17:27:51.349923
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    empty_node = ast.Import()
    empty_node.names = []
    class_ = BaseImportRewrite(empty_node)
    class_.rewrites = [('foo', 'bar'), ('bar.fizz', 'baz')]
    actual = class_.visit_Import(ast.Import(names=[
        ast.alias(name='foo', asname='_foo')]))
    expected = """try:
    import foo as _foo
except ImportError:
    import bar as _foo"""
    assert astor.to_source(actual) == expected

    node = ast.Import(names=[
        ast.alias(name='bar.fizz', asname='_buzz')])
    actual = class_.visit_Import(node)

# Generated at 2022-06-21 17:28:10.306888
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.astdiff import ast_diff
    import astor
    import textwrap

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.Python2
        rewrites = [
            ('foo', 'foo2')
        ]

    tree = ast.parse(textwrap.dedent("""\
        import foo
        import foo.bar
        import foo.bar.zoo
        import foo2
        import foo2.bar
        """))
    expected = ast.parse(textwrap.dedent("""\
        import foo
        import foo.bar
        import foo.bar.zoo
        try:
            import foo2
        except ImportError:
            import foo2.bar
            import foo2.bar.zoo
            foo2 = foo2.bar.zoo
        """))
    Test

# Generated at 2022-06-21 17:28:21.151708
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [('asyncio', 'trio'), ('trio', 'trio')]
    BaseImportRewrite.rewrites.sort(key=lambda x: len(x[0]), reverse=True)
    b = BaseImportRewrite(None)
    assert list(b._get_matched_rewrite('asyncio.unix')) == ('asyncio', 'trio')
    assert list(b._get_matched_rewrite('six')) == (None)
    assert list(b._get_matched_rewrite('trio')) == ('trio', 'trio')
    assert list(b._get_matched_rewrite('trio.hazmat')) == ('trio', 'trio')

# Generated at 2022-06-21 17:28:21.849157
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target == CompilationTarget.NONE

# Generated at 2022-06-21 17:28:23.484256
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        pass
    t = DummyTransformer()
    assert(t.target == CompilationTarget.PY36)



# Generated at 2022-06-21 17:28:29.025834
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    code = """from foo import bar, foo
    from foo import bar as foobar, foo as foofoo
    from foo import *
    import foo
    import foo.bar
    from foo import bar, foo
    """
    tree = ast.parse(code)
    BaseImportRewrite(tree)

# Generated at 2022-06-21 17:28:36.184259
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ...compiler.ast import ast_to_source

    src = 'from django.db import models'
    tree = ast.parse(src)

    class MyClass(BaseImportRewrite):
        rewrites = [('django.db', 'django.db.models')]

    MyClass.transform(tree)



# Generated at 2022-06-21 17:28:48.577624
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..compilers.base.ast_builder import _CompilationError
    from ..compilers.base import BaseCompiler
    from ..utils.snippet import Snippet
    from ..utils.misc import raise_

    compiler = BaseCompiler(CompilationTarget.PY37)

    def lazy_raise(msg):
        return Snippet('''
        def __init__(self):
            raise_('{}')
        '''.format(msg))

    class AnyTransformer(BaseTransformer):
        transform = 'pass'

    class NotAValidTransformer(BaseTransformer):
        transform = 1

    class NotAnASTNodeTransformer(BaseNodeTransformer):
        transform = 'pass'

    class NotAValidASTNodeTransformer(BaseNodeTransformer):
        transform = 1


# Generated at 2022-06-21 17:28:51.126940
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    print("Test BaseTransformer")
    BaseTransformer()
    

# Generated at 2022-06-21 17:28:57.867675
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test_1 = BaseNodeTransformer({'hello': 'world'})
    assert not hasattr(test_1, '_tree_changed')
    assert not hasattr(test_1, '_tree')
    assert test_1.visit({'hello': 'world'}) == {'hello': 'world'}
    assert not test_1._tree_changed
    assert test_1._tree == {'hello': 'world'}


# Generated at 2022-06-21 17:29:00.354895
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
  try:
    x = BaseImportRewrite()
  except:
    return False
  return True

# Generated at 2022-06-21 17:29:27.527274
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = astor.parse("""from foo.bar import baz
                         from foo.bar import *
                         """)
    class TestRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.baz')]

    TestRewrite.transform(tree)
    assert astor.to_source(tree) == \
        """try:
            from foo.bar import baz
        except ImportError:
            from foo.baz import baz
        try:
            from foo.bar import *
        except ImportError:
            from foo.baz import *
        """



# Generated at 2022-06-21 17:29:38.163987
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import ast_source

    source = """
import ctypes
from ctypes import *
import sys.platform
from sys.platform import *
import numpy as np
from numpy import *
import numpy.random as nprandom
from numpy.random import *
import numpy.distutils as npd
from numpy.distutils import *
import numpy.distutils.system_info as npdinfo
from numpy.distutils.system_info import *
import foo as bar
from foo import bar as baz
from os.foo.bar import baz
"""

# Generated at 2022-06-21 17:29:39.019849
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    o = BaseImportRewrite(None)

# Generated at 2022-06-21 17:29:45.653066
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    original = """
    import scrapy
    """

    expected = """
    try:
        import scrapy
    except ImportError:
        import scrapy_pyppeteer
    """

    tree = ast.parse(original)
    BaseImportRewrite.transform(tree)
    assert astunparse.unparse(tree) == expected



# Generated at 2022-06-21 17:29:50.414952
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.Module([])
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert not transformer._tree_changed


# Generated at 2022-06-21 17:29:56.870989
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..compiler import Compiler # TODO: same in BaseTransformationTransformer
    tree = Compiler.compile('from foo import Bar\n')
    transformer = BaseImportRewrite(tree)
    code = transformer.visit(tree)
    transformer.visit(code)
    print(code)



# Generated at 2022-06-21 17:30:07.988196
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    print('test BaseImportRewrite.visit_Import()')
    class Node:
        def __init__(self, name):
            self.name = name
            self.asname = None
    class Import:
        def __init__(self, names):
            self.names = names
    imports = [
        Import([Node('module1')]),
        Import([Node('module2.submodule')]),
        Import([Node('module2')]),
        Import([Node('module1.submodule')]),
        Import([Node('module3')]),
        Import([Node('module4')]),
    ]
    class BaseImportRewrite:
        rewrites = [('module1', 'module1.rewritten')]

# Generated at 2022-06-21 17:30:18.734417
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # type: () -> None
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert not issubclass(str, BaseNodeTransformer)
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)
    assert not issubclass(str, BaseNodeTransformer)
    assert not issubclass(BaseTransformer, BaseNodeTransformer)
    assert not issubclass(ast.NodeTransformer, BaseNodeTransformer)
    assert not issubclass(BaseNodeTransformer, BaseNodeTransformer)
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert issubclass(BaseNodeTransformer, BaseTransformer)


# Generated at 2022-06-21 17:30:28.032935
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    """This test tests the dynamic aspect of the class BaseTransformer."""
    example = BaseTransformer()
    field_example_class = example.__class__.__dict__
    field_correct = BaseTransformer.__dict__
    result = 1
    for key, value in field_correct.items():
        if not hasattr(field_example_class[key], '__call__'):
            if not field_example_class[key] == field_correct[key]:
                result = 0
    assert result == 1


# Generated at 2022-06-21 17:30:32.184102
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('pass')
    bnt = BaseNodeTransformer(tree)
    assert bnt._tree == tree
    return


# Generated at 2022-06-21 17:31:14.029888
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
	node = BaseNodeTransformer(None)
	assert isinstance(node, BaseNodeTransformer)


# Generated at 2022-06-21 17:31:15.558186
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite()



# Generated at 2022-06-21 17:31:22.279162
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import example_code
    from .codegen_tools import generate_source

    source_module = example_code.get_module('BaseImportRewriter')
    source_code = generate_source(source_module)

    with patch('typed_python.compiler.transforms.BaseImportRewriter.rewrites',
               [(i, 'typed_python.compiler.transforms.rewritten') for i in
                ('typed_python.compiler.transforms.BaseImportRewriter',)]):
        class Test(BaseImportRewrite):
            rewrites = []

        result = Test.transform(source_module)
        assert generate_source(result.tree) == source_code.replace('BaseImportRewriter',
                                                                   'rewritten',
                                                                   1)
        assert result.is_changed


# Unit test

# Generated at 2022-06-21 17:31:32.754328
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.compare_ast import compare_ast

    class MyImportRewrite(BaseImportRewrite):
        # my_module.my_name == my.different.module.my_name
        rewrites = [
            ('my_module', 'my.different.module'),
        ]

    tree = ast.parse('from my_module import my_name, other_name')
    expected = ast.parse(
        """from my_module import my_name, other_name
from my.different.module import my_name
try:
    from my.different.module import other_name
except ImportError:
    pass
        """)

    actual = MyImportRewrite.transform(tree).tree
    # print(astor.to_source(actual))
    assert compare_ast(actual, expected)



# Generated at 2022-06-21 17:31:34.326634
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-21 17:31:43.862243
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    mod = ast.parse('''
from foo import bar
from foo.baz import bar as baz
from foo.bar import baz as boo
from foo.bar.baz import foo as baz
from foo import bar as boo
import foo.bar as bar
''')
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'foo2')]
        dependencies = []
    result = TestTransformer.transform(mod)
    print(result.tree)

# Generated at 2022-06-21 17:31:53.706338
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import random
    import unittest
    import sys
    sys.stdout = io.StringIO()  # type: ignore
    class Test(unittest.TestCase):
        def test_visit_ImportFrom_0(self):
            print('Testing {}...'.format(self._testMethodName))

            class Mock(BaseImportRewrite):
                rewrites = [('os', 'six.moves.os')]
            tree = ast.parse('''\
from os import path

path.abspath('.')''')

            result = Mock.transform(tree)
            self.assertEqual(result.tree.body[1].value.func.value.id, 'path')

            self.assertEqual(result.tree.body[1].value.func.value.attr, 'abspath')

            self

# Generated at 2022-06-21 17:31:56.827940
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.fixtures import get_example_ast

    tree = get_example_ast()
    BaseNodeTransformer(tree)

# Generated at 2022-06-21 17:32:00.678710
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    rewrites = [('package1', 'package1new')]
    class Rewrite(BaseImportRewrite):
        rewrites = rewrites

# Generated at 2022-06-21 17:32:04.055285
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse("print('ok')")
    res = TestTransformer.transform(tree)
    assert not res.tree_changed
    assert res.dependencies == []



# Generated at 2022-06-21 17:33:41.570448
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import itertools
    import os
    import shutil
    import tempfile

        # test if import from statement is replaced with try/except statement
    @snippet
    def test_import_from():
        from some_module import some_function, bar as baz

    @snippet
    def expected_result1():
        try:
            from some_module import some_function, bar as baz
        except ImportError:
            from some_other_module import some_function, bar as baz

    tree = ast.parse(test_import_from.get_body())
    rewritten = BaseImportRewrite.transform(tree)
    assert astunparse.unparse(rewritten.tree) == expected_result1.get_body()
    assert rewritten.changed

    # test if import from statement is not changed

# Generated at 2022-06-21 17:33:43.540710
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    foo = BaseTransformer()
    assert foo.target == None


# Generated at 2022-06-21 17:33:54.126769
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import CompilationTarget
    from ..ast import ast_to_string

    class TestTransformer(BaseNodeTransformer):
        target = CompilationTarget.PYTHON_35

        def visit_Name(self, node: ast.Name) -> Union[ast.Name, ast.Attribute]:
            if (isinstance(node.ctx, ast.Load) and
                    node.id.startswith('magic')):
                self._tree_changed = True
                return ast.Attribute(value=ast.Name(id='magic',
                                                    ctx=ast.Load()),
                                     attr=node.id.split('magic_')[-1],
                                     ctx=ast.Load())
            return self.generic_visit(node)

    source = '''
    magic_value = magic_function()
    '''

# Generated at 2022-06-21 17:33:59.289051
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from typed_ast import ast3 as ast
    root = ast.parse("")
    assert hasattr(BaseImportRewrite(root), 'visit_Import')
    assert hasattr(BaseImportRewrite(root), 'visit_ImportFrom')
    with pytest.raises(NotImplementedError):
        BaseImportRewrite.transform(root)

# Generated at 2022-06-21 17:34:10.622646
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestClass(BaseImportRewrite):
        rewrites = [('abc', 'def')]

    node = ast.ImportFrom(
        module='abc.xyz',
        names=[ast.alias(name='a1')],
        level=0)

    result = TestClass.transform(node).result

    def_tree = ast.Try(
        body=[],
        handlers=[
            ast.ExceptHandler(type=None,
                              name=None,
                              body=[
                ast.ImportFrom(
                    module='def.xyz',
                    names=[ast.alias(name='a1')],
                    level=0)])],
        finalbody=[],
        orelse=[],
        type_comment=None)

    assert result == def_tree

