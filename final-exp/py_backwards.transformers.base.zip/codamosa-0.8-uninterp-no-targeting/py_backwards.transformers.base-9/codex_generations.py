

# Generated at 2022-06-21 17:24:24.690741
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import unittest
    
    class MockNode(BaseImportRewrite):
        rewrites = [('test_module', 'test_rewrite')]
    
    def generate(module, names):
        return ast.parse('from {} import {}'.format(module, names), mode='exec').body[0]

    def test_module_rewrite(module, names, expected_module, expected_names):
        tree = generate(module, names)
        MockNode.visit_ImportFrom(tree)
        assert tree.module == expected_module
        assert [a.name for a in tree.names] == expected_names


# Generated at 2022-06-21 17:24:34.774485
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .utils import get_sample_code

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('socket', 'socketserver')]

    code = get_sample_code('node_transformers', 'base_import_rewrite.py')
    tree = ast.parse(code)
    tree = DummyTransformer.transform(tree)
    assert isinstance(tree, ast.Try)
    import_node, except_node = (tree.body[0], tree.body[1])
    assert isinstance(import_node, ast.Import)
    assert import_node.names[0].name == 'socketserver'
    assert except_node.body[0].body[0].module == 'socket'
    assert except_node.body[1].body[0].module == 'socket'
    assert except_

# Generated at 2022-06-21 17:24:37.518272
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-21 17:24:44.841982
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest.mock as mock
    import ast
    import sys

    m = mock.mock_open(read_data="""\
    from typing import List
    from discord import Message
    from discord.ext.commands import Context
    from discord.abc import User
    """)

    with mock.patch('builtins.open', m):
        node = ast.parse('', '<file_name>')
        assert node.body == []
        mock_write = mock.Mock()


# Generated at 2022-06-21 17:24:55.962615
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_rewrites = [
        ("foo.bar", "baz.quux"),
        ("quux.foo.bar", "baz.quux"),
        ("foo.middleware", "middleware"),
        ("foo.middleware.bar", "middleware.bar"),
        ("foo.bar.baz", "bar.baz"),
        ("foo.bar.baz.quux", "bar.baz.quux")
    ]

    import_rewrites = [
        ("foo.bar", "baz.quux"),
        ("quux.foo.bar", "baz.quux"),
        ("foo", "bar")
    ]

    rewrites = import_from_rewrites + import_rewrites


# Generated at 2022-06-21 17:24:56.975418
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    bnt = BaseNodeTransformer(None)
    assert bnt is not None

# Generated at 2022-06-21 17:25:05.202422
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compiler import Compiler
    from ..compiler.unpythonic_rewrites import ENVIRONMENT_MODULE_REWRITES

    compiler = Compiler()
    module = compiler.compile(
        source='from future import print_function\n',
        target=Compiler.TARGET_PYTHON_LEGACY)

    import_rewrites = [
        rewrite for rewrite in ENVIRONMENT_MODULE_REWRITES
        if rewrite[0] == 'future']
    assert module.find('from future import print_function')
    assert len(import_rewrites) == 1
    import_rewrite = import_rewrites[0]

    BaseImportRewrite.rewrites = import_rewrites
    BaseImportRewrite.transform(module)


# Generated at 2022-06-21 17:25:15.675875
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTestCase(object):
        pass

    test_cases = [
        ImportTestCase(),
        ImportTestCase(),
        ImportTestCase(),
        ImportTestCase(),
    ]

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class FakeNode(object):
        def __init__(self, module_name: str) -> None:
            self.names = [FakeName(module_name)]

        def __eq__(self, other) -> bool:
            return other.names[0].name == self.names[0].name

        def __repr__(self) -> str:
            return 'FakeNode({})'.format(self.names[0].name)


# Generated at 2022-06-21 17:25:16.227914
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:25:28.765340
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..py3_to_py2 import BaseImportRewrite, CompilationTarget
    import sys
    import ast

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PY2
        rewrites = [
            ('dataclasses', 'attrs'),
            ('typing', 'typing_extensions')
        ]

    tree = ast.parse('''if True:
    from dataclasses import dataclass, field
    from typing import List
    ''')
    TestTransformer.transform(tree)


# Generated at 2022-06-21 17:25:44.982029
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer):
        pass
    tree = ast.parse('import thread')
    t = Transformer(tree)
    assert t._tree == tree
    assert t._tree_changed == False


# Generated at 2022-06-21 17:25:58.505053
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module'),
            ('old_module2', 'new_module2'),
        ]

    ast_new = ast.parse('from old_module.something import *')
    ast_old = ast.parse('from old_module.something import *')
    assert Rewrite.transform(ast_new) == TransformationResult(ast_old, True, [])

    ast_new = ast.parse('from old_module.something import a, b')
    ast_old = ast.parse('from old_module.something import a, b')
    assert Rewrite.transform(ast_new) == TransformationResult(ast_old, True, [])

    ast_new = ast.parse('from old_module.something.some2 import a, b')


# Generated at 2022-06-21 17:26:02.991182
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import pytest
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ("urllib.parse", "urllib.request"),
        ]

    tree = ast.parse(
        "from urllib.parse import parse_qs, parse_qsl")
    TestImportRewrite.transform(tree)

    expected = """
from urllib.request import parse_qs, parse_qsl  # @@@[1]
try:
    from urllib.parse import parse_qs, parse_qsl
except ImportError:
    pass
"""[1:-1]

    actual = astor.to_source(tree)
    assert expected == actual



# Generated at 2022-06-21 17:26:08.770305
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_astunparse
    import ast

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON3_3
        rewrites = [('old_module', 'new_module')]

    node = ast.parse('from old_module import old_name')
    transformer = TestTransformer(node)
    res = transformer.visit(node)
    assert typed_astunparse.unparse(res) == "try:\n    from new_module import old_name\nexcept ImportError:\n    from old_module import old_name"



# Generated at 2022-06-21 17:26:10.199927
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    my_transformer = BaseTransformer()

# Generated at 2022-06-21 17:26:18.635055
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    in_import = ast.parse('from a.b.c import d, e, f')
    out_import = ast.parse('try:\n    from a.b.c import d, e, f\nexcept ImportError:\n    from a.x.c import d as d, e as e, f as f')
    tr = BaseImportRewrite(in_import)
    tr.rewrites = [
        ('a.b', 'a.x')]
    in_import = tr.visit(in_import)

    assert astunparse.unparse(in_import).strip() == astunparse.unparse(out_import).strip()

# Generated at 2022-06-21 17:26:28.060923
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..test_utils import assert_to_test
    from typed_ast import ast3
    import_test = ast3.parse('''
    import 
    import logging
    import logging.config
    import logging.handlers
    import logging.config.dictConfig
    import to_be_rewritten
    import to_be_rewritten.as_well
    import to_be_rewritten.as_well.logging
    import to_be_rewritten.as_well.logging.config
    import to_be_rewritten.as_well.logging.handlers
    import to_be_rewritten.as_well.logging.config.dictConfig''').body


# Generated at 2022-06-21 17:26:29.712650
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite


# Generated at 2022-06-21 17:26:39.083844
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six.moves.urllib_parse'),
            ('json', 'six.moves.cPickle'),
        ]

# Generated at 2022-06-21 17:26:44.697340
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    transformer = BaseImportRewrite(None)
    transformer.rewrites = [('foo', 'bar')]
    tree = ast.parse("import foo")
    assert transformer.visit(tree) == ast.parse("try:\n    import foo\nexcept ImportError:\n    import bar")



# Generated at 2022-06-21 17:26:49.305696
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(1)

# Generated at 2022-06-21 17:26:51.753664
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    with raises(TypeError):
        BaseTransformer.transform(None)



# Generated at 2022-06-21 17:27:04.500017
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Class definition
    class Test(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]
    
    # Test
    tree = ast.parse('''
    import a
    import c
    import a.x
    import c.x
    ''')

    Test.transform(tree)
    
    expected = '''
try:
    import a
except ImportError:
    import b
try:
    import c
except ImportError:
    import d
try:
    import a.x
except ImportError:
    import b.x
try:
    import c.x
except ImportError:
    import d.x
    '''
    assert expected == ast.dump(tree, include_attributes=False)



# Generated at 2022-06-21 17:27:05.477105
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer), "BaseTransformer is not a NodeTransformer"


# Generated at 2022-06-21 17:27:08.475905
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = ast.parse('import foo')
    result = BaseImportRewrite(module).visit(module)
    assert isinstance(result, ast.Import)



# Generated at 2022-06-21 17:27:15.973792
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module'),
            ('old_module2', 'new_module2'),
        ]

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            if name:
                return 'old_module', 'new_module'

            return None


# Generated at 2022-06-21 17:27:17.722541
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target == None


# Generated at 2022-06-21 17:27:28.125798
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_ = ast.Import(names=[
        ast.alias(name='os.path',
                  asname=None)])

    rewriter = BaseImportRewrite([('os.path', 'pathlib')])
    assert rewriter._get_matched_rewrite('os.path') == ('os.path', 'pathlib')

    try_ = rewriter._replace_import(import_, *rewriter._get_matched_rewrite('os.path'))
    assert try_.body[0].body[0].names[0].name == 'pathlib.path'
    assert try_.body[0].body[0].names[0].asname == 'path'
    assert try_.body[1].body[0].names[0].name == 'os.path'
    assert try_.body[1].body[0].names[0].asname

# Generated at 2022-06-21 17:27:32.747344
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .utils import TestAST
    tree = TestAST.ast_from_string('1')
    inst = BaseNodeTransformer(tree)
    assert inst._tree is tree

# Generated at 2022-06-21 17:27:41.069900
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import typed_ast.ast3 as typed_ast
    from typed_ast import _ast3
    from typed_ast import ast3 as typed_ast

    module = ast.parse("import a, b\nfrom c import d, e, f\nimport g")
    typed_module = typed_ast.parse("import a, b\nfrom c import d, e, f\nimport g")
    class transformer(BaseImportRewrite):
        rewrites = [('d', 'dd')]

    assert transformer.transform(module).changed
    assert module == typed_module

    assert transformer.transform(typed_module).changed
    assert module == typed_module

    module = ast.parse("import a, b\nfrom c import d, e, f\nimport g")

# Generated at 2022-06-21 17:27:51.055510
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_print import ast_print
    import io
    import sys

    # TODO add import rewrite for io.open -> io.StringIO.open in BaseImportRewrite


    t = BaseImportRewrite(
            ast.Module(body=[
                ast.ImportFrom(module='io',
                               names=[ast.alias(name='open')],
                               level=1)]))

    t.visit_ImportFrom(t._tree.body[0])

    ast_print(t._tree, file=sys.stdout)

# Generated at 2022-06-21 17:28:00.898633
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from typed_ast.ast3 import parse
    from ..utils.snippet import is_exactly

    class ImportRewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('six.moves.urllib_parse', 'urllib.parse')
        ]

    class ImportRewriteTransformerTests(unittest.TestCase):
        def transform(self, tree):
            transformed = ImportRewriteTransformer.transform(tree)
            self.assertTrue(transformed.changed)
            return transformed.tree

        def parse(self, source: str) -> ast.ImportFrom:
            parsed = parse(source)

# Generated at 2022-06-21 17:28:07.467804
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    transformer.dependencies = ['test1', 'test2']
    transformer.target = 'test_target'
    transformer.rewrites = [('test3', 'test3')]
    assert transformer.dependencies == ['test1', 'test2']
    assert transformer.target == 'test_target'
    assert transformer.rewrites == [('test3', 'test3')]

# Generated at 2022-06-21 17:28:09.428379
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None


# Generated at 2022-06-21 17:28:20.792108
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('from old.m1 import b, c')
    result = tree.body[0]

    import_rewrite_ = MyImportRewrite(tree)
    result_ = import_rewrite_.visit_ImportFrom(result)

    assert isinstance(result_, ast.Try)
    assert isinstance(result_.body[0], ast.ImportFrom)
    assert result_.body[0].module == 'new.m1'
    assert result_.body[0].names[0].name == 'b'
    assert result_.body[0].names[1].name == 'c'
    assert result_.body[0].names[1].asname is None

# Generated at 2022-06-21 17:28:27.806725
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast
    import astunparse
    import tempfile
    import os
    source = 'print(1 + 2)'
    filename = os.path.join(tempfile.gettempdir(), 'python')
    with open(filename, 'w') as f:
        f.write(source)
    tree = ast.parse(source, filename, 'exec')
    tr = BaseNodeTransformer(tree)
    assert tr._tree == tree


# Generated at 2022-06-21 17:28:34.233177
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class ImportRewriter(BaseImportRewrite):
        rewrites = [('import_a', 'import_b')]

    tree = ast.parse('import import_a')
    transformer = ImportRewriter(tree)

    expected = ast.parse(
        textwrap.dedent(
            """
            try:
                import import_a
            except ImportError:
                import import_b as import_a
            """
        )
    )

    assert transformer.visit(tree) == expected



# Generated at 2022-06-21 17:28:41.918503
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    import_ = ast.Import(names=[
        ast.alias(name='unittest.mock', asname='mock')])

    import_rewrite = BaseImportRewrite(None)
    import_rewrite.rewrites = [
        ('unittest.mock', 'mock')
    ]

    result = import_rewrite.visit_Import(import_)

    assert astunparse.unparse(result) == textwrap.dedent("""\
    try:
        import unittest.mock as mock
    except ImportError:
        import mock""")



# Generated at 2022-06-21 17:28:43.281511
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(None)

# Generated at 2022-06-21 17:28:46.706376
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class ConcreteTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse('1')
    transformer = ConcreteTransformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed is False

# Generated at 2022-06-21 17:29:05.273037
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import sys
    import_from_str = 'from zlib import decoder'
    import_from_str_expected = '''
try:
    from zlib import decoder
except ImportError:
    from zlib import decoder
'''
    assert BaseImportRewrite.transform(  # type: ignore
        ast.parse(import_from_str)
    ).tree_to_string() == import_from_str_expected

    import_from_str = 'from zlib.decoder import Codec'
    import_from_str_expected = '''
try:
    from zlib.decoder import Codec
except ImportError:
    from zlib.decoder import Codec
'''
    assert BaseImportRewrite.transform(  # type: ignore
        ast.parse(import_from_str)
    ).tree_

# Generated at 2022-06-21 17:29:16.268839
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    from ..types import CompilationTarget
    from ..utils.snippet import extend, snippet

    class MockBaseImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PY38
        rewrites = [
            ('collections.abc', 'collections')
        ]

    # case 1: Import
    tree = ast.parse('from collections.abc import defaultdict')
    transform_result = MockBaseImportRewrite.transform(tree)
    assert astor.to_source(transform_result.tree) == 'try:\n    from collections.abc import defaultdict\nexcept ImportError:\n    from collections import defaultdict'

    # case 2: ImportFrom
    tree = ast.parse('from collections.abc import defaultdict, OrderedDict')

# Generated at 2022-06-21 17:29:18.426522
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    b=BaseImportRewrite()

# Generated at 2022-06-21 17:29:22.062503
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrite = BaseImportRewrite(None)
    assert rewrite.rewrites == []
    assert rewrite.dependencies == []
    assert rewrite.target == None


# Generated at 2022-06-21 17:29:22.736452
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None

# Generated at 2022-06-21 17:29:24.967592
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(ast.parse('print(1)'))._tree == \
        ast.parse('print(1)')


# Generated at 2022-06-21 17:29:37.634115
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyRewriter(BaseImportRewrite):
        rewrites = [('foo_module', 'new_module')]

    import csv
    import foo_module.bar

    # Cas 1: no change
    import_stmt = ast.parse('import csv').body[0]
    assert isinstance(import_stmt, ast.Import)
    result = MyRewriter.transform(import_stmt)
    assert not result[1]
    assert result[0] is import_stmt

    # Cas 2: module import
    import_stmt = ast.parse('import foo_module').body[0]
    assert isinstance(import_stmt, ast.Import)
    target = MyRewriter.transform(import_stmt)[0]
    assert isinstance(target, ast.Try)

# Generated at 2022-06-21 17:29:45.166493
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test import assert_transformation
    
    class Visitor(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    assert_transformation(
        Visitor,
        'import foo',
        'import foo\ntry:\n    extend(foo)\nexcept ImportError:\n    extend(bar)\n')



# Generated at 2022-06-21 17:29:51.328784
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_test(BaseNodeTransformer):
        target: CompilationTarget = CompilationTarget.PYTHON_3_6

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            BaseNodeTransformer.__init__(self, tree)

    tree = ast.parse('print(True)')
    BaseTransformer_test.transform(tree)
    assert repr(tree) == repr(ast.parse('print(True)', mode='exec'))



# Generated at 2022-06-21 17:29:57.811618
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("print('Hello world')")
    class TestTransformer(BaseNodeTransformer):
        def visit_Print(self, node):
            ret = ast.Name(id='y')
            return ast.Expr(value=ret)
    x = TestTransformer(tree)
    x.visit(tree)
    assert x._tree_changed == True


# Generated at 2022-06-21 17:30:21.377495
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'foo'
    to = 'bar'
    import_from = ast.ImportFrom(
        module=from_,
        names=[ast.alias(name='B',
                         asname='c')],
        level=0)

    replaced = ast.ImportFrom(
        module=to,
        names=[ast.alias(name='B',
                         asname='c')],
        level=0)

    try_ = ast.Try(body=[replaced],
                   handlers=[],
                   orelse=[],
                   finalbody=[])

    class DummyBaseImportRewrite(BaseImportRewrite):
        rewrites = [(from_, to)]

    assert DummyBaseImportRewrite.visit_ImportFrom(None, import_from) == try_

# Generated at 2022-06-21 17:30:30.067541
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..packages import six

    class Test(BaseImportRewrite):
        rewrites = [('_six', 'six')]

    def test_rewrite_import():
        node = ast.parse('import _six')
        result = Test.transform(node)
        assert result.transformed
        assert 'import _six' not in ast.dump(result.tree)
        assert 'import six' in ast.dump(result.tree)

    def test_rewrite_import_as():
        node = ast.parse('import _six as six')
        result = Test.transform(node)
        assert result.transformed
        assert 'import _six' not in ast.dump(result.tree)
        assert 'import six as six' in ast.dump(result.tree)


# Generated at 2022-06-21 17:30:32.746845
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("""print("Hello, World!")""")
    BaseNodeTransformer(tree)
    assert True

# Generated at 2022-06-21 17:30:33.877245
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

# Generated at 2022-06-21 17:30:40.303209
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [('os.path', 'pathlib')]
    tree = ast.parse('import os.path\nimport os.path.index')

    result = BaseImportRewrite.transform(tree)
    expected = TransformationResult(
        tree=ast.parse("""
try:
    import os.path
except ImportError:
    import pathlib as os_path

try:
    import os.path.index
except ImportError:
    import pathlib.index as os_path_index
"""),
        tree_changed=True,
        dependencies=[])

    assert result == expected



# Generated at 2022-06-21 17:30:47.589363
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    result = BaseImportRewrite(None).visit_Import(ast.parse('import os').body[0])
    assert isinstance(result, ast.Import)

    result = BaseImportRewrite(None).visit_Import(ast.parse('import os.path').body[0])
    assert isinstance(result, ast.Try)



# Generated at 2022-06-21 17:30:48.080892
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:31:00.629378
# Unit test for constructor of class BaseImportRewrite

# Generated at 2022-06-21 17:31:01.331450
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:31:09.301042
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import ImportFrom
    from typed_ast.ast3 import alias
    from typed_ast.ast3 import Attribute
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Try
    from typed_ast.ast3 import Assign
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Store
    from typed_ast.ast3 import ExceptHandler
    from typed_ast.ast3 import parse
    
    stm = "from `importlib.abc`.`foo`.`bar` import `Foo`"
    node = parse(stm, mode="exec")
    
    trans = BaseImportRewrite()
    trans.rewrites = [("importlib.abc", "importlib")]
    trans.vis

# Generated at 2022-06-21 17:32:01.570314
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    # Test Import that doesn't need to be rewritten
    node = ast.Import(names=[
        ast.alias(name='no_rewrite')])
    tree = TestTransformer.transform(node)
    assert not tree.tree_changed
    assert tree.tree == node

    # Test Import that needs to be rewritten
    node = ast.Import(names=[
        ast.alias(name='old.module')])
    tree = TestTransformer.transform(node)
    assert tree.tree_changed



# Generated at 2022-06-21 17:32:02.988169
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer


# Generated at 2022-06-21 17:32:04.489254
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-21 17:32:09.406065
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not BaseTransformer.target
    BaseTransformer.target = CompilationTarget.PYTHON_3_5
    assert BaseTransformer.target == CompilationTarget.PYTHON_3_5


# Generated at 2022-06-21 17:32:14.177155
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    tree = ast.parse('import re')
    result = BaseImportRewrite.transform(tree)
    # assert isinstance(result.tree, ast.Try)
    if hasattr(sys.version_info, 'major') and sys.version_info.major > 2:
        assert isinstance(result.tree.body[0], ast.ImportFrom)



# Generated at 2022-06-21 17:32:24.869998
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import pytest
    from textwrap import dedent

    tree = ast.parse(dedent('''\
    import six
    import six.moves
    from six.moves import input
    from six.moves import xrange
    from six.moves import *
    from six.moves import xrange as range
    from foo.bar import baz

    '''), mode='exec')

    class MockTransformer(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six.moves.mock')]

    MockTransformer.transform(tree)

# Generated at 2022-06-21 17:32:30.769264
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('pyramid', 'django')
        ]

    tree = ast.parse("import pyramid.renderers")
    result = ImportRewrite.transform(tree)

    assert result.tree.body[0].value.names[0].name == 'django'



# Generated at 2022-06-21 17:32:41.987451
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # type: () -> None 
    from ..runners.ast_runner import ASTRunner
    from ..runners.exec_runner import ExecRunner

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = """
import six
six.moves
"""
    expected_source = """
try:
    import six
except ImportError:
    import six.moves
six.moves
"""

    result = TestTransformer.transform(ASTRunner.to_ast(source))
    result_source = ExecRunner.to_source(result.tree)
    assert result_source == expected_source



# Generated at 2022-06-21 17:32:53.151784
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    def get_node(code: str) -> ast.Import:
        tree = ast.parse(code)
        assert len(tree.body) == 1
        return cast(ast.Import, tree.body[0])

    def test_node_with_rewrite(node: ast.Import, name: str, asname: str, module: str):
        class Test(BaseImportRewrite):
            rewrites = [('A', 'B')]

        from_, to = Test.rewrites[0]
        result = Test.transform(node)
        assert result.tree_changed  # type: ignore
        result_node = cast(ast.Try, result.tree)
        assert isinstance(result_node, ast.Try) and len(result_node.handlers) == 1

# Generated at 2022-06-21 17:32:56.169503
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    obj = BaseNodeTransformer.__new__(BaseNodeTransformer)
    assert isinstance(obj, BaseNodeTransformer)