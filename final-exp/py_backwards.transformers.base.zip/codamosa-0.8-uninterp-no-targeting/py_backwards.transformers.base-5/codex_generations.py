

# Generated at 2022-06-21 17:24:21.691315
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass
    assert TestTransformer(object())._tree is None



# Generated at 2022-06-21 17:24:33.638766
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..mixins.base import InPlaceRewriteMixin

    # should transform import with rewrite
    class SomeImportBaseImportRewrite(InPlaceRewriteMixin, BaseImportRewrite):
        rewrites = [('six', 'six_backport')]

    # should not transform import without rewrite
    class SomeImportBaseImportRewrite(InPlaceRewriteMixin, BaseImportRewrite):
        rewrites = []

    class InnerClass(ast.AST):
        pass

    class SomeClass(ast.AST):
        _fields = ('inner_class',)

    class SomeModule(ast.AST):
        _fields = ('classes',)

        def __init__(self) -> None:
            self.classes = [InnerClass(), SomeClass()]

    # should not transform import without rewrite

# Generated at 2022-06-21 17:24:44.051933
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..tests.test_transforms.test_imports import preprocessor
    import astor
    import ast

    class Transformer(BaseImportRewrite):
        rewrites = [(preprocessor.__name__, 'typed_ast.ast3')]
    
    module = Transformer.transform(ast.parse('''\
from typed_ast import ast3 as ast
import typed_ast

import preprocessor
preprocessor.preprocess(ast.parse('print (1)'), '3.6')

import preprocessor.imports
preprocessor.imports.is_rewrite('')
'''))
    assert module.changed

# Generated at 2022-06-21 17:24:54.854163
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import inspect

    class TS(BaseImportRewrite):
        rewrites = [('django.db.backends.pyodbc', 'django.db.backends.oracle')]


# Generated at 2022-06-21 17:24:55.433821
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    a = BaseNodeTr

# Generated at 2022-06-21 17:24:56.576735
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-21 17:24:57.881641
# Unit test for constructor of class BaseNodeTransformer

# Generated at 2022-06-21 17:25:04.529279
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    tests = [
        ('import foo',
         'import bar'),
        ('import foo.bar',
         'import bar.bar'),
        ('import foo.bar as baz',
         'import bar.bar as baz'),
        ('import foo.bar.baz as baz',
         'import bar.bar.baz as baz'),
    ]

    for code, expected in tests:
        tree = ast.parse(code)
        DummyTransformer.transform(tree)
        assert ast.dump(tree) == expected



# Generated at 2022-06-21 17:25:07.454565
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)

    Test(int())


# Generated at 2022-06-21 17:25:11.780877
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    _ = BaseImportRewrite
    assert _.dependencies == []
    assert _.target is None
    assert _.rewrites == []


Transformer = TypeVar('Transformer', bound=BaseNodeTransformer)



# Generated at 2022-06-21 17:25:19.872795
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse(
        'a = 1\n'
        'b = 2')

    BaseNodeTransformer(tree)



# Generated at 2022-06-21 17:25:25.210468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.Import(names=[ast.alias(name='os.path', asname='path')])
    rewrite_class = BaseImportRewrite([('os.path', 'ntpath')])
    assert rewrite_class.visit_Import(node).body[0].body[0].names[0].name == 'ntpath'



# Generated at 2022-06-21 17:25:26.121597
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(object())

# Generated at 2022-06-21 17:25:34.831059
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse("from twisted.internet.defer import Deferred")
    node.body[0]._fields = ('type', 'module', 'names', 'level')
    from_rewrite = ('twisted.internet.defer', 'asyncio')
    rewrite = BaseImportRewrite(None)
    rewrite.rewrites.append(from_rewrite)
    res = rewrite.visit_ImportFrom(node.body[0])
    assert res.body[0].body[0].value.args[0].value.body[0].module == 'asyncio'
    assert res.body[0].body[0].value.args[1].value.body[0].module == 'asyncio'



# Generated at 2022-06-21 17:25:36.233981
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()

# Generated at 2022-06-21 17:25:45.181714
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..test_utils import assert_transformation_result
    from ..test_utils import get_test_file_context
    from ..transforms.import_rewrites import Django10ImportRewrite

    test_file_context = get_test_file_context('import_rewrite.py')
    result = Django10ImportRewrite.transform(test_file_context.tree)
    assert_transformation_result(result, test_file_context.name)


# Generated at 2022-06-21 17:25:48.151137
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:25:48.986391
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:25:59.911127
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    def test_BaseImportRewrite_visit_Import_helper(source, expected):
        body = ast.parse(source, mode='exec')
        class TestTransformer(BaseImportRewrite):
            rewrites = [('six', 'six.moves')]

        result = TestTransformer.transform(body)
        result_body = astunparse.unparse(result.body[0]).strip().split('\n')
        expected_body = astunparse.unparse(expected).strip().split('\n')
        assert result_body == expected_body

    source = 'import six'
    expected = '''try:
    import six
except ImportError:
    import six.moves'''
    test_BaseImportRewrite_visit_Import_helper(source, expected)


# Generated at 2022-06-21 17:26:09.301852
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import transpile_src
    from . import visiter


# Generated at 2022-06-21 17:26:25.973732
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    source = """
import json
from json import dump
from json import loads as JSON
from urllib.parse import urljoin
from abc import ABC as AbstractClass
from abc import abc
from abc import ABCMeta
from typing import Optional
from typing import Generator
"""
    tree = ast.parse(source)

# Generated at 2022-06-21 17:26:27.805398
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import requests')
    instance = BaseNodeTransformer(tree)
    assert instance._tree == tree
    assert instance._tree_changed == False



# Generated at 2022-06-21 17:26:28.751841
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:26:38.571674
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer.__doc__ is None
    assert BaseNodeTransformer.__dict__ == dict(__module__='typed_astunparse.transforms',
                                               _tree=None,
                                               _tree_changed=False,
                                               __init__=BaseNodeTransformer.__init__,
                                               )
    assert BaseNodeTransformer.__init__.__defaults__ == (None,)
    assert BaseNodeTransformer.__init__.__dict__ == dict(__module__='typed_astunparse.transforms',
                                                         __qualname__='BaseNodeTransformer.__init__',
                                                         __annotations__={'tree': ast.AST,
                                                                          })

# Unit tests for snippet import_rewrite

# Generated at 2022-06-21 17:26:41.737551
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # type: () -> None
    class BaseTransformerTest(BaseTransformer):
        target = 'test'

    BaseTransformerTest()

# Generated at 2022-06-21 17:26:46.580778
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """BaseNodeTransformer should have __init__() and _visit() """
    tree = ast.parse('import a')
    instance = BaseNodeTransformer(tree)
    assert isinstance(instance, BaseNodeTransformer)
    assert isinstance(instance, ast.NodeTransformer)
    assert instance.__class__.__name__ == BaseNodeTransformer.__name__

# Generated at 2022-06-21 17:26:58.444622
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import foo")
    result = BaseImportRewrite.transform(tree)

    assert result.tree.body[0].__class__ == ast.Import
    assert result.changed is False

    tree = ast.parse("import foo.bar.buz")
    result = BaseImportRewrite.transform(tree)

    assert result.tree.body[0].__class__ == ast.Import
    assert result.changed is False

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'foo_module')]

    tree = ast.parse("import foo")
    result = ImportRewrite.transform(tree)

    assert result.tree.body[0].__class__ == ast.Try
    assert result.changed is True

    tree = ast.parse("import foo.bar.buz")
   

# Generated at 2022-06-21 17:27:05.215681
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        target = 'tests'
        dependencies = ['common']

        def visit_Call(self, node):
            return node

    result = TestTransformer.transform(ast.parse('print(1)'), 'tests')
    assert result.tree is not None
    assert type(result.tree) == ast.Module


# Generated at 2022-06-21 17:27:17.992192
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    from unittest import TestCase

    from .test_utils import get_fixture, cmp_source

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('unittest', 'unittest2')]

    class TestBaseImportRewriteModule(TestCase):
        def test_rewrite_module(self):
            """Should rewrite module."""
            transform = TestBaseImportRewrite.transform
            source = get_fixture('class_ImportFrom_1.py')
            expect = get_fixture('class_ImportFrom_1_rewritten.py')

            tree = ast.parse(source)
            transformed, _, _ = transform(tree)

            self.assertTrue(cmp_source(astor.to_source(transformed), expect))


# Generated at 2022-06-21 17:27:28.215794
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    import typed_ast.ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('abc', 'abc'),
            ('abc.def', 'abc.def'),
            ('abc.def.ghi', 'abc.def.ghi'),
        ]

    def _check_visit(code, expected):
        node = ast.parse(code)
        test = TestTransformer(node)
        result = test.visit(node)
        assert ast.dump(result) == expected

    _check_visit('import abc.def\n', 'import abc.def\n')
    _check_visit('import abc.def as def\n', 'import abc.def as def\n')

# Generated at 2022-06-21 17:27:53.585258
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformerClass(BaseTransformer):
        target = CompilationTarget.PYTHON_C

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    BaseTransformerClass()

# Generated at 2022-06-21 17:28:01.987839
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from datetime import datetime
    from ..ast_transformer import BaseImportRewrite
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('datetime', 'dateutil.parser')
        ]
        dependencies = [
            'dateutil',
            'dateutil.parser'
        ]

    node = ast.Import(names=[
        ast.alias(name='datetime',
                  asname=None)])
    tree = TestTransformer.transform(node)

    assert tree.changed
    assert tree.dependencies == TestTransformer.dependencies
    assert isinstance(tree.tree, ast.Try)

    body = tree.tree.body
    assert len(body) == 2
    assert isinstance(body[0], ast.Import)

# Generated at 2022-06-21 17:28:05.874892
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('class Foo: pass')
    assert tree == ast.parse('class Foo: pass')
    assert BaseNodeTransformer(tree)._tree == tree

# Generated at 2022-06-21 17:28:07.328962
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    tree = ast.parse('')
    obj = BaseImportRewrite(tree)

# Generated at 2022-06-21 17:28:11.081393
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        base = BaseTransformer()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 17:28:16.649559
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        pass

    assert issubclass(A, BaseTransformer)
    assert A.target is None

    a = A()
    assert isinstance(a, BaseTransformer)
    assert a.target is None



# Generated at 2022-06-21 17:28:28.251698
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import os
    from io import StringIO
    from typed_ast import ast3

    from tests.utils.compile import assert_transformed

    class TestTransformer(BaseImportRewrite):
        target = '3.3'
        rewrites = [('os', 'other_os')]

    code = '''
import os

os.path.join('')
    '''
    expected_code = '''
try:
    import os
except ImportError:
    import other_os as os

os.path.join('')
    '''
    tree = ast3.parse(code)
    assert_transformed(tree, expected_code, TestTransformer)


# Generated at 2022-06-21 17:28:35.848141
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]
        target = CompilationTarget.PYTHON_37

    transformer = TestTransformer(None)

    # import from full module name
    node = ast.parse("from old_module import foo", mode="exec").body[0]
    expected = ast.parse("""
try:
    from old_module import foo
except ImportError:
    from new_module import foo
""", mode="exec").body[0]
    assert isinstance(transformer.visit(node), ast.Try)
    assert ast.dump(transformer.visit(node), annotate_fields=False) == \
           ast.dump(expected, annotate_fields=False)

    # import from partial module name

# Generated at 2022-06-21 17:28:48.418577
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code_a1 = 'from a import b as c, d'

    node_a1_c, node_a1_d = ast.parse(code_a1).body[0].names

    code_a2 = 'from a import b as c2, d2'

    node_a2_c, node_a2_d = ast.parse(code_a2).body[0].names

    code_b = 'from b import c, d'

    node_b = ast.parse(code_b).body[0]

    class MockImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'a2')]

    root = ast.parse('import a\n{}\n{}\n{}'.format(code_a1, code_a2, code_b))


# Generated at 2022-06-21 17:28:54.648162
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        pass

    tree = ast.parse('x')
    assert Test(tree).visit(tree) == tree

    class Test2(BaseNodeTransformer):
        def visit(self, tree):
            self._tree_changed = True
            return tree

    assert Test2(tree).visit(tree) == tree

    class Test3(Test2):
        dependencies = []

    assert Test3.transform(tree) == TransformationResult(tree, True, [])

# Generated at 2022-06-21 17:29:25.406064
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from .base import BaseTransformer
    
    class T1(BaseTransformer):
        target = None

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, True, [])
    
    # True
    print(T1.target is None)
    # True
    print(isinstance(T1.transform(None), TransformationResult))


# Generated at 2022-06-21 17:29:31.994867
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestBaseNodeTransformer(BaseNodeTransformer):
        pass
    assert issubclass(TestBaseNodeTransformer, BaseNodeTransformer)
    assert issubclass(TestBaseNodeTransformer, BaseTransformer)
    assert issubclass(TestBaseNodeTransformer, ast.NodeTransformer)

# Generated at 2022-06-21 17:29:35.674654
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BaseImportRewrite(object):
        name = "BaseImportRewrite"
        rewrites = []
        tree_changed = False
        tree = None
        dependencies = []
    BaseImportRewrite()

# Generated at 2022-06-21 17:29:45.972617
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..analyzers.base import BaseAnalyzer
    from ..analyzers.strategies.base import BaseStrategy
    from ..analyzers.strategies.printer import Printer
    class TestAnalyzer(BaseAnalyzer):
        strategy_class = Printer

    tree = ast.parse('import os\nimport sys')
    tree = BaseImportRewrite(tree).visit(tree)
    TestAnalyzer().analyze(tree)
    assert tree.body[0].body[0].dst == 'os\nimport sys'



# Generated at 2022-06-21 17:29:52.152188
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    ast_tree = ast.parse('x = 1')
    assert TestTransformer.transform(ast_tree) == TransformationResult(
        ast.parse('x = 1'), False, [])

# Generated at 2022-06-21 17:30:00.835008
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import test_transform.test_import_rewrite as test_import_rewrite
    from ..utils import get_ast
    from ..translate import translate_ast
    from ..utils import get_all_subclasses
    from unittest import TestCase
    import inspect

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('typing', 'six.moves.builtins')
        ]

    print(TestTransformer.__name__)
    TestTransformer(None)

    class TestRewrite(TestCase):
        def test_rewrite(self):
            code = """
                import typing
            """
            tree = get_ast(code)
            TestTransformer.visit(TestTransformer, tree)
            print(translate_ast(tree))

# Generated at 2022-06-21 17:30:11.203430
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module='requests.api',
                                 names=[ast.alias(name='get', asname='request')], level=0)
    # test rewrite import from module

# Generated at 2022-06-21 17:30:19.047981
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    node = ast.parse("import six", mode="single")
    import_rewrite = BaseImportRewrite()
    result = import_rewrite.visit(node)
    assert result.body[0] == ast.Try(
        handlers=[ast.ExceptHandler(
            type=None,
            name=None,
            body=[ast.Import(names=[ast.alias(name="six.moves")])])],
        orelse=[],
        body= [ast.Import(names=[ast.alias(name="six")])])


# Generated at 2022-06-21 17:30:28.311076
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('six.moves.urllib.request', 'urllib.request')]

    tree = ast.parse('import six.moves.urllib.request')
    inst = Test(tree)
    node = inst.visit(tree.body[0])
    code = 'import six.moves.urllib.request\nimport urllib.request\nexcept ImportError:\n    pass'
    assert ast.dump(node) == ast.dump(ast.parse(code).body[0])


# Generated at 2022-06-21 17:30:29.688967
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == {'transform'}



# Generated at 2022-06-21 17:30:52.009606
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not hasattr(BaseTransformer, 'transform'), 'Do not implement BaseTransformer.transform'


# Generated at 2022-06-21 17:31:00.590005
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class Test(BaseImportRewrite):
        rewrites = [('re', 'six.moves')]

    # Original Python code as an instance of class ast.Module
    original = ast.parse('import re')
    tree = Test.transform(original).tree
    # Rewritten Python code as an instance of class ast.Module
    rewritten = ast.parse('try:\n'
                          '    import re\n'
                          'except ImportError:\n'
                          '    import six.moves.re as re')
    assert ast.dump(rewritten) == ast.dump(tree)



# Generated at 2022-06-21 17:31:10.758403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    from typed_ast import ast3 as ast

    from typed_astunparse import unparse
    from typed_astunparse.unparser import Unparser

    class MyClass(BaseImportRewrite):
        rewrites = [('six', 'typed_astunparse.six')]

    class MyTests(unittest.TestCase):  # type: ignore
        def setUp(self):
            self.maxDiff = None  # type: ignore

        def test_rewrite(self):
            code = 'import six'
            tree = ast.parse(code)

            expected = 'try:\n    import typed_astunparse.six\nexcept ImportError:\n    import six'
            tree = MyClass.transform(tree).tree
            out = Unparser(tree)  # type: ignore

# Generated at 2022-06-21 17:31:11.919453
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1 + 1')
    res = BaseNodeTransformer.transform(tree)
    assert res.tree == tree
    assert res.changed is False



# Generated at 2022-06-21 17:31:19.899245
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class NodeTransformerImpl(BaseImportRewrite):
        rewrites = [
            ('os.path', 'posixpath'),
            ('io', 'StringIO')
        ]
    root = ast.parse('import os.path')
    result = NodeTransformerImpl.transform(root)
    assert result.changed
    assert 'import os.path' not in result.code
    assert 'try:\n    import os.path' in result.code
    assert 'except ImportError:' in result.code
    assert 'import os.path as os' in result.code
    assert 'import posixpath' in result.code


# Generated at 2022-06-21 17:31:24.837396
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite.__new__(BaseImportRewrite)
    assert x._tree is None
    assert x._tree_changed is False


# Generated at 2022-06-21 17:31:30.838812
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestClass(BaseNodeTransformer):
        dependencies = ['a']

        @classmethod
        def transform(cls, tree):
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)
    tree = ast.parse("1 + 1")
    assert TestClass.transform(tree) == TransformationResult(tree, False, ['a'])

# Generated at 2022-06-21 17:31:32.286094
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(None)

# Generated at 2022-06-21 17:31:43.227459
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # First without rewriting
    import_statements = [
        ast.Import(names=[ast.alias(name='foo',
                                    asname=None)])]
    
    BaseImportRewrite.rewrites = [
        ('foo', 'foo2'),
        ('bar', 'bar2')]

    class TestImportRewriter(BaseImportRewrite):
        pass

    assert TestImportRewriter.transform(ast.Module(body=import_statements)).changed is False

    # Without rewrite and with alias
    import_statements = [
        ast.Import(names=[ast.alias(name='foo',
                                    asname='baz')])]
    
    BaseImportRewrite.rewrites = [
        ('foo', 'foo2'),
        ('bar', 'bar2')]


# Generated at 2022-06-21 17:31:53.637217
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..target import transform_py3_to_py2

    node = ast.parse('''from six.moves import range''')
    tree = BaseImportRewrite.transform(node).tree
    assert transform_py3_to_py2(ast.dump(tree)) == '''try:
    from six.moves import range
except ImportError:
    from six.moves.range import range'''

    node = ast.parse('''from six.moves import range as __range''')
    tree = BaseImportRewrite.transform(node).tree
    assert transform_py3_to_py2(ast.dump(tree)) == '''try:
    from six.moves import range as __range
except ImportError:
    from six.moves.range import range as __range'''


# Generated at 2022-06-21 17:33:01.913617
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TempTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse(
        '''
        def foo(x, y):
            pass
        '''
    )
    temp_transformer = TempTransformer(tree)
    assert tree == ast.parse(
        '''
        def foo(x, y):
            pass
        '''
    )
    assert temp_transformer._tree == ast.parse(
        '''
        def foo(x, y):
            pass
        '''
    )
    assert temp_transformer._tree_changed == False


# Generated at 2022-06-21 17:33:04.326044
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_rewrite_transformer = BaseImportRewrite()


# Generated at 2022-06-21 17:33:12.770884
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Testing module name replacing
    class ImportRewriteA(BaseImportRewrite):
        rewrites = [('example', 'new_example')]

    assert ast.dump(ast.parse('''
        import example
    '''.strip()), sort_names=True) == ast.dump(ImportRewriteA.transform(ast.parse('''
        import example
    '''.strip())).tree, sort_names=True)

    assert ast.dump(ast.parse('''
        import example as ex
    '''.strip()), sort_names=True) == ast.dump(ImportRewriteA.transform(ast.parse('''
        import example as ex
    '''.strip())).tree, sort_names=True)


# Generated at 2022-06-21 17:33:21.703596
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import get_fixture
    from ..tests.base import get_transformed_code
    import astor
    with get_fixture('import_rewrite.py') as f:
        source = f.read()
    trans_code = get_transformed_code(BaseImportRewrite, source)
    actual_tree = ast.parse(trans_code)
    expected_tree = ast.parse(source.replace('import os', 'import posix as os'))
    assert astor.to_source(actual_tree) == astor.to_source(expected_tree)

# Generated at 2022-06-21 17:33:26.976179
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'type'

        @classmethod
        def transform(cls, tree):
            return "success"
    assert TestTransformer.target == 'type'
    assert TestTransformer.transform('value') == "success"

# Generated at 2022-06-21 17:33:40.247791
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Tests visit_ImportFrom method for BaseImportRewrite class"""

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six_with_aliases')]

    statement_from_import = ast.parse("from six import with_metaclass")
    statement_from_import1 = ast.parse("from six_with_aliases import with_metaclass")
    statement_from_import2 = ast.parse("from six import with_metaclass as with_metaclass1")
    statement_from_import3 = ast.parse("from six_with_aliases import with_metaclass as with_metaclass1")
    statement_from_import4 = ast.parse("from six import *")

# Generated at 2022-06-21 17:33:42.479016
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert hasattr(BaseTransformer, 'transform')


# Generated at 2022-06-21 17:33:49.258389
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        def test_method(self):
            pass

    inst = Test(None)
    assert isinstance(inst, Test)
    assert isinstance(inst, BaseNodeTransformer)
    assert hasattr(inst, '_tree')
    assert hasattr(inst, '_tree_changed')
    assert hasattr(inst, 'test_method')

# Generated at 2022-06-21 17:33:52.952487
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    value = True
    try:
        import_rewrite()
    except TypeError:
        value = False
    assert value



# Generated at 2022-06-21 17:33:58.321885
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer, ast.NodeTransformer):
        pass

    result = Transformer.transform(ast.parse('x = 1'))
    assert isinstance(result.tree, ast.AST)
    assert result.changed is False
    assert result.dependencies == []