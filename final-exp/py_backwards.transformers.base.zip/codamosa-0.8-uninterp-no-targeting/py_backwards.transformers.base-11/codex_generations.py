

# Generated at 2022-06-21 17:24:17.408895
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from AbstractBaseClasses import BaseNodeTransformer
    new = BaseNodeTransformer()
    assert(new.dependencies is not None)


# Generated at 2022-06-21 17:24:23.806049
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import re
    import typed_ast.ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typed_ast.ast3', 'ast')]
        target = 'python3.6'

    code = 'import typed_ast.ast3'
    root = ast.parse(code)

    transformed = TestTransformer.transform(root)
    assert len(transformed.tree.body) == 1

    try_stmt = transformed.tree.body[0]  # type: ast.Try
    assert isinstance(try_stmt, ast.Try)
    assert len(try_stmt.body) == 1
    assert isinstance(try_stmt.body[0], ast.Import)
    assert try_stmt.body[0].names[0].name == 'ast'


# Generated at 2022-06-21 17:24:25.489881
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with raises(TypeError):
        BaseTransformer()

# Generated at 2022-06-21 17:24:28.321099
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    instance = BaseNodeTransformer(tree=ast.parse(text='test'))
    assert isinstance(instance, BaseNodeTransformer)

# Generated at 2022-06-21 17:24:29.735781
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert isinstance(BaseNodeTransformer(), BaseNodeTransformer)


# Generated at 2022-06-21 17:24:36.799527
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    with patch('typed_ast.ast3.parse', return_value=ast.parse(textwrap.dedent("""\
        import a

        def foo():
            pass
        """))):
        tree = ast.parse('foo')
        class Transformer(BaseImportRewrite):
            rewrites = [('a', 'b')]
        res = Transformer.transform(tree)

        expected_tree = ast.parse(textwrap.dedent("""\
            try:
                import a
            except ImportError:
                import b as a


            def foo():
                pass
            """))

        assert res.tree == expected_tree



# Generated at 2022-06-21 17:24:38.222765
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__init__(BaseImportRewrite, ast.AST())

# Generated at 2022-06-21 17:24:44.749462
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    result: TransformationResult = TestBaseImportRewrite.transform(
        ast.parse('from six.moves import urllib'))
    assert result.tree.body == ['try:\n',
                                '    from six import urllib\n',
                                'except ImportError:\n',
                                '    from six.moves import urllib']
    assert result.changed is True
    assert result.dependencies == ['six']



# Generated at 2022-06-21 17:24:55.961195
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    
    import_module = ast.parse(
        'from foo import x, y as yy, *\n'
        'from foo.x import a, b as bb')

    expected_import_module = ast.parse(
        'from bar import x, y as yy, *\n'
        'from bar.x import a, b as bb')

    test_tree = ast.parse(
        'import foo\n'
        'import foo.baz\n'
        'import foo.baz.bar')

    expected_tree = ast.parse(
        'import bar\n'
        'import bar.baz\n'
        'import bar.baz.bar')

    result_tree

# Generated at 2022-06-21 17:25:00.149953
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrites = ['a', 'b', 'c']
    target = 'python'
    node = ast.Import(names=[
        ast.alias(name='a', asname='d')])

    # BaseImportRewrite expected to be BaseImportRewrite
    assert BaseImportRewrite(node).__class__ is BaseImportRewrite

# Generated at 2022-06-21 17:25:18.325187
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    # Old module name is not replaced
    node = ast.parse('''
import demo
''')
    transformer = BaseImportRewrite.transform(node)
    assert astor.to_source(transformer.tree) == 'import demo'

    # New module name is added if old module is not found
    node = ast.parse('''
import unknown.demo
''')
    transformer = BaseImportRewrite.transform(node)
    assert astor.to_source(transformer.tree) == '''
try:
    import unknown.demo
except ImportError:
    import demo
'''

    # Old module name is replaced in import from statement
    node = ast.parse('''
from unknown.demo import *
''')
    transformer = BaseImportRewrite.transform(node)
    assert astor

# Generated at 2022-06-21 17:25:24.993850
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("import sys\nimport os as o")
    node_transformer = BaseImportRewrite(tree)
    assert isinstance(node_transformer, BaseNodeTransformer)
    assert isinstance(node_transformer, BaseImportRewrite)
    assert node_transformer._tree == tree
    assert node_transformer._tree_changed == False
    assert node_transformer.rewrites == []

# Generated at 2022-06-21 17:25:34.684820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    class Transformer(BaseImportRewrite):

        rewrites = [('numopy', 'numpy')]

    node = ast.parse('''
from numopy import beta
from numopy.beta import beta
import numopy
from numopy import beta as b
from numopy.beta import beta as b
import numopy as numopy

beta()
b()

beta.beta()
b.beta()

numopy.beta.beta()
numopy.beta()
''')


# Generated at 2022-06-21 17:25:46.421906
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class FakeTransformer(BaseImportRewrite):
        rewrites = [
            ('legacy.import', 'new.package')
        ]

    tree = ast.parse('import legacy.import')
    assert FakeTransformer.transform(tree).tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='new.package', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='legacy.import', asname=None)])])],
        orelse=[],
        finalbody=[])


# Generated at 2022-06-21 17:25:48.683177
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError:
        pass

# Generated at 2022-06-21 17:25:56.283638
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import CompilationTarget
    from .base_node_transformer import BaseNodeTransformer
    from typed_ast import ast3 as ast


    class Transformer(BaseNodeTransformer):
        target = CompilationTarget.PY2
    
    tree = ast.parse('1 + 1')
    transformer = Transformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed is False



# Generated at 2022-06-21 17:25:58.678998
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test constructor
    assert isinstance(BaseImportRewrite(), BaseImportRewrite)



# Generated at 2022-06-21 17:25:59.178001
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:26:02.309870
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert hasattr(BaseTransformer, "target")
    assert hasattr(BaseTransformer, "transform")

# Generated at 2022-06-21 17:26:07.848449
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from .transformers.six_transformer import SixTransformer
    from ..utils.test_utils import transform
    from ..utils.loader import load_source
    from ..types import CompilationTarget

    source = "import six"

    tree = load_source(source)
    result = SixTransformer.transform(tree)
    assert result.tree is tree
    assert not result.changed
    assert result.dependencies == []

    result = transform(source, CompilationTarget.PY36)
    assert result == 'import six\n'

# Generated at 2022-06-21 17:26:19.661023
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        pass

    assert Test._tree is None
    assert Test._tree_changed is False
    assert Test.visit(Test, None) is None
    assert Test._tree._tree is None
    assert Test._tree_changed is False

# Generated at 2022-06-21 17:26:28.454440
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    # Import
    node = ast.parse('import foo').body[0]
    expected = ast.parse('try: import foo\nexcept: import bar')

    tree = Transformer.transform(ast.parse('import foo'))
    assert tree.tree == expected
    assert tree.changed

    # Import as
    node = ast.parse('import foo as barz').body[0]
    expected = ast.parse('try: import foo as barz\nexcept: import bar as barz')

    tree = Transformer.transform(ast.parse('import foo as barz'))
    assert tree.tree == expected
    assert tree.changed

    assert Transformer.transform(ast.parse('import foo.baz')).changed
    assert Trans

# Generated at 2022-06-21 17:26:38.711100
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_tools import ast_to_src
    from .imports import RewritePython2Import

    import_to_rewrite_src = """
    import sys
    import os
    import shutil
    import pathlib
    """

    import_to_rewrite_tree = ast.parse(import_to_rewrite_src)

    transformed_src = ast_to_src(RewritePython2Import.transform(import_to_rewrite_tree).tree)

# Generated at 2022-06-21 17:26:46.769696
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse

    class SimpleImportRewrite(BaseImportRewrite):
        rewrites = [('old_name', 'new_name')]

    source = 'import old_name'
    expected = import_rewrite.get_body(previous=source, current='import new_name')[0]
    expected = unparse(expected).strip()

    node = ast.parse(source)
    actual = SimpleImportRewrite.transform(node)
    actual = unparse(actual.tree).strip()

    assert expected == actual



# Generated at 2022-06-21 17:26:47.373724
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer()

# Generated at 2022-06-21 17:26:58.543562
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import_node = ast.ImportFrom(module="pandas", names=[ast.alias(name="DataFrame", asname="DF")], level=0)
    class Test(BaseImportRewrite):
        rewrites = [("pandas", "pandas_ext")]
    result = Test.transform(import_node)

# Generated at 2022-06-21 17:27:02.380614
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = ImportRewrite.transform(tree)
    assert result.tree_changed
    assert ast.dump(result.tree) == 'import_rewrite(ast.Import(names=[ast.alias(name=\'foo\', asname=None)]), ast.Import(names=[ast.alias(name=\'bar\', asname=None)]))'

# Generated at 2022-06-21 17:27:04.473588
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.rewrites == []
    BaseImportRewrite()

# Generated at 2022-06-21 17:27:10.134327
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..utils.ast import dump

    class ImportRewrite(BaseImportRewrite):
        target = CompilationTarget.C_CPP_EXTENSION
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    tree = ImportRewrite().visit(tree)

    assert dump(tree) == 'try:\n    import bar as foo\nexcept ImportError:\n    import foo'



# Generated at 2022-06-21 17:27:16.755417
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import get_source
    from ..utils.inspect import get_ast_from_source

    source = get_source(BaseImportRewrite)
    tree = get_ast_from_source(source)

    assert tree is not None
    b = BaseImportRewrite(tree)

    assert b._tree_changed is False
    assert b.rewrites == []

# Generated at 2022-06-21 17:27:25.883209
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert repr(BaseNodeTransformer(ast.AST()))

# Generated at 2022-06-21 17:27:30.356152
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Dummy(BaseTransformer):
        pass
    assert Dummy.__name__ == "Dummy"
    assert Dummy.target is None



# Generated at 2022-06-21 17:27:34.371135
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .base import LazyTransformer
    from ..types import CompilationTarget, TransformationResult
    from ..target import PY2_TARGET, PY3_TARGET
    from ..utils import source_to_tree
    from ..utils.snippet import snippet, extend
    import ast, unittest

    # Define the class and methods needed by the base class
    class RewriterA(BaseImportRewrite):
        target = CompilationTarget(version=PY2_TARGET.version)
        rewrites = [('six', 'mysix')]
        dependencies = ['mysix']

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            import ast
            # This will have the same effect as
            # ast.NodeTransformer.visit, which calls
            # ast.NodeTransformer

# Generated at 2022-06-21 17:27:38.741008
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class _BaseNodeTransformer(BaseNodeTransformer):
        def visit_Pass(self, node: ast.Pass):
            return ast.Continue()

    source = "pass"
    tree = ast.parse(source)
    result = _BaseNodeTransformer.transform(tree)
    assert result.tree.body[0].__class__.__name__ == 'Continue'

# Generated at 2022-06-21 17:27:50.021034
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Testing object
    class MyBaseImportRewrite(BaseImportRewrite):
        rewrites = [('version1', 'version2')]


    tree = ast.parse('import version1')
    assert MyBaseImportRewrite.transform(tree).changed is True

    tree = ast.parse('import version1.submodule')
    assert MyBaseImportRewrite.transform(tree).changed is True

    tree = ast.parse('import version1 as ver')
    assert MyBaseImportRewrite.transform(tree).changed is True

    tree = ast.parse('import other_version')
    assert MyBaseImportRewrite.transform(tree).changed is False

    tree = ast.parse('import other_version.sub_module')
    assert MyBaseImportRewrite.transform(tree).changed is False



# Generated at 2022-06-21 17:27:51.620509
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None)

# Generated at 2022-06-21 17:27:56.943460
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .fn import BaseFnTransformer
    tree = ast.parse('pass')
    bnt = BaseNodeTransformer(tree)
    assert bnt._tree == tree
    assert bnt._tree_changed == False
    assert BaseFnTransformer.transform(tree) == tree
    assert BaseFnTransformer.dependencies == []
    return True

# Generated at 2022-06-21 17:27:58.913243
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite(None).rewrites == []

# Generated at 2022-06-21 17:28:02.582203
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("a = 1")
    nt = BaseNodeTransformer(tree)
    assert nt._tree is tree
    assert nt._tree_changed is False

# Generated at 2022-06-21 17:28:06.872944
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Could be any class that inherits BaseImportRewrite
    import six
    assert issubclass(six.MovedModule, BaseImportRewrite)
    assert six.MovedModule.rewrites
    assert six.MovedModule.dependencies

# Generated at 2022-06-21 17:28:14.279557
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__()

# Generated at 2022-06-21 17:28:22.791675
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import os
    import io

    # We need this because we are going to break normal import
    # It will raise ImportError for 'io' module
    # And it will be replaced with our stub
    class IoTest:
        pass

    old_import = __builtins__['__import__']
    def my_import(name, *args):
        if name == 'io':
            raise ImportError('No module named io')
        return old_import(name, *args)

    __builtins__['__import__'] = my_import

    import six

    class Transformer(BaseImportRewrite):
        rewrites = [('io', 'six')]

    tree = ast.parse('''
import io
import six
from io import StringIO

StringIO('test')
''')


    Transformer.transform(tree)


# Generated at 2022-06-21 17:28:27.026789
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # 1
    cls = BaseNodeTransformer(tree=ast.parse("import foo"))
    assert cls._tree_changed is False # 1-1
    assert cls._tree is not None # 1-2


# Generated at 2022-06-21 17:28:35.337430
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    code = """
# File test.py, line 1
from a import *
from a import c
from a.d import f
from a.d import g, h
from a.d.j import k, l
"""

    node = ast.parse(code, mode='exec').body[0].value

    assert ast.dump(node) == code.strip()

    TestImportRewrite.transform(node)


# Generated at 2022-06-21 17:28:36.921308
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    b = BaseTransformer()
    b.target = 'x'
    assert b.target == 'x'

# Generated at 2022-06-21 17:28:37.740793
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer._tree is not None

# Generated at 2022-06-21 17:28:40.281383
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    result = BaseTransformer().transformation()
    assert result is not None

# Generated at 2022-06-21 17:28:51.333048
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import sys
    assert issubclass(BaseImportRewrite, ast.NodeTransformer)
    assert hasattr(BaseImportRewrite, 'rewrites')
    assert isinstance(BaseImportRewrite.rewrites, list)
    assert BaseImportRewrite.rewrites == []
    assert hasattr(BaseImportRewrite, '_replace_import')
    if sys.version_info[0] == 2:
        assert hasattr(BaseImportRewrite, 'visit_Import')
        assert hasattr(BaseImportRewrite, 'visit_ImportFrom')
    else:
        assert hasattr(BaseImportRewrite, 'visit_Import')
        assert hasattr(BaseImportRewrite, 'visit_ImportFrom')
    del sys
    del ast



# Generated at 2022-06-21 17:28:57.118043
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class FakeNodeTransformer(BaseNodeTransformer):
        pass

    fake_tree = ast.parse("")
    fake_node_transformer = FakeNodeTransformer(fake_tree)
    assert fake_node_transformer._tree == fake_tree
    assert fake_node_transformer._tree_changed == False


# Generated at 2022-06-21 17:29:04.682027
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.fixtures import ImportFrom, Import, Try
    from ..utils.ast import parse
    from ..utils.helpers import get_node
    rewrites = [('old', 'new')]
    class Dummy(BaseImportRewrite):
        rewrites = rewrites
    # empty import from
    import_from = ImportFrom(module='a')
    try:
        Dummy().visit(import_from)
    except BaseException:
        assert False
    # import from with rewrite
    import_from = ImportFrom(module='old')
    result = Dummy().visit(import_from)
    expected = Try(body=[ImportFrom(module='new')])
    assert isinstance(result, ast.Try)
    assert get_node(parse(expected), get_node(result))
    # import from with

# Generated at 2022-06-21 17:29:25.480082
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import transform_ast

    tree = ast.parse('from foo.bar import example, other')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('foo.bar', 'baz')]
    transformer.visit(tree)
    tree = transformer._tree

    assert transform_ast(tree) == 'try:\n    from foo.bar import example, other\nexcept ImportError:\n    from baz import example, other'

# Generated at 2022-06-21 17:29:37.714446
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # NOTE: BaseImportRewrite.transform() is not unit tested as it's mostly
    # a wrapper for visit_Import[From]() methods.
    import astor  # type: ignore

    source = """
from foo import A
from baz.bar.baz import B
import foo
import bar
import baz.bar.baz
from bar.baz import C, D
"""

    class PrefixTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar.baz'),
            ('bar', 'baz'),
            ('baz', 'baz.bar.baz')
        ]


# Generated at 2022-06-21 17:29:44.047846
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    import_ = ast.Import(names=[ast.alias(name='a')])

    node = ImportRewrite.transform(import_).tree

    expected = ast.Try(
        body=[ast.Import(names=[ast.alias(name='b')])],
        handlers=[
            ast.ExceptHandler(
                type=ast.Name(id='ImportError', ctx=ast.Load()),
                name=None,
                body=[ast.Import(names=[ast.alias(name='a')])])
        ],
        orelse=[])

    assert node == expected



# Generated at 2022-06-21 17:29:46.290343
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer
    assert transformer.target is None

# Generated at 2022-06-21 17:29:48.395066
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .base import BaseNodeTransformer
    BaseNodeTransformer()

# Generated at 2022-06-21 17:30:00.056106
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('foo.baz', 'spam.baz')]

    content = '''
from foo.baz import abc
from foo.baz import xyz as xyx
from foo.zzz import qwe
from foo import bar
'''.strip()

    expected = '''
try:
    from foo.baz import abc
except ImportError:
    from spam.baz import abc

try:
    from foo.baz import xyx
except ImportError:
    from spam.baz import xyx

from foo.zzz import qwe
from foo import bar
'''.strip()

    tree = ast.parse(content)
    result = MyImportRewrite.transform(tree)

    from ..utils.ast_to_source import ast_

# Generated at 2022-06-21 17:30:10.575527
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-21 17:30:17.954820
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # BaseImportRewrite is abstract class, so we need to get instance
    # of child class.
    class Child(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
from foo import bar
from foo import *
from foo import bar, baz
''')

    assert isinstance(ast.dump(tree), str)
    assert isinstance(ast.dump(Child(tree).visit(tree)), str)
    assert isinstance(ast.dump(Child.transform(tree)), str)



# Generated at 2022-06-21 17:30:19.690717
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass


# Generated at 2022-06-21 17:30:22.048722
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert isinstance(BaseNodeTransformer(), BaseNodeTransformer)



# Generated at 2022-06-21 17:30:39.244737
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Tests functionality of method visit_Import
    of class BaseImportRewrite.
    """
    import astor
    tree = ast.parse('import datetime')
    rewriter = BaseImportRewrite(tree)
    rewriter.rewrites = [('datetime', 'dateutil')]

    result = rewriter.visit(tree)
    assert isinstance(result, ast.Try)
    assert astor.to_source(result) == '''\
try:
    import datetime
except ImportError:
    import dateutil as datetime
'''



# Generated at 2022-06-21 17:30:49.791197
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    expected_result = """
        try:
            from a import b
        except ImportError:
            try:
                from c import d
            except ImportError:
                from a import b
    """
    import_stmt = ast.parse('from a import b', '<string>', 'exec')
    imports = import_stmt.body[0]
    import_rewrite = BaseImportRewrite([('a', 'c')])
    import_rewrite.visit_ImportFrom(imports)
    assert ast.dump(imports, annotate_fields=False, include_attributes=False) == expected_result, \
        'The result is not what is expected'


# Generated at 2022-06-21 17:30:58.902641
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old', 'new')
        ]
    import_ast = ast.parse('import old').body[0]
    tree = TestBaseImportRewrite.transform(import_ast)
    assert isinstance(tree[0], ast.Try)
    assert tree[0].body[0].names[0].name == 'new'
    assert tree[0].body[1].name.s == 'old'


# Generated at 2022-06-21 17:31:10.386378
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'quux.qux'),
            ('foo.bar.baz', 'quux.qux.quux'),
        ]

    transformer = TestTransformer(None)


# Generated at 2022-06-21 17:31:19.863557
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..compiler import Compiler
    from ..compiler.dependency import get_dependencies_graph
    
    # TODO: Improve this test
    compiler = Compiler()
    graph = get_dependencies_graph(compiler.target)
    node_transformers = [cls for cls in BaseNodeTransformer.__subclasses__()
                         if cls.target == CompilationTarget.PYTHON3]
    for transformer in node_transformers:
        if transformer not in graph:
            raise ValueError('BaseNodeTransformer {} has no dependencies'.format(type.__name__))

# Generated at 2022-06-21 17:31:30.193335
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_to_rewrite = ('flask.testing', 'pytest_flask.plugin')
    rewrites = [from_to_rewrite]
    import_rewrite = BaseImportRewrite(rewrites=rewrites)

    before_import = ast.Import(names=[ast.alias(name='flask.testing', asname=None)])
    after_import = ast.Import(names=[ast.alias(name='pytest_flask.plugin', asname=None)])

    assert import_rewrite.visit_Import(before_import) == after_import


# Generated at 2022-06-21 17:31:34.597187
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TreeTransformer(BaseNodeTransformer):
        def visit_Assign(self, node):
            pass

    tree = ast.parse("a = 1")
    TreeTransformer(tree)



# Generated at 2022-06-21 17:31:42.032462
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import os
    import astor

    original = '''import os
import socket'''
    expected = '''try:
    import os
except ImportError:
    import socket'''
    rewrites = [('os', 'socket')]
    tree = ast.parse(original)
    transformer = BaseImportRewrite(tree)
    transformer.__class__.rewrites = rewrites
    transformer.visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-21 17:31:53.103636
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('example', 'example_new')]

    # Type hint: typed_ast.ast3.Import
    import_rewrite = ast.Import(names=[ast.alias(name='example',
                                                asname='example')])

    transformed = TestTransformer.transform(import_rewrite)
    assert transformed.changed

    # Type hint: typed_ast.ast3.Try
    try_rewrite = ast.Try(
        body=[import_rewrite],
        handlers=[],
        orelse=[],
        finalbody=[],
    )

    # Type hint: typed_ast.ast3.Import

# Generated at 2022-06-21 17:32:02.888054
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse
    from .utils import dedent
    from .test_transformer_base import run_transformer_test

    @snippet
    def _run_test(target):
        def _import():
            module.method()

        def _import_from():
            from module import method
            method()

        def _nested_import_from():
            from module.submodule import method
            method()

    class Transformer(BaseImportRewrite):
        rewrites = [('module', 'm')]


# Generated at 2022-06-21 17:32:26.211146
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from textwrap import dedent

    node = ast.parse(dedent('''
        from foo.bar import baz
        from foo.bar import foo as bar
        from foo.baz import *
        from foo import bar
        '''))

    transformed = BaseImportRewrite(node).visit(node)  # type: ignore


# Generated at 2022-06-21 17:32:32.461385
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('modules', 'my_modules')]

    node = ast.parse("import modules").body[0]
    assert isinstance(TestTransformer.visit(TestTransformer, node), ast.Try)
    assert TestTransformer.visit(TestTransformer, node).body[0].body[0].names[0].name == 'my_modules'

    node = ast.parse("import something").body[0]
    assert TestTransformer.visit(TestTransformer, node) == node



# Generated at 2022-06-21 17:32:40.674196
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockTransformer(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    tree = ast.parse('''
import previous
''')
    result = MockTransformer.transform(tree)

    assert result.tree == ast.parse('''
try:
    import previous
except ImportError:
    import current
''')
    assert result.changed



# Generated at 2022-06-21 17:32:52.485903
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("from a import b, c")
    BaseImportRewrite.rewrites = [("a", "b")]
    inst = BaseImportRewrite(tree)
    inst.visit(tree)
    assert(type(tree.body[0]) == ast.Try)
    assert(type(tree.body[0].body[0]) == ast.ImportFrom)
    assert(tree.body[0].body[0].module == "b")
    assert(tree.body[0].body[1].body[0].names[0].name == "a")
    assert(type(tree.body[0].handlers[0].body[0]) == ast.ImportFrom)
    assert(tree.body[0].handlers[0].body[0].module == "a")

# Generated at 2022-06-21 17:33:03.505482
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class DummyNodeTransformer(BaseNodeTransformer):  # type: ignore
        """Example of derived class.

        Implements visit_Module method which marks transformation
        as done by setting variable tree_changed to True.
        """

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            return self.generic_visit(node)

    class MockAst(ast.AST):  # type: ignore
        """Mock of ast class.

        Class is used as fake Ast tree in test.
        """

        _fields = ()

    # Create mock of tree
    TEST_TREE = MockAst()
    # Create instance of DummyNodeTransformer
    DUMMY_TRANSFORMER = DummyNodeTransformer(TEST_TREE)
    # Call visit_Module method

# Generated at 2022-06-21 17:33:10.617421
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('spam', 'eggs')
        ]


# Generated at 2022-06-21 17:33:20.810299
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('collections.namedtuple', 'typing.NamedTuple')
        ]

    tree = ast.parse('import collections.namedtuple')
    tree2 = Rewrite.transform(tree).tree

    assert isinstance(tree2.body[0], ast.Try)
    assert isinstance(tree2.body[0].body[0], ast.Import)
    assert tree2.body[0].body[0].names[0].name == 'typing.NamedTuple'


# Generated at 2022-06-21 17:33:29.477229
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    source = 'import sys'
    tree = ast.parse(source)
    import_cls = type('Import',
                      (BaseNodeTransformer,),
                      dict(__init__=BaseNodeTransformer.__init__,
                           _tree=None,
                           _tree_changed=None,
                           visit_Import=BaseNodeTransformer.visit_Import,
                           transform=BaseNodeTransformer.transform))
    import_cls(tree)
    assert astor.to_source(tree) == source

# Generated at 2022-06-21 17:33:33.565510
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class MyTransformer():
        def transform(arg):
            return None
    assert BaseTransformer.__init__(MyTransformer, type(None), []) == None


# Generated at 2022-06-21 17:33:43.054690
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('six', 'bzt')]

    tree = ast.parse("""
import six

assert True
""")

    result = Transformer.transform(tree)

    assert result.changed is True
    assert result.dependencies == ['bzt']

    assert ast.dump(result.tree) == """
Module(body=[Try(body=[Import(names=[alias(name='bzt', asname='six')])], handlers=[ExceptHandler(type=None, name=None, body=[Import(names=[alias(name='six', asname='six')])])], orelse=[], finalbody=[]), Assert(test=NameConstant(value=True), msg=None)])
"""

