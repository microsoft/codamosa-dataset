

# Generated at 2022-06-21 17:24:21.497163
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert isinstance(BaseImportRewrite(), BaseImportRewrite)

# Generated at 2022-06-21 17:24:30.589652
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Test for basic instance variables
    class TestTransformer1(BaseTransformer):
        target = CompilationTarget.PYTHON
    assert TestTransformer1.target == CompilationTarget.PYTHON
    assert TestTransformer1()

    # Test for error when subclass of BaseTransformer doesn't have target set
    class TestTransformer2(BaseTransformer):
        pass
    try:
        assert TestTransformer2()
    except AttributeError as e:
        assert isinstance(e, AttributeError)



# Generated at 2022-06-21 17:24:34.129380
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    node = ast.parse("import json").body[0]
    transformation_result = BaseImportRewrite.transform(node)

    assert transformation_result.changed is False
    assert astor.to_source(node) == astor.to_source(transformation_result.tree)



# Generated at 2022-06-21 17:24:39.690262
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    cls = lambda:None
    cls.transform = lambda:None
    cls.dependencies = []
    cls.target = CompilationTarget.PY38.value
    tree = ast.parse("print('Hello, World!')")
    obj = BaseNodeTransformer(tree)
    obj.visit(tree)


# Generated at 2022-06-21 17:24:46.460530
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astunparse as astup
    from ast import ImportFrom
    from ast import Import, alias
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON2
        rewrites = {'six.moves': 'six.moves'}
    input_module = Import(names=[alias(name='six', asname='six')])
    input_module2 = ImportFrom(module='six.moves',
                               names=[alias(name='ABC', asname=None), alias(name='MutableMapping', asname=None)],
                               level=0)
    print(astup.unparse(input_module))
    print(astup.unparse(input_module2))
    print(astup.unparse(TestTransformer.transform(input_module).new_tree))


# Generated at 2022-06-21 17:24:53.882353
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='a', 
                          names=[ast.alias(name='b.c',
                                           asname='d')],
                          level=0)

    rewriter = BaseImportRewrite()
    rewriter.rewrites = [('b.c', 'b.xxx.c')]
    rewriter.visit_ImportFrom(node)

    assert node.module == 'a'
    assert node.names[0].name == 'b.xxx.c'
    assert node.names[0].asname == 'd'

# Generated at 2022-06-21 17:25:00.430859
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    target = CompilationTarget('python', '3.5')

    class Foo(BaseImportRewrite):
        target = target
        rewrites = [('foo.bar', 'foobar')]

    t = ast.parse("import foo.bar; from foo import bar")
    r = Foo.transform(t)
    assert r.tree.body[0].body[0].body[0].value.module == 'foobar'
    assert r.tree.body[1].names[0].name == 'bar'
    assert r.tree.body[1].module == 'foo'

# Generated at 2022-06-21 17:25:01.355138
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass



# Generated at 2022-06-21 17:25:02.765604
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .snippets import import_rewrite
    from .snippets import ast_of_source

# Generated at 2022-06-21 17:25:08.660044
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('from1', 'to1'), ('from2', 'to2')]

    tree = ast.parse("from one import *")
    transformed_tree, _, _ = TestTransformer.transform(tree)

    assert ast.dump(tree) == ast.dump(transformed_tree)

    tree = ast.parse("from two import *")
    transformed_tree, _, _ = TestTransformer.transform(tree)

    assert ast.dump(tree) == ast.dump(transformed_tree)

    tree = ast.parse("from from1 import *")
    transformed_tree, _, _ = TestTransformer.transform(tree)

    assert ast.dump(tree) != ast.dump(transformed_tree)

# Generated at 2022-06-21 17:25:18.069261
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import ast
    from astmonkey import transformers

    module_name = b'my_module'
    code = b'import my_module'
    tree = ast.parse(code)

    class MockImportRewrite(transformers.BaseImportRewrite):
        rewrites = [
            ('my_module', 'new_module'),
        ]

    result = MockImportRewrite.transform(tree)

    assert result.tree.body[0].body[0].finalbody[0].value.names[0].name == 'new_module'
    assert result.tree.body[0].body[0].handlers[0].type.names[0].name == 'ImportError'

# Generated at 2022-06-21 17:25:21.794623
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    tree = ast.parse('x = 123')
    trans = BaseTransformer()
    assert trans.target is None



# Generated at 2022-06-21 17:25:22.372033
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-21 17:25:32.047038
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'a.b'
    to = 'c.d'

    class T(BaseImportRewrite):
        rewrites = [(from_, to)]


    assert ast.dump(ast.parse(
        'from a.b.f import g, h as i')) == ast.dump(T().visit(ast.parse(
            'from a.b.f import g, h as i')))
    assert ast.dump(ast.parse(
        'from c.d.f import g, h as i')) == ast.dump(T().visit(ast.parse(
            'from a.b.f import g, h as i')))


# Generated at 2022-06-21 17:25:37.512947
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():

    class Node(BaseNodeTransformer):
        def visit_Num(self, node: ast.Num) -> ast.Num:
            return ast.Num(n=node.n + 1)

    tree = ast.parse('1 + 2')
    new_tree = Node.transform(tree).tree
    assert type(new_tree.body[0].value.left) is ast.Num
    assert new_tree.body[0].value.left.n == 2



# Generated at 2022-06-21 17:25:44.665025
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    old_import = ast.Import(names=[ast.alias(name='old', asname=None)])
    new_tree = ast.Try(body=[ast.Import(names=[ast.alias(name='new', asname=None)])],
                       handlers=[
                           ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                             name=None,
                                             body=[old_import])
                       ],
                       orelse=[],
                       finalbody=[])

    result = Rewrite.transform(old_import)
    assert result.is_changed()
    assert ast.dump(result.get_tree()) == ast.dump(new_tree)



# Generated at 2022-06-21 17:25:53.967313
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_tree = ast.parse('import my_old_module')
    rewrite_tree = ast.parse('import my_new_module')

    class MyTransformer(BaseImportRewrite):
        rewrites = [('my_old_module', 'my_new_module')]

    result = MyTransformer.transform(import_tree)
    assert result.tree == rewrite_tree
    assert result.changed


# Generated at 2022-06-21 17:25:55.410436
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseImportRewrite._expected_args == ('tree',)

# Generated at 2022-06-21 17:26:05.704671
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ExampleTransformer(BaseImportRewrite):
        rewrites = [('urlparse', 'urllib.parse'), ('urljoin', 'urllib.parse.urljoin')]

    tree = ast.parse('from urlparse import urljoin, urlsplit\n'
                     'import xmlrpc.client')

    result = ExampleTransformer.transform(tree)
    assert result.changed


# Generated at 2022-06-21 17:26:17.383507
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..types import CompilationTarget
    from ..transformers.v3 import BaseImportRewrite

    class MyTransformer(BaseImportRewrite):
        target = CompilationTarget.V3
        rewrites = [('os', 'toos')]

    tree = ast.parse('''from os import path\npath.join(a, b)''')
    tree = MyTransformer.transform(tree)
    assert astor.to_source(tree.ast).strip() == '''\
try:
    from os import path
except ImportError:
    from toos import path

path.join(a, b)
'''.strip()

    tree = ast.parse('''from os import path as one, environ as two\npath.join(a, b)''')

# Generated at 2022-06-21 17:26:37.304881
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import sys
    from io import StringIO
    from subprocess import PIPE, Popen

    test_python_code = ("from test_module import test_function_1\n"
                        "from test_from.test_module import test_function_2\n"
                        "from test_from import test_function_3\n"
                        "from test_from.test_from.new_from_module import test_function_4\n"
                        "from test_module import *\n"
                        "from test_from.test_module import *\n"
                        "from test_from import *")

    rewrites = [('test_from.test_from.from_module', 'test_from.from_module')]
    import_rewrite_class = BaseImportRewrite
    import_rewrite

# Generated at 2022-06-21 17:26:38.822531
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.AST())

# Generated at 2022-06-21 17:26:45.499112
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    from typed_ast import ast3 as ast
    from ..utils.tests import const_node
    from . import BaseImportRewrite


    BaseImportRewrite.rewrites = [('requests', 'urllib.request')]
    class Dummy(BaseImportRewrite):
        target = 'python'
        dependencies = ['urllib']

    tree = ast.parse(
"""
import urllib

from requests import get, post
from requests.utils import get_dict
from requests.utils.nothing import nothing
""")
    Dummy.transform(tree)

# Generated at 2022-06-21 17:26:57.989944
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MyTransformer(BaseImportRewrite):
        rewrites = [
            ('urllib', 'urllib.request'),
            ('urllib.parse', 'urllib.parse'),
        ]
    
    # Test with module but no names from rewrites
    import_from = ast.parse('from urllib import urlopen').body[0]
    visitor = MyTransformer(ast.parse(''))
    assert isinstance(visitor.visit(import_from), ast.ImportFrom)

    # Test with module and all names from rewrites
    import_from = ast.parse('from urllib.parse import urlencode, parse_qsl').body[0]
    visitor = MyTransformer(ast.parse(''))
    result = visitor.visit(import_from)

# Generated at 2022-06-21 17:27:07.863296
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..pypytransformer import PyPyTransformer
    import ast as pyast
    rw = PyPyTransformer.rewrites[0]
    PyPyTransformer.rewrites = [rw]
    tree = pyast.parse("import PyQt5.QtCore")
    rw_tr = BaseImportRewrite(tree)
    rw_tr.visit(tree)
    print(pyast.dump(tree))

    tree = pyast.parse("from PyQt5 import QtCore, QtGui")
    rw_tr = BaseImportRewrite(tree)
    rw_tr.visit(tree)
    print(pyast.dump(tree))

    tree = pyast.parse("import numpy.random as rnd")
    rw_tr = BaseImportRewrite(tree)
    rw

# Generated at 2022-06-21 17:27:16.658197
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyNodeTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module):
            return node

    tree = ast.parse('1')
    t = MyNodeTransformer(tree)
    assert isinstance(t, MyNodeTransformer)
    assert isinstance(t, BaseNodeTransformer)
    assert isinstance(t, ast.NodeTransformer)
# Unit test function BaseNodeTransformer
test_BaseNodeTransformer()



# Generated at 2022-06-21 17:27:26.218522
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    source = 'import datetime'
    tree = ast.parse(source)
    transformer = BaseImportRewrite()
    transformer.rewrites.append(('datetime', 'dateutil.parser'))
    result = transformer.visit(tree)
    assert isinstance(result, ast.Try)
    assert result.body[0].value.names[0].name == 'datetime'
    assert result.body[1].type.id == 'ImportError'
    assert result.body[1].body[0].value.names[0].name == 'dateutil.parser'


# Generated at 2022-06-21 17:27:36.078704
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse('from urllib.request import urlopen, Request').body[0]  # type: ast.ImportFrom
    rewriter = BaseImportRewrite(None)
    rewriter.rewrites = [('urllib.request', 'urllib2')]
    rewriter.visit(node)

    assert node.module == 'urllib2'
    assert node.names[0].name == 'urlopen'
    assert node.names[1].name == 'Request'



# Generated at 2022-06-21 17:27:38.014519
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    inst = BaseTransformer()
    assert inst.target is None


# Generated at 2022-06-21 17:27:42.422877
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None
    assert isinstance(transformer.transform, staticmethod)


# Generated at 2022-06-21 17:28:02.733646
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    tree = ast.parse('''
    import old_module
    import old_module.submodule.name as name
    from old_module import Class
    from old_module.submodule import Class
    from old_module.submodule import Class as ClassName
    from old_module.submodule import Class, method
    ''')
    Transformer.transform(tree)

# Generated at 2022-06-21 17:28:08.766393
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # Arrange
    from typed_ast import ast3 as ast

    from ..utils.ast import get_tree_changes

    class NodeTransformer(BaseNodeTransformer):
        def visit_Module(self, node):
            node.body.append(ast.Expr(value=ast.Name(id='True')))
            return self.generic_visit(node)

    # Act
    tree = ast.parse('5')
    NodeTransformer.transform(tree)
    tree_changes = get_tree_changes(tree, ast.parse('5\n\ntrue'))

    # Assert
    assert tree_changes == {'added': ['true']}

# Generated at 2022-06-21 17:28:13.178021
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  try:
    BaseTransformer()
  except TypeError as e:
    assert str(e) == "Can't instantiate abstract class BaseTransformer with abstract methods transform"
  else:
    assert False



# Generated at 2022-06-21 17:28:17.158877
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.testing import transform

    class TestTransformer(BaseNodeTransformer):
        target = None

        def visit_Constant(self, node):
            pass

    transform(TestTransformer, '1')

# Generated at 2022-06-21 17:28:17.900153
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:28:20.545455
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Foo(BaseTransformer):
        pass



# Generated at 2022-06-21 17:28:27.057669
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    class TestTransform(BaseImportRewrite):
        rewrites = [('struct', '_struct')]

    code = '''
    import struct
    import struct.error
    '''
    tree = parse(code)
    Result = TestTransform.transform(tree)
    print(Result)
    assert Result.changed == True



# Generated at 2022-06-21 17:28:35.200124
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.ast_tools import dump
    try:
        class Test(BaseImportRewrite):
            rewrites = [('foo', 'bar')]
            def visit_Import(self, node):
                return node
            def visit_ImportFrom(self, node):
                return node
        Test.transform(ast.parse('''
            import foo
            import foo.baz
            from foo import bar, baz, qux
            from foo import baz
            from foo.baz import quux, quuz
            from foo.baz import quux
            from foo.baz.qux import corge
            from foo.baz.qux import corge
        '''))
    except Exception as e:
        print(dump(e))
        raise

# Generated at 2022-06-21 17:28:45.429708
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # Testing not rewriting module name and not rewriting names
    class BaseImportRewriteMock(BaseImportRewrite):

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._count_visit_ImportFrom = 0

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            self._count_visit_ImportFrom += 1
            return super(BaseImportRewriteMock, self).visit_ImportFrom(node)

    rewriter = BaseImportRewriteMock(ast.parse('from os import path'))
    result = rewriter.transform(ast.parse('from os import path'))
    assert result.tree_changed == False
    assert rewriter._count_visit_ImportFrom == 1

   

# Generated at 2022-06-21 17:28:47.572482
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from . import ast_transformer
    assert isinstance(BaseImportRewrite(ast_transformer.BaseASTTransformer()), BaseImportRewrite)

# Generated at 2022-06-21 17:29:22.062660
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    from ..transformation.base import BaseImportRewrite

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('a', 'b'),
            ('d', 'e')
        ]

    import_from_import = ast.parse(
        "from a.b import x, B as y")
    import_from_import_new_1 = ast.parse(
        "from b.b import x, B as y")
    import_from_import_new_2 = ast.parse(
        "from b.b import x\n"
        "from d.B import B as y")

    transform = ImportRewrite.transform(import_from_import)
    assert transform.changed
    assert ast.dump(import_from_import_new_1) == ast.dump(transform.tree)

    import_rew

# Generated at 2022-06-21 17:29:28.816107
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import pytest

    import astunparse
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('collections.abc', 'collections')]

    import_node = ast.Import(names=[ast.alias(name='collections.abc')])
    expected = astor.to_source(TestTransformer._replace_import(
        TestTransformer(None), 'collections.abc', 'collections')).strip()
    actual = astor.to_source(TestTransformer.visit_Import(TestTransformer(None), import_node)).strip()
    assert actual == expected

    # Matched name not in node.names[0].name
    import_node = ast.Import(names=[ast.alias(name='collections')])

# Generated at 2022-06-21 17:29:34.661054
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, True, [])

    assert Transformer.target is None


# Unit tests for constructor of class BaseNodeTransformer

# Generated at 2022-06-21 17:29:37.023408
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class ChildBaseNodeTransformer(BaseNodeTransformer):
        pass

    node = ChildBaseNodeTransformer(tree=ast.parse("1"))
    assert node is not None
    assert node._tree_changed is False
    assert node._tree is not None


# Generated at 2022-06-21 17:29:40.315342
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_ = ast.Import(names=[ast.alias(name='import_', asname='import_')])
    import_rewrite = BaseImportRewrite.transform(import_)
    assert astor.to_source(import_rewrite.tree) == """\
try:
    import import_
except ImportError:
    pass"""



# Generated at 2022-06-21 17:29:48.633522
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import mock_node_factory
    from .js_transformer import JS_IMPORT_REWRITES
    from .js_transformer import JSImportRewrite


    # case of import from "rewrote_module"
    imp = mock_node_factory.ImportFrom(
            module='rewrote_module',
            names=[
                mock_node_factory.alias(
                    name='name1',
                    asname='asname1'
                )
            ],
            level=0
        )

# Generated at 2022-06-21 17:29:52.287085
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert t is not None
    assert t.target is None



# Generated at 2022-06-21 17:29:54.276259
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-21 17:30:01.206538
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    t = BaseImportRewrite()
    node = ast.parse("""
import os
import sys
import datetime as dt
from a import b, c
from a.b.c import d, e
from a.b.c.d import z
from a.b import c
"""
    )
    t.rewrites = [
        ("os", "new_os"),
        ("datetime", "new_datetime"),
        ("a.b.c.d", "new_a.b.c.d")
    ]
    t.visit(node)
    print(astor.to_source(node))
    # output:

# Generated at 2022-06-21 17:30:03.651223
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Foo(BaseTransformer):
        target = 'foo'
    assert Foo.target == 'foo'

# Generated at 2022-06-21 17:30:52.098537
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..visitor import Visitor
    import unittest

    class Test(BaseImportRewrite, Visitor):
        rewrites = [('old', 'new')]

        def visit_FunctionDef(self, node):
            self.generic_visit(node)

    class TestTest(unittest.TestCase):
        def test_rewrites(self):
            node = ast.parse("""
                from new import module_one, module

                def f():
                    pass
            """)

            result = Test(node).visit(node)
            self.assertEqual(Test.transform(node)[0], result)


# Generated at 2022-06-21 17:31:01.837261
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..transformers.base import BaseImportRewrite

    class Transformer(BaseImportRewrite):
        rewrites = [('.django.http.request_middleware', '.http.middleware')]
        target = None

    tree = ast.parse('''
import typing
from django.http import request_middleware
from tests.utils import utils
request_middleware.HttpRequest
typing.List
if True:
    utils.Utils()
''')
    tree = Transformer.transform(tree).tree

# Generated at 2022-06-21 17:31:09.965954
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert isinstance(BaseTransformer.target, property)
    assert str(BaseTransformer.transform.__doc__) == ''
    assert BaseTransformer.transform.__name__ == 'transform'
    assert BaseTransformer.transform.__module__ == 'django_transformer.transformers.base'
    assert isinstance(BaseTransformer.transform.__annotations__, dict)
    assert BaseTransformer.transform.__annotations__['cls'] == type
    assert BaseTransformer.transform.__annotations__['tree'] == ast.AST
    assert BaseTransformer.transform.__annotations__['return'] == TransformationResult
    assert hasattr(BaseTransformer.target, 'fset')
    assert isinstance(BaseTransformer.target.fset, object)
    assert hasattr(BaseTransformer.target, 'fget')
   

# Generated at 2022-06-21 17:31:21.100679
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [
        ('collections.abc', 'typing'),
        ('_collections_abc', 'typing'),
    ]
    class Rewriter(BaseImportRewrite):
        rewrites = rewrites


# Generated at 2022-06-21 17:31:25.402782
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a = "sd"')
    inst = BaseNodeTransformer(tree)
    assert inst._tree == tree

# Generated at 2022-06-21 17:31:30.358964
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from unittest.mock import MagicMock
    import sys
    from ..utils.ast import eval_ast
    ast_to_mod = eval_ast
    class T(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            return 'test'


# Generated at 2022-06-21 17:31:33.436668
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    x = BaseNodeTransformer()
    assert x._tree == None
    assert x._tree_changed == False



# Generated at 2022-06-21 17:31:43.636631
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # TODO: Generate this test by parser.
    import_from_node = ast.parse('''
from __future__ import absolute_import
import typing
from typing import Generator
from typing.io import *
from typing.re import Pattern
from typing.collections import deque
from typing.collections import defaultdict as dict
from typing import get_type_hints
from tensorflow import keras
from tensorflow.keras import layers
''').body[0]  # type: ast.ImportFrom
    import_node = ast.parse('''
from __future__ import absolute_import
import typing
import typing.io
import typing.re
import typing.collections
import typing
import tensorflow
import tensorflow.keras
''').body[1]  # type: ast.Import
    transformer = BaseImportRewrite()

# Generated at 2022-06-21 17:31:50.979838
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    import_ast = ast.parse('import datetime')
    instance = BaseImportRewrite(import_ast)
    instance.rewrites = [('datetime', 'dateutil.parser')]
    result_import_ast = instance.visit(import_ast)
    assert astunparse.unparse(result_import_ast).strip() == \
           """try:
    import datetime
except ImportError:
    import dateutil.parser as datetime"""


# Generated at 2022-06-21 17:31:54.548363
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = CompilationTarget.ALL
        def transform(tree):
            pass
    assert Transformer.target == CompilationTarget.ALL


# Generated at 2022-06-21 17:33:49.299628
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite
    assert isinstance(x, BaseNodeTransformer)
    assert not isinstance(x, type)
    

# Generated at 2022-06-21 17:33:51.848864
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    global BaseImportRewrite
    BaseImportRewrite = BaseImportRewrite


# Generated at 2022-06-21 17:33:59.540274
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)
    assert BaseImportRewrite.__doc__ == """\
        Base class for import transforms which also supports Python 2.7 and 3.x.
        
        Example usage:
        
        .. code-block:: python
        
            class BaseImportRewrite(BaseNodeTransformer):
                rewrites = [
                    ('os.path', 'pathlib'),
                ]
        
        """
    assert BaseImportRewrite.rewrites == []


# Generated at 2022-06-21 17:34:09.989730
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'moo'),
        ]

    valid_import = ast.parse('import foo', mode='eval')
    rewrote = TestImportRewrite.transform(valid_import)
    assert isinstance(rewrote.transformed, ast.Try)
    assert rewrote.changed

    invalid_import = ast.parse('import bar', mode='eval')
    rewrote = TestImportRewrite.transform(invalid_import)
    assert isinstance(rewrote.transformed, ast.Import)
    assert not rewrote.changed



# Generated at 2022-06-21 17:34:22.848869
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget

    source = '''
    import math
    import numpy as np
    from math import pi
    '''

    expected = '''
    try:
        import math
    except ImportError:
        import math
    import numpy as np
    from math import pi'''

    tree = ast.parse(source)

    class MathRewrite(BaseImportRewrite):
        rewrites = [(math.__name__, 'math')]
        target = CompilationTarget.PYTHON_36

    transformation_result = MathRewrite.transform(tree)

    print(transformation_result.tree)

    assert transformation_result.tree_changed is True
    assert ast.dump(transformation_result.tree, annotate_fields=True) == expected

