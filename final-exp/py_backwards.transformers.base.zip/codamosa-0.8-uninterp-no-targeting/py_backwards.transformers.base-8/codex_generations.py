

# Generated at 2022-06-21 17:24:19.925213
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def check(import_expr: str, expected: Optional[str]) -> None:
        # changed to test with custom ast (since ast.parse() doesn't support
        # import_expr), but it's ok, because ast builder was already tested
        from typed_ast.ast3 import Module
        from typed_ast.ast3 import Import
        from typed_ast.ast3 import ImportFrom
        from typed_ast.ast3 import alias
        from ..utils.snippet import snippet_to_ast
        from .utils import get_ast_to_text, test_ast_to_text

        imports = []
        for i in import_expr.split(';'):
            i = i.strip()

# Generated at 2022-06-21 17:24:22.266773
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class NewBaseTransformer(BaseTransformer):
        target = None
        @classmethod
        def transform(cls, tree):
            return None
    assert NewBaseTransformer.target is None


# Generated at 2022-06-21 17:24:29.733776
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node_rewrite = ast.parse("""
from foo import a, b
from baz.quux import *
""")
    transformer = BaseImportRewrite(node_rewrite)
    transformer.rewrites = [('foo', 'quux')]
    tree = transformer.visit(node_rewrite)
    assert transformer._tree_changed == True



# Generated at 2022-06-21 17:24:33.231782
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree =  ast.AST()
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed == False


# Generated at 2022-06-21 17:24:34.294880
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()

# Generated at 2022-06-21 17:24:44.638153
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_rewrite(previous = ast.ImportFrom(level = 0, module = 'from_module', names = [ast.alias(name = 'a', asname = 'A')]),
                   current  = ast.ImportFrom(level = 0, module = 'to_module', names = [ast.alias(name = 'a', asname = 'A')]))
    import_rewrite(previous = ast.ImportFrom(level = 0, module = 'from_module', names = [ast.alias(name = 'from_module_a', asname = 'A')]),
                   current  = ast.ImportFrom(level = 0, module = 'from_module', names = [ast.alias(name = 'to_module_a', asname = 'A')]))

# Generated at 2022-06-21 17:24:49.459815
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    def assert_import_from_changed(to_find, to_replace, old, new):
        rewrites = [(to_find, to_replace)]
        node0 = ast.parse(old)
        node = BaseImportRewrite(node0).visit(node0)
        print(astor.to_source(node))
        assert astor.to_source(node) == new

    def assert_import_from_not_changed(to_find, old):
        rewrites = [(to_find, 'something')]
        node0 = ast.parse(old)
        node = BaseImportRewrite(node0).visit(node0)
        assert astor.to_source(node0) == astor.to_source(node)


# Generated at 2022-06-21 17:24:56.916632
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast
    from ..utils.snippet import transform_to_tree
    from ..transpilers.utils import transform_to_source

    source = '''\
import os
from os import chdir
from os import chdir as ahaha
from os import *
try:
    import os
except ImportError:
    import wos

import ahaha
try:
    import ahaha
except ImportError:
    import aha
'''

    transpiler = BaseNodeTransformer(transform_to_tree(source))
    tree = transpiler.visit(transpiler._tree)
    assert source == transform_to_source(tree)

# Generated at 2022-06-21 17:25:05.161950
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse

    import typing
    import os.path
    import six

    from ..tests.stubs import typing_typed as _typed

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('typing', 'typing_typed'),
        ]


# Generated at 2022-06-21 17:25:10.680469
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..target.python import PythonTarget

    class TestTransformer(BaseImportRewrite):
        target = PythonTarget
        rewrites = [("my_module", "new_module")]


# Generated at 2022-06-21 17:25:22.268687
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.visitor import find_all_nodes

    tree = ast.parse("import os as _os")
    BaseImportRewrite.rewrites = [('os', 'os_typing')]
    BaseImportRewrite.transform(tree)
    os_import = find_all_nodes(tree, ast.Import)
    assert isinstance(os_import[0], ast.Import) and os_import[0].names[0].name == 'os_typing'

    tree = ast.parse("import os as _os")
    BaseImportRewrite.rewrites = [('os_typing', 'os')]
    BaseImportRewrite.transform(tree)
    os_import = find_all_nodes(tree, ast.Import)

# Generated at 2022-06-21 17:25:29.588622
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import sys
    import astunparse

    import_old = ast.parse("""from old import module1, module2""").body[0]
    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = [('old', 'new')]
    import_new = import_rewrite.visit(import_old)
    print(astunparse.unparse(import_new))


# Generated at 2022-06-21 17:25:30.910787
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target is None


# Generated at 2022-06-21 17:25:39.274885
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast as ast2
    class A(BaseImportRewrite):
        rewrites = [('requests', 'urllib.request')]
    # Test ast.Import
    current = ast2.parse('import requests')
    tree = A().visit(current)
    assert type(tree) is ast2.Try
    assert tree.body[0].value.names[0].name == 'requests'
    assert tree.body[0].value.names[0].asname == 'requests'
    assert tree.body[1].body[0].value.names[0].name == 'urllib.request'
    assert tree.body[1].body[0].value.names[0].asname == 'requests'
    # Test ast.ImportFrom
    current = ast2.parse('from requests import Session')
    tree

# Generated at 2022-06-21 17:25:46.289353
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import unittest
    from ..utils import assertion
    from ..utils.isort_fix import isort_fix

    @isort_fix
    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            import astor
            import os
            from ..utils import src_to_ast
            self.target = 'py37'
            self.transform_result = None  # type: Optional[TransformationResult]
            self.transformer = BaseImportRewrite
            self.src = astor.to_source(src_to_ast.src_to_ast("""\
    from collections import namedtuple
    import collections
    import types
    """))


# Generated at 2022-06-21 17:25:58.803844
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_get_matched_rewrite(self):
            base_import_rewrite = BaseImportRewrite()
            self.assertIsNone(base_import_rewrite._get_matched_rewrite(None))
            self.assertEqual(base_import_rewrite._get_matched_rewrite(BaseImportRewrite.rewrites[0][1]),
                             BaseImportRewrite.rewrites[0])
            self.assertEqual(base_import_rewrite._get_matched_rewrite(BaseImportRewrite.rewrites[1][1]),
                             BaseImportRewrite.rewrites[1])

# Generated at 2022-06-21 17:26:00.685965
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer): pass
    assert TestTransformer.target is None

# Generated at 2022-06-21 17:26:03.696577
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        transformer = BaseTransformer()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 17:26:14.448048
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [
            ('import_from', 'from_import')
        ]

    tree = ast.parse('from import_from.module import name').body
    transformed = Test.transform(tree)[0]
    # print(ast.dump(transformed))
    assert ast.dump(transformed) == "Try(body=[Import(names=[alias(name='from_import.module', asname='name')])], orelse=[Import(names=[alias(name='import_from.module', asname='name')])], finalbody=[])"


# Generated at 2022-06-21 17:26:15.960890
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        pass

    assert A.target is None


# Generated at 2022-06-21 17:26:37.981459
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from src.python.transpilers.pynode.pynode_transformer import PyNodeTransformer
    # test simple import
    ast_mod = ast.parse('import os')
    PyNodeTransformer.rewrites = [
        ('os', 'importlib')
    ]
    PyNodeTransformer.transform(ast_mod)
    assert str(ast_mod) == """
try:
    import os
except ImportError:
    import importlib as os
"""
    # test submodule import
    ast_mod = ast.parse('import os.path')
    PyNodeTransformer.rewrites = [
        ('os.path', 'pathlib')
    ]
    PyNodeTransformer.transform(ast_mod)

# Generated at 2022-06-21 17:26:45.705024
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_transformer import test_run, test_run_with_error


# Generated at 2022-06-21 17:26:58.080135
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = []

    import inspect
    assert inspect.isclass(TestImportRewrite)
    assert issubclass(TestImportRewrite, BaseImportRewrite)
    assert hasattr(TestImportRewrite, 'rewrites')
    assert isinstance(TestImportRewrite.rewrites, list)
    assert isinstance(TestImportRewrite.transform, classmethod)
    assert hasattr(TestImportRewrite, '_get_matched_rewrite')
    assert hasattr(TestImportRewrite, '_replace_import')
    assert hasattr(TestImportRewrite, '_replace_import_from_module')
    assert hasattr(TestImportRewrite, '_get_names_to_replace')

# Generated at 2022-06-21 17:27:03.584378
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from ..transforms.imports import RemoveSix
    """
    Tests if imported module with specific name is replaced with new 
    import with new module name.
    """
    class Test(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = parse("import six")
    assert Test.transform(tree).tree == parse('import six.moves')

    tree = parse("import six.moves")
    assert Test.transform(tree).tree == parse('import six.moves')

    tree = parse("import six.moves.http_client")
    assert Test.transform(tree).tree == parse('import six.moves.http_client')

    tree = parse("import six.moves.http_client as client")
    assert Test.transform

# Generated at 2022-06-21 17:27:04.156564
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:27:11.998119
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('requests', 'urllib')]

    import1 = ast.Import(names=[ast.alias(name='requests.models', asname='req_models')])
    transformed1 = TestBaseImportRewrite.transform(import1).tree

    assert isinstance(transformed1, ast.Try)
    handler1 = transformed1.handlers[0]
    assert isinstance(handler1, ast.ExceptHandler)
    body1 = handler1.body
    assert len(body1) == 1
    assert isinstance(body1[0], ast.Import)
    import2 = body1[0]
    assert len(import2.names) == 1
    name2 = import2.names[0]

# Generated at 2022-06-21 17:27:14.658367
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    name = BaseTransformer()
    assert name.target == None


# Generated at 2022-06-21 17:27:22.007696
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.typing_test_case import TypingTestCase
    import astor
    class Transformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_36
        rewrites = [('queue', 'queue_stub')]

    tree = ast.parse('''from queue import Queue''')
    Transformer.transform(tree)
    expected_tree = ast.parse('''try:
    from queue import Queue
except ImportError:
    from queue_stub import Queue''')
    assert astor.to_source(expected_tree) == astor.to_source(tree)

# Generated at 2022-06-21 17:27:26.273564
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    code = "import foo"
    node = ast.parse(code)
    result = BaseImportRewrite.transform(node)
    assert result[0] is node
    assert astor.to_source(node) == code



# Generated at 2022-06-21 17:27:27.617480
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()
    BaseImportRewrite()

# Generated at 2022-06-21 17:27:57.325815
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    assert MyRewrite.dependencies == [__name__]

    # tree = parse('import a', '<>', 'exec')
    # result = MyRewrite.transform(tree)
    # assert not result.tree_changed
    # assert result.tree == tree
    # assert result.dependencies == ['a']



# Generated at 2022-06-21 17:28:09.765931
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astor
    import _ast

    class Transformer(BaseImportRewrite):
        target = "py2"
        rewrites = [("future.builtins", "past.builtins")]

    class TestCase(unittest.TestCase):
        def test_rewrite_import(self):
            old = _ast.parse("import future.builtins")
            new = _ast.parse("""
try:
    import future.builtins
except ImportError:
    import past.builtins""")

            tree = Transformer.transform(old).tree
            self.assertEqual(astor.to_source(new).strip(), astor.to_source(tree).strip())

        def test_not_rewrite_import(self):
            old = _ast.parse("import builtins")
           

# Generated at 2022-06-21 17:28:20.947903
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_37
        rewrites = [('os', 'nt')]

    code = """
        import os
    """
    expected = """
        try:
            import os
        except ImportError:
            import nt as os
    """
    result = MyTransformer.transform(ast.parse(code)).ast
    assert ast.dump(result) == expected

    code = """
        import os.path
    """
    expected = """
        try:
            import os.path
        except ImportError:
            import nt.path as path
    """
    result = MyTransformer.transform(ast.parse(code)).ast
    assert ast.dump(result) == expected

    code = """
        import os.path as p
    """

# Generated at 2022-06-21 17:28:22.130889
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import pytest

    with pytest.raises(TypeError):
        BaseImportRewrite()

# Generated at 2022-06-21 17:28:25.937765
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert hasattr(BaseTransformer, 'transform'), "BaseTransformer has no method: 'transform'"
    assert hasattr(BaseTransformer, 'target'), "BaseTransformer has no attribute: 'target'"


# Generated at 2022-06-21 17:28:31.755353
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    old_import_from = ast.Import(names=[ast.alias(name='foo', asname='bar')])
    new_import_from = ast.Import(names=[ast.alias(name='foo', asname='bar')])
    node = import_rewrite.get_body(previous=old_import_from, current=new_import_from)[0]
    assert isinstance(node, ast.Try)



# Generated at 2022-06-21 17:28:33.381943
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    a = BaseNodeTransformer(None)

# Generated at 2022-06-21 17:28:38.541313
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('import_old', 'import_new')]

    tree = ast.parse("import import_old")
    inst = TestImportRewrite(tree)
    result = inst.visit(tree)

    assert result.body[0].handlers[0].body[0].name == "import_new"


# Generated at 2022-06-21 17:28:49.413373
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import transform
    import unittest

    from ..simple import transforms

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('future', 'typed_ast.future'),
            ('typed_ast', 'typed_ast.ast3'),
        ]
        dependencies = ['typed_ast']

    class TestTransformation(unittest.TestCase):
        def setUp(self):
            self._old = '''
import future
from future import blah
'''
            self._new = '''
try:
    import future
except ImportError:
    import typed_ast.future
from typed_ast.future import blah
'''

        def test(self):
            tree = ast.parse(self._old)

# Generated at 2022-06-21 17:28:52.049718
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__init__.__annotations__ == {'return': None}


# Generated at 2022-06-21 17:29:48.232085
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    import_node = ast.Import()
    importfrom_node = ast.ImportFrom()
    assert transformer.visit(import_node) == import_node
    assert transformer.visit(importfrom_node) == importfrom_node



# Generated at 2022-06-21 17:29:53.618655
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # class BaseTransformer:
    x = BaseTransformer()
    assert x is not None
    assert x.target is None
    assert x.transform() is None

# Generated at 2022-06-21 17:29:54.708375
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer(): 
    baseTransformer = BaseTransformer()
    assert baseTransformer.target == None


# Generated at 2022-06-21 17:30:00.871348
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # This function does not test the functionality;
    # it only checks meta-information and constructor.
    from ..utils.pytest_types import assert_type

    class NodeTransformer(BaseNodeTransformer):
        def visit_Import(self, node: ast.Import) -> ast.Import:
            return self.generic_visit(node)

    assert_type(NodeTransformer.target, CompilationTarget)

    tree = ast.parse('import os')

    # It is not easy to check for a Subclass of ast.NodeTransformer
    # since ast.NodeTransformer is not a class but a metaclass or similar.
    # The following test is sufficient.
    assert_type(NodeTransformer(tree), BaseNodeTransformer)

# Generated at 2022-06-21 17:30:02.769513
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None


# Generated at 2022-06-21 17:30:04.434005
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    m = BaseTransformer()
    assert m.target == None


# Generated at 2022-06-21 17:30:06.982006
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('')
    trans = BaseNodeTransformer(tree)
    assert tree == trans._tree
    assert not trans._tree_changed

# Generated at 2022-06-21 17:30:10.520121
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('print("test")', mode='exec')  # type: ast.AST
    BaseNodeTransformer(tree)


# Generated at 2022-06-21 17:30:12.145400
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite

# Generated at 2022-06-21 17:30:20.846603
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import_rewrite = ast.ImportFrom(module="import_rewrite",
                                    names=[ast.alias(name="extend",
                                                     asname=None)],
                                    level=0)
    import_from_orig = ast.ImportFrom(module="import_rewrite",
                                      names=[ast.alias(name="extend",
                                                       asname=None)],
                                      level=0)
    import_from_rewrite = ast.ImportFrom(module="import_rewrite2",
                                         names=[ast.alias(name="extend",
                                                          asname=None)],
                                         level=0)

# Generated at 2022-06-21 17:31:56.610425
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None


# Generated at 2022-06-21 17:32:01.799823
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    source = """
    from request import get, fetch
    from foo import bar
    from baz.mod import boo
    from qux.mod import lal, lul
    from . import mod
    from . import another_mod as mod
    from .mod import lala
    """
    src = astor.to_source(ast.parse(source), indent_with=' ' * 4).strip()


# Generated at 2022-06-21 17:32:14.453406
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_stmt = ast.parse('from foo import bar, baz').body[0]
    import_stmt_one = ast.parse('from foo import bar').body[0]
    import_stmt_two = ast.parse('from foo import baz').body[0]
    import_stmt_from_module = ast.parse('from foo import *').body[0]
    import_stmt_with_as = ast.parse('from foo import bar as x').body[0]
    import_stmt_one_with_as = ast.parse('from foo import bar as baz').body[0]
    import_stmt_from_module_with_as = ast.parse('from bar import * as baz').body[0]

    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.P

# Generated at 2022-06-21 17:32:21.451196
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyNodeTransformer(BaseNodeTransformer):
        def visit_MyNode(self, node):
            return node

        def visit_OtherNode(self, node):
            return node

    assert MyNodeTransformer.__name__ == 'MyNodeTransformer'

    tree = ast.parse('''class MyNode:pass
                      class OtherNode:pass
                      ''')
    assert MyNodeTransformer.transform(tree).changed

# Generated at 2022-06-21 17:32:25.167046
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert isinstance(bt, BaseTransformer)
    

# Generated at 2022-06-21 17:32:28.113898
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .rewrites.default import RewriteImports
    assert isinstance(RewriteImports(None), BaseImportRewrite)


# Generated at 2022-06-21 17:32:29.373723
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tester = BaseTransformer()



# Generated at 2022-06-21 17:32:36.436656
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockedTransformer(BaseImportRewrite):
        rewrites = [('rewrite_module', 'rewritten_module')]

    # module_name: startswith rewrite_module
    # module_name: not startswith rewrite_module
    # module_name: is None

    module_name_with_rewrite = 'rewrite_module.my_module'
    module_name_without_rewrite = 'no_rewrite_module.my_module'
    module_to_import = 'import_module'
    module_name_none = None
    import_name = 'import_name'

    class TestImport(ast.Import):
        def __init__(self, name: str):
            super().__init__(names=[ast.alias(name=name)])


# Generated at 2022-06-21 17:32:44.535138
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    from typed_ast.ast3 import parse
    import_from = parse('''
from pkg.subpkg1 import func1, func2
from pkg.subpkg2 import func3, func4
from pkg.subpkg1.subpkg1 import func5
from pkg.subpkg2.subpkg2 import func6
''').body[0]

    class Rewriter(BaseImportRewrite):
        rewrites = [('pkg.subpkg1', 'pkg.subpkg3')]

    rewriter = Rewriter(None)

    rewrote = rewriter.visit_ImportFrom(import_from)


# Generated at 2022-06-21 17:32:53.705932
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .python2 import dump

    class Transformer(BaseImportRewrite):
        rewrites = [('.foo', '.bar')]

    def assert_rewrote(original: ast.ImportFrom, expected: str) -> None:
        tree = ast.parse(original)
        _, _, deps = Transformer.transform(tree)
        assert deps == ['bar'], deps
        assert dump(tree) == expected, dump(tree)

    assert_rewrote('from foo import bar',
                   'try:\n    from foo import bar\nexcept ImportError:\n    from bar import bar')

    assert_rewrote('from foo import bar, baz',
                   'try:\n    from foo import bar, baz\nexcept ImportError:\n    from bar import bar, baz')
