

# Generated at 2022-06-21 17:24:18.634639
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import foo')
    bnt = BaseNodeTransformer(tree)
    assert bnt._tree_changed == False
    bnt.visit(tree)
    assert bnt._tree_changed == False
    assert ast.dump(tree) == 'Module(body=[Import(names=[alias(name=\'foo\', asname=None)])])'


# Generated at 2022-06-21 17:24:23.578128
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    tree = ast.parse("""
import foo
import baz
""")
    tree = DummyTransformer.transform(tree).tree

    expected_tree = ast.parse("""
try:
    import foo
except ImportError:
    import bar as foo
import baz
""")

    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-21 17:24:26.436644
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__.__annotations__['tree'] is ast.AST


# Generated at 2022-06-21 17:24:35.776872
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():  # noqa

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('module1', 'module2')]

    tree = ast.parse(
        """
from module1 import foo
from module1 import bar, foo as barfoo
from module1 import *
from module3 import foo
from module3 import bar, foo as barfoo
from module3 import *
from module1 import foo as barfoo
from module1 import * as module1
from module3 import foo as barfoo
from module3 import * as module3
    """)
    ImportRewrite.transform(tree)


# Generated at 2022-06-21 17:24:37.681354
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("")
    obj = BaseNodeTransformer(tree)
    assert obj._tree_changed == False

test_BaseNodeTransformer()

# Generated at 2022-06-21 17:24:44.994252
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    sys.path.append(r'C:\Users\admin\PycharmProjects\typed-astunparse')
    import ast as A
    import json
    import typed_astunparse


# Generated at 2022-06-21 17:24:53.567457
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test lambda class with name "BaseImportRewrite"
    BaseImportRewrite_ = lambda: None
    BaseImportRewrite_.target = CompilationTarget.PYTHON
    BaseImportRewrite_.rewrites = [('.py3', '.py3')]
    BaseImportRewrite_.dependencies = []
    BaseImportRewrite_.__name__ = 'BaseImportRewrite'
    BaseImportRewrite_ = BaseImportRewrite_(BaseImportRewrite)
    # Test BaseImportRewrite.__init__
    assert BaseImportRewrite_.rewrites[0] == ('.py3', '.py3')

# Generated at 2022-06-21 17:24:54.158284
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite

# Generated at 2022-06-21 17:25:03.500386
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astor.code_gen import to_source
    from ..utils.helpers import generate_ast
    from ..utils.snippet import snippet, extend

    class Dummy(BaseImportRewrite):
        rewrites = [
            ('os', 'nt'),
        ]

    tree = generate_ast('''
import os
os.path
''')
    tree = Dummy().visit(tree)
    source = to_source(tree)
    result = snippet.get_body(previous='''
import os
os.path
''', current=source)[0]

    tree_with_try = generate_ast('''
try:
    import os
except ImportError:
    import nt as os
os.path
''')

    # we use extend to make sure that two trees are equal

# Generated at 2022-06-21 17:25:05.996527
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..compiler import TransformerManager
    from ..utils.parser import parse_module

    class Test(BaseNodeTransformer):
        target = None
    
    t = TransformerManager()
    t.register(Test)
    t.transform(parse_module(''))

# Generated at 2022-06-21 17:25:17.363542
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_statement = ast.parse('from a import b as bb, c').body[0]
    assert not isinstance(import_statement, ast.Try)

    class Test(BaseImportRewrite):
        rewrites = [('a', 'b')]

    new_tree = Test.transform(import_statement)

    assert isinstance(new_tree.tree, ast.Try)
    assert not new_tree.changed
    assert len(new_tree.tree.body) == 1

    import_from_part = ast.parse('from b import b as bb, c').body[0]
    assert import_from_part.body[0] == new_tree.tree.body[0]

# Generated at 2022-06-21 17:25:20.565110
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    try:
        BaseImportRewrite()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 17:25:23.596117
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.testutils import test_node_transformer
    test_node_transformer(BaseNodeTransformer, 'ast')

# Generated at 2022-06-21 17:25:34.769935
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('six', 'importlib')]

    test_data = [
        ('import six', 'try: import six\nexcept ImportError: import importlib as six'),
        ('import six.moves', 'try: import six.moves\nexcept ImportError: import importlib.moves as six.moves'),
        ('import six.moves as alias', 'try: import six.moves as alias\nexcept ImportError: import importlib.moves as alias'),
    ]
    for src, expected_result in test_data:
        tree = ast.parse(src)
        result = Test.visit_Import(tree.body[0])
        assert ast.fix_missing_locations(result).body[0].body[0].body[0].s == expected_result

# Generated at 2022-06-21 17:25:40.103013
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('def f(x):\n    pass')
    cls = BaseNodeTransformer(tree)
    assert len(cls.dependencies) == 0
    assert cls.transform(tree) == (tree, False, cls.dependencies)


# Generated at 2022-06-21 17:25:44.595539
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("a = 1")
    assert BaseNodeTransformer.transform(tree) == (
        tree,
        False,
        [],
        )



# Generated at 2022-06-21 17:25:54.854450
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    source = '''"Test"; from foo import bar'''
    tree = ast.parse(source)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[1], ast.ImportFrom)
    result = BaseImportRewrite.transform(tree)
    assert result.tree_changed is False
    assert len(result.tree.body) == 2
    assert isinstance(result.tree.body[1], ast.ImportFrom)



# Generated at 2022-06-21 17:26:05.493991
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_ast_tree_equal

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('a.b', 'c.d')]

    tree = ast.parse('import foo', 'test.py')

    transformed = Test(tree).visit_Import(tree.body[0])
    expected = ast.parse(
        '''try:
        import foo
except ImportError:
        import bar as foo''', 'test.py')

    assert_ast_tree_equal(transformed, expected)

    tree = ast.parse('import a.b', 'test.py')

    transformed = Test(tree).visit_Import(tree.body[0])

# Generated at 2022-06-21 17:26:06.664455
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert t.target is None


# Generated at 2022-06-21 17:26:09.839764
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__(BaseImportRewrite, ast.AST(lineno=1, col_offset=2)) is None


# Generated at 2022-06-21 17:26:17.382562
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    node = ast.Import(names=[ast.alias(name='name', asname='as_name')])
    instance = BaseImportRewrite(node)
    assert isinstance(instance, BaseImportRewrite)
    assert isinstance(instance, BaseNodeTransformer)


# Generated at 2022-06-21 17:26:19.872931
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, BaseTransformer)


# Generated at 2022-06-21 17:26:26.873079
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .namespaces import TransformNamespaces

    class BaseImportRewriteTest(BaseImportRewrite):
        rewrites = [('typed_ast', 'ast')]

    tr = TransformNamespaces()
    tr.transform('import typed_ast')
    assert 'import typed_ast' == tr.get_source()

    tr_rewrite = BaseImportRewriteTest()
    tr_rewrite.transform('import typed_ast')
    assert 'try:\n    import typed_ast\nexcept ImportError:\n    import ast' == tr_rewrite.get_source()



# Generated at 2022-06-21 17:26:35.709283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import import_rewrite
    import_rewrite.set_snippet('import_rewrite', snippet)
    ast_tree = ast.parse("import numpy")
    new_ast_tree = BaseImportRewrite.transform(ast_tree)
    assert new_ast_tree == TransformationResult(ast.parse("""try:
    import numpy
except ImportError:
    import numpy as np"""), True, [])
    import_rewrite.reset_snippet()


# Generated at 2022-06-21 17:26:37.677964
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass


# Generated at 2022-06-21 17:26:39.240859
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite


# Generated at 2022-06-21 17:26:48.475754
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import sys
    import io
    from io import StringIO
    from contextlib import redirect_stdout
    import sys
    import unittest

    from .utils import CodeString, WriteCapture

    class BaseImportRewrite(BaseNodeTransformer):
        rewrites = [('io', 'sys')]

    class TestBaseTransform(unittest.TestCase):
        def setUp(self):
            self.test_code = CodeString(
                'import io',
                'import sys',
                'io.StringIO()',
                'sys.stdout'
            )

        def test_visit_Import_from_sys(self):
            expected_code = CodeString(
                'import sys',
                'import sys',
                'sys.StringIO()',
                'sys.stdout'
            )


# Generated at 2022-06-21 17:26:52.875476
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import unittest
    import ast

    class Transformer(BaseTransformer):
        target = "original"

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return BaseTransformer.transform(tree)
    unittest.TestCase().assertRaises(TypeError, Transformer.transform, ast.AST)



# Generated at 2022-06-21 17:26:53.685820
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite



# Generated at 2022-06-21 17:27:06.173186
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """
    >>> class Foo(BaseImportRewrite):
    ...     rewrites = [
    ...         ('urlparse', 'urllib.parse'),
    ...         ('urllib.error', 'urllib.request')
    ...     ]
    >>> Foo({})
    >>> Foo({'module': 1, 'names': [2], 'level': 3})
    >>> Foo({'module': 'urlparse', 'names': [4], 'level': 5})
    >>> Foo({'module': 'urllib.error', 'names': [6], 'level': 7})
    >>> Foo({'module': 'urllib.error.foo', 'names': [8], 'level': 9})
    >>> Foo({'module': 'urllib.error', 'names': [{'foo': 10}], 'level': 11})
    """

# Generated at 2022-06-21 17:27:16.277844
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()


# Generated at 2022-06-21 17:27:19.093192
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """
    Should correctly import BaseImportRewrite
    """
    BaseImportRewrite

# Generated at 2022-06-21 17:27:22.377058
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.transform is BaseTransformer.transform
    assert BaseTransformer.transform is BaseNodeTransformer.transform


# Generated at 2022-06-21 17:27:24.298547
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    BaseNodeTransformer(ast.parse(''))



# Generated at 2022-06-21 17:27:27.910446
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class A(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._tree_changed = False
            self._tree = tree
 
    tree = ast.parse('print(42)')
    A(tree)

# Generated at 2022-06-21 17:27:30.208504
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None

# Generated at 2022-06-21 17:27:36.256078
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_ast = ast.parse(
        'from old_module import foo, bar as bar1, baz as bar2')
    old_module = import_ast.body[0]
    old_module.names[0].name = 'old.module'

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('old.module', 'new.module')]

    import_rewrite = ImportRewrite.visit_ImportFrom(old_module)
    assert isinstance(import_rewrite, ast.Try)
    assert len(import_rewrite.handlers) == 1
    assert import_rewrite.handlers[0].type.id == 'ImportError'
    assert len(import_rewrite.handlers[0].body) == 2
    assert len(import_rewrite.body) == 1

    old

# Generated at 2022-06-21 17:27:41.680754
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from typed_ast.ast3 import parse
    from .test_util import TestTransformer
    tree = parse('')
    r = TestTransformer.transform(tree)
    print(r)

# Generated at 2022-06-21 17:27:50.722538
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    import typed_astunparse

    class TestBaseImportRewriteVisitImport(unittest.TestCase):
        def check(self, txt, rewrite, expected_txt, expected_changed=True):
            class TestTransformer(BaseImportRewrite):
                rewrites = [rewrite]

            tree = ast.parse(txt)
            result = TestTransformer.transform(tree)
            self.assertEqual(expected_txt, typed_astunparse.unparse(result.tree))
            self.assertEqual(expected_changed, result.changed)

        def test_import_no_rewrite(self):
            txt = 'import test'
            self.check(txt, ('a', 'b'), txt, expected_changed=False)

        def test_import_rewrite(self):
            t

# Generated at 2022-06-21 17:27:57.807075
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transformer(BaseImportRewrite):
        rewrites = [('urlparse', 'urllib.parse')]

    expected_transformed_tree = ast.parse("""
try:
    import urlparse
except ImportError:
    import urllib.parse
""")

    expected_result = TransformationResult(expected_transformed_tree, True, [])

    input_tree = ast.parse("""
import urlparse
""")

    assert Transformer.transform(input_tree) == expected_result



# Generated at 2022-06-21 17:28:15.984266
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None


# Generated at 2022-06-21 17:28:18.384001
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("")
    trans = BaseNodeTransformer(tree)
    assert tree is trans._tree
    assert trans._tree_changed is False


# Generated at 2022-06-21 17:28:27.496617
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    import_node = ast.parse('import foo.bar')
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo2.bar2')]

    res = TestImportRewrite.transform(import_node)
    assert res.changed
    assert astunparse.unparse(res.tree) == """
try:
    import foo.bar
except ImportError:
    import foo2.bar2
    """



# Generated at 2022-06-21 17:28:33.059772
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(
        module='sys',
        names=[ast.alias(
            name='argv',
            asname='argv')],
        level=0)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('sys', 'something_else')]

    _, tree_changed, _ = TestImportRewrite.transform(import_from)
    assert tree_changed



# Generated at 2022-06-21 17:28:43.261981
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    class TestClass(BaseImportRewrite):
        rewrites = [
            ('os', 'posixpath'),
            ('pwd', 'os'),
            ('urllib.request', 'urllib2'),
            ('urllib.parse', 'urlparse')]
  
    import_from_1 = ast.ImportFrom(module='os',
                                   names=[ast.alias(name='path', asname='path')],
                                   level=0)
    import_from_2 = ast.ImportFrom(module='pwd',
                                   names=[ast.alias(name='getpwuid', asname=None)],
                                   level=0)

# Generated at 2022-06-21 17:28:44.635458
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(None)

# Generated at 2022-06-21 17:28:53.839619
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.baz')]

    tree = ast.parse(
        "from foo import bar\n"
        "from foo.bar import foo\n"
        "from foo.baz import *\n"
        "from foo import *\n"
        "from foo.bar import *\n"
        "from foo.bar import foo as bar\n"
    )

    MyTransformer.transform(tree)


# Generated at 2022-06-21 17:28:56.825878
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert hasattr(BaseTransformer, 'target')
    assert hasattr(BaseTransformer, 'transform')
    assert BaseTransformer.target is None


# Generated at 2022-06-21 17:29:08.267739
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..compilers.base import import_alias_from_from
    from ..compilers.base import import_alias_from_import

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('transpyle.utils', 'transpyle.utils.rewritten')]

    simple_import_from = import_alias_from_from('from transpyle.utils.tests import TEST')
    simple_try_from = import_rewrite.get_body(from_='transpyle.utils',
                                              to='transpyle.utils.rewritten')
    import_from_name = import_alias_from_from('from transpyle.utils.tests import test')

# Generated at 2022-06-21 17:29:17.663464
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Example(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    target = CompilationTarget('foo.Bar', 'foo', 'Bar')
    expected = ast.Module(body=[
        ast.Try(
            body=[
                ast.Import(names=[
                    ast.alias(name='bar.Bar',
                              asname='Bar')]),
            ],
            handlers=[
                ast.ExceptHandler(
                    type=None,
                    name=None,
                    body=[
                        ast.Import(names=[
                            ast.alias(name='foo.Bar',
                                      asname='Bar')]),
                    ]),
            ],
            orelse=[],
            finalbody=[])
    ])
    result = Example.transform(
        target.get_stub_ast()
    )

# Generated at 2022-06-21 17:30:05.185284
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert hasattr(BaseNodeTransformer, "_tree")
    assert hasattr(BaseNodeTransformer, "_tree_changed")
    assert hasattr(BaseNodeTransformer, "dependencies")


# Generated at 2022-06-21 17:30:08.937478
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.Import(names=[ast.alias(name='foo')])
    result = Transformer.transform(node)

    assert result.tree.body[0].body[0].value.names[0].name == 'bar'


# Generated at 2022-06-21 17:30:10.888991
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()  # type: ignore

# Generated at 2022-06-21 17:30:12.530855
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-21 17:30:20.968927
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast as pyast
    import astunparse as pyastunparse
    import textwrap
    class MyTransformer(BaseImportRewrite):
        # type: ignore
        rewrites = [('foo', 'bar'),
                    ('a', 'b')]
    test_input = """
    import foo
    import foo.bar
    import foo.baz
    import foo.baz.a
    import foo.baz.b
    import foo.baz.c
    from foo import bar
    from foo import bar, baz
    from foo import bar, baz, test
    from foo import bar, baz, test
    from foo.bar import baz, test
    from foo.bar import baz as test
    from foo.bar import baz as a
    from foo.bar import baz, test as a
    """

# Generated at 2022-06-21 17:30:27.781571
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    inst = BaseNodeTransformer(ast.parse('''
        def x():
            pass
    '''))

    from os import getcwd

    assert inst._tree == ast.parse('''
        def x():
            pass
    ''')

    assert inst._tree_changed == False

    inst = BaseNodeTransformer(ast.parse('''
        def x():
            pass
    '''))

    from os import getcwd

    assert inst._tree == ast.parse('''
        def x():
            pass
    ''')

    assert inst._tree_changed == False



# Generated at 2022-06-21 17:30:31.540998
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(ast.parse('pass'))
    assert t._tree_changed == False



# Generated at 2022-06-21 17:30:38.347276
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._tree = tree
            self._tree_changed = False

    # pylint: disable=unused-variable
    # unit test for constructor of BaseNodeTransformer
    t = TestTransformer('abc')


# Generated at 2022-06-21 17:30:50.481573
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse
    from typed_ast import ast3 as ast

    class TestImportRewrites(BaseImportRewrite):
        rewrites = [('scipy.spatial.distance', 'scipy.spatial.distances'),
                    ('scipy.spatial.distance._distance_wrap', 'scipy.spatial.distances._distance_wrap')]

    class TestImportRewrites2(BaseImportRewrite):
        rewrites = [('numpy', 'numpy as np')]

    tree = ast.parse('import scipy.spatial.distance as dist')
    result = TestImportRewrites().transform(tree)
    assert result.has_changes is True
    print(unparse(result.tree))


# Generated at 2022-06-21 17:31:01.408345
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from pox.compiler._unittest.utils import compile_source

    source = """
    from target.item import item, *
    from target.item.other import *
    """

    tr = compile_source(source,
                        "test_BaseImportRewrite_visit_ImportFrom",
                        target=CompilationTarget.PYTHON)
    if tr.success:
        node = tr.tree
        assert type(node.body[0]) == ast.ImportFrom
        assert type(node.body[0].names[0]) == ast.alias
        assert node.body[0].names[0].name == "item"
        assert node.body[0].names[0].asname == None
        assert type(node.body[0].names[1]) == ast.alias

# Generated at 2022-06-21 17:32:37.995380
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = []

    test_BaseImportRewrite()

# Generated at 2022-06-21 17:32:44.991862
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [
        ('unittest', 'unittest2')
    ]

    class Rewriter(BaseImportRewrite):
        rewrites = rewrites


# Generated at 2022-06-21 17:32:45.973783
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-21 17:32:53.823106
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    import ast as pyast

    from ..compiler_config import ServiceCompilerConfiguration
    from ..compiler_config import TypedPythonCompilerConfiguration
    from .. import Compiler
    from ..types import CompilationTarget

    class MyBaseImportRewrite(BaseImportRewrite):
        config_class = TypedPythonCompilerConfiguration
        target = CompilationTarget
        rewrites = [
            ('django.conf', 'starlette.config'),
            ('django', 'starlette'),
            ('django.urls.resolvers', 'starlette.routing')]

    class MyCompiler(Compiler):
        base_transformer = MyBaseImportRewrite

    class TestCase(unittest.TestCase):
        compiler = MyCompiler()

        def test_import(self):
            tree = pyast

# Generated at 2022-06-21 17:33:03.398862
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .base import BaseTransformTest
    from ..utils import load_source_module, replace_module_names

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [(replace_module_names('__future__.absolute_import'),
                     replace_module_names('__future__.relative_import'))]

    class Test(BaseTransformTest):
        transformer = TestImportRewrite

        @property
        def tree(self) -> ast.AST:
            return load_source_module(self.module)

        def test_import(self):
            tree = self.transformer.transform(self.tree)
            assert hasattr(tree, 'foo')

    return Test('', 'import foo\nfoo')

# Generated at 2022-06-21 17:33:12.509373
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import importlib
    import sys
    import os
    import tempfile
    import shutil
    from six.moves import reload_module

    tree = ast.parse('''
import os
from six.moves import reload_module
''')

    sys.path.append(os.getcwd())

    class TestModule(object):
        def test_method(self):
            pass

    dummy_module = TestModule()
    def get_module(name):
        return dummy_module

    class TestImportRewriter(BaseImportRewrite):
        rewrites = [(
            'test_transformer_import_rewrite',
            'test_transformer_import_rewrite_new'
        )]

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 17:33:14.474110
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, BaseTransformer)
    BaseTransformer()

# Generated at 2022-06-21 17:33:17.296652
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    base = BaseTransformer()

    assert base is not None
    assert base.target is None



# Generated at 2022-06-21 17:33:23.483019
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...types import CompilationTarget
    from ...compiler import Compiler
    from .typing_compat import typing_compat_3

    compiler = Compiler(CompilationTarget.PYTHON_TYPING, [typing_compat_3])
    tree = compiler.parse("""
from typing import List
import types
""")
    BaseImportRewrite(tree).visit(tree)
    assert compiler.unparse(tree) == """
try:
    from typing import List
except ImportError:
    from typing_extensions import List

import types
"""


# Generated at 2022-06-21 17:33:31.068921
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.tree_walker import walk_module, ImportVisitor

    from .helpers import import_rewrite_test, check_node_transformer

    ast_tree = import_rewrite_test.get_ast()
    tree = walk_module(ast_tree)
    visitor = ImportVisitor()
    visitor.visit(tree)
    transformer = check_node_transformer(BaseImportRewrite,
                                         expected=import_rewrite_test.rewrite_expected,
                                         rewrites=[('node_transformer', 'node_transformers')],
                                         tree=tree,
                                         visitor=visitor)
    assert transformer._tree_changed

