

# Generated at 2022-06-21 17:24:34.236211
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportReplace(BaseImportRewrite):
        rewrites = [('node', 'proxy')]

    code = '''
    import node.express
    from node.express import Router, Request, Response
    from node import fs
    from node.fs import readFileSync, getStatsSync
    from node.awesome import fetch, find
    from node.simple import log
    '''
    tree = ast.parse(code)
    tr = ImportReplace.transform(tree)

    assert tr.tree.body[0].body[0].value.args[0].value.body[0].value.value.id == 'express'

    assert tr.tree.body[0].body[1].value.args[0].value.body[0].value.value.id == 'Router'
    assert tr.tree.body[0].body

# Generated at 2022-06-21 17:24:42.984095
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from unittest.mock import Mock
    from typings import NoReturn
    class TestTransformer(BaseTransformer):
        def transform(self, tree: ast.AST) -> TransformationResult:
            ...
    transformer = TestTransformer()
    transformer.transform = Mock(return_value=TransformationResult(None, False, []))
    try:
        transformer.target = Mock()
        transformer.transform()
        transformer.target = None
    except:
        assert False
    try:
        transformer.transform()
        assert False
    except NoReturn:
        pass
    transformer.transform.assert_called_once_with(None)



# Generated at 2022-06-21 17:24:44.171435
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, object)


# Generated at 2022-06-21 17:24:46.518732
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = CompilationTarget.PY2
    assert issubclass(Transformer, BaseTransformer)
    assert issubclass(Transformer, BaseTransformer.__class__)


# Generated at 2022-06-21 17:24:56.538278
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    import parso
    import io

    class TestTransformer(BaseImportRewrite):
        rewrites = [('http.client', 'six.moves.http_client')]

    class TestTransformer2(BaseImportRewrite):
        rewrites = [('http.client', 'six.moves.http_client')]

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._tree_changed = False

    tree = parso.parse("import http.client")
    TestTransformer.transform(tree)

    tree = parso.parse("import http.client.client")
    TestTransformer.transform(tree)

    tree = parso.parse("import http.client")
    TestTransformer2.transform

# Generated at 2022-06-21 17:24:59.798197
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import transform_test

    @transform_test(BaseImportRewrite)
    def test():
        import unittest as ut  # noqa
        import atexit as at  # noqa

    test()



# Generated at 2022-06-21 17:25:06.859058
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    tree = ast.parse("import b")
    class SomeImportRewrite(BaseImportRewrite):
        dependencies = ['b']

    SomeImportRewrite.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import b\nexcept ImportError:\n    pass\n'
    SomeImportRewrite.dependencies = []

    tree = ast.parse("import a as b")
    SomeImportRewrite.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import a as b\nexcept ImportError:\n    pass\n'

    tree = ast.parse("import a.b.c as d")
    class SomeImportRewrite(BaseImportRewrite):
        rewrites = [('a.b', 'e.f')]

   

# Generated at 2022-06-21 17:25:12.831156
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert hasattr(BaseImportRewrite, 'visit_Import'),\
        "BaseImportRewrite class doesn't have a 'visit_Import' class method"
    assert hasattr(BaseImportRewrite, 'visit_ImportFrom'),\
        "BaseImportRewrite class doesn't have a 'visit_ImportFrom' class method"

# Generated at 2022-06-21 17:25:14.895592
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test of constructor of class BaseImportRewrite
    class Test(BaseImportRewrite):
        rewrites = []
    new_instance = Test(ast.AST())
    assert new_instance is not None



# Generated at 2022-06-21 17:25:21.838527
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_ = ast.Import(names=[ast.alias(name='foo.bar', asname='bar')])
    import_from = ast.ImportFrom(module='foo.bar',
                                 names=[ast.alias(name='baz')],
                                 level=0)
    import_from_with_alias = ast.ImportFrom(module='foo.bar',
                                            names=[ast.alias(name='baz', asname='biz')],
                                            level=0)
    import_from_relative = ast.ImportFrom(module='foo.bar',
                                          names=[ast.alias(name='baz')],
                                          level=1)


# Generated at 2022-06-21 17:25:29.588879
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()


# Generated at 2022-06-21 17:25:38.165758
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest.mock as mock
    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    transformer = MockBaseImportRewrite(tree=mock.MagicMock())
    with mock.patch.object(MockBaseImportRewrite, 'visit_ImportFrom', wraps=transformer.visit_ImportFrom) as mock_visit_ImportFrom:
        node = mock.MagicMock(module='foo')
        transformer.visit_ImportFrom(node)
        assert mock_visit_ImportFrom.call_count == 1
        node = mock.MagicMock(module='foo', names=[ast.alias(name='baz')])
        transformer.visit_ImportFrom(node)
        assert mock_visit_ImportFrom.call_count == 2
        node

# Generated at 2022-06-21 17:25:45.293143
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # static definition of the method visit_Import()
    def visit_Import(node):
        # if node has the required attribute names
        if hasattr(node, 'names'):

            rewrite = self._get_matched_rewrite(node.names[0].name)

            # a rewrite exists, if the module name starts with the searched string
            if rewrite:
                if len(rewrite) == 2:
                    # the rewrite is a tuple of 2 modules
                    return self._replace_import(node, rewrite[0], rewrite[1])
                else:
                    return self.generic_visit(node)
            else:
                return self.generic_visit(node)
        else:
            # no rewrites exist
            return self.generic_visit(node)
    # end of method definition

    # definition of the class BaseImportRewrite

# Generated at 2022-06-21 17:25:57.079928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_ = ast.Import(names=[
        ast.alias(name='foo.bar', asname='bar')])

    rewrites = [('foo.bar', 'foo.baz')]

    class MyTransformer(BaseImportRewrite):
        rewrites = rewrites

    expected = ast.Try(body=[import_rewrites.get_body(previous=import_,  # type: ignore
                                                      current=rewrote)[0]],
                      orelse=[],
                      finalbody=[])
    actual = MyTransformer.transform(import_).tree
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-21 17:26:00.083338
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(ast.AST())
    assert transformer._tree_changed == False
    assert transformer._tree is not None


# Generated at 2022-06-21 17:26:09.301719
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    src = '''
import foo
import bar as b
from foo.bar import spam, eggs
from foo.baz.quux import la, la

print(foo)
'''
    tree = ast.parse(src)
    tree = BaseImportRewrite(tree).visit(tree)


# Generated at 2022-06-21 17:26:16.238721
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typing', 'copy')]

    source = """
import typing
"""
    expected = """
try:
    import typing
except ImportError:
    import copy
"""
    tree = ast.parse(source)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    actual = astor.to_source(tree)

    assert expected == actual



# Generated at 2022-06-21 17:26:19.803712
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, ast.NodeTransformer)
    assert isinstance(BaseNodeTransformer.transform, classmethod)


# Generated at 2022-06-21 17:26:21.216343
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.parse(''))

# Generated at 2022-06-21 17:26:21.599330
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:26:28.087492
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert isinstance(BaseImportRewrite, BaseNodeTransformer)
    assert isinstance(BaseImportRewrite, BaseTransformer)

# Generated at 2022-06-21 17:26:35.745170
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    __tree, __changed = BaseNodeTransformer.transform(ast.parse(
        """
        def test(a):
            pass
        """
    ))
    assert __tree == ast.parse(
        """
        def test(a):
            pass
        """
    )
    assert __changed is False
    assert astor.to_source(__tree) == 'def test(a):\n    pass\n'


# Generated at 2022-06-21 17:26:47.495211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Prepare
    from ..utils import ast_helpers

    transformer_data = {
        'rewrites': [
            ('django.x', 'django.y'),
            ('django.utils.a', 'django.utils.b')
        ]
    }  # type: Dict[str, List[Tuple[str, str]]]
    transformer_class = type('TestTransformer', (BaseImportRewrite, ), transformer_data)

# Generated at 2022-06-21 17:26:54.985626
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyTransformer(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'baz.qux')
        ]

    # Imports with dots
    expr = ast.parse('import baz.qux.foo\n')
    expected = ast.parse('import baz.qux.foo\n')
    trans = MyTransformer.transform(expr)
    assert trans.ast == expected
    assert trans.changed is False
    assert trans.dependencies == ['baz.qux']

    # Imports from
    expr = ast.parse('from baz.qux import foo\n')
    expected = ast.parse('from baz.qux import foo\n')
    trans = MyTransformer.transform(expr)
    assert trans.ast == expected
    assert trans.changed is False
    assert trans

# Generated at 2022-06-21 17:27:01.788629
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-21 17:27:09.476996
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class Test(BaseImportRewrite):
        rewrites = [('tkinter', 'tkinter.ttk')]

    expected = """\
try:
    from tkinter import *
except ImportError:
    from tkinter.ttk import *
"""

    node = ast.ImportFrom(module='tkinter', names=[ast.alias(name='*')])
    transformed = Test.transform(node)

    assert astor.to_source(transformed.tree) == expected



# Generated at 2022-06-21 17:27:14.234747
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    #Test method
    def test_target():
        assert bt.target is None
    test_target()


# Generated at 2022-06-21 17:27:18.615732
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo_rewrite'),
            ('bar', 'bar_rewrite'),
        ]
    tree = ast.parse('import foo; import bar; from foo import *; from bar import baz')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 17:27:28.008364
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.snippet import snippet

    class TestTransformer(object):
        target = 'test'
        rewrites = [('old', 'new')]

        @snippet
        def test(self):
            import old
            import old.sub
            from old import x, y
            from old.sub import x, y

    t = TestTransformer()
    result = t.test()

    try:
        import old
        import old.sub
        from old import x, y
        from old.sub import x, y
    except ImportError:
        import new
        import new.sub
        from new import x, y
        from new.sub import x, y

    assert result == t.test.body

# Generated at 2022-06-21 17:27:32.211209
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tran = BaseNodeTransformer(ast.parse("x=1"))
    assert not tran._tree_changed


# Generated at 2022-06-21 17:27:50.198943
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert hasattr(BaseNodeTransformer, '_tree')
    assert hasattr(BaseNodeTransformer, '_tree_changed')
    assert hasattr(BaseNodeTransformer, 'target')

# Generated at 2022-06-21 17:27:53.539581
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == 'python 3.2'


# Generated at 2022-06-21 17:28:00.624055
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    module = ast.parse('''from foo import *
from foo import bar
from foo import baz
from foo import qux as foo
from foo.bar import *
from foo.bar import bar
from foo.bar import baz
from foo.bar import qux as foo''')
    rewrite = BaseImportRewrite(module)
    rewrite.rewrites = [('foo.bar', 'bar.foo')]
    rewrite.visit(module)

# Generated at 2022-06-21 17:28:01.453196
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:28:02.619333
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == {'transform'}

# Generated at 2022-06-21 17:28:03.836588
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Trans(BaseNodeTransformer):
        ...

    t = Trans(ast.parse("while True: pass"))

# Generated at 2022-06-21 17:28:08.406069
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Foo(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

    foo = Foo(ast.Module(body=[]))
    assert isinstance(foo, Foo)
    assert isinstance(foo, BaseNodeTransformer)
    assert isinstance(foo, ast.NodeTransformer)
    assert foo._tree.body == []
    assert foo._tree_changed is False



# Generated at 2022-06-21 17:28:12.887427
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast as _ast
    obj = BaseImportRewrite()
    # Note: it would be better if the type of obj is BaseImportRewrite
    assert isinstance(obj, BaseNodeTransformer)


# Generated at 2022-06-21 17:28:14.353025
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(object()) is not None

# Generated at 2022-06-21 17:28:22.809597
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    from foo import Foo
    from foo.bar import Bar
    ''')

    result = TestBaseImportRewrite.transform(tree)
    assert not result.changed
    assert result.tree is tree

    tree = ast.parse('''
    from foo.bar import Bar
    from foo import Foo
    from foo.baz import Baz
    import foo
    ''')

    result = TestBaseImportRewrite.transform(tree)
    assert result.changed

    import_module = ast.Import(names=[ast.alias(name='bar', asname=None)])

# Generated at 2022-06-21 17:28:33.398892
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-21 17:28:34.238967
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:28:36.376123
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer().__init__()


# Generated at 2022-06-21 17:28:48.606073
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    fixture = type('Fixture', (BaseImportRewrite,), {
        'rewrites': [
            ('ssl', 'six.moves.ssl'),
        ],
    })
    tree = ast.parse("""
from ssl import SSLContext
from ssl import CreatedCertificate  # type: ignore[args-differ]

from ssl.sslContext import _create_sslsocket

from .ssl import SSLContext

from ssl import *
    """)
    result = fixture.transform(tree)
    assert result.changed is True

# Generated at 2022-06-21 17:28:52.895571
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("")
    assert BaseNodeTransformer(tree)._tree is not None
    assert BaseNodeTransformer(tree)._tree is tree
    assert BaseNodeTransformer(tree).transform(tree) is not None



# Generated at 2022-06-21 17:29:04.240788
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Tr(BaseImportRewrite):
        rewrites = [("test", "upgrade.test"), ("test.utils", "upgrade.test.utils")]

    tree = ast.parse("""
        import test
        import test.utils
        import test.utils as utils
        from test import utils as utils2
        from test.utils import bar
    """)

    Tr.transform(tree)


# Generated at 2022-06-21 17:29:12.582550
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as builtin_ast
    from ..utils.source import source
    from ..utils.runner import run_tests

    def check(code, expected, **kwargs):
        assert expected.strip() == builtin_ast.dump(BaseImportRewrite().visit(builtin_ast.parse(code.strip()))).strip()

    run_tests(check, source(__file__).dir.joinpath('BaseImportRewrite_visit_ImportFrom.txt'))


__all__ = ('BaseTransformer',
           'BaseNodeTransformer',
           'BaseImportRewrite')

# Generated at 2022-06-21 17:29:15.301337
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'py2'

    assert TestTransformer.target == 'py2'



# Generated at 2022-06-21 17:29:16.098349
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:29:18.215283
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert hasattr(BaseTransformer, "transform")

# Generated at 2022-06-21 17:29:46.980121
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class test(BaseTransformer):
        pass
    assert isinstance(test(), BaseTransformer)


# Generated at 2022-06-21 17:29:57.409238
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from ..ast_helpers import parse
    from .base import register_transformer, transformers

    class Test(BaseTransformer):
        target = CompilationTarget('test')

    def transform(tree):  # Dummy
        return tree

    Test.transform = transform

    register_transformer(Test)

    assert Test in transformers
    assert Test.transform == transform

    tree = ast.parse('foo()')
    assert transformers['test'].transform(tree) == tree

# Generated at 2022-06-21 17:29:58.964750
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)

# Generated at 2022-06-21 17:30:03.662342
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = None
    assert isinstance(BaseNodeTransformer(tree), BaseNodeTransformer)
    assert BaseNodeTransformer(tree)._tree == tree
    assert BaseNodeTransformer(tree)._tree_changed == False


# Generated at 2022-06-21 17:30:05.088758
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass



# Generated at 2022-06-21 17:30:07.606498
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class transformer(BaseTransformer):
        target = CompilationTarget.PY2

        @classmethod
        def transform(cls, tree):
            return
    transformer({})

# Generated at 2022-06-21 17:30:17.009885
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BaseImportRewriteSubclass(BaseImportRewrite):
        rewrites = [
            ('django', 'django_mock'),
            ('requests', 'requests_mock')]

    tree = ast.parse("import django")
    assert BaseImportRewriteSubclass.transform(tree) == TransformationResult(ast.parse("""
try:
    import django
except ImportError:
    import django_mock as django"""), True, [])

# Generated at 2022-06-21 17:30:20.936737
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert not hasattr(BaseTransformer, "transform")


# Generated at 2022-06-21 17:30:30.311573
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]

    assert ImportRewrite.transform(ast.parse('import a')).changed is True
    assert ImportRewrite.transform(ast.parse('import a.d')).changed is True
    assert ImportRewrite.transform(ast.parse('import a.d as d')).changed is True
    assert ImportRewrite.transform(ast.parse('from a import *')).changed is True
    assert ImportRewrite.transform(ast.parse('import a.d')).source == 'try:\n    import a.d\nexcept ImportError:\n    import b.d'

# Generated at 2022-06-21 17:30:39.786368
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    expected_result = ast.module(
        'from django.contrib import auth\n'
        'from django.test import TestCase as TC\n'
        'try:\n'
        '    from django.test import TestCase\n'
        'except ImportError:\n'
        '    from django.test import TestCase as TC\n')

    input_tree = ast.parse('from django.contrib import auth\n'
                           'from django.test import TestCase as TC\n')

    class MockTransformer(BaseImportRewrite):
        rewrites = [('django', 'django2')]


    assert MockTransformer.transform(input_tree).tree == expected_result

# Generated at 2022-06-21 17:31:42.158118
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.parse('''
from six.moves import http_client

from six.moves import http_cookies
from six.moves.urllib.request import urlretrieve
from six.moves.urllib.parse import quote

http_client.HTTPSConnection('example.org')
http_cookies.CookieError
urlretrieve('http://example.org/foo.txt')
quote('Test')
''').body


# Generated at 2022-06-21 17:31:53.234159
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.Import(names=[ast.alias(name='foo', asname=None),
                             ast.alias(name='foo.bar', asname='baz'),
                             ast.alias(name='bar', asname=None)])


# Generated at 2022-06-21 17:31:54.293842
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None

# Generated at 2022-06-21 17:31:59.296529
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [
            ('sqlite3', 'pysqlite2'),
        ]

    tree = ast.parse('''
import sqlite3
''')
    result = Test.transform(tree)
    assert result.tree == ast.parse('''
try:
    import sqlite3
except ImportError:
    import pysqlite2
''')
    assert result.changed
test_BaseImportRewrite_visit_Import()


# Generated at 2022-06-21 17:32:04.704281
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():

    import astor
    # Unit test for constructor BaseNodeTransformer
    # check that we have correct instance of BaseNodeTransformer 
    # when we call BaseNodeTransformer

# Generated at 2022-06-21 17:32:09.037761
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None

    transformer.target = CompilationTarget.PYTHON
    assert transformer.target is CompilationTarget.PYTHON

# Generated at 2022-06-21 17:32:17.507167
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('import_rewrite', 'my_module')]

    node = ast3.parse('from import_rewrite.snippet import extend as ext')
    TestImportRewrite().visit(node)


# Generated at 2022-06-21 17:32:26.153925
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from textwrap import dedent
    from .. import CompilationTarget

    code = dedent("""\
        import six.moves as sixm
        from six import moves as sixm2
        import something.six.moves.as.sixm3

        from something import sixm4
        from something import sixm5 as sixm6
        from something.six.moves import seven
        from something.six.moves import something as eight
        from something.six.moves import nine as ten
        """)

    rewrites = [("six.moves", "six.moves.something")]


# Generated at 2022-06-21 17:32:28.060791
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()

    assert transformer.target == None


# Generated at 2022-06-21 17:32:30.658668
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class FakeTransformer(BaseNodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]

    assert FakeTransformer._tree is None
    assert FakeTransformer._tree_changed is False

# Generated at 2022-06-21 17:34:21.306848
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ....tests.transformer_tests.utils import generate_module_from_code

    code = """
from . import p
from .a import A, B
from .a import *
from .b import *
from . import d
from .e import A, B
from .e import *
from .f import *
from . import *
from .h import *
"""
    tree = generate_module_from_code(code)
    trans = BaseImportRewrite(tree)
    trans.visit(tree)

