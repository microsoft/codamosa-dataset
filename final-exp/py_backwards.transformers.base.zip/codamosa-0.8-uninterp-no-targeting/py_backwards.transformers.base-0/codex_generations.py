

# Generated at 2022-06-21 17:24:13.037218
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from .transformer import BaseImportRewrite
    import_node = ast.Import([ast.alias(name='six',
                                        asname='six')])
    import_node_rewrite = ast.Import([ast.alias(name='six.moves',
                                                asname='six')])
    try_node = ast.Try([ast.stmt(body=import_node,
                                 lineno=0,
                                 col_offset=0)],
                       [ast.ExceptHandler(type=None,
                                          name=None,
                                          body=[ast.stmt(body=import_node_rewrite,
                                                         lineno=0,
                                                         col_offset=0)])],
                       [],
                       [])
    class_rewrite = BaseImport

# Generated at 2022-06-21 17:24:16.552696
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Test(BaseTransformer):
        target = (3, 4)

        @classmethod
        def transform(cls, tree):
            pass
    test = Test()
    assert test is not None
    assert Test.transform is not None
    assert Test.target == (3, 4)


# Generated at 2022-06-21 17:24:23.217902
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    from ..utils.ast import parse_ast, dump_ast
    from ..utils.testing import assert_code_equal

    node = parse_ast("""
        from a.b.c import as as as_
    """)

    result = BaseImportRewrite(node)
    result.visit(node)
    assert_code_equal(dump_ast(node), """
        try:
            from a.b.c import as as as_
        except ImportError:
            from a.b.c import as as as_
    """)

    result.rewrites = [("a.b", "x")]
    result._tree_changed = False
    result.visit(node)

# Generated at 2022-06-21 17:24:27.656260
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        pass

    tnt = TestNodeTransformer(ast.parse("pass"))
    assert tnt._tree == ast.parse("pass")

# Generated at 2022-06-21 17:24:28.894623
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target == None

# Generated at 2022-06-21 17:24:35.696519
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    import ast

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget('python', '3.5')
        rewrites = [('os', 'posix')]

    program = '''
        import os
        import some_other_module
    '''

    expected = '''
        try:
            import os
        except ImportError:
            import posix
        import some_other_module
    '''

    actual = TestTransformer.transform(ast.parse(program)).tree
    print(ast.dump(actual))
    assert ast.dump(actual) == expected


# Generated at 2022-06-21 17:24:42.625664
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from typing import List, Tuple
    from typed_ast import ast3 as ast

    rewrites = [("baz.foo", "bar.baz")] # type: List[Tuple[str, str]]
    tree = ast.parse("import baz.foo")

    class F(BaseImportRewrite):
        rewrites = rewrites
        def visit_Import(self, node):
            return BaseImportRewrite.visit_Import(self, node)

    F.transform(tree)
    assert astor.to_source(tree) == "try:\n    import baz.foo\nexcept ImportError:\n    import bar.baz\n"



# Generated at 2022-06-21 17:24:43.854099
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(ast.Module(body=[]))

# Generated at 2022-06-21 17:24:47.870159
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # type: () -> None
    class DummyTransformer(BaseTransformer):
        @classmethod
        def transform(cls, tree):
            # type: (ast.AST) -> TransformationResult
            return TransformationResult(tree, False, [])

    tree = ast.parse("")
    result = DummyTransformer.transform(tree)  # type: ignore

    assert result.tree == tree
    assert not result.changed
    assert result.dependencies == []



# Generated at 2022-06-21 17:24:50.188792
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer(): 
    transformer = BaseTransformer()
    _ = transformer.target
    assert transformer.target == None

# Generated at 2022-06-21 17:25:05.007255
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:25:06.804811
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('import os\nfrom typing import List')
    assert BaseImportRewrite.transform(tree) == (
        ast.parse('import os\nfrom typing import List'), False, [])

# Generated at 2022-06-21 17:25:08.140086
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'
    assert BaseImportRewrite.dependencies == []
    assert BaseImportRewrite.target == None

# Generated at 2022-06-21 17:25:12.303630
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.test import assertEqual
    tree = ast.parse('x = 5')
    result = BaseNodeTransformer.transform(tree).tree
    assertEqual(result, ast.parse('x = 5'))

# Generated at 2022-06-21 17:25:17.084050
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Class(BaseNodeTransformer):
        def visit_Import(self, node):
            return ast.Import(node.names)

    tree = ast.parse('import a, b')
    result = Class.transform(tree)
    assert result.changed is True
    assert result.dependencies == []
    assert ast.dump(tree) == 'Import(names=[alias(name=\'a\', asname=None), alias(name=\'b\', asname=None)])'


# Generated at 2022-06-21 17:25:18.223472
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    obj = BaseImportRewrite()
    assert(obj is not None)

# Generated at 2022-06-21 17:25:23.052155
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tr_cls = BaseTransformer

    assert tr_cls.target is None
    assert tr_cls.transform(None) is None
    assert issubclass(tr_cls, BaseTransformer)


# Generated at 2022-06-21 17:25:32.136764
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import ast_equals

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('old', 'new')]

    tree_in = ast.parse('''
from old import A
''')
    tree_out = ast.parse('''
try:
    from old import A
except ImportError:
    from new import A
''')
    tree_transformed = TestTransformer.transform(tree_in).tree
    assert ast_equals(tree_transformed, tree_out)

    tree_in = ast.parse('''
from future import print_function
''')
    tree_transformed = TestTransformer.transform(tree_in).tree
    assert ast_equals(tree_transformed, tree_in)



# Generated at 2022-06-21 17:25:33.154093
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite


# Generated at 2022-06-21 17:25:38.147937
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            self._fail = False

    t = MyTransformer(None)
    assert not t._fail



# Generated at 2022-06-21 17:25:48.302451
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Unit test for method visit_Import of class BaseImportRewrite"""
    import unittest
    import ast
    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast
    from py2c.transformer.base import BaseImportRewrite

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('abc.abc.abc', 'typed_ast.ast3')]

    class TestTransformer(unittest.TestCase):
        def test_visit_Import(self):
            """Test visit_Import"""
            code = """\
            import abc.abc.abc
            """
            tree = DummyTransformer.transform(parse(code))[0]
            tree = ast.fix_missing_locations(tree)

# Generated at 2022-06-21 17:25:49.149618
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert True

# Generated at 2022-06-21 17:25:59.965320
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # This class is an abstraction of:
    # from . import some_module
    # from .x import some_module
    # from .x.y import some_module
    class ImportFromTest(BaseImportRewrite):
        rewrites = [('module_1', 'module_2')]

    # The module name does not match the import rewrite list
    tree = ast.parse('from . import module_1')
    result = ImportFromTest.transform(tree)
    assert not result.changed

    # The module name matches the import rewrite list
    tree = ast.parse('from . import module_1')
    result = ImportFromTest.transform(tree)
    assert result.changed

# Generated at 2022-06-21 17:26:03.483844
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class ExBaseNodeTransformer(BaseNodeTransformer):
        def visit_Module(self, node):
            return True

    ExBaseNodeTransformer(ast.Module)



# Generated at 2022-06-21 17:26:15.708572
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...compiler import Compiler
    from ...tests.test_ast import ast_tree
    from ...tests.test_utils.snippet import assert_source

    tree = ast_tree('''
    import foo

    def foo():
        pass
    ''')
    compiler = Compiler(targets={'python': '3'})
    compiler.transformers.append(BaseImportRewrite)
    BaseImportRewrite.rewrites = [('foo', 'baz')]
    result = compiler.compile(tree)
    assert_source(result, '''
    try:
        import foo
    except ImportError:
        import baz


    def foo():
        pass
    ''')



# Generated at 2022-06-21 17:26:27.007997
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('django.utils', 'django_utils')]

    import_ = ast.Import(names=[ast.alias(name='django.utils.six', asname='six')])
    rewrote = ImportRewrite.transform(import_).ast

    assert rewrote.body[0].body[0].value.names[0].name == 'django_utils.six'
    assert rewrote.body[0].body[0].value.names[0].asname == 'six'
    assert rewrote.body[0].handlers[0].type.id == 'ImportError'
    assert rewrote.body[0].handlers[0].name is None
    assert rewrote.body[0].handlers[0].body[0].value.names[0].name

# Generated at 2022-06-21 17:26:38.202949
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as typed_ast
    import sys
    transformer = BaseImportRewrite()

    node = typed_ast.parse(
        'from __future__ import (absolute_import, division, print_function, '
        'unicode_literals)'
    ).body[0]
    rewrote = transformer.visit(node)
    assert node == rewrote

    node = typed_ast.parse(
        'from __future__ import absolute_import'
    ).body[0]
    rewrote = transformer.visit(node)
    assert node == rewrote

    node = typed_ast.parse(
        'from future.standard_library import install_aliases'
    ).body[0]
    rewrote = transformer.visit(node)
    assert node != rewrote

# Generated at 2022-06-21 17:26:43.015798
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from asttokens import ASTTokens
    tree = ASTTokens(source="1").tree
    arg = BaseNodeTransformer(tree)
    assert arg._tree is tree
    assert arg._tree_changed is False


# Generated at 2022-06-21 17:26:50.707867
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    m = sys.modules[__name__]
    global_vars = m.__dict__.copy()
    global_vars.update({ 'tree' : ast.parse('import foo as f') })

    result = eval(compile(tree, '<string>', 'exec'), global_vars)  # type: import_rewrite
    assert result  # Just to stop warning about unused variable
    assert isinstance(result, ast.Try)



# Generated at 2022-06-21 17:26:57.090468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..visitors.base import BaseImportRewrite, source_to_nodes, nodes_to_source

    import pytest
    from typed_ast import ast3 as ast

    source_code = '''
    import previous as p
    '''
    nodes = source_to_nodes(source_code)

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    with pytest.raises(ImportError):
        class_instance = MyImportRewrite(ast.Module(body=[]))
        class_instance.visit(nodes[0])

        # TODO: Find another way to get result without executing code
        exec(nodes_to_source(nodes), {'__name__': '__main__', '__builtins__': __builtins__})



# Generated at 2022-06-21 17:27:06.079570
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert callable(BaseTransformer.transform)
    assert BaseTransformer.target is None


# Generated at 2022-06-21 17:27:06.921395
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-21 17:27:18.584403
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import CompilationTarget
    from ..utils.ast_helpers import parse
    from ..utils.general import get_tree_and_code_from_string
    from ..transformers.typing import BaseTransformer as bt
    from ..transformers.typing import BaseNodeTransformer as bnt
    import ast

    assert isinstance(bnt.target, CompilationTarget)
    assert isinstance(bnt.dependencies, list)

    tree = ast.parse("def foo():\n    pass")
    bnt.transform(tree)

    assert hasattr(bnt, "__init__")
    assert isinstance(bnt()._tree, ast.Module)
    assert bnt()._tree_changed == False

    assert hasattr(bnt, "transform")
    assert isinstance(bnt.transform(tree), tuple)

# Generated at 2022-06-21 17:27:27.206495
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import sys
    import unittest.mock

    tree = ast.Module([
        ast.Import(names=[
            ast.alias(
                name='os',
                asname=None
            )]),
        ast.ImportFrom(
            module='os',
            names=[
                ast.alias(
                    name='path',
                    asname=None
                )],
            level=0)
    ])

    with unittest.mock.patch.object(sys, 'gettrace') as gettrace:
        transformer = BaseNodeTransformer(tree)
        assert gettrace.call_count == 0



# Generated at 2022-06-21 17:27:30.057572
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass
    # bt = BaseTransformer()


# Generated at 2022-06-21 17:27:33.281068
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('import os\nimport sys')
    instance = BaseImportRewrite(tree)
    assert instance.target is None

# Generated at 2022-06-21 17:27:35.232819
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    t = BaseImportRewrite()
    assert isinstance(t, BaseImportRewrite)

# Generated at 2022-06-21 17:27:37.202405
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer('a')

# Generated at 2022-06-21 17:27:39.653491
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite
    BaseNodeTransformer
    BaseTransformer


# Generated at 2022-06-21 17:27:50.344978
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Tests behavior of method visit_ImportFrom of class BaseImportRewrite."""
    import_rewrite_snippet = "try:\n    pass\nexcept ImportError:\n    pass\n"

    # test_BaseImportRewrite_visit_ImportFrom_module
    assert(BaseImportRewrite(None)._replace_import_from_module(
        ast.ImportFrom(module='six.moves.urllib',
                       names=[ast.alias(name='parse')],
                       level=0),
        'six.moves', 'six').body[1].body[0] == ast.ImportFrom(
            module='six.urllib',
            names=[ast.alias(name='parse', asname='parse')],
            level=0))

    # test_BaseImportRewrite_visit_ImportFrom_name


# Generated at 2022-06-21 17:28:08.915102
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    gen = BaseTransformer()
    assert gen.target is None


# Generated at 2022-06-21 17:28:20.416926
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    def check_module_import_rewrite(expected_new_code: str, module: str, import_from: str):
        node = ast.parse(module)
        new_node = ast.parse(import_from)
        old_node = new_node.body[0]
        old_node.lineno = new_node.lineno
        old_node.col_offset = new_node.col_offset

        rewrites = [(from_, to) for from_, (to, _) in [
            ('six', ('future.utils', 'unicode_literals')),
            ('six.moves', ('future.moves', '*')),
        ]]
        dep = BaseImportRewrite(node)
        dep.rewrites = rewrites
        new_node.body[0]

# Generated at 2022-06-21 17:28:28.695860
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    from ..types import CompilationTarget
    from .base import BaseNodeTransformer
    
    class BaseNodeTransformer_test(BaseNodeTransformer, ast.NodeTransformer):
        target = CompilationTarget.PY3

        def visit_Module(self, mod):
            self._tree_changed = True
            return mod

    test_case = 'import sys'
    tree = ast.parse(test_case)
    trans = BaseNodeTransformer_test(tree)
    
    trans.visit(tree)
    assert trans._tree_changed == True
    assert astor.code_gen.to_source(tree) == 'import sys'


# Generated at 2022-06-21 17:28:32.461705
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer # type: ignore
    assert BaseNodeTransformer # type: ignore
    assert BaseImportRewrite # type: ignore

# Generated at 2022-06-21 17:28:36.452394
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .test_utils import dummy_tree
    from ..transformer import BaseNodeTransformer

    class DummyTransformer(BaseNodeTransformer):
        pass

    DummyTransformer(dummy_tree)

# Generated at 2022-06-21 17:28:43.719270
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            print(node.name)
    # construct
    t = TestTransformer.transform(ast.parse('''def f(a, b):
        c = a + b
        return c
    '''))



# Generated at 2022-06-21 17:28:48.249950
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    assert not hasattr(BaseImportRewrite, 'foo')
    # class BaseImportRewrite(BaseNodeTransformer):
    assert type(BaseImportRewrite) is type
    assert type(BaseImportRewrite) is ast.type
    assert hasattr(BaseImportRewrite, 'transform')
    # rewrites = []
    assert BaseImportRewrite.rewrites == []

# Generated at 2022-06-21 17:28:50.195354
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    assert transformer is not None

# Generated at 2022-06-21 17:29:00.762582
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import unittest as ut

    class DummyBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old', 'new')
        ]

    class TestCases(ut.TestCase):

        def test_full(self):
            tree = ast.parse('import old')
            DummyBaseImportRewrite.transform(tree)
            self.assertEqual(
                '''try:
    import old
except ImportError:
    import new
''',
                ast.unparse(tree))

        def test_dot_full(self):
            tree = ast.parse('import old.module')
            DummyBaseImportRewrite.transform(tree)

# Generated at 2022-06-21 17:29:05.876986
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'python-2.7'
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    assert TestTransformer.target == 'python-2.7'


# Generated at 2022-06-21 17:30:04.000392
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node = ast.parse('from a.b.c import A').body[0]
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a.b.c', 'd.e')]
    assert astor.to_source(TestImportRewrite.transform(node).tree) == 'try:\n    import d.e\nexcept ImportError:\n    from d.e import A\n'



# Generated at 2022-06-21 17:30:13.269621
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import sys
    import unittest
    import unittest.mock
    
    if sys.version_info.major != 3:
        sys.exit()
    
    class BaseImportRewriteTestCase(unittest.TestCase):
        def setUp(self):
            self.keep_value = unittest.mock.patch.object(
                BaseImportRewrite, 'keep_value')
            self.mock_keep_value = self.keep_value.start()
            self.mock_keep_value.return_value = True

        def tearDown(self):
            self.keep_value.stop()

        def test_full_name_import_to_rewrite(self):
            import_from = ast.parse(
                'from foo import example')
           

# Generated at 2022-06-21 17:30:14.514178
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target == None

# Generated at 2022-06-21 17:30:21.506472
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse('''
from multiprocessing import Process, Queue
from multiprocessing.util import Finalize''')

    class TestTransformer(BaseImportRewrite):
        rewrites = [('multiprocessing', 'multiprocessing_on_dill')]
        dependencies = ['multiprocessing_on_dill']

    transformer = TestTransformer(module)
    transformer.visit(module)
    res = transformer.generic_visit(module)


# Generated at 2022-06-21 17:30:22.106355
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target is None


# Generated at 2022-06-21 17:30:30.649306
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from typed_ast import ast3
    from typed_ast import ast3 as ast

    tree_raw = 'import re'
    tree = ast.parse(tree_raw)
    rewrites = [('re', 'regex')]
    BaseImportRewrite.rewrites = rewrites
    tree_new = BaseImportRewrite.transform(tree)
    assert tree_new.tree_new == ast.parse(
        'try:\n    import re\nexcept ImportError:\n    import regex', mode='eval')
    assert tree_new.changed is True
    assert tree_new.dependencies == ['regex']

    tree_raw = 'import regex'
    tree = ast.parse(tree_raw)
    tree_new = BaseImportRewrite.transform(tree)
    assert tree

# Generated at 2022-06-21 17:30:33.217394
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite(): 
    assert issubclass(BaseImportRewrite, ast.NodeTransformer)
test_BaseImportRewrite()

# Generated at 2022-06-21 17:30:41.085579
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('django.utils', 'django.utils.pytest')
        ]
    import_stmt = ast.Import(names=[
        ast.alias(name='django.utils.os',
                  asname='os')])

# Generated at 2022-06-21 17:30:51.352554
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transformer(BaseImportRewrite):
        rewrites = [('only_from', 'only_to')]
        dependencies = ['only_from']

    pytest.helpers.assert_source_equal(
        Transformer.transform(ast.parse('import only_from')).tree,
        'try:\n'
        '    import only_from\n'
        'except ImportError:\n'
        '    import only_to\n'
    )
    pytest.helpers.assert_source_equal(
        Transformer.transform(ast.parse('import only_from.one.two')).tree,
        'try:\n'
        '    import only_from.one.two\n'
        'except ImportError:\n'
        '    import only_to.one.two\n'
    )
   

# Generated at 2022-06-21 17:31:00.868387
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import typed_astunparse
    from .line_matcher import LineMatcher

    class Foo(BaseNodeTransformer):
        def visit_Expr(self, node: ast.Expr) -> ast.Expr:
            self._tree_changed = True
            return ast.Expr(value=ast.Constant(value=42))

    tree = ast.parse('1')
    result = Foo.transform(tree)
    print(typed_astunparse.dump(result.tree))

    assert LineMatcher('''\
    42
    ''').matches(typed_astunparse.dump(result.tree))
    assert result.tree_changed

# Generated at 2022-06-21 17:32:54.454572
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import typed_ast.ast3 as ast

    import this
    import that
    import realpython_reader as rp_reader
    import realpython_reader.reader as rp_reader_reader

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('this', 'the_new_this'),
            ('that', 'the_new_that'),
            ('realpython_reader.reader', 'the_new_reader')
        ]

    def get_transformed_tree(src):
        original = astunparse.unparse(ast.parse(src))
        tree = ast.parse(src)
        Transformer.transform(tree)
        transformed = astunparse.unparse(tree)

        return original, transformed
    

# Generated at 2022-06-21 17:33:04.116356
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.visitor import NodeVisitor

    class DerivedImportRewrite(BaseImportRewrite):
        rewrites = [('django.utils.six', 'six')]

    class Tester(NodeVisitor):
        def __init__(self):
            self.import_rewrites = []
            self.import_from_rewrites = []

        def visit_Import(self, node):
            self.import_rewrites.append(node)
            return node

        def visit_ImportFrom(self, node):
            self.import_from_rewrites.append(node)
            return node

    source = """
    from django.utils.six import text_type, binary_type
    import six
    import django.utils.six
    """
    tree = ast.parse(source)

    tester = Tester

# Generated at 2022-06-21 17:33:12.720655
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [('sqlalchemy', 'sqlalchemy_stubs')]

    module = ast.parse(
        "from sqlalchemy.sql.functions import GenericFunction\n"
        "from sqlalchemy import text")
    original = ast.dump(module, annotate_fields=False)

    Transformer.transform(module)
    rewritten = ast.dump(module, annotate_fields=False)

    assert rewritten == dedent("""\
    Try([    from sqlalchemy.sql.functions import GenericFunction
        except ImportError:
            from sqlalchemy_stubs.sql.functions import GenericFunction,
    Try([    from sqlalchemy import text
        except ImportError:
            from sqlalchemy_stubs import text,
    """)

# Generated at 2022-06-21 17:33:23.344065
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget

    class DummyTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON37
        rewrites = [
            ('urllib.request', 'urllib.request.urlopen'),
        ]

    tree = ast.parse('import urllib.request as ulib')

    assert str(DummyTransformer.transform(tree)[0]) == '''
try:
    import urllib.request as ulib
except ImportError:
    import urllib.request.urlopen as ulib
'''

    tree = ast.parse('import urllib.request')


# Generated at 2022-06-21 17:33:28.341676
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer(): 
    class TestTransformer(BaseNodeTransformer):
        pass
    tree = ast.parse('x = 1')
    obj1 = TestTransformer(tree)
    assert obj1._tree == tree
    assert obj1._tree_changed == False


# Generated at 2022-06-21 17:33:31.338831
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    @snippet
    def lexer():
        a = DeprecatedTransformer()
        a.transform("a")

    lexer()



# Generated at 2022-06-21 17:33:40.356006
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('''from foo.bar.baz import X''').body[0]
    assert(isinstance(import_from, ast.ImportFrom))


# Generated at 2022-06-21 17:33:52.700421
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    input = ast.parse('''
from module import name
from module.foo import bar
from module.foo import baz, kaz
from module import *
from module.foo import *
''')

    # Test nothing to change
    class FakeTransformer(BaseImportRewrite):
        rewrites = []

        def transform(tree):
            return super().transform(tree)

    result = FakeTransformer.transform(input).tree
    assert ast.dump(result) == ast.dump(input)

    # Test module rewrite
    class FakeTransformer(BaseImportRewrite):
        rewrites = [
            ('module', 'new_module')
        ]

        def transform(tree):
            return super().transform(tree)

    result = FakeTransformer.transform(input).tree

# Generated at 2022-06-21 17:33:59.624048
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class NodeTransformer(BaseImportRewrite):
        target = CompilationTarget.python_2
        rewrites = [('future', 'past')]

    tree = ast.parse('from future.builtins import print')
    NodeTransformer.transform(tree)
    assert ast.dump(tree) == textwrap.dedent("""
        try:
            from past.builtins import print
        except ImportError:
            from future.builtins import print
        """).lstrip()

