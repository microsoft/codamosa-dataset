

# Generated at 2022-06-21 17:24:24.754356
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import sys
    import unittest
    import ast
    import imp
    from ..utils.snippet import snippet

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node):
            # Need to change the tree.
            self._tree_changed = True
            return snippet.get_body()[0]

    imp.reload(sys)

    class TestBaseNodeTransformer(unittest.TestCase):
        def test_transform(self):
            code = 'import sys'
            tree = ast.parse(code)
            tree = TestTransformer.transform(tree).tree
            compiler = compile(tree, '<ast>', 'exec')
            exec(compiler)
            self.assertFalse(hasattr(sys, 'execute'))
    unittest.main()

# Generated at 2022-06-21 17:24:25.153893
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-21 17:24:30.122295
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformerSubclass(BaseNodeTransformer):
        pass
    tree = ast.parse('import json')
    obj = BaseNodeTransformerSubclass(tree)
    assert obj._tree == tree
    assert obj._tree_changed == False


test_BaseNodeTransformer()

# Generated at 2022-06-21 17:24:38.446010
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest

    from typed_ast import ast3 as ast

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.Six')
        ]

    class TestCase(unittest.TestCase):
        def test_ImportFrom_plain(self):
            node = ast.parse('from six import *')
            result = TestBaseImportRewrite.visit_ImportFrom(node)

            self.assertEqual(
                TestBaseImportRewrite._replace_import_from_module(node, 'six', 'six.Six'),  # type: ignore
                result
            )

        def test_ImportFrom_as_name(self):
            node = ast.parse('from six import foo as bar')
            result = TestBaseImportRewrite.visit_ImportFrom(node)



# Generated at 2022-06-21 17:24:45.983007
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = [('configobj', 'config')]

    import astor
    original_code = (
        'import configobj\n'
        'from configobj import ConfigObj')
    rewrote_code = (
        'import configobj\n'
        'try:\n'
        '    from configobj import ConfigObj\n'
        'except ImportError:\n'
        '    from config import ConfigObj')

    tree = astor.parse_file(original_code)
    result = MockBaseImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == rewrote_code

# Generated at 2022-06-21 17:24:51.933878
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = ast.parse("from http.client import HTTPConnection")
    transformer = BaseImportRewrite(tree)
    transformer.visit(tree)
    print(astor.to_source(tree))
    assert astor.to_source(tree) == """try:
    from http.client import HTTPConnection
except ImportError:
    from http.client import HTTPConnection"""


# Generated at 2022-06-21 17:25:01.535710
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    import_ = ast.parse("import foo").body[0]
    assert isinstance(TestTransformer.transform(import_).tree, ast.Try)

    import_ = ast.parse("import foo.bar").body[0]
    assert isinstance(TestTransformer.transform(import_).tree, ast.Try)

    import_ = ast.parse("import foo.bar.baz").body[0]
    assert isinstance(TestTransformer.transform(import_).tree, ast.Try)

    import_ = ast.parse("import foo2").body[0]
    assert isinstance(TestTransformer.transform(import_).tree, ast.Import)


# Generated at 2022-06-21 17:25:03.783107
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    tree = ast.parse("x=5")
    obj=BaseNodeTransformer(tree)
    assert obj._tree == tree
    assert obj._tree_changed == False


# Generated at 2022-06-21 17:25:11.190669
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    from io import BytesIO
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse, fix_missing_locations as fix

    source = 'import re as regex\nimport os\n' \
             'from sys import meta_path\n' \
             'from typing import Union, List\n' \
             'from typing import Optional as Opt\n'

    tree = parse(source, mode='exec')
    fix(tree)
    class RewriteTest(BaseImportRewrite):
        rewrites = [
            ('re', 'regex'),
            ('typing', 'typy')
        ]

    result = RewriteTest.transform(tree)

    assert result.changed

    module = result.tree


# Generated at 2022-06-21 17:25:18.754937
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import os
    import sys
    import unittest
    from unittest.mock import Mock, patch, call
    from ..transformers.base import BaseImportRewrite

    # Create mock TargetTransformer
    rewrites = [
        ('a.b.c.d', 'e.f.g.h')
    ]
    BaseImportRewrite.rewrites = rewrites
    instance = BaseImportRewrite()

    # Create AST
    import_node = ast.ImportFrom(module='a.b.c.d',
                                 names=[
                                     ast.alias(name='e'),
                                     ast.alias(name='f', asname='g')],
                                 level=0)

# Generated at 2022-06-21 17:25:32.912810
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typed_ast.ast3 as typed_ast
    
    
    
    
    
    
    
    
    
    
    import inspect
    import sys
    import os
    import re
    import astor

    class Rewriter(BaseImportRewrite):
        rewrites = [('typed_ast.ast3', 'ast')]

    tree = ast.parse('import typed_ast')
    rewriter = Rewriter(tree)
    rewriter.visit(tree)
    print(astor.to_source(tree))
    assert astor.to_source(tree).startswith('try:')

    tree = ast.parse('import typed_ast.ast3')
    rewriter = Rewriter(tree)
    rewriter.visit(tree)

# Generated at 2022-06-21 17:25:42.064413
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .runner import run_transformation
    from .transform import format_tree
    from .transform import ast_to_source
    from ..types import CompilationTarget

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('a.b', 'b.a')
        ]

        def __init__(self, tree: ast.AST) -> None:
            super(TestImportRewrite, self).__init__(tree)


# Generated at 2022-06-21 17:25:49.191698
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('a.b', 'a.x')]
        target = 'test'

    tree = ast.parse('from a.b import c as y, d, y as x')
    transformer = TestTransformer(tree)
    tree = transformer.visit(tree)
    assert ast.dump(tree) == "try:\n    from a.b import c as y, d, y as x\nexcept ImportError:\n    from a.x import c as y, d, y as x"

    tree = ast.parse('from a.b import d, e')
    transformer = TestTransformer(tree)
    tree = transformer.visit(tree)
    assert ast.dump(tree) == "from a.b import d, e"


# Generated at 2022-06-21 17:25:59.993853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_code import ImportTestCode
    printer = ast.NodeVisitor()

    target = 'python2'
    # target = 'python3'
    # target = 'python3.6'
    # target = 'python3.7'

    class ImportTest(BaseImportRewrite):
        target = target
        rewrites = [
            ('urllib.urlopen', 
             'urllib.request.urlopen'),
            ('urllib.urlretrieve', 
             'urllib.request.urlretrieve')]

    result = ImportTest.transform(ImportTestCode.import_code)
    assert result.tree_changed is True
    assert printer.visit(result.tree) == printer.visit(ImportTestCode.import_code_results[target])



# Generated at 2022-06-21 17:26:03.139810
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert t.target == None
    transformationResult = t.transform(None)


# Generated at 2022-06-21 17:26:04.998518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...target import DunderSlots
    from ..utils.utils import load_module

# Generated at 2022-06-21 17:26:08.129898
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from unittest.mock import Mock

    tree_mock = Mock()
    BaseImportRewrite(tree_mock)

# Generated at 2022-06-21 17:26:12.576503
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not hasattr(BaseTransformer, 'transform')

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 17:26:20.221420
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Setup
    import astunparse
    import typing_extensions
    import nox.sessions as nox_sessions
    import nox.sessions as nox_sessions
    import ast as _ast

# Generated at 2022-06-21 17:26:24.421447
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class WithImport(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    tree = ast.parse('import old_module')
    res = WithImport.transform(tree)
    assert res.tree.body[0].body[0].body[0].value.names[0].name == 'old_module'
    assert res.tree.body[0].body[0].body[1].value.names[0].name == 'new_module'



# Generated at 2022-06-21 17:26:39.655866
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helper import is_import_from
    module = ast.parse('from urllib import request')
    transformer = BaseImportRewrite(module)
    module = transformer.visit(module)
    assert astor.to_source(module) == '''
try:
    from urllib import request
except ImportError:
    from urllib import request
'''



# Generated at 2022-06-21 17:26:40.959273
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test_BaseNodeTransformer_BaseNodeTransformer()

# Generated at 2022-06-21 17:26:49.056005
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('import_module', 'new_module')]

    tree = ast.parse('from import_module import a, b\n'
                     'from import_module import *\n'
                     'from import_module import c, d as d1\n'
                     'from import_module import e.e1, e.e2')
    result = TestTransformer.transform(tree)

# Generated at 2022-06-21 17:26:56.170291
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.snippet import ast_from_snippet
    from ..utils.ast_diff import check_ast_diff

    # no rewrites -> no changes
    node = ast.Import(names=[ast.alias(name='os', asname=None)])
    expected_node = ast.Import(names=[ast.alias(name='os', asname=None)])
    check_ast_diff(BaseImportRewrite.transform(node)[0], expected_node)

    # rewrite forward -> replace import
    node = ast.Import(names=[ast.alias(name='os', asname=None)])
    expected_node = import_rewrite.get_body(current=ast.Import(names=[ast.alias(name='os2', asname=None)]))[0]

# Generated at 2022-06-21 17:27:05.436043
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('''
    def foo():
        x = 1
    ''')
    class Transformer(BaseNodeTransformer):
        def visit_Num(self, node):
            self._tree_changed = True
            return ast.Num(n=2)
    transformer = Transformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree.body[0].body[0].value) == 'Num(n=2)'


# Generated at 2022-06-21 17:27:13.434400
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class ImportsRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ImportsRewrite.transform(ast.parse('import foo')).tree
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-21 17:27:14.822077
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None


# Generated at 2022-06-21 17:27:23.854024
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [("django.conf", "uiucprescon.django.conf")]
    BaseImportRewrite.__init__(self, tree)
    assert BaseImportRewrite._get_matched_rewrite("django.conf") == ("django.conf", "uiucprescon.django.conf")
    assert BaseImportRewrite._get_matched_rewrite("django.conf.settings") == ("django.conf", "uiucprescon.django.conf")
    assert BaseImportRewrite._get_matched_rewrite("django.conf.settings.django") == None
    ast_tree = ast.parse("from django.conf import settings")

# Generated at 2022-06-21 17:27:30.343116
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock
    import ast

    mock_tree_changed = unittest.mock.Mock()
    mock_tree_changed.return_value = 'changed'

    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = [('from_', 'to')]
        _tree_changed = mock_tree_changed

    rebaser = MockBaseImportRewrite(None)
    import_ = ast.Import(names=[ast.alias(name='from_', asname='from_')])
    rebaser.visit_Import(import_)
    mock_tree_changed.assert_called_once_with()

    mock_tree_changed.reset_mock()
    import_ = ast.Import(names=[ast.alias(name='to', asname='from_')])

# Generated at 2022-06-21 17:27:40.089194
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typing
    from ..utils.source import source

    class Foo(BaseImportRewrite):
        rewrites = [
            ('typing', 'mytyping')
        ]

    result = Foo.transform(source(typing))

    assert result.tree_changed
    assert source(result.tree) == '''
import mytyping
try:
    from typing import *
except ImportError:
    from mytyping import *
    '''

    # Assert that no exception is raised when there is no such module
    class Foo(BaseImportRewrite):
        rewrites = [
            ('mytyping', 'mytyping')
        ]


# Generated at 2022-06-21 17:27:54.641056
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class DummyNodeTransformer(BaseNodeTransformer):
        pass
    DummyNodeTransformer(None)

# Generated at 2022-06-21 17:28:00.314532
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__init__.__annotations__ == {
        'return': None
    }, 'Bad annotations for BaseTransformer.__init__'

    assert BaseTransformer.transform.__annotations__ == {
        'tree': ast.AST,
        'return': TransformationResult
    }, 'Bad annotations for BaseTransformer.transform'

    assert BaseTransformer.transform.__annotations__['return'].__args__ == (
        ast.AST,
        bool,
        List[str]
    ), 'Bad annotations for return type of BaseTransformer.transform'

    assert BaseTransformer.target.__class__ == CompilationTarget, 'Bad annotations for BaseTransformer.target'



# Generated at 2022-06-21 17:28:05.254784
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import graphql

    class _(BaseImportRewrite):
        rewrites = [(graphql.__name__, 'graphene.types.base_schema.graphql')]
        rewrites = []

    _()

# Generated at 2022-06-21 17:28:06.931789
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from .test_transformation_helper import check_transformer_has_class_method

    check_transformer_has_class_method(BaseTransformer, 'transform')


# Generated at 2022-06-21 17:28:19.736084
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [
            ("django.apps", "django.contrib.apps")
        ]

    source = """
from django.apps import apps
from django.apps import models
from django.apps.models import QuerySet
from django.apps.config import AppConfig
from django.utils import something
"""


# Generated at 2022-06-21 17:28:28.784315
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('a', 'b')
        ]

    node = ast.parse('import a').body[0]
    result = TestImportRewrite(None).visit(node)
    assert isinstance(result, ast.Try)
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'b'
    assert result.body[1].body[0].test.names[0].name == 'ImportError'

# Generated at 2022-06-21 17:28:37.961686
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    node = ast.parse('from foo import bar, baz')
    from_, to = 'foo', 'foo_renamed'
    rewrites = [(from_, to)]
    tree = BaseImportRewrite.transform(node, rewrites)
    assert astor.to_source(tree) == \
        'try:\n' \
        '    from foo_renamed import bar, baz\n' \
        'except ImportError:\n' \
        '    from foo import bar, baz'


# Generated at 2022-06-21 17:28:49.058341
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import pkg.subpkg")

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [("pkg.subpkg", "new_pkg.subpkg")]

    result = TestImportRewrite.transform(tree=tree)
    assert result.tree.body[0].value.names[0].name == "new_pkg.subpkg"
    assert isinstance(result.tree.body[0].value, ast.Try)
    assert len(result.tree.body[0].value.handlers) == 1
    assert result.tree.body[0].value.handlers[0].type.id == "ImportError"
    assert result.tree.body[0].value.handlers[0].body[0].value.names[0].name == "pkg.subpkg"


# Generated at 2022-06-21 17:29:00.168639
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    assert BaseImportRewrite(ast.parse('pass'))._tree_changed == False
    assert BaseImportRewrite(ast.parse('from datetime import datetime'))._get_matched_rewrite('datetime') == ('datetime', 'datetime1')
    assert BaseImportRewrite(ast.parse('from datetime import datetime'))._get_matched_rewrite('ast') == None
    assert BaseImportRewrite(ast.parse('from datetime import datetime'))._get_matched_rewrite('datetime.datetime') == ('datetime', 'datetime1')

# Generated at 2022-06-21 17:29:04.513936
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__.__annotations__['self'] == 'BaseImportRewrite'
    assert BaseImportRewrite.__init__.__annotations__['tree'] == ast.AST



# Generated at 2022-06-21 17:29:35.679408
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class A(BaseImportRewrite):
        pass
    A()

# Generated at 2022-06-21 17:29:41.774496
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    t= BaseNodeTransformer(ast.parse('if 1: x'))
    assert astor.to_source(t._tree) == 'if 1:\n    x'
    assert t._tree_changed == False

# Generated at 2022-06-21 17:29:44.410430
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(BaseNodeTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:29:48.232252
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'test'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    x = TestTransformer()


# Generated at 2022-06-21 17:30:00.008060
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from itertools import permutations

    class Test(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    # Permutations of imports with possible import, import as, from import

# Generated at 2022-06-21 17:30:10.577687
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest

    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six.moves', 'six.moves.mock')]


# Generated at 2022-06-21 17:30:18.686373
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore

    class FakeTransformer(BaseImportRewrite):
        target = 'python-3.5'
        rewrites = [('sqlalchemy.sql', 'sqlalchemy.orm')]

    original = astor.to_source(ast.parse('import sqlalchemy.sql'))
    expected = astor.to_source(ast.parse((
        'try:\n'
        '    import sqlalchemy.sql\n'
        'except ImportError:\n'
        '    import sqlalchemy.orm')))
    assert expected == astor.to_source(FakeTransformer.transform(ast.parse(original)).tree)



# Generated at 2022-06-21 17:30:26.333274
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Dummy
    class DummyBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    dummy = DummyBaseImportRewrite()
    assert isinstance(dummy, BaseNodeTransformer)
    assert dummy.__class__.__name__ == 'DummyBaseImportRewrite'


# Generated at 2022-06-21 17:30:30.403791
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    tree = ast.parse("i = 0")
    inst = BaseNodeTransformer(tree)
    assert inst._tree == ast.parse("i = 0")
    assert inst._tree_changed == False
    inst.visit(tree)
    assert inst._tree == ast.parse("i = 0")
    assert inst._tree_changed == False
    result = inst.transform(tree)
    assert inst._tree == ast.parse("i = 0")
    assert inst._tree_changed == False


# Generated at 2022-06-21 17:30:36.472340
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import a')
    inst = BaseNodeTransformer(tree)
    assert inst._tree == tree
    assert inst._tree_changed is False


if __name__ == '__main__':
    import doctest
    import sys
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-21 17:31:40.584892
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..transformation import BaseImportRewrite
    from .test_utils import assert_transformed_ast_equals

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    # Imports from

# Generated at 2022-06-21 17:31:50.831612
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    node = ast.Import(names=[ast.alias(name='tempfile', asname='tempfile')])
    assert node.names[0].name != 'tempfile'
    assert node.names[0].name != 'tempfile'
    assert node.names[0].asname != 'tempfile'
    assert node.names[0].asname != 'tempfile'
    assert node.names[0].name == 'tempfile'
    assert node.names[0].name == 'tempfile'
    assert node.names[0].asname == 'tempfile'
    assert node.names[0].asname == 'tempfile'

# Generated at 2022-06-21 17:31:57.247155
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('platform', 'compat_platform')]

    tr = Transformer.transform(ast.parse('import platform'))
    assert 'ImportError' in tr.tree.body[0].handlers[0].name.split('.')[-1]



# Generated at 2022-06-21 17:32:02.394432
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.tester import run_tests

    class Test(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    class TestFromWithAlias(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    class TestFromWithAliasWithAsname(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    class TestFromWithModule(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    class TestFromWithName(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    class TestFromWithNameWithAsname(BaseImportRewrite):
        rewrites = [('previous', 'current')]


# Generated at 2022-06-21 17:32:14.758381
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import math
    import ast
    from ..utils.snippet import snippet, extend
    import_rewrite = snippet('try:\n    extend(previous)\nexcept ImportError:\n    extend(current)\n')
    # previous and current don't have any sense here
    # it's just a test that snippet has been inserted properly
    previous = ast.Import(names=[ast.alias(name='six.moves.configparser', asname='configparser')])
    current = ast.Import(names=[ast.alias(name='configparser', asname='configparser')])

    res = import_rewrite.get_body(previous, current)
    assert isinstance(res[0], ast.Try)
    assert res[0].body[0].value.value is extend
    assert res[0].body[1].value.value is extend



# Generated at 2022-06-21 17:32:25.193490
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='six', names=[ast.alias(name='text_type', asname=None)], level=0)
    a = BaseImportRewrite(None)
    transformed = a.visit_ImportFrom(node)
    assert isinstance(transformed, ast.Try)
    assert len(transformed.body) == 1
    assert isinstance(transformed.body[0], ast.ImportFrom)
    assert transformed.body[0].names[0].name == 'six'
    assert transformed.body[0].names[0].asname == 'six'
    assert len(transformed.body[0].names[0].names) == 1
    assert transformed.body[0].names[0].names[0] == 'text_type'
    assert transformed.body[0].names[0].level == 0


# Generated at 2022-06-21 17:32:29.642056
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    instance = BaseTransformer()
    instance.target = CompilationTarget.PYTHON
    assert instance.target == CompilationTarget.PYTHON

    assert BaseTransformer.transform(None) == None
    with pytest.raises(TypeError):
        BaseTransformer.target = 5


# Generated at 2022-06-21 17:32:30.595150
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from . import test_import_rewrite
    test_import_rewrite()

# Generated at 2022-06-21 17:32:32.095338
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class SomeTransformer(BaseTransformer):
        target = 'target_name'

    some_transformer = SomeTransformer()
    assert some_transformer.target == 'target_name'

# Generated at 2022-06-21 17:32:34.410096
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer.__init__