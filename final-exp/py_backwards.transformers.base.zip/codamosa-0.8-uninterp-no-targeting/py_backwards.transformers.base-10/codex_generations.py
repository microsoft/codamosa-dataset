

# Generated at 2022-06-21 17:24:19.375497
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('past', 'future')]

    input = """
import past
"""
    expected = """
try:
    import past
except ImportError:
    import future
"""
    ast_tree = ast.parse(input)
    TestImportRewrite().transform(ast_tree)
    assert astor.to_source(ast_tree) == expected


# Generated at 2022-06-21 17:24:26.051087
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from typed_ast import ast3 as ast
    from ..utils import source_generator
    from ..utils.source_generator import generate_source

    class TestCase(unittest.TestCase):

        def __init__(self, *args, **kwargs):
            self.rewrites = kwargs.pop('rewrites')
            self.expected = kwargs.pop('expected')
            self.source = kwargs.pop('source')
            super().__init__(*args, **kwargs)

        def runTest(self):
            tree = ast.parse(self.source)
            inst = BaseImportRewrite(tree)
            inst.rewrites = self.rewrites
            result = inst.visit_ImportFrom(tree.body[0])

# Generated at 2022-06-21 17:24:27.753228
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'

# Generated at 2022-06-21 17:24:36.642015
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compile import compile_ast
    from .test_utils.tester import run_tests

    class Test(BaseImportRewrite):
        rewrites = [('test.test_old', 'test.test_new')]

    def Test_1():
        tests = compile_ast('import test.test_old')
        return Test.transform(tests).transformed

    def Test_2():
        tests = compile_ast('import test.test_old\n'
                            'import test.test_new\n')
        return Test.transform(tests).transformed

    def Test_3():
        tests = compile_ast('try:\n'
                            '    import test.test_old\n'
                            'except ImportError:\n'
                            '    import test.test_new')

# Generated at 2022-06-21 17:24:45.584727
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import pytest
    from typed_ast import ast3 as ast
    from ..utils.compiler import compile

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('functools', 'typing')]


# Generated at 2022-06-21 17:24:52.608822
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('textwrap', 'wrapt')]

    source = '''
    import textwrap
    '''

    tree = ast.parse(source)
    transformer = TestTransformer(tree)
    visitor = transformer.visit(tree)

    expected_source = '''
    import wrapt
    '''

    assert ast.dump(visitor) == ast.dump(ast.parse(expected_source))



# Generated at 2022-06-21 17:24:54.249777
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    tree = ast.parse('')
    cls = BaseNodeTransformer
    cls(tree)

# Generated at 2022-06-21 17:24:58.847673
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget()
        rewrites = [('six.moves', 'six')]

    node = ast.parse('import six.moves')
    result = TestTransformer.transform(node)
    assert isinstance(result.tree.body[0].body[0], ast.Try)



# Generated at 2022-06-21 17:25:06.223886
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..target import py3 as target

    class import_rewrite(BaseImportRewrite):
        rewrites = [('os', 'foo')]
        target = target

    import_source = astor.to_source(ast.parse('import os'))
    import_expected = astor.to_source(ast.parse('try:\n'
                                                '    import os\n'
                                                'except ImportError:\n'
                                                '    import foo'))

    import_from_source = astor.to_source(ast.parse('import os.path'))

# Generated at 2022-06-21 17:25:08.974401
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    file_name = "../ext/test_files/test.py"
    fp = open(file_name, "rb")
    code = fp.read()
    fp.close()
    tree = ast.parse(code)
    transformer = BaseNodeTransformer(tree)



# Generated at 2022-06-21 17:25:22.152070
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class myBase(BaseNodeTransformer):
        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            print(name)

    tree = ast.parse('import pickle')
    myBase(tree)

# Generated at 2022-06-21 17:25:22.922353
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.transform(None) == None


# Generated at 2022-06-21 17:25:27.962574
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformerTest(BaseNodeTransformer):
        def __init__(self, tree):
            super(BaseNodeTransformerTest, self).__init__(tree)

    ast_tree = ast.parse('pass')

    btt = BaseNodeTransformerTest(ast_tree)
    assert btt._tree == ast_tree



# Generated at 2022-06-21 17:25:32.082549
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    inst = BaseTransformer()
    assert inst.target == None
    assert BaseTransformer.target == None
    assert inst.transform is BaseTransformer.transform
    

# Generated at 2022-06-21 17:25:40.335372
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-21 17:25:41.775498
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-21 17:25:44.203068
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-21 17:25:48.307802
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    BaseTransformer.__abstractmethods__ = frozenset()
    BaseTransformer()

# Generated at 2022-06-21 17:25:52.402927
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('django.db', 'django.contrib.gis.db'),
        ]
        dependencies = ['django.contrib.gis.db']

    tree = ast.parse('''
    from django.db import models
    ''')

    result = Rewrite.transform(tree)
    assert result.changed
    assert isinstance(result.tree.body[0], ast.Try)
    assert result.dependencies == ['django.contrib.gis.db']

    tree = ast.parse('''
    import django.db
    ''')

    result = Rewrite.transform(tree)
    assert result.changed
    assert isinstance(result.tree.body[0], ast.Try)
    assert result.dependencies

# Generated at 2022-06-21 17:25:55.482352
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        pass

    t = TestNodeTransformer(None)

    assert isinstance(t, ast.NodeTransformer)
    assert isinstance(t, BaseNodeTransformer)
    assert isinstance(t, BaseTransformer)
    assert t.dependencies == []
    assert t.target is None


# Generated at 2022-06-21 17:26:18.431889
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('from six import metaclass')
    assert Transformer.transform(tree).tree == ast.parse(
        'try:\n'
        '    from six import metaclass\n'
        'except ImportError:\n'
        '    from six.moves import metaclass')
    tree = ast.parse('from six import (metaclass)')
    assert Transformer.transform(tree).tree == ast.parse(
        'try:\n'
        '    from six import (metaclass)\n'
        'except ImportError:\n'
        '    from six.moves import (metaclass)')

# Generated at 2022-06-21 17:26:19.241725
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None


# Generated at 2022-06-21 17:26:25.307395
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Rewriting of import
    class TestTransformer(BaseImportRewrite):
        rewrites = [('_six', 'six')]
        target = 'python2'

    node = ast.parse('import _six')
    result = TestTransformer.transform(node)
    expected = ast.parse('''
    try:
        import _six as six
    except ImportError:
        import six as six
    ''')

    assert(ast.dump(result.tree) == ast.dump(expected))

    # Visiting of unchanged import from
    node = ast.parse('import requests')
    result = TestTransformer.transform(node)
    expected = ast.parse('''
    import requests
    ''')

    assert(ast.dump(result.tree) == ast.dump(expected))



# Generated at 2022-06-21 17:26:36.496003
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..unittests.fixtures.commons import BaseImportRewrite as BaseImportRewriteTarget
    test_tree = ast.parse("from enum import IntEnum, unique, Enum as _Enum, Flag, IntFlag \n")
    test_instance = BaseImportRewriteTarget(test_tree)
    test_result = test_instance.visit(test_tree)
    assert(test_result[0].value.func.value.id == 'import_rewrite')
    assert(test_result[0].value.args[0].names[0].name == 'enum')
    assert(test_result[0].body[0].module == 'enum')


# Generated at 2022-06-21 17:26:42.743719
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformerTestClass(BaseTransformer):
        pass
    test_object = BaseTransformerTestClass()
    assert test_object, "Test 1 failed."
    assert test_object.target == None, "Test 2 failed."
    assert test_object.transform == None, "Test 3 failed."


# Generated at 2022-06-21 17:26:48.377553
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import ast_from_module
    from ..typing import CompilationTarget, TransformationResult
    from .tests.example_ast_matching import example_ast_matching_exp

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    exp_result = TransformationResult(
        ast_from_module(example_ast_matching_exp), True, [])
    result = TestTransformer.transform(
        ast_from_module(example_ast_matching_exp))

    assert result == exp_result

# Generated at 2022-06-21 17:26:58.959211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from ..types import CompilationTarget
    from ..utils.snippet import get_class
    import unittest

    class Transformer(BaseImportRewrite):
        target = CompilationTarget.PY34
        rewrites = [('abc', 'abc2')]

    class Test(unittest.TestCase):
        def test_visit_Import(self):
            transformer = Transformer(None)
            from_ = 'abc'
            to = 'abc2'
            node = ast.parse('import abc').body[0]
            actual = transformer._replace_import(node, from_, to)
            expected = ast.parse("""try:
    import abc
except ImportError:
    import abc2""").body[0]
            self.assertEqual(actual, expected)


# Generated at 2022-06-21 17:27:09.703255
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .. import types
    from ..parser import parse
    from ..transformer import BaseTransformer

    class MyTransformer(BaseNodeTransformer):
        rewrites = [
            ('django.conf.urls.url', 'django.urls.re_path'),
            ('django.conf.urls.i18n', 'django.conf.urls.i18n'),
            ('django.conf.urls.static', 'django.conf.urls.static'),
            ('django.conf.urls.include', 'django.urls.include'),
        ]


# Generated at 2022-06-21 17:27:14.380523
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("print(1+2)")
    bt = BaseNodeTransformer(tree)
    assert isinstance(bt, BaseNodeTransformer)



# Generated at 2022-06-21 17:27:18.886565
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    class ExampleNodeTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    result = ExampleNodeTransformer.transform(ast.parse('import old_module'))
    assert result.changed
    assert astunparse.unparse(result.tree) == """try:
    import old_module
except ImportError:
    import new_module"""



# Generated at 2022-06-21 17:27:51.694875
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from . import transformers as trans

    class Transform(trans.BaseImportRewrite):
        rewrites = [('abc', 'def')]

    tree = ast.parse('import abc')
    result = Transform.transform(tree)

    assert result.tree.body[0].body[0].value.names == [ast.alias(name='abc',
                                                                 asname=None)]

    assert result.tree.body[0].body[1].value.names == [ast.alias(name='def',
                                                                 asname=None)]

    assert isinstance(result.tree.body[0], ast.Expr)



# Generated at 2022-06-21 17:28:01.396627
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..parser.parser import parse

    import_node = ast.ImportFrom(module='six.moves',
                                 names=[ast.alias(name='queue')],
                                 level=0)
    import_node2 = ast.ImportFrom(module='six',
                                  names=[ast.alias(name='binary_type'),
                                         ast.alias(name='text_type')],
                                  level=0)
    import_node3 = ast.ImportFrom(module='typing',
                                  names=[ast.alias(name='Sequence')],
                                  level=0)

    import_rewrite_class = type(
        'ImportRewrite',
        (BaseImportRewrite,),
        {
            'target': '2.7',
            'rewrites': [('six.moves', 'six')]
        })



# Generated at 2022-06-21 17:28:08.434792
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
import os
""")
    class Rewrite(BaseImportRewrite):
        rewrites = [('os', 'sys')]
    
    res = Rewrite.transform(tree)
    assert res.changed is True
    assert ast.dump(res.tree) == """
Try(body=[
    Import(names=[alias(name='sys', asname=None)])],
    handlers=[],
    orelse=[],
    finalbody=[])
"""



# Generated at 2022-06-21 17:28:13.733849
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [
            ('unittest', 'unittest2')
        ]

    node = ast.parse(
        textwrap.dedent('''
            import unittest
        ''')
    )
    result = Test.transform(node)
    expected = ast.parse(
        textwrap.dedent('''
            try:
                import unittest
            except ImportError:
                import unittest2 as unittest
        ''')
    )
    assert result.tree == expected



# Generated at 2022-06-21 17:28:16.820514
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Foo(BaseImportRewrite):
        rewrites = []  # type: List[Tuple[str, str]]

    return Foo

# Generated at 2022-06-21 17:28:18.021572
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None



# Generated at 2022-06-21 17:28:29.845754
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    target = CompilationTarget(python_version=(3, 7))

    class MockedTransformer(BaseImportRewrite):
        target = target
        rewrites = [('typing', 'typed_ast')]

    original = 'import typing'
    tree = ast.parse(original)
    transformed = MockedTransformer.transform(tree).tree

    assert transformed is not None

# Generated at 2022-06-21 17:28:36.653551
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    original = ast.parse(
        "import six\n"
        "import six.abc")

    expected = ast.parse(
        "try:\n"
        "    import six\n"
        "except ImportError:\n"
        "    import six.moves as six")

    transformed = TestTransformer.transform(original)

    assert astunparse.unparse(expected) == astunparse.unparse(transformed.ast)



# Generated at 2022-06-21 17:28:44.925109
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.snippet import snippet
    transformer = BaseImportRewrite()
    node = ast.parse(snippet('''
import test
from test.config import config
from test import config
from test.config.config import config
from test.config.config import config, config2
'''))
    transformer.visit(node)
    print(ast.dump(node))


# Generated at 2022-06-21 17:28:48.031321
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__dict__.get("transform") is not None
    assert BaseImportRewrite.__dict__.get("visit_Import") is not None
    assert BaseImportRewrite.__dict__.get("visit_ImportFrom") is not None

# Generated at 2022-06-21 17:29:59.957579
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import sys
    from .asserts import assert_code_equal
    from ..utils.ast import parse_ast

    transforms = []
    transforms.append(BaseImportRewrite.transform(parse_ast('import foo')))
    transforms.append(BaseImportRewrite.transform(parse_ast('from foo import bar')))
    transforms.append(BaseImportRewrite.transform(parse_ast('from foo import bar, baz')))
    transforms.append(BaseImportRewrite.transform(parse_ast('from foo import *')))
    transforms.append(BaseImportRewrite.transform(parse_ast('from foo.bar import baz')))
    transforms.append(BaseImportRewrite.transform(parse_ast('from foo.bar import baz as buzz')))

# Generated at 2022-06-21 17:30:09.887034
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrite = BaseImportRewrite
    rewrite.rewrites = [('from', 'fom'), ('name', 'newname')]
    visitor = rewrite(None)

    line = ast.ImportFrom(module='from',
                          names=[ast.alias(name='name',
                                           asname=None)],
                          level=0)

# Generated at 2022-06-21 17:30:17.938593
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)

    import astor
    class MyTree(ast.AST):
        _fields = ['one', 'two', 'three']

    tree = MyTree(one=1, two=2, three=3)
    tr = MyTransformer(tree)
    assert tr._tree is tree
    assert tr._tree_changed is False

# Generated at 2022-06-21 17:30:19.691808
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()
    assert True

# Generated at 2022-06-21 17:30:22.617712
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite
    # TODO: Test for __init__ method


# Generated at 2022-06-21 17:30:25.154910
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    a = BaseImportRewrite()


test_BaseImportRewrite()

# Generated at 2022-06-21 17:30:27.340635
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..core.conversions import convert_ast


# Generated at 2022-06-21 17:30:38.549735
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast, astor
    code = """
from a.b import c
from a.b import d, e
    """
    tree = ast.parse(code)
    BaseImportRewrite.rewrites = [('a.b', 'x.y')]
    BaseImportRewrite.transform(tree)
    code = astor.to_source(tree).strip()
    assert code == """
try:
    from a.b import c
except ImportError:
    from x.y import c
try:
    from a.b import d, e
except ImportError:
    from x.y import d, e
    """

# Generated at 2022-06-21 17:30:49.436168
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():

    @snippet
    def expected_transformer():
        class BaseTransformer(metaclass=ABCMeta):
            target = None  # type: CompilationTarget

            @classmethod
            @abstractmethod
            def transform(cls, tree: ast.AST) -> TransformationResult:
                ...

    assert BaseTransformer.__doc__ == expected_transformer.__doc__

    import inspect
    import textwrap

    expected = textwrap.dedent("""\
    BaseTransformer(builtins.object)
        BaseTransformer(metaclass=_ast3.ABCMeta)
    
    """)
    assert inspect.getdoc(BaseTransformer) == expected



# Generated at 2022-06-21 17:30:50.583689
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'

# Generated at 2022-06-21 17:33:02.907577
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('collections.abc', 'collections')]

    tree = ast.parse('import collections.abc')

    Test.transform(tree)
    assert str(tree) == """
import_rewrite(previous=ast.Import(names=[ast.alias(name='collections.abc',
                                                    asname=None)]),
                current=ast.Import(names=[ast.alias(name='collections',
                                                    asname='abc')]))
    """



# Generated at 2022-06-21 17:33:05.898972
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert (BaseImportRewrite.__init__)
    assert (BaseImportRewrite.__init__)

# Generated at 2022-06-21 17:33:08.158477
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__(BaseImportRewrite, None) is None
    return

# Generated at 2022-06-21 17:33:10.057890
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    print("BaseNodeTransformer")
    x = BaseNodeTransformer._tree_changed
    y = BaseNodeTransformer.dependencies

# Generated at 2022-06-21 17:33:13.477287
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'
    assert BaseImportRewrite.target is None


# Generated at 2022-06-21 17:33:14.908908
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()



# Generated at 2022-06-21 17:33:17.146993
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__init__.__annotations__ == {}


# Generated at 2022-06-21 17:33:20.394454
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('def foo(): pass')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False


# Generated at 2022-06-21 17:33:21.177307
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-21 17:33:25.613413
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    obj = BaseNodeTransformer(ast.Constant(value=123))
    assert type(obj) == BaseNodeTransformer
    assert obj._tree.value == 123
    assert obj._tree_changed == False