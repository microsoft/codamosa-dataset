

# Generated at 2022-06-21 17:24:34.166179
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ast import AST
    from ..types import CompilationTarget
    from ..utils.snippet import BaseSnippet
    from .transformers import BaseNodeTransformer
    from ..utils.ast_tools import get_or_create_arguments
    from typing import List, Dict, Optional, Union, Tuple, Type
    from typed_ast.ast3 import AST as AST
    from .transformers import BaseTransformer, BaseNodeTransformer
    from ..types import CompilationTarget, TransformationResult
    from ..utils.snippet import BaseSnippet
    from ..utils.snippet import snippet
    from ..utils.ast_tools import get_or_create_arguments
    class BaseNodeTransformerTest(BaseNodeTransformer):
        def __init__(self, tree: AST) -> None:
            super().__init__(tree)


# Generated at 2022-06-21 17:24:40.437842
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class Dummy(BaseImportRewrite):
        target = 'python'
        rewrites = [('six', 'six.moves')]

    tree = ast.parse("import six.moves")
    expected = ast.parse("""
try:
    import six
except ImportError:
    import six.moves
    """)
    assert Dummy.transform(tree).tree == expected



# Generated at 2022-06-21 17:24:42.430214
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    a = BaseImportRewrite()
    assert isinstance(a, BaseNodeTransformer)
    assert isinstance(a, BaseTransformer)


# Generated at 2022-06-21 17:24:44.712829
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class test_m(BaseNodeTransformer):
        def visit_Import(self, node):
            return node
    a = ast.parse('import x')
    b = ast.parse('import y')
    test_m.transform(a,b)

# Generated at 2022-06-21 17:24:53.216222
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from dataclasses import dataclass
    import inspect

    global BaseTransformer

    @dataclass
    class TestBaseTransformer(BaseTransformer):
        target: CompilationTarget

    assert BaseTransformer.target is None
    assert TestBaseTransformer.target == CompilationTarget.CPYTHON_36
    assert not hasattr(BaseTransformer, 'transform')
    assert inspect.isfunction(TestBaseTransformer.transform)
    assert TestBaseTransformer.transform.__module__ == __name__


# Generated at 2022-06-21 17:24:54.152313
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__

# Generated at 2022-06-21 17:25:02.806966
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transformer = BaseImportRewrite()
    from_ = 'a'
    to = 'b'
    transformer.rewrites = [(from_, to)]
    import_from_1 = ast.ImportFrom(module=from_,
                                   names=[ast.alias(name='X')],
                                   level=0)
    import_from_2 = ast.ImportFrom(module=from_ + '.x',
                                   names=[ast.alias(name='Y')],
                                   level=0)
    import_from_3 = ast.ImportFrom(module='y',
                                   names=[ast.alias(name=from_)],
                                   level=0)
    import_from_4 = ast.ImportFrom(module='y',
                                   names=[ast.alias(name='x.y')],
                                   level=0)


# Generated at 2022-06-21 17:25:04.396802
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert isinstance(transformer, BaseTransformer)
    assert transformer.target is None



# Generated at 2022-06-21 17:25:11.464434
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert BaseImportRewrite.visit_Import(ast.Import(names=[
        ast.alias(name='something',
                  asname='alias')])) == ast.Import(names=[
        ast.alias(name='something',
                  asname='alias')])


# Generated at 2022-06-21 17:25:18.941427
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('urlparse', 'urllib.parse')]

    tree = ast.parse("""
import urlparse
from urlparse import parse_qs, ParseResult
from urllib.parse import parse_qs
from urllib import parse_qs
import urllib.parse as up2
from urllib.parse import parse_qs as pq2
from urllib.parse import parse_qs as pq3, ParseResult
from urlparse import parse_qs, ParseResult as PR
""")

    result = TestImportRewrite.transform(tree)

# Generated at 2022-06-21 17:25:31.123790
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from_ = 'from_'
    to = 'to'
    class Transformer(BaseImportRewrite):
        rewrites = [(from_, to)]

    tree = ast.parse('import from_ as f')
    transformed = Transformer.transform(tree)
    assert transformed.tree == ast.parse('import to as f')

# Generated at 2022-06-21 17:25:33.122825
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class _(BaseImportRewrite):
        rewrites = [('a', 'b')]
    _


# Generated at 2022-06-21 17:25:34.774636
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-21 17:25:35.569241
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer
    assert transformer

# Generated at 2022-06-21 17:25:39.181966
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target
    assert BaseTransformer().transform(BaseTransformer.target) == TransformationResult(BaseTransformer.target, False, [])


# Generated at 2022-06-21 17:25:39.898380
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-21 17:25:43.766485
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    instance = BaseTransformer()
    assert isinstance(instance, BaseTransformer)


# Generated at 2022-06-21 17:25:48.684520
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import a\nimport b')
    transformer = BaseNodeTransformer(tree)  # type: ignore
    assert transformer._tree_changed is False
    assert transformer._tree is tree


# Generated at 2022-06-21 17:25:59.825784
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    input_code = """
import typing.io
import typing.io as tio
from typing import io
from typing import io as tio
import typing as t
from typing import *
from typing import Dict
from typing import Dict as tdict
from typing import List
from typing import List as tlist
"""

# Generated at 2022-06-21 17:26:03.824130
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class NodeTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            return node
    tree = ast.parse("x")
    NodeTransformer(tree)



# Generated at 2022-06-21 17:26:22.945013
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ast import dump

    class TestClass(BaseImportRewrite):
        ast.NodeTransformer.__init__(self, tree)
        rewrites = [('.old', '.new')]

    test_import_statement = """
from old.module import old_name, old.module.old_name as renamed_old, asname1
"""
    tree = ast.parse(test_import_statement)

    TestClass.visit(tree)

    rewrote_import = """
try:
    from old.module import old_name, old.module.old_name as renamed_old, asname1
except ImportError:
    from new.module import new_name, new.module.new_name as renamed_old, asname1
"""
    assert dump(tree) == ast.dump(ast.parse(rewrote_import))




# Generated at 2022-06-21 17:26:26.574598
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class ModuleTransformer(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib')]

    node = ast.parse('import urllib.request')
    tree = ModuleTransformer.transform(node)
    assert tree.changed is True
    assert str(tree.tree) == """
    import urllib.request as __original__ # type: ignore
    try:
        import urllib.request
    except ImportError:
        import urllib"""



# Generated at 2022-06-21 17:26:28.038280
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer # type: ignore

# Generated at 2022-06-21 17:26:34.041977
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .. import rewriter as rewrite
    from ..rewriter import (
        BaseImportRewrite,
        BaseNodeTransformer
    )
    assert isinstance(BaseImportRewrite, BaseNodeTransformer)
    assert isinstance(BaseImportRewrite, rewrite.BaseImportRewrite)

# Generated at 2022-06-21 17:26:34.835037
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    obj = BaseImportRewrite()


# Generated at 2022-06-21 17:26:47.461768
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    class TestRewrite(BaseImportRewrite):
        rewrites = [('sys', 'my_sys')]

        def __init__(self, tree: ast.Module) -> None:
            self._tree = tree
            self._tree_changed = False

        def visit(self, node: ast.AST) -> ast.AST:
            return super().visit(node)

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.cb = self._cb

        def _cb(self, node: ast.AST, child: ast.AST) -> None:
            pass

        def visit(self, node: ast.AST) -> None:
            self.cb(node, node)
            self.generic_visit(node)


# Generated at 2022-06-21 17:26:49.608055
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget('2.7')
    assert BaseTransformer.target is None
    assert BaseTransformer.target != target
    assert BaseTransformer.transform('') is None


# Generated at 2022-06-21 17:26:52.614432
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("5 + 3")
    transormer = BaseNodeTransformer(tree)
    assert (transormer._tree is tree)
    assert not transormer._tree_changed


# Generated at 2022-06-21 17:26:53.617911
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target is None


# Generated at 2022-06-21 17:27:04.287807
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    from .py_to_py3 import Py3ImportRewrite
    replace = Py3ImportRewrite.rewrites
    for t in (
        (ast.Import, replace),
        (ast.ImportFrom, replace),
    ):
        class TypeC(BaseImportRewrite):
            rewrites = t[1]

        class Type(t[0]):
            def __init__(self, value):
                self.value = value

        select = Type('abc'.value)
        instance = TypeC._transform(select)
        print(astor.dump(instance))

# Generated at 2022-06-21 17:27:54.603146
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from tests.compiler.test_BaseImportRewrite import BaseImportRewriteTest
    BaseImportRewriteTest()

if __name__ == '__main__':
    test_BaseImportRewrite()

# Generated at 2022-06-21 17:27:55.410456
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:28:01.446485
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from tests.transformers.utils import node_to_str

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        target = CompilationTarget.PYTHON35

    tree = ast.parse(
        'import foo\n'
    )  # type: ast.Module
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)

    assert (node_to_str(result) ==
            '''
try:
    import foo
except ImportError:
    import bar
''')



# Generated at 2022-06-21 17:28:02.456511
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, BaseTransformer)


# Generated at 2022-06-21 17:28:07.019729
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse("from datetime import (  \n"
                     "    date)\n")
    BaseImportRewrite().visit(node)
    assert ast.dump(node) == ("Try(body=[ImportFrom(module='datetime', "
                              "names=[alias(name='date', asname=None)], "
                              "level=0), ImportFrom(module='arrow', "
                              "names=[alias(name='date', asname=None)], "
                              "level=0)], "
                              "handlers=[ExceptHandler(type=None, "
                              "name=None, body=[Pass()])], "
                              "orelse=[], finalbody=[])")

# Generated at 2022-06-21 17:28:14.207756
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astpretty import pprint as print

    class TestTransformer(BaseImportRewrite):
        rewrites = [(('old', 'new'))]

    code = 'import old'

    result = TestTransformer.transform(ast.parse(code))
    print(result.tree)

    assert result.tree_changed is True



# Generated at 2022-06-21 17:28:21.375925
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import asttokens

    source = '''
from typing import Callable, Optional, Tuple, Union

from test_utils import mocking
from test_utils.assertions import assert_equal
from test_utils.mocking import B, expected_exception
from test_utils.mocking import ANY_ARG
from test_utils.mocking import mock_call_order
'''

    atok = asttokens.ASTTokens(source, parse=True)
    tree = atok.tree


# Generated at 2022-06-21 17:28:31.863484
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from0 = ast.ImportFrom(
        module='a.b.c.d',
        names=[ast.alias(name='e',
                         asname='f')],
        level=0
    )
    import_from1 = ast.ImportFrom(
        module='a.b.c.d',
        names=[ast.alias(name='e.y',
                         asname='f')],
        level=0
    )
    import_from2 = ast.ImportFrom(
        module='a.b',
        names=[ast.alias(name='a.b.e',
                         asname='f')],
        level=0
    )

# Generated at 2022-06-21 17:28:36.413854
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class MyTransformer():
        target = None
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    assert issubclass(MyTransformer, BaseTransformer)


# Generated at 2022-06-21 17:28:48.606582
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    from ..utils import run_transformer
    import ast
    import os
    import sys

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.python_library

        rewrites = [
            ('a.b', 'x.y'),
        ]

    source = """
from a.b import c
from a.b import d as e
from a.b import *
from a.c import f, x as y
from x.y import z
    """

    class TestModule(ast.NodeVisitor):
        def __init__(self) -> None:
            super().__init__()
            self.names = set()  # type: Set[str]


# Generated at 2022-06-21 17:29:49.722690
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astor import dump_tree

    class OTO(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_ = ast.Import(names=[ast.alias(name='foo')])
    assert dump_tree(import_) == 'import foo'

    tr = OTO.transform(import_)
    assert dump_tree(tr.tree) == '''try:
    import foo
except ImportError:
    import bar'''



# Generated at 2022-06-21 17:29:54.483213
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    with pytest.raises(NotImplementedError):
        BaseTransformer.transform(None)  


# Generated at 2022-06-21 17:29:57.089765
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Foo(BaseTransformer):
        pass
    foo = Foo()
    assert isinstance(foo.target, CompilationTarget)

# Generated at 2022-06-21 17:30:08.048490
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .coverage import BaseCoverageTransformer

    class TestTransformer(BaseImportRewrite):
        rewrites = [('')]

    class TestTransformer2(BaseCoverageTransformer):
        pass

    base_import_rewrite = TestTransformer()
    test_transformer2 = TestTransformer2()

# Generated at 2022-06-21 17:30:11.232619
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    new_BaseTransformer=BaseTransformer()


# test for constructor of class BaseNodeTransformer

# Generated at 2022-06-21 17:30:12.972885
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.transform == NotImplemented


# Generated at 2022-06-21 17:30:21.085596
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    tree = ast.parse('''
from sm import foo, bar
from sm import *
from sm2.a import foo
from sm.b import bar
from sm.b import *
from sm.c import bar as baz
from sm.d import foo as bar
from sm.d import bar as foo
from sm.d import *
'''.strip())

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('sm', 'spam'),
            ('sm2.a', 'spam2.b'),
            ('sm.b', 'spam.c'),
            ('sm.c', 'spam.d'),
            ('sm.d', 'spam.e'),
        ]

    result = TestTransformer.transform(tree)
    # print(astunparse.unparse(result

# Generated at 2022-06-21 17:30:24.190466
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
  try:
    BaseNodeTransformer(ast.AST())
  except TypeError:
    raise AssertionError()


# Generated at 2022-06-21 17:30:26.198232
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    baseNodeTransformer = BaseNodeTransformer

# Generated at 2022-06-21 17:30:30.358007
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        def visit_ImportFrom(self, node):
            pass

    import astor

    tree = ast.parse('''
from bs4 import BeautifulSoup
from typing import List
    ''')
    tree_changed = TestNodeTransformer.transform(tree).changed
    assert not tree_changed
    assert astor.to_source(tree) == '''
from bs4 import BeautifulSoup
from typing import List
    '''



# Generated at 2022-06-21 17:32:32.093609
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class_ = type(
        'Test',
        (BaseImportRewrite,),
        {'rewrites': [
            ('othermodule.sub', 'sub')
        ]})

    importnode = ast.Import(names=[
        ast.alias(name='othermodule.sub',
                  asname='sub')])
    trynode = class_.visit_Import(importnode)
    assert trynode.body[0].body[0].names[0].name == 'sub'

    importnode = ast.Import(names=[
        ast.alias(name='othermodule',
                  asname='othermodule')])
    trynode = class_.visit_Import(importnode)
    assert isinstance(trynode, ast.Import)



# Generated at 2022-06-21 17:32:43.423915
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'foo'
    to = 'bar'
    import_fixture1 = 'from foo import foo'
    import_fixture2 = 'from foo import bar'
    import_fixture3 = 'from foo.fuz import foo'
    import_fixture4 = 'from bar import bar'
    import_result1 = "from bar import foo"
    import_result2 = "from bar import bar"
    import_result3 = "from foo.fuz import foo"
    import_result4 = "from bar import bar"

    import_fixt = ast.parse(import_fixture1)
    import_tree = ast.parse(import_fixture1)
    import_rewrite_tree = ast.parse(import_result1)

    class ImportTestCase(BaseImportRewrite):
        dependencies = []
        re

# Generated at 2022-06-21 17:32:46.913912
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..transformer import BaseTransformer

    assert isinstance(BaseTransformer.transform, classmethod)

# Generated at 2022-06-21 17:32:54.377360
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    def actual_tree(rewrite: List[Tuple[str, str]]) -> ast.AST:
        """Actual result tree"""

        @BaseImportRewrite.bind(rewrites=rewrite)
        class Visitor(BaseImportRewrite):
            pass
        return Visitor.transform(tree).tree

    # module_name is not in rewrites
    # Result: unchanged tree
    module = ast.Module(body=[
        ast.Import(names=[
            ast.alias(name='os', asname=None)])])

    tree = ast.fix_missing_locations(module)

    assert ast.dump(actual_tree(rewrites=[
        ('foo', 'bar'),
        ('spam', 'ham')])) == ast.dump(tree)

    # module_name is in rewrites and doesn't have alias


# Generated at 2022-06-21 17:32:58.539158
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        target = 'foo'

    assert A.target == 'foo'
    assert A.target.startswith('foo')



# Generated at 2022-06-21 17:33:01.656494
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class FakeImportRewrite(BaseImportRewrite):
        dependencies = []
        rewrites = []

    f = FakeImportRewrite(ast.parse(''))
    assert f.dependencies == []

# Generated at 2022-06-21 17:33:12.045431
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import parse
    from ..utils.snippet import py_ast_to_src

    class TestTransformer(BaseImportRewrite):
        target = 'python35'
        rewrites = [('os', 'os_mock')]


# Generated at 2022-06-21 17:33:23.175607
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites_list = ['typing']

    class TestClass(BaseImportRewrite):
        rewrites = [(rewrites_list[0], 'typing.py')]

    import_statement = ast.Import(names=[
        ast.alias(name=rewrites_list[0],
                  asname='typing_')])

    import_with_try = TestClass.transform(import_statement).tree

    assert isinstance(import_with_try, ast.Try)
    assert len(import_with_try.body) == 1

    [try_import] = import_with_try.body
    assert isinstance(try_import, ast.Import)
    assert try_import.names[0].name == 'typing.py'
    assert try_import.names[0].asname == 'typing_'

   

# Generated at 2022-06-21 17:33:23.594376
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-21 17:33:33.565866
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse

    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.parse('import foo')
    assert unparse(node) == "import foo"
    Transformer.transform(node)
    assert unparse(node) == ("try:\n    import foo\n"
                             "except ImportError:\n    import bar")

    node = ast.parse('import foo.bar')
    assert unparse(node) == "import foo.bar"
    Transformer.transform(node)
    assert unparse(node) == ("try:\n    import foo.bar\n"
                             "except ImportError:\n    import bar.bar")

    node = ast.parse('import foo.bar.baz')