

# Generated at 2022-06-21 17:24:11.903238
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class MyBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    # Check if import is changed
    test_tree = ast.parse('import foo')
    MyBaseImportRewrite.transform(test_tree)
    expected_tree = ast.parse('try:\n\timport foo\nexcept ImportError:\n\timport bar')
    assert ast.dump(test_tree) == ast.dump(expected_tree)

    # Check if import is not changed
    test_tree = ast.parse('import baz')
    MyBaseImportRewrite.transform(test_tree)
    assert ast.dump(test_tree) == ast.dump(expected_tree)

    # Check if import is not changed: foo is part of module name

# Generated at 2022-06-21 17:24:19.777090
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    expected = ast.parse(textwrap.dedent('''\
    try:
        import os as _os
    except ImportError:
        import test.os as _os
    
    try:
        from os import path as _path
    except ImportError:
        from test.os import path as _path
    ''')).body
    import_from = ast.parse(textwrap.dedent('''\
    from os import path
    ''')).body[0]
    import_from2 = ast.parse(textwrap.dedent('''\
    from os import path as pat
    ''')).body[0]
    import_from3 = ast.parse(textwrap.dedent('''\
    from os import *
    ''')).body[0]


# Generated at 2022-06-21 17:24:22.177645
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    transformer.target = CompilationTarget('test')
    try:
        transformer.transform(ast.Pass())
    except NotImplementedError:
        pass


# Generated at 2022-06-21 17:24:34.170791
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    ast_node = ast.parse("from types import MappingProxyType")
    assert BaseImportRewrite.transform(ast_node).changed == False
    ast_node = ast.parse("from six.moves import urllib")
    assert BaseImportRewrite.transform(ast_node).changed == False
    ast_node = ast.parse("from six.moves import urllib as url")
    assert BaseImportRewrite.transform(ast_node).changed == False
    ast_node = ast.parse("from six.moves import urllib, zip")
    assert BaseImportRewrite.transform(ast_node).changed == False
    ast_node = ast.parse("from six.moves import json as json_m, zip")
    assert BaseImportRewrite.transform(ast_node).changed == False
    ast_node = ast.parse

# Generated at 2022-06-21 17:24:36.575343
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()

# Generated at 2022-06-21 17:24:39.542096
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    names_to_replace = dict(self._get_names_to_replace(self))
    if names_to_replace:
        return self._replace_import_from_names(self, names_to_replace)

# Generated at 2022-06-21 17:24:42.940666
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)
            self._tree_changed = False

    tree = ast.parse('a = 1')

    assert isinstance(Test(tree), Test)

# Generated at 2022-06-21 17:24:49.321139
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor # type: ignore
    source = """
import a.b
import a.b.c as d
from a.b import c, d
from a.b import e as f
from a.b import g
"""
    tree = ast.parse(source)
    BaseImportRewrite.rewrites = [
        ('a.b', 'rewrite.a.b')
    ]
    BaseImportRewrite.transform(tree)
    actual = astor.to_source(tree)

# Generated at 2022-06-21 17:24:57.069107
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class FakeNodeTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    visitor = FakeNodeTransformer(None)
    import_node = ast.parse('import old').body[0]
    try_node = visitor.visit_Import(import_node)

    assert isinstance(try_node, ast.Try)
    assert try_node.body[0] == ast.parse('import old').body[0]
    assert try_node.handlers[0].type.name == 'ImportError'
    assert try_node.handlers[0].body[0] == ast.parse('import new').body[0]



# Generated at 2022-06-21 17:25:00.897216
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class ATestTransformer(BaseTransformer):
        target = None

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    assert isinstance(ATestTransformer(), BaseTransformer) is False


# Generated at 2022-06-21 17:25:11.658901
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    try:
        BaseImportRewrite('tree')
    except Exception as e:
        print("Error: " + str(e))
        raise e



# Generated at 2022-06-21 17:25:18.850073
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class SomeClass(BaseImportRewrite):
        rewrites = [('oldmod', 'newmod')]

    result = SomeClass.transform(ast.Module(body=[ast.Import(names=[ast.alias(name='oldmod', asname='foo')])]))
    expected = ast.Module(body=[ast.Try(body=[ast.Import(names=[ast.alias(name='newmod', asname='foo')])],
                                        handlers=[ast.ExceptHandler(type=None, name=None, body=[
                                            ast.Import(names=[ast.alias(name='oldmod', asname='foo')])])],
                                        orelse=[],
                                        finalbody=[])])
    assert ast.dump(result.tree) == ast.dump(expected)

# Generated at 2022-06-21 17:25:28.257099
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a')
    inst = BaseNodeTransformer.__new__(BaseNodeTransformer)
    inst.__init__(tree)
    assert inst._tree == tree
    assert inst._tree_changed == False
    # check compilation of source code into AST
    tree = ast.parse('a')
    inst = BaseNodeTransformer(tree)
    assert inst._tree == tree
    assert inst._tree_changed == False
    # check compilation of source code into AST
    inst = BaseNodeTransformer('a')
    assert inst._tree == tree
    assert inst._tree_changed == False


# Generated at 2022-06-21 17:25:28.769994
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-21 17:25:36.553422
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass(BaseImportRewrite):
        rewrites = [('a', 'b'), ('x', 'y')]

    node = ast.Import(names=[ast.alias('a', 'b')])
    rewrote = ast.Try(
        body=[ast.Import(names=[ast.alias('b', 'b')])],
        handlers=[
            ast.ExceptHandler(
                type=None,
                name=None,
                body=[
                    ast.Import(names=[ast.alias('a', 'b')]),
                ],
                lineno=None,
                col_offset=None)
        ],
        orelse=[],
        finalbody=[])
    assert TestClass(None).visit_Import(node) == rewrote



# Generated at 2022-06-21 17:25:41.077807
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils import ast_to_code

    import_ = ast.ImportFrom(module='django.db.models',
                             names=[ast.alias(name='Model', asname='Model')])

# Generated at 2022-06-21 17:25:47.541967
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('queue', 'multiprocessing.Queue')]

    class TestBaseImportRewrite2(BaseImportRewrite):
        rewrites = []

    assert TestBaseImportRewrite()._get_matched_rewrite('queue') == ('queue', 'multiprocessing.Queue')
    assert TestBaseImportRewrite()._get_matched_rewrite('queue.PriorityQueue') == ('queue', 'multiprocessing.Queue')
    assert TestBaseImportRewrite()._get_matched_rewrite('foobar') is None

    assert TestBaseImportRewrite2()._get_matched_rewrite('queue') is None
    assert TestBaseImportRewrite2()._get_matched_rewrite('queue.PriorityQueue') is None
    assert TestBaseImport

# Generated at 2022-06-21 17:25:58.729863
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyTransformer(BaseImportRewrite):
        target = 'my_target'
        rewrites = [('rewritten', 'new')]

    tree = ast.parse("""
    import rewritten
    
    def fun():
        pass
    """,
                     type_comments=False)

    result = MyTransformer.transform(tree)

    assert result.tree.body[0].body[0].lineno == 2
    assert result.tree.body[0].body[0].col_offset == 4
    assert result.tree.body[1].lineno == 4
    assert result.tree.body[1].col_offset == 0
    assert result.changed is True
    assert result.dependencies == ['rewritten']



# Generated at 2022-06-21 17:25:59.215357
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-21 17:26:09.266073
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import get_ast
    tree = get_ast('import foo')
    result = BaseImportRewrite(tree).visit_Import(tree.body[0])
    
    assert isinstance(result, ast.Try)
    assert result.body[0].value.names[0].name == 'foo'
    assert result.body[0].value.names[0].asname is None
    assert result.handlers[0].name == 'ImportError'
    assert result.handlers[0].body[0].value.names[0].name == 'foo'
    assert result.handlers[0].body[0].value.names[0].asname is None
    assert result.handlers[0].body[0].value.names[0].name == 'foo'
    assert result.handlers[0].body[0].value

# Generated at 2022-06-21 17:26:16.810090
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    node = ast.parse('print("hello")', mode='exec')
    tree = BaseNodeTransformer(node)

# Generated at 2022-06-21 17:26:27.537979
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import testing

    from jinja2 import Template

    # First we define rewrite from old module to new one
    from_ = 'module'
    to = 'another_module'
    rewrites = [(from_, to)]

    # Then we define program, where we will do the rewrite
    program = Template("""
    from {{ from_ }} import name
    import {{ from_ }}.function
    from {{ from_ }} import *
    """).render(from_=from_)

    # We need context to import modules
    context = testing.context
    context.update(from_=from_, to=to)

    # Now we can instantiate the class
    t = testing.get_class(BaseImportRewrite, rewrites=rewrites)
    # And transform

# Generated at 2022-06-21 17:26:33.527092
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    print('unit test for BaseImportRewrite')
    transformer = BaseImportRewrite()
    assert transformer.__class__.__name__ == 'BaseImportRewrite'
    assert transformer.__doc__ == snippet.BaseImportRewrite.__doc__


# Generated at 2022-06-21 17:26:36.496520
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..main import Transformer
    import inspect

    assert 'object' in inspect.getmro(BaseTransformer)
    assert BaseTransformer.transform('hello') is None
    assert issubclass(BaseTransformer, Transformer)

# Generated at 2022-06-21 17:26:45.223764
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class R(BaseImportRewrite):
        rewrites = [('foo1', 'bar1'),
                    ('foo2', 'bar2')]
    tree = ast.parse('''
import foo1
from foo1 import x
from foo1 import x as y
from foo1 import *
import foo2
from foo2 import x
from foo2 import x as y
from foo2 import *
import foo3
from foo3 import x
from foo3 import x as y
from foo3 import *
    ''')
    t = R.transform(tree)

# Generated at 2022-06-21 17:26:47.781952
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'


# Generated at 2022-06-21 17:26:55.151924
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # 1. Test for * import
    # import * from {module}
    import_from_star = ast.ImportFrom(
        module='models',
        names=[ast.alias(name='*',
                         asname=None)],
        level=0)
    # 2. Test for import with alias
    # import {name} from {module} as {alias}
    import_from_alias = ast.ImportFrom(
        module='models.fields',
        names=[ast.alias(name='CharField',
                         asname='Char')],
        level=0)
    # 3. Test for import without alias
    # import {name} from {module}

# Generated at 2022-06-21 17:26:59.817107
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    import typed_astunparse

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestBaseImportRewrite_visit_ImportFrom(unittest.TestCase):
        def test_simple_rewrite_name(self):
            input = 'from foo import foo'
            node = ast.parse(input)
            output = typed_astunparse.unparse(TestBaseImportRewrite.transform(node).tree)
            self.assertEqual(output, 'try:\n    import foo\nexcept ImportError:\n    import bar\n')

        def test_rewrite_name_with_module(self):
            input = 'from foo.foo import foo'
            node = ast.parse(input)
            output = typed_astunparse

# Generated at 2022-06-21 17:27:07.256689
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils import build_tree
    from .. import transformer

    class TestTransformer(BaseNodeTransformer):
        rewrites = []

        def visit_Name(self, node):
            return ast.Name(id='changed', ctx=node.ctx)


    tree = build_tree("a=0")
    new_tree, changed, dependencies = transformer.transform(tree, TestTransformer)
    assert changed
    assert new_tree is not tree
    assert dependencies == TestTransformer.dependencies
    assert new_tree.body[0].value.id == 'changed'

# Generated at 2022-06-21 17:27:18.706058
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MockTransformer(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    code = "from six.moves import filter"
    node = ast.parse(code)

    result = MockTransformer.transform(node)

    assert result.changed
    assert result.code == dedent('''\
        try:
            from six.moves import filter
        except (ImportError):
            from six import filter
        
        ''')

    code = "from six.moves import filter, map"
    node = ast.parse(code)

    result = MockTransformer.transform(node)

    assert result.changed

# Generated at 2022-06-21 17:27:36.570773
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # def __init__(self, tree: ast.AST) -> None:
    tree = ast.parse('def f(): pass')
    inst = BaseImportRewrite(tree)
    assert isinstance(inst._tree, ast.Module)
    assert not inst._tree_changed
    assert inst.rewrites == []
    assert inst.dependencies == []


# Generated at 2022-06-21 17:27:37.339243
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-21 17:27:46.274857
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse
    class TestTansformer(BaseImportRewrite):
        rewrites = [('os', 'posix')]
    tree = ast.parse('import os')
    tree = TestTansformer.transform(tree).tree
    assert unparse(tree) == 'try:\n    from posix import os\nexcept ImportError:\n    import os'


# Generated at 2022-06-21 17:27:56.179283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from io import StringIO
    import ast
    import typing_c3 as c3
    import_ast = ast.parse("import asyncio\n")
    import_ast_rewrite = c3.BaseImportRewrite(import_ast) # type: ignore
    import_ast_rewrite.visit(import_ast)
    assert str(import_ast) == """# generated by typing_c3.transformers.base
try:
    import trollius as asyncio
except ImportError:
    import asyncio"""


# Generated at 2022-06-21 17:28:02.721788
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'test'
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass
    assert TestTransformer.target == 'test'
    t = TestTransformer()
    assert t.target == 'test'


# Generated at 2022-06-21 17:28:12.069202
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget
    from .test_utils import assert_node_equal
    from .test_utils import patch_ast, patch_ast_for_backends

    patch_ast()
    patch_ast_for_backends()

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('abc', 'xyz')
        ]

        target = CompilationTarget.JAVA_SCRIPT

    assert_node_equal(TestImportRewrite().visit(ast.parse('import foo')),
                      ast.parse('try: import foo\n'
                                'except ImportError: import bar'))


# Generated at 2022-06-21 17:28:21.880946
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('urllib', 'urllib.request'),
        ]

    test_module = '''
from urllib import urlopen
from urllib import parse
import urllib

from urllib.error import URLError

from urllib.parse import quote
'''.strip()


# Generated at 2022-06-21 17:28:25.374852
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    with pytest.raises(TypeError) as excinfo:
        BaseNodeTransformer()
    assert "Can't instantiate abstract class BaseNodeTransformer with abstract methods transform" in str(excinfo.value)



# Generated at 2022-06-21 17:28:34.607906
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import parse
    from ..models.typed_ast_ex import pretty

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('pathlib', 'pathlib2')
        ]


# Generated at 2022-06-21 17:28:40.356774
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import code

    class Sample(BaseImportRewrite):
        rewrites = [('new', 'old')]

    tree = code.parse("from new import A")
    tree = Sample.transform(tree)
    assert code.unparse(tree).strip() == 'try:\n    from new import A\nexcept ImportError:\n    from old import A'

    tree = code.parse("from new import *")
    tree = Sample.transform(tree)
    assert code.unparse(tree).strip() == 'from old import *'

    tree = code.parse("from new.module import A")
    tree = Sample.transform(tree)
    assert code.unparse(tree).strip() == 'try:\n    from new.module import A\nexcept ImportError:\n    from old.module import A'


# Generated at 2022-06-21 17:28:53.956366
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = None  # type: ast.AST

    class TestTransformer(BaseNodeTransformer):
        pass

    assert isinstance(TestTransformer(tree), BaseNodeTransformer)

# Generated at 2022-06-21 17:29:02.527914
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Rewriter(BaseImportRewrite):
        rewrites = [('six', 'backports.six')]

    tree = ast.parse('''
    import six

    from six.moves import input

    import six.moves.input
    ''')

    expected = '''
    try:
        import six
    except ImportError:
        from backports import six

    try:
        from six.moves import input
    except ImportError:
        from backports.six.moves import input

    try:
        import six.moves.input
    except ImportError:
        import backports.six.moves.input
    '''

    res = Rewriter.transform(tree)
    assert res.tree_changed
    assert res.code == expected



# Generated at 2022-06-21 17:29:11.361115
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('path', 'path2')
        ]

    tree = ast.parse("""
    from path.name import module1

    from path.name import module2 as mod2

    from path.name import *
    """)  # type: ast.AST

    tree = TestBaseImportRewrite.transform(tree).tree
    print(ast.dump(tree))

# Generated at 2022-06-21 17:29:18.843729
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six-py27')]

    test = unittest.TestCase()

    tree = ast.parse("import six", filename="test.py")
    result = TestTransformer.transform(tree)
    expected = ast.parse("""
try:
    import six
except ImportError:
    import six-py27
""".strip(), filename="test.py")
    test.assertEqual(result.tree.body[0], expected.body[0])

    tree = ast.parse("import six.moves", filename="test.py")
    result = TestTransformer.transform(tree)

# Generated at 2022-06-21 17:29:20.190891
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer._tree_changed == False

# Generated at 2022-06-21 17:29:27.693647
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..transforms.misc import RemoveRedundantImports
    from ..utils.misc import get_ast


# Generated at 2022-06-21 17:29:38.206283
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("""
from a import A
from b import B
from c import C
from d import D, d
from e import e as E
from f import f as F
from g import *
from h import i as I
    """)
    class Class(BaseImportRewrite):
        rewrites = [
            ('a', 'aa'),
            ('b', 'bb'),
            ('c', 'cc'),
            ('d.d', 'dd.dd'),
            ('e.e', 'ee.ee'),
            ('f', 'ff'),
            ('h.i', 'hh.ii'),
        ]
    Class.transform(tree)


# Generated at 2022-06-21 17:29:46.860010
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from pprint import pformat
    from typed_ast import ast3
    from ai.backend.common.transformers import BaseImportRewrite

    class TestTransformer(BaseImportRewrite):
        rewrites = [('io', 'pathlib')]

        def __init__(self, tree):
            self._tree = tree

    class TestImportRewrite(unittest.TestCase):
        def _test_import(self, expected, node):
            t = TestTransformer(node)
            result = t.visit(node)
            self.assertEqual(pformat(expected), pformat(result))


# Generated at 2022-06-21 17:29:59.527196
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    statements = [
        ast.Import(names=[
            ast.alias(name='a.b', asname='c'),
            ast.alias(name='d.e', asname='f')]),
        ast.Import(names=[
            ast.alias(name='p.q.r', asname='s')]),
        ast.Import(names=[
            ast.alias(name='a', asname='b')])]

    class TestSubclass(BaseImportRewrite):
        rewrites = [('p.q', 'p.q.r')]

    tree = ast.Module(body=statements)


# Generated at 2022-06-21 17:30:09.734797
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import unittest
    from typed_ast import ast3 as ast

    import_ = ast.Import(names=[ast.alias(name='foo',
                                         asname='bar')])
    import_changed = ast.Import(names=[ast.alias(name='qux',
                                                asname='bar')])

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'qux')]

    class TestBaseNodeTransformer(BaseNodeTransformer):
        def visit_Import(self, node: ast.Import) -> ast.Import:
            return TestBaseImportRewrite.transform(node)[0]

    tree = TestBaseNodeTransformer.transform(import_)[0]
    assert isinstance(tree, ast.Import)

# Generated at 2022-06-21 17:30:39.739492
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import parse
    import ast
    import sys
    import copy
    import six

    tree = parse('from typing import List')
    node = tree.body[0]
    assert isinstance(node, ast.ImportFrom)
    assert node.module == 'typing'
    assert node.level == 0

    node_copy = copy.deepcopy(node)

    rewriter = BaseImportRewrite(tree)
    new_node = rewriter.visit_Import(node)
    assert isinstance(new_node, ast.Try)

    assert new_node.body[0].body[0].names[0].name == 'typing.List'
    assert new_node.body[1].body[0].names[0].name == 'mytyping.List'

# Generated at 2022-06-21 17:30:51.092095
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import io
    from io import BytesIO
    nodetree = ast.parse("""import numpy as np; from numpy import *;    import matplotlib.pyplot as plt;   from sklearn.linear_model import LinearRegression""")
    rewr = BaseImportRewrite(nodetree)
    rewr.visit(nodetree)

# Generated at 2022-06-21 17:31:01.605297
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    from py2ts.transformers.base import BaseImportRewrite

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')]

    def import_rewrite_test(before_import: str, after_import: str):
        node = ast.parse(before_import,
                         filename='<unknown>',
                         mode='exec')
        result = TestImportRewrite.transform(node)
        assert astunparse.unparse(result.tree) == after_import

    import_rewrite_test('import foo',
                        'import bar')
    import_rewrite_test('import foo as bar',
                        'import bar as bar')
    import_rewrite_test('from foo import bar',
                        'from bar import bar')
    import_

# Generated at 2022-06-21 17:31:03.740679
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformerTest(BaseTransformer):
        target = None

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass

    test = BaseTransformerTest()
    assert test


# Generated at 2022-06-21 17:31:13.977088
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astunparse
    class Test1(BaseImportRewrite):
        rewrites = [
            ('os', 'os')
        ]

    class Test2(BaseImportRewrite):
        rewrites = [
            ('os', '_os')
        ]

    class Test3(BaseImportRewrite):
        rewrites = [
            ('os', '_os')
        ]

    tree = ast.parse('import os')
    tree1 = Test1.transform(tree)[0]
    assert astunparse.unparse(tree1) == 'import os'

    tree = ast.parse('from os.path import join')
    tree2 = Test2.transform(tree)[0]

# Generated at 2022-06-21 17:31:20.398258
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_tree = astor.parse_file(
        'tests/inputs/import_rewrites/input_import.py')
    instance = BaseImportRewrite(import_tree)
    instance.visit(import_tree)
    expected = astor.parse_file(
        'tests/outputs/import_rewrites/output_import.py')
    assert astor.to_source(import_tree) == astor.to_source(expected)



# Generated at 2022-06-21 17:31:32.085036
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast, sys
    class TestClass(BaseImportRewrite):
        target = None
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo, foo.bar')
    transformer = TestClass(tree)
    node = transformer.visit_Import(tree.body[0])
    assert node.body[0].value.names[0].name == 'foo'
    assert node.body[1].value.names[0].name == 'bar'
    assert node.body[2].body[0].value.names[0].name == 'foo'
    assert node.body[2].body[0].value.names[0].asname == 'foo'
    assert node.body[2].body[1].value.names[0].name == 'bar.bar'

# Generated at 2022-06-21 17:31:37.568578
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..types import CompilationTarget
    from ..utils import compile_snippet


# Generated at 2022-06-21 17:31:44.686882
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import ast_to_str
    import ast
    import six
    
    class RewriteImports(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('baz', 'quux')]
    
    import_statement = ast.ImportFrom(
        module='foo',
        names=[
            ast.alias(name='A', asname=None),
            ast.alias(name='B', asname='C')
        ],
        level=0
    )

# Generated at 2022-06-21 17:31:50.312783
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import sys, os")
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [("sys", "test")]
    new_tree = transformer.visit_Import(tree.body[0])
    assert ast.dump(new_tree) == "try:\n    import sys\nexcept ImportError:\n    import test"


# Generated at 2022-06-21 17:32:32.351075
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    type_comment_class = "transformer_constructor"
    before = """
    from abc import ABCMeta, abstractmethod

    class BaseTransformer(metaclass=ABCMeta):
        target = None  # type: CompilationTarget

        @classmethod
        @abstractmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    """
    after = """
    from abc import ABCMeta, abstractmethod

    class BaseTransformer:
        def __init__(self):
            self.target = None  # type: CompilationTarget

        @classmethod
        @abstractmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    """

# Generated at 2022-06-21 17:32:43.497412
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestNodeTransformer(BaseImportRewrite):
        target = CompilationTarget.PY3
        rewrites = [
            ('six.moves', 'six')]

        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)

    tree = ast.parse("""
    import six.moves.urllib
    print("test")
    """)  # NOQA

    result = TestNodeTransformer.transform(tree)


# Generated at 2022-06-21 17:32:52.198997
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import typing as T
    class SomeReplace(BaseImportRewrite):
        rewrites = [['typing', 'six']]
    tree = ast.parse('import typing\n', '<ast>', 'exec')
    SomeReplace(tree).visit(tree)
    assert ast.dump(tree) == 'Module(body=[Try(body=[Import(names=[alias(name=\'six\', asname=\'T\')])], handlers=[except(type=None, name=None)], orelse=[], finalbody=[])])'

test_BaseImportRewrite()

# Generated at 2022-06-21 17:32:54.974798
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # TODO: Add unit test for constructor of class BaseNodeTransformer
    raise NotImplementedError


# Generated at 2022-06-21 17:32:57.162237
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("")
    BaseNodeTransformer(tree)

# Generated at 2022-06-21 17:33:04.808991
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Import
    from typed_ast.ast3 import ImportFrom
    # TODO: Replace with typed snippet

# Generated at 2022-06-21 17:33:07.579488
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class X(BaseTransformer):
        pass
    
    assert(X.target is None)

# Generated at 2022-06-21 17:33:08.092129
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-21 17:33:13.612470
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class N(BaseNodeTransformer):
        def visit_Module(self, node):
            return node
    tree = ast.parse('1 + 2')
    result = N.transform(tree)
    assert result.changed_tree == False
    assert result.ast == ast.parse('1 + 2')
    assert result.dependencies == []

# Generated at 2022-06-21 17:33:18.088139
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [(1,2),(3,4)]
    BaseImportRewrite._tree_changed = True
    BaseImportRewrite._tree = ast.AST()
    assert(BaseImportRewrite == BaseImportRewrite())
    assert(BaseImportRewrite.transform(BaseImportRewrite._tree) ==
           TransformationResult(BaseImportRewrite._tree,
                                BaseImportRewrite._tree_changed,
                                BaseImportRewrite.dependencies))
