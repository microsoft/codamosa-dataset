

# Generated at 2022-06-17 23:57:28.940021
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast_node_at_line
    from ..utils.ast_helpers import get_ast_node_at_line_column
    from ..utils.ast_helpers import get_ast_node_at_line_column_end
    from ..utils.ast_helpers import get_ast_node_at_line_column_end_end
    from ..utils.ast_helpers import get_ast_node_at_line_column_end_end_end
    from ..utils.ast_helpers import get_ast_node_at_line_column_end_end_end_end
    from ..utils.ast_helpers import get_ast_node_at_line_column_end_end_end

# Generated at 2022-06-17 23:57:35.930771
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('django.utils.translation', 'django.utils.translation.trans_real'),
            ('django.utils.translation.trans_real', 'django.utils.translation'),
        ]


# Generated at 2022-06-17 23:57:47.773316
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
from foo.bar.baz import qux
from foo.bar.baz import quux as quux_alias
from foo.bar.baz import * as *
from foo.bar.baz import * as *_alias
from foo.bar.baz import qux as qux_alias
''')
    TestImportRewrite.transform(tree)


# Generated at 2022-06-17 23:57:55.813074
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation_result(
        TestTransformer,
        parse_ast("import foo"),
        parse_ast("""
try:
    import foo
except ImportError:
    import bar
"""),
        True,
        ['bar'])

    assert_transformation_result(
        TestTransformer,
        parse_ast("import foo as bar"),
        parse_ast("""
try:
    import foo as bar
except ImportError:
    import bar as bar
"""),
        True,
        ['bar'])


# Generated at 2022-06-17 23:58:05.457637
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.asserts import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_ast_equal(ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar'),
                     tree)

    tree = ast.parse('import foo.bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_ast_equal(ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'),
                     tree)

    tree

# Generated at 2022-06-17 23:58:08.753285
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = parse_ast("import a")
    result = TestTransformer.transform(tree)
    assert dump_ast(result.tree) == dump_ast(parse_ast("""
    try:
        import a
    except ImportError:
        import b
    """))



# Generated at 2022-06-17 23:58:18.862242
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_code_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')
        ]

    code = '''
from foo import bar
from baz import qux
from foo import bar as baz
from foo.bar import qux
from foo.bar import qux as quux
from foo.bar import *
from foo.bar.baz import qux
from foo.bar.baz import qux as quux
from foo.bar.baz import *
'''

# Generated at 2022-06-17 23:58:26.387999
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_code():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = ast.parse(test_code.get_source())
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == test_code.get_source(
        previous='import foo',
        current='import bar')



# Generated at 2022-06-17 23:58:33.290831
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from ..utils.snippet import snippet
    from .base import BaseImportRewrite
    from .base import import_rewrite

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    code = '''
    from six import iteritems
    from six.moves import range
    from six.moves import map
    from six import iteritems as items
    '''
    tree = ast.parse(code)
    TestImportRewrite.transform(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-17 23:58:42.208669
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import typing
    import six
    import six.moves.urllib.parse
    import six.moves.urllib.request
    import six.moves.urllib.error
    import six.moves.urllib.response
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse

# Generated at 2022-06-17 23:58:58.726401
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)
    expected = get_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:59:05.098793
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = parse_ast(test_snippet)
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert astor.to_source(tree) == '''\
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar

import foo.bar.baz
'''



# Generated at 2022-06-17 23:59:15.759226
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux'),
        ]

    tree = get_ast('''
    from foo import bar
    from foo.bar import baz
    from foo.bar.baz import qux
    from foo.bar.baz.qux import quux
    ''')
    ImportRewrite.transform(tree)


# Generated at 2022-06-17 23:59:23.249849
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.snippet import get_ast
    from ..utils.ast_helpers import get_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os_mock')]


# Generated at 2022-06-17 23:59:31.999620
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import unittest
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast

# Generated at 2022-06-17 23:59:42.184708
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.test_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import a, b, c')
    expected_tree = ast.parse('''
try:
    from foo import a, b, c
except ImportError:
    from bar import a, b, c
    ''')

    TestTransformer.transform(tree)
    assert_ast_equal(expected_tree, tree)

    tree = ast.parse('from foo.bar import a, b, c')

# Generated at 2022-06-17 23:59:53.674069
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'from foo import baz'
    expected = 'from bar import baz'
    tree = get_ast_from_source(source)
    result = TestTransformer.transform(tree)
    assert result.changed
    assert_equal_ast(get_source_from_ast(result.tree), expected)

    source = 'from foo import *'
    expected = 'from bar import *'
    tree = get_ast_from_source(source)
    result = TestTransformer.transform(tree)

# Generated at 2022-06-18 00:00:00.659124
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.test_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source('import foo')
    expected = get_ast_from_source('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:00:08.725784
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_node_at_line

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    import foo.bar
    import foo.bar.baz
    ''')

    TestTransformer.transform(tree)

    assert astor.to_source(get_ast_node_at_line(tree, 2)) == 'import foo'
    assert astor.to_source(get_ast_node_at_line(tree, 3)) == 'import bar'
    assert astor.to_source(get_ast_node_at_line(tree, 4)) == 'import bar.baz'



# Generated at 2022-06-18 00:00:18.223006
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]

    tree = ast.parse('import six')
    result = TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(result.tree),
                        'try:\n    import six\nexcept ImportError:\n    import six_mock')

    tree = ast.parse('import six.moves')
    result = TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(result.tree),
                        'try:\n    import six.moves\nexcept ImportError:\n    import six_mock.moves')


# Generated at 2022-06-18 00:00:41.463925
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    sys.path.append('../../../')
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser

# Generated at 2022-06-18 00:00:48.505378
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit_Import(tree.body[0])
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:53.420885
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit_Import(tree.body[0])
    assert astor.to_source(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:58.476760
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['bar']
    assert result.tree.body[0].body[0].body[0].names[0].name == 'bar'



# Generated at 2022-06-18 00:01:09.544207
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar').body[0]
    import_from_rewrite = ast.parse('from foo import bar as baz').body[0]
    import_from_rewrite_2 = ast.parse('from foo.bar import baz').body[0]
    import_from_rewrite_3 = ast.parse('from foo.bar import baz as qux').body[0]
    import_from_rewrite_4 = ast.parse('from foo import *').body[0]
    import_from_rewrite_5 = ast.parse('from foo.bar import *').body[0]
    import_from_rewrite_6 = ast.parse('from foo.bar import baz, qux').body[0]
    import_from_rewrite_7 = ast.parse

# Generated at 2022-06-18 00:01:20.971914
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )
    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]
        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

# Generated at 2022-06-18 00:01:25.915027
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import get_body
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:01:37.211590
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, extend
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    tree = ast.parse(
        """
        import foo
        """
    )
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:01:46.735479
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast
    from ..utils.compiler import compile_snippet
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_or_value
    from ..utils.source import get_source_for_value
    from ..utils.source import get_source_for_value_or_node
    from ..utils.source import get_source_for_value_or_node_or_value
    from ..utils.source import get_source_for_value_or_value
    from ..utils.source import get_source_for_value_or_value_or_node

# Generated at 2022-06-18 00:01:51.879850
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('foo.baz', 'bar.baz'),
            ('foo.baz.qux', 'bar.baz.qux'),
        ]

    @snippet
    def test_import_from():
        from foo import bar
        from foo import baz
        from foo import qux
        from foo.baz import bar
        from foo.baz import baz
        from foo.baz import qux
        from foo.baz.qux import bar
        from foo.baz.qux import baz
        from foo.baz.qux import qux


# Generated at 2022-06-18 00:02:21.903812
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    sys.path.append('../')
    from ..types import CompilationTarget
    from ..utils.snippet import snippet, extend
    from ..transformers.base import BaseImportRewrite
    from ..transformers.base import import_rewrite

    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON_3_6
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:02:32.690454
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.snippet import snippet
    from ..utils.ast import parse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    @snippet
    def test_snippet():
        import foo
        import foo.bar

    tree = parse(test_snippet.get_source())
    result = TestImportRewrite.transform(tree)
    assert result.tree.body[0].body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[0].body[1].value.names[0].name == 'bar.bar'



# Generated at 2022-06-18 00:02:39.914790
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.test_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:02:48.146292
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:02:57.891031
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
'''

# Generated at 2022-06-18 00:03:06.061266
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom_data import data
    for d in data:
        tree = astor.parse_file(d)
        BaseImportRewrite.rewrites = [('six', 'six.moves')]
        BaseImportRewrite.transform(tree)
        assert astor.to_source(tree) == d

# Generated at 2022-06-18 00:03:10.499174
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:20.563418
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_code():
        from foo import baz
        from foo import bar as baz
        from foo import *
        from foo.bar import baz
        from foo.bar import bar as baz
        from foo.bar import *
        from foo.bar.baz import baz
        from foo.bar.baz import bar as baz
        from foo.bar.baz import *


# Generated at 2022-06-18 00:03:25.858361
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astor.to_source(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:36.523003
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse("from foo import bar, baz").body[0]
    import_from_rewrite = ast.parse("from foo import bar, baz").body[0]
    import_from_rewrite.names[0].name = "bar_rewrite"
    import_from_rewrite.names[1].name = "baz_rewrite"
    import_from_rewrite = astor.to_source(import_from_rewrite)
    import_from_rewrite = ast.parse(import_from_rewrite).body[0]
    import_from_rewrite = astor.to_source(import_from_rewrite)
    import_from_rewrite = ast.parse(import_from_rewrite).body[0]
    import_from_rewrite = astor

# Generated at 2022-06-18 00:04:21.572072
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_transform

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('old', 'new')
        ]

    assert_transform(TestTransformer,
                     'import old',
                     'try:\n    import old\nexcept ImportError:\n    import new')

    assert_transform(TestTransformer,
                     'import old.sub',
                     'try:\n    import old.sub\nexcept ImportError:\n    import new.sub')

    assert_transform(TestTransformer,
                     'import old.sub as sub',
                     'try:\n    import old.sub as sub\nexcept ImportError:\n    import new.sub as sub')


# Generated at 2022-06-18 00:04:27.126562
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(get_snippet_body('import_rewrite'))
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == get_snippet_body('import_rewrite_result')



# Generated at 2022-06-18 00:04:36.382139
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='foo', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='bar', asname=None)])])],
        orelse=[],
        finalbody=[])
    assert result.changed is True



# Generated at 2022-06-18 00:04:47.273914
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from test_BaseImportRewrite import BaseImportRewrite

    class Test(BaseImportRewrite):
        rewrites = [('test_BaseImportRewrite', 'test_BaseImportRewrite_visit_ImportFrom')]


# Generated at 2022-06-18 00:04:54.793376
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import unittest
    import unittest.mock
    import typing
    import typing_extensions
    import six
    import enum
    import contextlib
    import functools
    import collections
    import abc
    import asyncio
    import asyncio.coroutines
    import asyncio.futures
    import asyncio.locks
    import asyncio.queues
    import asyncio.streams
    import asyncio.subprocess
    import asyncio.tasks
    import asyncio.transports
    import asyncio.windows_events
    import asyncio.windows_utils
    import asyncio.events
    import asyncio.proactor_events
    import asyncio.selector_events

# Generated at 2022-06-18 00:05:01.688134
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom_data import data

    for d in data:
        tree = ast.parse(d['code'])
        transformer = BaseImportRewrite(tree)
        transformer.rewrites = d['rewrites']
        transformer.visit(tree)
        assert astor.to_source(tree) == d['expected']

# Generated at 2022-06-18 00:05:05.977532
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_body
    from ..utils.ast import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_body(TestImportRewrite.transform.__func__))
    assert astor.to_source(tree) == '''\
try:
    import foo
except ImportError:
    import bar
'''



# Generated at 2022-06-18 00:05:17.421989
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import ast_to_str

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = ast.parse(test_snippet.get_source())
    TestTransformer.transform(tree)
    assert ast_to_str(tree) == """
    import foo
    try:
        import foo.bar
    except ImportError:
        import bar.bar
    try:
        import foo.bar.baz
    except ImportError:
        import bar.bar.baz
    """


# Generated at 2022-06-18 00:05:25.286480
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert compare_ast(result.tree, expected)
    assert result.changed



# Generated at 2022-06-18 00:05:31.436973
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom_data import data
    for d in data:
        tree = astor.parse_file(d)
        BaseImportRewrite.rewrites = [('foo', 'bar')]
        BaseImportRewrite.transform(tree)
        assert astor.to_source(tree) == d

# Generated at 2022-06-18 00:07:02.518445
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.test_helpers import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from():
        from foo import bar
        from foo.baz import qux
        from foo.baz import qux as quux
        from foo.baz import *
        from foo.baz import qux as quux, quux as quuux

    tree = get_ast(test_import_from)
    TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:07:12.502724
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz.qux
        import foo.bar.baz.qux.quux

    tree = get_ast(test_snippet)
    TestTransformer.transform(tree)

    @snippet
    def expected_snippet():
        try:
            import foo
        except ImportError:
            import bar
        try:
            import foo.bar
        except ImportError:
            import bar.bar

# Generated at 2022-06-18 00:07:18.726287
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import textwrap
    from ..utils.snippet import snippet

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from():
        from six import iteritems
        from six import iterkeys
        from six import itervalues
        from six import viewitems
        from six import viewkeys
        from six import viewvalues
        from six import StringIO
        from six import StringIO as StringIOAlias
        from six import BytesIO
        from six import BytesIO as BytesIOAlias
        from six import PY2
        from six import PY3
        from six import PY34
        from six import PY35
        from six import PY36