

# Generated at 2022-06-17 23:57:40.396806
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('''
import six
''')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == '''
try:
    import six
except ImportError:
    import six.moves as six
'''



# Generated at 2022-06-17 23:57:51.046511
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='bar', asname=None)])],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[ast.Import(names=[ast.alias(name='foo', asname=None)])])],
        orelse=[],
        finalbody=[])



# Generated at 2022-06-17 23:57:59.601926
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import get_test_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_test_ast("""
    import foo
    """)

    expected_tree = get_test_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    assert_transformation_result(TestImportRewrite, tree, expected_tree)



# Generated at 2022-06-17 23:58:07.239007
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import test_BaseImportRewrite_visit_ImportFrom
    import test_BaseImportRewrite_visit_ImportFrom_rewrite
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_2
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_3
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_4
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_5
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_6
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_7

# Generated at 2022-06-17 23:58:14.589499
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'
    assert result.tree_changed is True
    assert result.dependencies == ['foo']



# Generated at 2022-06-17 23:58:24.323726
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    from foo import a
    from foo import b as c
    from foo import *
    from foo.bar import d
    from foo.bar import e as f
    from foo.bar import *
    from foo.bar.baz import g
    from foo.bar.baz import h as i
    from foo.bar.baz import *
    """)

# Generated at 2022-06-17 23:58:30.848112
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_node_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert_node_equal(expected, result.tree)



# Generated at 2022-06-17 23:58:41.334868
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import bar')
    expected = ast.parse('try:\n    from foo import bar\nexcept ImportError:\n    from bar import bar')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('from foo import bar as baz')
    expected = ast.parse('try:\n    from foo import bar as baz\nexcept ImportError:\n    from bar import bar as baz')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('from foo import bar, baz')

# Generated at 2022-06-17 23:58:52.502070
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies_equal(result, ['foo', 'bar'])
    assert_ast_equal(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)

# Generated at 2022-06-17 23:59:01.031445
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:59:22.005780
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import a, b, c')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == 'try:\n    from foo import a, b, c\nexcept ImportError:\n    from bar import a, b, c'

    tree = ast.parse('from foo import *')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == 'try:\n    from foo import *\nexcept ImportError:\n    from bar import *'

    tree = ast.parse('from foo.bar import a, b, c')
    TestImportRewrite.transform(tree)
    assert astor.to_

# Generated at 2022-06-17 23:59:31.416978
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_code_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:59:39.213855
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast, compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('import six')
    expected = get_ast('try:\n    import six\nexcept ImportError:\n    import six.moves as six')

    result = TestImportRewrite.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:59:43.378302
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:59:50.198534
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-17 23:59:59.673585
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:00:07.726232
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transform

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transform(TestTransformer,
                     'import foo',
                     'try:\n    import foo\nexcept ImportError:\n    import bar')

    assert_transform(TestTransformer,
                     'import foo.bar',
                     'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    assert_transform(TestTransformer,
                     'import foo.bar as baz',
                     'try:\n    import foo.bar as baz\nexcept ImportError:\n    import bar.bar as baz')



# Generated at 2022-06-18 00:00:14.785794
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected_tree = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_transformation_result(TestTransformer, tree, expected_tree)



# Generated at 2022-06-18 00:00:19.577018
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_source('from foo import baz'))
    result = TestImportRewrite.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar.baz'



# Generated at 2022-06-18 00:00:26.525914
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(get_snippet_body(test_BaseImportRewrite_visit_Import))
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == get_snippet_body(test_BaseImportRewrite_visit_Import)



# Generated at 2022-06-18 00:00:52.808892
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast, get_code
    from ..utils.snippet import snippet
    from ..utils.test_helpers import assert_equal_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = get_ast('''
    import old
    ''')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert_equal_code(get_code(result), snippet('''
    try:
        import old
    except ImportError:
        import new
    '''))



# Generated at 2022-06-18 00:00:59.594188
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('os', 'pathlib'),
            ('os.path', 'pathlib.Path'),
            ('os.path.join', 'pathlib.Path.joinpath')
        ]

    source = get_snippet('import_rewrite')
    tree = get_ast(source)
    result = TestBaseImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == get_snippet('import_rewrite_result')

# Generated at 2022-06-18 00:01:10.882854
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz
        from foo import bar
        from foo import bar as baz
        from foo import bar, baz
        from foo import bar as baz, baz as bar
        from foo import *
        from foo.bar import baz
        from foo.bar import baz as bar
        from foo.bar import baz, bar
        from foo.bar import baz as bar, bar as baz
        from foo.bar import *
        from foo.bar.baz import bar
        from foo.bar.baz import bar as baz
        from foo.bar.baz import bar

# Generated at 2022-06-18 00:01:19.166373
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
import foo
""")

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == """
try:
    import foo
except ImportError:
    import bar
"""



# Generated at 2022-06-18 00:01:29.843387
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os.path')]

            tree = ast.parse('''
            import os
            import os.path
            import os.path.join
            import os.path.join as join
            ''')
            TestTransformer.transform(tree)

# Generated at 2022-06-18 00:01:40.127270
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import io
    import unittest
    from typing import List, Tuple, Union, Optional, Iterable, Dict

    class BaseImportRewrite(BaseNodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None


# Generated at 2022-06-18 00:01:49.032455
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ast import parse
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_node_by_path

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six'),
            ('six.moves.urllib.parse', 'urllib.parse'),
            ('six.moves.urllib.request', 'urllib.request'),
            ('six.moves.urllib.error', 'urllib.error'),
            ('six.moves.urllib.response', 'urllib.response'),
            ('six.moves.urllib.robotparser', 'urllib.robotparser'),
        ]


# Generated at 2022-06-18 00:01:58.880592
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def test_snippet():
        from a.b.c import d
        from a.b.c import e as f
        from a.b.c import g as h, i as j
        from a.b.c import k, l as m, n as o
        from a.b.c import *

    test_snippet_ast = astor.to_ast(test_snippet)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('a.b.c', 'a.b.c.d'),
        ]

    result = TestImportRewrite.transform(test_snippet_ast)
    assert_ast

# Generated at 2022-06-18 00:02:09.423502
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_source_with_import
    from ..utils.test_utils import assert_equal_source_with_import_from

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_equal_ast(
        TestImportRewrite.transform(ast.parse('import foo')).tree,
        ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar'))


# Generated at 2022-06-18 00:02:20.226478
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:02:46.497560
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import get_snippet_body

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(get_snippet_body(test_BaseImportRewrite_visit_ImportFrom))
    result = TestImportRewrite.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == get_snippet_body(test_BaseImportRewrite_visit_ImportFrom_result)



# Generated at 2022-06-18 00:02:56.671843
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from():
        import six
        from six import moves
        from six.moves import urllib

    @snippet
    def test_import_from_rewrite():
        try:
            import six
        except ImportError:
            import six.moves as six
        try:
            from six import moves
        except ImportError:
            from six.moves import moves
        try:
            from six.moves import urllib
        except ImportError:
            from six.moves import urllib

    tree = ast.parse(extend(test_import_from))


# Generated at 2022-06-18 00:03:07.632750
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from ..utils.ast_helpers import get_node_of_class
    from ..utils.ast_helpers import get_node_of_class_in_function
    from ..utils.ast_helpers import get_node_of_class_in_function_in_class
    from ..utils.ast_helpers import get_node_of_class_in_function_in_class_in_module
    from ..utils.ast_helpers import get_node_of_class_in_function_in_module
    from ..utils.ast_helpers import get_node_of_class_in_module
    from ..utils.ast_helpers import get_node_of_class_in_module_in_module
    from ..utils.ast_helpers import get_node_of_class_in_module_in_module

# Generated at 2022-06-18 00:03:16.229066
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:03:25.502845
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_node
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_node(astor.to_source(snippet_to_ast('''
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz.qux
    ''')))

    result = TestTransformer.transform(tree)
    assert result.changed


# Generated at 2022-06-18 00:03:36.222045
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast.ast3 import ImportFrom, alias, Try, Import
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import parse

# Generated at 2022-06-18 00:03:47.393476
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_equal_ast(tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    TestTransformer.transform(tree)
    assert_equal_ast(tree, 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:03:58.522177
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse
    from ..utils.ast import dump

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:04:09.394737
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:04:20.186211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    import_rewrite = snippet('''
    try:
        extend(previous)
    except ImportError:
        extend(current)
    ''')

    class Test(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse('''
    import a
    ''')
    Test.transform(tree)
    assert astor.to_source(tree) == '''
    try:
        extend(Import(names=[alias(name='a', asname=None)]))
    except ImportError:
        extend(Import(names=[alias(name='b', asname=None)]))
    '''



# Generated at 2022-06-18 00:05:05.574403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse("""
    try:
        import foo
    except ImportError:
        import bar
    """)
    assert_ast_equal(expected, TestImportRewrite.transform(tree).tree)



# Generated at 2022-06-18 00:05:17.152218
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = get_ast(test_snippet)
    TestImportRewrite.transform(tree)

    assert astor.to_source(tree) == """
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar

try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz
"""



# Generated at 2022-06-18 00:05:28.366128
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = ast.parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:05:34.712616
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast('import foo')
    expected = parse_ast('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_asts(result.tree, expected)



# Generated at 2022-06-18 00:05:45.100555
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo

    @snippet
    def expected():
        try:
            import foo
        except ImportError:
            import bar

    tree = astor.parse_file(test_import.get_path())
    expected_tree = astor.parse_file(expected.get_path())
    TestImportRewrite.transform(tree)
    assert_equal_ast(tree, expected_tree)



# Generated at 2022-06-18 00:05:51.571817
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:59.723743
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves'),
            ('six.moves.urllib', 'urllib.request'),
        ]

    tree = get_ast('''
from six import StringIO
from six.moves import urllib
from six.moves.urllib import request
from six.moves.urllib.request import urlopen
''')

# Generated at 2022-06-18 00:06:10.323681
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.testing import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]


# Generated at 2022-06-18 00:06:20.084990
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:06:26.107215
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

