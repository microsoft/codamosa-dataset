

# Generated at 2022-06-17 23:57:36.085182
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.snippet import get_snippet_from_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
from foo.bar.baz import qux
'''

# Generated at 2022-06-17 23:57:44.514625
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    Test.transform(tree)
    assert_equal_ast(tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    Test.transform(tree)
    assert_equal_ast(tree, 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    Test.transform(tree)

# Generated at 2022-06-17 23:57:47.491897
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astor.to_source(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:57:54.852028
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_node = ast.parse('import foo').body[0]
    import_node_rewrite = ast.parse('import foo_rewrite').body[0]
    import_node_rewrite_try = ast.parse('try:\n    import foo_rewrite\nexcept ImportError:\n    import foo').body[0]
    import_node_rewrite_try_indent = ast.parse('try:\n    import foo_rewrite\nexcept ImportError:\n    import foo').body[0]

# Generated at 2022-06-17 23:58:05.108446
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('''
        import six
        import six.moves
        import six.moves.urllib
        import six.moves.urllib.parse
        import six.moves.urllib.parse as urlparse
        import six.moves.urllib.parse.urlparse
        import six.moves.urllib.parse.urlparse as urlparse
    ''')

    result = TestTransformer.transform(tree)
    assert result.changed


# Generated at 2022-06-17 23:58:14.982915
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast
    from ..utils.ast_helpers import get_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    import foo
    ''')
    expected = get_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert compare_ast(tree, expected)
    assert get_source(tree) == get_source(expected)



# Generated at 2022-06-17 23:58:23.242388
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.testing import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')
        ]

    tree = ast.parse('''
from foo import bar
from foo import baz as qux
from foo import *
from foo.bar import baz
from foo.bar import qux as quux
from foo.bar import *
from baz import qux
from baz import quux
from baz import *
from baz.qux import quux
from baz.qux import quuux
from baz.qux import *
''')

# Generated at 2022-06-17 23:58:28.480991
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_equal_ast(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-17 23:58:40.393534
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import ast_from_code
    from ..utils.ast_helpers import ast_to_code
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import ast_to_source_code
    from ..utils.ast_helpers import ast_to_source_code_no_comments
    from ..utils.ast_helpers import ast_to_source_code_no_comments_no_newlines
    from ..utils.ast_helpers import ast_to_source_code_no_newlines
    from ..utils.ast_helpers import ast_to_source_no_comments
    from ..utils.ast_helpers import ast_to_source_no_comments_no_newlines
    from ..utils.ast_helpers import ast_to_source_

# Generated at 2022-06-17 23:58:51.697404
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = ast.parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = ast.parse('import foo.bar as baz')
    result = TestTransformer.transform(tree)

# Generated at 2022-06-17 23:59:04.931070
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import os.path
    import os.path as path
    import os.path as path2
    import os.path as path3
    import os.path as path4
    import os.path as path5
    import os.path as path6
    import os.path as path7
    import os.path as path8
    import os.path as path9
    import os.path as path10
    import os.path as path11
    import os.path as path12
    import os.path as path13
    import os.path as path14
    import os.path as path15
    import os.path as path16
    import os.path as path17
    import os.path as path18
    import os.path as path19

# Generated at 2022-06-17 23:59:15.573738
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import get_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse(get_body(test_BaseImportRewrite_visit_ImportFrom))
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == get_body(test_BaseImportRewrite_visit_ImportFrom, 1)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse(get_body(test_BaseImportRewrite_visit_ImportFrom, 2))
    result = TestTransformer.transform(tree)

# Generated at 2022-06-17 23:59:25.543010
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_utils import BaseImportRewrite

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:59:31.257342
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class Test(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = get_ast('import a')
    expected = get_ast('''
try:
    import a
except ImportError:
    import b
    ''')

    result = Test.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:59:41.635419
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("from foo import bar")
    Test.transform(tree)
    assert_ast_equal(tree, "try:\n    from bar import bar\nexcept ImportError:\n    from foo import bar")

    tree = ast.parse("from foo import bar as baz")
    Test.transform(tree)
    assert_ast_equal(tree, "try:\n    from bar import bar as baz\nexcept ImportError:\n    from foo import bar as baz")

    tree = ast.parse("from foo import *")
    Test.transform(tree)

# Generated at 2022-06-17 23:59:53.221231
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation_result(
        TestTransformer,
        """
        from foo import bar
        """,
        """
        try:
            from foo import bar
        except ImportError:
            from bar import bar
        """)

    assert_transformation_result(
        TestTransformer,
        """
        from foo import bar as baz
        """,
        """
        try:
            from foo import bar as baz
        except ImportError:
            from bar import bar as baz
        """)


# Generated at 2022-06-18 00:00:01.691547
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast


# Generated at 2022-06-18 00:00:07.796381
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:00:18.060468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert_tree_changed(result)
    assert_ast_equal(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert_tree_changed(result)
    assert_ast_equal(result.tree, 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse

# Generated at 2022-06-18 00:00:25.888074
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from .. import utils
    from ..utils import snippet
    from ..utils.snippet import extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('''
import six
''')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == '''
try:
    import six
except ImportError:
    import six.moves as six
'''



# Generated at 2022-06-18 00:00:46.415710
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_ast_from_source_with_imports

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = """
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
from foo.bar.baz import baz
"""

# Generated at 2022-06-18 00:00:56.190322
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from ..utils import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_

# Generated at 2022-06-18 00:01:02.535551
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.compare import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)
    expected = parse_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)
    compare_ast(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:01:14.232466
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import os.path
    import typing
    import typing.io
    import typing.io.IOBase
    import typing.io.TextIO
    import typing.io.BinaryIO
    import typing.io.TextIOWrapper
    import typing.io.BufferedIOBase
    import typing.io.BufferedReader
    import typing.io.BufferedWriter
    import typing.io.BufferedRWPair
    import typing.io.BufferedRandom
    import typing.io.FileIO
    import typing.io.BytesIO
    import typing.io.StringIO
    import typing.io.StringIO
    import typing.io.RawIOBase
    import typing.io.RawIOBase
    import typing.io.RawIOBase
    import typing.io.Raw

# Generated at 2022-06-18 00:01:24.590231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_transformation

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation(TestTransformer,
                          'import foo',
                          'try:\n    import foo\nexcept ImportError:\n    import bar')

    assert_transformation(TestTransformer,
                          'import foo.bar',
                          'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    assert_transformation(TestTransformer,
                          'import foo.bar as baz',
                          'try:\n    import foo.bar as baz\nexcept ImportError:\n    import bar.bar as baz')


# Generated at 2022-06-18 00:01:33.965662
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..utils import ast_utils
    from ..utils.ast_utils import ast_to_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Test(unittest.TestCase):
        def test_import(self):
            tree = ast_utils.parse_string('''
                import foo
            ''')
            TestTransformer.transform(tree)
            self.assertEqual(ast_to_source(tree), '''
                try:
                    import foo
                except ImportError:
                    import bar
            ''')

    unittest.main()


# Generated at 2022-06-18 00:01:41.004900
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import_from = ast.ImportFrom(module='foo',
                                 names=[ast.alias(name='bar',
                                                  asname='baz')],
                                 level=0)
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = TestImportRewrite.transform(import_from).tree
    assert astor.to_source(tree) == astunparse.unparse(tree)

# Generated at 2022-06-18 00:01:48.122848
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    @snippet
    def test():
        import os
        import os.path

    ast_tree = get_ast(test)
    transformer = TestTransformer(ast_tree)
    transformer.visit(ast_tree)
    assert astor.to_source(ast_tree) == """
try:
    import os
except ImportError:
    import os.path
    """


# Generated at 2022-06-18 00:01:54.534104
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    test_BaseImportRewrite_visit_ImportFrom.test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-18 00:02:00.462463
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == 'Try(\n' \
                             '    Import(names=[alias(name=\'bar\', asname=\'foo\')]),\n' \
                             '    ExceptHandler(type=None, name=None, body=[Import(names=[alias(name=\'foo\', asname=\'foo\')])]),\n' \
                             '    orelse=[],\n' \
                             '    finalbody=[]\n' \
                             ')'



# Generated at 2022-06-18 00:02:34.107807
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = get_ast('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = get_ast('import foo.bar as baz')

# Generated at 2022-06-18 00:02:45.019593
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
from foo import bar
from foo.baz import qux
from foo.baz import qux as quux
from foo.baz import *
from foo.baz import qux, quux
from foo.baz import qux as quux, quux as quuux
from foo.baz import qux, quux as quuux
from foo.baz import qux as quux, quux
'''


# Generated at 2022-06-18 00:02:53.454449
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')
        ]

    tree = ast.parse('''
from foo import bar
from foo import bar as baz
from foo import *
from foo.bar import baz
from foo.bar import baz as qux
from foo.bar import *
from baz import qux
from baz import qux as quux
from baz import *
from baz.qux import quux
from baz.qux import quux as quuz
from baz.qux import *
    ''')


# Generated at 2022-06-18 00:03:00.109183
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    from ..utils.test_utils import assert_code_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
from foo.bar.baz import qux
''')
    result = TestImportRewrite.transform(tree)
    assert result.changed

# Generated at 2022-06-18 00:03:10.089104
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo.bar import baz
from foo.bar import baz as qux
from foo.bar import *
''')


# Generated at 2022-06-18 00:03:20.287473
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import os.path
    import shutil
    import tempfile
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tempdir)
            self.old_path = sys.path[:]
            sys.path.insert(0, self.tempdir)

        def tearDown(self):
            sys.path = self.old_path

        def test_BaseImportRewrite_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os.path')]

            code = 'import os'
            tree

# Generated at 2022-06-18 00:03:28.518277
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)

    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']
    assert tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='bar', asname='foo')])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='foo', asname='foo')])])],
        orelse=[],
        finalbody=[])

# Generated at 2022-06-18 00:03:37.226085
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import os.path
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import compare_source
    from ..utils.ast_helpers import compare_ast
    from ..utils.ast_helpers import compare_source_with_ast
    from ..utils.ast_helpers import compare_ast_with_source
    from ..utils.ast_helpers import get_source_with_imports
    from ..utils.ast_helpers import get_ast_with_imports
    from ..utils.ast_helpers import compare_source_with_ast_with_imports
    from ..utils.ast_helpers import compare_

# Generated at 2022-06-18 00:03:47.719171
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import get_module_name
    from ..utils.ast_helpers import get_module_names
    from ..utils.ast_helpers import get_module_names_from_import_from
    from ..utils.ast_helpers import get_module_names_from_import_from_names
    from ..utils.ast_helpers import get_module_names_from_try_except
    from ..utils.ast_helpers import get_module_names_from_try_except_handlers
    from ..utils.ast_helpers import get_module_names_from_try_except_handler
    from ..utils.ast_helpers import get_module_names_from_try_except_handler_body

# Generated at 2022-06-18 00:03:58.814940
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_ast

    source = """
from foo import bar
from foo import baz
from foo import *
from foo import bar as baz
from foo.bar import baz
from foo.bar import baz as bar
from foo.bar import *
from foo.bar import baz as bar
from foo.bar.baz import bar
from foo.bar.baz import bar as baz
from foo.bar.baz import *
from foo.bar.baz import bar as baz
"""

# Generated at 2022-06-18 00:04:48.734925
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = ast.parse('import os')
    transformer = TestTransformer(tree)
    transformer.visit_Import(tree.body[0])
    assert astor.to_source(tree) == 'try:\n    import os\nexcept ImportError:\n    import os.path'



# Generated at 2022-06-18 00:04:53.726991
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:03.806235
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_utils import dump_ast
    from ..utils.ast_utils import parse_ast
    from ..utils.ast_utils import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast('''
    from foo import bar
    from foo import baz
    from foo import *
    from foo.bar import baz
    from foo.bar import *
    from foo.bar import baz as baz1
    from foo.bar import * as baz2
    from foo.bar.baz import baz
    from foo.bar.baz import *
    from foo.bar.baz import baz as baz1
    from foo.bar.baz import * as baz2
    ''')

    expected = parse

# Generated at 2022-06-18 00:05:15.931305
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    import_node = ast.Import(names=[ast.alias(name='foo', asname='bar')])
    import_rewrite = BaseImportRewrite(import_node)
    import_rewrite.rewrites = [('foo', 'baz')]
    import_rewrite.visit(import_node)
    assert import_rewrite._tree_changed
    assert isinstance(import_node, ast.Try)
    assert isinstance(import_node.body[0], ast.Import)
    assert import_node.body[0].names[0].name == 'baz'
    assert import_node.body[0].names[0].asname == 'bar'
    assert isinstance(import_node.handlers[0], ast.ExceptHandler)

# Generated at 2022-06-18 00:05:25.992228
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_snippet('import foo'))
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert get_snippet(tree) == get_snippet(get_snippet('''
    try:
        import foo
    except ImportError:
        import bar
    '''))



# Generated at 2022-06-18 00:05:31.011997
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(tree, '''
try:
    import foo
except ImportError:
    import bar
''')



# Generated at 2022-06-18 00:05:37.696385
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar, baz').body[0]
    import_from_rewrite = ast.parse('from foo import bar, baz').body[0]
    import_from_rewrite.names[0].name = 'bar_rewrite'
    import_from_rewrite.names[1].name = 'baz_rewrite'
    import_from_rewrite.names[1].asname = 'baz_rewrite_asname'
    import_from_rewrite = astor.to_source(import_from_rewrite)
    import_from_rewrite = astor.parse_file(import_from_rewrite)
    import_from_rewrite = import_from_rewrite.body[0]

# Generated at 2022-06-18 00:05:47.909769
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast27
    from typed_ast import ast35 as typed_ast35
    from typed_ast import ast36 as typed_ast36
    from typed_ast import ast37 as typed_ast37
    from typed_ast import ast38 as typed_ast38
    from typed_ast import ast39 as typed_ast39
    from typed_ast import ast40 as typed_ast40
    from typed_ast import ast41 as typed_ast41
    from typed_ast import ast42 as typed_ast42
    from typed_ast import ast43 as typed_ast43
    from typed_ast import ast44 as typed_ast44
    from typed_ast import ast45 as typed_ast45

# Generated at 2022-06-18 00:05:58.389089
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo")
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astor.to_source(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = ast.parse("import foo.bar")
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astor.to_source(result) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = ast.parse("import foo.bar as baz")
    transformer = TestTransformer(tree)
    result = transformer

# Generated at 2022-06-18 00:06:09.408963
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
