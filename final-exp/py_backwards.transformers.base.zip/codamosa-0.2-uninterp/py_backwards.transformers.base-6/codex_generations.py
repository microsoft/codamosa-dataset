

# Generated at 2022-06-17 23:57:23.494366
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import qux
from foo.bar.baz import *
''')

# Generated at 2022-06-17 23:57:34.315914
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation_result(
        TestTransformer,
        """
        import foo
        """,
        """
        try:
            import foo
        except ImportError:
            import bar as foo
        """)

    assert_transformation_result(
        TestTransformer,
        """
        import foo.bar
        """,
        """
        try:
            import foo.bar
        except ImportError:
            import bar.bar as foo_bar
        """)


# Generated at 2022-06-17 23:57:41.538438
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = parse_ast("""
    import foo
    """)
    expected = parse_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:57:51.631928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:58:03.327026
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies_equal(result, ['foo', 'bar'])
    assert_ast_equal(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)

# Generated at 2022-06-17 23:58:15.311115
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import unittest
    import unittest.mock

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:58:23.490872
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'import bar')

    tree = ast.parse('import foo.bar')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'import bar.bar as baz')


# Generated at 2022-06-17 23:58:27.946960
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)
    TestTransformer.transform(tree)
    assert tree.body[0].body[0].names[0].name == 'bar'



# Generated at 2022-06-17 23:58:40.066699
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-17 23:58:51.342928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == astunparse.unparse(
        ast.Try(
            body=[ast.Import(names=[ast.alias(name='foo', asname='foo')])],
            handlers=[ast.ExceptHandler(
                type=ast.Name(id='ImportError', ctx=ast.Load()),
                name=None,
                body=[ast.Import(names=[ast.alias(name='bar', asname='foo')])])],
            orelse=[],
            finalbody=[]))



# Generated at 2022-06-17 23:59:04.886889
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    sys.path.append('../../')
    from typed_astunparse import ast3unparse
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import UnparserVisitor
    from typed_astunparse.unparser import UnparserError
    from typed_astunparse.unparser import UnparserWarning
    from typed_astunparse.unparser import UnparserIndentationError
    from typed_astunparse.unparser import UnparserIndentationWarning
    from typed_astunparse.unparser import UnparserSyntaxError
    from typed_astunparse.unparser import UnparserSyntaxWarning
    from typed_astunparse.unparser import UnparserTypeError
    from typed_astunparse.unparser import UnparserTypeWarning


# Generated at 2022-06-17 23:59:11.038842
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    assert TestTransformer.transform(tree).tree == get_ast(
        'try:\n'
        '    import foo\n'
        'except ImportError:\n'
        '    import bar')



# Generated at 2022-06-17 23:59:16.878519
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-17 23:59:22.296667
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.test_helpers import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(TestImportRewrite.transform(tree).tree, expected)



# Generated at 2022-06-17 23:59:31.626641
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom
    from ..utils.snippet import test_BaseImportRewrite_visit_Import
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom_with_asname
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom_

# Generated at 2022-06-17 23:59:40.418733
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
        ]

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == astunparse.unparse(
        ast.parse(
            'try:\n'
            '    import six\n'
            'except ImportError:\n'
            '    import six.moves as six'))



# Generated at 2022-06-17 23:59:52.196540
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:00:01.108860
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = get_node('import foo')
    expected = get_node('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_node_equal(expected, TestTransformer.transform(node).tree)

    node = get_node('import foo.bar')
    expected = get_node('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_node_equal(expected, TestTransformer.transform(node).tree)

    node = get_node('import foo.bar as baz')

# Generated at 2022-06-18 00:00:09.213908
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast.ast3 import Import, alias
    from typed_ast.ast3 import Try, ExceptHandler, Name, Call, Attribute, Str, Expr, Load
    from typed_ast.ast3 import Assign, Store, Name as Name_, FunctionDef, arguments, arg
    from typed_ast.ast3 import Return, Pass, Module, parse, dump
    from typed_ast.ast3 import Assign as Assign_, Store as Store_, Load as Load_
    from typed_ast.ast3 import Name as Name__, arguments as arguments_, arg as arg_
    from typed_ast.ast3 import FunctionDef as FunctionDef_, Return as Return_, Pass as Pass_
    from typed_ast.ast3 import Module as Module_, parse

# Generated at 2022-06-18 00:00:13.505747
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import ast_from_code
    from ..utils.ast_helpers import ast_to_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast_from_code('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert ast_to_code(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:30.664035
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = '''
from six.moves import map
from six import map as six_map
from six.moves import map as moves_map
from six import (
    map as six_map,
    filter as six_filter,
)
from six.moves import (
    map as moves_map,
    filter as moves_filter,
)
from six import *
from six.moves import *
'''

# Generated at 2022-06-18 00:00:40.625451
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.test_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(TestTransformer.transform(tree).tree, expected)

    tree = get_ast('import foo.bar')
    expected = get_ast('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_ast_equal(TestTransformer.transform(tree).tree, expected)

    tree = get_ast('import foo.bar as baz')

# Generated at 2022-06-18 00:00:51.046535
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    @snippet
    def test_snippet():
        import os
        import sys
        import re
        import os.path
        import sys.path
        import re.path

    test_ast = get_ast(test_snippet)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('os', 'os.path'),
            ('sys', 'sys.path'),
            ('re', 're.path'),
        ]

    result = TestImportRewrite.transform(test_ast)
    assert result.changed


# Generated at 2022-06-18 00:00:56.066731
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:01:06.353412
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:01:11.261283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-18 00:01:22.613932
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('from six import StringIO')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies_equal(result, ['six.moves'])
    assert_ast_equal(result.tree, '''
    try:
        from six import StringIO
    except ImportError:
        from six.moves import StringIO
    ''')

    tree = ast.parse('from six.moves import StringIO')
    result = TestImport

# Generated at 2022-06-18 00:01:33.468626
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]


# Generated at 2022-06-18 00:01:43.765894
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import typing
    import six
    import six.moves
    import six.moves.urllib
    import six.moves.urllib.request
    import six.moves.urllib.parse
    import six.moves.urllib.error
    import six.moves.urllib.response
    import six.moves.urllib.robotparser
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse
    import six.moves.urllib.parse

# Generated at 2022-06-18 00:01:52.814353
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_from_source
    from ..utils.test_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'import foo'
    expected_source = 'try:\n    import foo\nexcept ImportError:\n    import bar'
    expected_ast = get_ast_node_from_source(expected_source)
    ast_node = get_ast_node_from_source(source)
    result = TestTransformer.transform(ast_node)
    assert_ast_equal(result.tree, expected_ast)


# Generated at 2022-06-18 00:02:18.593152
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:02:30.288460
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:02:38.549282
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import unittest
    import unittest.mock as mock

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.rewrites = [('os', 'os_mock')]
            self.transformer = BaseImportRewrite(None)
            self.transformer.rewrites = self.rewrites

        def test_visit_Import(self):
            import_node = ast.parse('import os').body[0]
            result = self.transformer.visit_Import(import_node)
            self.assertEqual(astor.to_source(result),
                             'try:\n    import os\nexcept ImportError:\n    import os_mock')


# Generated at 2022-06-18 00:02:42.781434
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[1].body[0].value.names[0].name == 'foo'
    assert result.changed is True


# Generated at 2022-06-18 00:02:48.381414
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_body

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(get_body(test_BaseImportRewrite_visit_Import))
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == get_body(test_BaseImportRewrite_visit_Import)


# Generated at 2022-06-18 00:02:54.758058
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']
    assert ast.dump(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:02.036020
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast_compare import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)
    expected_tree = parse_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(expected_tree, result.tree)



# Generated at 2022-06-18 00:03:11.202200
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import parse_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast('''
    from foo import bar
    from foo import baz
    from foo import *
    from foo.bar import baz
    from foo.bar import *
    from foo.bar.baz import *
    ''')


# Generated at 2022-06-18 00:03:21.071483
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = [('foo', 'bar')]

        def _get_matched_rewrite(self, name):
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None


# Generated at 2022-06-18 00:03:27.781155
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast_compare import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = parse_ast('''
    import foo
    ''')
    expected_tree = parse_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected_tree)



# Generated at 2022-06-18 00:04:19.327291
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.compare_ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)

    expected = get_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:04:25.879282
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse(snippet.get_body(test_BaseImportRewrite_visit_Import)[0])
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == snippet.get_body(test_BaseImportRewrite_visit_Import)[1]
    assert result.changed == True
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-18 00:04:35.665387
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_utils import ast_to_str
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    from foo import baz
    from foo.bar import baz
    from foo import *
    from foo.bar import *
    from foo.bar import baz as baz2
    from foo.bar import baz as baz2, *
    from foo.bar import baz as baz2, baz3
    from foo.bar import baz as baz2, baz3, *
    ''')


# Generated at 2022-06-18 00:04:47.194810
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]


# Generated at 2022-06-18 00:04:54.709026
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('requests', 'urllib.request')]


# Generated at 2022-06-18 00:05:04.419192
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )

    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_

# Generated at 2022-06-18 00:05:16.357904
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(TestImportRewrite.transform(tree).tree, expected)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_equal_ast(TestImportRewrite.transform(tree).tree, expected)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:05:27.814432
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
        import foo.bar
        import foo.bar.baz
        from foo import bar
        from foo import bar, baz
        from foo import *
        from foo.bar import baz
        from foo.bar import baz, qux
        from foo.bar import *
        from foo.bar.baz import qux
        from foo.bar.baz import qux, quux
        from foo.bar.baz import *
    ''')

    result = TestImportRewrite.transform(tree)
    assert result.changed

# Generated at 2022-06-18 00:05:32.626065
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:41.348523
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]

    source = '''
import six
'''
    expected = '''
try:
    import six
except ImportError:
    import six_mock as six
'''

    tree = get_ast_from_source(source)
    TestTransformer.transform(tree)
    assert compare_ast(tree, expected)

