

# Generated at 2022-06-17 23:57:30.069458
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_code_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert_code_equal(astor.to_source(result.tree),
                      'try:\n    import six\nexcept ImportError:\n    import six.moves as six')



# Generated at 2022-06-17 23:57:40.853925
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_node = ast.parse('import foo').body[0]
    import_node_rewrite = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo_rewrite').body[0]
    import_node_rewrite_with_as = ast.parse('try:\n    import foo as bar\nexcept ImportError:\n    import foo_rewrite as bar').body[0]

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'foo_rewrite')]

    assert astor.to_source(Test.transform(import_node).tree) == astor.to_source(import_node_rewrite)
    assert astor.to_source(Test.transform(import_node_rewrite_with_as).tree) == astor.to_source

# Generated at 2022-06-17 23:57:52.311390
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:58:00.627017
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'pathlib')]

    tree = ast.parse('import os')
    result = TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(result.tree),
                        'try:\n    import os\nexcept ImportError:\n    import pathlib')



# Generated at 2022-06-17 23:58:07.630954
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test import assert_snippet_equal

    @snippet
    def test_snippet():
        from foo import bar, baz
        from foo.bar import baz
        from foo.bar.baz import qux
        from foo.bar.baz import qux as quux
        from foo.bar.baz import qux as quux, quux as quuz
        from foo.bar.baz import *

    @snippet
    def expected_snippet():
        try:
            from foo import bar, baz
        except ImportError:
            from foo_rewrite import bar, baz
        try:
            from foo.bar import baz
        except ImportError:
            from foo_rewrite.bar import baz

# Generated at 2022-06-17 23:58:17.867065
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]

    @snippet
    def test_snippet():
        from six import iteritems
        from six.moves import range
        from six.moves.urllib.parse import urlparse

    tree = get_ast(test_snippet)
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    @snippet
    def expected_snippet():
        try:
            from six import iteritems
        except ImportError:
            from six_mock import iteritems

# Generated at 2022-06-17 23:58:28.074944
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:58:40.139753
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast, get_node_name

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.quux
    import foo.bar.baz.quux.quuux
    """)

    TestTransformer.transform(tree)

    assert get_node_name(tree.body[0]) == 'Try'
    assert get_node_name(tree.body[1]) == 'Try'
    assert get_node_name(tree.body[2]) == 'Try'
    assert get_node_name(tree.body[3]) == 'Try'
    assert get_node_name

# Generated at 2022-06-17 23:58:51.422883
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from():
        from six.moves import range

    @snippet
    def test_import_from_as():
        from six.moves import range as rng

    @snippet
    def test_import_from_multiple():
        from six.moves import range, map

    @snippet
    def test_import_from_multiple_as():
        from six.moves import range as rng, map as m


# Generated at 2022-06-17 23:59:03.175867
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestTransformer.transform(tree)

# Generated at 2022-06-17 23:59:19.482717
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import baz')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz'

    tree = get_ast('from foo import baz as baz2')
    result = TestImportRewrite.transform(tree)
    assert result.changed

# Generated at 2022-06-17 23:59:27.515306
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_snippet_body
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_snippet_body(test_BaseImportRewrite_visit_Import))
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == get_snippet_body(test_BaseImportRewrite_visit_Import)



# Generated at 2022-06-17 23:59:39.404209
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import io
    import six
    import typing
    import collections
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc as abc
    import importlib.abc as abc_alias
    import importlib.abc as abc_alias_2
    import importlib.abc as abc_alias_3
    import importlib.abc as abc_alias_4
    import importlib.abc as abc_alias_5
    import importlib.abc as abc_alias_6
    import importlib.abc as abc_alias_7
    import importlib.abc as abc_alias_8
    import importlib.abc as abc_alias_9


# Generated at 2022-06-17 23:59:45.176125
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == """
    import_rewrite(previous=foo, current=bar)
    """



# Generated at 2022-06-17 23:59:56.222090
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_transformation

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:00:06.749263
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = ast.parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = ast.parse('import foo.bar as baz')
    result = TestTransformer.transform(tree)

# Generated at 2022-06-18 00:00:17.965362
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import six
    import typing
    import collections
    import functools
    import itertools
    import operator
    import contextlib
    import re
    import json
    import inspect
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc


# Generated at 2022-06-18 00:00:24.004035
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    assert_transformation_result(TestTransformer, tree, """
try:
    import foo
except ImportError:
    import bar
""")



# Generated at 2022-06-18 00:00:30.961684
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import BaseNodeTransformer
    from ..utils.snippet import BaseTransformer
    from ..utils.snippet import TransformationResult
    from ..utils.snippet import CompilationTarget
    from ..utils.snippet import List
    from ..utils.snippet import Tuple
    from ..utils.snippet import Union
    from ..utils.snippet import Optional
    from ..utils.snippet import Iterable
    from ..utils.snippet import Dict
    from ..utils.snippet import snippet

# Generated at 2022-06-18 00:00:40.837220
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = get_ast("from a import c")
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == "try:\n    from a import c\nexcept ImportError:\n    from b import c"

    tree = get_ast("from a import c as d")
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == "try:\n    from a import c as d\nexcept ImportError:\n    from b import c as d"

    tree = get_ast("from a.b import c")
    result = TestImportRew

# Generated at 2022-06-18 00:00:59.680576
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)

    assert isinstance(result, ast.Try)
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'foo'
    assert isinstance(result.body[1], ast.Import)
    assert result.body[1].names[0].name == 'bar'



# Generated at 2022-06-18 00:01:08.289347
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(snippet(
        '''
        import foo
        '''
    ))
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == snippet(
        '''
        try:
            import foo
        except ImportError:
            import bar
        '''
    )



# Generated at 2022-06-18 00:01:19.690149
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from ..transformers import BaseImportRewrite
    from ..utils.snippet import snippet, extend
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves')
        ]


# Generated at 2022-06-18 00:01:25.087365
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(TestImportRewrite.transform(tree).tree, expected)



# Generated at 2022-06-18 00:01:35.778582
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    from foo import bar
    from foo import baz
    from foo.bar import baz
    from foo.bar import qux
    from foo.bar import quux as qux
    from foo.bar import quuz as qux
    from foo.bar import quuz as quux
    from foo.bar import quuz as quuz
    from foo.bar import quuz as quuz
    from foo.bar import quuz as quuz
    """)

    result = TestTransformer.transform(tree)
    assert result.changed


# Generated at 2022-06-18 00:01:44.815245
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_from_source

    source = """
    import os
    import sys
    import six
    """

    tree = get_ast_from_source(source)
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    result = TestImportRewrite.transform(tree)
    assert result.changed

    expected = """
    import os
    import sys
    try:
        import six
    except ImportError:
        import six.moves as six
    """

    assert astor.to_source(result.tree) == expected



# Generated at 2022-06-18 00:01:50.168716
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(snippet(
        '''
        import foo
        '''
    ))

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == snippet(
        '''
        try:
            import foo
        except ImportError:
            import bar
        '''
    )



# Generated at 2022-06-18 00:01:57.298820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import baz')
    expected = ast.parse('''
try:
    from foo import baz
except ImportError:
    from bar import baz
    ''')

    result = TestImportRewrite.transform(tree)
    assert_ast_equal(result.tree, expected)



# Generated at 2022-06-18 00:02:07.083704
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.test_helpers import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    @snippet
    def test_snippet():
        import old
        import old.submodule
        import old.submodule.subsubmodule
        import old.submodule.subsubmodule.subsubsubmodule


# Generated at 2022-06-18 00:02:14.359814
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast, get_code
    from ..utils.compat import IS_PY2

    class BaseImportRewriteTest(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_data_dir = os.path.join(self.test_dir, 'data')
            self.test_data_dir = os.path.join(self.test_data_dir, 'BaseImportRewrite')
            self.test_data_dir = os.path.join

# Generated at 2022-06-18 00:02:59.466629
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:03:09.669423
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.snippet import snippet_test
    from ..utils.ast import parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = parse("""
    import six
    """)
    snippet_test(TestTransformer.transform, tree, """
    try:
        import six
    except ImportError:
        import six.moves as six
    """)

    tree = parse("""
    import six.moves
    """)
    snippet_test(TestTransformer.transform, tree, """
    try:
        import six.moves
    except ImportError:
        import six.moves as six.moves
    """)

    tree = parse("""
    import six.moves.urllib
    """)
    snippet_

# Generated at 2022-06-18 00:03:20.010063
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = ImportRewrite.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']
    assert astor.to_source(result.tree) == astor.to_source(import_rewrite.get_body(previous=tree, current=get_ast('import bar'))[0])


# Generated at 2022-06-18 00:03:26.190337
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    @snippet
    def test_snippet():
        import old

    tree = ast.parse(test_snippet.get_body())
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == test_snippet.get_body(rewrite=True)



# Generated at 2022-06-18 00:03:36.613473
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import snippet_to_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    from foo import baz
    from foo import *
    from foo.bar import baz
    from foo.bar import *
    from foo.bar.baz import *
    from foo.bar.baz import baz
    ''')


# Generated at 2022-06-18 00:03:44.440288
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:50.044297
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    @snippet
    def test_snippet():
        import old.module
        import old.module as module
        import old.module as new_module

    tree = ast.parse(test_snippet.get_source())
    expected_tree = ast.parse(test_snippet.get_source())
    expected_tree.body[0] = ast.parse(
        'try:\n'
        '    import old.module\n'
        'except ImportError:\n'
        '    import new.module\n'
    ).body[0]

# Generated at 2022-06-18 00:03:54.665562
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-18 00:04:06.087577
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
import foo.bar
import foo.bar.baz
import foo.bar.baz.qux
''')

    transformed = TestTransformer.transform(tree)

# Generated at 2022-06-18 00:04:10.422189
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'pathlib')]

    tree = ast.parse('import os')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import os\nexcept ImportError:\n    import pathlib as os'



# Generated at 2022-06-18 00:05:03.508529
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = ast.parse(test_snippet.get_body())
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert astor.to_source(tree) == """
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar

try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz
"""



# Generated at 2022-06-18 00:05:08.595585
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-18 00:05:18.522179
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = ast.parse('''
import os
import os.path
import os.path.join
import os.path.join as join

import sys
import sys.path
import sys.path.join
import sys.path.join as join
''')


# Generated at 2022-06-18 00:05:29.482333
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import io
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(ast.AST, 'assertAstEqual')

        def assertAstEqual(self, node1, node2, msg=None):
            if not isinstance(node1, ast.AST) or not isinstance(node2, ast.AST):
                self.fail('ASTs expected')


# Generated at 2022-06-18 00:05:36.770992
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    @snippet
    def test_import_from():
        from datetime import datetime
        from datetime import date
        from datetime import time
        from datetime import timedelta
        from datetime import tzinfo
        from datetime import timezone
        from datetime import timezone as tz
        from datetime import timezone as tz2
        from datetime import timezone as tz3
        from datetime import timezone as tz4
        from datetime import timezone as tz5
        from datetime import timezone as tz6
        from datetime import timezone as tz7
        from datetime import timezone as tz8
        from datetime import timezone as tz9

# Generated at 2022-06-18 00:05:47.686928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import astunparse
    import astor
    import ast
    import sys


# Generated at 2022-06-18 00:05:58.190088
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import test_BaseImportRewrite_visit_ImportFrom
    import test_BaseImportRewrite_visit_ImportFrom_rewrite
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_2
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_3
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_4
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_5
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_6
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_7

# Generated at 2022-06-18 00:06:09.229080
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux'),
        ]


# Generated at 2022-06-18 00:06:12.829494
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(result.tree),
                        'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:06:18.598741
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(result.tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

