

# Generated at 2022-06-17 23:57:26.835635
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast
    from ..utils.compat import StringIO
    from ..utils.compat import PY2
    from ..utils.compat import PY3
    from ..utils.compat import PY35
    from ..utils.compat import PY36
    from ..utils.compat import PY37
    from ..utils.compat import PY38
    from ..utils.compat import PY39
    from ..utils.compat import PY310
    from ..utils.compat import PY311
    from ..utils.compat import PY312
    from ..utils.compat import PY313

# Generated at 2022-06-17 23:57:30.681363
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:57:41.917359
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from test_BaseImportRewrite import BaseImportRewrite
    from test_BaseImportRewrite import BaseNodeTransformer
    from test_BaseImportRewrite import BaseTransformer
    from test_BaseImportRewrite import import_rewrite
    from test_BaseImportRewrite import snippet
    from test_BaseImportRewrite import extend
    from test_BaseImportRewrite import test_BaseImportRewrite_visit_ImportFrom
    from test_BaseImportRewrite import test_BaseImportRewrite_visit_Import
    from test_BaseImportRewrite import test_BaseImportRewrite_visit_ImportFrom_with_asname
    from test_BaseImportRewrite import test_BaseImportRewrite_

# Generated at 2022-06-17 23:57:53.159747
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_code():
        from foo import baz
        from foo import bar as baz
        from foo.bar import baz
        from foo.bar import baz as bar
        from foo.bar import *

    tree = get_ast(test_code)
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    @snippet
    def expected_code():
        try:
            from foo import baz
        except ImportError:
            from bar import baz

# Generated at 2022-06-17 23:58:04.742136
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    test_BaseImportRewrite_visit_ImportFrom.__globals__['BaseImportRewrite'] = BaseImportRewrite
    test_BaseImportRewrite_visit_ImportFrom.__globals__['ast'] = ast
    test_BaseImportRewrite_visit_ImportFrom.__globals__['astor'] = astor
    test_BaseImportRewrite_visit_ImportFrom.__globals__['sys'] = sys
    test_BaseImportRewrite_visit_ImportFrom.__globals__

# Generated at 2022-06-17 23:58:09.851146
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_not_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six')
        ]

    tree = ast.parse('''
from six.moves import map
from six.moves import map as m
from six import map
from six import map as m
from six import *
from six.moves import *
from six.moves import map, filter
from six.moves import map as m, filter as f
from six import map, filter
from six import map as m, filter as f
''')


# Generated at 2022-06-17 23:58:16.005882
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from_module():
        from six import moves
        from six.moves import urllib

    @snippet
    def test_import_from_module_rewrite():
        try:
            from six import moves
        except ImportError:
            from six.moves import moves
        try:
            from six.moves import urllib
        except ImportError:
            from six.moves import urllib

    @snippet
    def test_import_from_names():
        from six import moves as m

# Generated at 2022-06-17 23:58:23.604355
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast import ast_to_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    import foo.bar
    import foo.bar.baz
    """)

    expected = """
    try:
        import foo
    except ImportError:
        import bar
    try:
        import foo.bar
    except ImportError:
        import bar.bar
    try:
        import foo.bar.baz
    except ImportError:
        import bar.bar.baz
    """

    result = TestTransformer.transform(tree)
    assert ast_to_source(result.tree) == expected


# Generated at 2022-06-17 23:58:35.151570
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from . import BaseImportRewrite
    from ..utils.snippet import snippet

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from_module():
        from foo import baz

    @snippet
    def test_import_from_module_rewrote():
        try:
            from foo import baz
        except ImportError:
            from bar import baz

    @snippet
    def test_import_from_names():
        from foo import baz, qux

    @snippet
    def test_import_from_names_rewrote():
        try:
            from foo import baz
        except ImportError:
            from bar import baz

# Generated at 2022-06-17 23:58:43.372812
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_snippet_body(test_BaseImportRewrite_visit_Import))
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'bar'
    assert result.body[0].names[0].asname == 'foo'
    assert isinstance(result.body[1], ast.Import)
   

# Generated at 2022-06-17 23:59:01.517371
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_BaseImportRewrite import BaseImportRewrite
    from .test_BaseImportRewrite import BaseNodeTransformer
    from .test_BaseImportRewrite import BaseTransformer
    from .test_BaseImportRewrite import import_rewrite
    from .test_BaseImportRewrite import snippet
    from .test_BaseImportRewrite import extend
    from .test_BaseImportRewrite import test_BaseImportRewrite_visit_ImportFrom
    from .test_BaseImportRewrite import test_BaseImportRewrite_visit_Import
    from .test_BaseImportRewrite import test_BaseImportRewrite_visit_ImportFrom_with_names


# Generated at 2022-06-17 23:59:12.750172
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast.ast3 import Import
    from typed_ast.ast3 import Try
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import alias
    from typed_ast.ast3 import Assign
    from typed_ast.ast3 import Store
    from typed_ast.ast3 import ExceptHandler
    from typed_ast.ast3 import Name as Name2
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Attribute
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import keyword
    from typed_ast.ast3 import Str
    from typed_ast.ast3 import Subscript
    from typed_ast.ast3 import Index

# Generated at 2022-06-17 23:59:21.842122
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast
    from ..utils.ast_helpers import get_node_type
    from ..utils.ast_helpers import get_node_name
    from ..utils.ast_helpers import get_node_value
    from ..utils.ast_helpers import get_node_lineno
    from ..utils.ast_helpers import get_node_col_offset
    from ..utils.ast_helpers import get_node_end_lineno
    from ..utils.ast_helpers import get_node_end_col_offset
    from ..utils.ast_helpers import get_node_children
    from ..utils.ast_helpers import get_node_fields
    from ..utils.ast_helpers import get_node_attr
   

# Generated at 2022-06-17 23:59:31.323406
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.snippet import snippet
    from ..utils.ast import parse
    import ast

    import_rewrite = snippet('''
    try:
        extend(previous)
    except ImportError:
        extend(current)
    ''')

    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = [('six', 'six.moves')]

        def _get_matched_rewrite(self, name):
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None


# Generated at 2022-06-17 23:59:41.671780
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]


# Generated at 2022-06-17 23:59:53.262161
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:59:59.132725
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse("""
try:
    import foo
except ImportError:
    import bar
""")

    TestTransformer.transform(tree)
    assert_ast_equal(tree, expected)



# Generated at 2022-06-18 00:00:06.350557
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import test_BaseImportRewrite_visit_ImportFrom
    import test_BaseImportRewrite_visit_ImportFrom_rewrite
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_as
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_as_from_module
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_as_from_module_from_name
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_as_from_module_from_name_from_name
    import test_BaseImportRewrite_visit_ImportFrom_rewrite_

# Generated at 2022-06-18 00:00:17.930715
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..transformers.base import BaseImportRewrite

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("""
    from foo import bar
    from foo import baz as qux
    from foo import *
    from foo.bar import baz
    from foo.bar import qux as quux
    from foo.bar import *
    from foo.bar.baz import qux
    from foo.bar.baz import quux as quuz
    from foo.bar.baz import *
    """)

    TestTransformer.transform(tree)


# Generated at 2022-06-18 00:00:28.547984
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_BaseImportRewrite import BaseImportRewrite
    from .test_BaseImportRewrite import test_BaseImportRewrite_visit_ImportFrom
    from .test_BaseImportRewrite import BaseNodeTransformer
    from .test_BaseImportRewrite import BaseTransformer
    from .test_BaseImportRewrite import snippet
    from .test_BaseImportRewrite import extend
    from .test_BaseImportRewrite import import_rewrite
    from .test_BaseImportRewrite import test_BaseImportRewrite_visit_Import
    from .test_BaseImportRewrite import BaseImportRewrite
    from .test_BaseImportRewrite import BaseNode

# Generated at 2022-06-18 00:00:51.767063
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz.qux
    ''')


# Generated at 2022-06-18 00:00:58.220083
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'foo'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'bar'
    assert result.changed is True
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-18 00:01:09.544198
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:01:20.968366
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('foo.bar', 'baz.bar')
        ]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo as bar')
    expected = ast.parse('''
try:
    import foo as bar
except ImportError:
    import bar as bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)


# Generated at 2022-06-18 00:01:28.285145
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    expected_tree = ast.parse('''
try:
    import six
except ImportError:
    import six.moves as six
''')

    assert_equal_ast(expected_tree, TestImportRewrite.transform(tree).tree)



# Generated at 2022-06-18 00:01:33.131966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit_Import(tree.body[0])
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(astor.to_source(result), astor.to_source(expected))



# Generated at 2022-06-18 00:01:43.396821
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:01:53.659302
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, extend
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse(
        """
        import six
        """
    )

    expected = ast.parse(
        """
        try:
            extend(ast.Import(names=[ast.alias(name='six', asname='six')]))
        except ImportError:
            extend(ast.Import(names=[ast.alias(name='six.moves', asname='six')]))
        """
    )

    result = Test

# Generated at 2022-06-18 00:02:00.290573
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import_node = ast.parse('import foo').body[0]
    import_node_rewrite = ast.parse('import foo_rewrite').body[0]
    import_node_rewrite_try = ast.parse('try:\n    import foo_rewrite\nexcept ImportError:\n    import foo').body[0]
    import_node_rewrite_try_expected = astor.to_source(import_node_rewrite_try)
    import_node_rewrite_try_actual = astor.to_source(BaseImportRewrite(None)._replace_import(import_node, 'foo', 'foo_rewrite'))
    assert import_node_rewrite_try_expected == import_node_rewrite_try_actual


# Generated at 2022-06-18 00:02:07.797568
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = 'import foo'
    expected_code = 'try:\n    import foo\nexcept ImportError:\n    import bar'
    tree = ast.parse(code)
    result = TestTransformer.transform(tree)
    assert_equal_ast(result.tree, expected_code)
    assert_equal_code(result.tree, expected_code)



# Generated at 2022-06-18 00:02:36.558788
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse("""
try:
    import foo
except ImportError:
    import bar
""")

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:02:47.496131
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import io
    import tempfile
    import unittest
    import unittest.mock
    import types
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc

# Generated at 2022-06-18 00:02:57.746257
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestTransformer.transform(tree)
    assert_source_

# Generated at 2022-06-18 00:03:08.748440
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:03:19.191967
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestImportRewrite.transform(tree)
    assert_source_

# Generated at 2022-06-18 00:03:27.840133
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]

    tree = snippet_to_ast('''
    from six import iteritems
    from six.moves import range
    from six.moves.urllib.parse import urlparse
    from six.moves.urllib.parse import urlparse as parse_url
    from six.moves.urllib.parse import *
    ''')


# Generated at 2022-06-18 00:03:36.939112
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_utils import get_ast_from_source
    from ..utils.snippet import get_snippet_body

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = '''
    from six import StringIO
    from six.moves import StringIO as StringIO2
    from six.moves import StringIO as StringIO3
    '''

    expected = '''
    try:
        from six import StringIO
    except ImportError:
        from six.moves import StringIO
    from six.moves import StringIO as StringIO2
    from six.moves import StringIO as StringIO3
    '''

    tree = get_ast_from_source(source)

# Generated at 2022-06-18 00:03:47.694326
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import old\nexcept ImportError:\n    import new'

    tree = ast.parse('import old.sub')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import old.sub\nexcept ImportError:\n    import new.sub'

    tree = ast.parse('import old.sub as sub')
    result = TestImportRewrite.transform(tree)
   

# Generated at 2022-06-18 00:03:53.843950
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-18 00:04:02.393748
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
import foo.bar
import foo.bar.baz
''')
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == '''
try:
    import foo
except ImportError:
    import bar
try:
    import foo.bar
except ImportError:
    import bar.bar
try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz
'''



# Generated at 2022-06-18 00:05:03.433986
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    from . import BaseImportRewrite
    from ..utils.snippet import snippet

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves')
        ]

    @snippet
    def test_import_from():
        from six.moves import urllib
        from six.moves import urllib as urllib_alias
        from six.moves import urllib as urllib_alias2, urllib2 as urllib2_alias

# Generated at 2022-06-18 00:05:15.602720
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_node = ast.parse('import foo')
    import_rewrite_node = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo2')
    import_rewrite_node_2 = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo2 as foo')
    import_rewrite_node_3 = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import foo2.bar')
    import_rewrite_node_4 = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import foo2.bar as bar')
    import_rewrite_node_5 = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import foo2.bar as bar')


# Generated at 2022-06-18 00:05:27.411339
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast import dump_ast
    from ..utils.test import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed

# Generated at 2022-06-18 00:05:34.339348
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_code_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = ast.parse(test_snippet.get_source())
    TestTransformer.transform(tree)
    assert_code_equal(astor.to_source(tree),
                      test_snippet.get_source(rewrote=True))



# Generated at 2022-06-18 00:05:43.147923
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    @snippet
    def test(a):
        import a
        return a

    tree = parse_ast(test)
    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['b']

# Generated at 2022-06-18 00:05:49.449525
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('..')
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast
    from ..transformers.base import BaseImportRewrite
    from ..transformers.base import import_rewrite

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves')
        ]


# Generated at 2022-06-18 00:05:58.730353
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar').body[0]
    import_from_rewrite = ast.parse('from foo import bar').body[0]
    import_from_rewrite.names[0].name = 'baz'
    import_from_rewrite.names[0].asname = 'bar'
    import_from_rewrite = ast.Try(body=[import_from_rewrite],
                                  handlers=[ast.ExceptHandler(type=None,
                                                              name=None,
                                                              body=[import_from])],
                                  orelse=[],
                                  finalbody=[])

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:06:09.579904
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz
        from foo import bar
        from foo import bar, baz
        from foo.bar import baz
        from foo.bar import baz, qux
        from foo.bar.baz import qux

    test_snippet_ast = get_ast(test_snippet)


# Generated at 2022-06-18 00:06:15.820938
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.compare_ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
    ''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:06:26.161265
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import typing
    import six
    import enum
    import collections
    import functools
    import itertools
    import operator
    import contextlib
    import tempfile
    import shutil
    import subprocess
    import multiprocessing
    import threading
    import concurrent.futures
    import asyncio
    import aiohttp
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.response
    import urllib.robotparser
    import http.client
    import http.server
    import http.cookies
    import http.cookiejar
    import email.message
    import email.utils
    import xmlrpc.client
    import xmlrpc.server