

# Generated at 2022-06-17 23:57:34.707866
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('../../')
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser

# Generated at 2022-06-17 23:57:43.079896
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='foo', asname='foo')])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='bar', asname='foo')])])],
        orelse=[],
        finalbody=[])
    assert result.changed



# Generated at 2022-06-17 23:57:53.545421
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Import, alias
    from typed_ast.ast3 import Try, ExceptHandler, Name, Load, Str, ImportFrom
    from typed_ast.ast3 import Assign, Store, Name as Name_
    from typed_ast.ast3 import FunctionDef, arguments, arg, Return, Call, Attribute
    from typed_ast.ast3 import Assign, Store, Name as Name_
    from typed_ast.ast3 import FunctionDef, arguments, arg, Return, Call, Attribute
    from typed_ast.ast3 import Assign, Store, Name as Name_
    from typed_ast.ast3 import FunctionDef, arguments, arg, Return, Call, Attribute
    from typed_ast.ast3 import Assign, Store, Name as Name

# Generated at 2022-06-17 23:58:04.989528
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo']

# Generated at 2022-06-17 23:58:09.986261
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestImportRewrite(tree)
    transformer.visit(tree)

    expected = ast.parse(astor.to_source(import_rewrite.get_body(previous=ast.parse('import foo'),  # type: ignore
                                                                 current=ast.parse('import bar'))))  # type: ignore

# Generated at 2022-06-17 23:58:16.297718
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == snippet(
        '''
        try:
            import foo
        except ImportError:
            import bar
        '''
    )

    tree = ast.parse('import foo.bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == snippet(
        '''
        try:
            import foo.bar
        except ImportError:
            import bar.bar
        '''
    )


# Generated at 2022-06-17 23:58:23.899104
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_snippet():
        from six.moves import urllib
        from six.moves.urllib import request
        from six.moves.urllib.request import urlopen
        from six.moves.urllib.request import urlretrieve
        from six.moves.urllib.request import urlcleanup
        from six.moves.urllib.request import url2pathname
        from six.moves.urllib.request import pathname2url
        from six.moves.urllib.request import getproxies
        from six.moves.urllib.request import proxy_bypass

# Generated at 2022-06-17 23:58:35.499409
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('from six import moves')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == '''
try:
    from six import moves
except ImportError:
    from six.moves import moves
'''

    tree = get_ast('from six.moves import moves')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == '''
try:
    from six.moves import moves
except ImportError:
    from six.moves import moves
'''


# Generated at 2022-06-17 23:58:43.554019
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.test_utils import assert_equal_ast

    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:58:53.823525
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import io
    import tempfile
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.py')

# Generated at 2022-06-17 23:59:05.459937
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = '''
    from six import StringIO
    from six.moves import StringIO as StringIO2
    from six.moves import StringIO as StringIO3
    from six.moves import StringIO as StringIO4
    from six.moves import StringIO as StringIO5
    '''


# Generated at 2022-06-17 23:59:16.089814
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import baz')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz'

    tree = get_ast('from foo import *')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    from foo import *\nexcept ImportError:\n    from bar import *'


# Generated at 2022-06-17 23:59:26.573986
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six.moves.urllib'),
            ('six.moves.urllib.parse', 'urllib.parse'),
            ('six.moves.urllib.request', 'urllib.request'),
        ]

    @snippet
    def test_import_from():
        from six.moves import urllib
        from six.moves.urllib.parse import urlparse
        from six.moves.urllib.request import urlopen


# Generated at 2022-06-17 23:59:33.457989
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import compare_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
    from foo import bar
    from foo import baz as qux
    from foo import *
    from foo.qux import quux
    from foo.qux import quuz as corge
    from foo.qux import *
    from foo.qux.corge import grault
    from foo.qux.corge import garply as waldo
    from foo.qux.corge import *
    '''

# Generated at 2022-06-17 23:59:42.871316
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_node_by_path

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = get_ast('import os')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(tree) == 'try:\n    import os\nexcept ImportError:\n    import os.path'

    tree = get_ast('from os import path')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(tree) == 'try:\n    from os import path\nexcept ImportError:\n    from os.path import path'

   

# Generated at 2022-06-17 23:59:49.903417
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-17 23:59:59.443014
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import ast
    import sys
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import extend_import
    from ..utils.snippet import extend_import_from
    from ..utils.snippet import extend_import_from_as
    from ..utils.snippet import extend_import_from_as_as
    from ..utils.snippet import extend_import_from_as_as_as
    from ..utils.snippet import extend_import_from_as_as_as_as
    from ..utils.snippet import extend_import_from_as_as_as_as_as
    from ..utils.snippet import extend_import_from_as_as_as_as_as_

# Generated at 2022-06-18 00:00:08.360567
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite import BaseImportRewrite
    from test_BaseImportRewrite import BaseNodeTransformer
    from test_BaseImportRewrite import BaseTransformer
    from test_BaseImportRewrite import import_rewrite
    from test_BaseImportRewrite import snippet
    from test_BaseImportRewrite import extend
    from test_BaseImportRewrite import TransformationResult
    from test_BaseImportRewrite import CompilationTarget
    from test_BaseImportRewrite import ABCMeta
    from test_BaseImportRewrite import abstractmethod
    from test_BaseImportRewrite import List
    from test_BaseImportRewrite import Tuple

# Generated at 2022-06-18 00:00:18.125651
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast
    from ..utils.source_helpers import get_source_from_snippet
    from ..utils.source_helpers import get_source_from_snippet_and_ast
    from ..utils.source_helpers import get_source_from_snippet_and_source
    from ..utils.source_helpers import get_source_from_snippet_and_ast_and_source
    from ..utils.source_helpers import get_source_from_snippet_and_source_and_ast
    from ..utils.source_helpers import get_source_from_snippet

# Generated at 2022-06-18 00:00:28.550265
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.test_helpers import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]

    tree = get_ast('from six import text_type')
    expected = get_ast("""
try:
    from six import text_type
except ImportError:
    from six_mock import text_type
""")
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = get_ast('from six.moves import StringIO')

# Generated at 2022-06-18 00:00:59.105369
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    new_tree = TestImportRewrite.transform(tree).tree
    assert isinstance(new_tree.body[0], ast.Try)
    assert isinstance(new_tree.body[0].body[0], ast.Import)
    assert new_tree.body[0].body[0].names[0].name == 'bar'
    assert new_tree.body[0].body[0].names[0].asname == 'foo'
    assert isinstance(new_tree.body[0].handlers[0].type, ast.Name)

# Generated at 2022-06-18 00:01:10.213469
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    import astor
    import sys
    import os
    import io
    import tempfile

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]


# Generated at 2022-06-18 00:01:19.213244
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_ast

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source("""
    import foo
    """)
    result = ImportRewrite.transform(tree)
    assert result.changed
    assert get_source_from_ast(result.tree) == """
    try:
        import foo
    except ImportError:
        import bar
    """



# Generated at 2022-06-18 00:01:29.985489
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:01:39.847028
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.snippet import snippet

    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(
        """
        import foo
        """
    )
    TestTransformer.transform(tree)

    expected = ast.parse(
        """
        try:
            extend(import foo)
        except ImportError:
            extend(import bar)
        """
    )

    assert astor.to_source(tree) == astor.to_source(expected)


# Generated at 2022-06-18 00:01:45.716175
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:01:56.102373
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:02:06.937021
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('from six import StringIO')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == 'try:\n    from six.moves import StringIO\nexcept ImportError:\n    from six import StringIO'

    tree = get_ast('from six import StringIO, StringIO as StringIO2')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == 'try:\n    from six.moves import StringIO, StringIO as StringIO2\nexcept ImportError:\n    from six import StringIO, StringIO as StringIO2'

# Generated at 2022-06-18 00:02:14.340079
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from_module():
        from six import moves
        from six import string_types

    @snippet
    def expected_import_from_module():
        try:
            from six import moves
        except ImportError:
            from six.moves import moves
        from six import string_types

    @snippet
    def test_import_from_names():
        from six import string_types
        from six import moves


# Generated at 2022-06-18 00:02:19.957708
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    expected = ast.parse('''
try:
    import old
except ImportError:
    import new
''')

    assert_equal_ast(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:02:52.022289
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.testing import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("""
from foo import baz
from foo.bar import baz
from foo.bar.baz import baz
from foo.bar.baz import *
from foo.bar.baz import baz as baz2
from foo.bar.baz import * as baz3
""")


# Generated at 2022-06-18 00:02:59.515066
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    import unittest.mock

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            import_node = ast.parse('import foo').body[0]
            import_rewrite_node = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo_rewrite').body[0]
            import_rewrite_node_with_as = ast.parse('try:\n    import foo as foo_rewrite\nexcept ImportError:\n    import foo_rewrite').body[0]

# Generated at 2022-06-18 00:03:06.681372
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    expected = ast.parse('''
try:
    import six
except ImportError:
    import six.moves as six
''')

    assert_equal_ast(TestImportRewrite.transform(tree).tree, expected)



# Generated at 2022-06-18 00:03:17.661863
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast
    from ..utils.compat import get_ast_from_text

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
        import foo.bar
        import foo.bar.baz
    ''')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:03:23.221101
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar').body[0]
    assert isinstance(import_from, ast.ImportFrom)
    import_from.names[0].name = 'foo'
    import_from.names[0].asname = 'bar'
    import_from.module = 'foo'
    import_from.level = 0
    import_from.col_offset = 0
    import_from.lineno = 1
    import_from.end_col_offset = 0
    import_from.end_lineno = 1
    import_from.type_ignores = []
    import_from.col_offset = 0
    import_from.lineno = 1
    import_from.end_col_offset = 0
    import_from.end_lineno = 1

# Generated at 2022-06-18 00:03:29.750929
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_node_of_class
    from ..utils.ast_helpers import get_node_of_class_by_name
    from ..utils.ast_helpers import get_node_of_class_by_name_and_attr
    from ..utils.ast_helpers import get_node_of_class_by_name_and_attr_value
    from ..utils.ast_helpers import get_node_of_class_by_attr_value
    from ..utils.ast_helpers import get_node_of_class_by_attr
    from ..utils.ast_helpers import get_node_of_class_by_attr_value_and_parent_class
    from ..utils.ast_helpers import get_node_of

# Generated at 2022-06-18 00:03:36.749963
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast, compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)
    expected_tree = get_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_asts(result.tree, expected_tree)



# Generated at 2022-06-18 00:03:46.193298
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils import get_ast_node
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_node('import foo')
    expected = get_ast_node('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert_ast_equal(expected, result.tree)



# Generated at 2022-06-18 00:03:57.410669
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    import sys
    sys.modules['typed_ast'] = typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast

# Generated at 2022-06-18 00:04:08.536986
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal, assert_tree_changed, assert_dependencies

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies(result, ['six.moves'])
    assert_ast_equal(result.tree, 'try:\n    import six\nexcept ImportError:\n    import six.moves as six')

    tree = ast.parse('import six.moves')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies(result, ['six.moves'])
    assert_ast_

# Generated at 2022-06-18 00:05:03.674873
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:05:14.935098
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.baz

    tree = ast.parse(test_snippet.get_source())
    assert astor.to_source(tree) == test_snippet.get_source()

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == test_snippet.get_source().replace('foo', 'bar')



# Generated at 2022-06-18 00:05:20.354943
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.source_helpers import source_to_ast
    from ..utils.source_helpers import source_to_ast_and_code
    from ..utils.source_helpers import source_to_code
    from ..utils.source_helpers import source_to_code_and_ast
    from ..utils.source_helpers import source_to_code_and_tree
    from ..utils.source_helpers import source_to_tree
    from ..utils.source_helpers import source_to_tree_and_code
    from ..utils.source_helpers import source_to_tree_and_source
    from ..utils.source_helpers import source_to_tree_and_tree

# Generated at 2022-06-18 00:05:30.573744
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:05:36.358269
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:47.402691
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:05:57.148310
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_utils import get_ast
    from ..utils.source_utils import get_source
    from ..utils.source_utils import get_source_lines

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = get_source(__file__, 'test_BaseImportRewrite_visit_Import')
    tree = get_ast(source)
    result = TestTransformer.transform(tree)
    assert result.changed

    expected = get_source_lines(__file__, 'test_BaseImportRewrite_visit_Import_expected')
    assert expected == get_source_lines(result.tree)



# Generated at 2022-06-18 00:06:08.426629
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_node = ast.parse('import foo').body[0]
    import_node_rewrite = ast.parse('import foo_rewrite').body[0]
    import_node_rewrite_try = ast.parse('try:\n    import foo_rewrite\nexcept ImportError:\n    import foo').body[0]
    import_node_rewrite_try_str = 'try:\n    import foo_rewrite\nexcept ImportError:\n    import foo'
    import_node_rewrite_try_str_expected = 'try:\n    import foo_rewrite\nexcept ImportError:\n    import foo'

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'foo_rewrite')]


# Generated at 2022-06-18 00:06:14.291333
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite import BaseImportRewrite
    from test_BaseImportRewrite import BaseNodeTransformer
    from test_BaseImportRewrite import BaseTransformer
    from test_BaseImportRewrite import import_rewrite
    from test_BaseImportRewrite import snippet
    from test_BaseImportRewrite import extend
    from test_BaseImportRewrite import TransformationResult
    from test_BaseImportRewrite import CompilationTarget
    from test_BaseImportRewrite import ABCMeta
    from test_BaseImportRewrite import abstractmethod
    from test_BaseImportRewrite import List
    from test_BaseImportRewrite import Tuple

# Generated at 2022-06-18 00:06:20.513015
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)

