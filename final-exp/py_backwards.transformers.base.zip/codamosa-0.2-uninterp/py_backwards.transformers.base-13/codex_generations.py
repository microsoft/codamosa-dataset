

# Generated at 2022-06-17 23:57:30.105414
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import ast_to_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert ast_to_source(result) == 'try:\n    import bar\nexcept ImportError:\n    import foo'



# Generated at 2022-06-17 23:57:37.145053
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert_ast_equal(result.tree, expected)
    assert result.changed



# Generated at 2022-06-17 23:57:44.514844
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar

    tree = get_ast(test_snippet)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == '''
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar
'''



# Generated at 2022-06-17 23:57:50.457518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)
    TestImportRewrite.transform(tree)
    assert tree.body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-17 23:57:56.199944
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_code

    @snippet
    def code():
        from module import name1, name2
        from module import name3, name4

    tree = ast.parse(code.get_body())
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('module', 'new_module')]
    transformer.visit(tree)

    expected = """
    try:
        from module import name1, name2
    except ImportError:
        from new_module import name1, name2
    try:
        from module import name3, name4
    except ImportError:
        from new_module import name3, name4
    """

# Generated at 2022-06-17 23:58:01.889889
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)

    assert ast.dump(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:58:08.317543
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:58:18.473910
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    from ..utils.snippet import snippet, extend

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:58:29.234465
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.compiler import compile_snippet

    @snippet
    def test_snippet(a):
        import os
        import sys
        import os.path
        import sys.path
        import os.path.join
        import sys.path.join

    tree = ast.parse(test_snippet.get_source())
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('os', 'os.path'),
            ('sys', 'sys.path'),
        ]

    TestImportRewrite.transform(tree)
    code = compile_snippet(astor.to_source(tree), 'test_snippet')
    assert code.test_snippet(1) == 1


# Unit

# Generated at 2022-06-17 23:58:40.755439
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import compare_ast
    from ..utils.ast_helpers import compare_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    from foo import a, b
    from foo.bar import c
    from foo.bar.baz import d
    from foo.bar.baz import e as f
    from foo.bar.baz import *
    from foo import g
    from foo import h as i
    from foo import *
    """)

# Generated at 2022-06-17 23:58:56.413286
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
import foo
import foo.bar
import foo.bar.baz
import foo.bar.baz.qux
'''
    tree = get_ast_from_source(source)
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo']

# Generated at 2022-06-17 23:59:03.195410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')

    result = TestImportRewrite.transform(tree)

    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:59:09.918771
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(result.tree),
                        'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-17 23:59:19.808460
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source("""
    from foo import bar
    from foo import baz as qux
    from foo import *
    from foo.bar import baz
    from foo.bar import qux as quux
    from foo.bar import *
    """)


# Generated at 2022-06-17 23:59:29.685976
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from a.b import c, d').body[0]
    import_from_rewrite = ast.parse('from a.b import c as c1, d as d1').body[0]
    import_from_rewrite_2 = ast.parse('from a.b import c as c1, d as d1').body[0]
    import_from_rewrite_3 = ast.parse('from a.b import c as c1, d as d1').body[0]
    import_from_rewrite_4 = ast.parse('from a.b import c as c1, d as d1').body[0]
    import_from_rewrite_5 = ast.parse('from a.b import c as c1, d as d1').body[0]
    import_

# Generated at 2022-06-17 23:59:40.461883
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = parse_ast("""
from old import a, b
from old import *
from old.c import d, e
from old.c import *
from old.c.f import g, h
from old.c.f import *
from old.c.f.i import j, k
from old.c.f.i import *
    """)


# Generated at 2022-06-17 23:59:52.243315
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet_to_ast
    from ..utils.ast_helpers import get_ast_node_by_path

    snippet_ast = snippet_to_ast(import_rewrite)
    snippet_ast = ast.fix_missing_locations(snippet_ast)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:59:58.273242
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert_source_equal(astor.to_source(result.tree),
                        'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:00:04.106512
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = astor.parse('import foo')
    expected = astor.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert_equal_ast(result.tree, expected)
    assert_equal_source(result.tree, expected)
    assert result.changed



# Generated at 2022-06-18 00:00:12.451966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    import typing
    import six

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typing', 'six')]

    tree = ast.parse('''
    import typing
    import typing.io
    ''')

    expected = ast.parse('''
    try:
        import typing
    except ImportError:
        import six
    try:
        import typing.io
    except ImportError:
        import six.io
    ''')

    assert astor.to_source(TestTransformer.transform(tree).tree) == astor.to_source(expected)



# Generated at 2022-06-18 00:00:28.366293
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:35.387830
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'
    assert result.tree_changed


# Generated at 2022-06-18 00:00:42.398722
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test():
        import foo
        import foo.bar

    tree = get_ast(test)
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == """
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar
"""



# Generated at 2022-06-18 00:00:48.386921
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:56.993067
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from_module():
        import foo.bar
        import foo.baz

    @snippet
    def test_import_from_names():
        from foo import bar
        from foo import baz

    @snippet
    def test_import_from_module_and_names():
        from foo import bar, baz

    @snippet
    def test_import_from_module_and_names_with_as():
        from foo import bar as b, baz as c


# Generated at 2022-06-18 00:01:04.700545
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
    ''')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:01:13.184487
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse
    from ..utils.ast import dump
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse("""
    import foo
    """)
    new_tree = TestTransformer.transform(tree).tree
    expected_tree = parse("""
    try:
        import foo
    except ImportError:
        import bar
    """)
    assert compare_ast(new_tree, expected_tree)



# Generated at 2022-06-18 00:01:20.823903
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import get_ast
    from ..utils.compare import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = get_ast("""
    import old
    """)
    expected = get_ast("""
    try:
        import old
    except ImportError:
        import new
    """)

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:01:31.768538
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestImportRewrite.transform(tree)
    assert_equal_ast(astor.to_source(tree),
                     'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    TestImportRewrite.transform(tree)
    assert_equal_ast(astor.to_source(tree),
                     'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
    TestImportRewrite.transform(tree)
   

# Generated at 2022-06-18 00:01:41.976632
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar

    expected = """
    try:
        import foo
    except ImportError:
        import bar
    try:
        import foo.bar
    except ImportError:
        import bar.bar
    """
    expected = astor.to_source(ast.parse(expected))

    result = TestTransformer.transform(ast.parse(astor.to_source(test_snippet.get_body())))
    assert result.changed
    assert_equal_ast(result.tree, expected)



# Generated at 2022-06-18 00:02:06.701989
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert_ast_equal(expected, result)



# Generated at 2022-06-18 00:02:14.207450
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from():
        from six import StringIO
        from six.moves import range

    @snippet
    def test_import_from_as():
        from six import StringIO as sio
        from six.moves import range as rng

    @snippet
    def test_import_from_as_star():
        from six import *
        from six.moves import *

    @snippet
    def test_import_from_star():
        from six import *
        from six.moves import *


# Generated at 2022-06-18 00:02:24.999812
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_node_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_node_equal(TestTransformer.transform(tree).tree, expected)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_node_equal(TestTransformer.transform(tree).tree, expected)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:02:35.385618
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo
        import foo.bar

    @snippet
    def expected_import():
        try:
            import foo
        except ImportError:
            import bar

        try:
            import foo.bar
        except ImportError:
            import bar.bar

    tree = test_import.get_ast()
    expected_tree = expected_import.get_ast()

    TestImportRewrite.transform(tree)

    assert_equal_ast(tree, expected_tree)



# Generated at 2022-06-18 00:02:46.564677
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_node = ast.parse('import foo').body[0]
    assert astor.to_source(BaseImportRewrite(import_node).visit(import_node)) == 'import foo'

    import_node = ast.parse('import foo.bar').body[0]
    assert astor.to_source(BaseImportRewrite(import_node).visit(import_node)) == 'import foo.bar'

    import_node = ast.parse('import foo.bar as baz').body[0]
    assert astor.to_source(BaseImportRewrite(import_node).visit(import_node)) == 'import foo.bar as baz'

    import_node = ast.parse('import foo.bar as baz').body[0]

# Generated at 2022-06-18 00:02:56.745398
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_from_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'from foo import baz'
    expected = '''
try:
    from foo import baz
except ImportError:
    from bar import baz
'''
    tree = get_ast_from_source(source)
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree).strip() == expected.strip()

    source = 'from foo import baz as qux'
    expected = '''
try:
    from foo import baz as qux
except ImportError:
    from bar import baz as qux
'''
    tree = get_ast_from

# Generated at 2022-06-18 00:03:03.717737
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['six.moves']
    assert ast.dump(result.tree) == '''
try:
    import six
except ImportError:
    import six.moves as six
'''



# Generated at 2022-06-18 00:03:11.397064
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo

    @snippet
    def expected_import():
        try:
            import foo
        except ImportError:
            import bar

    tree = ast.parse(test_import.get_source())
    expected_tree = ast.parse(expected_import.get_source())
    TestImportRewrite.transform(tree)
    assert_ast_equal(tree, expected_tree)



# Generated at 2022-06-18 00:03:17.500909
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:03:26.513301
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import ast_from_code
    from ..utils.ast_helpers import ast_to_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = '''
from foo import baz
from foo.bar import baz
from foo.bar.baz import baz
from foo import *
from foo.bar import *
from foo.bar.baz import *
'''

# Generated at 2022-06-18 00:03:50.078086
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom_data import a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z
    tree = ast.parse(a)
    transformer = BaseImportRewrite()
    transformer.visit(tree)
    assert astor.to_source(tree) == b
    tree = ast.parse(c)
    transformer = BaseImportRewrite()
    transformer.visit(tree)
    assert astor.to_source(tree) == d
    tree

# Generated at 2022-06-18 00:03:56.804140
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import ast_to_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert ast_to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:04:08.001790
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    import_rewrite = snippet('''
    try:
        extend(previous)
    except ImportError:
        extend(current)
    ''')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    class TestImportRewrite2(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    class TestImportRewrite3(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    class TestImportRewrite4(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:04:18.938557
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast


# Generated at 2022-06-18 00:04:27.058012
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    test_BaseImportRewrite_visit_ImportFrom.__globals__['BaseImportRewrite'] = BaseImportRewrite
    test_BaseImportRewrite_visit_ImportFrom.__globals__['ast'] = ast
    test_BaseImportRewrite_visit_ImportFrom.__globals__['astor'] = astor
    test_BaseImportRewrite_visit_ImportFrom.__globals__['sys'] = sys
    test_BaseImportRewrite_visit_ImportFrom.__globals__

# Generated at 2022-06-18 00:04:32.670615
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:04:39.411880
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import ast_to_source_code

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:04:47.797705
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = get_ast('''
import os
''')
    result = TestTransformer.transform(tree)
    assert result.tree_changed is True
    assert astor.to_source(result.tree) == get_snippet_body('''
try:
    import os
except ImportError:
    import os.path as os
''')



# Generated at 2022-06-18 00:04:55.109074
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_node
    from ..utils.code_generator import generate_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = '''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar import baz as baz1
from foo.bar import * as baz2
'''

# Generated at 2022-06-18 00:05:04.648970
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    @snippet
    def test():
        import foo
        import bar
        import baz

    tree = parse_ast(test)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'new_foo')]

    result = TestImportRewrite.transform(tree)
    assert result.changed

    @snippet
    def expected():
        try:
            import foo
        except ImportError:
            import new_foo
        import bar
        import baz

    expected_tree = parse_ast(expected)
    assert astor.to_source(result.tree) == astor.to_source(expected_tree)



# Generated at 2022-06-18 00:05:47.977904
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_transformation_result
    from ..utils.test_utils import assert_equal_transformation_results
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_trees
    from ..utils.test_utils import assert_equal_types
    from ..utils.test_utils import assert_equal_values
    from ..utils.test_utils import assert_equal_with_printing
    from ..utils.test_utils import assert_is_instance
    from ..utils.test_utils import assert_is_subclass

# Generated at 2022-06-18 00:05:58.426050
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[0].value.names[0].asname == 'foo'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'
    assert result.tree.body[0].body[0].body[1].value.names[0].asname == 'foo'

# Generated at 2022-06-18 00:06:09.444324
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_ast_from_snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'import foo'
    expected = 'try:\n    import foo\nexcept ImportError:\n    import bar'
    tree = get_ast_from_source(source)
    expected_tree = get_ast_from_snippet(expected)
    assert_ast_equal(expected_tree, TestTransformer.transform(tree).tree)

    source = 'import foo.bar'
    expected = 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'
    tree

# Generated at 2022-06-18 00:06:14.582238
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    test_BaseImportRewrite_visit_ImportFrom.__globals__['BaseImportRewrite'] = BaseImportRewrite
    test_BaseImportRewrite_visit_ImportFrom.__globals__['ast'] = ast
    test_BaseImportRewrite_visit_ImportFrom.__globals__['astor'] = astor
    test_BaseImportRewrite_visit_ImportFrom.__globals__['os'] = os
    test_BaseImportRewrite_visit_ImportFrom.__globals__

# Generated at 2022-06-18 00:06:19.976225
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['old', 'new']
    assert ast.dump(result.tree) == '''
try:
    import old
except ImportError:
    import new
'''



# Generated at 2022-06-18 00:06:30.128892
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend

# Generated at 2022-06-18 00:06:32.646502
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:06:38.358703
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.qux
    ''')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:06:48.164456
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, extend
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_source_with_import
    from ..utils.test_utils import assert_equal_source_with_import_as
    from ..utils.test_utils import assert_equal_source_with_import_from
    from ..utils.test_utils import assert_equal_source_with_import_from_as
    from ..utils.test_utils import assert_equal_source_with_import_from_as_all
    from ..utils.test_utils import assert_equal_source_with_import_from_

# Generated at 2022-06-18 00:06:51.924722
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('../../')
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import BaseNodeTransformer
    from ..utils.snippet import BaseTransformer
    from ..utils.snippet import TransformationResult
    from ..utils.snippet import CompilationTarget
    from ..utils.snippet import List
    from ..utils.snippet import Tuple
    from ..utils.snippet import Union
    from ..utils.snippet import Optional
    from ..utils.snippet import Iterable
    from ..utils.snippet import Dict