

# Generated at 2022-06-17 23:57:32.047589
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_data.BaseImportRewrite_visit_ImportFrom import test_data
    for test_case in test_data:
        tree = astor.parse_file(test_case['file'])
        BaseImportRewrite.rewrites = test_case['rewrites']
        BaseImportRewrite.visit(tree)
        assert astor.to_source(tree) == test_case['expected']

# Generated at 2022-06-17 23:57:41.917435
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = astor.parse("import foo")
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astunparse.unparse(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = astor.parse("import foo.bar")
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astunparse.unparse(result) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = astor.parse("import bar")
    transformer = TestTransformer(tree)
    result

# Generated at 2022-06-17 23:57:53.157545
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    test_BaseImportRewrite_visit_ImportFrom.__globals__['BaseImportRewrite'] = BaseImportRewrite
    test_BaseImportRewrite_visit_ImportFrom.__globals__['ast'] = ast
    test_BaseImportRewrite_visit_ImportFrom.__globals__['astor'] = astor
    test_BaseImportRewrite_visit_ImportFrom.__globals__['os'] = os
    test_BaseImportRewrite_visit_ImportFrom.__globals__

# Generated at 2022-06-17 23:58:03.841436
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast('''
    import foo
    ''')
    expected = parse_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')
    result = TestTransformer.transform(tree)
    assert compare_ast(result.tree, expected)
    assert ast_to_source(result.tree) == ast_to_source(expected)



# Generated at 2022-06-17 23:58:15.909980
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse('''
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz.qux
    ''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['bar']


# Generated at 2022-06-17 23:58:23.797850
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:58:35.412442
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
''')
    TestTransformer.transform(tree)

# Generated at 2022-06-17 23:58:43.510414
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    from typing import List, Tuple, Union, Optional, Iterable, Dict
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget, TransformationResult
    from ..utils.snippet import snippet, extend
    from ..transformers.base import BaseTransformer, BaseNodeTransformer, BaseImportRewrite
    from ..transformers.base import import_rewrite
    import_rewrite = import_rewrite
    class BaseTransformer(metaclass=ABCMeta):
        target = None  # type: CompilationTarget
        @classmethod
        @abstractmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    class BaseNodeTransformer(BaseTransformer, ast.NodeTransformer):
        dependencies = []  # type: List

# Generated at 2022-06-17 23:58:53.822961
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
        import foo.bar
        import foo.baz
        import foo.bar.baz
        import foo.bar.baz.qux
    ''')


# Generated at 2022-06-17 23:59:01.977607
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    expected = ast.parse('try:\n    import six\nexcept ImportError:\n    import six.moves')

    result = TestImportRewrite.transform(tree)
    assert_ast_equal(astor.to_source(result.tree), astor.to_source(expected))



# Generated at 2022-06-17 23:59:21.925305
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='foo', asname=None)])],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[ast.Import(names=[ast.alias(name='bar', asname=None)])])],
        orelse=[],
        finalbody=[])
    assert result.tree_changed
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-17 23:59:28.747542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit_Import(tree.body[0])
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:59:34.018354
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-17 23:59:43.030317
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import unittest
    import unittest.mock

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    class TestBaseImportRewrite_visit_Import(unittest.TestCase):
        def test_rewrite(self):
            code = 'import os'
            tree = ast.parse(code)
            tree = TestBaseImportRewrite.transform(tree).tree
            self.assertEqual(astor.to_source(tree),
                             'try:\n    import os\nexcept ImportError:\n    import os.path')

        def test_no_rewrite(self):
            code = 'import sys'

# Generated at 2022-06-17 23:59:54.011574
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.test_helpers import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:00:04.342966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest
    import unittest.mock

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.temp_dir)
            self.old_path = sys.path
            sys.path.append(self.temp_dir)

        def tearDown(self):
            sys.path = self.old_path

        def _create_module(self, name: str, content: str) -> str:
            module_path = os.path.join(self.temp_dir, name)

# Generated at 2022-06-18 00:00:10.467124
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_snippet():
        import six
        import six as six_alias
        import six.moves

    tree = ast.parse(test_snippet.get_source())
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == """\
try:
    import six
except ImportError:
    import six.moves as six

try:
    import six as six_alias
except ImportError:
    import six.moves as six_alias

import six.moves
"""



# Generated at 2022-06-18 00:00:19.336636
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import unittest
    from typed_ast import ast3 as typed_ast

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestCase(unittest.TestCase):
        def test_import_from_module(self):
            tree = typed_ast.parse("from foo import bar")
            result = TestBaseImportRewrite.transform(tree)
            self.assertEqual(
                astor.to_source(result.tree),
                "try:\n    from foo import bar\n"
                "except ImportError:\n    from bar import bar")

        def test_import_from_names(self):
            tree = typed_ast.parse("from foo import bar, baz")
            result = TestBaseImportRewrite

# Generated at 2022-06-18 00:00:25.813151
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:00:33.452958
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import_from = ast.ImportFrom(module='foo',
                                 names=[ast.alias(name='bar',
                                                  asname='baz')],
                                 level=0)
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    assert astunparse.unparse(TestImportRewrite.transform(import_from).tree) == 'try:\n    import bar as baz\nexcept ImportError:\n    import foo as baz'


# Generated at 2022-06-18 00:00:58.793551
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string
    import importlib
    import types
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            sys.path.append(self.temp_dir)
            self.addCleanup(shutil.rmtree, self.temp_dir)

        def _create_module(self, name: str, content: str) -> str:
            path = os.path.join(self.temp_dir, name + '.py')
            with open(path, 'w') as f:
                f.write(content)
            return path


# Generated at 2022-06-18 00:01:05.515884
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:01:17.326506
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:01:23.601552
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(get_body(test_BaseImportRewrite_visit_Import))
    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == get_body(test_BaseImportRewrite_visit_Import)


# Generated at 2022-06-18 00:01:33.395448
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import snippet, extend

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = 'import foo'
    tree = get_ast(code)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:01:40.496943
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == astunparse.unparse(
        ast.parse('''
try:
    import six
except ImportError:
    import six.moves as six
        '''))



# Generated at 2022-06-18 00:01:46.774285
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)
    expected = snippet("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    assert astor.to_source(TestImportRewrite.transform(tree).tree) == expected



# Generated at 2022-06-18 00:01:51.897076
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_transformation_result

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation_result(
        TestImportRewrite,
        'from foo import bar',
        'from foo import bar')

    assert_transformation_result(
        TestImportRewrite,
        'from foo import bar as baz',
        'from foo import bar as baz')

    assert_transformation_result(
        TestImportRewrite,
        'from foo import *',
        'from foo import *')

    assert_transformation_result(
        TestImportRewrite,
        'from foo import bar as baz, qux',
        'from foo import bar as baz, qux')


# Generated at 2022-06-18 00:01:57.563063
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    assert_transformation_result(
        TestTransformer,
        """
        import six
        """,
        """
        try:
            import six
        except ImportError:
            import six.moves as six
        """,
        dependencies=['six.moves'])



# Generated at 2022-06-18 00:02:03.016758
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:02:35.811986
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import dump_ast
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:02:47.013237
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_snippet():
        import os
        from os import path
        from os.path import join
        from os.path import join as j
        from os.path import join as j, exists
        from os.path import join as j, exists as e
        from os.path import join as j, exists as e, isdir
        from os.path import join as j, exists as e, isdir as i
        from os.path import join as j, exists as e, isdir as i, isfile

    test_ast = get_ast(test_snippet)
    import_rewrite = BaseImportRewrite(test_ast)

# Generated at 2022-06-18 00:02:55.740936
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast
    from ..utils.compat import get_arg_names

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit_Import(tree.body[0])
    assert astor.to_source(result) == snippet(import_rewrite(previous='import foo', current='import bar')).strip()


# Generated at 2022-06-18 00:03:06.488132
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import copy
    import unittest
    from unittest.mock import patch
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_ast
    from ..utils.ast_helpers import get_source_from_node
    from ..utils.ast_helpers import get_node_from_source
    from ..utils.ast_helpers import get_source_from_node
    from ..utils.ast_helpers import get_source_from_ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_node_from_

# Generated at 2022-06-18 00:03:13.895499
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:22.305617
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("""
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import qux
from foo.bar.baz import *
""")

    TestImportRewrite.transform(tree)


# Generated at 2022-06-18 00:03:29.693178
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_from_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    source = '''
from os import path
from os import path as p
from os import *
from os.path import path
from os.path import path as p
from os.path import *
from os.path.path import path
from os.path.path import path as p
from os.path.path import *
'''

# Generated at 2022-06-18 00:03:37.429231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import astunparse
    import io
    import sys
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os.path')]

            code = 'import os'
            tree = ast.parse(code)
            TestTransformer.transform(tree)
            self.assertEqual(astor.to_source(tree).strip(),
                             'try:\n    import os\nexcept ImportError:\n    import os.path')

    unittest.main()


# Generated at 2022-06-18 00:03:47.791005
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert result.dependencies == ['bar']

# Generated at 2022-06-18 00:03:58.894164
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_snippet():
        import six
        import six.moves

    expected = astor.to_source(test_snippet.get_ast())

    @snippet
    def test_snippet_rewrite():
        import six
        try:
            import six.moves
        except ImportError:
            import six

    assert_equal_ast(TestTransformer.transform(test_snippet.get_ast()).tree,
                     test_snippet_rewrite.get_ast())

    assert astor.to_

# Generated at 2022-06-18 00:04:53.646618
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('.')
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:05:03.741679
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:05:15.895843
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import baz')
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n'
                        '    from foo import baz\n'
                        'except ImportError:\n'
                        '    from bar import baz')

    tree = ast.parse('from foo import *')
    TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:05:27.724421
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_body

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')]


# Generated at 2022-06-18 00:05:32.853479
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    TestTransformer.transform(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:05:42.224746
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_asts

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    from foo import baz
    """)

    expected_tree = get_ast("""
    try:
        from foo import baz
    except ImportError:
        from bar import baz
    """)

    result = TestImportRewrite.transform(tree)
    assert result.tree_changed
    assert compare_asts(result.tree, expected_tree)



# Generated at 2022-06-18 00:05:47.999407
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves as six'



# Generated at 2022-06-18 00:05:58.453756
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit_Import(tree.body[0])
    assert isinstance(result, ast.Try)
    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'bar'
    assert result.body[0].names[0].asname == 'foo'
    assert len(result.handlers) == 1
    assert isinstance(result.handlers[0], ast.ExceptHandler)
    assert result.hand

# Generated at 2022-06-18 00:06:06.425054
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_rewrite_test = BaseImportRewrite()
    import_rewrite_test.rewrites = [('foo', 'bar')]
    import_rewrite_test._tree_changed = False
    import_rewrite_test._tree = None
    import_rewrite_test.visit(ast.parse("import foo"))
    assert astor.to_source(import_rewrite_test._tree) == "try:\n    import foo\nexcept ImportError:\n    import bar"


# Generated at 2022-06-18 00:06:11.207211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected_tree = ast.parse("""
    try:
        import foo
    except ImportError:
        import bar
    """)
    assert_equal_ast(expected_tree, TestTransformer.transform(tree).tree)

