

# Generated at 2022-06-17 23:57:34.124940
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz as qux
from foo.bar import baz
from foo.bar import qux as quux
from foo.bar.baz import qux
from foo.bar.baz import quux as quuz
from foo.bar.baz.qux import quux
from foo.bar.baz.qux import quuz as quuuz
''')
    TestImportRewrite.transform(tree)

# Generated at 2022-06-17 23:57:43.153190
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import unittest
    import unittest.mock
    import typing
    import astunparse
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast27
    from typed_ast import ast35 as typed_ast35
    from typed_ast import ast36 as typed_ast36
    from typed_ast import ast38 as typed_ast38
    from typed_ast import ast3 as typed_ast3
    from typed_ast import ast35 as typed_ast35
    from typed_ast import ast36 as typed_ast36
    from typed_ast import ast38 as typed_ast38
    from typed_ast import ast3 as typed_ast3
    from typed_ast import ast35 as typed

# Generated at 2022-06-17 23:57:46.634380
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import get_test_data

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(get_test_data('import_rewrite_test.py'))
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == get_test_data('import_rewrite_test_result.py')



# Generated at 2022-06-17 23:57:52.202542
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:58:03.997370
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_transformation_result_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected_tree = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    expected_result = TransformationResult(expected_tree, True, [])

    result = TestTransformer.transform(tree)
    assert_transformation_result_equal(result, expected_result)

    tree = ast.parse('import foo.bar')
    expected_tree = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

# Generated at 2022-06-17 23:58:15.907871
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_node_at_line

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_code():
        from foo import bar
        from foo import baz
        from foo import qux as quux
        from foo.bar import baz
        from foo.bar import qux as quux
        from foo.bar.baz import qux as quux

    tree = ast.parse(test_code.get_source())
    TestImportRewrite.transform(tree)


# Generated at 2022-06-17 23:58:23.770209
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = parse_ast("""
    import six
    """)
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['six.moves']

# Generated at 2022-06-17 23:58:32.546055
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestImportRewrite.transform(tree)
    assert_ast_equal(astor.to_source(result.tree), astor.to_source(expected))



# Generated at 2022-06-17 23:58:41.702114
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar').body[0]
    import_from_rewrite = ast.parse('from foo.bar import bar').body[0]
    import_from_rewrite_2 = ast.parse('from foo.bar import bar as bar2').body[0]
    import_from_rewrite_3 = ast.parse('from foo.bar import bar as bar2, baz').body[0]
    import_from_rewrite_4 = ast.parse('from foo.bar import bar as bar2, baz as baz2').body[0]
    import_from_rewrite_5 = ast.parse('from foo.bar import bar as bar2, baz as baz2, *').body[0]

# Generated at 2022-06-17 23:58:52.537661
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('../../')
    from ..utils.snippet import snippet, extend
    from ..transformers.base import BaseImportRewrite
    from ..transformers.base import import_rewrite
    import_rewrite = extend(import_rewrite)
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    tree = ast.parse('from six import StringIO')
    result = TestBaseImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    from six import StringIO\nexcept ImportError:\n    from six.moves import StringIO\n'
    assert result.changed == True

# Generated at 2022-06-17 23:59:08.434760
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves'

    tree = ast.parse('import six.moves')
    result = TestTransformer.transform(tree)
    assert not result.changed
    assert astor.to_source(result.tree) == 'import six.moves'

    tree = ast.parse('import six.moves.urllib.parse')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_

# Generated at 2022-06-17 23:59:17.344061
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='foo', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='bar', asname=None)])])],
        orelse=[],
        finalbody=[])



# Generated at 2022-06-17 23:59:25.295777
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("import foo")
    result = TestTransformer.transform(tree)
    assert result.changed
    assert snippet_to_ast(result.tree) == snippet_to_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)



# Generated at 2022-06-17 23:59:30.502391
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert_equal_ast(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-17 23:59:41.151796
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    from typed_ast import ast3 as typed_ast

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os_mock')]


# Generated at 2022-06-17 23:59:53.015419
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_utils import BaseImportRewrite as test_BaseImportRewrite
    from .test_utils import import_rewrite as test_import_rewrite
    from .test_utils import extend as test_extend
    from .test_utils import ImportError as test_ImportError
    from .test_utils import TransformationResult as test_TransformationResult
    from .test_utils import CompilationTarget as test_CompilationTarget
    from .test_utils import snippet as test_snippet
    from .test_utils import extend as test_extend
    from .test_utils import ast as test_ast
    from .test_utils import ast3 as test_ast

# Generated at 2022-06-18 00:00:01.561748
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import io
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True

        def test_visit_Import(self):
            import_ = ast.Import(names=[ast.alias(name='os', asname=None)])
            import_rewrite = BaseImportRewrite(import_)
            import_rewrite.rewrites = [('os', 'os_')]
            import_rewrite.visit(import_)
            self.assertEqual(astor.to_source(import_),
                             'try:\n    import os\nexcept ImportError:\n    import os_')

    un

# Generated at 2022-06-18 00:00:09.503217
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import io
    import unittest
    from typed_ast import ast3 as typed_ast

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(typed_ast.AST, 'assertAstEqual')

        def assertAstEqual(self, node1, node2, msg=None):
            if msg is None:
                msg = 'ASTs not equal'
            self.assertEqual(astor.to_source(node1), astor.to_source(node2), msg)


# Generated at 2022-06-18 00:00:15.739863
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = snippet_to_ast('''
    import foo
    import foo.bar
    import foo.bar.baz
    ''')
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == '''
    try:
        import foo
    except ImportError:
        import bar
    try:
        import foo.bar
    except ImportError:
        import bar.bar
    try:
        import foo.bar.baz
    except ImportError:
        import bar.bar.baz
    '''



# Generated at 2022-06-18 00:00:26.308407
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies_equal(result, ['foo', 'bar'])
    assert_ast_equal(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)

# Generated at 2022-06-18 00:00:43.633595
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:52.072001
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import_from = ast.ImportFrom(module='foo',
                                 names=[ast.alias(name='bar',
                                                  asname='baz')],
                                 level=0)
    rewriter = BaseImportRewrite(None)
    rewriter.rewrites = [('foo', 'foo_rewrite')]
    rewrote = rewriter.visit_ImportFrom(import_from)
    assert isinstance(rewrote, ast.Try)
    assert rewrote.body[0].names[0].name == 'foo_rewrite.bar'
    assert rewrote.body[0].names[0].asname == 'baz'
    assert rewrote.body[1].names[0].name == 'foo.bar'

# Generated at 2022-06-18 00:01:00.020821
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast27
    from typed_ast import ast35 as typed_ast35
    from typed_ast import ast36 as typed_ast36
    from typed_ast import ast37 as typed_ast37
    from typed_ast import ast38 as typed_ast38
    from typed_ast import ast39 as typed_ast39
    from typed_ast import ast40 as typed_ast40
    from typed_ast import ast41 as typed_ast41
    from typed_ast import ast42 as typed_ast42
    from typed_ast import ast43 as typed_ast43
    from typed_ast import ast44 as typed_ast44
    from typed_ast import ast45 as typed_ast45

# Generated at 2022-06-18 00:01:11.357656
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal

    @snippet
    def test_snippet():
        from foo import bar
        from foo import baz as baz2
        from foo import *
        from foo.bar import baz
        from foo.bar import baz as baz2
        from foo.bar import *

    tree = ast.parse(test_snippet.get_source())

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    result = TestTransformer.transform(tree)
    assert result.changed

    @snippet
    def expected_snippet():
        try:
            from foo import bar
        except ImportError:
            from bar import bar
       

# Generated at 2022-06-18 00:01:22.698002
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(result.tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(result.tree), 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:01:33.550671
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    import_from_snippet = snippet(
        """
        from foo import bar
        from foo import baz
        from foo import qux
        from foo import quux
        from foo import quuz
        from foo import corge
        from foo import grault
        from foo import garply
        from foo import waldo
        from foo import fred
        from foo import plugh
        from foo import xyzzy
        from foo import thud
        """
    )


# Generated at 2022-06-18 00:01:43.899446
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz.qux
    ''')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:01:54.193819
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import get_body
    from ..utils.snippet import get_ast
    from ..utils.snippet import get_source
    from ..utils.snippet import get_source_without_imports
    from ..utils.snippet import get_source_without_docstrings
    from ..utils.snippet import get_source_without_imports_and_docstrings
    from ..utils.snippet import get_source_without_leading_whitespace
    from ..utils.snippet import get_source_without_trailing_whitespace
    from ..utils.snippet import get_source_without_leading_or_trailing_whitespace
   

# Generated at 2022-06-18 00:01:58.334678
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = 'import foo'
    expected_code = 'try:\n    import foo\nexcept ImportError:\n    import bar'
    assert_transformation_result(TestTransformer, code, expected_code)



# Generated at 2022-06-18 00:02:09.067539
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse
    from ..utils.ast import dump
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse('''
    from foo import bar
    from foo import baz
    from foo import *
    from foo.bar import baz
    from foo.bar import *
    from foo.bar.baz import *
    from foo.bar.baz import baz
    ''')

# Generated at 2022-06-18 00:02:50.997059
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'
    assert result.tree_changed



# Generated at 2022-06-18 00:02:56.673678
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_source_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:03:07.633119
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
from foo.bar.baz import qux
''')

    TestImportRewrite.transform(tree)


# Generated at 2022-06-18 00:03:18.895289
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'pathlib')]


# Generated at 2022-06-18 00:03:23.712270
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import get_body
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    from foo import baz
    from foo.bar import baz
    from foo.bar.baz import baz
    from foo import *
    from foo.bar import *
    from foo.bar.baz import *
    ''')

    result = TestImportRewrite.transform(tree)
    assert result.changed


# Generated at 2022-06-18 00:03:29.432258
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']
    assert ast.dump(result.tree) == 'Try(\n' \
                                    '    Import(names=[alias(name=\'bar\', asname=\'foo\')]),\n' \
                                    '    ExceptHandler(type=None, name=None, body=[Import(names=[alias(name=\'foo\', asname=\'foo\')])]),\n' \
                                    '    orelse=[])'



# Generated at 2022-06-18 00:03:36.105653
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:44.184277
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert_ast_equal(result.tree, expected)



# Generated at 2022-06-18 00:03:49.539690
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(
        """
        import foo
        """
    )

    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == \
        """
        try:
            extend(import foo)
        except ImportError:
            extend(import bar)
        """



# Generated at 2022-06-18 00:03:59.543678
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = ast.parse('import foo.bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = ast.parse('import foo.bar as baz')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
   

# Generated at 2022-06-18 00:05:18.685430
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import import_rewrite_from_module
    from ..utils.snippet import import_rewrite_from_names
    from ..utils.snippet import import_rewrite_from_names_with_as
    from ..utils.snippet import import_rewrite_from_names_with_as_and_star
    from ..utils.snippet import import_rewrite_from_names_with_star
    from ..utils.snippet import import_rewrite_from_names_with_star_and_as
    from ..utils.snippet import import_rewrite_from_names_

# Generated at 2022-06-18 00:05:29.486661
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import *
from foo.bar.baz import baz
''')
    Test.transform(tree)

# Generated at 2022-06-18 00:05:34.384877
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('import six')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves as six'



# Generated at 2022-06-18 00:05:45.832908
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import sys
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os.path')]


# Generated at 2022-06-18 00:05:56.447471
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    from foo import bar
    from foo.baz import bar
    from foo import bar as baz
    from foo.baz import bar as baz
    from foo import *
    from foo.baz import *
    ''')


# Generated at 2022-06-18 00:06:07.608696
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('/home/user/PycharmProjects/py2ts/py2ts/tests/test_data')
    from test_data.test_import_rewrite import test_import_rewrite_1
    from py2ts.transformers.base import BaseImportRewrite
    from py2ts.transformers.base import import_rewrite
    from py2ts.transformers.base import BaseNodeTransformer
    from py2ts.transformers.base import BaseTransformer
    from py2ts.transformers.base import import_rewrite
    from py2ts.transformers.base import BaseImportRewrite
    from py2ts.transformers.base import BaseNodeTransformer
    from py2ts.transformers.base import BaseTransformer

# Generated at 2022-06-18 00:06:12.018338
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)

    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-18 00:06:21.462204
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast27
    from typed_ast import ast35 as typed_ast35
    from typed_ast import ast36 as typed_ast36
    from typed_ast import ast37 as typed_ast37
    from typed_ast import ast38 as typed_ast38
    from typed_ast import ast39 as typed_ast39
    from typed_ast import ast40 as typed_ast40
    from typed_ast import ast41 as typed_ast41
    from typed_ast import ast42 as typed_ast42
    from typed_ast import ast43 as typed_ast43
    from typed_ast import ast44 as typed_ast44
    from typed_ast import ast45 as typed_ast45

# Generated at 2022-06-18 00:06:32.113560
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import BaseNodeTransformer
    from ..utils.snippet import BaseTransformer
    from ..utils.snippet import TransformationResult
    from ..utils.snippet import CompilationTarget
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import BaseNodeTransformer
    from ..utils.snippet import BaseTransformer

# Generated at 2022-06-18 00:06:35.691325
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'new'

