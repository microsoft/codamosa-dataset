

# Generated at 2022-06-17 23:57:32.734471
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from ..utils.ast_helpers import get_ast_node_from_source, get_ast_node_from_target

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'import foo'
    tree = get_ast_node_from_source(source)
    result = TestTransformer.transform(tree)
    assert result.tree_changed is True
    assert get_ast_node_from_target(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:57:41.732329
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)

    transformer = TestTransformer(tree)
    result = transformer.visit_Import(tree.body[0])
    assert astor.to_source(result) == """
    try:
        import foo
    except ImportError:
        import bar
    """



# Generated at 2022-06-17 23:57:52.959308
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import get_body

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import bar')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == get_body(
        'try:',
        '    from foo import bar',
        'except ImportError:',
        '    from bar import bar')

    tree = ast.parse('from foo import bar as baz')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == get_body(
        'try:',
        '    from foo import bar as baz',
        'except ImportError:',
        '    from bar import bar as baz')

# Generated at 2022-06-17 23:58:04.609917
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import os.path
    import typing
    import typing as t
    import typing as tt
    import typing as ttt
    import typing as tttt
    import typing as ttttt
    import typing as tttttt
    import typing as ttttttt
    import typing as tttttttt
    import typing as ttttttttt
    import typing as tttttttttt
    import typing as ttttttttttt
    import typing as tttttttttttt
    import typing as ttttttttttttt
    import typing as tttttttttttttt
    import typing as ttttttttttttttt
    import typing as tttttttttttttttt
    import typing as ttttttttttttttt

# Generated at 2022-06-17 23:58:16.070293
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]


# Generated at 2022-06-17 23:58:25.429532
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.abspath('.'))
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import get_source_from_ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_file
    from ..utils.ast_helpers import get_ast_from_file
    from ..utils.ast_helpers import get_source_from_url
    from ..utils.ast_helpers import get_ast_from_url
    from ..utils.ast_helpers import get_source_from

# Generated at 2022-06-17 23:58:33.239295
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar import baz as baz2
from foo.bar import * as baz3
''')


# Generated at 2022-06-17 23:58:42.149640
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_transformation

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation(TestTransformer,
                          'import foo',
                          'try:\n    import foo\nexcept ImportError:\n    import bar')

    assert_transformation(TestTransformer,
                          'import foo.bar',
                          'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    assert_transformation(TestTransformer,
                          'import foo.bar as baz',
                          'try:\n    import foo.bar as baz\nexcept ImportError:\n    import bar.bar as baz')


# Generated at 2022-06-17 23:58:52.904540
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    from foo import a
    from foo import b as c
    from foo import *
    from foo.bar import d
    from foo.bar import e as f
    from foo.bar import *
    from foo.bar.baz import g
    from foo.bar.baz import h as i
    from foo.bar.baz import *
    ''')
    TestImportRewrite.transform(tree)

# Generated at 2022-06-17 23:59:03.402011
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_utils import get_ast
    from ..utils.ast_utils import get_node_type
    from ..utils.ast_utils import get_node_name
    from ..utils.ast_utils import get_node_module
    from ..utils.ast_utils import get_node_names
    from ..utils.ast_utils import get_node_level
    from ..utils.ast_utils import get_node_asname
    from ..utils.ast_utils import get_node_body
    from ..utils.ast_utils import get_node_names
    from ..utils.ast_utils import get_node_orelse
    from ..utils.ast_utils import get_node_finalbody
    from ..utils.ast_utils import get_node_handlers
    from ..utils.ast_utils import get_node_type
   

# Generated at 2022-06-17 23:59:15.993315
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo

    tree = parse(test_snippet.get_body())
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == """\
try:
    import foo
except ImportError:
    import bar
"""



# Generated at 2022-06-17 23:59:21.305031
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    assert_equal_ast(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-17 23:59:30.873667
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import_from():
        from six import moves
        from six.moves import builtins

    @snippet
    def test_import_from_as():
        from six import moves as six_moves
        from six.moves import builtins as six_builtins

    @snippet
    def test_import_from_as_with_alias():
        from six import moves as six_moves
        from six.moves import builtins as six_builtins
        from six.moves import map as six_map


# Generated at 2022-06-17 23:59:37.230279
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:59:44.087395
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='foo', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='bar', asname=None)])])],
        orelse=[],
        finalbody=[])
    assert result.changed



# Generated at 2022-06-17 23:59:55.316716
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import re
    import unittest
    import unittest.mock as mock
    from typed_astunparse import unparse
    from typed_astunparse import ast3 as ast3
    from typed_astunparse import ast27 as ast27
    from typed_astunparse import ast35 as ast35
    from typed_astunparse import ast36 as ast36
    from typed_astunparse import ast37 as ast37
    from typed_astunparse import ast38 as ast38
    from typed_astunparse import ast39 as ast39
    from typed_astunparse import ast310 as ast310
    from typed_astunparse import ast311 as ast311
    from typed_astunparse import ast312 as ast312
    from typed_astunparse import ast313

# Generated at 2022-06-18 00:00:05.416105
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_from_text
    from ..utils.test_utils import get_ast_node_from_text_as_module
    from ..utils.test_utils import get_ast_node_from_text_as_module_with_future
    from ..utils.test_utils import get_ast_node_from_text_as_module_with_future_and_typing

    import ast
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    # Test import
    node = get_ast_node_from_text('import foo')
    expected = get_ast_node_from_

# Generated at 2022-06-18 00:00:09.993261
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)

    expected = get_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:00:19.011305
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]


# Generated at 2022-06-18 00:00:29.026520
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = snippet_to_ast('''
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.qux
    ''')


# Generated at 2022-06-18 00:01:08.472756
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    import_rewrite = snippet('''
    try:
        extend(previous)
    except ImportError:
        extend(current)
    ''')
    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = [('a', 'b')]
        def _get_matched_rewrite(self, name):
            if name is None:
                return None
            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to
            return None
        def _replace_import(self, node, from_, to):
            rewrote_name = node.names[0].name.replace(from_, to, 1)
           

# Generated at 2022-06-18 00:01:19.876484
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree == ast.Try(
        body=[ast.Import(names=[ast.alias(name='bar', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='foo', asname=None)])])],
        orelse=[],
        finalbody=[])

    tree = get_ast('import foo.bar')
   

# Generated at 2022-06-18 00:01:30.861196
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite

    class BaseImportRewrite(BaseNodeTransformer):
        rewrites = [('six', 'six.moves')]

        def _get_matched_rewrite(self, name):
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None

        def _replace_import(self, node, from_, to):
            self._tree_changed = True

            rewrote_name = node.names[0].name.replace(from_, to, 1)


# Generated at 2022-06-18 00:01:35.611415
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:01:43.542803
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)
    result = TestTransformer.transform(tree)
    assert dump_ast(result.tree) == """
    try:
        import foo
    except ImportError:
        import bar
    """
    assert result.changed is True
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-18 00:01:53.802384
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    from foo import a, b
    from foo.bar import c, d
    from foo.bar.baz import e, f
    from foo.bar.baz.qux import g, h
    from foo.bar.baz.qux.quux import i, j
    ''')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:01:58.565903
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert_ast_equal(result.tree, expected)



# Generated at 2022-06-18 00:02:08.813625
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    from .utils import get_test_data

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    test_data = get_test_data(__file__, 'test_BaseImportRewrite_visit_Import.txt')
    expected_data = get_test_data(__file__, 'test_BaseImportRewrite_visit_Import_expected.txt')

    for test_code, expected_code in zip(test_data, expected_data):
        tree = ast.parse(test_code)
        TestTransformer.transform(tree)
        assert astunparse.unparse(tree) == expected_code


# Generated at 2022-06-18 00:02:19.428895
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = snippet_to_ast('''
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.qux
    ''')

# Generated at 2022-06-18 00:02:31.154253
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse
    from ..utils.ast import dump

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse('import foo')
    result = TestTransformer.transform(tree)
    assert dump(result.tree) == '''
try:
    import foo
except ImportError:
    import bar
'''

    tree = parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert dump(result.tree) == '''
try:
    import foo.bar
except ImportError:
    import bar.bar
'''

    tree = parse('import foo.bar as baz')
    result = TestTransformer.transform(tree)

# Generated at 2022-06-18 00:03:03.812122
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    import foo
    ''')

    expected = get_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    compare_ast(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:03:12.171542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected_tree = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(expected_tree, TestTransformer.transform(tree).tree)
    assert_equal_code(astor.to_source(expected_tree), astor.to_source(TestTransformer.transform(tree).tree))

    tree = ast.parse('import foo.bar')

# Generated at 2022-06-18 00:03:19.193644
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected_tree = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(expected_tree, TestTransformer.transform(tree).tree)
    assert_equal_code(expected_tree, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:03:25.282679
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert_ast_equal(result.tree, ast.parse("""
try:
    import foo
except ImportError:
    import bar
"""))



# Generated at 2022-06-18 00:03:36.056849
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')
        ]


# Generated at 2022-06-18 00:03:47.309809
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_utils import parse_ast
    from ..utils.ast_utils import get_ast_str
    from ..utils.ast_utils import get_ast_diff
    from ..utils.ast_utils import get_ast_diff_str

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast('from foo import a, b, c')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert get_ast_str(result.tree) == '''
try:
    from foo import a, b, c
except ImportError:
    from bar import a, b, c
'''

    tree = parse_ast('from foo import a, b, c')
    result = TestTransformer.transform(tree)

# Generated at 2022-06-18 00:03:55.260526
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_ast_equal(tree, expected)



# Generated at 2022-06-18 00:04:06.614501
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:04:10.904813
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert_ast_equal(astor.to_source(result.tree), astor.to_source(expected))



# Generated at 2022-06-18 00:04:21.501401
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import BaseNodeTransformer
    from ..utils.snippet import BaseTransformer
    from ..utils.snippet import TransformationResult
    from ..utils.snippet import CompilationTarget
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite

# Generated at 2022-06-18 00:04:53.859541
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-18 00:05:01.122004
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source('import foo')
    transformer = TestTransformer(tree)
    transformer.visit_Import(tree.body[0])
    assert get_source_from_ast(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:07.581721
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar').body[0]
    assert astor.to_source(import_from) == 'from foo import bar\n'
    import_from_rewrite = ast.parse('from foo import bar as baz').body[0]
    assert astor.to_source(import_from_rewrite) == 'from foo import bar as baz\n'
    import_from_rewrite_2 = ast.parse('from foo import bar as baz, baz as bar').body[0]
    assert astor.to_source(import_from_rewrite_2) == 'from foo import bar as baz, baz as bar\n'
    import_from_rewrite_3 = ast.parse('from foo import bar as baz, baz as bar, *').body

# Generated at 2022-06-18 00:05:17.965181
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_import():
        import six
        import six.moves
        import six.moves.urllib
        import six.moves.urllib.parse
        import six.moves.urllib.parse.urlparse
        import six.moves.urllib.parse.urlparse as urlparse
        import six.moves.urllib.parse.urlparse as urlparse2
        import six.moves.urllib.parse.urlparse as urlparse3
        import six.moves.urllib.parse.urlparse as urlparse4

# Generated at 2022-06-18 00:05:29.285316
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_from_source

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz
        from foo import bar
        from foo import bar, baz
        from foo.bar import baz
        from foo.bar import baz, qux
        from foo.bar.baz import qux
        from foo.bar.baz import qux, quux

    test_snippet_ast = get_ast_from_source(test_snippet.get_source())


# Generated at 2022-06-18 00:05:33.888370
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(expected, TestImportRewrite.transform(tree).tree)



# Generated at 2022-06-18 00:05:45.299410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='foo', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='bar', asname=None)])])],
        orelse=[],
        finalbody=[])
    assert result.changed is True
    assert result.dependencies == []



# Generated at 2022-06-18 00:05:55.463929
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]


# Generated at 2022-06-18 00:06:01.568617
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..utils.snippet import BaseImportRewrite
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom
    from ..utils.snippet import test_BaseImportRewrite_visit_Import
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom_2
    from ..utils.snippet import test_BaseImportRewrite_visit_ImportFrom_3
    from ..utils.snippet import test_BaseImportRew

# Generated at 2022-06-18 00:06:09.865268
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.test_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
        import foo.bar
    ''')
    expected = get_ast('''
        try:
            import foo
        except ImportError:
            import bar
        try:
            import foo.bar
        except ImportError:
            import bar.bar
    ''')

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:07:18.970666
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_utils import BaseImportRewrite_visit_ImportFrom as test_module

    module_ast = ast.parse(test_module.__doc__)
    class Test(BaseImportRewrite):
        rewrites = [('test_utils', 'test_utils')]

    result = Test.transform(module_ast)
    assert result.changed is True
    assert result.dependencies == ['test_utils']
    assert astor.to_source(result.tree) == test_module.__doc__


# Generated at 2022-06-18 00:07:25.306392
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'
    assert result.tree_changed is True
