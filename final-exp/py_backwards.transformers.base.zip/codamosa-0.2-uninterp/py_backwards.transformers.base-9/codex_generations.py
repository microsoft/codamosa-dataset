

# Generated at 2022-06-17 23:57:34.708005
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_code_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_code_equal(astor.to_source(tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert_code_equal(astor.to_source(tree), 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    tree = ast.parse('import foo.bar as baz')
   

# Generated at 2022-06-17 23:57:43.651662
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.ast_helpers import get_ast_node_path

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('''
import six
import six.moves
import six.moves.urllib
from six import moves
from six import moves as sm
from six.moves import urllib
from six.moves import urllib as ul
from six.moves import urllib as ul2
from six.moves import urllib as ul3
''')


# Generated at 2022-06-17 23:57:53.158188
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from_node = ast.parse('''
from typing import List, Tuple
from typing import List as L, Tuple as T
    ''').body[0]
    import_from_node_rewrote = ast.parse('''
try:
    from typing import List, Tuple
except ImportError:
    from typing import List as L, Tuple as T
    ''').body[0]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('typing', 'typing_extensions')]

    assert astor.to_source(TestImportRewrite.transform(import_from_node).tree) == astor.to_source(import_from_node_rewrote)



# Generated at 2022-06-17 23:58:04.184658
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    import_rewrite = snippet('''
    try:
        extend(previous)
    except ImportError:
        extend(current)
    ''')

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    ''')

    expected = ast.parse('''
    try:
        extend(import foo)
    except ImportError:
        extend(import bar)
    ''')

    TestTransformer.transform(tree)
    assert astor.to_source(tree) == astor.to_source(expected)



# Generated at 2022-06-17 23:58:12.901909
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert_ast_equal(result.tree, 'import_rewrite(previous=Import(names=[alias(name="old", asname=None)]), current=Import(names=[alias(name="new", asname=None)]))')



# Generated at 2022-06-17 23:58:18.591475
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = get_ast('import os')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import os\nexcept ImportError:\n    import os.path'



# Generated at 2022-06-17 23:58:27.996924
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_transformation_result
    from ..utils.test_utils import assert_equal_dependencies

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = '''
from six.moves import range
from six import StringIO
from six.moves import StringIO as StringIO2
from six import *
from six.moves import *
'''

# Generated at 2022-06-17 23:58:40.103718
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies_equal(result, ['foo', 'bar'])
    assert_ast_equal(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)

# Generated at 2022-06-17 23:58:49.691064
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import a, b, c')
    expected = get_ast('''
    try:
        from foo import a, b, c
    except ImportError:
        from bar import a, b, c
    ''')

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:59:01.590038
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal
    import ast
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ..utils.test_utils import assert_ast_equal
    import ast
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ..utils.test_utils import assert_ast_equal
    import ast
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   

# Generated at 2022-06-17 23:59:18.997097
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(TestTransformer.transform(tree).tree, expected)



# Generated at 2022-06-17 23:59:28.593352
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_ImportFrom(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os.path')]

            code = 'from os import path'
            tree = ast.parse(code)
            transformer = TestTransformer(tree)
            transformer.visit(tree)
            result = astor.to_source(tree)
            expected = 'try:\n    from os import path\nexcept ImportError:\n    from os.path import path'
            self.assertEqual(result, expected)

    unittest.main()

# Generated at 2022-06-17 23:59:39.310416
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.compiler import compile_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = parse_ast("""
    import foo
    import foo.bar
    import foo.bar.baz
    """)
    TestImportRewrite.transform(tree)
    assert compile_ast(tree) == """
    try:
        import foo
    except ImportError:
        import bar
    try:
        import foo.bar
    except ImportError:
        import bar.bar
    try:
        import foo.bar.baz
    except ImportError:
        import bar.bar.baz
    """


# Generated at 2022-06-17 23:59:42.812160
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-17 23:59:52.472574
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'os.path')]

            tree = ast.parse('import os')
            transformer = TestTransformer(tree)
            transformer.visit(tree)
            self.assertEqual(astor.to_source(tree), 'try:\n    import os\nexcept ImportError:\n    import os.path')

    unittest.main()


# Generated at 2022-06-18 00:00:01.272066
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_transformation_result(
        TestTransformer,
        'import foo',
        'try:\n    import foo\nexcept ImportError:\n    import bar')

    assert_transformation_result(
        TestTransformer,
        'import foo.bar',
        'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    assert_transformation_result(
        TestTransformer,
        'import foo.bar as baz',
        'try:\n    import foo.bar as baz\nexcept ImportError:\n    import bar.bar as baz')


# Generated at 2022-06-18 00:00:09.341410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:00:15.796510
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar import baz as baz2
from foo.bar import * as baz3
from foo.bar import baz as baz2, * as baz3
''')

# Generated at 2022-06-18 00:00:23.162937
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.ast_utils import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert_ast_equal(result.tree, get_ast('try:\n    import foo\nexcept ImportError:\n    import bar'))



# Generated at 2022-06-18 00:00:28.919051
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('import six')
    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves as six'



# Generated at 2022-06-18 00:00:51.446089
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_node_by_path
    from ..utils.snippet import get_snippet_body

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse(get_snippet_body(test_BaseImportRewrite_visit_ImportFrom))
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == get_snippet_body(test_BaseImportRewrite_visit_ImportFrom,
                                                            'expected')

    tree = ast.parse(get_snippet_body(test_BaseImportRewrite_visit_ImportFrom, 'input2'))

# Generated at 2022-06-18 00:00:59.652822
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_ast_not_equal
    from ..utils.test_utils import assert_ast_contains
    from ..utils.test_utils import assert_ast_not_contains
    from ..utils.test_utils import assert_ast_contains_only
    from ..utils.test_utils import assert_ast_not_contains_only
    from ..utils.test_utils import assert_ast_contains_only_once
    from ..utils.test_utils import assert_ast_not_contains_only_once
    from ..utils.test_utils import assert_ast_contains_only_once_in_order
    from ..utils.test_utils import assert_ast_not_contains_only_once_in_order

# Generated at 2022-06-18 00:01:10.927274
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast_from_source
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = """
    from foo import a
    from foo import b as c
    from foo.bar import d
    from foo.bar import e as f
    from foo.bar.baz import g
    from foo.bar.baz import h as i
    """


# Generated at 2022-06-18 00:01:22.302910
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_snippet():
        import foo
        import bar
        import baz

    tree = get_ast(test_snippet)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'foo2'), ('bar', 'bar2')]

    result = TestTransformer.transform(tree)
    assert result.changed

    expected = """
try:
    import foo
except ImportError:
    import foo2

try:
    import bar
except ImportError:
    import bar2

import baz
"""
    assert astor.to_source(result.tree) == expected



# Generated at 2022-06-18 00:01:33.178382
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast
    from ..utils.ast import get_ast_from_source
    from ..utils.ast import get_source_from_ast
    from ..utils.ast import get_source_from_source
    from ..utils.ast import get_ast_from_source
    from ..utils.ast import get_source_from_source
    from ..utils.ast import get_source_from_ast
    from ..utils.ast import get_source_from_source
    from ..utils.ast import get_ast_from_source
    from ..utils.ast import get_source_from_source
    from ..utils.ast import get_source_from_ast
    from ..utils.ast import get_source_from_source
   

# Generated at 2022-06-18 00:01:43.445333
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom_1
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom_2
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom_3
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom_4

# Generated at 2022-06-18 00:01:53.706412
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_node_name
    from ..utils.ast_helpers import get_node_names
    from ..utils.ast_helpers import get_node_module
    from ..utils.ast_helpers import get_node_asname
    from ..utils.ast_helpers import get_node_level
    from ..utils.ast_helpers import get_node_names
    from ..utils.ast_helpers import get_node_names_asname
    from ..utils.ast_helpers import get_node_names_name
    from ..utils.ast_helpers import get_node_names_asname
    from ..utils.ast_helpers import get_node_names_name
    from ..utils.ast_helpers import get_node_

# Generated at 2022-06-18 00:01:58.011998
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:02:02.426730
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-18 00:02:06.061520
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:02:39.056107
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.snippet import get_snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_snippet('import foo'))
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == get_snippet('import_rewrite(previous=import foo, current=import bar)')



# Generated at 2022-06-18 00:02:46.146017
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast_node
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_node(get_snippet_body('import foo'))
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:02:56.252193
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast, get_node_type
    from ..utils.ast_helpers import get_node_type_name, get_node_value


# Generated at 2022-06-18 00:03:07.162094
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo")
    expected = ast.parse("try:\n    import foo\nexcept ImportError:\n    import bar")
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse("import foo.bar")
    expected = ast.parse("try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar")
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse("import foo.bar as baz")

# Generated at 2022-06-18 00:03:13.610843
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz
        from foo import bar
        from foo import bar, baz
        from foo import bar as baz
        from foo import bar as baz, baz as foo
        from foo.bar import baz
        from foo.bar import baz as foo
        from foo.bar import baz as foo, bar as baz
        from foo.bar import baz as foo, bar as baz, foo as bar

    @snippet
    def test_snippet_rewrite():
        try:
            import foo
        except ImportError:
            import foo_rewrite as foo


# Generated at 2022-06-18 00:03:22.103932
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestTransformer2(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestTransformer3(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestTransformer4(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestTransformer5(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestTransformer6(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:03:27.809220
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)

    assert result.tree_changed is True
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:33.861561
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:45.513567
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    import_rewrite = snippet('''
    try:
        extend(previous)
    except ImportError:
        extend(current)
    ''')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('''
    import six
    ''')

    expected = get_ast('''
    try:
        extend(ast.Import(names=[ast.alias(name='six', asname='six')]))
    except ImportError:
        extend(ast.Import(names=[ast.alias(name='six.moves', asname='six')]))
    ''')

    assert ast

# Generated at 2022-06-18 00:03:55.991741
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils import get_ast_node

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_node('''
    import foo
    import foo.bar
    import foo.bar.baz
    ''')
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == '''
    try:
        import foo
    except ImportError:
        import bar
    try:
        import foo.bar
    except ImportError:
        import bar.bar
    try:
        import foo.bar.baz
    except ImportError:
        import bar.bar.baz
    '''



# Generated at 2022-06-18 00:04:51.881029
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:05:01.272748
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from .test_BaseImportRewrite_visit_Import import BaseImportRewrite_visit_Import

    class Test(BaseImportRewrite_visit_Import):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('''
import six
''')
    Test.transform(tree)
    assert astor.to_source(tree) == '''
try:
    import six
except ImportError:
    import six.moves as six
'''



# Generated at 2022-06-18 00:05:06.143200
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('''
import six
''')

    expected = ast.parse('''
try:
    import six
except ImportError:
    import six.moves as six
''')

    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected)


# Generated at 2022-06-18 00:05:17.504917
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse
    from ..utils.ast import dump
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:05:28.853445
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)
    assert_dependencies_equal(result, ['foo', 'bar'])
    assert_ast_equal(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result)

# Generated at 2022-06-18 00:05:34.746466
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
''')

    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert compare_ast(tree, expected)
    assert transformer._tree_changed is True



# Generated at 2022-06-18 00:05:46.050675
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..transforms.base import BaseImportRewrite
    from ..transforms.base import BaseNodeTransformer
    from ..transforms.base import BaseTransformer
    from ..types import CompilationTarget
    from ..types import TransformationResult
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import import_rewrite
    from ..transforms.base import BaseImportRewrite
    from ..transforms.base import BaseNodeTransformer


# Generated at 2022-06-18 00:05:56.783552
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.testutils import assert_ast_equal
    from ..utils.testutils import assert_tree_changed

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert_tree_changed(result)
    assert_ast_equal(result.tree, """
    try:
        import foo
    except ImportError:
        import bar
    """)

    tree = ast.parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert_tree_changed(result)

# Generated at 2022-06-18 00:06:07.884487
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import io
    import six
    import typing
    import collections
    import inspect
    import functools
    import contextlib
    import itertools
    import operator
    import keyword
    import tokenize
    import token
    import builtins
    import dis
    import time
    import datetime
    import calendar
    import math
    import random
    import string
    import struct
    import codecs
    import locale
    import copy
    import pickle
    import json
    import hashlib
    import hmac
    import base64
    import binascii
    import zlib
    import platform
    import subprocess
    import multiprocessing
    import threading
    import concurrent
    import concurrent.futures
    import logging


# Generated at 2022-06-18 00:06:14.250366
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast.ast3 import ImportFrom, alias, Try, Import, Name, Store, Assign, Str, Expr, NameConstant, Pass
    from typed_ast.ast3 import Load, Attribute, Call, keyword, arguments, arg, Subscript, Index, List, Tuple, Num, BinOp, Add, Mult
    from typed_ast.ast3 import Compare, Eq, Gt, Lt, GtE, LtE, NotEq, In, NotIn, Is, IsNot, And, Or, BoolOp, UnaryOp, Invert, Not, UAdd, USub, NotEq, USub, UAdd, Eq, NotIn, In, IsNot, Is, LtE, GtE, Lt, Gt, NotE