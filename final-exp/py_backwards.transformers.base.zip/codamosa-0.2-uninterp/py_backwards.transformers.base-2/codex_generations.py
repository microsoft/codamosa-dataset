

# Generated at 2022-06-17 23:57:28.527698
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_compare import compare_ast
    from ..utils.ast_helpers import get_ast_from_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:57:31.930735
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-17 23:57:35.426663
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'



# Generated at 2022-06-17 23:57:44.172259
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert_equal_ast(
        TestImportRewrite().visit(ast.parse('import foo')),
        ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar'))

    assert_equal_ast(
        TestImportRewrite().visit(ast.parse('import foo.bar')),
        ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'))


# Generated at 2022-06-17 23:57:53.801402
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed

    tree = get_ast('import foo.bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed

    tree = get_ast('import foo.bar as baz')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed

    tree = get_ast('import bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert not transformer._tree_changed

# Generated at 2022-06-17 23:58:05.049755
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.test_helpers import assert_ast_equal

    @snippet
    def test_snippet():
        extend(import_rewrite)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(test_snippet.get_source())
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    expected_tree = ast.parse(test_snippet.get_source().replace('foo', 'bar'))
    assert_ast_equal(tree, expected_tree)

    # Test that import is not replaced if it does not match
    tree

# Generated at 2022-06-17 23:58:16.321731
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse('from a import x')
    expected = ast.parse('from b import x')
    assert_ast_equal(TestImportRewrite.transform(tree).tree, expected)

    tree = ast.parse('from a.a import x')
    expected = ast.parse('from b.a import x')
    assert_ast_equal(TestImportRewrite.transform(tree).tree, expected)

    tree = ast.parse('from a.a import x as y')
    expected = ast.parse('from b.a import x as y')

# Generated at 2022-06-17 23:58:22.499110
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:58:27.279419
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:58:35.109628
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(TestImportRewrite.transform(tree).tree, expected)



# Generated at 2022-06-17 23:58:53.368612
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = get_ast('import os')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['os.path']
    assert astor.to_source(result.tree) == 'try:\n    import os\nexcept ImportError:\n    import os.path as os'

    tree = get_ast('import os.path')
    result = TestTransformer.transform(tree)
    assert not result.changed
    assert result.dependencies == []
    assert astor.to_source(result.tree) == 'import os.path'

    tree = get_

# Generated at 2022-06-17 23:59:03.736628
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import baz')
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz'

    tree = get_ast('from foo import baz as qux')

# Generated at 2022-06-17 23:59:10.100405
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed is True
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:59:17.062944
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    expected = get_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')
    assert compare_asts(result.tree, expected)



# Generated at 2022-06-17 23:59:27.681691
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.snippet import snippet, extend

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == astunparse.unparse(import_rewrite.get_body(previous=ast.parse('import foo'),
                                                                                      current=ast.parse('import bar'))[0])
    assert result.changed



# Generated at 2022-06-17 23:59:39.535708
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys
    import os
    import sys

# Generated at 2022-06-17 23:59:51.136729
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import io
    import unittest
    from unittest import mock
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import Mock
    from unittest.mock import mock_open
    from unittest.mock import ANY
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock

# Generated at 2022-06-18 00:00:00.425809
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    import foo.bar
    import foo.bar.baz
    """)

    result = TestImportRewrite.transform(tree)

    assert result.tree.body[0].body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[0].body[1].value.names[0].name == 'bar.bar'
    assert result.tree.body[0].body[0].body[0].body[2].value.names[0].name == 'bar.bar.baz'

# Unit test

# Generated at 2022-06-18 00:00:08.778998
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_builder import build_ast
    from ..utils.ast_compare import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves')
        ]


# Generated at 2022-06-18 00:00:15.062526
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:00:30.642365
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast_node_by_path

    # Test case 1
    tree = ast.parse(
        snippet(
            """
            from foo import bar
            """
        )
    )
    expected_tree = ast.parse(
        snippet(
            """
            try:
                from foo import bar
            except ImportError:
                from foo_rewrite import bar
            """
        )
    )
    rewrites = [('foo', 'foo_rewrite')]
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = rewrites
    transformer.visit(tree)
    assert astor.to_source(tree) == astor.to_source(expected_tree)

    # Test case 2
    tree

# Generated at 2022-06-18 00:00:40.589339
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_node_by_path
    from ..utils.test_utils import assert_node_equal

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
''')

    expected_tree = ast.parse('''
import_rewrite(previous=foo, current=bar)
''')

    TestTransformer.transform(tree)
    assert_node_equal(tree, expected_tree)



# Generated at 2022-06-18 00:00:50.220774
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    import foo
    ''')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == '''
    try:
        import foo
    except ImportError:
        import bar
    '''



# Generated at 2022-06-18 00:00:55.481403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestTransformer.transform(tree)
    assert_ast_equal(expected, result.tree)



# Generated at 2022-06-18 00:01:01.925109
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_names
    from ..utils.ast_helpers import get_ast_node_module
    from ..utils.ast_helpers import get_ast_node_level
    from ..utils.ast_helpers import get_ast_node_asname
    from ..utils.ast_helpers import get_ast_node_names_asnames
    from ..utils.ast_helpers import get_ast_node_names_names
    from ..utils.ast_helpers import get_ast_node_names_asnames_names
    from ..utils.ast_helpers import get_ast_node_names_asnames_asnames

# Generated at 2022-06-18 00:01:10.595312
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    import foo
    ''')

    expected_tree = get_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == astor.to_source(expected_tree)



# Generated at 2022-06-18 00:01:21.935078
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:01:29.995840
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[1].body[0].value.names[0].name == 'foo'
    assert result.tree_changed
    assert TestTransformer.dependencies == ['typed_ast']



# Generated at 2022-06-18 00:01:37.591298
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_module_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_module_ast("""
    import foo
    """)

    expected = get_module_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected)



# Generated at 2022-06-18 00:01:43.628791
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')

    assert ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:02:24.338973
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:02:35.178561
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.rewrites = [('re', 'regex')]
            self.transformer = BaseImportRewrite(None)
            self.transformer.rewrites = self.rewrites

        def test_visit_Import(self):
            node = ast.parse('import re')
            expected = ast.parse('try:\n    import re\nexcept ImportError:\n    import regex')
            result = self.transformer.visit_Import(node.body[0])
            self.assertEqual(astor.to_source(expected), astor.to_source(result))


# Generated at 2022-06-18 00:02:46.338431
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('../../')
    from typed_astunparse import unparse
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import Unparser

# Generated at 2022-06-18 00:02:56.482280
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_node_by_path

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse(snippet.get_body(
        import_rewrite.get_body(previous=ast.Import(names=[ast.alias(name='old', asname='a')]),
                                current=ast.Import(names=[ast.alias(name='new', asname='a')]))[0]))
    TestTransformer.transform(tree)


# Generated at 2022-06-18 00:03:02.886598
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    assert_transformation_result(TestTransformer, tree, expected)



# Generated at 2022-06-18 00:03:11.653035
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    import unittest.mock

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    class TestBaseImportRewrite_visit_ImportFrom(unittest.TestCase):
        def test_rewrite_import_from_module(self):
            code = """
            from six import moves
            """
            tree = ast.parse(code)
            TestBaseImportRewrite.transform(tree)
            self.assertEqual(astor.to_source(tree).strip(), """
            try:
                from six import moves
            except ImportError:
                from six.moves import moves
            """.strip())


# Generated at 2022-06-18 00:03:21.111061
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert_source_equal(astor.to_source(result.tree), 'try:\n    import foo\nexcept ImportError:\n    import bar')

    tree = ast.parse('import foo.bar')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert_source_equal(astor.to_source(result.tree), 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')


# Generated at 2022-06-18 00:03:26.546888
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    assert_ast_equal(TestImportRewrite.transform(tree).tree, expected)



# Generated at 2022-06-18 00:03:36.628726
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
    import foo
    import foo.bar
    import foo.bar.baz
    from foo import bar
    from foo import bar, baz
    from foo import bar as baz
    from foo import bar as baz, baz as qux
    from foo.bar import baz
    from foo.bar import baz, qux
    from foo.bar import baz as qux
    from foo.bar import baz as qux, qux as quux
    ''')

    TestImportRewrite.transform(tree)


# Generated at 2022-06-18 00:03:47.696864
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_equal_ast(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_code(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_source(result.tree, 'try:\n    import foo\nexcept ImportError:\n    import bar')



# Generated at 2022-06-18 00:04:38.021408
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')
        ]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert_equal_ast(result.tree,
                     ast.parse('''
try:
    import foo
except ImportError:
    import bar
'''))
    assert result.changed
    assert_equal_code(result.tree, '''
try:
    import foo
except ImportError:
    import bar
''')
    assert_equal_

# Generated at 2022-06-18 00:04:44.476731
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_transformation_result

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_transformation_result(TestTransformer, tree, expected)



# Generated at 2022-06-18 00:04:52.615124
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    class TestImportRewrite2(BaseImportRewrite):
        rewrites = [('os', 'os.path'), ('sys', 'sys.path')]

    class TestImportRewrite3(BaseImportRewrite):
        rewrites = [('os.path', 'os.path.path')]

    class TestImportRewrite4(BaseImportRewrite):
        rewrites = [('os.path', 'os.path.path'), ('sys', 'sys.path')]


# Generated at 2022-06-18 00:04:59.164914
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['bar']
    assert ast.dump(result.tree) == '''
try:
    import foo
except ImportError:
    import bar
'''



# Generated at 2022-06-18 00:05:04.611354
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'
    assert result.changed is True


# Generated at 2022-06-18 00:05:16.526302
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_BaseImportRewrite import BaseImportRewrite
    from test_BaseImportRewrite import BaseNodeTransformer
    from test_BaseImportRewrite import BaseTransformer
    from test_BaseImportRewrite import import_rewrite
    from test_BaseImportRewrite import snippet
    from test_BaseImportRewrite import extend
    from test_BaseImportRewrite import TransformationResult
    from test_BaseImportRewrite import CompilationTarget
    from test_BaseImportRewrite import ABCMeta
    from test_BaseImportRewrite import abstractmethod
    from test_BaseImportRewrite import List
    from test_BaseImportRewrite import Tuple

# Generated at 2022-06-18 00:05:26.742240
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_node_by_path
    from ..utils.snippet import get_snippet_body

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = ast.parse(get_snippet_body(test_BaseImportRewrite_visit_Import))
    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(get_node_by_path(result.tree, [0, 0])) == 'try:\n    import os\nexcept ImportError:\n    import os.path'



# Generated at 2022-06-18 00:05:33.525223
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
    import foo
    """)
    expected_tree = get_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected_tree)



# Generated at 2022-06-18 00:05:45.259719
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = parse_ast(test_snippet)
    transformer = TestTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-18 00:05:53.896057
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast
    import sys
    import os
    import io
    import unittest

    class TestBaseImportRewrite(unittest.TestCase):
        def test_visit_Import(self):
            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'pathlib')]

            tree = ast.parse('import os')
            transformer = TestTransformer(tree)
            transformer.visit(tree)
            self.assertEqual(astor.to_source(tree), 'try:\n    import os\nexcept ImportError:\n    import pathlib as os')

    unittest.main()
