

# Generated at 2022-06-17 23:57:34.868972
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_names
    from ..utils.ast_helpers import get_ast_node_module
    from ..utils.ast_helpers import get_ast_node_asname
    from ..utils.ast_helpers import get_ast_node_level
    from ..utils.ast_helpers import get_ast_node_names_asnames
    from ..utils.ast_helpers import get_ast_node_names_names
    from ..utils.ast_helpers import get_ast_node_names_asnames_names
    from ..utils.ast_helpers import get_ast_node_names

# Generated at 2022-06-17 23:57:43.749530
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_BaseImportRewrite import BaseImportRewrite as test_BaseImportRewrite
    class TestBaseImportRewrite(test_BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    tree = ast.parse('from six import StringIO')
    TestBaseImportRewrite.transform(tree)
    assert astor.to_source(tree) == 'try:\n    from six import StringIO\nexcept ImportError:\n    from six.moves import StringIO'
    tree = ast.parse('from six.moves import StringIO')
    TestBaseImportRewrite.transform(tree)

# Generated at 2022-06-17 23:57:46.894097
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = astor.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astor.to_source(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-17 23:57:52.576117
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_node_of_class
    from ..utils.ast_helpers import get_node_of_class_by_name

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('import six')
    transformer = TestTransformer(tree)
    transformer.visit_Import(get_node_of_class(tree, ast.Import))

    assert transformer._tree_changed is True
    assert get_node_of_class(tree, ast.Try) is not None
    assert get_node_of_class_by_name(tree, ast.Import, 'six') is not None

# Generated at 2022-06-17 23:58:04.403942
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = parse_ast(test_snippet)
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == """\
try:
    import foo
except ImportError:
    import bar
try:
    import foo.bar
except ImportError:
    import bar.bar
try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz"""



# Generated at 2022-06-17 23:58:15.949832
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]


# Generated at 2022-06-17 23:58:22.637876
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-17 23:58:27.441108
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert dump_ast(tree) == 'try:\n    import bar\nexcept ImportError:\n    import foo'



# Generated at 2022-06-17 23:58:39.764011
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('foo.bar', 'baz.bar')
        ]


# Generated at 2022-06-17 23:58:50.978561
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from_module():
        from foo import bar

    @snippet
    def test_import_from_module_with_as():
        from foo import bar as baz

    @snippet
    def test_import_from_module_with_as_and_multiple_names():
        from foo import bar as baz, qux

    @snippet
    def test_import_from_module_with_multiple_names():
        from foo import bar, qux


# Generated at 2022-06-17 23:59:04.931511
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_node_at_line

    @snippet
    def test_snippet():
        import foo
        import bar.baz

    tree = ast.parse(test_snippet.get_body())
    node = get_node_at_line(tree, 1)
    assert isinstance(node, ast.Import)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'foo_rewrite')]

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo_rewrite']

# Generated at 2022-06-17 23:59:14.577551
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_code_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo
        import foo.bar

    tree = ast.parse(test_snippet.get_source())
    TestTransformer.transform(tree)
    assert_code_equal(astor.to_source(tree),
                      test_snippet.get_source(previous='import foo',
                                              current='try:\n    import foo\nexcept ImportError:\n    import bar'))



# Generated at 2022-06-17 23:59:22.655110
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io
    import re
    import sys
    import os
    import io

# Generated at 2022-06-17 23:59:31.857784
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
import foo.bar
import foo.bar.baz
''')

    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar

try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz
''')

    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected)
    assert astunparse.unparse(result.tree) == astun

# Generated at 2022-06-17 23:59:42.087128
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    import_rewrite = snippet(
        """
        try:
            extend(previous)
        except ImportError:
            extend(current)
        """
    )
    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = [('six', 'six.moves')]
        def _get_matched_rewrite(self, name):
            if name is None:
                return None
            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to
            return None

# Generated at 2022-06-17 23:59:53.582929
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:00:01.881981
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    from ..utils.test_utils import assert_code_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = '''
    from foo import a, b, c
    from foo.bar import d, e, f
    from foo.bar.baz import g, h, i
    from foo.bar.baz.qux import j, k, l
    '''
    tree = ast.parse(code)
    TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:00:12.219707
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    @snippet
    def test_snippet():
        import six
        import six.moves

    expected = astor.to_source(ast.parse(test_snippet.get_body()))

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == expected

    tree = ast.parse('import six.moves')
    result = TestTransformer.transform(tree)
    assert not result.changed
    assert astor.to_source(result.tree) == astor.to

# Generated at 2022-06-18 00:00:20.510594
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import get_node_name
    from ..utils.ast_helpers import get_node_names
    from ..utils.ast_helpers import get_node_module

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.qux
    """)

    result = TestImportRewrite.transform(tree)
    assert result.changed is True

    import_ = tree.body[0]
    assert get_node_name(import_) == 'foo'
    assert isinstance(import_, ast.Try)

    import_ = tree

# Generated at 2022-06-18 00:00:29.792309
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3

# Generated at 2022-06-18 00:00:47.758403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet
    import_rewrite = snippet('import_rewrite')
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    tree = ast.parse("import six")
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == import_rewrite.get_body(previous="import six", current="import six.moves")[0]


# Generated at 2022-06-18 00:00:52.857688
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    expected = ast.parse('try:\n    import old\nexcept ImportError:\n    import new')

    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:01:00.480982
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_asname
    from ..utils.ast_helpers import get_ast_node_names
    from ..utils.ast_helpers import get_ast_node_level
    from ..utils.ast_helpers import get_ast_node_names_asnames
    from ..utils.ast_helpers import get_ast_node_names_names
    from ..utils.ast_helpers import get_ast_node_names_asnames_names
    from ..utils.ast_helpers import get_ast_node_names_asnames_asnames
    from ..utils.ast_helpers import get_ast_node_names_asnames_asnames_names
   

# Generated at 2022-06-18 00:01:12.376871
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    import textwrap
    from typing import List, Tuple, Union, Optional, Iterable, Dict
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget, TransformationResult
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend
    from ..utils.snippet import snippet, extend

# Generated at 2022-06-18 00:01:20.825518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import compare_ast_trees

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source('import foo')
    expected = get_ast_from_source('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert compare_ast_trees(result.tree, expected)



# Generated at 2022-06-18 00:01:27.385743
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:01:36.071494
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse
    from ..utils.ast import dump
    from ..utils.ast import compare

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = parse('''
    import six
    import six.moves.urllib.parse
    ''')

    expected = parse('''
    try:
        import six
    except ImportError:
        import six.moves as six
    import six.moves.urllib.parse
    ''')

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert compare(result.tree, expected)



# Generated at 2022-06-18 00:01:43.212432
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = snippet_to_ast("""
    import foo
    """)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == """
    try:
        import foo
    except ImportError:
        import bar
    """



# Generated at 2022-06-18 00:01:50.488957
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
   

# Generated at 2022-06-18 00:01:56.614713
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:02:27.795548
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import io
    import unittest
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as ast

# Generated at 2022-06-18 00:02:37.044710
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
from foo import *
from foo import bar
from foo import bar as baz
from foo.bar import baz
from foo.bar import baz as qux
''')

    TestImportRewrite.transform(tree)


# Generated at 2022-06-18 00:02:47.735078
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:02:57.776283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import get_test_tree

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:03:08.786968
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('from foo import bar').body[0]
    import_from_rewrite = ast.parse('from foo import bar').body[0]
    import_from_rewrite.names[0].name = 'bar_rewrite'
    import_from_rewrite.names[0].asname = 'bar_rewrite'
    import_from_rewrite = ast.Try(body=[import_from_rewrite],
                                  handlers=[],
                                  orelse=[],
                                  finalbody=[])
    import_from_rewrite = astor.to_source(import_from_rewrite)
    import_from_rewrite = astor.code_to_ast(import_from_rewrite)

# Generated at 2022-06-18 00:03:19.229600
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
        ]


# Generated at 2022-06-18 00:03:25.282631
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:03:36.012609
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.snippet import get_snippet_body

    import_from_snippet = get_snippet_body(import_rewrite)
    import_from_ast = ast.parse(import_from_snippet)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:03:47.292544
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.ast_helpers import get_ast_node_path
    from ..utils.ast_helpers import get_ast_node_by_path

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves')
        ]


# Generated at 2022-06-18 00:03:58.407718
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = '''
from six import iteritems
from six.moves import map
from six.moves import range
from six.moves import zip
from six.moves import zip_longest
'''
    tree = get_ast(source)
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:04:47.153535
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('/home/user/PycharmProjects/python-to-python-bytecode/tests/data/')
    from test_BaseImportRewrite_visit_ImportFrom import test_BaseImportRewrite_visit_ImportFrom
    tree = astor.code_to_ast.parse_file('/home/user/PycharmProjects/python-to-python-bytecode/tests/data/test_BaseImportRewrite_visit_ImportFrom.py')
    tree = BaseImportRewrite.transform(tree)
    assert astor.to_source(tree) == test_BaseImportRewrite_visit_ImportFrom

# Generated at 2022-06-18 00:04:52.936367
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(snippet.get_body(
        import_foo='import foo'
    )[0])
    result = TestTransformer.transform(tree)

    assert astor.to_source(result.tree) == snippet.get_body(
        import_foo='try:\n    import foo\nexcept ImportError:\n    import bar'
    )[0]



# Generated at 2022-06-18 00:05:02.525548
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse
    from ..utils.compat import ast_parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit_Import(tree.body[0])
    assert isinstance(result, ast.Try)
    assert ast_parse('import bar').body[0].names[0].name == result.body[0].body[0].names[0].name
    assert ast_parse('import foo').body[0].names[0].name == result.body[1].body[0].names[0].name


# Generated at 2022-06-18 00:05:10.421695
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert_equal_ast(expected, result.tree)



# Generated at 2022-06-18 00:05:19.106016
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source
    from ..utils.source_helpers import get_source_for_node
    from ..utils.source_helpers import get_source_for_node_list
    from ..utils.source_helpers import get_source_for_node_list_with_indent
    from ..utils.source_helpers import get_source_for_node_with_indent

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast(get_source('import foo'))
    result = TestTransformer.transform(tree)
    assert result.changed
    assert get_source_for_node(result.tree)

# Generated at 2022-06-18 00:05:29.661660
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo")
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == "try:\n    import foo\nexcept ImportError:\n    import bar"

    tree = ast.parse("import foo.bar")
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == "try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar"

    tree = ast.parse("import foo.bar as baz")
    TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:05:36.867917
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    from ..utils.snippet import get_body
    from ..utils.snippet import get_body_ast
    from ..utils.snippet import get_body_ast_node
    from ..utils.snippet import get_body_ast_node_list
    from ..utils.snippet import get_body_ast_node_list_item
    from ..utils.snippet import get_body_ast_node_list_item_list
    from ..utils.snippet import get_body_ast_node_list_item_list_item
    from ..utils.snippet import get_body_ast_node_list_item_list_item_list

# Generated at 2022-06-18 00:05:46.539916
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_utils import parse_ast
    from ..utils.ast_utils import ast_to_source
    from ..utils.ast_utils import compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = parse_ast("""
    import six
    """)

    expected = parse_ast("""
    try:
        import six
    except ImportError:
        import six.moves
    """)

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:05:57.308372
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = parse(test_snippet.get_body())

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo_rewrite'),
            ('foo.bar', 'foo_rewrite.bar_rewrite')
        ]

    result = TestImportRewrite.transform(tree)
    assert result.changed


# Generated at 2022-06-18 00:06:06.223439
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_node_type

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert get_node_type(tree) == 'Try'
    assert get_node_type(tree.body[0]) == 'Import'
    assert tree.body[0].names[0].name == 'bar'
