

# Generated at 2022-06-17 23:57:34.521777
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_3_6
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['six.moves']
    assert result.tree.body[0] == import_rewrite.get_body(previous=tree.body[0],  # type: ignore
                                                          current=ast.Import(names=[ast.alias(name='six.moves',
                                                                                             asname='six')]))[0]



# Generated at 2022-06-17 23:57:43.486707
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = get_ast('import foo.bar')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = get_ast('import foo.bar as baz')
    transformer = Test

# Generated at 2022-06-17 23:57:46.680627
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'pathlib')]

    tree = ast.parse('import os')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import os\nexcept ImportError:\n    import pathlib as os'



# Generated at 2022-06-17 23:57:52.268475
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast("""
        import six
        import six.moves
        import six.moves.urllib
        import six.moves.urllib.request
        import six.moves.urllib.request.urlopen
        import six.moves.urllib.request.urlopen as urlopen
    """)


# Generated at 2022-06-17 23:58:04.073432
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_utils import get_ast
    from ..utils.ast_utils import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast("""
from foo import a, b
from foo import c as d
from foo import *
from foo.bar import a, b
from foo.bar import c as d
from foo.bar import *
from foo.bar.baz import a, b
from foo.bar.baz import c as d
from foo.bar.baz import *
    """)


# Generated at 2022-06-17 23:58:10.625694
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transform

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    assert_transform(TestTransformer,
                     'import six',
                     'try:\n    import six\nexcept ImportError:\n    import six.moves')



# Generated at 2022-06-17 23:58:19.705443
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import io
    import collections
    import typing
    import six
    import typing_extensions
    import typing_inspect
    import enum
    import functools
    import inspect
    import contextlib
    import abc
    import asyncio
    import asyncio.coroutines
    import asyncio.tasks
    import asyncio.queues
    import asyncio.locks
    import asyncio.events
    import asyncio.futures
    import asyncio.streams
    import asyncio.proactor_events
    import asyncio.base_events
    import asyncio.base_subprocess
    import asyncio.base_tasks
    import asyncio.base_futures
    import asyncio.base_events
    import asyncio

# Generated at 2022-06-17 23:58:30.253444
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    from foo import bar
    from foo import baz
    from foo import *
    from foo.bar import baz
    from foo.bar import *
    from foo.bar.baz import *
    from foo.bar.baz import baz
    """)


# Generated at 2022-06-17 23:58:37.657588
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_ast_equal(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-17 23:58:44.192443
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from_module():
        from foo import bar

    @snippet
    def test_import_from_names():
        from foo import bar, baz

    @snippet
    def test_import_from_names_with_as():
        from foo import bar as baz

    @snippet
    def test_import_from_names_with_as_and_alias():
        from foo import bar as baz, baz as qux

    @snippet
    def test_import_from_names_with_alias():
        from foo import bar as b

# Generated at 2022-06-17 23:59:04.423835
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import baz')
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz')

    tree = ast.parse('from foo import baz, bar')
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n    from foo import baz, bar\nexcept ImportError:\n    from bar import baz, bar')


# Generated at 2022-06-17 23:59:15.104627
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast
    from ..utils.compat import get_ast_arguments

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from():
        from foo import bar, baz
        from foo.bar import baz
        from foo.bar import baz as qux
        from foo.bar import baz as qux, quux
        from foo.bar import baz as qux, quux as quuz
        from foo.bar import baz as qux, quux as quuz, corge
        from foo.bar import baz as qux, quux as quuz, corge as grault
        from foo.bar import b

# Generated at 2022-06-17 23:59:22.940821
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo
        import foo.bar
        import foo.bar.baz

    tree = get_ast(test_import)
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == """
try:
    import foo
except ImportError:
    import bar

try:
    import foo.bar
except ImportError:
    import bar.bar

try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz
"""


# Generated at 2022-06-17 23:59:31.998062
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast_from_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo
        import foo.bar

    @snippet
    def test_import_as():
        import foo as bar
        import foo.bar as baz

    @snippet
    def test_from_import():
        from foo import bar
        from foo.bar import baz

    @snippet
    def test_from_import_as():
        from foo import bar as baz
        from foo.bar import baz as qux


# Generated at 2022-06-17 23:59:42.152779
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import_from_module():
        from foo import baz
        from foo import bar as baz
        from foo import foo as bar
        from foo import foo as bar, baz
        from foo import foo as bar, baz as foo

    @snippet
    def test_import_from_module_rewrite():
        try:
            from foo import baz
        except ImportError:
            from bar import baz
        try:
            from foo import bar as baz
        except ImportError:
            from bar import bar as baz

# Generated at 2022-06-17 23:59:51.041548
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('''
        import foo
    ''')
    expected_tree = get_ast('''
        try:
            import foo
        except ImportError:
            import bar
    ''')

    TestTransformer.transform(tree)
    assert astor.to_source(tree) == astor.to_source(expected_tree)



# Generated at 2022-06-18 00:00:00.352812
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse
    from ..utils.ast import dump
    from ..utils.ast import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_mock')]


# Generated at 2022-06-18 00:00:08.558518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']
    assert ast.dump(result.tree) == 'Try(\n' \
                                    '    Import(names=[alias(name=\'bar\', asname=\'foo\')]),\n' \
                                    '    ExceptHandler(type=None, name=None, body=[Import(names=[alias(name=\'foo\', asname=\'foo\')])]),\n' \
                                    '    orelse=[],\n' \
                                    '    finalbody=[])'



# Generated at 2022-06-18 00:00:14.953804
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_ast_not_equal
    from ..utils.test_utils import assert_ast_not_equal_with_msg
    from ..utils.test_utils import assert_ast_equal_with_msg
    from ..utils.test_utils import assert_ast_not_equal_with_msg
    from ..utils.test_utils import assert_ast_equal_with_msg
    from ..utils.test_utils import assert_ast_not_equal_with_msg
    from ..utils.test_utils import assert_ast_equal_with_msg
    from ..utils.test_utils import assert_ast_not_equal_with_msg
    from ..utils.test_utils import assert_ast_equal_with_msg

# Generated at 2022-06-18 00:00:21.412995
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.testutils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')

    result = TestTransformer.transform(tree)
    assert_ast_equal(astor.to_source(result.tree), astor.to_source(expected))



# Generated at 2022-06-18 00:00:37.985785
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    tree = ast.parse('import foo')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    assert astor.to_source(result) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:00:47.759292
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves', 'six.moves')
        ]

    tree = parse_ast("""
from six.moves import urllib
from six import urllib
from six.moves import urllib as url
from six import urllib as url
from six.moves import *
from six import *
""")


# Generated at 2022-06-18 00:00:54.503206
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'import foo'
    expected = 'try:\n    import foo\nexcept ImportError:\n    import bar'
    tree = get_ast_from_source(source)
    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_asts(expected, result.tree)



# Generated at 2022-06-18 00:00:59.105634
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse("""
try:
    import foo
except ImportError:
    import bar
""")
    assert_equal_ast(TestImportRewrite.transform(tree).tree, expected)



# Generated at 2022-06-18 00:01:10.218053
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_import_from_rewrite():
        from foo import bar
        from foo import baz
        from foo import qux as quux
        from foo import quuz as corge
        from foo import grault
        from foo import garply
        from foo import waldo
        from foo import fred
        from foo import plugh
        from foo import xyzzy
        from foo import thud


# Generated at 2022-06-18 00:01:18.116222
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == astunparse.unparse(
        ast.parse('''
try:
    import foo
except ImportError:
    import bar
'''))



# Generated at 2022-06-18 00:01:28.560784
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import unittest
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast27
    from typed_ast import ast35 as typed_ast35
    from typed_ast import ast36 as typed_ast36
    from typed_ast import ast38 as typed_ast38
    from typed_ast import ast39 as typed_ast39
    from typed_ast import ast40 as typed_ast40
    from typed_ast import ast41 as typed_ast41
    from typed_ast import ast42 as typed_ast42
    from typed_ast import ast43 as typed_ast43
    from typed_ast import ast44 as typed_ast44
    from typed_ast import ast45 as typed_ast45

# Generated at 2022-06-18 00:01:34.494849
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import get_source_from_ast
    from ..utils.ast_helpers import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
from foo import a, b
from foo import *
from foo.bar import c, d
from foo.bar import *
from foo.bar.baz import e, f
from foo.bar.baz import *
'''

# Generated at 2022-06-18 00:01:44.906063
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3
    from typed_ast.ast3 import ImportFrom, alias, Try, Import, Assign, Name, Store, Load, Str, Expr, Pass, Module
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import AST


# Generated at 2022-06-18 00:01:51.428606
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    from foo import baz
    from foo import *
    from foo.bar import baz
    from foo.bar import *
    from foo.bar.baz import baz
    from foo.bar.baz import *
    from foo.bar.baz.qux import baz
    from foo.bar.baz.qux import *
    """)


# Generated at 2022-06-18 00:02:21.781917
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import baz')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz'

    tree = get_ast('from foo.baz import bar')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    from foo.baz import bar\nexcept ImportError:\n    from bar.baz import bar'

    tree = get_ast('from foo.baz import bar as baz')

# Generated at 2022-06-18 00:02:33.850431
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')
        ]

    tree = get_ast('from foo import bar, baz')
    result = TestImportRewrite.transform(tree)
    assert astor.to_source(result.tree) == '''\
try:
    from foo import bar, baz
except ImportError:
    from bar import bar
    from qux import baz
'''

    tree = get_ast('from foo import bar as baz')
    result = TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:02:40.231009
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_utils import ast_to_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert ast_to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:02:49.878579
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_node = ast.parse('import foo').body[0]
    import_rewrite_node = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo_bar').body[0]
    import_rewrite_node_2 = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo_bar.foo').body[0]
    import_rewrite_node_3 = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo_bar.foo.bar').body[0]
    import_rewrite_node_4 = ast.parse('try:\n    import foo\nexcept ImportError:\n    import foo_bar.foo.bar.baz').body[0]

# Generated at 2022-06-18 00:02:58.416170
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re
    import io
    import sys
    import os
    import re

# Generated at 2022-06-18 00:03:09.360639
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import baz')
    expected = get_ast('try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz')
    compare_ast(expected, TestImportRewrite.transform(tree).tree)

    tree = get_ast('from foo import baz as qux')
    expected = get_ast('try:\n    from foo import baz as qux\nexcept ImportError:\n    from bar import baz as qux')
    compare_ast(expected, TestImportRewrite.transform(tree).tree)


# Generated at 2022-06-18 00:03:19.774833
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    import textwrap
    import unittest

    from typed_ast import ast3 as typed_ast

    from typed_astunparse import unparse

    from ..utils.snippet import snippet

    class TestBaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.rewrites = [('foo', 'bar')]
            self.transformer = BaseImportRewrite(None)
            self.transformer.rewrites = self.rewrites

        def test_visit_Import_no_rewrite(self):
            node = ast.parse('import foo')
            self.assertEqual(self.transformer.visit_Import(node), node)

        def test_visit_Import_rewrite(self):
            node = ast.parse('import foo')
           

# Generated at 2022-06-18 00:03:28.191071
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = ast.parse('import foo.bar')
    result = TestImportRewrite.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar'

    tree = ast.parse('import foo.bar as baz')
    result = TestImportRewrite.transform

# Generated at 2022-06-18 00:03:35.277556
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_ast(result.tree, expected)



# Generated at 2022-06-18 00:03:42.506502
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)

    expected_tree = parse_ast("""
    try:
        import foo
    except ImportError:
        import bar
    """)

    assert_transformation_result(TestImportRewrite, tree, expected_tree)



# Generated at 2022-06-18 00:04:36.550413
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo

    @snippet
    def test_import_as():
        import foo as bar

    @snippet
    def test_import_from():
        from foo import bar

    @snippet
    def test_import_from_as():
        from foo import bar as baz

    @snippet
    def test_import_from_all():
        from foo import *


# Generated at 2022-06-18 00:04:43.522461
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = [('foo', 'bar')]
    import_node = ast.parse('import foo').body[0]
    import_rewrite.visit(import_node)
    assert astor.to_source(import_node) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:04:50.371448
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import compare_source

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux'),
        ]


# Generated at 2022-06-18 00:05:00.604393
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_code():
        import foo
        from foo import bar
        from foo import baz as baz1
        from foo import baz as baz2
        from foo import baz as baz3
        from foo import baz as baz4
        from foo import baz as baz5
        from foo import baz as baz6
        from foo import baz as baz7
        from foo import baz as baz8
        from foo import baz as baz9
        from foo import baz as baz10
        from foo import baz as baz11
        from foo import baz as baz12
        from foo import baz as baz13

# Generated at 2022-06-18 00:05:05.005919
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import baz')
    result = TestImportRewrite.transform(tree)
    assert result.tree == ast.parse('try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz')

# Generated at 2022-06-18 00:05:16.725780
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_node_by_path
    from ..utils.ast_helpers import get_node_by_path_and_type
    from ..utils.ast_helpers import get_node_by_path_and_type_and_attr
    from ..utils.ast_helpers import get_node_by_path_and_type_and_attr_and_value
    from ..utils.ast_helpers import get_node_by_path_and_type_and_attr_and_value_and_attr
    from ..utils.ast_helpers import get_node_by_path_and_type_and_attr_and_value_and_attr_and_value
    from ..utils.ast_helpers import get_

# Generated at 2022-06-18 00:05:24.334691
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import ast_to_source

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    result = TestTransformer.transform(tree)
    assert ast_to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:33.340884
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz as qux
from foo.bar import quux
from foo.bar import quuz as corge
from foo.bar.grault import garply
from foo.bar.grault import waldo as fred
''')


# Generated at 2022-06-18 00:05:39.757723
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:48.379726
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet
    from ..utils.ast import get_ast_from_source

    @snippet
    def test_snippet():
        import foo
        import foo.bar
        import foo.bar.baz
        from foo import bar
        from foo import bar as baz
        from foo import bar, baz
        from foo import bar as baz, baz as bar
        from foo import *
        from foo.bar import baz
        from foo.bar import baz as bar
        from foo.bar import baz, bar
        from foo.bar import baz as bar, bar as baz
        from foo.bar import *
        from foo.bar.baz import bar
        from foo.bar.baz import bar as baz

# Generated at 2022-06-18 00:07:07.740331
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_snippet():
        import foo

    tree = get_ast(test_snippet)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == '''\
try:
    import foo
except ImportError:
    import bar
'''



# Generated at 2022-06-18 00:07:14.333042
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected = get_ast('''
try:
    import foo
except ImportError:
    import bar
''')

    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert compare_ast(tree, expected)



# Generated at 2022-06-18 00:07:20.834809
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast import get_ast
    from ..utils.snippet import get_snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast(get_snippet('import_from.py'))
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == get_snippet('import_from_rewrite.py')

