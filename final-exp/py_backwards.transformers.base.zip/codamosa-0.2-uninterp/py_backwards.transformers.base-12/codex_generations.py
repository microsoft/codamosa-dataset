

# Generated at 2022-06-17 23:57:41.421789
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz.qux
    """)
    TestTransformer.transform(tree)


# Generated at 2022-06-17 23:57:47.697710
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'foo'


# Generated at 2022-06-17 23:57:55.813285
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @snippet
    def test_import():
        import foo

    @snippet
    def test_import_as():
        import foo as bar

    @snippet
    def test_import_from():
        from foo import bar

    @snippet
    def test_import_from_as():
        from foo import bar as baz

    @snippet
    def test_import_from_as_star():
        from foo import *


# Generated at 2022-06-17 23:58:05.457534
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.ast_helpers import get_ast

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('from foo import baz')
    Test.transform(tree)
    assert astor.to_source(tree) == 'try:\n    from bar import baz\nexcept ImportError:\n    from foo import baz'

    tree = get_ast('from foo import *')
    Test.transform(tree)
    assert astor.to_source(tree) == 'from foo import *'

    tree = get_ast('from foo import baz as baz2')
    Test.transform(tree)

# Generated at 2022-06-17 23:58:16.321668
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.qux
    ''')
    TestTransformer.transform(tree)

# Generated at 2022-06-17 23:58:22.978795
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_ast_from_source_as_string

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast_from_source('import foo')
    expected = get_ast_from_source_as_string('''
    try:
        import foo
    except ImportError:
        import bar
    ''')
    result = TestTransformer.transform(tree)
    assert_ast_equal(expected, result.tree)



# Generated at 2022-06-17 23:58:34.468382
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test import assert_ast_equal
    from ..utils.test import assert_tree_changed
    from ..utils.test import assert_dependencies_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import baz')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result, True)
    assert_dependencies_equal(result, ['bar'])
    assert_ast_equal(result.tree, 'try:\n    from bar import baz\nexcept ImportError:\n    from foo import baz')

    tree = ast.parse('from foo import *')
    result = TestImportRewrite.transform(tree)
    assert_tree_changed(result, True)
    assert_depend

# Generated at 2022-06-17 23:58:42.982008
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-17 23:58:53.531065
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast

# Generated at 2022-06-17 23:59:01.803853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet, extend

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
''')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected)



# Generated at 2022-06-17 23:59:14.776026
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from typed_ast import ast3 as typed_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'typed_ast.ast3')]

    tree = ast.parse('import os')
    typed_tree = typed_ast.parse('import os')
    result = TestTransformer.transform(typed_tree)
    assert astor.to_source(tree) == astor.to_source(result.tree)



# Generated at 2022-06-17 23:59:21.232504
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_asts

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected_tree = get_ast('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    result = TestTransformer.transform(tree)
    assert result.changed
    assert compare_asts(result.tree, expected_tree)



# Generated at 2022-06-17 23:59:28.160312
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert result.dependencies == ['foo', 'bar']

    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert ast.dump(result.tree) == ast.dump(expected)



# Generated at 2022-06-17 23:59:39.593187
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = '''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar.baz import qux
from foo.bar.baz import *
'''

# Generated at 2022-06-17 23:59:51.182227
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
import foo
import foo.bar
import foo.bar.baz
import foo.bar.baz as baz
''')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
try:
    import foo.bar
except ImportError:
    import bar.bar
try:
    import foo.bar.baz
except ImportError:
    import bar.bar.baz
try:
    import foo.bar.baz as baz
except ImportError:
    import bar.bar.baz as baz
''')
    result = TestTransformer

# Generated at 2022-06-17 23:59:56.591720
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_source_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'from foo import bar, baz'
    tree = ast.parse(source)
    TestImportRewrite.transform(tree)
    assert_source_equal(astor.to_source(tree),
                        'try:\n    from foo import bar, baz\nexcept ImportError:\n    from bar import bar, baz')

    source = 'from foo.bar import baz'
    tree = ast.parse(source)
    TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:00:06.821757
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    @snippet
    def test_snippet():
        import a
        import a.b
        import a.b.c

    expected = """
    try:
        import a
    except ImportError:
        import b
    try:
        import a.b
    except ImportError:
        import b.b
    try:
        import a.b.c
    except ImportError:
        import b.b.c
    """

    tree = ast.parse(test_snippet.get_source())
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:00:17.967205
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('../../')
    from py2ts.transformers.base import BaseImportRewrite
    from py2ts.transformers.base import import_rewrite

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('from six import StringIO')
    TestImportRewrite.transform(tree)
    assert astor.to_source(tree) == '''
try:
    from six import StringIO
except ImportError:
    from six.moves import StringIO
'''

    tree = ast.parse('from six import StringIO as sio')
    TestImportRewrite.transform(tree)

# Generated at 2022-06-18 00:00:25.594187
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestImportRewrite.transform(tree)
    assert_ast_equal(astor.to_source(result.tree), astor.to_source(expected))



# Generated at 2022-06-18 00:00:31.297557
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_ast_equal
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_ast_equal(TestTransformer.transform(tree).tree, expected)



# Generated at 2022-06-18 00:00:52.396288
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.compat import get_argspec

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    ''')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == '''
    try:
        import foo
    except ImportError:
        import bar
    '''

    tree = ast.parse('''
    import foo.bar
    ''')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert ast

# Generated at 2022-06-18 00:00:57.879077
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('os', 'os.path'),
        ]

    test_code = 'import os'
    tree = ast.parse(test_code)
    TestTransformer.transform(tree)
    assert astor.to_source(tree) == '''
try:
    import os
except ImportError:
    import os.path as os
'''



# Generated at 2022-06-18 00:01:05.109453
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast('import six')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves as six'



# Generated at 2022-06-18 00:01:16.252931
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import re
    import astunparse
    import astor
    import ast
   

# Generated at 2022-06-18 00:01:23.509676
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = get_ast('''
        import foo
    ''')

    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert astor.to_source(tree) == '''
        try:
            import foo
        except ImportError:
            import bar
    '''



# Generated at 2022-06-18 00:01:34.310995
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import get_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = get_ast('from old import a, b')
    result = TestImportRewrite.transform(tree)
    assert result.tree == get_ast('try:\n    from old import a, b\nexcept ImportError:\n    from new import a, b')
    assert result.changed is True
    assert result.dependencies == []

    tree = get_ast('from old.a import b')
    result = TestImportRewrite.transform(tree)
    assert result.tree == get_ast('try:\n    from old.a import b\nexcept ImportError:\n    from new.a import b')
    assert result.changed is True
    assert result.depend

# Generated at 2022-06-18 00:01:44.678723
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test import assert_ast_equal
    from typed_ast.ast3 import parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-18 00:01:50.224273
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.changed
    assert astor.to_source(result.tree) == astunparse.unparse(
        ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar'))



# Generated at 2022-06-18 00:01:59.199774
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import bar
from foo import baz
from foo import *
from foo.bar import baz
from foo.bar import *
from foo.bar import baz as qux
from foo.bar import * as qux
from foo.bar import baz as qux, * as qux
''')

    TestTransformer.transform(tree)


# Generated at 2022-06-18 00:02:05.535052
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    result = TestImportRewrite.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'foo'
    assert result.tree.body[0].body[1].body[0].value.names[0].name == 'bar'
    assert result.changed is True
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-18 00:02:37.156574
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = get_ast('import foo')
    expected_tree = get_ast('''
try:
    import foo
except ImportError:
    import bar
    ''')

    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected_tree)



# Generated at 2022-06-18 00:02:47.833197
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
        ]

    test_cases = [
        ('import six', 'import six.moves as six'),
        ('import six.moves', 'import six.moves'),
        ('import six.moves.urllib', 'import six.moves.urllib as urllib'),
        ('import six.moves.urllib as urllib', 'import six.moves.urllib as urllib'),
    ]

    for test_case, expected in test_cases:
        tree = ast.parse(test_case)
        TestTransformer.transform(tree)
        assert astor.to_source(tree) == expected



# Generated at 2022-06-18 00:02:54.857796
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
try:
    import foo
except ImportError:
    import bar
''')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)



# Generated at 2022-06-18 00:03:05.456738
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar')
    expected = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')
    assert_equal_ast(expected, TestTransformer.transform(tree).tree)

    tree = ast.parse('import foo.bar as baz')

# Generated at 2022-06-18 00:03:15.994609
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    from ..utils.snippet import snippet, extend
    from ..utils.ast import get_ast

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class BaseImportRewrite(ast.NodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

# Generated at 2022-06-18 00:03:25.282884
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.test_utils import assert_equal_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
from foo import a, b
from foo import *
from foo.bar import c
from foo.bar import *
from foo.bar.baz import d
from foo.bar.baz import *
from foo.bar.baz.qux import e
from foo.bar.baz.qux import *
''')


# Generated at 2022-06-18 00:03:34.960879
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .test_utils import BaseImportRewrite_visit_ImportFrom as test_module

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('test_utils', 'test_utils_rewrite')
        ]

    tree = ast.parse(test_module.__doc__)
    TestTransformer.transform(tree)
    result = astor.to_source(tree).rstrip()

    assert result == test_module.__doc__.rstrip()

# Generated at 2022-06-18 00:03:41.542283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = parse_ast('''
    import six
    ''')
    TestTransformer.transform(tree)

    assert tree == parse_ast('''
    try:
        import six
    except ImportError:
        import six.moves as six
    ''')



# Generated at 2022-06-18 00:03:48.026749
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = get_ast('import foo')
    expected = get_ast('try:\n    import foo\nexcept ImportError:\n    import bar')

    transformer = TestTransformer(tree)
    transformer.visit(tree)

    assert compare_ast(tree, expected)



# Generated at 2022-06-18 00:03:55.536513
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import snippet_to_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = snippet_to_ast('import foo')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:04:55.724594
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_helpers import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = get_ast("import six")
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves as six'



# Generated at 2022-06-18 00:05:04.960481
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from ..utils.snippet import snippet
    from ..utils.snippet import extend
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

# Generated at 2022-06-18 00:05:16.693787
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helpers import ast_from_str
    from ..utils.ast_helpers import ast_to_str
    from ..utils.ast_helpers import ast_to_source
    from ..utils.ast_helpers import ast_to_source_code
    from ..utils.ast_helpers import ast_to_source_code_with_comments
    from ..utils.ast_helpers import ast_to_source_code_with_comments_and_newlines
    from ..utils.ast_helpers import ast_to_source_code_with_newlines
    from ..utils.ast_helpers import ast_to_source_with_comments
    from ..utils.ast_helpers import ast_to_source_with_comments_and_newlines
    from ..utils.ast_helpers import ast_to_source_

# Generated at 2022-06-18 00:05:27.901484
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.qux
    ''')
    TestTransformer.transform(tree)

# Generated at 2022-06-18 00:05:35.981844
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse_ast
    from ..utils.ast import dump_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('six.moves.urllib', 'urllib.request'),
            ('six.moves.urllib.parse', 'urllib.parse'),
        ]

    tree = parse_ast("""
    from six.moves import urllib
    from six.moves.urllib import parse
    from six.moves.urllib.parse import urlparse
    """)

    result = TestImportRewrite.transform(tree)
    assert result.changed
    assert result.dependencies == ['six']


# Generated at 2022-06-18 00:05:42.345342
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = [('foo', 'bar')]
    import_rewrite.visit(ast.parse('import foo'))
    assert astunparse.unparse(import_rewrite._tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-18 00:05:48.246247
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    ''')
    expected = ast.parse('''
    try:
        import foo
    except ImportError:
        import bar
    ''')

    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected)



# Generated at 2022-06-18 00:05:55.409628
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import assert_ast_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    result = TestTransformer.transform(tree)
    assert_ast_equal(result.tree, expected)



# Generated at 2022-06-18 00:06:01.547487
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append('../')
    from ..utils.snippet import snippet, extend
    from ..transformers.base import BaseImportRewrite
    from ..types import CompilationTarget

    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON_27
        rewrites = [('six', 'six.moves')]

    test_code = '''
    from six import iteritems
    from six import iteritems as items
    from six import iteritems, iterkeys
    from six import *
    from six.moves import range
    from six.moves import range as xrange
    from six.moves import range, map
    from six.moves import *
    '''


# Generated at 2022-06-18 00:06:09.302985
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.ast_helpers import compare_asts

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = 'import foo'
    expected = 'try:\n    import foo\nexcept ImportError:\n    import bar'

    tree = get_ast_from_source(source)
    result = TestImportRewrite.transform(tree)
    assert compare_asts(result.tree, expected)
