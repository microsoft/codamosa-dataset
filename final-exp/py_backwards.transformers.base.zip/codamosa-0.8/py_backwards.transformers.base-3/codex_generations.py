

# Generated at 2022-06-12 03:29:04.325478
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..py2to3 import import_rewrite as refact
    tree = ast.parse('''
import foo
from foo import bar
import baz
from baz import zap
''')
    refact(tree, {('foo', 'foo2')})

# Generated at 2022-06-12 03:29:08.037942
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ReplaceSomething(BaseImportRewrite):
        rewrites = [('something', 'something.else')]

    tree = ast.parse('''import something  # replaced''')
    result = ReplaceSomething.transform(tree)
    assert str(result.tree.body[0]) == '''try:  # import_rewrite
    import something
except ImportError:
    import something.else as something  # replaced
'''
    assert result.tree_changed
    assert not result.dependencies



# Generated at 2022-06-12 03:29:12.862094
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import os.path
    import sys
    import unittest
    import unittest.mock
    from ..types import CompilationTarget

    rewrites = {'trytond': 'trytond.modules'}
    test_cases = [
        [
            'import trytond',
            'try: import trytond\nexcept ImportError: import trytond.modules' +
            ' as trytond'
        ],
        [
            'import trytond.res',
            'try: import trytond.res\nexcept ImportError: import trytond.modules.res' +
            ' as trytond.res'
        ],
    ]


# Generated at 2022-06-12 03:29:19.215064
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import ast_equal
    from . import assert_equal_source

    source = "import six\n"
    rewrites = [('six', 'six.moves')]
    expected = "import six.moves as six\n"

    tree = ast.parse(source)
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = rewrites
    tree = transformer.visit(tree)

    assert ast_equal(tree, expected)



# Generated at 2022-06-12 03:29:26.459986
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    source = 'from unittest import TestCase'
    tree = ast.parse(source)
    inst = BaseImportRewrite(tree)
    node = tree.body[0]

    import_from = inst.visit_ImportFrom(node)  # type: ignore
    assert (isinstance(import_from, ast.Try) and
            len(import_from.handlers) == 1 and
            import_from.handlers[0].type.id == 'ImportError' and
            len(import_from.handlers[0].body) == 1)

# Generated at 2022-06-12 03:29:32.695416
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock

    from typed_ast import ast3 as ast

    from .transformer import BaseImportRewrite

    import_node = ast.parse('import foo').body[0]
    import_node_as = ast.parse('import foo as bar').body[0]

    rewrites = [('foo', 'bar')]
    class TestImportRewriter(BaseImportRewrite):
        rewrites = rewrites

    with unittest.mock.patch('typed_ast.transformer.import_rewrite') as mock_import_rewrite:
        transformed = TestImportRewriter.transform(import_node)

    assert transformed.changed
    assert isinstance(transformed.new_tree, ast.Try)
    # _get_matched_rewrite
    assert TestImportRewriter(import_node)._get

# Generated at 2022-06-12 03:29:42.254132
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportsTransformer(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module')
        ]

    class_def = ast.parse('''
        import old_module
    ''').body[0]
    class_def = TestImportsTransformer(class_def).visit(class_def)

    try_except_import = class_def.body[0]
    try_stmt = try_except_import.body[0]

    assert isinstance(try_except_import, ast.Try)
    assert isinstance(try_stmt, ast.Try)

    try_stmt = try_stmt.body
    assert isinstance(try_stmt[0], ast.Import)

# Generated at 2022-06-12 03:29:45.643303
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Arrange
    tree = ast.parse('''
import argparse
''')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [
        ('argparse', 'argparse2')
    ]

    # Act
    transformer.visit(tree)

    # Assert
    assert ast.dump(tree) == textwrap.dedent('''\
        try:
            import argparse
        except ImportError:
            import argparse2
        ''')


# Generated at 2022-06-12 03:29:53.589795
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore
    import_ = ast.Import(names=[
        ast.alias(name='six',
                  asname='six')])

    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = [('six', 'six.moves')]
    import_rewrite.visit(import_)

    assert astor.to_source(import_rewrite._tree) == 'try:\n\textend(six)\nexcept ImportError:\n\textend(six.moves)'  # noqa
    assert import_rewrite._tree_changed is True



# Generated at 2022-06-12 03:30:03.025988
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    n = ast.parse("""
import unittest
from unittest import mock
import unittest.mock as um
from unittest.mock import MagicMock
""")

    class MockTransformer(BaseImportRewrite):
        rewrites = [('unittest', 'unittest2')]

    result = MockTransformer.transform(n)
    assert result.changed


# Generated at 2022-06-12 03:30:19.640036
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('''
    import test
    import os
    import test.os
    import test.os as os_
    ''')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('test', 'tests')]

    result = TestImportRewrite.transform(tree)

    assert ast.dump(result.tree) == ast.dump(ast.parse('''
    try:
        import tests
    except ImportError:
        import test
    import os
    try:
        import tests.os
    except ImportError:
        import test.os
    import test.os as os_
    '''))



# Generated at 2022-06-12 03:30:27.195797
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    code = ['from test.mod1 import mod1_func1 as m1f1']
    target = CompilationTarget.PYTHON
    expected = 'from test.mod1 import mod1_func1 as m1f1'

    class TestModuleImport(BaseImportRewrite):
        pass

    TestModuleImport.rewrites = [('test.mod1', 'test.mod2')]
    actual = TestModuleImport.transform(ast.parse(code[0], target.value))[0]
    assert ast.dump(actual, target.value) == expected



# Generated at 2022-06-12 03:30:37.297654
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..transforms.types.python2 import Python2ImportRewrite
    from ..utils.snippet import snippet, extend

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('StringIO', 'io')]

    @snippet
    def test_source(s):
        import StringIO
        from StringIO import StringIO

    src = test_source.get_source()
    parsed = ast.parse(src)
    ImportRewrite.transform(parsed)
    assert astor.to_source(parsed).strip() == extend(
        """
        import io
        try:
            import StringIO
        except ImportError:
            import io
        try:
            from StringIO import StringIO
        except ImportError:
            from io import StringIO
        """).strip()

# Generated at 2022-06-12 03:30:45.108813
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old', 'new')]

    # import from old module
    node_module = ast.ImportFrom(module='old.module',
                                 names=[ast.alias(name='test', asname='Test')],
                                 level=0)
    # import from old module, *
    node_module_star = ast.ImportFrom(module='old.module',
                                      names=[ast.alias(name='*')],
                                      level=0)
    # import from old.module, test alias
    node_name = ast.ImportFrom(module='module',
                               names=[ast.alias(name='old.test', asname='Test')],
                               level=0)
    # import from old

# Generated at 2022-06-12 03:30:51.654422
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import compile_and_load

    rewrites = [('unittest', 'unittest.mock')]
    node = ast.parse('import unittest')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    TestImportRewrite.transform(node)

    module, _ = compile_and_load(node)

    assert hasattr(module, 'unittest')

# Generated at 2022-06-12 03:31:00.897619
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils import test_utils
    import_a = ast.Import(names=[
        ast.alias(name='a', asname=None)])

    import_b = ast.Import(names=[
        ast.alias(name='b', asname=None)])

    import_c = ast.Import(names=[
        ast.alias(name='c.d', asname=None)])

    expected_rewrite = ast.parse(
        astor.to_source(
            ast.Try(
                body=[import_a],
                handlers=[ast.ExceptHandler(type=None, name=None, body=[import_b])])),
        'my_file').body[0]


# Generated at 2022-06-12 03:31:06.716217
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    class AST(ast.AST):
        _fields = ('module',)

    node = AST(module='old_module')
    transformed = TestTransformer.transform(node)
    expected = AST(module='try:\n    import new_module as old_module\nexcept ImportError:\n    import old_module')
    assert transformed.tree == expected



# Generated at 2022-06-12 03:31:16.884329
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_stmt = ast.Import(names=[
        ast.alias(name="time",
                  asname=None),
        ast.alias(name="collections",
                  asname=None)])

    target = CompilationTarget(
        'python',
        'python35'
    )

    class TestTransformer(BaseImportRewrite):
        target = target
        rewrites = [
            ('time', 'time')
        ]

    transformer = TestTransformer(import_stmt)
    import_stmt = transformer.visit(import_stmt)
    assert isinstance(import_stmt, ast.Try)
    assert import_stmt.handlers[0].name is None
    assert isinstance(import_stmt.handlers[0].type, ast.Name)

# Generated at 2022-06-12 03:31:23.404933
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import dump
    code = 'from unittest.mock.call import _Call'
    node = ast.parse(code)  # type: ast.Module
    visitor = BaseImportRewrite(node)
    visitor.visit_ImportFrom(node.body[0])
    assert dump(node.body[0]) == \
        "import extend\n" \
        "try:\n" \
        "    from unittest.mock.call import _Call\n" \
        "except ImportError:\n" \
        "    from unittest_mock_call import _Call"

# Generated at 2022-06-12 03:31:33.906233
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Create a test AST node
    node = ast.Import(names=[
        ast.alias(name='six',
                  asname=None),
        ast.alias(name='os',
                  asname='_os'),
        ast.alias(name='six.moves.urllib.parse',
                  asname='_urllib_parse'),
        ast.alias(name='abc',
                  asname='abc')])

    # Run the test
    inst = BaseImportRewrite(None)
    res = inst.visit_Import(node)

    # Check the result
    assert isinstance(res, ast.Try)
    assert len(res.body) == 1
    assert isinstance(res.body[0], ast.Import)
    assert len(res.body[0].names) == 4

# Generated at 2022-06-12 03:31:45.991231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class RewriteTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_2
        rewrites = [
            ('foo', 'bar'),
        ]

    code = '''
import foo
'''
    tree = ast.parse(code)
    res = RewriteTransformer.transform(tree)

    expected_code = """
try:
    import foo
except ImportError:
    import bar
"""
    expected_code = dedent(expected_code)

    assert res.tree_changed is True
    assert ast.dump(res.tree) == ast.dump(ast.parse(expected_code))



# Generated at 2022-06-12 03:31:54.180468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore

    class ExampleBaseImportRewrite(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib')]

    source = 'import os.path'
    tree = astor.code_to_ast.parse_string(source)
    result = ExampleBaseImportRewrite.transform(tree)
    assert len(result.new_tree.body) == 1
    assert isinstance(result.new_tree.body[0], ast.Try)
    assert isinstance(result.new_tree.body[0].body[0], ast.Import)
    assert result.new_tree.body[0].body[0].names[0].name == 'pathlib'



# Generated at 2022-06-12 03:32:03.049959
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.parse('''
import foo
import foo.bar
''').body[0]
    node_visited = TestClass.visit(TestClass(), node)
    assert node_visited.body[0] == ast.parse('''
try:
    import foo
except ImportError:
    import bar
''').body[0]
    assert node_visited.body[1] == ast.parse('''
try:
    import foo.bar
except ImportError:
    import bar.bar
''').body[0]



# Generated at 2022-06-12 03:32:09.822016
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    trans = BaseImportRewrite(None)

    # Equal import cases
    tests = {
        ast.ImportFrom(module='a',
                       names=[ast.alias(name='b',
                                        asname=None)],
                       level=0):
            ast.ImportFrom(module='a',
                           names=[ast.alias(name='b',
                                            asname=None)],
                           level=0),
    }

    for test in tests:
        assert trans.visit_ImportFrom(test) == tests[test]

    # Module rewrite

# Generated at 2022-06-12 03:32:16.312211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class RewriteTest(BaseImportRewrite):
        rewrites = [
            ('collections', 'collections2')
        ]
    module = astor.parse("import collections")
    t = RewriteTest(None)
    res = t.visit_Import(module.body[0])
    assert isinstance(res, ast.Try)
    expected = 'try: extend(import collections) except ImportError: extend(import collections2)'
    assert astor.to_source(res) == expected


# Generated at 2022-06-12 03:32:27.246592
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    from typed_ast import ast3 as ast

    class Tr(BaseImportRewrite):
        rewrites = [('a', 'b')]

    # Imports that should be ready by Tr.transform()
    imports = [
        ('from a import foo', ('from b import foo')),
        ('from a.c import b', ('from b.c import b')),
        ('from a import foo, bar as baz', ('from b import foo, bar as baz')),
        ('from a import *', ('from b import *')),
    ]

    # List of imports that should not be changed

# Generated at 2022-06-12 03:32:37.696909
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_node = ast.parse('from typing import List, Dict')
    import_from_node = import_from_node.body[0]

    import_from_node_changed = ast.parse(
        'try:\n'
        '    from typing import Dict\n'
        'except ImportError:\n'
        '    from dataclasses import Dict\n')
    import_from_node_changed = import_from_node_changed.body[0]

    name_to_replace = ('typing.Dict', ('dataclasses', 'Dict'))

    class TestTransformer(BaseImportRewrite):
        rewrites = [name_to_replace]

    import_from_node_changed, changed, dependencies = TestTransformer.transform(import_from_node)
    assert import_from_node

# Generated at 2022-06-12 03:32:46.073800
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestBaseImportRewrite(BaseImportRewrite):
        pass

    TestBaseImportRewrite.rewrites = [('six.moves', 'six'), ('six.moves.urllib', 'six.moves')]
    tree = ast.parse('import six.moves.urllib.parse')
    TestBaseImportRewrite.transform(tree)
    expected = astor.to_source(ast.parse('''
try:
    import six.moves.urllib.parse
except ImportError:
    import six.moves
'''))
    assert astor.to_source(tree) == expected



# Generated at 2022-06-12 03:32:53.862796
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test import assert_transformed_ast
    from ..utils.test import get_module_list


    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'posixpath'),
                    ('shutil', 'posixpath')]


    module_list = get_module_list('import a')
    assert_transformed_ast(
        TestBaseImportRewrite,
        module_list,
        """
        import a
        """,
        """
        import a
        """)

    module_list = get_module_list('import os')

# Generated at 2022-06-12 03:33:03.634145
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Unit test for method visit_Import of class BaseImportRewrite."""
    tree = ast.parse('import module1')
    transformer = BaseImportRewrite.__new__(BaseImportRewrite)
    transformer.rewrites = [('module1', 'module2')]
    transformer.visit(tree)
    assert isinstance(tree.body[0], ast.Try)
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Import)
    assert tree.body[0].body[0].names[0].name == 'module1'
    assert len(tree.body[0].handlers) == 1
    assert isinstance(tree.body[0].handlers[0], ast.ExceptHandler)

# Generated at 2022-06-12 03:33:20.766953
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from a.b import c')
    rewrites = [('a.b', 'x.y')]
    transformer = BaseImportRewrite(tree=tree)
    transformer.rewrites = rewrites
    node = list(ast.walk(tree))[-1]

# Generated at 2022-06-12 03:33:29.327049
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [('a.b', 'x.y')]

    import_from = ast.parse("from a.b import c").body[0]
    result = DummyImportRewrite.transform(import_from)
    assert_code_equal(result.tree, "try:\n    from a.b import c\nexcept ImportError:\n    from x.y import c")

    import_from = ast.parse("from a import c").body[0]
    result = DummyImportRewrite.transform(import_from)
    assert_code_equal(result.tree, import_from)

    import_from = ast.parse("from a.b import c as d").body[0]
    result = DummyImportRewrite.transform(import_from)

# Generated at 2022-06-12 03:33:39.258266
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class SampleRewrite(BaseImportRewrite):
        rewrites = [
            ('overrides', 'trains.backend.common.overrides'),
            ('mock', 'unittest.mock'),
            ('six.moves', 'six_moves'),
            ('numpy.random', 'numpy_random'),
            ('numpy.testing', 'numpy.testing as testing'),
            ('unittest.mock', 'mock'),
        ]

    def test(import_from: ast.AST) -> ast.AST:
        return SampleRewrite.transform(import_from).tree


# Generated at 2022-06-12 03:33:47.396980
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import six
    import pytest
    import typed_ast.ast3

    code = """from six.moves import map"""
    tree = typed_ast.ast3.parse(code)

    class Test(BaseImportRewrite):
        target = CompilationTarget.PY_30
        rewrites = [('six.moves', 'six')]

    result = Test.transform(tree)

    assert result.new is True
    assert result.dependencies == ['six']
    assert typed_ast.ast3.dump(result.tree) == """try:
    from six.moves import map
except ImportError:
    from six import map"""

# Generated at 2022-06-12 03:33:57.677882
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_rewrite.clear()

    class TestTransformer(BaseImportRewrite):
        rewrites = [('x', 'y')]

    @snippet
    def test():
        """
        from a import x
        from a.x import y
        from a.x.y import z
        from a.x.y.z import q
        from a.x.y import q as w
        from a import x as y
        from a.x import y as z
        from a.x.y import z as q
        from a.x.y.z import q as w
        """

    result = TestTransformer.transform(ast.parse(test.code))
    assert result.tree != test.tree
    assert ast.dump(result.tree) == ast.dump(test.tree)



# Generated at 2022-06-12 03:34:03.235966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse('import a.b')
    import_rewrite = BaseImportRewrite(node)
    rewrite_node = import_rewrite._replace_import(node, 'a', 'c')
    assert ast.dump(rewrite_node) == """\
try:
    import a.b as b
except ImportError:
    import c.b as b
"""


# Generated at 2022-06-12 03:34:12.928863
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'django.contrib.gis.geoip2'
    to = 'django_geoip2'
    rewrites = [(from_, to)]

    class ImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse("""
from django.contrib.gis.geoip2 import GeoIP2
from django.contrib.gis.geoip2 import GeoIP2Exception
from django.contrib.gis.geoip2 import GeoIP2ConnectionError
from django.contrib.gis import geos

geo_ip = GeoIP2(path='/data')
    """)

    tree, changed, deps = ImportRewrite.transform(tree)


# Generated at 2022-06-12 03:34:23.146612
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from typed_ast.ast3 import Name, ImportFrom, alias, If, NameConstant, Test, Attribute
    from typed_ast.ast3 import FunctionDef, Pass, Compare, Eq
    import astunparse
    import re
    from plshandle import conditions
    from plshandle.plugins import import_rewrite
    import_rewrite.rewrites = [('a.b', 'x.y'), ('a.b.c', 'x.y.z')]

# Generated at 2022-06-12 03:34:33.225537
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_Import = 'import sys'
    expected_Import = 'import sys'
    result_Import = BaseImportRewrite.visit(ast.parse(test_Import).body[0])
    assert ast.dump(result_Import) == ast.dump(ast.parse(expected_Import).body[0])

    test_Import = 'import sys as s'
    expected_Import = 'import sys as s'
    result_Import = BaseImportRewrite.visit(ast.parse(test_Import).body[0])
    assert ast.dump(result_Import) == ast.dump(ast.parse(expected_Import).body[0])

    test_Import = 'import sys.path'
    expected_Import = 'import sys.path'

# Generated at 2022-06-12 03:34:36.816737
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node = astor.parse('import sys')[0]
    s = BaseImportRewrite()
    print(s.visit_Import(node))
    node = astor.parse('import sys.path')[0]
    print(s.visit_Import(node))
    node = astor.parse('from sys import path')[0]
    print(s.visit_ImportFrom(node))



# Generated at 2022-06-12 03:35:06.969144
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert BaseImportRewrite.visit_Import(ast.parse("import foo").body[0]) == ast.parse("import foo").body[0]
    assert BaseImportRewrite.visit_Import(ast.parse("import foo.bar").body[0]) == \
           ast.parse("try:\n    import foo.bar\nexcept ImportError:\n    import foo").body[0]
    assert BaseImportRewrite.visit_Import(ast.parse("import foo.bar.baz").body[0]) == \
           ast.parse("try:\n    import foo.bar.baz\nexcept ImportError:\n    import foo.bar").body[0]

# Generated at 2022-06-12 03:35:15.938966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('urllib', 'urllib.request')]

    class ImportRewriteMultiple(BaseImportRewrite):
        rewrites = [('urllib', 'urllib.request'), ('six', 'six')]

    tree = ast.parse('''import urllib''')
    ImportRewrite.transform(tree)

    tree = ast.parse('''import urllib.request''')
    ImportRewrite.transform(tree)

    tree = ast.parse('''import urllib.parse''')
    ImportRewrite.transform(tree)

    tree = ast.parse('''import urllib.request''')
    ImportRewriteMultiple.transform(tree)

    tree = ast.parse('''import six''')
    ImportRew

# Generated at 2022-06-12 03:35:24.224191
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON2
        rewrites = [('six', 'six2')]


# Generated at 2022-06-12 03:35:33.991895
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    global T, t

    T1 = type("NodeTransformer", (BaseImportRewrite,), {
        'rewrites': [
            ('_abc', 'abc'),
            ('_def', 'def'),
        ]
    })

    class Test:

        class tree1:
            """Original AST"""

            @staticmethod
            def _import_aaa():
                import _abc  # noqa: F401
                import _def  # noqa: F401

        class tree2:
            """Transformed AST"""

            @staticmethod
            def _import_aaa():
                try:
                    import _abc
                except ImportError:
                    import abc


# Generated at 2022-06-12 03:35:42.982804
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTransformer(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six'),
        ]

    tree = ast.parse('import six.moves.http_cookiejar')
    assert ImportTransformer.transform(tree) == \
        TransformationResult(ast.parse('try:\n    import six.moves.http_cookiejar\nexcept ImportError:\n    import six.http_cookiejar'),
                             True,
                             [])

    tree = ast.parse('import six')
    assert ImportTransformer.transform(tree) == \
        TransformationResult(tree, False, [])


# Generated at 2022-06-12 03:35:52.364076
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from datetime import date
    from ..ast_rewrite_tests import BaseImportRewriteTestCase
    import sys
    import unittest

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('datetime', 'dateutil.parser')]
        target = None

        def _replace_import(self, node, from_, to):
            return self.generic_visit(node)

    class TestBaseImportRewrite_visit_Import(
            BaseImportRewriteTestCase, unittest.TestCase):
        transformer = TestBaseImportRewrite
        target = None
        module = 'a.b'

# Generated at 2022-06-12 03:36:02.369863
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import unparse
    from ..types import CompilationTarget, TransformationResult

    test_cases = [
        ('''
import text_to_html
from x import a, b''',
         '''
try:
    import text_to_html
except ImportError:
    import text_to_markdown as text_to_html
try:
    from x.a import *
    from x.b import *
except ImportError:
    from a import *
    from b import *'''),
        ('''
from x import *''',
         '''
try:
    from x.a import *
    from x.b import *
except ImportError:
    from a import *
    from b import *''')
    ]


# Generated at 2022-06-12 03:36:13.359336
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import sys
    from ..utils.snippet import snippet

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'pos')]

    # Before: from os import path
    # After: try: from pos import path except ImportError: from os import path
    string_import = astunparse.unparse(ast.parse('from os import path').body[0])
    transformer = TestTransformer(ast.parse(string_import))
    result = transformer.visit_ImportFrom(ast.parse(string_import).body[0],)

# Generated at 2022-06-12 03:36:18.389890
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_transformer import test_transform
    from ..transform import ImportsRewriter


# Generated at 2022-06-12 03:36:25.660670
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Unit test for method visit_ImportFrom of class BaseImportRewrite."""
    import astor
    import_from = ast.ImportFrom(module='foo',
                                 names=[ast.alias(name='foo',
                                                  asname='bar')],
                                 level=1)

    visitor = BaseImportRewrite(None)
    visitor.rewrites = [('foo', 'bar')]

    visited = visitor.visit(import_from)
    print(astor.to_source(visited)) # TODO: test with assertion

    visited = visitor.visit(import_from)
    print(astor.to_source(visited)) # TODO: test with assertion

    visitor.rewrites = [('foo', 'foo')]
    visited = visitor.visit(import_from)

# Generated at 2022-06-12 03:36:54.351337
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transformer.import_rewrite import _BaseImportRewrite
    import ast

    class Visitor(_BaseImportRewrite):
        rewrites = [('a.b', 'x.y')]

    node = ast.parse('''
from a.b import f
from a.b.c import g
from a.b.c import h as H
from a import b
from a import b as B
from a.b.c import *
''')

    v = Visitor(node)
    new_tree = v.visit(node)

    assert isinstance(new_tree, ast.Module)
    assert isinstance(new_tree.body[0], ast.Try)
    assert isinstance(new_tree.body[0].body[0].body[0], ast.Import)

# Generated at 2022-06-12 03:37:03.776853
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..transformer import BaseImportRewrite
    from ..context import Context

# Generated at 2022-06-12 03:37:09.711853
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..tests import test_utils
    from typed_ast import ast3 as ast
    node = ast.parse("from django.db.models import Model")
    node2 = ast.parse("from django.db.models import Model")
    BaseImportRewrite.rewrites = [("django.db.models", "django.db.models.sql_server")]
    assert test_utils.compare_src(node, BaseImportRewrite(node2).visit_ImportFrom(node)) == True



# Generated at 2022-06-12 03:37:18.594155
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest, ast_factory

    class TestCase(unittest.TestCase):
        def test_get_matched_rewrite(self):
            self.assertEqual(
                BaseImportRewrite._get_matched_rewrite(None, 'argparse'),
                None)
            self.assertEqual(
                BaseImportRewrite._get_matched_rewrite(None, 'argparse.abc'),
                None)
            self.assertEqual(
                BaseImportRewrite._get_matched_rewrite(None, 'argparse.ArgumentParser'),
                None)
            self.assertEqual(
                BaseImportRewrite._get_matched_rewrite(None, 'argparse.Foo.ArgumentParser'),
                None)

# Generated at 2022-06-12 03:37:25.449354
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('socket', 'socket2'),
        ]

    import socket
    from socket import socket as socket_function

    tree = ast.parse("""
import socket
from socket import socket
    """)

    tr = ImportRewrite.transform(tree)
    assert tr.changed

    exec(compile(tr.tree, '<tree>', 'exec'), globals())

    assert socket is socket2
    assert socket_function is socket2.socket

# Generated at 2022-06-12 03:37:31.751739
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from enum import Enum
    from typing import Any
    from typed_ast import ast3 as ast

    class EnumStub(Enum):
        SUB_CONST = 'Substitution'

    class UnitTestImportRewrite(BaseImportRewrite):

        rewrites = [
            ('some.library', 'another.library'),
            ('some.library.submodule.subsubmodule', 'another.library.submodule.subsubmodule'),
            ('some.library.submodule', 'another.library.submodule')
        ]

    class Case(EnumStub):
        IMPORT_FROM_MODULE = 'from {from_} import {name}',
        IMPORT_FROM_NAMES = 'from {from_} import {name}, {from_}.{name}',
        IMPORT_FROM_NAMES_AND

# Generated at 2022-06-12 03:37:41.402497
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from typed_ast.ast3 import Import, alias

    tree_original = Import(names=[
        alias(name='foo', asname='bar'),
        alias(name='baz', asname=None),
    ])

    tree_expected = Import(names=[
        alias(name='foo_bar', asname='bar'),
        alias(name='baz', asname=None),
    ])

    import_rewrites = [('foo', 'foo_bar')]

    class TestClass(BaseImportRewrite):
        rewrites = import_rewrites

    test_class = TestClass(ast3.parse('pass'))
    result = test_class.visit_Import(tree_original)
    assert isinstance(result, Import)
    assert result == tree_expected


# Generated at 2022-06-12 03:37:48.823987
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class TestCase:
        tree: ast.AST
        expected: ast.AST


# Generated at 2022-06-12 03:37:50.876979
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import generate_code
    from .utils import run_transform


# Generated at 2022-06-12 03:38:00.479259
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import AST, parse
    import typed_astunparse
    from .utils import compare_ast

    from .test_BaseNodeTransformer import test_BaseNodeTransformer_visit_ImportFrom

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')]

    # test with no rewrites
    tree = parse(test_BaseNodeTransformer_visit_ImportFrom)
    assert isinstance(tree, AST)

    result = TestTransformer.transform(tree)
    assert isinstance(result.tree, AST)
    assert result.tree_changed is False
    assert typed_astunparse.unparse(result.tree) == test_BaseNodeTransformer_visit_ImportFrom

    # test with rewrites