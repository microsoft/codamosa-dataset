

# Generated at 2022-06-12 03:29:05.780746
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    from_ = 'six'
    to = 'more_itertools'
    imp = ast.Import(names=[
        ast.alias(name=from_,
                  asname=None)])

    # When we replace import of module
    class ReplaceImport(BaseImportRewrite):
        rewrites = [(from_, to)]

    tree = ReplaceImport.transform(imp).tree
    assert astor.to_source(tree) == "import more_itertools"

    # When we replace import of submodule
    class ReplaceImport2(BaseImportRewrite):
        rewrites = [(from_ + '.six', to + '.more')]

    imp.names[0].name = from_ + '.six'
    imp.names[0].asname = None
    tree = ReplaceImport2.transform(imp).tree

# Generated at 2022-06-12 03:29:15.536715
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from1 = ast.ImportFrom(module='a.b',
                                  names=[ast.alias(name='c',
                                                   asname='d'),
                                         ast.alias(name='e',
                                                   asname='f')],
                                  level=0)
    import_from2 = ast.ImportFrom(module='a',
                                  names=[ast.alias(name='c.g',
                                                   asname='h'),
                                         ast.alias(name='i.j.k',
                                                   asname='l')],
                                  level=0)
    import_from3 = ast.ImportFrom(module='m',
                                  names=[ast.alias(name='n.o',
                                                   asname='o')],
                                  level=0)

# Generated at 2022-06-12 03:29:23.284030
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    def assert_import(node: ast.Import, from_: str, to: str):
        rewriter = BaseImportRewrite([(from_, to)])
        result = rewriter.visit_Import(node)
        assert isinstance(result, ast.Try)
        assert len(result.handlers) == 1
        assert len(result.handlers[0].type.names) == 1
        assert result.handlers[0].type.names[0].name == 'ImportError'
        assert len(result.handlers[0].body) == 1
        assert len(result.body) == 1
        assert result.body[0].names[0].name == node.names[0].name.replace(from_, to, 1)

# Generated at 2022-06-12 03:29:32.797192
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [('email.encoders', 'email3.encoders')]
    class ImportRewrite(BaseImportRewrite):
        rewrites = rewrites
    # Before
    import_node = ast.parse('import email.encoders as email_encoders').body[0]
    before = 'import email.encoders as email_encoders'
    # After
    body = ImportRewrite.transform(import_node).body
    after = 'try:\n    import email.encoders as email_encoders\nexcept ImportError:\n    import email3.encoders as email_encoders'
    # Comparing
    assert ast.dump(body) == after
    assert ast.dump(ast.parse(before).body[0]) == ast.dump(body)
    # Test if

# Generated at 2022-06-12 03:29:42.395536
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('asyncio', 'aio'),
            ('asyncio.coroutines', 'aio.coroutine')
        ]

    tree = ast.parse('from asyncio import *\n'
                     'from asyncio.coroutines import Task')

    TestImportRewrite().visit(tree)


# Generated at 2022-06-12 03:29:47.341874
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = """
    from django import get_user_model
    from django.db.models import Q
    import django.db.models.query
    from django.db.models import *
    from django.db.models.functions import *
    """
    tree = ast.parse(code, filename='', mode='exec')
    rewrites = [('django.db.models', 'django_mysql')]
    class ModuleRewrite(BaseImportRewrite):
        rewrites = rewrites
    result = ModuleRewrite.transform(tree)

# Generated at 2022-06-12 03:29:58.480026
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import ast_utils
    from . import base_transformer_helpers
    from ..utils import ast_to_source

    tree = ast_utils.parse_module(base_transformer_helpers.IMPORT_CODE)
    transformer = base_transformer_helpers.BaseTransformerImportRewrite([
        ('foo', 'bar')
    ])
    transformer.visit(tree)

# Generated at 2022-06-12 03:30:02.816683
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    from ..utils.compat import builtins

    class RewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('os', 'sys'),
        ]

    tree = ast.parse('import os')
    RewriteTransformer.transform(tree)
    assert ast.dump(tree) == 'import sys\ntry:\n    import os\nexcept ImportError:\n    pass\n'

    tree = ast.parse('import os.path')
    RewriteTransformer.transform(tree)
    assert ast.dump(tree) == 'import sys.path\ntry:\n    import os.path\nexcept ImportError:\n    pass\n'

    tree = ast.parse('import os.path.join')
    RewriteTransformer.transform(tree)

# Generated at 2022-06-12 03:30:13.211941
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:30:23.783790
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # arrange
    import unittest
    import copy
    import ast
    from qa import node_to_str

    class TestCase(unittest.TestCase):

        def assertEqualNode(self, left, right):
            left_str = node_to_str(left)
            right_str = node_to_str(right)
            self.assertEqual(left_str, right_str)


# Generated at 2022-06-12 03:30:38.483666
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    node = ast.Import(names=[
        ast.alias(name='os'),
        ast.alias(name='sys',
                  asname='_')])
    res = BaseImportRewrite._replace_import(None, node, 'os', 'pathlib')
    assert str(res) == (
        'try:\n'
        '    import os as pathlib\n'
        'except ImportError:\n'
        '    import pathlib as pathlib\n'
    )
    res = BaseImportRewrite._replace_import(None, node, 'os', 'pathlib.Path')

# Generated at 2022-06-12 03:30:45.605793
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .mock.vr_helpers import mock_module
    node = ast.parse('import a.b.c')
    with mock_module(node, 'foo'):
        class Foo(BaseImportRewrite):
            rewrites = [('x.y', 'a')]

        new_node = Foo.transform(node).tree


# Generated at 2022-06-12 03:30:52.573856
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('xxx', 'yyy')]

    node = ast.parse('import xxx.yyy')
    node = TestImportRewrite.transform(node).tree
    assert astor.to_source(node) == (
        """
try:
    import xxx.yyy
except ImportError:
    import yyy.yyy
        """).strip()



# Generated at 2022-06-12 03:30:58.679316
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_rewrite = BaseImportRewrite([ast.parse('import user.foo')], [('user', 'u')])
    import_rewrite.visit_Import(ast.parse('import user.foo'))
    assert astor.to_source(import_rewrite.visit_Import(ast.parse('import user.foo'))) == '''try:
    import user.foo
except ImportError:
    import u.foo
'''



# Generated at 2022-06-12 03:31:08.085377
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..test_utils import assert_equal_ast, _get_ast

    class Dummy(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = _get_ast('import foo')
    Dummy.transform(tree)
    assert_equal_ast(
        ast.parse(
            'import bar\n'
            'try:\n'
            '    import foo\n'
            'except ImportError:\n'
            '    pass'),
        tree)

    tree = _get_ast('import foo.bar')
    Dummy.transform(tree)

# Generated at 2022-06-12 03:31:18.774246
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyImportRewrite(BaseImportRewrite):
        target = '3.5'
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('''
    import six
    ''')
    trans = MyImportRewrite(tree)
    trans.visit_Import(ast.parse('''
    import six
    ''').body[0])
    assert isinstance(trans._tree.body[0], ast.Try)
    assert isinstance(trans._tree.body[0].body[0].body[0], ast.Import)
    assert trans._tree.body[0].body[0].body[0].names[0].name == 'six'

# Generated at 2022-06-12 03:31:25.531759
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class D(BaseImportRewrite):
        rewrites = [
            ('werkzeug', 'flask_werkzeug')
        ]

    def run(code: str, expected: str) -> None:
        tree = ast.parse(code)
        D().visit(tree)
        print(ast.dump(tree))
        assert ast.dump(tree) == expected


# Generated at 2022-06-12 03:31:36.463412
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    # test for import
    for node in parse('import os\n').body:
        result = BaseImportRewrite.visit_Import(BaseImportRewrite(''.encode('utf-8')),
                                               node)
        assert isinstance(result, ast.Import)
        assert result.names[0].name == 'os'

    # test for try/except
    for node in parse('import os.path\n').body:
        result = BaseImportRewrite.visit_Import(BaseImportRewrite(''.encode('utf-8')),
                                               node)
        assert isinstance(result, ast.Try)
        assert isinstance(result.body[0], ast.Import)
        assert result.body[0].names[0].name == 'os.path'

# Generated at 2022-06-12 03:31:44.918661
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..compatibility import import_from_to_import
    module = 'from foo.bar.baz import bar as bar1, baz as baz1\nfrom foo.bar.baz import baz\n'
    tree = ast.parse(module)
    import_from_to_import.BaseImportRewrite.rewrites = [('foo.bar', 'snake')]

    import_from_to_import.BaseImportRewrite.transform(tree)

    assert 'from snake.bar.baz import bar as bar1, baz as baz1\nfrom snake.bar.baz import baz\n' in tree.body[0].body[0]



# Generated at 2022-06-12 03:31:54.142492
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from .ast_unparse import unparse
    from ..typing.nodes import get_alias_name
    import textwrap

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(textwrap.dedent('''
        from foo import bar as baz, foo as boo
        from foo.bar import baz as bal
        import foo
        import foo.bar as baz
        from foo import *
    '''))

    transformer = TestImportRewrite(tree)
    transformer.visit(tree)

    aliases = get_alias_name(tree)


# Generated at 2022-06-12 03:32:09.704741
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    old = ast.parse('from old import x, y as z')
    ImportRewrite.transform(old)
    assert ast.dump(old) == "try:\n    from old import x, y as z\nexcept ImportError:\n    from new import x, y as z"

    old = ast.parse('from old import *')
    ImportRewrite.transform(old)
    assert ast.dump(old) == "try:\n    from old import *\nexcept ImportError:\n    from new import *"

    old = ast.parse('from old.old2 import x, y as z')
    ImportRewrite.transform(old)

# Generated at 2022-06-12 03:32:17.988457
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    # Simple import
    node = ast.parse('''import foo''').body[0]  # type: ast.Import
    assert 'try:' in ast.dump(Rewrite(node).visit(node))

    # Simple import as
    node = ast.parse('''import foo as bar''').body[0]  # type: ast.Import
    assert 'try:' in ast.dump(Rewrite(node).visit(node))

    # Import from
    node = ast.parse('''import foo.bar as baz''').body[0]  # type: ast.Import
    assert 'try:' in ast.dump(Rewrite(node).visit(node))

    # Import not match

# Generated at 2022-06-12 03:32:28.966362
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import _assert_node_match
    from ..utils.test_utils import _assert_NoQName_match
    from ..utils.test_utils import _assert_Identifier_match
    import untyped_ast as ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]
        dependencies = ['new_module']

    # Test import from module rewrites

# Generated at 2022-06-12 03:32:38.979033
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'typed_ast.ast3.os')]

    source = """
from os import path
from os import *
import os
from typing.io import *
from typing.io import IOBase
"""

# Generated at 2022-06-12 03:32:48.564864
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_module = ast.Import(names=[
        ast.alias(name='foo.bar',
                  asname='fbb')])

    import_package = ast.Import(names=[
        ast.alias(name='foo',
                  asname=None)])

    tr = TestImportRewrite(None)

    rewrite = tr._get_matched_rewrite('foo.bar')
    assert rewrite == ('foo', 'bar')

    rewrite = tr._get_matched_rewrite('foo')
    assert rewrite == ('foo', 'bar')

    rewrite = tr._get_matched_rewrite('baz')
    assert rewrite == None

    rewrote = tr._replace_import(import_module, 'foo', 'bar')
   

# Generated at 2022-06-12 03:32:56.506268
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    from importlib import import_module
    from .ast_transformer import ast_transform
    from .transformers import Py2Py3ImportRewrite, Py2Py3NodeTransformer

    class TestTransformer(Py2Py3NodeTransformer):
        class _TestImport:
            import_module = import_module

        def visit_Import(self, node):
            return TestTransformer._TestImport

    module = import_module('typing')
    tree = ast_transform(module, [Py2Py3ImportRewrite,
                                  TestTransformer])
    result = tree.body[0]
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[0].module == 'typing_extensions'


# Generated at 2022-06-12 03:33:06.067061
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import parse_and_unparse, transform_to_source

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('a.b', 'a.c'),
        ]

    source = """
    import a.b
    a.b.foo()
    """
    expect = """
    try:
        import a.b
    except ImportError:
        import a.c
    
    a.c.foo()
    """
    tree = parse_and_unparse(source)
    Transformer.transform(tree)
    assert transform_to_source(tree) == expect

    source = """
    from a.b import foo
    foo()
    """

# Generated at 2022-06-12 03:33:11.879741
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='a',
                          names=[
                              ast.alias(name='A',
                                        asname='A'),
                              ast.alias(name='B',
                                        asname='B'),
                              ast.alias(name='C',
                                        asname='C')
                          ],
                          level=0)



# Generated at 2022-06-12 03:33:20.258902
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Scenario: visit_ImportFrom method is defined in super class
    # Given transformation result expected to be a class
    # Then visit_ImportFrom method is defined in super class
    assert isinstance(BaseImportRewrite.visit_ImportFrom, types.FunctionType),\
        "visit_ImportFrom method is defined in super class"
    # Scenario: import statement is not changed
    # Given import statement is present
    import_statement = ast.Import(names=[ast.alias(name='os', asname=None)])
    # And there is no rewrite for an import statement
    rewrites = []
    # When visit_ImportFrom is called
    BaseImportRewrite.visit_ImportFrom(BaseImportRewrite, import_statement)
    # Then import statement is not changed

# Generated at 2022-06-12 03:33:28.959893
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """
    Test of method visit_Import of class BaseImportRewrite
    
    """
    import unittest
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('dst', 'src')]

    class BaseImportRewriteTest(unittest.TestCase):
        def test_replace_import(self):
            a = TestImportRewrite.transform(
                ast.parse("""
t = 10
import dst.module
"""
                )
            )
            self.assertEqual(
                astor.to_source(a.tree).strip(), """
t = 10
try:
    import dst.module
except ImportError:
    import src.module
"""
                .strip()
            )

        def test_not_replace_import(self):
            a = TestImport

# Generated at 2022-06-12 03:33:56.150963
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # arrange
    module = ast.Module(
        body=[ast.ImportFrom(module='sqlalchemy.sql',
                             names=[
                                 ast.alias(name='Select', asname=None),
                                 ast.alias(name='insert', asname='insert_')],
                             level=0),
              ast.ImportFrom(module='sqlalchemy.sql',
                             names=[ast.alias(name='update', asname='update_')],
                             level=0)])
    rewrites = [('sqlalchemy', 'sqla')]

    # act
    result = BaseImportRewrite(None, rewrites).visit(module)

    # assert
    assert isinstance(result, ast.Try)

    try_ = cast(ast.Try, result)
    assert len(try_.body) == 2


# Generated at 2022-06-12 03:34:06.786717
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3

    import typed_astunparse as astunparse

    from ..utils.ast_compare import ASTComparator

    from typed_astunparse import NoAliasVisitor

    # 1. module rewrite
    ast1 = ast.parse("from math import pi")
    ast2 = ast.parse("from cmath import pi")
    t = BaseImportRewrite(ast1)
    t.rewrites = [("math", "cmath")]
    t.visit(ast1)
    assert ASTComparator().compare(ast1, ast.parse(astunparse.unparse(ast2))) is True

    # 2. alias rewrite
    ast1 = ast.parse("from math import pi as x")
    ast2 = ast.parse("from cmath import pi as x")

# Generated at 2022-06-12 03:34:12.086087
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..tests.visitors.utils import get_visitor_test_cases, get_tree
    test_cases = get_visitor_test_cases(BaseImportRewrite, 'visit_Import')
    for case in test_cases:
        tree = get_tree(case['input'])
        BaseImportRewrite.transform(tree)
        actual = ast.dump(tree)
        assert actual == case['expected']


# Generated at 2022-06-12 03:34:15.755667
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import compile_source

    class TestImportRewrite(BaseImportRewrite):
        target = '3.7'
        rewrites = [('rewrite', 'rewrite_new')]

    node = compile_source('import rewrite').body[0]
    try_node = TestImportRewrite(None).visit(node)
    assert isinstance(try_node, ast.Try)



# Generated at 2022-06-12 03:34:22.175780
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import textwrap

    source = textwrap.dedent("""
    import foo
    """).lstrip()

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.parse(source)

    node = TestImportRewrite().visit(node)
    assert node.body[0].__class__ == ast.Try
    assert node.body[0].body[0].names[0].name == 'bar'



# Generated at 2022-06-12 03:34:32.356546
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tr = BaseImportRewrite

    tr.rewrites = [('foo', 'bar')]
    assert ast.dump(tr().visit(ast.parse('import foo').body[0])) == (
        'Module(body=[Try(body=[Import(names=[alias(name="bar", asname="foo")])], '
        'handlers=[ExceptHandler(type=Name(id="ImportError", ctx=Load()), name=None, '
        'body=[Import(names=[alias(name="foo", asname="foo")])])], orelse=[], finalbody=[])])'
    )

    tr.rewrites = [('foo', 'bar')]

# Generated at 2022-06-12 03:34:39.652051
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astor.astunparse as astunparse
    from ipytranspile.core.compiler import compile
    from ipytranspile.core.compiler import CompilationTarget as CT
    from ipytranspile.core.compiler import CompilationResult as CR
    from ipytranspile.core.compiler.transformers import BaseImportRewrite as BIR


    class TryCompiled(BIR):
        target = CT.COMPILED
        rewrites = [
            ('gevent', 'gevent_import_rewrite')
        ]

    class TryToPython3(BIR):
        target = CT.PYTHON_3
        rewrites = [
            ('gevent', 'gevent_importer')
        ]


# Generated at 2022-06-12 03:34:48.246447
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewriteMock(BaseImportRewrite):
        rewrites = [
            ('urllib.parse', 'urllib.parse'),
        ]

    class BaseNodeTransformerMock(BaseNodeTransformer):
        rewrites = [
            ('abc.abc', 'abc.abc'),
        ]

    import_ = ast.Import(names=[
        ast.alias(name='abc.abc'),
        ast.alias(name='abc.cba'),
        ast.alias(name='urllib.parse'),
        ast.alias(name='urllib.parse.test'),
        ast.alias(name='urllib.test.test'),
        ast.alias(name='urllib.test'),
    ])

    assert BaseImportRewriteMock(import_).visit_Import(import_) == ast

# Generated at 2022-06-12 03:34:54.590136
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [('setuptools', 'distribute')]

    tree = ast.parse('''
    import setuptools
    import setuptools.command
    ''')

    result = DummyTransformer.transform(tree)
    assert result.changed is True

    assert_ast(result.tree[0], '''
    try:
        import setuptools
    except ImportError:
        import distribute
    ''')

    assert_ast(result.tree[1], '''
    try:
        import setuptools.command
    except ImportError:
        import distribute.command
    ''')



# Generated at 2022-06-12 03:35:03.944620
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_, to = 'django.core.urlresolvers', 'django.urls'

# Generated at 2022-06-12 03:35:39.227279
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import test_targets.targets7.test_module1.a as a

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('test_targets.targets7.test_module1.a', 'test_targets.targets7.test_module2.a')]

    tree = ast.parse('''import test_targets.targets7.test_module1.a as a''')
    result = TestTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.dependencies == ['test_targets.targets7.test_module1.a',
                                   'test_targets.targets7.test_module2.a']


# Generated at 2022-06-12 03:35:46.127938
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [('requests', 'aiohttp')]

    class Rewrite(BaseImportRewrite):
        dependencies = []
        rewrites = rewrites

    tree = ast.parse('import requests')
    result = Rewrite.transform(tree)

    new_tree = ast.parse('''try:
    import requests
except ImportError:
    import aiohttp as requests''')

    assert ast.dump(result.tree) == ast.dump(new_tree)


# Generated at 2022-06-12 03:35:51.457450
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportNode(BaseImportRewrite):
        target = CompilationTarget.PY2
        rewrites = [('six', 'past.six')]

    tree = ast.parse('import six')
    expected = ast.parse(
        """
        try:
            import six
        except ImportError:
            import past.six as six
        """
    )
    expected_changed = True

    actual_changed, actual = ImportNode.transform(tree)

    assert actual_changed == expected_changed
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-12 03:36:01.483893
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..testing import assert_equal

    import types
    import ast as standard_ast

    def check(self, code: str, expected: Optional[str], rewrites: List[Tuple[str, str]] = []) -> None:
        class TestRewrite(BaseImportRewrite):
            rewrites = [] + rewrites

        tree = standard_ast.parse(code)
        assert_equal(TestRewrite(tree).visit(tree), expected)

    # rename module
    check(None,
          expected='import a',
          code='import b',
          rewrites=[('b', 'a')])

    # rename module in from import statement
    check(None,
          expected='from a import b',
          code='from b import c',
          rewrites=[('b', 'a')])

    # rename sub

# Generated at 2022-06-12 03:36:09.707977
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from tst.test_compat.nodes import test_literal
    from tst.test_compat.transformers import rewrite_test
    # Tested method

    # Variables
    transformer = rewrite_test.RewriteTestImport()
    source = 'import math'

    # Tested method
    source_ast = ast.parse(source)
    transformer.visit(source_ast)
    source_generated = astor.to_source(source_ast).strip()

    # Tested method
    assert source_generated == "try:\n    import math\nexcept ImportError:\n    import builtins.math"



# Generated at 2022-06-12 03:36:18.177165
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    from ..target.python import PYTHON_VERSION

    tree = parse_ast('from example.other import *')
    assert isinstance(tree, ast.ImportFrom)

    class ImportTransformer(BaseImportRewrite):
        rewrites = [('example.other', 'example.new')]

    changed, tree = ImportTransformer.transform(tree)
    assert changed

    if PYTHON_VERSION >= (3, 6):
        assert isinstance(tree, ast.Try)
    else:
        assert isinstance(tree, ast.Import)



# Generated at 2022-06-12 03:36:25.545422
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('some_module', 'some_other_module')]

    import_stmt = ast.parse('import some_module').body[0]
    result = ImportRewrite.visit_Import(import_stmt)
    assert isinstance(result, ast.Try)
    assert result.finalbody[0].body[0].names[0].name == 'some_module'
    assert result.finalbody[0].body[0].names[0].asname == 'some_module'
    assert result.handlers[0].type.id == 'ImportError'
    assert result.handlers[0].body[0].names[0].name == 'some_other_module'

# Generated at 2022-06-12 03:36:35.682272
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..user_code import BaseImportRewrite as TypeImportRewrite
    from inspect import getsource
    from textwrap import dedent

    class ImportRewrite(TypeImportRewrite):
        target = ''
        rewrites = [('foo', 'bar')]

    old_code = '''
    import foo
    import bar
    import baz
    '''
    new_code = '''
    try:
        import foo as foo
    except ImportError:
        import bar as foo
    import bar
    import baz
    '''

    assert str(ImportRewrite.transform(ast.parse(dedent(old_code)))) == dedent(new_code)

    assert ImportRewrite.translate(old_code) == dedent(new_code)



# Generated at 2022-06-12 03:36:45.352514
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node1 = ast.parse('''from a import b''').body[0]
    node2 = ast.parse('''from a import *''').body[0]
    node3 = ast.parse('''from . import b''').body[0]
    node4 = ast.parse('''from . import *''').body[0]
    node5 = ast.parse('''from .a import b''').body[0]
    node6 = ast.parse('''from .a import *''').body[0]
    node7 = ast.parse('''from .. import b''').body[0]
    node8 = ast.parse('''from .. import *''').body[0]
    node9 = ast.parse('''from ..a import b''').body[0]
    node

# Generated at 2022-06-12 03:36:54.781011
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    source = """
import os
import os.path as path
from numpy import *
from numpy import array, zeros
from numpy import array as a, zeros as z
import numpy as np
from numpy import array as a
from numpy import array as a, zeros as z
"""

    rewrites = [
        ('numpy', 'pyramid')
    ]

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse(source)
    tree = TestTransformer.transform(tree).tree
    source_rewritten = compile(tree, '<ast>', 'exec').co_consts[0]

# Generated at 2022-06-12 03:37:54.438714
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import sys
    import _ast as ast
    from ..utils.snippet import snippet
    from ..testutils import SimpleTransformerTestCase, CodeTransformerTestCase
    from ..testutils import run_transformer_test_cases

    class M1(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    class M2(BaseImportRewrite):
        rewrites = [
            ('foo.a1', 'bar.a1'),
            ('foo.a2', 'bar.a2'),
        ]

    class M3(BaseImportRewrite):
        rewrites = [
            ('baz', 'baz1'),
            ('baz.a1', 'baz.a3'),
        ]


# Generated at 2022-06-12 03:38:01.355951
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('oldmodule', 'newmodule')]

    tree = ast.parse('import oldmodule')
    assert Test.transform(tree).changed
    assert ast.dump(tree) == (
        'Module(body=[Try(body=[Pass()], '
        'handlers=[ExceptHandler(body=[Import(names=[alias(name="newmodule", asname=None)])], '
        'name=None)], finalbody=[Import(names=[alias(name="oldmodule", asname=None)])], '
        'orelse=[])])')



# Generated at 2022-06-12 03:38:08.648928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from . import get_targets, get_cursor_position, get_target_type

    class Mock(BaseImportRewrite):
        target = get_targets(0)
        rewrites = [('.custom_module', '.custom_module_rewrite')]

    test_ast = ast3.parse('import custom_module')
    Mock.transform(test_ast)

    assert get_cursor_position(test_ast) == (1, 1)
    assert get_target_type(test_ast) == 'Try'


# Generated at 2022-06-12 03:38:13.388757
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    importBase_obj = BaseImportRewrite()
    new_node = ast.ImportFrom(level=0, names=[ast.alias(asname='some_asname', name='some_name')], module='math')
    importBase_obj.visit_ImportFrom(node=new_node)

# Generated at 2022-06-12 03:38:16.337848
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_ = 'some'
    to = 'other'

    # Imports
    to_import = ast.Import(names=[
        ast.alias(name=to,
                  asname=None)])    


# Generated at 2022-06-12 03:38:18.750399
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    name = 'test'
    import_ = ast.Import(names=[ast.alias(name=name, 
                                          asname=None)])
    assert BaseImportRewrite(None).visit_Import(import_) == import_


# Generated at 2022-06-12 03:38:23.155429
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    transpiler_class = BaseImportRewrite
    transpiler_class.rewrites = [('dummy', 'new_dummy')]

    input_ast = ast.parse("import dummy")
    expected_ast = ast.parse("""try:
    import dummy
except ImportError:
    import new_dummy""")

    tree = input_ast

    # Test
    transpiler = transpiler_class()
    actual = transpiler.visit_Import(tree.body[0])

    assert_equal_ast(expected_ast.body[0].body[0], actual)



# Generated at 2022-06-12 03:38:27.823387
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')]
    tree = ast.parse('import foo')
    new_tree = ast.fix_missing_locations(MockImportRewrite.transform(tree).tree)
    assert ast.dump(new_tree) == '''
try:
    import foo
except ImportError:
    import bar
'''



# Generated at 2022-06-12 03:38:35.704640
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('path.io', 'path2.io2')
        ]

    source = 'import path.io'
    tree = ast.parse(source)
    result = TestTransformer.transform(tree)
    expected = 'import path.io as path_io\n'\
               'try:\n'\
               '    import path2.io2 as path_io\n'\
               'except ImportError:\n'\
               '    pass'
    assert expected == ast.dump(result.tree)
    assert result.tree_changed is True
    assert result.dependencies == ['print']



# Generated at 2022-06-12 03:38:42.621657
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]
        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    node = ast.parse("""from old_module import Old""")
    node = ImportRewrite().transform(node)
    expected = """try:
    from old_module import Old
except ImportError:
    from new_module import Old"""
    assert astor.to_source(node) == expected
