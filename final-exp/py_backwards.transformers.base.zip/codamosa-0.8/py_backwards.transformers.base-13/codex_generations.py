

# Generated at 2022-06-12 03:29:01.386538
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('from six.moves import map')
    res = TestBaseImportRewrite.transform(tree)
    assert res.changed

    expected = '''\
try:
    from six import map
except ImportError:
    from six.moves import map
'''
    assert ast.dump(res.tree) == expected



# Generated at 2022-06-12 03:29:04.020366
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-12 03:29:10.012175
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # statement with changed module
    node = ast.parse('from old.foo import bar').body[0]
    expected = ast.parse('try:\n    from old.foo import bar\nexcept ImportError:\n    from new.foo import bar')
    assert BaseImportRewrite._replace_import_from_module(BaseImportRewrite(), node, 'old', 'new') == expected
    # statement with changed module and alias
    node = ast.parse('from old.foo import bar as baz').body[0]
    expected = ast.parse('try:\n    from old.foo import bar as baz\nexcept ImportError:\n    from new.foo import bar as baz')
    assert BaseImportRewrite._replace_import_from_module(BaseImportRewrite(), node, 'old', 'new') == expected
    # statement with changed module and level

# Generated at 2022-06-12 03:29:19.870349
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as python_ast
    import typed_ast.ast3 as typed_ast
    from typed_ast.transforms.import_rewrite import BaseImportRewrite

    rewrite_example = [
        ('A', 'B'),
        ('C.D', 'E.F')
    ]

    class MockImportRewrite(BaseImportRewrite):
        rewrites = rewrite_example

    class MockModule(typed_ast.AST):
        body = []
        type_ignores = []

    class MockAST(python_ast.AST):
        body = []
        type_ignores = []

    input_module_name = 'A'
    output_module_name = 'B'


# Generated at 2022-06-12 03:29:30.347675
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..testing import assert_tree_equal

    class Rewrite(BaseImportRewrite):
        rewrites = [('requests', 'fakerequests')]

    tree = ast.parse('''\
from requests.models import Response
from requests import exceptions
from requests import Session
from requests import request
''')
    expected_tree = ast.parse('''\
try:
    from fakerequests.models import Response
except ImportError:
    from requests.models import Response
from requests import exceptions
try:
    from fakerequests import Session
except ImportError:
    from requests import Session
try:
    from fakerequests import request
except ImportError:
    from requests import request
''')

    tree, changed, _ = Rewrite.transform(tree)
    assert changed
    assert_tree_equal(expected_tree, tree)

# Generated at 2022-06-12 03:29:38.330102
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    import os
    import sys
    sys.path.append('.')
    from . import base

    tree = ast.parse("""
import inspect
import os
import typing
import os.path
import inspect as inspect_alias
import inspect as inspect_alias
import os as os_alias
import typing as typing_alias
import os.path as path
""")
    NodeTransformer = base.BaseImportRewrite
    NodeTransformer.rewrites = [('typing', 'typing_backport')]
    node_transformer = NodeTransformer(tree)
    node_transformer.visit(tree)
    print(astor.to_source(tree).rstrip())



# Generated at 2022-06-12 03:29:45.862057
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    class Transformer(BaseImportRewrite):
        rewrites = [('gevent', 'greenlet')]

    tree = ast.parse("""
        import gevent
        import gevent.monkey
        import gevent.greenlet
    """)
    tree = Transformer().visit(tree)

    # Check that import was correctly replaced
    assert astunparse.unparse(tree).strip() == """
        try:
            import gevent
        except ImportError:
            import greenlet
        try:
            import gevent.monkey
        except ImportError:
            import greenlet.monkey
        import gevent.greenlet
    """.strip()



# Generated at 2022-06-12 03:29:56.254231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_astunparse
    import_ast = ast.parse("import ssl")
    base_import_rewrite = BaseImportRewrite(import_ast)
    base_import_rewrite.rewrites = [("ssl", "myssl")]
    base_import_rewrite_visit_import = base_import_rewrite.visit_Import(import_ast.body[0])
    expected = ast.parse(
        "try:" +
        "    import ssl" +
        "except ImportError:" +
        "    import myssl"
    )
    assert typed_astunparse.unparse(base_import_rewrite_visit_import) == typed_astunparse.unparse(expected)
    assert base_import_rewrite._tree_changed == True


# Generated at 2022-06-12 03:30:04.551307
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from mod import name1\nfrom mod1 import *')
    ast.fix_missing_locations(tree)
    class Test(BaseImportRewrite): 
        rewrites = [('mod', 'mod2')]
    
    new_tree = Test.transform(tree).tree

# Generated at 2022-06-12 03:30:11.451465
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six_new')
        ]

    body = ast.parse('from six import print_').body
    expected = ast.parse(
        '''from six_new import print_
        except ImportError:
            from six import print_''').body
    assert body[0].body == []
    assert TestBaseImportRewrite.transform(body) == (expected, True, [])


# Generated at 2022-06-12 03:30:30.396853
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    import _ast
    import io

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('os.path', 'os'),
            ('_six.moves.urllib.parse', 'urllib.parse'),
            ('_six.moves.urllib.error', 'urllib.error'),
        ]


# Generated at 2022-06-12 03:30:40.856312
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    module = ast.parse('from foo import bar, baz; from foo.baz import qux')
    transformer = TestTransformer(module)
    transformer.visit(module)

    assert len(module.body) == 2
    assert isinstance(module.body[0], ast.Try)
    assert isinstance(module.body[0].body[0], ast.ImportFrom)
    assert module.body[0].body[0].module == 'bar'
    assert module.body[0].body[0].names[0].name == 'bar'
    assert module.body[0].body[0].names[1].name == 'baz'


# Generated at 2022-06-12 03:30:41.854900
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor


# Generated at 2022-06-12 03:30:52.219436
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Test for method visit_ImportFrom of class BaseImportRewrite""" 
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('os', 'nt'),
            ('io', 'StringIO')
        ]

    code = 'from os import *'
    expected_code = 'try:\n    from nt import *\nexcept ImportError:\n    from os import *'
    tree = ast.parse(code)
    transformer = TestTransformer(tree)
    result = transformer.visit(tree.body[0])
    assert isinstance(result, ast.Try)
    assert ast.dump(result) == expected_code

    code = 'from io import StringIO'
    expected_code = 'try:\n    from StringIO import StringIO\nexcept ImportError:\n    from io import StringIO'
   

# Generated at 2022-06-12 03:31:01.299160
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Unit test for method visit_ImportFrom of class BaseImportRewrite"""
    import astor
    import ast
    import six

    class BaseTestImportRewrite(BaseImportRewrite):
        rewrites = [('simple', 'rewrote')]

    tree = astor.parse('''
        from simple import a, b, c
        from simple import d
        from simple import e, f
        from simple.sub import g, h
    ''')

    ast.NodeTransformer.visit(BaseTestImportRewrite(tree), tree)

    output = astor.to_source(tree)

# Generated at 2022-06-12 03:31:09.518209
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    import astor
    code = 'import six'
    tree = ast.parse(code)
    new_tree = ast.parse(code)
    assert astor.to_source(TestImportRewrite.transform(tree).tree) == \
           astor.to_source(new_tree)

    code = 'import six.moves'
    tree = ast.parse(code)
    new_tree = ast.parse(code)
    assert astor.to_source(TestImportRewrite.transform(tree).tree) == \
           astor.to_source(new_tree)

    code = 'import six.moves as sm'
    tree = ast.parse(code)
    new_tree = ast

# Generated at 2022-06-12 03:31:20.232963
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]

    tree = ast.parse('import a.b')
    rewrote = Rewrite.transform(tree).tree

    assert(isinstance(rewrote.body[0], ast.Try))
    body = rewrote.body[0].body
    assert(isinstance(body[0], ast.Import))
    assert(body[0].names[0].name == 'c.d')
    assert(isinstance(body[1], ast.ExceptHandler))
    assert(body[1].name == 'ImportError')
    assert(isinstance(body[1].body, ast.Expr))
    assert_is_call(body[1].body.value, 'extend', 'a.b')


# Generated at 2022-06-12 03:31:22.543292
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():  # skipped
    import inspect
    import astor
    from typed_ast import ast3 as ast
    t = BaseImportRewrite()

# Generated at 2022-06-12 03:31:32.888989
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    source = '''
import json
from os import path as pth
from re import *
from abc import * as *ABC
from sys import *
from foo import bar as bar, baz as baz
from zzzz import * as zzzz
from defg import *
'''
    test_node = ast.parse(source).body[0]
    assert isinstance(test_node, ast.ImportFrom)
    namespace, _, _ = ast.fix_missing_locations(test_node)
    namespace.names = [
        ast.alias(name='bar', asname=None),
        ast.alias(name='baz', asname='baz'),
        ast.alias(name='*', asname=None),
        ast.alias(name='*', asname='zzzz')
    ]


# Generated at 2022-06-12 03:31:37.639150
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astor
    from ..utils.testutils import TestParseable

    class TestImportRewrite(unittest.TestCase,
                            TestParseable,
                            metaclass=ABCMeta):
        # TODO: Add tests
        pass

    unittest.main()



# Generated at 2022-06-12 03:32:06.727071
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from .snippet import snippet as s

    class Mock(BaseImportRewrite):
        rewrites = [('pdb', 'ipdb')]

    src = """
from pdb import set_trace
from pdb import set_trace as st
from pdb import *
    """
    tree = parse(src)
    Mock().visit(tree)
    expected = s("""
try:
    from pdb import set_trace
    from pdb import set_trace as st
    from pdb import *
except ImportError:
    from ipdb import set_trace
    from ipdb import set_trace as st
    from ipdb import *
    """)
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-12 03:32:14.648997
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..utils.unittest import parse, ast_to_source

    rewrites = [('abc', 'abc_rewritten')]

    class Test(BaseImportRewrite):
        rewrites = rewrites

    class TestCase(unittest.TestCase):
        def test(self):
            import_node = parse('import abc').body[0]
            rewritten = Test().visit(import_node)
            self.assertEqual(ast_to_source(rewritten),
                             'try:\n    import abc\nexcept ImportError:\n    import abc_rewritten')


# Generated at 2022-06-12 03:32:24.246345
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Base(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.parse('import foo.bar')
    test_node = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    # Test with rewrited module
    res = Base.transform(node)
    assert res.changed is True
    assert ast.dump(res.tree) == ast.dump(test_node)

    # Test with rewrited name
    node = ast.parse('from foo import bar')
    test_node = ast.parse('try:\n    from foo import bar\nexcept ImportError:\n    from bar import bar')

    res = Base.transform(node)
    assert res.changed is True

# Generated at 2022-06-12 03:32:33.495330
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from _six import exec_
    from typed_ast.ast3 import Import
    import typed_astunparse
    from . import BaseImportRewrite, BaseNodeTransformer
    # Init
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]
    # Test
    code = 'import old_module'
    expected_code = "try:\n    import old_module\nexcept ImportError:\n    import new_module"
    tree = ast.parse(code)
    TestImportRewrite.transform(tree)
    generated_code = typed_astunparse.unparse(tree)
    assert generated_code == expected_code
    exec_(generated_code)


# Generated at 2022-06-12 03:32:42.009269
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    expected_source = \
u'''try:
    import old
except ImportError:
    import new
'''

    import_node = ast.Import(names=[ast.alias(name='old',
                                             asname=None)])
    actual_source = ast.unparse(BaseImportRewrite._replace_import(None, 'old', 'new'), indent_with='    ')
    assert actual_source == expected_source

    # import with new name
    expected_source = \
u'''try:
    import old as new
except ImportError:
    import old
'''

    import_node = ast.Import(names=[ast.alias(name='old',
                                             asname='new')])

# Generated at 2022-06-12 03:32:50.474213
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from typed_ast import Code
    import copy
    class Test1(BaseImportRewrite):
        rewrites = [('builtins', 'future')]
        def visit_Import(self, node):
            return super(Test1, self).visit_Import(node)

    class Test2(BaseImportRewrite):
        rewrites = [('builtins', 'future')]
        def visit_ImportFrom(self, node):
            return super(Test2, self).visit_ImportFrom(node)

    # single import in file
    code1 = Code("import builtins", mode="exec")
    expected1 = "try:\n    import builtins\nexcept ImportError:\n    import future as builtins"
    c1 = Test1()

# Generated at 2022-06-12 03:32:59.490198
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock as mock

    class MockTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Namespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-12 03:33:08.070143
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse, dump  # type: ignore
    from .. import Base
    import unittest
    import mock

    class MockTransformer(mock.Mock, BaseImportRewrite):
        rewrites = [
            ('six', 'sixer'),
            ('a.b', 'b.a'),
            ('a.b.c', 'c.a.b')
        ]

    transformer = MockTransformer(None)

    def mock_generic_visit(node: ast.AST) -> ast.AST:
        return node

    transformer.generic_visit = mock_generic_visit
    unparse(transformer.visit(ast.parse('import six')), '')
    unparse(transformer.visit(ast.parse('import six.moves.queue as queue')), '')

# Generated at 2022-06-12 03:33:10.894930
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testutils import assert_transformed_ast

    class FooTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    input_tree = ast.parse("import foo")

# Generated at 2022-06-12 03:33:14.435637
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse('''
import abc
from abc import a, b
from a.b import c, d as e
from a import b as f
import a
from a import * 
''')
    BaseImportRewrite(None).visit(module)

# Generated at 2022-06-12 03:33:36.322375
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .transformers import BaseImportRewrite
    from astunparse import unparse

    node = ast.parse("from foo import bar")
    BaseImportRewrite.rewrites = [("foo", "baz")]
    transformed = BaseImportRewrite(node)
    transformed.visit(node)
    assert unparse(node) == "try:\n    from foo import bar\nexcept ImportError:\n    from baz import bar"

# Generated at 2022-06-12 03:33:46.306274
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import copy
    import astor
    import_from = ast.ImportFrom(module = 'from_module', names = [
        ast.alias(name = 'from_name', asname = None),
        ast.alias(name = 'from_name2', asname = 'from_name2_as'),
        ast.alias(name = 'from_name3', asname = 'from_name3_as')
    ], level = 0)
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('from_module', 'to_module')]

# Generated at 2022-06-12 03:33:56.638654
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import aio
    from ..asyncio import aio
    from ..asyncio import aio as aio0
    import asyncio
    from .. import asyncio
    from .. import asyncio as asyncio0

    import aio
    import aio as aio0
    import aio.os
    from aio import os
    from aio import os as os0
    from aio import os as os0, os as os1, os as os2
    from aio import os as os0, os as os1, os as os2, os as os3
    from aio import os, os as os0
    from aio.os import other
    from aio import *
    from aio.os import *

# Generated at 2022-06-12 03:34:06.502672
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = 'from test import a, b\n'
    node = ast.parse(code)
    transformer = BaseImportRewrite(node)
    result = transformer.visit_ImportFrom(node.body[0])
    check = node.body[0]
    assert result.body[0].test.func.value.id == 'ImportError'
    assert result.body[0].test.args[0].s == 'test'
    assert result.body[0].body[0].value.module.id == 'test'
    assert result.body[0].body[0].value.names[0].name.id == 'a'
    assert result.body[0].body[0].value.names[1].name.id == 'b'



# Generated at 2022-06-12 03:34:15.012498
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    from ..tests.utils import assert_equal_tree
    from typed_ast import ast3 as ast

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestSuccess(unittest.TestCase):
        def test_rewrite_import(self):
            inp = ast.parse('''
                import foo
                ''')
            expected = ast.parse('''
                try:
                    import foo
                except ImportError:
                    import bar
                ''')
            assert_equal_tree(expected, Test.transform(inp).tree)

    class TestFailure(unittest.TestCase):
        def test_not_rewrite_import(self):
            inp = ast.parse('''
                import foo as bar
                ''')

# Generated at 2022-06-12 03:34:25.301996
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import textwrap
    from ..utils.test import TestCase
    from ..utils.snippet import snippet, extend

    import_rewrite = snippet('''
        try:
            extend(previous)
        except ImportError:
            extend(current)
    ''')

    class TestTransformer(BaseImportRewrite):
        target = None
        rewrites = [
            ('base_transformer', 'base_rewriter')
        ]

        def __init__(self, tree):
            super().__init__(tree)
            self.rewrites = []

        def visit_Import(self, node):
            rewrite = self._get_matched_rewrite(node.names[0].name)
            if rewrite:
                return self._replace_import(node, *rewrite)

# Generated at 2022-06-12 03:34:31.969537
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing.transformation import apply_transformer

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six_old'),
        ]

    node = ast.parse('import six')
    new_node = apply_transformer(TestTransformer, node)
    assert new_node.body[0] == import_rewrite.get_body(previous='import six',
                                                       current='import six_old')[0]


# Generated at 2022-06-12 03:34:37.791990
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    input_ = b'''
import tensorflow as tf
a = tf.add(b, c)
'''
    expected = b'''
try:
    import tensorflow as tf
except ImportError:
    import tensorflow.compat.v1 as tf
a = tf.add(b, c)
'''

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('tensorflow', 'tensorflow.compat.v1')]

    result = ImportRewrite.transform(ast.parse(input_))
    assert result.tree == ast.parse(expected)



# Generated at 2022-06-12 03:34:46.570968
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestImport(BaseImportRewrite):
        rewrites = [('time', 'datetime')]

    import_ = ast.parse('import time')
    tree = TestImport.transform(import_).tree
    assert 'import datetime' == ast.dump(tree)

    import_ = ast.parse('import time.localtime')
    tree = TestImport.transform(import_).tree
    assert 'try:\n    import time.localtime\nexcept ImportError:\n    import datetime.localtime' == ast.dump(tree)

    import_ = ast.parse('import time as time')
    tree = TestImport.transform(import_).tree
    assert 'try:\n    import time as time\nexcept ImportError:\n    import datetime as time' == ast.dump(tree)



# Generated at 2022-06-12 03:34:54.279969
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.utils import compile_tree, get_tree
    from ..types import CompilationTarget
    from ..transformers.transformers import ImportRewrite
    from ..utils.utils import get_module_body
    import astor
    import ast

    # test basic
    tree = get_tree('import numpy')
    module_body = get_module_body(tree)
    assert len(module_body) == 1
    assert isinstance(module_body[0], ast.Import)
    assert module_body[0].names[0].name == 'numpy'

    result, changed, deps = ImportRewrite.transform(tree)
    assert changed
    module_body = get_module_body(result)
    assert len(module_body) == 1
    assert isinstance(module_body[0], ast.Try)
   

# Generated at 2022-06-12 03:35:24.017846
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import unittest

    class TestModule(ast.NodeVisitor):
        def __init__(self):
            self.body = []
            self.body.append(ast.Import(names=[ast.alias(name='sys'), ast.alias(name='os')]))

        def visit_Import(self, node):
            return 'x'

    module = TestModule()
    result = module.visit(module.body[0])
    assert result == 'x'


# Generated at 2022-06-12 03:35:31.991614
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    old_import = ast.Import(names=[
        ast.alias(name='foo', asname='foo')])

    expected_import = ast.Try(body=[ast.Import(names=[
        ast.alias(name='bar', asname='foo')])],
        handlers=[ast.ExceptHandler(type=None, name=None, body=[ast.Import(names=[
            ast.alias(name='foo', asname='foo')])])],
        orelse=[],
        finalbody=[])

    assert Test.visit_Import(old_import) == expected_import



# Generated at 2022-06-12 03:35:38.538498
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Replace foo import with bar."""
    class FooTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_node = ast.parse("import foo").body[0]
    replacement_node = ast.parse("try:\n    import foo\nexcept ImportError:\n    import bar")
    replacement_node = replacement_node.body[0]
    assert FooTransformer.transform(import_node).tree == replacement_node



# Generated at 2022-06-12 03:35:43.734653
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_ast = ast.parse("import math").body[0]
    visitor = BaseImportRewrite(import_ast)
    visitor.rewrites = [
        ('math', 'math_new')
    ]

    result = visitor.visit(import_ast)
    assert type(result.body[0]) == ast.Try



# Generated at 2022-06-12 03:35:47.344536
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..transformers.django import migrate
    tree = ast.parse('import django')
    migrate.transform(tree)
    assert astor.to_source(tree) == 'try:\n    import django\nexcept ImportError:\n    import django_migrations'



# Generated at 2022-06-12 03:35:53.192818
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'from . import foo, bar'
    import_ = 'from . import baz'
    node = ast.parse(from_).body[0]
    assert isinstance(node, ast.ImportFrom)
    assert not BaseImportRewrite._get_names_to_replace(node)
    node = ast.parse(import_).body[0]
    assert isinstance(node, ast.ImportFrom)
    assert not BaseImportRewrite._get_names_to_replace(node)

# Generated at 2022-06-12 03:36:03.322501
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # constants for unit test
    s = ast.parse("from typing import List")
    test_rewrite = "typing", "future.types.newtypes"
    test_rewroted = "future.types.newtypes", "future.types.newtypes"

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [test_rewrite]

    result = TestImportRewrite.transform(s)
    assert result.changed

    assert isinstance(result.tree, ast.Try)
    assert isinstance(result.tree.body[0], ast.ImportFrom)
    assert isinstance(result.tree.body[1], ast.ImportFrom)
    assert result.tree.body[0].module == test_rewroted[0]

# Generated at 2022-06-12 03:36:14.241631
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from py1 import a1\nfrom py1 import a2')
    inst = BaseImportRewrite(tree)

# Generated at 2022-06-12 03:36:23.566052
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('abc', 'def')
        ]

    inst = Transformer(None)

    # No rewrite
    tree = ast.Import([ast.alias(name='abc')])
    new_tree = inst.visit_Import(tree)
    assert new_tree == tree

    # Rewrite
    tree = ast.Import([ast.alias(name='abc')])
    expected = ast.Try(ast.Import([ast.alias(name='def')]),
                       [ast.ExceptHandler(None, None, [ast.Import([ast.alias(name='abc')])])],
                       [],
                       [])
    new_tree = inst.visit_Import(tree)

# Generated at 2022-06-12 03:36:34.265788
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    import sys

    class ImportRewriteTransformer(BaseImportRewrite):
        target = CompilationTarget.STDLIB
        rewrites = [('six.moves', 'six.moves.builtins')]

    class ImportTransformer(BaseImportRewrite):
        target = CompilationTarget.THIRD_PARTY
        rewrites = [('six.moves', 'six.moves.builtins')]

    tree = ast.parse('import six.moves.cPickle')
    expected_rewritten = """try:
    import six.moves.cPickle
except ImportError:
    import six.moves.builtins.cPickle"""

    assert ImportRewriteTransformer.transform(tree) == \
        TransformationResult(ast.parse(expected_rewritten), True, [])

   

# Generated at 2022-06-12 03:37:22.160544
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from pprint import pprint
    from ..utils.vistools import from_source

    class TestTransformer(BaseImportRewrite):
        target = '<test_target>'
        rewrites = [('os', 'os.path')]

    t = TestTransformer(from_source('import os'))
    pprint(t.visit(t._tree))



# Generated at 2022-06-12 03:37:29.624829
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    import astor

    class _BaseImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    class TestBaseImportRewrite(unittest.TestCase):

        # Nothing is changed
        def test_no_change(self):
            tree = ast.parse("""import a\nfrom . import b\nfrom .. import c\n""")
            _BaseImportRewrite.transform(tree)
            self.assertEqual(astor.to_source(tree), """import a\nfrom . import b\nfrom .. import c\n""")

        # Import has been replaced
        def test_replace_import(self):
            tree = ast.parse("""import old\n""")
            _BaseImportRewrite.transform(tree)

# Generated at 2022-06-12 03:37:38.572337
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .unittest_utils import assert_node_equals
    from ..utils.ast_helpers import get_python_source

    rewrites = [
        ('old_module', 'new_module'),
        ('old_submodule.subsubmodule', 'new_submodule.subsubmodule'),
    ]

# Generated at 2022-06-12 03:37:47.488404
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Test method visit_Import of class BaseImportRewrite."""
    class Transformer(BaseImportRewrite):
        target = 'python'
        rewrites = [('transforms', 'transforms_python')]

    assert ast.dump(ast.parse(
        'import transforms'), 'single') == ast.dump(Transformer.transform(
        ast.parse('import transforms')).tree, 'single')

    assert ast.dump(ast.parse(
        'import transforms.node'), 'single') == ast.dump(Transformer.transform(
        ast.parse('import transforms.node')).tree, 'single')

    assert ast.dump(ast.parse(
        'import transforms_python'), 'single') == ast.dump(Transformer.transform(
        ast.parse('import transforms_python')).tree, 'single')


# Generated at 2022-06-12 03:37:54.437642
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_node = ast.ImportFrom(module = 'my_package.my_module.my_submodule', names = [ast.alias(name = 'my_import', asname = 'my_alias')], level = 0)

    tr = BaseImportRewrite()
    repl_node = tr.visit_ImportFrom(import_node)
    assert repl_node == ast.ImportFrom(module = 'my.other.package.my_module.my_submodule', names = [ast.alias(name = 'my_import', asname = 'my_alias')], level = 0)

# Generated at 2022-06-12 03:37:59.760198
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astor.code_gen import to_source
    from .utils import get_module

    class SubTransformer(BaseImportRewrite):
        rewrites = [('_py2to3.builtins', 'builtins')]

    tree = get_module('import_import')
    result = SubTransformer.transform(tree)
    print(result.changed)
    print(to_source(result.tree))



# Generated at 2022-06-12 03:38:01.548999
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    obj = BaseImportRewrite()
    ret = obj.visit_ImportFrom(None)
    assert ret is None



# Generated at 2022-06-12 03:38:11.515074
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert ast.dump(
        BaseImportRewrite().visit(ast.parse('import re'))) == \
           'Module(body=[Import(names=[alias(name=\'re\', asname=None)])])'
    assert ast.dump(
        BaseImportRewrite().visit(ast.parse('import re.what'))) == \
           'Module(body=[Import(names=[alias(name=\'re.what\', asname=None)])])'
    assert ast.dump(
        BaseImportRewrite().visit(ast.parse('import re.what as that'))) == \
           'Module(body=[Import(names=[alias(name=\'re.what\', asname=\'that\')])])'

# Generated at 2022-06-12 03:38:15.748292
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class A(BaseImportRewrite):
        rewrites = [('a', 'b')]

    assert A.transform(ast.parse('import a')).tree == ast.parse(
        'try:\n'
        '    import a\n'
        'except ImportError:\n'
        '    import b')



# Generated at 2022-06-12 03:38:20.450912
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..target import NodeTarget

    @snippet
    class F(BaseImportRewrite):
        __module__ = 'target'
        target = NodeTarget
        rewrites = [
            ('old', 'new')
        ]

    tree = ast.parse('import old')
    F.transform(tree)
    result = astor.to_source(tree)
    assert result == dedent('''
    try:
        import old
    except ImportError:
        import new
    ''')

