

# Generated at 2022-06-12 03:28:57.178256
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Case 1: Import with no rewrite
    tree = ast.parse('import unittest')
    original = ast.dump(tree)
    BaseImportRewrite([], [], tree).visit(tree)
    result = ast.dump(tree)
    assert original == result, 'BaseImportRewrite.visit_Import: import unchanged'

    # Case 2: Import with rewrite
    tree = ast.parse('import unittest')
    original = ast.dump(tree)
    BaseImportRewrite([('unittest', 'unittest2')], [], tree).visit(tree)
    result = ast.dump(tree)

# Generated at 2022-06-12 03:29:03.365203
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Test if import is replaced."""
    from typed_ast import ast3 as ast

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('_io', 'io')]

    tree = ast.parse("import os\nimport _io")
    result = ImportRewrite.transform(tree)
    print(result.tree)
    print(result.changed)



# Generated at 2022-06-12 03:29:08.773658
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_ast_equal

    class SimpleTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    import_ast = ast.parse('import old')
    with assert_ast_equal(ast.parse('try:\n    import old\nexcept ImportError:\n    import new')):
        SimpleTransformer.transform(import_ast)

    import_from_ast = ast.parse('import new')
    with assert_ast_equal(import_from_ast):
        SimpleTransformer.transform(import_from_ast)


# Generated at 2022-06-12 03:29:18.851856
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_stmt = ast.parse("import module").body[0]
    rewrite = BaseImportRewrite(None)

    res = rewrite._get_matched_rewrite("module")
    assert res == None

    rewrite.rewrites = [("module", "other_module")]
    res = rewrite._get_matched_rewrite("module")
    assert res == ("module", "other_module")

    res = rewrite._get_matched_rewrite("module.module_sub")
    assert res == ("module", "other_module")

    res = rewrite._get_matched_rewrite("module_sub")
    assert res == None

    rewrote_tree = rewrite._replace_import(import_stmt, *rewrite._get_matched_rewrite("module"))
    assert rewrote_tree.body[0].value == "import module"


# Generated at 2022-06-12 03:29:26.066478
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transformer = BaseImportRewrite()
    transformer.rewrites = [('glib.i18n', 'gi.repository.GLib')]
    node = ast.ImportFrom(module='glib',
                          names=[ast.alias(name='_',
                                           asname='_')],
                          level=0)
    rewrote = transformer.visit_ImportFrom(node)
    assert rewrote.body[0].body[0].value.names[0].name == 'gi.repository.GLib._'



# Generated at 2022-06-12 03:29:34.422799
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('my_module', 'my_module_rewrote')
        ]

    tree = ast.parse(textwrap.dedent('''\
    import my_module

    my_module.foo()
    '''))

    new_tree = Transformer.transform(tree)
    assert new_tree.changed

    new_tree = ast.parse(textwrap.dedent('''\
    import my_module
    import my_module_rewrote

    try:
        my_module.foo()
    except ImportError:
        my_module_rewrote.foo()
    '''))


# Generated at 2022-06-12 03:29:44.114100
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class NodeTransformer(BaseImportRewrite):
        rewrites = [('base_import_rewrite', 'base_import_rewrite2')]

    node = ast.Import([ast.alias(name='base_import_rewrite', asname=None)])
    transformed = NodeTransformer(node).visit(node)
    assert isinstance(transformed, ast.Try)
    assert isinstance(transformed.body[0], ast.Import)
    assert transformed.body[0].names[0].name == 'base_import_rewrite'
    assert transformed.body[0].names[0].asname is None

    # check except block
    assert len(transformed.handlers) == 1
    assert len(transformed.handlers[0].body) == 2

# Generated at 2022-06-12 03:29:54.069064
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from logging import Logger, StreamHandler, Formatter, DEBUG
    from io import StringIO
    from ..utils.testutil import init_logger

    # Initialize logger
    output = StringIO()
    init_logger(level=DEBUG, output=output)
    logger = Logger(__name__)
    handler = StreamHandler(output)
    handler.setFormatter(Formatter('%(asctime)s [%(levelname)s] %(name)s [%(funcName)s]: %(message)s'))
    logger.addHandler(handler)

    rewrites = [('a', 'b')]

# Generated at 2022-06-12 03:30:00.419733
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    import astor
    t = BaseImportRewrite({'rewrites': [('abc', 'def')]})
    node = ast.Import(names=[ast.alias(name='abc', asname=None)])
    result = t.visit_Import(node)
    expected = 'try:\n    import abc\nexcept ImportError:\n    import def'
    assert astor.to_source(result) == expected


# Generated at 2022-06-12 03:30:10.742691
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewr = BaseImportRewrite()
    assert ast.dump(ast.parse("from six.moves import range")) == ast.dump(rewr.visit(ast.parse("from six.moves import range")))
    assert ast.dump(ast.parse("from six.moves import range, map")) == ast.dump(rewr.visit(ast.parse("from six.moves import range, map")))
    assert ast.dump(ast.parse("from six.moves import range as rng")) == ast.dump(rewr.visit(ast.parse("from six.moves import range as rng")))
    assert ast.dump(ast.parse("from six.moves.urllib import request")) == ast.dump(rewr.visit(ast.parse("from six.moves.urllib import request")))

# Generated at 2022-06-12 03:30:20.603335
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import x')

    class TestTransformer(BaseImportRewrite):
        rewrites = [('x', 'y')]

    assert TestTransformer.transform(tree) == TransformationResult(
        tree=ast.parse(
            'try:'
            '    import y'
            'except ImportError:'
            '    import x'),
        tree_changed=True,
        dependencies=[])



# Generated at 2022-06-12 03:30:30.677975
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typing
    import six

    import astroid
    from astroid import nodes

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typing', 'typing_extensions')]

    tree = astroid.parse('import typing')
    assert (TestTransformer.transform(tree.body[0]).tree ==
            nodes.Try(
                nodes.Import(
                    nodes.alias(
                        name='typing',
                        asname=None
                    )
                ),
                nodes.ExceptHandler(
                    nodes.Import(
                        nodes.alias(
                            name='typing_extensions',
                            asname=None
                        )
                    ),
                    None,
                    nodes.Name(
                        name='ImportError'
                    )
                ),
            ))


# Generated at 2022-06-12 03:30:41.093851
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    print("Test: BaseImportRewrite_visit_Import")
    import astor
    import astunparse
    node = ast.parse("import math")
    expected = ast.parse("import math")
    ir = BaseImportRewrite()
    ir.rewrites = [('math', 'numpy')]
    actual = ir.visit(node)
    assert astor.to_source(actual) == astor.to_source(expected)
    expected = ast.parse("try:\r\n    import math\r\nexcept ImportError:\r\n    import numpy")
    ir.rewrites = [('math', 'numpy')]
    actual = ir.visit(node)
    actual = ast.Module(body=actual)
    assert astor.to_source(actual) == astor.to_source(expected)

# Generated at 2022-06-12 03:30:51.151686
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..types import CompilationTarget
    from ..utils.ast_visitor import compare_ast

    class TestCase(unittest.TestCase):
        def test_simple(self):
            class Transformer(BaseImportRewrite):
                target = CompilationTarget.PYTHON_3
                rewrites = [(from_, to) for from_, to in [
                    ('abc', 'abc3'),
                    ('abc.def', 'abc3.def3'),
                    ('abc.def.ghi', 'abc3.def3.ghi3')]]

            code = """\
            import abc

            import abc.def

            import abc.def.ghi
            """

# Generated at 2022-06-12 03:30:55.276953
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from typed_ast.ast3 import parse

    class ImportRewriteTest(unittest.TestCase):
        def test_import_from_no_rewrite(self):
            tree = parse('from foo import bar')
            trans = BaseImportRewrite(tree)
            res = trans.visit_ImportFrom(tree.body[0])
            self.assertIsInstance(res, ast.ImportFrom)
            self.assertEqual(res.module, 'foo')
            self.assertEqual(res.names[0].name, 'bar')

        def test_import_from_rewrite_module(self):
            tree = parse('from foo import bar')
            trans = BaseImportRewrite(tree)
            trans.rewrites = [
                ('foo', 'foo_new'),
            ]

# Generated at 2022-06-12 03:31:02.906947
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from1 = ast.parse("""
    from os import path, popen
    """).body[0]
    import_from2 = ast.parse("""
    from os.path import join, split
    """).body[0]
    node = ast.Module(body=[
        import_from1,
        import_from2
    ])

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('os', 'posix'),
            ('os.path', 'posix.path')
        ]

    result = TestImportRewrite.transform(node)
    assert result.transformed


# Generated at 2022-06-12 03:31:10.214531
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [('foo', 'baz')]

    import_from = ast.ImportFrom(module='foo.bar', names=[ast.alias(name='bar', asname='b')])
    import_from_rewrite = ast.Try(
        body=[ast.ImportFrom(module='foo.bar', names=[ast.alias(name='b', asname='bar')])],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[ast.ImportFrom(module='baz.bar',
                                                         names=[ast.alias(name='b', asname='bar')])])],
        orelse=[],
        finalbody=[],
    )


# Generated at 2022-06-12 03:31:20.885030
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:31:30.696695
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransform(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    from_, module, lineno = ast.ImportFrom, 'foo', 10
    obj = from_(module=module, level=0)
    obj.col_offset, obj.lineno = 0, lineno
    tree = obj
    new_tree, changed, dependencies = TestTransform.transform(tree)
    assert obj is not new_tree
    assert changed

    assert isinstance(new_tree, ast.Try)
    assert isinstance(new_tree.body[0], ast.ImportFrom)
    assert new_tree.body[0].module == 'bar'
    assert new_tree.body[1].body[0].module == module

    from_, module, lineno = ast.ImportFrom, 'foo.foo', 10
   

# Generated at 2022-06-12 03:31:41.650433
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = ast.parse("""
    import django.test
    from django.test import TestCase, HttpRequest
    import six

    import os
    import sys
    """)  # type: ast.Module

    rewrites = [('django.test', 'unittest.mock')]
    node_transformer = BaseImportRewrite(rewrites=rewrites)


# Generated at 2022-06-12 03:31:58.206188
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    import_from_code = '''
        from previous.submodule import something
        from previous.submodule import another
        from other.submodule import something'''

    expected_result = '''
        try:
            from previous.submodule import something
        except ImportError:
            from current.submodule import something


        try:
            from previous.submodule import another
        except ImportError:
            from current.submodule import another


        from other.submodule import something'''
    tree = ast.parse(import_from_code)
    Test.transform(tree)
    assert ast.dump(tree) == expected_result

# Generated at 2022-06-12 03:31:58.999688
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass

# Generated at 2022-06-12 03:32:07.710634
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import sys
    from . import _utils

    # Create a test node
    node = ast.ImportFrom(
        level=0,
        module='django',
        names=[_utils.alias('conf')],
    )

    # Create a test transformer
    class TestTransformer(BaseImportRewrite):
        rewrites = [('django.conf', 'django.conf.global_settings')]

    # Transform node
    tree = TestTransformer.transform(node).tree

    # Check node
    assert isinstance(tree, ast.Try)
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert tree.body[0].names[0].name == 'django.conf'

# Generated at 2022-06-12 03:32:17.075170
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyImportRewrite(BaseImportRewrite):  # type: ignore
        rewrites = [('foo', 'bar')]
    
    import_stmt = ast.Import(names=[
        ast.alias(name='foo',
                  asname='foo1'),
        ast.alias(name='foo.bar',
                  asname='baz')])
    tree = ast.Module(body=[import_stmt])

    result = MyImportRewrite.transform(tree)
    rewrote = list(result.tree.body)[0]
    assert isinstance(rewrote, ast.Try)
    (rewrote_stmt,) = rewrote.body
    assert isinstance(rewrote_stmt, ast.Import)
    (rewrote_alias,) = rewrote_stmt.names


# Generated at 2022-06-12 03:32:24.452965
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    class Imports(BaseImportRewrite):
        target = 'python3.5'
        rewrites = [('foo', 'bar')]

    test_input = """
import foo
    """.strip()

    expected_output = """
try:
    import foo
except ImportError:
    import bar
    """.strip()

    # Exercise
    tree = ast.parse(test_input)
    tree = Imports.transform(tree).tree

    # Verify
    assert ast.dump(tree) == expected_output


# Generated at 2022-06-12 03:32:28.052176
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import compare_ast

    class Foo(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-12 03:32:36.138101
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_tree = ast.parse("""import os""")

    class ExampleTransformer(BaseImportRewrite):
        rewrites = [('os', 'pathlib')]

    node = ast.parse("""import os""")
    try_node = ast.parse("""try:
    import os
except ImportError:
    import pathlib as os""")
    try_node.body[1].body[0].names[0].asname = None
    example_transformer = ExampleTransformer(node)
    example_transformer.visit(node)
    assert node == try_node


# Generated at 2022-06-12 03:32:38.704345
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [('x', 'y')]
    ast = ast_from_import('import x', rewrites)
    assert ast.body[0].names[0].name == 'y'



# Generated at 2022-06-12 03:32:48.317035
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..types import CompilationTarget
    from ..utils.snippet import snippet, extend
    from ..compilers.python import BaseImportRewrite
    extend(snippet)
    target = CompilationTarget('python3')
    tree = astor.parse('from collections import OrderedDict')
    tr = BaseImportRewrite.transform(tree)
    assert tr.tree.body[0].body[0].value.func.value.id == 'ordered_dict'
    assert tr.tree.body[0].body[0].value.func.value.attr == 'OrderedDict'
    assert tr.tree.body[0].handlers[0].name.id == 'collections'
    assert tr.tree.body[0].handlers[0].name.attr == 'OrderedDict'
    assert tr

# Generated at 2022-06-12 03:32:54.968314
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    class Rewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo")
    rewrote = Rewrite.transform(tree)
    result = ast.dump(rewrote)
    assert result == "Try(body=[Import(names=[alias(name='bar', asname='foo')])], " \
                     "handlers=[ExceptHandler(type=None, " \
                     "name=None, body=[Import(names=[alias(name='foo', asname='foo')])])], " \
                     "orelse=[], finalbody=[])"



# Generated at 2022-06-12 03:33:07.834801
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('some_library', 'some_package')]

    tree = ast.parse('from some_library import *\n'
                     'from some_library import module2\n'
                     'import some_library.module3')
    result = TestImportRewrite.transform(tree)
    expected = ('try:\n'
                '    from some_library import *\n'
                'except ImportError:\n'
                '    from some_package import *\n'
                'try:\n'
                '    from some_library import module2\n'
                'except ImportError:\n'
                '    from some_package import module2\n'
                'from some_library.module3 import module3')

# Generated at 2022-06-12 03:33:16.499074
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('foo.bar', 'baz')]

# Generated at 2022-06-12 03:33:25.201483
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astor import dump_tree
    import ast

    from ..abstract import BaseNodeTransformer
    from ..utils.snippet import snippet


    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)


    class TestTransformer(BaseNodeTransformer):
        rewrites = [
            ('unittest', 'unittest2'),
            ('ast.NodeTransformer', 'typed_ast.ast3.NodeTransformer'),
            ('ast.fix_missing_locations', 'typed_ast.ast3.fix_missing_locations'),
            ('ast.parse', 'typed_ast.ast3.parse'),
            ('ast.dump', 'typed_ast.ast3.dump'),
        ]

# Generated at 2022-06-12 03:33:31.248199
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PY2
        rewrites = [
            ('old_module', 'new_module'),
            ('foo.bar.old_module', 'foo.bar.new_module'),
            ('__future__', 'future')
        ]

    with open(path.join(path.dirname(__file__), 'fixtures', 'import_rewrite.py')) as f:
        tree = ast.parse(f.read())
    result = TestTransformer.transform(tree)
    assert result.is_changed
    assert result.dependencies == ['future']
    assert 'foo.bar.new_module.baz' in ast.dump(result.tree)
    assert 'import future.print_function' in ast.dump(result.tree)

# Generated at 2022-06-12 03:33:41.908325
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    class Visitor(BaseImportRewrite):
        rewrites = [('typing', 'typing_extensions')]
    class Test(ast.NodeVisitor):
        def visit_ImportFrom(self, node):
            output = astor.to_source(Visitor().visit(node), indent_with=' '*4)
            return output

    program = """
from typing.abc import ABCMeta
    """
    # end program
    expected = """
try:
    from typing.abc import ABCMeta
except ImportError:
    from typing_extensions.abc import ABCMeta
    """
    # end expected
    tree = ast.parse(program)
    Test().visit(tree)
    assert astor.to_source(tree, indent_with=' '*4) == expected

# Generated at 2022-06-12 03:33:46.305816
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = """
from os.path import join, splitext
from io import StringIO, BytesIO
"""
    node = ast.parse(code)
    node = BaseImportRewrite.visit(node)
    print(compile(node, filename='<snippet>', mode='exec').co_code)
    assert False

# Generated at 2022-06-12 03:33:56.638542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    try:
        import import_rewrite_test_module
    except ImportError:
        import_rewrite_test_module = __import__('future', fromlist=['some_future_module'])
    parent = ast.parse('import import_rewrite_test_module')
    import_rewrite_test_module.some_future_module = parent
    import_rewrite_test_module.some_past_module = parent
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('import_rewrite_test_module', 'some_future_module'),
            ('some_future_module', 'some_past_module')]
    tree = ast.parse('import import_rewrite_test_module')
    result = ImportRewrite.transform(tree)
    assert result.tree == import_rewrite_

# Generated at 2022-06-12 03:34:07.319396
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Unit test for method visit_ImportFrom of class BaseImportRewrite."""
    new_str = 'new_str'  # type: str
    new_str_ignored = 'new_str_ignored'  # type: str

# Generated at 2022-06-12 03:34:15.467064
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget

    class TestTransformer(BaseImportRewrite):
        rewrites = [('sys', 'foo.sys')]
        target = CompilationTarget.STDLIB

    import astor
    source_tree = astor.parse('''
import sys
sys.argv
    ''')
    expected_transformed_tree = astor.parse('''
try:
    import sys
    import sys as foo_sys
    import sys as foo_sys
except ImportError:
    import foo.sys
    import foo.sys as foo_sys
    import foo.sys as foo_sys

sys.argv
    ''')
    transformed_tree = TestTransformer.transform(source_tree).tree

# Generated at 2022-06-12 03:34:25.586435
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    import ast as _ast
    from .test_BaseImportRewrite import test_BaseImportRewrite_visit_ImportFrom

    module = type(sys)('test_BaseImportRewrite_visit_ImportFrom')
    module.__file__ = sys.modules['typed_astunparse'].__file__
    module.__builtins__ = sys.modules['builtins']
    module.__package__ = 'typed_astunparse'
    module.__doc__ = ''
    sys.modules['test_BaseImportRewrite_visit_ImportFrom'] = module
    exec(test_BaseImportRewrite_visit_ImportFrom.__code__.co_consts[1], module.__dict__)

    assert 'test_BaseImportRewrite_visit_ImportFrom' in sys.modules


# Generated at 2022-06-12 03:34:44.833938
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import sys
    # backup the original dir
    original_path = sys.path.copy()
    sys.path.remove('')

    from astunparse import unparse
    from ast import parse

    class Transformer(BaseImportRewrite):
        rewrites = [('json', 'demjson')]

    source = "from json import dumps, loads"

# Generated at 2022-06-12 03:34:53.018801
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from ast_tools.transformers.base import BaseImportRewrite

    import_from = ast.ImportFrom(
        module='foo.bar',
        names=[
            ast.alias(name='baz',
                      asname='baz_alias')
        ],
        level=0,
    )

    class TestTransformer(BaseImportRewrite):
        target = '3.5'
        rewrites = [('foo.bar', 'mod_to_import')]

    import_from_rewritten = TestTransformer.visit_ImportFrom(TestTransformer, import_from)

# Generated at 2022-06-12 03:34:58.083728
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    from . import _mock_dependencies

    transformer = BaseImportRewrite(ast.parse(_mock_dependencies.SOURCE))
    transformer.rewrites = [('pandas', 'pyspark')]
    transformer.visit_Import(ast.parse(_mock_dependencies.SOURCE_IMPORT_STATEMENT))

    source = astor.to_source(transformer._tree)
    import_stmt = _mock_dependencies.SOURCE_IMPORT_STATEMENT.strip()
    assert import_stmt in source
    import_stmt = 'import pyspark\n'
    assert import_stmt in source
    import_stmt = 'except ImportError: import pyspark\n'
    assert import_stmt in source


# Generated at 2022-06-12 03:35:06.112756
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor  # type: ignore
    tree = ast.parse("""from json import loads, dumps""")
    node = tree.body[0]
    with patch("builtins.__import__", autospec=True) as mock_import:
        mock_import.side_effect = ImportError
        transform = BaseImportRewrite(tree)
        result = transform.visit_ImportFrom(node)
        assert isinstance(result, ast.Try)
        assert astor.to_source(result).strip() == """\
try:
    from json import loads, dumps
except ImportError:
    from yajson import loads, dumps"""

# Generated at 2022-06-12 03:35:15.014629
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..compiler import compile_code
    code = "from foo.bar.baz import *"

    class MyRewrite(BaseImportRewrite):
        rewrites = [("foo.bar.baz", "foo.bar.biz")]

    target = CompilationTarget("Python", "Python", "Python", "Python", "Python", "Python", "Python")
    result = MyRewrite.transform(compile_code(code, target))

    assert result.tree.body[0].body[0].body[0].body[0].test.left.comparators[0].s.value == "foo.bar.baz"
    assert result.tree.body[0].body[0].body[0].body[0].test.comparators[0].value.s.value == "foo.bar.biz"
    assert result

# Generated at 2022-06-12 03:35:23.766181
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.snippet import code_to_ast

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PY34
        rewrites = [('foo', 'bar')]


# Generated at 2022-06-12 03:35:33.459546
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transformer import assert_node_equal

    initial_code = """from foo import bar, baz"""
    expected_code = """from foo import bar, baz"""
    expected_tree = ast.parse(expected_code)
    initial_tree = ast.parse(initial_code)
    # Rewrites are not specified
    BaseImportRewrite(initial_tree).visit(initial_tree)
    assert_node_equal(initial_tree, expected_tree)
    # Rewrites are specified but do not match
    BaseImportRewrite(initial_tree).rewrites = [('foo', 'quxquux')]
    BaseImportRewrite(initial_tree).visit(initial_tree)
    assert_node_equal(initial_tree, expected_tree)
    # Rewrites are specified and match

# Generated at 2022-06-12 03:35:44.424212
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    node_rewrite = ast.parse(
        """
from foo.rewrite import bar
from foo.rewrite import baz, abc
        """).body
    node = ast.parse(
        """
from foo.rewrite import bar
from foo.rewrite import baz, abc
        """).body

    from_, to = 'foo.rewrite', 'foo'
    rewrites = [(from_, to)]
    transformer = BaseImportRewrite(None, rewrites)
    node_changed = transformer.visit_ImportFrom(node[0])
    assert astor.to_source(node_rewrite[0]) == astor.to_source(node_changed)
    node_changed = transformer.visit_ImportFrom(node[1])

# Generated at 2022-06-12 03:35:51.589201
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [('re', 're2')]

    t = ast.parse("from re import *")
    t2 = Test.transform(t).tree

    assert isinstance(t2.body[0], ast.Try)
    assert t2.body[0].body[0].module == 're'
    assert t2.body[0].body[0].names[0].name == '*'
    assert t2.body[0].handlers[0].type.id == 'ImportError'
    assert t2.body[0].handlers[0].body[0].module == 're2'
    assert t2.body[0].handlers[0].body[0].names[0].name == '*'



# Generated at 2022-06-12 03:36:01.624497
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrite_class_code = 'import re\nimport math\n\n' + \
                         'from inspect import getframeinfo\n\n' + \
                         'print(math.factorial(100))\n' + \
                         'print(math.factorial(200))\n' + \
                         'print(re.sub("a", "b", "abracadabra"))\n'
    import_transform = BaseImportRewrite([('math', 'math2')])
    tree = ast.parse(rewrite_class_code)
    import_transform.transform(tree)

    assert ast.dump(tree) == '<code_object>'

# Generated at 2022-06-12 03:36:21.081825
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .grammar import parse

    test_case = '''
from foo.bar import (
    abc,
    ghi,
    pqr,
    xyz,
    _tuple
)

from def.ghi import xyz

from abc import foo

from abc import (
    bar,
    baz
)

from foo.bar import abc as qwe

from foo.bar.ghi import abc
    '''

    trans = BaseImportRewrite()
    trans.rewrites = [
        ('foo.bar', 'x.y.z'),
        ('abc.def', 'u.v.w'),
        ('foo.bar.ghi', 'x.y.z.ghi'),
    ]
    tree = parse(test_case)
    trans.transform(tree)



# Generated at 2022-06-12 03:36:31.301189
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = """
from foo import bar
from example.foo import baz
from example.foo.bar import test
from .foo import baz
"""
    tree = ast.parse(code)
    BaseImportRewrite.transform(tree)


# Generated at 2022-06-12 03:36:34.818564
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from code_monkey.transformers import BaseImportRewrite


# Generated at 2022-06-12 03:36:44.687380
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformers import BaseImportRewrite
    from typed_ast import ast3 as ast

    import_node_1 = ast.Import(names=[
        ast.alias(name='foo',
                  asname='bar')])
    import_node_2 = ast.Import(names=[
        ast.alias(name='foo.bar',
                  asname='bar')])
    import_node_3 = ast.Import(names=[
        ast.alias(name='foo.bar.baz',
                  asname='bar')])

    rewrite = BaseImportRewrite.transform(import_node_1)
    assert not rewrite.changed
    assert import_node_1 == rewrite.tree

    class TestTransform(BaseImportRewrite):
        rewrites = [('foo', 'rewrote')]


# Generated at 2022-06-12 03:36:54.114034
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class SomeTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]


# Generated at 2022-06-12 03:37:03.547009
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:37:12.920535
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import test_utils
    from ..schemes import base_scheme

    ast_import_from_1 = """
from urllib.parse import urlparse, urljoin
    """

    ast_import_from_1_after = """
try:
    from urllib.parse import urlparse, urljoin
except ImportError:
    from urllib.parse import urlparse, urljoin
    """

    import_rewrite_transformer = BaseImportRewrite(None)
    import_rewrite_transformer.rewrites = base_scheme.rewrites

# Generated at 2022-06-12 03:37:22.759404
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'hilbert'
    to = 'hilbertcurve'
    module = 'os.path'
    node_namespace = '{module}.{from_}.stuff'.format(module=module,
                                                     from_=from_)

    node = ast.ImportFrom(module=node_namespace,
                          names=[ast.alias(name='some_stuff')],
                          level=1)

    rewriter = BaseImportRewrite.__new__(BaseImportRewrite)
    rewriter.dependencies = ['hilbertcurve']
    rewriter.rewrites = [(from_, to)]
    rewriter._tree = node

    actual = rewriter.visit_ImportFrom(node)


# Generated at 2022-06-12 03:37:26.380644
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:37:30.620831
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse('import something').body[0]
    cls = type('Test', (BaseImportRewrite,), dict(rewrites=[('something', 'something_new')]))
    node = cls().visit(node)
    assert isinstance(node, ast.Try)
    assert len(node.body) == 1
    assert node.body[0].value.names[0].name == 'something_new'


# Generated at 2022-06-12 03:37:57.030708
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from io import StringIO
    import unittest

    import typed_ast.ast3 as ast
    from typed_ast.ast3 import parse # type: ignore

    from .typed_ast_ut import assertAstEqual

    class TestBaseImportRewrite(BaseImportRewrite):
        target = 'python34'
        rewrites = [('foo', 'bar')]

    class TestBaseImportRewriteTestCase(unittest.TestCase):
        def test_import(self):
            code = StringIO('''
import foo
import baz as baz

import foo.bar
from foo import bar

from baz import *
from foo import *
from foo.baz import baz
''')


# Generated at 2022-06-12 03:38:03.905094
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    result_expected = TransformationResult(
        ast.parse(
            '''
            try:
                from foo_bar.bar_foo import baz
            except ImportError:
                from baz.bar_foo import baz
            '''
        ),
        True,
        [],
    )
    result_actual = BaseImportRewrite.transform(
        ast.parse(
            '''
            from foo_bar import bar_foo
            
            bar_foo.baz
            '''
        ),
    )
    assert result_actual == result_expected
    
    

# Generated at 2022-06-12 03:38:13.805071
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('argparse', 'argparse3')]

    import argparse

    tree = ast.parse("""import argparse""")
    result = TestTransformer.transform(tree)
    assert result.transformations_count == 1
    assert result.result.body[0].value.names[0].name == "argparse3"
    assert set(result.dependencies) == {'argparse3'}

    tree = ast.parse("""import argparse.ArgumentParser""")
    result = TestTransformer.transform(tree)
    assert result.transformations_count == 1
    assert result.result.body[0].value.names[0].name == "argparse3.ArgumentParser"
    assert set(result.dependencies) == {'argparse3'}

# Generated at 2022-06-12 03:38:20.803076
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astor
    from pprint import pprint
    from .binder import Binder
    from .utils import compile_snippet
    from .rewrite import handle_import_rewrites

    source = '''
    from old_module import SomeClass
    from old_module.old_submodule import SubClass
    from old_module.old_submodule import OtherSubClass
    from old_module.old_submodule import *
    '''

    class MyRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    binder = Binder()
    binder.update_with_class(MyRewrite)

    tree = ast.parse(source)
    pprint(ast.dump(tree))

# Generated at 2022-06-12 03:38:29.028597
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import alias
    expected = ast.Try(body=[ast.Import(names=[alias(name='extra.path.module_a', asname='module_a')]),
                            ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                              name=None,
                                              body=[ast.Import(names=[alias(name='extra.module_a',
                                                                            asname='module_a')])])],
                       orelse=[],
                       finalbody=[])
    instance = BaseImportRewrite(ast.parse(''))

# Generated at 2022-06-12 03:38:38.285858
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # type: () -> None
    import typed_astunparse
    import re
    import sys

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'sixx')]
        if sys.version_info[0] == 2:
            rewrites.append(('builtins', '__builtin__'))
        else:
            rewrites.append(('backports.functools_lru_cache', 'functools.lru_cache'))

# Generated at 2022-06-12 03:38:46.523595
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_node_1 = ast.ImportFrom(module='foo.bar.baz', names=[ast.alias(name='baz', asname='spam')], level=1)
    import_node_2 = ast.ImportFrom(module='foo', names=[ast.alias(name='spam', asname='eggs')], level=1)
    import_node_3 = ast.ImportFrom(module='foo.other.thing', names=[ast.alias(name='spam', asname='eggs')], level=1)
    import_node_4 = ast.ImportFrom(module='foo.bar.other', names=[ast.alias(name='baz', asname='eggs')], level=1)