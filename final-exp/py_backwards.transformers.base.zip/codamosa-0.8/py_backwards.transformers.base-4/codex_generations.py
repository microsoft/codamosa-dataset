

# Generated at 2022-06-12 03:28:54.639356
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        target = 'py27'
        rewrites = [('user.models', 'django.contrib.auth.models')]

    node = ast.parse('import user.models')
    tree = TestTransformer.transform(node)
    assert tree.changed is True
    assert tree.dependencies == ['django.contrib.auth.models']



# Generated at 2022-06-12 03:29:05.365093
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast as pyast
    import inspect
    import textwrap

    import pytest
    from typed_ast.nodes import AST as PyTypedAST

    from py2ts import transforms
    from py2ts.utils.ast import parse_ast

    class ImportRewrite(transforms.BaseImportRewrite):
        rewrites = [
            ('os', 'os_test'),
        ]

    source = """
    import foo
    import bar
    import os
    """

    expected = """
    import foo
    import bar
    try:
        import os_test as os
    except ImportError:
        import os as os
    """

    before = parse_ast(source)
    after, changed, deps = ImportRewrite.transform(before)

    # Check AST before
    assert type(before) == PyTypedAST


# Generated at 2022-06-12 03:29:15.109485
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    compiler = BaseImportRewrite
    import_from_old = ast.ImportFrom(
        module="test.test2",
        names=[ast.alias(name="a")],
        level=2
    )
    import_from_new = ast.ImportFrom(
        module="test.test4",
        names=[ast.alias(name="a")],
        level=2
    )
    tree = ast.parse("import_rewrite(previous=import_from_old, current=import_from_new)")
    compiler.rewrites = [("test.test2", "test.test4")]
    inst = compiler(tree)
    inst.visit(tree)
    assert str(tree) == """try:
    import test.test2
except ImportError:
    import test.test4"""

# Generated at 2022-06-12 03:29:23.071611
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # class BaseImportRewrite rewrites imports with try/except
    import typed_ast.ast3
    from typed_ast.ast3 import *
    from typed_ast.ast3 import mod
    from .. import ast3 as typed_ast
    # in order to rewrite import from typed_ast.ast3 to typed_ast.ast3.types
    import_rewrite(
        previous=Import(names=[alias(name='typed_ast.ast3', asname=None)]),
        current=Import(names=[alias(name='typed_ast.ast3.types', asname='ast')]))

# Generated at 2022-06-12 03:29:32.763220
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('b', 'a'),
            ('c.b', 'c.a')
        ]

    def assert_import(tree, import_, as_=None, rewrite_import=False):
        class Imports(BaseImportRewrite):
            rewrites = [
                ('a', 'b'),
                ('c.a', 'c.b')
            ]

        t = Imports.transform(tree).tree  # type: ast.AST
        if rewrite_import:
            assert isinstance(t, ast.Try)
            assert isinstance(t.body[0], ast.Import)
            assert isinstance(t.body[1], ast.Import)
            assert t.body[0].names[0].name == import_

# Generated at 2022-06-12 03:29:41.199489
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    node = ast.parse('import previous').body[0]

    transformer = TestTransformer(None)
    result = transformer.visit_Import(node)

    assert transformer._tree_changed
    assert isinstance(result, ast.Try)
    assert result.body[0].value.names[0].name == 'current'
    assert result.handlers[0].type.id == 'ImportError'
    assert result.handlers[0].name is None
    assert result.handlers[0].body[0].value.names[0].name == 'previous'



# Generated at 2022-06-12 03:29:46.562628
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyTransformer(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib.request_orig'),
                    ('urllib', 'urllib2')]

    tree = ast.parse("import urllib.request")
    expected = "try:\n    import urllib.request_orig\nexcept ImportError:\n    import urllib2"
    result = MyTransformer.transform(tree).tree
    assert expected == ast.unparse(result)


# Generated at 2022-06-12 03:29:57.004522
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import os
    import sys
    from simpletransformers.language_utils.compile_transformer import CompileTransformer
    from simpletransformers.language_utils.transformers import BaseImportRewrite

    cur_dir = os.path.dirname(os.path.realpath(__file__))
    ct = CompileTransformer(
        transformer_class=BaseImportRewrite,
        transformer_dependencies=['masked_cnn'],
        target='python3')
    test_dir = os.path.join(cur_dir, 'test_data')
    ct.transform(os.path.join(test_dir, 'test_formatter.py'))
    sys.path.append(os.path.join(test_dir))

# Generated at 2022-06-12 03:30:04.899056
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    from .test_utils import wrap_tree

    class ExampleTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz.bar')]

    @wrap_tree
    def do(tree):  # pylint: disable=missing-docstring
        return ExampleTransformer.transform(tree)

    tree = ast.parse('''\
    import foo.bar
    baz = foo.bar.something()
    ''')
    do(tree)
    assert astunparse.unparse(tree) == '''\
    import foo.bar
    try:
        import foo.bar as bar
    except ImportError:
        import baz.bar as bar

    baz = foo.bar.something()
    '''


# Generated at 2022-06-12 03:30:15.280893
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast as _ast
    import copy as _copy
    import typing as _typing

    class TestTransformer(BaseImportRewrite):
        rewrites = [('t.1', 't.2')]

    def _make_import_stmt(name):
        return _ast.Import(names=[_ast.alias(name=name,
                                             asname=None)])

    def _make_import_from_stmt(module, name):
        return _ast.ImportFrom(module=module,
                               names=[_ast.alias(name=name,
                                                 asname=None)],
                               level=0)

    # alias
    res = TestTransformer._replace_import(_make_import_stmt('t.1.a'), 't.1', 't.2')

# Generated at 2022-06-12 03:30:38.434593
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Will replace "import a" with "try: import b"
    rewrite = BaseImportRewrite(ast.parse("import a"))
    rewrite.rewrites = [("a", "b")]
    assert rewrite.visit(ast.parse("import a")) == ast.parse("""
try:
    import b
except ImportError:
    import a
""")

    # Will replace "import a.b" with "try: import b.b"
    rewrite = BaseImportRewrite(ast.parse("import a.b"))
    rewrite.rewrites = [("a", "b")]
    assert rewrite.visit(ast.parse("import a.b")) == ast.parse("""
try:
    import b.b
except ImportError:
    import a.b
""")

    # Will replace "from a import b" with "from

# Generated at 2022-06-12 03:30:45.596030
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typed_ast.ast3
    class A(BaseImportRewrite):
        rewrites = [('six', 'typed_ast.six')]

    assert (typed_ast.ast3.parse('''
        try:
            import six
        except ImportError:
            import typed_ast.six as six
    ''').body == A.transform(
        typed_ast.ast3.parse('import six')
    ).tree.body)

    assert (typed_ast.ast3.parse('''
        import six
    ''').body == A.transform(
        typed_ast.ast3.parse('import six as sixsix')
    ).tree.body)


# Generated at 2022-06-12 03:30:56.656788
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [
        ('os', 'path'),
        ('os.path', 'pathlib.Path')]
    
    class Test(BaseImportRewrite):
        tree = None
        rewrites = rewrites


    test = Test(None)


# Generated at 2022-06-12 03:31:06.561022
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert BaseImportRewrite.transform(
        ast.parse("from operator import add, mul")).tree == \
        ast.parse("from operator import add, mul")

    assert BaseImportRewrite.transform(
        ast.parse("from operator import add as a, mul as m")).tree == \
        ast.parse("from operator import add as a, mul as m")

    assert BaseImportRewrite.transform(
        ast.parse("from operator import *")).tree == \
        ast.parse("from operator import *")

    assert BaseImportRewrite.transform(
        ast.parse("from os import path as a")).tree == \
        ast.parse("from os import path as a")

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('operator', 'operator3')]


# Generated at 2022-06-12 03:31:12.176766
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    my_import = ast.ImportFrom(module='six',
                               names=[ast.alias(name='string_types', 
                                                asname='string_types')])
    my_import_rewrite = BaseImportRewrite()
    my_import_rewrite.rewrites = [('six', 'six.moves')]
    my_import_rewrite.visit_ImportFrom(my_import)
    assert my_import.names[0].name == 'six.string_types'

# Generated at 2022-06-12 03:31:22.305273
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    rewrites = [
        ('foo', 'bar_foo')
    ]
    obj = BaseImportRewrite(None)
    node = ast.Import(names=[ast.alias(name='foo', asname='x')])
    obj.rewrites = rewrites

    # When
    new_node = obj.visit_Import(node)

    # Then
    assert isinstance(new_node, ast.Try)
    assert isinstance(new_node.body[0], ast.Import)
    assert new_node.body[0].names[0].name == 'bar_foo'
    assert new_node.body[0].names[0].asname == 'x'
    assert isinstance(new_node.handlers[0], ast.ExceptHandler)

# Generated at 2022-06-12 03:31:28.766539
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    from py2gcode.pycompiler import BaseImportRewrite
    class Test(BaseImportRewrite):
        rewrites = [("os.path", "pathlib")]

    tree = ast.parse("import os.path")
    Test().visit(tree)

    assert unparse(tree) == "try:\n    import os.path\nexcept ImportError:\n    import pathlib\n"


# Generated at 2022-06-12 03:31:39.571522
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("""
    import foo
    import baz
    """)

    new_tree = ast.parse("""
    try:
        import foo
    except ImportError:
        import bar as foo

    import baz
    """)

    target = ast.parse("""
    import baz
    """)

    assert Transformer.transform(tree).new_tree == target, \
        'BaseImportRewrite.visit_Import should return the same tree, ' \
        'when there is no module match'

    tree = ast.parse("""
    import foo
    """)


# Generated at 2022-06-12 03:31:48.966938
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import six
    import ast
    import sys
    if sys.version_info > (3, 5):
        # noinspection PyUnresolvedReferences
        import_stmt_1 = ast.parse('import datetime')
        # noinspection PyUnresolvedReferences
        import_stmt_2 = ast.parse('from httpserver import HTTPServer')
        # noinspection PyUnresolvedReferences
        import_stmt_3 = ast.parse('import unittest')
        # noinspection PyUnresolvedReferences
        import_stmt_4 = ast.parse('from urllib2 import urlopen')

# Generated at 2022-06-12 03:31:54.363176
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    node = ast.parse("import foo").body[0]
    rewrites = [("foo", "bar")]
    class TestClass(BaseImportRewrite):
        rewrites = rewrites

    tree = TestClass.transform(node).tree
    assert astor.to_source(tree).strip() ==  'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-12 03:32:14.033689
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    UNIT_TESTS_NODE_TRANSFORMER_TEST_VISIT_IMPORT_FROM: ast.ImportFrom = ast.parse('from core.exceptions import (ObjectNotFoundException,                                            ObjectTooBigException,                                            ObjectTooSmallException)')

# Generated at 2022-06-12 03:32:20.673898
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('abc', 'abc.def')]

    no_rewrite_node = ast.Import(names=[ast.alias(name='abc',
                                                 asname='abc')])
    rewrote_node = ast.Import(names=[ast.alias(name='abc.def',
                                            asname='abc')])
    rewrote = TestImportRewrite.transform(no_rewrite_node)
    assert rewrote.modified
    assert ast.dump(rewrote_node) == ast.dump(rewrote.tree)


# Generated at 2022-06-12 03:32:31.484107
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast

    # class BaseImportRewrite(BaseNodeTransformer):
    #     ...
    #     def _replace_import_from_module(self, node: ast.ImportFrom, from_: str, to: str) -> ast.Try:
        #         ...
        #         return import_rewrite.get_body(previous=node,  # type: ignore
        #                                        current=rewrote)[0]
        #     ...
        #     def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
        #         rewrite = self._get_matched_rewrite(node.module)
        #         if rewrite:
        #             return self._replace_import_from_module(node, *rewrite)
        # ...

# Generated at 2022-06-12 03:32:35.810715
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('django.conf', 'django.conf.base'),
        ]

    node = ast.parse('import django.conf.settings')
    transformed = Transformer.transform(node)

    assert transformed.tree == ast.parse('''
import django.conf.base.settings
try:
    import django.conf.settings
except ImportError:
    pass
''')



# Generated at 2022-06-12 03:32:42.702084
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Im(BaseImportRewrite):
        rewrites = [('a.b', 'a.c')]

    node = ast.ImportFrom(module='a.b.c', names=[ast.alias(name='d', asname='e')])

    new_node = Im.transform(node).tree

    assert isinstance(new_node, ast.Try)
    assert isinstance(new_node.body[0], ast.ImportFrom)
    assert new_node.body[0].module == 'a.c.c'
    assert new_node.body[0].names[0].name == 'd'
    assert new_node.body[0].names[0].asname == 'e'
    assert isinstance(new_node.finalbody[0], ast.ImportFrom)

# Generated at 2022-06-12 03:32:50.991174
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import save_and_run_for
    from . import builtin_types
    import inspect

    tree = ast.parse('import sys')
    assert save_and_run_for(builtin_types.BuiltinTypes.get_py2(ast.parse('')),
                            inspect.getsource(BaseImportRewrite))
    tree = BaseImportRewrite.transform(tree).tree

# Generated at 2022-06-12 03:33:00.193979
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from ..utils.tree import get_node

    tree = '''
    import time
    import time 
    '''
    main_tree = parse(tree)

    class Rewrite(BaseImportRewrite):
        rewrites = [('time', 'new_time')]

    new_tree = Rewrite.transform(main_tree).tree
    # Test that there are two nodes with Import
    actual = get_node(new_tree, (ast.Import, ast.Import))

# Generated at 2022-06-12 03:33:08.532506
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transform import transform

    class SomeTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    module = ast.parse('import foo; from foo import *; from foo import bar')
    transform(module, transformers=[SomeTransformer])

# Generated at 2022-06-12 03:33:17.231269
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast

    imp = ast.ImportFrom(module='six', level=0, names=[
        ast.alias(name='python_2_unicode_compatible', asname=None),
        ast.alias(name='PY3', asname=None),
    ])

    tree = ast.parse('''
from django.utils.six import string_types, python_2_unicode_compatible, PY3
''')

    tree.body[0] = imp

    from django_installer.transpilers.django_rest_framework import fix_django_1_8_2_imports
    fix_django_1_8_2_imports.rewrites = []
    fix_django_1_8_2_imports.dependencies = []


# Generated at 2022-06-12 03:33:26.072378
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Check normal imports
    import_from_valid_body = """
from urlparse import urlparse
from urlparse import urljoin
from urlparse import urlsplit
    """

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('urlparse', 'urllib.parse'),
        ]

    import_from_valid_body_transformed = """
from urllib.parse import urlparse
from urllib.parse import urljoin
from urllib.parse import urlsplit
    """
    assert ImportRewrite.transform(ast.parse(import_from_valid_body))[0] == import_from_valid_body_transformed

    # Check imports with 'as'
    import_from_valid_as_body = """
from urllib import parse as urlparse
    """


# Generated at 2022-06-12 03:33:46.651704
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typing import Any
    from ..utils.types_tree import is_leaf_type
    from ..utils.ast_helpers import parse_python

    class NewImportTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_3_6
        rewrites = [
            ('some.module', 'other.module')
        ]

    def assert_node(node: ast.AST, expected_node: ast.AST) -> None:
        node = parse_python(ast.dump(node))  # type: ignore
        ast.fix_missing_locations(node)
        expected_node = parse_python(ast.dump(expected_node))  # type: ignore
        ast.fix_missing_locations(expected_node)
        assert node == expected_node


# Generated at 2022-06-12 03:33:56.968298
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from typed_ast import ast3 as ast
    from ..utils import make_tree

    class TestBaseImportRewrite(BaseImportRewrite):
        target = 'python3.4'

    class TestModule(unittest.TestCase):

        def test_BaseImportRewrite_visit_ImportFrom(self):
            source = '''
            from six import with_metaclass
            '''
            rewrite_1 = ('six', 'future.moves')
            target_1 = '''
            try:
                from six import with_metaclass
            except ImportError:
                from future.moves.six import with_metaclass
            '''

            rewrite_2 = ('enum', 'future.utils')

# Generated at 2022-06-12 03:34:07.655487
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import sys
    import textwrap
    import unittest
    import typed_ast.ast3 as typed_ast
    from typed_ast.ast3 import Module, FunctionDef, Expr
    from typed_ast.ast3 import arguments, alias, parse, NodeTransformer
    from typed_ast.ast3 import ImportFrom, Import, Try, ExceptHandler
    from typed_ast.ast3 import AST

    class CustomImportRewrite(BaseImportRewrite):
        rewrites = [
            ('pysha3', 'hashlib'),
        ]

    class CustomImportRewrite2(BaseImportRewrite):
        rewrites = [
            ('pysha3.sha3_256', 'hashlib.sha3_256'),
        ]


# Generated at 2022-06-12 03:34:12.741077
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class TestTransformer(BaseImportRewrite):

        rewrites = (('typeguard', 'typing_extensions'),)

        def __init__(self, tree):
            super().__init__(tree)

    node = ast.parse("import math\nimport typing as t\nfrom typeguard import typechecked").body

    transformer = TestTransformer(node)
    transformer.visit_ImportFrom(node[2])



# Generated at 2022-06-12 03:34:22.628809
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    input_tree = ast.parse(textwrap.dedent("""
        from test.test_statistics import NormalDistTest, ParetoDistTest
        from test.test_statistics import uniform"""))

    import_rewrite = BaseImportRewrite().transform(input_tree)

    expected = ast.parse(textwrap.dedent(
        """
        try:
            from test.test_statistics import NormalDistTest, ParetoDistTest
        except ImportError:
            from test.test_statistics import NormalDistTest, ParetoDistTest
        try:
            from test.test_statistics import uniform
        except ImportError:
            from test.test_statistics import uniform
        """
    ))

    assert import_rewrite.tree.body == expected.body



# Generated at 2022-06-12 03:34:32.722556
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse_ast, dump_ast, dump_code
    from .imports import BaseImportRewrite
    from .exceptions import BaseExceptionTransformer
    from ..config import Config

    src = """
    from foo import baz
    from foo.bar import Baz
    from foo.bar.baz import Baz
    """

    tree = parse_ast(src)
    config = Config({'rewrites': [('foo.bar', 'foo.baz')],
                     'dependencies': []})
    BaseImportRewrite.transform(tree, config)
    BaseExceptionTransformer.transform(tree, config)

# Generated at 2022-06-12 03:34:39.090956
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class _Test(BaseImportRewrite):
        rewrites = [
            ('urllib', 'urllib.request'),
            ('six', 'six.moves'),
        ]
    test = ["import urllib",
            "import six",
            "import os",
            "import urllib.request as url",
            "import six.moves",
            ]
    for i, t in enumerate(test):
        t = ast.parse(t)
        t = _Test.transform(t)
        print(astor.to_source(t))
        assert_equal(i == 1 or i == 5, t.changed)



# Generated at 2022-06-12 03:34:47.667341
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor  # type: ignore
    from ..parse import parse_ast


# Generated at 2022-06-12 03:34:51.699548
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    
    class Transform(BaseImportRewrite):
        target = 'py2to3'
        rewrites = [('six', 'something_else')]

    source = 'import six'
    tree = parse(source)
    Transform.transform(tree)
    assert source != ast.dump(tree)



# Generated at 2022-06-12 03:34:57.358076
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from io import StringIO

    code = 'from io import StringIO'
    tree = ast.parse(code)

    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = [('io', 'io2')]

    result = MockBaseImportRewrite.transform(tree).tree
    assert code in ast.dump(result, include_attributes=False)

# Generated at 2022-06-12 03:35:29.152354
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import ast
    import six

    class MyTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
        ]

    tree = ast.parse("""
    import sys
    import six
    """)

    res = MyTransformer.transform(tree)
    tree = res.tree
    assert not res.tree_changed

    tree = ast.parse("""
    import sys
    import six
    """)

    res = MyTransformer.transform(tree)
    tree = res.tree
    assert res.tree_changed

# Generated at 2022-06-12 03:35:39.588809
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # type: () -> None
    tree = ast.parse("""
    from django.db import models
    from django.conf import settings
    from django.db import *
    from django import test
    import django.db.models as models_
    import django.conf
    from myapp.models import *
    from myapp import *
    from . import *
    from .. import *
    from .abc import *
    from . import abc
    from .abc import (x, y)
    from .abc import x, y
    from abc import (def, xyz)
    import abc
    """)


# Generated at 2022-06-12 03:35:42.614075
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ast_tools.visitors.imports import BaseImportRewrite
    import ast
    import doctest
    doctest.testmod(BaseImportRewrite)


# Generated at 2022-06-12 03:35:52.120615
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast;
    import typing;
    import typing as typing_0;
    import not_typing_0 as not_typing;
    from typing import List;
    from typing import List as List_0;
    from typing import List as List_1;
    from typing_extensions import List as List_2;
    from typing_extensions import List as List_3;
    from typing_extensions import List as List_4;
    from not_typing_extensions import List as List_5;
    from not_typing_extensions import List as List_6;
    from not_typing_extensions import List as List_7;
    from not_typing_extensions import List_8 as NotList;
    from not_typing_extensions import List_9 as NotList;

# Generated at 2022-06-12 03:36:02.114597
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from spaceone.core.transformer.handler.base_import_rewrite import BaseImportRewrite

    import_from = ast.parse("from spaceone.api.identity import keypairs, users, domains").body[0]
    import_from_rewrite = ast.parse("""from spaceone.api.identity.v1 import keypairs, users, domains""").body[0]
    import_from_rewrite_from = ast.parse("from spaceone.api.identity.v1 import keypairs").body[0]
    import_from_rewrite_as = ast.parse("from spaceone.api.identity import KeyPair as keypairs").body[0]

# Generated at 2022-06-12 03:36:13.094762
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .utils import parse_to_module
    from .utils import compare_trees

    module = parse_to_module(
        """
        from m1 import a, b, c
        from m1.d import e, f
        from m2 import g
        import m3
        import m4.h
        from m5 import i.j
        import m6.n
        """)

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('m1', 'm1_rewrite'),
            ('m3', 'm3_rewrite'),
            ('m5', 'm5_rewrite'),
        ]


# Generated at 2022-06-12 03:36:22.768338
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:36:30.785709
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class C(BaseImportRewrite):
        rewrites = [('old', 'new')]

    import_old = ast.Import(names=[ast.alias(name='old', asname='new')])
    import_new = ast.Import(names=[ast.alias(name='new', asname='new')])
    import_rewrite_snippet = import_rewrite.get_body(previous=import_old, current=import_new)[0]

    assert C.transform(import_old).ast == import_rewrite_snippet


# Generated at 2022-06-12 03:36:37.887542
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from xxx import yyy')
    class Transformer(BaseImportRewrite):
        rewrites = [('yyy', 'zz.yyy')]
        target = CompilationTarget.PYTHON_37

    result = Transformer.transform(tree)
    assert result.tree.body[0].finalbody == [ast.ImportFrom(module='zz',
                                                            names=[ast.alias(name='yyy',
                                                                             asname=None)],
                                                            level=0)]
    assert result.changed



# Generated at 2022-06-12 03:36:47.075353
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..base import base_import_rewrite
    class CustomImportRewrite(base_import_rewrite.BaseImportRewrite):
        rewrites = [('one', 'two')]
    class_import_from = ast.ImportFrom(module='one',
                                       names=[ast.alias(name='Foo',
                                                        asname=None)],
                                       level=0)
    result = CustomImportRewrite(None).visit_ImportFrom(class_import_from)
    assert isinstance(result, ast.Try)
    assert result.body[0].value.names[0].name == 'two.Foo'
    assert len(result.body) == 2
    # Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:37:36.958095
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('pytest', 'unittest')]
    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    ast_node = ast.parse('from pytest import skip')
    transformer = MockBaseImportRewrite(ast_node)
    assert transformer.visit(ast_node)

# Generated at 2022-06-12 03:37:46.327678
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse, Import, ImportFrom, Try
    from ..utils.visitor import get_one

    class TestTransformer(BaseImportRewrite):
        rewrites = [('collections', 'tuple_dict')]

    tree = parse('from collections import namedtuple')
    transformed_tree = TestTransformer.transform(tree)
    assert isinstance(transformed_tree.tree, Try)
    assert get_one(transformed_tree.tree, Import)
    assert get_one(transformed_tree.tree, ImportFrom)

    tree = parse('from collections import namedtuple, OrderedDict')
    transformed_tree = TestTransformer.transform(tree)
    assert isinstance(transformed_tree.tree, Try)
    assert get_one(transformed_tree.tree, Import)
   

# Generated at 2022-06-12 03:37:55.763241
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import numpy as np
    import torch

    class TestBaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [('torch_snippets', 'torch')]

    tree = TestBaseImportRewrite_visit_Import.transform(ast.parse('import torch_snippets.ops'))
    assert tree.code == 'import torch.ops'

    tree = TestBaseImportRewrite_visit_Import.transform(ast.parse('import torch_snippets as torch_snippets'))
    assert tree.code == 'import torch'

    tree = TestBaseImportRewrite_visit_Import.transform(ast.parse('import torch'))
    assert tree.code == 'import torch'


# Generated at 2022-06-12 03:38:00.813739
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class TestRewrite(BaseImportRewrite):
        rewrites = [('old_mod', 'new_mod')]

    tree = ast.parse('import old_mod')
    result = TestRewrite.transform(tree)
    assert astor.to_source(result.tree) == 'try:\n    import old_mod\nexcept ImportError:\n    import new_mod\n'



# Generated at 2022-06-12 03:38:10.311840
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [
            ('re', 're2'),
            ('abc', 'abc2')]

    import_node_1 = ast.parse('import re; import abc', mode='exec')
    import_node_2 = ast.parse('from abc import a', mode='exec')
    import_node_3 = ast.parse('from re import a', mode='exec')
    import_node_4 = ast.parse('from abc2 import a', mode='exec')
    import_node_5 = ast.parse('from re2 import a', mode='exec')


# Generated at 2022-06-12 03:38:19.063856
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    with override_import_transformer_rewrites():
        with override_import_transformer_dependencies():
            with override_node_transformer_tree_changed():
                import_transformer = BaseImportRewrite(None)
                import_transformer.rewrites = [('sys', 'six.moves')]
                import_transformer.dependencies = []

                tree = ast.parse('import sys')
                new_tree = import_transformer.visit(tree)


# Generated at 2022-06-12 03:38:26.982183
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
  import astor
  class TestClass(BaseImportRewrite):
    rewrites = [('six.moves', 'test_moves')]
    def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try] : return BaseImportRewrite.visit_ImportFrom(self, node)
  node = ast.parse(
    '''from six.moves import cStringIO\nimport six.moves.urllib''')
  expected_result = '''\
try:
    from six.moves import cStringIO
except ImportError:
    from test_moves import cStringIO

try:
    import six.moves.urllib
except ImportError:
    import test_moves.urllib'''
  inst = TestClass(node)
  inst

# Generated at 2022-06-12 03:38:36.187739
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old', 'new'),
            ('old1', 'new1'),
        ]

    code = """
from old.foo import foo
from old.bar import bar
from old import foo as old_foo
from old1.foo import foo as old1_foo
from old3.foo import foo as old3_foo
"""


# Generated at 2022-06-12 03:38:44.815230
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from ..parametrized_test import parametrized_test
    from ..utils.test_visitor import TestVisitor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'py2to3')]
