

# Generated at 2022-06-12 03:28:57.129085
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse(dedent('''
    import abc
    '''))
    rw = BaseImportRewrite.transform(tree)
    assert tree != rw.tree
    assert rw.tree_changed

    tree = ast.parse(dedent('''
    import abc
    import abc
    '''))
    rw = BaseImportRewrite.transform(tree)
    assert tree != rw.tree
    assert rw.tree_changed

    tree = ast.parse(dedent('''
    import abc as xyz
    import abc
    '''))
    rw = BaseImportRewrite.transform(tree)
    assert tree != rw.tree
    assert rw.tree_changed


# Generated at 2022-06-12 03:29:03.315272
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_module')]

    original = ast.parse('import six')
    transformed = TestTransformer.transform(original).tree
    assert astor.to_source(transformed) == """\
try:
    import six
except ImportError:
    import six_module as six
"""


# Generated at 2022-06-12 03:29:08.693294
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    tree = ast.parse("from os import path")
    DummyTransformer.transform(tree)
    assert ast.dump(tree) == "try:\n    from os.path import path\nexcept ImportError:\n    from os import path"

# Generated at 2022-06-12 03:29:18.812988
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
	from typed_ast import ast3 as ast
	from typed_ast.ast3 import Call, Name, Load, Str, Attribute, ImportFrom, alias, Num, List, Subscript, Index, BinOp, Arguments, arguments, Compare, Eq, Call, Attribute, Load, Name, Store, AugAssign, Add, Mod, Mult, Div, Sub, Gt, Lt, GtE, LtE, Is, IsNot, Del, Ellipsis, BoolOp, And, Or, keyword, BoolOp, Not, UnaryOp, Invert, UAdd, USub, NotImplemented, Starred, Pass, Break, Continue, Nonlocal, Return, Yield, YieldFrom, Assert, If, NameConstant, Print, For, While, TryExcept, TryFinally, Assign, Raise, Import, alias, Delete, Global, ImportFrom, Exec

# Generated at 2022-06-12 03:29:21.987427
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import parse

    class Test(BaseImportRewrite):
        rewrites = [('email.mime', 'email')]


# Generated at 2022-06-12 03:29:32.357388
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse('import urllib.request\n').body[0]
    node_str = ast.dump(node)
    cls = BaseImportRewrite
    cls.rewrites = [('urllib.request', 'urllib.rquest')]

    result = cls.visit_Import(cls, node)
    result_str = ast.dump(result)


# Generated at 2022-06-12 03:29:41.814109
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3

    import_from = ast.ImportFrom(module='os',
                                 names=[ast.alias(name='path'),
                                        ast.alias(name='stat')])
    rewriter = BaseImportRewrite(ast3)
    rewriter.rewrites.append(('os', 'posix'))

    imported_from = rewriter.visit_ImportFrom(import_from)

    assert isinstance(imported_from, ast.Try)
    assert imported_from.body
    assert imported_from.body[0] == \
        ast.ImportFrom(module='posix',
                       names=[ast.alias(name='path'),
                              ast.alias(name='stat')])
    assert imported_from.handlers[0].name == 'ImportError'

# Generated at 2022-06-12 03:29:47.265792
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    expected = ast.parse("import os; import re;")
    actual = ast.parse("import os; import re;")
    transformer = BaseImportRewrite(actual)
    transformer.visit(actual)
    # No change
    assert ast.dump(expected) == ast.dump(actual)
    # Import is rewrited
    actual = ast.parse("import os; import re;")
    transformer = BaseImportRewrite(actual)
    transformer.visit(actual)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-12 03:29:58.432750
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from typing import List

    from .pythran_helpers import transform

    class BaseImportRewrite(BaseNodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None

        def _replace_import(self, node: ast.Import, from_: str, to: str) -> ast.Try:
            """Replace import with try/except with old and new import."""
            self

# Generated at 2022-06-12 03:30:05.293345
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    import datetime
    from pprint import pprint
    from transformation.rewrites import BaseImportRewrite
    from test_transformation.snippets import import_rewrite

    class Test(BaseImportRewrite):
        def __init__(self):
            self.rewrites = [('datetime', 'dateutil.parser')]

        def _get_matched_rewrite(self, name):
            return BaseImportRewrite._get_matched_rewrite(self, name)

        def _replace_import(self, node, from_, to):
            return BaseImportRewrite._replace_import(self, node, from_, to)

    src = """
    import datetime
    
    def main():
        pass
    """


# Generated at 2022-06-12 03:30:26.871551
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tb = ast.Import(names=[ast.alias(name='test_BaseImportRewrite_visit_Import',
                                     asname=None)])
    tb.lineno = 1
    tb.col_offset = 8
    tb._fields = ('names',)
    tb._attributes = ('lineno', 'col_offset')

    class Test(BaseImportRewrite):
        rewrites = [('test_BaseImportRewrite_visit_Import', 'test_BaseImportRewrite')]

    result, _, _ = Test.transform(tb)

    t = ast.Import(names=[ast.alias(name='test_BaseImportRewrite',
                                    asname=None)])
    t.lineno = 1
    t.col_offset = 8
    t._fields = ('names',)
   

# Generated at 2022-06-12 03:30:36.949493
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    original_tree = ast.parse('''
from unittest import TestCase
from mocking.unittest import TestCase as MockedTestCase
from test import TestCase as OriginalTestCase
from test import (TestCase, 
                  TestCase as AliasedTestCase)
''')

    class TestBaseImportRewrite(BaseImportRewrite):
        target = CompilationTarget._2to3
        rewrites = [
            ('unittest', 'mocking.unittest')
        ]

    transformed_tree = TestBaseImportRewrite.transform(original_tree).transformed_tree

# Generated at 2022-06-12 03:30:44.964275
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from os import path
    from ..compiler import GenericTarget
    from ..compiler.python import Compiler

    test_dir = path.dirname(path.realpath(__file__))
    base_dir = path.join(test_dir, '../')


# Generated at 2022-06-12 03:30:56.104272
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import unittest
    from typing import List, Tuple, Union, Optional, Iterable, Dict

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'fuu'),
            ('bar', 'baa'),
            ('spam', 'spum')
        ]

    class TestBaseNodeTransformer(BaseNodeTransformer):
        pass

    class TestBaseTransformer(BaseTransformer):
        pass

    class TestBaseImportRewrite_visit_ImportFrom(unittest.TestCase):
        def test_rewrite_module_ok(self):
            """Test rewrite module."""
            import_from_node_from = ast.ImportFrom(module='spam', names=[ast.alias(name='spam', asname=None)], level=0)
           

# Generated at 2022-06-12 03:31:03.190525
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import Module, ImportFrom, alias
    import_from = ImportFrom(module='typed_ast.ast3',
                             names=[alias(name='AST'),
                                    alias(name='alias',
                                          asname='alias_as')],
                             level=0)
    stmt_list = [import_from]
    tree = Module(body=stmt_list)
    process_import_from = BaseImportRewrite([('typed_ast.ast3', 'typed_ast')])
    processed_tree = process_import_from.transform(tree)
    assert processed_tree.tree.body[0].names[0].name == 'AST'
    assert processed_tree.tree.body[0].names[0].asname == 'AST'

# Generated at 2022-06-12 03:31:08.723077
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module'),
        ]
    tree = ast.parse("import old_module")
    correct_tree = '''\
try:
    import old_module
except ImportError:
    import new_module
'''
    result = ImportRewrite.transform(tree)
    assert result.result.body[0] == ast.parse(correct_tree).body[0]


# Generated at 2022-06-12 03:31:16.598115
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import textwrap
    from ..utils.ast import parse_ast, dump_ast

    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = textwrap.dedent('''\
        import foo
        ''')
    tree = parse_ast(code)
    expected = textwrap.dedent('''\
        try:
            import foo
        except ImportError:
            import bar as foo
        ''')

    Transformer.transform(tree)
    assert dump_ast(tree) == expected

# Generated at 2022-06-12 03:31:24.516767
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget(sys.version_info[0])
        rewrites = [('test', 'newtest')]
    
    class BadImportClass:
        pass
    
    class GoodImportClass:
        pass
    
    tree = ast.parse('from __future__ import absolute_import\n'
                     'from test import BadImportClass\n'
                     'from test.foo import GoodImportClass\n')
    result = TestImportRewrite.transform(tree)
    assert result.tree.body[1].body[0].body[0].body[0].body
    assert result.tree.body[1].body[0].body[0].body[0].orelse

# Generated at 2022-06-12 03:31:35.184670
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import test_utils

    # Standard import
    module = ast.parse('''import os''')
    updated = test_utils.transform_and_assert(
        module, [BaseImportRewrite],
        '''import os''', '''import os''')
    assert not updated

    # Import with rewrite
    module = ast.parse('''import tornado.ioloop''')
    updated = test_utils.transform_and_assert(
        module, [BaseImportRewrite],
        '''import tornado.ioloop''',
        '''try:
    import tornado.ioloop
except ImportError:
    import uvloop.ioloop''')
    assert updated

    # Import with rewrite and alias
    module = ast.parse('''import tornado.ioloop as tio''')
    updated = test_utils.transform_

# Generated at 2022-06-12 03:31:45.302836
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformers.base import BaseImportRewrite
    from ..transformers.base import BaseNodeTransformer
    from unittest import TestCase

    class Transformer(BaseNodeTransformer):
        rewrites = [('requests', 'collections.requests')]

        def __init__(self, tree):
            super().__init__(tree)

    class TestCase(TestCase):
        def setUp(self):
            from asttokens import ASTTokens
            self.tree = ASTTokens('''
            import requests
            import threading
            def test():
                global requests
            ''').tree

        def test(self):
            transformer = Transformer(self.tree)
            transformer.visit(self.tree)
            self.assertIsInstance(self.tree.body[0], ast.Try)

    Test

# Generated at 2022-06-12 03:32:04.965851
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import ImportFrom, alias
    from typed_ast.ast3 import Import, Try, ExceptHandler, Name, Store
    from typed_ast.ast3 import Assign, Call

    class MyTransform(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo2'),
            ('bar', 'bar2'),
            ('foo.bar', 'foo.bar2'),
        ]

    tree = parse('''
    from foo.bar import baz
    from bar import qux
    import foo
    import foo.bar.foo
    import foo.bar
    import foo.bar.foo as f
    ''')

    replace = ImportFrom(module='foo.bar',
                         names=[alias(name='baz', asname=None)])
   

# Generated at 2022-06-12 03:32:14.244244
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    
    from ..tests.test_utils import get_ast_from_snippet
    from ..utils import ast_helpers as ah

    tr = BaseImportRewrite({})
    ast_tree = get_ast_from_snippet('', 'import os')
    tr.visit(ast_tree)
    assert ah.ast2str(ast_tree) == 'import os'
    
    tr = BaseImportRewrite({'rewrites': [('os', 'six.moves')]})
    ast_tree = get_ast_from_snippet('', 'import os')
    tr.visit(ast_tree)
    assert ah.ast2str(ast_tree) == ("""
try:
    import os
except ImportError:
    import six.moves as os
    """.strip())

    # Unit test

# Generated at 2022-06-12 03:32:19.416499
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...utils import check_source
    
    class MyBaseImportRewrite(BaseImportRewrite):
        rewrites = [('_base_rewrite_module1', '_base_rewrite_module2')]

    class MyBaseImportRewrite2(BaseImportRewrite):
        rewrites = [('_base_rewrite_module2', '_base_rewrite_module3')]
    

# Generated at 2022-06-12 03:32:25.215601
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    from ..utils.compilation import get_ast


# Generated at 2022-06-12 03:32:35.856302
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ConcreteTransformer(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]

    imp = ast.Import(names=[ast.alias(name='a.b',
                                      asname='e')])
    tree = ConcreteTransformer.transform(imp).node

    try_stmt = tree
    assert isinstance(try_stmt, ast.Try)

    try_block = try_stmt.body[0]
    assert isinstance(try_block, ast.Expr)

    try_expr = try_block.value
    assert isinstance(try_expr, ast.Call)

    call_func = try_expr.func
    assert isinstance(call_func, ast.Name)
    assert call_func.id == 'extend'


# Generated at 2022-06-12 03:32:45.639615
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import _ast
    node = _ast.ImportFrom(module='click', 
                           names=[
                               _ast.alias(name='command', asname='command'),
                               _ast.alias(name='option', asname='option'),
                               _ast.alias(name='echo', asname='echo')
                           ],
                           level=0)
    assert str(node) == 'from click import command as command, option as option, echo as echo'
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('click', 'typed_astunparse')
        ]
    new_node = Rewrite.transform(node).tree
    print(new_node)

# Generated at 2022-06-12 03:32:53.308900
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # Test rewrite only module
    node = ast.parse("from six import iteritems").body[0]
    rewrites = [('six', 'past.six')]
    tree_changed = BaseImportRewrite(node, rewrites).visit_ImportFrom(node)
    assert repr(tree_changed) == 'Try(body=[ImportFrom(module="past.six", names=[alias(name="iteritems", asname=None)], level=0)], handlers=[ExceptHandler(type=Name(id="ImportError", ctx=Load()), name=None, body=[ImportFrom(module="six", names=[alias(name="iteritems", asname=None)], level=0)])], orelse=[], finalbody=[])'

    # Test rewrite module and name

# Generated at 2022-06-12 03:32:58.880445
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse(
"""\
import os
import sys
""")

    class TestTransformation(BaseImportRewrite):
        rewrites = [('os', 'shutil')]

    result = TestTransformation.transform(tree)
    assert result.new_tree == ast.parse(
"""\
import os
try:
    import os as os
except ImportError:
    import shutil as os

import sys
""")



# Generated at 2022-06-12 03:33:07.654395
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_import = ast.ImportFrom(module='some_module.some_submodule',
                                 names=[ast.alias(name='some_name',
                                                  asname='as_name'),
                                        ast.alias(name='some_name_2',
                                                  asname='as_name_2'),
                                        ast.alias(name='some_name_3',
                                                  asname='as_name_3')],
                                 level=None)


# Generated at 2022-06-12 03:33:14.296845
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .collectors import CollectInfoVisitor
    from .parsers import parse

    source = """
    from module import a, b as c
    from module1 import d as e
    """
    tree = parse(source)

    cls = type('', (BaseImportRewrite,), {'rewrites': [('module', 'rewrite_module')]})
    collector = CollectInfoVisitor(tree)
    cls.transform(tree)
    collector.visit(tree)

    assert collector.imports == {'e': 'module1.d', 'c': 'module.b', 'a': 'module.a'}

# Generated at 2022-06-12 03:33:39.070632
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

# Generated at 2022-06-12 03:33:49.214827
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import six
    import ast as std_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    source = '''
import six

alias = six.moves.zip
'''
    expected_source = '''
try:
    from six import zip
except ImportError:
    from six.moves import zip
alias = zip
'''

    module = std_ast.parse(source)
    new_module, changed, _ = TestTransformer.transform(module)
    # print("\n".join([line for line in std_ast.dump(new_module, include_attributes=True).split("\n") if line.strip()]))
    assert std_ast.dump(new_module, include_attributes=True) == expected_source
   

# Generated at 2022-06-12 03:33:59.569300
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import inspect
    import sys

    class DaftImportVisitor(ast.NodeVisitor):
        def __init__(self):
            self.work = ast.parse(inspect.getsource(sys.modules[__name__]))
            self.import_from = None

        def visit_ImportFrom(self, node):
            self.import_from = node

    visitor = DaftImportVisitor()
    visitor.visit(visitor.work)
    assert visitor.import_from is not None

    import_from = visitor.import_from
    assert import_from.module == 'typing'

    class ConcreteImportRewrite(BaseImportRewrite):
        rewrites = [('typing', 'types')]

    visitor = ConcreteImportRewrite(ast.parse('from typing import List'))
    visitor

# Generated at 2022-06-12 03:34:10.110767
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = '''
import module1
from module1 import function1, function2
'''

    class T(BaseImportRewrite):
        rewrites = [
            ('module1', 'module2'),
        ]

    node = ast.parse(code)
    T.transform(node)

# Generated at 2022-06-12 03:34:19.134709
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from python_modernize.visitors.imports import BaseImportRewrite
    from typed_ast import ast3 as ast
    import_from = ast.parse('''
from foo.bar import foo, bar as baz
import foo.bar.baz
''')

    # Module rewrite to module rewrite (import from)
    transformer = BaseImportRewrite(import_from)
    transformer.rewrites = [('foo.bar', 'foo.baz')]


# Generated at 2022-06-12 03:34:26.633130
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.python_version import python_version

    with python_version(3, 5):
        from ..utils.ast_factory import ast_factory

        class MockImportFromRewrite(BaseImportRewrite):
            rewrites = [('a', 'b')]

        node = ast_factory('from a import b', module='__main__')
        result = MockImportFromRewrite.transform(node)

        assert isinstance(result.tree, ast.Try)
        assert isinstance(result.tree.body[0], ast.ImportFrom)



# Generated at 2022-06-12 03:34:35.694679
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from unittest.mock import patch
    import unittest

    class TestNode(BaseImportRewrite):
        rewrites = [('six', 'six1'), ('six.moves', 'six.moves1')]

    tree = ast.parse("from six.moves import __import__ as imp; "
                     "from six.moves import *; "
                     "from six import *; "
                     "import six.moves")

    with patch('typed_astunparse.unparse', return_value="") as unpatch:
        TestNode.transform(tree)

# Generated at 2022-06-12 03:34:44.221350
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import smth.inner
    import smth.inner as inner
    import smth.inner.inner
    import smth.inner.inner as inner2
    from smth import inner_2
    from smth import inner_3 as inner3
    from smth.inner_4 import inner4
    from smth.inner_5 import inner5 as inner5

    from smth_rewrote.inner import inner_rewrote
    from smth_rewrote.inner import inner_rewrote as inner_rewrote
    from smth_rewrote.inner.inner import inner_rewrote
    from smth_rewrote.inner_2 import inner_2_rewrote
    from smth_rewrote.inner_3 import inner_3_rewrote as inner_3_rewrote
    from smth_rewrote.inner_4 import inner_4_rew

# Generated at 2022-06-12 03:34:51.736812
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('module_from', 'module_to')]

    tree = ast.parse("""from module_from import name, name2 as name2_alias""")
    result = TestImportRewrite.transform(tree)

    # check result
    assert result.changed is True
    assert result.dependencies == ['module_from', 'module_to']

    expected = ast.parse("""try:
    from module_from import name, name2 as name2_alias
except ImportError:
    from module_to import name, name2 as name2_alias""")
    assert ast.dump(expected) == ast.dump(result.tree)



# Generated at 2022-06-12 03:34:57.406357
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:35:50.211509
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestClass(BaseImportRewrite):
        rewrites = [('foo', 'foo.bar'), ('bar', 'baz.qux')]

    tree = ast.parse(
        'from foo import x as y, * as z\n'
        'from foo.bar import x as y, * as z\n'
        'from foo.bar.baz import x as y, * as z\n'
        'from bar import x as y, * as z\n'
        'from bar.baz import x as y, * as z\n'
        'from bar.baz.qux import x as y, * as z\n'
        'from baz import x as y, * as z'
    )

    result = TestClass.transform(tree)


# Generated at 2022-06-12 03:35:58.122434
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node1 = ast.ImportFrom(module="os",
                           names=[ast.alias(name="path",
                                            asname=None)],
                           level=0)

    rewrite = BaseImportRewrite(None)
    node2 = ast.ImportFrom(module="os.path",
                           names=[ast.alias(name="path",
                                            asname=None)],
                           level=0)

    assert astor.to_source(rewrite._replace_import_from_names(node1, {"os.path": ("os", "os")})) == astor.to_source(
        node2)

# Generated at 2022-06-12 03:36:08.525337
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    # Test if module name is replaced correctly
    node = ast.parse('''
        from six import with_metaclass
    ''')
    name = 'six'
    rewrites = [(name, name + 'x')]
    expected = ast.parse('''
        try:
            from six import with_metaclass
        except ImportError:
            from sixx import with_metaclass
    ''')
    assert isinstance(node.body[0], ast.ImportFrom)

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    transformed = TestTransformer.transform(node).tree
    assert astor.to_source(transformed.body[0]) == astor.to_source(expected.body[0])

    # Test if only name is replaced correctly

# Generated at 2022-06-12 03:36:09.146306
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass

# Generated at 2022-06-12 03:36:19.950478
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from . import transformers

    class TestRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

        target = CompilationTarget('tests.transformers.test_import_rewrite.test_1', 'test_1.py')
        dependencies = ['six', 'six.moves']

    class TestRewrite2(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

        target = CompilationTarget('tests.transformers.test_import_rewrite.test_2', 'test_2.py')
        dependencies = ['six']

    class TestRewrite3(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]


# Generated at 2022-06-12 03:36:26.346964
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast as pyast

    class TestTransformer(BaseImportRewrite):
        rewrites = [("ids", "ident")]

    # no rewriting
    tree = pyast.parse('import foo')
    result = TestTransformer.transform(tree)
    assert result.tree == tree
    assert result.changed == False

    # rewriting
    tree = pyast.parse('import ids.john')
    assert TestTransformer.transform(tree).changed  # type: ignore
    assert TestTransformer.transform(tree).tree == pyast.parse("""
        try:
          from ids import john as john
        except ImportError:
          from ident import john as john
        """)

    # aliasing
    tree = pyast.parse('import ids.john as another')
    assert TestTransformer.transform(tree).changed  #

# Generated at 2022-06-12 03:36:36.788847
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = []

    import astunparse

    code = 'from module.submodule import name\nfrom module.submodule import *\nfrom module import name'
    tree = ast.parse(code)
    Transformer().visit(tree)
    assert astunparse.unparse(tree).strip() == code

    Transformer.rewrites = [('module', 'new_module')]
    tree = ast.parse(code)
    Transformer().visit(tree)

# Generated at 2022-06-12 03:36:46.326365
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import unittest.mock as mock

    with mock.patch('astroid.builder.MANAGER') as mock_builder:
        mock_builder.ast_from_module_name.return_value = ast.parse('pass')

        import asttokens  # noqa: F401
        from astor import codegen

        from ..transformations.import_rewrite import BaseImportRewrite

        class MockTransformer(BaseImportRewrite):
            rewrites = [
                ('astroid.builder', 'asttokens.builder')
            ]
            dependencies = []

        tree = ast.parse('from astroid.builder import extract_node')
        MockTransformer.transform(tree)

        res = codegen.to_source(tree)

# Generated at 2022-06-12 03:36:52.402173
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('django.views', 'rest_framework.views')]

    tree = ast.parse('import django.views.generic.edit as views')
    tree = Transformer.transform(tree)
    assert tree.get_node_value() == """
try:
    import django.views.generic.edit as views
except ImportError:
    from rest_framework import views
    """



# Generated at 2022-06-12 03:36:58.327281
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six')
    tree = TestTransformer.transform(tree).tree

    assert 'ImportError' in ast.dump(tree, include_attributes=False)

    tree = ast.parse('import six.moves')
    tree = TestTransformer.transform(tree).tree

    assert 'import six.moves' in ast.dump(tree, include_attributes=False)


# Generated at 2022-06-12 03:38:30.549600
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Case 1: import ast import rewrite
    import ast3 as ast
    import typed_ast.ast3 as typed_ast
    class TestClass(ast.NodeVisitor):
        def __init__(self):
            self.data = []
        def visit_Module(self, node):
            self.data.append(node)
        def result(self):
            return self.data
    source_code = 'import ast3\n'
    # source_code = 'import ast3 as ast\n'
    node = ast.parse(source_code)
    class MockClass(BaseImportRewrite):
        rewrites = [('ast3', 'typed_ast.ast3')]
    MockClass().visit(node)
    tc = TestClass()
    tc.visit(node)

# Generated at 2022-06-12 03:38:39.983081
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class _TestImportRewrite(BaseImportRewrite):
        rewrites = [('django.utils.http', 'django.http')]

    tree = ast.parse('from django.utils.http import urlencode, quote')
    _TestImportRewrite.transform(tree)

    def is_try_node(node):
        return isinstance(node, ast.Try)

    try_node = tree.body[0]
    assert is_try_node(try_node)
    assert len(try_node.body) == 2
    assert len(try_node.handlers) == 1

    except_node = try_node.handlers[0]
    assert isinstance(except_node, ast.ExceptHandler)
    assert isinstance(except_node.type, ast.Name)

# Generated at 2022-06-12 03:38:47.680672
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.testhelper import assert_equal_code

    class TestTranformer(BaseImportRewrite):
        rewrites = [('_io', 'io')]

    tree = ast.parse('from _io import BytesIO')
    assert_equal_code(
        tree,
        TestTranformer.transform(tree).tree,
        """
        try:
            from _io import BytesIO
        except ImportError:
            from io import BytesIO
        """
    )
    assert_equal_code(
        tree,
        TestTranformer.transform(tree).tree,
        """
        try:
            from _io import BytesIO
        except ImportError:
            from io import BytesIO
        """
    )
    tree = ast.parse('from _io import *')
    assert_equal