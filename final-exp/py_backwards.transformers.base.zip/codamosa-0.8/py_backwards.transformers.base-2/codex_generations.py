

# Generated at 2022-06-12 03:28:59.561086
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class RewriteTransformer(BaseImportRewrite):
        target = "3.3"
        rewrites = [
            ('unittest.mock', 'mock'),
        ]

    input = ast.parse("from unittest.mock import Mock")
    actual = RewriteTransformer.transform(input)
    expected_output = ast.parse("""
try:
    from unittest.mock import Mock
except ImportError:
    from mock import Mock
""")
    expected_output = ast.fix_missing_locations(expected_output)
    assert ast.dump(actual.tree, include_attributes=True) == ast.dump(expected_output, include_attributes=True)
    assert actual.changed is True



# Generated at 2022-06-12 03:29:08.025681
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    @snippet
    def test_snippet():
        import os

        def test():
            pass

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'test_os')]

    tree = ast.parse(test_snippet.get_source())

    TestImportRewrite.transform(tree)

    assert ast.dump(tree) == dedent('''
        import os as test_os
        try:
            import os
        except ImportError:
            import test_os
        def test():
            pass
    ''').strip()



# Generated at 2022-06-12 03:29:12.843912
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astroid
    from astroid import extract_node

    rewrites = [
        ('django.utils.timezone', 'pytz')]
    tree = astroid.parse('''
    from django.utils import timezone
    from django.utils import timezone as pytz
    from django.utils.timezone import utc
    from django.utils.timezone import utc as UTC''')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    result = TestImportRewrite.transform(tree)


# Generated at 2022-06-12 03:29:21.860082
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # input
    node_alias = ast.alias(name='os.path', asname='path')
    node = ast.Import(names=[node_alias])

    # output
    node_rewritten_alias = ast.alias(name='importlib.machinery.SourceFileLoader(\'path\', \'os/path.py\').load_module()', asname='path')
    node_rewritten = ast.Import(names=[node_rewritten_alias])

    # test
    print("TEST BASE IMPORT REWRITE")
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('os.path', 'importlib.machinery.SourceFileLoader(\'path\', \'os/path.py\')')]
    output = TestBaseImportRewrite.visit_Import(node)

# Generated at 2022-06-12 03:29:32.242599
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.snippet import doctest_snippets

# Generated at 2022-06-12 03:29:41.672584
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from unittest import TestCase, mock
    from ..target.python import Python

    class Cls(BaseImportRewrite):
        target = Python
        rewrites = [('os', 'pathlib')]

    class A(TestCase):
        def run_rewrite(self, code: str, expected: str) -> None:
            tree = ast.parse(code)
            with mock.patch('typed_ast.ast3.NodeTransformer.generic_visit',
                            return_value=tree):
                new_tree = Cls.transform(tree).tree
                self.assertEqual(expected, ast.dump(new_tree))


# Generated at 2022-06-12 03:29:47.673265
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    tree = ast.parse('from test import test2')
    visitor = BaseImportRewrite(tree)
    node = tree.body[0]
    res = visitor.visit_Import(node)

    assert isinstance(res, ast.Try)
    assert astunparse.unparse(res).strip() == """
try:
    from test import test2
except ImportError:
    from test import test2
    """.strip()

    import sys; sys.modules['test.test2'] = None
    assert isinstance(ast.dump(res).strip(), str)



# Generated at 2022-06-12 03:29:58.852418
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewriteClass(BaseImportRewrite):
        rewrites = [('thread', '_thread')]

    module = ast.parse('import thread, thread1, thread2.foo\n'
                       'from thread import foo, bar, baz\n'
                       'from thread1 import foo, bar, baz\n'
                       'from thread2 import foo, bar, baz\n')

    expected = ast.parse('try:\n    import thread, thread1, thread2.foo\n'
                         '    from thread import foo, bar, baz\n'
                         'except ImportError:\n'
                         '    import _thread, thread1, thread2.foo\n'
                         '    from _thread import foo, bar, baz\n')

    ImportRewriteClass.transform(module)
    assert module == expected

# Generated at 2022-06-12 03:30:08.508414
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_statement = dedent(
        '''\
        from module1.module2 import mod1, mod2
        ''')
    import_from_tree = ast.parse(import_from_statement)
    import_from_node = import_from_tree.body[0]
    assert isinstance(import_from_node, ast.ImportFrom)

    class ImportRewriter(BaseImportRewrite):
        rewrites = [('module1.module2', 'module3.module4')]

    result = ImportRewriter.transform(import_from_tree)
    assert result.changed is True
    assert 'module1.module2' not in import_from_statement
    assert 'module3.module4' in import_from_statement

    try_statement = result.tree.body[0]

# Generated at 2022-06-12 03:30:18.715033
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import foo')
    result = BaseImportRewrite.transform(tree)
    assert not result.changed
    assert ast.dump(tree) == ast.dump(result.tree)

    result = BaseImportRewrite.transform(ast.parse('import foo.bar.baz'))
    assert not result.changed
    assert ast.dump(tree) == ast.dump(result.tree)

    tree = ast.parse('import foo.bar')
    result = BaseImportRewrite.transform(tree)
    assert not result.changed
    assert ast.dump(tree) == ast.dump(result.tree)

    class Test(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'foo.bar.baz')]

    tree = ast.parse('import foo.bar')
    result = Test

# Generated at 2022-06-12 03:30:37.397602
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'a.b.c.moves'),
            ('future.builtins', 'b.future.builtins')
        ]

    source = """
    import six.moves
    import b.future.builtins
    
    """
    tree = ast.parse(source)

    tree_changed, tree_new = TestTransformer.transform(tree)
    assert tree_changed
    assert ast.dump(tree_new) == """
    import six.moves
    except ImportError:
        import a.b.c.moves as moves
    
    
    import b.future.builtins
    
    """



# Generated at 2022-06-12 03:30:42.587689
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('ipdb', 'pdb')]

    code = """
import ipdb
"""
    expected_code = """
try:
    import ipdb
except ImportError:
    import pdb as ipdb
"""

    tree = ast.parse(code)
    TestImportRewrite.transform(tree)
    assert ast.dump(tree) == expected_code



# Generated at 2022-06-12 03:30:53.186052
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom(): # type: ignore[name]
    from ..target.python36 import Python36Target
    import_from = ast.ImportFrom(module='module', names=[ast.alias(name='name')], level=0)
    expected = ast.Try(handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                                   name=None,
                                                   body=[ast.ImportFrom(module='new_module',
                                                                        names=[ast.alias(name='name')],
                                                                        level=0)])],
                       body=[import_from],
                       orelse=[],
                       finalbody=[])
    class TestTransformer(BaseImportRewrite):
        class Meta:
            target = Python36Target
            rewrites = [('module', 'new_module')]  # type

# Generated at 2022-06-12 03:31:01.855184
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    sys.path.append(".")
    from typepy import class_factory, ast_utils
    from worker.transformer import base

    transformer_class = class_factory("BaseImportRewrite",
                                      (base.BaseImportRewrite,),
                                      {"rewrites" : [("re", "re3")]})
    test_class_code = """
from re import compile
from re import findall
from re import search
"""
    test_class_ast = ast.parse(test_class_code)
    transformer_class.transform(test_class_ast)

# Generated at 2022-06-12 03:31:09.746284
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('a', 'b'), ('c', 'd')]
    import_from = ast.ImportFrom(module='a.b',
                                 names=[ast.alias(name='c', asname='c1')],
                                 level=0)

    class Transformer(BaseImportRewrite):
        rewrites = rewrites

    rewritten = Transformer.transform(import_from)

    new_import_from = rewritten.tree.body[1].body[1].orelse[0]
    assert isinstance(new_import_from, ast.ImportFrom)

    assert new_import_from.module == 'b.b'
    assert new_import_from.names[0].name == 'c'
    assert new_import_from.names[0].asname == 'c1'
    assert new_import

# Generated at 2022-06-12 03:31:13.840715
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.typed_ast_v2 import parse

    class ImportTest(BaseImportRewrite):
        rewrites = [('contextlib', 'contextlib2')]

    result = ImportTest.transform(parse('import contextlib'))
    assert result.tree
    assert ImportTest.dependencies



# Generated at 2022-06-12 03:31:23.375987
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testing import assert_transformed_code_equal

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'sixer')]

    assert_transformed_code_equal(
        ImportRewrite,
        'import backports\n',
        'import backports\n'
    )

    assert_transformed_code_equal(
        ImportRewrite,
        'import six\n',
        'try:\n    import sixer\n'
        'except ImportError:\n    import six\n'
    )

    assert_transformed_code_equal(
        ImportRewrite,
        'import six.moves\n',
        'try:\n    import sixer.moves\n'
        'except ImportError:\n    import six.moves\n'
    )

# Generated at 2022-06-12 03:31:33.905064
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import os
    import ast
    import inspect
    import uuid

    import retype.transformers

    l = []

    def visitor(node):
        l.append(node)

    tree = ast.parse("import retype.transformers")
    for cls in BaseImportRewrite.__subclasses__():
        if cls.target is None:
            continue

        if cls.target != os.environ.get('PYTHONVERSION'):
            continue

        if not 'support' in inspect.getfile(cls):
            continue

        inst = cls(tree)
        inst.visit(tree)
        print(cls)
        for i in l:
            print(i)
        # print(l[0])
        # print(l[1])
        id1 = uuid.uuid4

# Generated at 2022-06-12 03:31:42.906512
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo_bar', 'foo.bar')]

    test_case = ast.parse('import foo_bar', mode='exec')
    transformer = TestTransformer(test_case)

    test_case = transformer.visit(test_case)
    print(ast.dump(test_case, include_attributes=False))
    print()

    test_case = ast.parse('import foo_bar.baz', mode='exec')
    transformer = TestTransformer(test_case)
    test_case = transformer.visit(test_case)
    print(ast.dump(test_case, include_attributes=False))



# Generated at 2022-06-12 03:31:52.234741
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast
    import _ast_unparse_typed_ast
    from typed_ast.ast3 import parse

    class ImportTransformer(BaseImportRewrite):
        rewrites = [
            ('buildins', 'builtins')
        ]

    tree = parse('""\nimport buildins\nimport buildins.__abs__\nimport unittest')
    assert str(tree) == '""\nimport buildins\nimport buildins.__abs__\nimport unittest'
    assert type(tree) == typed_ast.ast3.Module

    tree, changed, _ = ImportTransformer.transform(tree)
    assert changed
    assert type(tree) == typed_ast.ast3.Module

# Generated at 2022-06-12 03:32:08.093131
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    # Expected result
    class Expected(ast.AST):
        _fields = ('body',)

        def __init__(self, body):
            self.body = body
    try_ = Expected(body=ast.Try(body=[ast.Import(names=[ast.alias(name='foo', asname=None)])], 
                                handlers=[ast.ExceptHandler(type=None, name=None, body=[
                                ast.Import(names=[ast.alias(name='foo2', asname=None)])])], 
                                finalbody=[]))
    res = astor.to_source(try_)
    
    # Given node
    class Given(ast.AST):
        _fields = ('names',)

        def __init__(self, names):
            self.names = names
   

# Generated at 2022-06-12 03:32:17.037022
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse(textwrap.dedent('''\
        from datetime import date, tzinfo, time 
        from datetime import timezone
        from io import (
            FileIO,
            BytesIO
        )
        '''))

    trans = BaseImportRewrite()
    trans.rewrites = [('datetime', 'dateutil')]
    trans.visit(tree)
    assert ast.dump(tree) == textwrap.dedent('''\
        try:
            from datetime import date, tzinfo, time
        except ImportError:
            from dateutil import date, tzinfo, time

        from dateutil import timezone
        from io import (
            FileIO,
            BytesIO
        )
        ''')


# Generated at 2022-06-12 03:32:24.020163
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .transformer_test_tools import expected, get_node_changed

    from typed_ast.ast3 import parse

    tree = parse(
        'from sys import exc_info\n'
        'import types\n'
        'import os.path\n')

    class transformer(BaseImportRewrite):
        rewrites = [
            ('os.path', 'pathlib')]

    get_node_changed(tree, transformer, expected('test_BaseImportRewrite_visit_Import.py'))

# Generated at 2022-06-12 03:32:32.748529
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import parse
    from . import six as six_mod
    code = 'from a import *; from a.b import c'
    tree = parse(code)
    rewrites = [('a', 'six')]
    six = six_mod.SixImportRewrite(tree, rewrites)
    six.visit(tree)
    expected = ('from six import *\n'
                '\n'
                'try:\n'
                '    from a.b import c\n'
                'except ImportError:\n'
                '    from six.b import c\n')
    result = six_mod.dumps(tree)
    assert expected == result

# Generated at 2022-06-12 03:32:40.948490
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    import six

    import trio

    # 
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('trio', 'asyncio'),
        ]

    test_data = [
        (
            """
            import trio
            """,
            """
            try:
                extend(import trio)
            except ImportError:
                extend(import asyncio as trio)
            """,
        ),
        (
            """
            import trio.abc
            """,
            """
            try:
                extend(import trio.abc)
            except ImportError:
                extend(import asyncio.abc as trio.abc)
            """,
        ),
    ]


# Generated at 2022-06-12 03:32:47.421181
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('asyncio', 'trollius')]

    original = ast.parse('''
import sys
from asyncio import test
''')

    expected = ast.parse('''
import sys
try:
    from asyncio import test
except ImportError:
    from trollius import test
''')

    transformed = TestTransformer.transform(original)
    assert transformed.tree == expected
    assert transformed.changed



# Generated at 2022-06-12 03:32:55.518420
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .common import (
        import_from_to_from_import,
        import_from_to_import)

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('from.from_module', 'from_module'),
            ('import_module', 'from.from_module'),
            ('from_module', 'import_module'),
        ]

    class TestTransformerFromToFrom(BaseImportRewrite):
        rewrites = [
            ('from.from_module', 'from_module'),
            ('import_module', 'from.from_module'),
            ('from.from_module2', 'from_module2'),
            ('from_module', 'import_module'),
            ('from_module2', 'from.from_module2'),
        ]


# Generated at 2022-06-12 03:33:05.239179
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from pycompat import AST_NODE_TYPES
    from ..utils import get_tree

    def check(cls, node_to_check, tree_changed):
        assert isinstance(node_to_check, cls)
        if tree_changed:
            assert isinstance(node_to_check, AST_NODE_TYPES[ast.Try])
        else:
            assert isinstance(node_to_check, AST_NODE_TYPES[ast.ImportFrom])

    class ImportFromRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves'),
            ('foo', 'bar')
        ]

    tree = get_tree('from six import moves as foo')
    node_to_check = tree.body[0]

# Generated at 2022-06-12 03:33:11.442134
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse(
        """
import sys.abc as a
import sys.def as b
import sys.def.ghi as c
from sys import abc as a
from sys import def as b
from sys import def as b, ghi as c
from sys import *
from sys.abc import def as a
from sys.abc import def as a, ghi as b
from sys.abc.def import ghi as a
from sys.abc.def.ghi import jkl as b
from sys.abc.def.ghi import *
""")
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('sys', 'abc'),
            ('sys.abc.def.ghi', 'def.ghi.jkl.mno')
        ]


# Generated at 2022-06-12 03:33:15.380929
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse('import module')
    transformer = BaseImportRewrite(node)
    transformer.rewrites = [
        ('from', 'to'),
        ('from.module', 'to.module')
    ]
    new_node = transformer.visit(node)
    assert isinstance(new_node, ast.Try)



# Generated at 2022-06-12 03:33:30.744944
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import typed_ast.ast3 as ast
    from ..target.python2 import BaseImportRewrite

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typed_ast', 'typed_ast.ast3')]

    assert TestTransformer.transform(
        ast.parse("import typed_ast; typed_ast.ast3.parse('pass')")
    ) == TransformationResult(
        tree=ast.parse("try:\n    import typed_ast\nexcept ImportError:\n    import typed_ast.ast3\ntyped_ast.ast3.parse('pass')"),
        changed=True,
        dependencies=['typed_ast.ast3']
    )


# Generated at 2022-06-12 03:33:40.169118
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse(
        r'''
        import datetime.time as dttm
        from datetime import datatime
        from datetime import time as tm
        ''')
    class Test(BaseImportRewrite):
        rewrites = [('datetime', '_datetime')]

    result = Test.transform(module)
    assert result.tree.body[0].body[0].value.names[0].name == '_datetime.time'
    assert result.tree.body[0].body[1].value.names[0].name == 'datatime'
    assert result.tree.body[0].body[2].value.names[0].name == 'time'

# Generated at 2022-06-12 03:33:50.167399
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    from . import BaseImportRewrite

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib.Xrequest')]

    node = ast.ImportFrom(module='urllib',
                          names=[ast.alias(name='urlopen',
                                           asname=None)],
                          level=0)
    result = TestImportRewrite(node).visit(node)
    assert isinstance(result, ast.Try)
    assert len(result.handlers) == 1
    assert isinstance(result.handlers[0].type, ast.Name)
    assert result.handlers[0].type.id == 'ImportError'
    assert len(result.handlers[0].body) == 1

# Generated at 2022-06-12 03:34:00.523417
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import inspect
    import unittest
    import sys

    class Test_BaseImportRewrite(unittest.TestCase):
        def setUp(self):
            self.cls = BaseImportRewrite
            self.cls.rewrites = [('collections', 'collections.abc')]

        def run_test(self, source, expected):
            tree = ast.parse(source)
            self.cls.transform(tree)
            self.assertEqual(astor.to_source(tree), expected)

        def test_1(self):
            source = '''
            from collections import defaultdict
            '''
            expected = '''
            try:
                from collections import defaultdict
            except ImportError:
                from collections.abc import defaultdict
            '''

# Generated at 2022-06-12 03:34:10.903756
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..tests.utils import string_ast_to_ast3
    from ..tests.test_import_rewrite import get_expected
    from ..utils.snippet import snippet

    snippet = snippet.get_body(previous=None, current=None)[0]

    @snippet
    def snippet(x):
        from datetime import datetime
        from sys import (stdout)
        from json import loads as json_loads

    a = string_ast_to_ast3(get_expected(snippet))
    b = string_ast_to_ast3(astor.to_source(snippet))

    class TestTransformer(BaseImportRewrite):
        dependencies = []

# Generated at 2022-06-12 03:34:20.241735
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    from typed_ast import ast3, convert
    import unittest
    from _compatibility_py2 import patch

    class ImportRewriteTestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            ast3.Import = patch.ast3.Import
            convert.parse = patch.convert.parse

        def test_import_rewrite(self):
            source = 'import unittest2'
            expected = '__import__("unittest2")'

            class ImportRewrite(BaseImportRewrite):
                rewrites = [('unittest2', 'unittest')]

            module = convert.parse(source)
            result, _, _ = ImportRewrite.transform(module)

# Generated at 2022-06-12 03:34:26.137263
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import run_test

    testcase = {
        'code': 'from module import *',
        'other': None,
        'rewrites': [(module, new_module)],
        'expected': 'try: from module import *\nexcept ImportError: from new_module import *'
    }

    result = run_test(testcase, BaseImportRewrite)
    assert result['failed'] == 0



# Generated at 2022-06-12 03:34:35.338054
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    
    tree = ast.parse("import string")
    transformer = BaseImportRewrite(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == 'import string'

    tree = ast.parse("import typing.NamedTuple")
    transformer = BaseImportRewrite(tree)
    transformer.visit(tree)
    assert astor.to_source(tree) == '''
try:
    import typing.NamedTuple
except ImportError:
    import collections.NamedTuple
'''.strip()

    tree = ast.parse("import typing.NamedTuple as New")
    transformer = BaseImportRewrite(tree)
    transformer.visit(tree)

# Generated at 2022-06-12 03:34:40.135048
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_ = ast.parse('import foo').body[0]

    class ImportTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    result = ImportTransformer.transform(import_)
    # type: ignore
    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar').body[0]
    assert result == (expected, True, [])


# Generated at 2022-06-12 03:34:48.661027
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from mekano.types import CompilationTarget, TransformationResult
    from typed_ast import ast3 as ast

    import_rewrites = [
        ('urllib', 'urllib2'),
    ]

    class RewriteTest(BaseImportRewrite):
        rewrites = import_rewrites

    # selected example based on https://docs.python.org/3.7/library/urllib.html

# Generated at 2022-06-12 03:35:07.726632
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import textwrap

    original_code = textwrap.dedent('''
    import itertools
    import os
    import web
    ''')

    rewrote_code = textwrap.dedent('''
    try:
        import itertools
    except ImportError:
        import itertools_ver2 as itertools
    import os
    try:
        import web
    except ImportError:
        import web_ver2 as web
    ''')

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('itertools', 'itertools_ver2'),
            ('web', 'web_ver2'),
        ]

    tree = ast.parse(original_code)
    Transformer.transform(tree)

# Generated at 2022-06-12 03:35:16.912854
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import ast
    
    module_name = 'transpyle.tests.test_base_transformer'
    target = CompilationTarget.PYTHON_LEGACY
    from_ = 'transpyle.tests.test_base_transformer'
    to = 'transpyle._compat.tests.test_base_transformer'


# Generated at 2022-06-12 03:35:24.626399
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    class TestTransformer(BaseImportRewrite):
        rewrites = [("test.test1", "test.test2")]
        def visit_ImportFrom(self, node):
            return super().visit_ImportFrom(node)
    # No matching
    node = ast.parse("from test.test1 import foo").body[0]
    res = TestTransformer.transform(node)
    assert str(res.tree) == 'from test.test1 import foo'
    # Matching whole import
    node2 = ast.parse("from test.test1 import foo").body[0]
    res = TestTransformer.transform(node2)
    assert str(res.tree) == 'from test.test2 import foo as foo'
    # Matching part of import

# Generated at 2022-06-12 03:35:34.573560
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys, os
    code = '''\
#!/usr/bin/env python3
import os, sys
import socket as socket2
from http import HTTPStatus, client
from urllib.parse import urlparse
from xmlrpc.client import ServerProxy as XMLRPCClient
from os import path
from os import path as path2
from . import path as path3
from . import path2
'''


# Generated at 2022-06-12 03:35:45.263686
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astunparse
    class ImportTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'foobar')]

    source = '''
        from foo.bar.x import a, b
        from foo.bar import a as foo, bar_b as b
    '''

    expected_source = '''
        try:
            import foobar.x as a, foobar.x as b
        except ImportError:
            from foo.bar.x import a, b

        try:
            from foobar import a as foo, b as bar_b
        except ImportError:
            from foo.bar import a as foo, bar_b as b
    '''

    expected_tree = ast.parse(expected_source)

    result_tree = ast.parse(source, mode='exec')
   

# Generated at 2022-06-12 03:35:54.498291
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import strip
    source = '''
    from gevent import wait as gevent_wait

    from gevent import wait
    '''
    etalon = '''
    try:
        from gevent import wait as gevent_wait
    except ImportError:
        from pygevent import wait as gevent_wait


    try:
        from gevent import wait
    except ImportError:
        from pygevent import wait
    '''
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('gevent', 'pygevent')]

    tree = ast.parse(source)
    ImportRewrite.transform(tree)
    result = astor.to_source(tree)
    assert strip(result) == strip(etalon)



# Generated at 2022-06-12 03:35:59.580181
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import collections\n")
    transformer = BaseImportRewrite(tree)
    old_import = tree.body[0]
    result = transformer.visit_Import(old_import)
    assert not transformer._tree_changed
    assert type(result) == ast.Import
    assert result.names[0].name == 'collections'


# Generated at 2022-06-12 03:36:09.897301
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import six
    import warnings
    import astor
    from ..utils.tree import compile_ast
    from ..utils.compat import UTF8Mixin
    from ..transformations import convert_ast_import
    from ..transformations.convert_ast_import.rewrites import (
        convert_ast2to3_import_rewrites,
        convert_ast3to2_import_rewrites,
    )

    class FakeFileObject(UTF8Mixin):
        def __init__(self, data: bytes):
            self.data = data

        def read(self) -> bytes:
            return self.data

        def write(self, data: bytes) -> None:
            pass

        def flush(self) -> None:
            pass

    tree = ast.parse(six.u('import six.moves.queue as queue'))


# Generated at 2022-06-12 03:36:20.894820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Create node ImportFrom
    name = ast.Name()
    name.id = 'builtins'
    import_from = ast.ImportFrom()
    import_from.level = 0
    import_from.module = name
    # Create and add node alias to node ImportFrom
    alias = ast.alias()
    alias.name = 'quit'
    alias.asname = 'quit'
    import_from.names = [alias]
    # Create instance of class BaseImportRewrite and call method visit_ImportFrom
    import_rewrite_instance = BaseImportRewrite(ast.AST())
    result = import_rewrite_instance.visit_ImportFrom(import_from)
    # Check type of result
    assert type(result) is ast.Try, 'Should be same type'
    # Chec if body contains node ImportFrom

# Generated at 2022-06-12 03:36:31.027816
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.compile import compile_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('urllib.request', 'urllib.request2'),
            ('collections', 'collections2')]

    def test_rewrite_import():
        source = '\n'.join([
            'import collections',
            'import urllib.request',
            'import requests',
            'print(1)',
        ])

        tree = compile_ast.get_ast(source)

        result = TestImportRewrite.transform(tree)
        assert result.changed

        # print(ast.dump(result.tree))


# Generated at 2022-06-12 03:36:55.167391
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    from .test_conftest import get_ast_equal
    from .test_conftest import ast_equal_func

    ast_equal = get_ast_equal(BaseImportRewrite)

    import_text = 'from test_import.module import *'
    import_tree = astor.parse(import_text)

    assert ast_equal(import_text, import_tree)

    import_text = 'from abc import (a, b as c, d as e)'
    import_tree = astor.parse(import_text)

    assert ast_equal(import_text, import_tree)

    import_text = 'from test_import.module import a'
    import_tree = astor.parse(import_text)

    assert ast_equal(import_text, import_tree)

    import_

# Generated at 2022-06-12 03:37:02.113119
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom(): 
    import astor
    from ..utils import make_visit_method
    visit_ImportFrom = make_visit_method(BaseImportRewrite, 'visit_ImportFrom')

    import_from_node = ast.parse("""from numpy import ones, flip""").body[0]

    transformed_node = visit_ImportFrom(BaseImportRewrite(ast.Module([])), import_from_node)

    assert astor.to_source(transformed_node) == """try:
    from numpy import ones, flip
except ImportError:
    from numpy.core.numeric import ones, flip"""



# Generated at 2022-06-12 03:37:03.542197
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-12 03:37:12.920014
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast_unparse
    from ..types import CompilationTarget
    for module, names in [('django.forms', ['Form']),
                          ('django.forms.widgets', ['Widget']),
                          ('django.forms.widgets.Select', ['Select']),
                          ('django.contrib.sessions.serializers', ['PickleSerializer']),
                          ('django.contrib.sessions.serializers.PickleSerializer', ['PickleSerializer'])]:
        test_code = 'from {} import *'.format(module)
        tree = ast.parse(test_code)
        BaseImportRewrite.rewrites = [('django.forms', 'django_backports.forms')]
        BaseImportRewrite.transform(tree)

# Generated at 2022-06-12 03:37:22.759946
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert BaseImportRewrite.transform(ast.parse("from subprocess import Popen")) == \
      TransformationResult(ast.parse("from subprocess import Popen"), False, [])
    assert BaseImportRewrite.transform(ast.parse("from pycron import timedelta")) == \
      TransformationResult(ast.parse("from croniter.datetimecroniter import timedelta"), True, [])
    assert BaseImportRewrite.transform(ast.parse("from pycron import Timedelta")) == \
      TransformationResult(ast.parse("from croniter.datetimecroniter import timedelta"), True, [])

# Generated at 2022-06-12 03:37:24.879593
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class FakeTransformer(BaseImportRewrite):
        rewrites = [('old.module_name', 'new.module_name')]

    tree = ast.parse('import old.module_name')
    result = FakeTransformer.transform(tree)
    assert isinstance(result.tree.body[0], ast.Try)



# Generated at 2022-06-12 03:37:30.985211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..targets.python import PythonTarget

    class TestTransformer(BaseImportRewrite):
        target = PythonTarget
        rewrites = [('os', 'os2')]

    source = '''
import os
'''.strip()

    tree = TestTransformer.transform(ast.parse(source)).tree
    assert TestTransformer._tree_changed
    assert isinstance(tree.body[0], ast.Try)
    assert tree.body[0].body[0].names[0].name == 'os2'
    assert tree.body[0].handlers[0].type.id == 'ImportError'
    assert tree.body[0].handlers[0].body[0].names[0].name == 'os'



# Generated at 2022-06-12 03:37:40.473268
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import typed_ast.ast3 as ast
    from typed_ast.transforms.typed_ast_transforms import BaseImportRewrite, import_rewrite
    import itertools
    from .utils import check_import_syntax, assert_ast

    tree = ast.parse('from flask import request, Response')
    class BaseImportRewrite_test(BaseImportRewrite):
        rewrites = [('flask', 'flask-deprecated')]
    BaseImportRewrite_test.visit(tree)
    assert_ast(tree, ['try:',
                      'from flask import request, Response',
                      'except ImportError:',
                      'from flask-deprecated import request, Response'])

    tree = ast.parse('from flask import request, Response')

# Generated at 2022-06-12 03:37:46.757727
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'mock.six')]

    tree = ast.parse('import six')
    res = DummyImportRewrite.transform(tree)

    assert isinstance(res.tree.body[0], ast.Try)
    assert res.changed

    assert isinstance(res.tree.body[0].handlers[0].type, ast.Name)
    assert res.tree.body[0].handlers[0].type.id == 'ImportError'



# Generated at 2022-06-12 03:37:54.402590
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    original_source = 'from typing import NamedTuple, List'
    expected = '\n'.join((
        '    from typing import NamedTuple, List',
        '    try:',
        '        from typing import NamedTuple, List',
        '    except ImportError:',
        '        from collections import NamedTuple, List',
    ))

    class Rewrite(BaseImportRewrite):
        rewrites = [('typing', 'collections')]

    result = Rewrite.transform(ast.parse(original_source))
    assert result.tree_changed
    assert ast.dump(result.tree) == expected



# Generated at 2022-06-12 03:38:34.883970
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    class Test(unittest.TestCase):
        def _make_one(self):
            from . import (  # noqa
                transformers
            )
            from .transformers.typed_ast_support import (  # noqa
                BaseImportRewrite
            )
            class Test(BaseImportRewrite):
                rewrites = [
                    ('foo', 'bar')
                ]

            return Test

        def test_it(self):
            import ast
            import mock
            real_rewrites = [
                ('foo', 'bar'),
                ('foobar', 'barbar'),
                ('foofoo', 'barr'),
                ('bar', 'foo')
            ]
            cls = self._make_one()
            cls.rewrites = real_rewrites

# Generated at 2022-06-12 03:38:43.583672
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from textwrap import dedent
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('mypackage.my', 'yourpackage.your'),
            ('otherpackage.other', 'anotherpackage.another'),
        ]

    def do_test(src, expected):
        tree = ast.parse(src)
        result = Transformer.transform(tree)
        assert result.changed is True
        assert unparse(result.tree).strip() == expected.strip()
