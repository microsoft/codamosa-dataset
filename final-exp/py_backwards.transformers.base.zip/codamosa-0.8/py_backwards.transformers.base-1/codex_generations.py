

# Generated at 2022-06-12 03:29:02.076853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse

    import_rewrites = [('collections', 'collections.abc')]
    class TestTransformer(BaseImportRewrite):
        rewrites = import_rewrites

    input_tree = ast.parse("""
        import collections
    """)

    expected = """
    try:
        import collections
    except ImportError:
        import collections.abc as collections
    """

    result = TestTransformer.transform(input_tree)
    output = unparse(result.tree)
    assert output == expected


# Generated at 2022-06-12 03:29:11.991518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import ast_utils

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('shutil', 'shutil_replace')]

    tree = ast_utils.ast_from_source('''
        import shutil
        shutil.copy('/tmp/file1', '/tmp/file2')
    ''')

    import_rewrite = ImportRewrite.transform(tree)
    assert import_rewrite.changed is True
    assert import_rewrite.dependencies == []
    assert ast_utils.ast_to_source(import_rewrite.tree) == '''
        try:
            import shutil
        except ImportError:
            import shutil_replace as shutil
        shutil.copy('/tmp/file1', '/tmp/file2')
    '''



# Generated at 2022-06-12 03:29:21.288127
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    from ..target import python, transition  
    from ..transformer.imports import BaseImportRewrite
    
    old_import = ast.Import(names=[ast.alias(name='site',
                                             asname='site')])
    new_import = ast.Import(names=[ast.alias(name='site',
                                             asname='site')])
    
    newnode = BaseImportRewrite.visit_Import(ast.Import(names=[ast.alias(name='sys',
                                             asname='sys')]))
    

# Generated at 2022-06-12 03:29:31.711568
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore
    import os

    # Setup test variables
    target = CompilationTarget.PYTHON_27
    node_builder = ast.NodeBuilder(target)
    node_builder.add_import(name='foo')
    node = node_builder.get_tree()
    expected = os.linesep.join([
        'try:',
        '    import foo',
        'except ImportError:',
        '    import foo_py2'
    ])
    rewrites = [('foo', 'foo_py2')]

    # Perform test
    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    transformer = TestTransformer(node)
    transformed = transformer.visit(node)
    assert astor.to_source(transformed).strip() == expected



# Generated at 2022-06-12 03:29:39.158285
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compatibility import ast_parse, ast3_to_string
    rewrites = [('foo', 'bar')]
    tree = ast_parse('import foo')
    BaseImportRewrite.rewrites = rewrites
    inst = BaseImportRewrite(tree)
    node = tree.body[0]
    new_node = inst.visit_Import(node)
    node_str = 'try:\n    import bar\nexcept ImportError:\n    import foo'
    assert ast3_to_string(new_node) == node_str
    assert inst._tree_changed == True
    assert inst.dependencies == []


# Generated at 2022-06-12 03:29:47.491218
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import unittest

    from typed_ast import ast3 as typed_ast
    from typed_ast.ast3 import ImportFrom, alias

    import_from = ImportFrom(module='module',
                             names=[alias(name='name', asname=None)], level=0)

    class RewriteTestCase(unittest.TestCase):
        def test_rewrite_import_from(self):
            from typed_astunparse import unparse

            class MockTransformer(BaseImportRewrite):
                rewrites = [
                    ('module.name', 'rewrote.name'),
                ]

            result = MockTransformer.transform(import_from)
            self.assertEqual(unparse(result.tree), unparse(result.tree))

    unittest.main()


# Generated at 2022-06-12 03:29:58.670513
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import import_rewrite_test
    import_rewrite_test.import_rewrite_test()
    from import_rewrite_test import import_rewrite_test
    from import_rewrite_test import import_rewrite_test as import_rewrite_test2
    import import_rewrite_test as import_rewrite_test3  # noqa
    import import_rewrite_test.import_rewrite_test as import_rewrite_test4
    import import_rewrite_test.import_rewrite_test as import_rewrite_test5 # noqa
    import_rewrite_test.import_rewrite_test.import_rewrite_test2()
    import import_rewrite_test.import_rewrite_test.import_rewrite_test2

# Generated at 2022-06-12 03:30:03.408108
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    tree = ast.parse('''
import foo
import foo.bar
import foo.bar.baz

print()
    ''')
    BaseImportRewrite.rewrites = [('foo', 'bar')]
    BaseImportRewrite.transform(tree)
    assert astor.to_source(tree) == '''
import bar
import bar.bar
import bar.bar.baz

print()
    '''


# Generated at 2022-06-12 03:30:13.882148
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    import onnx
    import keras
    # Module node with 'import'
    onnx_node = ast.parse('''
import onnx
''').body[0]
    rewriter = BaseImportRewrite()
    rewriter.rewrites = [('onnx', 'onnxmltools')]
    new_node = rewriter.visit(onnx_node)
    # Correct import using "onnx" is replaced by "onnxmltools"
    # Compare with ast.dump output
    expected_body = '''
try:
    import onnx
except ImportError:
    import onnxmltools
'''
    assert astunparse.unparse(new_node) == expected_body
    # Module node with 'import'


# Generated at 2022-06-12 03:30:24.307023
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from test.fixtures import some_sub_test_module_import
    from typed_ast.ast3 import parse
    from ..utils.snippet import to_source
    import_node = parse(to_source(some_sub_test_module_import))
    t = BaseImportRewrite(None)
    t.rewrites = [('sub.subsub', 'subsub')]
    result = t.visit_Import(import_node)

    assert isinstance(result, ast.Try)
    assert to_source(result.body[0]) == "import subsub.subsubsub_mod"
    assert to_source(result.handlers[0].type) == "ImportError"
    assert to_source(result.handlers[0].body[0]) == "import sub.subsub.subsubsub_mod"
   

# Generated at 2022-06-12 03:30:39.656546
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import os.path
    import unittest

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('simplejson', 'json')]

    class TestBaseImportRewrite_visit_Import(unittest.TestCase):
        def test_import(self):
            code = astor.parse_file(os.path.join(os.path.abspath(__file__), '..', '..', 'examples', 'sqlite.py'))
            self.assertIn('import simplejson', astor.to_source(code))
            code = TestBaseImportRewrite.transform(code).tree
            self.assertIn('import simplejson', astor.to_source(code).splitlines())

# Generated at 2022-06-12 03:30:46.865880
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..tests.fixtures import tree_from_code
    import ast
    import sys

    if sys.version_info[:2] >= (3, 8):
        for code in [
            'import threading',
            'import threading.foo',
            'import threading.foo.bar.baz',
        ]:
            tree = tree_from_code(code)
            expected = tree_from_code(
                '''
                try:
                    import threading
                except ImportError:
                    import _threading as threading
                ''')
            BaseImportRewrite(tree).visit(tree)

            assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 03:30:53.085134
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Source code
    code = 'import collections.abc'

    # Expected results
    expected = '''\
try:
    import collections.abc
except ImportError:
    import collections_abc as collections.abc
'''

    # Run the test
    BaseImportRewrite.rewrites = [('collections.abc', 'collections_abc')]
    BaseImportRewrite.transform(code) == expected


# Generated at 2022-06-12 03:31:01.770813
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    from typed_ast.transformer import BaseImportRewrite, TransformationResult

    class A(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse('import a')
    assert A.transform(tree) == TransformationResult(ast.parse('try:\n    import a\nexcept ImportError:\n    import b'), True, [])

# Generated at 2022-06-12 03:31:09.699042
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Stub(BaseImportRewrite):
        rewrites = [('old', 'new')]

    inst = Stub(None)

    assert inst.visit_Import(ast.parse('import foo').body[0]) == ast.parse('import foo').body[0]

    assert inst.visit_Import(ast.parse('import old').body[0]
                             ) == ast.parse("""
try:
    import old
except ImportError:
    try:
        import new
    except ImportError:
        import old
""").body[0]


# Generated at 2022-06-12 03:31:20.412478
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = astor.parse('''
from django.urls import path, re_path
from django.views.generic import TemplateView
path('', TemplateView.as_view(template_name="index.html"), name='index'),
re_path(r'^', TemplateView.as_view(template_name="index.html"), name='index'),
''')

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('django.urls', 'django.urls.path')]

    tree = ImportRewrite.transform(tree)[0]

# Generated at 2022-06-12 03:31:25.249243
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_node = ast.parse('import foo').body[0]
    expected = ast.parse(dedent("""
    try:
        import foo
    except ImportError:
        import bar
    """))

    assert DummyTransformer.transform(import_node).tree == expected


# Generated at 2022-06-12 03:31:32.744418
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    source = """from re import *""".split('\n')
    test_snippet = compile(source, 'test_source', 'exec')

    rewr = BaseImportRewrite(test_snippet)
    rewr.rewrites = [('re', 'regex')]
    rewr.transform(test_snippet)

    expected = """try:
    from re import *
except ImportError:
    from regex import *""".split('\n')
    assert check_unit_test(rewr._tree, expected)



# Generated at 2022-06-12 03:31:42.996633
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    source = """
    from django.contrib.auth import get_user_model
    from django import forms
    from django.contrib.auth.forms import UserCreationForm
    from django.contrib.auth.forms import UsernameField
    from django.contrib.auth.forms import SetPasswordForm
    from rest_framework.authtoken.models import Token
    """
    tree = ast.parse(source)
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('django.contrib.auth.forms', 'django')]
    transformer.visit(tree)

# Generated at 2022-06-12 03:31:50.721921
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class ImportRewriter(BaseImportRewrite):
        target = 'python2.7'
        rewrites = [
            ('abc', 'abc1'),
        ]

    source = """\
import abc
import abc.def
import def
import def as ghi"""
    tree = ast.parse(source)
    ImportRewriter.transform(tree)
    assert astor.to_source(tree) == """\
try:
    import abc
except ImportError:
    import abc1
try:
    import abc.def
except ImportError:
    import abc1.def
import def
import def as ghi"""



# Generated at 2022-06-12 03:32:02.793717
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import unparse
    from .examples import BaseImportRewrite_example

    from_ = 'some_module'
    to = 'another_module'
    node = ast.parse('import ' + from_)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [(from_, to)]

    tree = TestImportRewrite.transform(node)[0]

    expected_tree = ast.parse(BaseImportRewrite_example)
    assert unparse(tree) == unparse(expected_tree)


# Generated at 2022-06-12 03:32:09.684510
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import TransformationResult
    from ..compiler import Compiler
    from ..parser.parser import Parser
    from ..parser.unparser import Unparser

    class BaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [('future', 'past')]

    # Test 1
    # Test simple import
    tree = Parser.parse("from future.standard_library import install_aliases")
    result = BaseImportRewrite_visit_Import.transform(tree)
    assert result == TransformationResult(
        tree, True,
        [])
    string = Unparser.unparse(tree)
    assert string == "from future.standard_library import install_aliases"

    # Test 2
    # Test import from future with alias past

# Generated at 2022-06-12 03:32:16.239467
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from . import dummy_target

    class TestCase(BaseImportRewrite):
        target = dummy_target
        rewrites = [('re', 'regex')]

    import_ = ast.Import(names=[ast.alias(name='re')])

    try_ = TestCase.visit_Import(import_)
    assert isinstance(try_, ast.Try)
    assert try_.body[0].names[0].name == 'regex'
    assert try_.handlers[0].type.id == 'ImportError'



# Generated at 2022-06-12 03:32:25.214681
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.snippet import get_first_snippet_source_for_test
    tree = ast.parse(get_first_snippet_source_for_test(__name__, test_BaseImportRewrite_visit_Import.__name__))
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('.six', '.six_mock')]
    import_rewrite = ImportRewrite()
    import_rewrite.visit(tree)
    assert astor.to_source(tree).strip() == """
try:
    import six
except:
    import six_mock as six
""".strip()


# Generated at 2022-06-12 03:32:35.855453
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import core.plugins.simple.simple_transformer
    from core.plugins.simple.simple_transformer import SimpleTransformer
    import core.transformer
    from core.transformer import ImportRewrite

    class TestImportRewrite(ImportRewrite):
        rewrites = [("typing", "types")]
        target = "python-2.7"

        class SimpleTransformer(SimpleTransformer):
            target = "python-2.7"
            __tests__ = ["__init__", "transform", "visit_Import"]

    tree = ast.parse("from typing import List")
    result = TestImportRewrite.transform(tree)
    assert result.changed
    expected_tree = ast.parse("from typing import List\ntry:\n    extend(previous)\nexcept ImportError:\n    from types import List")

# Generated at 2022-06-12 03:32:42.689210
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from . import ast_helpers as helpers

    import_from_stmt_with_rewrite = helpers.parse_stmt(
        'from package.sub.subsub.subsubsub import function1, function2, function3')
    import_from_stmt_with_rewrite_expected = 'try:\n' + \
        '    from package.sub.subsub.subsubsub import function1, function2, function3\n' + \
        'except ImportError:\n' + \
        '    from package.sub.subsub.subsubsub import function1, function2, function3\n'

    import_from_stmt_without_rewrite = helpers.parse_stmt(
        'from package.sub.subsub import function1, function2, function3')
    import_from_stmt_without_rewrite

# Generated at 2022-06-12 03:32:50.993527
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..registry import TransformerRegistry
    # Source code for the test
    code = '''\
import django.conf

a = django.conf.settings.LANGUAGE_CODE
'''
    # Create and register transformer
    class rewrite_import(BaseImportRewrite):
        rewrites = [
            ('django.conf', 'django.settings'),
        ]

    TransformerRegistry[rewrite_import.target].append(rewrite_import)
    # Create AST and transform
    tree = ast.parse(code)
    result = TransformerRegistry.transform(tree)
    # Compare output with source code

# Generated at 2022-06-12 03:33:00.240380
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:33:08.532789
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..typing import Dict
    from ..utils.py3_ast import ast_str, parse
    from ..utils.test_utils import assert_ast_equals
    from .base import _BaseImportRewrite_test

    def test_single_rewrite():
        class Transformer(_BaseImportRewrite_test):
            rewrites = [('m', 'n')]

        tree = parse('import m')
        assert_ast_equals(
            Transformer.transform(tree).tree,
            parse('''
            try:
                import m
            except ImportError:
                import n as m
            '''),
            includes_code=True)

    test_single_rewrite()


# Generated at 2022-06-12 03:33:17.232380
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse(
        "import six",
        type_comments=False)
    result = ImportTransformer.transform(tree)
    new_import = result.new_tree.body[0]
    assert isinstance(new_import, ast.Try)
    assert new_import.body[0].value.names[0].name == 'six'
    assert new_import.body[1][0].name == "ImportError"
    assert new_import.body[1].body[0].value.names[0].name == 'six.moves'
    assert len(result.dependencies) == 1
    assert result.dependencies[0] == 'six.moves'


# Generated at 2022-06-12 03:33:36.928731
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..types import CompilationTarget
    from ..utils import uast

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_3
        rewrites = [
            ('old_module', 'new_module'),
            ('old_module.sub_module', 'new_module.sub_module'),
        ]

    class TestBaseImportRewrite(unittest.TestCase):
        """Tests method visit_Import"""
        def test_changed(self):
            """Tests changed import statements."""
            old = 'import old_module'
            new = 'try:\n    import new_module\nexcept ImportError:\n    import old_module'

# Generated at 2022-06-12 03:33:46.844978
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import transform
    import sys
    from ..utils.typing import get_imports, get_used_imports
    from ..utils import _parse_module, _parse_snippet

    module_file = sys.modules[__name__].__file__

    # BaseImportRewrite should not change anything
    tree = _parse_module(module_file)
    tree = transform(tree, BaseImportRewrite)['ast']
    assert get_imports(tree) == ['sys']
    assert get_used_imports(tree) == set(['sys', 'ast'])

    # BaseImportRewrite should rewrite import
    rewrites = [('os', 'sys')]
    tree = _parse_module(module_file)

# Generated at 2022-06-12 03:33:51.631369
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformers import local_import_rewrite
    from ..transformers.python.compile import compile

    tree = compile(
        'from random import randint\nfrom random import randrange')

    local_import_rewrite.visit(tree)

    assert hasattr(local_import_rewrite, 'from_random_import_random')

# Generated at 2022-06-12 03:34:01.809451
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..ast_info import ast_info as ast_info
    from ..transformer import import_rewrite
    tree = ast.parse('from test.module import a as a, b')
    result = import_rewrite.transform(tree)
    assert result.result == ast.parse('from test.module import a as a, b')
    assert result.changed is False
    assert result.dependencies == []

    replacements = [('test.module', 'test_module')]
    import_rewrite.rewrites = replacements
    result = import_rewrite.transform(tree)
    assert result.changed is True

# Generated at 2022-06-12 03:34:11.929138
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from bz2 import decompress

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('bz2', 'tarfile')]

    tree = ast.parse('''
from bz2 import decompress
decompress(b"0")
    ''')
    Transformer.transform(tree)
    actual = ast.dump(tree)
    expected = '''Module(body=[Try(body=[Import(names=[alias(name='tarfile.decompress', asname='decompress')])], orelse=[], finalbody=[], handlers=[], type_comment=None), Expr(value=Call(func=Name(id='decompress', ctx=Load()), args=[Bytes(s=b'0')], keywords=[]))])'''
    assert actual == expected



# Generated at 2022-06-12 03:34:21.766124
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from textwrap import dedent
    from ..utils.compiler import compile_test_module

    snippet = dedent("""
    from future import standard_library
    standard_library.install_aliases()

    from urllib2 import urlopen  # type: ignore
    from urllib2 import urlretrieve  # type: ignore
    from urllib2 import URLError  # type: ignore
    from urllib2 import HTTPError  # type: ignore

    with urlopen('https://docs.python.org/3/') as response:
        print(response.read())
    """)


# Generated at 2022-06-12 03:34:29.136008
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_only_changed
    from .base import BaseImportRewrite

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('__six__', 'six')]

    node = ast.parse('import __six__').body[0]
    assert get_only_changed(ImportRewrite.transform(node)) == [
        "try:\n",
        "    import __six__\n",
        "except ImportError:\n",
        "    import six\n"
    ]



# Generated at 2022-06-12 03:34:37.303441
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ast_visitor import BaseImportRewrite
    from ..parsers.python import from_python

    TEST_DATA = [
        """
from six.moves import pkg_resources
from six import text_type, iteritems
from six import StringIO""",
        """
from six.moves import pkg_resources
from six import text_type, iteritems
from six import StringIO
from six.moves.urllib_parse import urlparse
from six.moves.urllib_parse import parse_qs, parse_qsl""",
        """
from six import string_types
from six import integer_types""",
        """
from django.contrib.auth.backends import ModelBackend
from django.contrib import auth
auth.login""",
    ]


# Generated at 2022-06-12 03:34:43.930903
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    tree = astor.parse('import foo')
    tree = BaseImportRewrite(tree).visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo\nexcept ImportError:\n    import foo_py36'

    tree = astor.parse('import foo.bar')
    tree = BaseImportRewrite(tree).visit(tree)
    assert astor.to_source(tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import foo_py36.bar'


# Generated at 2022-06-12 03:34:52.328800
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .base import TransformationTestCase

    class TestRewrite(BaseImportRewrite):
        rewrites = [('cStringIO', 'io')]

    class Test(TransformationTestCase):
        transformer = TestRewrite

        def test_import_from_1(self):
            self.assertTransformed(
                """
                from cStringIO import StringIO
                """,
                """
                try:
                    from cStringIO import StringIO
                except ImportError:
                    from io.StringIO import StringIO
                """
            )


# Generated at 2022-06-12 03:35:05.448734
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import x; from x import y
    tree = ast.parse("""
    import x
    from x import y
    """)
    result = BaseImportRewrite.transform(
        tree)
    assert result._changed



# Generated at 2022-06-12 03:35:14.294620
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Fake(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]

    import astor
    input_ = """
from a.b import c, d
from a import b
from a.b.c import d
from x import y
"""
    tree = ast.parse(input_)
    tree = Fake.transform(tree)
    output = astor.to_source(tree.tree).replace(' ', '').replace('\n', '')

# Generated at 2022-06-12 03:35:23.327173
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    code_input = 'from xmodule import Foo'
    expected = import_rewrite.get_body(previous=ast.parse(code_input).body[0],  # type: ignore
                                       current=ast.Import(names=[
                                           ast.alias(name='new_xmodule.Foo',
                                                     asname='Foo')
                                       ]))[0]

    class TestTransformer(BaseImportRewrite):
        rewrites = [('xmodule', 'new_xmodule')]
    result = TestTransformer.transform(ast.parse(code_input)).tree.body[0]

    assert isinstance(result, ast.Try)
    assert len(result.body) == 1
    assert len(result.handlers) == 1
    assert len(result.body[0].body) == 1

# Generated at 2022-06-12 03:35:32.781848
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..transformers import BaseImportRewrite


    class TestTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    tree = ast.parse(
        textwrap.dedent('''
        from old_module import SomeClass, SomeFunction

        from old_module.subpackage import SomeClass as SubClass
        '''))

    transformer = TestTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-12 03:35:40.100496
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class import_rewrite_Test(BaseImportRewrite):
        rewrites = [('old', 'new')]

    node = ast.parse('import old')
    result = import_rewrite_Test.transform(node)

    assert issubclass(type(result.tree.body[0].body[0].body[0]), ast.Import)
    assert issubclass(type(result.tree.body[0].body[1].body[1].body[0]), ast.Import)
    assert result.changed



# Generated at 2022-06-12 03:35:44.560841
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    import_node = ast.parse('import threading')
    node = BaseImportRewrite.transform(import_node)
    assert node.tree == BaseImportRewrite.transform(ast.parse('import threading')).tree


# Generated at 2022-06-12 03:35:50.114128
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils import get_node

    class TestClass(BaseImportRewrite):
        rewrites = [('typing.abc', 'abc')]

    tree = get_node('import typing.abc')
    TestClass.transform(tree)
    assert astor.to_source(tree) == textwrap.dedent('''
    try:
        import typing.abc
    except ImportError:
        import abc''')



# Generated at 2022-06-12 03:35:59.922118
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.source_code import SourceCode
    from ..utils.testing import assert_node_structure

    class Test1(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = SourceCode('''
    from foo import bar, baz
    from foo.name import spam, ham
    ''')

    expected = SourceCode('''
    from bar import bar, baz
    from bar.name import spam, ham
    ''')

    assert_node_structure(expected.tree, Test1.transform(source.tree).tree)

    class Test2(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = SourceCode('''
    from foo import *
    from foo.name import *
    ''')

    expected = SourceCode

# Generated at 2022-06-12 03:36:05.484654
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_from = 'import numpy as np'
    rewrite = ('numpy', 'cupy')
    expected = "import cupy as np"

    visitor = BaseImportRewrite()
    visitor.rewrites = [rewrite]
    visitor.visit(ast.parse(import_from))

    assert (ast.dump(visitor.visit(ast.parse(import_from)))) == expected


# Generated at 2022-06-12 03:36:11.663831
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class SampleTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz')]

    original_code = '''
    import foo.bar.baz
    '''
    expected_code = '''
    try:
        import foo.bar.baz
    except ImportError:
        import baz.baz
    '''
    compare_transformer(SampleTransformer, original_code, expected_code, mode='exec')



# Generated at 2022-06-12 03:36:34.218275
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('previous', 'new')]
    import_node = ast.parse('import previous').body[0]
    import_rewrite_node = ast.parse("""
try:
    import previous
except ImportError:
    import new
    """).body[0]
    result = Rewrite(None).visit(import_node)
    assert isinstance(result, ast.Try)
    assert ast.dump(result) == ast.dump(import_rewrite_node)



# Generated at 2022-06-12 03:36:43.647336
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from typed_ast import ast3 as ast, parse

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six')]

    class TestBaseImportRewriteTestCase(unittest.TestCase):
        def test_visit_Import(self):
            tree = ast.parse('import six')
            rewrote = TestBaseImportRewrite.transform(tree).tree
            rewrote_code = ast.unparse(rewrote)
            block = '''
            try:
                import six
            except ImportError:
                import six as six
            '''
            self.assertEqual(block, rewrote_code)

    unittest.main()


# Generated at 2022-06-12 03:36:52.947996
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # [AST]
    # import_from = ast.ImportFrom(module='os',
    #                              names=[ast.alias(name='path',
    #                                               asname=None),
    #                                     ast.alias(name='system',
    #                                               asname='sys')])
    import_from: ast.ImportFrom = ast.parse("from os import path, system as sys").body[0]  # type: ignore

    # [Test1]
    # import_rewrite = BaseImportRewrite()
    import_rewrite = BaseImportRewrite([])  # type: ignore

    from_ = 'os'
    to = 'os2'
    # import_rewrite.rewrites = [(from_, to)]
    import_rewrite.rewrites = [(from_, to)]  # type: ignore
   

# Generated at 2022-06-12 03:37:01.904238
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # test 1
    import astor

    my_module = astor.parse_file('../tests/basic_tests/tests/test_import.py')
    # print(astor.to_source(my_module))
    transformer = BaseImportRewrite()
    transformer.visit(my_module)
    assert astor.to_source(my_module)[1] == 'import numpy as np\n'

    # test 2
    import astor

    my_module = astor.parse_file('../tests/basic_tests/tests/test_import.py')
    transformer = BaseImportRewrite()
    transformer.visit(my_module)
    assert astor.to_source(my_module)[2] == 'try:\n    from test_import_from import *\n'

    # test 3
    import ast

# Generated at 2022-06-12 03:37:11.309016
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse(
        "import werkzeug\n")
    tree = BaseImportRewrite().transform(tree)[0]

# Generated at 2022-06-12 03:37:21.658184
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [
        ('foo.bar', 'baz.qux'),
    ]

    class RewriteTransformer(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse("""
import foo.bar
import foo.bar.baz
""")

    tr = RewriteTransformer.transform(tree)
    assert tr.tree_changed

    # import foo.bar
    stmt = tr.tree.body[0]
    assert isinstance(stmt, ast.Try)
    assert len(stmt.body) == 1
    assert len(stmt.handlers) == 1
    assert len(stmt.orelse) == 0
    assert stmt.finalbody == []

    try_body = stmt.body[0]

# Generated at 2022-06-12 03:37:28.032094
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.Module(body=[
        ast.Try(body=[
            ast.ImportFrom(module='os.path',
                           names=[ast.alias(name='path', asname=None)],
                           level=None)],
            handlers=[],
            orelse=[],
            finalbody=[])])

    tree = ast.parse('from os.path import path')

    inst = BaseImportRewrite(tree)
    actual = inst.visit(module)
    expected = tree
    assert ast.dump(actual, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-12 03:37:37.204668
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]

    tree = ast.parse("from a import x\nfrom a import y")
    try:
        import_rewrite.extend(transform.Import)
    except ImportError:
        import_rewrite.extend(transform2.Import)


# Generated at 2022-06-12 03:37:46.553558
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import prettify
    
    class SimpleImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'future')]
    
    class SubImportRewrite(BaseImportRewrite):
        rewrites = [('six.moves', 'future')]
    
    class SubImportRewriteError(BaseImportRewrite):
        rewrites = [('six.moves.urllib', 'future')]
    
    def test(test_class, code):
        tree = ast.parse(code)
        test_class.transform(tree)
        assert prettify(tree) == prettify(ast.parse(code.replace('six.', 'future.')))
    
    test(SimpleImportRewrite, 'import six')
    test(SimpleImportRewrite, 'import six.moves')
    test

# Generated at 2022-06-12 03:37:53.814235
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'past'), ('six.moves', 'past.moves')]

    tree = ast.parse('import six')
    result = TestTransformer.transform(tree)
    assert isinstance(result.tree.body[0], ast.Try)
    assert isinstance(result.tree.body[0].body[0], ast.ImportFrom)
    assert result.tree.body[0].body[0].module == 'past'
    assert result.tree.body[0].body[0].names[0].name == 'six'


# Generated at 2022-06-12 03:38:39.508642
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    import_from = ast.ImportFrom(module='os',
                                 names=[ast.alias(name='path', asname='path'),
                                        ast.alias(name='stat', asname='stat')],
                                 level=0)

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('subprocess', 'subprocess32')]

    assert astor.to_source(ImportRewrite.transform(import_from)[0]) == """\
try:
    from os import path
    from os import stat
except ImportError:
    from os32 import path
    from os32 import stat

"""



# Generated at 2022-06-12 03:38:47.331033
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as _ast
    import astunparse as ap

    class A(BaseImportRewrite):
        rewrites = [('foo', 'bar')]


    class B(A):
        rewrites = [('bar', 'baz')]


    code = '''
from foo import b
from foo import a as a1
from foo import *
from foo.a.b.c import a, d
from foo.a.b.c import *
'''


    class Expected(ast.AST):
        _fields = ('body',)
        _attributes = ('body',)


    class Try(ast.AST):
        _fields = ('body', 'orelse', 'finalbody')
        _attributes = ('body', 'orelse', 'finalbody')

