

# Generated at 2022-06-12 03:29:04.370074
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ("xml", "etree")
        ]

    tree = ast.parse('''
    import xml.etree.ElementTree
    import xml.etree.ElementTrees as et
    import xml.sax
    
    def test():
        import xml.etree.ElementTree
        import xml.etree.ElementTrees as et
        import xml.sax
    ''')
    res = TestImportRewrite.transform(tree)
    assert res.tree_changed

    code = compile(res.tree, '<test>', 'exec')
    glob = {}
    exec(code, glob)

    assert "xml" not in glob
    assert "etree" in glob

# Generated at 2022-06-12 03:29:08.356548
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .snippets import import_foo
    module = import_foo.get_module()
    inst = BaseImportRewrite(module)
    inst.rewrites = [('foo', 'bar')]
    inst.visit(module)
    import_foo.expect_snippet(module)



# Generated at 2022-06-12 03:29:11.574816
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from .transformers import BaseImportRewrite
    BaseImportRewrite.rewrites = [('six', 'six.moves')]


# Generated at 2022-06-12 03:29:18.365683
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .unittest_data import (UNITTEST_IMPORT_FROM_BEFORE, UNITTEST_IMPORT_FROM_AFTER)

    class SimpleImportRewrite(BaseImportRewrite):
        rewrites = [("os", "os1")]

    tree = ast.parse(UNITTEST_IMPORT_FROM_BEFORE)
    result = SimpleImportRewrite.transform(tree)
    assert UNITTEST_IMPORT_FROM_AFTER == ast.unparse(result.tree)

# Generated at 2022-06-12 03:29:28.625305
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    rewrites = {
        "django.db.models.fields.CharField":
            "djng.db.models.fields.CharField",
        "django.contrib.postgres.fields.ArrayField":
            "djng.contrib.postgres.fields.ArrayField"}
    old_import_name = "django.db.models.fields.CharField"
    old_import = ast.Import(names=[
        ast.alias(name=old_import_name,
                  asname="CharField")])
    new_import_name = "djng.db.models.fields.CharField"
    new_import = ast.Import(
        names=[ast.alias(name=new_import_name,
                         asname="CharField")])

# Generated at 2022-06-12 03:29:33.842375
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = ast.parse('from urllib2 import urlopen')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('urllib2', 'urllib.request')]
    transformer.visit(tree)
    assert astor.to_source(tree) == 'import urllib.request\ntry:\n    from urllib2 import urlopen\nexcept ImportError:\n    from urllib.request import urlopen'


# Generated at 2022-06-12 03:29:43.532350
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..refactor import RefactoringTool

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse

    class Rewriter(BaseImportRewrite):
        rewrites = [('six', 'six-backport')]

        def visit_Module(self, node: ast.Module) -> ast.Module:
            return self.generic_visit(node)

    code = """
    import six

    six.moves.configparser
    """
    tree = parse(code)
    rt = RefactoringTool([Rewriter])
    rt.refactor_tree(tree)

# Generated at 2022-06-12 03:29:53.302075
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [
        ('xml.etree.ElementTree', 'lxml.etree'),
        ('xml.etree.ElementTree.fromstring', 'lxml.etree.fromstring'),
    ]

    transformed = ast.parse('''
    from xml.etree import ElementTree
    from xml.etree.ElementTree import fromstring
    from xml.etree import ElementTree as ET
    from xml.etree.ElementTree import fromstring as f
    ''')

    result = BaseImportRewrite(transformed).visit(transformed)

    assert isinstance(result, ast.Try)

    assert isinstance(result.body[0], ast.TryExcept)
    assert isinstance(result.body[0].body[0], ast.Import)

# Generated at 2022-06-12 03:30:02.829159
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    tree = ast.parse("""
import foo
""")

    tt = TestTransformer(tree)
    result = tt.visit_Import(tree.body[0])
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'bar'
    assert tt._tree_changed is True

    tree = ast.parse("""
import foo.baz
""")

    tt = TestTransformer(tree)
    result = tt.visit_Import(tree.body[0])
    assert isinstance(result, ast.Try)

# Generated at 2022-06-12 03:30:09.705959
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    code = """
    import mypkg.foo
    """
    transformed = """
    try:
        import mypkg.foo
    except ImportError:
        import mypkg.foo as foo
    """

    tree = ast.parse(code)
    class TestNodeTransformer(BaseImportRewrite):
        rewrites = [('mypkg.foo', 'mypkg.foo')]

    transformed_tree = TestNodeTransformer.transform(tree).tree
    assert ast.dump(transformed_tree) == transformed


# Generated at 2022-06-12 03:30:22.682652
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import astor

    class TestTransformer(BaseImportRewrite):

        rewrites = [
            ('foo.bar', 'spam.eggs')
        ]

    node = ast.Import(names=[ast.alias(name='foo.bar', asname=None)])
    transformer = TestTransformer(node)

    rewrote = transformer.visit_Import(node)

    code = astor.to_source(rewrote)

    expected = '''
try:
    import foo.bar
except ImportError:
    import spam.eggs
    '''

    assert code == expected


# Generated at 2022-06-12 03:30:32.033185
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'pathlib'), ('sys', 'os')]

    tree = ast.parse('import os')

    transformer = TestTransformer(tree)
    res = transformer.visit_Import(tree.body[0])

    assert isinstance(res, ast.Try)
    assert len(res.handlers) == 1
    assert isinstance(res.handlers[0], ast.ExceptHandler)
    assert isinstance(res.handlers[0].type, ast.Name)
    assert res.handlers[0].type.id == 'ImportError'
    assert len(res.finalbody) == 1
    assert isinstance(res.finalbody[0], ast.Import)
    assert len(res.finalbody[0].names) == 1

# Generated at 2022-06-12 03:30:40.295596
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    class SampleTransformer(BaseImportRewrite):
        rewrites=[('foo','bar')]
    output = astunparse.unparse(SampleTransformer.transform(ast.parse("import foo")).tree)
    assert output == 'try:\n    import bar\nexcept ImportError:\n    import foo'
    output = astunparse.unparse(SampleTransformer.transform(ast.parse("import foo.bar")).tree)
    assert output == 'try:\n    import bar.bar\nexcept ImportError:\n    import foo.bar'



# Generated at 2022-06-12 03:30:49.618050
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from importlib import import_module
    import sys

    class MyClass(BaseImportRewrite):
        rewrites = [
            ('six', 'importlib'),
            ('collections.abc', 'collections'),
            ('typing', 'importlib.abc')
        ]

    tree = ast.parse(
"""
from typing import List
import six
from six import get_function_globals
from collections.abc import Sized
from collections.abc import Callable
from typing import List, Optional
from typing import Set as S
from typing import Sequence as S, Tuple as T
"""
    )

    printed = astor.to_source(tree)

# Generated at 2022-06-12 03:30:59.629820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from . import unittests


# Generated at 2022-06-12 03:31:08.907706
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .sample_code import from_import_sample

    expected = from_import_sample.expected_from_import
    expected_globals = dict(from_import_sample.expected_from_import_globals)
    expected_rewrites = dict(from_import_sample.from_import_rewrites)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = expected_rewrites.items()

    tr = TestImportRewrite()
    tr.visit(from_import_sample.from_import_ast)
    assert tr._tree_changed is True
    code = compile(from_import_sample.from_import_ast,
                   '<string>',
                   mode='exec')
    exec(code, expected_globals)

# Generated at 2022-06-12 03:31:19.577640
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import textwrap
    body = ast.parse(textwrap.dedent("""\
        from pandas import DataFrame, Series
        from numpy import array as np_array
        from matplotlib import pylab as plt, pyplot as plt2
        from os.path import join as path_join, join_2
        from some_lib import *
        """))
    import_rewrites = [
        ('pandas', 'pandas1'),
        ('numpy', 'numpy1'),
        ('matplotlib.pyplot', 'matplotlib1.pyplot')
    ]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = import_rewrites  # type: ignore

    result = TestImportRewrite.transform(body)
    import_rewrite_module = import_rewrite.__

# Generated at 2022-06-12 03:31:25.759421
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test = "import my_module"

    class _Transfomer(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [
            ('my_module', 'my_rewrote')
        ]

    tree = ast.parse(test)
    _Transfomer.transform(tree)

    expected = """\
try:
    import my_module
except ImportError:
    import my_rewrote
"""
    assert ast.dump(tree) == expected



# Generated at 2022-06-12 03:31:36.702892
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast import parse
    from . import PREVENT_MATCHING_CONFIG

    PREVENT_MATCHING_CONFIG['rewrites'] = [('os.path', 'pathlib')]
    PREVENT_MATCHING_CONFIG['dependencies'] = []
    PREVENT_MATCHING_CONFIG['target'] = 'python-2'

    class BaseImportRewriteMock(BaseImportRewrite):
        rewrites = PREVENT_MATCHING_CONFIG['rewrites']
        dependencies = PREVENT_MATCHING_CONFIG['dependencies']
        target = PREVENT_MATCHING_CONFIG['target']

    tree = parse('import os.path')

    result = BaseImportRewriteMock.transform(tree)
    assert result.changed == True


# Generated at 2022-06-12 03:31:46.468436
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor as asrt
    import ast
    import os, sys, inspect
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    from typed_ast import ast3 as ast
    from ..transformers.base import BaseImportRewrite
    from ..types import CompilationTarget


    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYPY
        rewrites = [
            ('six', 'six')]

    tree = ast.parse('''
import six 
from six import binary_type, text_type, string_types, integer_types, class_types     
''')

    transformed_

# Generated at 2022-06-12 03:31:57.844892
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from astunparse import unparse

    node = ast.parse("from six.moves import urllib.parse as urlparse").body[0]

    tree = BaseImportRewrite.transform(node)
    assert unparse(node) == "from six.moves import urllib.parse as urlparse"
    assert unparse(tree) == """\
try:
    from six.moves import urllib.parse as urlparse
except ImportError:
    from urllib import parse as urlparse"""



# Generated at 2022-06-12 03:32:05.827399
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    code = """
    from app.utils.x import os
    """
    tree = ast.parse(code)
    expected_code = """
    try:
        from app.utils.x import os
    except ImportError:
        from app.utils.y import os
    """
    expected_tree = ast.parse(expected_code)
    BaseImportRewrite.rewrites = [('app.utils.x', 'app.utils.y')]
    result = BaseImportRewrite.transform(tree)
    assert result.tree == expected_tree
    assert result.changed
    assert result.dependencies == ['app.utils.y']


# Generated at 2022-06-12 03:32:11.574849
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astor import parse

    from ...utils.snippet import rewrite

    tree = parse('import collections')

    result = BaseImportRewrite.transform(tree)

    rewrote_tree = rewrite('try:\n    import collections\nexcept ImportError:\n    import part_collections')

    assert str(result.tree) == str(rewrote_tree)
    assert result.tree_changed
    assert result.dependencies == ['collections', 'part_collections']


# Generated at 2022-06-12 03:32:18.580726
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_list = ['pymongo']
    rewrites = [('pymongo', 'pymongo_mock')]

    for import_item in import_list:
        rewrote = BaseImportRewrite._replace_import(ast.Import(names=[ast.alias(name=import_item)]),
                                                    *rewrites[0])
        assert isinstance(rewrote, ast.Try)
        assert len(rewrote.handlers) == 1
        assert len(rewrote.body) == 1
        assert rewrote.body[0].names[0].name == import_item
        assert rewrote.handlers[0].type.id == 'ImportError'
        assert rewrote.handlers[0].body[0].names[0].name == rewrites[0][1]
        assert rewrote.finalbody == []



# Generated at 2022-06-12 03:32:26.762856
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..testutils.compiler import Compiler
    from ..testutils.transformer import transform_to_string
    from ..utils.name_storage import NameStorage
    from ..utils.snippet import snippet

    class TestRewrite(BaseImportRewrite):
        rewrites = [('random', 'secrets')]

    @snippet
    def code():
        import random

    tree = Compiler.compile(code.get())
    TestRewrite.transform(tree)
    with NameStorage():
        assert code.get() == transform_to_string(tree)



# Generated at 2022-06-12 03:32:37.340422
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import ast
    class Test(BaseImportRewrite):
        rewrites = [('collections', 'collections2')]
    module = ast.parse('''\
from collections import OrderedDict
from collections import deque
from collections2 import defaultdict
from collections2 import defaultdict as dd
from collections.abc import Generator
''')
    result = astunparse.unparse(Test.transform(module).tree)
    #print(result)

# Generated at 2022-06-12 03:32:47.420397
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    # Test on import from module.
    old_import_from = "from Crypto import Random"
    new_import_from = "from cryptography.hazmat.primitives.random import Random"
    expected = "try:\n    from Crypto import Random\nexcept ImportError:\n    from cryptography.hazmat.primitives.random import Random"

    tree = astor.parse_file(old_import_from)
    BaseImportRewrite(tree).visit_ImportFrom(tree.body[0])
    assert astor.to_source(tree) == expected

    # Test on import from module with as
    old_import_from = "from Crypto import Random as R"
    new_import_from = "from cryptography.hazmat.primitives.random import Random as R"

# Generated at 2022-06-12 03:32:55.479928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from six import PY2

    import sys
    print(sys.executable)

    target = 'gevent'
    test_case = 'import aiohttp'

    class MockTransformer(BaseImportRewrite):
        target = target
        rewrites = [('aiohttp', 'geventhttpclient.aiohttp')]

    if PY2:
        expected = dedent('''\
        try:
            import aiohttp
        except ImportError:
            import geventhttpclient.aiohttp as aiohttp
        ''')
    else:
        expected = test_case

    tree = parse(test_case)
    result = MockTransformer.transform(tree)
    assert expected == ast.unparse(result.tree)
    assert result.tree_changed

# Generated at 2022-06-12 03:33:05.193117
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class My(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    module = ast.Module(body=[
        ast.ImportFrom(module='previous',
                       names=[ast.alias(name='foo',
                                        asname=None)],
                       level=0)])

    result = My.transform(module)
    assert isinstance(result.tree.body[0], ast.Try)
    assert isinstance(result.tree.body[0].body[0].body[0], ast.ImportFrom)
    assert result.tree.body[0].body[0].body[0].module == 'current'
    assert result.tree.body[0].body[0].body[0].names[0].name == 'foo'

# Generated at 2022-06-12 03:33:09.056875
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Sample(BaseImportRewrite):
        rewrites = [
            ('os', 'posix'),
        ]

    source = """
import os
"""
    module = ast.parse(source)
    sample = Sample(module)
    result = sample.visit_Import(module.body[0])
    expected = import_rewrite.get_body(previous=ast.Import(names=[ast.alias(name="os")]),
                                       current=ast.Import(names=[ast.alias(name="posix")]))[0]
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 03:33:28.488189
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Sample(BaseImportRewrite):
        rewrites = [
            ('re', 'regex'),
            ('six', 'six'),
            ('six.moves', 'six')]

    code = '''
    import re
    import six.moves
    impor inspect
    import math as m
    '''

    # Regex module should be imported using try/except statement
    result = Utility.transfrom_code(Sample, code)
    assert 'try:\n    import regex as re\nexcept ImportError:' in result

    # Six module should be imported as is
    assert 'import six\n' in result

    # Six.moves should be imported as is
    assert 'import six.moves\n' in result

    # Inspect module should be imported as is
    assert 'import inspect\n' in result

    # Math module

# Generated at 2022-06-12 03:33:36.649456
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    code = """import module"""
    tree = ast.parse(code)
    stmt = tree.body[0]

    class RewriteImport(BaseImportRewrite):
        rewrites = [('module', 'rewrited_module')]
    result = RewriteImport.transform(tree)

    rewrited_code = """try:
    extend(module)
except ImportError:
    extend(rewrited_module)"""

    rewrited_tree = ast.parse(rewrited_code)
    assert str(result.tree.body[0]) == str(rewrited_tree.body[0])
    assert result.tree_changed


# Generated at 2022-06-12 03:33:46.650857
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Example of import rewrite."""
    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six.moves')
        ]
        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    # import six
    import_from = ast.parse("import six").body[0]
    assert isinstance(import_from, ast.Import)
    import_from = import_from.names[0].name
    assert isinstance(import_from, str)
    assert import_from == 'six'

    # from six import text_type
    import_from = ast.parse("from six import text_type").body[0]

# Generated at 2022-06-12 03:33:48.872647
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('__builtin__', 'builtins')]

    tree = astor.parse('''
    import __builtin__
    ''')

    result = TestTransformer.transform(tree)
    assert astor.to_source(result.tree) == '''
try:
    import __builtin__
except ImportError:
    import builtins
    '''



# Generated at 2022-06-12 03:33:59.242028
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    example_node = ast.parse(
        """
from base.module import name
from base.module2 import *
from base.module3 import *
from base.module4 import name as new_name
from base.module4 import name4, name4a
        """
    )
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('base.module', 'replaced.module'),
                    ('base.module2', 'replaced.module2'),
                    ('base.module4.name', 'replaced.module4.name')]

    # test
    inst = TestImportRewrite(example_node)
    result_tree = inst.visit(example_node)

    # check
    assert isinstance(result_tree, ast.Try)

# Generated at 2022-06-12 03:34:09.782447
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astor.code_gen import to_source

    import_rewrite.add_body(previous="foo", current="#")
    import_rewrite.add_body(previous="foo.bar", current="#", indent=4)

    import_fixture = """
import foo
import foo.bar
"""

    import_rewrote = """
try:
    import foo
except ImportError:
    extend("#")
try:
    import foo.bar
except ImportError:
    extend("#", indent=4)
"""

    import_rewrite.start_over()
    tree = ast.parse(import_fixture)
    BaseImportRewrite.rewrites = [('foo', '#')]
    BaseImportRewrite.transform(tree)
    assert to_source(tree) == import_rewrote


# Generated at 2022-06-12 03:34:18.990175
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..compat import ast_parse
    from ..transformation import BaseImportRewrite
    from . import BaseTest

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')]

    class Test(BaseTest):
        target = ''
        transformer = ImportRewrite

        def test_match(self):
            # type: () -> None
            tree = ast_parse('import foo')
            expected = 'try:\n    import foo\nexcept ImportError:\n    import bar'
            self.check_ast(tree, expected)

        def test_not_match(self):
            # type: () -> None
            tree = ast_parse('import foo1')
            expected = 'import foo1'

# Generated at 2022-06-12 03:34:28.331761
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Dummy(BaseImportRewrite):
        rewrites = [('email.header', 'email.headerregistry')]

    tree = ast.parse("""
        from email.header import *
        from email import header
        import email.header
    """)

    transformed = Dummy.transform(tree)
    assert transformed.changed

    expected = """
        try:
            from email.header import *
        except ImportError:
            from email.headerregistry import *
        try:
            from email import header
        except ImportError:
            from email import headerregistry as header
        try:
            import email.header
        except ImportError:
            import email.headerregistry
        """

    assert transformed.tree.__source == expected

# Generated at 2022-06-12 03:34:34.404738
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class Rewrite:
        rewrites = [('foo', 'bar')]

        def test(self, tree):
            tree = astor.parse(tree)
            inst = BaseImportRewrite(tree)
            inst.visit(tree)
            return astor.to_source(tree)
    Rewrite().test('import foo') == dedent("""\
    try:
        import foo
    except ImportError:
        import bar as foo""")



# Generated at 2022-06-12 03:34:40.509142
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import CompilationTarget
    from ..transforms.others import BaseImportRewrite

    class T(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [('os', 'new_os')]

    tree = ast.parse('from os import makedirs')
    T.transform(tree)

    assert ast.dump(tree) == '''\
Try(body=[
    ImportFrom(module='new_os', names=[alias(name='makedirs', asname=None)], level=0)], orelse=[], \
finalbody=[])'''



# Generated at 2022-06-12 03:35:14.256208
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import unittest.mock
    class BaseImportRewrite_visit_ImportTests(unittest.TestCase):
        def test_case_0(self):
            from typed_ast import ast3 as ast
            import unittest.mock
            from .base import BaseImportRewrite, BaseNodeTransformer, BaseTransformer
            class TestVal(BaseImportRewrite):
                rewrites = [('module', 'module2')]
                target = 'python-2'
                dependencies = []
                def __init__(self, tree):
                    self.tree = tree
                    self.tree_changed = False
                def _get_matched_rewrite(self, name):
                    if name is None:
                        return None

# Generated at 2022-06-12 03:35:23.327613
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # prepare
    import unittest
    from typed_ast._ast3 import parse

    class TestCase(unittest.TestCase):
        def test(self):
            self.assertEqual(
                BaseImportRewrite._get_replaced_import_from_part(
                    ast.ImportFrom(module='foo.bar', names=[ast.alias(name='baz', asname='B')], level=1),
                    ast.alias(name='baz', asname='B'),
                    {'foo.bar.baz': ('foo', 'bar')}).body,
                [(ast.ImportFrom(module='bar.bar', names=[ast.alias(name='baz', asname='B')], level=1))]
            )

# Generated at 2022-06-12 03:35:28.492765
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class SomeCustomTransformer(BaseImportRewrite):
        rewrites = [('mock', 'unittest.mock')]

    tree = ast.parse("import mock as magik")
    tree = SomeCustomTransformer.transform(tree).tree
    assert ast.dump(tree) == '''\
try:
    import mock as magik
except ImportError:
    import unittest.mock as magik
'''



# Generated at 2022-06-12 03:35:38.964388
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert_equals_ast(
        BaseImportRewrite().visit(ast.parse('import foo')),
        'import foo')

    assert_equals_ast(
        BaseImportRewrite().visit(ast.parse('import foo.bar')),
        'import foo.bar')

    assert_equals_ast(
        BaseImportRewrite().visit(ast.parse('import foo.bar as baz')),
        'import foo.bar as baz')

    assert_equals_ast(
        BaseImportRewrite(rewrites=[('foo', 'bar')])
            .visit(ast.parse('import foo.bar')),
        'try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')


# Generated at 2022-06-12 03:35:49.019035
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformer import BaseImportRewrite
    rewrites = [(from_, to) for from_, to in BaseImportRewrite.rewrites]
    rewrites.append(('snippet_test_1', 'snippet_test_2'))

    class Transform(BaseImportRewrite):
        rewrites = rewrites

    import_node = ast.parse('import snippet_test_1').body[0]

    assert Transform.transform(import_node).tree == \
        ast.parse('try: import snippet_test_1\nexcept ImportError: import snippet_test_2')

    import_node = ast.parse('import snippet_test_1.sub1').body[0]


# Generated at 2022-06-12 03:35:57.745775
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..config import Config
    from ..compiler import compile_string
    from ..utils.compat import StringIO

    filename = 'filename'
    s = 'import typing'
    config = Config(target=CompilationTarget.PYTHON27,
                    transformations=[BaseImportRewrite])
    tree = compile_string(s, filename=filename, config=config)
    output = StringIO()
    compile(tree, filename, 'exec', output.write)

    expected = '''
    import typing
    '''

    assert output.getvalue() == expected, '''
    expected:\n---\n{}---\ngot:\n---\n{}---\n'''.format(expected, output.getvalue())



# Generated at 2022-06-12 03:36:08.142614
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Namespace(tree=<_ast.Module object at 0x7f978d8e8cc0>, tree_changed=False, dependencies=[])
    assert (BaseImportRewrite.transform(ast.parse('import json')).tree ==
            ast.parse('import json'))

    # Namespace(tree=<_ast.Module object at 0x7f978d8e8cc0>, tree_changed=True, dependencies=['simplejson'])
    assert (BaseImportRewrite.transform(ast.parse('import json')).tree ==
            ast.parse('''\
try:
    import json
except ImportError:
    import simplejson'''))

    # Namespace(tree=<_ast.Module object at 0x7f978d8e8cc0>, tree_changed=True, dependencies=['simplejson'])

# Generated at 2022-06-12 03:36:15.515852
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_transformer import get_calls

    class RewrittenTransformer(BaseImportRewrite):
        rewrites = [('urlparse', 'urllib.parse')]

    tree = ast.parse('import urlparse')
    RewrittenTransformer.transform(tree)
    assert get_calls(tree) == ['import urllib.parse']

    tree = ast.parse('import urlparse')
    RewrittenTransformer.transform(tree)
    assert get_calls(tree) == ['import urllib.parse']



# Generated at 2022-06-12 03:36:24.360473
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as stdlib_ast
    from .utils import compare_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('dummy.bar', 'dummy.foo'),
            ('dummy.baz.spam', 'dummy.baz.eggs'),
        ]

    tree = stdlib_ast.parse("""\
from foo import *
from dummy.bar import spam
from dummy.bar.ham import egg
from dummy.baz.spam import bacon
from dummy.baz.spam.sausage import *
from dummy.baz.spam.eggs import *
""")


# Generated at 2022-06-12 03:36:34.817337
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import AST
    from typed_ast.transforms.imports import BaseImportRewrite
    import copy

    class Testvisit_ImportFrom(BaseImportRewrite):
        rewrites = [
            ('typed_ast.ast3', 'ast'),
            ('typed_ast.transforms', 'ast')]
        dependencies = ['typed_ast']

    # INSTANCE_NAME = 'INSTANCE_NAME'

    # test 1
    import_from_1 = ast.parse('from typed_ast.ast3 import FunctionDef'
                              ).body[0]  # type: ast.ImportFrom
    # ast.NodeVisitor().visit(import_from_1)
    import_from_2 = copy.deepcopy(import_from_1)

# Generated at 2022-06-12 03:37:27.617301
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_node = ast.parse('import foo').body[0]
    node_to_test = ImportRewrite.visit_Import(ImportRewrite(ast.AST()), import_node)
    assert node_to_test.body[0].body[0].value.func.id == 'extend'



# Generated at 2022-06-12 03:37:31.774127
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    tree = ast.Module([
        ast.Import([
            ast.alias(name='foo',
                      asname='f')
        ])])
    transformer = BaseImportRewrite([('foo', 'bar')])

    transformer.visit(tree)

    assert transformer._tree_changed
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Import)
    assert tree.body[0].body[0].names[0].name == 'bar'


# Generated at 2022-06-12 03:37:39.603115
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget, TransformationResult
    from ..utils.generate import ast_from_source
    from ..transform.import_rewrites import Python2PY3ImportRewrite
    
    code = """
import logging
import unittest2
"""
    expected_code = """
import logging
try:
    import unittest2
except ImportError:
    import unittest as unittest2
"""
    tree = ast_from_source(code)

    result = Python2PY3ImportRewrite.transform(tree)

    assert result.changed
    assert code != expected_code
    assert ast_from_source(expected_code).body == tree.body

# Generated at 2022-06-12 03:37:48.115254
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typing import cast
    from ..utils.ast_visitor import collect_nodes

    class TestTransformer(BaseImportRewrite):
        rewrites = [('test_io', 'test_io2')]

    tree = ast.parse('''
import test_io

test_io.test()
''')
    TestTransformer.transform(tree)

    imports = cast(List[ast.Import], collect_nodes(tree, ast.Import))
    assert len(imports) == 1
    assert isinstance(imports[0], ast.Try)
    assert len(imports[0].body) == 1
    assert isinstance(imports[0].body[0], ast.Import)
    assert imports[0].body[0].names[0].name == 'test_io'
    assert imports[0].handlers

# Generated at 2022-06-12 03:37:57.922744
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...tests.test_utils.random_code import generate_random_code

    rewrites = [
        ('python', 'python2'),
        ('math', 'math2'),
    ]
    code = """
    import python
    import python.foo as foo
    import math as m
    import math.foo
    import foo

    import python2
    import python2.foo as foo
    import math2 as m
    import math2.foo
    import foo2

    import python3 as python
    import python3.foo as foo
    """
    code = generate_random_code(code)

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse(code)
    new_tree = TestTransformer.transform(tree)[0]  # type: ignore
    new_

# Generated at 2022-06-12 03:38:07.316590
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    def do(line, from_, to):
        tr = RewriteTransformer({from_: to})
        node = ast.parse(line, mode='exec').body[0]
        res_node = tr.visit(node)
        return ast.dump(res_node)

    assert do('import foo', 'foo', 'bar') == \
        'Try(\n' \
        '  body=[[Import(names=[alias(name=bar, asname=None)])]],\n' \
        '  handlers=[ExceptHandler(type=None, name=None, body=[[Import(names=[alias(name=foo, asname=None)])]])],\n' \
        '  orelse=[],\n' \
        '  finalbody=[])'


# Generated at 2022-06-12 03:38:16.659151
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .transformers.six_transformer import SixTransformer
    from .transformers.common import ImportRewrite
    import astor

    tree = ast.parse('''
import typing
import django.utils.translation
import django.db.models.deletion
from django.db.models import ForeignKey
from typing import Any, TypeVar, Generic
from django.utils.translation import ugettext_lazy as _
from django.db.models.deletion import SET_NULL
''')
    import_rewrite_ctxs = [
        (SixTransformer, ImportRewrite),
        (ImportRewrite, SixTransformer),
        (ImportRewrite, ImportRewrite),
        (SixTransformer, SixTransformer)
    ]

# Generated at 2022-06-12 03:38:22.664922
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Bar(BaseImportRewrite):
        rewrites = [
            ('foo', 'new.foo')]

    # Rewrite
    node = ast.parse('import foo')
    new_node = Bar.transform(node).tree
    expected = 'try: from foo import *\nexcept ImportError: from new.foo import *'
    assert ast.dump(new_node) == expected

    # No rewrite
    node = ast.parse('import bar')
    new_node = Bar.transform(node).tree
    expected = 'import bar'
    assert ast.dump(new_node) == expected

    # No rewrite
    node = ast.parse('import foo.bar')
    new_node = Bar.transform(node).tree
    expected = 'import foo.bar'
    assert ast.dump(new_node) == expected



# Generated at 2022-06-12 03:38:31.185507
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock
    import pytest
    import sys
    import ast

    sys.modules['test.test_module'] = unittest.mock.Mock()

    class MockImportRewrite(BaseImportRewrite):
        rewrites = [('test.test_module', 'test.rewrite_module')]
    
    @pytest.fixture
    def mock_transformer():
        return MockImportRewrite(None)

    def test_import_rewrite(mock_transformer):
        node = ast.parse('import test.test_module').body[0]
        assert isinstance(mock_transformer.visit(node), ast.Try)


# Generated at 2022-06-12 03:38:40.651162
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast import parse_ast
    node = parse_ast("""
import foo
import foo as bar
""")
    assert node.body[0].names[0].name == 'foo'
    assert node.body[1].names[0].name == 'foo'
    assert node.body[1].names[0].asname == 'bar'

    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node_transformed = Transformer.transform(node).tree
    assert node_transformed.body[0].body[0].names[0].name == 'foo'
    assert node_transformed.body[1].body[0].names[0].name == 'bar'