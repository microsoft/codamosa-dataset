

# Generated at 2022-06-12 03:29:04.325497
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class A(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    x = ast.parse('import foo')
    result = A.transform(x)
    assert result.changed is True
    assert result.dependencies == ['foo', 'bar']
    assert result.tree.body[0] == import_rewrite.get_body(previous=ast.Import(names=[ast.alias(name='foo')]),
                                                          current=ast.Import(names=[ast.alias(name='bar')]))[0]

    # Test when no match
    x = ast.parse('import notfoo')
    result = A.transform(x)
    assert result.changed is False
    assert result.dependencies == []

# Generated at 2022-06-12 03:29:10.038245
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transform = BaseImportRewrite(None)
    import astor
    def test_case(import_from: ast.ImportFrom, expected_import_froms: ast.ImportFrom) -> None:
        code = astor.to_source(import_from)
        import_from.lineno = 1
        import_from.col_offset = 0

        transforms = BaseImportRewrite.transform(import_from)
        print(astor.to_source(transforms.tree))

        body = transforms.tree.body[0].body
        assert isinstance(body, ast.Try)
        for try_, expected in zip(body.body, expected_import_froms):
            expected.lineno = 1
            expected.col_offset = 0

            assert astor.to_source(try_) == astor.to_source(expected)

# Generated at 2022-06-12 03:29:19.905792
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # 1. Positive test - module is found and rewrite is done
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]
    code = 'import old_module'
    tree = ast.parse(code)
    visitor = TestTransformer(tree)
    visitor.visit_Import(tree.body[0])
    result = ast.dump(tree)
    expected = "Try(\nbody=[Import(names=[alias(name='new_module', asname='old_module')])],\n" \
               "handlers=[ExceptHandler(type=Name(id='ImportError', ctx=Load()), name='None', body=[])],\n" \
               "finalbody=[Import(names=[alias(name='old_module', asname='old_module')])])"


# Generated at 2022-06-12 03:29:30.347086
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import get_tree

    class Transformer(BaseImportRewrite):
        rewrites = [('http', 'requests')]

    tree = get_tree("import http\nimport http.client")
    tree = Transformer.transform(tree).tree
    assert isinstance(tree.body[0], ast.Try)  # import http rewrite

    tree = get_tree("import http.client")
    tree = Transformer.transform(tree).tree
    assert isinstance(tree.body[0], ast.Import)  # no rewrite

    tree = get_tree("import http.client as c")
    tree = Transformer.transform(tree).tree
    assert isinstance(tree.body[0], ast.Try)  # import http.client rewrite

    tree = get_tree("from http.client import HTTPConnection")

# Generated at 2022-06-12 03:29:39.507684
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..testing import assert_transformed

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    @assert_transformed(TestTransformer, 'from foo import baz')
    def test_from_foo_import_baz():
        import foo
        import foo.bar

    @assert_transformed(TestTransformer, 'from foo import (baz)')
    def test_from_foo_import_parentheses():
        from foo import (baz)

    @assert_transformed(TestTransformer, 'from foo.bar import baz')
    def test_from_foo_dot_bar_import_baz():
        import foo
        import foo.bar
        from foo.bar import baz


# Generated at 2022-06-12 03:29:44.114165
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    node = ast.parse('import x')
    obj = BaseImportRewrite(node)
    obj.rewrites = [('x', 'y')]
    result = obj.visit_Import(node.body[0])
    assert astor.to_source(result) == 'try:\n    import x\nexcept ImportError:\n    import y'



# Generated at 2022-06-12 03:29:54.070345
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformation import BaseImportRewrite
    from ..types import CompilationTarget, TransformationResult
    from ..utils.source import compile_source
    import types

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('queue', 'queue')]
        target = CompilationTarget.PYTHON2

    source = '''
    import queue, threading, time
    queue
    queue.Queue
    '''
    expected_source = '''
    try:
        import queue,threading
    except ImportError:
        import queue,threading

    queue
    queue.Queue
    '''
    tree = compile_source(source, mode='exec')
    result = ImportRewrite.transform(tree)
    assert result.success
    assert result.changed

# Generated at 2022-06-12 03:30:03.318426
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    import io

    input = ast.Import(names=[ast.alias(name='datetime', asname=None)])
    expected_output = ast.Try(body=[
        ast.Import(names=[ast.alias(name='datetime', asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='datetime', asname=None)])])],
        orelse=[],
        finalbody=[])

    class TestTransformer(BaseImportRewrite):
        target = '2to3'
        rewrites = [('datetime', 'dateutil.parser.parser')]

    actual_output = TestTrans

# Generated at 2022-06-12 03:30:10.971928
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_ast = ast.parse('from datetime import datetime, date')
    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = [('datetime', 'dateutil')]
    import_rewrite.visit(import_ast)
    assert set([i.asname for i in import_ast.body[0].body if isinstance(i, ast.ImportFrom)]) == {'datetime', 'date'}
    # this should raise an error, but doesn't
    # assert import_rewrite.deps == ['dateutil']

# Generated at 2022-06-12 03:30:11.840354
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

# Generated at 2022-06-12 03:30:27.786653
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class InheritedClass(BaseImportRewrite):
        rewrites = [(from_, to) for (from_, to) in [('concurrent', 'futures'), ('collections', 'collections.abc')]]  # noqa

    import_from_1_snippet = ast.parse('from a.b.c import d\n')
    import_from_2_snippet = ast.parse('from . import d\n')
    import_from_3_snippet = ast.parse('from a import b as c\n')
    import_from_4_snippet = ast.parse('from a.b import c as d\n')
    import_from_5_snippet = ast.parse('from a.b.c import d as e\n')

# Generated at 2022-06-12 03:30:38.082310
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('test', 'rewrite')]

    test_import = """
import test
"""

    tree = ast.parse(test_import)
    TestImportRewrite.transform(tree)
    assert """
try:
    import test
except ModuleNotFoundError:
    import rewrite
""" == ast.dump(tree)

    test_import = """
import test.test1 as test1
"""
    tree = ast.parse(test_import)
    TestImportRewrite.transform(tree)
    assert """
try:
    import test.test1 as test1
except ModuleNotFoundError:
    import rewrite.test1 as test1
""" == ast.dump(tree)

    test_import = """
import rewrite
"""

# Generated at 2022-06-12 03:30:45.430600
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    from ..utils.transformer import transform
    import os

    class Test(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'foo.bar2')
        ]

    for fixture in ('test1', 'test2', 'test3'):
        test_tree = parse(open(os.path.join('test_fixtures', 'test_import_rewrite', fixture), encoding='utf-8').read())
        expected = unparse(parse(open(os.path.join('test_fixtures', 'test_import_rewrite', fixture + '_expected'), encoding='utf-8').read()))
        res = transform(test_tree, [Test])
        assert len(res.transformed_trees) == 1


# Generated at 2022-06-12 03:30:56.470332
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.testing_utils import assert_source_equal, assert_transformed_example

    class Transformer(BaseImportRewrite):
        rewrites = [('six', 'six_custom')]

    data = [
        "from six import *",
        "from six import a,b,c",
        "from six.moves import a",
        "from six.moves import a,b,c",
        "from six.moves.a import b",
    ]


# Generated at 2022-06-12 03:31:04.890069
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewriteTest(BaseImportRewrite):
        rewrites = [('pytest.util', 'tbx.pytest.util')]

    result = ImportRewriteTest.transform(
        ast.parse('import pytest.util'))

    assert result.tree.body[0] == import_rewrite.get_body(previous=ast.Import(names=[
        ast.alias(name='pytest.util')]),  # type: ignore
                                          current=ast.Import(names=[
                                              ast.alias(name='tbx.pytest.util')]))[0]
    assert result.tree_changed



# Generated at 2022-06-12 03:31:12.021734
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites: List[Tuple[str, str]] = [('backports', 'six.moves')]

    tree = ast.parse('import backports.configparser')

    expected_tree = ast.parse('try:\n'
                              '    import backports.configparser\n'
                              'except ImportError:\n'
                              '    import six.moves.configparser')

    result = TestImportRewrite.transform(tree)

    assert result.tree == expected_tree
    assert result.changed is True
    assert result.dependencies == ['six']



# Generated at 2022-06-12 03:31:22.175809
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    from typed_ast.codegen import to_source
    from typed_ast.codegen import SourceGenerator

    import_rewrites = (
        (ast.Import(names=[ast.alias(name='rewrite_me', asname=None)]),
         ast.Try(
             body=[ast.Import(names=[ast.alias(name='rewrite_me', asname=None)])],
             handlers=[ast.ExceptHandler(name=None, type=None, body=[
                 ast.Import(names=[ast.alias(name='rewrote_me', asname='rewrote_me')])
             ])],
             orelse=[],
             finalbody=[])),
    )


# Generated at 2022-06-12 03:31:31.006844
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from astor.codegen import to_source
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import print_ast

    rewrites = (
        ('future.standard_library', 'builtins'),
    )

    class Test(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse('''
import future.standard_library.random.integers
''')

    expected_tree = ast.parse('''
try:
    import future.standard_library.random.integers
except ImportError:
    import builtins.random.integers
''')

    assert expected_tree == Test.transform(tree).tree


# Generated at 2022-06-12 03:31:41.994409
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as _ast
    import astunparse
    from typing import Dict
    from ..utils import convert
    
    # The below code is equivalent to the following code for typing.
    #
    # class TypingFoo():
    #     a = 1
    #
    #     def foo(self, a: int) -> int:
    #         return a + 1
    #
    # foo = TypingFoo()
    # foo.foo(3)
    #


# Generated at 2022-06-12 03:31:51.272386
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as pyast  # type: ignore
    import astunparse
    # Test if import is rewritten when it's imported from module
    sample = "from typing import List, Tuple"
    pytree = pyast.parse(sample)
    pyast.copy_location(pytree, pyast.parse(""))
    pyast.fix_missing_locations(pytree)
    rewrites = [("typing", "typed_ast")]
    transformer = BaseImportRewrite(pytree)
    transformer.rewrites = rewrites
    node = transformer.visit(pytree)
    result = astunparse.unparse(node)
    target = """
try:
    from typing import List, Tuple
except ImportError:
    from typed_ast import ast3 as ast
""".lstrip()
    assert result == target

# Generated at 2022-06-12 03:32:06.014384
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..testing.utils import SnippetExecutionTestCase, snippet_test_case
    from ..testing import stdlib_path

    def test_case(self, tree):
        result = BaseImportRewrite.transform(tree)
        self.assertTrue(result.changed)
        self.assertEqual(
            result.tree,
            snippet_test_case.format(
                import_rewrite="""
                import sys
                try:
                    from sys import *
                except ImportError:
                    from sys3 import *
                """))

    class TestCase(SnippetExecutionTestCase, unittest.TestCase):
        snippet = snippet_test_case.format(import_rewrite="""
            import sys
            from sys import *
        """)


# Generated at 2022-06-12 03:32:15.486989
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import os
    import sys
    # type: (...) -> typing.Union[typing.Optional[typing.List[ast.stmt]], ast.stmt]

    class ModuleTest(object):

        def method_stmt(self):
            """My doc string."""
            pass

        @property
        def method_stmt_property(self):
            pass

    class NestedModuleTest(object):

        class NestedModuleTest(object):
            pass

    class ModuleTest2(object):
        pass

    class TestClass(BaseImportRewrite):
        rewrites = [('test.module', 'test.module2')]

    source = ast.parse('import test.module')
    result = TestClass.transform(source)


# Generated at 2022-06-12 03:32:24.707120
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    node_to_test = ast.parse("from foo.bar.baz import q1, q2, q3\n")

    class Rewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo2.bar2')]

    node_transformer = Rewrite(node_to_test)
    node_transformer.visit(node_to_test)

    expected_result = "try:\n    from foo.bar.baz import q1, q2, q3\n" \
                      "except ImportError:\n    from foo2.bar2.baz import q1, q2, q3\n"

    assert astor.to_source(node_to_test) == expected_result

# Generated at 2022-06-12 03:32:31.399536
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class RewriteImport(BaseImportRewrite):
        rewrites = [('python_modernize', 'six')]

    node = ast.parse("import python_modernize")
    tree, changed, _ = RewriteImport.transform(node)
    expected = ast.parse(""" try:
        import python_modernize
    except ImportError:
        import six """)
    assert ast.dump(tree) == ast.dump(expected)
    assert changed


# Generated at 2022-06-12 03:32:39.363985
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('tests.rewrites.test_rewrites', 'test_rewrites')]


# Generated at 2022-06-12 03:32:48.832909
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    if sys.version_info < (3, 0):
        try:
            import mock
        except ImportError:
            raise SkipTest('mock is not installed')
    else:
        from unittest import mock

    import_node = ast.Import(names=[ast.alias(name='urllib', asname='')])
    tree = mock.Mock()
    base_import_rewrite = BaseImportRewrite(tree)

# Generated at 2022-06-12 03:32:56.663519
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestNodeTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    @snippet
    def some_function(a):
        import old

    assert TestNodeTransformer.transform(some_function.ast).tree == some_function.ast  # type: ignore

    @snippet
    def some_function(a):
        import new

    assert TestNodeTransformer.transform(some_function.ast).tree == some_function.ast  # type: ignore

    @snippet
    def some_function(a):
        import old

    result = TestNodeTransformer.transform(some_function.ast).tree  # type: ignore
    assert result == import_rewrite.ast  # type: ignore

    @snippet
    def some_function(a):
        import old.other

# Generated at 2022-06-12 03:33:01.773080
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    expected = ast.parse('''
    try:
        import foo
    except ImportError:
        import bar
    ''')
    assert TestTransformer.transform(tree).tree == expected



# Generated at 2022-06-12 03:33:09.211029
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransform(BaseImportRewrite):
        aliases = [
            ('a.b.c', 'a.b.d'),
            ('a.b.e', 'a.b.f'),
            ('a.g', 'a.h')
        ]
        rewrites = [(alias[0].split('.')[0], alias[1].split('.')[0]) for alias in aliases]


# Generated at 2022-06-12 03:33:17.978624
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.parse import parse
    import os
    import sys
    import subprocess

    def pretty(output: bytes) -> str:
        return subprocess.Popen(['astpretty'],
                                stdout=subprocess.PIPE,
                                stdin=subprocess.PIPE).communicate(output)[0]

    rewrites = [
        ('_compat', '_compat_mock'),
        ('_compat.names', '_compat_mock.names'),
        ('_compat.func_name', '_compat_mock.func_name'),
        ('_compat.imp', '_compat_mock.imp'),
    ]

    class RewriteTest(BaseImportRewrite):
        rewrites = rewrites


# Generated at 2022-06-12 03:33:41.118406
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class RewriteImport(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six.moves'),
            ('ipaddress', 'ipaddress')]


    import_from = ast.ImportFrom(module='six.moves', names=[ast.alias(name='map', asname='map')], level=0)
    transformed = RewriteImport.transform(import_from)
    assert isinstance(transformed.tree, ast.Try)
    assert isinstance(transformed.tree.body[0], ast.ImportFrom)
    assert transformed.tree.body[0].module == 'six.moves'
    assert transformed.tree.body[0].names[0].name == 'map'
    assert transformed.tree.body[0].names[0].asname == 'map'


# Generated at 2022-06-12 03:33:51.074970
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    tree = ast.parse('from lxml import etree')
    transformer = BaseImportRewrite()
    transformer.rewrites = [('lxml', 'newxml')]
    result = transformer.visit_ImportFrom(tree.body[0])
    assert type(result) is ast.Try
    assert 'from newxml import etree' == astor.to_source(result.body).strip()
    assert type(result.handlers[0].type) is ast.Name
    assert 'ImportError' == astor.to_source(result.handlers[0].type).strip()
    assert type(result.handlers[0].body[0]) is ast.ImportFrom
    assert 'from lxml import etree' == astor.to_source(result.handlers[0].body[0]).strip

# Generated at 2022-06-12 03:33:58.535297
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...test_utils import parse

    tree = parse('import example')

    class Transformer(BaseImportRewrite):
        rewrites = [('example', 'rewrite')]

    result = Transformer.transform(tree)
    assert result.tree.body[0] == import_rewrite(
        previous=ast.Import(names=[ast.alias(name='example', asname='example')]),
        current=ast.Import(names=[ast.alias(name='rewrite', asname='rewrite')]),
    )
    assert result.tree_changed



# Generated at 2022-06-12 03:34:05.398730
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse('''
from foo.bar import *
from foo import baz
''').body[0]
    trans = BaseImportRewrite([('foo.bar', 'baz.bar')])
    trans.visit(node)
    assert ast.dump(node) == '''
try:
    from foo.bar import *
except ImportError:
    from baz.bar import *
try:
    from foo import baz
except ImportError:
    from baz import baz
'''



# Generated at 2022-06-12 03:34:14.397630
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Rewrite import from module
    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'path')]

        def __init__(self):
            tree = ast.parse('''
import os
from os import *
from os.path import dirname, join
''')
            super().__init__(tree)


    tree, _, _ = TestTransformer.transform(None)
    expected = '''\
try:
  import os
  from os import *
except ImportError:
  from path import *
try:
  from os.path import dirname, join
except ImportError:
  from path.path import dirname, join
'''
    assert ast.dump(tree) == expected

    # Rewrite import

# Generated at 2022-06-12 03:34:24.909667
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    class TestRewriter(BaseImportRewrite):
        rewrites = [('os', 'typed_ast_test')]
        def visit_Import(self, node: ast3.Import) -> Union[ast3.Import, ast3.Try]:
            return super().visit_Import(node)
    # Test rewrite via import
    tree = ast3.parse('import os')
    TestRewriter.transform(tree)

# Generated at 2022-06-12 03:34:32.306994
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        target = 'py26'
        rewrites = [('six.moves', 'six.moves.y')]

    tree = ast.parse('import six.moves.x, six.moves.y')
    TestTransformer.transform(tree).tree

    assert ast.dump(tree) == dedent("""
        try:
            import six.moves.x, six.moves.y
        except ImportError:
            import six.moves.y
    """).lstrip()



# Generated at 2022-06-12 03:34:38.944744
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .six import get_tree

    tree = get_tree()

    class Transformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

        def visit_Assign(self, node: ast.Assign) -> Union[ast.Assign, ast.Try]:
            self._tree_changed = True
            return super(self.__class__, self).visit_Assign(node)

    transformer = Transformer(tree)
    transformer.visit(tree)

    source = """
import six
from six import moves
from six.moves import classmro
from six.moves import SimpleCookie

six.integer_types = classmro
six.print_ = moves.print_
SimpleCookie = moves.SimpleCookie
"""

    assert ast.dump(transformer._tree)

# Generated at 2022-06-12 03:34:46.529517
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class BaseImportRewriteSubclass(BaseImportRewrite):
        rewrites = [
            ('some', 'other'),
        ]

    code = '''
from some.a import A
import some.b
import another
from some import c'''

    target_code = '''
from other.a import A
try:
    import some.b
except ImportError:
    import other.b
import another
from other import c'''

    tree = ast.parse(code)
    result = BaseImportRewriteSubclass.transform(tree)

    assert astor.to_source(result.tree) == target_code.strip()
    assert result.changed is True


# Generated at 2022-06-12 03:34:54.250242
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class Test(BaseImportRewrite):
        rewrites = [
            ('xml.etree.ElementTree', 'xml.etree.cElementTree'),
            ('xml.etree.ElementTree.Element', 'xml.etree.cElementTree.Element'),
            ('xml.etree.ElementTree.ElementTree',
             'xml.etree.cElementTree.ElementTree')
        ]

    tree = ast.parse(textwrap.dedent('''
        from xml.etree.ElementTree import Element, ElementTree
        from xml.etree.ElementTree import QName, SubElement, fromstring
        from qwe.xml.etree.ElementTree import Element, SubElement
    '''))
    Test().visit(tree)
    result = astor.to_source(tree)

# Generated at 2022-06-12 03:35:24.953837
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import a")
    BaseImportRewrite.rewrites = [("a", "b")]
    result = BaseImportRewrite.transform(tree)

    tree.body[0]
    assert isinstance(tree.body[0], ast.Import)
    assert tree.body[0].names[0].name == "a"

    assert isinstance(result.tree.body[0], ast.Try)
    assert len(result.tree.body[0].body) == 1
    assert isinstance(result.tree.body[0].body[0], ast.Import)
    assert result.tree.body[0].body[0].names[0].name == "b"
    assert len(result.tree.body[0].orelse) == 1

# Generated at 2022-06-12 03:35:34.932878
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..builtins import BUILTINS

    code = '''
from foo import bar
from foo.bar import baz
from foo.bar import baz as qux
from foo import *
    '''

    class TestClass(BaseImportRewrite):
        rewrites = BUILTINS

    tree = ast.parse(code)
    new_tree = TestClass.transform(tree)

# Generated at 2022-06-12 03:35:45.606124
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..testing import TemplatedTestCase

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    with TemplatedTestCase() as test:
        test.assertTemplatesEqual(TestTransformer,
                                  '''
                                  import foo
                                  ''',
                                  '''
                                  try:
                                      import foo as foo
                                  except ImportError:
                                      import bar as foo
                                  ''')

        test.assertTemplatesEqual(TestTransformer,
                                  '''
                                  import foo.baz
                                  ''',
                                  '''
                                  try:
                                      import foo.baz as baz
                                  except ImportError:
                                      import bar.baz as baz
                                  ''')


# Generated at 2022-06-12 03:35:50.194919
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from a import b, c')
    class TestTransformer(BaseImportRewrite):
        rewrites = [('a.c', 'b.d')]

    transformer = TestTransformer(tree)
    node = transformer.visit(tree)
    assert(node.body[0].orelse[0].body[0].body[0].names[0].name == 'b.d')


# Generated at 2022-06-12 03:36:00.016206
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:36:10.371383
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from .models import TransformCase

    class MyTransformer(BaseImportRewrite):
        rewrites = [
            ('typing', 'typing_extensions'),
            ('foo.bar', 'foo.baz'),
            ('foo.baz', 'foo_baz'),
            ('bar.foo', 'baz.foo'),
            ('bar.baz', 'baz.baz'),
        ]

    def test(transform_case: TransformCase) -> None:
        visitor = MyTransformer(ast.parse(transform_case.source))
        result = visitor.visit_Import(transform_case.node)
        assert result == ast.parse(transform_case.expected).body[0]


# Generated at 2022-06-12 03:36:21.357745
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    class TestClass(BaseImportRewrite):
        rewrites = [
            ('six.moves.urllib.parse', 'urllib.parse')
        ]

    def test_rewrite_import_from_names(expected, imports):
        tree = ast.parse(imports)

        tree = TestClass.transform(tree)

        assert astunparse.unparse(tree) == expected

    test_rewrite_import_from_names(
        expected="""try:\n""",
        imports="""from six.moves.urllib.parse import urljoin"""
    )


# Generated at 2022-06-12 03:36:30.585530
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node_ast = ast.parse("import a")
    class Test(BaseImportRewrite):
        rewrites = [("a", "b")]
    Test().visit(node_ast)
    assert node_ast.body[0].body[0].handlers[0].name == 'ModuleNotFoundError'
    assert isinstance(node_ast.body[0].body[0].handlers[0].type, ast.Name)
    assert node_ast.body[0].body[0].handlers[0].type.id == 'ModuleNotFoundError'
    assert node_ast.body[0].body[0].handlers[0].body[1].value.args[0].s == 'a'


# Generated at 2022-06-12 03:36:36.839466
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astor import dump
    
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'foo')]
        target = '<>'

    source = '''
    import six
    '''
    expected = '''
    try:
        import six
    except ImportError:
        import foo
    '''
    tree = ast.parse(source)
    TestTransformer.transform(tree)
    result = dump(tree)

    assert expected == result



# Generated at 2022-06-12 03:36:41.531739
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .conftest import get_example_tree

    tree = get_example_tree()

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six2')]

    result = TestImportRewrite.transform(tree)
    assert result == TransformationResult(tree, True, ['six2'])



# Generated at 2022-06-12 03:37:29.173233
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import fake
    class FakeImportRewrite(BaseImportRewrite):
        rewrites = [('fake1', 'fake2')]

    fake_ast = ast.parse(fake, mode='exec')
    fake_ast_rewritten = FakeImportRewrite.transform(fake_ast)[0]
    assert fake_ast != fake_ast_rewritten



# Generated at 2022-06-12 03:37:37.975981
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [('from', 'to')]

    node1 = ast.ImportFrom(
        module='from_module',
        names=[ast.alias(name='from_alias1')],
        level=0)

    node2 = ast.ImportFrom(
        module='from_module',
        names=[ast.alias(name='from_alias2')],
        level=0)

    node3 = ast.ImportFrom(
        module='from_module',
        names=[ast.alias(name='from_alias3')],
        level=0)

    node4 = ast.ImportFrom(
        module='from_module',
        names=[ast.alias(name='from_alias4')],
        level=0)


# Generated at 2022-06-12 03:37:47.139442
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..compilers import BasePythonCompiler
    from ..compilers.python import SUPPORTS_PYTHON_35, NOT_SUPPORTS_PYTHON_35

    @BasePythonCompiler.register_transformer
    class TestTransformer(BaseImportRewrite):
        target = NOT_SUPPORTS_PYTHON_35
        rewrites = [('from_', 'to')]

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return super(TestTransformer, cls).transform(tree)


# Generated at 2022-06-12 03:37:56.699372
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class FirstTryImportRewrite(BaseImportRewrite):
        rewrites = [
            ('python_snippets.snippets', 'python_snippets.tests.snippets'),
            ('python_snippets.utils.snippet', 'python_snippets.tests.snippets.snippet')
        ]

    tree = ast.parse("from python_snippets.snippets import snippet, extend")
    FirstTryImportRewrite.transform(tree)

    expected_tree = ast.parse("from python_snippets.tests.snippets import snippet, extend")
    assert ast.dump(tree) == ast.dump(expected_tree), tree

    tree = ast.parse("from python_snippets.snippets.snippet import extend")
    FirstTryImportRewrite.transform(tree)

# Generated at 2022-06-12 03:38:02.904594
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    tree = ast.parse("""
import os
import sys

sys.exit()
    """)

    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [
        ('os', 'pathlib')]
    transformer.visit(tree)
    result = astor.to_source(tree)

    expected_result = """try:
    import os
except ImportError:
    import pathlib as os
sys.exit()
    """

    assert result == expected_result



# Generated at 2022-06-12 03:38:05.727051
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import run_transformer_test_on_class
    run_transformer_test_on_class(BaseImportRewrite,
                                  'tests/fixtures/import_rewrite/visit_Import')


# Generated at 2022-06-12 03:38:10.383198
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert str(BaseImportRewrite().visit_ImportFrom(
        ast.parse('from mockito import mockito, when').body[0])) == \
        'try:\n' \
        '    from unittest.mock import mockito, when\n' \
        'except ImportError:\n' \
        '    from mock import mockito, when\n'



# Generated at 2022-06-12 03:38:19.125082
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_ = ast.Import(names=[
        ast.alias(name='old_module'),
        ast.alias(name='old_module.submod', asname='sub')])
    rewrites = [
        ('old_module', 'new_module'),
    ]

    transformed_tree = BaseImportRewrite.transform(import_)
    assert transformed_tree.changed

    import_rewrite_body = import_rewrite.get_body(previous=import_,  # type: ignore
                                                  current=ast.Import(                                                      
                                                      names=[ast.alias(name='new_module', asname=None)]))[0]
    assert isinstance(transformed_tree.tree, ast.Try)
    assert transformed_tree.tree.body[0] == import_rewrite_body



# Generated at 2022-06-12 03:38:26.819824
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import_node = ast.parse('import foo').body[0]
    import_node_as = ast.parse('import foo as bar').body[0]

    class T(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    res_module, res_module_as = T.transform(import_node)

    assert res_module == ast.parse(
    '''
    try:
        import foo
    except ImportError:
        import bar
    '''
    ).body[0]
    assert res_module_as == ast.parse(
    '''
    try:
        import foo as bar
    except ImportError:
        import bar as bar
    '''
    ).body[0]



# Generated at 2022-06-12 03:38:34.846820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('''
import pkg.a
from pkg.b import *
from pkg.c import a
''')

    class Rewrite(BaseImportRewrite):
        rewrites = [('pkg', 'pkg_rewrite')]

    actual = Rewrite.transform(tree).tree
    expected = ast.parse('''
import pkg_rewrite.a
try:
    from pkg.b import *
except ImportError:
    from pkg_rewrite.b import *
try:
    from pkg.c import a
except ImportError:
    from pkg_rewrite.c import a
''')

    assert ast.dump(actual) == ast.dump(expected)