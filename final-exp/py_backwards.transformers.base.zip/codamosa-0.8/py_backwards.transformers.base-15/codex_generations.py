

# Generated at 2022-06-12 03:29:07.704703
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_utils import compile_snippet
    from ..utils import ast_dump, source_dump

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    snippet_1 = '''
    from six.moves import http_cookies
    '''
    snippet_2 = '''
    from six.moves import http_cookies as c

    c.SimpleCookie()
    '''
    snippet_3 = '''
    from six.moves import http_cookies, http_cookies as c

    c.SimpleCookie()
    '''
    snippet_4 = '''
    from six.moves import *

    c.SimpleCookie()
    '''

# Generated at 2022-06-12 03:29:17.904491
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse
    from ast import parse

    d = dict()

    old_module = '_thread'
    new_module = '_threading'
    old_module_name = 'Thread'
    new_module_name = 'Threading'

    class TestImportFrom(BaseImportRewrite):
        rewrites = [(old_module, new_module)]


# Generated at 2022-06-12 03:29:28.000097
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Imports only for test
    import os
    import sys

    from .codegenerator import CodeGenerator
    from .imports import RewriteImportedModule
    from .transformers import BaseImportRewrite

    node = ast.parse('from os import path')
    rewriter = RewriteImportedModule(node)
    tree = BaseImportRewrite.visit(rewriter, node)
    code = CodeGenerator(tree).code()
    assert code == """try:
    from os import path
except ImportError:
    from os import path"""

    node = ast.parse('import os')
    rewriter = RewriteImportedModule(node)
    tree = BaseImportRewrite.visit(rewriter, node)
    code = CodeGenerator(tree).code()

# Generated at 2022-06-12 03:29:33.471145
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module="datetime",
                                 names=[ast.alias(name="datetime",
                                                  asname="datetime")])
    from_ = "datetime"
    to = "time"

    transformer = BaseImportRewrite()
    transformer.rewrites = [(from_, to)]
    node = transformer.visit(import_from)
    assert node.body[0].value.module == to
    assert node.body[1].value.module == to



# Generated at 2022-06-12 03:29:43.170805
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from ..utils import dump
    import_from = ast3.parse('''
from typing import (
    TypeVar,
    Generic,
    NewType,
    Callable,
    Tuple,
    Union,
    Optional,
    cast,
    Type,
    Any,
    Dict,
    Set,
    List,
)''')
    class T(BaseImportRewrite):
        rewrites = [('typing', '_typing')]

# Generated at 2022-06-12 03:29:53.078033
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transforms.__tests_helpers__ import assert_transformation_result, assert_ast_structure_equal

    expected = [
        ast.Import(names=[
            ast.alias(name='b', asname=None)
        ]),
        ast.Try(body=[
            ast.Import(names=[
                ast.alias(name='b', asname=None)
            ])],
            handlers=[
                ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                  name=None,
                                  body=[
                    ast.Import(names=[
                        ast.alias(name='a', asname=None)
                    ])
                ])
            ],
            orelse=[],
            finalbody=[])
    ]
    input_ast = expected[0]
    assert_

# Generated at 2022-06-12 03:30:02.660352
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    rewrite_1 = dict(from_='requests.api', to='requests')
    rewrite_2 = dict(from_='requests.utils', to='requests')

# Generated at 2022-06-12 03:30:08.917931
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Foo(BaseImportRewrite):
        rewrites = [('bar', 'quux')]

    result = Foo.transform(ast.parse('import bar'))

    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'bar'
    assert result.tree.body[0].body[0].body[0].finalbody[0].value.names[0].name == 'quux'



# Generated at 2022-06-12 03:30:19.115925
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [
            ('tests.test_data.legacy', 'tests.data.legacy'),
        ]

    node = ast.Import(names=[
        ast.alias(name='tests.test_data.legacy',
                  asname='legacy'),
    ])

    instance = Test(node)

    result = instance.visit_Import(node)

# Generated at 2022-06-12 03:30:29.142966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
from six.moves import builtins
import six.moves.map
from six.moves.queue import LifoQueue, Queue
from threading import Thread, Event
from six.moves import socketserver, sockets
from six.moves.http_client import (
    HTTPConnection as _HTTPConnection,
    OK as _OK,
    _UNKNOWN,
    responses
)
""")
    rewrites = ('six.moves', 'six.moves.urllib')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [rewrites]
    transformer.visit(tree)

# Generated at 2022-06-12 03:30:42.952837
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('from_module_name', 'to_module_name')]

    def check_rewrite(src):
        importlib.invalidate_caches()
        expected_src = textwrap.dedent(src)
        node = ast.parse(textwrap.dedent(src))
        result = ImportRewrite.transform(node)
        if result.changed:
            src = astor.to_source(node)
            assert src == expected_src
            assert compile(src, '<ast>', 'exec') is not None
        else:
            assert src == expected_src

    yield check_rewrite, """\
        import from_module_name"""

    yield check_rewrite, """\
        import from_module_name as name"""

    yield check

# Generated at 2022-06-12 03:30:53.525045
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Dummy:
        pass

    def get_ast(source):
        node = ast.parse(source)
        node.body[0] = Dummy()
        return node

    assert BaseImportRewrite(None).visit_ImportFrom(get_ast('from test import nb')) is None
    assert BaseImportRewrite(None).visit_ImportFrom(get_ast('from os import path')) is None
    assert BaseImportRewrite(None).visit_ImportFrom(get_ast('from os.path import join')) is None

    class Rewriter(BaseImportRewrite):
        rewrites = [
            ('os', 'posixpath'),
            ('os.path', 'posixpath'),
        ]

    assert type(Rewriter(None).visit_ImportFrom(get_ast('from os import path')))

# Generated at 2022-06-12 03:31:02.039262
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typing as t
    import six as s
    import six.moves.configparser as c

    class MockBaseImportRewrite(BaseImportRewrite):
        def _replace_import_from_module(self, node, from_, to):
            return node

        def _replace_import_from_names(self, node, names_to_replace):
            return node

    # Mock rewriteing module
    class MockModule(ast.Module):
        pass

    # Mock import from statement
    class MockImportFrom(ast.ImportFrom):
        def __init__(self, module, names, level=0):
            self.module = module
            self.names = names
            self.level = level


# Generated at 2022-06-12 03:31:09.817582
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import enum
    from enum import IntEnum
    from enum import IntFlag
    from enum import unique

    @unique
    class A(enum.Enum):
        a = 1

    @unique
    class B(IntEnum):
        b = 1

    @unique
    class C(IntFlag):
        c = 1

    class D(BaseImportRewrite):
        rewrites = [
            ('enum', 'aenum')]

    tree = ast.parse('''
    import enum
    import enum as e

    import enum.IntEnum
    import enum.IntEnum as i

    import enum.IntFlag
    import enum.IntFlag as f

    import enum.unique as u

    @unique
    class A(enum.Enum):
        a = 1
    ''')


# Generated at 2022-06-12 03:31:20.556384
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('foo.bar', 'bar')]  # type: List[Tuple[str, str]]
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = rewrites


# Generated at 2022-06-12 03:31:30.224671
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import copy
    import re

    from django_polyfield.transformation import BaseImportRewrite

    class ModuleImportTransformer(BaseImportRewrite):
        rewrites = [('django_polyfield', 'django_polyfield_test')]


# Generated at 2022-06-12 03:31:39.133180
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_stmt_str = 'import os'
    import_stmt = ast.parse(import_stmt_str).body[0]  # type: ast.Import
    rewrote_stmt = ast.parse(
        'try:\n\timport os\nexcept ImportError:\n\tfrom os import path').body[0]  # type: ast.Try

    rewrites = [
        ('os', 'os.path'),
    ]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    assert TestImportRewrite().visit(import_stmt) == rewrote_stmt



# Generated at 2022-06-12 03:31:45.510690
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Sub(BaseImportRewrite):
        rewrites = [
            ('unittest.mock', 'mock'),
        ]

    o = ast.parse('import unittest.mock as mt')

    class Dummy(ast.NodeVisitor):
        pass

    Dummy().visit(o)
    new = Sub.transform(o).ast

    try:
        extend(new)
    except ImportError:
        pass
    else:
        assert False, 'import failed'



# Generated at 2022-06-12 03:31:54.718604
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astor
    source = '''
from foo.bar import baz
import foo.bar as baz
from foo.bar import *
    '''
    tree = ast.parse(source)
    class Test(BaseImportRewrite):
        rewrites = [('foo.bar', 'a.b.c')] #type: List[Tuple[str, str]]
    result = Test.transform(tree)
    source = '''
try:
    from foo.bar import baz
except ImportError:
    from a.b.c import baz
import foo.bar as baz
try:
    from foo.bar import *
except ImportError:
    from a.b.c import *
    '''
    assert astor.to_source(result) == source



# Generated at 2022-06-12 03:32:04.848601
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astroid import builder
    from astroid.exceptions import InferenceError
    from ..utils.testing import assert_equal_asts
    import ast

    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    test_cases = [
        # Case 1.
        {
            'in': 'import foo',
            'out': '''try:
    import foo
except ImportError:
    import bar
'''
        },
        # Case 2.
        {
            'in': 'import foo.bar',
            'out': '''try:
    import foo.bar
except ImportError:
    import bar.bar
'''
        },
    ]

    for test_case in test_cases:
        in_tree = ast.parse(test_case['in'])
       

# Generated at 2022-06-12 03:32:16.421649
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'bar.baz')]

    tree = ast.parse('import foo.bar')
    r = ImportRewrite.transform(tree)
    assert r.modified

    assert ast.dump(r.tree) == \
        "Module(body=[Try(body=[Import(names=[alias(name='bar.baz', asname='bar')])], " \
        "handlers=[ImportError()], orelse=[Import(names=[alias(name='foo.bar', asname='bar')])])])"



# Generated at 2022-06-12 03:32:27.439691
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestClass(BaseImportRewrite):
        rewrites = [
            ('rewritten_module0', 'rewritten_module1'),
            ('rewritten_module0.rewritten_module0', 'rewritten_module1.rewritten_module1')]

    tree = ast.parse('''
from rewritten_module0 import alias0
''')

    expected = ast.parse('''
try:
    from rewritten_module0 import alias0
except ImportError:
    from rewritten_module1 import alias0
''')

    inst = TestClass(tree)
    result = inst.visit(tree)
    assert ast.dump(result) == ast.dump(expected)

    tree = ast.parse('''
from rewritten_module0 import alias0 as alias1
''')


# Generated at 2022-06-12 03:32:37.881141
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..codegen import to_source
    from ..parser import parse

    class Rewriter(BaseImportRewrite):
        rewrites = [('six', 'six_')]

    class Test(unittest.TestCase):     
        def test_rewrite(self):
            tree = parse('import six')
            Transformer = Rewriter.transform(tree)
            self.assertEqual(to_source(Transformer.tree).strip(), 'try:\n    import six_ as six\nexcept ImportError:\n    import six')
        
        def test_no_rewrite(self):
            tree = parse('import six.moves')
            Transformer = Rewriter.transform(tree)
            self.assertEqual(to_source(Transformer.tree).strip(), 'import six.moves')
        


# Generated at 2022-06-12 03:32:45.105764
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from .transform import BaseImportRewrite
    ast_tree = ast.parse('from old_module import Name\nprint(Name)')
    tree = BaseImportRewrite.transform(ast_tree)
    assert tree.tree.body[0].body[0].value.args[0].s == 'Name'
    assert tree.tree.body[0].body[0].value.args[0].s == 'Name'
    assert tree.tree.body[1].names[0].name == 'print'

# Generated at 2022-06-12 03:32:52.493622
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from typed_ast.ast3 import Import, alias, Name, Try
    from typing import Tuple, List
    from typed_ast.ast3 import TryExcept

    class TestTransformer(BaseImportRewrite):
        rewrites = [('future', 'past')]

    old_import = Import(names=[alias(name='future', asname=None)])
    rewrote = Import(names=[alias(name='past', asname=None)])

    tf = TestTransformer(None)
    rewrote_import = tf.visit_Import(old_import)  # type: ast3.TryExcept
    assert isinstance(rewrote_import, TryExcept)

    try_block = rewrote_import.body[0]  # type: List[Try]

# Generated at 2022-06-12 03:33:02.427717
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'A')]

        def generic_visit(self, node):
            return node

    import_body = ast.Import(names=[ast.alias(name='a', asname='a')])
    tree = ast.parse('''a = 1\nimport a''')

    tree = TestBaseImportRewrite.transform(tree).tree
    assert tree.body[1] == import_body


# Generated at 2022-06-12 03:33:09.360144
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [(r'future', r'past')]
    import_from_a = ast.ImportFrom(module='future.stdlib.simple',
                              names=[ast.alias(name='http',
                                               asname=None)],
                              level=0)
    result = ImportRewrite.transform(import_from_a)
    import_from_b = [ast.ImportFrom(module='past.stdlib.simple',
                              names=[ast.alias(name='http',
                                               asname=None)],
                              level=0)]

# Generated at 2022-06-12 03:33:18.015585
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Dummy(BaseNodeTransformer):
        rewrites = [('a', 'b')]

    dummy = Dummy(None)

    @dummy.visit_ImportFrom
    def test(node):
        return node

    from_ = 'a'
    to = 'b'

    import_from = ast.ImportFrom(module=from_,  # type: ignore
                                 names=[
                                     ast.alias(name='c'),
                                     ast.alias(name='d',
                                               asname='e')],
                                 level=1)

    rewrote = dummy._replace_import_from_module(import_from, from_, to)
    assert isinstance(rewrote, ast.Try)
    error_body = rewrote.body[0].body
    assert len(error_body) == 1
   

# Generated at 2022-06-12 03:33:26.928570
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('''
import a.b.A as A
from x import X, Y
from x.y import *
import y as y
import z.v
''')

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('x.y', 'a.b.c')
        ]

    r = ImportRewrite.transform(tree)
    assert r._tree_changed

# Generated at 2022-06-12 03:33:36.417742
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    target = CompilationTarget.PY2
    transformer = BaseImportRewrite(None)
    transformer.rewrites = [
        ('exceptional', 'exceptional3'),
        ('tests.utils.compiler.decorator_rewrite_test', 'tests.utils.compiler.decorator_rewrite_test_3')]

    # import test_3
    import_from = ast.ImportFrom(module='.test_3',
                                 names=[ast.alias(name='a', asname='b'),
                                        ast.alias(name='c', asname='d'),
                                        ast.alias(name='e', asname='f'),
                                        ast.alias(name='g', asname='h')],
                                 level=1)

    rewritten_import_from = transformer.visit_ImportFrom(import_from)


# Generated at 2022-06-12 03:33:55.013282
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..transformer import BaseImportRewrite
    from ..types import CompilationTarget
    from ..utils.snippet import import_rewrite

    contents = """
from typing import List
from .test import Test

Test = List[Test]
"""
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.python
        rewrites = [
            ('.test', '.test2')
        ]

    tree = ast.parse(contents)
    result = TestTransformer.transform(tree)

    expected_contents = """
from typing import List
try:
    from .test import Test
except ImportError:
    from .test2 import Test

Test = List[Test]
"""
    expected_tree = ast.parse(expected_contents)

# Generated at 2022-06-12 03:34:05.198209
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('django', 'django1'), ('django.db', 'django1.db')]
    import_tree = ast.parse(
        'from django.db import models\n'
        'from django import forms')

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    assert TestBaseImportRewrite.transform(import_tree).tree == ast.parse(
        'try:\n'
        '    from django.db import models\n'
        'except ImportError:\n'
        '    from django1.db import models\n'
        'try:\n'
        '    from django import forms\n'
        'except ImportError:\n'
        '    from django1 import forms')

# Generated at 2022-06-12 03:34:14.221151
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    import unittest

    class Imports(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    class ImportTests(unittest.TestCase):
        def test_rewrite_import(self):
            tree = ast.parse('import foo')
            result, changed, dependencies = Imports.transform(tree)
            self.assertTrue(changed)
            self.assertEqual(result, ast.parse('import bar'))

        def test_rewrite_import_as(self):
            tree = ast.parse('import foo as bar')
            result, changed, dependencies = Imports.transform(tree)
            self.assertTrue(changed)
            self.assertEqual(result, ast.parse('import bar as bar'))


# Generated at 2022-06-12 03:34:24.661311
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [('foo', 'foo_changed')]

    tree = ast.parse("import foo", mode='exec')
    res = TestImportRewrite.transform(tree)
    assert astor.to_source(res.tree) == """
try:
    import foo
except ImportError:
    import foo_changed
"""

    tree = ast.parse("import foo.bar", mode='exec')
    res = TestImportRewrite.transform(tree)
    assert astor.to_source(res.tree) == """
try:
    import foo.bar
except ImportError:
    import foo_changed.bar
"""

    tree = ast.parse("import foo.bar as bar", mode='exec')


# Generated at 2022-06-12 03:34:28.100567
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('topo', 'shapely.geometry'),
        ]


# Generated at 2022-06-12 03:34:32.355571
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import os

    class test_BaseImportRewrite_visit_ImportFrom(BaseImportRewrite):
        rewrites = [
            ('os', 'os.path')
        ]


# Generated at 2022-06-12 03:34:39.652566
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast.ast3 as ast3
    import copy
    import_from_1 = ast3.ImportFrom(module="wand",
                                    names=[ast3.alias(name="ImageMagickException",
                                                      asname=None)],
                                    level=0)
    transformer = BaseImportRewrite(ast3.parse(""))
    with pytest.raises(AttributeError):
        transformer.rewrites = []
    transformer._tree_changed = False
    result_1 = transformer.visit_ImportFrom(import_from_1)  # returns import_from_1
    assert transformer._tree_changed == False
    transformer._tree_changed = False
    transformer.rewrites = [("wand", "Wand")]
    result_1 = transformer.visit_ImportFrom(import_from_1)

# Generated at 2022-06-12 03:34:46.054589
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree1 = ast.parse("""
import foo
""")
    assert tree1 == BaseImportRewrite.transform(tree1).tree

    tree2 = ast.parse("""
import foo
""")
    assert tree2 != BaseImportRewrite.transform(tree2).tree

    tree3 = ast.parse("""
import foo.bar
""")
    assert tree3 == BaseImportRewrite.transform(tree3).tree

    tree4 = ast.parse("""
import foo.bar
""")
    assert tree4 != BaseImportRewrite.transform(tree4).tree


# Generated at 2022-06-12 03:34:53.863801
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from pytest import raises
    from ..utils.tests.helper import get_call_ast
    from ..utils.tests.helper import compare_source

    tree = get_call_ast(BaseImportRewrite, tree_changed=False)
    with raises(AssertionError):
        compare_source(tree, """
from time import time
from time import clock
from time import perf_counter
from time import process_time
from time import ctime
from time import gmtime
from time import localtime
from time import mktime
from time import strftime
from time import strptime
from time import tzset
from time import tzname
from time import monotonic
from time import monotonic_ns
from time import highres_clock
from time import highres_clock_ns
from time import sleep
""")

# Generated at 2022-06-12 03:34:58.967679
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..transformer.base_import_rewrite import BaseImportRewrite
    import sys
    # test for changing import
    tree = astor.parse('import a')
    assert tree.body[0].__class__ == ast.Import
    class ImportTest(BaseImportRewrite):
        rewrites = [('a', 'b')]
    result = ImportTest.transform(tree)
    assert result.changed
    assert result.tree.body[0].__class__ == ast.Try
    assert result.tree.body[0].body[0].__class__ == ast.Import
    assert result.tree.body[0].body[0].names[0].name == 'b'
    assert result.tree.body[0].body[0].names[0].asname == 'a'
    # test for not changing

# Generated at 2022-06-12 03:35:25.087485
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..std_libs.four_suite import patch_tree
    from ..utils.ast_helpers import get_ast

    nodes = [
        get_ast('''
            from datetime import date, datetime, time
        ''').body,
        get_ast('''
            import datetime
        ''').body,
        get_ast('''
            from datetime import datetime, date, time
        ''').body,
        get_ast('''
            from datetime import datetime, date
        ''').body,
    ]

    rewrites = [
        ('datetime', 'builtins.datetime'),
        ('datetime', 'xmlrpc.client'),
        ('datetime.date', 'xmlrpc.client.datetime.date'),
    ]


# Generated at 2022-06-12 03:35:33.788347
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        target = None
        rewrites = [('numpy', 'cupy')]

    code = '''\
from numpy import array, dot
from numpy.linalg import inv
'''
    expected = '''\
try:
    from numpy import array, dot
except ImportError:
    from cupy import array, dot
try:
    from numpy.linalg import inv
except ImportError:
    from cupy.linalg import inv
'''
    tree = ast.parse(code)
    rewrote = TestTransformer.transform(tree)
    assert rewrote.changed
    assert ast.dump(rewrote.tree) == expected

# Generated at 2022-06-12 03:35:44.329240
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    mock_import = ast.Import(names=[ast.alias(name='os', asname=None)])
    mock_try = ast.Try(body=[mock_import],
                       handlers=[],
                       orelse=[],
                       finalbody=[])

    import_rewrite_transformer = BaseImportRewrite()
    import_rewrite_transformer.rewrites = [('os', 'os2')]
    res = import_rewrite_transformer.visit(mock_import)
    assert isinstance(res, ast.Try)
    assert res.body == mock_try.body
    assert res.handlers == mock_try.handlers
    assert res.orelse == mock_try.orelse
    assert res.finalbody == mock_try.finalbody


# Generated at 2022-06-12 03:35:53.527480
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import typed_ast.ast3 as ast

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo")

    class ImportVisitor(ast.NodeVisitor):
        def visit(self, node: ast.AST) -> Optional[ast.AST]:
            """Calls visitor method for this node."""
            method = 'visit_' + node.__class__.__name__
            visitor = getattr(self, method, self.generic_visit)
            return visitor(node)

        def visit_Import(self, node: ast.Import) -> None:
            if node.names[0].name.module != 'bar':
                raise ValueError("Module of the import is not as expected")

    import_visitor = ImportVisitor

# Generated at 2022-06-12 03:36:03.696975
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Mock(BaseImportRewrite):
        rewrites = (('old.module', 'new.module'),)

    tree = ast.parse('from old.module import spam[')
    assert Mock.transform(tree) == (ast.parse('try: from new.module import spam\nexcept ImportError: from old.module import spam['), True)

    tree = ast.parse('from old.module import spam, eggs as eggs[')
    assert Mock.transform(tree) == (ast.parse('try: from new.module import spam, eggs as eggs\nexcept ImportError: from old.module import spam, eggs as eggs['), True)

    tree = ast.parse('import old.module[')
    assert Mock.transform(tree) == (ast.parse('try: import new.module\nexcept ImportError: import old.module['), True)



# Generated at 2022-06-12 03:36:11.238485
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astor.codegen
    input = astor.parse("""
        from collections import namedtuple, defaultdict
    """)

    class Transformer(BaseImportRewrite):
        rewrites = [('collections', 'typed_collections')]

    result = Transformer.transform(input)
    assert astor.dump_tree(result) == """
try:
    from typed_collections import namedtuple, defaultdict
except (ImportError):
    from collections import namedtuple, defaultdict
    """.strip()


# Generated at 2022-06-12 03:36:22.041102
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.snippet import rewrite, snippet
    from ..utils import module_test
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            @snippet
            def original(rewrite, staticmethod, x):
                extend(rewrite)
                staticmethod.bar()
                return x

            @snippet
            def expected(rewrite, staticmethod, x):
                from functools import staticmethod
                extend(rewrite)
                staticmethod.bar()
                return x

            class ImportRewrite(BaseImportRewrite):
                rewrites = [('functools', 'rewritten.functools')]


# Generated at 2022-06-12 03:36:31.588971
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node = ast.parse('from six.moves.urllib.request import urlopen')
    visitor = BaseImportRewrite(None)
    rewrited = visitor.visit_ImportFrom(node.body[0])
    assert astor.to_source(rewrited).strip() == (
            'try:\n'
            '    from six.moves.urllib.request import urlopen\n'
            'except ImportError:\n'
            '    try:\n'
            '        from urllib.request import urlopen\n'
            '    except ImportError:\n'
            '        from six.moves.urllib.request import urlopen'
    )

# Generated at 2022-06-12 03:36:41.617413
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Rewriter(BaseImportRewrite):
        rewrites = [('datetime', 'datetime_mock')]

    module = ast.parse('from datetime import datetime')
    result = Rewriter.transform(module)
    assert result.tree.body[0].body[0].targets[0].value.id == 'datetime_mock'
    result = Rewriter.transform(module)
    assert result.tree.body[0].body[0].targets[0].value.id == 'datetime_mock'

    module = ast.parse('from datetime import datetime')
    result = Rewriter.transform(module)
    assert result.tree.body[0].body[0].targets[0].value.id == 'datetime_mock'
    result = Rewriter.transform(module)

# Generated at 2022-06-12 03:36:50.825103
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    astnode = ast.parse("from foo import bar as baz\nfrom foo import bar\nfrom bar import baz, boz\nfrom foo import *\n")
    tree = astnode.body[0]
    target = tree.__class__
    transformer = BaseImportRewrite(target)
    visit = transformer.visit_ImportFrom(tree)
    assert visit.__class__ == ast.Try
    assert isinstance(visit.body[0], ast.Try)
    assert visit.body[0].body[0].__class__ == ast.ImportFrom
    assert visit.body[0].body[0].names[0].name == 'bar'
    assert visit.body[0].body[0].names[0].asname == 'baz'
    assert visit.body[0].body[0].module == 'foo'

# Generated at 2022-06-12 03:37:34.069983
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse(
        'from os import path')

    class Transformer(BaseImportRewrite):
        rewrites = [('os', 'generated_os')]

    result = Transformer.transform(tree)
    assert result.changed

    correct_tree = ast.parse(
        'try:\n    from os import path\nexcept ImportError:\n    from generated_os import path')
    assert ast.dump(result.tree, include_attributes=True) == ast.dump(correct_tree, include_attributes=True)

# Generated at 2022-06-12 03:37:43.919983
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    visitor = BaseImportRewrite(None)
    import_ = ast.Import(names=[
        ast.alias(name='math', asname=None),
        ast.alias(name='scipy.special', asname='special'),
        ast.alias(name='scipy.special', asname='special')])

    # import math
    import_.names = [import_.names[0]]
    visitor.rewrites = [('math', 'math_new')]

# Generated at 2022-06-12 03:37:52.950372
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import check_node_transformation
    
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    check_node_transformation(
        TestTransformer,
        ast.parse('import old_module'),
        ast.parse('try:\n    import old_module\nexcept ImportError:\n    import new_module')
    )
    check_node_transformation(
        TestTransformer,
        ast.parse('import old_module as old'),
        ast.parse('try:\n    import old_module as old\nexcept ImportError:\n    import new_module as old')
    )

# Generated at 2022-06-12 03:38:02.094234
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """
        Test class BaseImportRewrite, method visit_Import
    """
    def create_tree(name: str) -> ast.Import:
        return ast.Import(names=[
            ast.alias(name=name,
                      asname=None)])

    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar'),
                    ('x', 'y')]

    check_list = [
        ('foo', ast.Try),
        ('foo.x', ast.Try),
        ('bar', ast.Import),
        ('y', ast.Import),
        ('foo.y', ast.Try)
    ]

    for name, result in check_list:
        node = create_tree(name)
        assert isinstance(MyTransformer.transform(node).tree, result)


# Generated at 2022-06-12 03:38:12.419813
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import get_ast, get_ast_tree
    from itertools import permutations

    class ImportRewrite(BaseImportRewrite):
        target = 'python'
        rewrites = [('requests', 'requests_ntlm')]

    def test(original_string, expected_string_list):
        original_ast = get_ast(original_string)
        tree = get_ast_tree(original_ast)

        transformed_tree = ImportRewrite.transform(tree)

        expected_output = [
            (hasattr(transformed_tree, 'body')
             and get_ast(expected_string).body == transformed_tree.body)
            for expected_string in expected_string_list]

        assert any(expected_output)


# Generated at 2022-06-12 03:38:17.109758
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from .utils import to_source
    import_from_stmt = 'from typing import Optional'
    tree = parse(import_from_stmt)
    tree = BaseImportRewrite(tree).visit(tree)
    assert to_source(tree) == '\nfrom typing import Optional\ntry:\n    from builtins import Optional\nexcept ImportError:\n    from typing import Optional\n'



# Generated at 2022-06-12 03:38:24.545747
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    trans = BaseImportRewrite(None)
    imported = ast.Import(names=[
        ast.alias(name='foo',
                  asname='bar')])

    # no match
    rewrote = trans.visit_Import(imported)
    assert rewrote is imported

    # no local match
    trans.rewrites = [('f00', 'b4r')]
    rewrote = trans.visit_Import(imported)
    assert rewrote is imported

    # matched
    trans.rewrites = [('foo', 'bar')]
    rewrote = trans.visit_Import(imported)
    assert isinstance(rewrote, ast.Try)
    handler = rewrote.handlers[0]
    assert handler.type.id == 'ImportError'
    assert isinstance(handler.body[0], ast.Import)

# Generated at 2022-06-12 03:38:30.040819
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class T(BaseImportRewrite):
        rewrites = [("from1", "from2")]
    tree = ast.parse("import from1.a\n"
                     "import from3.b")
    result = T.transform(tree)
    assert result.changed
    assert result.tree == ast.parse("import from3.b\n"
                                    "try:\n"
                                    "    import from2.a\n"
                                    "except ImportError:\n"
                                    "    import from1.a")



# Generated at 2022-06-12 03:38:36.259379
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        target = "3"

    import_snippet = ast.parse(dedent('''
    import foo
    '''))

    result = TestTransformer.transform(import_snippet)

    assert result.changed

    expected_code = dedent('''
    try:
        import foo
    except ImportError:
        pass
    ''')

    assert expected_code == astor.to_source(result.tree)


# Generated at 2022-06-12 03:38:41.362253
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    tree = ast.parse('''from flask import Flask''')
    BaseImportRewrite.rewrites = [('flask', 'flask_new')]
    visit_ImportFrom(tree)
    expected = ast.parse('''from flask_new import Flask''')
    if ast.dump(tree) != ast.dump(expected):
        print('Test not passed')
    else:
        print('Test passed')    
