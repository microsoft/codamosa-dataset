

# Generated at 2022-06-12 03:29:05.317125
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor # type: ignore

    actual = ast.parse('''
import module
''')
    class Test(BaseImportRewrite):
        rewrites = [('module', 'rewritten_module')]
    expected = ast.parse('''
try:
    import module
except ImportError:
    import rewritten_module
''')
    Test.transform(actual)
    assert(astor.to_source(actual) == astor.to_source(expected))



# Generated at 2022-06-12 03:29:15.065497
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = ast.parse('''
from cryptography.hazmat.backends import default_backend 
from cryptography.hazmat.backends.interfaces import (
    CipherBackend,
    HashBackend,
    HMACBackend,
    RSAPublicKeyBackend,
    RSAPrivateKeyBackend,
    EllipticCurveBackend,
    CMACBackend,
    DSABackend,
    PEMSerializationBackend,
    X509Backend,
    DERSerializationBackend, 
)
''')
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('cryptography.hazmat.backends.interfaces', 'cryptography.hazmat.primitives.interfaces'),
        ]

# Generated at 2022-06-12 03:29:21.257831
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import six
    import tests.test_transformers.test_base

    trans = tests.test_transformers.test_base.BaseImportRewrite.transform
    input_tree = ast.parse('from thread import start_new_thread')
    output_tree = ast.parse('import thread\nthread.start_new_thread')

    if six.PY2:
        output_tree = ast.parse('from thread import start_new_thread')

    assert trans(input_tree) == (output_tree, True, [])

# Generated at 2022-06-12 03:29:31.672772
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    start = """
    from .foo import bar, baz
    
    from .foo.bar import baz
    
    from .foo.bar.baz import blah
    
    from .foo.bar.baz.blah import blah2
    """
    start_ast = ast.parse(start)

    class Rewrite(BaseImportRewrite):
        rewrites = [('.foo', 'fizz'),
                    ('fizz.bar', 'fizz.buzz')]

    result = Rewrite().transform(start_ast)
    assert result.changed


# Generated at 2022-06-12 03:29:38.329897
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('urllib.parse', 'six.moves.urllib.parse'),
        ]

    tree = ast.parse("from urllib.parse import urljoin")
    result = RewriteTransformer.transform(tree)

    assert not result._error_raised, 'Transformation failed'

    expected = ast.parse("from six.moves.urllib.parse import urljoin")

    test_utils.assert_equivalent_code(result.tree, expected)
    assert result._changed



# Generated at 2022-06-12 03:29:42.776129
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..rewrites import compat

    node = ast.parse('import some')

    rewriter = compat.BackportedImport()
    new_node = rewriter.visit(node)

    assert isinstance(new_node, ast.Try)
    assert isinstance(new_node.body[0], ast.Import)



# Generated at 2022-06-12 03:29:49.481229
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    import textwrap

    class BaseImportRewrite_visit_Import_BaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'pkg_resources'),
        ]

    def test_BaseImportRewrite_visit_Import_test1():
        tree = ast.parse(textwrap.dedent('''
        import six
        '''))
        expected = ast.parse(textwrap.dedent('''
        import pkg_resources as six
        '''))

        result = BaseImportRewrite_visit_Import_BaseImportRewrite.transform(tree)
        assert result.tree == expected


# Generated at 2022-06-12 03:29:59.636853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    # When
    import_ = ast.Import(names=[ast.alias(name='foo.bar')])
    result = DummyImportRewrite.visit_Import(import_)

    # Then
    expected = ast.Try(
        body=[import_rewrite.get_body(previous=import_,  # type: ignore
                                      current=ast.Import(names=[
                                          ast.alias('bar.bar')]))[0]],
        handlers=[],
        orelse=[],
        finalbody=[])

    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-12 03:30:09.107297
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast.ast3 as ast
    import astunparse
    from ..transpiler import BaseImportRewrite

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a.b', 'c.d.e')]

    rewritten = ast.parse('''
    try:
        import a.b
    except ImportError:
        import c.d.e
    ''').body[0]

    original = ast.Import(names=[ast.alias(name='a.b', asname=None)])
    # noinspection PyTypeChecker
    assert rewritten == TestTransformer()._replace_import(original, 'a.b', 'c.d.e')


# Generated at 2022-06-12 03:30:19.280865
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from ..types import CompilationTarget
    from ..utils.samples import get_sample

    import_from = """
    from future.backports import urllib
    from typing import List, Dict, Optional
    from foo import bar, bar2, bar3
    from foo.bar import bar4

    from builtins import str, bytes

    from baz import *
    from baz.baz2 import *
    from baz.baz2.baz3 import *
    """

    t = parse(import_from)
    class Transformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_33

# Generated at 2022-06-12 03:30:37.053659
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Unit test for method visit_Import of class BaseImportRewrite."""
    import astor
    from ..backports import six

    if six.PY2:
        node = ast.parse('import six')
    else:
        node = ast.parse('import past')
    node = ast.fix_missing_locations(node)

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('six', 'past')]

    new = DummyTransformer.transform(node).tree
    assert astor.to_source(new) == 'try:\n    import six\nexcept ImportError:\n    import past\n\n'



# Generated at 2022-06-12 03:30:45.014331
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # unittest.skip("Unit test for method visit_ImportFrom of BaseImportRewrite")
    from ..utils import test_visitor
    from ..types import CompilationTarget
    from .typing_extension import TypingRewriter
    from .unify_types import UnifyTypes
    from .flatten_types import FlattenTypes
    from .pipeline import Pipeline
    from .rewrite_builtin_annotations import RewriteBuiltinAnnotations
    from ..utils import assert_ast_equal

    # TODO: rewrites = [['typing', 'typing_extensions']]
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [(x, x + '_extensions') for x in ('typing', 'typing_extensions')]


# Generated at 2022-06-12 03:30:56.152774
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = ast.parse('import test')
    assert BaseImportRewrite.transform(module).tree.body == []

    module = ast.parse('import test')
    assert BaseImportRewrite.transform(module).tree.body == []

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('test', 'test2')]

    module = ast.parse('import test')
    assert TestImportRewrite.transform(module).tree.body == ['from __future__ import print_function',
                                                             'from __future__ import unicode_literals',
                                                             'from __future__ import division',
                                                             'try:',
                                                             '    from test2 import test',
                                                             'except ImportError:',
                                                             '    import test']


# Generated at 2022-06-12 03:31:03.209794
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import asttokens

    def check(actual: ast.ImportFrom, expected: ast.Node) -> None:
        assert isinstance(actual, ast.Try)

        assert len(actual.body) == 1
        assert isinstance(actual.body[0], ast.ImportFrom)
        assert actual.body[0].module == expected.module

        assert len(actual.body[0].names) == len(expected.names)
        for actual_alias, expected_alias in zip(actual.body[0].names, expected.names):
            assert isinstance(actual_alias, ast.alias)
            assert isinstance(expected_alias, ast.alias)

            assert actual_alias.name == expected_alias.name
            assert actual_alias.asname == expected_alias.asname

        assert len(actual.handlers) == 1

# Generated at 2022-06-12 03:31:10.336774
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MockRewriter(BaseImportRewrite):
        rewrites = [('transforms', 'typed_ast')]

    import_from_name = ast.ImportFrom(
        module='transforms.visitors',
        names=[ast.alias(name='version_info',
                         asname=None)],
        level=0)
    import_from_all = ast.ImportFrom(
        module='transforms',
        names=[ast.alias(name='*',
                         asname=None)],
        level=0)
    import_from_all_2 = ast.ImportFrom(
        module='transforms',
        names=[ast.alias(name='__all__',
                         asname='_')],
        level=0)

    result_name = MockRewriter.transform(import_from_name)
    result_all

# Generated at 2022-06-12 03:31:20.963836
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast import parse
    from ..utils.testing import assert_code_equal

    class TestTransformer(BaseImportRewrite):
        rewrites = [('abc', 'abc_rewrited')]

    import_ = parse('import abc').body[0]
    assert_code_equal(
        TestTransformer(import_).visit_Import(import_),
        '''try:
    import abc
except ImportError:
    import abc_rewrited''')

    import_ = parse('import abc.cba.def').body[0]
    assert_code_equal(
        TestTransformer(import_).visit_Import(import_),
        '''try:
    import abc.cba.def
except ImportError:
    import abc_rewrited.cba.def''')

   

# Generated at 2022-06-12 03:31:30.701226
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrite = BaseImportRewrite(ast.Module(body=[]))
    import_from = ast.ImportFrom(module='a', names=[
        ast.alias(name='a',
                  asname='a'),
        ast.alias(name='b',
                  asname='b'),
        ast.alias(name='c',
                  asname='c')])
    try_statements = rewrite.visit(import_from)
    assert isinstance(try_statements, ast.Try)
    try_body = try_statements.body
    assert len(try_body) == 2
    assert try_body[0] == import_from
    assert isinstance(try_body[1], ast.ImportFrom)
    import_from = try_body[1]
    assert import_from.module == 'a'

# Generated at 2022-06-12 03:31:38.077693
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Apple(BaseImportRewrite):
        rewrites = [('apple', 'banana')]

    tree = ast.parse("""
    import apple
    """)

    result = Apple.transform(tree)
    assert result is not None
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies == Apple.dependencies
    assert str(result.tree) == '\ntry:\n    import apple\nexcept ImportError:\n    import banana\n'



# Generated at 2022-06-12 03:31:44.877843
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('this', 'that'),
            ('other.module', 'new.module'),
        ]

    statement = 'import this'
    tree = ast.parse(statement)

    result = ImportRewrite.transform(tree)

    assert astor.to_source(result.tree) == dedent('''
    import that
    ''').strip() + '\n'
    assert result.changed is True
    assert result.dependencies == ['that']


# Generated at 2022-06-12 03:31:52.282936
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    from ..utils.snippet import snippet
    import_ = ast.Import(names=[
        ast.alias(name='foo.bar.baz', asname='a')
    ])
    transformer = BaseImportRewrite(None) # type: ignore
    transformer.rewrites = [(
        'foo.bar.baz',
        'foo.bar1.baz1'
    )]

    # Exercise
    result = transformer.visit_Import(import_) # type: ast.Try

    # Verify
    assert result.body[0].value.names[0].name == 'foo.bar1.baz1'


# Generated at 2022-06-12 03:32:05.865496
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    rewrites = [('six', 'six.moves')]
    class BaseImportRewriteUnitTest(BaseImportRewrite):  # type: ignore
        rewrites = rewrites


# Generated at 2022-06-12 03:32:11.673389
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'bar.foo')]

    tree = ast.parse('from foo import bar')
    expected = ast.parse(
        'try:\n'
        '    from foo import bar\n'
        'except ImportError:\n'
        '    from bar import foo')
    TestImportRewrite.transform(tree)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 03:32:16.938776
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""import module""")
    rewrites = [("module", "module_rewrite")]
    node_transformer = type("NodeTransformer",
                            (BaseImportRewrite,),
                            {"rewrites": rewrites})
    result = node_transformer.transform(tree)
    assert result.tree.body[0].body[0].orelse[0].body[0].names[0].name == "module_rewrite"


# Generated at 2022-06-12 03:32:28.007374
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..tests.helpers import TransformerTestCase

    class TestClass(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._change_records = []  # type: List[Tuple[ast.AST]]

        def _replace_import_from_module(self, node: ast.ImportFrom,
                                        from_: str, to: str) -> ast.Try:
            self._change_records.append(('_replace_import_from_module',
                                         node,
                                         from_,
                                         to))
            return super()._replace_import_from_module(node, from_, to)


# Generated at 2022-06-12 03:32:33.236204
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert BaseImportRewrite.transform(ast.parse(textwrap.dedent('''
        import past
        from __future__ import unicode_literals
        
        x = 10
        
        '''))) == TransformationResult(ast.parse(textwrap.dedent('''
        try:
            import past
        except ImportError:
            import future
        
        x = 10
        
        ''')), True, [])



# Generated at 2022-06-12 03:32:41.847215
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from copy import deepcopy
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Import, ImportFrom, Try, Name
    from ..utils.astutils import ASTEqualChecker


# Generated at 2022-06-12 03:32:50.370518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from .visitors.base_visitor import BaseVisitor

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('typing', 'six'),
        ]

    # Tranform single import
    tree = parse('''
    import typing
    ''')
    Transformer.transform(tree)
    assert BaseVisitor.verify_ast(tree, '''
    try:
        import typing
    except ImportError:
        import six
    ''')

    # Tranform nested import
    tree = parse('''
    import typing.io
    ''')
    Transformer.transform(tree)

# Generated at 2022-06-12 03:32:54.864612
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...utils.test import check_transformer

    class Transformer(BaseImportRewrite):
        rewrites = [('to_rewrite', 'rewrote')]

    check_transformer(Transformer, """
        import to_rewrite
        import not_rewritten
        """, """
        try:
            import to_rewrite
        except ImportError:
            import rewrote
        import not_rewritten
        """, 0)


# Generated at 2022-06-12 03:32:59.161842
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockTransformer(BaseImportRewrite):
        rewrites = [('mod', 'newmod')]

    t = MockTransformer(ast.parse('import mod'))
    assert t.visit_Import(ast.parse('import mod').body[0])
    assert t._tree_changed



# Generated at 2022-06-12 03:33:07.839867
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Tests method visit_Import of class BaseImportRewrite.

    """

    def _get_result(from_, to):
        """Returns class of BaseImportRewrite with given rewrites."""

        class ImportRewrite(BaseImportRewrite):
            rewrites = [(from_, to)]

        return ImportRewrite.transform(
            ast.parse(
                'from testing import *'))

    def _get_try(to):
        """Returns what visit_Import method of BaseImportRewrite should return for given to."""


# Generated at 2022-06-12 03:33:27.807997
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.Import(names=[
        ast.alias(name='foo.bar', asname='baz'),
    ])
    actual = BaseImportRewrite.transform(node)
    expected = ast.Import(names=[
        ast.alias(name='foo.bar', asname='baz'),
    ])
    assert actual.get_tree() == expected



# Generated at 2022-06-12 03:33:34.525530
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [('unittest', 'unittest2')]

    class Test(BaseImportRewrite):
        rewrites = rewrites

    code = """
import unittest
    """
    tree = ast.parse(code)
    Test.transform(tree)
    print(ast.dump(tree, include_attributes=False))

    code = """
import unittest.test
    """
    tree = ast.parse(code)
    Test.transform(tree)
    print(ast.dump(tree, include_attributes=False))



# Generated at 2022-06-12 03:33:40.289941
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Generate test AST
    tree = ast.parse(
        # -----
        'import sys'
        # -----
    )
    # Run transformer
    BaseImportRewrite.transform(tree)
    # Check result
    assert tree == ast.parse(
        # -----
        'try:\n'
        '    import sys\n'
        'except ImportError:\n'
        '    pass'
        # -----
    )



# Generated at 2022-06-12 03:33:48.333334
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import six")

    t = BaseImportRewrite(tree)
    t.rewrites = [("six", "sixer")]
    node = t.visit(tree)

    assert type(node) is ast.Try  # type: ignore
    
    try_ = node
    except_ = try_.handlers[0]
    assert except_.type is None
    assert type(except_.body[0]) is ast.Import  # type: ignore

    # In case of failure, the second node in except body is an Import
    assert except_.body[1].names[0].name == "sixer"



# Generated at 2022-06-12 03:33:58.584514
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class FakeImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'fakeos')]

    from_ = 'from os import sep, path'
    ast_from = ast.parse(from_)
    assert FakeImportRewrite.transform(ast_from).tree == ast.parse('from fakeos import sep, path')

    from_ = 'from os.path import sep'
    ast_from = ast.parse(from_)
    assert FakeImportRewrite.transform(ast_from).tree == ast.parse('from fakeos.path import sep')

    from_ = 'from os.path import path as path'
    ast_from = ast.parse(from_)
    assert FakeImportRewrite.transform(ast_from).tree == ast.parse('from fakeos.path import path as path')


# Generated at 2022-06-12 03:34:07.275915
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_tree = ast.parse(
        '''
try:
    import os
except ImportError:
    import pathlib
    ''')
    import_rewrite = BaseImportRewrite(import_tree)
    import_rewrite.rewrites = [('os', 'pathlib')]
    import_rewrite.visit(import_tree)

    assert import_rewrite._tree_changed is True
    assert ast.dump(import_tree) == ast.dump(
        ast.parse(
            '''
try:
    import pathlib
except ImportError:
    import pathlib
    '''))



# Generated at 2022-06-12 03:34:15.439240
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.arguments import load_arguments
    from ..utils.location import Location
    from ..utils.source import load_file

    def _test_rewrite(source: str, expectation: str,
                      arguments: Dict,
                      extra_rewrites: List[Tuple[str, str]]) -> None:
        with load_arguments(arguments):
            tree = ast.parse(source)
            transformer = type(  # type: ignore
                'MyTransformer',
                (BaseImportRewrite,),
                {'rewrites': extra_rewrites})
            trans = transformer.transform(tree)
            assert trans.changed

            generated_source = astor.to_source(trans.tree).strip()
            assert generated_source == expectation


# Generated at 2022-06-12 03:34:25.446392
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [
            ('multiprocessing', 'multiprocessing2')
        ]


# Generated at 2022-06-12 03:34:33.706591
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore
    import astunparse as astyp  # type: ignore

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'qux.quux')]

    raw_code = 'import foo.bar'
    tree = ast.parse(raw_code)
    tree = astor.to_source(tree)
    tree = ast.parse(tree)
    transformer = TestTransformer(tree)
    tree = transformer.visit(tree)
    assert astyp.unparse(tree) == 'try:\n    import foo.bar\nexcept ImportError:\n    import qux.quux'


# Generated at 2022-06-12 03:34:38.940276
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("from somewhere import something")
    
    # Right hand of the assignment isn't supported by typed_ast.
    replacement = ast.parse("from somewhere.something import something")
    replacement = replacement.body[0]

    class TestTransformer(BaseImportRewrite):
        rewrites = [('somewhere', 'somewhere.something')]

    result = TestTransformer.transform(tree)
    assert result.changed
    assert len(result.result.body) == 1
    assert result.result.body[0] == replacement



# Generated at 2022-06-12 03:34:57.570601
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    from_ = 'foo'
    to = 'bar'

    import_node = ast.Import(names=[ast.alias(name=from_,
                                              asname='foo_module')])
    import_rewrite_try_node = ast.Try(body=[
        ast.Import(names=[ast.alias(name=from_,
                                    asname='foo_module')]),
        ast.Import(names=[ast.alias(name=to,
                                    asname='foo_module')])],
                               handlers=[ast.ExceptHandler(type=None,
                                                            name=None,
                                                            body=[])],
                               orelse=[],
                               finalbody=[])

    assert TestImport

# Generated at 2022-06-12 03:34:58.356647
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-12 03:35:08.054258
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    from ..compiler import compile
    from ..utils.ast import get_ast
    from ..utils.testing import _MAIN_NODE_TYPES, _STRING_NODE_TYPES
    from ..utils.env import Env

    env = Env()

# Generated at 2022-06-12 03:35:14.550294
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import copy

    tree = ast.parse('import some_old_module')
    expected = ast.parse('try:\n    import some_old_module\nexcept ImportError:\n    import some_new_module')

    transformer = BaseImportRewrite.__new__(BaseImportRewrite)
    transformer.rewrites = [('some_old_module', 'some_new_module')]

    result = transformer.visit_Import(tree.body[0])
    assert copy.deepcopy(result) == expected.body[0]
    assert transformer._tree_changed



# Generated at 2022-06-12 03:35:23.485457
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'sixx')]


# Generated at 2022-06-12 03:35:30.283473
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import builtins
    import inspect
    module_name = inspect.getmodulename(__file__)
    module_tree = ast.parse(builtins.open(module_name).read())
    ast.dump(module_tree)
    module_tree = ast.fix_missing_locations(module_tree)

    class BadImportRewrite(BaseImportRewrite):
        rewrites = [('builtins', 'six.moves')]

    tree = BadImportRewrite.transform(module_tree)
    fix = astor.to_source(tree)



# Generated at 2022-06-12 03:35:40.710467
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import textwrap
    from typed_ast import ast3
    from typed_ast import ast27
    from .. import transforms

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('typed_ast', 'six'), ('six', 'typed_ast')]

    tree = ast.parse(textwrap.dedent('''\
    import typed_ast
    import six
    import ast'''))
    tree = ast3.fix_missing_locations(tree)
    result = DummyTransformer.transform(tree)


# Generated at 2022-06-12 03:35:46.679118
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import json
    import astor
    tree = astor.parse(
        """import json""")
    rewrites = [('json', 'simplejson')]
    BaseImportRewrite.rewrites = rewrites  # type: ignore
    BaseImportRewrite.transform(tree)
    assert astor.to_source(tree) == \
        """
try:
    import json
except ImportError:
    import simplejson
"""

# Generated at 2022-06-12 03:35:53.158551
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('test', 'test')]

    tree = ast.parse("from test.a import b")
    ImportRewrite().visit(tree)
    assert ast.dump(tree) == "try:\n    from test.a import b\nexcept ImportError:\n    from test.a import b"

    tree = ast.parse("from test.a import *")
    ImportRewrite().visit(tree)
    assert ast.dump(tree) == "from test.a import *"

    tree = ast.parse("import test.a")
    ImportRewrite().visit(tree)
    assert ast.dump(tree) == "import test.a"

    tree = ast.parse("from a import b")
    ImportRewrite().visit(tree)
    assert ast

# Generated at 2022-06-12 03:36:03.277089
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockedBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('bar', 'baz')]

    node = ast.parse('import foo', mode='exec')
    transformed = MockedBaseImportRewrite(node).visit(node)
    expected = ast.parse("try:\n    import foo\nexcept ImportError:\n    import bar", mode='exec')
    assert ast.dump(transformed) == ast.dump(expected)

    node = ast.parse('import foo.bar', mode='exec')
    transformed = MockedBaseImportRewrite(node).visit(node)
    expected = ast.parse("try:\n    import foo.bar\nexcept ImportError:\n    import foo.baz", mode='exec')
    assert ast.dump(transformed) == ast

# Generated at 2022-06-12 03:36:34.692903
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transform = BaseImportRewrite.visit_ImportFrom
    tree = ast.parse('from urllib.parse import *')
    # import_from = ast.ImportFrom(module='urllib.parse',
    #                              names=['*'],
    #                              level=0)
    result = ast.parse('''try:
        from urllib.parse import *
    except ImportError:
        from request.parse import *''').body[0]
    assert transform(transform, tree.body[0]) == result

# Generated at 2022-06-12 03:36:44.606782
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("""
from a.b import c, d
from a.b.e import f
from a.b.e.g import *

from django.views.generic import ListView

""")

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('a.b', 'aa.b')
        ]

    result, changed, msg = Rewrite.transform(tree)
    assert changed

    result_code = ast.unparse(result)

# Generated at 2022-06-12 03:36:49.662397
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('my_module', 'changed_module')]


    tree = ast.parse(r'''
import my_module
''')
    TestTransformer.transform(tree)

    assert ast.dump(tree) == r'''
try:
    import my_module
except ImportError:
    import changed_module
'''



# Generated at 2022-06-12 03:36:55.435864
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'new_foo.bar')
        ]

    source = 'import foo.bar'
    tree = ast.parse(source)
    expected = '''
try:
    import foo.bar
except ImportError:
    import new_foo.bar
'''
    res = DummyTransformer.transform(tree)
    assert res.changed is True
    assert ast.dump(tree) == expected



# Generated at 2022-06-12 03:37:04.910542
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'haha.hehe'
    to = 'muj.modul'
    module = 'hehe.muj'
    name = 'muj.modul'
    level = 0
    import_from = ast.ImportFrom(
        module=module,
        names=[ast.alias(name=name,
                         asname=None)],
        level=level)

    class X(BaseImportRewrite):
        rewrites = [(from_, to)]

    transformer = X.transform(import_from)
    rewrote_import_from = transformer.ast.body[0].body[0].body[0]

    assert isinstance(rewrote_import_from, ast.ImportFrom)
    assert rewrote_import_from.module == 'hehe.muj.modul'
    assert rewrote_import_

# Generated at 2022-06-12 03:37:11.499413
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    
    tree = ast.parse("import foo")
    result = TestImportRewrite.transform(tree)
    
    assert result.tree.body[0].body.body[0].body[0].names[0].name == 'bar'
    assert result.tree.body[0].body.body[1].body[0].names[0].name == 'foo'
    assert result.changed
    assert result.dependencies == ['foo']
    

# Generated at 2022-06-12 03:37:21.878130
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrote = ast.ImportFrom(
        module='std.math',
        names=[
            ast.alias(
                name='cos',
                asname='cos',
            ),
            ast.alias(
                name='sin',
                asname='sin',
            )
        ],
        level=0,
    )


# Generated at 2022-06-12 03:37:29.461057
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    import_ = ast.Import(names=[
        ast.alias(name='foo.bar',
                  asname='baz'),
    ])

    expected = astor.to_source(ast.Try(
        body=[
            ast.Import(names=[ast.alias(name='foo.baz',
                                        asname='baz')]),
        ],
        handlers=[
            ast.ExceptHandler(
                type=ast.Name(id='ImportError',
                              ctx=ast.Load()),
                name=None,
                body=[
                    ast.Import(names=[ast.alias(name='foo.bar',
                                                asname='baz')])
                ]
            )
        ],
        orelse=[],
        finalbody=[]
    ))


# Generated at 2022-06-12 03:37:38.315843
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typing
    import ipaddress
    node = ast.parse('from ipaddress import ip_address').body[0]
    assert isinstance(node, ast.ImportFrom)
    code = compile(ast.Module([node]), '<test>', 'exec')
    exec(code)
    node = ast.parse('from ipaddress import ip_address as ip').body[0]
    assert isinstance(node, ast.ImportFrom)
    code = compile(ast.Module([node]), '<test>', 'exec')
    exec(code)
    node = ast.parse('from ipaddress import *').body[0]
    assert isinstance(node, ast.ImportFrom)
    code = compile(ast.Module([node]), '<test>', 'exec')
    exec(code)

# Generated at 2022-06-12 03:37:47.331796
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from collections import namedtuple
    from typed_ast import ast3 as typed_ast
    from ..compiler import BaseImportRewrite

    class TestRewriter(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        """default target which is python 2.7 for testing"""

        rewrites = [('collections', 'collection')]

    INPUT = """
import collections
"""
    EXPECTED = """
try:
    import collections
except ImportError:
    import collection
"""

    def cmp_ast(a: ast.AST, b: ast.AST) -> bool:
        if a.__class__ != b.__class__:
            return False

# Generated at 2022-06-12 03:38:49.082514
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    tree = ast.parse('''
from future import print_function
from copy import (copy,
                  deepcopy)
from future.standard_library import install_aliases

from future.builtins import (ascii, bytes, chr, dict, filter, hex, input, int, isinstance, map, next, oct, open, pow, range, round, str, super, zip)

from builtins import (ascii, bytes, chr, dict, filter, hex, input, int, isinstance, map, next, oct, open, pow, range, round, str, super, zip)

from builtins import *

from future.builtins import *

import builtins

import future.builtins

from ...unknown import *

import time
import past.time
''')
