

# Generated at 2022-06-12 03:29:00.028302
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    module = ast.parse("from one.two import *\nfrom one import two")
    rewriter = BaseImportRewrite(module)
    rewriter.rewrites = [('one.two', 'three.four')]
    rewriter.visit(module)
    assert astor.to_source(module) == ('try:\n'
                                       '    from three.four import *\n'
                                       'except ImportError:\n'
                                       '    from one.two import *\n'
                                       '\n'
                                       'try:\n'
                                       '    from three.four import two\n'
                                       'except ImportError:\n'
                                       '    from one import two\n')
    assert rewriter._tree_changed

# Generated at 2022-06-12 03:29:10.031721
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module='foo', names=[ast.alias(name='Bar')], level=0)
    my_node = BaseImportRewrite(None)
    my_node.rewrites = [('foo', 'baz')]
    new_import = my_node.visit_ImportFrom(import_from)
    assert isinstance(new_import, ast.Try)
    assert new_import.body[1].names[0].name == 'baz'
    assert new_import.body[1].names[0].asname == 'Bar'
    assert new_import.body[0].names[0].name == 'foo'
    assert new_import.body[0].names[0].asname == 'Bar'


# Generated at 2022-06-12 03:29:16.764990
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_node_equal
    from .transformers_for_tests import TransformerForTests

    tree = ast.parse('import foo')
    inst = TransformerForTests(tree)
    rewrote = inst.visit_Import(ast.parse('import foo').body[0])

    assert_node_equal(rewrote, '''
    try:
        extend(foo)
    except ImportError:
        extend(bar)
    ''', ignore_fields=['lineno', 'col_offset'])


# Generated at 2022-06-12 03:29:18.230002
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    raise NotImplementedError()

# Generated at 2022-06-12 03:29:24.443299
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.TARGET_3_6
        rewrites = [
            ('old_module', 'new_module'),
        ]

    tree = ast.parse('import old_module')
    expected = ast.parse('try:\n    import old_module\nexcept ImportError:\n    import new_module')

    result = TestImportRewrite.transform(tree)
    assert result.tree == expected



# Generated at 2022-06-12 03:29:27.858687
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    mod = ast.parse("""
import module
    """)

    res = BaseImportRewrite.transform(mod)
    assert res.tree == ast.parse("""
import module
    """)
    assert res.changed is False


# Generated at 2022-06-12 03:29:35.240861
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    tree = ast.parse("""import math""")
    BaseImportRewrite.rewrites = [
        ('math', 'math2')
    ]
    class Test(BaseImportRewrite):
        def visit_Name(self, node):
            if node.id == 'math':
                return ast.parse('math2.cos(2)').body[0].value
            return self.generic_visit(node)
    transformer = Test(tree)
    transformer.visit(tree)
    expected = ast.parse("""
try:
    import math
except ImportError:
    import math2
math2.cos(2)
""")
    assert astor.to_source(tree) == astor.to_source(expected)


# Generated at 2022-06-12 03:29:44.674775
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ModuleFooToBar(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    module = ast.Module([
        ast.Assign(targets=[ast.Name(id='x',
                                      ctx=ast.Store())],
                   value=ast.Name(id='True',
                                  ctx=ast.Load())),
        ast.Import(names=[
            ast.alias(name='foo',
                      asname=None)])])


# Generated at 2022-06-12 03:29:54.741002
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import TransformationResult

    # Test case 1: current_module is not from_module
    current_module = "abc" # type: str
    from_module = "def"
    from_module_to = "ghi"
    import_from = ast.ImportFrom(level=None, module=current_module,
                   names=[ast.alias(name="klm", asname=None)],
                   lineno=None, col_offset=None) # type: ast.ImportFrom
    rewrites = [(from_module, from_module_to)] # type: List[Tuple[str, str]]
    result = BaseImportRewrite(rewrites=rewrites).visit_ImportFrom(import_from)
    assert result == import_from, "Expected: {}, Got: {}".format(import_from, result)
    

# Generated at 2022-06-12 03:30:03.726084
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import ast3 as ast3
    from .. import nodes as nodes
    from .. import prelude as prelude

    class MockBaseImportRewrite(BaseImportRewrite):
        rewrites = []

    assert MockBaseImportRewrite.transform(
        nodes.import_from(
            module='foo', names=[nodes.name(name='bar')])) == \
        prelude.ast_to_source(ast3.parse('import foo.bar'))

    assert MockBaseImportRewrite.transform(
        nodes.import_from(
            module='foo',
            names=[nodes.name(name='bar'), nodes.name(name='baz')])) == \
        prelude.ast_to_source(ast3.parse('import foo.bar\nimport foo.baz'))


# Generated at 2022-06-12 03:30:18.668189
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock as mock

    class MockImport(BaseImportRewrite):
        rewrites = [
            ('foo', 'baz'),
            ('old.baz', 'new.baz')
        ]

    module = ast.parse('import foo; import old.baz')
    assert module.body[0] == ast.Import(names=[ast.alias(name='foo',
                                                        asname=None)])
    assert module.body[1] == ast.Import(names=[ast.alias(name='old.baz',
                                                        asname=None)])


# Generated at 2022-06-12 03:30:24.066555
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('bar', 'baz')]

    tree = ast.parse(
        """import foo""")
    Rewrite.transform(tree)
    assert ast.dump(tree) == \
    """try:
    import foo
except ImportError:
    import bar
"""


# Generated at 2022-06-12 03:30:31.986538
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compiler.python2 import Python2Compiler
    from ..dummies import DummyCompiler
    from ..eol.python2 import Python2EOL
    compiler = DummyCompiler(
        compilers=Python2Compiler(),
        transformations=[Python2EOL])
    compiler.compile(code='from __future__ import nested_scopes')
    assert compiler.sources[0] == 'from __future__ import nested_scopes'
    compiler.compile(code='import unittest2 as unittest')
    assert compiler.sources[0] == 'try: import unittest2 as unittest\nexcept ImportError: import unittest'



# Generated at 2022-06-12 03:30:37.297899
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo', mode='exec')
    Transformer.transform(tree)
    assert tree == ast.parse('try:\n    import foo as foo\nexcept ImportError:\n    import bar as foo', mode='exec')



# Generated at 2022-06-12 03:30:43.820857
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as old_ast
    import astor

    s = "import aaa.bbb.ccc"
    t = old_ast.parse(s)
    class Transformer(BaseImportRewrite):
        rewrites = [('aaa.bbb', 'ddd')]

    class DummyTarget(CompilationTarget):
        pass

    new_t = astor.to_source(Transformer.transform(t, DummyTarget())[0])
    assert new_t == "try:\n    import aaa.bbb.ccc\nexcept ImportError:\n    import ddd.ccc"

# Generated at 2022-06-12 03:30:46.374448
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('''from sys import version''')
    result = BaseImportRewrite.transform(tree)
    assert result.changed



# Generated at 2022-06-12 03:30:57.347336
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transforms.typing import BaseImportRewrite
    from ..common import MYPY_CHECK_RUNNING

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('re', 'regex')]

    tree = ast.parse("import re")
    import_stmt = ImportRewrite.transform(tree).tree.body[0]
    assert isinstance(import_stmt, ast.Try)

    try_ = import_stmt
    assert len(try_.handlers) == 1
    assert all(isinstance(except_, ast.ExceptHandler) for except_ in try_.handlers)
    assert isinstance(try_.body[0], ast.Import)
    assert try_.body[0].names[0].name == "regex"
    assert len(try_.body[0].names) == 1


# Generated at 2022-06-12 03:31:03.765326
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse, dump

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('typed_ast.ast3', 'ast'),
            ('collections', 'typing')
        ]

    assert dump(
        ImportRewrite.transform(
            parse('import typed_ast.ast3')).tree) == '''
try:
    extend(import typed_ast.ast3)
except ImportError:
    extend(import ast)
'''



# Generated at 2022-06-12 03:31:12.697288
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import ast_builder as builder

    rewrites = [
        ('old', 'new'),
        ('old.foo', 'new.foo')
    ]  # type: List[Tuple[str, str]]


# Generated at 2022-06-12 03:31:22.657729
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('os', 'builtins.test.test_os')]

    tree = ast.parse('import os', '')
    assert isinstance(Rewrite(tree).visit_Import(tree.body[0]), ast.Try)
    assert Rewrite(tree).visit_Import(tree.body[0]).body  # noqa
    assert Rewrite(tree).visit_Import(tree.body[0]).handlers[0].type.id == 'ImportError'  # noqa

    tree = ast.parse('import os.path', '')
    assert isinstance(Rewrite(tree).visit_Import(tree.body[0]), ast.Try)
    assert Rewrite(tree).visit_Import(tree.body[0]).body  # noqa
    assert Rew

# Generated at 2022-06-12 03:31:38.738894
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    import_from_node = ast.parse("from Crypto.Cipher import AES").body[0]
    # get_names_to_replace = dict(self._get_names_to_replace(import_from_node))
    # print(get_names_to_replace)
    # print(type(import_from_node))
    # print(import_from_node)

    # for alias in import_from_node.names:
    #     full_name = '{}.{}'.format(import_from_node.module, alias.name)
    #     print("full_name", full_name)
    #     if full_name in get_names_to_replace:
    #         full_name = full_name.replace(get_names_to_replace[full_name][

# Generated at 2022-06-12 03:31:48.269189
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from .test_support import get_test_data

    source1 = get_test_data('test_node_transformer.py')
    source2 = get_test_data('test_visit_import_from.py')

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('six.moves', 'six.moves')]

    tree1 = ast.parse(source1)
    tree2 = ast.parse(source2)

    result1 = ImportRewrite.transform(tree1)
    result2 = ImportRewrite.transform(tree2)

    assert result1.tree_changed == False
    assert result1.dependencies == []
    assert astor.to_source(result1.tree) == source1

    # expected = """try:
    #     from six.moves

# Generated at 2022-06-12 03:31:56.063895
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typed_ast.ast3 as ast3
    from typed_ast.transforms import BaseImportRewrite
    from typed_ast.transforms.imports import BaseImportRewrite
    class ImportRewriter(BaseImportRewrite):
        target = 'py25'
        rewrites = [
            ('unittest', 'unittest2')
        ]

    tree = ast3.parse("""import unittest""")
    res = ImportRewriter.transform(tree)
    assert ast3.dump(res.tree) == """\
try:
    import unittest
except ImportError:
    import unittest2 as unittest"""


# Generated at 2022-06-12 03:32:03.088626
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # type: () -> None
    import typed_ast.ast3 as ast

    tree = ast.parse("import A")
    ast.fix_missing_locations(tree)
    import_tree = tree.body[0]

    class TestClass(BaseImportRewrite):
        rewrites = [('A', 'B')]

    result = TestClass.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == "B"


# Generated at 2022-06-12 03:32:12.771843
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    import unittest

    class BaseImportRewrite(BaseNodeTransformer):
        rewrites = [
            ('os', 'pathlib'),
            ('time', 'datetime'),
            ('json', 'simplejson')
        ]

    class Test(unittest.TestCase):
        def test_import_success(self):
            t = ast3.parse('import os\nos')
            visitor = BaseImportRewrite(t)
            visitor.visit(t)
            new_t = ast3.parse('import pathlib\npathlib')
            self.assertEqual(new_t, t)

        def test_import_from_success(self):
            t = ast3.parse('''
from time import time, sleep
time()
sleep''')
            visitor = BaseImportRew

# Generated at 2022-06-12 03:32:22.195965
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..asyncio_support import asyncio_support

    # no imports -> no changes
    tree = ast.parse('import os')
    transformed = asyncio_support.BaseImportRewrite(tree)
    result = transformed.visit(tree)
    assert result is not None
    assert isinstance(result, ast.Import)

    # no rewrites for module -> no changes
    tree = ast.parse('import os')
    transformed = asyncio_support.BaseImportRewrite(tree)
    transformed.rewrites = [('_asyncio', 'asyncio')]
    result = transformed.visit(tree)
    assert result is not None
    assert isinstance(result, ast.Import)

    # rewrite found -> rewrite
    tree = ast.parse('import _asyncio')
    transformed = asyncio_support.BaseImport

# Generated at 2022-06-12 03:32:32.643491
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_utils import transform, prepare_test_tree

    _ast = prepare_test_tree("""
    import sys
    """)

    ast = transform(_ast, [BaseImportRewrite])
    assert ast == _ast

    _ast = prepare_test_tree("""
    import sys as _sys
    """)

    ast = transform(_ast, [BaseImportRewrite])
    assert ast == _ast

    _ast = prepare_test_tree("""
    import sys.path
    """)

    ast = transform(_ast, [BaseImportRewrite])
    assert ast == _ast

    _ast = prepare_test_tree("""
    import sys.path as _path
    """)

    ast = transform(_ast, [BaseImportRewrite])
    assert ast == _ast


# Generated at 2022-06-12 03:32:37.537805
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    m = ast.parse(
        'import x')
    BaseImportRewrite.rewrites = [('x', 'y')]
    BaseImportRewrite.transform(m)

    assert "from x import *" in m.body[0].body[0].value.body[0].body.body[0].targets[0].value.id
    assert "from y import *" in m.body[0].body[0].value.body[0].body.body[1].targets[0].value.id



# Generated at 2022-06-12 03:32:47.622253
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import bs4
    import cchardet
    import certifi
    import chardet
    import idna
    import pytest
    import requests
    import urllib3
    import w3lib
    import zope.interface

    class Test(BaseImportRewrite):
        rewrites = [
            ('chardet', 'cchardet'),
            ('urllib3', 'urllib3_py2'),
            ('zope', 'zope.interface')
        ]

    tree = ast.parse("""
    import chardet
    import urllib3
    import zope.interface
    """)
    result = Test.transform(tree)
    assert result.changed


# Generated at 2022-06-12 03:32:55.684468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'os1')]

    class Test(unittest.TestCase):
        def test_change_import(self):
            tree = ast.parse('import os')
            result = TestBaseImportRewrite.transform(tree)
            self.assertEqual(result.tree, ast.parse('try:\n    import os\nexcept ImportError:\n    import os1'))
            self.assertTrue(result.changed)
            self.assertEqual(result.dependencies, [])

        def test_not_change_import(self):
            tree = ast.parse('import os1')
            result = TestBaseImportRewrite.transform(tree)

# Generated at 2022-06-12 03:33:05.865789
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Analyzer(BaseImportRewrite):
        rewrites = [('re', 'regex')]

    tree = ast.parse('import re')
    result = Analyzer.transform(tree)
    assert str(result.tree) == 'def __extend__():\n' \
                               '    try:\n' \
                               '        import re\n' \
                               '    except ImportError:\n' \
                               '        import regex'
    assert result.changed is True
    assert result.dependencies == []



# Generated at 2022-06-12 03:33:11.071186
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('unittest', 'unittest2')]

    node = ast.parse('import unittest').body[0]
    result = ast.dump(TestTransformer().visit(node), include_attributes=True)
    expected = "Try(body=[Import(names=[alias(name='unittest', asname='unittest')])], " \
               "handlers=[ExceptHandler(type=Name(id='ImportError', ctx=Load()), " \
               "name=None, body=[Import(names=[alias(name='unittest2', asname='unittest')])])], " \
               "orelse=[], finalbody=[])"
    assert result == expected


# Generated at 2022-06-12 03:33:19.569787
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import typed_ast.ast3 as ast

    class Test(BaseImportRewrite):
        rewrites = [('from', 'to'),]

    test = Test(None)
    test._tree_changed = False
    node = ast.Import(names=[
        ast.alias(name='from.from')
    ])

    rewrote = test.visit_Import(node)
    assert rewrote is not None
    assert isinstance(rewrote, ast.Try)

    assert test._tree_changed is True
    assert isinstance(rewrote.body[0], ast.Import)
    assert rewrote.body[0].names[0].name == 'to.from'
    assert rewrote.body[0].names[0].asname == 'from'

# Generated at 2022-06-12 03:33:24.924610
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from tst.utils import get_test_tree
    from tst.utils import check_tree

    tree = get_test_tree('test_BaseImportRewrite_visit_Import')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    check_tree(TestImportRewrite.transform(tree).tree,
               'test_BaseImportRewrite_visit_Import')



# Generated at 2022-06-12 03:33:30.572441
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from .test_utils import get_test_case_ast, get_test_case
    from .test_utils import validate_transformation

    test_cases = get_test_case_ast('BaseImportRewrite_visit_ImportFrom')
    test_cases_source = get_test_case('BaseImportRewrite_visit_ImportFrom')

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    for case, actual, expected in zip(test_cases, test_cases, test_cases_source):
        transform = MyImportRewrite.transform(case)
        validate_transformation(transform, actual, expected)

# Generated at 2022-06-12 03:33:40.791792
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import compile_code
    src = 'from uuid import uuid4\nfrom os import path'
    tree = compile_code(src)
    class Transformer(BaseImportRewrite):
        rewrites = {('os', 'pathlib')}
    result = Transformer.transform(tree)
    assert result.tree_changed
    assert_equal(str(result.tree),
                 (
                     "try:\n"
                     "    from uuid import uuid4\n"
                     "except ImportError:\n"
                     "    from uuid import uuid4\n"
                     "try:\n"
                     "    from pathlib import path\n"
                     "except ImportError:\n"
                     "    from os import path"
                 ))



# Generated at 2022-06-12 03:33:50.749834
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class Child(BaseImportRewrite):
        rewrites = [
            ('os.path', 'pathlib'),
            ('os.cpu_count', 'multiprocessing.cpu_count')
        ]

    tree = ast.parse('''from os import path, environ as env
from os.path import *
from os import cpu_count, altsep
from os.path import *
from os.path import join, basename''')

    result = Child.transform(tree)
    tree = result.tree


# Generated at 2022-06-12 03:34:01.106125
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class NoRewrites(BaseImportRewrite):
        rewrites = []

    class SingleRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class MultipleRewrites(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('spam', 'eggs')]

    assert astor.to_source(
        NoRewrites.visit(ast.parse('import foo'))) == 'import foo'
    assert astor.to_source(
        NoRewrites.visit(ast.parse('import foo.bar'))) == 'import foo.bar'


# Generated at 2022-06-12 03:34:11.341028
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import get_ast

    class FakeNode:
        names = [ast.alias(name='a', asname=None),
                 ast.alias(name='b', asname='c')]
        level = 0

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('import_a', 'import_b')]

    class TestImportRewrite1(BaseImportRewrite):
        rewrites = [('import_a', 'import_b')]

    class TestImportRewrite2(BaseImportRewrite):
        rewrites = [('import_a.c', 'import_b.c'),
                    ('import_a.d', 'import_b.d')]


# Generated at 2022-06-12 03:34:20.809932
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from ..utils.assertions import assert_node

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('socket', 'socketio'),
            ('http.server', 'flask')
        ]

    code = """
from socket import *
"""
    expected_ast = ast3.parse(dedent("""
    try:
        from socket import *
    except ImportError:
        from socketio import *
    """))

    assert_node(ImportRewrite.transform(ast3.parse(code))[0], expected_ast)

    code = """
from socket import socket
"""
    expected_ast = ast3.parse(dedent("""
    try:
        from socket import socket
    except ImportError:
        from socketio import socket
    """))


# Generated at 2022-06-12 03:34:32.094858
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    source = '''
import foo

foo()
'''
    tree = astor.code_to_ast.parse_file(source)
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('foo', 'foo_old')]
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert astor.to_source(tree) == '''
try:
    import foo
except ImportError:
    import foo_old

foo()
'''



# Generated at 2022-06-12 03:34:39.130332
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import Module, parse
    from typed_astunparse import unparse
    from typed_astunparse.unparser import Unparser

    source = """import six"""
    tree = parse(source)
    module = Module(body=[])

    class TestTransformer(BaseImportRewrite):
        rewrites = [(
            "six",
            "typed_astunparse.six"
        )]

    result = TestTransformer.transform(tree)

    assert isinstance(result.tree.body[0], ast.Try)

    unparser = Unparser(tree, module)
    expected = "try:\n    import typed_astunparse.six as six\nexcept ImportError:\n    import six"
    assert expected == unparse(unparser.body[0])
    assert result.changed


# Unit test

# Generated at 2022-06-12 03:34:47.706431
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse

    class Rewriter(BaseImportRewrite):
        rewrites = [('six', 'six_renamed')]


# Generated at 2022-06-12 03:34:54.186542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Tree(ast.AST):
        _fields = ["node", "node_rewrite"]
        _attributes = []

    class Transformer(BaseImportRewrite):
        rewrites = [('shutil.copyfile', 'shutil2.copyfile')]

    tree = Tree(
        node=ast.Import(names=[ast.alias(name='shutil.copyfile', asname='copyfile')]),
        node_rewrite=ast.Import(names=[ast.alias(name='shutil2.copyfile', asname='copyfile')]),
    )
    new_tree = Transformer.visit(tree)
    assert new_tree == tree.node_rewrite



# Generated at 2022-06-12 03:35:03.354147
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys, io
    import typed_ast.ast3 as ast
    
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('json', 'xml')]
    
        def visit_ImportFrom(self, node):
            return super().visit_ImportFrom(node)
    

# Generated at 2022-06-12 03:35:12.174094
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    
    rewrites = [
        ('old', 'new')
    ]

    class MyClass(BaseImportRewrite):
        
        rewrites = rewrites

    @snippet
    def to_import():
        import old

    @snippet
    def expected():
        try:
            import old
        except ImportError:
            import new

    import_node = to_import.get_body(to_import=to_import)[0]
    expected_node = expected.get_body(to_import=to_import)[0]

    assert isinstance(MyClass.transform(import_node).tree, ast.Try)

    assert ast.dump(expected_node) == ast.dump(
        MyClass.transform(import_node).tree)



# Generated at 2022-06-12 03:35:21.832219
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from unittest import mock

    rewrites = [
        ('a', 'b'),
        ('a.c', 'b'),
        ('a.c.d', 'b.d'),
        ('a.c.e.f', 'b.e.f'),
        ('a.g.h.i', 'b.g.h.i')
    ]

    class BASE(BaseImportRewrite):
        rewrites = rewrites

    class T(BASE):
        pass

    class N(BASE):
        rewrites = []

    # no rewrites
    n = mock.Mock(spec=ast.Import)
    n.names = [
        mock.Mock(spec=ast.alias, name='g.h.i')
    ]

# Generated at 2022-06-12 03:35:31.098109
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from typing import Dict
    class MyBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo.baz1', 'bar.baz1'),
            ('foo.bar.baz2', 'bar.baz2'),
            ('foo.bar.baz3', 'bar.baz3')
        ]
        def _get_replaced_import_from_part(self, module, alias, names_to_replace):
            return ast.parse("from {}.{} import 'as'".format(module, alias)).body[0]

    node = ast.parse("from foo.bar import baz1, baz2, baz3, *, something")

# Generated at 2022-06-12 03:35:41.622199
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    import pytest
    from ..types import CompilationTarget

    rewrites = {'six.moves': 'six.moves.urllib.parse'}
    target = CompilationTarget.PY27

    class Rewriter(BaseImportRewrite):
        rewrites = [(rewrite, current) for rewrite, current in rewrites.items()]
        target = target


# Generated at 2022-06-12 03:35:47.430451
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    import_from = ast3.parse('from datetime import datetime')
    visitor = BaseImportRewrite(import_from)
    assert isinstance(visitor.visit(import_from), ast3.ImportFrom)
    visitor.rewrites = [
        ('datetime', 'dateutil.parser')]
    rewrite = visitor.visit(import_from)
    assert isinstance(rewrite, ast3.Try)

# Generated at 2022-06-12 03:36:09.381240
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    tree = ast.parse("import old_module")
    result = TestBaseImportRewrite.transform(tree)
    assert result.tree == ast.parse("""
    try:
        import old_module
    except ImportError:
        import new_module
    """)
    assert result.changed



# Generated at 2022-06-12 03:36:17.405211
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test_utils import get_test_tree

    class ImportRewrite(BaseImportRewrite):
        target = 'py36'
        rewrites = [('foo', 'bar')]

    tree = get_test_tree('import foo')
    transformer = ImportRewrite(tree)

    expected_body = '[import bar\ntry:\n    import foo\nexcept ImportError:\n    pass]'
    assert astor.to_source(transformer.visit(tree.body[0])) == expected_body


# Generated at 2022-06-12 03:36:25.185635
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    '''
    Tests for simple import
    '''
    tree = ast.parse("import os")
    t = BaseImportRewrite(tree)
    t.rewrites = [('os', 'some_os')]
    tree = t.visit(tree)
    assert tree == ast.parse("""
        try:
            import os
        except ImportError:
            import some_os as os
    """)

    '''
    Tests for import with dotted name
    '''
    tree = ast.parse("import os.path")
    t = BaseImportRewrite(tree)
    t.rewrites = [('os', 'some_os')]
    tree = t.visit(tree)

# Generated at 2022-06-12 03:36:35.731097
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    class TestClass(unittest.TestCase):
        def test_with_simple_import(self):
            transformer = BaseImportRewrite()
            transformer.rewrites = [('six', 'six_mock')]

            node = ast.parse('import six')

            result = transformer.visit_Import(node.body[0])

            self.assertIsInstance(result, ast.Try)
            self.assertEqual(len(result.body), 1)
            self.assertIsInstance(result.body[0], ast.Import)
            self.assertEqual(result.body[0].names[0].name, 'six_mock')
            self.assertEqual(result.body[0].names[0].asname, None)


# Generated at 2022-06-12 03:36:41.231624
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    input = ast.parse("import test")
    expected_node = ast.parse("try:\n    import test\nexcept ImportError:\n    import new_test")
    expected = ast.Module([expected_node])
    class Dummy(BaseImportRewrite):
        rewrites = [("test", "new_test")]

    assert ast.dump(expected) == ast.dump(Dummy.transform(input).tree)

# Generated at 2022-06-12 03:36:50.499089
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typing import List, Tuple
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import expr
    from typed_ast.ast3 import expr_context
    from typed_ast.ast3 import stmt
    from typed_ast.ast3 import compiler
    tree = ast.parse("""from module import A, B:
                        from module import C
                        from module import *
                        from module.submodule import D
                        from module.submodule import E
                        from module.submodule import *
                     """)
    result = BaseImportRewrite.transform(tree)
    expected = ast.TryExcept()

# Generated at 2022-06-12 03:36:59.636046
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import as_snippet

    from typing import List
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import ImportFrom
    from typed_ast.ast3 import alias

    class Test(BaseImportRewrite):
        rewrites = [
            ('foo1', 'bar1'),
            ('foo2', 'bar2')]

        def visit_ImportFrom(self, node: ImportFrom) -> Union[ImportFrom, AST]:
            return super().visit_ImportFrom(node)


# Generated at 2022-06-12 03:37:09.160007
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import pyl3.asttools.transforms.import_rewrite as import_rewrite


# Generated at 2022-06-12 03:37:17.962265
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.tester import *

    # import <something>
    class_decl = astor.code_to_ast("""class A:
                                            pass
                                    """)

    import_ = ast.Import(names=[ast.alias(name='something',
                                         asname=None)])
    class_decl.body[0].decorator_list.append(import_)

    # replace import module with try/except
    rewrites = [('something', 'something1')]
    expected = astor.code_to_ast("""class A:
                                        pass
                                """)
    expected_body = expected.body[0].decorator_list

# Generated at 2022-06-12 03:37:27.583891
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass(BaseImportRewrite):
        rewrites = [
            ('old', 'new')
        ]

        def visit_Import(self, node):
            return super().visit_Import(node)

    test_module = ast.parse('import old')

    test_class = TestClass(test_module)
    test_class.visit(test_module)


# Generated at 2022-06-12 03:37:53.900726
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import_from = ast.ImportFrom(module='boto3.s3.transfer',  # type: ignore
                                 names=[ast.alias(name='S3Transfer',  # type: ignore
                                                  asname=None)],
                                 level=0)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('boto3.s3.transfer', 'boto3.s3.transfer2')]

    result = TestImportRewrite.transform(import_from).tree


# Generated at 2022-06-12 03:38:02.132721
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("""from django import db\nfrom models import Model\nfrom django.test.testcase import TestCase\nfrom django.core.exceptions import ValidationError""")
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON27
        rewrites = [
            ('django.core.exceptions', 'exceptions')
        ]

    TestTransformer.transform(tree)
    assert tree_equal(tree, ast.parse("""from django import db
from models import Model
from django.test.testcase import TestCase
try:
    from django.core.exceptions import ValidationError
except ImportError:
    from exceptions import ValidationError"""))

# Generated at 2022-06-12 03:38:12.421697
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_rewrite = BaseImportRewrite
    import_rewrite.rewrites = [('old', 'new')]
    f_test = [
        ast.Import(names=[ast.alias(name='old', asname='new')]),
        ast.Import(names=[ast.alias(name='old.foo.bar', asname='new_foo_bar')]),
        ast.Import(names=[ast.alias(name='old', asname='new')]),
        ast.Import(names=[ast.alias(name='old.foo.bar', asname='new_foo_bar')])
    ]

# Generated at 2022-06-12 03:38:16.332513
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # test case for alias with name equal to module name
    rewrites = [('os', 'os_new_module')]
    node = parse('from os import path').body[0]
    transformer = BaseImportRewrite(node)
    transformer.rewrites = rewrites  # type: ignore
    node = transformer.visit_ImportFrom(node)
    node_correct = parse('try:\n    from os import path\nexcept ImportError:\n    from os_new_module import path')
    assert are_ast_equal(node_correct.body[0], node)

    # test case for alias with name not equal to module name
    node = parse('from os import path, name').body[0]
    transformer = BaseImportRewrite(node)
    transformer.rewrites = rewrites  # type: ignore
    node = transformer

# Generated at 2022-06-12 03:38:22.673360
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import astor
    from .visitor import BaseVisitor
    from ..parser.rewriter import ast_visitor

    class NamesExtractor(BaseVisitor):

        def __init__(self):
            super().__init__()
            self.names = []  # type: List[str]

        def visit_Import(self, node):
            for alias in node.names:
                self.names.append(alias.name)

        def visit_ImportFrom(self, node):
            for alias in node.names:
                self.names.append(alias.name)

    import sys
    import re
    import datetime
    import typing
    import typing_extensions as _

    class ImportRewriteTransformer(BaseImportRewrite):
        rewrites = [('typing_extensions', 'typing')]


# Generated at 2022-06-12 03:38:31.185718
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import inspect
    import ast as ast3
    import pytest
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast3 as typed_ast3
    from ..utils.source_code import source_code
    from ..types import CompilationTarget, TransformationResult

    class ImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON_35

        rewrites = [
            ('typing', 'typed_ast.ast3')
        ]

    def test_module():
        @source_code(target=ImportRewrite.target)
        def fn():
            from typing import Callable, cast


# Generated at 2022-06-12 03:38:40.650363
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    node = ast.Import(names=[ast.alias(name='logging', asname=None)])
    expected_node = ast.Try(body=node.body,
                            handlers=[],
                            orelse=[],
                            finalbody=[])
    # When
    class TestTransformer(BaseImportRewrite):
        rewrites = [('logging', 'mylogger')]
        tree = None  # type: ast.AST
        node_transformed = False

        @classmethod
        def transform(cls, tree):
            cls.tree = tree
            cls.node_transformed = cls.visit_Import(node) == expected_node
            return TransformationResult(tree, True, [])

    TestTransformer.transform(None)
    # Then
    assert TestTransformer.node

# Generated at 2022-06-12 03:38:48.012726
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class A(BaseImportRewrite):
        rewrites = [('a', 'b')]

    assert ast.dump(ast.parse('''
from a import x
''')) == ast.dump(A.transform(ast.parse('''
from a import x
'''))[0])
    assert ast.dump(ast.parse('''
from b import x
''')) == ast.dump(A.transform(ast.parse('''
from a import x
'''))[0])
    assert ast.dump(ast.parse('''
from a.b import x
''')) == ast.dump(A.transform(ast.parse('''
from a.b import x
'''))[0])