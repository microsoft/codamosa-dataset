

# Generated at 2022-06-12 03:28:57.223845
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = '_backports_abc'
    to = 'backports.abc'

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [(from_, to)]

    tree = ast.parse("""
    from ._backports_abc import ABC
    """)

    result = TestImportRewrite.transform(tree)

# Generated at 2022-06-12 03:29:07.982701
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import re, sys
    import astor
    from unittest.mock import MagicMock
    from astmonkey import transformers
    from astmonkey import visitors
    from astor.code_gen import to_source
    from jinja2 import Template
    from ..transpilers import BaseImportRewrite


    class BaseImportRewrite_(BaseImportRewrite):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._tree_changed = False

    transpiler = BaseImportRewrite_(None)


# Generated at 2022-06-12 03:29:14.313589
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from tests.utils.utils import assert_transformation_result

    tree = ast.parse('import foo.bar')
    tree, changed = BaseImportRewrite.transform(tree, rewrites=[('foo', 'baz')])
    assert_transformation_result(
        tree,
        [
            'try:',
            '    import foo.bar',
            'except ImportError:',
            '    import baz.bar',
            '',
        ],
        changed
    )



# Generated at 2022-06-12 03:29:22.666870
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.Import(
        names=[ast.alias(name='a', asname='b')])
    x = BaseImportRewrite(None)
    assert x._get_matched_rewrite('a') == ('a', 'a.b')
    assert x._get_matched_rewrite('b') is None
    assert x._replace_import(node, 'a', 'a.b') == ast.Try(body=[ast.Import(
        names=[ast.alias(name='a.b', asname='b')])],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()), name=None,
                                    body=[ast.Import(names=[ast.alias(name='a', asname='b')])])],
        orelse=[],
        finalbody=[])


# Generated at 2022-06-12 03:29:28.724316
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('from.module', 'to.module')]

    unittest.TestCase().assertEqual(
        TestTransformer.transform('import from.module', ast.parse).tree,
        ast.parse('try:\n    import from.module\nexcept ImportError:\n    import to.module')
    )



# Generated at 2022-06-12 03:29:35.910771
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = []  # type: List[Tuple[str, str]]

    def test(code, expected):
        tree = ast.parse(code)
        new_tree = TestTransformer.transform(tree).tree
        assert ast.dump(new_tree) == expected

    test('import sys, os', 'import sys, os\n')
    test('from . import sys, os', 'from . import sys, os\n')
    test('from .sys import path', 'from .sys import path\n')
    test('from .sys import *', 'from .sys import *\n')
    test('from .x.y import z', 'from .x.y import z\n')

# Generated at 2022-06-12 03:29:45.180843
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Tests if method visit_Import replaces import with try/except."""
    from ..utils.ast import parse_ast

    class MockClass(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = parse_ast("""
    import foo
    """)

    transformed_tree = MockClass.transform(tree).tree
    assert isinstance(transformed_tree.body[0], ast.Try)

    # Check statements inside of try block
    try_node = transformed_tree.body[0]
    assert isinstance(try_node.orelse[0], ast.Import)
    assert try_node.orelse[0].names[0].name == 'foo'

    assert isinstance(try_node.body[0], ast.Import)

# Generated at 2022-06-12 03:29:55.359889
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'fizzbuzz')]
        def visit_ImportFrom(self, node):
            return super().visit_ImportFrom(node)

    import_from_node = ast.parse(
"""
from foo.bar import *
""").body[0]
    transformed_node = RewriteTransformer(ast.Module(body=[ast.Import(names=[ast.alias(name="foo.bar", asname=None)])])).visit_ImportFrom(import_from_node)
    assert transformed_node.__class__ == ast.Try
    assert transformed_node.body[0].__class__ == ast.ImportFrom
    assert transformed_node.body[0].module == "fizzbuzz"

# Generated at 2022-06-12 03:30:04.054640
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import typing
    import itertools


# Generated at 2022-06-12 03:30:12.045993
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import fake
    import astor

    tree = ast.parse(fake.IMPORT_STATEMENT)
    rewrites = [('some_package', 'another_package')]

    class TestClass(BaseImportRewrite):
        rewrites = rewrites

    result = TestClass.transform(tree)
    assert result.changed
    assert result.dependencies == ['some_package']
    assert astor.to_source(result.tree).rstrip() == 'try:\n    import some_package as module\nexcept ImportError:\n    import another_package as module'

# Generated at 2022-06-12 03:30:30.678251
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]

    module = ast.parse(
        'from a.b import a as b, *\n'
        'from a.b.c import *\n'
    )
    Transformer.transform(module)

    expected = ast.parse(
        'try:\n'
        '    from a.b import a as b, *\n'
        'except ImportError:\n'
        '    from c.d import a as b, *\n'
        'try:\n'
        '    from a.b.c import *\n'
        'except ImportError:\n'
        '    from c.d.c import *\n'
    )


# Generated at 2022-06-12 03:30:41.092306
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import sys

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    class TestTransformer2(BaseImportRewrite):
        rewrites = [('old_module.submodule', 'new_module.submodule')]

    node = ast.parse('import old_module')
    result = TestTransformer.transform(node)
    assert isinstance(result.transformed_tree, ast.Try)
    if sys.version_info >= (3, 5):
        assert 'importlib' in result.dependencies
        assert 'new_module' in result.dependencies

    node = ast.parse('import old_module.submodule')
    result = TestTransformer2.transform(node)

# Generated at 2022-06-12 03:30:51.150501
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.testing import evaluate_transformation
    class ExampleTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_27
        rewrites = [
            ('six', 'six27'),
        ]


# Generated at 2022-06-12 03:30:55.240283
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from typed_astunparse.unparser import Unparser
    # test rewrite
    code = 'from foo import x, *, y'
    tree = ast.parse(code)
    r = BaseImportRewrite(tree)
    r.rewrites = [('foo', 'bar')]
    r.visit(tree)
    assert Unparser(tree).code == 'from bar import x, *, y'
    # test rewrite with alias
    code = 'from foo.bar import x as x0'
    tree = ast.parse(code)
    r = BaseImportRewrite(tree)
    r.rewrites = [('foo.bar', 'bar.foo')]
    r.visit(tree)

# Generated at 2022-06-12 03:31:02.885454
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import sys
    if sys.version_info.major == 3 and sys.version_info.minor == 8:
        import importlib.abc
        import importlib.machinery
    elif sys.version_info.major == 3 and sys.version_info.minor > 8:
        import importlib.abc
        import importlib.metadata
    elif sys.version_info.major == 2:
        import imp
    from python_modernize.fixes import BaseImportRewrite
    from python_modernize.utils import python_2_unicode_compatible

    # Check that we could prepare to run unit test
    if sys.version_info.major == 2 or (sys.version_info.major == 3 and sys.version_info.minor == 8):
        module_name = '_tmp_mock_module'


# Generated at 2022-06-12 03:31:10.212949
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = ast.parse(
        """
        from module1 import name1, name2
        
        name1 = 1
        """
    )
    import_rewriter = BaseImportRewrite(tree)
    new_tree = import_rewriter.visit_ImportFrom(tree.body[0])

    assert astor.to_source(tree) != astor.to_source(new_tree).strip(), \
        'Import from statement without replacements should not be changed'

    tree = ast.parse(
        """
        from module1 import name1, name2
        
        name1 = 1
        """
    )
    import_rewriter = BaseImportRewrite(tree)
    import_rewriter.rewrites = [('module1.name2', 'new_module2.new_name2')]
   

# Generated at 2022-06-12 03:31:20.846999
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from typed_astunparse import unparse
    from ..utils.substr import substr_replace

    def test_case(tree, expected_tree, from_, to):
        transform = BaseImportRewrite()
        transform.rewrites = [(from_, to)]
        new_tree = transform.visit(tree)
        assert(unparse(new_tree) == expected_tree)

    import_tree = ast.parse('import test')
    expected_tree = '\n'.join([
        'try:',
        '    import test',
        'except ImportError:',
        '    import test as test',
        ''
    ])
    test_case(import_tree, expected_tree, 'test', 'test')

    import_tree = ast.parse('import test as t')

# Generated at 2022-06-12 03:31:30.650203
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget
    from .base import BaseImportRewrite
    from .sphinx import SphinxRewrite
    from .sphinx import SphinxNodeTransformer
    from ..utils.snippet import body

    class ImportTest(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        target = CompilationTarget.from_version(3, 2, 0)

    class ImportTestFrom(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        target = CompilationTarget.from_version(3, 2, 0)

    tree = ast.parse(body('test_typed_ast.py'), 'test_typed_ast.py')

# Generated at 2022-06-12 03:31:38.410333
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """
    Tests the method visit_Import of BaseImportRewrite class.
    """
    import astor
    from astor.code_gen import to_source
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('collections', 'collections.abc')]

    tree = ast.parse('import collections')  # type: ast.AST
    tree = ImportRewrite.transform(tree).tree
    assert to_source(tree) == 'try:\n    import collections\nexcept ImportError:\n    import collections.abc'



# Generated at 2022-06-12 03:31:45.160034
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Arrange
    from ..transformers import BaseImportRewrite
    class Transformer(BaseImportRewrite):
        target = 'python2.7'
        rewrites = [('foo', 'bar')]
    
    tree = ast.parse('import foo')
    
    expected_tree = ast.parse('try:\n    import foo\n'
                              'except ImportError:\n    import bar')

    # Act
    result = Transformer.transform(tree)

    # Assert
    assert result.tree == expected_tree


# Generated at 2022-06-12 03:32:03.918903
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_34
        rewrites = (('old', 'new'),)

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

    tree = ast.parse('from old import a\nfrom old import b as c')
    assert str(TestTransformer.transform(tree)[0]) == 'try:\n    from new import a\nexcept ImportError:\n    from old import a\ntry:\n    from new import c as c\nexcept ImportError:\n    from old import b as c'


# Generated at 2022-06-12 03:32:08.303362
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    import_tree = ast.parse('import previous').body[0]
    tree = Test.transform(import_tree)
    assert tree.changed

    import_tree = ast.parse('import current').body[0]
    tree = Test.transform(import_tree)
    assert not tree.changed



# Generated at 2022-06-12 03:32:17.396740
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..utils.testing import assert_transformation
    from ..types import CompilationTarget

    class TestBaseImportRewrite(BaseImportRewrite):
        target = CompilationTarget.UNIVERSAL
        rewrites = [('urllib', 'urllib.request')]

    class TestCase(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            pass

        def setUp(self):
            pass


# Generated at 2022-06-12 03:32:28.433726
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    NAMES = [ast.alias(name='name1', asname='alias1'),
             ast.alias(name='name2', asname='alias2')]
    node = ast.Import(names=NAMES)
    rewrites = [('name1', 'name1_new')]
    result = BaseImportRewrite.visit_Import(None, node, rewrites)
    assert isinstance(result, ast.Try)
    assert len(result.handlers) == 1
    assert result.handlers[0].type.id == 'ImportError'
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names == NAMES
    assert result.handlers[0].body[0].names[0].name == 'name1_new'
    assert result.handlers[0].body

# Generated at 2022-06-12 03:32:37.019187
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class BaseImportRewrite_visit_ImportFrom(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'bam')
        ]
    import_from = ast.ImportFrom(module='foo',
                                 names=[ast.alias(name='a', asname='c')],
                                 level=0)
    expected = ast.ImportFrom(module='bar',
                              names=[ast.alias(name='a', asname='c')],
                              level=0)

    result = BaseImportRewrite_visit_ImportFrom.transform(import_from)
    assert expected == result.tree

# Generated at 2022-06-12 03:32:47.037863
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    t = TestImportRewrite()
    assert t.visit(ast.parse('import mod')) == ast.parse('try:\n\textend(mod)\nexcept ImportError:\n\textend(new.mod)')
    assert t.visit(ast.parse('import mod.sub')) == ast.parse('try:\n\textend(mod.sub)\nexcept ImportError:\n\textend(new.mod.sub)')
    assert t.visit(ast.parse('import mod.sub as var')) == ast.parse('try:\n\textend(mod.sub)\nimport mod.sub as var\nexcept ImportError:\n\textend(new.mod.sub)\nimport new.mod.sub as var')

# Generated at 2022-06-12 03:32:55.122390
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # no change
    node = ast.parse("import sys", "<test>", "exec").body[0]
    transform = BaseImportRewrite("<test>")
    rewrited = transform.visit(node)
    assert rewrited == node

    # change to exists module
    node = ast.parse("import tkinter", "<test>", "exec").body[0]
    transform = BaseImportRewrite("<test>")
    transform.rewrites.append(("tkinter", "Tkinter"))
    rewrited = transform.visit(node)

# Generated at 2022-06-12 03:33:04.853070
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    from ..targets.python import PythonCompilationTarget

    class DummyTransformer(BaseImportRewrite):
        target = PythonCompilationTarget
        rewrites = [
            ('future', 'six'),
        ]

    # import future
    import_future = ast.Import(names=[
        ast.alias(name='future')])

    # try:
    #     import future
    # except ImportError:
    #     import six as future
    new_import_future = DummyTransformer.transform(import_future)

    assert new_import_future.changed


# Generated at 2022-06-12 03:33:09.272110
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse

    class BaseImportRewriteTest(BaseImportRewrite):
        rewrites = [('foo', 'rewrite_foo')]

    node = ast.parse('import foo')
    expected = ast.parse('try:\n    import foo as foo\nexcept ImportError:')

    result = BaseImportRewriteTest.transform(node).tree
    assert astunparse.dump(result) == astunparse.dump(expected)


# Generated at 2022-06-12 03:33:18.027591
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    ast.ImportFrom()
    ast.Import()
    class TestTransformer(BaseImportRewrite):
        rewrites = [('tkinter', 'tkinter')]
        target = CompilationTarget.PYTHON_3_6
    code = '''
    import tkinter
    import tkinter.ttk
    from tkinter import *
    from tkinter import Tk, ttk, Label
    from tkinter.ttk import Frame, Button
    '''
    node = ast.parse(code)
    transformer = TestTransformer(node)
    transformer.visit(node)
    result = astor.to_source(node)

# Generated at 2022-06-12 03:33:50.459862
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    result = ast.parse(
        'import modulename'
    ).body[0]
    assert BaseImportRewrite.transform(result).changed is False

    result = ast.parse(
        'import modulename as module'
    ).body[0]
    assert BaseImportRewrite.transform(result).changed is False

    result = ast.parse(
        'import modulename.submodulename'
    ).body[0]
    assert BaseImportRewrite.transform(result).changed is False

    result = ast.parse(
        'import modulename.submodulename as module'
    ).body[0]
    assert BaseImportRewrite.transform(result).changed is False


# Generated at 2022-06-12 03:33:58.387510
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestClass(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    snippet = """
import foo
"""
    node = ast.parse(snippet, mode='exec')
    result = TestClass.transform(node)
    assert result.changed

    snippet = """
try:
    import foo
except ImportError:
    import bar
"""
    expected_node = ast.parse(snippet, mode='exec')
    assert astor.to_source(result.tree) == astor.to_source(expected_node)



# Generated at 2022-06-12 03:34:08.955993
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Rewrite(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib')]

    tree = ast.parse(textwrap.dedent('''\
        from os.path import join


        from os.path import join, pardir


        from os.path import abspath as ab, expanduser as ex


        from os.path import *
        '''))
    Rewrite.transform(tree)


# Generated at 2022-06-12 03:34:14.006751
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transf(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import baz')
    node = ast.ImportFrom(module='foo',
                          names=[ast.alias(name='baz', asname='baz')],
                          level=0)
    inst = Transf(tree)
    assert isinstance(inst.visit(node), ast.Try) == True


# Generated at 2022-06-12 03:34:20.054883
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_fixtures import snippet
    from ..utils import parse_snippet, dump_tree

    class DummyTransformer(BaseImportRewrite):
        target = '3.4'
        rewrites = [('foo', 'bar')]

    tree = parse_snippet(snippet)
    result = DummyTransformer.transform(tree)
    assert result.changed
    assert 'bar' in dump_tree(result.tree)

# Generated at 2022-06-12 03:34:30.504995
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import six
    import astor
    assert ast.parse(
        '''
        import sys
        import os
        import six
        from requests import *
        from six import *
        from os.path import *
        from six.moves import *
        import os.path as my_path
        from os.path import dirname as my_dir
        from six import moves as my_moves
        from six.moves import getcwd as my_getcwd
        from requests import get
        ''') == astor.code_to_ast.parse_file("sample_code.txt")
    # From class BaseImportRewrite

    import astor
    import six
    from . import base
    from . import test_base

    # Replace import from requests to six.moves
    import requests as req

# Generated at 2022-06-12 03:34:37.965958
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3

    old_module = 'old.module'
    new_module = 'new.module'
    old_name = 'old_name'
    new_name = 'new_name'
    old_full_name = '{}.{}'.format(old_module, old_name)
    new_full_name = '{}.{}'.format(new_module, new_name)

    class MockedImportRewrite(BaseImportRewrite):
        rewrites = [(old_module, new_module)]

    transform = MockedImportRewrite.transform

    # Old module name, old name
    node = ast3.ImportFrom(module=old_module, names=[ast3.alias(name=old_name)])

# Generated at 2022-06-12 03:34:46.570470
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import parse
    from pprint import pprint
    # assert node with one name == named name
    node = parse("import platform").body[0]
    target = BaseImportRewrite(None)
    pprint(target.visit_Import(node))

    # assert node with one name != named name
    node = parse("import platform").body[0]
    target = BaseImportRewrite(None)
    target.rewrites = [
        ('platform', 'platform2')
    ]
    pprint(target.visit_Import(node))

    # assert node with one name != unnamed name
    node = parse("import platform.uname").body[0]
    target = BaseImportRewrite(None)
    target.rewrites = [
        ('platform.uname', 'platform2.uname')
    ]
    p

# Generated at 2022-06-12 03:34:54.279600
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transformer = BaseImportRewrite(None)
    import_node = ast.parse(textwrap.dedent("""
        from sys import exit
        """
    ))
    import_from = import_node.body[0]
    transformer.rewrites = [('sys', 'os')]

    import_rewritten = transformer.visit_ImportFrom(import_from)

    assert transformer._tree_changed
    assert isinstance(import_rewritten, ast.Try)
    assert import_rewritten.body[0].value.module == 'os'
    assert import_rewritten.body[0].value.names[0].name == 'exit'
    assert import_rewritten.body[1].value.module == 'sys'
    assert import_rewritten.body[1].value.names[0].name == 'exit'
    assert isinstance

# Generated at 2022-06-12 03:35:03.468099
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    source = '''
    import old
    import old.module1
    import old.module2
    import old.module3 as module3
    '''
    tree = ast.parse(source)
    result = TestTransformer.transform(tree)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'old'
    assert result.tree.body[0].body[0].body[0].value.names[0].asname is None
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'new'

# Generated at 2022-06-12 03:35:52.281625
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('tensorflow', 'tf'),
            ('dill.source', 'dill.sourceutil'),
        ]

    tree = ast.parse('from test import Test')
    assert TestBaseImportRewrite.transform(tree).tree == ast.parse('from test import Test')

    tree = ast.parse('from x import Test')
    assert TestBaseImportRewrite.transform(tree).tree == ast.parse('from x import Test')

    tree = ast.parse('import tensorflow as tf')
    assert TestBaseImportRewrite.transform(tree).tree == ast.parse('import tf as tf')

    tree = ast.parse('import dill.source')

# Generated at 2022-06-12 03:36:02.286371
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    test_module = 'some_package.some_subpackage'
    expected = '''
try:
    import some_package.some_subpackage
except ImportError:
    import some_subpackage'''

    # Create tree with import statement
    node = ast.Import(names=[
        ast.alias(name=test_module,
                  asname='some_subpackage')])

    # Create test transformer
    class TestTransform(BaseImportRewrite):
        rewrites = [('some_package', '')]
    test_transform = TestTransform(ast.Module(body=[node]))

    # Transform node
    result = test_transform.visit(node)
    result_str = astor.to_source(result)

    # Compare result with expected value
    assert result_str == expected.strip()


#

# Generated at 2022-06-12 03:36:08.295104
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse('import simplejson').body[0]
    visitor = BaseImportRewrite(node)
    node = visitor.visit(node)
    assert isinstance(node, ast.Try)
    assert isinstance(node.body[0], ast.Import)
    assert isinstance(node.handlers[0], ast.ExceptHandler)
    assert isinstance(node.handlers[0].body[0], ast.Import)

# Generated at 2022-06-12 03:36:19.048389
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast

    rewrites = [
        ('a', 'b'),
        ('a.c.d', 'b.d.e')]

    tree = ast.parse(
        """\
from a import x
from a.c.d import x as y, z
from a.c.e import *

from a.c.d.e import *
from a.c.d import x as z, y as z
from a.c.d import x
from a.c.d import x as y, y as z
"""

    )


# Generated at 2022-06-12 03:36:24.841287
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    with pytest.raises(ImportError):
        import_rewrite(previous='foo', current='bar')

    tree = ast.parse('import os.path')
    inst = BaseImportRewrite(tree)
    inst.rewrites = [('os.path', 'os.pathlib')]
    inst.visit(tree)
    result = inst.generic_visit(node=tree)
    assert result.body[0].__class__ == ast.Try

    try:
        import os.path as op
    except ImportError:
        import os.pathlib as op
    assert op



# Generated at 2022-06-12 03:36:35.400696
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():  # noqa
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("""
        import foo
        import foo.bar as a
        from foo import a, b
        from foo import *
        from foo.a.b.c import *
        from foo import a as b, c as d
        from foo.a import b as c
        from foo import (a, b, c)
        from foo.a import (b,)
        from foo.a import (b as c,)
    """)

    Transformer.transform(tree)

# Generated at 2022-06-12 03:36:37.747290
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import ast, typed_ast.ast3
    module = typed_ast.ast3.parse('import sys')
    tree = typed_ast.ast3.walk(module, BaseImportRewrite())
    assert(typed_ast.ast3.dump(tree) == "Try(body=[Import(names=[alias(name='sys', asname=None)])],\
                                          orelse=[], finalbody=[])")


# Generated at 2022-06-12 03:36:46.967984
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = []

    # rewrites nothing
    import_from = ast.ImportFrom(module='module_name',
                                 names=[ast.alias(name='some_name', asname='some_asname')],
                                 level=0)
    res = Transformer(import_from).visit(import_from)
    assert isinstance(res, ast.ImportFrom)
    assert res == import_from

    # rewrites module name
    import_from = ast.ImportFrom(module='module_name',
                                 names=[ast.alias(name='some_name', asname='some_asname')],
                                 level=0)
    transformer = Transformer(import_from)

# Generated at 2022-06-12 03:36:55.857448
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget
    from .rewrite_imports import BaseImportRewrite

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_37
        rewrites = [('prev.mod', 'curr.mod')]

    tree = ast.parse("import prev.mod")
    result = TestTransformer.transform(tree)
    assert result.changed

    expected_tree = ast.parse("""
try:
    import prev.mod as mod
except ImportError:
    import curr.mod as mod
    """.strip())

    assert ast.dump(expected_tree) == ast.dump(result.tree)



# Generated at 2022-06-12 03:37:05.303097
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # "from urllib.request import Request"
    from_node = ast.ImportFrom(module='urllib.request', names=[ast.alias(name='Request',
                                                                          asname='Request')],
                               level=0)
    # "try:"
    try_node = ast.Try(body=[from_node],
                       handlers=[],
                       orelse=[],
                       finalbody=[],
                       lineno=1,
                       col_offset=0)
    # "except ImportError:"
    except_node = ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[from_node.copy()],
                                    lineno=9,
                                    col_offset=0)
    # "from urllib2 import

# Generated at 2022-06-12 03:37:46.328761
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    import example
    from example import myclass

    class ExampleImportRewrite(BaseImportRewrite):
        rewrites = [('example', 'mock_example')]

    tree = ast.parse("""
    import example
    from example import myclass
    """)

    transformed = ExampleImportRewrite.transform(tree)[0]
    transformed = astor.to_source(transformed)
    assert transformed == """\
try:
    import example
except ImportError:
    import mock_example as example
try:
    from example import myclass
except ImportError:
    from mock_example import myclass as myclass
"""



# Generated at 2022-06-12 03:37:55.764441
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('requests', 'urllib.request')
        ]

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self._visited_nodes = []

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            self._visited_nodes.append(node)
            return super().visit_ImportFrom(node)

    tree = ast.parse('from requests import *')
    result = TestTransformer.transform(tree)
    assert result.tree != tree
    assert result.tree != tree.body[0]

    visited_nodes = result.tree.body  # type: ignore

# Generated at 2022-06-12 03:38:04.986305
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_utils import transform
    from .test_utils import assert_transformer_output

    assert_transformer_output(
        'import itertools as ittools',
        'import itertools as ittools',
        BaseImportRewrite,
        rewrites=[('itertools', 'backports.itertools')],
        target=CompilationTarget.PY38)

    assert_transformer_output(
        'from itertools import izip as zip',
        'import itertools as __old_ittools\n'
        'from backports.itertools import izip as zip',
        BaseImportRewrite,
        rewrites=[('itertools', 'backports.itertools')],
        target=CompilationTarget.PY38)


# Generated at 2022-06-12 03:38:13.618891
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import six

    import_ = ast.Import(names=[
        ast.alias(name='six',
                  asname='six')])

    try:
        import_rewrite.apply(import_,
                             from_='six',
                             to='six.moves')
    except ImportError:  # pragma: no cover
        pass

    rewrite = BaseImportRewrite(import_)
    rewrite.rewrites = [('six', 'six.moves')]
    result = rewrite.visit(import_)

    assert isinstance(result, ast.Try)
    assert result.body[0].names[0].name == 'six.moves'


# Generated at 2022-06-12 03:38:20.671724
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test_utils import assert_component_equal

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('a.b', 'a.c')
        ]

        def visit(self, tree: ast.AST) -> ast.AST:
            return self.visit_ImportFrom(tree)

    assert_component_equal(
        TestImportRewrite.transform(
            ast.parse("from a.b import x").body[0]).tree,
        """
        try:
            from a.b import x
        except ImportError:
            from a.c import x
        """)


# Generated at 2022-06-12 03:38:26.914249
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='module', names=[ast.alias(name='name')], level=0)
    assert BaseImportRewrite._replace_import_from_module(None, 'module', 'module2')._fields == \
        ast.Try(
            body=[ast.ImportFrom(module='module', names=[ast.alias(name='name')], level=0)],
            handlers=[ast.ExceptHandler(type=None, name=None, body=[], lineno=0, col_offset=0)],
            orelse=[],
            finalbody=[], lineno=0, col_offset=0)._fields

# Generated at 2022-06-12 03:38:36.114952
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_from = ast.ImportFrom(module='foo', names=[ast.alias(name='name', asname='asname')], level=0)
    expected = ast.Try(body=[ast.ImportFrom(module='foo', names=[ast.alias(name='name', asname='asname')], level=0)],
                       handlers=[ast.ExceptHandler(type=None, name=None,
                                                   body=[ast.ImportFrom(module='bar',
                                                                        names=[ast.alias(name='name',
                                                                                         asname='asname')],
                                                                        level=0)])],
                       orelse=[], finalbody=[])


# Generated at 2022-06-12 03:38:44.745246
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest

    from ..utils.testing import get_ast

    class TestCase(unittest.TestCase):
        def test_simple(self):
            source = '''from example import *'''
            expected = '''try:
    from example import *
except ImportError:
    from some.example import *'''
            tree = get_ast(source)

            class T(BaseImportRewrite):
                rewrites = [('example', 'some.example')]

            T.transform(tree)
            self.assertEqual(ast.dump(tree, include_attributes=True), expected)

        def test_alias(self):
            source = '''from example import foo, bar as baz'''