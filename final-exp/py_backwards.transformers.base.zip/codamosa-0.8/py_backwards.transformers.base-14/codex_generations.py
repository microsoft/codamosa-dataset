

# Generated at 2022-06-12 03:28:57.740435
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('argparse', 'docopt')]

    source = ast.parse('import argparse')
    result = ImportRewrite.transform(source)
    assert result.tree == ast.parse(
        'import_rewrite(previous=import argparse, current=import docopt)')
    assert not result.tree_changed
    assert result.dependencies == []



# Generated at 2022-06-12 03:29:01.551973
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    target = ast.parse("import foo", '<unknown>', 'exec')
    result = BaseImportRewrite.transform(target)
    assert result.tree.body[0].names[0].name == 'foo'


# Generated at 2022-06-12 03:29:11.627880
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('django.views.generic.base', 'django.views'),
        ]

    code = """
        import datetime
        from django import forms

        from django.views.generic.base import View
        from django.http import HttpResponse
        from django.views.generic.base import TemplateView

        from django.views.generic.base import ContextMixin

        from django.views import generic
    """

    tree = ast.parse(code)
    TestTransformer.transform(tree)


# Generated at 2022-06-12 03:29:21.026855
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # previous: 'import x'
    previous = ast.Import(names=[
        ast.alias(name='x',
                  asname=None)])

    # current: 'import y'
    current = ast.Import(names=[
        ast.alias(name='y',
                  asname=None)])

    # expected: 'try:
    #                import x
    #            except ImportError:
    #                import y
    #            '
    expected = ast.Try(
        body=[previous],
        handlers=[ast.ExceptHandler(
            type=ast.Name(
                id='ImportError',
                ctx=ast.Load()),
            name=None,
            body=[current])],
        orelse=[],
        finalbody=[])

    import_rewrite.body[0] = current

    assert BaseImport

# Generated at 2022-06-12 03:29:29.470866
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('utils', 'utils_v1')]

    tree = ast.parse('''
from utils import simple_module
from utils.apitools import Fake
''')
    tree = Rewrite.transform(tree)
    assert tree.code == '''
try:
    from utils import simple_module
except ImportError:
    from utils_v1 import simple_module

try:
    from utils.apitools import Fake
except ImportError:
    from utils_v1.apitools import Fake
'''



# Generated at 2022-06-12 03:29:34.824863
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_compare import ast_compare

    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('abc', 'def')]

    tree = ast.parse('import abc')
    transformer = TestTransformer(tree)
    changed = transformer.visit(tree)

    expected = ast.parse('try:\n'
                         '    import abc\n'
                         'except ImportError:\n'
                         '    import def')

    assert ast_compare(changed, expected)



# Generated at 2022-06-12 03:29:44.376912
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('tensorflow', 'tf'), ('tensorflow.keras', 'tf.keras')]

    source = """
import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras import layers as keras_layers
from tensorflow import layers as tf_layers
from tensorflow.keras import layers
"""
    tree = ast.parse(source)
    TestImportRewrite.transform(tree)
    result = ast.unparse(tree).strip()

# Generated at 2022-06-12 03:29:50.300992
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.snippet import get_ast

    class XStaticMethod(BaseImportRewrite):
        rewrites = [
            ('collections.abc', 'collections')
        ]

    tree = get_ast('from collections.abc import Hashable, Mapping')
    result = XStaticMethod.transform(tree)
    assert result.changed
    assert 'import Hashable, Mapping' in result.get_source()
    assert 'from collections import Hashable, Mapping' in result.get_source()



# Generated at 2022-06-12 03:29:56.863380
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('from old import something else, anything as else2')
    transformed = ImportRewrite.transform(tree)
    expected = ast.parse('try:\n    from old import something else, anything as else2\nexcept ImportError:\n    from new import something else, anything as else2')
    assert ast.dump(transformed.tree) == ast.dump(expected)

# Generated at 2022-06-12 03:30:04.669012
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    src = """
from module import obj
"""
    tree = ast.parse(src)

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('module', 'module2')]

    TestImportRewrite.transform(tree)
    code = compile(tree, '<test>', mode='exec')
    ns = {}

    exec(code, ns)
    assert ns['obj']

    ns = {}
    tree = ast.parse(src)
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('module', 'module_')]

    TestImportRewrite.transform(tree)
    code = compile(tree, '<test>', mode='exec')
    exec(code, ns)
    assert ns['obj']


# Generated at 2022-06-12 03:30:19.320905
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest as ut

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Test(ut.TestCase):
        def runTest(self):
            node = ast.parse('import foo').body[0]
            result = DummyTransformer.transform(node)
            self.assertTrue(result.changed)

# Generated at 2022-06-12 03:30:28.320484
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astor
    import io

    code = 'from test import test2\nfrom test import *\nfrom test import test3 as test3_1'

    module = ast.parse(code)
    test = BaseImportRewrite()
    test.rewrites = [('test', 'newtest')]

    with io.StringIO() as f:
        f.write('import newtest\n')
        f.write('from newtest import test2\n')
        f.write('from newtest import test3_1\n')
        expected = f.getvalue()

    test.visit(module)

    assert astor.to_source(module) == expected


# Generated at 2022-06-12 03:30:38.682799
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformer import BaseImportRewrite

    # Test case where nothing should be changed
    node = ast.parse('import foo').body[0]
    assert node == BaseImportRewrite.generic_visit(BaseImportRewrite, node)

    # Test case where node should be rewrited
    node = ast.parse('import foo').body[0]
    assert node is not BaseImportRewrite(None)._replace_import(node, 'foo', 'bar')

    # Test case where import should be replaced
    node = ast.parse('import foo').body[0]
    tree_changed, new_node = BaseImportRewrite(None).visit_Import(node)
    assert node is not new_node

    # Test case where import should be replaced
    node = ast.parse('import foo').body[0]

# Generated at 2022-06-12 03:30:46.421713
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    transformer = BaseImportRewrite()
    assert transformer.visit(ast.Import(names=[ast.alias(name='foo', asname=None)])) == ast.Import(names=[ast.alias(name='foo', asname=None)])
    transformer.rewrites = [("foo", "bar")]
    assert transformer.visit(ast.Import(names=[ast.alias(name='foo', asname=None)])) == ast.Try(body=[ast.Import(names=[ast.alias(name='bar', asname=None)])], handlers=[ast.ExceptHandler(type=None, name=None, body=[ast.Import(names=[ast.alias(name='foo', asname=None)])])], orelse=[])
    transformer.rewrites = [("foo", "bar")]


# Generated at 2022-06-12 03:30:51.396389
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'os'
    to = 'my_os'

    rewrites = [
        (from_, to)
    ]

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites
        target = None


# Generated at 2022-06-12 03:31:00.765253
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():  # type: () -> None
    import unittest.mock as mock

    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new'),
                    ('old.exceptions', 'new.other')]

    # Comment for test case
    def test1():  # type: () -> None
        input = ast.parse('''import name''')
        result = TestTransformer.transform(input)
        assert not result.changed

    # Comment for test case
    @mock.patch('nuitka.utils.snippet.extend', mock.Mock())
    def test2():  # type: () -> None
        input = ast.parse('''import name.name2''')
        result = TestTransformer.transform(input)
        assert not result.changed

    # Comment for test case


# Generated at 2022-06-12 03:31:06.996089
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewriter(BaseImportRewrite):
        rewrites = [('math', 'mathematics')]

    tree = parse(dedent('''
    import math as m
    '''))
    expected_tree = parse(dedent('''
    try:
        import math as m
    except ImportError:
        import mathematics as m
    '''))
    assert ImportRewriter.transform(tree).tree.body[0].body == expected_tree.body[0].body



# Generated at 2022-06-12 03:31:14.874113
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
	# Test data:
	import_name = ast.Import([ast.alias(name="typing",asname="t")])
	source_code = "import typing as t"
	expected_source_code = "try:\n    import typing as t\nexcept ImportError:\n    import backports.typing as t"

	# Test assertions
	tester = BaseImportRewrite(import_name)
	result = tester.visit_ImportFrom(import_name)
	assert ast.dump(result) == ast.dump(ast.parse(expected_source_code).body[0])


# Generated at 2022-06-12 03:31:21.938187
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import_ = ast.Import(names=[
        ast.alias(name='os', asname='replacement')])
    rewrites = [('os', 'os_module')]
    instance = BaseImportRewrite.__new__(
        BaseImportRewrite, tree=None, rewrites=rewrites)
    instance._tree_changed = False
    instance.visit_Import(import_)
    assert astor.to_source(import_) == 'import os_module as replacement'
    assert instance._tree_changed is True



# Generated at 2022-06-12 03:31:32.432052
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast.ast3 as ast  # type: ignore

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.RE
        rewrites = [
            ('re', 're'),
            ('re.sub', 'sub.sub')
        ]

    class_names = {
        're',
        'sub'
    }

    def check(node: ast.AST, expected: ast.AST) -> None:
        transformer = TestTransformer(node)
        result = transformer.visit(node)
        assert result == expected

        result_names = {
            alias.name for alias in ast.walk(result)
            if isinstance(alias, ast.alias)
        }

        assert result_names == class_names


# Generated at 2022-06-12 03:31:50.353242
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import target_compiler

    compiler = target_compiler.compilers[CompilationTarget.python2]
    assert isinstance(compiler.compilers[0], BaseImportRewrite)

    for from_, to in compiler.compilers[0].rewrites:
        tree = ast.parse('import {}'.format(from_))
        expected = 'try:\n    import {}\nexcept ImportError:\n    import {}'.format(from_, to)
        res = compiler.compile(tree)
        assert res.code == expected



# Generated at 2022-06-12 03:32:00.519727
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast

    code = 'import numpy as np'
    tree = ast.parse(code)
    node = tree.body[0]
    result = BaseImportRewrite(tree).visit_Import(node)
    expected = ast.parse(
        "try:\n    import numpy.core._methods as np\n"
        "except ImportError:\n    import numpy as np"
    )
    assert astor.to_source(result) == astor.to_source(expected)

    code = 'from numpy import einsum'
    tree = ast.parse(code)
    node = tree.body[0]
    result = BaseImportRewrite(tree).visit_Import(node)

# Generated at 2022-06-12 03:32:08.549285
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as _ast
    # import a.b as ab, c.d as cd, e.f as ef
    node = _ast.ImportFrom(module='module_name', level=0, names=[
        _ast.alias(name='a.b', asname='ab', asname_lineno=0, name_lineno=0, col_offset=0),
        _ast.alias(name='c.d', asname='cd', asname_lineno=0, name_lineno=0, col_offset=0),
        _ast.alias(name='e.f', asname='ef', asname_lineno=0, name_lineno=0, col_offset=0)])
    # import a.b as ab, c.d as cd, e as ef
    new_node = _ast.ImportFrom

# Generated at 2022-06-12 03:32:17.534248
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    node = ast.Import(
        names=[ast.alias(name='foo', asname=None)]
    )
    result = Transformer.transform(node)
    assert result.changed, "Tree was changed"


# Generated at 2022-06-12 03:32:28.538433
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import textwrap
    from py2web.compilers.base import BaseImportRewrite

    class Python2ModuleNameNotMatch(BaseImportRewrite):
        rewrites = [('os', 'os3')]

    tree = ast.parse('import math')
    transformer = Python2ModuleNameNotMatch(tree)
    new_tree = transformer.visit(tree)
    assert new_tree == tree

    class Python3ModuleNameMatch(BaseImportRewrite):
        rewrites = [('os', 'os3')]

    tree = ast.parse('import os')
    transformer = Python3ModuleNameMatch(tree)
    new_tree = transformer.visit(tree)

# Generated at 2022-06-12 03:32:35.699159
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Test(unittest.TestCase):
        def test(self):
            tree = ast.parse('import foo')
            transformed = TestTransformer(tree).visit(tree)
            self.assertEqual(astunparse.unparse(transformed),
                             'try:\n    import foo\nexcept ImportError:\n    import bar')

    unittest.main()


# Generated at 2022-06-12 03:32:42.645191
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='os.path',
                          names=[ast.alias(name='path',
                                           asname='Path'),
                                 ast.alias(name='listdir')],
                          level=0)
    orig = ast.ImportFrom(module='os.path',
                          names=[ast.alias(name='path',
                                           asname='Path'),
                                 ast.alias(name='listdir')],
                          level=0)
    trans = BaseImportRewrite(None)
    trans._get_matched_rewrite = lambda s: ('os.path', 'pathlib')

# Generated at 2022-06-12 03:32:50.955737
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import unparse
    from ..typing import type_alias_rewrites
    from ..specialobjects import SPECIAL_OBJECTS
    from . import type_alias_rewrite

    input = """
try:
    from typing import Dict, List, Tuple
except ImportError:
    from typing import Dict, List, Tuple
"""
    # test 1
    rewrites = SpecialObjectsTransformer.rewrites + type_alias_rewrites
    for rewrite in rewrites:
        # test 1.1
        node = ast.parse(input)
        visitor = BaseImportRewrite(node)
        module = visitor.visit(node)
        new_input = unparse.unparse(module)

# Generated at 2022-06-12 03:33:00.149769
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    source = """
import six
import sys
print(six.PY3)
if six.PY3:
    import django
else:
    import django.utils
"""
    tree = ast.parse(source)
    cls = type('BaseImportRewrite', (BaseImportRewrite,), {'rewrites': [('six', 'builtins')]})
    result = cls.transform(tree)
    assert result.tree is not tree
    assert result.was_changed


# Generated at 2022-06-12 03:33:06.553199
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from .base import BaseImportRewrite
    import_from_ast = ast.parse("from typing import List, Dict").body[0]

    class DummyBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ("typing", "typing3")
        ]

    DummyBaseImportRewrite.transform(import_from_ast)
    assert ast.dump(import_from_ast) == "try:\n    from typing import List, Dict\nexcept ImportError:\n    from typing3 import List, Dict"

# Generated at 2022-06-12 03:33:25.332267
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # method under test is inherited
    import unittest.mock as mock
    class MockBaseImportRewrite(BaseImportRewrite):
        pass

    transformer = mock.Mock(spec=MockBaseImportRewrite)
    transformer.visit = mock.Mock()

    node = ast.parse('import foo').body[0]
    transformer.visit_ImportFrom(node)
    transformer.visit.assert_called_with(node)

    node = ast.parse('from foo import bar').body[0]
    transformer.visit_ImportFrom(node)
    transformer.visit.assert_called_with(node)

    module_rewrite = [('foo_old', 'foo_new')]
    transformer.rewrites = module_rewrite

    node = ast.parse('import foo_old').body[0]


# Generated at 2022-06-12 03:33:30.405048
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from os import path, environ')
    rewrite = BaseImportRewrite(tree)
    result = rewrite.visit_ImportFrom(tree.body[0])
    assert result.body[1].body[1].names[0].name == 'path'
    assert result.body[1].body[1].names[1].name == 'environ'
    assert result.body[1].body[0].names[0].name == 'os.path'
    assert result.body[1].body[0].names[1].name == 'os.environ'


# Generated at 2022-06-12 03:33:33.062332
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_codegen import test_visit_Import
    test_visit_Import(BaseImportRewrite)


# Generated at 2022-06-12 03:33:39.916258
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..test.test_transformation import run_transformer_test
    from ..types import CompilationTarget
    from . import transformers

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('datetime', 'datetime.datetime')]

    run_transformer_test(transformers=transformers.from_parent(TestTransformer),
                         filename='03-import-rewrite.py',
                         target=CompilationTarget.PYTHON_34)



# Generated at 2022-06-12 03:33:49.567196
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Import
    from .visitor import collect_names

    class IR(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six.moves._six')
        ]

    tree = ast.parse('import six.moves.urllib.parse')
    IR.transform(tree)

    expected = 'try:\n    import six.moves._six.urllib.parse\nexcept ImportError:\n    import sixt.moves.urllib.parse'
    assert (expected == ast.unparse(tree))
    assert (collect_names(tree) == {'six.moves._six', 'six.moves'})


# Generated at 2022-06-12 03:33:59.834900
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from py2to3.utils.ast_tools import NodeVisitor

    import_snippet = """
    import unittest.mock
    """

    ast_node = ast.parse(import_snippet)
    import_node = ast_node.body[0]
    assert isinstance(import_node, ast.Import)
    assert import_node.names[0].name == 'unittest.mock'
    assert import_node.names[0].asname is None

    class MockImportRewrite(BaseImportRewrite):
        rewrites = [
            ('unittest.mock', 'mock'),
        ]

    visitor = MockImportRewrite()
    assert isinstance(visitor, NodeVisitor)
    replaced_node = visitor.visit_Import(import_node)
   

# Generated at 2022-06-12 03:34:02.045516
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import os')
    BaseImportRewrite(tree).visit_Import(tree.body[0])


# Generated at 2022-06-12 03:34:12.124986
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-12 03:34:17.646332
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import six  # type: ignore
    import os  # type: ignore
    rewrite = ('six', 'six.moves')
    import_node = ast.Import(names=[ast.alias(name='six',
                                              asname='six')])
    result_tree = BaseImportRewrite([rewrite]).visit(import_node)
    expected_tree = ast.Try()
    assert ast.dump(result_tree) == ast.dump(expected_tree)

    import_node = ast.Import(names=[ast.alias(name='six.moves',
                                              asname='six')])
    result_tree = BaseImportRewrite([rewrite]).visit(import_node)
    expected_tree = ast.Try()
    assert ast.dump(result_tree) == ast.dump(expected_tree)

    import_

# Generated at 2022-06-12 03:34:27.816186
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import random as _random

    tree = ast.parse("import random")
    tree = BaseImportRewrite.transform(tree).tree
    code = compile(tree, '', 'exec')
    exec(code)
    assert __builtins__.get('random') is _random, 'Must not rewrite import'

    tree = ast.parse("import random as r")
    tree = BaseImportRewrite.transform(tree).tree
    code = compile(tree, '', 'exec')
    exec(code)
    assert __builtins__.get('r') is _random, 'Must not rewrite import'

    tree = ast.parse("import builtins")
    tree = BaseImportRewrite.transform(tree).tree
    code = compile(tree, '', 'exec')
    exec(code)

# Generated at 2022-06-12 03:34:55.572617
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast as ast3

    class TestNodeTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        dependencies = ['bar']
        target = CompilationTarget.PYTHON_34

    t = TestNodeTransformer(None)

    import_ = ast3.parse('import os', mode='exec').body[0]
    assert t.visit(import_) == import_

    import_ = ast3.parse('import foo', mode='exec').body[0]
    assert t.visit(import_) == ast3.parse(
        """
try:
    import foo
except ImportError:
    import bar
""".strip(), mode='exec').body[0]

    import_ = ast3.parse('import foo.bar', mode='exec').body[0]
    assert t.vis

# Generated at 2022-06-12 03:35:05.058741
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTargetEnum
    from ..exceptions import TransformError

    class TestRewrite1(BaseImportRewrite):
        rewrites = [('test', 'foo')]
        target = CompilationTargetEnum.PYTHON2

    class TestRewrite2(BaseImportRewrite):
        rewrites = [('test', 'foo')]
        target = CompilationTargetEnum.PYTHON3

    # test.foo -> foo.foo
    tree = ast.parse('import test.foo')
    rewrote = TestRewrite1.transform(tree)
    assert rewrote.changed
    assert import_rewrite.get_body(previous='import test.foo', current='import foo.foo')[0] == rewrote.tree

    # test.foo -> foo.foo
    tree = ast.parse

# Generated at 2022-06-12 03:35:13.925348
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class A(BaseImportRewrite):
        def __init__(self):
            self.tree = ast.parse("""from django.conf import settings""")

        rewrites = [("django.conf", "django.conf.global_settings")]

    a = A()
    node = a.tree.body[0]
    import_from = a.visit_Import(node)

    assert isinstance(import_from, ast.Try)
    assert len(import_from.body) == 1
    assert isinstance(import_from.body[0], ast.Import)
    assert import_from.body[0].names[0].name == "django.conf.global_settings"
    assert import_from.body[0].names[0].asname == "settings"

# Generated at 2022-06-12 03:35:21.246410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Arrange
    tree = ast.parse("import my_module")
    t = BaseImportRewrite(tree=tree)
    t.rewrites = [('my_module', 'new_module')]
    
    # Act
    rewrote = t.visit_Import(node=tree.body[0])
    
    # Assert
    assert ast.dump(rewrote) == ("try:\n" +
                                 "    import my_module\n" +
                                 "except ImportError:\n" +
                                 "    import new_module")


# Generated at 2022-06-12 03:35:24.139816
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-12 03:35:31.011255
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import snippet

    tree = snippet.parse('''
import sys
import os
''')
    transformer = BaseImportRewrite()
    transformer.rewrites = [('sys', 'six')]
    transformer.visit(tree)

    expected = snippet.parse('''
import_rewrite(
    previous=ast.Import(names=[ast.alias(name='sys', asname=None)]),
    current=ast.Import(names=[ast.alias(name='six', asname=None)])
)
import os
''')
    assert tree == expected



# Generated at 2022-06-12 03:35:38.351665
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..utils.ast import parse_ast

    class ImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON_35
        rewrites = [('os', 'fake.os')]

    tree = parse_ast("""
import os
import sys

""")
    ImportRewrite.transform(tree)
    assert str(tree) == """
try:
    import os
except ImportError:
    import fake.os as os
import sys
"""



# Generated at 2022-06-12 03:35:45.405794
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = (
        ('one', 'two'),
    )
    class Transformer(BaseImportRewrite):
        rewrites = rewrites
    tree = ast.parse('import one as a')
    Transformer.visit(tree)
    expected = ''.join([
        'try:\n',
        '    import one as a\n',
        'except ImportError:\n',
        '    import two as a',
    ])
    assert ast.dump(tree) == expected



# Generated at 2022-06-12 03:35:54.677829
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-12 03:36:04.901791
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTransformer(BaseImportRewrite):
        rewrites = [('multipledispatch', 'md')]

    node = ast.Import([ast.alias(name='multipledispatch', asname='md')])
    result = ImportTransformer.transform(node)

    assert result.changed
    assert result.tree.body[0].handlers[0].name == 'ImportError'
    assert str(result.tree.body[0].handlers[0].body[0]) == \
        "extend(ast.Import([ast.alias(name='md', asname='md')]))"
    assert str(result.tree.body[0].body[0]) == \
        "extend(ast.Import([ast.alias(name='multipledispatch', asname='md')]))"



# Generated at 2022-06-12 03:36:56.635857
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    from libcst.codemod import CodemodContext, VisitorBasedCodemodCommand
    from libcst.matchers import Import
    class BaseImportRewrite(VisitorBasedCodemodCommand):
        rewrites = [(u'libcst', u'libcst_example')]
        def leave_Import(self, original_node, updated_node):
            name = (original_node.names[0]).name
            rewrite = self._get_matched_rewrite(name)

# Generated at 2022-06-12 03:37:05.418688
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from .transformers import BaseImportRewrite
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar'),
                    ('fii', 'baz')]
    tree = ast.parse('import foo\nimport foo.bar\nimport something')
    Transformer.transform(tree)
    assert ast.dump(tree) == \
"""try:
    extend(__import__('foo'))
except ImportError:
    extend(__import__('bar'))
try:
    extend(__import__('foo.bar'))
except ImportError:
    extend(__import__('bar.bar'))
__import__('something')"""


# Generated at 2022-06-12 03:37:08.992927
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    module = ast3.parse("print('Hello, World!')")

    transformer = BaseImportRewrite()
    module = transformer.transform(module)
    assert not module.changed
    assert module.tree == module.tree


# Generated at 2022-06-12 03:37:17.822560
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..visitor import BaseVisitor
    from .py3to2 import Py3to2RewriteModuleNames
    from ..types import CompilationTarget
    import os


# Generated at 2022-06-12 03:37:27.517919
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    old_import = ast.Import(names=[ast.alias(name="os", asname=None)])
    new_import = ast.Import(names=[ast.alias(name="os2", asname=None)])

    class MyImportTransformer(BaseImportRewrite):
        rewrites = [
            ('os', 'os2')
        ]

    trans = MyImportTransformer(old_import)
    result = trans.visit_Import(old_import)
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == "os"
    assert result.body[1].names[0].name == "os2"



# Generated at 2022-06-12 03:37:32.236617
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'path')]

    tree = ast.parse("import os")
    assert TestImportRewrite.transform(tree).tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='path', asname=None)])],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()), name=None,
                                    body=ast.Import(names=[ast.alias(name='os', asname=None)]))],
        orelse=[],
        finalbody=[])



# Generated at 2022-06-12 03:37:42.012733
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..parser.mypy import parse
    from ..utils.source import fix_missing_locations
    # test for replacing module
    tree = parse('from typing import Mapping')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('typing', 'typing_extensions')]
    transformer.visit(tree)
    assert 'typing_extensions.Mapping' == tree.body[0].names[0].name
    tree = parse('from random import randint')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('random', 'secrets')]
    transformer.visit(tree)
    assert 'secrets.randint' == tree.body[0].names[0].name
    tree = parse('from random import randint')

# Generated at 2022-06-12 03:37:49.054653
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class ImportTransformer(BaseImportRewrite):
        rewrites = [('libs.old', 'libs.new')]

    tr = ImportTransformer.transform(
        ast.parse('import libs.old.module_name'))
    assert tr.changed

    assert ast.dump(tr.tree) == textwrap.dedent("""\
        import_rewrite(
            previous=(
                import (
                    libs.old.module_name,
                ),
            ),
            current=(
                import (
                    libs.new.module_name,
                ),
            ),
        )
    """)

    tr = ImportTransformer.transform(
        ast.parse('import libs.old.module_name as new_module_name'))
    assert tr.changed


# Generated at 2022-06-12 03:37:58.906265
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse

    # test case 1
    #
    # before:
    # import test
    #
    # rewrites = [('test', 'mytest')]
    #
    # after:
    # try:
    #    import test
    # except ImportError:
    #    import mytest
    tree = parse('import test')
    rewrites = [('test', 'mytest')]

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    result = TestTransformer.transform(tree)

    assert result.tree.body[0].body[0].body[0].value.func.id == 'import_module'
    assert result.tree.body[0].body[0].body[0].value.args[0].s == 'test'



# Generated at 2022-06-12 03:38:08.058518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]
        target = 'py3.6'

    import_node = ast.Import(names=[
        ast.alias(name='old_module', asname='m')])
    expected = ast.Try(body=[
        ast.Import(names=[
            ast.alias(name='old_module', asname='m')])],
        handlers=[ast.ExceptHandler(type=None,
                                    name=None,
                                    body=[
            ast.Import(names=[
                ast.alias(name='new_module', asname='m')])])],
        orelse=[],
        finalbody=[])

    assert MockTransformer.transform(import_node).ast == expected