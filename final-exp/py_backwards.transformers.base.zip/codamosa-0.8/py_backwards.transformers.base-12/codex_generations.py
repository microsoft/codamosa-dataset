

# Generated at 2022-06-12 03:29:05.133209
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from . import typed_ast as typed_ast
    node = ast.Import(names=[ast.alias(name='typed_ast',
                                      asname='typed_ast')])
    # Replace typed_ast with typed_ast3
    transformer = BaseImportRewrite(node)
    rewrote = transformer.visit_Import(node)
    assert rewrote.body[0].value.args[1].module == 'typed_ast3'
    # Ensure that name is still typed_ast after import
    assert rewrote.body[0].handlers[0].name == 'typed_ast'



# Generated at 2022-06-12 03:29:09.103815
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_utils import assert_transform

    class ImportRewriteTestCase(BaseImportRewrite):
        rewrites = [('future', 'six')]


    assert_transform(ImportRewriteTestCase,
                     'import future',
                     'import six',
                     count=1)



# Generated at 2022-06-12 03:29:19.164779
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # {
    #   "module": "test",
    #   "body": [
    #     {
    #       "type": "Import",
    #       "names": [
    #         {
    #           "_fields": [
    #             "name",
    #             "asname"
    #           ],
    #           "name": "json"
    #         }
    #       ]
    #     }
    #   ]
    # }
    ast_json = {
        "module": "test",
        "body": [
            {
                "type": "Import",
                "names": [
                    {
                        "_fields": [
                            "name",
                            "asname"
                        ],
                        "name": "json"
                    }
                ]
            }
        ]
    }

   

# Generated at 2022-06-12 03:29:29.564408
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from collections import namedtuple

    Change = namedtuple('Change', ['module', 'rewrite'])

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    snippet_node = parse('import module_name')

    tree = parse('import module_name\n')
    visitor = TestImportRewrite(tree)
    res = visitor.visit_Import(snippet_node)
    assert isinstance(res, ast.Try)
    assert res.body[0].names == [ast.alias(name='module_name', asname='module_name')]
    assert res.body[1].names == [ast.alias(name='new', asname='new')]
    assert res.body[2].msg.args == parse

# Generated at 2022-06-12 03:29:35.741020
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    original_code = astor.to_source(ast.parse('''
import foo
import bar as b
from foo import x
from bar import y as w
    '''))
    expected_code = astor.to_source(ast.parse('''
try:
    import foo
except ImportError:
    import foo_rewrite as foo
import bar as b
from foo import x
from bar import y as w
    '''))
    transformer = BaseImportRewrite(ast.parse(original_code))
    transformed_tree = transformer.visit(transformer._tree)
    assert astor.to_source(transformed_tree) == expected_code.strip()


# Generated at 2022-06-12 03:29:45.073066
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node_1 = ast.parse("import numpy as np")
    node_2 = ast.parse("import numpy")
    node_3 = ast.parse("import numpy.random as npr")
    node_4 = ast.parse("import numpy.random.test as nprtest")

    rewrites = [("numpy", "tenpy"),("numpy.random", "numpy.random")]
    transformer = BaseImportRewrite(node_1)
    transformer.rewrites = rewrites

    def check_results(node, expected_node):
        result = transformer.visit_Import(node)
        expected_result = expected_node
        assert isinstance(result, ast.Try)
        assert transformer._tree_changed
        assert ast.dump(result) == ast.dump(expected_result)

    check_results

# Generated at 2022-06-12 03:29:48.900781
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class R(BaseImportRewrite):
        rewrites = [('os', '_os')]

    assert R.transform(ast.parse('import os')).tree == ast.parse(
        '''try:
    import os
except ImportError:
    import _os as os
''')



# Generated at 2022-06-12 03:29:59.785485
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Test data
    import_nodes = [ast.Import(names=[ast.alias(name='foo', asname='bar')]),
                    ast.Import(names=[ast.alias(name='foo.bar', asname='foobar')])]
    rewrites = [('foo', 'foo_rewrite')]
    expected = [ast.Try(body=[ast.Import(names=[ast.alias(name='foo_rewrite', asname='bar')])],
                       orelse=[],
                       finalbody=[],
                       handlers=[],
                       type_comment=None),
                ast.Try(body=[ast.Import(names=[ast.alias(name='foo_rewrite.bar', asname='foobar')])],
                       orelse=[],
                       finalbody=[],
                       handlers=[],
                       type_comment=None)]
   

# Generated at 2022-06-12 03:30:09.659796
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
import importlib
""")
    result_tree, changed, dependencies = BaseImportRewrite.transform(tree)
    assert not changed
    assert dependencies == []

    tree = ast.parse("""
import sys
""")
    result_tree, changed, dependencies = BaseImportRewrite.transform(tree)
    assert not changed
    assert dependencies == []

    tree = ast.parse("""
import six
""")
    result_tree, changed, dependencies = BaseImportRewrite.transform(tree)
    assert changed
    assert dependencies == ['six']
    assert ast.dump(result_tree) == """
try:
    import six
except ImportError:
    import six_legacy as six
"""


# Generated at 2022-06-12 03:30:19.572061
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('abc', 'xyz')]

    # module
    result = TestImportRewrite().visit(ast.parse('import abc'))
    assert result == ast.Try(body=[ast.Import(names=[ast.alias(name='xyz')])],
                             handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError',
                                                                      ctx=ast.Load()),
                                                        name=None,
                                                        body=[ast.Import(names=[ast.alias(name='abc')])])],
                             orelse=[],
                             finalbody=[])
    # module.name
    result = TestImportRewrite().visit(ast.parse('import abc.defg'))

# Generated at 2022-06-12 03:30:34.702632
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..utils.ast import ast_to_str
    import ast as std_ast

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_LEGACY

        rewrites = [('_abc', 'abc')]


# Generated at 2022-06-12 03:30:43.913435
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3

    target = ast3.Module(
        body=[ast3.Import(names=[ast3.alias(name='lxml', asname='lxml')])])

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('lxml', 'scrapy')]

    transformationResult = ImportRewrite.transform(target)
    assert transformationResult.tree.body[0].body[0].names[0].name == 'lxml'
    assert transformationResult.tree.body[0].body[0].names[0].asname == 'lxml'
    assert len(transformationResult.tree.body[0].body[0].body) == 1
    assert transformationResult.tree.body[0].body[0].body[0].names[0].name == 'scrapy'
    assert transformation

# Generated at 2022-06-12 03:30:52.013140
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_node = ast.parse('import module_name').body[0]
    import_node.names[0].name = 'module_name'
    transformer = BaseImportRewrite(import_node)
    transformer.rewrites = [('module_name', 'module_rewrite')]
    node = transformer.visit(import_node)
    assert node.body[0].body[0].value.func.id == 'extend'
    assert node.body[0].body[0].value.args[0].id == 'module_rewrite'



# Generated at 2022-06-12 03:30:59.483117
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Should rewrite import statements."""
    import astor  # type: ignore

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = astor.parse('''
    import foo 
    import baroo
    ''')
    ImportRewrite.transform(tree)

    expected_tree = astor.parse('''
    try:
        import foo
    except ImportError:
        import bar
    import baroo
    ''')
    assert astor.to_source(tree) == astor.to_source(expected_tree)



# Generated at 2022-06-12 03:31:08.879410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    source_code = 'import a'
    module = ast.parse(source_code)
    node = module.body[0]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a.b', 'a.b.c.d')]

    new_node = TestImportRewrite.transform(module).tree.body[0]
    assert isinstance(new_node, ast.Try)
    assert len(new_node.handlers) == 1
    assert isinstance(new_node.handlers[0], ast.ExceptHandler)
    assert new_node.handlers[0].name is None
    assert len(new_node.handlers[0].type.elts) == 1
    assert isinstance(new_node.handlers[0].type.elts[0], ast.Name)
   

# Generated at 2022-06-12 03:31:19.532507
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    from ..utils import parse_snippet_as_ast
    from ..utils.ast_helpers import compare_asts

    # test unittest decode
    class TestImportFrom(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [('GEOS', 'geos')]

    a = parse_snippet_as_ast("""
        from GEOS import geom
    """)
    b = parse_snippet_as_ast("""
        try:
            from GEOS import geom
        except ImportError:
            from geos import geom
    """)
    compare_asts(a, b, TestImportFrom.visit)
    compare_asts(b, a, TestImportFrom.visit)

    # test unittest encode

# Generated at 2022-06-12 03:31:22.041281
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import os")
    result = BaseImportRewrite.transform(tree)
    assert result.changed == False
    assert ast.dump(tree) == ast.dump(result.tree)



# Generated at 2022-06-12 03:31:32.580398
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [
            # from_, to
            ('old', 'new'),
            ('another.old', 'another.new')
        ]


# Generated at 2022-06-12 03:31:42.864628
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MockTransformer(BaseImportRewrite):
        rewrites = [
            ('django', 'myproject.django')
        ]

    tree = ast.parse(
        'import django.http\n'
        'from django.conf import settings'
    )

    res = MockTransformer.transform(tree)


# Generated at 2022-06-12 03:31:52.189475
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    # previous_import = ast.parse('import foo')
    previous_import = ast.Import(names=[ast.alias(name='foo', asname=None)])
    # current_import = ast.parse('import foo as foo_new')
    current_import = ast.Import(names=[ast.alias(name='foo', asname='foo_new')])

    # import_rewrite = ast.parse('''\
    # try:
    #     extend(previous)
    # except ImportError:
    #     extend(current)
    # ''')

# Generated at 2022-06-12 03:32:09.482301
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-12 03:32:17.181885
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse
    from .base import BaseCompiler

    class TestCompiler(BaseCompiler):
        target = 'py2'
        node_transformer_classes = [BaseImportRewrite]
        rewrites = [('foo', 'bar')]

    ast_tree = ast.parse('import foo', '<test>', 'exec')
    expected_ast_tree = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar',
                                  '<test>',
                                  'exec')

    result = TestCompiler.compile(ast_tree)
    assert result == (expected_ast_tree, True)


# Generated at 2022-06-12 03:32:22.523153
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    class NodeTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    src = 'import foo'
    node = ast.parse(src).body[0]
    inst = NodeTransformer(node)
    result = inst.visit(node)
    assert(type(result) == ast.Try)


# Generated at 2022-06-12 03:32:30.434188
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
  from typed_ast import ast3 as ast
  class Test(BaseImportRewrite):
    rewrites = [('foo', 'bar')]

  import_node = ast.Import(
    names=[ast.alias(name='foo', asname=None)])
  try_node = ast.Try(body=[import_node], 
    handlers=[ast.ExceptHandler(type=None, name=None, body=[import_node])], 
    orelse=[], finalbody=[])
  assert Test.transform(import_node).tree == try_node


# Generated at 2022-06-12 03:32:39.041205
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import my_module
    from my_module import my_name
    from my_module import my_name2, my_name3
    from smth import my_name4
    from smth import my_name5
    from smth import my_name6
    from my_module import my_name7, my_name8
    import smth, my_module

    test_class = type('TestClass', (BaseImportRewrite,), {
        'rewrites': [('my_module', 'my_module2')],
    })


# Generated at 2022-06-12 03:32:48.598011
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from pytest import raises
    from ..utils.fake_ast import import_from, import_
    from ..utils.fake_tree import fake_tree

    def test(node, expected):
        class Transformer(BaseImportRewrite):
            target = 'asyncio'
            rewrites = [('spam', 'eggs')]

        result = Transformer.transform(fake_tree(node))
        assert result.tree == fake_tree(expected)

    test(
        import_from('spam'),
        import_rewrite(
            previous=import_from('spam'),
            current=import_from('eggs'),
        ),
    )


# Generated at 2022-06-12 03:32:56.533361
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .base import BaseNodeTransformer
    from .rewrites.typing_rewrites import (
        OldStyleClassesTransformer, TypingTransformer)

    class MockTransformer(BaseNodeTransformer):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import six; print(six.moves)')
    result = MockTransformer.transform(tree)
    assert result.change
    assert result.dependencies == ['six.moves']
    assert str(result.tree) == 'try:\n    import six\nexcept ImportError:\n    import six.moves\nprint(six.moves)\n'

    tree = ast.parse('from six import moves; print(moves)')
    result = MockTransformer.transform(tree)
    assert result.change
    assert result

# Generated at 2022-06-12 03:33:02.793711
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('re', 're_module'),
        ]

    tree = ast.parse('''
import re
''')
    TestImportRewrite().transform(tree)

    expected = '''
try:
    import re
except ImportError:
    import re_module as re
'''
    assert astor.to_source(tree) == expected



# Generated at 2022-06-12 03:33:09.540826
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MyImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON_27
        rewrites = [('CoffeeScript', 'python_jsonschema_objects')]

    snippet = 'import a, b'
    node = ast.parse(snippet, mode='eval')

    transformer = MyImportRewrite(node)
    assert transformer._tree_changed is False
    assert isinstance(transformer.visit(node), ast.Expression)

    snippet = 'import a, b'
    node = ast.parse(snippet, mode='eval')
    node.body = MyImportRewrite.transform(node.body).tree
    assert transformer._tree_changed is False

    snippet = 'from . import a, b'
    node = ast.parse(snippet, mode='eval')


# Generated at 2022-06-12 03:33:13.672050
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    
    module = ast.parse('import foo as bar')
    BaseImportRewrite._replace_import(module.body[0], 'foo', 'baz')
    assert module == ast.parse('''
        try:
            import foo as bar
        except ImportError:
            import baz as bar
    ''')


# Generated at 2022-06-12 03:33:45.449151
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    # pep8
    from typing import Typing
    from ast import AST
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typing', 'typed_ast')]

    tree = ast.parse(
        '''import typing'''
    )

    tree_expected = ast.parse(
        '''try:
    import typing
except ImportError:
    import typed_ast as typing'''
    )

    transformer = TestTransformer(tree)
    n = transformer.visit(tree)
    assert n.body[0].test.left.id == 'typing'
    assert n.body[0].body[0].names[0].name == 'typed_ast'
    assert n.body[0].body[0].names

# Generated at 2022-06-12 03:33:55.775011
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor


# Generated at 2022-06-12 03:34:05.446161
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    
    result = Transformer(None).visit_Import(
        ast.Import(names=[ast.alias(name='foo', asname=None)]))
    assert isinstance(result, ast.Try)
    assert len(result.handlers) == 1
    assert isinstance(result.handlers[0].type, ast.Name)
    assert result.handlers[0].type.id == 'ImportError'
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'bar'



# Generated at 2022-06-12 03:34:14.397291
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typing import List
    from typed_ast import ast3 as ast
    b = BaseImportRewrite(None)
    node = ast.Import(names=[
        ast.alias(name="typing.typing",
                  asname=None),
        ast.alias(name="typing.List",
                  asname="List")])
    out = b.visit(node)
    assert type(out) == ast.Try
    assert type(out.body[0]) == ast.Import
    assert [str(x) for x in out.body[0].names] == ["typing.typing", "typing.List"]
    assert type(out.body[0].names[1].asname) == ast.Name
    assert out.body[0].names[1].asname.id == "List"

# Generated at 2022-06-12 03:34:24.909362
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typing

    class TestTransformer(BaseImportRewrite):
        rewrites = [('typing', 'typing2')]

    inst = TestTransformer(ast.parse(''))
    result = inst.visit_Import(ast.Import(names=[ast.alias(name='typing')]))

    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'typing'

    result = inst.visit_Import(ast.Import(names=[ast.alias(name='typing2')]))

    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'typing2'



# Generated at 2022-06-12 03:34:30.926042
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_fixture import ast_fixture, get_name_node

    class TestTransformer(BaseImportRewrite):
        rewrites = [('urllib.parse', 'urllib.parse2')]

    tree = ast_fixture("import urllib.parse")
    TestTransformer.transform(tree)

    assert get_name_node(tree)[0].value == 'urllib.parse2'


# Generated at 2022-06-12 03:34:37.361540
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    old = ast.Import(names=[ast.alias(name='old',
                                      asname='old')])
    new = ast.Import(names=[ast.alias(name='new',
                                      asname='new')])

    try_body = import_rewrite.get_body(previous=old,  # type: ignore
                                       current=new)[0]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    result = TestImportRewrite.transform(old)
    assert result.tree == try_body
    assert result.changed is True



# Generated at 2022-06-12 03:34:44.015332
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_fixture = ast.ImportFrom(
        module="test_module",
        level=0,
        names=[
            ast.alias(
                name="test_name",
                asname=None
            )
        ]
    )

    assert BaseImportRewrite._BaseImportRewrite__get_names_to_replace(
        None, import_fixture
    ) == [("test_module.test_name", None)]

    # TODO: Add unit tests for transformed import_fixture.
    # TODO: Add unit tests for visiting import rewrites.

# Generated at 2022-06-12 03:34:52.397468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock as mock 
    import textwrap

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    class Node:
        def __repr__(self):
            return '<{} at {}>'.format(self.__class__.__name__, id(self))

    node = mock.Mock(spec=Node)

    code = textwrap.dedent('''\
    import old
    ''')

    rewrote = textwrap.dedent('''\
    try:
        import old
    except ImportError:
        import new
    ''')

    tree = ast.parse(code)
    result = TestBaseImportRewrite.transform(tree)

    assert result.tree_rewrote == True
    assert result.depend

# Generated at 2022-06-12 03:34:55.756904
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from typed_ast.ast3 import parse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = parse('''
import a
''')

    tree = TestTransformer.transform(tree)[0]
    assert astor.to_source(tree) == '''
try:
    import a
except ImportError:
    import b
'''


# Generated at 2022-06-12 03:35:27.906069
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..utils.ast_helper import ast_dump
    from ..utils.python_source import SourceCode
    import astunparse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six.moves', 'stubs.six.moves')]

    class BaseImportRewriteTestCase(unittest.TestCase):
        def test_empty(self):
            source = ''
            self._test_source(source)

        def test_no_match(self):
            source = 'import foo.bar'
            self._test_source(source)

        def test_simple_match(self):
            source = 'import six.moves'
            expected = '''try:
    import six.moves
except ImportError:
    import stubs.six.moves'''

# Generated at 2022-06-12 03:35:34.708331
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ExampleImportRewrite(BaseImportRewrite):
        rewrites = [('argparse', 'argparse2')]

    tree = ast.parse("""
        import argparse

        def func():
            pass
    """)

    expected = """
        try:
            import argparse
        except ImportError:
            import argparse2


        def func():
            pass
    """

    ExampleImportRewrite.transform(tree)
    assert ast.dump(tree) == expected



# Generated at 2022-06-12 03:35:45.405346
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.testing import files_equal

    tree = ast.parse('''import foo''')
    BaseImportRewrite.rewrites = [('foo', 'bar')]
    BaseImportRewrite.transform(tree)

    assert files_equal('''try:
    import foo
except ImportError:
    import bar
''', astor.to_source(tree))

    tree = ast.parse('''import foo.bar''')
    BaseImportRewrite.rewrites = [('foo', 'bar')]
    BaseImportRewrite.transform(tree)

    assert files_equal('''try:
    import foo.bar
except ImportError:
    import bar.bar
''', astor.to_source(tree))

    tree = ast.parse('''import foo as bar''')
    BaseImport

# Generated at 2022-06-12 03:35:52.495726
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from ..utils.test_helpers import assert_code_transformation_result
    import pytest

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'typing.six')
        ]


# Generated at 2022-06-12 03:35:58.881047
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Arrange
    class MyImportRewrite(BaseImportRewrite):
        rewrites = [('A', 'B')]
    input_tree = ast.parse("""
try:
    import A
except ImportError:
    import B
""")
    expected_tree = input_tree

    # Act
    output_tree = MyImportRewrite.transform(input_tree).tree

    # Assert
    assert ast.dump(output_tree) == ast.dump(expected_tree)


# Generated at 2022-06-12 03:36:09.285249
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    source = """
import a
import a.b
import a, b
"""
    tree = ast.parse(source)
    rewriter = BaseImportRewrite(tree)

    rewriter.rewrites = [('a', 'b')]
    rewriter.visit(tree)
    assert len(tree.body) == 3

    node = tree.body[0]
    assert isinstance(node, ast.Import)
    assert node.names[0].name == 'b'

    node = tree.body[1]
    assert isinstance(node, ast.Try)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Import)
    assert node.body[0].names[0].name == 'b.b'
    assert isinstance(node.body[1], ast.Import)

# Generated at 2022-06-12 03:36:16.184105
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class Foo(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    code = '''
import foo
import foo.bar

print(foo)
'''

    code_to_compare = '''
import bar
import bar.bar

print(bar)
'''

    tree = ast.parse(code)
    Foo.transform(tree)
    assert astor.to_source(tree) == code_to_compare


# Generated at 2022-06-12 03:36:21.897356
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    node = ast.parse('import foo')
    result = MockTransformer.transform(node)

    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')
    assert ast.dump(result.tree) == ast.dump(expected)



# Generated at 2022-06-12 03:36:27.501181
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import test", 'test.py')
    results = BaseImportRewrite.transform(tree)
    assert results.tree == ast.parse("try:\n    import test\nexcept ImportError:\n    import test_rewrite", 'test.py')
    # assert results.tree == ast.parse("try:\n    import test\nexcept ImportError:\n    import test_rewrite as test", 'test.py')



# Generated at 2022-06-12 03:36:33.222275
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast import parse

    class ImportRewriter(BaseImportRewrite):
        target = "python"
        rewrites = [("foo", "bar")]

    tree = parse("import foo")
    rewritten = ImportRewriter.transform(tree)
    assert rewritten.changed is True
    assert rewritten.new == 'try:\n    import foo\nexcept ImportError:\n    import bar'



# Generated at 2022-06-12 03:37:02.701515
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..utils.inline import inline
    from .base import BaseImportRewrite
    from .typing import TypingTransformer

    tree = """
    from typing import Tuple, Union
    from typing import Tuple as T, Union as U
    from typing import (Tuple as T, Union as U)

    from typing import *

    from typing import NewType, Set

    import typing
    import typing as typ
    """

    class Rewrite(BaseImportRewrite):
        rewrites = [('typing', 'typed_ast.ast3')]

    tree = ast.parse(tree)
    tree = inline(tree, [TypingTransformer, Rewrite])


# Generated at 2022-06-12 03:37:11.998037
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module='six.moves',
                                 names=[ast.alias(name='map',
                                                  asname=None),
                                        ast.alias(name='filter',
                                                  asname=None)],
                                 level=0)
    class DummyNewTransformer(BaseImportRewrite):
        target = 'py2'
        rewrites = [('six.moves', 'itertools')]

    # `from six.moves import map, filter`
    #     should be replaced with
    # `try:
    #     from six.moves import map, filter
    # except ImportError:
    #     from itertools import map, filter`
    new_tree = DummyNewTransformer.transform(import_from)[0]

# Generated at 2022-06-12 03:37:16.530118
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('os', 'osx')]

    tree = ast.parse('import os')
    result = Test.transform(tree)
    assert result.modified

    expected = """
try:
    import os
except ImportError:
    import osx
"""
    assert ast.dump(result.tree) == expected



# Generated at 2022-06-12 03:37:26.307735
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class T(BaseImportRewrite):
        target = 'asyncio'
        rewrites = [('shutil.copy', 'shutil.copy2')]
    import shutil
    node = ast.Import(names=[ast.alias(name='shutil',
                                       asname=None)])
    tree = T.transform(node)
    assert tree.tree == node
    node = ast.Import(names=[ast.alias(name='shutil.copy',
                                       asname=None)])
    tree = T.transform(node)
    assert tree.tree == import_rewrite.get_body(previous=node,  # type: ignore
                                                current=ast.Import(names=[ast.alias(name='shutil.copy2',
                                                                                   asname='copy')]))[0]
    node

# Generated at 2022-06-12 03:37:31.138054
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import CompilationTarget, transform
    from ..utils.source import Source
    from .._pre_py36_transformer import PrePy36Transformer

    source = Source("""
from random import randint
from decimal import Decimal""")

    assert transform(
        source,
        CompilationTarget.PYTHON27,
        [PrePy36Transformer]
    ).source == '''
try:
    from random2 import randint
except ImportError:
    from random import randint
try:
    from decimal2 import Decimal
except ImportError:
    from decimal import Decimal'''


# Generated at 2022-06-12 03:37:34.149410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import random
    import_ = ast.parse('import random')
    transform_result = BaseImportRewrite(import_)
    assert transform_result.visit_Import(import_.body[0]) == import_


# Generated at 2022-06-12 03:37:44.014282
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_node_1 = ast.parse('from email.mime.image import MIMEImage').body[0]
    import_from_node_2 = ast.parse('from email.mime.audio import MIMEAudio').body[0]
    import_from_node_3 = ast.parse('from email.mime.application import MIMEApplication').body[0]
    import_from_node_4 = ast.parse('from email.mime.text import MIMEText').body[0]
    import_from_node_5 = ast.parse('from email.mime.text import MIMEText, MIMENonMultipart').body[0]
    import_from_node_6 = ast.parse('from email.mime.multipart import MIMEMultipart').body[0]
    import_from

# Generated at 2022-06-12 03:37:53.130614
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = '_portage'
    to = '_xportage'

    module = '_portage'
    name = 'Config'
    module_name = '.'.join([module, name])
    module_as_name = 'py_Config'
    old_import_from = ast.ImportFrom(module=module, names=[ast.alias(name=name,
                                                                      asname=module_as_name)], level=0)
    new_module = '_xportage'
    new_module_name = '.'.join([new_module, name])
    new_import_from = ast.ImportFrom(module=new_module, names=[ast.alias(name=name,
                                                                          asname=module_as_name)], level=0)

    expected_rewrite = ast.Try

# Generated at 2022-06-12 03:38:02.862357
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from typed_ast import ast27
    import copy
    
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('ast27', 'ast27_fixed'),
        ]

    for alias_name in ['ast27', 'ast27.ast']:
        node = ast3.Import(names=[ast3.alias(name=alias_name)])
        fixed = ast3.Try(body =[ast3.Import(names=[ast3.alias(name='ast27_fixed')])],
                          handlers=[ast3.ExceptHandler(type=ast3.Name(id='ImportError', ctx=ast3.Load()))],
                          orelse = [ast3.Import(names=[ast3.alias(name='ast27')])],
                          finalbody = [])

# Generated at 2022-06-12 03:38:12.737170
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('__future__', 'typed_ast')]

    assert TestTransformer.transform(ast.parse('from __future__ import absolute_import')).tree\
        == ast.parse('from typed_ast import absolute_import')

    assert TestTransformer.transform(ast.parse('from __future__ import generators')).tree\
        == ast.parse('from typed_ast import generators')

    assert TestTransformer.transform(ast.parse('from __future__ import generators as gen')).tree\
        == ast.parse('from typed_ast import generators as gen')

    assert TestTransformer.transform(ast.parse('from __future__ import nested_scopes')).tree\
        == ast.parse('from typed_ast import nested_scopes')
