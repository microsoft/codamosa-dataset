

# Generated at 2022-06-23 22:26:31.753726
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import warnings
    import ast
    import astor
    from typed_ast import ast3 as ast
    BaseImportRewrite(None)   # type: ignore

# Generated at 2022-06-23 22:26:37.417570
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_ = ast.Import(names=[ast.alias(name='os', asname='_os')])
    node = BaseImportRewrite(None)
    rewrote = node._replace_import(import_, 'os', 'os2')

    assert ast.dump(rewrote, True) == '''
        try:
            import _os
        except ImportError:
            import os as _os'''



# Generated at 2022-06-23 22:26:38.403366
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(1)

# Generated at 2022-06-23 22:26:47.184267
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast2

    from ..utils.main import main
    from ..utils.test_utils import assert_test_failed, assert_test_output

    tree = ast.parse('import os\nimport sys\n')
    expected_output = ast2.dump(ast.parse('import os\n'))
    result = main([], tree, transforms=[BaseImportRewrite],
                  flags={'rewrites': [('sys', 'os')]})
    if not result:
        assert_test_failed('Unexpected failure')
    if not result._tree_changed:
        assert_test_failed('Transformation did not changed tree')
    actual_output = ast2.dump(result.tree)
    assert_test_output(expected_output, actual_output, 'Wrong output')


# Generated at 2022-06-23 22:26:51.407587
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name):
            return node
    tree = ast.parse('x')
    res = MyTransformer.transform(tree)
    assert res == TransformationResult(tree, False, [])

# Generated at 2022-06-23 22:26:59.618909
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.tree import get_tree

    source = """
        import request
    """
    expected = """
        try:
            import request
        except ImportError:
            import requests
    """
    rewrites = [('request', 'requests')]

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    tree = get_tree(source, rewrite=False)
    res = TestTransformer.transform(tree)
    assert expected == res.tree.as_string()
    assert res.tree_changed



# Generated at 2022-06-23 22:27:01.412283
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite()



# Generated at 2022-06-23 22:27:01.944109
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:27:08.900799
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import ast_util
    from ..cc_import_rewrite import CCImportRewrite
    from ..django_import_rewrite import DjangoImportRewrite

    tree = ast_util.parse("""
import json
from collections import namedtuple

from django.http import HttpRequest
from django.views.generic import View

request = HttpRequest()
""")

    cc_rewrite = CCImportRewrite()
    cc_rewrite.visit(tree)

    django_rewrite = DjangoImportRewrite()
    django_rewrite.visit(tree)

# Generated at 2022-06-23 22:27:13.764205
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .debug import parse, dumps
    code = '''from typing import List, Tuple'''
    node = parse(code)  # type: ast.Module
    BaseImportRewrite.transform(node)
    assert dumps(node).strip() == '''
try:
    from typing import List, Tuple
except ImportError:
    from typing.pyi import List, Tuple'''.strip()

    node = parse(code)  # type: ast.Module
    BaseImportRewrite.rewrites = [('typing', 'typing.pyi')]
    BaseImportRewrite.transform(node)
    assert dumps(node).strip() == '''
from typing.pyi import List, Tuple'''.strip()



# Generated at 2022-06-23 22:27:16.582146
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    test_node = ast.parse("from datetime import struct_time")
    test_BaseImportRewrite = BaseImportRewrite(test_node)
    assert test_BaseImportRewrite._get_matched_rewrite("datetime") == ("datetime", "python_dateutil")


# Generated at 2022-06-23 22:27:21.366140
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    case1 = ast.parse("""from six.moves import reload_module""")
    class Transformer(BaseImportRewrite):
        rewrites = [('six.moves', 'importlib.reload')]
    assert ast.dump(Transformer.transform(case1).tree) == \
        "import\nimportlib.reload\ntry:\n    from six.moves import reload_module"

# Generated at 2022-06-23 22:27:23.392597
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a=1+2')
    t = BaseNodeTransformer(tree)
    assert t._tree == tree
    assert not t._tree_changed

# Generated at 2022-06-23 22:27:29.058106
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    from ...utils.testing import parse_node, assert_ast, assert_tree_changed

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux'),
        ]

    tree = parse_node(
        '''
        import foo

        import baz

        import spam
        '''
    )
    result = Transformer.transform(tree)
    assert_tree_changed(result)

    new_tree = parse_node(
        '''
        try:
            import foo
        except ImportError:
            import bar as foo


        try:
            import baz
        except ImportError:
            import qux as baz


        import spam
        '''
    )
    assert_ast(new_tree, result.new_tree)



# Generated at 2022-06-23 22:27:37.653556
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from pprint import pprint
    from _fixtures._ast_raw import _Py3Import
    from _fixtures._ast import _Py3Import_fixed

    # member rewrites
    pprint(BaseImportRewrite.rewrites)
    BaseImportRewrite.rewrites = [('old', 'new')]
    pprint(BaseImportRewrite.rewrites)
    
    # member tree
    pprint(BaseImportRewrite._tree)
    
    # member _tree_changed
    assert BaseImportRewrite._tree_changed == False
    pprint(BaseImportRewrite._tree_changed)
    
    # member _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]

# Generated at 2022-06-23 22:27:40.425969
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt
    assert bt.target is None


# Generated at 2022-06-23 22:27:49.778569
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-23 22:27:53.299302
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    t = BaseImportRewrite()
    assert t.rewrites == []
    assert list(t._get_names_to_replace(None)) == []
    assert t.dependencies == []
    assert t.target is None
    with pytest.raises(NotImplementedError):
        assert t.transform(None)

# Generated at 2022-06-23 22:28:01.466271
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    from .test_transformation_result import test_TransformationResult
    import unittest

    class BaseImportRewriteTest(BaseImportRewrite):
        rewrites = [('xx', 'yy')]

    class BaseImportRewriteTestCase(unittest.TestCase):
        def test_method_visit_Import_should_match_rewrite(self):
            import_node = ast.parse('import xx.yy')
            expected = ast.parse('try: import xx.yy\nexcept ImportError: import yy.yy')

            result = BaseImportRewriteTest.transform(import_node)
            self.assertEqual(str(expected), str(result.tree))
            self.assertEqual(True, result.tree_changed)
            self.assertEqual(['xx'], result.dependencies)


# Generated at 2022-06-23 22:28:12.394630
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_utils import assert_node_transformation
    from typed_ast import ast3
    from .test_utils import node_contains_subnode, node_contains_subnodes


# Generated at 2022-06-23 22:28:21.729337
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock as mock

    class TestTransformer(BaseImportRewrite):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self.generic_visit_called = False

        rewrites = [('foo', 'bar')]

        def generic_visit(self, node):
            self.generic_visit_called = True
            return node

    with mock.patch('ast.parse') as mock_parse:
        mock_parse.return_value = ast.parse('import foo')
        tree = ast.parse('import foo')
        transformer = TestTransformer(tree)
        import_from = transformer.visit_Import(tree.body[0])

        assert isinstance(import_from, ast.Try)
        assert transformer.generic_vis

# Generated at 2022-06-23 22:28:25.774376
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from ..utils import assert_equal
    transformer = BaseTransformer()
    transformer.target = CompilationTarget.PYTHON
    assert_equal(transformer.target, CompilationTarget.PYTHON)



# Generated at 2022-06-23 22:28:26.961245
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:28:33.846562
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer): pass
    Transformer._get_matched_rewrite()
    Transformer._replace_import()
    Transformer._replace_import_from_module()
    Transformer._get_names_to_replace()
    Transformer._get_replaced_import_from_part()
    Transformer._replace_import_from_names()
    Transformer.visit_Import()
    Transformer.visit_ImportFrom()

# Generated at 2022-06-23 22:28:41.359671
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    parser = ast.PyCF_ONLY_AST
    compile_mode = 'exec'
    
    # Example: import re
    imp_re_src = """
    import re
    """
    imp_re = ast.parse(imp_re_src, mode=compile_mode)

    # Example: from re import compile
    imp_from_re_src = """
    from re import compile
    """
    imp_from_re = ast.parse(imp_from_re_src, mode=compile_mode)

    # Example: from re import *
    imp_from_re_all_src = """
    from re import *
    """
    imp_from_re_all = ast.parse(imp_from_re_all_src, mode=compile_mode)

    # Example: from re import compile as cp


# Generated at 2022-06-23 22:28:43.035267
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__init__(BaseImportRewrite, ast.AST(body=[ast.Import(names=[ast.alias(name='a', asname='b')])]))


# Generated at 2022-06-23 22:28:48.475780
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import numpy as np

    class Foo(BaseImportRewrite):
        rewrites = [('numpy', 'np')]

    tree = ast.parse(
        'import numpy as np'
        'from numpy import *'
        'from numpy import random as rnd'
    )
    Foo.transform(tree)

    tree = ast.parse(
        'import scipy as sp'
        'import sklearn as sk'
    )
    Foo.transform(tree)


## Rewriting long imports
#class BaseImportRewrite(BaseNodeTransformer):
#    rewrites = [] # type: List[Tuple[str, str]]
#
#    @classmethod
#    def _get_matched_rewrite(cls, name: str) -> Optional[Tuple[str, str]]:
#

# Generated at 2022-06-23 22:28:52.350888
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    target = CompilationTarget.get_target_by_name(
        "python"
    )
    transformer_class = target.transformers.get("BaseImportRewrite")
    assert transformer_class.__name__ == "BaseImportRewrite"


# Generated at 2022-06-23 22:28:59.680684
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..targets import python3
    from ..utils import get_test_data_path
    from ..utils.source_code import SourceCode
    from astunparse import unparse
    import ast

    import_from_source = SourceCode.read_data('import_from.py')
    import_from_source.path = get_test_data_path('import_from.py')
    import_from_source.target = python3
    module = import_from_source.parse(85)

    class Transform(BaseImportRewrite):
        rewrites = [('six', 'past.builtins')]

    transformed = Transform.transform(module)


# Generated at 2022-06-23 22:29:00.685059
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    print(BaseNodeTransformer.__doc__)
    BaseNodeTransformer()


# Generated at 2022-06-23 22:29:05.551841
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Create object
    base_transformer = BaseTransformer()

    # Create object with custom parameter
    base_transformer = BaseTransformer(tree='tree')

    # Check type of __init__() return value
    result = BaseTransformer()
    assert isinstance(result, BaseTransformer)

    # Check instance attributes
    instance_attributes = ['target']
    for attr in instance_attributes:
        assert hasattr(base_transformer, attr)

    assert isinstance(BaseTransformer.target, CompilationTarget)
    assert BaseTransformer.target is None

    # Check class attributes
    class_attributes = ['transform']
    for attr in class_attributes:
        assert hasattr(BaseTransformer, attr)

    # Check abstractmethod
    with pytest.raises(TypeError):
        BaseTrans

# Generated at 2022-06-23 22:29:06.931985
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()


# Generated at 2022-06-23 22:29:16.925376
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import textwrap

    module = ast.parse(textwrap.dedent("""
    import importlib
    import importlib.abc
    import importlib.resources
    from importlib import abc
    from importlib import abc, resources
    """))

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('importlib.abc', 'importlib.machinery'),
            ('importlib.resources', 'importlib_resources')
        ]

    transformer = Transformer(module)
    transformer.visit(module)


# Generated at 2022-06-23 22:29:21.466428
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""from foo import bar""")
    expected_tree = ast.parse("""from foo import bar""")

    class SampleTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    result = SampleTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed is False



# Generated at 2022-06-23 22:29:22.689069
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrites = [(from_, to)
                for from_, to in BaseImportRewrite.rewrites]

    assert rewrites == []

# Generated at 2022-06-23 22:29:24.581391
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class cls(BaseTransformer):
        pass
    empty = cls()
    assert empty.target == None

# Generated at 2022-06-23 22:29:34.584795
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from textwrap import dedent
    from ..utils.test_utils import parse_text, assert_transform_result, assert_equal

    rewrites = [
        ('foo', 'bar')
    ]

    class Rewriter(BaseImportRewrite):
        rewrites = rewrites
        
    src = dedent('''\
        import foo.bar as baz
    ''')
    expected_transformed = dedent('''\
        try:
            import foo.bar as baz
        except ImportError:
            import bar.bar as baz
    ''')
    assert_transform_result(expected_transformed, Rewriter, src)
    


# Generated at 2022-06-23 22:29:38.405953
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Arrange
    from typed_ast import ast3 as ast
    from typed_ast import TypeComment
    Tree = ast.parse('from foo import bar')
    Target = type(
        'Target',
        (BaseImportRewrite,),
        {'rewrites': [('foo', 'bar')]}
    )


# # Unit test for the method _get_matched_rewrite of class BaseImportRewrite

# Generated at 2022-06-23 22:29:42.342728
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from foo import bar')
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo_rewrote')
        ]
    res = RewriteTransformer.transform(tree)
    tree = res.tree
    expected = ast.parse(
            'try:\n    from foo import bar\nexcept ImportError:\n    from foo_rewrote import bar'
    )
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 22:29:52.620815
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse

    code = "from mypackage.module.submodule import other_module"
    node = ast.parse(code).body[0]
    assert astunparse.unparse(node) == code
    node = ast.parse(node).body[0]

    # apply transform
    class MyBase(BaseImportRewrite):
        rewrites = [('mypackage.module', 'new_name')]
    MyBase.transform(node)
    assert astunparse.unparse(node) == """try:
    from new_name.submodule import other_module
except ImportError:
    from mypackage.module.submodule import other_module
"""
    node = ast.parse(node).body[0]

    # apply transform once again
    MyBase.transform(node)
    assert astun

# Generated at 2022-06-23 22:29:54.177467
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite  # type: ignore



# Generated at 2022-06-23 22:30:03.912752
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..parser import ast_from_string
    from ..utils.source import get_source

    tree = ast_from_string(get_source(globals()))

    class Rewriter(BaseImportRewrite):
        rewrites = [('test.test_transformers.BaseImportRewrite',
                     'test.test_transformers.test_BaseImportRewrite')]

    rewriter = Rewriter(tree)
    rewriter.visit(tree)

    assert rewriter._get_matched_rewrite('test.test_transformers.BaseImportRewrite') == ('test.test_transformers.BaseImportRewrite',
                                                                                         'test.test_transformers.test_BaseImportRewrite')

# Generated at 2022-06-23 22:30:04.551420
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:30:12.084980
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import get_tree

    class TestTransformer(BaseImportRewrite):
        target = 'python35'
        rewrites = [
            ('unittest', 'unittest2')
        ]

    tree = get_tree('import unittest')
    transformer = TestTransformer(tree)
    rewrote = transformer.visit_Import(tree.body[0])
    assert isinstance(rewrote, ast.Try)
    assert rewrote.body[0].names[0].name == 'unittest2'


# Generated at 2022-06-23 22:30:21.131357
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    rewrites = [('django.utils', 'typed_django_utils')]
    class Test(BaseImportRewrite):
        rewrites = rewrites
    sample_code = 'import django.utils'

    tree = ast.parse(sample_code)
    assert ast.dump(tree) == (
        'Module(body=[Import(names=[alias(name="django.utils", '
        'asname=None)])])'
    )

    tr = Test.transform(tree)

# Generated at 2022-06-23 22:30:30.847042
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    stack = []
    for i in range(10):
        stack.append(ast.parse('''
            import abc
            import xyz
        '''))
    assert astor.to_source(stack[0]) == '''
        import abc
        import xyz
        '''
    BaseImportRewrite.rewrites = [('abc', 'abc.old')]
    BaseImportRewrite.transform(stack[0])
    assert astor.to_source(stack[0]) == '''
        try:
            import abc.old as abc
        except ImportError:
            import abc
        import xyz
        '''
    BaseImportRewrite.rewrites = [('xyz', 'xyz.old')]
    BaseImportRewrite.transform(stack[0])
    assert ast

# Generated at 2022-06-23 22:30:33.393600
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Create an instance of class BaseImportRewrite so it can be inspected"""
    assert BaseImportRewrite.__name__ == "BaseImportRewrite"

# Generated at 2022-06-23 22:30:35.400191
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()


# Generated at 2022-06-23 22:30:44.364129
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse
    import ast
    import itertools

    class Something(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib')]

    tree = ast.parse('from os.path import abspath\n'
                     'from os.path import *\n'
                     'from os.path import join as pjoin\n')

    expected = 'from pathlib import abspath\n' \
               'from pathlib import *\n' \
               'try:\n' \
               '    from pathlib import pjoin\n' \
               'except ImportError:\n' \
               '    from os.path import pjoin as pjoin\n'

    assert unparse(Something.transform(tree).tree) == expected

# Generated at 2022-06-23 22:30:54.015757
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # import a
    old_node = ast.Import(names=[ast.alias(name='a', asname=None)])
    # try: import a
    # except ImportError: import b
    new_node = ast.Try(body=[old_node],
                       handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError'), name=None,
                                                   body=[ast.Import(
                                                       names=[ast.alias(name='b', asname=None)])])],
                       orelse=[],
                       finalbody=[])
    assert BaseImportRewrite._replace_import(BaseImportRewrite, old_node, 'a', 'b') == new_node


# Generated at 2022-06-23 22:30:58.657246
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # TODO: pass fixture instead of a simple instance
    class MyTransformer(BaseNodeTransformer):
        def visit_Assign(self, node):
            return node

    tree = ast.parse('a = 1')
    transformer = MyTransformer(tree)

    assert tree is transformer._tree
    assert False is transformer._tree_changed

# Generated at 2022-06-23 22:30:59.979692
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()



# Generated at 2022-06-23 22:31:00.605081
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:31:12.494140
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MockTransformer(BaseImportRewrite):
        rewrites = [('django.http', 'django.core.http')]


# Generated at 2022-06-23 22:31:13.747902
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert(BaseTransformer)


# Generated at 2022-06-23 22:31:23.599540
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import jinja2  # noqa

    class Transformer(BaseImportRewrite):
        rewrites = [('jinja2', 'django.template')]

    class ImportFrom(ast.ImportFrom):
        pass

    class Import(ast.Import):
        pass

    class Alias(ast.alias):
        def __init__(self, name):
            self.name = name
            self.asname = None

    import_ = Import([Alias('a')])
    import_from_ = ImportFrom(names=[Alias('b')], module='test')

    import_2 = Import([Alias('test.a')])
    import_from_2 = ImportFrom(names=[Alias('test.b')], module='test')

    import_3 = Import([Alias('jinja2.a')])

# Generated at 2022-06-23 22:31:26.716527
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from six.moves import input')
    transformer = BaseImportRewrite(tree)
    transformer.visit_ImportFrom(tree.body[0])
    assert transformer._tree_changed



# Generated at 2022-06-23 22:31:31.045105
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
import foo
    """)

    result = BaseImportRewrite.transform(tree)
    assert ast.dump(result.tree) == ast.dump("""
try:
    import foo
except ImportError:
    import foo as foo
""")



# Generated at 2022-06-23 22:31:32.770351
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        obj = BaseTransformer()


# Generated at 2022-06-23 22:31:40.078390
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('''
    import foo
    import bar
    import foo.baz as fb
    import bar.baz as bb
    from foo import bar
    from bar import foo
    from foo import bar as foo_bar
    from bar import foo as bar_foo
    from foo import *
    from bar import *
    ''')

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'f')]

    Test.transform(tree)

# Generated at 2022-06-23 22:31:49.071528
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import typed_astunparse
    from mypy_extensions import TypedDict
    import sys

    code = """
    from typing import List, Dict, Union, Tuple, Optional
    from math import floor
    from os import path as opath
    from typing import List, Dict
    from math import *
    from os import path, floor as ofloor
    from os import *
    """
    tree = ast.parse(code)
    node = tree.body[3]
    class rewrites(TypedDict):
        from_: str
        to: str
    BaseImportRewrite.rewrites = [
        rewrites(from_='typing', to='typing_extensions'),
        rewrites(from_='math', to='math_extensions')
    ]
    BaseImport

# Generated at 2022-06-23 22:31:53.651058
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    
    class Foo(BaseImportRewrite):
        rewrites = [('from_', 'to_')]

    body = ast.parse('from a import b, c').body
    node = body[0]  # ast.ImportFrom()
    node.names[0].name = 'from_'
    node.names[1].name = 'from_.c'
    tree = ast.Module(body=body)
    result = Foo.transform(tree)

    assert result.tree == """
        try:
            from to_ import b, c
        except ImportError:
            from_import b
            from_import c
    """.strip()

    body = ast.parse('from a import b, c').body
    node = body[0]  # ast.ImportFrom()
    node

# Generated at 2022-06-23 22:31:55.778835
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('x = 1')
    transformer = BaseNodeTransformer(tree)

    assert transformer._tree is tree
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:32:04.018783
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test to change names in ImportFrom
    # I want to change names "import_name_1" and "import_name_2" to "rewrite_name"
    import_name_1 = ast.Name(id="import_name_1", ctx=ast.Load())
    import_name_2 = ast.Name(id="import_name_2", ctx=ast.Load())
    import_node = ast.ImportFrom(module="module_name", names=[import_name_1, import_name_2], level=1)
    # Result: from module_name import import_name_1 as import_name_1, import_name_2 as import_name_2

# Generated at 2022-06-23 22:32:08.996627
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # test abstract class
    try:
        transformer = BaseTransformer()
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == 'Can\'t instantiate abstract class BaseTransformer with abstract method transform'
    else:
        raise AssertionError('Should not reach')


# Generated at 2022-06-23 22:32:14.027137
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from pytest import raises

    # class without abstractmethods
    class Transformer(BaseTransformer):
        ...

    # class without abstractmethods
    class NodeTransformer(BaseNodeTransformer):
        ...

    with raises(TypeError):
        Transformer()

    with raises(TypeError):
        NodeTransformer()

# Generated at 2022-06-23 22:32:24.143123
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.Import(names=[ast.alias(name='os',
                                       asname=None)])

    class Inst(BaseImportRewrite):
        rewrites = [('os', 'os')]

        def __init__(self, tree: ast.AST, node: ast.Import) -> None:
            super().__init__(tree)
            self._node = node

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            if node == self._node:
                return super().visit_Import(node)
            else:
                return node


# Generated at 2022-06-23 22:32:30.932487
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    tree = ast.parse("import abc")
    tree.body[0] = ast.Import([ast.alias(name="abc", asname="abc")])

    class SimpleImportRewrite(BaseImportRewrite):
        rewrites = [("abc", "def")]

    assert SimpleImportRewrite.transform(tree).tree.body[0] == ast.Try(
        [ast.Import([ast.alias(name='def', asname='abc')])],
        [ast.Import([ast.alias(name='abc', asname='abc')])],
        [],
        None
    )


# Generated at 2022-06-23 22:32:41.097728
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class A(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    A.transform(ast.parse('from foo import baz'))
    assert A.transform(ast.parse('from foo import baz')) == \
        TransformationResult(
            ast.parse('try:\n    from foo import baz\nexcept ImportError:\n    from bar import baz'),
            True,
            [],
        )
    import astor
    print(astor.to_source(A.transform(ast.parse('from foo import baz'))[0]))

# Generated at 2022-06-23 22:32:45.745172
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .test_transformer import BasicTransformer

    tree = ast.parse("a = 10")
    tree1 = BasicTransformer.transform(tree)
    assert tree1.tree_changed is True
    assert tree1.dependencies == []

# Generated at 2022-06-23 22:32:53.801101
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..typing_utils import type_comment
    from ..utils import test_utils

    node = ast.parse("from django.utils.decorators import foo, bar, baz")
    module = test_utils.MockModule("django_utils_decorators")

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [("django.utils.decorators", "django_utils_decorators")]
        target = CompilationTarget(platform="3.6.0")

    result = TestImportRewrite.transform(node)
    tree = ast.parse(str(result.tree))
    assert result.tree_changed is True
    assert inspect.getsource(tree._import_from_module(None, "foo")) == str(module.function("foo"))

# Generated at 2022-06-23 22:33:04.539375
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import CompilationTarget
    from ..utils.symbols import ClassSymbol, Symbol
    from typed_ast import ast3

    sym = ClassSymbol('Class', '')
    sym.sub_symbols[Symbol.FIELD] = ['a', 'b']
    tree = ast3.parse('class Class:\n'
                      '    a\n'
                      '    b\n')
    transformed_tree = MockNodeTransformer(sym)(tree=tree).transform(tree)
    assert(transformed_tree == ast3.parse('class Class:\n'
                                          '    def __init__(self, a, b):\n'
                                          '        self.a = a\n'
                                          '        self.b = b\n'))

# Generated at 2022-06-23 22:33:07.660416
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    assert Transformer.transform(ast.parse("pass")) == TransformationResult(ast.parse("pass"), False, [])


# Generated at 2022-06-23 22:33:11.541458
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    from .utils import parse_snippet

    code = 'print(123)'

    t = BaseNodeTransformer(parse_snippet(code))
    t._tree_changed = True
    
    assert astor.to_source(t._tree) == code
    assert t._tree_changed == True


# Generated at 2022-06-23 22:33:20.646610
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():

    BaseImportRewrite.rewrites = [('old', 'new')]

    assert BaseImportRewrite._get_matched_rewrite('new') == ('old', 'new')
    assert BaseImportRewrite._get_matched_rewrite('new.something') == ('old', 'new')
    assert BaseImportRewrite._get_matched_rewrite('old') == ('old', 'new')
    assert BaseImportRewrite._get_matched_rewrite('old.something') == ('old', 'new')
    assert BaseImportRewrite._get_matched_rewrite('some.thing') is None
    assert BaseImportRewrite._get_matched_rewrite('some.old') is None



# Generated at 2022-06-23 22:33:21.502609
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    _ = BaseTransformer()

# Generated at 2022-06-23 22:33:30.007046
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestClass(BaseImportRewrite):
        def __init__(self, tree: ast.AST=None):
            super().__init__(tree)
            self.rewrites = [('websocket.client', 'websockets.client')]
            self._visited_nodes = []

        def generic_visit(self, node: ast.AST) -> ast.AST:
            self._visited_nodes.append(node)
            return node


# Generated at 2022-06-23 22:33:33.177524
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON
        dependencies = [] # type: List[str]

    assert TestTransformer.target is CompilationTarget.PYTHON
    assert TestTransformer.dependencies == []


# Generated at 2022-06-23 22:33:36.265700
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # BaseTransformer.transform
    obj = BaseTransformer()

    assert obj.transform() == NotImplemented



# Generated at 2022-06-23 22:33:41.236230
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'foo3')]

    tree = ast.parse('import foo')
    tr = ImportRewrite.transform(tree)

    assert len(tr.tree.body) == 1
    assert isinstance(tr.tree.body[0], ast.Try)



# Generated at 2022-06-23 22:33:44.789296
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    try:
        BaseImportRewrite()
    except Exception as e:
        assert type(e) is TypeError
        assert str(e) == 'Can\'t instantiate abstract class BaseImportRewrite with abstract methods visit_Import, visit_ImportFrom'

# Generated at 2022-06-23 22:33:45.803464
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:46.594799
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.parse("pass"))

# Generated at 2022-06-23 22:33:49.897192
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_tree_generation import get_test_tree

    tree = get_test_tree('import_statements.py')
    tree = BaseImportRewrite.transform(tree).tree

    for import_stmt in tree.body:
        if isinstance(import_stmt, ast.Import):
            pass


# Generated at 2022-06-23 22:33:55.423608
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        target = '2.7'
        dependencies = []

        def visit_Import(self, node: ast.Import) -> ast.Import:
            self._tree_changed = True
            return node

    tree = ast.parse('import os')
    result = TestTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-23 22:33:56.306444
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    object()

# Generated at 2022-06-23 22:33:57.301324
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, BaseTransformer)

# Generated at 2022-06-23 22:34:06.551725
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget
    from ..utils.ast import ast_to_code
    from ..utils.helper import transform_ast

    for cls in BaseImportRewrite.__subclasses__():
        if cls.target != CompilationTarget.JAVA:
            continue

        print('Testing:', cls.__name__)

        tree = ast.parse('from requests.packages.urllib3.contrib.pyopenssl \
    import WrappedSocket\n')
        result = cls.transform(tree)
        assert result.changed is True

# Generated at 2022-06-23 22:34:09.498921
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Foo(BaseTransformer):
        pass

    class Bar(BaseNodeTransformer):
        pass

    foo = Foo()
    bar = Bar(None)

    assert foo
    assert bar

# Generated at 2022-06-23 22:34:15.799591
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    import mock
    import typing

    class Fixture(BaseImportRewrite):
        rewrites = [('a', 'b')]

    node = ast.parse(
        '''
        import a
        import b
        import a.x as y
        import b.x as y
        import a.x
        from c import *
        from d import *
        from a import *
        from a import x, y, z
        from c import x, y, z
        from a.x import y, z
        from b import x as c
        from b.x import y as z
        from b.x import y
        ''')


# Generated at 2022-06-23 22:34:20.894958
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('''from typing import Type, List, Any''')
    visitor = BaseImportRewrite(tree)
    visitor.visit(tree)
    assert ast.dump(tree) == '''
try:
    from typing import Type, List, Any
except ImportError:
    from typing import Type, List
    from typing import Any
'''

# Generated at 2022-06-23 22:34:31.530825
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    for code in [
        """import sys""",
        """from sys import version""",
        """from sys import *""",
        """from sys import version as sys_version""",
        """from .sys import version""",
        """from sys import version as sys_version as sv""",
    ]:
        class RT(BaseImportRewrite):
            rewrites = [('sys', 'os')]
        node = ast.parse(code)
        assert RT().visit(node)
        res = ast.dump(node, annotate_fields=False, include_attributes=False)
        print(res)


# Generated at 2022-06-23 22:34:32.081322
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:34:34.394818
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Test constructor of class BaseImportRewrite."""
    BaseImportRewrite(ast.parse("x = 1"))



# Generated at 2022-06-23 22:34:37.221709
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        pass
    dt = DummyTransformer()
    assert isinstance(dt, BaseTransformer)


# Generated at 2022-06-23 22:34:38.310531
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    _ = BaseTransformer()

# Generated at 2022-06-23 22:34:40.836614
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("from foo import bar as baz", "<string>")
    result = BaseImportRewrite.transform(tree)
    assert result.changed
    assert result.tree == ast.parse("try:\n    from foo import bar as baz\nexcept ImportError:\n    from foo import bar as baz", "<string>")

# Generated at 2022-06-23 22:34:42.664520
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert type(bt) == BaseTransformer


# Generated at 2022-06-23 22:34:49.212348
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_from = ast.ImportFrom(module='foo', level=0, names=[ast.alias(name='baz', asname='qux')])
    actual = TestBaseImportRewrite.transform(import_from)
    assert actual.changed is True
    assert isinstance(actual.tree, ast.Try)

    actual_try = actual.tree
    assert actual_try.body[0].name == 'bar'
    assert actual_try.body[0].names[0].name == 'baz'
    assert actual_try.body[0].names[0].asname == 'qux'

    assert actual_try.handlers[0].name.id == 'ImportError'
    assert actual_try.handlers

# Generated at 2022-06-23 22:34:57.437652
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    a = BaseImportRewrite()
    b = ast.parse('''
import os
import json
import os.path
from os import path
import xml.etree.ElementTree as ET
import xml.etree.cElementTree as CE
from xml.etree.ElementTree import parse as p
from xml.etree.ElementTree import *
from xml import etree
from xml.etree import ElementTree as E
import xml.etree.ElementTree
import xml.etree.ElementTree as b
from xml.etree.ElementTree import findall as find
''')
    a.visit(b)
    print(astor.to_source(b))

# Generated at 2022-06-23 22:35:00.254388
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.ast_builder import build

    class Dummy(BaseNodeTransformer):
        pass


# Generated at 2022-06-23 22:35:08.560799
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import(): # pragma: no cover
    class Rewriter(BaseImportRewrite):
        rewrites = [('mymodule', 'othermodule')]

    node = ast.parse("import mymodule")
    rewrote = Rewriter.transform(node).tree
    assert rewrote.body[0].body[0].value.value == ast.Import(names=[
        ast.alias(name='othermodule',
                  asname='mymodule')])
    assert rewrote.body[0].body[0].body[0].value.value == ast.Import(names=[
        ast.alias(name='mymodule',
                  asname='mymodule')])



# Generated at 2022-06-23 22:35:13.449629
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_str = 'from mongoengine.fields import StringField, EmbeddedDocumentField as EmbeddedField'
    tree = ast.parse(import_str)
    node = tree.body[0]
    
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('mongoengine.fields', 'mongoengine_extras.fields'),
        ]

    rewrote = TestImportRewrite.transform(tree)
    assert rewrote.changed == True
    assert rewrote.tree.body[0].names[0].name == 'mongoengine_extras.fields'

# Generated at 2022-06-23 22:35:19.806403
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_parser import module
    import typing

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('os', '_os'),
            ('typing', '_typing'),
            ('typing.Any', '_typing.Any'),
            ('typing.List', '_typing.List'),
            ('typing.Optional', '_typing.Optional'),
            ('typing.Text', '_typing.Text'),
            ('typing.Tuple', '_typing.Tuple'),
            ('typing.Union', '_typing.Union'),
        ]

    t = ImportRewrite()


# Generated at 2022-06-23 22:35:26.186297
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from test.utils.sample_module import test
    import typed_ast.ast3 as ast
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('test', 'test_rewrite')
        ]
        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            return super().visit_Import(node)
        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    tree = ast.parse('import test, test.foo.bar')
    result = TestImportRewrite.transform(tree)
    assert result.changed
    import_stmt = result.tree.body[0]
    assert type(import_stmt) == ast

# Generated at 2022-06-23 22:35:29.397603
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tr = BaseTransformer()
    assert isinstance(tr, BaseTransformer)
    assert tr.target == None
    with pytest.raises(NotImplementedError):
      tr.transform()

# Generated at 2022-06-23 22:35:39.950994
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class Transformer(BaseImportRewrite):
        """Transformer for tests."""
        rewrites = [('foo.bar', 'bar.bar')]

    import_from_stmt = ast.ImportFrom(module='foo.bar',
                                      names=[ast.alias(name='*', asname=None)], level=0)
    expected = ast.Try(
        body=[ast.ImportFrom(module='bar.bar',
                             names=[ast.alias(name='*', asname=None)], level=0)],
        handlers=[],
        orelse=[ast.ImportFrom(module='foo.bar',
                               names=[ast.alias(name='*', asname=None)], level=0)],
        finalbody=[])

    result = Transformer.transform(import_from_stmt)

# Generated at 2022-06-23 22:35:40.884738
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass



# Generated at 2022-06-23 22:35:41.894515
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__init__(BaseImportRewrite, ast.AST)

# Generated at 2022-06-23 22:35:49.585045
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BIR = BaseImportRewrite
    assert BIR.rewrites == []

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestImportRewrite2(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('baz', 'qux')]

    assert TestImportRewrite.rewrites == [('foo', 'bar')]
    assert TestImportRewrite2.rewrites == [('foo', 'bar'), ('baz', 'qux')]



# Generated at 2022-06-23 22:36:00.090428
# Unit test for constructor of class BaseImportRewrite

# Generated at 2022-06-23 22:36:00.829722
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    obj = BaseImportRewrite()
    assert obj.rewrites == []



# Generated at 2022-06-23 22:36:11.062976
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test import assert_transformation_result
    from typed_ast import ast3 as ast

    class ImportRewrite(BaseImportRewrite):
        target='python>=3.7'
        rewrites = [('six', 'six')]

    tree = ast.parse('''
        import six.moves.urllib.error
    ''')
    expected = ast.parse('''
        try:
            import six.moves.urllib.error
        except ImportError:
            import six.moves.urllib.error
    ''')
    assert_transformation_result(ImportRewrite, tree, expected)



# Generated at 2022-06-23 22:36:19.690157
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import six
    import astor
    import re
    from yapic.compat.typing import TYPE_CHECKING
    from yapic.compat import ast_try_except

    if TYPE_CHECKING:
        from typed_ast import ast3 as ast

    class DummyModuleTransformer(BaseImportRewrite):
        rewrites = [('six', 'yapic.compat.six'),
                    ('yapic.compat.typing', 'yapic.compat.typing')]


# Generated at 2022-06-23 22:36:30.491432
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast, inspect
    import typed_astunparse as astunparse
    from typed_astunparse import ast3 as ast3
    class BaseImportRewrite_visit_ImportFrom(BaseImportRewrite):
        rewrites = [
            ('selenium.webdriver', 'fake'),
            ('selenium.webdriver.common.keys', 'fake.keys')
        ]

    source = '''
    from selenium import webdriver
    from selenium.webdriver import common
    from selenium.webdriver.common import keys
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.common.service import Service
    '''