

# Generated at 2022-06-23 22:26:37.547478
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'baz')
        ]

    tree = ast.parse("from foo.bar.a import abc\nfrom foo.bar import bcd as bcd1, bcd2, *\nfrom baz.bar2 import efg")
    TestImportRewrite.transform(tree)

    assert str(tree) == "from baz.bar.a import abc\ntry:\n    from foo.bar import bcd as bcd1, bcd2, *\nexcept ImportError:\n    from baz.bar import bcd as bcd1, bcd2, *\nfrom baz.bar2 import efg"

# Generated at 2022-06-23 22:26:39.047713
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    try:
        class TestTransformer(BaseNodeTransformer):
            pass
    except Exception as e:
        pass
    else:
        raise Exception('unexpected success')

# Generated at 2022-06-23 22:26:46.240065
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewrite(BaseImportRewrite, ast.NodeTransformer):
        rewrites = [
            ('xml.dom.minidom', 'dom.minidom'),
            ('xml.etree.ElementTree', 'etree.ElementTree')]

    node = ast.parse("import xml.dom.minidom as minidom")
    tree = ImportRewrite.transform(node)

    assert tree.changed

    node = ast.parse("""\
from xml.etree.ElementTree import ElementTree
""")
    tree = ImportRewrite.transform(node)

    assert tree.changed

# Generated at 2022-06-23 22:26:57.082523
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from pytest import raises
    from ..utils.testing import assert_transformation_result
    with raises(NotImplementedError):
        class BaseImportRewrite(BaseImportRewrite):  # type: ignore
            pass

    class BaseImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    @snippet
    def snippet():
        import old
        from old.sub import x as y

    @snippet
    def test():
        try:
            import old
        except ImportError:
            import new

        try:
            from old.sub import x as y
        except ImportError:
            from new.sub import x as y

    assert_transformation_result(BaseImportRewrite, snippet, test)



# Generated at 2022-06-23 22:26:59.009991
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transform(BaseImportRewrite):
        rewrites = [('previous', 'current')]
    Transform.transfor

# Generated at 2022-06-23 22:26:59.994505
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite()


# Generated at 2022-06-23 22:27:01.780246
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget('python3')
    BaseTransformer.target = target
    BaseTransformer.target == target

# Generated at 2022-06-23 22:27:03.618119
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            pass

# Generated at 2022-06-23 22:27:08.941075
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert isinstance(BaseNodeTransformer('node'), ast.NodeTransformer)
    assert isinstance(BaseNodeTransformer('node'), BaseTransformer)
    assert BaseNodeTransformer._tree is 'node'
    assert BaseNodeTransformer._tree_changed is False


# Generated at 2022-06-23 22:27:09.591840
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:27:11.766429
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget('python', '3.6')

    transformer = BaseTransformer()
    transformer.target = target

    assert transformer.target == target


# Generated at 2022-06-23 22:27:19.691276
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from os import path
    from ast import parse
    from io import StringIO
    from .test_utils import assert_ast_equal
    from .template import get_automagic_transformer

    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch

    rewrites = [('__future__.print_function', 'six.print_function')]
    import_rewrite = get_automagic_transformer(BaseImportRewrite, rewrites)

# Generated at 2022-06-23 22:27:28.336153
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astpp, astor
    import ast
    import re

    # pattern for matching import inside try body
    import_pattern = re.compile(r'^try:(\s+)?(import )|(from .* import)')

    class BaseImportRewriteDumb(BaseImportRewrite):
        rewrites = [('matplotlib', 'matplotlib_test')]

        def transform(cls, tree):
            return super().transform(tree)

    source = """
    import matplotlib
    from matplotlib.pyplot import plot
    """

    tree = ast.parse(source)
    result = BaseImportRewriteDumb.transform(tree)

    assert(result.changed)

# Generated at 2022-06-23 22:27:32.121638
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Test(BaseTransformer):
        target = CompilationTarget.PYTHON_SIMPLE

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    test = Test()
    assert isinstance(test, BaseTransformer)



# Generated at 2022-06-23 22:27:34.523674
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer
    print('Success')


# Generated at 2022-06-23 22:27:44.628460
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestRewrite(BaseImportRewrite):
        rewrites = [
            ('os', 'erp5.util'),
            ('accessor', 'erp5.util.accessor')]

    source = 'import os'
    expected_source = '''try:
    extend(os)
except ImportError:
    extend(erp5.util)
'''
    tree = astor.parse_file(StringIO(source))
    TestRewrite.transform(tree)
    assert astor.to_source(tree) == expected_source

    source = 'import os.path'
    expected_source = '''try:
    extend(os.path)
except ImportError:
    extend(erp5.util.path)
'''

# Generated at 2022-06-23 22:27:45.638544
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:27:55.152826
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Check that class BaseTransformer can be instantiated
    try:
        BaseTransformer()
    except TypeError:
        pass
    else:
        assert False
    # Check that class BaseTransformer can be instantiated.
    # The instantiation should raise a TypeError.
    try:
        BaseTransformer(target=None)
    except TypeError:
        pass
    else:
        assert False
    # Check that class BaseTransformer can be instantiated.
    # The instantiation should raise a TypeError.
    try:
        BaseTransformer(target=None, dependencies=None)
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-23 22:27:57.470629
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astor
    from .helpers import get_node
    from .sample_transformers import ImportRewriteSample as Sample



# Generated at 2022-06-23 22:27:59.975958
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.ast import parse_snippet
    from pathlib import Path
    
    class TestTransformer(BaseNodeTransformer):
        pass
   
    path = Path(__file__)
    tree = parse_snippet(path, '"{}"'.format(__file__))
    
    test = TestTransformer(tree=tree)
    assert test._tree is tree
    assert test._tree_changed is False

# Generated at 2022-06-23 22:28:05.195529
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImplicitFromRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    ImplicitFromRewrite.transform(tree)

    assert tree.body[0].body[0].names[0].name == 'new'



# Generated at 2022-06-23 22:28:06.796531
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        @classmethod
        def transform(cls, tree):
            return TransformationResult(tree, True, ['a'])

    assert isinstance(TestTransformer, BaseTransformer)


# Generated at 2022-06-23 22:28:07.905671
# Unit test for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:28:12.918613
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'z')]

    tree = ast.parse("""
from a import b
from a.b import c
from a.b import d as e
from a.b import f as g, h, i, j as k
""")


# Generated at 2022-06-23 22:28:16.841211
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    def get_import_from_node(statement):
        module = ast.parse(statement)
        last = module.body[-1]
        while not isinstance(last, ast.ImportFrom):
            last = last.body[-1]

        return last

    def test_visit_no_rewrite(node, to_replace_from, to_replace_to):
        visitor = BaseImportRewrite.__new__(BaseImportRewrite)
        visitor._tree_changed = False
        visitor.rewrites = [(to_replace_from, to_replace_to)]

        c = visitor.visit_ImportFrom(node)

        assert c is node
        assert visitor._tree_changed is False

    def test_visit_rewrite_from(node, to_replace_from, to_replace_to):
        visitor = BaseImport

# Generated at 2022-06-23 22:28:27.022884
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    import_rewrite = BaseImportRewrite(None)
    import_rewrite.rewrites = BaseImportRewrite.rewrites

    import_rewrite.rewrites.append(
        ('django.forms.fields', 'django.forms.fields_tests'))

    import_rewrite.rewrites.append(
        ('django.forms.widgets', 'django.forms.widgets_tests'))

    import_rewrite.rewrites.append(
        ('django.test.utils', 'django.test.testcases.utils'))


# Generated at 2022-06-23 22:28:38.737595
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    @snippet
    def assert_code_unchanged(input):
        result = input
        return result

    import_rewrite_rewrite = {'abc': 'abc2'}

    @snippet
    def rewrite_imports_with_import_rewrite_rewrite(input):
        import abc
        return input

    @snippet
    def rewrite_imports_with_import_rewrite_rewrite_and_target(input):
        import abc2
        return input

    class Test1(BaseImportRewrite):
        rewrites = import_rewrite_rewrite

    assert Test1.transform(assert_code_unchanged.get_ast()[0]) == TransformationResult(
        assert_code_unchanged.get_ast()[0],
        False,
        [])

    assert Test1

# Generated at 2022-06-23 22:28:39.854662
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer.target = 'python2'


# Generated at 2022-06-23 22:28:43.108879
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # class SnippetTransformer
    class SnippetTransformer(BaseTransformer):
        target = 'python>=2.7'

    with pytest.raises(TypeError):
        SnippetTransformer()

    assert SnippetTransformer.target == 'python>=2.7'


# Generated at 2022-06-23 22:28:52.950166
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse(
        'import old\n'
        'import old.module\n'
        'from old import module\n'
        'from old import module1, module2\n'
        'from old import *\n'
    )

# Generated at 2022-06-23 22:29:00.037158
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import parse
    from .trivia import _assert_ast_structure

    old_module = 'old.module'
    new_module = 'new.module'

    # old_module is the root module
    node = parse('''import {}'''.format(old_module))
    node = BaseImportRewrite._replace_import(  # type: ignore
        BaseImportRewrite((node)), node, old_module, new_module)
    _assert_ast_structure(node, '''
    Try(body=[Import(names=[alias(name='new.module', asname=None)])],
        orelse=[],
        finalbody=[])
    ''')

    # old_module is submodule
    node = parse('''import {}.submodule'''.format(old_module))

# Generated at 2022-06-23 22:29:00.749914
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target is None


# Generated at 2022-06-23 22:29:02.944999
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = CompilationTarget.PYTHON
        
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    
    Transformer()
    # For now assert nothing, we only care that this doesn't raise an error

# Generated at 2022-06-23 22:29:04.138029
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert isinstance(BaseImportRewrite, type)  # type: ignore


# Generated at 2022-06-23 22:29:14.621742
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse
    from typed_ast import ast3

    rewrites = [('abc', 'def')]

    class T(BaseImportRewrite):
        rewrites = rewrites

    t = T(None)

    import_name = astor.to_source(ast.parse('import abc.ddd'))
    check_before, check_after = import_rewrite.get_body(previous=import_name, current='import def.ddd')
    body_node = t.visit(ast.parse(import_name))
    assert ast.Try == type(body_node)
    assert astunparse.unparse(body_node) == check_before
    assert astunparse.unparse(body_node.body[0].body[0]) == check_after
    assert ast

# Generated at 2022-06-23 22:29:18.882005
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.snippet import get_imports

    import_rewrite = BaseImportRewrite(None)
    assert import_rewrite.dependencies == ['typed_ast']
    assert 'from . import utils' in get_imports(import_rewrite)

# Generated at 2022-06-23 22:29:20.604509
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert BaseTransformer.transform.__name__ == 'transform'
    assert Callable[[BaseTransformer, ast.AST], None].__args__ == (BaseTransformer, Union[ast.AST, ast.Module])


# Generated at 2022-06-23 22:29:21.422260
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    global BaseImportRewrite
    BaseImportRewrite
    assert True

# Generated at 2022-06-23 22:29:22.120720
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:29:33.760021
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    from_ = 'a'
    to = 'b'
    tree = ast.parse(
        'from c import d, e\n'
        'from a import f, g\n'
        'from a.h import i, j\n'
        'from a.k import l, m\n')

    transformer = BaseImportRewrite()
    transformer.rewrites = [(from_, to)]
    transformer.visit(tree)

    result = astor.to_source(tree)
    # TODO: fix astor issue with quote
    # https://github.com/berkerpeksag/astor/issues/82

# Generated at 2022-06-23 22:29:40.829568
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import textwrap

    source = textwrap.dedent('''\
    import A
    import B.C
    from D import *
    from E import A, B
    from F.G import *
    from H.I.J import *''')

    tree = ast.parse(source)
    for node in ast.walk(tree):
        if hasattr(node, 'filename'):
            node.filename = '<test>'

    class Test(BaseImportRewrite):
        rewrites = [
            ('A', 'A1'),
            ('D', 'D1'),
            ('E.A', 'E.A1'),
            ('H.I', 'H.I1'),
        ]


# Generated at 2022-06-23 22:29:48.451144
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module')
        ]

    tree = ast.parse('''
from old_module import a
from old_module import b as c
''')

    expected_tree = ast.parse('''
try:
    from old_module import a
except ImportError:
    from new_module import a
try:
    from old_module import b as c
except ImportError:
    from new_module import b as c
''')

    assert Transformer.transform(tree).tree == expected_tree


# Generated at 2022-06-23 22:29:58.354941
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from astor.code_gen import to_source
    from astor.source_repr import dump, parse
    from astor.ast_repr import unparse, dump_tree
    from pprint import pprint
    from typing import Any, List, Tuple, Union, Optional, Iterable, Dict
    from functools import partial # type: ignore
    from .base import BaseNodeTransformer
    from .base import BaseImportRewrite
    from .base import snippet, extend
    from .base import BaseTransformer
    import ast
    import astor
    import asttokens
    import astunparse
    import typed_ast.ast3 as typed_ast
    import datetime
    import test.support

    _globals = {} # type: Dict[str, Any]
    _locals = {} # type: Dict[

# Generated at 2022-06-23 22:30:00.408641
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:30:10.822556
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..visitors import BaseImportRewrite
    from ..visitors.mock import ast

    import_node = ast.Import(names=[
        ast.alias(name='os',
                  asname=None)
    ])

    # No transformation applied
    result = BaseImportRewrite.transform(import_node)
    assert result == (import_node, False, [])

    # Transformation applied
    BaseImportRewrite.rewrites = [('os', 'ntpath')]
    result = BaseImportRewrite.transform(import_node)
    assert result.tree is not import_node

# Generated at 2022-06-23 22:30:20.017664
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import os", "", "exec")
    result = BaseImportRewrite.transform(tree)
    assert result.result.body[0].value.names[0].name == "os"
    assert result.tree_changed == False

    tree = ast.parse("import os2", "", "exec")
    result = BaseImportRewrite.transform(tree)
    assert result.result.body[0].value.names[0].name == "os2"
    assert result.tree_changed == False

    class Os3(BaseImportRewrite):
        rewrites = [("os2", "os")]

    tree = ast.parse("import os2", "", "exec")
    result = Os3.transform(tree)
    assert result.result.body[0].value.names[0].name == "os"

# Generated at 2022-06-23 22:30:21.463821
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from . import import_rewrite
    import_rewrite.BaseImportRewrite


# Generated at 2022-06-23 22:30:22.456840
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite is not None

# Generated at 2022-06-23 22:30:24.277597
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer): pass
    transformer = Transformer()
    assert transformer


# Generated at 2022-06-23 22:30:25.705321
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target is None



# Generated at 2022-06-23 22:30:27.846222
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ast import parse
    tree = parse('x = 10')
    class T(BaseNodeTransformer):
        pass
    
    T(tree)

# Generated at 2022-06-23 22:30:32.319779
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    class Example(BaseImportRewrite):
        rewrites = [
            ('six', 'six_mock')
        ]

    tree = ast.parse('''\
import six
from six import PY3
from six.moves import input, xrange
    ''')
    Example.transform(tree)

    assert astor.to_source(tree).strip() == '''\
import six_mock as six
try:\n    from six_mock import PY3\nexcept ImportError:\n    from six import PY3
try:\n    from six_mock.moves import input, xrange\nexcept ImportError:\n    from six.moves import input, xrange
    '''.strip()

# Generated at 2022-06-23 22:30:42.783917
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    import_from = ast.parse('from foo import x').body[0]  # type: ast.ImportFrom
    rewrited = ast.parse(
        'try:\n'
        '    from foo import x\n'
        'except ImportError:\n'
        '    from bar import x\n')
    rewrited = rewrited.body[0]  # type: ast.Try

    assert TestBaseImportRewrite.transform(import_from).tree == rewrited

    import_from = ast.parse('from foo.bar import z').body[0]  # type: ast.ImportFrom

# Generated at 2022-06-23 22:30:49.724326
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse('''
from urllib.parse import quote''').body[0]
    visitor = BaseImportRewrite(None)
    result = visitor.visit(import_from)
    assert result is not None
    assert astor.to_source(result) == '''
try:
    from urllib.parse import quote
except ImportError:
    from urllib.parse import quote
'''

# Generated at 2022-06-23 22:30:53.205009
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    test = BaseTransformer()
    test2 = BaseTransformer()
    assert not test
    assert test != test2
    assert test == BaseTransformer()
    assert test != BaseNodeTransformer()
    assert test != BaseImportRewrite()

# Generated at 2022-06-23 22:30:54.322701
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target is None



# Generated at 2022-06-23 22:31:02.294039
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer =  BaseImportRewrite()
    import ast
    import_node = ast.parse('import os').body[0]
    import_from_node = ast.parse('from sys import argv').body[0]
    import_from_node_with_star = ast.parse('from sys import *').body[0]
    import_from_node_with_aliases = ast.parse('from sys import argv as a').body[0]
    import_from_node_with_multiple_aliases = ast.parse('from sys import argv as a, version as b').body[0]

    # check import node
    transformer._get_matched_rewrite(None) == None
    transformer._get_matched_rewrite('os') == None
    transformer._get_matched_rewrite('sys') == None
    transformer._get_matched

# Generated at 2022-06-23 22:31:03.532763
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite

# Generated at 2022-06-23 22:31:10.062570
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('previous', 'current')]

    tree = ast.parse('import previous')
    expected = ast.parse('try:\n    import previous\nexcept ImportError:\n    import current')

    result = RewriteTransformer.transform(tree)
    assert result.tree == expected
    assert result.success
    assert result.dependencies == ['previous']



# Generated at 2022-06-23 22:31:11.569087
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:31:15.451875
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """Unit test for BaseNodeTransformer constructor."""
    tree = ast.parse('x = 5')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:31:16.603424
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite()
    assert isinstance(instance, BaseImportRewrite)

# Generated at 2022-06-23 22:31:17.715803
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test = BaseNodeTransformer(None)
    assert test._tree_changed == False

# Generated at 2022-06-23 22:31:22.477443
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import ast

    class TestBaseTransformer(BaseTransformer):
        target = "python>=3.6"

        @classmethod #Takes class as a first argument
        def transform(cls, tree):
            pass

    # Lets try to call the constructor
    base_transformer = TestBaseTransformer()

    # Lets inspect the instance of class BaseTransformer
    assert isinstance(base_transformer, BaseTransformer)
    assert base_transformer.target == 'python>=3.6'

# Generated at 2022-06-23 22:31:26.457152
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Rewriter(BaseImportRewrite):
        rewrites = [
            ('a.b', 'c'),
        ]

    inst = Rewriter(ast.parse('import a.b'))
    inst.visit(ast.parse('import a.b'))
    assert inst._tree_changed == True

# Generated at 2022-06-23 22:31:29.424724
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    node = ast.Import()
    instance = BaseNodeTransformer(node)
    assert instance._tree == node
    assert instance._tree_changed == False


# Generated at 2022-06-23 22:31:38.845133
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transforms.base import BaseImportRewrite
    import ast
    class Example(BaseImportRewrite):
        rewrites = [
            ('future', 'past'),
        ]
        dependencies = []

    node = ast.Import(names=[
        ast.alias(name='future.utils',
                  asname=None)])

    expected = ast.Try(body=[
        ast.Import(names=[
            ast.alias(name='past.utils',
                      asname=None)])
        ],
        handlers=[
        ast.ExceptHandler(type=None,
                          name=None,
                          body=[
            ast.Import(names=[
                ast.alias(name='future.utils',
                          asname=None)])])
        ],
        orelse=[],
        finalbody=[])

    assert Example().vis

# Generated at 2022-06-23 22:31:47.781765
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # BaseImportRewrite is abstract class, so it can't be instantiated
    # Use MyTransformer as a placeholder
    class MyTransformer(BaseImportRewrite):
        target = "python27"
        rewrites = [
            ('__builtin__', 'builtins'),
        ]

    class MyOtherTransformer(MyTransformer):
        target = "python36"
        rewrites = [
            ('__builtin__', 'builtins'),
        ]
        dependencies = ["re"]

    # Case 1: simple import
    import_code = "import __builtin__"
    try_code = "try:\n    import __builtin__\nexcept ImportError:\n    import builtins"
    import_ast = ast.parse(import_code)
    try_ast = ast.parse(try_code)


# Generated at 2022-06-23 22:31:51.398512
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass
    tree = ast.parse('pass')
    transformer = TestTransformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed is False

# Unit tests for method _get_matched_rewrite

# Generated at 2022-06-23 22:31:54.401414
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor

    a = ast.parse('a = 1')
    b = BaseNodeTransformer(a)
    assert astor.to_source(b._tree) == astor.to_source(a)



# Generated at 2022-06-23 22:31:57.793891
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import typing
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)
    assert hasattr(BaseNodeTransformer, 'transform')
    assert isinstance(BaseNodeTransformer.transform, typing.Callable)

# Unit tests for constructor of class BaseImportRewrite

# Generated at 2022-06-23 22:32:05.804490
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Generate AST node
    node = ast.parse('from A import B, C as D, E as F')
    node = node.body[0]

    # Generate class
    class Transformer(BaseImportRewrite):
        pass

    # Generate instance of class Transformer
    transformer = Transformer(ast.parse('a'))

    # Transform node
    new_node = transformer.visit_ImportFrom(node)

    # Assert equality of transformed node
    new_node == node


# Generated at 2022-06-23 22:32:07.175007
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer



# Generated at 2022-06-23 22:32:18.062639
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import copy

    node = ast.parse('from foo import a as foo_a, b as foo_b, foo_func')
    original_tree = astor.to_source(copy.deepcopy(node))

    class ImportRewriteSample(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    new_tree, changed, _ = ImportRewriteSample.transform(node)
    new_tree = astor.to_source(new_tree)

    assert changed is True

    assert new_tree == """\
try:
    from foo import a as foo_a, b as foo_b, foo_func
except ImportError:
    from bar import a as foo_a, b as foo_b
    from bar import foo_func
"""

# Generated at 2022-06-23 22:32:19.022345
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()
    # pass

# Generated at 2022-06-23 22:32:27.962006
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    import unittest
    import types

    class TestTransformer(BaseImportRewrite):
        target = 'mypy'
        rewrites = [('tensorflow', 'tensorflow_typed')]

    def test_visit_ImportFrom(self, transformer: TestTransformer, node: ast.ImportFrom, expected: str):
        assert astunparse.unparse(transformer.visit(node)) == expected

    for testcase in types.ModuleType('testcases'):
        transformer = TestTransformer(None)
        test_visit_ImportFrom = create_method(testcase, test_visit_ImportFrom)
        test_visit_ImportFrom(transformer, testcase.node, testcase.expected)

# Generated at 2022-06-23 22:32:32.935579
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import foo\n')
    transformer = BaseNodeTransformer(tree=tree)
    assert transformer._tree == tree
    assert transformer._tree_changed is False


# Unit tests for constructor of class BaseImportRewrite

# Generated at 2022-06-23 22:32:33.971258
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(1)

# Generated at 2022-06-23 22:32:41.849177
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Unit test for BaseImportRewrite.visit_Import."""
    import astunparse

    class Transformer(BaseImportRewrite):
        rewrites = [('collections.abc', 'collections')]

    code = 'import collections.abc as abc'
    expected_result = '''
try:
    import collections.abc as abc
except ImportError:
    import collections as abc
'''

    tree = ast.parse(code)
    Transformer.transform(tree)
    result = astunparse.unparse(tree).strip()

    print(result)
    print(expected_result)

    assert result == expected_result


# Generated at 2022-06-23 22:32:44.658329
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None
    assert BaseTransformer.transform.__doc__ == None


# Generated at 2022-06-23 22:32:49.229542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_ = 'six'
    to = 'my_six'
    node = ast.parse('import six').body[0]

    transformer = BaseImportRewrite([(from_, to)])
    res = transformer.visit(node)

    assert isinstance(res, ast.Try)
    assert len(res.body) == 1
    assert isinstance(res.body[0], ast.Import)
    assert res.body[0].names[0].name == to



# Generated at 2022-06-23 22:32:57.397288
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test_BaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse("""
    import a
    import c
    """)

    expected = """
    try:
        import a
    except ImportError:
        import b
    import c
    """

    result = Test_BaseImportRewrite_visit_Import.transform(tree)

    assert expected in str(result.tree)
    assert result.tree_changed


# Generated at 2022-06-23 22:33:00.173187
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class DummyTransformer(BaseNodeTransformer):
        transformations = []

    tree = ast.parse('import a')
    assert isinstance(DummyTransformer.transform(tree), TransformationResult)

# Generated at 2022-06-23 22:33:01.094321
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(None)



# Generated at 2022-06-23 22:33:08.142793
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.snippet import Snippet as CodeExperiment
    import astor

    # Rewrite imports for ``six.moves`` and ``six``
    class SixImportRewrite(BaseImportRewrite):  # type: ignore
        rewrites = [('six.moves', 'six')]

    def _test_OneImport(sut, sample, expected):
        tree = ast.parse(sample, '<test>')
        tree = ast.fix_missing_locations(tree)

        result = sut.transform(tree)
        result = astor.to_source(result.tree)
        result = result.strip()  # remove newlines

        assert result == expected, (result, expected)

    sut = SixImportRewrite()

    # Rewrite import statement

# Generated at 2022-06-23 22:33:19.654597
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Arg0Rewrite(BaseImportRewrite):
        rewrites = [('arg0', 'six')]

    source = 'import arg0'
    tree = ast.parse(source)
    Arg0Rewrite.transform(tree)
    assert ast.dump(tree) == '''Module(body=[Try(body=[Import(names=[alias(name='six', asname=None)])],
                                      handlers=[],
                                      orelse=[],
                                      finalbody=[])])'''

    class Arg0Rewrite(BaseImportRewrite):
        rewrites = [('arg0.tests', 'six.tests')]

    source = 'import arg0.tests'
    tree = ast.parse(source)
    Arg0Rewrite.transform(tree)

# Generated at 2022-06-23 22:33:23.108437
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseNodeTransformer({})
    assert transformer.target == None
    try:
        transformer.transform({})
    except NotImplementedError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 22:33:29.642009
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from ..types import CompilationTarget
    from ..utils.snippet import extend
    import_rewrite = extend('import_rewrite')

    assert CompilationTarget.PY2.value == '2'
    assert CompilationTarget.PY3.value == '3'

    def test_visit_Import(visitor):
        tree = ast3.parse('import foo')
        tree = visitor.visit(tree)
        assert tree.body[0].body[0].body[0].value.names[0].name == 'foo'
        assert tree.body[0].body[0].orelse[0].value.names[0].name == 'foo3'

        tree = ast3.parse('import foo3')
        tree = visitor.visit(tree)
        assert tree.body

# Generated at 2022-06-23 22:33:30.883809
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()



# Generated at 2022-06-23 22:33:38.507036
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    def check_transformation(tree, expected):
        compiled = compile(tree, '<string>', 'exec')
        if expected is None:
            assert compiled.co_code == compile(tree, '<string>', 'exec').co_code
        else:
            assert compiled.co_code == compile(expected, '<string>', 'exec').co_code

    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [('sys', 'sage.repl.load')]

    check_transformation('''
import sys
''', '''
try:
    import sys
except ImportError:
    import sage.repl.load as sys
''')


# Generated at 2022-06-23 22:33:39.869254
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-23 22:33:49.965620
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.node_visit_mixin import CollectNodeVisitor
    from ..utils.snippet import get_body

    class TestClass(BaseImportRewrite):
        rewrites = [('xmlrpc', 'xmlrpclib')]

    imports = get_body('''import xmlrpc
from xmlrpc import client
import os
from os import path
from os.path import join

from xmlrpc.client import loads
from xmlrpc.client import loads
''')

    collected_nodes = []  # type: List[ast.AST]

    class NodeCollector(CollectNodeVisitor):
        def __init__(self, nodes: List[ast.AST]) -> None:
            self._nodes = nodes

        def generic_visit(self, node: ast.AST) -> None:
            self

# Generated at 2022-06-23 22:33:57.445141
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class Testimportrewrite(BaseImportRewrite):
        rewrites = [('import_a', 'import_b')]

    tree = ast.parse('from import_a import package_a')
    expected = ast.parse('''
try:
    from import_a import package_a
except ImportError:
    from import_b import package_a
''')
    node_transformer = Testimportrewrite(tree)
    node_transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 22:34:05.193623
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("import foo\n"
                     "from foo import bar\n")
    result = BaseImportRewrite.transform(tree)
    assert result.changed is False

    result = BaseImportRewrite.transform(tree)
    assert result.changed is False

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo\n"
                     "from foo import bar\n")
    result = ImportRewrite.transform(tree)
    assert result.changed is True
    assert result.tree == ast.parse("import bar\n"
                                    "from bar import bar\n")

# Generated at 2022-06-23 22:34:11.519260
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Assign(self, node):
            self._tree_changed = True

            return ast.Assign(targets=node.targets,
                              value=ast.Num(n=1))

    tree = ast.parse("a = 2")
    result = TestTransformer.transform(tree)

    assert result.tree is not tree
    assert result.tree is not None
    assert result.tree_changed is True



# Generated at 2022-06-23 22:34:13.183512
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite(): 
    BaseImportRewrite(ast.AST())

# Generated at 2022-06-23 22:34:16.711099
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    _BaseNodeTransformer = BaseNodeTransformer(tree=None)
    assert _BaseNodeTransformer._tree is None
    assert _BaseNodeTransformer._tree_changed is False


# Generated at 2022-06-23 22:34:27.644799
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.parse('from datetime import datetime').body[0] # type: ignore
    assert isinstance(import_from, ast.ImportFrom)
    old_module = import_from.module

    # Rewrite 'datetime'
    import_from_rewrite = BaseImportRewrite(import_from)
    import_from_rewrite.rewrites = [('datetime', '_datetime')]

    new_node = import_from_rewrite.visit_ImportFrom(
        import_from)  # type: ignore

    assert isinstance(new_node, ast.Try)
    assert len(new_node.finalbody) == 1
    assert isinstance(new_node.finalbody[0], ast.ImportFrom)
    assert new_node.finalbody[0].module == '_datetime'

   

# Generated at 2022-06-23 22:34:28.292382
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:34:38.876082
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [(from_, to) for from_, to in [
            ('old_import', 'new_import'),
            ('old_import2', 'new_import2'),
        ]]

    from_, to = TestBaseImportRewrite.rewrites[0]
    import_ = ast.Import(names=[
        ast.alias(name=from_,
                  asname=None)])

    result = TestBaseImportRewrite.transform(import_)
    assert isinstance(result.transformed_tree, ast.Try)

    assert result.transformed_tree.body[0].value.names[0].name == to
    assert len(result.transformed_tree.body) == 1
    assert len(result.transformed_tree.handlers) == 1


# Generated at 2022-06-23 22:34:46.912518
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..parso_helper import dump_python_source
    from ..utils.source import Source
    from ..utils.tree_compare import assert_source_equal

    source = Source("from tkinter import *")
    assert dump_python_source(source.tree) == "from tkinter import *"

    transform = BaseImportRewrite.transform(source.tree)
    assert_source_equal(transform.tree, "from tkinter import *")

    transform = BaseImportRewrite.transform(source.tree)
    assert_source_equal(transform.tree, "from tkinter import *")

    source = Source("from tkinter.font import *")
    assert dump_python_source(source.tree) == "from tkinter.font import *"

    transform = BaseImportRewrite.transform(source.tree)


# Generated at 2022-06-23 22:34:51.951875
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """Tests that BaseNodeTransformer initializes a tree."""
    class TreeTransfomer(BaseNodeTransformer):
        def visit_Module(self, node):
            pass

    tree = ast.parse('1+1')
    transformer = TreeTransfomer(tree)
    assert transformer._tree is tree

# Generated at 2022-06-23 22:34:52.520794
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-23 22:34:58.591909
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.visitor import get_module_ast
    module = get_module_ast("""
try:
    from old.name import thing
except ImportError:
    from new.name import thing

try:
    from old.name import thing as alias
except ImportError:
    from new.name import thing as alias

try:
    from old.name import thing as alias
except ImportError:
    from old.name import thing

try:
    from old.name import *
except ImportError:
    from old.name import *

try:
    import old.name
except ImportError:
    import new.name

try:
    import old.name as alias
except ImportError:
    import new.name as alias
""")
    BaseImportRewrite(module)

# Generated at 2022-06-23 22:35:02.853131
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("from logging import getLogger")
    tree_changed, tree = BaseImportRewrite.transform(tree)
    assert tree_changed
    assert ast.dump(tree) == "from logging import getLogger"

# Generated at 2022-06-23 22:35:09.044508
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    from ..utils.ast_helper import dump

    class Example(BaseImportRewrite):
        rewrites = [('Math', 'FooBar.BarBaz')]

    tree = ast.parse("""from Math import sqrt, radians
from foo import bar, baz
from foo.bar import baz
from foo.bar import baz as baz2
from Math import pow as pow2, sin as sin2""")
    tree = Example().visit(tree)
    dump(tree)
    tree = ast.parse(astunparse.unparse(tree))
    dump(tree)



# Generated at 2022-06-23 22:35:10.345080
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite()


# Generated at 2022-06-23 22:35:18.253987
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    from ..utils.compiler import compile_ast

    class Dummy(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Test(unittest.TestCase):
        def test(self):
            tree = ast.parse('import foo')
            result = Dummy.transform(tree)  # type: ignore
            self.assertEqual(compile_ast(result.tree), 'import bar')

    Test().test()


# Generated at 2022-06-23 22:35:19.114482
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    x = BaseTransformer()
    

# Generated at 2022-06-23 22:35:19.944070
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    intransformer = BaseImportRewrite(None)
    assert intransformer is not None

# Generated at 2022-06-23 22:35:26.279846
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    def do_assert(source: str, target: Optional[str]) -> None:
        if target is None:
            target = source

        tree = ast.parse(source)
        transformer = BaseImportRewrite(tree)  # type: ignore
        transformer.visit_Import(tree.body[0])

        assert transformer._tree_changed
        assert transformer._tree.body[0] == ast.parse(target).body[0]

    do_assert('import fake_package',
              'try:\n    import fake_package\nexcept ImportError:\n    import flake8_polyfill.fake_package')
    do_assert('import abc.package',
              'try:\n    import abc.package\nexcept ImportError:\n    import flake8_polyfill.abc.package')

# Generated at 2022-06-23 22:35:33.774900
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.test import make_test

    class Test(BaseImportRewrite):
        rewrites = [('six', 'test')]

    program = [
        'import six',
        'import six.moves',
        'import b',
    ]

    expected_program = [
        'try:',
        '    import six',
        'except ImportError:',
        '    import test',
        'import test.moves',
        'import b',
    ]

    make_test(Test, program, expected_program)


# Generated at 2022-06-23 22:35:36.331139
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestClass(BaseTransformer):
        target = CompilationTarget.Python37
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return True

    assert issubclass(TestClass, BaseTransformer)

test_BaseTransformer()


# Generated at 2022-06-23 22:35:41.269679
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class _BaseNodeTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            pass

        def visit_Attribute(self, node):
            pass

        def visit_BoolOp(self, node):
            pass

        def visit__(self, node):
            pass

    _BaseNodeTransformer('tree')

# Generated at 2022-06-23 22:35:50.051699
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import unittest

    class BaseNodeTransformerTestCase(unittest.TestCase):
        def test_init(self):
            from astunparse import unparse

            tree = ast.parse('''\
import json
from json import load, dump
print('hello')
''')

            class DummyTransformer(BaseNodeTransformer):
                pass

            inst = DummyTransformer(tree)
            self.assertTrue(isinstance(inst._tree, ast.Module))
            self.assertEqual(unparse(inst._tree), unparse(tree))
            self.assertEqual(inst._tree_changed, False)

    unittest.main()



# Generated at 2022-06-23 22:35:54.040454
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Test(BaseTransformer):
        target = None
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(None, False, [])
    test = Test.transform(ast.parse("pass"))
    assert test is not None

# Generated at 2022-06-23 22:36:03.593450
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        rewrites = [('name1', 'name2')]

    # Test import
    def test_import():
        tree = ast.parse("import name1")
        Test.transform(tree)

        expected = ast.parse("try:\n    import name1\nexcept ImportError:\n    import name2")
        assert ast.dump(tree) == ast.dump(expected)

    test_import()

    # Test import from
    def test_import_from():
        tree = ast.parse("from name1 import var")
        Test.transform(tree)

        expected = ast.parse("try:\n    from name1 import var\nexcept ImportError:\n    from name2 import var")
        assert ast.dump(tree) == ast.dump(expected)

    test_import_from()



# Generated at 2022-06-23 22:36:11.662124
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    tree = astor.parse("from foo import bar", mode="exec")
    node = tree.body[0]

    class FooBar(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    result = FooBar.transform(tree)

    expected = astor.parse("try:\n    from foo import bar\nexcept ImportError:\n    from bar import bar", mode="exec")
    assert astor.dump_tree(result.tree) == astor.dump_tree(expected)



# Generated at 2022-06-23 22:36:22.308972
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class R(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo1.bar1')]
    t = ast.parse('''
from foo import baz
from foo.bar import baz
from foo.bar import baz as baz1
from foo.bar import *
from foo import bar as bar1
from foo.bar import bar as bar1
from foo.bar import baz as baz1, bar as bar1, bar2
''')
    r = R(t)
    r.visit(t)

# Generated at 2022-06-23 22:36:23.918258
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(None)
    assert not transformer._tree_changed

# Generated at 2022-06-23 22:36:26.824247
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    inst = BaseImportRewrite(None)
    def_tree_changed = inst._tree_changed
    assert def_tree_changed == False
    
    inst._tree_changed = True
    assert inst._tree_changed == True
    
    assert inst.transform(None) == None


# Generated at 2022-06-23 22:36:31.771130
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('sys', 'six')]

    test_ast_snippet = """
import sys
"""
    ast_tree = ast.parse(test_ast_snippet)
    tree = TestTransformer.transform(ast_tree).tree
    assert astor.to_source(tree) == """
try:
    import sys
except ImportError:
    import six
"""



# Generated at 2022-06-23 22:36:42.286598
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compiler.codegen import CstCodeGenerator
    from ..parser import Parser

    obj = BaseImportRewrite()
    obj.rewrites = [('six', 'six.moves')]
    imported_name = "six.moves.{}".format("reduce")
    b = Parser.parse("import six as sx; sx")

    assert (
        CstCodeGenerator(b.body[0].as_import_from).to_source_code() ==
        CstCodeGenerator(obj.visit(b)).to_source_code()
    )

    b = Parser.parse("import {}".format(imported_name))
