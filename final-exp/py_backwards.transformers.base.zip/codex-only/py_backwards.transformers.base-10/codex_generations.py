

# Generated at 2022-06-23 22:26:29.626972
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    test = True
    if test:
        assert True
    else:
        assert False


# Generated at 2022-06-23 22:26:30.505962
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.rewrites == []

# Generated at 2022-06-23 22:26:36.381487
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import get_sample_path
    from ..utils.files import read
    from ..utils.compilation_target import CompilationTarget
    from .imports import FixImports

    path = get_sample_path('six_fix_imports.py')
    tree = ast.parse(read(path), filename='six_fix_imports.py')
    f = FixImports()
    f.target = CompilationTarget(filename=path)
    f.transform(tree)

    result = ast.dump(tree, indent='    ')
    expected = read(get_sample_path('six_fix_imports_result.py'))

    assert result == expected

# Generated at 2022-06-23 22:26:43.651386
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestClass(BaseImportRewrite):
        rewrites = [('x', 'old_x'),
                    ('old_y', 'y')]

    tree = ast.parse('''
from y import x
import x.y
x.y.z
import y
from x import y
    ''')
    # import_rewrite() does not have side effects
    # so to test if it was called we need to do
    # some hackery.
    import_rewrite.insert()
    result = TestClass.transform(tree)
    import_rewrite.remove()


# Generated at 2022-06-23 22:26:45.341761
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    d = {}
    BaseTransformer()
    assert d == {}


# Generated at 2022-06-23 22:26:49.650758
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old')
    tree_res, tree_changed, _ = TestTransformer.transform(tree)
    assert tree_changed



# Generated at 2022-06-23 22:26:51.616886
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(None)
    assert transformer._tree is None
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:26:52.236823
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:26:54.448121
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__init__.__annotations__['return'] == None


# Generated at 2022-06-23 22:27:01.971253
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('''
        import <old>_module

        <old>_module.x 
        <old>_module.y
    ''')

    from_, to = '<old>', '<new>'
    transformer = BaseImportRewrite()
    transformer.rewrites = [(from_, to)]
    transformer.transform(tree)

    assert ast.dump(tree) == '''
        try:
            import <old>_module
        except ImportError:
            import <new>_module
        <new>_module.x
        <new>_module.y
    '''



# Generated at 2022-06-23 22:27:11.224392
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import astor
    # Build AST
    tree_string = """
import django.contrib.auth
from django.contrib.auth import *
from django.contrib.auth import user
    """
    tree = ast.parse(tree_string, mode='exec')
    expected_code = """
try:
    import django.contrib.auth
except ImportError:
    import django_contrib_auth as django.contrib.auth

try:
    from django.contrib.auth import *
except ImportError:
    from django_contrib_auth import *
try:
    from django.contrib.auth import user
except ImportError:
    from django_contrib_auth import user
    """
    expected_code = ast.parse(expected_code, mode='exec')

# Generated at 2022-06-23 22:27:21.078418
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTransformer(BaseImportRewrite):
        def __init__(self, tree):
            rewrites = [('m1', 'm1rewrote')]
            super().__init__(tree, rewrites)

    tree = ast.parse('''
from m1 import a
from m2 import b
from m3 import c
    ''')
    rw, is_changed, deps = ImportTransformer.transform(tree)
    assert is_changed
    assert deps == ['m1rewrote']
    assert ast.dump(rw) == '''Module(body=[Try(body=[Import(names=[alias(name='m1rewrote', asname='a')], lineno=2, col_offset=0)])], type_ignores=[])'''



# Generated at 2022-06-23 22:27:30.461565
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = """
from abc import ABCMeta
from datetime import datetime
from datetime import (timedelta, datetime)
from datetime import timedelta as td
import abc.abc
"""
    old_import_module = 'datetime'
    old_import_module_with_dot = '{}.'.format(old_import_module)

    new_import_module = 'mydtm'
    new_import_module_with_dot = '{}.'.format(new_import_module)

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [
            (old_import_module, new_import_module)
        ]

    tree = ast.parse(code)
    transformed = MyImportRewrite.transform(tree)


# Generated at 2022-06-23 22:27:33.808862
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import CompilationTarget
    from ..utils.snippet import source

    with source('foo') as filename:
        tree = ast.parse(filename)
        inst = BaseNodeTransformer(tree)
        assert isinstance(inst, BaseNodeTransformer)

# Generated at 2022-06-23 22:27:44.050983
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert BaseImportRewrite.rewrites == []
    assert BaseImportRewrite.dependencies == []
    assert BaseImportRewrite.target == None
    assert BaseImportRewrite.transform == BaseImportRewrite.transform
    assert BaseImportRewrite.visit_Import == BaseImportRewrite.visit_Import
    assert BaseImportRewrite.visit_ImportFrom == BaseImportRewrite.visit_ImportFrom
    assert BaseImportRewrite._get_matched_rewrite('_abc') == None
    assert BaseImportRewrite._replace_import('Import', 'from_', 'to') == 'Try'
    assert BaseImportRewrite._replace_import_from_module('ImportFrom', 'from_', 'to') == 'Try'

# Generated at 2022-06-23 22:27:50.898334
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    name = "import abc"
    module_name = name.split()[1]
    # Create AST for input string
    tree = ast.parse(name)
    # Create instance of class BaseImportRewrite
    inst = BaseImportRewrite(tree)
    
    # Run a test
    node = tree.body[0]
    assert isinstance(node, ast.Import)
    # When
    actual = inst.visit_Import(node)
    # Then
    assert isinstance(actual, ast.Try)
    assert isinstance(actual.body[0], ast.Import)
    assert module_name == actual.body[0].names[0].name
    


# Generated at 2022-06-23 22:27:59.881579
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ConcreteImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz.qux')]

    import_stmt = ast.parse('import foo.bar')
    rewrote = ConcreteImportRewrite(import_stmt).visit(import_stmt)
    assert(rewrote.body[0].body[0].value.func.id == 'extend')
    assert(rewrote.body[0].body[0].value.args[0].s == 'baz.qux')
    assert(rewrote.body[0].body[0].value.args[0].s == 'baz.qux')

    from_stmt = ast.parse('from foo.bar import baz')

# Generated at 2022-06-23 22:28:06.112624
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():

    class DummyTransformer(BaseNodeTransformer):
        pass

    assert DummyTransformer._tree is None
    assert DummyTransformer._tree_changed is False

    dummy_tree = ast.parse("")
    dummy_transformer = DummyTransformer(dummy_tree)
    assert dummy_transformer._tree is dummy_tree
    assert dummy_transformer._tree_changed is None


# Generated at 2022-06-23 22:28:10.417993
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseNodeTransformer), "expected BaseNodeTransformer to be a subclass of BaseImportRewrite"
    try:
        BaseImportRewrite()
        assert False, "expected exception TypeError"
    except TypeError:
        pass


# Generated at 2022-06-23 22:28:12.688889
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    code = """
    from pypy.module.pyexpat import model
    """
    tree = ast.parse(code)
    BaseTransformer.transform(tree)

# Generated at 2022-06-23 22:28:14.461879
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import get_tree
    tree = get_tree('import os')  # type: ast.AST
    result, changed, deps = BaseImportRewrite.transform(tree)

    assert(not changed)
    assert(not deps)


# Generated at 2022-06-23 22:28:16.851117
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Foo(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    inst = Foo(None)
    assert inst


# Generated at 2022-06-23 22:28:17.695951
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()

# Generated at 2022-06-23 22:28:18.972564
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None


# Generated at 2022-06-23 22:28:19.453654
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:23.362414
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # TODO
    # @add_method
    # def __init__(self, tree: ast.AST) -> None:
    #     super().__init__()
    #     self._tree = tree
    #     self._tree_changed = False
    pass

# Generated at 2022-06-23 22:28:34.943811
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('config', 'config_'),
                ('config.settings', 'config_settings')]
    imports = [
        'from config import settings',
        'from config.settings import setting',
        'from config import settings as conf',
        'from config.settings import setting as conf_setting',
        'from config import settings, parser',
        'from config.settings import setting, parser',
        'from config import settings as conf, parser',
        'from config.settings import setting as conf_setting, parser',
        'from config import settings as conf, parser as par',
        'from config.settings import setting as conf_setting, parser as par',
        'from config import settings, parser as par',
        'from config.settings import setting, parser as par'
    ]

# Generated at 2022-06-23 22:28:42.564905
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import pytest
    import astunparse

    class Test(BaseNodeTransformer):
        def visit_Module(self, node):
            pass

        def generic_visit(self, node):
            pass

    class BadTest(BaseNodeTransformer):
        def visit(self, node):
            pass

        def generic_visit(self, node):
            pass

    tree = ast.parse('')
    BaseNodeTransformer.transform(tree)  # type: ignore

    with pytest.raises(TypeError):
        BaseNodeTransformer.transform(123)

    with pytest.raises(TypeError):
        BaseNodeTransformer.transform(astunparse.ast2str(tree))

    with pytest.raises(TypeError):
        Test.transform(tree)


# Generated at 2022-06-23 22:28:49.147938
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert BaseImportRewrite({}, []).visit_Import(ast.parse('import sys').body[0]).body
    assert BaseImportRewrite({}, []).visit_Import(ast.parse('import sys as foo').body[0]).body
    assert BaseImportRewrite({'sys': 'asyncio'}, []).visit_Import(ast.parse('import sys').body[0]).body
    assert BaseImportRewrite({'sys': 'asyncio'}, []).visit_Import(ast.parse('import sys as foo').body[0]).body


# Generated at 2022-06-23 22:28:52.622147
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """Test for constructor of class BaseNodeTransformer."""
    tree = ast.parse('x = 1')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed is False



# Generated at 2022-06-23 22:28:54.919781
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__name__ == 'BaseTransformer'
    assert BaseTransformer.__doc__ is None
    assert BaseTransformer.target is None


# Generated at 2022-06-23 22:29:04.300653
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('xmlrpc.client', 'xmlrpclib')]

    # Test single import, module name
    tree = ast.parse("""
        import xmlrpc.client
    """)
    assert str(Transformer.transform(tree).tree) == """
        import xmlrpclib
    """

    # Test single import, rewritten module name
    tree = ast.parse("""
        import xmlrpclib
    """)
    assert str(Transformer.transform(tree).tree) == """
        import xmlrpclib
    """

    # Test single import, module name with another name
    tree = ast.parse("""
        import xmlrpc.client as foo
    """)

# Generated at 2022-06-23 22:29:09.979318
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    transformed = BaseImportRewrite.transform(ast.parse("""
    import unittest
    """))
    assert transformed.applied_changes

    transformed = BaseImportRewrite.transform(ast.parse("""
    import unittest, os
    """))
    assert not transformed.applied_changes

    transformed = BaseImportRewrite.transform(ast.parse("""
    import unittest as ut
    """))
    assert transformed.applied_changes

    transformed = BaseImportRewrite.transform(ast.parse("""
    import unittest.mock.mock_open
    """))
    assert transformed.applied_changes



# Generated at 2022-06-23 22:29:13.787978
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = ast.parse('''import re''')
    tree = BaseImportRewrite(tree).visit(tree)
    assert astor.to_source(tree) == 'try:\n    import re\nexcept ImportError:\n    import re'



# Generated at 2022-06-23 22:29:16.762471
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    b = BaseImportRewrite()
    assert(b._tree == None)
    # assert(b._tree_changed == False)
    assert(b.rewrites == [])

# Generated at 2022-06-23 22:29:27.625848
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    
    rewrites = []

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse("from module_1 import function")

    rewrites = [("module_1", "module_2")]
    ret = TestBaseImportRewrite.transform(tree) 
    assert(ret.changed)
    assert(tree == ast.parse("from module_2 import function"))

    tree = ast.parse("from module_1 import *")

    rewrites = [("module_1", "module_2")]
    ret = TestBaseImportRewrite.transform(tree) 
    assert(ret.changed)
    assert(tree == ast.parse("from module_2 import *"))



# Generated at 2022-06-23 22:29:31.044610
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # type: () -> None
    class TestTransformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__(None)

    assert not TestTransformer()._tree_changed

# Generated at 2022-06-23 22:29:31.521979
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:29:31.993751
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:29:34.671392
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__name__ == 'BaseTransformer'
    assert BaseTransformer.__module__ == 'src.transformers.base'
    assert BaseTransformer.__bases__ == (abc.ABCMeta,)
    assert BaseTransformer.target is None


# Generated at 2022-06-23 22:29:41.496158
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astunparse
    code = """
    from module1 import fun1
    import module1
    """
    node = ast.parse(code)
    tree = ast.parse(code)
    rewrites = [('module1', 'module2')]

    class TestImportRewrite1(BaseImportRewrite):
        rewrites = rewrites

    class TestImportRewrite2(BaseImportRewrite):
        rewrites = [('mod', 'module')]

    tr = TestImportRewrite1()

    tr.visit(node)
    assert tree != node
    assert ast.dump(tree) != ast.dump(node)
    assert astunparse.unparse(tree) == code

# Generated at 2022-06-23 22:29:51.713307
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from x.y import z')
    node = tree.body[0]
    import mock
    trans = mock.Mock(rewrites=[])
    trans.rewrites = [('x', 'y')]
    trans._get_replaced_import_from_part = lambda node, alias, names_to_replace: alias
    trans._replace_import_from_names = lambda node, names_to_replace: node
    trans._get_names_to_replace = lambda node: []
    result = trans.visit_ImportFrom(node)
    assert isinstance(result, ast.Try)

    tree = ast.parse('from x.y import z')
    node = tree.body[0]
    import mock
    trans = mock.Mock(rewrites=[])

# Generated at 2022-06-23 22:29:52.615494
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None



# Generated at 2022-06-23 22:30:03.784952
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compilers.python.imports import (DjangoRestFrameworkTestCase,
                                            Patch,
                                            Mock)
    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [('rest_framework.test', 'rest_framework.testcases'),
                    ('rest_framework.test.APITestCase',
                     'rest_framework.testcases.APITestCase')]

    import_tree = ast.parse(
        "from rest_framework.test import APITestCase\n"
        "from rest_framework.test import APIView\n")

# Generated at 2022-06-23 22:30:04.800926
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    f = BaseImportRewrite()


# Generated at 2022-06-23 22:30:11.986640
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from pandas.compat._optional import import_optional_dependency
    import pandas
    from pandas.compat._optional import import_optional_dependency as import_optional_dependency_2
    import pandas.compat._optional as _optional
    from pandas.compat._optional import import_optional_dependency as import_optional_dependency_3
    class Test(BaseImportRewrite):
        rewrites = [('pandas.compat._optional', 'pandas.compat.tests._optional')]
        def visit_Import(self, node):
            return super().visit_Import(node)
    class Import(ast.Import): pass

# Generated at 2022-06-23 22:30:19.178159
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    from pprint import pprint

    tree = ast.parse(dedent('''
        from foo import bar
        from foo.bar import a, b as c
        from foo.bar.t import t1
        from foo.bar.t import t2 as t3
        '''))
    bnt = BaseNodeTransformer(tree)
    bnt.visit_ImportFrom(tree.body[2])
    print(astor.to_source(bnt._tree))
    print(bnt._tree_changed)
    print(bnt.dependencies)



# Generated at 2022-06-23 22:30:20.905282
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target is None


# Generated at 2022-06-23 22:30:23.884539
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class _Transformer(_TestTransformer):
        pass
    assert _Transformer._test_tree_changed == False
    assert _Transformer._test_tree == 'test_tree'


# Generated at 2022-06-23 22:30:32.925926
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('import_1', 'import_1'),
            ('import_2', 'import_22'),
            ('import_3', 'import_33')
        ]

    tree_module = ast.parse("""
from import_1 import module_1_1
from import_2 import module_2, module_2_2
from import_1 import module_1_2
from import_3 import module_3, module_3_1, module_3_2
from import_2 import module_2_3
""")

    transformer = TestImportRewrite(tree_module)
    transformer.visit(tree_module)
    assert transformer._tree_changed == True, "Method don't changed tree"


# Generated at 2022-06-23 22:30:41.733207
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse(textwrap.dedent('''\
    try:
        import unittest.case
    except ImportError:
        import unittest
        import unittest.case
    '''))

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('unittest.case', 'unittest')
        ]

    assert Rewrite.transform(tree).tree == ast.parse(textwrap.dedent('''\
    try:
        import unittest
    except ImportError:
        import unittest
        import unittest
    '''))


# Generated at 2022-06-23 22:30:46.837510
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib.requests')]
    assert TestBaseImportRewrite.rewrites == [('urllib.request', 'urllib.requests')]



# Generated at 2022-06-23 22:30:54.284863
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Dummy(BaseImportRewrite):
        rewrites = [('old', 'new')]

    node = ast.Import([
        ast.alias(name='old',
                  asname='dummy')])
    result = Dummy.transform(node)

# Generated at 2022-06-23 22:30:55.569294
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:30:58.432628
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert test_BaseImportRewrite_visit_Import.get_tree() == [
        ast.Import(names=[
            ast.alias(name='os', asname=None)])
    ]



# Generated at 2022-06-23 22:31:10.169711
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import_node = ast.Import(names=[ast.alias(name='urllib.parse',
                                             asname='urlquote')])
    rewrote = ast.Try(body=[ast.Import(names=[ast.alias(name='urllib.parse',
                                                       asname='urlquote')])],
                      handlers=[ast.ExceptHandler(type=None,
                                                  name='',
                                                  body=[ast.Import(names=[ast.alias(name='urllib.quote',
                                                                                   asname='urlquote')])])],
                      orelse=[],
                      finalbody=[])
    rewriter = BaseImportRewrite(rewrites=[('urllib.parse', 'urllib.quote')])
    rewriter._tree_changed = False

# Generated at 2022-06-23 22:31:12.493681
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == {'transform'}


# Generated at 2022-06-23 22:31:19.982129
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Assert that `from a import test` will be replaced `from a1 import test`
    trans = BaseImportRewrite.__new__(BaseImportRewrite)
    trans.rewrites = [('a', 'a1')]
    res = trans.visit_ImportFrom(ast.parse('from a import test').body[0])
    assert(isinstance(res, ast.Try))
    assert(isinstance(res.body[0], ast.ImportFrom))
    assert(res.body[0].module == 'a1')

    # Assert that `from a import test` will be replaced `from a.a1 import test`
    trans = BaseImportRewrite.__new__(BaseImportRewrite)
    trans.rewrites = [('a', 'a.a1')]

# Generated at 2022-06-23 22:31:31.262927
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import compile_source
    from ..types import CompilationTarget
    from ..transformers import BaseImportRewrite
    from astropy import _erfa

    source = '''
import astropy._erfa
print(astropy._erfa.apcs)
'''

    class Transformer(BaseImportRewrite):
        target = CompilationTarget.PY35
        rewrites = [('astropy._erfa', 'erfa')]

    tree = compile_source(source, '<test_import_rewrite>', CompilationTarget.PY35)
    tree = Transformer.transform(tree).tree
    bytecode = compile(tree, '<test_ import_rewrite>', 'exec', flags=0o2)
    scope: dict = {}
    exec(bytecode, scope)

# Generated at 2022-06-23 22:31:31.872655
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:31:37.858436
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import ast_to_source

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse(ast_to_source(ast.Import(names=[ast.alias(name='foo')])))
    assert ast_to_source(tree) == "import foo"

    tree = ast.parse(ast_to_source(ast.Import(names=[ast.alias(name='foo')])))
    new_tree = ImportRewrite().visit(tree)
    assert ast_to_source(new_tree) == """
try:
    import foo
except ImportError:
    import bar as foo
""".lstrip()


# Generated at 2022-06-23 22:31:44.096989
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert isinstance(BaseTransformer, ABCMeta)
    assert isinstance(BaseTransformer.__abstractmethods__, frozenset)
    assert BaseTransformer.__abstractmethods__ == frozenset({'transform'})
    assert isinstance(BaseTransformer.transform, staticmethod)
    assert BaseTransformer.transform.__name__ == 'transform'
    assert BaseTransformer.transform.__doc__ == 'transform(cls, tree: ast.AST) -> TransformationResult'


# Generated at 2022-06-23 22:31:54.317870
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.compat import ast_parse_with_future_features
    from ..typing import Literal

    target = Literal['python2.7', 'python3.5']

    class TestTransformer(BaseImportRewrite):
        target = target
        rewrites = [('future', 'past')]


# Generated at 2022-06-23 22:31:57.193805
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(ast.parse('pass'))
    assert t._tree_changed == False
    assert t._tree.body == [ast.Pass()]
    # unit tested in test_ImportRewrite
    assert t.visit(None) == None



# Generated at 2022-06-23 22:32:01.374409
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1 + 2')

    class TestTransformer(BaseNodeTransformer):
        def visit_Num(self, node):
            return ast.Num(n=node.n * 2)

    res = TestTransformer.transform(tree)

    assert(res.result == ast.parse('1 + 4'))
    assert(res.changed == True)


# Generated at 2022-06-23 22:32:07.049533
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyClass(BaseNodeTransformer):
        def __init__(self, tree):
            self._tree_changed = True
            self._tree = tree
    node = ast.parse('import foo', '', 'exec')
    assert MyClass(node)._tree
    assert MyClass(node)._tree_changed
    assert not MyClass.transform(node).changed


# Generated at 2022-06-23 22:32:13.843299
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astor

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'baz')]

    class TestCase(unittest.TestCase):
        def test(self):
            tree = ast.parse('import foo')
            transformed = Test.transform(tree)
            self.assertEqual(astor.to_source(transformed.tree), 'try:\n    import foo\nexcept ImportError:\n    import baz')

    TestCase.test(None)


# Generated at 2022-06-23 22:32:19.662925
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite()
    assert hasattr(x, '_tree'), \
        "Varible '_tree' is required!"
    assert hasattr(x, '_tree_changed'), \
        "Varible '_tree_changed' is required!"
    assert hasattr(x, 'dependencies'), \
        "Varible 'dependencies' is required!"
    assert hasattr(x, 'rewrites'), \
        "Varible 'rewrites' is required!"



# Generated at 2022-06-23 22:32:26.950953
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import sys
    import os.path

    node = ast.parse('from paramiko.common import *')
    rewrites = [('paramiko.common', 'paramecio')]
    node_rewrite = BaseImportRewrite.visit_ImportFrom(node.body[0], rewrites)
    print(astor.to_source(node_rewrite))
    def match_names(names, expected):
        for name in expected:
            if name not in names:
                return False
        return True
    
    assert match_names([name.name for name in node_rewrite.body[0].body[0].body[0].body], ['io', 'py3compat'])

# Generated at 2022-06-23 22:32:33.363124
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from testfixtures import compare

    tree = ast.parse('import foo')
    class SomeTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    expected = ast.parse('try:\n    import bar\nexcept ImportError:\n    import foo')
    result = SomeTransformer.transform(tree).tree
    compare(expected, result)



# Generated at 2022-06-23 22:32:42.446238
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_node = ast.parse("from foo import bar, foo").body[0]
    import_from_node_2 =ast.parse("from foo import bar, foo").body[0]
    import_from_node_3 =ast.parse("from foo import bar, foo").body[0]
    import_from_node_4 =ast.parse("from foo import bar, foo").body[0]
    # Unit test for when no rewrite is applied
    test_transformer = BaseImportRewrite()
    assert isinstance(test_transformer.visit_ImportFrom(import_from_node), ast.ImportFrom)

    # Unit test for when module rewrite is applied
    test_transformer = BaseImportRewrite()
    test_transformer.rewrites = [("foo", "bar")]

# Generated at 2022-06-23 22:32:43.286202
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()

# Generated at 2022-06-23 22:32:45.385776
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert hasattr(BaseTransformer(), "transform")
test_BaseTransformer()


# Generated at 2022-06-23 22:32:49.388201
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    res = BaseNodeTransformer.transform(ast.parse("1+1"))

    assert res.tree.body[0].value.left.n == 1
    assert res.tree.body[0].value.right.n == 1
    assert res.tree_changed is False
    assert res.dependencies == []


# Generated at 2022-06-23 22:33:01.016438
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from enum import Enum

    class Test(Enum):
        I_WANT_TO_BE_FIRST = 'first'
        I_WANT_TO_BE_LAST = 'last'

    assert Test.I_WANT_TO_BE_FIRST.value == 'first'
    assert Test.I_WANT_TO_BE_LAST.value == 'last'

    def type_test(**kwargs):
        assert isinstance(kwargs['I_WANT_TO_BE_FIRST'], Enum)
        assert isinstance(kwargs['I_WANT_TO_BE_LAST'], Enum)
        assert isinstance(kwargs['I_WANT_TO_BE_FIRST'], Test)

# Generated at 2022-06-23 22:33:07.336580
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
    import foo
    """)

    class Rewrites(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert ast.dump(Rewrites.transform(tree).tree) == """
Module(body=[
    Try(body=[
        Import(names=[
            alias(name='bar', asname='foo')])
    ], handlers=[
        ExceptHandler(type=Name(id='ImportError', ctx=Load()), name=None, body=[
            Import(names=[
                alias(name='foo', asname='foo')])
        ])
    ], orelse=[], finalbody=[])
])
    """.strip()



# Generated at 2022-06-23 22:33:14.400298
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..interop.typed_ast import parse

    ast_module = parse('from lib.mod import mod, mod_alias\n')
    assert not astor.to_source(ast_module).split('\n')[-1]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('lib', 'lib2')]

    tree, changed, dependencies = TestImportRewrite.transform(ast_module)
    assert dependencies == ['lib2']
    assert changed
    assert astor.to_source(tree).split('\n')[-1]
    assert astor.to_source(tree) == '''
try:
    from lib.mod import mod, mod_alias
except ImportError:
    from lib2.mod import mod, mod_alias'''



# Generated at 2022-06-23 22:33:18.642501
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .test_utils import assertTransformer
    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    assertTransformer(MyTransformer, 'import foo', 'try:\n    import foo\nexcept ImportError:\n    import bar')

# Generated at 2022-06-23 22:33:26.405367
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ReplaceImport(BaseImportRewrite):
        rewrites = [
            ('re', 're'),
            ('requests', 'requests'),
            ('functools', 'functools')]
    import re, functools
    assert ast.dump(ReplaceImport().transform(ast.parse("import re")).tree) == "Try(body=[Import(names=[alias(name='re', asname=None)])], orelse=[], finalbody=[])"
    assert ast.dump(ReplaceImport().transform(ast.parse("import requests")).tree) == "Try(body=[Import(names=[alias(name='requests', asname=None)])], orelse=[], finalbody=[])"

# Generated at 2022-06-23 22:33:35.053754
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_node_1 = ast.Import(
        names=[ast.alias(
            name='requests',
            asname=None)])

    import_node_2 = ast.Import(
        names=[ast.alias(
            name='requests.utils',
            asname=None)])

    import_node_3 = ast.Import(
        names=[ast.alias(
            name='django.conf.settings',
            asname='settings')])

    import_node_4 = ast.Import(
        names=[ast.alias(
            name='django',
            asname='django')])

    rewrites = [
        ('requests', 'urllib3'),
        ('django', 'django_dep')
    ]


# Generated at 2022-06-23 22:33:38.302297
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        def f(self):
            pass
    a = A()
    assert_true(hasattr(a, 'f'))

# Generated at 2022-06-23 22:33:47.882464
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert BaseImportRewrite.visit_ImportFrom(
        ast.parse('from ty_utils import widgets').body[0],
        {}) == ast.Try(
        body=[ast.ImportFrom(module='ty_utils',
                             names=[ast.alias(name='widgets', asname=None)],
                             level=0)],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[ast.ImportFrom(module='ty_utils',
                                                         names=[ast.alias(name='widgets', asname=None)],
                                                         level=0)])],
        orelse=[],
        finalbody=[])

# Generated at 2022-06-23 22:33:56.005201
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                    '..',
                                                    '..')))
    from typedpy.type_transforms import BaseImportRewrite


    class MyBaseImportRewrite(BaseImportRewrite, ast.NodeTransformer):
        rewrites = [('a', 'b')]


    tree = ast.parse('''
    import a
    from a import b
    from a.b import c
    from a.b import d as e
    from a.b import f as g
    from a.b import *
    ''')

    MyBaseImportRewrite.transform(tree)


# Generated at 2022-06-23 22:34:05.273410
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..transformer import BaseImportRewrite
    from ..utils.snippet import snippet, extend

    import_rewrite = snippet(
        '''
        try:
            extend(previous)
        except ImportError:
            extend(current)
        ''')
    extend(import_rewrite)

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert astor.to_source(Test.transform(
        ast.parse('from foo import x')).tree) == \
        '''\
try:
    from foo import x
except ImportError:
    from bar import x'''



# Generated at 2022-06-23 22:34:13.968513
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import copy
    import unittest
    import pprint

    from ..utils.snippet import snippet
    class TestCase(unittest.TestCase):
        def assertAstUnchanged(self, tree):
            tree2 = copy.deepcopy(tree)

            node_transformer = BaseImportRewrite(tree2)
            node_transformer.visit(tree2)

            self.assertEqual(
                pprint.pformat(tree),
                pprint.pformat(tree2))

        def test_ImportFrom_no_rewrite(self):
            module = snippet.get_module('""')

            ast_module = module.get_ast()

            self.assertAstUnchanged(ast_module)


# Generated at 2022-06-23 22:34:22.639912
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from typed_ast.ast3 import parse

    rewrites = [
        ('previous.module.submodule.Foo',
         'current.module.submodule.Foo'),
        ('previous.module.submodule.Bar',
         'current.module.submodule.Bar'),
        ('previous.module.submodule.Baz',
         'current.module.submodule.Baz'),
    ]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites


# Generated at 2022-06-23 22:34:24.345650
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None


# Generated at 2022-06-23 22:34:32.411701
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer):
        def visit_Name(self, node):
            # This is a mutating visitor
            node.id = 'a'
            return node
    tree = ast.parse('x')
    assert ast.dump(tree, annotate_fields=True) == "Module(body=[Expr(value=Name(id='x', ctx=Load()))])"
    BaseNodeTransformer.transform(Transformer, tree)
    assert ast.dump(tree, annotate_fields=True) == "Module(body=[Expr(value=Name(id='a', ctx=Load()))])"

# Generated at 2022-06-23 22:34:43.317009
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    import ast as stdlib_ast

    sys.path.append("/home/chris/Desktop/GitHub/pythran3/pythran") # hack for testing

    from pythran.analyses.matches import NoMatch, Match
    import pythran.codegen

    # The input script
    script = """
        from something.other.module import a, b as c
    """

    # Compile the input script
    tree = stdlib_ast.parse(script)
    # print(stdlib_ast.dump(tree))
    nodes = NoMatch._analyze(tree)

    # replace "something" with "something.else" in node 0 (ImportFrom)
    nodes[0].update(tree)

    # print script
    print(pythran.codegen.unparse(tree))

   

# Generated at 2022-06-23 22:34:53.753639
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        rewrites = [('a', 'b')]
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)
        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            rewrite = self._get_matched_rewrite(node.names[0].name)
            return self.generic_visit(node)

# Generated at 2022-06-23 22:34:54.966421
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Testing BaseImportRewrite constructor."""
    BaseImportRewrite(ast.parse('pass'))

# Generated at 2022-06-23 22:34:55.871016
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:35:02.430918
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():  # unit test for constructor of class BaseNodeTransformer
    tree = ast.parse('')
    t = BaseNodeTransformer(tree)
    assert isinstance(t, BaseNodeTransformer)
    assert BaseNodeTransformer.transform(tree) == (tree, False, [])
    assert t._tree == tree
    assert t._tree_changed == False
    assert t.dependencies == []


# Generated at 2022-06-23 22:35:07.192512
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Subscript(self, node: ast.Subscript):
            return ast.Index(value=node.value)
    # Test for constructor
    node = ast.Subscript(value=ast.Name(id='a', ctx=ast.Load()))
    transformer = TestTransformer(node)
    assert transformer._tree is node
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:35:10.157241
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    with open('../tests/example.py') as src:
        test_tree = ast.parse(src.read())
        trans = BaseNodeTransformer(tree=test_tree)

    # type: ignore
    assert isinstance(trans._tree, ast.Module)
    assert isinstance(trans._tree_changed, bool)
    assert not trans._tree_changed
    assert not trans.dependencies
    assert trans.visit(test_tree) is test_tree


# Generated at 2022-06-23 22:35:11.693338
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(None)
    assert transformer._tree_changed is False, \
        '_tree_changed should be false by default'

# Generated at 2022-06-23 22:35:18.260418
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..examples.import_rewrite import TryRewriteImport
    tree = ast.parse('import foo.bar')
    assert TryRewriteImport.transform(tree) == TransformationResult(
        tree=ast.parse('try: import foo.bar\nexcept ImportError: from foo.rewrite import bar'),
        tree_changed=True,
        dependencies=[]
    )



# Generated at 2022-06-23 22:35:24.858431
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_1 = 'from_1'
    to_1 = 'to_1'
    from_2 = 'from_2'
    to_2 = 'to_2'

    class Rewriter(BaseImportRewrite):
        rewrites = [(from_1, to_1), (from_2, to_2)]

    import_1 = ast.Import(names=[
        ast.alias(name=from_1,
                  asname='FA1'),
        ast.alias(name=from_2,
                  asname='FA2'),
        ast.alias(name=from_2 + '.sub',
                  asname='FA22')
    ])

# Generated at 2022-06-23 22:35:28.216498
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from test.utils.python import build_ast
    tree = build_ast("x = 1")
    inst = BaseNodeTransformer(tree)
    assert inst._tree == tree
    assert inst._tree_changed == False

# Generated at 2022-06-23 22:35:38.640218
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transforms.urllib.request import UrllibRequestTransformer
    tree = ast.parse('import_from(module="a.b.c.urllib.request", names=[alias(name="urlopen", asname=None), alias(name="Request", asname="Request")])')
    t = UrllibRequestTransformer(tree)
    t.visit_ImportFrom(tree.body[0])

# Generated at 2022-06-23 22:35:47.341892
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import unittest

    class Test(unittest.TestCase):
        def test_1(self):
            import_from_node_before = ast.ImportFrom(
                module='foo.bar',
                names=[
                    ast.alias(
                        name='foo',
                        asname=None),
                    ast.alias(
                        name='bar',
                        asname=None),
                    ast.alias(
                        name='baz',
                        asname='baz1'),
                    ast.alias(
                        name='qaz',
                        asname=None)],
                level=0)

# Generated at 2022-06-23 22:35:52.754904
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore

    class Foo(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformed = Foo.transform(tree).tree
    assert astor.dump_tree(transformed) == """
try:
    import foo
except ImportError:
    import bar
"""

    tree = ast.parse('import foo.not_foo')
    transformed = Foo.transform(tree).tree
    assert astor.dump_tree(transformed) == """
try:
    import foo.not_foo
except ImportError:
    import bar.not_foo
"""



# Generated at 2022-06-23 22:36:02.779266
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("""
from test import data
from test.data import *
from test.data import other_data
from test.data import other_data as alias
from test.data import (
    other_data as alias,
    other_data,
)
from test import (
    from_test,
    from_test2,
)
""")  # noqa

    old_code = ast.parse("""
from urllib import request
from urllib.request import urlopen
from urllib.request import urlopen, request
from urllib.request import urlopen as alias
from urllib.request import (
    urlopen as alias,
    urlopen,
)
from urllib import (
    parse,
    error,
)
""")  # noqa


# Generated at 2022-06-23 22:36:10.269254
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..utils.docstring import DocstringTransformer
    from ..utils.annotations import AnnotationTransformer

    # Unit test for constructor of class BaseNodeTransformer
    assert BaseNodeTransformer.transform(ast.parse("1")) == TransformationResult(
        ast.parse("1"), False, [])

    # Unit test for constructor of class BaseImportRewrite
    assert BaseImportRewrite.transform(
        ast.parse("import foo")) == TransformationResult(ast.parse("import foo"), False, [])

# Generated at 2022-06-23 22:36:20.964487
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
   from pytest import raises
   from ast import AST, BinOp
   import astor

   class TestImportRewrite(BaseImportRewrite):
     def visit_TestClass(self, node):
       return node

   s = TestClass()
   tree = TestImportRewrite().visit(s)
   astor.to_source(tree)
   astor.to_source(s)
   assert astor.to_source(tree) == astor.to_source(s)
   assert TestImportRewrite().visit(None) == None

   class TestImportRewrite(BaseImportRewrite):
     def visit_TestClass(self, node):
       return TestImportRewrite().visit(node.parent)

   s = TestClass()
   tree = TestImportRewrite().visit(s)


# Generated at 2022-06-23 22:36:22.668482
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        pass


# Generated at 2022-06-23 22:36:29.270673
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

    tree = ast.parse('import x')
    transformer = Transformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed is False
    assert transformer.visit(tree) is None
    assert transformer._tree_changed is False

