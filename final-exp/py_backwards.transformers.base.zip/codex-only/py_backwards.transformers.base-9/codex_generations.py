

# Generated at 2022-06-23 22:26:32.917693
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from typed_ast import ast3 as ast
    import inspect
    import pytest
    import sys


# Generated at 2022-06-23 22:26:33.525795
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass

# Generated at 2022-06-23 22:26:42.292630
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import run_transformer
    from . import testutils
    from ..utils import to_source_code

    class TestImportRewrite(BaseImportRewrite):
        src = 'import re'
        rewrites = [('re', 'regex')]

    class TestImportRewriteSubmodule(TestImportRewrite):
        src = 'import re.match'

    class TestImportRewriteNoSubmodule(TestImportRewrite):
        src = 'import re.no_such_module'

    class TestImportRewriteDontRewrite(TestImportRewrite):
        src = 'import re.match'
        rewrites = [('regex', 'regex')]

    class TestImportRewriteMultiple(TestImportRewrite):
        src = 'import re, itertools'

# Generated at 2022-06-23 22:26:43.367386
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.parse("pass"))

# Generated at 2022-06-23 22:26:44.497486
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None

# Generated at 2022-06-23 22:26:45.748820
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite
    

# Generated at 2022-06-23 22:26:57.039312
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    expected = [ast.Try(body=[ast.Import(names=[ast.alias(name='some.module', asname='module')])],
                        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                                    name=None,
                                                    body=[ast.Import(names=[ast.alias(name='new.module',
                                                                                     asname='module')])])],
                        orelse=[],
                        finalbody=[])]

    class _Test(BaseImportRewrite):
        rewrites = [('some.module', 'new.module')]

    actual = _Test.transform(
        ast.parse('import some.module as module')).tree


# Generated at 2022-06-23 22:27:04.434036
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Unit(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six.moves.tkinter'),
            ('turtle', 'turtle.TurtleScreen'),
            ('tkinter', 'tkinter.Tk')
        ]

    tree = ast.parse(
        '''
        import turtle
        
        from six.moves import tkinter
        
        from tkinter import *
        ''')
    node = ast.parse(
        '''
        import turtle.TurtleScreen
        
        from six.moves.tkinter import tkinter
        
        from tkinter.Tk import Tk
        ''')

    Unit.transform(tree)
    assert ast.dump(tree) == ast.dump(node)

# Generated at 2022-06-23 22:27:05.764134
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == 'none'



# Generated at 2022-06-23 22:27:08.647257
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyClass(BaseNodeTransformer):
        pass
    tree = ast.dump(ast.parse(''))
    assert MyClass(ast.parse(''))._tree == ast.parse('')


# Unit tests for BaseImportRewrite

# Generated at 2022-06-23 22:27:10.485939
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    x = BaseTransformer(CompilationTarget.PYTHON38)
    assert x.target == CompilationTarget.PYTHON38


# Generated at 2022-06-23 22:27:20.642127
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('abc.def', 'abc_def'),
            ('abc.deff.ghi', 'abc_def_ghi'),
        ]


# Generated at 2022-06-23 22:27:29.834964
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast; from ast import ImportFrom, alias, parse, dump; from typed_ast import ast3 as typed_ast
    from typed_ast.transforms import BaseImportRewrite as Base

    class Test(Base):
        rewrites = [('one_module', 'another_module')]

    node = ImportFrom(module='one_module',
                      names=[alias(name='one_function',
                                   asname=''),
                             alias(name='another_function',
                                   asname='')],
                      level=0)

    t = Test()
    result = t.visit(node)

    assert isinstance(result, typed_ast.Try)
    assert dump(result) == "try:\n    import another_module\nexcept ImportError:\n    import one_module"


# Generated at 2022-06-23 22:27:36.110126
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import textwrap
    expected_code = textwrap.dedent("""
    try:
        from decimal import Decimal as _Decimal
    except ImportError:
        from decimal import Decimal as _Decimal
        
    _Decimal
    """)

    code = textwrap.dedent("""
    from decimal import Decimal
    
    Decimal
    """)

    tree = ast.parse(code)
    BaseImportRewrite(tree).visit(tree)
    assert ast.dump(tree) == expected_code



# Generated at 2022-06-23 22:27:36.596216
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:27:38.378059
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        target = CompilationTarget.PYTHON_LEGACY
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass
    b = A()

# Generated at 2022-06-23 22:27:45.541255
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_test = ast.Import(names=[ast.alias(name='yaml')])
    transformer = BaseImportRewrite(None)
    transformer.rewrites = [
        ('yaml', 'ruamel.yaml')
    ]
    assert transformer.visit_Import(import_test) == import_rewrite.get_body(previous=import_test,  # type: ignore
                                                                           current=ast.Import(names=[ast.alias(name='ruamel.yaml')]))[0]


# Generated at 2022-06-23 22:27:46.270524
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:27:49.215430
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
        assert False, "BaseTransformer should be an abstract base class"
    except TypeError:
        pass

# Generated at 2022-06-23 22:27:59.321144
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Rewrite1(BaseImportRewrite):
        target = CompilationTarget.PYTHON_36
        rewrites = [
            ('old', 'new'),
        ]

    class Rewrite2(BaseImportRewrite):
        target = CompilationTarget.PYTHON_36
        rewrites = [
            ('old', 'new'),
            ('old.sub', 'new.sub'),
            ('old.other', 'new.other'),
        ]

    class Rewrite3(BaseImportRewrite):
        target = CompilationTarget.PYTHON_36
        rewrites = [
            ('old.sub', 'new.sub'),
        ]

    class Rewrite4(BaseImportRewrite):
        target = CompilationTarget.PYTHON_36

# Generated at 2022-06-23 22:28:10.629233
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import typing
    import random
    import sys
    import astor  # type: ignore
    from statik.code_generator.generator import generate_ast

    result = generate_ast(typing.Any)
    # Unit test for constructor of class BaseNodeTransformer
    cls = BaseNodeTransformer(result.tree)
    assert cls._tree == result.tree
    assert cls._tree_changed == False

    # Unit test for method _visit_Module
    def visit_Module(self, node):  # type: ignore
        self._tree_changed = True
        return node

    cls = BaseNodeTransformer(result.tree)
    code = "import sys\ndef foo():\n    pass\n"
    tree = ast.parse(code)

    cls.visit_Module = visit_Module.__

# Generated at 2022-06-23 22:28:12.689794
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget()

    # For typing
    x = BaseTransformer()
    assert x.target == None

    assert BaseTransformer.target == None

# Generated at 2022-06-23 22:28:15.915609
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class tester(BaseTransformer):
        target = 'js'
        def transform(self, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, True, [])

    test = tester()
    assert test.target == 'js'

# Generated at 2022-06-23 22:28:18.176080
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test = BaseNodeTransformer(ast.AST)
    assert test._tree_changed == False


# Generated at 2022-06-23 22:28:28.531204
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Simple case with single import without level
    node = ast.parse('''from foo import bar''').body[0]
    cls = type('TestRewrite', (BaseTransformer,), {
        'transform': lambda _: BaseTransformer.transform(_),
        'rewrites': [('foo', 'foo_rewritten')],
    })()
    rewrote = cls.visit(node)
    assert type(rewrote) is ast.Try
    assert len(rewrote.body) == 2
    assert type(rewrote.body[0]) is ast.ImportFrom
    assert rewrote.body[0].module == 'foo'
    assert rewrote.body[0].names[0].name == 'bar'
    assert type(rewrote.body[1]) is ast.ImportFrom
    assert rewrote.body[1].module

# Generated at 2022-06-23 22:28:35.511965
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from fluent.migrate.transforms._django import BaseImportRewrite
    from fluent.migrate import base
    import ast
    import types

    class T(base.BaseImportRewrite):
        rewrites = []

    t = T()
    # TODO
    assert(isinstance(t, object))
    assert(isinstance(t, ast.NodeTransformer))
    assert(isinstance(t, types.TypeType))


# Generated at 2022-06-23 22:28:43.184092
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import unittest
    from . import BaseImportRewrite
    from ..utils.snippet import snippet, extend

    @snippet
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('mod', 'new_mod')]

    class BaseImportRewriteTest(unittest.TestCase):
        def test_import(self):
            import ast
            import astor
            tree = ast.parse('import mod')
            tree = DummyTransformer.transform(tree)
            self.assertEqual(tree, import_rewrite.get_body(previous='import mod',
                                                           current='import new_mod'))

# Generated at 2022-06-23 22:28:43.988604
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None

# Generated at 2022-06-23 22:28:47.988507
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('six', 'six3')]
    tree = ast.parse("import six")
    tree = Transformer.transform(tree)
    assert tree.value == "try:\n    import six3\nexcept ImportError:\n    import six"


# Generated at 2022-06-23 22:28:50.125382
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():  # noqa
    '''
    base_import_rewrite.BaseImportRewrite.__init__()
    '''

# Generated at 2022-06-23 22:28:51.069062
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer(): pass  # type: ignore

# Generated at 2022-06-23 22:28:57.535443
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from astunparse import unparse

    class Bar(BaseImportRewrite):
        rewrites = [('foo', 'django.db')]
        dependencies = ['python-django']

    tree = ast.parse("import foo\nfrom foo import bar")
    result = Bar.transform(tree)

    assert result.changed
    assert unparse(result.tree) == "try:\n    import foo\nexcept ImportError:\n    import django.db as foo\ntry:\n    from foo import bar\nexcept ImportError:\n    from django.db import bar"



# Generated at 2022-06-23 22:28:59.543068
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        def visit_ImportFrom(self, node):
            pass
    tnt = TestNodeTransformer(1)
    assert tnt._tree is 1
    assert tnt.dependencies == []

# Generated at 2022-06-23 22:29:04.647260
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..utils.unittest import skip, skipIf

    from typed_ast import ast3 as ast
    from .test_utils import transform, Expect

    class Bar(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Foo(BaseImportRewrite):
        rewrites = [('foo.baz', 'foo')]

    class FooBaz(BaseImportRewrite):
        rewrites = [('foo.baz', 'foo.baz')]

    class Apple(BaseImportRewrite):
        rewrites = [('apple', 'orange.apple')]

    import_stmt = ast.Import(names=[ast.alias(name='foo.bar',
                                              asname='bar')])


# Generated at 2022-06-23 22:29:09.350781
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        target = CompilationTarget.SANDBOX

        @classmethod
        def transform(cls, tree):
            print('transforming')
            return (tree, False, [])

    dummy_transformer = DummyTransformer()
    assert dummy_transformer.target == CompilationTarget.SANDBOX

# Generated at 2022-06-23 22:29:13.921977
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('x = 1')
    class Test(BaseNodeTransformer):
        pass
    result = Test.transform(tree)
    assert result.tree is not tree
    assert result.tree.body[0].value.n == 2
    assert result.changed is True
    assert result.dependencies == []

# Generated at 2022-06-23 22:29:16.066722
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.rewrites == []
    assert BaseImportRewrite.dependencies == []

# Generated at 2022-06-23 22:29:27.795487
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_ = 'foo'
    to = 'bar'

    import_from = ast.ImportFrom(
        module=from_,
        names=[ast.alias(name='a', asname='a'),
               ast.alias(name='b', asname='c'),
               ast.alias(name='c', asname=None)],
        level=0)

    replaced = ast.ImportFrom(
        module=to,
        names=[ast.alias(name='a', asname='a'),
               ast.alias(name='b', asname='c'),
               ast.alias(name='c', asname=None)],
        level=0)


# Generated at 2022-06-23 22:29:28.944573
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None)

# Generated at 2022-06-23 22:29:39.014252
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('''from django.conf.urls import url
from django.contrib import auth, messages
import django.db, django.utils
from django.utils.html import escape

from django.contrib import messages as mes

if __name__ == '__main__':
    print('test')''')

    BaseImportRewrite.rewrites = [('django.contrib.auth', 'django2.contrib.auth')]

    result = BaseImportRewrite.transform(tree)

    assert result.changed
    assert result.dependencies == ['django2.contrib.auth']

# Generated at 2022-06-23 22:29:41.713713
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyNodeTransformer(BaseNodeTransformer):

        def visit_MyNode(self, node):
            # abc
            pass

    MyNodeTransformer()


# Generated at 2022-06-23 22:29:49.299976
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import CompilationTarget
    from ..transformer import BaseNodeTransformer
    from typed_ast import ast3 as ast

    class MyTransformer(BaseNodeTransformer):
        def __init__(self, tree: ast.AST):
            super().__init__(tree)


    class MyNodeTransformer(BaseNodeTransformer, ast.NodeTransformer):
        def __init__(self, tree: ast.AST):
            super().__init__(tree)

    MyTransformer(ast.Module(body=[]))
    MyNodeTransformer(ast.Module(body=[]))

# Generated at 2022-06-23 22:29:50.731848
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class T(BaseNodeTransformer):
        pass
    T(None)

# Generated at 2022-06-23 22:29:57.382619
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    import os
    import astor
    from test_transformer import get_tree
    from ...compiler import Compiler
    from ...manager import Manager
    from ...types import CompilationTarget

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('mock', 'unittest.mock')]

    class TestCompiler(Compiler):

        def _get_tree(self, source: str, path: str) -> ast.AST:
            return get_tree(source, path)

        def _get_manager(self, *args, **kwargs) -> Manager:
            return Manager(*args, **kwargs)

    comp = TestCompiler([TestBaseImportRewrite],
                        CompilationTarget.PYTHON27)


# Generated at 2022-06-23 22:30:08.053397
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import os
    import sys
    import pytest

    if sys.version_info >= (3, 6):
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data', 'rewrite_import_from.py'), 'r') as f:
            source = f.read()

        tree = ast.parse(source)

        class Test(BaseImportRewrite):
            rewrites = [('foo', 'bar')]
            dependencies = ['bar']

        Test.transform(tree)

        assert 'bar.baz' in source
        assert 'bar.fuz' in source
        assert 'bar.str' in source
        assert 'bar.int' in source
        assert 'bar.dict' in source

# Generated at 2022-06-23 22:30:17.913780
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast

    class Test(BaseImportRewrite):
        rewrites = [
            ('future', 'builtins'),
            ('asyncio', 'typing')
        ]

    node = ast.Import(names=[
        ast.alias(name='future', asname='fut')
    ])

    rewrote = Test.transform(node).tree
    assert isinstance(rewrote, ast.Import)
    assert rewrote.names[0].name == 'future'
    assert rewrote.names[0].asname == 'fut'

    node = ast.Import(names=[
        ast.alias(name='asyncio', asname='io')
    ])

    rewrote = Test.transform(node).tree
    assert isinstance(rewrote, ast.Try)

# Generated at 2022-06-23 22:30:28.505760
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.tests.assert_nodes_equal import assert_matched

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'six.moves')]

    # from os import *; from os.path import *; from os.path import join
    with Bundle() as bundle:
        bundle += 'from os import *'
        bundle += 'from os.path import *'
        bundle += 'from os.path import join'
        bundle += 'from os.path.splitext import splitext'


# Generated at 2022-06-23 22:30:38.204315
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from .base_import_rewrite import BaseImportRewrite

    tree = astor.parse("from datetime import timedelta, datetime, timezone")

    class FakeImportRewrite(BaseImportRewrite):
        rewrites = [("datetime", "mydatetime")]

    result = FakeImportRewrite.transform(tree)

    expected_tree = astor.parse("""
try:
    from datetime import timedelta, datetime, timezone
except ImportError:
    from mydatetime import timedelta, datetime, timezone
    """)

    assert astor.to_source(expected_tree.body[0]) == astor.to_source(result.tree.body[0])


# Generated at 2022-06-23 22:30:45.449046
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astor
    from collections import OrderedDict
    from ast_helper import compare_ast

    # Test case 1
    # both module and from name
    from pycparser import c_parser, c_ast, parse_file, c_generator
    import pycparser.c_ast
    module = 'example'
    import_text = 'from pycparser import c_parser, c_ast, parse_file, c_generator'
    import_from = ast.parse(import_text)
    rewrites = [('pycparser.c_parser', 'ast')]
    class TestRewriter(BaseImportRewrite):
        rewrites = rewrites
    ast_1 = TestRewriter.transform(import_from).tree

    import_from = ast.parse(import_text)
   

# Generated at 2022-06-23 22:30:48.676799
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite in BaseImportRewrite.__mro__
    assert BaseNodeTransformer in BaseImportRewrite.__mro__
    assert BaseTransformer in BaseImportRewrite.__mro__

# Generated at 2022-06-23 22:30:58.658318
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Arrange
    from ..utils.ast_extractor import extract
    source = '''
from .module import class1, class2
from .module.other import class3, class4

class1()
'''

    class Rewriter(BaseImportRewrite):
        rewrites = [('.', 'tests.support')]

    # Act
    result = extract(source, Rewriter.transform)

    # Assert

# Generated at 2022-06-23 22:31:10.386311
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..codegen import get_ast
    from ..transformer import BaseImportRewrite, TransformationResult
    from ..utils.mock.transformer import MockTransformer

    ast_tree = get_ast('def foo(): print(1)')

    class TestTransformer(BaseImportRewrite):
        rewrites = [('x', 'y')]

        def visit_Num(self, node: ast.Num) -> ast.AST:
            node.n += 1
            return node

    result = TestTransformer.transform(ast_tree)
    assert isinstance(result, TransformationResult)

    class TestTransformer2(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('bar', 'foo')]

    result = TestTransformer2.transform(ast_tree)
    assert isinstance(result, TransformationResult)
    

# Generated at 2022-06-23 22:31:21.353090
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('django', 'flask')]

    tree = ast.parse("""
    from django import urls as urls_django
    from rest_framework.routers import DefaultRouter
    from django import forms
    import django.forms
    from django.forms import ModelForm
    from django.forms.models import ModelForm
    import rest_framework
    import rest_framework.serializers
    from rest_framework.serializers import ModelSerializer, ListSerializer
    from rest_framework.serializers import HyperlinkedIdentityField
    from rest_framework import serializers
    from rest_framework.views import APIView
    import django.http""")


# Generated at 2022-06-23 22:31:25.062841
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.ast_util import dump
    from ..utils.parse_python_source import parse_python_source
    tree = parse_python_source("""print(1)""")
    inst = BaseNodeTransformer(tree)
    dump(inst._tree)

# Generated at 2022-06-23 22:31:29.283783
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformerTest(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self.dependencies = ['foo', 'bar']
            self._tree_changed = True

# Generated at 2022-06-23 22:31:38.729102
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    source = """\
    from django.conf.urls import url
    from django.views.generic import TemplateView
    
    from rest_framework.routers import DefaultRouter
    
    from . import views
    
    router = DefaultRouter()
    router.register(r'categories', views.CategoryViewSet)
    router.register(r'posts', views.PostViewSet)
    
    urlpatterns = [
        url(r'^', include(router.urls)),
        url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    ]
    """
    tree = ast.parse(source)
    transformer = BaseImportRewrite(tree)
    transformer.visit(tree)

# Generated at 2022-06-23 22:31:40.585966
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tr = BaseNodeTransformer(None)
    assert not tr.tree_changed


# Generated at 2022-06-23 22:31:49.415473
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # given:
    import astor
    tree = astor.parse_file("./tests/test_sources/base_import_rewrite.py")
    # and:
    class SomeBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('some_module', 'some.other_module'),
            ('other_module', 'yet.another_module')
        ]
    # when:
    result = SomeBaseImportRewrite.transform(tree).tree
    # then:

# Generated at 2022-06-23 22:31:57.783385
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ConcreteImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'future.standard_library.six'),
            ('trytond.exceptions', 'trytond.exceptions'),
            ('six.moves', 'future.standard_library.six.moves'),
        ]

    # Imports from valid modules but from name
    # which is not in rewrites
    input = """
        from flask import Flask

        from trytond.exceptions import UserError

        def foo():
            try:
                import six.moves
            except ImportError:
                pass

        class Bar:
            pass
    """
    tree = ast.parse(input)
    result = ConcreteImportRewrite.transform(tree)

# Generated at 2022-06-23 22:32:09.484766
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='six', names=[ast.alias(name='moves')], level=0)
    from_, to = BaseImportRewrite.rewrites[0]
    assert BaseImportRewrite._replace_import_from_module(
        node, from_, to) == ast.Try(
        body=[ast.ImportFrom(module='six', names=[ast.alias(name='moves')], level=0)],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id="ImportError", ctx=ast.Load()),
            name=None,
            body=[ast.ImportFrom(module='six', names=[ast.alias(name='moves')], level=0)])],
        orelse=[],
        finalbody=[])
    

# Generated at 2022-06-23 22:32:17.551086
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite = BaseImportRewrite()
    base_import_rewrite.rewrites = [('a', 'ab')]
    import_statement = ast.Import(names=[ast.alias(name='a',
                                                  asname='')])
    result = base_import_rewrite.visit_Import(import_statement)
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'ab'


# Generated at 2022-06-23 22:32:19.705179
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class A(BaseNodeTransformer):
        pass

    a = A()
    assert a._tree is None
    assert a._tree_changed is False

# Generated at 2022-06-23 22:32:26.939459
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import textwrap
    import ast as pyast
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 22:32:38.367708
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from unittest import mock
    from ..types import CompilationTarget, TransformationResult
    from ..utils.snippets import import_rewrite, extend
    import_rewrite_body = import_rewrite.get_body()
    tr = BaseImportRewrite()
    tr._get_matched_rewrite = mock.Mock(return_value=(None, None))
    tr._replace_import = mock.Mock()
    tr._replace_import_from_module = mock.Mock()
    tr._replace_import_from_names = mock.Mock()
    tr.generic_visit = mock.Mock()
    tr.visit_Import(None)
    tr._replace_import.assert_called_once()
    tr._get_matched_rewrite.reset_mock()
    tr._replace_import.reset_m

# Generated at 2022-06-23 22:32:40.444689
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformerTest(BaseTransformer):
        pass
    base = BaseTransformerTest()

    assert base is not None

# Generated at 2022-06-23 22:32:42.033718
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert not BaseNodeTransformer('').__init__


# Generated at 2022-06-23 22:32:52.293732
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_astunparse as astunparse
    import typing

    # Test rewritten import
    r = BaseImportRewrite([('typing', 'transcrypt.types')])
    result = astunparse.unparse(r.visit(ast.parse('import typing'))).strip()
    assert result == 'try:\n\timport typing\nexcept ImportError:\n\timport transcrypt.types'

    # Test import to rewrite
    r = BaseImportRewrite([('typing', 'transcrypt.types')])
    result = astunparse.unparse(r.visit(ast.parse('import pandas'))).strip()
    assert result == 'import pandas'

    # Test imported submodule
    r = BaseImportRewrite([('typing', 'transcrypt.types')])

# Generated at 2022-06-23 22:32:52.990518
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:33:03.822916
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import astor

    input_import_from1 = '  import sys\n  import unittest\n  import types\n  import os\n  import tempfile\n  import ctypes\n  from os import path\n  from os.path import basename\n  from unittest import TestCase\n  from unittest.mock import Mock\n  from unittest.mock import patch\n  from unittest.mock import mock_open\n  from unittest.mock import MagicMock\n  from unittest.mock import call\n  from unittest.mock import Mock\n  from unittest.mock import patch\n  from typing import Tuple\n  from ._compat import _range\n  from typing import Callable'

# Generated at 2022-06-23 22:33:04.578850
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        pass
    MyTransformer('test')

# Generated at 2022-06-23 22:33:10.622161
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import b3 as b3
    from .x86_64 import transform
    from .x86_64_transformers import BaseNodeTransformer
    from ..utils.testing import assert_ast_equal
    from ..types import CompilationTarget, TransformationResult

    with open('tests/simple_fact.b3', 'r') as f:
        code = f.read()
    tree = b3.parse(code)

    class TestTransformer(BaseNodeTransformer):
        target = CompilationTarget.X86_64

        def visit_FunctionDef(self, node):
            return ast.Expr(value=ast.NameConstant(value=True))

    tr = TestTransformer(tree)
    tr.visit(tree)


# Generated at 2022-06-23 22:33:13.858028
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    assert MyBaseImportRewrite.dependencies == ['typed_ast']

# Generated at 2022-06-23 22:33:21.088603
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse
    from typed_ast.ast3 import Import, ImportFrom

    class Dummy(BaseImportRewrite):
        rewrites = [('typing', 'typing-extensions')]
    
    tree = ast.parse('from typing import List')
    ast.fix_missing_locations(tree)
    result = Dummy.transform(tree)

    assert astunparse.unparse(result.tree).strip() == \
"""
try:
    from typing import List
except ImportError:
    from typing_extensions import List

"""
    assert result.changed is True

# Generated at 2022-06-23 22:33:23.284953
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():

    class TestTransformer(BaseImportRewrite):
        pass

    t = TestTransformer()
    assert t.rewrites == []



# Generated at 2022-06-23 22:33:23.802097
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
        pass

# Generated at 2022-06-23 22:33:26.803505
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.test_helper import assert_tree
    from .test_data import import_statements

    for code in import_statements:
        tree = ast.parse(code)
        BaseImportRewrite.transform(tree)  # no errors expected
        assert_tree(code, tree)  # tree should stay the same

# Generated at 2022-06-23 22:33:35.369995
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='foo', names=[ast.alias(name='bar', asname=None),
                                               ast.alias(name='baz', asname=None)],
                          level=0)
    class Test(BaseImportRewrite):
        rewrites = [('foo', 'foobar')]
    inst = Test(None)
    assert Test.transform(node).tree == inst._replace_import_from_module(node, 'foo', 'foobar')

    class Test(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.bar_new')]
    inst = Test(None)
    assert Test.transform(node).tree == inst._replace_import_from_names(node, {'foo.bar': ('foo.bar', 'foo.bar_new')})


# Generated at 2022-06-23 22:33:46.330879
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('foo', 'bar')]

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    source = """
    import foo
    from foo import foo as baz
    from foo import *
    from . import foo
    from . import foo as baz
    from . import *
    """


# Generated at 2022-06-23 22:33:48.242396
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast
    import typed_ast.ast3 as ast3
    ast3.BaseNodeTransformer(ast.NodeTransformer())

# Generated at 2022-06-23 22:33:51.288960
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer(): # type: () -> None
    assert hasattr(BaseNodeTransformer, '__init__')
    t = BaseNodeTransformer(ast.parse(''))

# Unit tests for constructor of class BaseImportRewrite

# Generated at 2022-06-23 22:34:01.076164
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import unittest


# Generated at 2022-06-23 22:34:10.963203
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        # import foo
        import_stmt_rewrite_expected = """\
try:
    import foo
except ImportError:
    import bar
"""
        # import foo.bar as something
        import_stmt_rewrite_long_expected = """\
try:
    import foo.bar as something
except ImportError:
    import bar.bar as something
"""
        # from foo import bar
        import_from_stmt_rewrite_expected = """\
try:
    from foo import bar
except ImportError:
        from bar import bar
"""
        # from foo import bar as something

# Generated at 2022-06-23 22:34:13.133498
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:34:22.268106
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('renamed_module', 'module'), ]

    t = ast.parse(
        """
from renamed_module.module import func_1, func_2
from renamed_module import func_3
from module import func_4, renamed_module
        """
    )

    ImportRewrite.transform(t)


# Generated at 2022-06-23 22:34:24.860355
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert hasattr(BaseImportRewrite, 'visit_Import')
    assert hasattr(BaseImportRewrite, 'visit_ImportFrom')


# Generated at 2022-06-23 22:34:26.673826
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        pass
    Test(ast.parse("pass"))

# Generated at 2022-06-23 22:34:29.232721
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError:
        pass
    else:
        assert False, "BaseTransformer constructor should be abstract."


# Generated at 2022-06-23 22:34:31.746398
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    def generator():
        yield 1
        yield 2
    b = BaseNodeTransformer(generator())
    assert b._tree_changed == False
    assert b._tree == generator()

# Generated at 2022-06-23 22:34:35.060804
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MockTransformer(BaseNodeTransformer):
        def visit(self, node):
            pass
    with pytest.raises(TypeError):
        MockTransformer.transform(None)



# Generated at 2022-06-23 22:34:45.686811
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.compat import TextIO
    from ..compiler import Compiler

    class TestTransformer(BaseImportRewrite):
        rewrites = [('email', 'smtplib')]

    class TestCompiler(Compiler):
        transformers = [TestTransformer]

    source = '''import email

from email.mime.text import MIMEText
from email import encoders
'''

    expected = '''try:
    import email
except ImportError:
    import smtplib as email

try:
    from email.mime.text import MIMEText
except ImportError:
    from smtplib.mime.text import MIMEText

try:
    from email import encoders
except ImportError:
    from smtplib import encoders
'''

   

# Generated at 2022-06-23 22:34:49.553170
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse('a = 1')
    transformer = TestTransformer(tree)
    assert transformer._tree_changed is False
    assert transformer._tree == tree

# Generated at 2022-06-23 22:34:54.053240
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import pytest
    from ..utils import ast_utils
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]
    with pytest.raises(TypeError):
        TestTransformer()
    TestTransformer(ast_utils.parse_ast(""))

# Generated at 2022-06-23 22:35:04.693018
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('os.path', 'pathlib')
        ]

        def __init__(self):
            super().__init__(None)

    import_os_path = ast.Import(names=[
        ast.alias(name='os.path',
                  asname='path')])


# Generated at 2022-06-23 22:35:12.177954
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..utils.typecheck import check_type
    import json
    import requests

    # CompilationTarget
    check_type("CompilationTarget()", CompilationTarget())
    check_type("CompilationTarget(target='py2', version='3')",
               CompilationTarget(target='py2', version='3'))

# Generated at 2022-06-23 22:35:22.529572
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import _ast

    class ImportReplace(BaseImportRewrite):
        rewrites = [('test.test', 'a.b.c')]

    tree = ast.parse('''\
from test import test
from test.test import a
from test.test import *
from test import *
from test.test.m import *
from test.test.m import c''')

# Generated at 2022-06-23 22:35:25.961337
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """Tests constructor of class BaseNodeTransformer."""
    import astor
    from ..tests.test_utils import get_ast_test_file

    class DummyTransformer(BaseNodeTransformer):
        def visit_Module(self, node):
            return node

    test_ast = astor.parsefile(get_ast_test_file('simple.py'))
    tree = DummyTransformer(test_ast)
    assert tree is not None

# Generated at 2022-06-23 22:35:27.330091
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(ast.Module())

# Generated at 2022-06-23 22:35:29.442837
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None, "BaseTransformer.target should be None"


# Generated at 2022-06-23 22:35:36.540222
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test_utils import assert_node_equal
    module = ast.parse("import requests")
    node = module.body[0]  # type: ast.Import
    rewrited = BaseImportRewrite._replace_import(BaseImportRewrite, node, "requests", "aiohttp") # type: ignore
    assert isinstance(rewrited, ast.Try)
    assert_node_equal(ast.parse("""try:
            import requests
        except ImportError:
            import aiohttp"""), rewrited)


# Generated at 2022-06-23 22:35:46.021264
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.testing import transform, assert_equal
    from . import typing

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('stdlib.io', 'io')]

    script = """
    import stdlib.io
    """
    expected = """
    try:
        import stdlib.io
    except ImportError:
        import io
    """

    assert_equal(transform(TestImportRewrite, script), expected)

    script = """
    from stdlib import io
    """
    expected = """
    try:
        from stdlib import io
    except ImportError:
        import io
    """

    assert_equal(transform(TestImportRewrite, script), expected)

    script = """
    import stdlib.io, stdlib.abc
    """

# Generated at 2022-06-23 22:35:49.076096
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from . import _unittest_transformer

    bt = BaseTransformer()  # type: ignore
    _unittest_transformer.check_abstract_class(bt)

# Generated at 2022-06-23 22:35:51.836320
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BaseImportRewriteMock(BaseImportRewrite):
        rewrites = []  # type: List[Tuple[str, str]]

    assert BaseImportRewriteMock.transform(None).changed is False

# Generated at 2022-06-23 22:35:59.582740
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    class BaseImportRewriteSubclass(BaseImportRewrite):
        rewrites = [('django.core.urlresolvers', 'django.urls')]

    node = ast.parse('import django.core.urlresolvers')
    expected = astunparse.unparse(ast.parse(
        '''try:
               import django.core.urlresolvers
           except ImportError:
               import django.urls'''))

    assert BaseImportRewriteSubclass.transform(node).tree_code == expected


# Generated at 2022-06-23 22:36:02.917340
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON
    instance = TestTransformer()
    assert TestTransformer.target == CompilationTarget.PYTHON
    assert isinstance(instance, BaseTransformer)



# Generated at 2022-06-23 22:36:03.559282
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:36:13.990280
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import get_node
    from .visitor import inspect_visitor
    import astor

    node = get_node("import a")
    inst = BaseImportRewrite('<tree>')
    result = inst.visit(node)
    assert result is None

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    node = get_node("import a")
    inst = TestImportRewrite('<tree>')
    result = inst.visit(node)
    assert result is not None
    assert astor.to_source(result).strip() == 'try:\n    import a\nexcept ImportError:\n    import b'



# Generated at 2022-06-23 22:36:20.448803
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import logging 
    class Test(BaseImportRewrite):
        rewrites = [("math", "blah")]
    logging.info("test_BaseImportRewrite_visit_ImportFrom")
    _test_code = """\
from math import sin, cos
"""
    _expected_code = """\
try:
    from math import sin, cos
except ImportError:
    from blah import sin, cos
"""
    _tree = ast.parse(_test_code)
    Test.transform(_tree)
    assert ast.dump(_tree) == _expected_code

# Generated at 2022-06-23 22:36:25.248527
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    compilable_code = '' # type: str
    tree = ast.parse(compilable_code) # type: ast.AST
    transformer = BaseNodeTransformer(tree) # type: BaseNodeTransformer
    assert transformer._tree == tree
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:36:32.908919
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from .base import BaseTransformer
    import ast, six
    import typing
    if typing.TYPE_CHECKING:
        from ..types import CompilationTarget
    class MyTransformer(BaseNodeTransformer):
        target = CompilationTarget.PYTHON_3_6
        rewrites = [('foo', 'bar')]
        def visit_Import(self, node):
            return node

    transformer = MyTransformer(ast.parse('import foo'))
    transformer.visit_Import(ast.parse('import foo').body[0])
    if six.PY2:
        if not isinstance(transformer.visit_Import(ast.parse('import foo').body[0]), ast.Try):
            raise AssertionError