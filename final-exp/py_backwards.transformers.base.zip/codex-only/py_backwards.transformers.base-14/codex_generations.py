

# Generated at 2022-06-23 22:26:31.650135
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:26:41.246188
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyTransformer(BaseImportRewrite):
        rewrites = [('base64', 'base64')]

    tree = ast.parse("""
        import base64
        from base64 import b64encode
        from base64 import b64encode as b64
        from base64 import b64decode as b64enc

        from base64 import *
        """)

    result = MyTransformer.transform(tree)


# Generated at 2022-06-23 22:26:42.973703
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.AST(body=[]))



# Generated at 2022-06-23 22:26:49.650888
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__
    assert BaseTransformer.__bases__
    assert BaseTransformer.__doc__
    assert BaseTransformer.__init__
    assert BaseTransformer.__module__
    assert BaseTransformer.__mro__
    assert BaseTransformer.__name__
    assert BaseTransformer.__qualname__
    assert BaseTransformer.__subclasshook__
    assert BaseTransformer.__text_signature__

# Generated at 2022-06-23 22:26:51.006660
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(None)

# Generated at 2022-06-23 22:26:55.412432
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast

    class TestTransformer(BaseNodeTransformer):

        def __init__(self, tree):
            super().__init__(tree)

    tree = ast.parse("a = 1")
    TestTransformer(tree)
    assert True



# Generated at 2022-06-23 22:26:56.504525
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None)  # type: ignore

# Generated at 2022-06-23 22:27:03.874756
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class import_rewrite_transformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')]

    import_correct = ast.Import(names=[
        ast.alias(name='foo')])  # type: ignore
    import_rewrite_transformer.transform(import_correct)
    assert import_correct.names[0].name == 'foo'

    import_wrong = ast.Import(names=[
        ast.alias(name='foo')])  # type: ignore
    try_node = import_rewrite_transformer.transform(import_wrong)
    assert try_node.body[0].names[0].name == 'bar'
    assert try_node.body[1].names[0].name == 'foo'


# Generated at 2022-06-23 22:27:07.130707
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class DummyTransformer(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

    test_tree = ast.parse('x')
    transformer = DummyTransformer(test_tree)
    transformer.visit(test_tree)
    assert transformer._tree_changed is False
    assert transformer._tree == test_tree

# Generated at 2022-06-23 22:27:13.401646
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import mymodule  # NOQA
    import mymodule as mymodule1

    rewrites = [
        ('mymodule', 'mymodule10')
    ]

    class transformer(BaseImportRewrite):
        rewrites = rewrites

    code = '''
        import mymodule
        import mymodule as mymodule1
    '''
    tree = ast.parse(code)
    transformer.transform(tree)
    assert 'from mymodule import mymodule' not in astunparse.unparse(tree)
    assert 'from mymodule10 import mymodule10' in astunparse.unparse(tree)

    code = '''
        import mymodule
    '''
    tree = ast.parse(code)
    transformer.transform(tree)

# Generated at 2022-06-23 22:27:15.337204
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class FakeTransformer(BaseTransformer):
        pass

    transformer = FakeTransformer()
    assert transformer.target is None

# Generated at 2022-06-23 22:27:24.044445
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import textwrap
    class Foo(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        dependencies = []
    source = textwrap.dedent('''
    from foo import X, Y, Z
    from foo import A
    from foo import B
    from foo import C
    ''')
    # For functions with assert_equal
    expected = textwrap.dedent('''
    try:
        from foo import X, Y, Z
        from foo import A
        from foo import B
        from foo import C
    except ImportError:
        from bar import X, Y, Z
        from bar import A
        from bar import B
        from bar import C
    ''')
    # For class generator and function with assert_equal

# Generated at 2022-06-23 22:27:31.457689
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    from ..transformer import BaseImportRewrite

    class DummyTransformer(BaseImportRewrite):
        target = CompilationTarget('py', '3.5.1')
        rewrites = [('urllib', 'urllib.request')]

    ast_node = ast.parse(
        """
import urllib
import urllib.request
""", mode='exec')

    result = DummyTransformer.transform(ast_node)
    compiled = compile(result.tree, '<ast>', mode='exec')
    exec(compiled)

# Generated at 2022-06-23 22:27:43.259513
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..target import Python36Target

    class TestImportRewrite(BaseImportRewrite):
        target = Python36Target
        rewrites = [('typing', 'backports.typing')]

    tree = ast.parse('from typing import Optional')
    result = TestImportRewrite.transform(tree)

    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    from typing import Optional\nexcept ImportError:\n    ' \
                                          'from backports.typing import Optional'

    tree = ast.parse('from typing import TypeVar')
    result = TestImportRewrite.transform(tree)

    assert result.changed
    assert astor.to_source(result.tree) == 'try:\n    from typing import TypeVar\nexcept ImportError:\n    '

# Generated at 2022-06-23 22:27:50.388672
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import six
    
    tree = compile(
        'import six.moves',
        mode='exec',
        filename=None,
        dont_inherit=True
    )
    expected = compile(
        """import six.moves

        try:
            import six.moves.urllib.parse
        except ImportError:
            import urllib.parse""",
        mode='exec',
        filename=None,
        dont_inherit=True
    )
    
    assert astor.to_source(expected) == astor.to_source(BaseImportRewrite.transform(tree.body[0]).tree)



# Generated at 2022-06-23 22:27:50.844497
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer()

# Generated at 2022-06-23 22:27:56.260975
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('b.old', 'b.new')]
    module = '''
from b.old import a
from b.old.foo import *
'''
    tree = ast.parse(module)
    origin_tree = copy.deepcopy(tree)
    TestTransformer.transform(tree)
    assert tree != origin_tree

# Generated at 2022-06-23 22:27:57.392320
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == CompilationTarget.any


# Generated at 2022-06-23 22:28:03.946364
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [
            ('abc', 'cba'),
            ('first.second', 'second.first'),
            ('last.first', 'first.last'),
        ]

    tree = ast.parse('from abc import c\n'
                     'from first.second import a, b, c\n'
                     'from last.first import d\n'
                     'from last.first.second import e\n')


# Generated at 2022-06-23 22:28:09.767063
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_one = ast.Import(names=[ast.alias(name='one')])
    import_two = ast.Import(names=[ast.alias(name='two')])
    assert BaseImportRewrite(None)._replace_import(import_one, 'one', 'two') == \
        import_rewrite.get_body(previous=import_one,
                                current=import_two)[0]



# Generated at 2022-06-23 22:28:14.747256
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import six

    class DummyTransformer(BaseImportRewrite):
        rewrites = [
            ('six', 'sixsix')]

        def generic_visit(self, node):
            return node

    tree = ast.parse('import six')
    transformer = DummyTransformer(tree)
    result = transformer.visit_Import(tree.body[0])

    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'sixsix'
    assert result.body[0].names[0].asname == 'six'
    assert result.body[1].name == 'six'
    assert result.body[2].body[0].value.func.value.func.id == 'extend'

# Generated at 2022-06-23 22:28:15.316608
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:23.741611
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import assert_parses_to_ast
    from ..utils.fake_ast import AST  # type: ignore
    from ..utils.fake_node import Node  # type: ignore
    from ..utils.fake_ast import node_factory  # type: ignore

    cls = type('BaseImportRewriteSubclass', (BaseImportRewrite, ), {})

    class NodeWithChildren(Node):  # type: ignore
        children = []

    assert cls(AST())._get_matched_rewrite(None) == None
    assert cls(AST())._get_matched_rewrite('os.path') == None
    assert cls(AST())._get_matched_rewrite('wsgiref.util') == ('wsgiref', 'wsgiref2')


# Generated at 2022-06-23 22:28:24.500713
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:28:33.875283
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestRewrite(BaseImportRewrite):
        rewrites = [('futures', 'concurrent.futures')]

    # No changes expected
    tree = ast.parse('import os', '<test>', 'exec')
    changed, _ = TestRewrite.transform(tree)
    assert not changed
    assert ast.dump(tree) == ast.dump(ast.parse('import os', '<test>', 'exec'))

    # Import rewrite expected
    tree = ast.parse('import futures', '<test>', 'exec')
    changed, _ = TestRewrite.transform(tree)
    assert changed

# Generated at 2022-06-23 22:28:35.942717
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.random import random_ast
    tree = random_ast(3)
    transformer = BaseNodeTransformer(tree=tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:28:43.590358
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..compilers.base import BaseSphinxCompiler

    class MyImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [(('basic_redis', 'redis'), ('redis', 'aioredis'))]

    compiler = BaseSphinxCompiler()

    # simple import
    tree = ast.parse('from basic_redis import Redis, Pool')
    result = MyImportRewrite.transform(tree=tree)
    body = result.tree.body[0]
    assert isinstance(body, ast.Try)
    assert isinstance(body.body[0], ast.ImportFrom)
    assert isinstance(body.handlers[0].body[0], ast.ImportFrom)

# Generated at 2022-06-23 22:28:46.246659
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert_that(BaseTransformer.transform(None)).is_equal_to(None)
    assert_that(BaseTransformer.target.name).is_equal_to("ALL")

# Generated at 2022-06-23 22:28:47.855802
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt == bt  # identity


# Generated at 2022-06-23 22:28:57.101014
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('''import sys
import abc
from abc import ABC
from abc import ABC, DEFGH
from abc import ABC as a
from abc import ABC, DEFGH as d
from a.b.c import A
from a.b.c import A as a
from a.b.c import A, B
from a.b.c import A as a, B as b
from a.b.c import *
''')

    class Test1(BaseImportRewrite):
        rewrites = [
            ('sys', 'os'),
            ('abc', 'xyz')]

    class Test2(BaseImportRewrite):
        rewrites = [
            ('abc.ABC', 'xyz.A')]


# Generated at 2022-06-23 22:29:00.277837
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = CompilationTarget.PYTHON_LEGACY
    assert Transformer.target == CompilationTarget.PYTHON_LEGACY
    


# Generated at 2022-06-23 22:29:01.395962
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError, message="Can't instantiate abstract class BaseTransformer with abstract methods transform"):
        BaseTransformer()


# Generated at 2022-06-23 22:29:02.479148
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass
    TestTransformer()



# Generated at 2022-06-23 22:29:06.740185
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class Transformer(BaseImportRewrite):
        rewrites = [('six', 'six_other')]

    tr = Transformer(ast.parse('import six'))
    tr.visit(tr._tree)
    assert astor.to_source(tr._tree).strip() == 'try:\n    import six\nexcept ImportError:\n    import six_other'



# Generated at 2022-06-23 22:29:13.710887
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [(from_, to) for from_, to in [('cPickle', 'pickle')]]

    for import_type in [ast.Import, ast.ImportFrom]:
        # if import is from standard library and has no from_ module
        assert TestImportRewrite.transform(
            ast.parse(import_type().to_source()).body[0]).changed is False

    from_ = 'cPickle'
    to = 'pickle'

    # if import is from standard library and has from_ module
    for import_type in [ast.Import, ast.ImportFrom]:
        if import_type is ast.Import:
            input_ = import_type(names=[ast.alias(name=from_)])

# Generated at 2022-06-23 22:29:15.850304
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BNT(BaseNodeTransformer):
        pass
    
    BNT(ast.AST())

# Generated at 2022-06-23 22:29:27.560693
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [('urllib.request', 'urllib2'), ('urllib.error', 'urllib2')]
    BaseImportRewrite._get_matched_rewrite = BaseImportRewrite._get_matched_rewrite
    BaseImportRewrite.get_replaced_import_from_part = BaseImportRewrite._get_replaced_import_from_part
    BaseImportRewrite._replace_import = BaseImportRewrite._replace_import
    BaseImportRewrite.generic_visit = BaseImportRewrite.generic_visit
    BaseImportRewrite.__init__ = BaseImportRewrite.__init__
    BaseImportRewrite.visit_Import = BaseImportRewrite.visit_Import
    BaseImportRewrite._get_names_to_replace = BaseImportRewrite._get_names_

# Generated at 2022-06-23 22:29:28.118747
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(1)

# Generated at 2022-06-23 22:29:29.749321
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)

# Generated at 2022-06-23 22:29:38.490820
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
        import foo.baz
        from foo.baz import *
        ''', 'test-file.py')

    expected = ast.parse('''
        try:
            import foo.baz
        except ImportError:
            import bar.baz
        try:
            import foo.baz
            import foo.baz
        except ImportError:
            import bar.baz
            import bar.baz
        ''', 'test-file.py')
    assert TestImportRewrite.transform(tree).tree == expected

# Generated at 2022-06-23 22:29:40.547853
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.parse('''
        def foo(bar):
            return bar
    '''))

# Generated at 2022-06-23 22:29:50.812026
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unit_tests.utils

    def assert_import_rewrite(tree: ast.AST, from_: str, to: str, **kwargs) -> None:  # pylint: disable=unused-argument
        import unit_tests.utils  # pylint: disable=unused-variable
        BaseImportRewrite.rewrites = [(from_, to)]
        BaseImportRewrite.transform(tree)

# Generated at 2022-06-23 22:30:00.052790
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class SimpleImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('curl', 'requests'),
        ]

    tree = ast.parse(
        'import foo\n'
        'from foo.bar import baz\n'
        'from foo import bar, baz\n'
        'from foo.faz import bar, baz\n'
        'import curl.http.post'
    )
    result = SimpleImportRewrite.transform(tree)
    code = compile(result.tree, '', mode='exec')

    import_error = None
    try:
        exec(code)
    except ImportError as e:
        import_error = str(e)

    assert isinstance(result, TransformationResult)
    assert result.tree_changed

# Generated at 2022-06-23 22:30:03.950671
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, BaseTransformer)
    assert BaseTransformer.__subclasses__() == []
    assert BaseTransformer.target is None
    assert BaseTransformer.transform(None) is None
    assert BaseTransformer.transform(ast.parse("pass")) is None


# Generated at 2022-06-23 22:30:08.109943
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = CompilationTarget.PYPY
        def transform(cls, tree):
            pass
    assert Transformer.target == CompilationTarget.PYPY
    assert Transformer.transform(None)


# Generated at 2022-06-23 22:30:18.783758
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astor
    import astunparse

    class Test(unittest.TestCase):

        def test1(self):
            class TestRewrite(BaseImportRewrite):
                rewrites = [
                    ('io', 'io_pyext')
                ]

            tree = ast.parse('''import io as io_alias''')
            result = TestRewrite.transform(tree)
            self.assertEqual(astor.to_source(result.tree),
                             astunparse.unparse('''try:
    extend(io_alias)
except ImportError:
    extend(io_pyext as io_alias)'''))
            
            tree = ast.parse('''import io.__init__ as init''')
            result = TestRewrite.transform(tree)

# Generated at 2022-06-23 22:30:19.365333
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer()

# Generated at 2022-06-23 22:30:22.999848
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Dummy(BaseNodeTransformer):
        def visit_Import(self, node):
            return self.generic_visit(node)

    with pytest.raises(AssertionError):
        Dummy(None)._tree_changed = True

# Generated at 2022-06-23 22:30:28.989763
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    """
    >>> from typed_ast.ast3 import parse
    >>> from py2py3 import utils
    >>> from py2py3.transformers.base import BaseTransformer
    >>> from py2py3.compat import CompilationTarget
    >>> source = "1"
    >>> tree = parse(source)
    >>> class MyTransformer(BaseTransformer):
    ...     target = CompilationTarget.PY2
    ...     @classmethod
    ...     def transform(cls, tree):
    ...         return 
    ... 
    >>> result = MyTransformer.transform(tree)
    >>> utils.dump_tree(result.tree)
    Module(body=[Expr(value=Num(n=1))])
    """


# Generated at 2022-06-23 22:30:30.946560
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class a(BaseTransformer):
        pass
    try:
        a()
    except TypeError:
        print("Error caught")


# Generated at 2022-06-23 22:30:41.924580
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        rewrites = [
            ('tests.utils.snippet', 'snippet')
        ]

    class TestTwo(Test):
        pass

    assert Test.rewrites == TestTwo.rewrites

    import_rewrite = Test.transform(ast.parse('import tests.utils.snippet as snippet'))
    assert import_rewrite.tree_changed
    assert import_rewrite.dependencies == ['snippet']

    import_from_rewrite = Test.transform(ast.parse('from tests.utils.snippet import snippet'))
    assert import_from_rewrite.tree_changed
    assert import_from_rewrite.dependencies == ['snippet']


# Generated at 2022-06-23 22:30:53.442744
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astor
    from typing import Any

    class BaseImportRewrite(object):
        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

            rewrites = [('itertools', '__builtin__'), ('dis', 'six.moves')]

            for from_, to in rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None


# Generated at 2022-06-23 22:30:58.202974
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Test "type" of "target" attribute
    assert hasattr(BaseTransformer, 'target')
    assert BaseTransformer.target is None
    assert type(BaseTransformer.target) == CompilationTarget
    # Test if "transform" method is abstract
    assert getattr(BaseTransformer, 'transform').__isabstractmethod__ == True


# Generated at 2022-06-23 22:31:09.903219
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrites = [(
        'django.core.urlresolvers', 'django.urls',
    )]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    tree = ast.parse(
        '''
import django.core.urlresolvers
import django.core.urlresolvers.resolve
from django.core.urlresolvers import resolve
from django.core.urlresolvers import resolve as resolve_url
from django.core.urlresolvers import *
'''
    )

    transformation = TestImportRewrite.transform(tree)
    ast.fix_missing_locations(tree)
    assert transformation.changed

# Generated at 2022-06-23 22:31:17.104014
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .. import compile_source
    from ..compiler import COMPILER_CLASSES
    from ..target import Python36Target

    target = Python36Target()
    for compiler_cls in COMPILER_CLASSES:
        if issubclass(compiler_cls, BaseImportRewrite) and compiler_cls.target == target:
            assert compile_source("import ssl", target=target) == COMPILER_CLASSES[0].transform("import ssl")

# Generated at 2022-06-23 22:31:27.974091
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transformer = BaseImportRewrite(None)
    transformer.rewrites = [['from this', 'to this'], ['from that', 'to that']]
    input_node = ast.ImportFrom(module='from', names=[ast.alias(name='that', asname='a')], level=0)
    output_node = transformer.visit(input_node)
    assert isinstance(output_node, ast.Try)
    assert isinstance(output_node.body[0], ast.ImportFrom)
    assert isinstance(output_node.body[1], ast.ImportFrom)
    assert isinstance(output_node.body[2], ast.ImportFrom)
    assert isinstance(output_node.handlers[0].type, ast.Name)
    assert output_node.handlers[0].type.id == 'ImportError'


# Generated at 2022-06-23 22:31:39.110059
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.test import assert_transform_result, assert_transform_tree, assert_transform_changed

    class Fixture(BaseImportRewrite):
        rewrites = [('foo', 'bar'),
                    ('baz.qux', 'qux')]

    # No change
    assert_transform_result(Fixture,
                            'import foo\n',
                            'import foo\n',
                            'import foo\n',
                            changed=False)

    # Rewrite
    assert_transform_result(Fixture,
                            'import foo\n',
                            'import bar\n',
                            'try:\n'
                            '    import foo\n'
                            'except ImportError:\n'
                            '    import bar\n',
                            changed=True)

    # Rewrite with dotted name

# Generated at 2022-06-23 22:31:48.734418
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class SubClass(BaseImportRewrite):
        rewrites = [('abc', 'def')]

    node = SubClass.visit_ImportFrom(ast.ImportFrom(
        module='abc',
        names=[ast.alias(name='a', asname=None)],
        level=0),
    )
    assert astor.to_source(node) == (
        'try:\n'
        '    from def import a\n'
        'except ImportError:\n'
        '    from abc import a\n'
    )
    node = SubClass.visit_ImportFrom(ast.ImportFrom(
        module='abc.xyz',
        names=[ast.alias(name='a', asname=None)],
        level=0),
    )
    assert astor.to_source

# Generated at 2022-06-23 22:31:51.895537
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        target = 'test'
        @classmethod
        def transform(cls, tree):
            return None
    a_obj = A()
    assert A.target == a_obj.target


# Generated at 2022-06-23 22:31:53.117919
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__


# Generated at 2022-06-23 22:32:00.518778
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .test_complex_types import BaseImportRewrite
    tree = ast.parse("from django.utils.http import urlquote, urlquote_plus, urlencode")
    result = BaseImportRewrite.transform(tree)
    import_tree = ast.parse(
        "try: \n"
        "    from django.utils.http import urlquote, urlquote_plus, urlencode\n"
        "except ImportError:\n"
        "    from django.utils.http import urlquote, urlquote_plus, urlencode\n"
    )
    assert ast.dump(result.tree) == ast.dump(import_tree)


# Generated at 2022-06-23 22:32:03.388997
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert(BaseTransformer.__init__.__doc__ == None)
    assert(BaseTransformer.transform.__doc__ == None)
    assert(BaseTransformer.target == None)

# Generated at 2022-06-23 22:32:05.911854
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert_equal(str(BaseTransformer.__init__), '<slot wrapper \'__init__\' of \'BaseTransformer\' objects>')



# Generated at 2022-06-23 22:32:15.869245
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class SomeTransformer(BaseImportRewrite):
        rewrites = [('foo.bar', 'bar.foo')]

    some_import = ast.Import(names=[
        ast.alias(name='foo.bar',
                  asname='bar')])

    some_import_rewrote = some_import

    result = SomeTransformer.transform(some_import)

    assert isinstance(result.tree, ast.Try)
    assert result.tree.body[0] == some_import_rewrote
    assert result.tree.body[1].type.id == 'ImportError'
    assert len(result.deps) == 1
    assert 'foo.bar' in result.deps


# Generated at 2022-06-23 22:32:25.861782
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module='os', 
                                 names=[ast.alias(name='stat', 
                                                  asname=None)], 
                                 level=0)
    replacement_module = ast.ImportFrom(module='nt', 
                                 names=[ast.alias(name='stat', 
                                                  asname=None)], 
                                 level=0)
    replacement_name = ast.ImportFrom(module='os', 
                                 names=[ast.alias(name='stat', 
                                                  asname='stat_nt')], 
                                 level=0)
    replacement_name2 = ast.ImportFrom(module='os', 
                                 names=[ast.alias(name='stat2', 
                                                  asname=None)], 
                                 level=0)

# Generated at 2022-06-23 22:32:29.582234
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    t = BaseImportRewrite()
    tree = ast.parse("""from Test.Test import A\n""")
    t.visit(tree)
    astor.dump_tree(tree)




# Generated at 2022-06-23 22:32:35.851154
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Num(self, node):
            return ast.Num(1)

    tree = ast.parse('1 + 2')
    assert TestTransformer.transform(tree).tree.body[0].value.left.n == 1
    assert TestTransformer.transform(tree).tree_changed
    assert TestTransformer.transform(tree).dependencies == []



# Generated at 2022-06-23 22:32:37.311590
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__name__ == 'BaseTransformer'


# Generated at 2022-06-23 22:32:48.916988
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    source = \
"""
from typing import List, Any
from typing import Tuple

from six import text_type

A = 1
B = 2
List[A]
List[B]
text_type
Any
Tuple
"""
    expected_source = \
"""
try:
    from typing import List, Any, Tuple
except ImportError:
    from typing import List, Any
    from typing import Tuple

try:
    from six import text_type
    A = 1
    B = 2
    List[A]
    List[B]
    text_type
    Any
    Tuple
except ImportError:
    A = 1
    B = 2
    List[A]
    List[B]
    Any
    Tuple
"""
    tree = ast.parse(source)

# Generated at 2022-06-23 22:33:00.328913
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast, traceback
    from python_minifier.transformations.base import BaseImportRewrite

# Generated at 2022-06-23 22:33:03.728800
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Should work
    class DummyTransformer(BaseTransformer):
        pass

    assert DummyTransformer.target is None
    with pytest.raises(NotImplementedError):
        DummyTransformer.transform(1)


# Generated at 2022-06-23 22:33:10.149386
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse('from six import Foo')
    result = BaseImportRewrite.transform(module)
    assert result.changed
    module_ast = ast.parse('from six import Foo\n'
                           'try:\n'
                           '    from future.utils import Foo\n'
                           'except ImportError:\n'
                           '    from past.utils import Foo\n')
    assert ast.dump(result.tree) == ast.dump(module_ast)

    module = ast.parse('from six import Foo')
    module.body[0].names[0].asname = 'f'
    result = BaseImportRewrite.transform(module)
    assert result.changed

# Generated at 2022-06-23 22:33:12.046270
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None



# Generated at 2022-06-23 22:33:12.694342
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:14.983578
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 22:33:22.864874
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('twisted.internet', 'twisted.internet.asyncio')]

    import_tree = ast.parse("from twisted.internet.protocol import Protocol, Factory\nfrom twisted.internet import reactor")
    expected = ast.parse("""try:
    from twisted.internet.protocol import Protocol, Factory
    from twisted.internet import reactor
except ImportError:
    from twisted.internet.asyncio.protocol import Protocol, Factory
    from twisted.internet.asyncio import reactor""")

    assert TestTransformer.transform(import_tree) == TransformationResult(expected, True, [])


# Generated at 2022-06-23 22:33:25.713639
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor

    class TestBaseNodeTransformer(BaseNodeTransformer):
        dependencies = [
            'a_dependency',
        ]

        def __init__(self, tree):
            super().__init__(tree)


# Generated at 2022-06-23 22:33:29.417483
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    tree = ast.parse("import old_module")
    result = RewriteTransformer.transform(tree)
    assert result.tree == ast.parse("try:\n    import old_module\nexcept ImportError:\n    import new_module")
    assert result.tree_changed is True
    assert result.dependencies == []


# Generated at 2022-06-23 22:33:32.403583
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():

    value = object()
    obj = BaseTransformer()
    assert isinstance(obj.target, CompilationTarget)
    assert obj.target is not None
    assert not hasattr(obj, 'transform')

# Generated at 2022-06-23 22:33:43.888723
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.source import source
    from ..transformer import _TransformerExecutor
    from ..ast_utils import dump_ast
    import unittest

    class A(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib')]

    class B(A):
        rewrites = [('os.path', 'pathlib')]

    class C(A):
        rewrites = [('os.path', 'pathlib'), ('os', 'os2')]

    class D(A):
        rewrites = [('os.path.join', 'os2.path2.join')]

    class E(A):
        rewrites = [('os.path.join', 'os2.path2.join')]


# Generated at 2022-06-23 22:33:45.649609
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.transform(1)
    assert not BaseImportRewrite.transform(ast.parse('import a')).changed
    assert BaseImportRewrite.transform(ast.parse('import a'))

# Generated at 2022-06-23 22:33:52.613915
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Test(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            self._tree_changed = True
            return ast.FunctionDef(name='new_name',
                                   args=node.args,
                                   body=node.body,
                                   decorator_list=node.decorator_list,
                                   returns=node.returns)

    code = 'def foo():\n    pass'
    tree = ast.parse(code)
    Test.transform(tree)
    assert tree.body[0].name == 'new_name'

# Generated at 2022-06-23 22:33:53.247961
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:34:02.839268
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from typed_ast import ast3 as ast
    
    class SomeNodeTransformer(BaseNodeTransformer):
        target = 'js'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)
    
    class MockTree():
        def __init__(self):
            self.body = []
        
        def visit(self, visitor):
            visitor.visit(self)
    
    mock_tree = MockTree()
    
    @snippet
    def x():
        pass
    
    x()
    
    str_tree = str(x.get_body()[0])

# Generated at 2022-06-23 22:34:04.161654
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert t.target == None


# Generated at 2022-06-23 22:34:06.551494
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(ast.parse('print("hello")'))
    assert not transformer._tree_changed
    assert transformer._tree == ast.parse('print("hello")')

# Generated at 2022-06-23 22:34:14.651207
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Impl(BaseImportRewrite, ast.NodeTransformer):
        rewrites = [
            ('test.test_base_transformer', 'test.test_base_transformers')
        ]

    tree = ast.parse('''
import test.test_base_transformer as test
from test.test_base_transformer import *
from test.test_base_transformer import test_BaseImportRewrite
from test.test_base_transformer import test_BaseImportRewrite
''')
    Impl.transform(tree)
    print(ast.dump(tree))


# Generated at 2022-06-23 22:34:19.539893
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class SomeTransformer(BaseTransformer):
        target = CompilationTarget.PY3
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    try:
        BaseTransformer()
    except TypeError:
        pass
    else:
        assert False, 'An abstract class BaseTransformer should not be instantiated'

# Generated at 2022-06-23 22:34:30.320413
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import run_to_ast

    src_import_module = """
    from x import y

    """
    src_import_name = """
    from x import y, z

    """
    src_import_name_as = """
    from x import y as my_y, z

    """
    src_import_name_as_star = """
    from x import y as my_y, *

    """

    class Rewrite(BaseImportRewrite):
        rewrites = [('x', 'y')]

    tree = run_to_ast(src_import_module, target=CompilationTarget.PY36)
    assert Rewrite.transform(tree).changed is True

# Generated at 2022-06-23 22:34:34.626068
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.testing import get_ast, get_visitor_output, get_visitor_output_node

    node_1 = get_ast('from chardet.universaldetector import UniversalDetector')
    node_2 = get_visitor_output_node(node_1, BaseImportRewrite)
    print(node_2)

    assert get_visitor_output(node_1, BaseImportRewrite) == get_visitor_output(node_2, BaseImportRewrite)



# Generated at 2022-06-23 22:34:39.998414
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        target = 'python-3.4'

        def visit_foo(self, node): pass
    
    tree = ast.parse('foo()')
    transformer = TestTransformer(tree)
    assert isinstance(transformer, TestTransformer)
    assert isinstance(transformer, ast.NodeTransformer)
    

# Generated at 2022-06-23 22:34:41.848391
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    x = TestTransformer(ast.parse('x'))
    assert x._tree_changed is False

# Generated at 2022-06-23 22:34:48.516928
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from .test_utils import compare_source
    from .base import BaseImportRewrite

    class T(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Rewrite(T):
        rewrites = T.rewrites + [('bar.baz', 'foo.baz')]

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._last_source = None

        def visit_ImportFrom(self, node: ast.ImportFrom):
            self._last_source = ast.dump(node)
            return super().visit_ImportFrom(node)


# Generated at 2022-06-23 22:34:54.220567
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Because BaseTransformer is an ABC, we need to handle the exception
    # raised when calling constructor.
    try:
        bt = BaseTransformer()
    except TypeError as e:
        print(e)
    except Exception as e:
        print(e)
    finally:
        # Here, we can continue the rest of the unit test.
        print("\nUnit test for constructor of class BaseTransformer is done.\n")

# Generated at 2022-06-23 22:34:56.671292
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer._tree_changed == False
    assert BaseNodeTransformer._tree == None
    assert BaseNodeTransformer.dependencies == []


# Generated at 2022-06-23 22:35:06.974950
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..compiler import Compiler

    class Foo(BaseImportRewrite):
        rewrites = [
            ('stdlib.six.moves.builtins', 'stdlib.six.moves.builtins'),
            ('stdlib', 'stdlib'),
            ('stdlib.six.moves', 'stdlib.six.moves'),
            ('stdlib.moves', 'stdlib.moves'),
            ('stdlib.six', 'stdlib.six'),
            ('stdlib.viewkeys', 'stdlib.six.viewkeys')]

    class FooCompiler(Compiler):
        transformers = [Foo]


# Generated at 2022-06-23 22:35:13.162838
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        rewrites = [
            ('subprocess', 'subprocess32'),
            ('os', 'os')]

    source = """
import subprocess
from os import path

subprocess.Popen('ls .', shell=True, stdout=subprocess.PIPE)
path.abspath('./')"""

    result = Test.transform(ast.parse(source))

    expected = """
try:
    import subprocess
except ImportError:
    import subprocess32 as subprocess
try:
    from os import path
except ImportError:
    from os import path"""

    assert result.tree_changed is True
    assert ast.dump(result.tree) == expected

# Generated at 2022-06-23 22:35:13.809234
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None)

# Generated at 2022-06-23 22:35:22.268310
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from . import FIXTURES_ROOT

    fixture_file = FIXTURES_ROOT / 'test_BaseImportRewrite_visit_Import.py'
    with open(fixture_file) as fp:
        fixture = astor.parse(fp.read())

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'baz')]

    result = TestImportRewrite.transform(fixture)
    assert result.changed

    assert astor.to_source(result.tree) == 'import baz as bar\n'



# Generated at 2022-06-23 22:35:22.761647
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:35:23.487220
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer is not None

# Generated at 2022-06-23 22:35:27.895913
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Unit test for constructor of class BaseImportRewrite."""

    # Create instance of class to call its constructor
    instance = BaseImportRewrite.__new__(BaseImportRewrite)

    # Check instance attributes after constructor call
    assert instance.rewrites == []

# Generated at 2022-06-23 22:35:28.824502
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(None)


# Generated at 2022-06-23 22:35:39.330766
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    # Test import with no alias
    noalias = ast.Import(names=[ast.alias(name='six', 
                                         asname=None)])
    noalias_expected = 'try:\n    import six\nexcept ImportError:\n    from django.utils import six'

    transformer = BaseImportRewrite.transform(noalias)
    assert transformer.has_changes()
    assert transformer.get_tree_unparsed() == noalias_expected 

    # Test import with alias
    with_alias = ast.Import(names=[ast.alias(name='six',
                                             asname='six_six')])
    with_alias_expected = 'try:\n    import six as six_six\nexcept ImportError:\n    from django.utils import six as six_six'

    transformer = BaseImport

# Generated at 2022-06-23 22:35:49.276028
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..target.ast import ASTCodegenTarget
    import ast

    class TestImportRewrite(BaseImportRewrite):
        target = ASTCodegenTarget
        rewrites = [('collections', 'collection')]

    tree = ast.parse('import collections')
    new_tree, _, _ = TestImportRewrite.transform(tree)

# Generated at 2022-06-23 22:35:50.937417
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    x = BaseTransformer()
    assert repr(x) == '<BaseTransformer>'


# Generated at 2022-06-23 22:36:01.494046
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..transforms.base import BaseImportRewrite
    from ..types import CompilationTarget

    class Transformer(BaseImportRewrite):
        rewrites = [('x', 'y'), ('y', 'z')]
        target = CompilationTarget.PY2
    
    def get_ast(module):
        return ast.parse('''
        from {module} import foo, bar as baz
        from {module} import *
        '''.format(module=module))


# Generated at 2022-06-23 22:36:13.317227
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    _import = ast.parse('import foo').body[0]
    _as_import = ast.parse('import foo as bar').body[0]
    _from_import = ast.parse('from a import b').body[0]
    _from_as_import = ast.parse('from a import b as c').body[0]
    _from_multi_import = ast.parse('from a import b, c').body[0]
    _from_multi_as_import = ast.parse('from a import b, c as d').body[0]
    _from_as_import_multi = ast.parse('from a import b as c, d').body[0]

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    transformed = ImportRewrite.transform(_import)
   

# Generated at 2022-06-23 22:36:14.818977
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  transformer = BaseTransformer()
  assert (BaseTransformer)


# Generated at 2022-06-23 22:36:17.713725
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("#!/usr/bin/env python3", "<stdin>", "exec")
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False


# Generated at 2022-06-23 22:36:28.872482
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_module_name = ""
    test_alias_name = ""
    class MockImportFrom(ast.ImportFrom):
        def __init__(self, module, names, level=0):
            super().__init__(module=module, names=names, level=level)
        def replace(self, module_name, alias_name):
            global test_module_name
            global test_alias_name
            test_module_name = module_name
            test_alias_name = alias_name
            return self

    test_rewrites = [("gevent.socket", "socket")]
    import_rewrite = BaseImportRewrite()
    import_rewrite.rewrites = test_rewrites

# Generated at 2022-06-23 22:36:38.754928
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compiler import Compiler

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('a', 'b'), ('c.d', 'c.e')]

    assert TestTransformer(None)._get_matched_rewrite('a') == ('a', 'b')
    assert TestTransformer(None)._get_matched_rewrite('a.c') == ('a', 'b')
    assert TestTransformer(None)._get_matched_rewrite('c.d') == ('c.d', 'c.e')
    assert TestTransformer(None)._get_matched_rewrite('c.d.e') == ('c.d', 'c.e')
    assert TestTransformer(None)._get_matched_rewrite('b') is None
    assert TestTransformer(None)._get_