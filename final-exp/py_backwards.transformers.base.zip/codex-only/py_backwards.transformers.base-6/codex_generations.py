

# Generated at 2022-06-23 22:26:34.416701
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import get_ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('warnings', 'typed_ast.backport.warnings')]

    tree = get_ast('from warnings import warn')
    transformer = TestTransformer(tree)
    transformer.visit(tree)

    try:
        from warnings import warn
    except ImportError:
        from typed_ast.backport.warnings import warn
    warn('test')



# Generated at 2022-06-23 22:26:42.670753
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    content = """
from c import a
from c import a as c
from c.a import b, d
from c.a import *
import c.a
"""
    tree = ast.parse(content)
    TestTransformer.transform(tree)

    expected = """
try:
    from c import a
except ImportError:
    from b import a

try:
    from c import a
except ImportError:
    from b import a

try:
    from c.a import b, d
except ImportError:
    from c.b import b, d

try:
    from c.a import *
except ImportError:
    from c.b import *

import c.a
"""

# Generated at 2022-06-23 22:26:54.423103
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('''
import old
import old.module as module
from old import Module as Module
from old.module import *
from old.module import obj
''')

# Generated at 2022-06-23 22:26:55.095406
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:27:03.477650
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseNodeTransformer):
        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            return None

    module = ast.parse('from datetime import datetime')
    transformed = ImportRewrite.transform(module)
    assert transformed.changed == False
    assert ast.dump(module) == ast.dump(transformed.tree)

    module = ast.parse('from datetime.datetim import datetime')
    transformed = ImportRewrite.transform(module)
    assert transformed.changed == False
    assert ast.dump(module) == ast.dump(transformed.tree)

    module = ast.parse('from datetime import datetime')
    transformed = ImportRewrite.transform(module)
    assert transformed.changed == False

# Generated at 2022-06-23 22:27:05.805514
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass
    assert TestTransformer.transfrom(None).tree is None

# Generated at 2022-06-23 22:27:12.346032
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformerTest(BaseTransformer):
        def __init__(self):
            pass

    class BaseNodeTransformerTest(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)

    class BaseImportRewriteTest(BaseImportRewrite):
        def __init__(self, tree):
            super().__init__(tree)
            
    try:
        BaseTransformerTest()
    except BaseException as e:
        print(e)
        assert False
    else:
        assert True

    try:
        BaseNodeTransformerTest('')
    except BaseException as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-23 22:27:22.066685
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..visitors import compile_tree

    tree = compile_tree('''
    import os
    
    from os import path
    
    from io.os import Path
    
    from io.os import path as p
    
    from io.os import *
    
    from io.os import *, path as p
    ''')

    BaseImportRewrite.rewrites = [
        ('os', 'os_path')
    ]

    BaseImportRewrite.transform(tree)


# Generated at 2022-06-23 22:27:24.839559
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import numpy as np")
    transformer = BaseNodeTransformer(tree)
    assert transformer.visit_Import(tree.body[0]) == ast.Import(names=[ast.alias(name="numpy", asname="np")])



# Generated at 2022-06-23 22:27:34.943380
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    tree = ast.parse('''
    import bs4
    ''')
    cls = type('TestClass', (BaseImportRewrite,), {
        'rewrites': [('bs4', 'beautifulsoup4')],
    })
    cls.transform(tree)
    assert astunparse.unparse(tree) == '''
try:
    import bs4
except ImportError:
    import beautifulsoup4
    '''

    tree = ast.parse('''
    import bs4
    import bs4.builder
    import bs4.dammit
    ''')
    cls = type('TestClass', (BaseImportRewrite,), {
        'rewrites': [('bs4', 'beautifulsoup4')],
    })
    cls.transform

# Generated at 2022-06-23 22:27:37.748861
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    dummy1 = BaseTransformer()
    assert dummy1.target == None
    dummy2 = BaseTransformer()
    assert dummy2.target == None


# Generated at 2022-06-23 22:27:48.387582
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..ast_transforms import BaseImportRewrite
    
    class RewriteA(BaseImportRewrite):
        rewrites = [('a', 'a2')]
    
    import_node = ast.parse('import a').body[0]
    try_node = RewriteA.transform(import_node).tree
    assert isinstance(try_node, ast.Try)
    assert len(try_node.body) == 2
    assert isinstance(try_node.body[0], ast.Import)
    assert try_node.body[0].names[0].name == 'a'
    assert isinstance(try_node.body[1], ast.Import)
    assert try_node.body[1].names[0].name == 'a2'
    assert len(try_node.handlers) == 1

# Generated at 2022-06-23 22:27:50.067202
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
   a = BaseNodeTransformer()
   assert(a) 


# Generated at 2022-06-23 22:27:51.815749
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None


# Generated at 2022-06-23 22:27:54.455061
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        class_ref = 1

    obj = TestImportRewrite(None)
    assert obj.class_ref == 1



# Generated at 2022-06-23 22:28:02.123956
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [
        ('foo1.bar', 'foo2.bar'),
        ('foo.bar', 'foo2.bar2'),
    ]

    import_from1 = ast.parse('from foo.bar import baz')
    import_from2 = ast.parse('from foo1 import *')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    assert rewrites == TestImportRewrite.rewrites
    assert TestImportRewrite.transform(import_from1).tree == ast.parse(
"""
try:
    from foo.bar import baz
except ImportError:
    from foo2.bar import baz
"""
    )

# Generated at 2022-06-23 22:28:12.897430
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock as mock
    from typing import Callable
    from ..utils.snippet import get_body

    class MockNodeTransformer(BaseImportRewrite):
        rewrites = [
            ('unittest.mock', 'mock')
        ]

        def __init__(self):
            super().__init__(None)
            self.generic_visit = mock.MagicMock(wraps=self.generic_visit)

    # When the name of import is the same as in the rewrite rule, it should be transformed
    node = ast.parse('import unittest.mock as m').body[0]
    trans = MockNodeTransformer()
    trans.visit_Import(node)
    expected_import = get_body('import mock as m')[0]
    expected_try = get

# Generated at 2022-06-23 22:28:15.087129
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None
    assert transformer.transform(None) == None


# Generated at 2022-06-23 22:28:18.716594
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse(u'print("Hello World")', 'test', 'exec')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:28:19.752927
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = None
    BaseNodeTransformer(tree)


# Generated at 2022-06-23 22:28:20.910675
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    _BaseImportRewrite = BaseImportRewrite()

# Generated at 2022-06-23 22:28:21.981167
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()

# Generated at 2022-06-23 22:28:33.501592
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..transforms. import_rewrites import Py2To3ImportRewrite


# Generated at 2022-06-23 22:28:40.836500
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import textwrap
    from ..utils.ast import ast_to_source

    snippet = textwrap.dedent("""
    import uuid
    import hashlib
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("v_name", help="A name of a variable.")
    parser.add_argument("v_length", help="A length of a variable.", type=int)
    args = parser.parse_args()

    hashlib.new("md5", uuid.uuid4().hex).hexdigest()[:args.v_length].upper()
    """)

    with open('snippet.py', 'w') as f:
        f.write(snippet)

    from ..utils.ast import source_to_ast

# Generated at 2022-06-23 22:28:46.798381
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransform(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            # pylint: disable=no-self-use
            node.id = 'test'
            return node

    assert TestTransform.__name__ == 'TestTransform'
    assert TestTransform.__module__ == '__main__'

    tree = ast.parse('hello')
    result = TestTransform.transform(tree)

    assert result.tree_changed
    assert not result.dependencies
    assert result.tree.body[0].value.id == 'test'



# Generated at 2022-06-23 22:28:48.957486
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    myobject = BaseTransformer()
    assert isinstance(myobject, BaseTransformer)
    assert myobject.name is not None


# Generated at 2022-06-23 22:28:57.777550
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    r = BaseImportRewrite()
    
    # Mocks
    class MockNode1(object):
        module = 'os.path'
        names = [
            ast.alias(name='abspath', asname='abspath')
        ]
        level = 0
    
    class MockNode2(object):
        module = 'os.path'
        names = [
            ast.alias(name='path', asname='path')
        ]
        level = 0
    
    # Test 1

# Generated at 2022-06-23 22:29:04.575375
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BTIR = BaseImportRewrite
    assert BTIR.transform(ast.parse('''
import xyz
from xyz import x,y

''')).tree == ast.parse('''
import xyz
from xyz import x,y

''')

    assert BTIR.transform(ast.parse('''
import xyz
''')).tree == ast.parse('''
import xyz
''')

    assert BTIR.transform(ast.parse('''
from xyz import x,y
''')).tree == ast.parse('''
from xyz import x,y
''')

# Generated at 2022-06-23 22:29:08.203266
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'target'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    obj = TestTransformer()
    assert obj.target == 'target'



# Generated at 2022-06-23 22:29:09.547569
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite('', [])

# Generated at 2022-06-23 22:29:16.241572
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyClass(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    node = ast.parse('import foo')
    new_node = MyClass.transform(node).new_tree
    assert new_node.body[0].body[0].body[0].value.func.id == 'extend'
    assert new_node.body[0].body[0].body[0].value.args[0].value.names == [ast.alias(name='bar', asname=None)]


# Generated at 2022-06-23 22:29:21.815575
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor

    class Example(BaseNodeTransformer):
        def __init__(self, tree: ast.AST):
            super().__init__(tree)

        def visit_Name(self, node: ast.Name) -> ast.Name:
            node.id += '_test'
            return node

    tree = ast.parse('a = 1')
    Example.transform(tree)
    assert astor.to_source(tree) == "a_test = 1"

# Generated at 2022-06-23 22:29:23.736465
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # was different class before
    assert type(BaseTransformer()) == BaseTransformer


# Generated at 2022-06-23 22:29:27.159522
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from ..utils.typecheck import assert_type
    
    transformer = BaseTransformer()
    assert_type(transformer.target, CompilationTarget)

# Generated at 2022-06-23 22:29:29.290809
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'test'

    assert TestTransformer().target == 'test'

# Generated at 2022-06-23 22:29:32.113755
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    a = BaseNodeTransformer(ast.fix_missing_locations(ast.parse('3')))
    assert a._tree_changed == False


# Generated at 2022-06-23 22:29:34.533532
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__.__code__.co_varnames == ('self', 'tree')
    assert BaseImportRewrite.__init__.__code__.co_argcount == 2
    

# Generated at 2022-06-23 22:29:41.606780
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    body = [
        ast.Import(names=[ast.alias(name='collections.abc',
                                    asname='abc')])
    ]
    rewrote_body = [
        ast.Try(
            body=[ast.Import(names=[ast.alias(name='collections.abc',
                                              asname='abc')])],
            handlers=[
                ast.ExceptHandler(
                    type=ast.Name(id='ImportError',
                                  ctx=ast.Load()),
                    name=None,
                    body=[
                        ast.Import(names=[ast.alias(name='_collections_abc',
                                                    asname='abc')])
                    ]
                )
            ],
            orelse=[],
            finalbody=[]
        )
    ]
    rewrote_tree = ast.Module

# Generated at 2022-06-23 22:29:43.815312
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    node = ast.Num(123)
    inst = BaseNodeTransformer(node)

    assert inst._tree_changed == False
    assert inst._tree == node

# Generated at 2022-06-23 22:29:53.949920
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import pandas
    from pandas import DataFrame

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('pandas', 'pandas_mod')]

    # Test replace
    node = ast.parse("import pandas").body[0]
    result = ast.parse("try:\n    import pandas\nexcept ImportError:\n    import pandas_mod").body[0]
    transformer = TestImportRewrite(ast.parse(''))
    assert transformer.visit_Import(node) == result

    # Test replace with as
    node = ast.parse("import pandas as pd").body[0]
    result = ast.parse("try:\n    import pandas as pd\nexcept ImportError:\n    import pandas_mod as pd").body[0]


# Generated at 2022-06-23 22:29:56.251011
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    transformer.target = CompilationTarget('3.3')
    assert isinstance(transformer.target, CompilationTarget)

# Generated at 2022-06-23 22:30:05.794906
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse('''
        import a
        import c
        import d.e
        import f.g
    ''')
    Test.transform(tree)

    expected = ast.parse('''
        try:
            import a
        except ImportError:
            import b
        import c
        try:
            import d.e
        except ImportError:
            import b.e
        try:
            import f.g
        except ImportError:
            import b.g
    ''')

    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 22:30:16.300855
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.testutils import compile as compile_
    from ..utils.testutils import get_module_tree

    class ImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [
            ('foo', 'mock'),
            ('bar', 'mybar')]

    def test_rewrite(from_, to, code):
        module_tree = get_module_tree(code)
        new_tree = ImportRewrite.transform(module_tree)
        new_code = astor.to_source(module_tree)
        new_module = compile_(new_code, 'TestModule')
        assert hasattr(new_module, to)
        assert getattr(new_module, to).__name__ == to


# Generated at 2022-06-23 22:30:20.904159
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite()
    assert x.__class__.__name__ == 'BaseImportRewrite'
    assert x._tree == None
    assert x._tree_changed == False
    assert x.rewrites == []
    assert x.dependencies == []


# Generated at 2022-06-23 22:30:22.698494
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(ast.parse("")).__class__ is BaseNodeTransformer


# Generated at 2022-06-23 22:30:29.192189
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class SampleImportRewrite(BaseImportRewrite):
        rewrites = []

    from_name = "my_module"
    to_name = "your_module"

    import_from = ast.ImportFrom(module="{}".format(from_name),
                                 names=[ast.alias(name="name1")])

    import_from_rewrite, changed = SampleImportRewrite.transform(import_from)
    assert changed

    assert isinstance(import_from_rewrite, ast.Try)
    assert len(import_from_rewrite.handlers) == 1
    assert isinstance(import_from_rewrite.handlers[0].type, ast.Name)
    assert import_from_rewrite.handlers[0].type.id == "ImportError"

# Generated at 2022-06-23 22:30:29.770956
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    a = BaseTransformer()
    assert a is not None

# Generated at 2022-06-23 22:30:37.207888
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from copy import copy
    from unittest.mock import patch
    from .test_utils import should_not_visit, assert_ast_equal

    class MockTransformer(BaseImportRewrite):
        rewrites = [('a.b', 'x.y')]

    @patch.object(MockTransformer, 'visit', return_value=should_not_visit)
    def run_test(node, expected, mock_visit):
        node = copy(node)
        result = MockTransformer.transform(node)
        mock_visit.assert_called_once()
        assert_ast_equal(result.tree, expected)
        assert result.changed

    # Should not change anything
    run_test(ast.parse('import math'),
             ast.parse('import math'))

    # Should rewrite import


# Generated at 2022-06-23 22:30:38.477777
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:30:45.562684
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import(): # noqa
    from ..utils.mock import mock_get_matched_rewrite

    def test(tree, expected_tree):
        assert (isinstance(expected_tree, type(tree)) and
                isinstance(tree, ast.Import) and
                isinstance(expected_tree, ast.Try))

        assert (len(tree.names) == 1 and
                len(expected_tree.body) == 1 and
                isinstance(tree.names[0], ast.alias) and
                isinstance(expected_tree.body[0], ast.TryExcept))

        assert (tree.names[0].name == 're' and
                str(expected_tree.body[0].body[0]) == 'import re' and
                str(expected_tree.body[0].body[1]) == 'import re as re')


# Generated at 2022-06-23 22:30:56.327149
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.snippet import parse
    from ..utils.testing import SourceTestCase
    from ..types import CompilationTarget
    
    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYTHON27
        rewrites = [('os.path', 'posixpath')]

    source = """
    import os.path as pth
    from os.path import join
    from os.path import *
    """
    expected = """
    try:
        import os.path as pth
    except ImportError:
        import posixpath as pth
    try:
        from os.path import join
    except ImportError:
        from posixpath import join
    try:
        from os.path import *
    except ImportError:
        from posixpath import *
    """
   

# Generated at 2022-06-23 22:30:58.718719
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.tests.fake_type import FakeType
    
    BaseImportRewrite.__init__(FakeType(), ast.parse(""))

# Generated at 2022-06-23 22:31:06.418640
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)

    test_tree = ast.parse('pass')

    class TestTransformer(BaseNodeTransformer):
        def visit_Pass(self, node: ast.Pass) -> None:
            self._tree_changed = True

    result = TestTransformer.transform(test_tree)
    assert result.tree != test_tree
    assert result.tree_changed



# Generated at 2022-06-23 22:31:15.559271
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.test import get_tree_from_text
    tree = get_tree_from_text("""
    import time_
    from time.clock import perf_counter
    """)

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('time', 'time_')]

    ImportRewrite.transform(tree)

    assert get_tree_from_text("""
    import time_
    try:
        from time.clock import perf_counter
    except ImportError:
        from time_.clock import perf_counter
    """).body == tree.body



# Generated at 2022-06-23 22:31:21.431104
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestedClass(BaseImportRewrite):
        rewrites = [('os', 'os')]

    import astor
    import_from_ast = ast.parse("from os import path, stat").body[0]
    result = TestedClass.transform(import_from_ast)
    expected_ast = ast.parse("try:\n    from os import path, stat\nexcept ImportError:\n    from os import path, stat").body[0].body[0]
    assert result.transformed
    assert astor.to_source(result.ast) == astor.to_source(expected_ast)



# Generated at 2022-06-23 22:31:25.788595
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("from asyncio import ensure_future")
    result = BaseImportRewrite.transform(tree)
    assert result.changed
    assert result.tree_to_code() == "try:\n    from asyncio import ensure_future\nexcept ImportError:\n    from asyncio import ensure_future"


# Generated at 2022-06-23 22:31:28.394707
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tr = BaseTransformer()
    assert tr.target == None
    assert tr.transform(None) == None


# Generated at 2022-06-23 22:31:29.794564
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class T(BaseNodeTransformer):
        pass
    T(None)

# Generated at 2022-06-23 22:31:40.717068
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    node = ast.Import(names=[ast.alias(name='test_module',
                                       asname=None)])
    tree = ast.Module(body=[node])
    target_ = CompilationTarget(python_version='3.0')
    rewrites = [('test_module', 'new_module')]

    class ImportRewrite(BaseImportRewrite):
        rewrites = rewrites
    BaseImportRewrite.target = target_

    transformation_result = ImportRewrite.transform(tree)

    try_ = transformation_result.tree.body[0]
    assert isinstance(try_, ast.Try)
    except_ = try_.body[0]
    assert isinstance(except_, ast.ExceptHandler)
    assert except_.type.id == 'ImportError'
    assert len(except_.body) == 1


# Generated at 2022-06-23 22:31:42.661320
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer()
    assert not hasattr(obj, 'target')
    assert not hasattr(obj, 'transform')


# Generated at 2022-06-23 22:31:48.838055
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        dependencies = ["dep1"]

        def visit_Call(self, node):
            return None

    tree = ast.parse("foo()")
    res = TestTransformer.transform(tree)
    assert isinstance(res, TransformationResult)
    assert res.target == tree
    assert res.changed is False
    assert res.dependencies == ["dep1"]

# Generated at 2022-06-23 22:31:49.493408
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:31:51.866711
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    @snippet
    def foo(arg1, arg2):
        pass
    t = BaseTransformer()
    f = foo.get_body()
    assert t.transform(f) == TransformationResult(f, False, [])



# Generated at 2022-06-23 22:31:59.322526
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            if node.id == 'a':
                self._tree_changed = True
                return ast.Name(id='b')
            else:
                return self.generic_visit(node)
                
    tree = ast.parse('a + a')
    TestTransformer.transform(tree)
    assert ast.dump(tree) == 'Module(body=[Expr(value=BinOp(left=Name(id=\'b\', ctx=Load()), op=Add(), \
right=Name(id=\'b\', ctx=Load())))])'

# Generated at 2022-06-23 22:32:06.898095
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            pass

    tree = ast.parse('class A: pass')
    res = TestTransformer.transform(tree)
    assert res == TransformationResult(tree, False, [])
    assert tree.body[0] == ast.ClassDef(name='A', 
                                        bases=[], 
                                        keywords=[], 
                                        body=[], 
                                        decorator_list=[])


# Generated at 2022-06-23 22:32:08.431620
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tree = ast.parse('print(42)')
    BaseTransformer.transform(tree)

# Generated at 2022-06-23 22:32:17.121778
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.test_utils import assert_tree

    class TestTransformer(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node.id = node.id + '_changed'
            self._tree_changed = True
            return self.generic_visit(node)
    tree = ast.parse('a')
    assert_tree(tree, '''
    Module(body=[
        Expr(value=Name(id='a', ctx=Load()))
    ])
    '''.strip())
    assert TestTransformer.transform(tree) == TransformationResult('a_changed', True, [])

# Generated at 2022-06-23 22:32:18.550161
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == frozenset({'transform'})

# Generated at 2022-06-23 22:32:28.334037
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import unittest

    from typed_ast import convert
    from ..utils.snippet import from_source_file
    from ..utils.testing import recreate_ast_nodes

    from .patterns import (
        get_name_exports_pattern,
        get_import_from_all_pattern,
        get_import_from_single_pattern,
    )

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('spam', 'eggs'),
        ]

        def _get_replaced_import_from_part(self, node, alias, names_to_replace):
            return super()._get_replaced_import_from_part(node, alias, names_to_replace)


# Generated at 2022-06-23 22:32:38.549989
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyRewriter(BaseImportRewrite):
        rewrites = [
            ('exceptions', 'builtins')
        ]

    tree = ast.parse('import exceptions')
    res = MyRewriter.transform(tree)
    assert ast.dump(tree) == ast.dump(res.tree)

    tree = ast.parse('import random')
    res = MyRewriter.transform(tree)
    assert ast.dump(tree) == ast.dump(res.tree)

    tree = ast.parse('import exceptions')
    res = MyRewriter.transform(tree)
    assert ast.dump(tree) == ast.dump(res.tree)



# Generated at 2022-06-23 22:32:39.407706
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    b = BaseTransformer()


# Generated at 2022-06-23 22:32:41.726778
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer.__init__.__defaults__ == (None,)



# Generated at 2022-06-23 22:32:52.081684
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from . import test_transformer
    import copy

    module = copy.deepcopy(test_transformer.module)

    stmt = module.body[2]
    assert isinstance(stmt, ast.ImportFrom)
    assert stmt.level == 0
    assert stmt.module == 'json'
    assert len(stmt.names) == 1
    assert stmt.names[0].name == 'dumps'
    assert stmt.names[0].asname is None

    class Rewriter(BaseImportRewrite):
        rewrites = [('json', 'simplejson')]

    new_module = Rewriter.transform(module).tree

    stmt = new_module.body[2]
    assert isinstance(stmt, ast.Try)
    assert len(stmt.body) == 1

# Generated at 2022-06-23 22:33:03.019604
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux'),
        ]

        def visit_Module(self, node: ast.Module) -> ast.Module:
            return self.generic_visit(node)

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            return super().visit_Import(node)

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    @snippet
    def test_rewrite(x):
        """Test rewrite that should be rewritten."""

    import test_rewrite as test_rewrite_old
    import test_rew

# Generated at 2022-06-23 22:33:03.637338
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:09.390770
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # given
    self = BaseImportRewrite()
    self.rewrites = [
        ('foo.bar', 'bar.baz'),
    ]

    # when
    actual = self.visit(ast.parse('import foo.bar'))

    # then
    expected = ast.parse("""
try:
    import foo.bar as bar
except ImportError:
    import bar.baz as bar
    """)
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 22:33:21.146595
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('''
import os
from abc import ABCMeta
from collections.abc import Iterable
from six.moves import range as xrange

from some_mod import *
from some_mod import foo as bar
from some_mod import f1
from some_mod import f2 as f3
from some_mod import f4, f5
from some_mod import f6, f7 as f8''')  # noqa
    cls = BaseImportRewrite
    cls.rewrites = [('os', 'six.moves.os'),
                    ('abc', 'six.moves.abc'),
                    ('collections.abc', 'six.moves.collections_abc')]
    cls.transform(tree)


# Generated at 2022-06-23 22:33:21.661584
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
  BaseImportRewrite()

# Generated at 2022-06-23 22:33:28.658121
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.typed_ast_helper import get_ast

    class MockImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    for code in ('from foo import a',
                 'from foo.b import a',
                 'from foo.b import c as d',
                 'from foo import *',
                 'from foo import a, c as d',
                 'from foo import a, c as d, *'):
        node = get_ast(code)
        assert isinstance(MockImportRewrite.transform(node).tree, ast.Try)

    for code in ('from foo import a as b',
                 'from foo.b import a as d'):
        node = get_ast(code)

# Generated at 2022-06-23 22:33:30.721485
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        pass
    assert TestTransformer.target is None

# Generated at 2022-06-23 22:33:35.170000
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)

    tree = ast.parse("test_str")
    transformer = TestTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False

# Generated at 2022-06-23 22:33:39.619081
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # Testing initialization of class BaseNodeTransformer
    tree = ast.parse("print('Hola')")
    test_obj = BaseNodeTransformer(tree)
    assert not test_obj._tree_changed
    assert isinstance(test_obj, ast.NodeTransformer)


# Generated at 2022-06-23 22:33:41.121753
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert 'BaseImportRewrite' in BaseImportRewrite.__name__

# Generated at 2022-06-23 22:33:42.475607
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    trans = BaseImportRewrite()
    assert trans.rewrites == []
    assert trans.dependencies == []


# Generated at 2022-06-23 22:33:48.391457
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import os
    import sys
    import unittest

    from typed_ast import ast3
    from typed_ast import codegen
    from typed_ast.transforms import BaseImportRewrite

    class Dummy(BaseImportRewrite):
        rewrites = [
            ('typed_ast', 'ast')
        ]


# Generated at 2022-06-23 22:33:50.274123
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.transform(None) == \
        TransformationResult(None, False, [])


# Generated at 2022-06-23 22:34:00.135458
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = ast.parse("import a;")
    tree = BaseImportRewrite(module).visit(module)
    assert tree == ast.parse("import a;")

    module = ast.parse("import a as b;")
    tree = BaseImportRewrite(module).visit(module)
    assert tree == ast.parse("import a as b;")

    module = ast.parse("import a.b.c;")
    tree = BaseImportRewrite(module).visit(module)
    assert tree == ast.parse("import a.b.c;")

    module = ast.parse("import a.b.c as d;")
    tree = BaseImportRewrite(module).visit(module)
    assert tree == ast.parse("import a.b.c as d;")


# Generated at 2022-06-23 22:34:10.072804
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import typedast

    # test for case when module name not matched
    import_from = ast.parse('import typing').body[0]
    visitor = BaseImportRewrite()
    result = visitor.visit(import_from)
    assert isinstance(result, ast.Import)

    # test for case when module name matched
    import_from = ast.parse('import asyncio.futures').body[0]
    visitor = BaseImportRewrite(rewrites=[('asyncio.futures', 'asyncio.tasks')])
    result = visitor.visit(import_from)
    assert isinstance(result, ast.Try)
    assert result.body[0].value.names[0].name == 'asyncio.tasks'

    # test for case when alias name not matched

# Generated at 2022-06-23 22:34:21.085539
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    cls = BaseImportRewrite
    assert cls.__name__ == 'BaseImportRewrite'
    assert cls.__doc__ is None
    assert cls.__module__ == 'python_transpiler.transformer.base_transformer'

# Generated at 2022-06-23 22:34:22.551843
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(None)

# Generated at 2022-06-23 22:34:33.309322
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(
        module='some.module',
        names=[ast.alias(name='foo', asname=None),
               ast.alias(name='bar', asname=None)],
        level=0)
    rewrote = ast.ImportFrom(
        module='other.module',
        names=[ast.alias(name='foo', asname=None),
               ast.alias(name='bar', asname=None)],
        level=0)
    import_rewrite = ast.Try(
        body=[rewrote],
        handlers=[],
        orelse=[],
        finalbody=[])

    # when
    test_base_import_rewrite = BaseImportRewrite()
    test_base_import_rewrite.rewrites = [('some.module', 'other.module')]
    result

# Generated at 2022-06-23 22:34:44.141039
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import io
    import sys

    class T0(BaseImportRewrite):
        rewrites = [ 
            ("io", "StringIO")
        ]

    def check(code, expected):
        tree = ast.parse(code)
        changed, tree = T0.transform(tree)
        assert changed
        assert ast.dump(tree) == expected

    def check_raw(code, expected):
        check(code, ast.dump(ast.parse(expected)))

    check_raw(
        """
import io
        """,
        """
try:
    import io
except ImportError:
    import StringIO as io
        """)

    check_raw(
        """
import io.BytesIO
        """,
        """
import io.BytesIO
        """)


# Generated at 2022-06-23 22:34:54.386716
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        dependencies = []
        rewrites = [
            ('old_name', 'new_name')
        ]

    code = '''
import old_name
import old_name.module
import old_name.module.submodule as X
import old_name.module.submodule as X, module2

'''


# Generated at 2022-06-23 22:34:55.280653
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    instance = BaseTransformer()


# Generated at 2022-06-23 22:35:01.003800
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import compare_ast

    module = ast.parse('from datetime import datetime')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('datetime', 'some_repo.timeutils')
        ]

    result = TestImportRewrite.transform(module)
    assert result.dependencies == ['some_repo']

    module = ast.parse('from datetime.tzinfo import utc')

    result = TestImportRewrite.transform(module)
    expected = ast.parse('from some_repo.timeutils.tzinfo import utc')
    assert result.dependencies == ['some_repo']
    compare_ast(result.tree, expected)

    module = ast.parse('from datetime import datetime, date, tzinfo')

    result = TestImportRewrite.transform

# Generated at 2022-06-23 22:35:10.698845
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from ..utils.compile_to_ast import compile_to_ast
    original_tree = parse('''
        import abc as ABC
        import def
        import ghi
        import jkl
    ''')
    expected_tree = parse('''
        try:
            import abc as ABC
        except ImportError:
            import abc_py2 as ABC
        import def
        try:
            import jkl
        except ImportError:
            import jkl_rewrite as jkl
    ''')
    actual_tree = BaseImportRewrite.transform(original_tree).tree

    assert compile_to_ast(expected_tree) == compile_to_ast(actual_tree)



# Generated at 2022-06-23 22:35:20.722201
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node = ast.ImportFrom(module=None,
                          names=[
                              ast.alias(name=None,
                                        asname=None),
                              ast.alias(name=None,
                                        asname=None),
                              ast.alias(name=None,
                                        asname=None),
                              ast.alias(name=None,
                                        asname=None),
                              ast.alias(name=None,
                                        asname=None)
                          ],
                          level=None)
    print(astor.to_source(node))
    result = BaseImportRewrite.visit_ImportFrom(BaseImportRewrite, node)
    print(astor.to_source(result, indent_with=' ' * 4))


# Generated at 2022-06-23 22:35:22.666211
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)

# Generated at 2022-06-23 22:35:30.944985
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from astunparse import unparse
    from asttokens import ASTTokens
    from ..utils.tst_utils import assert_code_equal
    from .test_BaseImportRewrite_transform_all import _transform_tree_to_string

    code = """
        from a import b, c
        from a.d import e, f
        from a import g
        import h
        from a.d.g.h import i, j
        from a import k
        from b import l
    """
    tree = ast.parse(code)

    # when
    class ImportTransformer(BaseImportRewrite):
        rewrites = [
            ("a", "z"),
            ("b", "y")
        ]
    res = ImportTransformer.transform(copy.deepcopy(tree))

    # then
   

# Generated at 2022-06-23 22:35:33.023778
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:35:39.062787
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformerTest(metaclass=ABCMeta):
        target = None  # type: CompilationTarget
        dependencies = []

        @classmethod
        @abstractmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    class Test(BaseNodeTransformerTest, ast.NodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__()
            self._tree = tree
            self._tree_changed = False

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)

    test = Test.transform(ast.parse(''))


# Generated at 2022-06-23 22:35:44.836431
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    old_import = "from foo import bar"
    new_import = "from baz import bar"

    tree = astor.parse(old_import)
    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [("foo", "baz")]

    assert TestTransformer.transform(tree) == TransformationResult(
        tree=astor.parse(new_import), tree_changed=True, dependencies=["foo"])



# Generated at 2022-06-23 22:35:48.325570
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformer1(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    ast1 = ast.parse('def foo(): pass')
    BaseNodeTransformer1.transform(ast1)



# Generated at 2022-06-23 22:35:49.308413
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    temp = BaseTransformer()
    assert temp.target == None


# Generated at 2022-06-23 22:35:59.691426
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import six
    import unittest.mock as mock
    import astunparse

    class BaseNodeTransformer2(BaseNodeTransformer):
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)

    class Transformer(BaseNodeTransformer2):
        def visit_Num(self, node: ast.Num) -> ast.Num:
            self._tree_changed = True
            return ast.Num(node.n + 1)


# Generated at 2022-06-23 22:36:03.720081
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    from ..utils.testing import BasicImportRewrite

    class Test(unittest.TestCase):
        def test_empty_rewrites(self):
            # If rewrites are empty, import were not transformed
            import_ = ast.Import(names=[
                ast.alias(name='a', asname='b')])
            result = BasicImportRewrite(import_).visit_Import(import_)
            self.assertEqual(result, import_)

        def test_module_rewrite(self):
            import_ = ast.Import(names=[
                ast.alias(name='a', asname='b')])
            result = BasicImportRewrite(import_,
                                        rewrites=[('a', 'c')]).visit_Import(import_)

# Generated at 2022-06-23 22:36:15.369259
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import re
    from .test_transformer import BaseImportRewrite
    rewrites = [
        ('b', 'base'),
        ('a', 'alpha')
    ]
    tree = ast.parse('from b import c\nfrom a.b import c as d')
    result = BaseImportRewrite.transform(tree=tree)
    assert_true(result.changed)
    assert_equal(result.dependencies, [])

# Generated at 2022-06-23 22:36:21.955092
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestImportRewrite(BaseImportRewrite):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self.rewrites = [('collections', 'typing')]

    code = """
        import collections
    """

    tree = astor.parse_file(code)

    tr = TestImportRewrite(tree)

    result = tr.visit(tree)
    assert astor.to_source(result) == '''
        try:
            import collections
        except ImportError:
            import typing as collections
    '''


# Generated at 2022-06-23 22:36:24.088839
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    try:
        BaseImportRewrite()
    except TypeError:
        return
    assert(False)


# Generated at 2022-06-23 22:36:30.274571
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    import_from = ast.ImportFrom(module="x",
                                 names=[ast.alias(name="y",
                                                  asname="z")],
                                 level=0)

    import_from_rewritten = ast.ImportFrom(module="x.anothermodule",
                                           names=[ast.alias(name="y",
                                                            asname="z")],
                                           level=0)

    import_from_rewritten_alias = ast.ImportFrom(module="x",
                                                 names=[ast.alias(name="y",
                                                                  asname="z")],
                                                 level=0)
