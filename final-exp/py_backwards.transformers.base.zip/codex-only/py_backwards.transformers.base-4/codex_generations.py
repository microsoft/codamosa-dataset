

# Generated at 2022-06-23 22:26:33.183321
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:26:39.906977
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typed_ast
    import typing
    import inspect

    class Foo(BaseImportRewrite):
        rewrites = [('typing', 'typing_extensions')]

    tree = typed_ast.ast3.parse(
        "import typing as bar",
        mode="exec")

    Foo.transform(tree)

    expected = """\
try:
    import typing as bar
except ImportError:
    from typing_extensions import bar
"""

    assert ast.dump(tree) == expected



# Generated at 2022-06-23 22:26:48.394192
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    

# Generated at 2022-06-23 22:26:53.111931
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from mypy import nodes
    from . import BaseImportRewrite
    import_obj = ast.Import([ast.alias(name='import_module',asname='import_module')])
    BaseImportRewrite.rewrites = [('import_module','rewrite_module')]
    tree = ast.Module(body=[import_obj])
    BaseImportRewrite.transform(tree)
    assert tree.body[0].names[0].name == 'rewrite_module'


# Generated at 2022-06-23 22:26:59.837597
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestRewriteImport(BaseImportRewrite):
        rewrites = [
            ('old', 'new'),
        ]

    tree = ast.parse('import old', mode='eval')
    tr = TestRewriteImport.transform(tree)

    import_rewrite = ast.parse('import old\ntry:\n  import new\nexcept ImportError:\n  import old', mode='exec')
    assert tr.tree == import_rewrite
    assert tr.changed is True


# Generated at 2022-06-23 22:27:04.787052
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'py27'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return

    tt = TestTransformer
    assert tt.target == 'py27'
    assert tt.transform(None) is None


# Generated at 2022-06-23 22:27:10.651629
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..transformer import BaseImportRewrite
    from ..types import CompilationTarget
    from typing import Optional
    from typed_ast import ast3 as ast

    class DerivedImportRewrite(BaseImportRewrite):
        target = CompilationTarget('python', '3.5')

    assert isinstance(ast.parse('import numpy'), ast.Module)
    assert DerivedImportRewrite.transform(ast.parse('import numpy')).has_changed == False
    assert bool(DerivedImportRewrite.transform(ast.parse('import numpy')).tree) == True

# Generated at 2022-06-23 22:27:11.519213
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    obj = BaseImportRewrite()

# Generated at 2022-06-23 22:27:19.771267
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.ast_builder import ast_from_snippet
    class Test(BaseImportRewrite):
        rewrites = [
            ('os', 'six.moves.os')]

    tree = ast_from_snippet('import os')
    res = Test.transform(tree)
    assert res.changed is True
    assert str(res.tree) == 'import_rewrite(previous = Import(names = [alias(name = "os", asname = None)]), current = Import(names = [alias(name = "six.moves.os", asname = None)]))'



# Generated at 2022-06-23 22:27:28.423586
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import os
    import sys
    import ast as _ast
    import typed_astunparse

    # Test replaces Import(names=[alias(name='os', asname=None)]) with
    # Try(body=[Import(names=[alias(name='os', asname=None)])],
    #     handlers=[ExceptHandler(type=Name(id='ImportError', ctx=Load()),
    #                             name=None,
    #                             body=[Import(names=[alias(name='os', asname='ot')])])],
    #     orelse=[])
    transformed = BaseImportRewrite.transform(
        _ast.parse(typed_astunparse.unparse(ast.Import(names=[ast.alias(name='os',
                                                                        asname=None)]))))

# Generated at 2022-06-23 22:27:29.589943
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:27:31.782767
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .tests import tree1
    from .tests import tree1_changed

    BaseNodeTransformer.transform(tree1)


# Generated at 2022-06-23 22:27:43.307330
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Mock tree
    tree = ast.parse('from foo import bar\nfrom foo.bar import foo')
    # Mock rewrites
    rewrites = [('foo', 'newfoo')]

    t = BaseImportRewrite(tree)
    t.rewrites = rewrites
    t.visit(tree)

    assert t._tree_changed

# Generated at 2022-06-23 22:27:45.292167
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a = 123')
    b = BaseNodeTransformer(tree)
    b.visit(tree)

# Generated at 2022-06-23 22:27:48.859294
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..types import ModuleInfo
    from ..utils import get_ast
    from .flask import FlaskTransformer
    
    class DummyTransformer(FlaskTransformer):
        target = 'demo'
    
    ast_ = get_ast(ModuleInfo('a', 'a.py', ""))
    
    transformer = DummyTransformer(ast_)

# Generated at 2022-06-23 22:27:59.167230
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    import textwrap

    class TestImportRewriteTransformer(BaseImportRewrite):
        rewrites = [('io', 'io2')]


# Generated at 2022-06-23 22:28:10.114000
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from typed_ast.ast3 import parse
    class A(BaseImportRewrite):
        rewrites = [('urllib2', 'urllib.request')]
    tree = parse("""\
import urllib2
from urllib2 import urlopen, Request
from urllib2.request import urlopen, Request\
"""
    )
    A.transform(tree)
    assert str(tree) == """\
import urllib2
try:
    from urllib2 import urlopen, Request
except ImportError:
    from urllib.request import urlopen, Request
try:
    from urllib2.request import urlopen, Request
except ImportError:
    from urllib.request.request import urlopen, Request
"""



# Generated at 2022-06-23 22:28:15.747306
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [("urllib", "requests")]
    BaseImportRewrite.dependencies = []
    BaseImportRewrite.target = CompilationTarget.Python27
    from io import StringIO

# Generated at 2022-06-23 22:28:22.698474
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [(
            'foo.bar', 'baz',
        )]

    tree = ast.parse("""\
    import foo.bar
    from foo import bar""")

    transformed = TestImportRewrite.transform(tree)

    expected = ast.parse("""\
    try:
        import foo.bar as bar
    except ImportError:
        import baz as bar
    try:
        from foo import bar
    except ImportError:
        from baz import bar""")

    assert ast.dump(transformed.tree) == ast.dump(expected)

# Generated at 2022-06-23 22:28:26.949082
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.node_utils import get_node, get_node_name
    from ..utils.source_code import EXAMPLES_DIRECTORY
    import unittest
    import os

    class TestBaseImportRewriteVisitImportFrom(unittest.TestCase):
        def test_visit_ImportFrom(self):
            example_path = os.path.join(EXAMPLES_DIRECTORY, 'lxml.html.inputstream', 'inputstream.py')
            tree = get_node(example_path, ast.parse)
            BaseImportRewrite.rewrites = [('lxml.html.inputstream', 'html5lib.inputstream')]
            BaseImportRewrite.visit(tree)

            o = get_node_name(tree, '_base.object')

# Generated at 2022-06-23 22:28:28.473317
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__(BaseImportRewrite)


# Generated at 2022-06-23 22:28:30.150470
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert t.target == None

# Generated at 2022-06-23 22:28:41.495150
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewriteTester(BaseImportRewrite):
        rewrites = [('foo', 'foobar')]

    class BaseImportRewriteTester2(BaseImportRewriteTester):
        pass

    # Unit test for method BaseImportRewriteTester._replace_import
    def test_BaseImportRewriteTester__replace_import():
        class BaseImportRewriteTester2(BaseImportRewriteTester):
            rewrites = [('foo', 'foobar')]

        def _replace_import(node, from_, to):
            tree = ast.parse("import foo")
            node = tree.body[0]
            from_ = 'foo'
            to = 'foobar'

# Generated at 2022-06-23 22:28:42.108183
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None


# Generated at 2022-06-23 22:28:42.897153
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    inst = BaseNodeTransformer(None)

# Generated at 2022-06-23 22:28:44.678893
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert callable(BaseTransformer.transform) == True
    #assert BaseTransformer.transform(tree: ast.AST) == None


# Generated at 2022-06-23 22:28:46.924278
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    a = BaseTransformer()
    try:
        print(a.target)
    except:
        print('no attribute')


# Generated at 2022-06-23 22:28:56.363140
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MyImportRewrite(BaseImportRewrite):
        rewrites = [
            ('urllib.foo', 'urllib.something'),
            ('urllib.bar', 'urllib.something_else'),
        ]

    class MyImportRewriteNoMatch(BaseImportRewrite):
        rewrites = []

    class MyImportRewriteDependencyMatch(BaseImportRewrite):
        rewrites = [
            ('urllib', 'urllib.something'),
        ]

    class MyImportRewriteMatchInDependency(BaseImportRewrite):
        rewrites = [
            ('x.y', 'x.z'),
        ]

    import_ = ast.parse('import urllib.foo').body[0]
    transformed_import = MyImportRewrite().visit(import_)

# Generated at 2022-06-23 22:29:00.277697
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = 'python3'
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    assert Transformer.target == 'python3'
    assert Transformer.transform.__name__ == 'transform'


# Generated at 2022-06-23 22:29:08.304700
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import(): 
    import unittest
    import os
    import astunparse

    class TestCase(unittest.TestCase):
        def test_simple_import(self):
            source = 'import os'
            expected = 'import os'

            expected_tree = ast.parse(expected)
            tree = ast.parse(source)

            class TestTransformer(BaseImportRewrite):
                rewrites = [('os', 'something')]

            transformer = TestTransformer.transform(tree)
            self.assertEqual(transformer.changed, True)
            self.assertEqual(astunparse.unparse(transformer.tree),
                             astunparse.unparse(expected_tree))
             
        def test_simple_import_as(self): 
            source = 'import os as target'

# Generated at 2022-06-23 22:29:10.419855
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    b = BaseImportRewrite(None)
    assert isinstance(b, BaseImportRewrite)

# Generated at 2022-06-23 22:29:13.852275
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__.__annotations__ == dict(
        self=BaseImportRewrite,
        tree=ast.AST)


# Generated at 2022-06-23 22:29:25.316657
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typed_astunparse
    import unittest
    from typed_astunparse import ast27

    class T(BaseImportRewrite):
        rewrites = [
            ('some.module1', 'module2'),
            ('some.module3', 'module4')
        ]

    class C(unittest.TestCase):

        def test_rewrite(self):
            node = ast.parse(typed_astunparse.unparse(ast27.parse('import some.module1')))
            assert typed_astunparse.unparse(T.transform(node).tree) == \
                'try:\n    import some.module1 as module1\n' \
                'except ImportError:\n    import module2 as module1'


# Generated at 2022-06-23 22:29:27.219266
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    t = BaseImportRewrite()
    assert t is not None

# Generated at 2022-06-23 22:29:37.965661
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class SampleTransformer(BaseImportRewrite):
        rewrites = [('unittest', 'test')]

    import test
    import unittest
    import test as t
    from test import TestCase
    from unittest import TestCase as TC
    from unittest import skip as skip_unittest
    from test import skip

    class A(test.TestCase):
        pass

    class B(unittest.TestCase):
        pass

    class C(t.TestCase):
        pass

    @skip
    def one():
        pass

    @skip_unittest
    def two():
        pass

    class D(TestCase):
        pass

    class E(TC):
        pass


# Generated at 2022-06-23 22:29:41.373866
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    old = ast.parse("import module_name")
    transformator = BaseImportRewrite(old)
    transformator.rewrites = [('module_name', 'new_module_name')]
    new = transformator.visit(old)
    expected = ast.parse("try:\n    import module_name\nexcept ImportError:\n    import new_module_name")
    assert ast.dump(new) == ast.dump(expected)



# Generated at 2022-06-23 22:29:46.072974
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_target import target
    from .test_transformer import BaseTestTransformer

    rewrites = [('a', 'b')]
    import_statement = "from a import b"
    transformer_class = type("TestTransformer", (BaseTestTransformer, BaseImportRewrite), {
        'rewrites': rewrites,
        'target': target
    })

    class TestTransformer(transformer_class):
        node_type = ast.Import

    expected = """
    try:
        from a import b
    except ImportError:
        from b import b
    """
    assert TestTransformer.transform(import_statement) == expected


# Generated at 2022-06-23 22:29:50.302526
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('my_func(1, 2)')
    tree_transformer = BaseNodeTransformer.transform(tree)
    assert tree_transformer.tree is tree
    assert tree_transformer.tree_changed is False
    assert tree_transformer.dependencies == []


# Generated at 2022-06-23 22:29:53.221842
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    if 'BaseNodeTransformer' != BaseNodeTransformer.__name__:
        raise ValueError('BaseNodeTransformer __name__ is not equal: ' +
                         BaseNodeTransformer.__name__)


# Generated at 2022-06-23 22:29:55.610108
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert isinstance(BaseImportRewrite, type)
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)


# Generated at 2022-06-23 22:30:04.136219
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def test_asserts(tree, node):
        print(ast.dump(tree))
        assert isinstance(tree, ast.Try)
        assert len(tree.handlers) == 1
        assert isinstance(tree.handlers[0], ast.ExceptHandler)

        assert isinstance(tree.body[0], ast.ImportFrom)
        assert tree.body[0].module == "new_module"

        assert isinstance(tree.body[1], ast.ImportFrom)
        assert tree.body[1].module == "old_module"

        assert tree == node

    def test_ImportFrom(rewrites):
        tree = ast.parse(
            'from mod import x',
            type_comments=True)

        class import_rewrite(BaseImportRewrite):
            rewrites = rewrites
            target = CompilationTarget

# Generated at 2022-06-23 22:30:14.756564
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import os
    import tempfile
    from ..parser import BaseParser

    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Import
    from typed_ast.ast3 import TryExcept
    from typed_ast.ast3 import Name

    import_dummy = Import(names=parse('''
    [
        alias(name='test.old')
    ]
    ''').body)


# Generated at 2022-06-23 22:30:23.481122
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('one', 'two')]

    import_ = ast.Import(names=[ast.alias(name='one', asname=None)])
    changed = Transformer.transform(import_).tree
    expected = ast.Try(body=[ast.Import(names=[ast.alias(name='one', asname=None)])],
                       handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError',
                                                                 ctx=ast.Load()),
                                                   name=None,
                                                   body=[ast.Import(names=[ast.alias(name='two',
                                                                                     asname=None)])])],
                       orelse=[],
                       finalbody=[])
    assert ast.dump(changed) == ast.dump(expected)




# Generated at 2022-06-23 22:30:24.872792
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import math')
    transformer = BaseNodeTransformer(tree)

    assert transformer._tree == tree
    assert transformer._tree_changed is False



# Generated at 2022-06-23 22:30:29.316554
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class SomeTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            self.tree = tree
    t = SomeTransformer(None)
    assert t.tree is None, "Tree was not saved at all"
    assert t._tree_changed is False, "Tree should be unchanged at the beginning"


# Generated at 2022-06-23 22:30:30.105210
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()  # should not raise

# Generated at 2022-06-23 22:30:35.802242
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # test __init__
    class TestTransformer(BaseNodeTransformer):
        pass

    node = ast.parse('pass')
    transformer = TestTransformer(node)
    assert isinstance(transformer, TestTransformer)
    assert transformer._tree == node
    assert transformer._tree_changed == False

    # test default dependencies
    assert TestTransformer.dependencies == []


# Generated at 2022-06-23 22:30:39.777155
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class NodeTransformer(BaseNodeTransformer):
        pass
    tree = ast.parse('x = 1')
    trans = NodeTransformer(tree)
    trans.visit(tree)
    assert trans._tree_changed == False

# Generated at 2022-06-23 22:30:40.720592
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:30:52.042771
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast as org_ast
    from textwrap import dedent

    from ..utils.node import get_ast

    code = dedent('''
    class Example:
        def some_method(self):
            import datetime
            import sys
            print(datetime.datetime.now())
    ''')
    expected_code = dedent('''
    class Example:
        def some_method(self):
            try:
                import datetime
                import sys
            except ImportError:
                import datetime
                import sys
            print(datetime.datetime.now())
    ''')
    tree = get_ast(code)
    inst = BaseImportRewrite(tree)
    inst.visit(tree)

    expected_tree = get_ast(expected_code)

# Generated at 2022-06-23 22:30:53.952984
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    inst = BaseTransformer()
    assert inst is not None


# Generated at 2022-06-23 22:30:56.035625
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class FooTransformer(BaseTransformer):
        pass

    foo = FooTransformer()
    assert foo.target is None

# Generated at 2022-06-23 22:31:03.626353
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astor

    class RewriteTestCase(unittest.TestCase):
        def test_rewrite(self):
            original = astor.parse_file(self.original)
            expected = astor.parse_file(self.expected)
            import_visitor = BaseImportRewrite(original)
            import_visitor.visit(original)
            self.assertEqual(astor.to_source(expected), astor.to_source(original))

    class TestRewrite_1(RewriteTestCase):
        rewrites = [('foo', 'bar')]

        original = '''
import foo
foo()
'''
        expected = '''
try:
    import foo
except ImportError:
    import bar

foo()
'''


# Generated at 2022-06-23 22:31:15.507511
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from astunparse import unparse
    from ..utils.imports import normalize_imports

    class Rewrite(BaseImportRewrite):
        target = 'python2'
        rewrites = [('from_me', 'to_you')]


# Generated at 2022-06-23 22:31:22.913973
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    from ..utils.typed_ast_fix import ast_fix_module
    from ..utils.typed_ast_fix import transform
    from ..utils.typed_ast_fix.fix_typed_ast import typed_ast_fix_module
    import sys
    from pathlib import Path
    from collections import OrderedDict

    class TestTransformer(BaseImportRewrite):
        rewrites = [('collections', 'typed_ast_fix.rewrites.collections')]

    class TestTransformer2(BaseImportRewrite):
        rewrites = [('collections', 'typed_ast_fix.rewrites.collections'),
                    ('typed_ast_fix.rewrites.collections', 'typed_ast_fix.rewrites.rewrites')]


# Generated at 2022-06-23 22:31:24.738346
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    '''
    This function will return NotImplementedError
    '''
    BaseNodeTransformer(tree)

# Generated at 2022-06-23 22:31:27.426357
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    bt = BaseNodeTransformer('')

    assert bt._tree_changed == False
    assert bt._tree == ''


# Generated at 2022-06-23 22:31:38.639944
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..test_utils import get_test_ast, assert_transform

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('test_utils', 'async_utils')]

    # test
    node = get_test_ast('import test_utils', 'import_from')
    assert_transform(TestImportRewrite,
                     'import async_utils',
                     node)

    # test import as
    node = get_test_ast('import test_utils as foo', 'import_from')
    assert_transform(TestImportRewrite,
                     'import async_utils as foo',
                     node)

    # test ImportFrom
    node = get_test_ast("""
from test_utils import foo
""", 'import_from')

# Generated at 2022-06-23 22:31:45.071689
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class A(BaseNodeTransformer):
        def __init__(self):
            super().__init__(a_tree)
            self._tree_changed = False
    class B(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)
            self._tree_changed = False

    a_tree = ast.parse('pass')
    b_tree = ast.parse('pass')
    a = A()
    b = B(b_tree)

# Generated at 2022-06-23 22:31:54.856917
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class SomeTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    transformer = SomeTransformer(None)
    import_node = ast.Import(names=[
        ast.alias(name='foo.baz', asname='baz'),
        ast.alias(name='foo.baz.quux', asname='quux')])
    assert transformer.visit_Import(import_node).__class__ != import_node.__class__

# Generated at 2022-06-23 22:31:57.378807
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    t = BaseNodeTransformer._create_instance(ast.parse('pass'))
    assert astor.to_source(t._tree) == 'pass\n'
    assert t._tree_changed is False

# Generated at 2022-06-23 22:32:05.160731
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    try:
        # Original: import a.b.c as d
        node = ast.ImportFrom(module='a.b', names=[
            ast.alias(name='c', asname='d')], level=0)
        # Expected: import a.b.c as d
        expected = node
        # Try to rewrite import a.b.c as d as import a.x.c as d
        visitor = BaseImportRewrite([('a.b', 'a.x')])
        rewrote = visitor.visit_ImportFrom(node)
        assert rewrote == expected
    except AssertionError as e:
        print(str(e))


# Generated at 2022-06-23 22:32:06.704389
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite



# Generated at 2022-06-23 22:32:09.957113
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .transform_urllib import HttpsOnly
    import typing

    assert isinstance(HttpsOnly, BaseImportRewrite)
    assert isinstance(HttpsOnly.rewrites, typing.List)

# Generated at 2022-06-23 22:32:12.411713
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert isinstance(BaseTransformer, ABCMeta)


# Generated at 2022-06-23 22:32:13.013113
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:32:14.950921
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    with pytest.raises(TypeError):
        BaseImportRewrite(None)


# Generated at 2022-06-23 22:32:24.327917
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    test_import = ast.parse('''
        import foo
        import foo.bar
        import random.foo
        import test
        import not_rewrite
    ''')

    expected = ast.parse('''
        try:
            import foo
        except ImportError:
            import bar
        try:
            import foo.bar
        except ImportError:
            import bar.bar
        try:
            import random.foo
        except ImportError:
            import random.bar
        import test
        import not_rewrite
    ''')

    assert TestTransformer.transform(test_import).tree == expected


# Generated at 2022-06-23 22:32:25.007456
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer is ast.NodeTransformer

# Generated at 2022-06-23 22:32:33.008939
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    @snippet_as_class
    class test_BaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [
            ('socks', 'socket'),
        ]

    class_ = test_BaseImportRewrite_visit_Import
    code = '\n'.join([
        'import socks',
        'import socks.socks',
        'import socks.something',
        'import socks5',
        'import something.socks'
    ])
    tree = ast.parse(code)
    res = class_.transform(tree)
    assert res.changed

# Generated at 2022-06-23 22:32:40.033107
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer.__bases__[0] == BaseTransformer
    assert BaseNodeTransformer.__bases__[1] == ast.NodeTransformer
    assert BaseNodeTransformer.__init__.__doc__ == \
        "Methods to visit and communicate with the context.\n\n" \
        "Subclasses should implement visit_Node(self, node) " \
        "for each AST node they want to process.\n\n" \
        "Don't call these methods yourself, instead call transform()."



# Generated at 2022-06-23 22:32:42.033420
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    try:
        from six import PY2
    except ImportError:
        PY2 = False


# Generated at 2022-06-23 22:32:52.294463
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import io
    import textwrap
    
    from typed_ast import ast3 as typed_ast

    source = textwrap.dedent("""
    import ast

    import datetime

    from datetime import datetime

    from datetime import datetime as dt

    from datetime import datetime as dt, time

    from datetime import *
    """)

    source = io.StringIO(source)
    tree = typed_ast.parse(source.read())

    class ImportTester(BaseImportRewrite):
        rewrites = [
            ('ast', 'typed_ast.ast3'),
            ('datetime', 'concurrent.futures.datetime'),
        ]

    changed, tree = ImportTester.transform(tree)

    assert changed is True


# Generated at 2022-06-23 22:32:53.432256
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert BaseTransformer.transform is BaseTransformer.transform

# Generated at 2022-06-23 22:32:56.790569
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    do_test = True
    if do_test:
        try:
            class Transform(BaseTransformer):
                pass
        except:
            assert False, "Can't create class BaseTransformer"


# Generated at 2022-06-23 22:32:59.183516
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(tree=None)
    assert t._tree is None
    assert t._tree_changed is False



# Generated at 2022-06-23 22:33:08.721618
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class _TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'rewrote_foo')]

    node = ast.parse('import foo').body[0]
    result = _TestImportRewrite.transform(node)
    assert result.changed
    assert 'foo' not in ast.dump(result.tree)
    assert 'rewrote_foo' in ast.dump(result.tree)

    node = ast.parse('from foo import bar').body[0]
    result = _TestImportRewrite.transform(node)
    assert result.changed
    assert 'foo' not in ast.dump(result.tree)
    assert 'rewrote_foo.bar' in ast.dump(result.tree)

    node = ast.parse('from foo import bar as baz').body[0]
    result = _TestImport

# Generated at 2022-06-23 22:33:20.502255
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..typed_ast.ast import Module, Import, ImportFrom, alias, fix_missing_locations
    from ..typed_ast.parse import parse
    from ..typed_ast.types import cpython_35

    class TestTransformer(BaseImportRewrite):
        rewrites = [('a_module', 'b_module')]

    # Test rewrite of Import
    tree = parse('import a_module', target=cpython_35)
    transformer = TestTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-23 22:33:27.892554
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astunparse
    
    class ImportFromTest(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib')]

    tree = ast.parse('from os.path import join as p_join')
    res = ImportFromTest.transform(tree)
    tree_rewritten = res.tree

    assert astor.to_source(tree_rewritten) == """try:
    from os.path import join as p_join
except ImportError:
    from pathlib import join as p_join"""

    tree = ast.parse('from os.path import join')
    res = ImportFromTest.transform(tree)
    tree_rewritten = res.tree


# Generated at 2022-06-23 22:33:36.024691
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = """
from module import *
from module import test, test1
from module import test as test_alias, test1 as test1_alias
"""
    expected = """
from module import *
try:
    from module import test, test1
except ImportError:
    from module_rewrite import test, test1
from module import test as test_alias
try:
    from module import test1 as test1_alias
except ImportError:
    from module_rewrite import test1 as test1_alias
"""
    rewrites = [('module', 'module_rewrite')]
    tree = ast.parse(code)
    BaseImportRewrite.rewrites = rewrites

    result = BaseImportRewrite.transform(tree).tree
    assert expected == unparse(result)

# Generated at 2022-06-23 22:33:46.759612
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..ast import ast_from_string
    from textwrap import dedent
    
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'baz')
        ]
        
    code_s = dedent('''\
    from foo.bar import baz as zaz
    
    
    from foo.bar.foo import foo
    
    
    import foo.bar
    
    
    from foo.bar import *''')

# Generated at 2022-06-23 22:33:47.811573
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseImportRewrite()



# Generated at 2022-06-23 22:33:57.869846
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    #pylint: disable=no-member
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)
    assert issubclass(BaseImportRewrite, ast.NodeTransformer)
    assert hasattr(BaseImportRewrite, 'rewrites')
    assert hasattr(BaseImportRewrite, '_get_matched_rewrite')
    assert hasattr(BaseImportRewrite, '_replace_import')
    assert hasattr(BaseImportRewrite, 'visit_Import')
    assert hasattr(BaseImportRewrite, '_replace_import_from_module')
    assert hasattr(BaseImportRewrite, '_get_names_to_replace')
    assert hasattr(BaseImportRewrite, '_get_replaced_import_from_part')

# Generated at 2022-06-23 22:34:06.407790
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    # ast.dump will generate different output depending on version of python
    # which is why we are using astor
    import astor
    from unittest.mock import MagicMock

    class BaseImportRewriteTester(BaseImportRewrite):
        rewrites = [
            ('old_name', 'new_name'),
        ]

    tree = ast.parse('import old_name\nimport old_name.submodule')
    BaseImportRewriteTester.transform(tree)
    expected = 'try:\n    import old_name\nexcept ImportError:\n    import new_name\nimport old_name.submodule'
    assert astor.to_source(tree).strip() == expected



# Generated at 2022-06-23 22:34:07.929760
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer

# Generated at 2022-06-23 22:34:10.888143
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    the_tree = ast.parse('name = "fos"')
    test = BaseNodeTransformer(the_tree)
    assert isinstance(test, BaseNodeTransformer)
    assert test._tree == the_tree

# Generated at 2022-06-23 22:34:21.553770
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('test.test_test_test', 'test.test')]
        dependencies = []

    tree = ast.parse('''from test_test_test import test_test''')
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    result = astor.to_source(transformer.visit(tree))
    expected = '''try:\n    from test_test_test import test_test\nexcept ImportError:\n    from test.test import test_test\n'''
    assert result == expected

    class TestTransformer(BaseImportRewrite):
        rewrites = [('test.test_test_test', 'test.test')]
        dependencies = []


# Generated at 2022-06-23 22:34:32.695164
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..testing import assert_ast, assert_transform

    class TestImportRewrite(BaseImportRewrite):
        rewrite = ('a', 'b')

    class TestImportRewriteMany(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]

    assert_transform(
        TestImportRewrite,
        'import a\n',
        'try:\n    import a\n    extend(a)\nexcept ImportError:\n    import b\n    extend(b)\n',
        lambda s: astor.to_source(s)
    )


# Generated at 2022-06-23 22:34:43.614952
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # test 1
    import_from_part1 = ast.ImportFrom(module='os',
                                       names=[ast.alias(name='path',
                                                        asname=None)],
                                       level=0)

    import_from_part2 = ast.ImportFrom(module='os.path',
                                       names=[ast.alias(name='join',
                                                        asname='pathjoin')],
                                       level=0)

    import_from_part3 = ast.ImportFrom(module='distutils',
                                       names=[ast.alias(name='core',
                                                        asname=None)],
                                       level=0)

    # test 2

# Generated at 2022-06-23 22:34:44.389487
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer is not None


# Generated at 2022-06-23 22:34:45.779843
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass

    import astor

# Generated at 2022-06-23 22:34:56.500914
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('PySide', 'PyQt5'),
            ('PyQt5.QtGui', 'PyQt5.QtWidgets'),
        ]

    ast_ = ast.parse("import PySide\nfrom PyQt5 import QtGui, QtWidgets\nfrom PySide import *")
    ast_.body[2] = ast.ImportFrom(module='PySide',
                                  names=[ast.alias(name='*')],
                                  level=0)

    expected_ast = ast.parse("import PyQt5\nfrom PyQt5 import QtGui, QtWidgets\nfrom PyQt5 import *")

# Generated at 2022-06-23 22:35:06.832379
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    try:
        from importlib import __import__
    except ImportError:
        from importlib import __builtin__
    target = 'import_from'

# Generated at 2022-06-23 22:35:08.230386
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("", filename="", mode="exec")
    BaseNodeTransformer(tree)



# Generated at 2022-06-23 22:35:09.883123
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:35:11.404619
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.parse('1 + 1'))

# Generated at 2022-06-23 22:35:22.228533
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from typed_ast import ast3 as ast
    from cwinter.compilation.transformers.transformer import BaseImportRewrite
    import astpretty
    import importlib
    import copy

    class TestTransformer(BaseImportRewrite):
        target = 'python'
        rewrites = [('foo', 'bar'), ('bar', 'foo')]
    
        def _replace_import(self, node: ast.Import, from_: str, to: str) -> ast.Try:
            """Replace import with try/except with old and new import."""
            self._tree_changed = True

            rewrote_name = node.names[0].name.replace(from_, to, 1)
            import_as = node.names[0].asname or node.names[0].name.split('.')[-1]


# Generated at 2022-06-23 22:35:29.183864
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor  # type: ignore

    target = CompilationTarget(
        module_name='foo',
        version=2,
        python_version='3.5')

    class TestTransformer(BaseImportRewrite):
        target = target
        rewrites = [('foo.bar', 'baz')]

    tree = astor.parse('import foo.bar.baz as qux')
    new_tree = TestTransformer.transform(tree).tree

    assert astor.to_source(tree) == 'import foo.bar.baz as qux'
    assert astor.to_source(new_tree) == import_rewrite.tpl.strip()


# Generated at 2022-06-23 22:35:29.682737
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:35:31.477155
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrite = BaseImportRewrite.transform(ast.parse('''
import x as y
from a import b
'''))

# Generated at 2022-06-23 22:35:41.833430
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    class MockTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    source = """
        import foo

        def foo():
            pass
    """
    module = ast.parse(source)

    transformer = MockTransformer(module)
    transformer.visit(module)

    import_node = module.body[0]
    assert isinstance(import_node, ast.Try)
    assert isinstance(import_node.body[0], ast.Import)
    assert import_node.body[0].names[0].name == 'bar'

    source = """
        import foo.baz

        def foo():
            pass
    """
    module = ast.parse(source)

    transformer = MockTransformer(module)
    transformer.visit(module)



# Generated at 2022-06-23 22:35:46.367462
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('pass')
    node = BaseNodeTransformer(tree)
    assert node._tree == tree


# Generated at 2022-06-23 22:35:49.557517
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from inspect import isabstract
    from abc import ABCMeta
    assert isabstract(BaseTransformer)
    assert isinstance(BaseTransformer, ABCMeta)
    assert hasattr(BaseTransformer, 'target')
    assert hasattr(BaseTransformer, 'transform')

# Generated at 2022-06-23 22:36:00.048246
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import transforms

    import_ = ast.Import(names=[
        ast.alias(
            name='mymodule',
            asname='mymodule',
        )])
    tree = ast.parse('import mymodule')
    new_tree = transforms.ImportRewrite().visit(tree)
    assert new_tree == import_


# Generated at 2022-06-23 22:36:04.051202
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    
    # Create sample data
    x = '''import threading'''
    
    # Create instance of class BaseImportRewrite
    instance = BaseImportRewrite(None)
    
    # Call method visit_Import
    z = instance.visit_Import(x)
    

# Generated at 2022-06-23 22:36:07.352913
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None
    assert BaseTransformer.transform
    try:
        BaseTransformer.transform(123)
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-23 22:36:18.638455
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class LocalTransformer(BaseImportRewrite):
        rewrites = [('collections', 'collections.abc')]

    import_rewrite = ast.Import(names=[
        ast.alias(name='collections',
                  asname=None)])

    expected_output = ast.Try(body=[
        ast.Import(names=[
            ast.alias(name='collections.abc',
                      asname=None)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[
                ast.Import(names=[
                    ast.alias(name='collections',
                              asname=None)])])],
        orelse=[],
        finalbody=[])

   

# Generated at 2022-06-23 22:36:21.733283
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class SimpleTransformer(BaseTransformer):
        target = 'python2'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    assert SimpleTransformer.transform(None) is not None

# Generated at 2022-06-23 22:36:22.217680
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:36:31.810273
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest

    import typed_ast.ast3 as ast
    from typed_ast.transforms.import_rewrite import BaseImportRewrite

    @snippet
    def original():
        import os

    def node(func):
        return func.get_body()

    class Test(unittest.TestCase):
        def test_os_to_path(self):
            module = ast.Module([
                ast.Import(names=[
                    ast.alias(name='os',
                              asname=None)])])

            BaseImportRewrite.rewrites = [('os', 'path')]
            class Test(BaseImportRewrite):
                pass

            assert node(original) == Test.transform(module).tree

            BaseImportRewrite.rewrites = [('os', 'shutil')]

# Generated at 2022-06-23 22:36:40.512975
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..tests.utils import check_node
    from ..types import CompilationTarget

    class MyTransformer(BaseTransformer):
        target = CompilationTarget.JS

    # is subclass of metaclass ABCMeta
    assert MyTransformer.__class__.__base__ is ABCMeta

    # has attribute target
    assert hasattr(MyTransformer, 'target')

    # attribute target is instance of CompilationTarget
    assert isinstance(MyTransformer.target, CompilationTarget)

    # has method transform
    assert hasattr(MyTransformer, 'transform')
    check_node(ast.parse('transform(tree)'),
               MyTransformer.transform)

