

# Generated at 2022-06-23 22:26:33.475481
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .utils import get_node
    from typed_astunparse import unparse
    tree = get_node("from my_module import name, another_name")
    BaseImportRewrite.rewrites = [('my_module', 'another_module')]
    expected = unparse(BaseImportRewrite._replace_import_from_module(tree, *BaseImportRewrite.rewrites[0]))
    assert unparse(BaseImportRewrite.transform(tree).tree).strip() == expected.strip()

# Generated at 2022-06-23 22:26:41.567610
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import collections.abc as abc

    module_name = 'collections.abc'
    node = ast.ImportFrom(module=module_name,
                          names=[ast.alias(name='Sequence', asname=None),
                                 ast.alias(name='Mapping', asname=None)],
                          level=0)

    import_rewrite_ = BaseImportRewrite(node)
    import_rewrite_.rewrites = [
        ('collections.abc', 'collections')]

    node_ = import_rewrite_.visit(node)
    assert astor.to_source(node_) == import_rewrite.get_body()[0]  # type: ignore



# Generated at 2022-06-23 22:26:46.331706
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite, 'Class BaseImportRewrite should exist'
    assert callable(BaseImportRewrite), 'Class BaseImportRewrite should be callable'
    instance = BaseImportRewrite()
    assert isinstance(instance, BaseImportRewrite), 'BaseImportRewrite should be a subclass of class BaseImportRewrite'

# Generated at 2022-06-23 22:26:57.513635
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.snippet import CodeSnippet
    from ..utils.node_transformer import node_transform
    from ..compat import parse

    import_rewrite_class = CodeSnippet('rewrite_class', 'BaseImportRewrite',
                                       indent=4,
                                       linenumbers='hide')

    class BaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')]

    code = 'import foo'

    tree = parse(code)
    result = node_transform(tree, BaseImportRewrite)
    assert result.tree.body[0].body[0].body[0].names[0].name == 'bar'


# Generated at 2022-06-23 22:27:04.803159
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test for _get_matched_rewrite()
    x = BaseImportRewrite(None)
    assert x._get_matched_rewrite(None) is None
    assert x._get_matched_rewrite('a') is None
    assert x._get_matched_rewrite('a.b') is None
    assert x._get_matched_rewrite('') is None
    assert x._get_matched_rewrite('a') == ('a', 'b')
    assert x._get_matched_rewrite('abc') == ('abc', 'def')
    assert x._get_matched_rewrite('abc.def') == ('abc', 'def')

    # Test for _replace_import_from_names
    x = BaseImportRewrite(None)
    x.dependencies = []

# Generated at 2022-06-23 22:27:05.297186
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:27:14.849624
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import_rewrite_class = type('import_rewrite',
                                (BaseImportRewrite,),
                                {'rewrites': [('x', 'z')]})
    source = '''
import x
from x import *
from x import y
from x import z as zz
from y import z
import z
'''
    tree = ast.parse(source)
    result = import_rewrite_class.transform(tree)

# Generated at 2022-06-23 22:27:17.033342
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    if transformer.target != None:
        raise AssertionError('This test failed because BaseTransformer.target is not None')

# Generated at 2022-06-23 22:27:21.939847
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    import_from = ast.ImportFrom(module='bar',
                                 names=[ast.alias(name='foo',
                                                  asname='as_foo')],
                                 level=0)

    class ImportRewriter(BaseImportRewrite):
        rewrites = [('bar', 'foo')]

    rewritten = ImportRewriter.transform(import_from)
    assert rewritten.changed



# Generated at 2022-06-23 22:27:31.698108
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import _transformation

    import_previous = ast.ImportFrom(
        module='foo.bar',
        names=[ast.alias(name='baz', asname='toto')],
        level=0)

    import_current1 = ast.ImportFrom(
        module='foo.bar.baz',
        names=[ast.alias(name='baz', asname='toto')],
        level=0)

    import_current2 = ast.ImportFrom(
        module='foo.bar',
        names=[ast.alias(name='baz', asname='toto')],
        level=0)


# Generated at 2022-06-23 22:27:34.469615
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestClass(BaseTransformer):
        pass

    instance = TestClass()

# Generated at 2022-06-23 22:27:42.740434
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    tree = ast.parse('''
        import threading
        from abc import ABC
    ''')
    class TestTransformer(BaseImportRewrite):
        rewrites = [('threading', '_threading'), ('abc', '_abc')]

    result = TestTransformer.transform(tree)

    assert result.modified
    assert astor.to_source(tree) == '''
try:
    import threading
except ImportError:
    import _threading as threading

try:
    from abc import ABC
except ImportError:
    from _abc import ABC
    '''


# Generated at 2022-06-23 22:27:44.825633
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)
    assert __class__.__name__ == 'BaseNodeTransformer'

# Generated at 2022-06-23 22:27:53.188409
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class FooImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'rewritten_foo.bar')]

    ast_node = ast.parse('from foo.bar import baz')
    FooImportRewrite().visit(ast_node)
    assert ast.dump(ast_node) == 'from rewritten_foo.bar import baz'

    ast_node = ast.parse('from foo.bar import baz, qux')
    FooImportRewrite().visit(ast_node)
    assert ast.dump(ast_node) == 'from rewritten_foo.bar import baz, qux'

    ast_node = ast.parse('from foo.bar import *')
    FooImportRewrite().visit(ast_node)

# Generated at 2022-06-23 22:27:53.699513
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:01.772507
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import os

    import astor
    import asdf

    base_import_rewrite = BaseImportRewrite([('asdf', 'os')])

    assert astor.to_source(
        base_import_rewrite.visit(ast.parse('''import asdf'''))
    ) == '''try:
    import asdf
except:
    import os'''

    assert astor.to_source(
        base_import_rewrite.visit(ast.parse('''import os'''))
    ) == '''import os'''

    assert astor.to_source(
        base_import_rewrite.visit(ast.parse('''import asdf'''))
    ) == '''try:
    import asdf
except:
    import os'''

    assert astor.to_source

# Generated at 2022-06-23 22:28:12.647812
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [
            ('test.test_types.test_visitor_utils.fake_six', 'test_six')
        ]


    orig_node = ast.import_from("test.test_types.test_visitor_utils.fake_six.A",
                                names=[ast.alias("A", "B")])

    rewrote = MyImportRewrite.visit_ImportFrom(orig_node)
    assert isinstance(rewrote, ast.Try)


# Generated at 2022-06-23 22:28:13.196099
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()



# Generated at 2022-06-23 22:28:22.547331
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse

    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six_mock')]

    class DummyImportRewrite2(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six_moves_mock')]

    class DummyImportRewrite3(BaseImportRewrite):
        rewrites = [
            ('six', 'six_mock'),
            ('six.moves', 'six_moves_mock')]

    class DummyImportRewrite4(BaseImportRewrite):
        rewrites = [
            ('six', 'six_mock'),
            ('six.moves', 'six_moves_mock'),
            ('foo.bar', 'foo_bar')]

# Generated at 2022-06-23 22:28:26.553058
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """The constructor of BaseImportRewrite should not be called.
    """
    class Broken(BaseImportRewrite):
        def __init__(self):
            # Throws TypeError
            super().__init__(None)

    with pytest.raises(TypeError):
        Broken()

# Generated at 2022-06-23 22:28:33.836477
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from typed_ast import ast3 as ast

    class T(BaseImportRewrite):
        rewrites = [('pandas', 'pandas_mock')]

    import_node = ast.parse('''
        import pandas
    ''').body[0]

    expected_import_node = ast.parse('''
    try:
        import pandas
    except ImportError:
        import pandas_mock as pandas
    ''').body[0]

    assert astor.to_source(T.transform(import_node).tree) == astor.to_source(expected_import_node)



# Generated at 2022-06-23 22:28:35.006128
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:37.747159
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    tree = astor.parse_file('tests/test_transformers/test_transformer.py')
    trans_tree = BaseNodeTransformer.transform(tree)
    assert str(trans_tree.tree) == astor.to_source(tree)


# Generated at 2022-06-23 22:28:40.881973
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..testutils import get_class_object
    c = get_class_object(BaseImportRewrite)
    assert c.dependencies == []
    assert c.rewrites == []


# Generated at 2022-06-23 22:28:41.951909
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    obj = BaseImportRewrite(ast.parse('foo'))
    assert obj is not None

# Generated at 2022-06-23 22:28:50.893452
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from .expectation import Expectation

    cls = BaseImportRewrite

    assert(cls.visit_Import(ast.Import(names=[ast.alias(name='os')])) ==
           Expectation(ast.Import(names=[ast.alias(name='os')]), False))

    assert(cls.visit_Import(ast.Import(names=[ast.alias(name='abc.os')])) ==
           Expectation(ast.Import(names=[ast.alias(name='abc.os')]), False))

    assert(cls.visit_Import(ast.Import(names=[ast.alias(name='os.path')])) ==
           Expectation(ast.Import(names=[ast.alias(name='os.path')]), False))


# Generated at 2022-06-23 22:28:54.717401
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'TEST'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])
    t = TestTransformer()
    assert t.target == 'TEST'

# Generated at 2022-06-23 22:29:04.097058
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor # type: ignore
    import astunparse # type: ignore
    from ast import ImportFrom, alias, fix_missing_locations

    # Import from with a name from rewrites
    tree = ast.parse("from foo import a, b")
    rewrites = BaseImportRewrite(tree)
    rewrites.rewrites = [("foo", "foo2")]
    result_tree = rewrites.visit(tree)
    # This is a validating test that was designed to be run against py3.6,
    # but fails against both py3.6 and py3.7.
    # Expected results:
    # try:
    #     from foo import a, b
    # except ImportError:
    #     from foo2 import a, b
    # assert astor.to_source(result_tree

# Generated at 2022-06-23 22:29:14.622717
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    ast.dump(BaseImportRewrite().ast_node(
        'import unittest')) == ast.dump(ast.Import(names=[
            ast.alias(name='unittest',
                      asname=None)]))

    ast.dump(BaseImportRewrite().ast_node(
        'import unittest as test')) == ast.dump(ast.Import(names=[
            ast.alias(name='unittest',
                      asname='test')]))

    ast.dump(BaseImportRewrite().ast_node(
        'from unittest import TestCase')) == ast.dump(ast.ImportFrom(module='unittest',
                                                                     names=[
                                                                         ast.alias(name='TestCase',
                                                                                   asname=None)],
                                                                     level=0))

   

# Generated at 2022-06-23 22:29:19.694588
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        target = CompilationTarget("2.7", "2.7")
        dependencies = []
        def visit_Module(self, node):
            return node
    tree = ast.parse("arg")
    result = TestTransformer(tree).transform(tree)
    assert result == TransformationResult(tree, False, [])

# Generated at 2022-06-23 22:29:24.317098
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import ast
    class TestBaseTransformer(BaseTransformer):
        target = '**.py'
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])
    print(TestBaseTransformer)



# Generated at 2022-06-23 22:29:26.246366
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    test_class = BaseImportRewrite()



# Generated at 2022-06-23 22:29:37.282887
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'python_compat')]

    import_from = ast.ImportFrom(module='six',
                                 names=[ast.alias(name='moves', asname='moves')],
                                 level=0)

    expected = ast.Try(body=[import_rewrite.get_body(
        previous=import_from,
        current=ast.ImportFrom(module='python_compat',
                               names=[ast.alias(name='moves', asname='moves')],
                               level=0)
    )[0]],
        handlers=[ast.ExceptHandler(type=None,
                                    name=None,
                                    body=[import_from])],
        orelse=[],
        finalbody=[])


# Generated at 2022-06-23 22:29:40.938897
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from collections import OrderedDict
    from typed_ast import ast3 as ast

    tree = ast.AST()

    assert BaseNodeTransformer(tree)._tree == tree
    assert BaseNodeTransformer(tree)._tree_changed is False
    assert BaseNodeTransformer(tree).dependencies == []
    assert BaseNodeTransformer(tree).__dict__ == OrderedDict(
            [('_tree', tree),
             ('_tree_changed', False),
             ('dependencies', [])])

# Generated at 2022-06-23 22:29:47.430252
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Case(BaseImportRewrite):
        rewrites = [('a.b', 'b.a')]

    tree = ast.parse("import a.b; from a.b import foo; from c.d import *")
    result = Case.transform(tree)
    assert result.result == """try:
    import b.a
except ImportError:
    import a.b
try:
    from b.a import foo
except ImportError:
    from a.b import foo
from c.d import *"""

# Generated at 2022-06-23 22:29:50.684358
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    t = BaseImportRewrite(None)
    assert isinstance(t, BaseNodeTransformer)
    assert isinstance(t, BaseTransformer)
    assert isinstance(t, BaseImportRewrite)
    assert isinstance(t, ast.NodeTransformer)

# Generated at 2022-06-23 22:29:53.109835
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils import unit
    inst = unit.instantiate_class(BaseNodeTransformer)
    assert isinstance(inst, BaseNodeTransformer)


# Generated at 2022-06-23 22:29:55.610361
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_1(BaseTransformer):
        def __init__(self):
            assert False

    BaseTransformer_1()

# Generated at 2022-06-23 22:29:56.206528
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:30:03.912388
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old; import old.lib')
    new_tree, changed, deps = Transformer.transform(tree)

    assert changed is True
    assert deps == Transformer.dependencies

    expected_code = '''import new; try:
    import old
except ImportError:
    import new.lib
'''

    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-23 22:30:14.564229
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.parse("""
from six.moves import http_client
from six.moves import urllib_parse

from six import text_type
import six.moves.urllib_parse

import xmlrpclib
import six
""").body
    tree = ast.Module(body=[ast.Expr(value=import_from[0])])
    result = BaseImportRewrite.transform(tree)
    assert "httplib" in result.tree.body[0].value.module
    assert "urlparse" in result.tree.body[0].value.module

    tree = ast.Module(body=[ast.Expr(value=import_from[1])])
    result = BaseImportRewrite.transform(tree)
    assert "urlparse" in result.tree.body[0].value.module

# Generated at 2022-06-23 22:30:21.606023
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import rpdb')
    result = BaseImportRewrite.transform(tree)
    assert ast.dump(result.tree) == "Try(\n    Import(names=[alias(name='rpdb', asname=None)]),\n    except=[ImportError],\n    name=None,\n    handlers=[ExceptHandler(type=Name(id='ImportError', ctx=Load()), name=None, body=[Import(names=[alias(name='rpd.b', asname=None)])])],\n    orelse=[],\n    finalbody=[])"


# Generated at 2022-06-23 22:30:25.755350
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse, dump

    tree = parse('import six')
    trans = BaseImportRewrite(tree)
    assert dump(trans.visit_Import(tree.body[0])) == 'try:\n    import six\nexcept ImportError:\n    pass\n'



# Generated at 2022-06-23 22:30:34.300420
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("import urllib.parse")
    transformed = BaseImportRewrite.transform(tree)
    assert transformed.tree.body[0].names[0].name.id == 'urllib.parse'
    assert transformed.tree.body[0].names[0].asname == None
    assert transformed.tree.body[0].names[0].name.s == 'urllib.parse'

    tree = ast.parse("import urllib.parse as parse")
    transformed = BaseImportRewrite.transform(tree)
    assert transformed.tree.body[0].names[0].name.id == 'urllib.parse'
    assert transformed.tree.body[0].names[0].asname == 'parse'

# Generated at 2022-06-23 22:30:43.895207
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    try_except = ast.Try(
        body=[ast.ImportFrom(
            module='django',
            names=[ast.alias(name='some_django_module',
                             asname='SomeDjangoModule')],
            level=0)],
        handlers=[ast.ExceptHandler(
            type=ast.Name(
                id='ImportError',
                ctx=ast.Load()),
            name=None,
            body=[ast.ImportFrom(
                module='django.some_django_module_new',
                names=[ast.alias(name='SomeDjangoModuleNew')],
                level=0)])],
        orelse=[],
        finalbody=[])

    # Replace module in import

# Generated at 2022-06-23 22:30:55.189304
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    trans = BaseImportRewrite(ast.Module(body=[]))

    assert astor.to_source(trans.visit_ImportFrom(
        ast.ImportFrom(
            module='a.b.c',
            names=[
                ast.alias(name='d', asname='e')],
            level=1))) == (
"""try:
    from c import d as e
except ImportError:
    from b.c import d as e
""")


# Generated at 2022-06-23 22:30:57.063193
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Tests constructor of BaseImportRewrite class."""
    assert BaseImportRewrite.rewrites == []


# Generated at 2022-06-23 22:31:03.700572
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'python3.3'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    transformer = TestTransformer()
    assert transformer.target == 'python3.3'
    assert transformer.transform(None) == TransformationResult(None, False, [])

# Generated at 2022-06-23 22:31:11.449791
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from tst.transformer import TstTransformer
    from ..dummy_target import DummyTransformer

    transformer = BaseTransformer()
    assert transformer.target is None

    transformer = TstTransformer(CompilationTarget.JSCRIPT)
    assert transformer.target == CompilationTarget.JSCRIPT

    transformer = DummyTransformer(CompilationTarget.PYTHON)
    assert transformer.target == CompilationTarget.PYTHON



# Generated at 2022-06-23 22:31:14.909538
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    for t in (BaseNodeTransformer, BaseImportRewrite):
        inst = t("tree")
        assert inst._tree == "tree", t
        assert inst._tree_changed == False, t


# Generated at 2022-06-23 22:31:16.682177
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer(): # type: () -> None
    import typed_ast.ast3 as ast
    tree = ast.stmt()
    BaseNodeTransformer(tree)

# Generated at 2022-06-23 22:31:19.794597
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    try:
        BaseImportRewrite()
        raise Exception("Should be abstract class")
    except Exception as e:
        assert "Can't instantiate abstract" in str(e)

# Generated at 2022-06-23 22:31:31.073015
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import unittest

    class TestTransformer(BaseImportRewrite):
        rewrites = [('six', 'six_route')]

    class TestImportRewrite(unittest.TestCase):
        def test_import(self):
            import astor
            tree = ast.parse('import six')
            expected_tree = ast.parse('''
            try:
                import six
            except ImportError:
                import six_route
            ''')
            transformed = TestTransformer.transform(tree).tree
            self.assertEqual(astor.to_source(expected_tree),
                             astor.to_source(transformed))

        def test_import_as(self):
            import astor
            tree = ast.parse("import six as something_else")

# Generated at 2022-06-23 22:31:31.722273
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:31:42.196816
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class _BaseImportRewrite(BaseImportRewrite):
        rewrites = []

    import astor
    code = """
    import a
    import b as c
    from x import y
    from x import z
    from x import *
    """
    orig = astor.code_to_ast(code)
    tree = ast.parse(code)
    inst = _BaseImportRewrite(tree)
    inst.visit(tree)
    assert astor.to_source(tree).strip() == astor.to_source(orig).strip()


# Generated at 2022-06-23 22:31:43.345450
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    foo = BaseTransformer()
    assert foo.target is None



# Generated at 2022-06-23 22:31:53.937217
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transforms.import_rewrites import visit_ImportFrom as func
    assert func(ast.ImportFrom(
        module='pytest',
        names=[
            ast.alias(name='test', asname='test')],
        level=None)) == ast.ImportFrom(
        module='pytest',
        names=[
            ast.alias(name='test', asname='test')],
        level=None)

    assert func(ast.ImportFrom(
        module='pytest',
        names=[
            ast.alias(name='test', asname='test')],
        level=None)) == ast.ImportFrom(
        module='pytest',
        names=[
            ast.alias(name='test', asname='test')],
        level=None)


# Generated at 2022-06-23 22:31:56.033099
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    with pytest.raises(NotImplementedError):
        BaseTransformer.transform(None)


# Generated at 2022-06-23 22:32:04.240141
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    def test_helper(node, expected):
        instance = BaseImportRewrite(None)
        instance._tree_changed = False
        result = instance.visit_ImportFrom(node)
        assert result == expected
        instance.generic_visit(node)  # This calls the method BaseImportRewrite_visit_ImportFrom
        assert result == expected

    import ast
    import_from = ast.ImportFrom(module='datetime.datetime',
                                 names=[ast.alias(name='datetime')])
    expect = ast.ImportFrom(module='datetime.datetime.time',
                            names=[ast.alias(name='datetime')])
    expect_import = ast.ImportFrom(module='datetime',
                                   names=[ast.alias(name='datetime')])

# Generated at 2022-06-23 22:32:05.106729
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert True

# Generated at 2022-06-23 22:32:16.525245
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget

    from ..transformers.python_3 import FUTURE_IMPORT

    class TestImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PY2
        rewrites = [('six.moves', 'six')]

    tree = ast.parse(FUTURE_IMPORT + 'from six.moves import map')
    result = TestImportRewrite().transform(tree)
    assert result.should_save
    assert 'import six' in ast.dump(result.tree)
    assert 'from six import map' in ast.dump(result.tree)

    tree = ast.parse(FUTURE_IMPORT + 'from six.moves import foo as bar, map')
    result = TestImportRewrite().transform(tree)
    assert result.should_save

# Generated at 2022-06-23 22:32:19.646545
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert hasattr(BaseNodeTransformer, 'visit')
    assert hasattr(BaseNodeTransformer, 'visit_Name')
    assert hasattr(BaseNodeTransformer, 'visit_Str')



# Generated at 2022-06-23 22:32:28.552657
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    tree = ast.parse('from six.moves import map, filter')
    BaseImportRewrite.transform(tree)
    assert ast.dump(tree) == \
        "Module(body=[Try(body=[ImportFrom(module='itertools', names=[alias(name='chain', asname=None)], level=0)], handl" \
        "ers=[ExceptHandler(type=Name(id='ImportError', ctx=Load()), name='err', body=[ImportFrom(module='six.moves', na" \
        "mes=[alias(name='map', asname='map'), alias(name='filter', asname='filter')], level=0)])], orelse=[], finalbo" \
        "dy=[])])"



# Generated at 2022-06-23 22:32:40.151181
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class ClassA(BaseTransformer):
        def __init__(self, a):
            super().__init__()
            self.a = a

    class ClassB(ClassA, metaclass=ABCMeta):
        def __init__(self, a, b):
            super().__init__(a)
            self.b = b

    class ClassC(ClassB):
        target = CompilationTarget.Python2
        def __init__(self, a, b, c):
            super().__init__(a, b)
            self.c = c

    a = ClassA(1)
    assert isinstance(a, ClassA)

    b = ClassB(1, 2)
    assert isinstance(b, ClassB)

    c = ClassC(1, 2, 3)

# Generated at 2022-06-23 22:32:44.337046
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class N(BaseNodeTransformer): pass
    with pytest.raises(NotImplementedError):
        N.transform(None)
    assert N(None).dependencies == []


# Generated at 2022-06-23 22:32:47.037308
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None

    assert BaseTransformer.transform.__qualname__ == 'BaseTransformer.transform'


# Generated at 2022-06-23 22:32:54.485371
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    imports = [
        ast.ImportFrom(
            module='foo',
            names=[ast.alias(name='bar', asname=None), ast.alias(name='baz', asname=None)],
            level=0),
        ast.ImportFrom(
            module='foo',
            names=[ast.alias(name='bar', asname=None), ast.alias(name='biz', asname=None)],
            level=0),
        ast.ImportFrom(
            module='baz',
            names=[ast.alias(name='biz', asname=None)],
            level=0),
        ast.ImportFrom(
            module='foo.bar',
            names=[ast.alias(name='baz', asname=None)],
            level=0),
    ]

# Generated at 2022-06-23 22:32:59.553831
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import sys
    class Derived(BaseImportRewrite):
        rewrites = [(sys.modules[BaseImportRewrite.__module__].BaseImportRewrite.__name__, "types.BaseImportRewrite")]
    
    # lines[0] for test_BaseImportRewrite_import_rewrite
    Derived(None)

# Generated at 2022-06-23 22:33:06.487160
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    old = ast.parse("""
from foo import bar, baz
from foo import *
from foo.baz import *
from foo.bar import qux as quux
from foo.bar.baz import qux as quux
""")
    rewrites = [
        ('foo', 'foo_rewrite'),
        ('foo.bar', 'foo_rewrite.bar'),
        ('foo.baz', 'foo_rewrite.baz'),
    ]

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    new = TestImportRewrite.transform(old)[0]


# Generated at 2022-06-23 22:33:16.811445
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('a', 'b'),
            ('c', 'd'),
            ('e', 'f')
        ]

    tree = ast.parse("""
    import a, b
    from a import x, y
    from a.module import a, b, c
    from c import x, d
    """)

    result = TestTransformer.transform(tree)

# Generated at 2022-06-23 22:33:17.446532
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite is not None

# Generated at 2022-06-23 22:33:22.448671
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    class FakeTransformer(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib.re')]

    fake_tree = ast.parse('''
import urllib.request
''')
    result = FakeTransformer.transform(fake_tree)
    assert result.tree.body[0].value.names[0].name == 'urllib.re'
    assert not result.error
    assert result.changed


# Generated at 2022-06-23 22:33:24.811353
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    """
    test_BaseTransformer
    """
    # BaseTransformer.transform() is abstract
    with pytest.raises(TypeError):
        test = BaseTransformer()


# Generated at 2022-06-23 22:33:26.820413
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target == None



# Generated at 2022-06-23 22:33:27.557531
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()


# Generated at 2022-06-23 22:33:30.458398
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite(None).visit(None) is None
    assert BaseImportRewrite(None).visit(ast.Module(body=[])) == ast.Module(body=[])

# Generated at 2022-06-23 22:33:31.352385
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.rewrites == []

# Generated at 2022-06-23 22:33:42.769011
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse('import foo')
    result = TestRewrite.transform(tree)
    assert not result.changed

    tree = ast.parse('import six')
    result = TestRewrite.transform(tree)
    assert result.changed
    assert result.tree == ast.parse('try:\n    import six\nexcept ImportError:\n    import six.moves as six')

    tree = ast.parse('import six as foo')
    result = TestRewrite.transform(tree)
    assert result.changed
    assert result.tree == ast.parse('try:\n    import six as foo\nexcept ImportError:\n    import six.moves as foo')

    tree = ast.parse('import six.bar')

# Generated at 2022-06-23 22:33:50.559335
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..compilers.python import PythonTarget as P
    class ImportRewriter(BaseImportRewrite):
        rewrites = [
            ('re', 'regex')
        ]
        target = P
    tree = ast.parse('from re import compile', 'test.py')
    ImportRewriter.transform(tree)
    assert ast.dump(tree) == "try:\n    from re import compile\nexcept ImportError:\n    from regex import compile"
    tree = ast.parse('import re', 'test.py')
    ImportRewriter.transform(tree)
    assert ast.dump(tree) == "try:\n    import re\nexcept ImportError:\n    import regex"
    tree = ast.parse('from re.sub.subsub import sub', 'test.py')
    ImportRewriter.transform(tree)
    assert ast

# Generated at 2022-06-23 22:33:52.110321
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt is not None


# Generated at 2022-06-23 22:34:00.631929
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('os', 'os.path')]

    node = ast.Import(names=[ast.alias(name='os')])
    visitor = Rewrite(ast.parse(""))
    assert visitor.visit(node) == ast.Try(
        body=[ast.Import(names=[ast.alias(name='os.path')])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            name=None,
            body=[ast.Import(names=[ast.alias(name='os')])])],
        orelse=[],
        finalbody=[])



# Generated at 2022-06-23 22:34:03.634962
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer(): # type: () -> None
    import astor
    tree = ast.parse("def a(): pass")
    assert astor.to_source(BaseNodeTransformer(tree).tree) == 'def a(): pass'


# Generated at 2022-06-23 22:34:12.749689
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class UnitTest(BaseImportRewrite):
        rewrites = [('unicodedata', 'unicodedata2')]
        def __init__(self):
            self.code = """
            import unicodedata
            import unicodedata as ud
            from unicodedata import __all__
            from unicodedata import __all__ as ud_all
            from unicodedata.foo import bar
            from unicodedata.foo import bar as bla
            """

# Generated at 2022-06-23 22:34:14.318492
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    with pytest.raises(TypeError):
        BaseImportRewrite()

# Generated at 2022-06-23 22:34:22.417550
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.compiler import compile

    class TestTransformer(BaseImportRewrite):
        rewrites = [('requests.sessions', 'aiohttp.client')]
    test_tree = ast.parse("""from requests.sessions import Session, method_something
from requests.sessions import *
from requests import sessions
from requests.sessions import method_nothing
from requests import sessions as s""")
    new_tree = TestTransformer.transform(test_tree)
    assert compile(new_tree) == """from aiohttp.client import Session, method_something
from aiohttp.client import *
from requests import sessions
from aiohttp.client import method_nothing
from requests import sessions as s""", compile(new_tree)



# Generated at 2022-06-23 22:34:31.549595
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    src = """
    import foo
    import foo.bar
    import foooo.barrrr
    """
    parsed = ast.parse(src)

    transformed = Transformer.transform(parsed)
    assert transformed.tree == '''
    try:
        __import__('foo')
    except ImportError:
        __import__('bar')
    try:
        __import__('foo.bar')
    except ImportError:
        __import__('bar.bar')
    import foooo.barrrr
    '''
    assert transformed.changed



# Generated at 2022-06-23 22:34:39.048856
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import astor.astunparse
    import typing
    from ..utils.text import dedent

    class MyTransformer(BaseImportRewrite):
        rewrites = [
            ('urllib.request', 'urllib.urlopen'),
            ('urllib.parse', 'urllib.urlparse')
        ]


# Generated at 2022-06-23 22:34:46.301274
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from open_eded import CompilationTarget
    from ..utils.ast_utils import create_tree
    from ..utils.utils import get_python_version
    from ..utils.snippet import snippet
    from ..utils.project_loader import ProjectLoader
    from abc import ABCMeta, abstractmethod
    import ast
    import sys
    import os
    import math

    class BaseTransformer(metaclass=ABCMeta):
        target = None  # type: CompilationTarget

        @classmethod
        @abstractmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    class BaseNodeTransformer(BaseTransformer, ast.NodeTransformer):
        dependencies = []  # type: List[str]

        def __init__(self, tree: ast.AST) -> None:
            super().__init__

# Generated at 2022-06-23 22:34:57.131812
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('json', 'ujson')]

    node = astor.parse('import json').body[0]  # type: ast.Import
    assert (TestTransformer.transform(node).tree == astor.parse("""
try:
    import json
except ImportError:
    import ujson
    json = ujson
    """).body[0])

    node = astor.parse('import json.tool').body[0]  # type: ast.Import
    assert (TestTransformer.transform(node).tree == astor.parse("""
try:
    import json.tool
except ImportError:
    import ujson.tool
    json.tool = ujson.tool
    """).body[0])


# Generated at 2022-06-23 22:35:01.144948
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class _TestTransformer(BaseNodeTransformer):
        # type: ignore
        pass

    tree = ast.parse('1')  # type: ignore
    transformer = _TestTransformer(tree)

    assert transformer._tree == tree
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:35:02.315341
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite is not None

# Generated at 2022-06-23 22:35:10.280840
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..conftest import get_source, get_tree

    class Rewriter(BaseImportRewrite):
        rewrites = [('os', 'pathlib')]

    source = get_source('''
        import os
        import os.path
        import os.path.abc
        import os.path.abc.def
    ''')

    tree = get_tree(source)
    Rewriter.transform(tree)


# Generated at 2022-06-23 22:35:11.035272
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite([],())

# Generated at 2022-06-23 22:35:13.863676
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrites = [('re.compile', 'regex.compile'), ('six.string_types', 'six.string_types')]
    class ImportRewrite(BaseImportRewrite):
        rewrites = rewrites
    
    assert ImportRewrite.rewrites == rewrites
    assert issubclass(ImportRewrite, BaseImportRewrite)

# Generated at 2022-06-23 22:35:22.268135
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    given = ast.parse('from datetime import datetime')
    expected = ast.parse(
        'try:\n'
        '    from datetime import datetime\n'
        'except ImportError:\n'
        '    from dateutil import datetime')
    class Rewrite(BaseImportRewrite):
        rewrites = [('datetime', 'dateutil')]

    result = Rewrite.transform(given)
    assert result.changed
    assert ast.dump(result.tree, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-23 22:35:29.374052
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class NewTransformer(BaseTransformer):
        target = 'test_test'
        # noinspection PyUnusedLocal
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass

    assert NewTransformer.target == 'test_test'
    assert issubclass(NewTransformer, BaseTransformer)


# Generated at 2022-06-23 22:35:29.949495
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass #TODO

# Generated at 2022-06-23 22:35:40.447783
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    tree = ast.parse('''
import first
import second

from first.module import first_module_1
from first.module import first_module_2

import third
from third.module import third_module

from first import second

from something.else import module
    ''')
    transformer = BaseNodeTransformer(tree)
    assert transformer.visit(tree) is tree
    assert transformer._tree_changed is False
    assert astor.to_source(tree) == '''
import first
import second

from first.module import first_module_1
from first.module import first_module_2

import third
from third.module import third_module

from first import second

from something.else import module
    '''

    class ImportRewrite(BaseImportRewrite):
        rewrit

# Generated at 2022-06-23 22:35:50.282908
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget

    target = CompilationTarget.python_37
    assert BaseImportRewrite.transform(
        ast.parse(
            'from future import *',
            filename='program.py'
        ),
        target
    ).tree == ast.parse(
        '''\
try:
    from future import *
except ImportError:
    from past import *
'''
    )

    assert BaseImportRewrite.transform(
        ast.parse(
            'from future.utils import *',
            filename='program.py'
        ),
        target
    ).tree == ast.parse(
        '''\
try:
    from future.utils import *
except ImportError:
    from past.utils import *
'''
    )


# Generated at 2022-06-23 22:35:51.297936
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # type: () -> None
    BaseImportRewrite()

# Generated at 2022-06-23 22:36:01.740646
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('fizz', 'buzz')]
    
    source = 'from foo import *\nfrom foo.bar import foo, bar as baz\nfrom fizz.buzz import l1\nfrom foo import b'
    tree = ast.parse(source)
    
    expected_source = '''
from bar import *
try:
    from foo.bar import foo, bar as baz
    from fizz.buzz import l1
except ImportError:
    from bar.bar import foo, bar as baz
    from buzz.buzz import l1
    from bar import b'''
    
    TestBaseImportRewrite.transform(tree)
    

# Generated at 2022-06-23 22:36:02.817839
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.AST())

# Generated at 2022-06-23 22:36:04.760503
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..tests.transformer import test_BaseNodeTransformer
    test_BaseNodeTransformer()


# Generated at 2022-06-23 22:36:09.450277
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    node = ast.Import(names=[
        ast.alias(name='test',
                  asname='test_1')
    ])
    tree = ast.parse(astor.to_source(node))
    assert BaseImportRewrite.transform(tree).tree != tree



# Generated at 2022-06-23 22:36:20.328359
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget
    from ..utils import get_module_formatter
    from .Python3Parser import Python3Parser
    from .base import BaseCompiler

    import astor
    import sys

    class DummyCompiler(BaseCompiler):
        target = CompilationTarget('dummy')
        name = 'dummy'

    source = """
import foo.bar
from foo import bar
from foo.bar import Baz
from foo.bar import *
from foo.bar import Baz
from foo.baz import Bar
from foo.baz import *
from foo import baz as baz2
from foo import baz

    """

    tree = Python3Parser().parse(source)
    dummy_compiler = DummyCompiler(tree)
    tree = dummy_compiler.compile()

    print('=' * 10)
   

# Generated at 2022-06-23 22:36:24.037362
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('print(1)')
    base_node_transformer = BaseNodeTransformer(tree)
    assert base_node_transformer._tree == tree
    assert base_node_transformer.dependencies == []
    assert base_node_transformer.target is None
    assert base_node_transformer.rewrites == []


# Generated at 2022-06-23 22:36:27.091878
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import inspect
    import ast
    module = inspect.getmodule(BaseImportRewrite)
    print(ast.dump(ast.parse(inspect.getsource(module))))