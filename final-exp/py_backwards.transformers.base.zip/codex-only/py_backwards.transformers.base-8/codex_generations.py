

# Generated at 2022-06-23 22:26:39.517438
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        def visit_Num(self, node):
            if node.n == 0:
                return node
            return ast.Num(n=node.n - 1)

    from typed_ast import ast3
    tree = ast3.parse('var = 1 + 0')
    result = MyTransformer.transform(tree)
    assert result.new_tree == ast3.parse('var = 1 + 0')
    assert result.new_tree != tree
    assert not result.tree_changed
    assert result.dependencies == []



# Generated at 2022-06-23 22:26:48.182910
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from .test_rewrites import BaseImportRewrite as TestRewrite
    test_rewrites = [(from_, to) for from_, to in TestRewrite.rewrites
                     if from_ != 'sqlalchemy.testing'
                     and from_ != 'sqlalchemy.engine'
                     and from_ != 'sqlalchemy.orm'
                     and from_ != 'sqlalchemy.testing.mock'
                     and from_ != 'sqlalchemy.testing._fixtures']
    import_ast = ast.parse('from sqlalchemy import testing\nfrom sqlalchemy import select')
    assert import_ast
    rewrite = TestRewrite(import_ast)
    assert rewrite
    import_ast = rewrite.visit(import_ast)
    assert import_ast

# Generated at 2022-06-23 22:27:00.450861
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..config import config
    from ..utils.test_utils import (
        assert_equals, assert_not_equals, TEST_USER_SCRIPT_PATH)

    class X(BaseImportRewrite):
        rewrites = [('lib.other', 'lib.new')]


# Generated at 2022-06-23 22:27:01.672458
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    x = BaseTransformer()()
    



# Generated at 2022-06-23 22:27:10.943672
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget
    from ..utils.snippet import body as snippet
    from ..utils.snippet import body_ast as snippet_ast
    from .analyser import Analyser
    from .rewriter import Rewriter
    from .transformer import Transformer
    from ..utils.disassembler import disassemble


    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', 'six_moves')
        ]

    transformer = Transformer([
        ImportRewrite
    ])

    analyser = Analyser()


# Generated at 2022-06-23 22:27:21.116001
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse(
        'from datetime import datetime, time'
    )

    class TestTransformer(BaseImportRewrite):
        rewrites = [('datetime', 'delorean')]

    new_tree = TestTransformer.transform(tree).tree

# Generated at 2022-06-23 22:27:24.972006
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite(tree = '[]')
    assert isinstance(instance, BaseImportRewrite)
    assert isinstance(instance, BaseNodeTransformer)
    assert isinstance(instance, BaseTransformer)
    assert instance._tree == '[]'
    assert instance._tree_changed == False
    assert instance.dependencies == []
    assert instance.rewrites == []

# Generated at 2022-06-23 22:27:35.088309
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast.ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    # import foo.bar
    import_foo_bar = ast.parse('import foo.bar').body[0] # type: ast.Import

    # import foo -> import bar
    import_foo = ast.parse('import foo').body[0] # type: ast.Import

    # from foo import bar
    from_foo_import_bar = ast.parse('from foo import bar').body[0] # type: ast.ImportFrom

    # from foo import bar, baz
    from_foo_import_bar_baz = ast.parse('from foo import bar, baz').body[0] # type: ast.ImportFrom

    # from foo import *
    from_foo_import_

# Generated at 2022-06-23 22:27:39.031297
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Try(self, node):
            return ast.Try()
    assert TestTransformer(ast.Module([ast.Try()])).transform().tree == ast.Module([ast.Try()])


# Generated at 2022-06-23 22:27:42.785047
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    class MyRewrite(BaseImportRewrite):
        rewrites = [(u'os', u'path')]
    a = ast.parse(u'import os')
    a = MyRewrite.transform(a)
    print(a)



# Generated at 2022-06-23 22:27:46.497099
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import Six")
    transformer = BaseImportRewrite()
    result = transformer.transform(tree)
    assert result.tree == ast.parse("""
try:
    import Six
except ImportError:
    import six as Six
""")



# Generated at 2022-06-23 22:27:47.845088
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-23 22:27:49.690783
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # form of assert True, "some message"
    assert True


# Generated at 2022-06-23 22:27:50.926854
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget.APPLICATION
    BaseTransformer.target = target
    assert target == BaseTransformer.target

# Generated at 2022-06-23 22:27:59.689202
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module'),
            ('old_module.submodule', 'new_module.submodule'),
        ]
    node = ast.parse("import old_module")
    result = Transformer.transform(node)
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'old_module'
    assert result.tree.body[0].body[0].body[1].value.names[0].name == 'new_module'

    node = ast.parse("import old_module.submodule")
    result = Transformer.transform(node)

# Generated at 2022-06-23 22:28:00.933461
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:28:04.761676
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .. import ast_utils

    tree = ast_utils.parse('1 + 2')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:28:14.776599
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test in case we replace module name
    tree = ast.parse('''
    from os import path
    ''')
    class Test(BaseImportRewrite):
        rewrites = [
            ('os', 'pathlib')
        ]
    t = Test(tree)
    result = t.visit_ImportFrom(tree.body[0])
    assert isinstance(result, ast.Try)
    assert result.body[0].value.module == 'pathlib'
    assert result.body[0].value.level == 0
    assert result.body[0].value.names[0].name == 'path'
    assert result.body[0].value.names[0].asname is None

    # Test in case we only change name of imported module

# Generated at 2022-06-23 22:28:15.712156
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass



# Generated at 2022-06-23 22:28:16.272885
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:20.666535
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.testing import TestCase

    class BaseNodeTransformer_test_class(BaseNodeTransformer):
        def visit_Load(self, node):
            return node

    with TestCase() as test:
        test.assertIsInstance(BaseNodeTransformer_test_class(None), BaseNodeTransformer_test_class)


# Generated at 2022-06-23 22:28:31.837695
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import parse_snippet

    class DummySubclass(BaseImportRewrite):
        rewrites = [('old', 'new')]
        def __init__(self):
            pass

    code = 'from old import a, b'
    ast_node = parse_snippet(code)
    class_instance = DummySubclass()
    result = class_instance.visit_ImportFrom(ast_node)

# Generated at 2022-06-23 22:28:38.841045
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .somemodule.submodule import submod
    from .somemodule import mod

    tree = ast.parse('from .somemodule import mod\nfrom .somemodule.submodule import submod')
    BaseImportRewrite.rewrites = [('somemodule', 'anothermodule')]
    BaseImportRewrite.transform(tree)
    assert 'from .anothermodule import mod' in ast.dump(tree)
    assert 'from .anothermodule.submodule import submod' in ast.dump(tree)

# Generated at 2022-06-23 22:28:42.450618
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse('import foo')
    class FooRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
    try:
        result = FooRewrite.visit_Import(FooRewrite(None), node)
    except NotImplementedError:
        assert False



# Generated at 2022-06-23 22:28:51.859113
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    from ..transformers.base import BaseImportRewrite
    from ..utils.snippet import to_source
    import sys

    # Using mock module for testing purpose
    if sys.version_info[:2] > (3, 4):
        import unittest.mock as mock
    else:
        import mock

    class ImportTransformer(BaseImportRewrite):
        rewrites = [('old_mod','new_mod')]

    with mock.patch('typed_ast.ast3') as mock_typed_ast:
        mock_typed_ast.ImportFrom.module = 'old_mod.mod_a'
        mock_typed_ast.ImportFrom.names = [
            ast.alias(name='obj1', asname='as_obj1')
        ]


# Generated at 2022-06-23 22:28:59.374250
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    target = 'python:3.6'
    tree = astor.parse("from unittest import TestCase, main")
    base_import_rewrite = BaseImportRewrite("unittest.case.TestCase")
    tree_changed, tree = base_import_rewrite.transform(target, tree)
    print("tree_changed:", tree_changed)
    print("tree:", astor.dump(tree))
    assert tree_changed == True
    assert astor.dump(tree) == """try:
    from unittest.case import TestCase
except ImportError:
    from unittest import TestCase
try:
    from unittest.case import main
except ImportError:
    from unittest import main""".strip()
test_BaseImportRewrite_visit_ImportFrom

# Generated at 2022-06-23 22:29:02.232671
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockTransformer(BaseImportRewrite):
        rewrites = [('os', 'test_os')]

    tree = ast.parse('import os')
    expected = ast.parse(textwrap.dedent("""\
    try:
        import os
    except ImportError:
        import test_os as os
    """).lstrip())

    assert MockTransformer.transform(tree).tree == expected



# Generated at 2022-06-23 22:29:03.599690
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a = 0')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False


# Generated at 2022-06-23 22:29:06.673299
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a=1')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree_changed == False
    assert transformer._tree == tree

# Generated at 2022-06-23 22:29:11.624833
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('xmlrpclib', 'xmlrpc.client')]

    tree = ast.parse('import xmlrpclib as xmlrpc')
    result = ImportRewrite.transform(tree)
    assert result.tree.body[0].body[0].body[0] == \
        ast.Import(names=[ast.alias(name='xmlrpc.client', asname='xmlrpc')])



# Generated at 2022-06-23 22:29:13.850146
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert BaseTransformer.transform(None) is None


# Generated at 2022-06-23 22:29:14.974814
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:29:18.358645
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("import unittest.mock\nfrom super.test import *")
    transformer = BaseImportRewrite(tree)
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-23 22:29:30.266890
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import copy
    class TestClass(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestVisitor(ast.NodeVisitor):
        def visit_Import(self, node: ast.Import):
            print(TestClass.visit_Import(TestClass, node))

    expected_result = '''\
try:
    import foo
except ImportError:
    import bar
'''

    node = ast.parse('import foo')
    TestVisitor().visit(node)
    assert ast.dump(TestClass.transform(ast.parse('import foo'))[0]) == expected_result
    assert TestClass.transform(ast.parse('import foo'))[1]

    node = ast.parse('import foo')
    TestVisitor().visit(node)
    assert ast

# Generated at 2022-06-23 22:29:36.305512
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class TestTransformer(BaseImportRewrite):
        rewrites = [('test', 'test_new')]

    import_ = ast.ImportFrom(module='test', names=[ast.alias(name='test_func', asname='test_func_a')])

    new_import_ = TestTransformer.transform(import_)[0]

    assert isinstance(new_import_, ast.Try)

    assert ast.dump(ast.Try(body=[import_],
                            handlers=[],
                            orelse=[],
                            finalbody=[])) == ast.dump(new_import_)

    # assert isinstance(new_import_, ast.Try)



# Generated at 2022-06-23 22:29:42.385797
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    class X(BaseImportRewrite):
        rewrites = [
            ('module_to_rewrite1', 'new_module1'),
            ('module_to_rewrite2', 'new_module2'),
        ]

    tree = ast.parse(
        "from module_to_rewrite1 import type1\n"
        "import module_to_rewrite2 as module2\n"
        "import module_to_rewrite3 as module3\n")
    result = X.transform(tree)

    assert isinstance(tree.body[0], ast.Import)
    assert tree.body[0].names[0].name == 'new_module1'

    assert isinstance(tree.body[1], ast.Try)
    assert isinstance(tree.body[1].body[0], ast.Import)

# Generated at 2022-06-23 22:29:49.156683
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('collections', 'six.moves')]

    tree = ast.parse('import collections')
    transformer = TestTransformer(tree)
    result = transformer.visit(tree)
    expected = ast.parse("""
try:
    import collections
except ImportError:
    import six.moves as collections
""")
    assert ast.dump(result) == ast.dump(expected)
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:29:54.645967
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    assert issubclass(BaseTransformer, ABCMeta)
    assert callable(BaseTransformer.transform)
    assert issubclass(TestTransformer, BaseTransformer)



# Generated at 2022-06-23 22:30:05.431427
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Rewrite(BaseImportRewrite):
        target = CompilationTarget.PY_3_5
        rewrites = [
            ('unittest.mock', 'mock'),
            ('foo', 'bar'),
        ]

    tree = ast.parse("""
from unittest import mock

from foo.bar import something

from foo import baz
    """)

    Rewrite.transform(tree)

    expected = """
try:
    from unittest import mock
except ImportError:
    from mock import mock

try:
    from bar.bar import something
except ImportError:
    from bar.bar import something

try:
    from bar import baz
except ImportError:
    from bar import baz
    """.strip()  # noqa: W293

    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:30:09.247777
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    try:
        # This is how we should instantiate inherited classes
        BaseNodeTransformer()
    except NotImplementedError:
        pass
    else:
        assert False, 'Constructor should have raised NotImplementedError'


# Generated at 2022-06-23 22:30:17.189443
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
import i.as_i
i.as_i.f()
    """)
    transformer = BaseImportRewrite()
    transformer.rewrites = [
        ('i.as_i', 'i'),
    ]
    tree = transformer.transform(tree)[0]
    expected_tree = ast.parse("""
try:
    import i.as_i
except ImportError:
    import i
i.f()
    """)
    assert ast.dump(tree, annotate_fields=False) == ast.dump(expected_tree,
                                                             annotate_fields=False)



# Generated at 2022-06-23 22:30:19.652492
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert hasattr(BaseNodeTransformer, '__init__')
    assert callable(BaseNodeTransformer.__init__)


# Generated at 2022-06-23 22:30:24.524435
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformerTest(BaseNodeTransformer):
        dependencies = ['module1']

        def visit_Module(self, node):
            return node

    tree = ast.parse("pass")
    result = BaseNodeTransformerTest.transform(tree)
    assert not result.tree_changed
    assert result.dependencies == ['module1']

# Generated at 2022-06-23 22:30:26.164659
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        target = 'a'
    assert A.target == 'a'

# Generated at 2022-06-23 22:30:27.559398
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(tree=None)._tree is None

# Generated at 2022-06-23 22:30:29.586045
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    expected_output = [2, 3, 4]
    assert BaseNodeTransformer._TEST_METHOD() == expected_output


# Generated at 2022-06-23 22:30:40.628059
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-23 22:30:51.877227
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.testutil import run_visitor_test
    from ..utils.testutil import check_node_class

    tree = ast.parse('import foo')
    node = tree.body[0]

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar')
        ]

    expected = ast.parse('try:\n    import foo\nexcept ImportError:\n    import bar')

    # First test case
    run_visitor_test(
        TestTransformer,
        node,
        expected,
        check_node_class=check_node_class)

    # Second test case
    tree = ast.parse('import foo.bar')
    node = tree.body[0]


# Generated at 2022-06-23 22:30:52.889189
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    x = BaseTransformer()


# Generated at 2022-06-23 22:31:01.787254
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # This is test for method visit_ImportFrom of class BaseImportRewrite.
    # It tests only one case, which is most important.

    # The test code i/o
    """
    from old_name import Name
    """
    # The expected result i/o
    """
    try:
        from old_name import Name
    except ImportError:
        from new_name import Name
    """

    # Replace old_name by new_name
    rewrite = [('old_name', 'new_name')]

    # Inner class inherited from BaseImportRewrite with rewriting plan
    class TestCase(BaseImportRewrite):
        rewrites = rewrite

    # The code snippet to be tested

# Generated at 2022-06-23 22:31:02.965943
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None)


# Generated at 2022-06-23 22:31:14.856505
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from mypy import api

    import_from = api.parse('''from typing import Optional''')
    visitor = BaseImportRewrite(import_from)
    import_from = visitor.visit(import_from)
    assert import_from._fields == ('body',)
    assert len(import_from.body) == 2
    assert import_from.body[0]._fields == ('body',)
    assert import_from.body[1]._fields == ('body',)
    assert import_from.body[0].body[0]._fields == ('names',)
    assert import_from.body[0].body[0].names[0].asname == 'Optional'
    assert import_from.body[0].body[0].names[0].name == 'typing.Optional'

# Generated at 2022-06-23 22:31:17.544226
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'py27'

    transformer = TestTransformer()
    assert transformer.target == 'py27'


# Generated at 2022-06-23 22:31:18.788480
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer is not None

# Generated at 2022-06-23 22:31:30.216947
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transformer import test_helpers

    @snippet
    class TestImportFrom(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]

    code = '''
from old_module.util import get_foo
from old_module import bar
from old_module.bar import Foo
from old_module.util import *

from old_module.bar import *

from new_module.util import get_foo
from new_module import bar
from new_module.bar import Foo
from new_module.util import *

from new_module.bar import *
'''


# Generated at 2022-06-23 22:31:36.668267
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BasicImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('import old\nfrom old import foo')
    result = BasicImportRewrite.transform(tree)

    assert result.tree == ast.parse('try:\n    import old\nexcept ImportError:\n    import new\n\ntry:\n    from old import foo\nexcept ImportError:\n    from new import foo')

# Generated at 2022-06-23 22:31:45.803140
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import Phase
    from ..utils import tree_from_string
    import_tree = tree_from_string('from mod import a')
    phase = Phase(target=CompilationTarget.PY27)
    phase.rewrites[BaseImportRewrite] = [('mod', 'mod_new')]
    phase.phases = [BaseImportRewrite]
    results = phase.transform_tree(import_tree)
    assert isinstance(results[0].node, ast.Try)
    assert isinstance(results[0].node.body[0], ast.Import)
    assert results[0].node.body[0].names[0].name == 'mod'
    assert isinstance(results[0].node.handlers[0], ast.ExceptHandler)
    assert results[0].node.handlers[0].type is None

# Generated at 2022-06-23 22:31:47.115426
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    d = BaseTransformer()
    assert d

# Generated at 2022-06-23 22:31:48.900590
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # type: ()-> None
    BaseNodeTransformer(None)

# Generated at 2022-06-23 22:31:49.610675
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()



# Generated at 2022-06-23 22:31:57.864256
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astunparse
    # Test replacement of import
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = (('foo', 'bar'),)
    tree = ast.parse('import foo')
    TestBaseImportRewrite.transform(tree)
    assert astunparse.unparse(tree) == 'try:\n    import foo\nexcept ImportError:\n    import bar'
    # Test unchanged import
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = (('foo', 'bar'),)
    tree = ast.parse('import foobar')
    TestBaseImportRewrite.transform(tree)
    assert astunparse.unparse(tree) == 'import foobar'
    # Test importing package with inner module replacement

# Generated at 2022-06-23 22:32:01.824469
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1 + 2')
    tr = BaseImportRewrite(tree)
    tree_ = tr.visit(tree)
    assert tree == tree_
    assert not tr._tree_changed

# Generated at 2022-06-23 22:32:12.583689
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrites = [
        ('old', 'new'),
        ('_old', '_new'),
    ]
    import_rewrites = BaseImportRewrite(None, rewrites=rewrites)

    assert import_rewrites._get_matched_rewrite('old') == ('old', 'new')
    assert import_rewrites._get_matched_rewrite('old.x') == ('old', 'new')
    assert import_rewrites._get_matched_rewrite('old.') == ('old', 'new')
    assert import_rewrites._get_matched_rewrite('old.x.y') == ('old', 'new')
    assert import_rewrites._get_matched_rewrite('_old') == ('_old', '_new')

# Generated at 2022-06-23 22:32:13.990172
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transform = BaseNodeTransformer(ast.parse('1'))
    assert transform is not None

# Generated at 2022-06-23 22:32:15.383827
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer()
    assert BaseTransformer.target is None


# Generated at 2022-06-23 22:32:24.148702
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # This is a unit test for the constructor of class BaseNodeTransformer (also BaseTransformer)
    # This test is to ensure that all class methods are present in BaseNodeTransformer
    class transformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__()

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            return None

        def _replace_import(self, node: ast.Import, from_: str, to: str) -> ast.Try:
            return None

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            return None


# Generated at 2022-06-23 22:32:27.311978
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # Test to wrap
    t = ast.parse('def foo(x): return x')
    class Test(BaseNodeTransformer): pass
    assert Test.transform(t) == TransformationResult(t, False, [])
    assert Test.transform(None) == TransformationResult(None, False, [])

    # Test constructor
    inst = Test(t)
    assert inst._tree_changed == False
    assert inst._tree == t

# Generated at 2022-06-23 22:32:38.768762
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class T(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz')]

    tree = ast.parse('import foo.bar')
    rewritten = T.transform(tree).tree

    assert ast.dump(rewritten) == dedent('''
        try:
            import foo.bar as bar
        except ImportError:
            import baz as bar
        ''').strip()

    tree = ast.parse('from foo import bar, bar2')
    rewritten = T.transform(tree).tree

    assert ast.dump(rewritten) == dedent('''
        try:
            from foo import bar as bar, bar2 as bar2
        except ImportError:
            from foo import bar as bar, bar2 as bar2
            from baz import bar as bar
        ''').strip()

# Generated at 2022-06-23 22:32:41.725864
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # type: () -> None
    assert isinstance(BaseImportRewrite(), BaseNodeTransformer)
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)


# Generated at 2022-06-23 22:32:43.694870
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert 'BaseImportRewrite' == BaseImportRewrite.__name__
    assert BaseImportRewrite.rewrites == []


assert 'BaseTransformer' == BaseTransformer.__name__
assert BaseTransformer.target is None

# Generated at 2022-06-23 22:32:52.856578
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import CompilationTarget

    class SubImportRewrite(BaseImportRewrite):
        target = CompilationTarget.PYPY
        rewrites = [('six', 'six')]

    source = 'import six'
    tree = ast.parse(source)
    SubImportRewrite.transform(tree)
    assert ast.dump(tree) == "Module([Try([Import(names=[alias(name='six', asname=None)])], excepts=[ImportError()], else_=[])])"

    source = 'from six import reraise'
    tree = ast.parse(source)
    SubImportRewrite.transform(tree)

# Generated at 2022-06-23 22:32:53.909610
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:32:55.059212
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-23 22:33:05.589666
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import os
    import traceback
    from textwrap import dedent
    from . import BaseImportRewrite
    
    try:
        from nose.tools import assert_equal, assert_raises
    except ImportError:
        from unittest import TestCase
        from unittest.case import expectedFailure
        from unittest.util import safe_repr
        from unittest.util import strclass
        
        from unittest.case import SkipTest

        class _AssertRaisesContext(object):
            """A context manager used to implement TestCase.assertRaises* methods."""

            def __init__(self, expected, test_case, expected_regexp=None):
                self.expected = expected
                self.failureException = test_case.failureException

# Generated at 2022-06-23 22:33:09.641557
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        pass

    @TestTransformer.transform.register  # type: ignore
    def _(tree: ast.AST) -> TransformationResult:
        return TransformationResult(tree, True, [])

    assert TestTransformer.target == CompilationTarget.parse('current')
    assert TestTransformer.transform(ast.parse('')).tree
    assert TestTransformer.transform(ast.parse('')).changed
    assert TestTransformer.transform(ast.parse('')).dependencies == []

# Generated at 2022-06-23 22:33:13.466010
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer(None)
    assert t._tree is None
    assert t._tree_changed is False


# Generated at 2022-06-23 22:33:14.109498
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:18.723320
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [('previous', 'current')]

    tree = ast.parse('import previous')
    transformer = DummyTransformer(tree)
    transformer.generic_visit(tree)
    assert transformer._tree_changed



# Generated at 2022-06-23 22:33:26.525169
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Test tree
    tree = ast.parse("import a.b.c", mode='exec')

    # Test transformer definition
    class TestTransformer(BaseImportRewrite):
        rewrites = [('a.b.c', 'd.e.f')]

    # Test transformer execution
    assert TestTransformer.transform(tree) == TransformationResult(
        tree, True, [])

    # Test expected result
    expected = ast.parse("try:\n    import a.b.c\nexcept ImportError:\n    import d.e.f", mode='exec')
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-23 22:33:27.328186
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:33:28.684977
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target is None


# Generated at 2022-06-23 22:33:31.050893
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Foo(BaseImportRewrite):
        rewrites = [('os', 'os.path')]
    assert Foo is not None

# Generated at 2022-06-23 22:33:38.933157
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astor.code_gen import to_source
    import astor

    class TestRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'bar.baz')]

    source = """
from foo.bar import baz
from foo.bar import bang, zzz
from zzzz import zzzz
from foo.bar.baz import zzzz
"""
    tree = ast.parse(source)
    result = TestRewrite.transform(tree)

    source = """
from foo.bar import baz
try:
    from foo.bar import bang, zzz
except ImportError:
    from bar.baz import bang, zzz
from zzzz import zzzz
from bar.baz import zzzz
"""
    rewritten_tree = ast.parse(source)
    assert result.tree

# Generated at 2022-06-23 22:33:42.977854
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.cst_visitors import CSTNodeTransformer

    class Tree(BaseNodeTransformer,
               CSTNodeTransformer,
               ast.NodeTransformer):
        pass

    tree = Tree()
    assert tree._tree is None
    assert tree._tree_changed is False

# Generated at 2022-06-23 22:33:45.660731
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError:
        return
    raise AssertionError("BaseTransformer() is not abstract")


# Generated at 2022-06-23 22:33:54.549562
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ast import Import
    from ..compilers.base import BaseCompiler

    class TestTransformer(BaseImportRewrite):
        rewrites = [('test', 'test2')]

    class TestCompiler(BaseCompiler):
        pass

    # Test import
    source = 'import test'
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, Import), 'Import statement is required.'

    # Apply transformer
    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.dependencies) == 1
    assert 'test2' in result.dependencies

    # Comfirm result
    rewrote = astor.to_source(result.tree)

# Generated at 2022-06-23 22:33:57.785747
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Test(BaseTransformer):
        target = None
        @classmethod
        def transform(cls, tree):
            return "hello"
    assert Test.target == None
    assert Test.transform("hello") == "hello"


# Generated at 2022-06-23 22:33:58.719053
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:34:00.304252
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('import os; print(True)')
    assert BaseNodeTransformer(tree)._tree == tree
    assert BaseNodeTransformer(tree)._tree_changed == False

# Generated at 2022-06-23 22:34:10.232643
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from textwrap import dedent
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]


# Generated at 2022-06-23 22:34:16.527479
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('from foo import bar')
    TestImportRewrite.transform(tree)

    assert str(tree) == '\ntry:\n    from foo import bar\nexcept ImportError:\n    from bar import bar'

# Generated at 2022-06-23 22:34:27.214803
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('past', 'future'),
            ('past.test', 'future.test')
        ]

    node = ast.parse('''from past.test import *''')
    new_node = Transformer.transform(node).tree
    result = ast.dump(new_node)
    expected = "Try(\n    body=[\n        ImportFrom(module='future.test', names=[alias(name='*', asname=None)], level=0)\n    ],\n    orelse=[],\n    finalbody=[\n        ImportFrom(module='past.test', names=[alias(name='*', asname=None)], level=0)\n    ]\n)"
    assert result == expected



# Generated at 2022-06-23 22:34:28.451163
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    assert transformer.rewrites == []
    assert transformer.dependencies == []


# Generated at 2022-06-23 22:34:30.947100
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not BaseTransformer().target,\
        'target parameter of class BaseTransformer is not empty'

# Unit tests for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:34:35.112411
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    """Test constructor."""
    from ..utils.tests.testcase import CompileTestCase

    class TestTransformer1(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            raise NotImplementedError

    tt = TestTransformer1(ast.Module(body=[]))
    assert tt is not None



# Generated at 2022-06-23 22:34:45.466983
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    def test_node(node: ast.AST, rewrite: Tuple[str, str]) -> None:
        test_transformer = BaseImportRewrite()
        test_transformer.rewrites = [rewrite]
        result = test_transformer.transform(node)

        assert result.changed is True
        assert isinstance(result.node, ast.Try)
        assert isinstance(result.node.body[0], ast.Import)
        assert result.node.body[0].names[0].name == rewrite[0]

    test_node(
        ast.Import(names=[ast.alias(name='a', asname='b')]),
        ('a', 'a.b')
    )


# Generated at 2022-06-23 22:34:53.924906
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse('from foo.bar import x, y, z')
    rewrites = [
        ('foo', 'foo2'),
        ('foo.bar', 'foo.bar2')]
    expected_result = """
try:
    from foo2.bar import x, y, z
except ImportError:
    from foo2.bar2 import x, y, z
"""

    class TestImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    node_new = TestImportRewrite.transform(node).tree

    assert ast.dump(node_new) == expected_result


# Generated at 2022-06-23 22:34:55.131295
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite()
    assert x.rewrites == BaseImportRewrite.rewrites


# Generated at 2022-06-23 22:34:55.750441
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:34:56.465303
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:34:57.093500
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass

# Generated at 2022-06-23 22:35:07.704701
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast import parse
    from ..utils.test_utils import test_transformer
    from ..utils.test_utils import return_ast

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('future.utils', 'six'),
        ]

    test_transformer(Rewrite, 'import future.utils',
                     'from six import *\ntry:\n    from future.utils import *\nexcept ImportError:\n    pass')

    test_transformer(Rewrite, 'import future',
                     'from __future__ import *\ntry:\n    import future\nexcept ImportError:\n    pass')


# Generated at 2022-06-23 22:35:17.339420
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestNodeTransformer(BaseImportRewrite):
        # The one of rewrites should match `import foo.bar`
        rewrites = [
            ('foo', 'bar'),
            ('foo', 'some_thing'),
        ]

    tree = ast.parse('import foo.bar')
    expected_tree = ast.parse('try:\n    import foo.bar\nexcept ImportError:\n    import bar.bar')

    result = TestNodeTransformer.transform(tree)
    assert result == TransformationResult(expected_tree, True, [])



# Generated at 2022-06-23 22:35:18.448169
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestClass(BaseTransformer):
        pass
    assert TestClass.transform is BaseTransformer.transform


# Generated at 2022-06-23 22:35:19.253550
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(ast.AST())

# Generated at 2022-06-23 22:35:23.773743
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typped._utils.testing import get_visitor_output
    from . import simple

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    class TestSimple(simple.Simple):
        target = 'python'

    output = get_visitor_output(TestBaseImportRewrite(), TestSimple())
    assert 'from six.moves import *' in output
    assert 'except (ImportError):' in output
    assert 'from six import *' in output


# Generated at 2022-06-23 22:35:25.350645
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None

# Generated at 2022-06-23 22:35:28.127482
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(None)
    assert transformer._tree is None
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:35:38.553596
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformer = TestImportRewrite(tree)
    result = transformer.visit_Import(tree.body[0])
    # import foo as foo
    # try:
    #     import bar as foo
    # except ImportError:
    #     import foo as foo

    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.Import)
    assert result.body[0].names[0].name == 'bar'
    assert result.body[0].names[0].asname == 'foo'
    assert isinstance(result.handlers[0], ast.ExceptHandler)

# Generated at 2022-06-23 22:35:47.138916
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    def compare(from_, to, import_):
        tree = ast.parse(import_)
        assert tree is not None
        assert isinstance(tree, ast.Module)
        assert isinstance(tree.body[0], ast.Import)

        transformer = BaseImportRewrite(tree)
        transformer.rewrites = [(from_, to)]

        result = transformer.visit_Import(tree.body[0])
        assert result is not None
        assert isinstance(result, ast.Try)

        expected = ast.Try(body=[],
                           handlers=[],
                           orelse=[],
                           finalbody=[])
        assert result == expected

    compare('six', 'foo', 'import six')
    compare('six', 'foo', 'import six.foo_bar')

# Generated at 2022-06-23 22:35:48.592899
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__module__ == __name__


# Generated at 2022-06-23 22:35:56.662051
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from unittest import TestCase
    from ..utils.compile import compile_

    class Replace(BaseImportRewrite):
        rewrites = [('replaced', 'new')]

    tree = ast.parse("""
    import replaced
    """)
    expect = ast.parse("""
    try:
        import replaced
    except ImportError:
        import new
    """)

    tree = Replace.transform(tree).tree
    assert compile_(tree, 'test', 'exec') == compile_(expect, 'test', 'exec')



# Generated at 2022-06-23 22:36:00.152456
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('class ClassB: ...')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree, "tree initialization"
    assert transformer._tree_changed == False, "tree_changed initialization"


# Generated at 2022-06-23 22:36:08.697716
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.module_mock import ModuleMock
    from ..utils.declarations import get_declarations
    
    class ReturnOnly(BaseImportRewrite):
        rewrites = [('random', 'test_random')]
    
    declarations = get_declarations(ReturnOnly.transform(ModuleMock(
        f'''
        from random import *
        from random import choice, shuffle
        from test_random import chice
        from other_module import something
        '''
    ))[0]._tree)
    
    assert declarations == {'choice', 'shuffle', 'test_random.choice'}



# Generated at 2022-06-23 22:36:19.779679
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module='urllib.request',
                                 names=[ast.alias(name='urlopen'),
                                        ast.alias(name='Request')],
                                 level=0)
    t = BaseImportRewrite()
    node = t.visit_ImportFrom(import_from)
    assert isinstance(node, ast.ImportFrom)
    assert node.module == 'urllib.request'
    assert len(node.names) == 2
    assert node.names[0].name == 'urlopen'
    assert node.names[0].asname is None
    assert node.names[1].name == 'Request'
    assert node.names[1].asname == 'Request'
    assert node.level == 0


# Generated at 2022-06-23 22:36:30.526283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_node = ast.parse('import os')
    import_node_rewrote = ast.parse('try:\n    import os\nexcept ImportError:\n    import os')

    def test_case(from_, to):
        rewrites = [(from_, to)]
        instance = BaseImportRewrite(ast.Module([]))
        instance.rewrites = rewrites
        expected_result = ast.fix_missing_locations(import_node_rewrote)
        assert instance.visit(import_node) == expected_result

    test_case('os', 'os_new')
    test_case('os.path', 'os_new.path')
    test_case('os.path', 'os.path_new')
    test_case('os', 'os.path_new')


# Generated at 2022-06-23 22:36:33.074284
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..ast_manipulator import AstManipulator
    tree = AstManipulator('a = 1').tree
    BaseNodeTransformer(tree)