

# Generated at 2022-06-23 22:26:28.238052
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer()

# Generated at 2022-06-23 22:26:38.448845
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class MockBaseImportRewrite(BaseImportRewrite):
        def __init__(self, module_name):
            super().__init__(None)
            self.module_name = module_name

    d = {'MockModule': 'SomeReplacement'}

    MockBaseImportRewrite.rewrites = [(d[k], k) for k in d]
    import_node = ast.parse('import MockModule').body[0]
    mock_instance = MockBaseImportRewrite(None)
    result = mock_instance.visit_Import(import_node)
    assert result.body[0].value.func.value.id == 'SomeReplacement'

    MockBaseImportRewrite.rewrites = [('MockModule.Some', 'SomeReplacement')]
    import_node = ast.parse('import MockModule.Some').body

# Generated at 2022-06-23 22:26:42.004397
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test input
    test_case_input = isinstance(BaseImportRewrite, BaseNodeTransformer)

    # Expected output
    expected_result = True

    # Assert
    assert expected_result == test_case_input


# Generated at 2022-06-23 22:26:45.482879
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class BaseNodeTransformerTest(BaseNodeTransformer):
        pass

    a = BaseNodeTransformerTest(1)
    assert a._tree_changed is False
    assert a.tree == 1


# Generated at 2022-06-23 22:26:56.810226
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = ast.parse("""
from __future__ import absolute_import
import re
import sys
import os.path

""")
    expected_ast = ast.parse("""
from __future__ import absolute_import

try:
    import re
except ImportError:
    from six import re  # type: ignore

try:
    import sys
except ImportError:
    from six import sys  # type: ignore

try:
    import os.path
except ImportError:
    from six import path  # type: ignore

""")

    rewrites = [
        ('sys', 'six.moves.sys'),
        ('os.path', 'six.moves.path'),
    ]
    class import_rewrite_test(BaseImportRewrite):
        rewrites = rewrites

    res = import_rew

# Generated at 2022-06-23 22:26:58.727026
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == {'transform'}


# Generated at 2022-06-23 22:27:04.795633
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    def run(old, expected, rewrites):
        node = ast.parse(old)
        BaseImportRewrite.rewrites = rewrites
        trans = BaseImportRewrite(node)
        trans.visit(node)
        assert astor.to_source(node) == expected

    run(
        """
from foo import bar, baz
    """,
        """
try:
    from foo import bar, baz
except ImportError:
    from foo import bbar, bbaz
    bar = bbar
    baz = bbaz
    """, [
            ('foo.bar', 'foo.bbar'), ('foo.baz', 'foo.bbaz')])


# Generated at 2022-06-23 22:27:09.871181
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    from . import rewriters, utils
    from .types import CompilationTarget

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('django', 'django_portage')]

    for target in (CompilationTarget.py2, CompilationTarget.py3):
        with utils.mock_compilation_target(target):
            module = ast3.parse('''
            import re as regex
            import urllib.request
            ''')

            TestImportRewrite.transform(module)

            assert module == ast3.parse('''
            try:
                import re as regex
            except ImportError:
                import regex
            import urllib.request
            ''')



# Generated at 2022-06-23 22:27:20.085197
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    class TestClass(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    original_code = 'import six.moves.map\n' + \
        'from six.moves import map'

    expected_code = 'try:\n    import six.moves.map\n    pass\n' + \
        'except ImportError:\n    import six.moves.map as map\n' + \
        'try:\n    from six.moves import map\n    pass\n' + \
        'except ImportError:\n    from six.moves import map\n'

    tree = ast.parse(original_code)
    TestClass.transform(tree)
    transformed_code = astor.to_source(tree)

    assert transformed_code == expected_

# Generated at 2022-06-23 22:27:21.092975
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target == None


# Generated at 2022-06-23 22:27:27.682835
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typing import Any
    from typed_ast.ast3 import parse
    from .utils import get_test_tree
    from .utils import assert_equal_tree_node
    from .utils import tree_to_string
    tree = get_test_tree()
    transformer = BaseImportRewrite(tree)
    
    # Case where module is not in rewrite list
    import_stmt = parse('from foo.bar import baz, baz2').body[0]
    assert isinstance(transformer.visit(import_stmt), ast.ImportFrom)
    
    # Case where module is in rewrite list
    transformer.rewrites = [('foo', 'foo2')]
    import_stmt = parse('from foo.bar import baz, baz2').body[0]

# Generated at 2022-06-23 22:27:29.734982
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert (BaseTransformer.target == None)


# Unit tests for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:27:34.757453
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import TransformationResult
    class DummyTransformer(BaseTransformer):
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])
    assert DummyTransformer.target == None
    assert DummyTransformer.transform(ast.parse("pass")) == TransformationResult(ast.parse("pass"), False, [])


# Generated at 2022-06-23 22:27:35.402985
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:27:44.327022
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test 1
    import_from = ast.ImportFrom(module="collections.abc",
                                 names=[ast.alias(name="Hashable", asname="Hashable_rewrite"),
                                        ast.alias(name="Mapping", asname="Mapping_rewrite"),
                                        ast.alias(name="MutableMapping")],
                                 level=0)
    node_transformer = BaseImportRewrite(ast.Module([import_from]))
    import_from_rewrite = node_transformer.visit_ImportFrom(import_from)
    assert isinstance(import_from_rewrite, ast.Try)
    assert len(import_from_rewrite.body) == 2


# Generated at 2022-06-23 22:27:45.736926
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    ast.parse('def f() -> None: pass')


# Generated at 2022-06-23 22:27:53.657826
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['some_dependency']

    class DummyTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            self.tree = tree
            self.tree_changed = tree_changed
            self.dependencies = dependencies

    trans = DummyTransformer(tree)
    assert trans.tree == tree
    assert trans.tree_changed == tree_changed
    assert trans.dependencies == dependencies



# Generated at 2022-06-23 22:27:59.030057
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class NodeTransformer(BaseImportRewrite):
        rewrites = [('_six', 'six')]
    
    t = ast.parse("""
import _six
    """)
    result = NodeTransformer.transform(t)
    expected = ast.parse("""
try:
    import _six as six
except ImportError:
    import six
    """)
    assert ast.dump(result.tree) == ast.dump(expected)
    


# Generated at 2022-06-23 22:28:00.229287
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import inspect
    assert inspect.isclass(BaseTransformer)

# Generated at 2022-06-23 22:28:05.611101
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..compiler.base import BaseCompiler
    from .. import CompilationTarget
    from . import ImportRewriter

    code = '''
import urllib.request
from urllib import request
from urllib import request as request2
from urllib import *
from urllib.request import urlopen
from urllib.request import urlopen as urlopen2
import urllib.error
'''

# Generated at 2022-06-23 22:28:06.481594
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer


# Generated at 2022-06-23 22:28:07.814469
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_rewrite = BaseImportRewrite()

# Generated at 2022-06-23 22:28:18.046528
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    import typed_astunparse

    tree = parse("import foo")
    transformer = BaseImportRewrite(tree)
    assert isinstance(transformer.visit(tree), ast.Import)

    tree = parse("import foo.bar")
    transformer = BaseImportRewrite(tree)
    assert isinstance(transformer.visit(tree), ast.Import)

    tree = parse("import foo")
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [("foo.bar", "foo")]
    assert isinstance(transformer.visit(tree), ast.Try)

    tree = parse("import foo.bar")
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [("foo.bar", "foo")]

# Generated at 2022-06-23 22:28:24.860672
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import ast_compare
    from astunparse import unparse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('module', 'new')]

    module = ast.parse('import module\n'
                       'from module import Test\n'
                       'from module.test import Test\n'
                       'from module import Test as Test2\n'
                       'from module.test import Test as Test2\n'
                       'from module import *')

    transformed = TestImportRewrite.transform(module).tree

    expected = 'try:\n' \
               '    import module\n' \
               'except ImportError:\n' \
               '    import new\n' \
               'try:\n' \
               '    from module import Test\n' \
               'except ImportError:\n'

# Generated at 2022-06-23 22:28:26.880830
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target == None


# Generated at 2022-06-23 22:28:38.630671
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    rewriter = BaseImportRewrite()
    rewriter.rewrites = [('foo', 'bar')]
    import_ = ast.Import(names=[ast.alias(name='foo', asname='Bar')])
    rewriter.visit(import_)
    assert astor.to_source(import_) == (
        'try:\n'
        '    import foo as Bar\n'
        'except ImportError:\n'
        '    import bar as Bar\n')

    rewriter.rewrites = [('foo', 'bar')]
    import_ = ast.Import(names=[ast.alias(name='foo.bar', asname='Bar')])
    rewriter.visit(import_)

# Generated at 2022-06-23 22:28:45.772142
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse
    module = ast.parse(
        "from django.db.models import __all__, BaseModel, ForeignKey\n")
    module.body[0].lineno = 1
    module.body[0].col_offset = 1
    b = BaseImportRewrite()
    assert unparse(b.visit(module)) == 'from django.db.models import __all__, BaseModel, ForeignKey'

    module = ast.parse("from django.db.models import BaseModel\n")
    module.body[0].lineno = 1
    module.body[0].col_offset = 1
    b = BaseImportRewrite()
    assert unparse(b.visit(module)) == 'from django.db.models import BaseModel'


# Generated at 2022-06-23 22:28:55.520409
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert(hasattr(BaseImportRewrite(), 'rewrites'))
    assert(hasattr(BaseImportRewrite(), '_get_matched_rewrite'))
    assert(hasattr(BaseImportRewrite(), '_replace_import'))
    assert(hasattr(BaseImportRewrite(), '_replace_import_from_module'))
    assert(hasattr(BaseImportRewrite(), '_replace_import_from_names'))
    assert(hasattr(BaseImportRewrite(), 'visit_Import'))
    assert(hasattr(BaseImportRewrite(), 'visit_ImportFrom'))
    assert(hasattr(BaseImportRewrite(), '_get_replaced_import_from_part'))
    assert(hasattr(BaseImportRewrite(), '_get_names_to_replace'))
#

# Generated at 2022-06-23 22:28:59.129426
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert 'target' in BaseTransformer.__dict__
    assert BaseTransformer.target is None
    assert BaseTransformer.transform.__doc__ is None
    assert isinstance(BaseTransformer.transform, abstractmethod)


# Generated at 2022-06-23 22:29:04.340981
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class SimpleImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo.new'),
        ]

    class MultiPartImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'foo.new.bar'),
        ]

    class MultiRewriteImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo.new'),
            ('foo.bar', 'foo.new.bar'),
        ]

    class ImportRewriteFromModule(BaseImportRewrite):
        rewrites = [
            ('foo', 'foo.new'),
            ('foo.bar', 'foo.new.bar'),
            ('foo.baz', 'foo.new.baz'),
        ]


# Generated at 2022-06-23 22:29:14.709860
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget  # noqa

    class BaseImportRewriteClass(BaseImportRewrite):
        rewrites = [('urlparse', 'urllib.parse')]

        target = CompilationTarget.python_33

    import_rewrite = BaseImportRewriteClass.transform
    assert import_rewrite(ast.parse('import urlparse')).changes is True
    assert import_rewrite(ast.parse('import urlparse')).converted.body[0].body[0].value.names[0].name == 'urllib.parse'
    assert import_rewrite(
        ast.parse('from urlparse import urljoin, urlparse as urlparser')).changes is True

# Generated at 2022-06-23 22:29:20.556915
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # BaseImportRewrite
    assert BaseImportRewrite
    # BaseImportRewrite.dependencies
    assert BaseImportRewrite.dependencies == []
    # BaseImportRewrite.rewrites
    assert BaseImportRewrite.rewrites == []
    # BaseImportRewrite.target
    assert BaseImportRewrite.target is None
    # BaseImportRewrite(tree)
    BaseImportRewrite(None)


# Generated at 2022-06-23 22:29:21.849642
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None

# Generated at 2022-06-23 22:29:26.943437
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    from ..utils import unparse


    class TestTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    class Test1(unittest.TestCase):
        def test(self):
            module = ast.parse("import old")
            self.assertEqual(unparse(TestTransformer.transform(module).tree),
                             '''try:
    import old
except ImportError:
    import new''')

    class Test2(unittest.TestCase):
        def test(self):
            module = ast.parse("import old.sub")
            self.assertEqual(unparse(TestTransformer.transform(module).tree),
                             '''try:
    import old.sub
except ImportError:
    import new.sub''')


# Generated at 2022-06-23 22:29:30.438333
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert BaseTransformer.transform.__annotations__ == {'tree': ast.AST,
                                                         'return': 'TransformationResult'}


# Generated at 2022-06-23 22:29:31.480694
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert t.target == None


# Generated at 2022-06-23 22:29:32.480823
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None

# Generated at 2022-06-23 22:29:33.194979
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__init__(None, None)

# Generated at 2022-06-23 22:29:40.336142
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MockTransformer(BaseImportRewrite):
        rewrites = [("urllib", "urllib3"), ("tkinter", "PyQt5")]
        dependencies = ["urllib3"]
    # Case 1, when alias has dot
    import_from_statement = """\
from tkinter.ttk import Button
from urllib import parse
try:
    from tkinter.ttk import Button
except ImportError:
    from PyQt5.ttk import Button
try:
    from urllib import parse
except ImportError:
    import urllib3.parse as parse
"""
    import_from = ast.parse(import_from_statement)
    import_from = import_from.body[0]
    print('Original:')
    print(import_from)
    import_from = Mock

# Generated at 2022-06-23 22:29:41.336196
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None



# Generated at 2022-06-23 22:29:43.567566
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class FooTest(BaseTransformer):
        pass
    foo = FooTest()
    assert foo.target is None



# Generated at 2022-06-23 22:29:44.455447
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert 'BaseImportRewrite'

# Generated at 2022-06-23 22:29:53.242020
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'
    assert BaseImportRewrite.__module__ == __name__
    from astroid import MANAGER
    from astroid.builder import AstroidBuilder
    from typed_ast.ast3 import parse
    # Find class BaseImportRewrite
    try:
        class_ = MANAGER.ast_from_module(__name__)[0][1].__getitem__('BaseImportRewrite')
    except TypeError:
        # In Python 2, indexes are not supported
        pass
    else:
        assert class_.instantiate_class() is None
    # Test constructor of class BaseImportRewrite

# Generated at 2022-06-23 22:29:58.981137
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("from abc import ABC\nfrom def import DEF")
    BaseImportRewrite.rewrites = [("abc", "rewrite_abc"), ("def", "rewrite_def")]
    BaseImportRewrite.dependencies = []
    BaseImportRewrite.target = "python"
    instance = BaseImportRewrite(tree)
    instance.visit(tree)
    assert tree == ast.parse("from abc import ABC\nfrom def import DEF")

# Generated at 2022-06-23 22:30:02.425916
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class _Transformer(BaseTransformer):
        pass
    transformer = _Transformer()
    assert isinstance(transformer, BaseTransformer)
    assert isinstance(transformer, object)
    assert transformer.target == None


# Generated at 2022-06-23 22:30:12.991634
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportTestCase(BaseNodeTransformer):
        rewrites = [('foo', 'bar')]

        def __init__(self, tree: ast.AST, expected: Dict[ast.AST, ast.AST]) -> None:
            super().__init__(tree)
            self.expected = expected

        def visit_Try(self, node: ast.Try) -> ast.Try:
            assert node in self.expected, 'Unexpected case'
            assert ast.dump(node) == ast.dump(self.expected[node]), 'Not equal try finally'
            return node

    def check_rewrite_import(source: str, target: str) -> None:
        """Check rewrite import."""
        tree = ast.parse(source)

# Generated at 2022-06-23 22:30:18.275724
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Test(BaseTransformer):
        pass
    class Test2(BaseTransformer):
        target = CompilationTarget('foo', 'bar', 'baz')
    assert Test.target == CompilationTarget('python', 'python', 'python')
    assert Test2.target == CompilationTarget('foo', 'bar', 'baz')
    assert Test.transform(None) == TransformationResult(None, False, [])

# Generated at 2022-06-23 22:30:19.697811
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None


# Generated at 2022-06-23 22:30:21.714222
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse(r'''
  print('hello world!')
''')
    transformer = BaseNodeTransformer(tree)
    assert tree == transformer._tree

# Generated at 2022-06-23 22:30:22.699422
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()
    assert not t.target

# Generated at 2022-06-23 22:30:25.656154
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == {'transform'}
    assert BaseTransformer.__dict__.get('__abstractmethods__') is None
    assert BaseTransformer.__bases

# Generated at 2022-06-23 22:30:28.596416
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    snippet.test(BaseImportRewrite._replace_import,
                 """
                 try:
                     import foo
                 except ImportError:
                     import bar as foo
                 """,
                 ("foo", "bar"))
    snippet.test(BaseImportRewrite._replace_import,
                 """
                 try:
                     from foo import bar
                 except ImportError:
                     from bar import bar
                 """,
                 ("foo", "bar"))



# Generated at 2022-06-23 22:30:39.344089
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget
    from ..utils.snippet import snippet, extend

    class TestClass(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [
            ('six', 'six.moves'),
            ('pymongo', 'mongoengine')
        ]

    code = 'import six; from six import moves; from six.moves import map; from pymongo import MongoClient'
    module = ast.parse(code)
    tree_changed, tree = TestClass.transform(module)
    assert tree_changed

# Generated at 2022-06-23 22:30:46.661835
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import meta
    import meta.transformer
    import meta.utils.snippet

    class MyTransformer(BaseImportRewrite):
        rewrites = [('meta', 'meta_dep')]

    tree = ast.parse(
        inspect.getsource(meta.transformer),
        filename='meta/transformer.py'
    )

    transformer = MyTransformer(tree)
    result = transformer.visit(tree)

    assert isinstance(result, ast.Try)
    assert len(result.body) == 2

    import_rewrites = [
        stmt for stmt in result.body
        if isinstance(stmt, ast.ImportFrom) and stmt.level == 0]
    import_rewrite_names = [
        alias.name for rewrite in import_rewrites
        for alias in rewrite.names]


# Generated at 2022-06-23 22:30:47.640892
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert isinstance(BaseNodeTransformer(None), BaseNodeTransformer)

# Generated at 2022-06-23 22:30:55.107891
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    import_node = ast.Import(names=[ast.alias(name='some.module.for.import')])
    import_rewrite = BaseImportRewrite(import_node)
    import_rewrite.rewrites = [('some.module', 'other.module')]
    import_rewrite.visit(import_node)

    assert import_rewrite._tree_changed is True
    assert len(import_node.body) == 1
    assert isinstance(import_node.body[0], ast.Try)
    assert len(import_node.body[0].body) == 1
    assert isinstance(import_node.body[0].body[0], ast.Import)
    assert import_node.body[0].body[0].names[0].name == 'other.module.for.import'


# Unit

# Generated at 2022-06-23 22:31:01.981761
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..build import Compiler
    from ..typed_ast import typing_visitor
    from typed_ast import ast3

    class Rewrite(BaseImportRewrite):
        rewrites = [('typing_extensions', 'typing')],

        def visit_Import(self, node: ast3.Import):
            return super().visit_Import(node)

    tree = ast3.parse('from typing_extensions import TypeVar\nT = TypeVar()')
    tree = typing_visitor.add_type_comments(tree)
    compiler = Compiler(rewriters=[Rewrite])
    compiler.compile(tree)
    assert 'from typing import TypeVar' in compiler.source



# Generated at 2022-06-23 22:31:02.741371
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:31:14.638058
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import six
    import pytest

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('a', 'b'),
        ]

    import_a_node = ast.Import(names=[ast.alias(name='a',
                                                asname='A')])
    import_b_node = ast.Import(names=[ast.alias(name='b',
                                                asname='A')])
    expected_node = ast.Try(
        body=[import_a_node],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError',
                                                  ctx=ast.Load()),
                                    name=None,
                                    body=[import_b_node])],
        orelse=[],
        finalbody=[])

    result_node = TestBaseImportRewrite

# Generated at 2022-06-23 22:31:22.230413
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    node = ast.parse('from foo import bar')
    result = BaseImportRewrite.transform(node)
    assert astor.to_source(result.tree) == astor.to_source(ast.parse('from foo import bar'))

    node = ast.parse('import foo')
    result = BaseImportRewrite.transform(node)
    assert astor.to_source(result.tree) == astor.to_source(ast.parse('import foo'))

    node = ast.parse('import foo')
    BaseImportRewrite.rewrites.append(('foo', 'baz'))
    result = BaseImportRewrite.transform(node)

# Generated at 2022-06-23 22:31:33.245557
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportTransformer(BaseImportRewrite):
        rewrites = [
            ('re', 'regex'),
        ]

    import_to_rewrite = ast.Import(names=[
        ast.alias(name='foo',
                  asname='bar')])
    tree = ast.Module(body=[import_to_rewrite])

    transformed_tree = ImportTransformer.transform(tree).tree
    assert isinstance(transformed_tree.body[0], ast.Import)
    assert transformed_tree.body[0].names[0].name == 'foo'

    import_to_rewrite = ast.Import(names=[
        ast.alias(name='re',
                  asname='bar')])
    tree = ast.Module(body=[import_to_rewrite])

    transformed_tree = ImportTransformer.transform(tree).tree

# Generated at 2022-06-23 22:31:35.218898
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # type: () -> None
    BaseImportRewrite()

# Generated at 2022-06-23 22:31:36.430956
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not BaseTransformer.__init__.__isabstractmethod__



# Generated at 2022-06-23 22:31:37.589500
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('foo = 2')
    BaseNodeTransformer(tree)

# Generated at 2022-06-23 22:31:44.374976
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.parse("import foo").body[0]
    node.lineno = 1
    node.col_offset = 1
    visitor = BaseImportRewrite([('foo', 'foo.bar')])
    res = visitor.visit(node)
    assert isinstance(res, ast.Try)
    assert isinstance(res.body[0], ast.Import)
    assert res.body[0].names[0].name == 'foo.bar'
    assert res.body[0].lineno == 1
    assert res.body[0].col_offset == 1



# Generated at 2022-06-23 22:31:48.595245
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Foo(BaseTransformer):
        target = CompilationTarget.PYTHON

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass

    foo = Foo()
    assert foo.target == CompilationTarget.PYTHON

# Generated at 2022-06-23 22:31:57.193278
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse
    from ..types import CompilationTarget

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYPY
        rewrites = [('sys', 'pypy_sys')]

    tree = parse("import sys")
    inst = TestTransformer(tree)
    result = inst.visit(tree.body[0])
    assert isinstance(result, ast.Try)

    tree = parse("import sys as sys")
    inst = TestTransformer(tree)
    result = inst.visit(tree.body[0])
    assert isinstance(result, ast.Try)

    tree = parse("import not_sys")
    inst = TestTransformer(tree)
    result = inst.visit(tree.body[0])

# Generated at 2022-06-23 22:32:01.095449
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        dependencies = []
        rewrites = []
    assert Test.dependencies == []
    assert Test.rewrites == []
    assert Test.dependencies == []
    assert Test.rewrites == []

    # Test is also class method
    assert Test.is_class_method


# Generated at 2022-06-23 22:32:11.962365
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Meta(type):
        def __new__(mcs, name, bases, namespace):
            cls = super().__new__(mcs, name, bases, namespace)
            cls.instance = cls()
            return cls

    class Test(ast.NodeTransformer, metaclass=Meta):
        class TestImportRewrite(BaseImportRewrite):
            rewrites = [('snake_case', 'camelCase')]

        instance: 'TestImportRewrite'

    class_node = ast.parse('class Klass(object):\n    pass\n').body[0]

# Generated at 2022-06-23 22:32:17.249798
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from .. import transformations
    import inspect
    assert not inspect.isabstract(BaseTransformer)
    for subclass in BaseTransformer.__subclasses__():
        assert not inspect.isabstract(subclass)
        assert issubclass(getattr(transformations, subclass.__name__.lower()), subclass)
        assert isinstance(getattr(transformations, subclass.__name__.lower()), subclass)

# Generated at 2022-06-23 22:32:17.873086
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  BaseTransformer()

# Generated at 2022-06-23 22:32:21.572308
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        pass
    assert TestTransformer(None).tree is None
    assert isinstance(TestTransformer(None), ast.NodeTransformer)
    assert TestTransformer(None)._tree_changed is False


# Generated at 2022-06-23 22:32:30.807830
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def get_result(a):
        class ImportRewrite(BaseImportRewrite):
            rewrites = [('module_a', 'module_b')]
        return ImportRewrite.transform(a).tree

    import_from = ast.ImportFrom(module='module_a',
        names=[ast.alias(name='a', asname='x'), ast.alias(name='b')],
        level=0)
    result = get_result(import_from)
    assert result.body[0].value.func.id == 'try_import'
    assert result.body[0].value.args[0].args[0].value.body[0].value.module == 'module_b'


# Generated at 2022-06-23 22:32:33.512051
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # call_BaseTransformer = BaseTransformer()
    # code for BaseTransformer.transform(tree)
    pass



# Generated at 2022-06-23 22:32:42.530477
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    from ..utils.mock_objects import MockRewrite
    from ..utils.mock_code import mock_tree
    import io
    s = io.StringIO()

    src = """
    from module1 import a, b as c
    import module2
    """

    class Call(BaseImportRewrite):
        rewrites = [MockRewrite('module1.a', 'module1.x'),
                    MockRewrite('module2', 'module2.y')]
        dependencies = ['module1.x', 'module2.y']

    tree = ast.parse(src)
    Call.transform(tree)
    astor.dump_tree(tree, s)


# Generated at 2022-06-23 22:32:47.447861
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class R(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo")
    R.transform(tree)
    assert ast.dump(tree) == """try:
    import foo
except ImportError:
    import bar as foo
"""



# Generated at 2022-06-23 22:32:54.666374
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transpile import transpile_to_ast

    class Transformer(BaseImportRewrite):
        target = CompilationTarget.PY38
        rewrites = [('six', 'six')]


# Generated at 2022-06-23 22:32:55.724129
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    t = Test(None)
    assert t

# Generated at 2022-06-23 22:33:03.169131
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Test(BaseImportRewrite):
        rewrites = [('from_module', 'to_module')]

    tree = ast.parse('import from_module')
    after_tree = ast.parse('''
try:
    import from_module
except ImportError:
    import to_module
''')

    result = Test.transform(tree)
    assert ast.dump(result.tree) == ast.dump(after_tree)
    assert result.changed
    assert Test.dependencies == ['from_module', 'to_module']


# Generated at 2022-06-23 22:33:04.342804
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__init__.__defaults__ == (None,)
# Parameters for constructor of class BaseTransformer
# No parameters for constructor of class BaseTransformer

# Generated at 2022-06-23 22:33:10.023609
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ("six", "six")
        ]

    result, changed = TestTransformer.transform(
        ast.parse("import six")
    )

    assert changed
    assert ast.dump(result, include_attributes=False) == "try:\n    import six\nexcept ImportError:\n    import six"

    result, changed = TestTransformer.transform(
        ast.parse("import six.moves")
    )

    assert changed
    assert ast.dump(result, include_attributes=False) == "try:\n    import six.moves\nexcept ImportError:\n    import six.moves"



# Generated at 2022-06-23 22:33:12.422658
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'

# Generated at 2022-06-23 22:33:13.550336
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite()
    print(x)

# Generated at 2022-06-23 22:33:23.014250
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Generated test
    class TestBaseImportRewrite(BaseImportRewrite):
        pass

    # Generated mock
    class MockBaseNodeTransformer(BaseNodeTransformer):
        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            return ("", "")

        def _replace_import(self, node: ast.Import, from_: str, to: str) -> ast.Try:
            return ast.Try()

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            return self.generic_visit(node)

        def _replace_import_from_module(self, node: ast.ImportFrom, from_: str, to: str) -> ast.Try:
            return ast.Try()


# Generated at 2022-06-23 22:33:24.738048
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = CompilationTarget.PYTHON27
        pass
    assert not Transformer.transform('tree')

# Generated at 2022-06-23 22:33:28.045996
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None
    with pytest.raises(Exception):
        assert BaseTransformer.transform(BaseTransformer()) == None

# Unit tests for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:33:32.404315
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast
    s = ast.parse('a=1')
    class Test(BaseNodeTransformer):
        pass
    t = Test(s)
    assert t._tree == s
    t._tree_changed = True
    result = Test.transform(s)
    assert result.tree == s
    assert result.changed == True

# Generated at 2022-06-23 22:33:43.888142
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typing_extensions

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('typing', 'typing_extensions')
        ]

    tree = ast.parse('from typing import List')
    result = TestTransformer.transform(tree)

    assert isinstance(result.tree, ast.Try)
    assert hasattr(result, 'body')
    assert len(result.body) == 1
    expected = 'from typing import List'
    assert ast.dump(result.body[0]) == expected

    except_ = result.handlers[0]
    assert isinstance(except_, ast.ExceptHandler)
    assert len(except_.body) == 1
    expected = 'from typing_extensions import List'
    assert ast.dump(except_.body[0]) == expected


#

# Generated at 2022-06-23 22:33:51.494476
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    framework = 'old1'
    replacement = 'new1'
    class SomeTransformer(BaseImportRewrite):
        rewrites = [(framework, replacement)],

    # When
    tree = ast.parse('import old1')
    result = SomeTransformer.transform(tree)
    tree = result.tree

    # Then
    expected = ast.Try(
        body=[ast.Import(names=[ast.alias(name=replacement)])],
        handlers=[ast.ExceptHandler(
            type=ast.Name(id='ImportError', ctx=ast.Load()),
            body=[ast.Import(names=[ast.alias(name=framework)])])],
        orelse=[],
        finalbody=[]
    )
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 22:33:54.863148
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError:
        pass
    else:
        assert False, 'BaseTransformer() is an abstract class, BaseTransformer() should have raised TypeError'

# Generated at 2022-06-23 22:33:55.862244
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(ast)


# Generated at 2022-06-23 22:33:57.255765
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer
    bt.target


# Generated at 2022-06-23 22:34:06.504359
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast, astor
    from python_to_python.transformers import BaseImportRewrite
    from python_to_python.transformers.import_rewrite import BaseImportRewrite

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('django.http.request', 'django.core.handlers.wsgi')]

    ImportRewrite.dependencies = []

    test_case = ast.parse('import django.http.request')

    result = ImportRewrite.transform(test_case)
    expected = ast.parse('import django.http.request; try: import django.core.handlers.wsgi as http except ImportError: import django.http.request as http')

    assert astor.to_source(result.tree) == astor.to_source(expected)

# Unit test

# Generated at 2022-06-23 22:34:14.627309
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    line1 = "from aia.b import c"
    line2 = "from aib.d import e"
    line3 = "from aib.f import g"
    line4 = "from aib.g import h"
    line5 = "from aib.h import i"
    line6 = "from aia import b"
    line7 = "from aib import h"
    line8 = "from aib import *"
    line9 = "from aib.i import *"
    line10 = "from aib.j import *"
    line11 = "from aib.k import *"
    line12 = "from aia.b import c, d"
    line13 = "from aib.d import e, f"
    line14 = "from aib.g import h, i"
    line15

# Generated at 2022-06-23 22:34:15.677425
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None


# Generated at 2022-06-23 22:34:18.073646
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    inst = BaseImportRewrite.__new__(BaseImportRewrite)
    inst._tree = ast.parse("import x")



# Generated at 2022-06-23 22:34:28.857058
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import astor
    import import_rewrite
    class BaseImportRewrite(BaseImportRewrite):
        rewrites = []
    inst = BaseImportRewrite(ast.AST())
    assert isinstance(inst, ast.NodeVisitor)
    assert inst.rewrites == []
    assert astor.to_source(inst._tree) == '<_ast.AST object at 0x7f615d4a4ba8>'
    assert inst._tree_changed is False
    assert inst._get_matched_rewrite(None) is None
    assert inst._get_matched_rewrite('') is None
    class BaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'qux')]

# Generated at 2022-06-23 22:34:33.716536
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node_one = ast.ImportFrom(module="a",
                              names=ast.alias(name="a"))
    node_two = ast.ImportFrom(module="a",
                              names=ast.alias(name="b"))
    result = BaseImportRewrite._replace_import_from_module(None, 
                                                           node_one, "rewrite")
    assert result == None
    result = BaseImportRewrite._replace_import_from_names(None, 
                                                          node_one, "rewrite")
    assert result == None


# Generated at 2022-06-23 22:34:44.528609
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast import ast_equals

    class ImportTransform(BaseImportRewrite):
        rewrites = [('abc', 'xyz')]

    expected_tree = ast.parse("""
try:
    import abc
except ImportError:
    import xyz
    """).body[0]

    tree = ast.parse("""
import abc
""")
    result = ImportTransform.transform(tree)

    assert ast_equals(result.tree.body[0], expected_tree)
    assert result.changed

    tree = ast.parse("""
from abc import foo
""")
    result = ImportTransform.transform(tree)

    expected_tree = ast.parse("""
try:
    from abc import foo
except ImportError:
    from xyz import foo
    """).body[0]

   

# Generated at 2022-06-23 22:34:47.757929
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class FakeTransformer(BaseNodeTransformer):
        pass
    try:
        f = FakeTransformer()
        e = AssertionError()
        raise e
    except AssertionError:
        assert True


# Generated at 2022-06-23 22:34:51.951717
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'abc'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return None

    assert(TestTransformer.target == 'abc')



# Generated at 2022-06-23 22:35:02.686197
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .ast_utils import ast_to_str

    class Test(BaseImportRewrite):
        rewrites = [
            ('biwako.templates', 'jinja2'),
            ('biwako.templates.util', 'jinja2.utils')
        ]

    tree = ast.parse('''
    import biwako.templates.filters as filters
    import biwako.templates.util
    import jinja2.utils
    from jinja2.loaders import FileSystemLoader
    from biwako.templates import constants
    from biwako.templates.api import PackageLoader
    from .loader import PackageLoader2
    ''')

    substituted = ast_to_str(Test.transform(tree).tree)

# Generated at 2022-06-23 22:35:10.586598
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astunparse import unparse as ast_unparse
    from .utils import parse_snippet, snippet_to_ast
    from .expected import tree_to_dict

    from ..transforms.config import DALITE_NS, DALITE_NS_ABBR

    # Replace import from with try/except with old and new import module

# Generated at 2022-06-23 22:35:15.603206
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('print("Hello world!")')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree_changed == False
    assert transformer._tree == tree


# Generated at 2022-06-23 22:35:25.112903
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def import_from(module: str, names: List[str], path: Tuple[str, str]) -> str:
        return 'from {} import {}'.format(module, ', '.join(names))

    all_names = ["name1, ", "name2, ", "name3, ", "*"]


# Generated at 2022-06-23 22:35:27.330092
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test = BaseNodeTransformer(ast.parse('1'))
    assert test._tree_changed == False


# Generated at 2022-06-23 22:35:29.759611
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert BaseTransformer.target is None
    assert BaseTransformer.transform.__doc__ == 'Abstract method.'

# Generated at 2022-06-23 22:35:37.553473
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer1(BaseNodeTransformer):
        target = CompilationTarget('test', '2')

        def visit_Import(self, node):
            return ast.Import([])

    class TestTransformer2(BaseNodeTransformer):
        target = CompilationTarget('test', '3')

        def visit_Import(self, node):
            return ast.Import([])

    class TestTransformer3(BaseNodeTransformer):
        target = CompilationTarget('test', '3')

        def visit_Import(self, node):
            return ast.Import([])

    class TestTransformer4(BaseNodeTransformer):
        target = CompilationTarget('test', '2')

        def visit_Import(self, node):
            return ast.Import([])


# Generated at 2022-06-23 22:35:41.727897
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    x = BaseNodeTransformer(1)
    assert x._tree == 1
    assert x._tree_changed == False


# Generated at 2022-06-23 22:35:43.988943
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class SubTransformer(BaseNodeTransformer):
        pass

    assert SubTransformer(None)._tree is None
    assert not SubTransformer(None)._tree_changed



# Generated at 2022-06-23 22:35:46.378061
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    t = BaseNodeTransformer.transform(ast.parse('print("Hello, World!")')).tree
    assert ast.dump(t) == ast.dump(ast.parse('print("Hello, World!")'))

# Generated at 2022-06-23 22:35:47.260918
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer


# Generated at 2022-06-23 22:35:53.356969
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # type: () -> None
    import itertools
    import types
    import ast
    import six
    import inspect
    import astunparse
    import sys
    import os.path

    def importable_modules(package):
        # type: (str) -> Iterable[str]
        with open(os.path.join(os.path.dirname(__file__), '..', 'data', 'modules', package + '.txt')) as f:
            for line in f.readlines():
                yield line.rstrip()

    def importable_module(path, name):
        # type: (str, str) -> ModuleType
        return types.ModuleType(name)

    def import_module(path, name):
        # type: (str, str) -> ModuleType
        module = importable_module(path, name)

# Generated at 2022-06-23 22:36:03.159605
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)
    assert hasattr(BaseImportRewrite, 'rewrites')
    assert hasattr(BaseImportRewrite, 'visit_Import')
    assert hasattr(BaseImportRewrite, 'visit_ImportFrom')
    assert hasattr(BaseImportRewrite, '_get_matched_rewrite')
    assert hasattr(BaseImportRewrite, '_replace_import')
    assert hasattr(BaseImportRewrite, '_replace_import_from_module')
    assert hasattr(BaseImportRewrite, '_get_names_to_replace')
    assert hasattr(BaseImportRewrite, '_get_replaced_import_from_part')
    assert hasattr(BaseImportRewrite, '_replace_import_from_names')


# Generated at 2022-06-23 22:36:14.870861
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import astunparse


# Generated at 2022-06-23 22:36:17.722897
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_Test(BaseTransformer):
        target = CompilationTarget.PYTHON_27

    cls = BaseTransformer_Test()
    assert cls.target == CompilationTarget.PYTHON_27


# Generated at 2022-06-23 22:36:28.922556
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Given:
    class MockTransformer(BaseNodeTransformer):
        rewrites = [
            ('old', 'new'),
            ('old.sub', 'other.sub')
        ]

    import_from = ast.parse('from old import spam')
    import_from_from_old = ast.fix_missing_locations(import_from)
    import_from_names = ast.parse('from old import spam, sausage')
    import_from_names_from_old = ast.fix_missing_locations(import_from_names)
    import_from_names_from_sub = ast.parse('from old.sub import spam, sausage')
    import_from_names_from_sub_from_old = ast.fix_missing_locations(import_from_names_from_sub)
    
    # When:
   