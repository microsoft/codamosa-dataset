

# Generated at 2022-06-23 22:26:29.895663
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    with pytest.raises(NotImplementedError):
        BaseTransformer.transform(None)


# Generated at 2022-06-23 22:26:33.655380
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tree = ast.parse('print("This is a test")')
    obj = BaseTransformer()
    result = obj.transform(tree)
    assert(tree == result.tree)
    assert(result.changed == False)



# Generated at 2022-06-23 22:26:34.900893
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:26:42.909477
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.transforms.visitors.visitor import ImportFromVisitor
    import ast

    exec('''if 1:
    from os.path  import exists as another_exists, abspath
    from sys.path import *
''')

    visit_res = ImportFromVisitor(rewrites=[('os.path', 'os.path'), ('sys.path', 'sys.path')]).visit(ast.parse('''if 1:
    from os.path  import exists as another_exists, abspath
    from sys.path import *
'''))


# Generated at 2022-06-23 22:26:54.610300
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    old_source = '''
    import boto.s3.connection
    import boto.s3.bucket
    import boto.dynamodb.layer1
    '''
    new_source = '''
    try:
        import boto.s3.connection
    except ImportError:
        import boto3.s3.connection
    try:
        import boto.s3.bucket
    except ImportError:
        import boto3.s3.bucket
    try:
        import boto.dynamodb.layer1
    except ImportError:
        import boto3.dynamodb.layer1
    '''

# Generated at 2022-06-23 22:27:03.259159
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    # test without rewrite
    class TestTransformer(BaseImportRewrite):
        pass

    code = "import os\nos.path"
    tree = ast.parse(code)
    transformer = TestTransformer(tree)
    transformer.visit(tree)
    assert code == astor.to_source(tree)

    # test with rewrite
    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'pandas')]

    code = "import os\nos.path"
    tree = ast.parse(code)
    transformer = TestTransformer(tree)
    transformer.visit(tree)

# Generated at 2022-06-23 22:27:04.872683
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(1)


# Generated at 2022-06-23 22:27:06.775693
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Dummy(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    assert Dummy.dependencies == []

# Generated at 2022-06-23 22:27:16.588891
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import os
    import sys
    lib = os.path.dirname(ast.__file__)
    result = BaseImportRewrite.transform(ast.parse('from test import a')).tree
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[1].body[0].lineno == 1
    assert result.body[1].body[0].col_offset == 0
    assert isinstance(result.body[1].body[0].value, ast.ImportFrom)
    assert not os.path.samefile(lib, sys.modules['ast'].__file__)
    assert os.path.samefile(lib, sys.modules['ast'].__file__)

# Generated at 2022-06-23 22:27:23.102690
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_astunparse
    from ..transforms import BaseImportRewrite
    rewrites = (
        ('a', 'b'),
    )
    test_code = """
from a import d
from a import c
from a import b
from a import f as e
from a.h import i
"""

# Generated at 2022-06-23 22:27:25.431296
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        import unittest.mock as mock
        obj = mock.Mock()
    except ImportError:
        import mock
        obj = mock.Mock()
    BaseTransformer(obj)


# Generated at 2022-06-23 22:27:35.614853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    @snippet
    def method(old, new):
        extend(old)

    for old, new, expected in [
        ('import old', 'import new', method.get_body(old='import old', new='import new')),
        ('import old as new', 'import new', method.get_body(old='import old', new='import new'))]:
        from_, to = old.split()[1].rsplit('.', 1)
        tree = ast.parse(old)
        transformer = BaseImportRewrite(tree)
        transformer.rewrites = [(from_, to)]
        tree = transformer.visit(tree).body[0]
        assert astor.to_source(tree) == astor.to_source(expected[0])



# Generated at 2022-06-23 22:27:36.274901
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass


# Generated at 2022-06-23 22:27:37.340355
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.rewrites == []

# Generated at 2022-06-23 22:27:48.202214
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse

    import flask_wtf

    class Foo(BaseImportRewrite):
        rewrites = [('flask_wtf', 'wtforms')]

    @Foo.transform
    class NewBaz:
        import flask_wtf
        import flask_wtf.form
        import flask_wtf as wtf

    def to_str(node: ast.AST) -> str:
        return astunparse.unparse(node)

    assert to_str(NewBaz.__ast__.body[0]) == 'import flask_wtf'
    assert to_str(NewBaz.__ast__.body[1]) == 'import flask_wtf.form'
    assert to_str(NewBaz.__ast__.body[2]) == 'import flask_wtf as wtf'

# Unit

# Generated at 2022-06-23 22:27:53.450601
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Tests handling of ImportFrom node which is to be rewritten."""
    import_from = ast.parse("from old import a").body[0]

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old', 'new')
        ]

    assert ImportRewrite.transform(import_from).changed



# Generated at 2022-06-23 22:27:56.021209
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    tree = ast.parse('a = 1')
    result = BaseTransformer.transform(tree)
    assert result == (tree, False, [])



# Generated at 2022-06-23 22:27:58.506251
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('def f(): pass')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree_changed == False
    assert transformer._tree == tree


# Generated at 2022-06-23 22:27:59.623814
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__

# Generated at 2022-06-23 22:28:01.209857
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import typed_ast.ast3 as ast



# Generated at 2022-06-23 22:28:09.416955
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.harness import FakeNodeTransformer, BaseTransformer
    from ..utils.node import get_node_names
    from ..utils.snippet import snippet_ast

    assert issubclass(BaseImportRewrite, BaseTransformer)
    assert issubclass(BaseImportRewrite, FakeNodeTransformer)

    class TestTransformer(BaseImportRewrite):
        rewrites = [('requests', 'urllib')]

    assert get_node_names(TestTransformer) == {'Import'}



# Generated at 2022-06-23 22:28:14.442396
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..parser import parse_ast_tree
    from ..types import CompilationTarget
    from ..compiler import TranspileManager
    from ..transformation import BaseImportRewrite, get_transformation_classes

    CompilationTarget.set(CompilationTarget.PYTHON36)

    with open('tests/data/import_rewrite.py') as f:
        source = f.read()
    tree = parse_ast_tree(source)
    manager = TranspileManager()
    transformations = get_transformation_classes(BaseImportRewrite)
    transformations.sort(key=lambda x: x.priority)
    for transformation in transformations:
        tree = manager.apply_transformation(tree, transformation, source)


# Generated at 2022-06-23 22:28:23.225721
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.parse('''
from some_module.test import (
    SmthTestCase,
    SmthElseTestCase,
    )
    
from some_other_module.test import (
    SmthTestCase,
    SmthElseTestCase,
    )

from some_module import SmthTestCase, SmthElseTestCase
''')
    node_transformer = BaseImportRewrite()

# Generated at 2022-06-23 22:28:32.701767
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # type: () -> None

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('my_python_module', 'my_c_module')]

    module = ast.Module([ast.ImportFrom(
        module='my_python_module',
        names=[ast.alias(name='my_py_obj', asname=None)],
        level=0)])

    import_rewrite = ImportRewrite(module)
    import_rewrite.visit(module)

    try_body = import_rewrite._tree.body[0].body

    assert isinstance(try_body[0], ast.ImportFrom)
    assert try_body[0].module == 'my_c_module'

    assert isinstance(try_body[1], ast.ExceptHandler)

# Generated at 2022-06-23 22:28:37.850601
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class T(BaseNodeTransformer):
        def visit_Import(self, node):
            self._tree_changed = True
            return node
    import_ = ast.parse("import requests").body[0]
    tree = ast.parse("import pathlib").body[0]
    T.transform(tree)
    assert import_ == tree

# Generated at 2022-06-23 22:28:38.357745
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:39.405269
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:28:46.240895
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .. import transforms

    import_from_ast = ast.parse('from abc import ABC, x as y')
    import_from_ast_current = ast.parse('from def import ABC, x as y')
    import_from_ast_previous = ast.parse('from abc import ABC, x as y')

    import_ast = ast.parse('import abc')
    import_ast_current = ast.parse('import def')
    import_ast_previous = ast.parse('import abc')

    abc_to_def_transform = type('', (BaseImportRewrite,), {
        'rewrites': [
            ('abc', 'def')
        ]
    })
    abc_to_def_transform_obj = abc_to_def_transform(import_from_ast)

    abc_to_

# Generated at 2022-06-23 22:28:55.443549
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import get_tree

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
        ]

    tree = get_tree('''
    import foo

    import bar

    import foo.baz''')

    tree = TestTransformer.transform(tree)
    assert tree == ('''
    import bar

    import bar

    import bar.baz''')

    tree = get_tree('''
    import foo

    import foo

    import foo.bar

    import foo.baz''')

    tree = TestTransformer.transform(tree)
    assert tree == ('''
    import bar

    import bar

    import bar.bar

    import bar.baz''')



# Generated at 2022-06-23 22:28:57.034053
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

# Generated at 2022-06-23 22:29:06.155711
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import module')
    BaseImportRewrite.rewrites = [('rewrited_module', 'rewrote_module')]
    BaseImportRewrite.transform(tree)


# Generated at 2022-06-23 22:29:07.533290
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.transform(None) == None


# Generated at 2022-06-23 22:29:08.856420
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    transformer.target
    transformer.transform
    assert transformer


# Generated at 2022-06-23 22:29:13.116994
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    if __debug__:
        assert hasattr(BaseNodeTransformer, '_tree'), '_tree not found'
        assert hasattr(BaseNodeTransformer, '_tree_changed'), '_tree_changed not found'
        assert hasattr(BaseNodeTransformer, 'transform'), "transform not found"

# Generated at 2022-06-23 22:29:14.091170
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__init__()

# Generated at 2022-06-23 22:29:23.160957
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrite_class = type('BaseImportRewrite', (BaseImportRewrite, ), {'rewrites': [('.foo', '.bar')]})
    import_ = ast.Import(names=[ast.alias(name='.foo', asname=None)])
    import_from = ast.ImportFrom(module='.foo', names=[ast.alias(name='baz', asname=None)], level=0)

    result = rewrite_class.transform(import_)
    assert isinstance(result.tree, ast.Try)

    result = rewrite_class.transform(import_from)
    assert isinstance(result.tree, ast.Try)

# Generated at 2022-06-23 22:29:28.189515
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert isinstance(BaseNodeTransformer, BaseTransformer)
    assert BaseNodeTransformer.__name__ == 'BaseNodeTransformer'
    assert BaseNodeTransformer.__module__ == 'typed_astunparse.transforms'
    assert BaseNodeTransformer.__doc__ == BaseTransformer.__doc__
    assert BaseNodeTransformer.__abstractmethods__ == {'transform'}
    assert isinstance(BaseNodeTransformer.transform, classmethod)
    assert BaseNodeTransformer.transform.__name__ == 'transform'
    assert BaseNodeTransformer.transform.__doc__ == ast.NodeTransformer.visit.__doc__
    assert BaseNodeTransformer.transform.__module__ == 'typed_astunparse.transforms'


# Generated at 2022-06-23 22:29:34.908275
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('boto3.dynamodb', 'mypackage.backend.boto3.dynamodb')
        ]
    input = '''
import boto3.dynamodb  # noqa: F401
    '''
    expected = '''
import boto3.dynamodb as dynamodb
try:
    import boto3.dynamodb as dynamodb
except ImportError:
    import mypackage.backend.boto3.dynamodb as dynamodb
    '''
    tree = ast.parse(input)
    result = TestTransformer.transform(tree)
    assert result.tree_changed
    assert astor.code_gen.to_source(result.tree).strip()

# Generated at 2022-06-23 22:29:35.904609
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    mt = BaseImportRewrite()

# Generated at 2022-06-23 22:29:40.603970
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MockImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old', 'new'),
        ]

    tree = ast.parse("""
    import old
    """)

    expected_tree = ast.parse("""
    try:
        import old
    except ImportError:
        import new
    """)

    actual_tree = MockImportRewrite.transform(tree).tree

    assert ast.dump(expected_tree) == ast.dump(actual_tree)


# Generated at 2022-06-23 22:29:50.949646
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from transf import ast_collector
    import_rewrite_visitor = BaseImportRewrite(ast_collector.parse(
"""
from foo.bar import baz, qux as qux_inside

from foo.bar.baz import qux

from foo.bar import *
"""
))
    import_rewrite_visitor.rewrites = [
        ('foo.bar', 'someday.somewhere')
    ]

    import_rewrite_visitor.visit(import_rewrite_visitor._tree)
    print(import_rewrite_visitor._tree)


# Generated at 2022-06-23 22:29:52.690759
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, metaclass=ABCMeta)
    

# Generated at 2022-06-23 22:29:54.703259
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert isinstance(bt, BaseTransformer)

# Generated at 2022-06-23 22:29:58.162563
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class class1(BaseTransformer):
        target = 'target1'
        def transform(self, tree):
            return 'test'
    assert class1().target == 'target1' and class1().transform('test') == 'test'


# Generated at 2022-06-23 22:30:01.932365
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..transformations import BaseNodeTransformer
    tree = ast.parse("def f():pass")
    trans = BaseNodeTransformer(tree)
    assert trans._tree == tree
    assert trans._tree_changed == False


# Generated at 2022-06-23 22:30:12.435764
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite(): 
    class DummyRewrite(BaseImportRewrite):
        rewrites = [
            ('from1', 'to1'),
            ('from2', 'to2')
        ]

    import astor

    code = """
    import from1
    import from1.mod1
    from from2 import mod2
    from from2 import mod2, from1
    from from1 import from1
    from from1.mod1 import from1
    from from2 import from2
    from from2 import to1
    from from2.from2 import mod2
    """

    tree = ast.parse(code)
    DummyRewrite.transform(tree)


# Generated at 2022-06-23 22:30:21.462476
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import astor
    from typed_ast import ast3 as ast

    class MockRewrite(BaseImportRewrite):
        rewrites = [
            ('my_module', 'my_module2')
        ]

    tree = ast.parse('''import my_module''')
    result = MockRewrite.transform(tree)
    expected = ast.parse(
        '''try:
    import my_module
except ImportError:
    import my_module2

''')
    assert astor.to_source(result.tree) == astor.to_source(expected)

    tree = ast.parse('''import my_module.sub_module''')
    result = MockRewrite.transform(tree)

# Generated at 2022-06-23 22:30:22.467422
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    x = BaseTransformer()
    assert x != None


# Generated at 2022-06-23 22:30:31.909538
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as p_ast
    from textwrap import dedent
    from typed_ast.ast3 import parse

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo_module', 'bar_module')
        ]
    
    tree = parse(dedent("""
    from foo_module import bar_module
    from foo_module.module import SomeClass
    from foo_module.module import *
    """))
    MyImportRewrite.transform(tree)

# Generated at 2022-06-23 22:30:34.376571
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:30:43.952961
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    import six
    import_ = ast.ImportFrom(
        module='example',
        names=[ast.alias(name='*',
                         asname=None)],
        level=0)
    visitor = BaseImportRewrite(ast.Module(body=[import_]))
    try:
        visitor.visit_ImportFrom(import_)
    except AttributeError:
        sys.exit(1)
    try:
        import_ = ast.ImportFrom(
            module='example',
            names=[ast.alias(name='test1',
                             asname=None),
                   ast.alias(name='test2',
                             asname=None)],
            level=0)
        visitor.visit_ImportFrom(import_)
    except AttributeError:
        sys.exit(1)

# Generated at 2022-06-23 22:30:46.370787
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # pylint: disable=W0212
    tree = ast.parse('')
    inst = BaseNodeTransformer(tree)

    assert tree is inst._tree
    assert not inst._tree_changed

# Generated at 2022-06-23 22:30:56.945603
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    import ast
    from ..processors import BaseImportRewrite

    class RewriteTest(BaseImportRewrite):
        rewrites = [('_', '_')]

    class Test(unittest.TestCase):
        def test_visit_ImportFrom(self):
            code = """
import something
from _.somethng import *
from something.somethng import *, x
from _.somethng import x, y
from something.somethng import x
from _.somethng import x as y
            """

# Generated at 2022-06-23 22:30:59.401374
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseNodeTransformer, BaseTransformer)
    assert issubclass(BaseTransformer, ast.NodeTransformer)

# Unit tests for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:31:01.510335
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer.__abstractmethods__ == 'target'

# Unit tests for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:31:06.763031
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    node = ast.parse("print('Hello world')")
    node_2 = ast.parse("print('Hello world')")
    class sample(BaseTransformer):
        def transform(self, tree):
            return TransformationResult(tree, False, [])

    sample()
    assert_true(sample.transform(node)==sample().transform(node_2))

# Generated at 2022-06-23 22:31:07.451799
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:31:14.517727
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    class BaseImportRewriteTest(BaseImportRewrite):
        rewrites = [
            ('os', 'xos.os')]
    source = """\
import os
import os.path
import os.path as path
"""
    result = """\
try:
    import os
except ImportError:
    import xos.os as os
import os.path
import os.path as path
"""
    tree = astor.parse_file(file_name=source,
                            process_includes=True,
                            process_doctests=True)
    result_tree = astor.parse_file(file_name=result,
                                   process_includes=True,
                                   process_doctests=True)
    assert BaseImportRewriteTest.transform(tree).tree == result_tree
    
    

# Generated at 2022-06-23 22:31:14.977659
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:31:20.541834
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import six')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six', '_six')]

    TestImportRewrite.transform(tree)

    expected = ast.parse('''\
try:
    import six as six
except ImportError:
    import _six as six''')

    assert ast.dump(expected) == ast.dump(tree)


# Generated at 2022-06-23 22:31:31.867571
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('a', 'b')]

    class TestClass(BaseImportRewrite):
        rewrites = rewrites

    node = ast.parse('from a.b import c').body[0]
    tree = TestClass.transform(node)

    assert tree.tree == ast.parse('from b.b import c').body[0]

    node = ast.parse('from a.b import c as d').body[0]
    tree = TestClass.transform(node)

    assert tree.tree == ast.parse('from b.b import c as d').body[0]

    # We don't want to replace module if it is not imported exactly as
    # it is in from_ name.
    node = ast.parse('from a.b.c import d').body[0]

# Generated at 2022-06-23 22:31:36.631010
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from typed_ast import ast3 as ast
    from typing import Optional
    import unittest.mock

    tree = ast.parse("1 + 2")
    BaseNodeTransformer(tree)
    assert tree is not unittest.mock.sentinel
    assert tree is not None
    assert tree is not Optional

# Generated at 2022-06-23 22:31:45.763154
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from . import stdlib
    from .stdlib import jython_27

    class ImportRewrite(BaseImportRewrite):
        target = stdlib.Jython27
        rewrites = [('string', 'jython_27.string')]

    tree = ast.parse('''
        import jinja2
        import string
        import posixpath as pp
    ''')

    new_tree = ImportRewrite.transform(tree).tree

    expected = astor.to_source(ast.parse('''
        import jinja2
        try:
            import string
        except ImportError:
            import jython_27.string as string
        import posixpath as pp
    '''))
    assert astor.to_source(new_tree) == expected



# Generated at 2022-06-23 22:31:55.398103
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
  from typed_ast.ast3 import parse

  tree = parse('''
from typing import Tuple
from typing import List
from typing import Tuple
from marshmallow import fields
from importlib import import_module
from typing.abc import Sequence
from typing import Tuple, List, Sequence
from typing import Tuple
from importlib import import_module
from marshmallow import fields
from marshmallow import fields
from marshmallow.fields import Nested
from marshmallow import fields
''')

  class BaseImportRewriteTest(BaseImportRewrite):
    rewrites = [('typing', 'typing2')]

  result = BaseImportRewriteTest.transform(tree)

# Generated at 2022-06-23 22:32:02.568404
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.testing import metrics
    from ..utils.transform import BaseImportRewrite
    from typed_ast import ast3 as ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib')]

    with metrics() as met:
        tr = TestImportRewrite.transform(ast.parse('import os.path\nos.path.exists("/")'))
    assert tr.tree_changed is True
    assert met['time'] < 1.0
    assert met['nodes'] < 100

    tr = TestImportRewrite.transform(ast.parse('from os.path import exists\nexists("/")'))
    assert tr.tree_changed is True

# Generated at 2022-06-23 22:32:03.235753
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:32:06.608927
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse('1')
    tnt = TestNodeTransformer(tree)
    assert tnt == TestNodeTransformer(tree)

# Generated at 2022-06-23 22:32:15.869148
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformation(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        target = CompilationTarget.PYTHON_35
        dependencies = ['bar']

    node = ast.parse("import foo\n").body[0]
    result = TestTransformation.transform(node)
    assert result.tree.body[0].body[1].body[0].value.value == 'foo'

    result = TestTransformation.transform(node)
    assert isinstance(result.tree.body[0], ast.Try)
    assert result.tree.body[0].body[1].body[0].value.value == 'bar'



# Generated at 2022-06-23 22:32:16.521463
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:32:18.363054
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("1")
    inst = BaseNodeTransformer(tree)
    inst.visit(tree)

# Generated at 2022-06-23 22:32:19.371335
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.transform


# Generated at 2022-06-23 22:32:21.144512
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    node = ast.Import()
    p = BaseImportRewrite(node)
    assert p._tree == node

# Generated at 2022-06-23 22:32:22.562789
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    cls = BaseNodeTransformer(ast.parse('pass'))


# Generated at 2022-06-23 22:32:25.192750
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__.__annotations__ == {
        'self': BaseImportRewrite,
        'tree': ast.AST,
    }



# Generated at 2022-06-23 22:32:26.530748
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(ast.Module(body=[]))


# Generated at 2022-06-23 22:32:27.013933
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite(): BaseImportRewrite()

# Generated at 2022-06-23 22:32:28.155790
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError:
        pass

# Generated at 2022-06-23 22:32:34.954029
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class T(BaseNodeTransformer):
        def visit_Name(self, node):
            self._tree_changed = True
            return ast.Name(id="bar")

    tree = ast.parse("foo()")
    result = T.transform(tree)
    assert result.tree.body[0].value.id == "bar"
    assert result.tree_changed
    assert result.dependencies == []



# Generated at 2022-06-23 22:32:37.260850
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__init__ == object.__init__
    assert BaseTransformer.__new__ == object.__new__

# Generated at 2022-06-23 22:32:38.190623
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:32:48.025059
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyTransformer(BaseImportRewrite):
        rewrites = [(fr, to) for fr, to in zip('abcde', 'vwxyz')]

    tree = ast.parse('import a.c.e as x\nfrom c.x import z as z')
    assert MyTransformer(tree).visit(tree) == ast.parse(
        'try:\n    import a.c.e as x\nexcept ImportError:\n    import v.y.z as x\n' +
        'try:\n    from v.x import z as z\nexcept ImportError:\n    from y.z import z as z')

# Generated at 2022-06-23 22:32:54.929589
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..state import State

    import mymodule
    from mymodule import mymodulefunction
    from .some_module import *
    from .some_module import test
    from .some_module import test as test_as
    from .some_module import test as test_as, test2 as test2_as
    from .some_module import test as test_as, test2 as test2_as, test3 as test3_as


# Generated at 2022-06-23 22:32:55.303793
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:32:57.778040
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not hasattr(BaseTransformer, '__init__')
    assert issubclass(BaseTransformer, metaclass=ABCMeta)



# Generated at 2022-06-23 22:33:00.121112
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert issubclass(BaseNodeTransformer, ast.NodeTransformer)
    assert issubclass(BaseNodeTransformer, BaseTransformer)



# Generated at 2022-06-23 22:33:02.828964
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    @BaseNodeTransformer.register_transformer
    class Test(BaseNodeTransformer):
        pass

    tree = ast.parse("pass")
    Test.transform(tree)

# Generated at 2022-06-23 22:33:03.629187
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:33:07.633896
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse("from xyz import ABC, DEF")
    module = BaseImportRewrite().visit(module)
    assert isinstance(module.body[0], ast.Try)
    assert len(module.body[0].handlers) == 2
    assert len(module.body[0].finalbody) == 0



# Generated at 2022-06-23 22:33:10.833508
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert not BaseNodeTransformer(ast.parse("i = 1"))._tree_changed
    assert BaseNodeTransformer(ast.parse("i = 1"))
    assert BaseNodeTransformer(ast.parse("i = 1"))._tree == ast.parse("i = 1")


# Generated at 2022-06-23 22:33:13.493730
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_test1(BaseTransformer):
        pass

    assert type(BaseTransformer_test1) == type



# Generated at 2022-06-23 22:33:14.493379
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite


# Generated at 2022-06-23 22:33:23.723102
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Function that checks if some node is replaced and if replaced node is valid
    def check_node_changed(node, new, check):
        if not new:
            assert isinstance(new, check)
        assert new is not node

    # Test replace of import module
    module_from = 'os.path'
    module_to = 'pathlib'
    class DummyTransformer(BaseImportRewrite):
        rewrites = [(module_from, module_to)]

    import_from_node = ast.ImportFrom(module=module_from, names=[ast.alias(name='Path')], level=0)
    expected_import_from_node = ast.ImportFrom(module=module_to, names=[ast.alias(name='Path')], level=0)

# Generated at 2022-06-23 22:33:27.726875
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from inspect import signature
    from types import FunctionType
    from ..types import CompilationTarget
    
    BaseImportRewrite()
    assert isinstance(BaseImportRewrite.transform, FunctionType)
    assert signature(BaseImportRewrite.transform) == signature(BaseNodeTransformer.transform)
    assert BaseImportRewrite.rewrites == []
    assert BaseImportRewrite.target is CompilationTarget.PYTHON


# Generated at 2022-06-23 22:33:36.163617
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .test_transformers import BaseImportRewrite
    from typed_ast import ast3 as ast

    class CustomImportRewrite(BaseImportRewrite):
        rewrites = [
            ('abc', 'abc.abc')
        ]

    node = ast.Import(names=[ast.alias(name='abc',
                                       asname='abc')])
    result = CustomImportRewrite.transform(node)

# Generated at 2022-06-23 22:33:38.604398
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a = 1')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:33:42.004478
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("def test(): pass")

    assert BaseNodeTransformer(tree).visit(tree) == tree

    inst = BaseNodeTransformer(tree)
    inst.visit(tree)
    assert inst._tree_changed == False

# Generated at 2022-06-23 22:33:49.773633
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node = ast.Import(names=[
        ast.alias(name='os',
                  asname=None),
        ast.alias(name='path',
                  asname=None),
    ])
    transformer = BaseImportRewrite([
        ('os', 'os.path')
    ])
    node = transformer.visit(node)
    assert isinstance(node, ast.Try)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Import)
    assert node.body[0].names[0].name == 'os'
    assert node.body[0].names[1].name == 'path'
    assert isinstance(node.body[1], ast.Import)
    assert node.body[1].names[0].name == 'os.path'

# Generated at 2022-06-23 22:33:50.278940
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:54.325087
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class ExampleTransformer(BaseTransformer):
        target = CompilationTarget("python", "3.4")

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False)
    e = ExampleTransformer()

# Generated at 2022-06-23 22:34:00.672035
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    input_ast = ast.parse("""\
import test
""")
    output_ast = ast.parse("""\
try:
    import test
except ImportError:
    import test as test
""")
    rw = BaseImportRewrite()
    rw.rewrites = [('test', 'test')]
    result = rw.visit(input_ast)
    assert ast.dump(output_ast, include_attributes=False) == ast.dump(result, include_attributes=False)


# Generated at 2022-06-23 22:34:10.583634
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..testing import assert_equal, assert_true
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'pathos')]

    import_name = ast.parse('import os.path').body[0]
    import_asname = ast.parse('import os.path as x').body[0]
    import_from_name = ast.parse('from os import path').body[0]
    import_from_asname = ast.parse('from os import path as x').body[0]
    import_from_all = ast.parse('from os import *').body[0]
    import_from_all_asname = ast.parse('from os import * as x').body[0]
    import_from_all_with_name = ast.parse('from os import path, *').body[0]

# Generated at 2022-06-23 22:34:15.328772
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite(None)
    assert BaseImportRewrite(None).tree is None
    assert BaseImportRewrite(None).rewrites == []
    assert not BaseImportRewrite(None)._tree_changed


# Generated at 2022-06-23 22:34:23.285258
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest

    from typed_ast.ast3 import parse

    from .utils import UnitTestNodeTransformer


    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.TEST
        rewrites = [('unittest', 'unittest2')]

    class TestTransformer2(TestTransformer):
        target = CompilationTarget.TEST2


    class TestImportRewrite(unittest.TestCase):
        def assertCodeEqual(self, a, b):
            self.assertEqual(parse(a), parse(b))

        def test_import(self):
            before = '''
                import unittest
                import configparser
            '''


# Generated at 2022-06-23 22:34:34.035826
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    
    class BaseImportRewrite_(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'baz')
        ]
    
    module = ast.parse('''
import foo.bar as a

from foo import b, c as d
from foo.bar import e as f

import qux

from qux import g as h
from foo.bar import i

''')

    old_module = ast.parse('''
import foo.bar as a

from foo import b, c as d
from foo.bar import e as f

import qux

from qux import g as h
from foo.bar import i

''')

    result = BaseImportRewrite_.transform(module)


# Generated at 2022-06-23 22:34:37.431014
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .test_import_rewrite import SomeTransformer
    transformer = SomeTransformer()

    assert transformer.rewrites == [('old', 'new')]
    assert transformer.dependencies == ['new']

# Generated at 2022-06-23 22:34:38.981898
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    check.check_class(BaseTransformer)



# Generated at 2022-06-23 22:34:44.982929
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Unit test for constructor of class BaseImportRewrite"""
    tree = ast.parse("import re")
    assert BaseImportRewrite.transform(tree).tree.body[0].names[0].name == "re"

    tree = ast.parse("import re as alias")
    assert BaseImportRewrite.transform(tree).tree.body[0].names[0].name == "re"

    tree = ast.parse("import re")
    assert BaseImportRewrite.transform(tree).tree_changed == False

    tree = ast.parse("import re as alias")
    assert BaseImportRewrite.transform(tree).tree_changed == False


# Generated at 2022-06-23 22:34:55.445720
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils import to_source

    class MyTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]
        dependencies = []

    tree = ast.parse('import old')
    result = MyTransformer.transform(tree)
    assert result.tree.body[0] == ast.Try(
        body=[ast.Import(names=[ast.alias(name='old', asname=None)])],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[ast.Import(names=[ast.alias(name='new', asname=None)])])],
        orelse=[],
        finalbody=[])

    # Reuse of transformer
    tree = ast.parse('import some.old')


# Generated at 2022-06-23 22:35:05.966601
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Tests that function changes import with module names that should be
    # changed according to rewrites.
    source = '''
from a import b
'''
    tree = ast.parse(source)
    BaseImportRewrite.rewrites = [('a', 'b')]
    transformer = BaseImportRewrite(tree)
    transformed_tree = tree.body[0].body[0]
    result = transformer.visit_Import(transformed_tree)
    module_name = result.body[0].body[0].names[0].name
    assert module_name == 'b'
    # Tests that function does not change import with module names that should
    # not be changed according to rewrites.
    source = '''
from a import b
'''
    tree = ast.parse(source)
    BaseImportRewrite.rewrites

# Generated at 2022-06-23 22:35:08.655046
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'py27'

        @classmethod
        def transform(cls, tree):
            pass

    t = TestTransformer()
    assert t.target == 'py27'

# Generated at 2022-06-23 22:35:10.281603
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, ast.NodeTransformer)
    assert (BaseTransformer.target == CompilationTarget.NONE)
    

# Generated at 2022-06-23 22:35:20.687210
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ...unittest import TestCase


# Generated at 2022-06-23 22:35:23.986151
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class SomeTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)
            self._tree_changed = True
            self.visit(self._tree)

    tree = ast.parse('1 + 1')
    trans = SomeTransformer(tree)

    assert trans._tree_changed

# Generated at 2022-06-23 22:35:29.175506
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class A(BaseTransformer):
        target = 'bla'

        @classmethod
        def transform(cls, tree):
            return '1'

    a = A()

    assert(a.target == 'bla')
    assert(a.transform('1') == '1')


# Generated at 2022-06-23 22:35:29.765019
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:35:32.784369
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyNodeTransformer(BaseNodeTransformer):
        pass

    tree = ast.parse('2 + 3')
    instance = MyNodeTransformer(tree)
    assert instance._tree_changed == False
    assert instance._tree == tree

# Generated at 2022-06-23 22:35:33.502554
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:35:36.604605
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_rewrite_obj = BaseImportRewrite()
    assert import_rewrite_obj.rewrites == []
    assert import_rewrite_obj.dependencies == []
    assert import_rewrite_obj.target is None



# Generated at 2022-06-23 22:35:46.058338
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('''
    import foo
    import foo.baz
    import bar
    import bar.baz
    ''')

    transformer = TestTransformer(tree)

    new_tree = transformer.visit(tree)
    assert transformer._tree_changed

    new_code = astor.to_source(new_tree).strip()

    expected_code = '''
    try:
        import foo
    except ImportError:
        import bar as foo

    try:
        import foo.baz
    except ImportError:
        import bar.baz as baz

    import bar
    import bar.baz
    '''.strip()

    assert new_code == expected_code

# Generated at 2022-06-23 22:35:46.671432
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:35:47.527117
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()



# Generated at 2022-06-23 22:35:52.568317
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.utils import parse_code

    import_from_code = """
from typing import Dict
from typing import Tuple
from typing import Iterable
from typing import List
from typing import Optional
from typing import Union
from typing import cast
"""


# Generated at 2022-06-23 22:36:01.740590
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer.target is None
    assert BaseNodeTransformer.dependencies == []

    tree = ast.parse('pass')
    class TestTransformer(BaseNodeTransformer):
        target = 'test'
        dependencies = ['a', 'b']

    transformer = TestTransformer(tree)

    assert transformer._tree == tree
    assert transformer._tree_changed is False
    assert transformer.target == 'test'
    assert transformer.dependencies == ['a', 'b']
    assert TestTransformer.target == 'test'
    assert TestTransformer.dependencies == ['a', 'b']

    transformer.visit(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:36:13.370131
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..compilers.base import BaseCompiler

    mod = ast.Module(body=[])

    class DummyObj(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        dependencies = []

    dummy = DummyObj(mod)
    assert isinstance(dummy, BaseImportRewrite)
    assert isinstance(dummy, BaseNodeTransformer), 'Should be instance of BaseNodeTransformer'
    assert isinstance(dummy, ast.NodeTransformer), 'Should be instance of NodeTransformer'
    assert isinstance(dummy, BaseTransformer), 'Should be instance of BaseTransformer'
    assert isinstance(dummy, BaseCompiler), 'Should be instance of BaseCompiler'
    assert isinstance(dummy, object), 'Should be instance of object'



# Generated at 2022-06-23 22:36:17.600197
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('from mod1 import a, b, c\nfrom mod2 import d, e\nimport mod3')
    tr = BaseImportRewrite(tree)
    assert tr.rewrites == []
    assert tr.dependencies == []
    assert tr.target is None
    assert not tr._tree_changed
    assert tr._tree is tree

# Generated at 2022-06-23 22:36:25.308118
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class A(BaseImportRewrite):
        rewrites = [('a', 'b')]
        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)


# Generated at 2022-06-23 22:36:31.087593
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast import parse
    from textwrap import dedent

    class Rewrite(BaseImportRewrite):
        rewrites = [
            ('asyncio', 'trollius')
        ]

    # Simple import
    node = parse(dedent('''
    import asyncio
    ''')).body[0]
    result = Rewrite.transform(node)
    assert result.transformed
    assert isinstance(result.tree, ast.Try)

    # Import with alias
    node = parse(dedent('''
    import asyncio as foo
    ''')).body[0]
    result = Rewrite.transform(node)
    assert result.transformed
    assert isinstance(result.tree, ast.Try)

    # Import with submodule