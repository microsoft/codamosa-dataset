

# Generated at 2022-06-23 22:26:38.845076
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import datetime
    import foo
    import foo.bar
    import foo.bar as foo_bar

    class Mocked(BaseImportRewrite):
        rewrites = [
            ('foo', 'foobar')
        ]

    import_from_statements = [
        'from foo.bar.baz import *',
        'from datetime import date',  # don't do anything
        'from astor.code_gen import to_source',  # don't do anything
        'from foo import bar',
        'from foo import bar as bar2',
        'from foo.bar import baz',
        'from foo.bar import baz as baz2',
    ]

    for import_from in import_from_statements:
        node = ast.parse(import_from)

# Generated at 2022-06-23 22:26:41.162098
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        target = "python"

    assert DummyTransformer().target == "python"

# Generated at 2022-06-23 22:26:42.400441
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-23 22:26:44.384333
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    a = BaseTransformer('', '')
    assert isinstance(a, BaseTransformer)


# Generated at 2022-06-23 22:26:55.854940
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..node_visitor import NodeVisitor
    from ..utils import ast_visit_multi
    from ..utils.compat import get_parser

    class TestTransformer(BaseImportRewrite):
        rewrites = [('os', 'fake_os'), ('os.path', 'fake_os.path')]
        class Target(CompilationTarget):
            pass

    visitor = NodeVisitor()
    tree = get_parser().parse("""
from os import path, X
from os.path import dirname
from os.path.split import split
from fake_os.path import exists, split as split2
from fake_os.path.split import split as split3
""")
    result = TestTransformer.transform(tree)
    assert not result.changed
    assert result.dependencies == ['fake_os']

    tree = get_

# Generated at 2022-06-23 22:27:01.635431
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..transformer import BaseImportRewrite

    class TestRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    t = TestRewrite(None)
    node = ast.parse("import foo").body[0]

    assert astor.to_source(t.visit(node)).strip() == """
    try:
        import foo
    except ImportError:
        import bar
    """.strip()



# Generated at 2022-06-23 22:27:05.253538
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
    except TypeError as e:
        assert str(e), 'Can\'t instantiate abstract class BaseTransformer with abstract methods transform'
        print(str(e))
    else:
        assert False

# Generated at 2022-06-23 22:27:07.480923
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget(platform=None,
                               version=None,
                               platform_version=None)
    obj = BaseTransformer()
    assert obj.target == target

# Generated at 2022-06-23 22:27:09.064623
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(NotImplementedError):
        BaseTransformer.transform(None)


# Generated at 2022-06-23 22:27:18.955471
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from pprint import pprint
    from .utils import parse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six'),
        ]

    tree = parse("""
import six.moves
from six.moves import something
""")
    new_tree = TestImportRewrite.transform(tree).tree
    pprint(new_tree)
    assert new_tree.body[0].body[0].value.args[0].s == 'import six.moves'
    assert new_tree.body[0].body[1].value.args[0].s == 'from six.moves import something'
    assert new_tree.body[1].value.args[0].s == 'from six import something'

# Generated at 2022-06-23 22:27:26.231350
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    ast_str = '''
from math import *
from math import sin
from math import sin as sin_1
from math.sin.cos import cos as sin_cos
'''
    ast_object = ast.parse(ast_str)
    ast_object_expected = ast.parse('''
try:
    from math import cos
except ImportError:
    from math.cos import cos

try:
    from math import sin
except ImportError:
    from math.sin import sin

try:
    from math import sin as sin_1
except ImportError:
    from math.sin import sin as sin_1

try:
    from math.sin.cos import cos as sin_cos
except ImportError:
    from math.sin.cos import cos as sin_cos
''')

# Generated at 2022-06-23 22:27:36.306200
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from . import compat_import_as, compat_import_from

    import_ = ast.Import(names=[ast.alias(name='os.path', asname='path')])
    result = BaseImportRewrite(ast.Module(body=[import_])).transform(import_)

    assert (result.node.body[0].body[0].value.names[0].name == 'pathlib' and
            result.node.body[0].body[1].value.names[0].name == 'pathlib.os.path')

    import_ = ast.Import(names=[ast.alias(name='os', asname='path')])
    result = BaseImportRewrite(ast.Module(body=[import_])).transform(import_)


# Generated at 2022-06-23 22:27:37.230233
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None
    assert BaseTransformer.transform(ast.parse("a = 1")) == NotImplemented


# Generated at 2022-06-23 22:27:39.495221
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__


# Generated at 2022-06-23 22:27:45.333791
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor

    class MockTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            self._tree_changed = True
            node.id = 'foo'
            return node

    tree = astor.parse_file('tests/testdata/base.py')
    MockTransformer.transform(tree)

    assert astor.to_source(tree) == 'def hello():\n\tfoo()\n\tfoo()\n'

# Generated at 2022-06-23 22:27:50.721245
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestNodeTransformer(BaseImportRewrite):
        rewrites = [('humanize', '''humanize''')]
    tree = ast.parse('''
    import humanize
    import something
    ''')
    expected_tree = ast.parse('''
    try:
        import humanize
    except ImportError:
        import humanize
    import something
    ''')
    result = TestNodeTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.changed == True



# Generated at 2022-06-23 22:27:51.366526
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:27:54.787595
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Pylint disable
    with mock.patch.multiple(BaseImportRewrite,
                             rewrites=[('foo', 'bar')],
                             dependencies=['foo']):
        BaseImportRewrite(None)
    # Pylint enable

# Generated at 2022-06-23 22:27:56.440736
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # type: () -> None
    assert BaseImportRewrite.__init__



# Generated at 2022-06-23 22:27:56.805033
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite

# Generated at 2022-06-23 22:27:57.915700
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .rewrites import SimpyRewrite
    return SimpyRewrite

# Generated at 2022-06-23 22:28:00.150702
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    """
    Tests the constructor of class BaseTransformer
    """
    assert BaseTransformer.target is None


# Generated at 2022-06-23 22:28:11.457952
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import astunparse


# Generated at 2022-06-23 22:28:13.750813
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer._tree_changed == False
    assert BaseNodeTransformer._tree is None
    assert BaseNodeTransformer.dependencies == []



# Generated at 2022-06-23 22:28:22.937315
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import astor  # type: ignore
    import sys
    import ast
    import pytest
    import asttools

    class CustomTransformer(BaseTransformer):
        def __init__(self, node: ast.AST, source: str=None) -> None:
            super().__init__()
            self._source = source or ''
            self._tree = node
            self._tree_changed = False
            self.target = CompilationTarget.PY2

        @classmethod
        def transform(cls, node: ast.AST) -> TransformationResult:
            """Transform AST.

            :param node: AST node to transform
            """
            self = cls(node, node)
            self.visit(node)
            return TransformationResult(
                self._tree, self._tree_changed, [])


# Generated at 2022-06-23 22:28:24.635259
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .test_transformer import BaseImportRewrite
    assert BaseImportRewrite.rewrites == []
    assert BaseImportRewrite.dependencies == []


# Generated at 2022-06-23 22:28:36.334789
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom(): 
    import astor
    import astunparse

    old_import = ast.Import(names=[ast.alias(name="unittest", asname="ut")])
    old_from_import = ast.ImportFrom(module="unittest", 
                                     names=[ast.alias(name="TestCase")],
                                     level=0)
    new_from_import = ast.ImportFrom(module="nose", 
                                     names=[ast.alias(name="TestCase")],
                                     level=0)
    expected = ast.Module(
        body=[ast.Try(
            body=[old_from_import],
            handlers=[],
            orelse=[new_from_import],
            finalbody=[])])

    tree = ast.parse("from unittest import TestCase")
    import_rewrite = BaseImportRewrite

# Generated at 2022-06-23 22:28:39.097342
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('a = 1')
    transformer = BaseNodeTransformer(tree=tree)
    assert transformer._tree is tree
    assert transformer._tree_changed == False

# Generated at 2022-06-23 22:28:44.587431
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass(BaseImportRewrite):
        rewrites = [
            ('foo1', 'foo2'),
            ('foo3.bar', 'foo4.bar')
        ]

    import_ast = ast.parse('import foo1\nimport foo3.bar')

    expected = ast.parse('try:\n    import foo1\nexcept ImportError:\n    import foo2\ntry:\n    import foo3.bar\nexcept ImportError:\n    import foo4.bar')

    assert TestClass.transform(import_ast).tree == expected.body


# Generated at 2022-06-23 22:28:45.560317
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer(): 
    tr = BaseTransformer()



# Generated at 2022-06-23 22:28:55.362449
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # Class under test
    class Test(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz.qux')]
    

    # Class to test with
    class TestImportFromNode(ast.ImportFrom):
        def __init__(self, lineno, col_offset, module, names):
            self.lineno = lineno
            self.col_offset = col_offset
            self.module = module
            self.names = names
            self.level = 0
    

    # Names to test

# Generated at 2022-06-23 22:29:01.063256
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('requests', 'urllib3')]

    tree = ast.parse('import requests')
    ast.fix_missing_locations(tree)

    (transformed, _, _) = Rewrite.transform(tree)
    assert transformed.body[0].body[0].body[0].value.func.value.id == 'urllib3'



# Generated at 2022-06-23 22:29:04.924951
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Tests if class BaseTransformer is an abstract class
    import abc
    assert isinstance(BaseTransformer, abc.ABCMeta)

    # Tests if abstract method transform is present in BaseTransformer
    import inspect
    assert 'transform' in inspect.getmembers(BaseTransformer, predicate=inspect.ismethod)


# Generated at 2022-06-23 22:29:08.160229
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'test'
        @classmethod
        def transform(cls, tree):
            return 'test'
    transformer = TestTransformer()
    assert transformer.target == 'test'


# Generated at 2022-06-23 22:29:18.088576
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_factory import ast_from_code
    from ..utils.ast_visitor import print_ast


    @snippet
    def test():
        from test.a import b


    node = ast_from_code(test)  # type: ast.Module

# Generated at 2022-06-23 22:29:21.211005
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse("import os\nimport re\nfrom subprocess import STDOUT, PIPE as pipe\nfrom re import *")
    t = BaseImportRewrite(tree)
    t.visit(tree)



# Generated at 2022-06-23 22:29:33.088699
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    code = 'from foo import bar\nfrom foo.bar import bar\nfrom foo.bar.baz import bar'
    tree = ast.parse(code)
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'foo_rewrited')]
    result = TestBaseImportRewrite.transform(tree)

# Generated at 2022-06-23 22:29:33.826085
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass


# Generated at 2022-06-23 22:29:35.194223
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None 
    assert BaseTransformer.transform == BaseTransformer.transform



# Generated at 2022-06-23 22:29:41.872628
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ...tests.templates.docs import python_docs_com_docs_ex1_py,\
        python_docs_com_docs_ex3_py,\
        python_docs_com_docs_ex4_py

    import astunparse
    rewriter = BaseImportRewrite()
    rewriter.rewrites = [('os', 'os.path')]
    tree = ast.parse(python_docs_com_docs_ex1_py.source)
    rewriter.visit(tree)
    expected = python_docs_com_docs_ex3_py.source
    code = astunparse.unparse(tree).rstrip()
    assert code == expected, code

    rewriter.rewrites = [('pdb', 'pudb')]

# Generated at 2022-06-23 22:29:42.912118
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()



# Generated at 2022-06-23 22:29:46.684969
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    rewrites = [
        ('six', 'six_minus_one'),
        ('six_minus_one', 'six.six_minus_one')
    ]
    obj = BaseImportRewrite(rewrites=rewrites)
    assert isinstance(obj, BaseImportRewrite)

# Generated at 2022-06-23 22:29:50.368747
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..parser import parse_file

    class SimpleAST(BaseNodeTransformer):
        def visit_Name(self, node):
            return ast.Str(s=node.id)

    with open('tests/simple.py') as f:
        tree = parse_file(f)

    result = SimpleAST.transform(tree)
    assert result
    
    

# Generated at 2022-06-23 22:29:51.801493
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        pass

    try:
        TestTransformer()
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 22:29:52.578734
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer

# Generated at 2022-06-23 22:30:03.682719
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import pprint
    import unittest

    class MyBaseTransformer(BaseTransformer):

        def transform(self, tree: ast.AST) -> TransformationResult:
            assert isinstance(self, MyBaseTransformer)
            return TransformationResult(tree, True, [])

    class MyBaseNodeTransformer(BaseNodeTransformer):

        rewrites = [('abc', 'xyz')]

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            assert isinstance(self, MyBaseNodeTransformer)
            return node

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            assert isinstance(self, MyBaseNodeTransformer)
            return node


# Generated at 2022-06-23 22:30:05.108130
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None)._tree_changed == False

# Generated at 2022-06-23 22:30:14.899495
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor  # noqa
    source = "from foo import bar"
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, ast.ImportFrom)
    ir = BaseImportRewrite(None)
    ir._tree_changed = False
    ir.rewrites = [("foo", "foo2")]
    result = ir.visit_ImportFrom(node)
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert astor.to_source(result) == (
        "try:\n    from foo2 import bar\n"
        "except ImportError:\n    from foo import bar")
    assert ir._tree_changed

# Generated at 2022-06-23 22:30:23.596453
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Sample(BaseImportRewrite):
        rewrites = [("previous_from_module", "new_from_module"),
                    ("previous_from_name", "new_from_name"),
                    ("previous_from_full_name", "new_from_full_name")]


# Generated at 2022-06-23 22:30:24.174815
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-23 22:30:26.105901
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        pass
    test_transformer = TestTransformer()

# Generated at 2022-06-23 22:30:26.477683
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:30:32.544674
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class MockTransformer(BaseImportRewrite):
        rewrites = [
            ('test', 'mock')
        ]

    class MockTransformerWithWildcard(BaseImportRewrite):
        rewrites = [
            ('test.a', 'mock')
        ]

    import_tree = ast.parse('import test')
    tree = MockTransformer(None).visit(import_tree)
    assert astor.to_source(tree) == 'try: extend(import test)\n' \
                                    'except ImportError: extend(import mock)'

    import_tree = ast.parse('import test.a')
    tree = MockTransformer(None).visit(import_tree)
    assert astor.to_source(tree) == 'try: extend(import test.a)\n' \
                                   

# Generated at 2022-06-23 22:30:38.826400
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import unittest
    import textwrap
    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    import six
    import astunparse

    class TestBaseImportRewrite(BaseImportRewrite):
        # Specify "rewrite" modules
        rewrites = [
            ('future.types', 'typing'),
            ('six.moves', 'six'),
        ]

    class TestCase(unittest.TestCase):
        maxDiff = None


# Generated at 2022-06-23 22:30:45.684320
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    transpiled_object = BaseImportRewrite()
    import_a = ast.Import(names=[
        ast.alias(name='a',
                  asname=None)])
    import_b = ast.Import(names=[
        ast.alias(name='b.a',
                  asname=None)])
    import_c1 = ast.Import(names=[
        ast.alias(name='c',
                  asname=None)])
    import_c2 = ast.Import(names=[
        ast.alias(name='c',
                  asname=None)])
    import_d1 = ast.Import(names=[
        ast.alias(name='d',
                  asname=None)])
    import_d2 = ast.Import(names=[
        ast.alias(name='d',
                  asname=None)])


# Generated at 2022-06-23 22:30:56.421278
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer1(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class TestTransformer2(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.baz')]

    class TestTransformer3(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.baz')]


# Generated at 2022-06-23 22:31:00.935588
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from typing import Optional
    from abc import ABCMeta, abstractmethod

    class BaseTransformer(metaclass=ABCMeta):
        target = None # type: Optional[CompilationTarget]

        @classmethod
        @abstractmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    t = BaseTransformer()
    t.target



# Generated at 2022-06-23 22:31:06.307554
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('import_rewrite', 'importrewrite'),
            ('typed_ast', 'typedast')
        ]

    import sys
    import import_rewrite
    import typed_ast


# Generated at 2022-06-23 22:31:17.104174
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('os.path', 'pathlib.Path'),
        ]

    tree = ast.parse('import os.path as path')
    transform_tree = TestTransformer.transform(tree)
    assert 'from pathlib import Path' in ast.dump(transform_tree.tree)
    assert 'from os.path import path' in ast.dump(transform_tree.tree)

    tree = ast.parse('import os.path')
    transform_tree = TestTransformer.transform(tree)
    assert 'import pathlib.Path' in ast.dump(transform_tree.tree)
    assert 'import os.path' in ast.dump(transform_tree.tree)



# Generated at 2022-06-23 22:31:27.567549
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.lexer import lex
    from ..utils.parser import parse

    exec(lex("from __future__ import absolute_import\nfrom test1 import *\nfrom test2 import A, B\nfrom test3 import *; from test4 import *\nfrom test5 import A, B, C"), globals())
    tree = parse(lex("from __future__ import absolute_import\nfrom test1 import *\nfrom test2 import A, B\nfrom test3 import *; from test4 import *\nfrom test5 import A, B, C"))
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('test2', 'test4'),
            ('test4', 'test4')
        ]

    TestTransformer.transform(tree)

# Generated at 2022-06-23 22:31:28.209877
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:31:29.757476
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite is not None


# Generated at 2022-06-23 22:31:32.213604
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__subclasshook__(BaseImportRewrite) is True
    assert BaseTransformer.__subclasshook__(BaseNodeTransformer) is True


# Generated at 2022-06-23 22:31:41.095565
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    with open('../test/test_files/simple.py') as f:
        tree = ast.parse(f.read())

    class CheckRewrite(BaseImportRewrite):
        rewrites = [('future', 'past')]

    result = CheckRewrite.transform(tree)
    new_tree = result.tree

    assert result.dependencies == ['past']
    assert result.changed
    assert isinstance(new_tree, ast.Module)
    assert len(new_tree.body) == 1
    assert isinstance(new_tree.body[0], ast.Try)
    assert isinstance(new_tree.body[0].body[1], ast.ImportFrom)
    assert new_tree.body[0].body[1].module == 'past'

# Generated at 2022-06-23 22:31:45.213558
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class DummyImportRewrite(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]


# Generated at 2022-06-23 22:31:46.938874
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    assert bt.target is None


# Generated at 2022-06-23 22:31:49.118937
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_rewrite = BaseImportRewrite()
    assert import_rewrite.rewrites == []
    assert import_rewrite.target == None

# Generated at 2022-06-23 22:31:50.122249
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite


# Generated at 2022-06-23 22:31:55.729787
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('hashlib', 'Crypto.Hash'),
        ]

    tree = ast.parse('import hashlib')
    result = Transformer.transform(tree)
    assert result.dependencies == ['Crypto']
    assert result.tree.body[0].body[0].body[0].value.names[0].name == 'Crypto.Hash'
    assert result.tree.body[0].body[1].value.names[0].name == 'hashlib'



# Generated at 2022-06-23 22:32:00.703242
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        target = '3.5'
        rewrites = [('foo', 'bar')]

    _in = '''
    import foo
    '''
    out = '''\
try:
    import foo
except ImportError:
    import bar
    '''
    result = TestTransformer.transform(_in)
    print(result)
    assert out == result


# Generated at 2022-06-23 22:32:11.395720
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import inspect
    import unittest

    class Test(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)

    class BaseNodeTransformerTestCase(unittest.TestCase):
        def test_init(self):
            tree = ast.parse('def foo(): pass')
            transformer = Test(tree)
            self.assertEqual(tree, transformer._tree)
            self.assertFalse(transformer._tree_changed)
            self.assertEqual([], transformer.dependencies)

    class BaseNodeTransformerSubclass(BaseNodeTransformer):
        dependencies = ['foo.bar']

        def __init__(self, tree):
            super().__init__(tree)


# Generated at 2022-06-23 22:32:18.731302
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer):
        def visit_Name(self, node):
            if node.id == '__builtins__':
                self._tree_changed = True
    tree = ast.parse('__builtins__.abs')
    Transformer.transform(tree)
    assert ast.dump(tree.body[0].value) == 'Call(func=Attribute(value=Name(id="abs", ctx=Load()), attr="abs", ctx=Load()), args=[], keywords=[])'



# Generated at 2022-06-23 22:32:21.713306
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError) as excinfo:
        BaseTransformer()
    assert 'Can\'t instantiate abstract class BaseTransformer with abstract methods transform' in str(excinfo.value)



# Generated at 2022-06-23 22:32:25.097222
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer1(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)
        def visit(self, node):
            pass
    assert(Transformer1)



# Generated at 2022-06-23 22:32:36.008869
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    getsource = lambda code: astor.to_source(ast.parse(code))

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('abc', 'def')]

    assert getsource(TestImportRewrite.transform(ast.parse('import abc')).tree) == \
        getsource('try:\n    import abc\nexcept ImportError:\n    import def')

    assert getsource(TestImportRewrite.transform(ast.parse('import abc as x')).tree) == \
        getsource('try:\n    import abc as x\nexcept ImportError:\n    import def as x')


# Generated at 2022-06-23 22:32:37.506464
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__init__(snippet)


# Generated at 2022-06-23 22:32:41.721319
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..tests.test_utils.test_parser import parsed

    class TestTransformer(BaseNodeTransformer):
        target = CompilationTarget.PYTHON_35

    tree = TestTransformer.transform(parsed.get_tree(
        'print(a)',
        target=CompilationTarget.PYTHON_35))

    assert tree.changed

# Generated at 2022-06-23 22:32:43.932199
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None



# Generated at 2022-06-23 22:32:46.403050
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..test.test_transform import BaseImportRewriteTest
    BaseImportRewriteTest.__init__Test()


# Generated at 2022-06-23 22:32:54.157828
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Rewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]

    def check(before, after):
        tree = ast.parse(before)
        result = Rewrite.transform(tree)
        assert not result.was_changed
        assert ast.dump(tree) == ast.dump(ast.parse(after))

    check(before='import old',
          after='import old')
    check(before='import old.module',
          after='import new.module')
    check(before='import old',
          after='import new')
    check(before='import old.module',
          after='import new.module')
    check(before='import old.module.submodule',
          after='import new.module.submodule')

# Generated at 2022-06-23 22:32:55.334920
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    print("BaseTransformer class can be constructed")

# Generated at 2022-06-23 22:32:57.527245
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

## Unit test for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:33:01.303272
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse("from shutil import copyfile")
    obj = BaseImportRewrite(tree=None)
    obj._tree_changed = False
    obj.rewrites = [("shutil", "backward.shutil")]
    new_node = obj.visit_ImportFrom(node)

    assert(str(new_node) == 'try:\n    from '.join(['copyfile',
                                                    'backward',
                                                    'shutil']))


# Generated at 2022-06-23 22:33:05.223982
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class __init__Test(metaclass=ABCMeta):
        @abstractmethod
        def transform(self, tree: ast.AST) -> TransformationResult:
            ...

    try:
        __init__Test()
    except TypeError:
        print('BaseTransformer test: __init__ test passed')
    else:
        print('BaseTransformer test: __init__ test failed')


# Generated at 2022-06-23 22:33:09.197426
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Given
    from ..utils.ast_ext import get_name
    from ..utils.typing import get_typing_type_node

    class Test_class(BaseImportRewrite):
        target = CompilationTarget.PYTHON_LEGACY

    # When
    c = Test_class()

    # Then
    assert (
        c.__class__.__name__ == "Test_class"
    )



# Generated at 2022-06-23 22:33:17.535200
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astroid
    def import_rewrite(previous, current):
        try:
            extend(previous)
        except ImportError:
            extend(current)
    import astropy
    import importlib
    try:
        extend(importlib)
    except ImportError:
        extend(astropy)
    import six
    try:
        extend(six)
    except ImportError:
        extend(astropy)


# Generated at 2022-06-23 22:33:18.081443
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:33:24.334406
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from astor import codegen
    from ..utils.visitor import Visitor

    class EmptyTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.AST:
            return self.generic_visit(node)

    class EmptyVisitor(Visitor, ast.NodeVisitor):
        def visit_Module(self, node: ast.Module) -> ast.AST:
            return self.generic_visit(node)

    tree = ast.parse('None')

    EmptyTransformer.transform(tree)
    EmptyVisitor.visit(tree)



# Generated at 2022-06-23 22:33:33.959100
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [
        ('mod1', 'rewritten.mod1'),
        ('mod2', 'rewritten.mod2'),
        ('mod3', 'rewritten.mod3'),
    ]
    class ImportRewrite(BaseImportRewrite):
        rewrites = rewrites

    module = ast.parse('from mod1 import str1 as alias1; from mod2 import *')
    visitor = ImportRewrite(module)
    result = visitor.visit(module)
    expected = ast.parse('''
        try:
            from mod1 import str1 as alias1
        except ImportError:
            from rewritten.mod1 import str1 as alias1
        try:
            from mod2 import *
        except ImportError:
            from rewritten.mod2 import *
    ''')

# Generated at 2022-06-23 22:33:37.771426
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer):
        pass

    inst = Transformer(None)
    assert inst._tree is None
    assert not inst._tree_changed



# Generated at 2022-06-23 22:33:38.941827
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    import typing


# Generated at 2022-06-23 22:33:47.489853
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import_from = ast.parse("from a.b.c import d, e as f, g as h").body[0]
    expected_1 = ast.parse("""
        from a.b.c import d

        from a.b.c import e as f

        from a.b.c import g as h
        """).body
    expected_2 = ast.parse("""
        try:
            from a.b.c import d
        except ImportError:
            from a.b.c import d
        """).body
    expected_3 = ast.parse("""
        try:
            from a.b.c import d, e as f as g as h
        except ImportError:
            from a.b.c import d, e as f as g as h
        """).body

# Generated at 2022-06-23 22:33:49.882009
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        cls = BaseTransformer()
    except:
        assert False, 'Failed to create instance of abstract class'
    assert True


# Generated at 2022-06-23 22:33:59.747609
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..tools import assert_same_tree

    @snippet
    def test():
        from package1.package2 import (object1,
                                       object2)
        from package1.package2 import object3 as alias1, object4 as alias2

    tree = ast.parse(test.get_body())
    result = astor.to_source(tree)
    assert result == test.get_body().strip()

    class ATest(BaseImportRewrite):
        rewrites = [
            ('package1', 'package3')
        ]

    tree = ast.parse(test.get_body())
    result = astor.to_source(tree)
    assert result == test.get_body().strip()

    ATest.transform(tree)
    result = astor.to_source(tree)


# Generated at 2022-06-23 22:34:09.666630
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transformer.base import BaseImportRewrite
    from ..transformer.base import import_rewrite

    source = """
    def foo():
        import x
        import y as z
        from a import b
        from c import d, e as f
        """
    expected = """
    def foo():
        try:
            extend(previous)
        except ImportError:
            extend(current)
        try:
            import a
        except ImportError:
            import b
        try:
            from c import d
        except ImportError:
            from d import d
        try:
            from c import e
        except ImportError:
            from e import e
        """


# Generated at 2022-06-23 22:34:20.745203
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import logging
    import tempfile
    import textwrap
    import unittest

    from ..utils.node import get_or_create_node_name
    from ..utils.visitor import get_used_variables
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import *  # noqa

    class TestTransformer(BaseNodeTransformer):

        def visit_Assert(self, node):
            return ast.Assign(targets=[Name(id="foo", ctx=Store())],
                              value=node.test)

    class Test(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger()

# Generated at 2022-06-23 22:34:23.595726
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert isinstance(BaseTransformer(), BaseTransformer)
    assert BaseTransformer.__class__.__name__ == 'BaseTransformer'


# Generated at 2022-06-23 22:34:25.670137
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_test1(BaseTransformer):
        pass
    assert BaseTransformer_test1.target is None

# Generated at 2022-06-23 22:34:28.161202
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_test(BaseTransformer):
        def __init__(self):
            super().__init__()


# Generated at 2022-06-23 22:34:28.753262
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:34:29.771100
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  BaseTransformer(None)

# Generated at 2022-06-23 22:34:33.933053
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class SimpleTransformer(BaseTransformer):
        def transform(self, tree: ast.AST) -> TransformationResult:
            return None

    assert hasattr(SimpleTransformer, 'target')
    assert SimpleTransformer.target is None

    r = SimpleTransformer.transform(None)
    assert r is None

# Generated at 2022-06-23 22:34:35.156649
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-23 22:34:36.836316
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseImportRewrite)

# Generated at 2022-06-23 22:34:45.574034
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ast import parse
    from typed_ast.ast3 import dump

    class RewriteTest(BaseImportRewrite):
        rewrites = [('test', 'tests')]

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    class RewriteTestNames(BaseImportRewrite):
        rewrites = [('test.module', 'tests.module')]

        def visit_ImportFrom(self, node: ast.ImportFrom) -> Union[ast.ImportFrom, ast.Try]:
            return super().visit_ImportFrom(node)

    class RewriteTestModuleAndNames(BaseImportRewrite):
        rewrites = [('test', 'tests'), ('test.module', 'tests.module')]


# Generated at 2022-06-23 22:34:54.052757
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    module = ast.parse("from antlr4.InputStream import InputStream")
    BaseImportRewrite.rewrites = [("antlr4", "antlr4-python3-runtime")]

    node = BaseImportRewrite.visit_ImportFrom(BaseImportRewrite(None), module.body[0])
    assert node is not None
    assert astunparse.unparse(node) == "try:\n    from antlr4.InputStream import InputStream\nexcept ImportError:\n    from antlr4_python3_runtime.InputStream import InputStream"



# Generated at 2022-06-23 22:34:56.524940
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    """Unit test for constructor of class BaseImportRewrite"""
    import astmonkey
    tree = astmonkey.transformers.ParentNodeTransformer().visit(ast.parse("""from ipdb import set_trace"""))
    obj = BaseImportRewrite(tree)
    assert obj._tree_changed is False


# Generated at 2022-06-23 22:35:02.264499
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("from django.core.serializers import json")
    result = BaseImportRewrite.transform(tree)
    assert result.tree == ast.parse("""
try:
    from django.core.serializers import json
except ImportError:
    from rest_framework.core.serializers import json
""")



# Generated at 2022-06-23 22:35:07.751140
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class RewriteTransformer(BaseImportRewrite):
        rewrites = [('X', 'Y')]
        dependencies = []

    tree = ast.parse('import X')
    result = RewriteTransformer.transform(tree)
    assert result.changed is True
    assert ast.dump(result.tree) == 'try:\n    import X\nexcept ImportError:\n    import Y'



# Generated at 2022-06-23 22:35:19.097858
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..utils.testing import assert_transformation
    from ..utils.testing import make_module
    from ..utils.testing import assert_result


    # constructor
    assert BaseTransformer.__subclasshook__(BaseTransformer)
    assert not BaseTransformer.__subclasshook__(ASTTransformer)
    assert not BaseTransformer.__subclasshook__(BaseNodeTransformer)
    assert not BaseTransformer.__subclasshook__(BaseImportRewrite)
    assert BaseNodeTransformer.__subclasshook__(BaseTransformer)
    assert BaseImportRewrite.__subclasshook__(BaseTransformer)

    mod = make_module("try:\n    pass")
    result = assert_transformation(
        BaseTransformer,
        mod,
        mod,
    )
    assert_result(result, True, [])

# Generated at 2022-06-23 22:35:25.364331
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_ast = ast.parse('import six')
    from_import_ast = ast.parse('from six import add_metaclass')
    from_import_2_ast = ast.parse('from six import add_metaclass, string_types')
    from_import_as_ast = ast.parse('from six import add_metaclass as x')
    from_import_2_as_ast = ast.parse('from six import add_metaclass as x, string_types')

    # No rewrite, just return
    assert BaseImportRewrite([]) is not None

    # Test import
    rewriter = BaseImportRewrite([('six', 'six.moves')])
    result = rewriter.visit(import_ast)
    assert isinstance(result, ast.Try)

    # Test import from
    rewriter = Base

# Generated at 2022-06-23 22:35:35.734449
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    # if module doesn't match
    module = ast.ImportFrom(
        module='foo',
        names=[ast.alias(name='X')])
    assert Transformer.transform(module).tree == module

    # if module matches
    module = ast.ImportFrom(
        module='foo.a',
        names=[ast.alias(name='X')])
    assert Transformer.transform(module).tree == import_rewrite.get_body(previous=module, current=ast.ImportFrom(
        module='foo.b',
        names=[ast.alias(name='X')]))[0]

    # if name doesn't match

# Generated at 2022-06-23 22:35:45.483843
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    test_class = BaseImportRewrite
    assert test_class.__name__ == 'BaseImportRewrite'
    assert test_class.__bases__ == (BaseNodeTransformer,)
    assert test_class.__module__ == 'ast_tools.transformer.base'
    test_class_instance = test_class(None)
    assert isinstance(test_class_instance, BaseImportRewrite)
    assert isinstance(test_class_instance, BaseNodeTransformer)
    assert isinstance(test_class_instance, ast.NodeTransformer)
    assert hasattr(test_class_instance, 'visit_Import')
    assert isinstance(test_class_instance.visit_Import, types.FunctionType) or \
        isinstance(test_class_instance.visit_Import, types.MethodType)
    assert hasattr

# Generated at 2022-06-23 22:35:52.396193
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
	assert BaseTransformer.__bases__ == (object,)
	assert BaseTransformer.__doc__ == None
	assert BaseTransformer.__name__ == 'BaseTransformer'
	assert BaseTransformer.__module__ == '__main__'
	assert BaseTransformer.__init__ == BaseTransformer.__init__
	assert BaseTransformer.__abstractmethods__ == {'transform'}

# Generated at 2022-06-23 22:35:53.475453
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # backward compatibility
    BaseNodeTransformer(None)

# Generated at 2022-06-23 22:36:03.227186
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from .transformers import BaseImportRewrite
    from .types import CompilationTarget
    from .utils.ast_helpers import print_ast

    code = 'from django.core.urlresolvers import reverse'

    class Rewrite(BaseImportRewrite):
        rewrites = [('django.core.urlresolvers', 'django.urls')]
        target = CompilationTarget.PY36

    tree = ast.parse(code)
    print_ast(tree)
    print(code)
    print()

    result = Rewrite.transform(tree)
    print_ast(result.tree)
    print(result.code)
    print()

    assert result.code == 'from django.urls import reverse'



# Generated at 2022-06-23 22:36:14.921265
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import ast_helper
    from tests.transformer.visitor.base_test import test_BaseNodeTransformer
    test_BaseImportRewrite = type(
        'test_BaseImportRewrite',
        (test_BaseNodeTransformer, BaseImportRewrite),
        {'rewrites': [(
            'os',
            'test_os'
        )]})
    visitor = test_BaseImportRewrite()
    visitor._tree_changed = False
    result = visitor.visit(ast.parse('from os import *'))
    assert ast_helper.module_to_source(result) == 'try:\n    from test_os import *\nexcept ImportError:\n    from os import *'
    result = visitor.visit(ast.parse('from os import path'))
   

# Generated at 2022-06-23 22:36:23.035464
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class ImportRewriteTransformer(BaseImportRewrite):
        rewrites = [('my_old_module', 'my_new_module')]


    tree = ast.parse('import my_old_module')
    result = ImportRewriteTransformer.transform(tree)
    assert not result.tree_changed
    assert not result.dependencies

    tree = ast.parse('from my_old_module import my_old_attr')
    result = ImportRewriteTransformer.transform(tree)
    assert not result.tree_changed
    assert not result.dependencies

    tree = ast.parse('from my_old_module import my_new_attr')
    result = ImportRewriteTransformer.transform(tree)
    assert not result.tree_changed
    assert not result.dependencies


# Generated at 2022-06-23 22:36:25.604628
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    assert transformer._tree is None
    assert transformer._tree_changed is False
    assert transformer.rewrites == []

# Generated at 2022-06-23 22:36:28.600567
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1 + 1')
    a = BaseNodeTransformer(tree)
    assert a._tree == tree
    assert a._tree_changed == False


# Generated at 2022-06-23 22:36:29.916302
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    with pytest.raises(NotImplementedError):
        transformer.transform(None)
