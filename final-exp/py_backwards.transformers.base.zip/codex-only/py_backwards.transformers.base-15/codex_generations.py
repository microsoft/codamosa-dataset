

# Generated at 2022-06-23 22:26:31.884557
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:26:38.311787
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_ = ast.Import(names=[
        ast.alias(name="foo.bar",
                  asname="baz")])
    import__ = ast.Import(names=[
        ast.alias(name="foo",
                  asname="baz")])
    import_from = ast.ImportFrom(module="foo.bar",
                                 names=[ast.alias(name="Baz",
                                                  asname=None)],
                                 level=0)
    import_from_ = ast.ImportFrom(module="foo",
                                  names=[ast.alias(name="Baz",
                                                   asname=None)],
                                  level=0)
    previous = import_rewrite.get_body(previous=import_,  # type: ignore
                                       current=import__)[0]

# Generated at 2022-06-23 22:26:46.832266
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportExample(BaseImportRewrite):
        rewrites = [('a', 'b')]  # type: List[Tuple[str, str]]

    tree = ast.parse('''
import a
import c
    ''')
    result = ImportExample.transform(tree)  # type: TransformationResult
    assert result.changed

    class ImportExample(BaseImportRewrite):
        rewrites = [('a.b', 'c.d')]  # type: List[Tuple[str, str]]

    tree = ast.parse('''
import a.b
import c.d
    ''')
    result = ImportExample.transform(tree)  # type: TransformationResult
    assert result.changed



# Generated at 2022-06-23 22:26:57.984449
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse('from module1 import name1, name2')  # type: ast.ImportFrom
    import_rewrite = BaseImportRewrite(None)
    assert import_rewrite.visit_ImportFrom(node) == ast.parse('from module1 import name1, name2')
    import_rewrite.rewrites = [('module1', 'module2')]
    assert import_rewrite.visit_ImportFrom(node) == ast.parse('from module2 import name1, name2')
    node = ast.parse('from module1 import *')
    assert import_rewrite.visit_ImportFrom(node) == ast.parse('from module2 import *')
    node = ast.parse('from module1.submodule1 import subname1, subname2')

# Generated at 2022-06-23 22:27:05.711042
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from astroid import builder  # type: ignore
    from typed_ast.ast3 import AST  # type: ignore

    class Dummy(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    builder = builder.AstroidBuilder()

# Generated at 2022-06-23 22:27:11.561107
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    input_node = ast.parse(
        """from qiskit.mapper import coupling, layout"""
    )
    expected_node = ast.parse(
        """
try:
    from qiskit.mapper import coupling, layout
except ImportError:
    from qiskit._mapper import coupling, layout
        """
    )

    compiled_node = BaseImportRewrite.transform(input_node)

    assert astor.to_source(expected_node) == astor.to_source(compiled_node.node)

# Generated at 2022-06-23 22:27:12.782918
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass


# Generated at 2022-06-23 22:27:19.928465
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget, TransformationResult
    import ast
    import typed_ast.ast3 as typed_ast 
    def func():
        print("some function")

    # BaseImportRewrite is not applicable
    assert BaseImportRewrite.transform(ast.parse(func())) == TransformationResult(ast.parse(func()), False, [])

    # BaseImportRewrite is applicable
    assert BaseImportRewrite.transform(typed_ast.parse(func())) == TransformationResult(typed_ast.parse(func()), True, [])

# Generated at 2022-06-23 22:27:22.053509
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, ast.NodeTransformer)
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)


# Basic test for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:27:31.832793
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast

    class ImportTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar'), ('.foo', '.bar')]

        def __init__(self, node: ast.AST) -> None:
            super().__init__(node)

    class TestImportTransformer:
        @staticmethod
        def test_dont_transform():
            """Test that import without rewrites isn't transformed."""
            node = ast.Import(names=[ast.alias(name='foo', asname='bar')])
            transformed = ImportTransformer.transform(node)
            assert not transformed.changed
            assert astor.to_source(transformed.tree).strip() == 'import foo as bar'


# Generated at 2022-06-23 22:27:43.306131
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree1 = ast.parse('from foo import a')
    tree2 = ast.parse('from goo import *')
    tree3 = ast.parse('from bar import *')
    tree4 = ast.parse('from boo import a')
    tree5 = ast.parse('from foo import b')
    tree6 = ast.parse('from foo import *')
    tree7 = ast.parse('from foo import * as bar')
    tree8 = ast.parse('from foo import x as y')
    tree9 = ast.parse('from foo import a, b')
    tree10 = ast.parse('from foo import b, c, a')
    tree11 = ast.parse('from foo import c, d, a')
    tree12 = ast.parse('from foo import x')

# Generated at 2022-06-23 22:27:45.291848
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
  class TestTransformer(BaseNodeTransformer):
    def __init__(self):
      pass

  assert TestTransformer(None)

# Generated at 2022-06-23 22:27:55.397533
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    import astor
    from ..transformer import BaseImportRewrite

    class T(BaseImportRewrite):
        target = "python_2"
        rewrites = [("http.client", "httplib")]

    code = '''
    import http.client
    '''
    tree = parse(code)
    T.transform(tree)
    print(astor.to_source(tree))
    assert astor.to_source(tree) == '''
    try:
        import http.client
    except ImportError:
        import httplib
'''



# Generated at 2022-06-23 22:28:01.457590
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Subclass(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = ast.parse('''
from old import a
from old import b as b_, c as c_, d
from old.e import e
from old.f import f as f_, g as g_, h
''')
    Subclass.transform(tree)

# Generated at 2022-06-23 22:28:06.236176
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from ..utils.utils import get_class_from_name

    transformer = get_class_from_name('typed_ast.transforms.ast3.BaseTransformer')
    test_transformer = transformer
    assert test_transformer.target == None


# Generated at 2022-06-23 22:28:16.346843
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class A(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]

    assert A.rewrites == [('a', 'b'), ('c', 'd')], A.rewrites
    assert A.dependencies == [], A.dependencies
    assert A.target is None, A.target
    assert A._get_matched_rewrite(None) == None, A._get_matched_rewrite(None)
    assert A._get_matched_rewrite('c') == ('c', 'd'), A._get_matched_rewrite('c')
    assert A._get_matched_rewrite('c.a') == ('c', 'd'), A._get_matched_rewrite('c.a')
    assert A._get_matched_rewrite('d.a') == None, A._get

# Generated at 2022-06-23 22:28:22.847301
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typing import TYPE_CHECKING
    from .tests_utils import assert_equal_source
    if TYPE_CHECKING:
        from ..transformers import TransformerCompatibility

    source = 'import django'
    expected = 'try:\n    import django\nexcept ImportError:\n    import jango'

    class TestTransformer(BaseImportRewrite):
        rewrites = [('django', 'jango')]

    tree = ast.parse(source)
    result = TestTransformer.transform(tree)
    assert_equal_source(result.tree, expected)

# Generated at 2022-06-23 22:28:23.691229
# Unit test for constructor of class BaseImportRewrite

# Generated at 2022-06-23 22:28:35.348197
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    code = """
from a.b.c import d, e as f
from a.b.c.d import g as h
from a.b import c as i
from a.b.c import g as j
"""
    node = ast.parse(code)
    result = BaseImportRewrite(None).visit_ImportFrom(node.body[0])
    assert isinstance(result, ast.Try)
    assert isinstance(result.body[1], ast.ImportFrom)
    assert result.body[1].module == 'x.y.z.d'
    assert result.body[1].names[0].name == 'e'
    assert result.body[1].names[0].asname == 'f'
    assert isinstance(result.body[2], ast.ImportFrom)

# Generated at 2022-06-23 22:28:43.039893
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typing
    import unittest
    from os.path import dirname, join

    from ..types import CompilationTarget
    from ..utils import ast_from_code
    from ..compile_builtins import compile_builtins

    MODULE = """import {from_}
from {from_}.a import b
from {from_}.a import c as d"""

    EXPECTED = """try:
    import {to}
except ImportError:
    import {from_}

try:
    from {to}.a import b
except ImportError:
    from {from_}.a import b

try:
    from {to}.a import c as d
except ImportError:
    from {from_}.a import c as d"""


# Generated at 2022-06-23 22:28:52.856842
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    from ..emit import emit
    from .transformer_test_case import TransformerTestCase, run_common_tests, run_annotated_test

    class TestTransformer(BaseImportRewrite):
        rewrites = [('urllib.request', 'urllib'),]

    class Test(TransformerTestCase):
        @classmethod
        def transform(cls, tree: ast.AST, *pargs) -> ast.AST:
            return TestTransformer.transform(tree).tree
        

# Generated at 2022-06-23 22:28:59.984850
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..tests.test_transformers import BaseImportRewrite as _BaseImportRewrite
    import astor
    import ast
    b = _BaseImportRewrite.construct(rewrites=[['tkinter.tix', 'ttk']])
    assert astor.to_source(b._replace_import(
        ast.Import(names=[ast.alias(name='tkinter', asname='ts')]), 
        'tkinter', 'ttk')) == 'try:\n    import tix as ts\nexcept ImportError:\n    import tkinter as ts'
    assert astor.to_source(b._replace_import_from_module(ast.ImportFrom(
        module='tkinter', names=[ast.alias(name='ttk', asname='ttk')], level=0),
        'tkinter', 'ttk'))

# Generated at 2022-06-23 22:29:00.374117
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass

# Generated at 2022-06-23 22:29:08.400098
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import sys
    import os
    import io
    #import pandas as pd
    import pandas as pd
    import pandas as pd
    import pandas as pd
    line_no_dict = {}
    sync_code_dict = {}
    def get_line_matching(file_name,string):
        #print("Entered get line matching")
        #print(file_name)
        #print(string)
        global line_no_dict
        if file_name in line_no_dict:
            return line_no_dict[file_name]
        else:
            line_no_dict[file_name] = []

# Generated at 2022-06-23 22:29:10.524167
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert isinstance(BaseImportRewrite.visit_Import(None, None), ast.Import)



# Generated at 2022-06-23 22:29:19.973696
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_, to = '_io', 'io'

    class Rewrite(BaseImportRewrite):
        rewrites = [(from_, to)]

    tree = ast.parse('import _io\n')
    rewrote = Rewrite.transform(tree)

    assert isinstance(rewrote, ast.Try)

    assert len(rewrote.body) == 1
    assert isinstance(rewrote.body[0], ast.Import)
    assert rewrote.body[0].names[0].name == to

    assert len(rewrote.handlers) == 1
    assert len(rewrote.handlers[0].body) == 1
    assert isinstance(rewrote.handlers[0].body[0], ast.Import)
    assert rewrote.handlers[0].body[0].names[0].name == from_


#

# Generated at 2022-06-23 22:29:22.591454
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()
    class Test(BaseTransformer):
        pass
    with pytest.raises(NotImplementedError):
        Test().transform(None)

# Generated at 2022-06-23 22:29:23.136216
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:29:34.835091
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import astor
    from ..testing import AssertAstEqualMixin

    class TestBaseImportRewrite_visit_Import(unittest.TestCase, AssertAstEqualMixin):
        def setUp(self):
            class TestBaseImportRewrite(BaseImportRewrite):
                rewrites = [
                        ('old', 'new')
                ]

            self.TestBaseImportRewrite = TestBaseImportRewrite

        def test_import(self):
            tree = ast.parse('import old')
            expected = ast.parse('import new')
            self.assertAstEqual(expected, self.TestBaseImportRewrite(tree).visit(tree))

        def test_import_as(self):
            tree = ast.parse('import old as new')
            expected = ast.parse('import new')

# Generated at 2022-06-23 22:29:41.626182
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import astor

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('unittest', 'unittest2')]


# Generated at 2022-06-23 22:29:51.830399
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    """
    `visit_ImportFrom` method of the `BaseImportRewrite` class will be tested.
    For this purpose, the class `BaseImportRewrite` should be inherited,
    and the `visit_ImportFrom` method should be overridden to be able to print the
    transformed code and compare it with the expected result.
    Subclass of `BaseImportRewrite` should have description of the rules of import
    rewriting in the `rewrites` variable.
    """
    class TestClass(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]
        def visit_ImportFrom(self, node):
            res = super().visit_ImportFrom(node)
            print(astor.to_source(res))
            return res


# Generated at 2022-06-23 22:29:52.883610
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite(): # type: ignore
    x = BaseImportRewrite()

# Generated at 2022-06-23 22:30:04.005143
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import parse

    rewrites = [('foo', 'bar')]

    class TestTransformer(BaseImportRewrite):
        rewrites = rewrites

    tree = parse('''
try:
    import foo.bar
except ImportError:
    import bar.bar
''')
    inst = TestTransformer(tree)
    inst.visit(tree)

    assert inst._tree_changed == True

    tree = parse('''
import foo.bar
''')
    inst = TestTransformer(tree)
    inst.visit(tree)

    assert inst._tree_changed == True

    tree = parse('''
try:
    import foo.bar
except ImportError:
    import bar.bar
''')
    inst = TestTransformer(tree)

# Generated at 2022-06-23 22:30:14.661728
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import jeeves

    src = '''
from typing import Optional, Any
from jeeves.BaseTransformer import BaseTransformer
from jeeves.BaseNodeTransformer import BaseNodeTransformer
from jeeves.BaseImportRewrite import BaseImportRewrite
from jeeves.utils.snippet import snippet
from jeeves.utils.snippet import extend
'''

    tree = ast.parse(src)
    BaseImportRewrite().visit(tree)
    tree = ast.fix_missing_locations(tree)
    print(jeeves.compile(tree, '<test>', 'exec'))


# Generated at 2022-06-23 22:30:18.616139
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class A(BaseNodeTransformer):
        pass

    tree = ast.parse('import sys')
    a = A(tree)
    assert isinstance(a, BaseNodeTransformer)
    assert isinstance(a, ast.NodeTransformer)


# Generated at 2022-06-23 22:30:28.906334
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor

    class ImportRewriteTransformer(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    # No matching
    test_tree = ast.parse('import sys')
    transformed = ImportRewriteTransformer.transform(test_tree)
    assert astor.to_source(transformed.tree) == 'import sys'

    # Rewrite
    test_tree = ast.parse('import six.moves.urllib.parse')
    transformed = ImportRewriteTransformer.transform(test_tree)
    assert astor.to_source(transformed.tree) == \
        'try:\n    import six.moves.urllib.parse\n' \
        'except ImportError:\n    import six.urllib.parse'



# Generated at 2022-06-23 22:30:36.210314
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass(BaseImportRewrite):
        rewrites = [('old', 'new')]

    test_tree = ast.parse(
        """import old as mod"""
    )
    res = TestClass.transform(test_tree)
    expected_result = ast.parse(
        """try:
    import old as mod
except ImportError:
    import new as mod"""
    )
    assert not res.tree_changed
    assert ast.dump(res.tree) == ast.dump(expected_result)



# Generated at 2022-06-23 22:30:41.809461
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)
            self._tree = 'test'
            self._tree_changed = True
    result = TestTransformer.transform('test_tree')
    assert result.new_tree == 'test'
    assert result.tree_changed
    assert result.dependencies == []


# Generated at 2022-06-23 22:30:45.117207
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        BaseTransformer()
        assert False
    except TypeError:
        pass
    assert BaseTransformer.target == None

# Generated at 2022-06-23 22:30:47.887979
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..utils import get_qualified_name
    assert get_qualified_name(BaseTransformer) == "python_modernize.fixes.base.BaseTransformer"



# Generated at 2022-06-23 22:30:49.670754
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer('tree')
    assert transformer._tree == 'tree'
    assert transformer._tree_changed == False


# Generated at 2022-06-23 22:30:59.328506
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_node_source = 'from foo import bar'
    import_node = ast.parse(import_node_source).body[0]

    import_node_expected_source = (
        'try:\n'
        '    from foo import bar\n'
        'except ImportError:\n'
        '    from baz import bar'
    )
    import_node_expected = ast.parse(import_node_expected_source).body[0]

    class SomeImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'baz')]

    actual = SomeImportRewrite.transform(import_node).tree.body[0]

    assert isinstance(actual, ast.Try)
    assert ast.dump(actual) == ast.dump(import_node_expected)


# Generated at 2022-06-23 22:31:06.474742
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    class SomeRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    new_tree = SomeRewrite.transform(tree).tree

    assert astor.to_source(tree) == 'import foo'
    assert astor.to_source(SomeRewrite.transform(tree).tree) == 'try:\n    import bar\nexcept ImportError:\n    import foo'

# Generated at 2022-06-23 22:31:08.988104
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        class ATest(BaseTransformer):
            pass
        a = ATest(None)


# Generated at 2022-06-23 22:31:19.325223
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('six.moves', 'six_moves')]

    original = ast.Import(
        names=[ast.alias(name='six.moves',
                         asname='moves')])
    expected = ast.Try(
        body=[ast.Import(
            names=[ast.alias(name='six_moves',
                             asname='moves')])],
        handlers=[ast.ExceptHandler(
            type=None,
            name=None,
            body=[ast.Pass()])],
        orelse=[],
        finalbody=[])

    transformed, changed, dependencies = TestTransformer.transform(original)
    assert transformed == expected
    assert changed



# Generated at 2022-06-23 22:31:30.613003
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    # Valid cases
    assert ast.dump(TestTransformer.transform(ast.parse('import foo', '<test>')).tree) == \
        "Try(body=[Import(names=[alias(name='bar', asname=None)], level=0)], " \
        "handlers=[ExceptHandler(type=Name(id='ImportError', ctx=Load()), name=None, body=[])], " \
        "orelse=[], finalbody=[])"


# Generated at 2022-06-23 22:31:33.484919
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None
    assert isinstance(transformer, BaseTransformer)
    assert issubclass(BaseTransformer, BaseTransformer)


# Generated at 2022-06-23 22:31:36.470107
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseImportRewrite)
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)


# Generated at 2022-06-23 22:31:42.703423
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.parse import parse_source
    
    source = '''from django.conf import settings'''
    ast_tree = parse_source(source)
    
    class Transform(BaseImportRewrite):
        rewrites = [('django.conf', 'django.core.conf')]
    
    result = Transform.transform(ast_tree)
    assert astor.to_source(result.tree) == '''
from django.core.conf import settings

'''

# Generated at 2022-06-23 22:31:43.233514
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:31:45.665267
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(ast.parse("1")).visit(ast.parse("1")) == ast.parse("1")

# Generated at 2022-06-23 22:31:49.300685
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = ast.parse('''import a
from a import b
from a import *
''')
    import_rewriter = BaseImportRewrite(tree)
    import_rewriter.visit(tree)


# Generated at 2022-06-23 22:31:50.631001
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target == None


# Generated at 2022-06-23 22:31:54.358689
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..parser import parse
    from ..types import CompilationTarget
    from .util import ast_equal

    tree = parse("print('hello')")
    transformer_cls = BaseNodeTransformer
    transformer = transformer_cls(tree)
    assert ast_equal(transformer._tree, transformer._tree)



# Generated at 2022-06-23 22:31:55.490732
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer()
    assert obj.target is None


# Generated at 2022-06-23 22:31:56.038415
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

# Generated at 2022-06-23 22:31:56.587796
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    pass

# Generated at 2022-06-23 22:32:04.692986
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import CompilationTarget
    from ..utils.ast_node import ast_to_source
    from ..utils.transformers import get_transformers
    from ..utils.compile_ast import compile_ast

    import ast
    import re
    import sys

    tree = ast.parse('import aiohttp')

    class MockBaseImportRewrite(BaseImportRewrite):
        target = CompilationTarget('asyncio', 'aiohttp', '0.22.1')
        rewrites = [('aiohttp', 'aiohttp'), ('standard_library', 'aiohttp')]

    mock_transformers = get_transformers(
        CompilationTarget('asyncio', 'aiohttp', '0.22.1'))
    mock_transformers.append(MockBaseImportRewrite)

    result = compile_ast

# Generated at 2022-06-23 22:32:16.019025
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from inspect import cleandoc
    from typing import Dict
    from .test_helpers import assert_node_equal, parse_ast

    class RewriteTests(object):
        def __init__(self):
            self.rewrites = []  # type: List[Tuple[str, str]]
            self.tests = {}  # type: Dict[str, Tuple[Optional[str], str]]

        def add(self, source: str, target: str=None, rewrite: Tuple[str, str]=('os', '_os')) -> None:
            self.rewrites.append(rewrite)
            if target is not None:
                self.tests[source] = (rewrite, target)

    tests = RewriteTests()

# Generated at 2022-06-23 22:32:26.002070
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('from foo import bar, baz')
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('foo', 'foo2')]
    transformed = transformer.visit(tree)
    

# Generated at 2022-06-23 22:32:26.737594
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:32:27.847853
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer


# Generated at 2022-06-23 22:32:33.663947
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = "Test"
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    transformer = TestTransformer()
    assert isinstance(transformer, BaseTransformer)
    assert transformer.target == "Test"


# Generated at 2022-06-23 22:32:38.504660
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # Test constructor  with no argument
    bnt = BaseNodeTransformer()
    # Test constructor with one argument
    tree = ast.parse('3')
    bnt1 = BaseNodeTransformer(tree)
    assert(bnt1._tree == tree)
    assert(bnt1._tree_changed == False)


# Generated at 2022-06-23 22:32:49.809324
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from typed_ast import codegen
    from typed_ast.ast3 import parse, iter_fields
    from typing import List, Tuple

    class SomeTransformer(BaseImportRewrite):
        rewrites = [
            ('pycocotools', 'pycocotools_old'),
            ('pycocotools.coco', 'pycocotools_old.coco'),
            ('pycocotools.mask', 'pycocotools_old.mask'),
            ('pycocotools.mask', 'pycocotools_old.mask'),
            ('json', 'ujson'),
        ]


# Generated at 2022-06-23 22:33:01.531001
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()
    #Test that there are no errors in that class
    BaseImportRewrite.visit_Import(None,[])
    BaseImportRewrite.visit_ImportFrom(None,[])
    BaseImportRewrite._get_replaced_import_from_part(None, None, None)
    BaseImportRewrite._get_matched_rewrite([])
    BaseImportRewrite._replace_import([],[],[])
    BaseImportRewrite._replace_import_from_module([],[],[])
    BaseImportRewrite._replace_import_from_names([],[])
    BaseImportRewrite._get_names_to_replace([])
    BaseImportRewrite.transform([])
    BaseImportRewrite.rewrites = []
    BaseImportRewrite.dependencies = []
    BaseImportRewrite.target = None


# Unit

# Generated at 2022-06-23 22:33:08.500656
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    non_rewrite_stmt = """import pickle"""
    non_rewrite_tree = ast.parse(non_rewrite_stmt)

    rewrite_stmt = """import numpy as np"""
    rewrite_tree = ast.parse(rewrite_stmt)

    transformer = BaseImportRewrite.__new__(BaseImportRewrite)
    transformer._tree_changed = False

    transformer.rewrites = [
        ('numpy', 'cupy')
    ]

    transformed = transformer.visit_Import(non_rewrite_tree.body[0])
    assert transformed is non_rewrite_tree.body[0]
    assert not transformer._tree_changed

    transformed = transformer.visit_Import(rewrite_tree.body[0])

# Generated at 2022-06-23 22:33:20.141757
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module = ast.parse('''
from ..__future__ import with_statement
from kivy.compat import xrange
import kivy.uix.button
from kivy.uix import button
from kivy.uix import (button,
    label, scrollview)
''')
    old_name = 'kivy.uix'
    new_name = 'kivy.uix2'

    class MyTransformer(BaseImportRewrite):
        rewrites = [(old_name, new_name)]

    result = MyTransformer.transform(module)
    assert result.changed is True


# Generated at 2022-06-23 22:33:28.319071
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("from one import car, thing; from two import *")
    BaseImportRewrite.rewrites = [('one.car', '_one_car'),
                                  ('two.thing', '_two_thing')]

    node = BaseImportRewrite.transform(tree)

    assert node.changed
    assert node.dependencies == ['_one_car', '_two_thing']
    assert ast.dump(node.tree) == """
try:
    from one import car, thing
except ImportError:
    from _one_car import car, thing
try:
    from two import *
except ImportError:
    from _two_thing import *
"""

# Generated at 2022-06-23 22:33:36.472748
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse, ImportFrom, dump
    from typed_ast.transforms.transformer import Transformer

    line = 'from typing import List, Union'
    node = parse(line).body[0]
    assert isinstance(node, ImportFrom)

    transformer = Transformer()
    cls = type('ConcreteNTR', (BaseImportRewrite,), {'rewrites': [
        ('typing', 'collections')
    ]})

    changed, tree = transformer.process(cls, node)
    assert changed
    assert line not in dump(tree)
    assert 'from collections import List' in dump(tree)

    line = 'from typing import List'
    node = parse(line).body[0]

    changed, tree = transformer.process(cls, node)
    assert changed
    assert line

# Generated at 2022-06-23 22:33:37.664527
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(1)

# Generated at 2022-06-23 22:33:48.067935
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Assert imports that should be removed
    for module_name in ('urllib', 'urllib2', 'urllib.request'):
        node = ast.Import(names=[ast.alias(name=module_name, asname=None)])
        name = 'urllib.request'
        replace_with = 'urllib.parse'
        inst = BaseImportRewrite(ast.parse('pass'))
        inst.rewrites = [(name, replace_with)]
        stmt = inst.visit_Import(node)

        assert isinstance(stmt, ast.Try)
        try_stmt = stmt

        assert isinstance(try_stmt.body, List)
        assert len(try_stmt.body) == 1
        import_stmt = try_stmt.body[0]


# Generated at 2022-06-23 22:33:50.658327
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformerTest(BaseTransformer):
        pass

    with pytest.raises(TypeError):
        BaseTransformerTest.transform(abc=None)



# Generated at 2022-06-23 22:33:58.504896
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..utils.transformer import BaseTransformer
    from ..utils.snippet import snippet
    import abc

    # Define a class for testing
    @snippet
    class TestTransformer(BaseTransformer):
        @abc.abstractmethod
        def transform(self, tree: ast.AST) -> TransformationResult:
            pass
    # End of define the class

    # Verify super constructor is called
    assert TestTransformer.__dict__ == BaseTransformer.__dict__

    # Unit test finished
    print('Test transformers.utils.transformer.BaseTransformer() finished')



# Generated at 2022-06-23 22:34:07.979222
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestCase(BaseImportRewrite):
        rewrites = [('asyncio', 'trollius')]

    tree = ast.parse("import asyncio")
    tree = TestCase.transform(tree).tree

    expected = """
try:
    import asyncio
except ImportError:
    import trollius
"""
    assert ast.dump(tree, annotate_fields=False, include_attributes=False) == expected

    tree = ast.parse("import asyncio.coroutine")
    tree = TestCase.transform(tree).tree

    expected = """
try:
    import asyncio.coroutine
except ImportError:
    import trollius.coroutine
"""
    assert ast.dump(tree, annotate_fields=False, include_attributes=False) == expected



# Generated at 2022-06-23 22:34:09.625385
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Arrange
    # Act
    # Assert
        assert True
        

# Generated at 2022-06-23 22:34:10.732492
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None

# Generated at 2022-06-23 22:34:16.575199
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Tester(BaseNodeTransformer):
        dependencies = ['a']

    tree = ast.parse('a = 1')
    tr = Tester(tree)
    assert tr._tree is tree
    assert tr._tree_changed is False
    tr._tree_changed = True
    assert tr._tree_changed is True

# Generated at 2022-06-23 22:34:27.643009
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    code = """
from a import b
from c import d
from e import f
from g import h
from i import *
from j.k import l
from a.b import c
from m.n.o import p
from q.r.s import t, u, v
"""

    tree = ast.parse(code)
    BaseImportRewrite.rewrites = [
        ('a', 'x'),
        ('g', 'y'),
        ('i', 'z'),
        ('j.k', 'w'),
        ('o', 's'),
        ('q.r', 't')
    ]

    BaseImportRewrite.transform(tree)


# Generated at 2022-06-23 22:34:28.997559
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    inst = BaseNodeTransformer(None)
    assert inst is not None

# Generated at 2022-06-23 22:34:33.073811
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test that attribute `dependencies` on class BaseImportRewrite is setup
    # correctly
    assert hasattr(BaseImportRewrite, 'dependencies')

    # Test that attribute `dependencies` on class BaseImportRewrite is setup
    # correctly
    assert hasattr(BaseImportRewrite, 'rewrites')

# Generated at 2022-06-23 22:34:43.958480
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from typed_ast.ast3 import Import
    from typed_ast.ast3 import alias
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from ..utils.snippet import snippet
    import unittest

    class ImportRewriter(BaseImportRewrite):
        rewrites = [
            ('import_rewrite', 'import_rewrite_from_typed_ast.transforms')
        ]

    @snippet
    def test_import_from_snippet(imp):
        extend(imp)

    body = test_import_from_snippet.get_body(imp=ast.Import(names=[alias('import_rewrite', 'extend')]))
    tree = ast.Module(body=body)

# Generated at 2022-06-23 22:34:45.018368
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  bt = BaseTransformer()
  assert bt.target == None


# Generated at 2022-06-23 22:34:52.756847
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()
    import astor
    from polysquarelinter.linter.transformer import BaseImportRewrite
    cls = BaseImportRewrite()
    cls.rewrites = [['abc', 'def']]
    tree = astor.parse_file('duck.py')
    assert isinstance(tree, ast.AST)
    tree = cls.transform(tree)
    assert isinstance(tree, ast.AST)
    assert isinstance(tree, ast.Import)
    assert isinstance(tree, ast.ImportFrom)

# Generated at 2022-06-23 22:34:59.003513
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from ast_tools.transformers.base import BaseImportRewrite
    from ast_tools.transformers import ast

    def parse(source):
        return ast.parse(source)

    def dump(node):
        import astunparse
        return astunparse.unparse(node)

    class T(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class Test(unittest.TestCase):
        def test_import_from_module(self):
            source = 'from foo import bar'
            expected = 'try:\n    from foo import bar\nexcept ImportError:\n    from bar import bar'
            node = parse(source)
            T().visit(node)
            self.assertEqual(dump(node), expected)


# Generated at 2022-06-23 22:35:08.683305
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.snippet import get_ast
    import ast

    class Dummy(BaseImportRewrite):
        rewrites = [('yaml', 'yml')]

    tree = get_ast("import yaml")
    result = Dummy.transform(tree)
    assert result == TransformationResult(get_ast("try:\n    import yml\nexcept ImportError:\n    import yaml"), True, [])
    tree = get_ast("import foo.yaml")
    result = Dummy.transform(tree)
    assert result == TransformationResult(get_ast("try:\n    import foo.yml\nexcept ImportError:\n    import foo.yaml"), True, [])

    tree = get_ast("from yaml import load")
    result = Dummy.transform(tree)

# Generated at 2022-06-23 22:35:17.267448
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Tester(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    inst = Tester(None)
    node = ast.Import(names=[ast.alias(name='foo', asname='Foo')])
    node = inst.visit_Import(node)
    assert isinstance(node, ast.Try), "Simple import rewrite failed"
    exc = node.body[0].body[0]
    assert isinstance(exc, ast.Import), "Simple import rewrite failed"



# Generated at 2022-06-23 22:35:20.278842
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():

    from .base import BaseImportRewrite


# Test for member variable rewrites of class BaseImportRewrite

# Generated at 2022-06-23 22:35:21.656390
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("print('test')")
    BaseNodeTransformer(tree)


# Generated at 2022-06-23 22:35:26.378301
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget(True, True, True, True, '1.8.0')
    with pytest.raises(TypeError):
        BaseTransformer(target)


# Generated at 2022-06-23 22:35:30.100830
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None
    assert isinstance(BaseTransformer.transform, staticmethod)
    assert hasattr(BaseTransformer.transform, '__call__')
    

# Generated at 2022-06-23 22:35:32.956057
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.transform


# Generated at 2022-06-23 22:35:35.132517
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'
    assert isinstance(BaseImportRewrite.rewrites, list)


# Generated at 2022-06-23 22:35:41.148983
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import gi
    import gi.repository
    
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('gtk', 'gi.repository.Gtk'),
        ]

    tree = ast.parse('''
    from gtk import Button as B1
    from gi.repository import Gtk
    from Gtk import Button as B2

    import gtk
    import gi.repository
    import Gtk

    from gtk import *
    from gi.repository import *
    from Gtk import *
    ''')


# Generated at 2022-06-23 22:35:42.023163
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    t = BaseTransformer()

# Generated at 2022-06-23 22:35:48.460277
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Must not fail."""
    class ImportRewrite(BaseImportRewrite, ast.NodeTransformer):
        rewrites = [('foo', 'bar')]

    module = ast.parse(
        """
from foo import x
from foo import y as z
from foo import a, b, c
from foo import *
""")

    ImportRewrite.transform(module)

# Generated at 2022-06-23 22:35:52.083743
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'baz')]

    tree = ast.parse("import foo.bar")
    expected_tree = ast.parse("try:\n    import foo.bar\nexcept ImportError:\n    import baz")
    node_transformer = ImportRewrite(tree)
    result = node_transformer.visit(tree)
    assert result == expected_tree


# Generated at 2022-06-23 22:36:02.351538
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = [('foo', 'bar')]
    tree = ast.parse("import foo; import foo.bar as foobar; from foo import bar")
    expected = ast.parse("try: import foo; import bar.bar as foobar; from bar import bar; except ImportError: import bar")
    result = BaseImportRewrite.transform(tree)
    assert result[0].body[0].body[0] == expected.body[0].body[0]
    assert result[0].body[0].body[1] == expected.body[0].body[1]
    assert result[0].body[0].body[2] == expected.body[0].body[2]
    assert result[0].body[1].body[0] == expected.body[1].body[0]


# Generated at 2022-06-23 22:36:05.527104
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == "BaseImportRewrite"
    assert isinstance(BaseImportRewrite, type)
    assert issubclass(BaseImportRewrite, BaseNodeTransformer)


# Generated at 2022-06-23 22:36:06.186472
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:36:07.731855
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(None) != None


# Generated at 2022-06-23 22:36:14.203741
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    text = 'import re'
    t = ast.parse(text)
    assert type(t) == ast.Module
    assert str(t) == 'import re\n'
    t = BaseImportRewrite(t)
    t.visit(t.tree)
    assert type(t._tree) == ast.Module
    assert str(t._tree) == 'import re\n'

# Generated at 2022-06-23 22:36:16.718545
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    try:
        object.__new__(BaseNodeTransformer)  # type: ignore
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 22:36:24.499609
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import CompilationError
    from . import lint, standard
    from .lint import PylintTransformer


    class MyTransformer(BaseImportRewrite):
        rewrites = [('abc', 'abcdef')]



# Generated at 2022-06-23 22:36:25.273939
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer()


# Generated at 2022-06-23 22:36:26.486213
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite(): assert BaseImportRewrite


# Generated at 2022-06-23 22:36:28.110321
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    cls = BaseImportRewrite()
    assert cls is not None

# Generated at 2022-06-23 22:36:33.660395
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    import_from = ast.parse(
        '''
        from my_module import SomeType
        ''').body[0]
    rewrites = [('my_module', 'new_module')]
    import_rewrite = BaseImportRewrite(None, rewrites)
    import_rewrite._tree_changed = False
    import_rewrite._get_matched_rewrite = lambda name: ('my_module', 'new_module')
    import_rewrite._replace_import_from_module = lambda node, from_, to: ast.parse(
        '''
        from new_module import SomeType
        ''').body[0]
    assert astunparse.unparse(import_rewrite.visit_ImportFrom(import_from)) == \
        'from new_module import SomeType'