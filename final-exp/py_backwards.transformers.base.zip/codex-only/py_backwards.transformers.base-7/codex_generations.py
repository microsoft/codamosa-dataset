

# Generated at 2022-06-23 22:26:39.640038
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import check_transformation

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('os.path', 'pathlib.PosixPath')]

    check_transformation(
        ImportRewrite,
        'from os.path import something',
        'from pathlib.PosixPath import something',
    )
    check_transformation(
        ImportRewrite,
        'from os.path import something, another',
        'from pathlib.PosixPath import something, another',
    )
    check_transformation(
        ImportRewrite,
        'from os.path import *',
        'from pathlib.PosixPath import *',
    )

# Generated at 2022-06-23 22:26:41.368485
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__class__ == BaseImportRewrite


# Generated at 2022-06-23 22:26:52.871978
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_astunparse
    

# Generated at 2022-06-23 22:26:54.662020
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    m = BaseImportRewrite()
    assert isinstance(m, BaseImportRewrite)

# Generated at 2022-06-23 22:26:59.216923
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class DummyTransformer(BaseNodeTransformer):
        target = CompilationTarget.PYTHON3
        def visit_NameConstant(self, node):
            self._tree_changed = True
            return ast.Num(1)
    import astor

# Generated at 2022-06-23 22:27:01.563307
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('x = 1 + 2')
    inst = BaseNodeTransformer(tree)
    results = inst.visit(tree)
    assert isinstance(results, ast.Module)



# Generated at 2022-06-23 22:27:03.068978
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite
    # More specific tests in test_...transformer.py files
    assert True

# Generated at 2022-06-23 22:27:08.730344
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class DummyNodeTransformer(BaseNodeTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

        def visit_Name(self, node: ast.Name) -> ast.Name:
            return ast.Name(id='hello')

    assert ast.dump(DummyNodeTransformer.transform('x')[0]) == "Name(id='hello', ctx=Load())"

# Generated at 2022-06-23 22:27:14.336594
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # Test method _get_matched_rewrite
    from_1 = 'a'
    to_1 = 'b'
    name = 'a'
    assert BaseImportRewrite(None)._get_matched_rewrite(name) == (from_1, to_1)
    name = 'a.b'
    assert BaseImportRewrite(None)._get_matched_rewrite(name) == (from_1, to_1)

    from_2 = 'somemodule'
    to_2 = 'newmodule'
    name = 'somemodule'
    assert BaseImportRewrite(None)._get_matched_rewrite(name) == (from_2, to_2)
    name = 'somemodule.b'
    assert BaseImportRewrite(None)._get_matched_rewrite

# Generated at 2022-06-23 22:27:21.763686
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    # Some aliases to replace
    src = 'from multiprocessing import Pool, cpu_count'
    # Expected result
    expected_src = """try:
    from multiprocessing import Pool, cpu_count
except ImportError:
    from multiprocessing.dummy import Pool, cpu_count"""

    # Call method
    import_rewriter = BaseImportRewrite(ast.parse(src))
    node = import_rewriter.visit(ast.parse(src))
    test_src = astor.to_source(node)

    # Evaluate result
    assert test_src == expected_src


# Generated at 2022-06-23 22:27:22.583535
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert isinstance(BaseImportRewrite(), BaseImportRewrite)

# Generated at 2022-06-23 22:27:28.298811
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import typed_ast.ast3 as ast

    from .test_utils import get_node_object

    class Test(BaseImportRewrite):
        rewrites = [
            ('os', 'import os')
        ]

    class TestCase(unittest.TestCase):
        def test_1(self):
            """Tests if one rewrite result has been created."""
            node = ast.Import(names=[
                ast.alias(name='os', asname=None)])

            result = Test(node).visit_Import(node)  # type: ignore
            self.assertIsInstance(result, ast.Try)
            self.assertEqual(len(result.body), 1)
            self.assertIsInstance(result.body[0], ast.Import)

# Generated at 2022-06-23 22:27:37.229048
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    statements = [
        'import my_module',
        'import my_module as my_module_as',
        'import my_module_submodule as my_module_submodule_as',
        'import my_module_submodule.my_module_submodule_submodule as my_module_submodule_submodule_as',
    ]

    class test_BaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [('my_module', 'your_module')]

    for statement in statements:
        tree = ast.parse(statement)

        class_ = test_BaseImportRewrite_visit_Import
        result = class_.transform(tree)

        assert result.tree.body[0].value.names[0].name == 'your_module'
        assert astor.to

# Generated at 2022-06-23 22:27:39.911718
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.test_utils import assert_type

    @snippet
    def transform_test(test):
        assert_type('test', test, BaseNodeTransformer,
                    args=[ast.AST], kwargs={},
                    properties={'_tree': ast.AST, '_tree_changed': bool})

    transform_test.apply([BaseNodeTransformer])



# Generated at 2022-06-23 22:27:47.292984
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import pytest
    import astor
    from typed_ast import ast3 as typed_ast
    source = """
from os import path
from os.path import join

join()
"""
    tree = typed_ast.parse(source)
    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('os.path', 'os')]
    node = transformer.visit(tree)
    assert astor.to_source(node) == 'import os\n\n\njoin()\n'



# Generated at 2022-06-23 22:27:58.272738
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast, astunparse
    from ..utils.pytest_plugin import assert_pyast_equal
    import this
    import antigravity
    from ..version import __version__
    from ..utils.pytest_plugin import pytest_transformer_test
    class TestTransformer(BaseImportRewrite):
        target = 'python36'
        rewrites = [
            ('this', 'that'),
            ('antigravity', 'gravity')
        ]
    testcase = TestTransformer.transform
    import this
    import antigravity
    import sys, os
    from ..version import __version__
    from ..utils.snippet import import_rewrite
    import this
    try:
        import that
    except ImportError:
        import that
    import antigravity

# Generated at 2022-06-23 22:27:59.254814
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    pass

# Generated at 2022-06-23 22:28:07.631537
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .. import ast
    from . import utils
    from .utils import scenarios
    from .utils.scenarios import VisitTestScenario
    from .utils.samples import IMPORT_SAMPLES

    scenarios.register(VisitTestScenario(
        target=CompilationTarget.PY27,
        node_class=ast.Import,
        node_test_data=IMPORT_SAMPLES,
        transformer_class=BaseImportRewrite,
        expected_node_test_data=[]))
    utils.run_visit_test_scenarios()


# Generated at 2022-06-23 22:28:09.007325
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer().target is None

# Generated at 2022-06-23 22:28:10.950513
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    transformer = BaseNodeTransformer(tree=1)
    assert transformer._tree == 1
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:28:17.027175
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class test_BaseNodeTransformer_case1(BaseNodeTransformer):
        pass

    class test_BaseNodeTransformer_case2(BaseNodeTransformer):
        dependencies = ["parent"]

    guess = test_BaseNodeTransformer_case1()
    assert isinstance(guess, BaseNodeTransformer)
    assert guess.dependencies == []

    guess = test_BaseNodeTransformer_case2()
    assert isinstance(guess, BaseNodeTransformer)
    assert guess.dependencies == ["parent"]

# Generated at 2022-06-23 22:28:18.389695
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()


# Generated at 2022-06-23 22:28:19.251079
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    transformer.target

# Generated at 2022-06-23 22:28:29.982312
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.strings import dedent
    from ..utils.ast import parse_ast_from
    from ..utils.pprint import dump_ast, dump_ast_with_comments

    class BaseImportRewriteTest(BaseImportRewrite):
        rewrites = [('os', 'future_builtins.os')]

    test_code = """
    from os import getcwd
    from os import path

    from os import system
    from os import path as p
    from os import system as system_
    """


# Generated at 2022-06-23 22:28:40.169494
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    import_ = ast3.Import(names=[ast3.alias(name='os', asname='osx')])
    rewrite = BaseImportRewrite(None)
    rewrite.rewrites = [('os', 'osx')]
    try_ = rewrite.visit_Import(import_)
    assert isinstance(try_, ast3.Try)
    except_ = try_.body[0].body[0]
    assert isinstance(except_, ast3.ExceptHandler)
    inner_import = except_.body[0]
    assert isinstance(inner_import, ast3.Import)
    assert inner_import.names[0].name == 'osx'



# Generated at 2022-06-23 22:28:41.343483
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    bla = BaseImportRewrite()
    assert bla.rewrites == []

# Generated at 2022-06-23 22:28:42.146642
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer()



# Generated at 2022-06-23 22:28:51.209678
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast as py_ast
    import typed_ast.ast3 as ty3_ast
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    for python_version in range(3, 9):
        for statement in (
            'from a import c',
            'from a.d import e',
            'from a import *',
            'from a.f import *',
            'from a import c as d',
            'from a.e import f as g',
            'from .i import j',
            'from . import i',
        ):
            for level in range(0, 2):
                node = py_ast.parse(statement).body[0]
                node.level = level
                py_node = py_ast.parse(statement).body[0]
               

# Generated at 2022-06-23 22:28:52.170069
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    x = BaseImportRewrite()
    

# Generated at 2022-06-23 22:28:53.128101
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer.target = 'Python 3'

# Generated at 2022-06-23 22:28:57.659340
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseNodeTransformer):
        def visit_Pass(self, node):
            return node

    tree = ast.parse('pass')
    assert TestTransformer.transform(tree) == TransformationResult(ast.parse('pass'), False, [])
    assert TestTransformer.transform(tree).tree == tree
    assert TestTransformer.transform(tree).changed is False
    assert TestTransformer.transform(tree).dependencies == []

# Generated at 2022-06-23 22:28:58.764323
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert(BaseNodeTransformer(None) is not None), "Constructor of class BaseNodeTransformer must work"

# Generated at 2022-06-23 22:29:00.649263
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class test(BaseTransformer):
        target = 'python-2'
        @classmethod
        def transform(cls, tree):
            return 100
    res = test.transform(1)
    assert res == 100


# Generated at 2022-06-23 22:29:01.123086
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite



# Generated at 2022-06-23 22:29:03.019354
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import inspect
    assert inspect.isclass(BaseNodeTransformer)
    assert issubclass(BaseNodeTransformer, BaseTransformer)


# Generated at 2022-06-23 22:29:04.886596
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import_rewrite_snippet = """
try:
    import module1
except ImportError:
    import module2
"""
    exec(compile(import_rewrite_snippet, '<string>', 'exec'))

# Generated at 2022-06-23 22:29:07.252862
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class BaseImportRewriteSubClass(BaseImportRewrite):
        tree = None
        rewrites = []
    test = BaseImportRewriteSubClass(BaseImportRewriteSubClass.tree)


# Generated at 2022-06-23 22:29:11.691106
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..tests.pytest_assert import assert_compiled_ok, assert_source_equal

    class EmptyClass(BaseNodeTransformer):
        pass

    assert isinstance(EmptyClass(None), EmptyClass)
    assert_compiled_ok(EmptyClass(ast.parse('1 + 1')))
    assert_source_equal(EmptyClass(ast.parse('1 + 1')).visit(ast.parse('1 + 1')), '2')



# Generated at 2022-06-23 22:29:22.321587
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .utils import patch

    old_import = patch('astunparse.unparse.unparse',
                       lambda x: 'unparsed old import')
    new_import = patch('astunparse.unparse.unparse',
                       lambda x: 'unparsed new import')
    node = ast.parse('import foo')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    t = TestImportRewrite(node)
    new_node = t.visit(node)
    assert isinstance(new_node, ast.Try)
    old_import.assert_called_once_with(node)
    new_import.assert_called_once_with(node)



# Generated at 2022-06-23 22:29:23.788516
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer.target = CompilationTarget('python') # type: ignore

# Generated at 2022-06-23 22:29:28.189572
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class A(BaseNodeTransformer):
        pass
    astree = ast.parse("a = 1 + 2")
    transformer = A(astree)
    assert transformer._tree == astree
    assert transformer._tree_changed == False

# Generated at 2022-06-23 22:29:38.653176
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transform(BaseImportRewrite):
        rewrites = [('re', 'regex')]
        dependencies = []
        def __init__(self, tree):
            super().__init__(tree)
        def visit_Import(self, node):
            super().visit_Import(node)
        def visit_ImportFrom(self, node):
            super().visit_ImportFrom(node)
    input_program = '''
import re
import re.match
import re.sub
from re import match, sub
from re.sub import pattern
    '''

# Generated at 2022-06-23 22:29:40.138940
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    testBaseTransformer = BaseTransformer()


# Generated at 2022-06-23 22:29:42.783733
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = 'python3'
        def transform(cls, tree):
            pass
    assert Transformer.target is 'python3'

# Generated at 2022-06-23 22:29:50.369547
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import typing
    import random
    import string


    class Renamer(BaseImportRewrite):
        rewrites = [
                ('inspect', 'typing')
        ]

    # It should replace simple ImportFrom
    def _1():
        nonlocal ast, typing, Renamer
        import ast, typing  # type: inspect.getmembers, typing.getmembers
        node = ast.parse("import ast, typing").body[0]
        Renamer().visit(node)
        assert node == ast.parse("import ast, typing").body[0]


    _1()
    # It should replace simple ImportFrom using ast.Name.id
    def _1():
        nonlocal ast, typing, Renamer
        import ast, typing  # type: inspect.getmembers, typing.getmembers
        node = ast.parse

# Generated at 2022-06-23 22:29:55.291036
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils import astdump

    class DummyTransformer(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node.id = 'foo'
            self._tree_changed = True
            return node

    tree = ast.parse('a')
    result = DummyTransformer.transform(tree)
    assert result == TransformationResult(tree=ast.parse('foo'), tree_changed=True, dependencies=[])



# Generated at 2022-06-23 22:30:03.407680
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    code = """
    import sys
    import os

    from os.path import exists as os_exists

    import foo as bar

    from baz import foo as baz_foo
    from baz import bar as baz_bar
    from baz import baz

    from baz.submodule import bar as baz_submodule_bar
    from baz.submodule import foo as baz_submodule_foo
    """
    tree = ast.parse(code)
    result = BaseNodeTransformer.transform(tree)
    assert result == TransformationResult(tree, False, [])

# Generated at 2022-06-23 22:30:06.871354
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # Subclass of BaseNodeTransformer
    class T(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)

    assert isinstance(T(None), ast.NodeTransformer)



# Generated at 2022-06-23 22:30:17.147830
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..types import ImportFromStatement, OtherImportStatement

    import_ = ast.ImportFrom(module='import_1',
                             names=[ast.alias(name='name_1', asname='asname_1')],
                             level=0)
    node_transformer = BaseImportRewrite([('import_1', 'rewrite_1')])
    assert node_transformer.visit_ImportFrom(import_) == \
        ImportFromStatement.from_source("""try:
    from import_1 import name_1 as asname_1
except ImportError:
    from rewrite_1 import name_1 as asname_1""")


# Generated at 2022-06-23 22:30:20.716682
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('def foo():\n\treturn 2')
    transformer = BaseNodeTransformer(tree)
    assert transformer._tree == tree
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:30:30.515409
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

# Generated at 2022-06-23 22:30:36.997274
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.snippet import body
    _tree_changed = False

    class Transformer(BaseNodeTransformer):
        def visit_Name(self, node):
            self._tree_changed = True

    result = Transformer.transform(body[0])
    assert result.tree_changed == True
    assert result.dependencies == Transformer.dependencies
    assert result.tree == body[1]

# Generated at 2022-06-23 22:30:42.544469
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ..utils.visitor import ASTVisitor
    class MyTransformer(BaseNodeTransformer):
        def visit_Import(self, node: ast.Import) -> ast.Import:
            node.names[0].name = 'my_module'
            return node
    tree = ast.parse('import sys')
    MyTransformer(tree).visit(tree)
    assert ASTVisitor().visit(tree) == 'import my_module'

# Generated at 2022-06-23 22:30:44.407700
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__subclasshook__(BaseTransformer) is True

# Generated at 2022-06-23 22:30:46.145106
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1')
    tr = BaseNodeTransformer(tree)
    assert tr._tree is tree
    assert not tr._tree_changed

# Generated at 2022-06-23 22:30:46.791029
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:30:49.096455
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite().dependencies == []
    assert BaseImportRewrite().target is None
    assert BaseImportRewrite().rewrites == []



# Generated at 2022-06-23 22:30:58.949962
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse('''
try:
    import a  # noqa
except ImportError:
    import b

try:
    from c import d
except ImportError:
    from c import d

try:
    from a import b
except ImportError:
    from b import b
''')
    expected_tree = ast.parse('''
try:
    import b  # noqa
except ImportError:
    import b

try:
    from c import d
except ImportError:
    from c import d

try:
    from b import b
except ImportError:
    from b import b
''')
    assert ImportRewrite.transform(tree)[0] == expected_tree

# Generated at 2022-06-23 22:31:02.097591
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():  # noqa: D103
    try:
        BaseTransformer()
    except TypeError:
        pass
    else:
        raise AssertionError('Must be initialized from metaclass')

# Generated at 2022-06-23 22:31:11.287273
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astunparse
    import_ast = ast.parse('import example')
    import_from_ast = ast.parse('from example import test')
    import_from_ast2 = ast.parse('from test import example')
    transformer = BaseImportRewrite
    transformer.rewrites = [('example', 'other_example')]
    print(astunparse.unparse(transformer.transform(import_ast).tree))
    print(astunparse.unparse(transformer.transform(import_from_ast).tree))
    print(astunparse.unparse(transformer.transform(import_from_ast2).tree))

# Generated at 2022-06-23 22:31:13.858393
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'
    assert hasattr(BaseImportRewrite, 'transform')


# Generated at 2022-06-23 22:31:15.017822
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite(None)

# Generated at 2022-06-23 22:31:22.569769
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import astunparse
    import sys
    from six import text_type
    
    class CompilationTarget(object):
        def __init__(self, target):
            self.target = target
            
    from .visitors import BaseImportRewrite
    

# Generated at 2022-06-23 22:31:33.485105
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('module_x', 'module_y')]

    node = ast.parse('from module_x import name1, name2').body[0]
    expected = ast.parse('try:\n    from module_y import name1, name2\n'
                         'except ImportError:\n    from module_x import name1, name2')
    actual = TestImportRewrite.transform(node).tree
    assert ast.dump(expected) == ast.dump(actual)

    node = ast.parse('from module_x.module_a import name1, name2').body[0]

# Generated at 2022-06-23 22:31:43.798738
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..types import BaseSource

    class Source(BaseSource):
        source = """
import foo.bar.zoo
from foo.bar.zoo import zoo
from foo.bar.zoo import *
from foo.bar import zoo
"""

        expected = """
try:
    import foo.bar.zoo
except ImportError:
    import foo_new.bar.zoo as zoo
try:
    from foo.bar.zoo import zoo
except ImportError:
    from foo_new.bar.zoo import zoo
try:
    from foo.bar.zoo import *
except ImportError:
    from foo_new.bar.zoo import *
try:
    from foo.bar import zoo
except ImportError:
    from foo_new.bar import zoo
"""

    class ImportRewrite(BaseImportRewrite):
        re

# Generated at 2022-06-23 22:31:54.148514
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class Y:
        pass

    import os, sys, pathlib

    _tree = ast.parse("""from os import path, path2\nfrom sys import path as path3\nfrom pathlib import Path\n""")
    _rewrite = (
        ('os.path', 'pathlib.Path'),
        ('sys.path', 'pathlib.Path'),
    )
    _class = BaseImportRewrite
    _class.rewrites = _rewrite
    _inst = _class(_tree)
    _result = _inst.visit_ImportFrom(_tree.body[2])
    assert type(_result) == ast.Try
    assert len(_result.body) == 2
    assert _result.body[0].names[0].name == 'pathlib.Path'
    assert _result

# Generated at 2022-06-23 22:32:02.327476
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('yaml.scanner', 'yaml.Scanner'),
            ('yaml.error', 'yaml.Error'),
            ('yaml.parser', 'yaml.Parser'),
            ('yaml.composer', 'yaml.Composer'),
            ('yaml.constructor', 'yaml.Constructor'),
            ('yaml.resolver', 'yaml.Resolver')
        ]


# Generated at 2022-06-23 22:32:10.503620
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    f = '''
from os import path
from os import path as p
'''

    transformer = BaseImportRewrite(ast.parse(f))
    transformer.visit(transformer._tree)
    assert transformer._tree_changed

    f_expected = '''
try:
    from os import path
except ImportError:
    from nt import path

try:
    from os import path as p
except ImportError:
    from nt import path as p
'''
    assert ast.dump(transformer._tree) == ast.dump(ast.parse(f_expected))



# Generated at 2022-06-23 22:32:21.316197
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # test with module name that need to be replaced
    class TestTrans(BaseImportRewrite):
        rewrites = [('module', 'newmodule')]

    ref = ast.parse('import module')
    new = TestTrans.transform(ref)[0]
    assert new != ref
    assert new.body[0].body[0].value.names[0].name == 'module'
    assert new.body[0].body[1].value.names[0].name == 'newmodule'

    # test with module name that doesn't need to be replaced
    class TestTrans(BaseImportRewrite):
        rewrites = [('fake', 'fake')]

    ref = ast.parse('import module')
    new = TestTrans.transform(ref)[0]
    assert new == ref

    # test with module name that contains module that need to be

# Generated at 2022-06-23 22:32:23.799214
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer(): # type: () -> None
    try:
        BaseTransformer()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-23 22:32:28.994882
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..transpilers.pysnippets.utils import get_tree
    from ..transpilers import JUPYTER_TRANSPILER

    source = '''
        from foo import bar

        from foo.bar import baz

        from foo.bar import *
        '''
    tree = get_tree(JUPYTER_TRANSPILER, source)

    class ImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'qux')
        ]

    transpiled, _, _ = ImportRewrite.transform(tree)


# Generated at 2022-06-23 22:32:40.224903
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import unittest
    from typed_ast import ast3 as ast

    class ImportTest(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.rewrites = [('old', 'new')]

        def test_import_from_one_module(self):
            class Transformer(BaseImportRewrite):
                rewrites = ImportTest.rewrites

            import_from = ast.ImportFrom(module='old',
                                         names=[ast.alias(name='foo')],
                                         level=0)
            try_body = Transformer.transform(import_from).tree

            new_import = try_body.body[1].body[0]
            self.assertIsInstance(new_import, ast.ImportFrom)


# Generated at 2022-06-23 22:32:42.238761
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite()
    assert isinstance(instance, BaseImportRewrite)


# Generated at 2022-06-23 22:32:44.496203
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.__new__(BaseImportRewrite)


# Generated at 2022-06-23 22:32:53.185255
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import brsq.__main__ as brsq
    import brsq.core.transformers.base as base
    import brsq.core.utils.snippets as snippets
    branch = brsq.__name__

# Generated at 2022-06-23 22:33:04.011919
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    ret = TestTransformer.transform(ast.parse(
        # @formatter:off
        '''
        import foo
        import foo.bar as foo_bar
        import foo.bar.baz
        '''
        # @formatter:on
    ))  # type: TransformationResult
    assert ret.changed == True
    assert ret.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 22:33:10.208803
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import astor
    import_rewrite_body = '''try:
    import foo.bar
except ImportError:
    import foo.baz
'''
    import_rewrite_body_parsed = ast.parse(import_rewrite_body)
    import_rewrite_ast = type('import_rewrite', (), {
        'get_body': lambda self: ast.Try(
            body=[ast.parse('import foo.bar')],
            handlers=[ast.ExceptHandler(
                type=ast.parse('ImportError'),
                name=None,
                body=[ast.parse('import foo.baz')]
            )],
            orelse=[],
            finalbody=[]
        )
    })()
    import_rewrite_ast.get_body = import_rewrite_ast.get_body.__get

# Generated at 2022-06-23 22:33:12.046520
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer()


# Generated at 2022-06-23 22:33:14.009495
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        pass
    assert Transformer.target == CompilationTarget.PYTHON

# Generated at 2022-06-23 22:33:20.892130
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.example_fragments import (
        import_with_name,
        import_with_name_and_asname,
    )

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('old', 'new')]

    tree = import_with_name
    result = DummyTransformer.transform(tree)
    assert result.changed == True

    tree = import_with_name_and_asname
    result = DummyTransformer.transform(tree)
    assert result.changed == True


# Generated at 2022-06-23 22:33:22.939788
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
        testtree = 'module example tree'
        instance = BaseNodeTransformer(testtree)
        assert instance._tree == testtree
        assert instance._tree_changed == False


# Generated at 2022-06-23 22:33:31.124809
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import os
    import tempfile
    import sys
    import shutil
    from ..utils.testutils import compare_ast

    # Create temporary directory to store modules
    tmpdir = tempfile.mkdtemp()
    sys.path.insert(0, tmpdir)

    class ImportFromTransformer(BaseImportRewrite):
        """Transforms `import from` with rewrites from the list to try/except pattern."""
        rewrites = [('mymodule', 'mymodule_new')]

    # Create inner module files
    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    touch(os.path.join(tmpdir, 'mymodule.py'))
    touch(os.path.join(tmpdir, 'mymodule_new.py'))

    # A

# Generated at 2022-06-23 22:33:42.716722
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('module', 'newmodule')
        ]


# Generated at 2022-06-23 22:33:50.503497
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('werkzeug.contrib.securecookie', 'flask.sessions')]

    source = textwrap.dedent('''\
        from werkzeug.contrib.securecookie import SecureCookie
        from flask.sessions import SecureCookieSessionInterface
        from werkzeug.contrib.securecookie import SecureCookieError
        from werkzeug.contrib.securecookie import BadSignature
        from werkzeug.contrib.securecookie import want_bytes
        from werkzeug.contrib.securecookie import serialization_methods
        from werkzeug.contrib import securecookie as securecookie_mod
        from werkzeug.contrib.securecookie import *
        ''')
    result = TestImport

# Generated at 2022-06-23 22:34:00.336684
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import unittest
    from ..utils import get_tree

    class BaseImportRewriteSubClass(BaseImportRewrite):
        rewrites = [
            ('a.b', 'c.d'),
            ('a', 'c')
        ]

    class TestImportRewrite(BaseNodeTransformer, unittest.TestCase):
        # noinspection PyMethodMayBeStatic
        def visit_ImportFrom(self, node: ast.ImportFrom) -> ast.ImportFrom:
            return BaseImportRewriteSubClass._replace_import_from_module(node, 'a.b', 'c.d')

    tree = get_tree("""from a.b import d as e, *""")
    tree = TestImportRewrite.transform(tree)
    tree.body[0].module.s

# Generated at 2022-06-23 22:34:03.998527
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class BaseTransformer_Test(BaseTransformer):
        target = True
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    assert BaseTransformer_Test.target == True
    assert BaseTransformer_Test.transform(True) == None

# Generated at 2022-06-23 22:34:05.976462
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    try:
        a = BaseNodeTransformer()
    except TypeError:
        b = True
    assert b


# Generated at 2022-06-23 22:34:10.350501
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyBaseTransformer(BaseTransformer):
        # check if abstract method is properly detected
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, ['dummy'])

    assert DummyBaseTransformer.transform is not None

# Generated at 2022-06-23 22:34:21.230605
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from moca.core.compiler import compile_tree
    from moca.utils.asttools import get_ast, transform_ast
    from ..target import PYTHON2

    # 1. Simple import from.
    a_tree = get_ast("import numpy as np")
    b_tree = get_ast("try:\n    import numpy as np\nexcept ImportError:\n    import cupy as np")
    trans = BaseImportRewrite(a_tree)
    trans.visit(a_tree)
    tree = compile_tree(a_tree)
    assert tree == b_tree

    # 1. Simple no import.
    a_tree = get_ast("import numpy")
    b_tree = get_ast("import numpy")
    trans = BaseImportRewrite(a_tree)
    trans.vis

# Generated at 2022-06-23 22:34:32.217840
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    @snippet
    def snippet():
        try:
            extend(previous)
        except ImportError:
            extend(current)

    def test(tree, expected=True, expanded=True):
        actual = BaseImportRewrite.transform(tree)
        if expanded:
            assert actual.tree == expected
        else:
            assert actual.tree.body[-1] == expected

    test(ast.parse('import dill'),
         ast.parse(textwrap.dedent('''
           import dill
           try:
               import dill
           except ImportError:
               import _dill as dill
         ''').strip('\n')))


# Generated at 2022-06-23 22:34:43.127370
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.ast_helper import dump
    import textwrap
    import typed_ast.ast3 as ast

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('os', 'os.path')]


# Generated at 2022-06-23 22:34:44.881062
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    try:
        BaseImportRewrite()
        assert False
    except TypeError:
        pass



# Generated at 2022-06-23 22:34:55.280930
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .transformations import replacements

    tree = ast.parse('''
from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import auth

from django.contrib import auth, messages
from django.contrib.auth import login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from django.db.models import Q

from django.utils import timezone
''')


# Generated at 2022-06-23 22:34:58.454991
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree_transformer = BaseNodeTransformer(ast.AST())
    assert tree_transformer._tree_changed == False
    assert tree_transformer._tree == ast.AST()


# Generated at 2022-06-23 22:35:04.459661
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [('old_module', 'new_module')]


    expected = ast.Import(names=[
        ast.alias(name='new_module',
                  asname='old_module')])

    actual = DummyTransformer.transform(
        ast.parse('import old_module')).tree

    assert expected == actual



# Generated at 2022-06-23 22:35:08.277275
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import_ = ast.Import(names=[
        ast.alias(name='django', asname='dj')])

    trans = BaseNodeTransformer(import_)

    assert trans._tree is import_
    assert trans._tree_changed == False



# Generated at 2022-06-23 22:35:09.089159
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    _ = BaseTransformer()


# Generated at 2022-06-23 22:35:11.315474
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target == None
    assert BaseTransformer().transform == BaseTransformer.transform
    

# Generated at 2022-06-23 22:35:19.359765
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast

    import pytest

    @pytest.fixture
    def nodes():
        tree = ast.parse("from django.contrib.auth import login")
        tree2 = ast.parse("from django.contrib.auth import login")

        tree.body[0].names.append(ast.alias(name="forms", asname="foo"))

        tree3 = ast.parse("from django.db import models")
        tree3.body[0].names.append(ast.alias(name="CharField", asname="FormField"))
        tree3.body[0].names.append(ast.alias(name="IntegerField", asname="FormField"))

        tree4 = ast.parse("from django.db import models")

        return tree, tree2, tree3, tree4


# Generated at 2022-06-23 22:35:25.181754
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    class Mock(BaseImportRewrite):
        rewrites = [('foo.bar', 'bar.foo')]

    node = ast.parse(
        "import foo.bar").body[0]
    # When
    result = Mock.transform(node)
    # Then
    assert "import foo.bar" in astunparse.unparse(result.tree)
    assert "try:" in astunparse.unparse(result.tree)
    assert "import bar.foo" in astunparse.unparse(result.tree)
    assert "except ImportError:" in astunparse.unparse(result.tree)
    assert "import foo.bar" in astunparse.unparse(result.tree)


# Generated at 2022-06-23 22:35:28.603966
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .common import FakeNodeTransformer
    from .visitor import transform_source
    tree = ast.parse('x = 4')
    x = FakeNodeTransformer(tree)
    x.visit(tree)

# Generated at 2022-06-23 22:35:39.083964
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.helper import TreeHelper
    import astor

    def get_tree(code):
        tree = ast.parse(code)
        BaseImportRewrite(tree).visit(tree)
        return TreeHelper.print_node(tree)

    result = get_tree("import datetime")
    expected = """import datetime"""
    assert expected == result

    result = get_tree("import unittest")
    expected = """try:
    import unittest
except ImportError:
    import unittest2 as unittest"""
    assert expected == result

    result = get_tree("import unittest.mock")
    expected = """try:
    import unittest.mock
except ImportError:
    import unittest2.mock as mock"""
    assert expected == result

    result = get_tree

# Generated at 2022-06-23 22:35:48.982793
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils import test_environment
    from ..utils.test_environment import ast as test_ast_module
    import ast

    rewriter = BaseImportRewrite(ast.parse('', '<test>', 'exec'))
    assert rewriter.dependencies == []

    rewriter = BaseImportRewrite(ast.parse('import a', '<test>', 'exec'))
    assert rewriter.dependencies == []

    rewriter = BaseImportRewrite(ast.parse('import a.b', '<test>', 'exec'))
    assert rewriter.dependencies == []

    rewriter = BaseImportRewrite(ast.parse('import a.b as c', '<test>', 'exec'))
    assert rewriter.dependencies == []


# Generated at 2022-06-23 22:35:59.237127
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import(): 
    import_node = ast.Import(names=[ast.Alias(name='foo', asname='bar')])
    rewrite_node = ast.Import(names=[ast.Alias(name='bar', asname='foo')])
    import_rewrite_body = """try:
    extend(import_node)
except ImportError:
    extend(rewrite_node)"""
    import_rewrite_snippet = snippet.get_snippet('import_rewrite')
    assert import_rewrite_body == import_rewrite_snippet
    assert eval(import_rewrite_snippet.strip(), {'import_node': import_node, 'rewrite_node': rewrite_node}) == eval(import_rewrite_body.strip(), {'import_node': import_node, 'rewrite_node': rewrite_node})

   

# Generated at 2022-06-23 22:36:00.790648
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        rewrites = [('re', 're_mock')]
    assert Test.__name__ == 'Test'
    assert Test.transform is BaseNodeTransformer.transform

# Generated at 2022-06-23 22:36:01.405194
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass

# Generated at 2022-06-23 22:36:13.317201
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..transforms.test_utils import apply_transform

    class TestTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        target = CompilationTarget.STDLIB

    src = "import foo"
    expected = """
try:
    import foo
except ImportError:
    import bar
"""
    apply_transform(TestTransformer, src, expected)

    src = "import foo.bar"
    expected = """
try:
    import foo.bar
except ImportError:
    import bar.bar
"""
    apply_transform(TestTransformer, src, expected)

    src = "import spam"
    expected = src
    apply_transform(TestTransformer, src, expected)

    src = "import spam.foo"
    expected = src
   

# Generated at 2022-06-23 22:36:15.354839
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__doc__ != BaseImportRewrite.__init__.__doc__

# Generated at 2022-06-23 22:36:17.097779
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('1')
    inst = BaseNodeTransformer(tree)
    assert inst._tree == tree


# Generated at 2022-06-23 22:36:21.808957
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('module1', 'module2')
        ]
    tree = ast.parse('import module1')
    import_rewrite.get_body()
    result = Transformer.transform(tree)
    assert result.tree == ast.parse(
        'try:\n    import module1\nexcept ImportError:\n    import module2')
    assert result.dependencies == Transformer.dependencies

# Generated at 2022-06-23 22:36:25.780438
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class MyTransformer(BaseNodeTransformer):
        pass

    assert MyTransformer(None).__class__ is MyTransformer
    assert MyTransformer(None)._tree is None
    assert not MyTransformer(None)._tree_changed


# Generated at 2022-06-23 22:36:32.926744
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    def get_code(node):
        module = ast.Module([node])
        return ast.fix_missing_locations(module).body[0]

    class DummyTransformer(BaseNodeTransformer):
        rewrites = [
            ('foo', 'bar'),
        ]

    node = ast.Import(names=[
        ast.alias(name='foo', asname=None),
    ])
    node = get_code(node)

    expected = ast.Import(names=[
        ast.alias(name='bar', asname=None),
    ])
    expected = get_code(expected)

    result = DummyTransformer.transform(node)
    assert result.tree == expected
    assert result.changed

