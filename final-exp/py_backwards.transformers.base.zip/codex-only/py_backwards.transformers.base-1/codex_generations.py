

# Generated at 2022-06-23 22:26:32.921019
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]
        dependencies = ['bar']


# Generated at 2022-06-23 22:26:41.926422
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    import unittest
    from ..utils.node_tools import ast_to_source
    from ..utils.source_tools import import_statement_to_source

    from typed_ast import ast3 as ast # type: ignore

    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('typed_ast', 'typed_ast')]

    class TestCase(unittest.TestCase):
        def test_empty(self):
            self.assert_import_from(
                'import x',
                'import x')

        def test_module(self):
            self.assert_import_from(
                'import typed_ast',
                'import typed_ast')


# Generated at 2022-06-23 22:26:48.151706
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('yaml.load', 'json.load'),
        ]
        dependencies = []
    tree = ast.parse('import yaml')
    result = TestTransformer.transform(tree)
    assert result == TransformationResult(ast.parse('try:\n    import yaml\nexcept ImportError:\n    import json'), True, [])

# Generated at 2022-06-23 22:26:54.099560
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    from .base import BaseNodeTransformer
    class NodeTransformerExample(BaseNodeTransformer):
        pass

    ast_tree = astor.parse_file('test_source.py')
    node_transformer = NodeTransformerExample(ast_tree)
    assert isinstance(node_transformer, BaseNodeTransformer)



# Generated at 2022-06-23 22:27:00.301690
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    expected_BaseTransformer = 'BaseTransformer'
    class_BaseTransformer = BaseTransformer()
    class_name_BaseTransformer = class_BaseTransformer.__class__.__name__
    assert expected_BaseTransformer == class_name_BaseTransformer, 'class_name_BaseTransformer should be BaseTransformer'

# Generated at 2022-06-23 22:27:02.496205
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        t = BaseTransformer()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-23 22:27:03.748261
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    # pylint: disable=no-member
    BaseNodeTransformer(None)

# Generated at 2022-06-23 22:27:06.733535
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    """Test BaseTransformer construction."""
    class MyBaseTransformer(BaseTransformer):
        pass
    assert MyBaseTransformer().target is None


# Generated at 2022-06-23 22:27:16.540082
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    tree = _ast_helper(
        """
    import os
    from six import xrange
    from six.moves import xxx
    import six.moves.yyy

    a = 1
    def x():
        from six import xrange as yrange
        from six.moves import input as raw_input
        from six.moves.input import raw_input as raw_input2
    """)
    class Rewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    res = Rewrite.transform(tree)


# Generated at 2022-06-23 22:27:20.424150
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    result = 'import sys\nimport os'
    transformer = BaseImportRewrite()
    _tree = ast.parse(result)
    transformer.visit(_tree)
    assert astor.to_source(_tree).strip() == result.strip()
    
    

# Generated at 2022-06-23 22:27:27.293826
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite.rewrites = []
    BaseImportRewrite.dependencies = []
    BaseImportRewrite.target = CompilationTarget.PY2
    import_rewrite.abstract_import(previous='')
    import_rewrite.abstract_import(current='')
    import_rewrite.abstract_import(previous='')
    import_rewrite.abstract_import(current='')
    import_rewrite.abstract_import(previous='')
    import_rewrite.abstract_import(current='')
    import_rewrite.abstract_import(previous='')
    import_rewrite.abstract_import(current='')
    import_rewrite.abstract_import(previous='')

# Generated at 2022-06-23 22:27:36.868124
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def test_rewrite(node: ast.ImportFrom, rewrites: List[Tuple[str, str]],
                     expected: Union[str, ast.Try]):
        class MockTransformer(BaseImportRewrite):
            rewrites = rewrites

        actual = MockTransformer.transform(node)
        assert actual == expected

    # case 1 - rewrite module
    node = ast.ImportFrom(
        module='six',
        names=[ast.alias(name='add_metaclass')],
        level=0)

    rewrites = [('six', 'typing')]


# Generated at 2022-06-23 22:27:47.365123
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [
            ('urls', 'viewsets'),
            ('base', 'django.views.generic.base')
        ]

    # 1. import from
    import_from_stmt = ast.ImportFrom(module='urls',
                                      names=[ast.alias(name='ListModelMixin',
                                                       asname='ListModelMixin')],
                                      level=0)
    # 1.1. import from (expected)


# Generated at 2022-06-23 22:27:48.113688
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:27:49.303164
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.rewrites == []

# Generated at 2022-06-23 22:27:50.388733
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert issubclass(BaseTransformer, ast.NodeTransformer)


# Generated at 2022-06-23 22:27:59.750556
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Dummy(BaseImportRewrite):
        rewrites = [
            ('cryptography','cryptography_bootstrap'),
            ('futures','asyncio'),
        ]

    ast_node = ast.parse('import a')
    Dummy.transform(ast_node)
    assert ast.dump(ast_node) == 'Module(body=[Import(names=[alias(name=\'a\', asname=None)])])'

    ast_node = ast.parse('import cryptography')
    Dummy.transform(ast_node)
    assert ast.dump(ast_node) == 'Module(body=[Try(body=[Import(names=[alias(name=\'cryptography_bootstrap\', asname=\'cryptography\')])], handlers=[], orelse=[], finalbody=[])])'


# Generated at 2022-06-23 22:28:03.805005
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("""
try:
    import os.path
except ImportError:
    import pathlib
""")

    tree_checked = ast.parse("""
import os.path
""")

    tree_changed = ast.parse("""
try:
    import pathlib
except ImportError:
    import pathlib
""")

    assert BaseImportRewrite.transform(tree_checked).transformed_tree == tree_checked
    assert BaseImportRewrite.transform(tree).transformed_tree == tree_changed



# Generated at 2022-06-23 22:28:06.882563
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    import_from = parse('from os import path').body[0]
    class Test(BaseImportRewrite):
        rewrites = [('os', 'tos')]

    result = Test.transform(import_from).tree
    assert isinstance(result, ast.Try)

    expected = '''
from os import path
try:
    from tos import path
except ImportError:
    pass
'''[1:]
    assert expected == str(result)

# Generated at 2022-06-23 22:28:15.182760
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestCase(BaseImportRewrite):
        rewrites = [
            ('collections', 'collections.abc')
        ]

        def _replace_import(self, node, from_, to):
            return node

    module = ast.Module([ast.Import(names=[ast.alias(name='collections', asname=None)])])
    tree = module.body[0]
    test = TestCase(tree)
    test.visit_Import(tree)

    assert test._tree_changed == True  # pylint: disable=no-member
    assert module.body[0].names[0].name == 'collections.abc'


# Generated at 2022-06-23 22:28:20.967922
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    node = ast.parse("from django.utils.http import quote_etag").body[0]
    rewriter = BaseImportRewrite()
    new = rewriter.visit(node)
    assert astor.to_source(new) == 'try:\n    from django.utils.http import quote_etag\nexcept ImportError:\n    from urllib import quote_etag'
    assert rewriter.dependencies == ['urllib']


# Generated at 2022-06-23 22:28:23.727663
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # BaseImportRewrite.__init__
    try:
        BaseImportRewrite(1)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 22:28:32.986464
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import Module, Import
    from typed_ast import ast3 as ast

    class MyTransformer(BaseImportRewrite):
        rewrites = [('typed_ast', 'typed_ast.ast3')]

    tree = Module(body=[Import(names=[ast.alias(name='typed_ast', asname=None)])])
    MyTransformer.transform(tree)

    tree = Module(body=[Import(names=[ast.alias(name='typed_ast.ast3', asname=None)])])
    MyTransformer.transform(tree)

    tree = Module(body=[Import(names=[ast.alias(name='typed_ast.ast3', asname=None)])])
    MyTransformer.transform(tree)



# Generated at 2022-06-23 22:28:34.752179
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyImportRewriteTest(BaseImportRewrite):
        rewrites = [("six", "typing")]

    import_rewrite_test = MyImportRewriteTest


# Generated at 2022-06-23 22:28:35.193536
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:35.646389
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:36.168238
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:28:43.791251
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import Import
    test_cases = [
        ('import x',
         Import(names=[ast.alias(name='x', asname=None)])),

        ('import x.y',
         Import(names=[ast.alias(name='x.y', asname=None)])),

        ('import x.y.z',
         Import(names=[ast.alias(name='x.y.z', asname=None)])),

        ('import x.y as y',
         Import(names=[ast.alias(name='x.y', asname='y')])),
    ]

    class TestRewrite(BaseImportRewrite):
        rewrites = [
            ('x.y', 'a.b'),
            ('x.y.z', 'd.e')
        ]

    transformer = Test

# Generated at 2022-06-23 22:28:44.380382
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass

# Generated at 2022-06-23 22:28:46.966592
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON

    assert TestTransformer.target == CompilationTarget.PYTHON

# Generated at 2022-06-23 22:28:56.400144
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Custom(BaseImportRewrite):
        rewrites = [('abc', 'def')]

    class CustomOne(Custom):
        rewrites = [('ghi', 'jkl')]

    class CustomTwo(Custom):
        rewrites = [('mno', 'pqr')]

    class CustomThree(CustomTwo):
        rewrites = [('stu', 'vwx')]


# Generated at 2022-06-23 22:28:58.149366
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer(ast.parse("x=10"))

# Generated at 2022-06-23 22:28:59.797169
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # assert BaseTransformer.target == None
    assert BaseTransformer.transform(None) == None



# Generated at 2022-06-23 22:29:01.068059
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    test = BaseNodeTransformer(ast.parse('pass'))

# Generated at 2022-06-23 22:29:05.970309
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from .test_data.importrewrite_visit_import import before, after

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'new_foo')]

    before_tree = ast.parse(before)
    after_tree = ast.parse(after)

    result = ImportRewrite.transform(before_tree)
    assert not result.tree_changed
    assert astor.to_source(result.tree).strip() == before.strip()

    result = ImportRewrite.transform(after_tree)
    assert result.tree_changed
    assert astor.to_source(result.tree).strip() == after.strip()


if __name__ == '__main__':
    test_BaseImportRewrite_visit_Import()

# Generated at 2022-06-23 22:29:07.828022
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('x = 1')
    assert isinstance(BaseNodeTransformer(tree), ast.NodeTransformer)



# Generated at 2022-06-23 22:29:09.856060
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    assert transformer.rewrites == []
    assert transformer.dependencies == []

# Generated at 2022-06-23 22:29:18.717316
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class Test(BaseImportRewrite):
        rewrites = [('requests', 'xrequests'),
                    ('http', 'xhttp')]

    test_tree = ast.parse(
        """from requests import request\nfrom http import client\nimport http.client""")
    result = Test.transform(test_tree)
    assert result.transformed_tree == ast.parse(
        """from xrequests import request
try:
    import requests as request
except ImportError:
    from xrequests import request

from xhttp import client
try:
    from http import client
except ImportError:
    from xhttp import client

try:
    import http.client
except ImportError:
    from xhttp import client
""")



# Generated at 2022-06-23 22:29:30.660244
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    import_tree = ast.parse(textwrap.dedent('''\
    import test
    import my_module
    '''))
    rewrites = [('test', 'new_test')]
    transformer = BaseImportRewrite('_', rewrites)
    transformer.visit = mock.Mock(wraps=transformer.visit)

    # Act
    transformer.visit(import_tree)

    # Assert
    assert transformer.visit.call_count == 2
    assert transformer.visit.call_args_list[0] == mock.call(ast.Import(names=[ast.alias(asname='test', name='test')]))

# Generated at 2022-06-23 22:29:37.840474
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .base import TransformationResult
    from .base import CompilationTarget
    from ..utils.snippet import make_tree
    from ..utils.repr import ast_repr
    import ast as ast3
    tree0 = ast3.parse('from module_1 import foo, name_1, name_2, bar')
    tree1 = ast3.parse('from module_1 import foo, name_1 as name_1_rewrite, name_2, bar')
    result0 = TransformationResult(
        tree=tree1,
        changed=True,
        additional_dependencies=['module_1'],
        imports=[]
    )
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('module_1.name_1', 'module_1.name_1_rewrite'),
        ]
    actual

# Generated at 2022-06-23 22:29:39.237276
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from .generic import GenericTransformer
    assert GenericTransformer.target == CompilationTarget.generic
    assert GenericTransformer.dependencies == []

# Generated at 2022-06-23 22:29:40.800545
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    bt = BaseTransformer()
    return bt


# Generated at 2022-06-23 22:29:44.589899
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    expected_tree = ast.parse('def foo():\n    pass')
    result_tree, changed, deps = BaseNodeTransformer.transform(expected_tree)
    assert expected_tree == result_tree
    assert changed == False
    assert deps == []



# Generated at 2022-06-23 22:29:53.241911
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_astunparse
    import unittest

    tree = ast.parse('import my_module')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('my_module', 'rewrote')]

    result = TestImportRewrite.transform(tree)
    expected = ast.parse('try:\n    import my_module\nexcept ImportError:\n    import rewrote')
    assert typed_astunparse.unparse(result.tree) == typed_astunparse.unparse(expected)

    tree = ast.parse('import my_module.module')

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('my_module', 'rewrote')]

    result = TestImportRewrite.transform(tree)

# Generated at 2022-06-23 22:30:02.685297
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from .base import mark_changed

    node = ast.parse('import foo').body[0]
    assert isinstance(node, ast.Import)
    assert node.names[0].name == 'foo'
    assert node.names[0].asname is None

    tree_changed = False
    def _mark_changed(*args, **kwargs):
        nonlocal tree_changed
        tree_changed = True

    rewrites = [('foo', 'bar')]

# Generated at 2022-06-23 22:30:07.693362
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import unittest
    from unittest import mock

    class BaseTransformerMock(BaseTransformer, metaclass=ABCMeta):
        def __init__(self):
            super().__init__()

    with mock.patch.object(BaseTransformerMock, 'transform') as mock_transform:
        BaseTransformerMock()

    mock_transform.assert_not_called()

# Generated at 2022-06-23 22:30:17.147515
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import pytest\n')
    transformer = BaseImportRewrite(tree)

    rewrote = transformer._replace_import(tree.body[0], 'pytest', 'pytest2')
    assert isinstance(rewrote, ast.Try)
    assert len(rewrote.body) == 1
    assert len(rewrote.handlers) == 1

    alias = rewrote.body[0]
    assert isinstance(alias, ast.Import)
    assert alias.names[0].name == 'pytest2'

    alias = rewrote.handlers[0].body[0]
    assert isinstance(alias, ast.Import)
    assert alias.names[0].name == 'pytest'



# Generated at 2022-06-23 22:30:27.756446
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.testutils import parse
    import astunparse  # type: ignore

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'sixx')]

    def assert_transform(before: str, after: str) -> None:
        tree = parse(before)
        result = TestImportRewrite.transform(tree)
        assert result.changed
        assert astunparse.unparse(result.tree) == after

    assert_transform(
        before="from six import moves",
        after="try:\n    from six import moves\nexcept ImportError:\n    from sixx import moves",
    )


# Generated at 2022-06-23 22:30:28.975828
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Subclass(BaseNodeTransformer):
        def transform(cls, tree):
            pass

    sub = Subclass(None)
    assert not sub._tree_changed

# Generated at 2022-06-23 22:30:30.135667
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert not hasattr(BaseTransformer, 'transform')


# Generated at 2022-06-23 22:30:32.971766
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse("print 'Hello world.'")
    compiler = BaseNodeTransformer(tree)
    assert compiler._tree is tree
    assert compiler._tree_changed is False

# Generated at 2022-06-23 22:30:35.145690
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.target is None

# Unittest for constructor of class BaseNodeTransformer

# Generated at 2022-06-23 22:30:44.010049
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils import test_data_path, parse_ast

    test_file = test_data_path('simple.py')
    test_tree = parse_ast(test_file)
    test_result = """
try:
    from re import error as RegexpError
    from re.pattern import pattern
    from re.compile import compile
except ImportError:
    from re import error as RegexpError
    from re.pattern import pattern
    from re.compile import compile
"""

    class Test(BaseImportRewrite):
        rewrites = [('re.error', 're')]

    result = Test.transform(test_tree)
    assert astor.to_source(result.tree).strip() == test_result.strip()

# Generated at 2022-06-23 22:30:47.156516
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import six  # type: ignore
    import ast  # type: ignore

    module = ast.parse(
        'import six')
    transformer = BaseImportRewrite(module)
    new_node = transformer.visit(module)
    assert isinstance(new_node, ast.Try)



# Generated at 2022-06-23 22:30:57.587625
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import sys
    import ast as stdlib_ast
    import typed_ast.ast3 as typed_ast

    sys.modules.pop(BaseImportRewrite.__module__, None)

    class MyTransformer(BaseImportRewrite):
        target = 'python'
        rewrites = [
            ('urllib.request', 'urllib3'),
            ('urllib.error', 'urllib3.exceptions')
        ]

    tree = stdlib_ast.parse('import urllib.request')
    transformed = MyTransformer.transform(tree)
    assert transformed.changed is True
    assert stdlib_ast.dump(transformed.tree) == stdlib_ast.dump(stdlib_ast.parse('try:\n    import urllib.request\nexcept ImportError:\n    import urllib3'))

# Generated at 2022-06-23 22:31:05.167854
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("""
from urllib.parse import urlencode
from urllib.request import urlopen""")

    trnsfrmr = BaseImportRewrite(tree)
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ImportFrom):
            trnsfrmr.visit_ImportFrom(node)

    assert "try" in ast.dump(trnsfrmr._tree, include_attributes=False)[0]



# Generated at 2022-06-23 22:31:16.907462
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .transformers import import_rewrite
    from typed_ast import ast3 as ast

    class Mock(BaseImportRewrite):
        rewrites = import_rewrite.rewrites
        dependencies = []

    @Mock.transform
    def test() -> None:
        from typing import Tuple

        def func():
            import datetime
            from datetime import date, datetime as now
            date(2017, 3, 3)
            now(2017, 3, 3)
            Tuple[str]

            from typing import Type

        func()

    tree = test.get_tree()

    def get_module_name(node: ast.ImportFrom) -> str:
        name = node.names[0].name
        if name != '*':
            name = '{}.{}'.format(node.module, name)
        return

# Generated at 2022-06-23 22:31:27.714826
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.tree_helpers import parse_tree
    from .base_node_transformer import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        rewrites = [('alpha', 'beta')]

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            return self._replace_import(node, self.rewrites[0][0], self.rewrites[0][1])

    tree = parse_tree("""
    import alpha

    import alpha.gamma

    import boo, alpha
    
    import a, alpha, c
    """)
    result, changed, _ = TestTransformer.transform(tree)
    assert changed
    assert len(result.body) == 4

# Generated at 2022-06-23 22:31:33.487178
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('baz', 'quux'),
        ]

    node = ast.parse('from foo import foo, bar, baz').body[0]
    assert Test.visit_ImportFrom(Test(None), node) == \
        Test.visit_ImportFrom(Test(None), node)

# Generated at 2022-06-23 22:31:36.471756
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Mock(BaseNodeTransformer):
        pass
    tree = ast.AST()
    transformer = Mock(tree)
    assert transformer._tree is tree

# Generated at 2022-06-23 22:31:45.606366
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('bar2', 'foo2'),
        ]

    s = """from foo import Foo"""
    tree = ast.parse(s)
    TestTransformer.transform(tree)

    result = """from foo import Foo
try:
    from foo import Foo
except:
    from bar import Foo"""
    assert render_code(tree) == result

    s = """from foo import Foo, Bar"""
    tree = ast.parse(s)
    TestTransformer.transform(tree)

    result = """from foo import Foo, Bar
try:
    from foo import Foo
    from foo import Bar
except:
    from bar import Foo
    from bar import Bar"""
    assert render_code(tree) == result


# Generated at 2022-06-23 22:31:48.501814
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from ast import parse
    tree = parse('[x for x in range(0, 10)]')
    assert BaseNodeTransformer(tree) is not None



# Generated at 2022-06-23 22:31:51.669860
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Test(BaseTransformer):
        target = 'test'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...

    assert Test.target == 'test'


# Generated at 2022-06-23 22:31:58.046022
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrites = [('os.path', 'pathlib')]
    module_name = 'os.path.join'

    from ..utils.ast import import_from_node
    node = import_from_node(module_name, ['join'])

    class Rewriter(BaseImportRewrite):
        dependencies = []
        rewrites = rewrites
        target = CompilationTarget.PYTHON27

    t = Rewriter.transform(node)[0]

    assert t.body[0].body[0].value.module == 'pathlib.join'
    assert t.body[0].body[1].value.module == 'os.path.join'

# Generated at 2022-06-23 22:32:09.720374
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    import re
    import unittest

    class TestImportRewrite(BaseImportRewrite):
        target = 'test'
        rewrites = [
            ('flask', 'flask_new'),
            ('flask.json', 'flask_new.json'),
            ('flask.json.tag', 'flask_new.json.tag')
        ]

    class TestCase(unittest.TestCase):
        def test_Import(self):
            replaced = TestImportRewrite.transform(ast.parse('''
import flask
'''))
            assert replaced.changed

            replaced = TestImportRewrite.transform(ast.parse('''
import flask
''').body[0])
            assert replaced.changed


# Generated at 2022-06-23 22:32:20.888331
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Test(BaseImportRewrite):
        rewrites = [('future', 'six')]
    a = ast.ImportFrom(module='future.types',
                       names=[ast.alias(name='a',
                                        asname='b')],
                       level=0)
    b = ast.Try(body=[
        ast.ImportFrom(module='future.types',
                       names=[ast.alias(name='a',
                                        asname='b')],
                       level=0)],
        handlers=[ast.ExceptHandler(type=None,
                                    name=None,
                                    body=[
            ast.ImportFrom(module='six.types',
                           names=[ast.alias(name='a',
                                            asname='b')],
                           level=0)])],
        orelse=[],
        finalbody=[])

# Generated at 2022-06-23 22:32:22.703800
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    transformer.target = 'python3'
    assert transformer.target == 'python3'

# Generated at 2022-06-23 22:32:31.738507
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    
    import ast
    import astq
    from ..transformer import BaseImportRewrite
    import sys
    import os.path
    from ..utils.snippet import extend
    from ..main import get_compiler
    
    module_code = """
import os
import sys
import logging.config
from os import path, makedirs
from os.path import join, dirname, basename
from logging import getLogger
from logging.config import dictConfig
from . import test
from .test import *
from .test.test1 import *
"""


# Generated at 2022-06-23 22:32:41.415306
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert hasattr(BaseNodeTransformer, '_get_matched_rewrite')
    assert hasattr(BaseNodeTransformer, '_replace_import')
    assert hasattr(BaseNodeTransformer, 'visit_Import')
    assert hasattr(BaseNodeTransformer, '_replace_import_from_module')
    assert hasattr(BaseNodeTransformer, '_get_names_to_replace')
    assert hasattr(BaseNodeTransformer, '_get_replaced_import_from_part')
    assert hasattr(BaseNodeTransformer, '_replace_import_from_names')
    assert hasattr(BaseNodeTransformer, 'visit_ImportFrom')
    assert hasattr(BaseNodeTransformer, 'transform')
    assert hasattr(BaseNodeTransformer, 'dependencies')


# Generated at 2022-06-23 22:32:51.901435
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astunparse
    import json
    test_program = """
    import ast

    class TestNodeTransformer(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='Matt', ctx=node.ctx), node)

    class TestBaseNodeTransformer(BaseNodeTransformer):
        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            if name == 'ast':
                return 'ast', 'astunparse'
            return None

        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='Matt', ctx=node.ctx), node)
    """

    test_ast = ast.parse(test_program)
    expected_ast = ast

# Generated at 2022-06-23 22:32:58.430168
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class Transformer(BaseTransformer):
        target = {'version': '3.6'}
        def transform(self, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])
    t = Transformer()
    # assert t.target == {'version': '3.6'}
    assert t.transform('some-tree') == TransformationResult('some-tree', False, [])



# Generated at 2022-06-23 22:33:05.156870
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def _test_visit_ImportFrom_with_rewrites(rewrites: List[Tuple[str, str]],
                                             code: str,
                                             expected: str) -> None:
        class Rewrite(BaseImportRewrite):
            rewrites = rewrites

        @snippet
        def rewrote():
            extend(expected)

        parsed = ast.parse(code)
        Rewrite.transform(parsed)
        rewrote = rewrote.get_body()[0]
        assert ast.dump(rewrote, include_attributes=False) ==\
            ast.dump(parsed, include_attributes=False)


# Generated at 2022-06-23 22:33:10.962740
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..tests.utils import parse

    class DummyTransformer(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]

    tree = parse('''
        import a
        import a.b
        import c
        import c.d
    ''')

    DummyTransformer.transform(tree)
    assert (import_rewrite.get_body(previous=ast.Import(names=[ast.alias(name='a', asname=None)]),
                                    current=ast.Import(names=[ast.alias(name='b', asname=None)]))[0] ==
            tree.body[0])


# Generated at 2022-06-23 22:33:12.444052
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from .visitor import BaseVisitor
    BaseNodeTransformer(None)
    BaseVisitor(None)

# Generated at 2022-06-23 22:33:14.396934
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    cls = BaseImportRewrite()
    assert isinstance(cls, BaseImportRewrite)


# Generated at 2022-06-23 22:33:16.958009
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Test abstract constructor
    with pytest.raises(TypeError):
        BaseTransformer()



# Generated at 2022-06-23 22:33:24.649648
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import sys')
    class TestTransformer(BaseImportRewrite):
        rewrites = [('sys', 'six')]
    result = TestTransformer.transform(tree)
    assert result.changed == True
    assert result.dependencies == ["six"]
    assert ast.dump(result.tree) == "Module(body=[Try(\n" \
                                    "    body=[Import(names=[alias(name='six', asname=None)])], \n" \
                                    "    handlers=[ExceptHandler(type=None, name=None, body=[Import(names=[alias(name='sys', asname=None)])])], \n" \
                                    "    orelse=[])])"


# Generated at 2022-06-23 22:33:25.145424
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()

# Generated at 2022-06-23 22:33:31.559638
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class SampleBaseNodeTransformer(BaseNodeTransformer):
        def visit_Import(self, node):
            return self.generic_visit(node)
    sample_tree = ast.parse('import os')
    sample_transformer = SampleBaseNodeTransformer(sample_tree)
    assert isinstance(sample_transformer, BaseNodeTransformer)
    assert sample_transformer._tree == sample_tree
    assert sample_transformer._tree_changed == False

# Generated at 2022-06-23 22:33:42.926496
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-23 22:33:43.376168
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:51.079777
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .. import transformers
    from ..types import CompilationTarget

    # type: List[Tuple[str, CompilationTarget]]

# Generated at 2022-06-23 22:34:00.871918
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from pytest import raises
    from pyannotate_runtime import collect_types
    from astmonkey import transformers

    def test(rewrites, expected):
        tree = ast.parse('''
import sys

from os import devnull, path

from . import cwd''')

        transformer = BaseImportRewrite(
            tree,
            rewrites=rewrites)

        tree = transformer.visit(tree)
        tree = transformers.ParentNodeTransformer().visit(tree)

        if expected is None:
            assert tree == ast.parse('''
import sys

from os import devnull, path

from . import cwd''')
        else:
            assert ast.dump(tree) == ast.dump(ast.parse(expected))


# Generated at 2022-06-23 22:34:10.775337
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import import_rewrite
    import astunparse
    import six
    class MyClass(BaseImportRewrite):
        rewrites = [('six', 'sixx')]
        def visit_Import(self, node: ast.Import) -> ast.Try:
            rewrite = self._get_matched_rewrite(node.names[0].name)
            if rewrite:
                return self._replace_import(node, *rewrite)
            return super().visit_Import(node)

    code = 'import six'
    tree = ast.parse(code)
    trans = MyClass.transform(tree)
    trans.apply()
    x = astunparse.unparse(tree)
    x.replace('\n', '')

# Generated at 2022-06-23 22:34:12.516781
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    pass

# Generated at 2022-06-23 22:34:21.882357
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    # pylint: disable=no-member
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('old', 'new')]
        target = '__test'


# Generated at 2022-06-23 22:34:25.011152
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    tree = ast.parse('print("Hello, world!")')
    inst = BaseNodeTransformer(tree)
    assert inst._tree_changed == False


# Generated at 2022-06-23 22:34:28.402163
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    # Test if BaseTransformer is abstract class
    try:
        BaseTransformer()
        assert False
    # Catch the exception if we instantiate an abstract class
    except TypeError:
        assert True


# Generated at 2022-06-23 22:34:30.523739
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    print('Test BaseTransformer...')
    test_btrans = BaseTransformer()
    assert test_btrans.target == None

# Generated at 2022-06-23 22:34:41.369047
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ..utils.testing import assert_snippets_equal
    from ..utils.ast import ast_equal, ast_str_equal

    class Test(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse("import foo.bar")
    transformed = Test.transform(tree)
    expected = ast.parse("""
try:
    import foo.bar
except ImportError:
    import bar.bar
""")
    assert transformed.changed
    assert ast_str_equal(transformed.tree, expected)

    tree = ast.parse("from foo import bar")
    transformed = Test.transform(tree)
    expected = ast.parse("""
try:
    from foo import bar
except ImportError:
    from bar import bar
""")
    assert transformed.changed


# Generated at 2022-06-23 22:34:42.941630
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
  assert '__init__' not in BaseTransformer.__dict__, 'do not override __init__'
  assert BaseTransformer.__init__.__func__.__globals__['__name__'] == 'BaseTransformer'


# Generated at 2022-06-23 22:34:47.928871
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..utils.examples import get_module_source
    source = get_module_source('test_source.test_foo')
    tree = ast.parse(source)
    transformation_result = BaseImportRewrite([]).transform(tree)
    assert transformation_result.tree_changed
    assert transformation_result.dependencies == []



# Generated at 2022-06-23 22:34:56.714993
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import sys

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('os', 'os.path'),
            ('sys', 'os')]

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            return super().visit_Import(node)

    node = ast.parse('import os')
    transformer = Transformer(node)
    node = transformer.visit(node)
    source = astor.to_source(node)
    assert 'import os' in source
    assert 'try:' in source
    assert 'import os.path' in source


# Generated at 2022-06-23 22:35:02.769021
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import six
    from typed_ast.ast3 import parse
    from ..utils.test_utils import TransformTestCase

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('pytest', 'six'),
        ]


# Generated at 2022-06-23 22:35:03.977315
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(tree=None)


# Generated at 2022-06-23 22:35:08.827728
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TransformerA(BaseTransformer):
        target = 'python'
        @classmethod
        def transform(cls, tree): pass

    class TransformerB(BaseTransformer):
        target = 'dart'
        @classmethod
        def transform(cls, tree): pass

    tA = TransformerA()
    assert tA.target == 'python'
    tB = TransformerB()
    assert tB.target == 'dart'


# Generated at 2022-06-23 22:35:15.867750
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class testTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON
        def transform(cls, tree):
            return tree

    assert isinstance(testTransformer(), type)
    assert isinstance(testTransformer.target, CompilationTarget)
    assert isinstance(testTransformer.transform(0), ast.AST)


# Generated at 2022-06-23 22:35:25.333522
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module')
        ]

    ast_test = ast.parse('import old_module')
    result = TestImportRewrite.transform(ast_test)
    assert result.changed

    ast_test = ast.parse('import old_module.module')
    result = TestImportRewrite.transform(ast_test)
    assert result.changed

    ast_test = ast.parse('import old_module.module as new_module')
    result = TestImportRewrite.transform(ast_test)
    assert result.changed

    ast_test = ast.parse('import not_matched_module')
    result = TestImportRewrite.transform(ast_test)
    assert not result.changed



# Generated at 2022-06-23 22:35:35.677158
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..main import compile_ast
    import ast
    import astunparse
    import difflib
    from typing import List
    from ..types import CompilationTarget

    class T(BaseImportRewrite):
        rewrites = [('import_this', 'this')]

    target = CompilationTarget.PY36

    source = '''
        from import_this import something
        from import_this import something_else as sth_else
        from import_this import *
        from import_this.a import object
        from import_this.a import object_else as obj_else
        from import_this.a import *
    '''

# Generated at 2022-06-23 22:35:42.484271
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import astor
    import astunparse
    class MyTransformer(BaseNodeTransformer):
        def visit_Name(self, node):
            return ast.Name(id='my_local')

    tree = ast.parse('foo = 1')
    result = MyTransformer.transform(tree)
    assert astunparse.unparse(result.tree) == 'my_local = 1\n'
    assert result.changed
    assert result.dependencies == MyTransformer.dependencies


# Generated at 2022-06-23 22:35:49.940849
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert isinstance(BaseTransformer.transform, classmethod)
    assert isinstance(BaseTransformer.target, property)

    class MyTransformer(BaseTransformer):

        def __init__(self, tree, foo):
            self.foo = foo
            self.tree = tree
            self.tree_changed = False

        @classmethod
        def transform(cls, tree, *args, **kwargs):
            my_transformer = cls(tree, *args, **kwargs)
            my_transformer.visit(my_transformer.tree)
            return TransformationResult(my_transformer.tree, my_transformer.tree_changed)
    tree = ast.parse('""')
    target = 'target'
    foo = (1, 2, 3)

# Generated at 2022-06-23 22:35:56.508182
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """
    BaseImportRewrite.visit_Import()
    """
    from_ = 'typing'
    to = 'typings'
    node = ast.parse("import typing")
    res = BaseImportRewrite._replace_import(node, from_, to)
    expected = ast.parse("""
    import typing
    try:
        import typings
    except:
        pass
    """)
    assert ast.dump(expected) == ast.dump(res)

# Generated at 2022-06-23 22:36:03.789492
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Given
    from ..utils.examples import get_example_tree, get_expected_tree
    from ..utils.examples import get_example_ast_tree

    tree = get_example_tree()
    example_tree = get_expected_tree('visit_ImportFrom_example')
    import_to = '__builtin__'

    # When
    _transformer = BaseImportRewrite(None)
    _transformer.rewrites = [('xml.sax', import_to)]
    _transformer.visit(tree)

    # Then
    assert example_tree == get_example_ast_tree(tree)


# Generated at 2022-06-23 22:36:07.072321
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    node = ast.parse('a = 1\nprint(a)\n')
    tr = BaseNodeTransformer(tree=node)
    assert not tr._tree_changed
    assert tr.generic_visit(node) is node

# Generated at 2022-06-23 22:36:09.762415
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer(CompilationTarget.PY2).transform(ast.parse("1")).tree == ast.parse("1")


# Generated at 2022-06-23 22:36:19.355790
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..api import Compiler
    from ..utils.testing import snippet_to_tree, check_tree

    snippet_tree = snippet_to_tree('''
        import module 
    ''', Compiler)   # type: ignore

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('module', 'new_module'),
        ]

    expected_tree = snippet_to_tree('''
        try:
            import module
        except ImportError:
            import new_module as module
    ''', Compiler)   # type: ignore

    tree = TestTransformer.transform(snippet_tree)[0]
    assert check_tree(tree, expected_tree)



# Generated at 2022-06-23 22:36:22.356730
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert isinstance(BaseImportRewrite(), BaseImportRewrite)


import_test_source = '''
from tests import a
'''
import_test_expected = '''
try:
    from tests import a
except ImportError:
    from test import a
'''



# Generated at 2022-06-23 22:36:31.427555
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MockImportRewrite(BaseImportRewrite):
        rewrites = [('foo.bar', 'spam.eggs')]

    mock = MockImportRewrite(None)
    assert mock._replace_import(ast.parse('import foo.bar').body[0], 'foo.bar', 'spam.eggs')

    assert mock._replace_import_from_module(ast.parse('from foo.bar import baz').body[0], 'foo.bar', 'spam.eggs')

    assert mock._replace_import_from_names(ast.parse('from foo.bar import baz, quux').body[0], {
        'foo.bar.quux': ('foo.bar', 'spam.eggs'),
    })