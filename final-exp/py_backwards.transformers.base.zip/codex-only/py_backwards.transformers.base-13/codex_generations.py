

# Generated at 2022-06-23 22:26:41.245919
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from ..parser import parse

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [
            ('typing', 'typed_ast.ast3')]

    tree = parse('''
import typing
import os
from typing import List
from os import path
    ''')
    TestImportRewrite.transform(tree)
    print(ast.dump(tree))

    tree = parse('''
import typing.List
from typing import List
    ''')
    TestImportRewrite.transform(tree)
    print(ast.dump(tree))

    tree = parse('''
from os import path
    ''')
    TestImportRewrite.transform(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 22:26:52.871361
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast as native_ast
    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    test_import_string_1 = 'import foo'
    test_import_string_2 = 'import foo.bar'
    test_import_string_3 = 'import foo as bar'

    native_ast.parse(test_import_string_1)
    native_ast.parse(test_import_string_2)
    native_ast.parse(test_import_string_3)

    node = ast.parse(test_import_string_1).body[0]

    transformed = MyTransformer.transform(node)
    transformed_string = ast.dump(transformed.tree)


# Generated at 2022-06-23 22:26:58.821221
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class MockedTransformer(BaseImportRewrite):
        rewrites = [('foo', 'foo_new')]

    node = ast.parse('from foo import x')
    transformer = MockedTransformer(None)

    assert transformer.visit(node) == ast.parse("""
try:
    from foo_new import x
except ImportError:
    from foo import x
""")



# Generated at 2022-06-23 22:27:03.688054
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Given
    import_from = ast.ImportFrom(module='os',
                                 names=[ast.alias(name='path', asname='p')],
                                 level=0)
    tree = ast.Try(body=[import_from],
                   handlers=[],
                   orelse=[],
                   finalbody=[]
                   )

    # When
    import_rewrite.get_body(previous=import_from,  # type: ignore
                            current=tree)

    result_ast = ast.dump(tree)

    # Then
    assert 'ImportFrom' not in result_ast
    assert 'Try' in result_ast



# Generated at 2022-06-23 22:27:13.765853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest.mock as mock

    from .mock_ast import MockNodeTransformer
    from .test_utils import compile_snippet

    node = mock.Mock(spec=ast.Import)

    transformer = BaseImportRewrite()
    BaseImportRewrite.rewrites = [('previous', 'current')]
    node.names = [
        mock.Mock(name='previous.foo', asname='foo')
    ]
    result = transformer.visit_Import(node)
    assert type(result) is ast.Try
    assert result.body[0].names[0].name == 'current.foo'

    BaseImportRewrite.rewrites = [('previous', 'current')]

# Generated at 2022-06-23 22:27:22.630776
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('foo.bar', 'replaced.bar')
        ]

    test_cases = [
        (
            ast.parse('import foo.bar'),
            ast.parse('import replaced.bar')
        ),
        (
            ast.parse('import foo.bar as bar'),
            ast.parse('import replaced.bar as bar')
        ),
        (
            ast.parse('import foo'),
            ast.parse('import foo')
        ),
    ]

    for before, after in test_cases:
        instance = TestBaseImportRewrite(before)
        instance.visit(before)
        assert ast.dump(before) == ast.dump(after)



# Generated at 2022-06-23 22:27:27.524991
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    import unittest
    
    class BaseTransformerTest(unittest.TestCase):
        def test_custom_transformer(self):
            class CustomTransformer(BaseTransformer):
                target = 'test'

                @classmethod
                def transform(self, tree):
                    return TransformationResult(tree, True, ['test'])
            
            tree = ast.parse('test')
            expected_result = b'1'
            result = base64.b64encode(pickle.dumps(CustomTransformer.transform(tree)))
            self.assertEqual(result, expected_result)
    
    unittest.main(verbosity=2)


# Generated at 2022-06-23 22:27:31.954257
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from . import ast3 as ast3
    from . import visitor as visitor
    from . import compiler as compiler
    from . import transform as transform
    from . import utils as utils

    # All public attributes should be defined in constructor
    BaseNodeTransformer(tree=ast3.AST())



# Generated at 2022-06-23 22:27:43.308741
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    node = ast.ImportFrom(module='a.b',
                          names=[ast.alias(name='c',
                                           asname=None)])

# Generated at 2022-06-23 22:27:46.942154
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'test'

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            ...
    assert TestTransformer.target == 'test'
    assert TestTransformer.transform


# Generated at 2022-06-23 22:27:57.989629
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import math
    import sys
    import pkgutil
    import os
    import _io
    import io
    import pkg_resources
    import abc
    import collections
    import re
    import types
    import six
    import functools
    import types

    from distutils import sysconfig
    from distutils.util import get_platform
    from typing import Any, Callable, Dict, Optional, List, Tuple
    from typed_ast import ast3, ast35
    from typed_ast.ast3 import AST


    from .utils import node_or_string


    from .transformations.utils.modifications import (
        add_imports, remove_imports, update_imports)

    import_from = 'from {}.{} import {}'


# Generated at 2022-06-23 22:27:59.180713
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

# Generated at 2022-06-23 22:28:10.461787
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ast import parse
    from ..typing import CompilationTarget

    class TestTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON_37

        rewrites = [('tkinter.filedialog', 'tkinter.askopenfilename')]

    import_ = "import tkinter.filedialog\n"
    import_from = "from tkinter.filedialog import askopenfilename\n"
    import_from_2 = "from tkinter.filedialog import open as open_file\n"

    import_ast = parse(import_)
    import_from_ast = parse(import_from)
    import_from_2_ast = parse(import_from_2)


# Generated at 2022-06-23 22:28:20.053574
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    target = 'js'
    rewrites = []
    dependencies = []
    b = BaseImportRewrite(target, rewrites, dependencies)
    assert b.target == 'js'
    assert b.rewrites == []
    assert b.dependencies == []
    assert b.generic_visit is not None
    assert b.visit is not None
    assert b.visit_Attribute is not None
    assert b.visit_Assert is not None
    assert b.visit_Assign is not None
    assert b.visit_Await is not None
    assert b.visit_BinOp is not None
    assert b.visit_BoolOp is not None
    assert b.visit_Break is not None
    assert b.visit_Call is not None

# Generated at 2022-06-23 22:28:23.410713
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor as orig_astor
    import typing as orig_typing
    import builtins as orig_builtins
    import queue as orig_queue
    import abc as orig_abc

# Generated at 2022-06-23 22:28:31.435918
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    class MyTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON36
        @classmethod
        def transform(cls, tree):
            return tree
    class MyTreeTransformer(BaseNodeTransformer):
        target = CompilationTarget.PYTHON36
        def visit(self, node):
            return node
    class MyImportRewriter(BaseImportRewrite):
        target = CompilationTarget.PYTHON36
    assert MyTransformer.target.value==1
    assert MyTreeTransformer.target.value==1
    assert MyImportRewriter.target.value==1

# Generated at 2022-06-23 22:28:36.334901
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    from ..types import CompilationTarget
    from typed_ast import ast3 as ast

    class T(BaseTransformer):
        target = CompilationTarget.PYTHON_38

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return None

    T.transform(None)

# Generated at 2022-06-23 22:28:43.386656
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import import_rewrite_test.test_BaseImportRewrite_visit_Import

    t = BaseImportRewrite(import_rewrite_test.test_BaseImportRewrite_visit_Import)
    t.rewrites = [('foo.bar', 'foo.baz'), ('foo.bar', 'foo.qaz')]

    result = t.visit(t._tree)

    assert result

    expected = '''try:
    import import_rewrite_test.test_BaseImportRewrite_visit_Import
except ImportError:
    import import_rewrite_test.test_BaseImportRewrite_visit_Import_cany
'''
    assert expected == compile(result, '', 'exec').strip()


# Generated at 2022-06-23 22:28:53.311558
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class BaseImportRewriteMock(BaseImportRewrite):
        rewrites = [('a.b.c', 'd.e')]

    ast_node = ast.ImportFrom(module='a.b.c.d', names=[ast.alias(name='e', asname=None)], level=0)
    transformer = BaseImportRewriteMock(None)
    node = transformer.visit(ast_node)
    assert isinstance(node, ast.Try)
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == 'd.e.d'
    assert node.body[0].names[0].name == 'e'


# Generated at 2022-06-23 22:28:55.520017
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class N(BaseNodeTransformer):
        def visit_Module(self, node):
            self._tree_changed = True
    N.transform(ast.parse("print(1)"))

# Generated at 2022-06-23 22:28:56.466438
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()  # should not fail

# Generated at 2022-06-23 22:28:58.954495
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL, verbose=False)

# Generated at 2022-06-23 22:29:07.320690
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class SomeTransformer(BaseImportRewrite):
        rewrites = [
            ('some.module', 'other.module'),
            ('some.name', 'other.name'),
        ]

    source = '''\
    import some.module
    from some.module import some_name
    from some.module import some_other_name
    from some.module import some_other_name as a
    from some.name import bar as foo
    from some.module.submodule import baz
    '''
    tree = ast.parse(source)
    result = SomeTransformer.transform(tree)
    assert result.is_changed is True


# Generated at 2022-06-23 22:29:10.697781
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_from = ast.Import(names=[ast.alias(name='sas7bdat')])

    result = BaseImportRewrite().visit(import_from)
    assert type(result) is ast.Try
    assert result.body[0].names[0].name == 'sas7bdat'



# Generated at 2022-06-23 22:29:12.126461
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    r = BaseImportRewrite()

test_BaseImportRewrite()

# Generated at 2022-06-23 22:29:23.631509
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget
    from ..utils.tree import template
    from os.path import dirname
    from os.path import join
    filename = join(dirname(__file__), '..', '..', 'tests', 'helper_classes.py')
    # Reads source code from file
    source_code = open(filename).read()
    tree = ast.parse(source_code) # Parses source code
    print(dir(tree))
    print(dir(tree.body))
    print(dir(tree.body[0]))
    print(dir(tree.body[1]))
    print(dir(tree.body[2]))
    print(dir(tree.body[3]))
    print(dir(tree.body[4]))
    #

# Generated at 2022-06-23 22:29:27.560736
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
	class TestTransformer(BaseTransformer):
		target = 'target'
		def transform(self, tree):
			pass
	test_transformer = TestTransformer()


# Generated at 2022-06-23 22:29:38.203435
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast
    from ._test_utils import BaseImportRewrite
    assert isinstance(BaseImportRewrite.rewrites, list)
    assert isinstance(BaseImportRewrite.dependencies, list)
    assert isinstance(BaseImportRewrite.target, object)
    assert isinstance(BaseImportRewrite.transform, object)
    assert isinstance(BaseImportRewrite._get_replaced_import_from_part, object)
    assert isinstance(BaseImportRewrite._tree, ast.AST)
    assert isinstance(BaseImportRewrite._tree_changed, bool)
    assert isinstance(BaseImportRewrite._get_names_to_replace, object)
    assert isinstance(BaseImportRewrite._replace_import_from_names, object)
    assert isinstance(BaseImportRewrite._replace_import, object)
    assert isinstance

# Generated at 2022-06-23 22:29:41.151049
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    transformer = BaseTransformer()
    assert transformer.target is None
    assert transformer.transform(None) == TransformationResult(None, False, [])


# Generated at 2022-06-23 22:29:51.437753
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestTransformer(BaseImportRewrite):
        rewrites = [
            ('module1', 'module2')
        ]

    tree = ast.parse('import module1')
    result = TestTransformer.transform(tree)
    assert result.transformations == ['import_rewrite']
    assert ast.dump(result.tree) == '\ntry:\n    import module1\nexcept ImportError:\n    import module2'

    tree = ast.parse('import module1.foo')
    result = TestTransformer.transform(tree)
    assert result.transformations == ['import_rewrite']
    assert ast.dump(result.tree) == '\ntry:\n    import module1.foo\nexcept ImportError:\n    import module2.foo'

    tree = ast.parse('import foo')
    result = TestTransformer

# Generated at 2022-06-23 22:29:56.166262
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    tree = ast.parse('import foo')
    import_rewrite_node_transformer = BaseImportRewrite.__new__(BaseImportRewrite)
    import_rewrite_node_transformer.rewrites = [('foo', 'bar')]
    import_rewrite_node_transformer.__init__(tree)
    assert ast.dump(import_rewrite_node_transformer.visit(tree)) == ast.dump(ast.parse(
        """
try:
    import foo
except ImportError:
    import bar
"""))


# Generated at 2022-06-23 22:29:57.617095
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
	assert issubclass(BaseTransformer, BaseTransformer)


# Generated at 2022-06-23 22:30:08.235172
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..compilers.python import get_transformer_list


# Generated at 2022-06-23 22:30:18.824271
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    class ExampleImportRewrite(BaseImportRewrite):
        rewrites = [
            ('six.moves', 'six')
        ]

    examples = {
        'from six.moves import StringIO':
            'from six import StringIO',
        'from six.moves.urllib.parse import urlparse':
            'from six.moves.urllib.parse import urlparse',
        'import six.moves': """try:
            import six.moves
        except ImportError:
            import six"""
    }

    for example, solution in examples.items():
        node = ast.parse(example)
        result = ExampleImportRewrite.transform(node)
        node = result.tree
        assert ast.dump(node) == solution

# Generated at 2022-06-23 22:30:27.559529
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..compiler import Compiler
    from ..utils.compiler import compile_snippet

    import_rewrite = 'import {}'.format(Compiler.reserved_name)

    class MyTransformer(BaseImportRewrite):
        source = import_rewrite
        rewrites = [('abc', 'abc_rewritten')]

    tree = compile_snippet(MyTransformer.source, 'single', 'exec').body
    result = MyTransformer.transform(tree)

    assert tree[0].names[0].name == 'abc'
    assert result.tree.body[0].body[0].names[0].name == 'abc_rewritten'


# Generated at 2022-06-23 22:30:29.577351
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestTransformer(BaseTransformer):
        target = 'temporary'

        @classmethod
        def transform(cls, tree: ast.AST) -> 'TransformationResult':
            return TransformationResult(tree, False, [])

    assert TestTransformer.target == 'temporary'

# Generated at 2022-06-23 22:30:30.521994
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    instance = BaseTransformer()
    instance



# Generated at 2022-06-23 22:30:33.793576
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    target = CompilationTarget.PY_36
    transformer = BaseTransformer(target)
    # Check that class target is set correctly
    assert transformer.target == target

# Generated at 2022-06-23 22:30:43.599061
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor

    # Test case import from with module to rewrite
    tree = ast.parse("""
    from six.moves import reload_module as reload
    """)

    class SubBaseImportRewrite(BaseImportRewrite):
        rewrites = (('six.moves', 'moves'),)

    result = SubBaseImportRewrite.transform(tree)
    expected = """
try:
    from six.moves import reload_module as reload
except ImportError:
    from moves import reload_module as reload
    """.strip()
    assert astor.to_source(result.tree) == expected

    # Test case import from with names to rewrite
    tree = ast.parse("""
    from six.moves import reload_module as reload, configparser
    """)


# Generated at 2022-06-23 22:30:50.618812
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .transformers.utils import print_ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]

    tree = ast.parse("""
import six
""")
    TestImportRewrite.transform(tree)

    assert print_ast(tree) == """
try:
    import six
except ImportError:
    import six.moves as six
"""


# Generated at 2022-06-23 22:30:52.094672
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert getattr(BaseImportRewrite, 'rewrites', None) is not None


# Generated at 2022-06-23 22:30:54.000810
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class MyTransformer(BaseTransformer):
        pass
    assert not MyTransformer().target

# Generated at 2022-06-23 22:30:55.675172
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite
    assert BaseImportRewrite is not None

# Generated at 2022-06-23 22:31:03.452565
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import unittest
    import json
    from typed_ast import ast3 as ast
    from ..utils.transform import BaseImportRewrite

    tree = ast.parse("""
    import json
    from base64 import b64encode
    import hmac
    from hashlib import sha1
    from .openssl import OpenSSL
    from .backends.commoncrypto import CommonCrypto
    from .backends.commoncrypto import _lib
    """)

    class Test(BaseImportRewrite):
        rewrites = [
           ('hashlib', 'hashlib3'),
           ('base64', 'base64codec')
        ]

    Test.transform(tree)


# Generated at 2022-06-23 22:31:05.053648
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    with pytest.raises(TypeError):
        BaseTransformer()


# Generated at 2022-06-23 22:31:16.390829
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    tree = ast.parse("import os")
    node_rewriter = BaseImportRewrite()
    node_rewriter.rewrites = [('os', 'nt')]
    node_rewriter.visit(tree)
    assert astor.to_source(tree) == "try:\n    import nt\nexcept ImportError:\n    import os"

    import astor
    tree = ast.parse("import os")
    node_rewriter = BaseImportRewrite()
    node_rewriter.rewrites = [('os', 'nt')]
    node_rewriter.visit(tree)
    assert astor.to_source(tree) == "try:\n    import nt\nexcept ImportError:\n    import os"


# Generated at 2022-06-23 22:31:17.831839
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from . import BaseImportRewriteTest
    BaseImportRewriteTest.BaseImportRewriteTest().test_BaseImportRewrite()

# Generated at 2022-06-23 22:31:19.142707
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    obj = BaseImportRewrite()


# Generated at 2022-06-23 22:31:20.678616
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    test_BaseImportRewrite._t = BaseImportRewrite()


# Generated at 2022-06-23 22:31:31.915976
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class MyTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    tree = ast.parse('import foo')
    transformation_result = MyTransformer.transform(tree)
    assert(str(transformation_result.tree) == """\
import_rewrite(
  try:
    extend(
      previous=foo,
      current=
      )
  except ImportError:
    extend(
      previous=None,
      current=bar,
      )
  )""")
    assert(transformation_result.changed)

    tree = ast.parse('from foo import bar, baz')
    transformation_result = MyTransformer.transform(tree)

# Generated at 2022-06-23 22:31:35.046439
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer(CompilationTarget.PYTHON_27)
    assert obj.target == CompilationTarget.PYTHON_27

# Generated at 2022-06-23 22:31:44.171491
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__name__ == 'BaseImportRewrite'
    assert BaseImportRewrite.rewrites == []
    assert BaseImportRewrite.dependencies == []
    assert BaseImportRewrite._tree is None
    assert BaseImportRewrite._tree_changed is False
    assert BaseImportRewrite.visit_Import is BaseImportRewrite.visit_Import
    assert BaseImportRewrite.visit_ImportFrom is BaseImportRewrite.visit_ImportFrom
    assert BaseImportRewrite._get_matched_rewrite(None) is None
    assert BaseImportRewrite._replace_import_from_module(None,1,2) is not None
    assert BaseImportRewrite._replace_import_from_names(None, {}) is not None

# Generated at 2022-06-23 22:31:45.073835
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer(): BaseTransformer()

# Generated at 2022-06-23 22:31:54.857135
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import codegen
    source = """
    from unittest.mock import patch
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from unittest.mock import Mock
    """
    tree = ast.parse(source)
    class Transformer(BaseImportRewrite):
        rewrites = [('unittest.mock', 'mock')]
    result = Transformer.transform(tree)
    assert result.transformed_tree is not tree
    assert result.tree_changed
    assert result.dependencies == ['mock']
    source_transformed = codegen.to_source(result.transformed_tree)

# Generated at 2022-06-23 22:32:00.777197
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse("import math")
    old_rewrite = ('math', 'abc')
    new_module = 'abc'
    cls = type('TestClass', (BaseImportRewrite,), {'rewrites': [old_rewrite]})
    cls.transform(tree)

    assert isinstance(tree.body[0], ast.Try)
    assert isinstance(tree.body[0].body[0], ast.Import)
    assert tree.body[0].body[0].names[0].name == new_module


# Generated at 2022-06-23 22:32:01.824532
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    BaseNodeTransformer(None)

# Generated at 2022-06-23 22:32:03.718271
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class T(BaseTransformer):
        pass
    assert T.target == None


# Generated at 2022-06-23 22:32:07.891310
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.parser import parse_ast
    from ..utils.composer import compose_ast
    #import_stmt = "import xbmc"
    import_stmt = "import xbmc as abc"
    import_stmt = "from xbmc import xyz"

    class Transformer(BaseImportRewrite):
        rewrites = [
            ('xbmc', 'xbmcaddon')
        ]

    tree = parse_ast(import_stmt)
    result = Transformer.transform(tree)
    output = compose_ast(result.tree)
    print(output)



# Generated at 2022-06-23 22:32:09.578358
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite(None)
    assert isinstance(transformer, BaseNodeTransformer)




# Generated at 2022-06-23 22:32:20.702055
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewr = BaseImportRewrite.__new__(BaseImportRewrite)

    module_name = "sys.stdin"
    alias_name = "get_input"
    level = 0

    node = ast.ImportFrom(names=[ast.alias(name=alias_name)], module=module_name, level=level)
    node.__class__.__name__ = "ImportFrom"

    rewr.__class__.rewrites = [("sys", "io")]

    expected_module_name = "io.stdin"
    expected_alias_name = "get_input"
    expected_level = 0


# Generated at 2022-06-23 22:32:30.146215
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('module1', 'module2')]

    node = ast.Import(names=[
        ast.alias(name='module1.name', asname='name'),
        ast.alias(name='module3', asname='asname')])


# Generated at 2022-06-23 22:32:32.635229
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Foo(BaseNodeTransformer):
        pass
    Foo(ast.parse('pass'))

# Generated at 2022-06-23 22:32:38.924394
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    from ..types import CompilationTarget

    class Transformer(BaseImportRewrite):
        target = CompilationTarget.PY3
        rewrites = [
            ('graphql', 'graphene')
        ]

    res, changed, deps = Transformer.transform(ast.parse('from graphql.type import List'))
    assert changed
    assert deps == []

# Generated at 2022-06-23 22:32:50.216379
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.compiler import StringSource
    from .noqa import NoQATransformer
    from .flatten_tuple import FlattenTupleTransformer

    # python -m unittest aiida_lark.transformer.base.test_BaseImportRewrite_visit_ImportFrom


# Generated at 2022-06-23 22:32:54.672929
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import ast
    tree = ast.parse("x = 1")
    class Test(BaseNodeTransformer):
        pass
    inst = Test(tree)
    assert inst._tree == tree
    assert inst._tree_changed == False


# Generated at 2022-06-23 22:32:58.092206
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    assert BaseTransformer.__abstractmethods__ == {'transform'}
    assert BaseTransformer.__module__ == 'fluentpy.transformer.base'
    assert BaseTransformer.__qualname__ == 'BaseTransformer'
    assert BaseTransformer.target is None

# Generated at 2022-06-23 22:32:58.759555
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    transformer = BaseImportRewrite()
    assert transformer

# Generated at 2022-06-23 22:33:05.574403
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
 
    assert BaseTransformer.__init__(object, target=CompilationTarget.PYTHON_SINGLE) == None
    assert BaseTransformer.__init__(object, target=CompilationTarget.PYTHON_TARGET) == None
    assert BaseTransformer.__init__(object, target=CompilationTarget.JAVA_TARGET) == None
    assert BaseTransformer.__init__(object, target=CompilationTarget.CSHARP_TARGET) == None
    assert BaseTransformer.__init__(object, target=CompilationTarget.CPP_TARGET) == None
    assert BaseTransformer.__init__(object, target=CompilationTarget.PYTHON_TARGET) == None
    assert BaseTransformer.__init__(object, target=CompilationTarget.CPYTHON_TARGET)

# Generated at 2022-06-23 22:33:06.755406
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    base = BaseTransformer()
    assert base.target == None

# Generated at 2022-06-23 22:33:07.711296
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert isinstance(BaseNodeTransformer._visit_fields, ast.NodeVisitor._visit_fields)

# Generated at 2022-06-23 22:33:17.642297
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .fix import fix_import
    from ..transformer import codegen

    tree = ast.parse("""
import thread
import threading
import queue

""")

    class Rewrite(BaseImportRewrite):
        rewrites = [('thread', '_thread')]

    result = Rewrite.transform(tree)

    assert codegen(result.tree) == codegen(fix_import("""
try:
    import thread
except ImportError:
    import _thread as thread

try:
    import threading
except ImportError:
    import threading

try:
    import queue
except ImportError:
    import queue

""", Rewrite.dependencies))



# Generated at 2022-06-23 22:33:18.162507
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:19.011678
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    assert BaseImportRewrite.__init__(BaseImportRewrite, ast.AST()) is None

# Generated at 2022-06-23 22:33:20.169327
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    trans = BaseTransformer()
    assert trans.target is None

# Generated at 2022-06-23 22:33:29.561960
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    index = len(BaseImportRewrite.rewrites) + 1

    # Simple import
    BaseImportRewrite.rewrites.append(('test.test', 'test_to.test_to'))
    node = ast.ImportFrom(module='test.test',
                          names=[ast.alias(name='test',
                                           asname=None)],
                          level=0)
    assert BaseImportRewrite.visit_ImportFrom(None, node) == ast.ImportFrom(module='test_to.test_to',
                                                                            names=[ast.alias(name='test',
                                                                                             asname=None)],
                                                                            level=0)

    # From module and from name

# Generated at 2022-06-23 22:33:30.548830
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    BaseImportRewrite()

# Generated at 2022-06-23 22:33:32.716183
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class DummyTransformer(BaseTransformer):
        target = ()

        @classmethod
        def transform(cls, tree):
            ...

    assert DummyTransformer.target == ()

# Generated at 2022-06-23 22:33:42.196111
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    code = 'from datetime import timedelta;'
    module = ast.parse(code)

    import_node = module.body[0]  # type: ast.Import
    assert isinstance(import_node, ast.Import)

    import_rewrite = BaseImportRewrite([('datetime', 'dateutil.parser')], module)
    result = import_node.accept(import_rewrite)

    assert isinstance(result, ast.Try)
    name = result.body[0].names[0]
    expected = ast.alias(name='dateutil.parser.timedelta', asname='timedelta')
    assert name == expected



# Generated at 2022-06-23 22:33:43.339282
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    try:
        t = BaseTransformer()
    except:
        t = None
    assert t is None

# Generated at 2022-06-23 22:33:50.143290
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [
            ('old_module', 'new_module')
        ]

    test_case = ast.parse('''
import old_module
''').body[0]
    test_case = TestBaseImportRewrite.visit_Import(test_case)

    expected_test_case = ast.parse('''
try:
    import old_module
except ImportError:
    import new_module
''').body[0]

    print(ast.dump(test_case))
    print(ast.dump(expected_test_case))

    assert test_case == expected_test_case



# Generated at 2022-06-23 22:33:51.466200
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer

#Unit test for constructor of class BaseTransformer

# Generated at 2022-06-23 22:34:01.236564
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tb = BaseImportRewrite()
    import_from = ast.ImportFrom(module='foo.bar',
                                 names=[ast.alias(name='foo1', asname='f'),
                                        ast.alias(name='foo2', asname='f2'),
                                        ast.alias(name='foo3', asname='f3'),
                                        ast.alias(name='*', asname=None)],
                                 level=0)

    tb.rewrites = [('foo.bar1', 'foo.bar2')]
    assert tb.visit_ImportFrom(import_from) == import_from

    tb.rewrites = [('foo.bar', 'foo.bar2')]

# Generated at 2022-06-23 22:34:07.685832
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():  # type: () -> None
    from ..utils import get_test_data_path

    with open(get_test_data_path('test_ast.py'), 'r') as f:
        tree = ast.parse(f.read())
    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            if node.name == 'my_func':
                return ast.Pass()

            return node

    TestTransformer(tree)

# Generated at 2022-06-23 22:34:09.021062
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    obj = BaseTransformer()
    assert obj.target == None


# Generated at 2022-06-23 22:34:15.059311
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class Transformer(BaseImportRewrite):
        rewrites = [('collections', 'collections.abc')]

    import_ = ast.Import(names=[ast.alias(name='collections',
                                         asname='coll')])

    rewrote = Transformer.transform(import_)[0]

    expected = ast.Try(body=[
        ast.Import(names=[ast.alias(name='collections.abc', asname='coll')]),
    ],
        orelse=[
            ast.Import(names=[ast.alias(name='collections', asname='coll')])],
        finalbody=[],
        handlers=[])

    assert ast.dump(rewrote) == ast.dump(expected)



# Generated at 2022-06-23 22:34:16.428056
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    BaseTransformer()


# Generated at 2022-06-23 22:34:18.668123
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    instance = BaseImportRewrite()
    assert isinstance(instance, BaseNodeTransformer)

# Generated at 2022-06-23 22:34:29.382279
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    expected = ast.Module(body=[
        ast.Try(body=[
            ast.Import(names=[ast.alias(name='winreg', asname='winreg')]),
            # TODO: add test for other situation
        ],
            handlers=[
                ast.ExceptHandler(
                    type=ast.Name(id='ImportError', ctx=ast.Load()),
                    name=None,
                    body=[
                        ast.Import(names=[ast.alias(name='_winreg', asname='_winreg')]),
                    ]
                )
            ],
            orelse=[],
        ),
    ])

    class TestTransformer(BaseImportRewrite):
        rewrites = [('winreg', '_winreg')]
    test = TestTransformer.transform(ast.parse('import winreg'))
    assert test.tree

# Generated at 2022-06-23 22:34:31.783839
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    import typed_ast.ast3 as ast
    tree = ast.parse('print("test")')
    instance = BaseNodeTransformer(tree)
    assert instance._tree is tree
    assert not instance._tree_changed


# Generated at 2022-06-23 22:34:42.715676
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    expected_module_name = 'greenio'
    expected_as_name = 'coolio'
    in_module_name = 'gevent'
    in_as_name = 'new_gevent'
    import_node = ast.Import(names=[
        ast.alias(name=in_module_name,
                  asname=in_as_name)])

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [(in_module_name, expected_module_name)]

    tree = ast.Module(body=[import_node])
    out_tree = TestImportRewrite.transform(tree).tree
    generator = TestImportRewrite.import_rewrite(previous=expected_module_name,
                                                 current=expected_module_name).body

# Generated at 2022-06-23 22:34:45.466675
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    class Transformer(BaseNodeTransformer):
        def __init__(self, tree):
            super().__init__(tree)
            self._tree_changed = False
    
    assert Transformer._tree_changed == False

# Generated at 2022-06-23 22:34:56.003714
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.sample_code import import_statement_sample
    from ..utils.ast_compare import is_equal_trees

    import ast as ast_lib
    import_ = ast_lib.parse(import_statement_sample)
    class ImportRewrite(BaseImportRewrite):
        target = 'py2'
        rewrites = [('typing', 'future_builtins')]

    ast_lib = ImportRewrite.transform(import_).tree
    expected = ast_lib.parse("""
try:
    import foo
    import bar
    import typing
    import typing_extra
except ImportError:
    import foo
    import bar
    import future_builtins
    import future_builtins
""")
    assert is_equal_trees(expected, ast_lib)



# Generated at 2022-06-23 22:35:06.772512
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils import ast_utils
    from textwrap import dedent

    source = dedent("""
    from project.a.b.c.d import e1, e2 as e2_alias, f
    from project.g import h as h_alias, i
    from project.j.k.l.m import n
    from project.e import f
    import project.o
    """)  # noqa: E501


# Generated at 2022-06-23 22:35:17.953171
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Dummy(BaseImportRewrite):
        rewrites = [
            ('foo', 'bar'),
            ('eggs', 'spam')
        ]
    tree = ast.parse('''
        import os
        import foo
        import foo.bar
        import eggs
        import eggs.spam
        import eggs.spam.ham
    ''')
    Dummy.transform(tree)

# Generated at 2022-06-23 22:35:18.723154
# Unit test for constructor of class BaseNodeTransformer
def test_BaseNodeTransformer():
    assert BaseNodeTransformer._tree_changed == False

# Generated at 2022-06-23 22:35:21.006603
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class TestBaseTransformer(BaseTransformer):
        def transform(tree):
            return

    obj = TestBaseTransformer()
    assert obj.target == "python3"

# Generated at 2022-06-23 22:35:23.078254
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    from .test_data import BaseImportRewrite_test
    assert BaseImportRewrite_test.test_BaseImportRewrite()

# Generated at 2022-06-23 22:35:33.495321
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import os
    import sys
    sys.path.append(os.path.dirname(__file__))

    import transformers
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    with mock.patch.object(BaseImportRewrite, 'rewrites', [('requests', 'requests_mock')]):
        tree = ast.parse('''
import requests
import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from . import requests2 as requests''')
        res = BaseImportRewrite.transform(tree)

# Generated at 2022-06-23 22:35:38.800289
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..python.builtins import BuiltinsTransformer

    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('abc', 'def')]

    tree = ast.parse("import abc")
    result = TestImportRewrite.transform(tree)

    assert isinstance(tree.body[0], ast.Try)
    assert isinstance(tree.body[0].body[0], ast.Import)
    assert tree.body[0].body[0].names[0].name == 'def'
    assert len(result.dependencies) == 1
    assert result.dependencies == [BuiltinsTransformer.dependency_name]


# Generated at 2022-06-23 22:35:48.630208
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    TREE = ast.Try(
        body=[ast.ImportFrom(
            module='a.b',
            names=[
                ast.alias(name='C1', asname=None)],
            level=0),
            ast.ImportFrom(
                module='a',
                names=[
                    ast.alias(name='C2', asname=None)],
                level=0),
            ast.ImportFrom(
                module='a.b',
                names=[
                    ast.alias(name='C3', asname=None)],
                level=0)],
        handlers=[],
        orelse=[])


# Generated at 2022-06-23 22:35:51.968311
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    class A(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]
        def visit_ImportFrom(self, node):
            pass
    assert A.dependencies == ['a', 'c']

# Generated at 2022-06-23 22:35:58.834085
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    from ..utils.ast_wrapper import ASTWrapper
    original = 'import gevent'
    tree = ast.parse(original)
    rewrited = 'try:\n    import gevent\nexcept ImportError:\n    import greenlet'

    transformer = BaseImportRewrite(tree)
    transformer.rewrites = [('gevent', 'greenlet')]
    transformer.visit(tree)

    assert astor.to_source(tree) == rewrited


# Generated at 2022-06-23 22:36:01.119137
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    arg = BaseTransformer()
    assert isinstance(arg, BaseTransformer)
    assert BaseTransformer.target is None


# Generated at 2022-06-23 22:36:13.209446
# Unit test for constructor of class BaseImportRewrite
def test_BaseImportRewrite():
    import ast as python_ast
    test_rewrites = BaseImportRewrite.rewrites
    BaseImportRewrite.rewrites = [("foo.bar", "baz.qux")]
    node_rewrite = BaseImportRewrite(None)
    BaseImportRewrite.rewrites = test_rewrites

    import_rewrite_from_module = python_ast.parse("from os import *").body[0]
    import_rewrite_from_name = python_ast.parse("from os import path as mpath").body[0]

    assert node_rewrite._get_replaced_import_from_part(import_rewrite_from_module, ast.alias(name='*',
                                                                                            asname=None),
                                                       {}) == import_rewrite_from_module

    assert node_rewrite._

# Generated at 2022-06-23 22:36:16.911711
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    CompilationTarget
    TransformationResult
    snippet
    extend
    BaseTransformer
    ast
    ast.AST
    ABCMeta
    List
    Tuple
    Union
    Optional
    Iterable
    Dict
    import_rewrite
    BaseNodeTransformer
    BaseImportRewrite

# Generated at 2022-06-23 22:36:24.653664
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    import astunparse

    class Rewriter(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    source = parse(
        'from foo import foo\n'
        'from foo import bar as baz\n'
        'from foo.qux import qux\n'
        'from foo.qux import bar as qux_baz\n'
    )


# Generated at 2022-06-23 22:36:30.692063
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import ast
    import unittest
    from unittest import mock
    from typed_ast.ast3 import Module, Import, alias
    from typed_astunparse import unparse
    from py2py3.transformers.rewrites import BaseImportRewrite
    from py2py3.transformers import BaseNodeTransformer
    from py2py3.py2py3 import get_dependencies

    class ImportRewrite(BaseImportRewrite):
        rewrites = [('some', 'othersome')]  # type: List[Tuple[str, str]]

    class NodeTransformer(BaseNodeTransformer):
        dependencies = ['some']  # type: List[str]


# Generated at 2022-06-23 22:36:36.945434
# Unit test for constructor of class BaseTransformer
def test_BaseTransformer():
    class FooTransformer(BaseTransformer):
        target = CompilationTarget.PYTHON_33

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    assert FooTransformer.target == CompilationTarget.PYTHON_33
    assert FooTransformer.transform(None) == TransformationResult(None, False, [])