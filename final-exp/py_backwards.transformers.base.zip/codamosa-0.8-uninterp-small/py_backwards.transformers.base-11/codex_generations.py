

# Generated at 2022-06-25 21:56:46.043275
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    for node in BaseImportRewrite().visit_Import(ast.parse("import os").body[0]):
        assert node[0] == "import os"


# Generated at 2022-06-25 21:56:55.987700
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    import numpy as np
    import scipy as sp
    import pandas as pd
    import os as os
    import sys as sys
    import re as re
    import matplotlib.pyplot as plt
    import glob as glob
    import collections as collections
    class BaseImportRewriteTransformer(BaseImportRewrite):
        rewrites = [
            ('numpy', 'Numpy'),
            ('scipy', 'Scipy'),
            ('pandas', 'Pandas'),
            ('os', 'os'),
            ('sys', 'sys'),
            ('re', 're'),
            ('matplotlib', 'Matplotlib'),
            ('glob', 'glob'),
            ('collections', 'collections')
        ]
    transformer = BaseImportRewriteTransformer

# Generated at 2022-06-25 21:56:57.516524
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass


# Generated at 2022-06-25 21:57:02.947542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast.ast3 import Import
    import_0 = Import(names=[])
    base_import_rewrite_0 = BaseImportRewrite(import_0)
    base_import_rewrite_0._tree_changed = True
    base_import_rewrite_0._get_matched_rewrite(None)
    base_import_rewrite_0._replace_import(import_0, '', '')
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:09.983978
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ...snippets import import_rewrite_example
    from ...compilation import patch

    import_rewrite_example.rewrite()
    patch.rewrite()

    import_rewrite_example.example(
        BaseImportRewrite({'BaseImportRewrite': BaseImportRewrite},
                          from_='abc.base',
                          to='base.abc'))
    import_rewrite_example.example(
        BaseImportRewrite({'BaseImportRewrite': BaseImportRewrite},
                          from_='abc',
                          to='base.abc'))


# Generated at 2022-06-25 21:57:18.794095
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer0(BaseImportRewrite):
        rewrites = [('syslog', 'syslog_r')]

    tree0 = ast.parse('import syslog')
    Transformer0.transform(tree0)
    assert tree0.body[0].value.names[0].name == 'syslog_r'

    tree0 = ast.parse('import syslog as sl')
    Transformer0.transform(tree0)
    assert tree0.body[0].value.names[0].name == 'syslog_r'

    tree0 = ast.parse('import syslog_r as sl')
    Transformer0.transform(tree0)
    assert tree0.body[0].value.names[0].name == 'syslog_r'

    tree0 = ast.parse('import time')

# Generated at 2022-06-25 21:57:27.992644
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast  # noqa
    import astor

    tree = ast.parse("""
    import a
    """)  # type: ast.AST

    import_rewrite_0 = BaseImportRewrite([])
    transformation_result_0 = BaseImportRewrite.transform(tree)

    assert transformation_result_0.tree != tree
    assert transformation_result_0.changed

    tree = ast.parse("""
    import a
    """)  # type: ast.AST

    import_rewrite_1 = BaseImportRewrite([('a', 'b')])
    transformation_result_1 = BaseImportRewrite.transform(tree)

    assert transformation_result_1.tree != tree
    assert transformation_result_1.changed


# Generated at 2022-06-25 21:57:33.021023
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Test the method `visit_Import` of class `BaseImportRewrite`."""
    tree = ast.parse("import os\nfrom email.mime.text import MIMEText")
    import_rewrite_0 = BaseImportRewrite()
    import_rewrite_0.rewrites = [(from_, to) for from_, to in [("email", "email2")]]
    import_rewrite_0.transform(tree)

# Generated at 2022-06-25 21:57:37.855433
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    import_from_0 = ast.Import(names=[ast.alias(name='', asname='')])
    try_0 = base_import_rewrite_0._replace_import(import_from_0, '', '')
    assert isinstance(try_0, ast.Try)
    assert try_0.body[0] == import_from_0

# Generated at 2022-06-25 21:57:45.168757
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    import_0 = ast.Import([ast.alias(name='import_0_name')])
    rewrites_0 = ()
    base_import_rewrite_0.rewrites = rewrites_0
    base_import_rewrite_0.generic_visit = lambda arg, arg_1: arg
    result = base_import_rewrite_0.visit_Import(import_0)
    assert isinstance(result, ast.Import)


# Generated at 2022-06-25 21:57:57.039851
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    alias_0 = module_0.alias(**dict_1)
    dict_2 = {}
    dict_2['names'] = []
    dict_2['names'].append(alias_0)
    a_s_t_2 = module_0.Import(**dict_2)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_0.visit(a_s_t_2)

# Unit

# Generated at 2022-06-25 21:58:05.779917
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Constructor of class Import creates an alias named "name" with attribute name
    # equal to the value of its argument name. The value of its argument name is not
    # defined in this test.
    alias_0 = module_0.alias(**dict_0)
    list_0 = [alias_0]
    import_0 = module_0.Import(**dict_0, names=list_0)
    from_0 = "from"
    to_0 = "to"
    try_0 = base_import

# Generated at 2022-06-25 21:58:11.911112
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    module_1 = module_0.ImportFrom(**dict_0)
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    rewrites_0 = [('a', 'b')]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1, rewrites_0)
    base_import_rewrite_0.visit_ImportFrom(module_1)


# Generated at 2022-06-25 21:58:21.099659
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    module_name_0 = "test"
    alias_0 = a_s_t_0
    list_0 = []
    list_0.append(alias_0)
    import_0 = a_s_t_0.Import(names=list_0, lineno=0, col_offset=0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(module_name_0, module_name_0)]

# Generated at 2022-06-25 21:58:30.548337
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {'names': [module_0.alias(**{'name': 'a'})]}
    a_s_t_0 = module_0.Import(**dict_0)
    dict_1 = {}
    dict_1_alias_0 = module_0.alias(**{'name': 'b'})
    dict_1['names'] = [dict_1_alias_0]
    a_s_t_1 = module_0.Import(**dict_1)
    dict_2 = {}
    dict_2_except_handler_0 = module_0.ExceptHandler(**{})
    dict_2['handlers'] = [dict_2_except_handler_0]
    dict_2_body_0 = a_s_t_1
    dict_2_body_1 = []
   

# Generated at 2022-06-25 21:58:38.076315
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = module_0.Dict(keys=[module_0.Str(s='module')], values=[module_0.Str(s='_ast')])
    keyword_0 = module_0.keyword(value=module_0.Name(id='module', ctx=module_0.Load()), arg='module')
    keyword_1 = module_0.keyword(value=module_0.Str(s='_ast'), arg='module')
    import_from_0 = module_0.ImportFrom(**dict_0)
    import_from_1 = module_0.ImportFrom(names=[], **dict_0)
    import_from_2 = module_0.ImportFrom(names=[module_0.alias(name='Name', asname=None)], **dict_0)
    list_0 = []
    list

# Generated at 2022-06-25 21:58:48.524375
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {'names': [module_0.alias(**{'name': '_importlib_fullname', 'asname': None})]}
    import_0 = module_0.Import(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(import_0)
    dict_0 = {'names': [module_0.alias(**{'name': '_importlib_fullname', 'asname': None})]}
    import_0 = module_0.Import(**dict_0)
    dict_0 = {'body': [import_rewrite(previous=import_0, current=import_0)]}
    try_0 = module_0.Try(**dict_0)

# Generated at 2022-06-25 21:58:54.855082
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {'names': ['os', 'sys', 'gettext']}
    a_s_t_0 = module_0.Import(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)


# Generated at 2022-06-25 21:58:58.683756
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import(names=[
        ast.alias(name='name',
                  asname=None)])

    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)



# Generated at 2022-06-25 21:59:04.492235
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    #§ import_from_1 = module_0.ImportFrom(module='typed_ast._ast3', names=[module_0.alias(name='AST', asname=None)], level=0)
    dict_0 = {}
    dict_0['module'] = 'typed_ast._ast3'
    dict_0['names'] = [module_0.alias(name='AST', asname=None)]
    dict_0['level'] = 0
    import_from_1 = module_0.ImportFrom(**dict_0)
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 21:59:25.814909
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {'lineno': 3, 'col_offset': 4}
    a_s_t_0 = module_0.AST(**dict_0)
    list_0 = [a_s_t_0]
    dict_1 = {'names': list_0}
    a_s_t_1 = module_0.Import(**dict_1)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    assert base_import_rewrite_0.visit_Import(a_s_t_1) == a_s_t_1


# Generated at 2022-06-25 21:59:32.067117
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(**dict_0)
    ast_alias_0 = module_0.alias(name='', **dict_0)
    ast_alias_0.name = ''
    ast_alias_0.asname = None
    ast_alias_1 = module_0.alias(name='', **dict_0)
    ast_alias_1.name = ''
    ast_alias_1.asname = None
    ast_alias_list_0 = [ast_alias_0, ast_alias_1]

# Generated at 2022-06-25 21:59:39.401578
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    dict_0 = {}
    string_0 = "abc"
    name_0 = string_0
    a_s_t_0 = module_0.alias(name=name_0, **dict_0)
    list_0 = [a_s_t_0]
    module_0.Import(names=list_0, **dict_0)


# Generated at 2022-06-25 21:59:48.795992
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast._ast3 as module_0
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    a_s_t_0.body = [module_0.Import()]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    class_dict_0 = {'rewrites': [(m_s_t_0_0_0, m_s_t_0_0_1) for (m_s_t_0_0_0, m_s_t_0_0_1) in (('old', 'new'),)], 'target': None}
    class_0 = type("BaseImportRewrite", (BaseImportRewrite,), class_dict_0)
    base_import_rewrite_0

# Generated at 2022-06-25 21:59:57.980946
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.Import(module_0.alias(**dict_0))
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Test for line 5
    assert(base_import_rewrite_0._tree_changed == False)
    # Test for line 9
    assert(base_import_rewrite_0._get_matched_rewrite(None) == None)
    # Test for line 14
    assert(base_import_rewrite_0._get_matched_rewrite('name') == None)

# Generated at 2022-06-25 22:00:02.738690
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import(names=[ast.alias(name='a',asname='b')])
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:00:05.188263
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:00:13.832460
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {u'module': u'HTTP_0', u'names': [module_0.alias(**{u'name': u'*'}), module_0.alias(**{u'name': u'*'})], u'level': 0}
    import_from_0 = module_0.ImportFrom(**dict_0)
    dict_1 = {u'transform': u'\\u3042', u'name': u'onion'}
    alias_1 = module_0.alias(**dict_1)
    list_0 = [alias_1, module_0.alias(**{u'name': u'*'})]
    dict_2 = {u'module': u'HTTP_0', u'names': list_0, u'level': 0}

# Generated at 2022-06-25 22:00:20.859966
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    alias_0 = module_0.alias(name='module_0', asname=None)
    list_0 = [alias_0]
    import_from_0 = module_0.ImportFrom(module='module_0', names=list_0, level=None)
    test_0 = base_node_transformer_0.visit_ImportFrom(import_from_0)
    assert isinstance(test_0, module_0.ImportFrom)


# Generated at 2022-06-25 22:00:23.142726
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)


# Generated at 2022-06-25 22:01:03.446194
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Default values of instance properties
    rewrites_0 =  []
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = rewrites_0
    dict_0 = {}
    alias_0 = module_0.alias(**dict_0)
    list_0 = [alias_0]
    import_node_0 = module_0.Import(**dict_0)
    import_node_0.names = list_0
    # Testing method visit_Import of class BaseImportRewrite
    test_0 = module_0.Import(**dict_0)
    test_0.names = list_0
   

# Generated at 2022-06-25 22:01:07.824290
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    dict_1 = {}
    import_from_0 = module_0.ImportFrom(**dict_1)
    union_0 = base_node_transformer_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:15.045509
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    str_0 = "test"
    str_1 = "test"
    tuple_0 = (str_0, str_1)
    list_0 = [tuple_0]
    list_0 = list_0
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_class_0 = BaseImportRewrite
    base_class_0.rewrites = list_0
    str_2 = "test"
    alias_0 = module_0.alias(**dict_0)
    alias_0.name = str_2

# Generated at 2022-06-25 22:01:26.563702
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite
    a_s_t_1 = module_0.AST(**dict_0)
    import_from_0 = module_0.ImportFrom(**dict_0)
    try:
        base_import_rewrite_0.visit_ImportFrom(base_node_transformer_0, import_from_0)
    except:
        pass
    else:
        raise Exception('Expected Exception not thrown')


# Generated at 2022-06-25 22:01:32.805719
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_1 = None
    alias_0_0 = module_0.alias(**{})
    level_0 = 0
    import_from_0 = module_0.ImportFrom(module=module_1, names=[alias_0_0], level=level_0)
    alias_0_1 = module_0.alias(**{})
    level_1 = 1
    import_from_1 = module_0.ImportFrom(module=module_1, names=[alias_0_1], level=level_1)
    alias_0_2 = module_0.alias(**{})
    level_2 = 2
    import_from_2 = module_0.ImportFrom(module=module_1, names=[alias_0_2], level=level_2)

# Generated at 2022-06-25 22:01:41.254924
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_1 = module_0.Import(names=[module_0.alias(name='typed_ast.ast3', asname='ast')])
    base_import_rewrite_0 = BaseImportRewrite(module_0.AST())
    dict_0 = {}
    dict_0['rewrites'] = [('typed_ast.ast3', 'typed_ast._ast3')]
    base_import_rewrite_1 = BaseImportRewrite(module_0.AST(**dict_0))
    dict_0 = {}
    dict_0['rewrites'] = [('typed_ast.ast3', 'typed_ast._ast3')]
    base_import_rewrite_2 = BaseImportRewrite(module_0.AST(**dict_0))
    dict_0 = {}

# Generated at 2022-06-25 22:01:51.889273
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    dict_1 = {}
    dict_1['type'] = module_0.Import
    dict_1['names'] = [dict_0]
    dict_1['lineno'] = 0
    dict_1['col_offset'] = 0
    a_s_t_1 = module_0.AST(**dict_1)
    a_s_t_2 = base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 22:01:59.362175
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    importfrom_0 = module_0.ImportFrom(**dict_0)
    dict_1 = {}
    a_s_t_0 = module_0.AST(**dict_1)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    get_names_to_replace_0 = base_import_rewrite_0.visit_ImportFrom(importfrom_0)

    if get_names_to_replace_0 != importfrom_0: #change dict_0
        importfrom_0.names[0].asname = ' '
    if get_names_to_replace_0 != importfrom_0.names[0].name: #change dict_0
        importfrom_0.names[0].name = ' '

# Generated at 2022-06-25 22:02:04.016856
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_1 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    dict_1 = {}
    dict_1['ctx'] = None
    dict_1['module'] = ''
    dict_1['names'] = (module_0.alias(**dict_1),)
    dict_1['col_offset'] = 0
    dict_1['level'] = 0
    dict_1['lineno'] = 0
    dict_2 = {}
    dict_2['names'] = (module_0.alias(**dict_1),)
    dict_2['lineno'] = 0
    dict_2['col_offset'] = 0
    import_from_0 = module_0.ImportFrom

# Generated at 2022-06-25 22:02:11.877698
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    int_0 = 0
    alias_0 = module_0.alias(name="*", asname="")
    list_0 = [alias_0]
    a_s_t_1 = module_0.ImportFrom(module="test", names=list_0, level=int_0)
    node_0 = base_node_transformer_0.visit_ImportFrom(a_s_t_1)


# Generated at 2022-06-25 22:03:25.288778
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = alias('a')
    list_0 = [alias_0]
    import_from_0 = import_from('oo', list_0)
    dict_1 = {}
    module_1 = module(**dict_1)
    list_1 = [import_from_0]
    module_1.body = list_1
    # Visit import_from 0
    base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:03:31.290584
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    import_from_0 = module_0.ImportFrom(
        **{'level': 0, 'module': '', 'names': [module_0.alias(**{
            'asname': '', 'name': ''
        })]})
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0 = base_import_rewrite_1
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    import_from_1 = import_from_0
    base_import_rewrite_0.visit_ImportFrom(import_from_1)


# Generated at 2022-06-25 22:03:33.144954
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    try:
        test_case_0()
    except Exception:
        print('Exception raised in case #0')


# Generated at 2022-06-25 22:03:38.236691
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {'names': []}
    import_0 = module_0.Import(**dict_0)
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:45.481698
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = 'abc'
    alias_0 = module_0.alias(**{'name': module_1})
    import_as = 'abc'
    alias_1 = module_0.alias(**{'name': module_1, 'asname': import_as})
    if alias_0 == alias_1:
        names_0 = [alias_0]
    else:
        names_0 = [alias_1]
    lineno = 0
    col_offset = 0

# Generated at 2022-06-25 22:03:53.899219
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {}
    import_0 = module_0.Import(**dict_0)
    dict_1 = {}
    alias_0 = module_0.alias(**dict_1)
    dict_2 = {'Names': [alias_0]}
    import_1 = module_0.Import(**dict_2)
    dict_3 = {'Names': [alias_0]}
    import_2 = module_0.Import(**dict_3)
    dict_4 = {'Names': [alias_0]}
    import_3 = module_0.Import(**dict_4)
    dict_5 = {'Names': [alias_0]}
    import_4 = module_0.Import(**dict_5)
    dict_6 = {'Names': [alias_0]}
    import_5 = module_0

# Generated at 2022-06-25 22:04:02.211668
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    int_0 = 1
    str_0 = 'from module import name'
    list_0 = []
    alias_0 = module_0.alias(**dict_0)
    import_from_0 = module_0.ImportFrom(int_0, str_0, list_0, **dict_0)
    base_node_transformer_0.visit = lambda x: alias_0 
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:04:09.959672
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {'module':'module','names':('import', 'from'),'level':int}
    import_ast_0 = module_0.ImportFrom(**dict_0)
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = ('rewrites',)
    base_import_rewrite_0.visit_ImportFrom(import_ast_0)
    base_import_rewrite_0.visit_ImportFrom(import_ast_0)


# Generated at 2022-06-25 22:04:18.486087
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    dict_0 = {'lineno': 18, 'col_offset': 20, 'level': 19, 'names': [{'col_offset': 0, 'name': 'string', 'asname': ''}], 'module': 'string'}
    import_from_0 = module_0.ImportFrom(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(import_from_0)
    rewrites_0 = []
    base_import_rewrite_0.rewrites = rewrites_0
    ast_0 = module_0.AST(**{})
    base_node_transformer_0 = BaseNodeTransformer(ast_0)
    base_import_rewrite_0._tree = ast_0
    base_import_rewrite_0._tree_changed = False
    base_import_

# Generated at 2022-06-25 22:04:26.756240
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    list_0 = []
    alias_0 = module_0.alias(name='i', asname='i')
    list_0.append(alias_0)
    import_from_0 = module_0.ImportFrom(level=0, module='django', names=list_0)
    import_from_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    list_1 = []
    alias_1 = module_0.alias(name='i', asname='i')
    list_1.append(alias_1)
    try_0 = module_0