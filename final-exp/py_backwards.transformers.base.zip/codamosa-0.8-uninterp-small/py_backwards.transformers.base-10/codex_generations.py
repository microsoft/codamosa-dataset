

# Generated at 2022-06-25 21:56:38.176830
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast_unparse import unparse
    tree = ast.parse('import test')
    transformer = BaseImportRewrite(tree)
    new_tree = transformer.visit(tree)
    assert unparse(new_tree) == 'import test'
    

# Generated at 2022-06-25 21:56:41.973343
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a = ast.Import()
    BaseImportRewrite.rewrites = []
    BaseImportRewrite.rewrites.append(("abc.abc", "def.abc"))
    a.names[0].name = "abc.abc"
    b = BaseImportRewrite.transform(a)
    assert len(b.body) == 1


# Generated at 2022-06-25 21:56:53.333667
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    from_0 = ast.Import()
    try:
        assert raise_exception(NotImplementedError, BaseImportRewrite, '_get_matched_rewrite', base_import_rewrite_0, None, None)
    except NotImplementedError:
        pass

    try:
        assert raise_exception(NotImplementedError, BaseImportRewrite, '_replace_import', base_import_rewrite_0, None, None, None, None)
    except NotImplementedError:
        pass

    assert base_import_rewrite_0._tree_changed == False
    node_None = None

# Generated at 2022-06-25 21:57:01.577049
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestClass1(BaseImportRewrite):
        rewrites = [
            ('os', '_os'),
            ('ast', '_ast')]

        def generic_visit(self, node):
            return node

    module_body = [
        ast.Import(names=[ast.alias(name='os', asname=None)]),
        ast.Import(names=[ast.alias(name='ast', asname=None)]),
        ast.Import(names=[ast.alias(name='sys', asname=None)])]

    module = ast.Module(body=module_body, type_ignores=[])
    transformer = TestClass1.transform(module)
    tree = transformer.tree

    import_rewrite_body = import_rewrite.get_body()

    first_import = tree.body[0]

# Generated at 2022-06-25 21:57:10.989970
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-25 21:57:16.655116
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree_0 = ast.parse('from a import b as c\nimport a')
    base_importer_rewrite_0 = BaseImportRewrite(tree_0)
    tree_0_result = base_importer_rewrite_0.visit_Import(tree_0.body[1].value)
    assert tree_0_result == ast.parse('''
try:
    import a
except ImportError:
    from a import b as c
    ''').body[0]



# Generated at 2022-06-25 21:57:25.638232
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_from_0 = ast.ImportFrom(module='from_module',
                                   names=[ast.alias(name='from_name',
                                                    asname='from_asname')],
                                   level=0)
    import_0 = ast.Import(names=[ast.alias(name='name',
                                          asname='asname')])
    module_0_0 = ast.Module(body=[import_from_0,
                                  import_0])
    base_node_transformer_0 = BaseImportRewrite(module_0_0)
    import_from_1 = ast.ImportFrom(module='from_module',
                                   names=[ast.alias(name='from_name',
                                                    asname='from_asname')],
                                   level=0)

# Generated at 2022-06-25 21:57:34.397818
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('''
import aiohttp
import asyncio
import functools
import logging
import os
import selectors
import shutil
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import warnings
''')
    transformer = BaseImportRewrite()
    transformer.visit(tree)
    expected = '''
import aiohttp
import asyncio
import functools
import logging
import os
import selectors
import shutil
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import warnings
'''
    assert ast.dump(tree) == expected



# Generated at 2022-06-25 21:57:42.806320
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    from ast import ImportFrom, alias
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import stmt

    imp = ImportFrom(module='time',
                     names=[alias(name='sleep', asname='')],
                     level=0)

    tree = ast.parse("from time import sleep; sleep(3)")

    class Transformer(BaseImportRewrite):
        rewrites = [('time', 'time')]

    transformer = Transformer(tree)

    node = ImportFrom(module='time',
                      names=[alias(name='sleep', asname='')],
                      level=0)

    assert transformer.visit_ImportFrom(node) == imp



# Generated at 2022-06-25 21:57:48.206910
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree_0 = ast.parse("from example.test import example_test")
    base_import_rewrite_0 = BaseImportRewrite(tree_0)
    base_import_rewrite_0.rewrites = [
        ('example.test', 'example1.test1')]
    base_import_rewrite_0.visit_ImportFrom(tree_0.body[0])
    assert base_import_rewrite_0._tree_changed == True


# Generated at 2022-06-25 21:58:00.600114
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import pytest
    try:
        from mistletoe.base_transformer import BaseImportRewrite
    except ImportError:
        pytest.skip("Function not implemented")
    from ..types import CompilationTarget
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseImportRewrite):
        target = CompilationTarget.PYTHON
        rewrites = [
            ('old', 'new'),
        ]

    node = ast.Import(names=[
        ast.alias(name='old.a', asname='a'),
    ])
    result = DummyTransformer.transform(node)
    assert isinstance(result[0], ast.Try), 'Object is not of type ast.Try'


# Generated at 2022-06-25 21:58:05.210088
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    baseimportrewrite_0 = BaseImportRewrite()
    alias_0 = ast.alias(name="alias_0", asname="asname_0")
    node_0 = ast.ImportFrom(module="module_0", names=[alias_0], level=0)
    import_rewrite_0 = baseimportrewrite_0._replace_import_from_names(node_0, {})
    assert import_rewrite_0 is not None

# Generated at 2022-06-25 21:58:14.244403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    tree = ast.parse('import os')
    ast.fix_missing_locations(tree)
    transformed = ast.dump(base_import_rewrite_0.visit(tree))
    assert transformed == ast.dump(tree)

    base_import_rewrite_1 = BaseImportRewrite()
    base_import_rewrite_1.rewrites = [('os', 'os')]
    tree = ast.parse('import os')
    ast.fix_missing_locations(tree)
    transformed = ast.dump(base_import_rewrite_1.visit(tree))

# Generated at 2022-06-25 21:58:23.531329
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test with no rewrite to make.
    import_from_0 = ast.ImportFrom(module='logging',
                                   names=[ast.alias(name='getLogger',
                                                    asname='logging')],
                                   level=0)
    import_rewrite_0 = BaseImportRewrite(import_from_0)
    assert import_rewrite_0.visit_ImportFrom(import_from_0) == import_from_0

    # Test with rewrite for module name.
    import_from_1 = ast.ImportFrom(module='django.db',
                                   names=[ast.alias(name='models',
                                                    asname='models')],
                                   level=0)
    import_rewrite_1 = BaseImportRewrite(import_from_1)
    import_rewrite_1.rewrites

# Generated at 2022-06-25 21:58:32.571363
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    #Create a tree
    a_ImportFrom_0 = ast.ImportFrom(
        level = 0,
        module = "abc",
        names = [ast.alias(
            name = "abc",
            asname = "abc")])

    a_module_0 = ast.Module(
        body = [a_ImportFrom_0])

    #Create an instance of BaseImportRewrite
    a_BaseImportRewrite_0 = BaseImportRewrite(
        tree = a_module_0)

    a_BaseImportRewrite_0.visit_ImportFrom(
        node = a_ImportFrom_0)

    #Return the result
    return a_BaseImportRewrite_0.visit_ImportFrom(
        node = a_ImportFrom_0)



# Generated at 2022-06-25 21:58:36.370862
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3
    from typed_ast.ast3 import ImportFrom, alias
    t = BaseImportRewrite()
    node=ast3.ImportFrom(module="a", names=[alias(name="b", asname=None)], level=0)
    t.visit_ImportFrom(node)
    assert node.module == "a"


# Generated at 2022-06-25 21:58:38.273470
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert (True,True)



# Generated at 2022-06-25 21:58:38.800683
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass



# Generated at 2022-06-25 21:58:49.181313
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('import ast')
    BaseImportRewrite.rewrites = [('ast', 'typed_ast')]
    BaseImportRewrite.transform(tree)
    assert ast.dump(tree) == 'try:\n    import typed_ast\nexcept ImportError:\n    import ast\n'

    tree = ast.parse('import ast as a')
    BaseImportRewrite.transform(tree)
    assert ast.dump(tree) == 'try:\n    import typed_ast as a\nexcept ImportError:\n    import ast as a\n'
    
    tree = ast.parse('from ast import parse')
    BaseImportRewrite.transform(tree)
    assert ast.dump(tree) == 'try:\n    from typed_ast import parse\nexcept ImportError:\n    from ast import parse\n'

    tree

# Generated at 2022-06-25 21:58:58.308487
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.parse('from foo.bar import bar, baz')
    import_from = node.body[0]

    assert(isinstance(import_from, ast.ImportFrom))
    assert(len(import_from.names) == 2)

    # No rewrite
    transformer = BaseImportRewrite()
    transformer.rewrites = []
    result = transformer.visit_ImportFrom(import_from)

    assert(result == import_from)

    # Match module
    transformer.rewrites = [('foo.bar', 'foo.foo')]
    result = transformer.visit_ImportFrom(import_from)

    assert(isinstance(result, ast.Try))
    assert(len(result.body) == 1)
    assert(len(result.body[0].names) == 2)

# Generated at 2022-06-25 21:59:09.085862
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = ast.Import()
    try_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:59:13.807332
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:59:22.366359
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Check class exists
    if not hasattr(BaseImportRewrite, "visit_Import"):
        raise Exception("Class BaseImportRewrite does not implement method visit_Import")

    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_1 = module_0.Import([module_0.alias(name="sys", asname="s")])
    var_0 = base_import_rewrite_0.visit_Import(import_1)
    import_1_changed = True
    if var_0 != import_1:
        import_1_changed = False


# Generated at 2022-06-25 21:59:28.352131
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import_1 = module_0.Import()
base_import_rewrite_1 = BaseImportRewrite(import_1)
var_1 = base_import_rewrite_1.visit_Import(import_1)


# Generated at 2022-06-25 21:59:32.185421
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 21:59:36.693401
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = ast.Import()
    base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast27 as module_1


# Generated at 2022-06-25 21:59:44.723288
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Arrange
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()

    # Act
    var_0 = base_import_rewrite_0.visit_Import(import_0)

    # Assert
    try:
        assert type(var_0) == module_0.Import
        assert var_0.names is None
    except AssertionError:
        raise AssertionError()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:59:50.800022
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Test with source code: 
    import_2 = module_0.Import(names=[
        module_0.alias(name='foo',
        asname=None)])
    target = CompilationTarget('python', 'default')
    target.add_dependency('foo', 'bar')
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_2)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:59:54.276816
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_1 = module_0.Import()
    assert base_import_rewrite_0.visit_Import(import_1) == import_1
    import_2 = module_0.Import()
    base_import_rewrite_0.rewrites = [("foo", "bar")]
    var_0 = base_import_rewrite_0.visit_Import(import_2)
    try_1 = module_0.Try()
    assert var_0 == try_1
    import_3 = module_0.Import()
    try_2 = module_0.Try()
    assert var_0 == try_2

# Generated at 2022-06-25 22:00:01.964446
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    
    # Call method on object
    result = base_import_rewrite_0.visit_Import(import_0)
    assert isinstance(result, module_0.Import)


import_from_0 = module_0.ImportFrom(module='string', names=[], level=0) # type: module_0.ImportFrom


# Generated at 2022-06-25 22:00:16.494800
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


if __name__ == '__main__':
    test_case_0()
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:00:20.599025
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:25.369825
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert var_0.__class__ == module_0.Import


# Generated at 2022-06-25 22:00:28.932491
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:00:33.273209
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    print(var_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:00:37.527038
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Case 0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:00:45.387344
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    alias_0 = import_0.names[0]
    var_0 = alias_0.name
    var_1 = base_import_rewrite_0._get_matched_rewrite(var_0)
    var_2 = base_import_rewrite_0.visit_Import(import_0)
    var_3 = base_import_rewrite_0.target
    class_0 = base_import_rewrite_0.target


# Generated at 2022-06-25 22:00:49.866393
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_2 = module_0.AST()
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    var_0 = base_import_rewrite_2.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:54.746709
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom(level=0, names=[module_0.alias(asname='', name='x')], module='')
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:57.334505
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert var_0 == import_0


# Generated at 2022-06-25 22:01:25.810435
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.ImportFrom()
    var_1 = base_import_rewrite_0.visit_ImportFrom(import_0)


# Generated at 2022-06-25 22:01:29.941744
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:01:34.742691
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:46.213077
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = ast.ImportFrom()
    alias_0 = ast.alias()
    alias_0.name = ""
    list_0 = [alias_0]
    import_from_0.names = list_0
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    module_0 = ast.ImportFrom()
    module_0.names = list_0
    module_0.level = 0
    alias_1 = ast.alias()
    alias_1.name = ""
    list_1 = [alias_1]
    module_0.names = list_1
    var_1 = base

# Generated at 2022-06-25 22:01:50.242031
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = ast.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:01:53.557071
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:02:01.461435
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = ast.ImportFrom('abc', [ast.alias('foo', 'bar')], 0)
    var_2 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    print(var_2)

# Generated at 2022-06-25 22:02:05.375761
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:02:09.617302
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:02:15.527443
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(level=0)
    # Try-except statements are currently not supported
    try:
        base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
        var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 22:02:43.107100
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:02:46.017046
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:02:53.056804
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    import_0.names.append(module_0.alias(None, None))
    import_0.names[0].name = 'string_0'
    import_0.names[0].asname = None
    # Exercise
    base_import_rewrite_0._tree_changed = False
    base_import_rewrite_0._get_matched_rewrite = lambda a_1: None
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert base_import_rewrite_0._tree_changed == False

# Generated at 2022-06-25 22:02:58.933224
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom("a", [module_0.alias("b", "c")], 0)
    base_import_rewrite_0 = BaseImportRewrite("")

    def _test(base_import_rewrite_0, import_from_0, expected_0):
        actual_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
        assert actual_0 == expected_0

    _test(base_import_rewrite_0, import_from_0, import_from_0)


# Generated at 2022-06-25 22:03:06.515055
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # default case
    # import ast
    import_from_0 = ast.ImportFrom(level=0, module='ast', names=[
        ast.alias(name='Name')])

    # import ast
    import_from_1 = ast.ImportFrom(level=0, module='ast', names=[
        ast.alias(name='Name')])

    assert import_from_0 == import_from_1

    # default case
    # import typing
    import_from_2 = ast.ImportFrom(level=0, module='typing', names=[
        ast.alias(name='List')])
    import_from_3 = ast.ImportFrom(level=0, module='typing', names=[
        ast.alias(name='List')])

# Generated at 2022-06-25 22:03:09.100515
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    import_from_0 = module_0.ImportFrom()
    var_1 = base_import_rewrite_1.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:03:13.172674
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:20.188040
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:03:23.638221
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='pandas')
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:03:24.311813
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


import unittest


# Generated at 2022-06-25 22:04:13.021620
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module="", names=[])
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:04:16.709723
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    try_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:04:24.326467
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('a', 'b'), ('c', 'd')]
    import_from_0 = module_0.ImportFrom()
    import_from_0.level = 0
    import_from_0.module = 'a'
    name_0 = module_0.alias()
    name_0.asname = 'AS'
    name_0.name = 'NAME'
    import_from_0.names = [name_0]
    import_from_1 = module_0.ImportFrom()
    import_from_1.level = 0
    import_from_1.module = 'c'
    import_

# Generated at 2022-06-25 22:04:26.482505
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
#     test_BaseImportRewrite_visit_Import_case_0()
    pass


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:04:33.274508
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Create an instance of BaseImportRewrite to test
    base_import_rewrite_0 = BaseImportRewrite(None)
    # Create a node to test it
    import_from_0 = module_0.ImportFrom(
        level=0,
        module='foo',
        names=[
            module_0.alias(
                name='x',
                asname=None
            )
        ]
    )
    # Call the visit method under test
    try_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    # Test that the state of the class is as expected after calling the method
    assert_true(base_import_rewrite_0._tree_changed)
    assert_is_instance(try_0, module_0.Try)


# Generated at 2022-06-25 22:04:38.542878
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    import_1 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_1)
    var_1 = base_import_rewrite_0.visit_Import(import_0)

if __name__ == '__main__':
    test_case_0()
    test_BaseImportRewrite_visit_Import()

# Generated at 2022-06-25 22:04:43.151494
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """
    test method BaseImportRewrite.visit_Import
    """
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert var_0 == None, "Wrong value of var_0, expected None, got " + str(var_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:04:45.977227
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = ast.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:48.382679
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Initialization
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0 = BaseImportRewrite()
    # Run method
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:04:51.742894
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = ast.Import()
    var_0 = base_import_rewrite_0.visit_Import(import_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:06:25.672971
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    module_0.logging.basicConfig()
    module_0.logging.getLogger().setLevel(module_0.logging.DEBUG)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)