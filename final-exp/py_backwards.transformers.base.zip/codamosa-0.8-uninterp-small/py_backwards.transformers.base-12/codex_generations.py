

# Generated at 2022-06-25 21:56:40.128352
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-25 21:56:47.228230
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('import module')
    base_import_rewrite_0 = BaseImportRewrite()
    base_import_rewrite_1 = BaseImportRewrite([('module', 're.module')])
    base_import_rewrite_2 = BaseImportRewrite([('rewrite', 're.rewrite')])
    base_import_rewrite_0.visit(tree)
    base_import_rewrite_1.visit(tree)
    base_import_rewrite_2.visit(tree)


# Generated at 2022-06-25 21:56:54.543322
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    node_0 = ast.Import(names=[ast.alias(name='typing', asname=None)])
    ast.copy_location(node_0, None)
    ast.fix_missing_locations(node_0)

    node_0 = base_import_rewrite_0._replace_import(node_0, 're', 're')
    assert str(node_0) == "try:\n    import typing\nexcept ImportError:\n    import re"


# Generated at 2022-06-25 21:57:01.295770
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class _Transformer(BaseImportRewrite):
        rewrites = [('time', 'time_1')]
    tree = ast.parse('import time')
    expected = ast.parse('try:\n    import time_1 as time\nexcept ImportError:\n    import time')
    assert ast.dump(_Transformer.transform(tree).tree) == ast.dump(expected)



# Generated at 2022-06-25 21:57:05.226610
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    class BaseImportRewriteImpl1(BaseImportRewrite):
        rewrites = [('')]

    base_import_rewrite_impl1 = BaseImportRewriteImpl1()

    class BaseImportRewriteImpl2(BaseImportRewrite):
        rewrites = []

    base_import_rewrite_impl2 = BaseImportRewriteImpl2()


# Generated at 2022-06-25 21:57:13.131110
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    with open('tests/resources/import_rewrite/rewrite_0.py', 'r') as f:
        tree = ast.parse(f.read())
        node = tree.body[0]
        actual_0 = base_import_rewrite_0.visit_Import(node)
        with open('tests/resources/import_rewrite/rewrite_0_actual.py', 'r') as fa:
            expected_0 = ast.parse(fa.read())
            assert ast.dump(actual_0) == ast.dump(expected_0)



# Generated at 2022-06-25 21:57:22.020564
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astunparse
    import ast
    import collections
    import six.moves.queue as queue

    class BaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [('six.moves.queue', 'queue')]

        def visit_Import(self, node):
            rewrite = self._get_matched_rewrite(node.names[0].name)
            if rewrite:
                return self._replace_import(node, *rewrite)

            return self.generic_visit(node)


    def assert_repr(actual, expected):
        assert astunparse.dump(actual) == astunparse.dump(expected)


    base_import_rewrite_0 = BaseImportRewrite_visit_Import()

# Generated at 2022-06-25 21:57:26.174085
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    ast_tree = ast.parse("""
import re
""")
    class TestBaseImportRewrite(BaseImportRewrite):
        dependencies = []
        rewrites = []
    result = TestBaseImportRewrite.transform(ast_tree)
    assert result == (ast.parse("""
import re
"""), False, [])



# Generated at 2022-06-25 21:57:33.629923
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite.__new__(BaseImportRewrite)
    node = ast.parse('import abc\n').body[0] # type: ast.Import
    base_import_rewrite_0.rewrites = [('abc', 'xyz')]
    try:
        ast.copy_location(base_import_rewrite_0.visit_Import(node), node)
    except (AssertionError, AttributeError, ImportError, IndexError, KeyError, NameError, NotImplementedError, RuntimeError, SyntaxError, TypeError, ValueError, ):
        pass


# Generated at 2022-06-25 21:57:43.086793
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Test with import {from}
    def test_case_1_1():
        base_import_rewrite_1 = BaseImportRewrite(None)
        base_import_rewrite_1.rewrites = [('from', 'to')]
        base_import_rewrite_1._get_matched_rewrite = lambda x: ('from', 'to')
        base_import_rewrite_1._replace_import = lambda x, y, z: x

        ast_import_1 = ast.Import(names=[ast.alias(name='from.mod', asname='mod')])
        result = base_import_rewrite_1.visit_Import(ast_import_1)
        expected = ast_import_1
        assert result == expected

    test_case_1_1()

    # Test with import {from}.{name

# Generated at 2022-06-25 21:58:00.366903
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from monty.tempfile import ScratchDir
    import pytest
    import re
    import sys

    class TestCase:
        class MockImport:
            def __init__(self, name, alias):
                self.name = name
                self.alias = alias

        def __init__(self, node, expected):
            self.node = node
            self.expected = expected

    def check(test_case):
        class MockBaseImportRewrite(BaseImportRewrite):
            rewrites = [(test_case.MockImport, test_case.MockImport)]

        result = MockBaseImportRewrite.transform(test_case.node)
        assert result == test_case.expected


# Generated at 2022-06-25 21:58:05.285369
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('from bar import baz')
    BaseImportRewrite.rewrites = [('bar', 'baz')]
    tree_changed, rewroted_tree = BaseImportRewrite.transform(tree)
    assert tree_changed
    assert ast.dump(rewroted_tree) == "Try(body=[Import(names=[alias(name='bar', asname='baz')])], orelse=[], finalbody=[])"



# Generated at 2022-06-25 21:58:14.282289
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 21:58:23.570967
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_node_0 = ast.parse('import json')
    base_import_rewrite_0 = BaseImportRewrite()
    res_0 = base_import_rewrite_0.visit(import_node_0)
    assert isinstance(res_0, ast.Import), "test #0: expected type: 'ast.Import', got: {}".format(type(res_0))
    assert res_0.lineno == 1, "test #0: expected: '1', got: {}".format(res_0.lineno)
    assert res_0.col_offset == 0, "test #0: expected: '0', got: {}".format(res_0.col_offset)

# Generated at 2022-06-25 21:58:32.895385
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Let's create names of what we want to import as:
    import_names = [ast.alias(name='urllib.request', asname='urllib_request'),
                    ast.alias(name='urllib.error', asname='urllib_error')]

    # Let's create imports from what we want to import:
    import_froms = [ast.ImportFrom(module='urllib',
                                  names=import_names,
                                  level=0)]

    # Let's create full tree
    tree = ast.Module(body=[ast.Import(names=import_names),
                            import_froms[0]])

    # Let's create instance of transformer
    transformer = BaseImportRewrite(tree=tree)

    # Let's check that it works

# Generated at 2022-06-25 21:58:33.906729
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert BaseImportRewrite.visit_Import("node", "from_", "to") == None


# Generated at 2022-06-25 21:58:39.201257
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_nodetransformer_0 = BaseImportRewrite()
    ast.parse("import foo")
    ast.Import(['foo'])
    ast.Import(['foo'])
    ast.Import(['foo'])
    ast.Import(['foo'])
    base_nodetransformer_0.visit(ast.Import(['foo']))
    base_nodetransformer_0.visit(ast.Import(['foo']))


# Generated at 2022-06-25 21:58:42.531302
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    import_0 = ast.Import(names=[ast.alias(name='typing', asname='typing')])
    base_import_rewrite_0.visit_Import(node=import_0)


# Generated at 2022-06-25 21:58:53.198308
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..examples.snippets.import_rewrite import a, b, c, import_rewrite_0, import_rewrite_1, import_rewrite_2

    importer = BaseImportRewrite([a, c])

    # case 0
    import_rewrite_0

    # case 1
    importer.rewrites.append(('typing', 'mypy_extensions'))
    import_rewrite_1

    # case 2
    importer.rewrites.append(('mypy_extensions', 'mypy.typeshed.mypy_extensions'))
    import_rewrite_2



# Generated at 2022-06-25 21:58:57.123453
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Import with rewrite
    tree_0_0 = ast.parse('import six')  # type: ast.Module
    tree_0_1 = ast.parse('import future')  # type: ast.Module
    tree_0_2 = ast.parse('import six')  # type: ast.Module
    inst_0_0 = BaseImportRewrite(tree_0_0)
    inst_0_1 = BaseImportRewrite(tree_0_1)
    inst_0_2 = BaseImportRewrite(tree_0_2)

    inst_0_0.rewrites = [('six', 'future')]
    inst_0_1.rewrites = [('six', 'future')]
    inst_0_2.rewrites = []


# Generated at 2022-06-25 21:59:09.912584
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:14.678356
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:19.581983
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:24.548248
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:30.027959
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = typed_ast._ast3.ImportFrom(*list_1)
    a_s_t_0 = typed_ast._ast3.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

import abc as module_1


# Generated at 2022-06-25 21:59:34.921810
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)



# Generated at 2022-06-25 21:59:40.673851
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:46.306476
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:50.751225
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # test effective code
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:55.621631
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = [None]
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:10.954518
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    tmp_0 = module_0.alias()
    list_0 = [tmp_0]
    import_0 = module_0.Import(list_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:15.140687
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:18.938469
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:23.683440
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:25.937778
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:00:29.895783
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:33.853808
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = []
    import_0 = module_0.Import(*list_0)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:39.623066
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:44.128350
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:49.212950
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_1 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:17.594805
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_2 = None
    list_3 = [list_2]
    import_0 = module_0.Import(*list_3)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    var_1 = base_import_rewrite_1.visit_Import(import_0)


# Generated at 2022-06-25 22:01:26.249632
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:29.779703
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = None
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:35.591544
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:41.365231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

if __name__ == '__main__':
    test_case_0()
    test_BaseImportRewrite_visit_Import()

# Generated at 2022-06-25 22:01:45.023869
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-25 22:01:47.570166
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    expected_0 = None
    actual_0 = None
    assert expected_0 == actual_0

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:01:52.664908
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_18 = None
    list_19 = ['x']
    import_from_1 = module_0.ImportFrom(*list_19)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    var_1 = base_import_rewrite_1.visit_ImportFrom(import_from_1)


# Generated at 2022-06-25 22:01:56.723663
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0 = BaseImportRewrite
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 22:02:03.043278
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = []
    import_0 = module_0.Import(*list_0)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:02:33.815408
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..ast_transformer_test_case import ASTTransformerTestCase
    import ast
    import sys
    import os
    import pathlib
    import tempfile
    import shutil
    test_dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(test_dir_path)
    temp_dir_path = os.path.join(test_dir_path, 'temp')
    os.makedirs(temp_dir_path, exist_ok=True)
    os.chdir(temp_dir_path)
    shutil.copyfile(os.path.join(test_dir_path, 'typed_ast', '__init__.py'), os.path.join(temp_dir_path, 'typed_ast', '__init__.py'))

# Generated at 2022-06-25 22:02:37.723859
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Before
    a = b = c = None
    # After
    try:
        if a:
            pass
        if b:
            pass
        if c:
            pass
    except:
        pass


# Generated at 2022-06-25 22:02:41.337940
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

# Generated at 2022-06-25 22:02:47.747954
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Create a fake AST and initialize a BaseImportRewrite with it.
    class AST:
        pass
    a_s_t = AST()
    base_import_rewrite = BaseImportRewrite(a_s_t)
    # Create a fake ImportFrom.
    import_from = AST()
    import_from.names = []
    import_from_0 = a_s_t.alias()
    import_from.names.append(import_from_0)
    import_from_0.name = 'collections.abc'
    import_from_0.asname = None
    import_from.module = None
    import_from.level = None
    # Run the method
    import_from = base_import_rewrite.visit_ImportFrom(import_from)
    # Check that the output is as expected.


# Generated at 2022-06-25 22:02:48.613120
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Test with node of class Import
    test_case_0()


# Generated at 2022-06-25 22:02:52.986354
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:02:58.136722
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert var_0 == None


# Generated at 2022-06-25 22:03:03.073787
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

if __name__ == '__main__' and __package__ is None:
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:03:07.946176
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(var_0, module_0.Try)

# Generated at 2022-06-25 22:03:11.545056
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:42.270663
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

    assert isinstance(var_0, module_0.Try)

import typing as module_1


# Generated at 2022-06-25 22:03:46.637793
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:03:49.680731
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    try:
        test_case_0()
    except Exception:
        import traceback
        print(traceback.format_exc())
print('')



# Generated at 2022-06-25 22:03:53.534582
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:58.203820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Initialization for test suite

# Generated at 2022-06-25 22:04:02.211210
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    from typed_ast import ast3 as ast
    module_0 = ast.Module()

    # Assert 'module_0' can be visited.
    assert_equal(True, True)

    # Assert 'module_0' can be visited.
    assert_equal(True, True)


# Generated at 2022-06-25 22:04:05.652677
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = []
    # Note that this list should be set to rewrites or it will be an empty list
    # which is not the rewrites list.
    cls = BaseImportRewrite(None, rewrites=rewrites)
    # Checking to see if it returns none
    assert cls.visit_Import(None) is None


# Generated at 2022-06-25 22:04:10.875850
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:19.498673
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias("an_alias", "alias_asname")
    alias_1 = module_0.alias("*")
    alias_2 = module_0.alias("*", "*")
    list_0 = ["an_alias", "*", "*"]
    list_1 = [alias_0, alias_1, alias_2]
    list_2 = [list_1]
    import_0 = module_0.Import(list_2)

    # Assert

# Generated at 2022-06-25 22:04:23.675319
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:53.152890
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:05:00.903038
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    str_0 = 'abc'
    list_2 = [str_0]
    import_0 = module_0.Import(*list_2)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:05:04.736702
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert var_0 == import_from_0


# Generated at 2022-06-25 22:05:10.985767
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Create test objects
    list_1 = [None]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Call function
    var_0 = base_import_rewrite_0.visit_Import(import_0)



# Generated at 2022-06-25 22:05:17.555194
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    list_0 = None
    list_1 = [list_0]
    import_from_0 = module_0.ImportFrom(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:05:23.518638
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    var_0 = None
    var_1 = tuple()
    var_2 = tuple()
    base_import_rewrite_0 = BaseImportRewrite(var_0)
    import_0 = module_0.Import(var_1, var_2)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:05:30.485472
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # setup
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # exercise
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    # verify
    try:
        var_0.visit_ImportFrom
    except AttributeError:
        raise AssertionError("var_0 should have had attribute visit_ImportFrom")
  

# Generated at 2022-06-25 22:05:38.695695
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_2 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_2)
    
    # Unit test for method visit_ImportFrom of class BaseImportRewrite
    def test_BaseImportRewrite_visit_ImportFrom():
        list_0 = None
        list_1 = [list_0]
        import_from_0 = module_0.ImportFrom(*list_1)
        a_s_t_0 = module_0.AST()
        base_import_rewrite_0 = BaseImportRew

# Generated at 2022-06-25 22:05:41.722071
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:05:46.165090
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    list_0 = None
    list_1 = [list_0]
    import_0 = module_0.Import(*list_1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        base_import_rewrite_0.visit_Import(import_0)
    except ImportError:
        print("ImportError")
