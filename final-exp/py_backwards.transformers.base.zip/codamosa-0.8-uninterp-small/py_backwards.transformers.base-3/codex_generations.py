

# Generated at 2022-06-25 21:56:50.971122
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    base_import_rewrite_0 = BaseImportRewrite()
    # try:
    #     import ast
    # except ImportError:
    #     import ast as ast
    node = ast.parse('import ast\n')
    node.body[0].names[0].name = "ast"
    node.body[0].names[0].asname = ""
    node.body[0].col_offset = 0
    node.body[0].end_col_offset = 10
    node.body[0].end_lineno = 1
    node.body[0].lineno = 1
    node.body[0].type_ignores = []
    print_ = ast.Print()
    print_.dest = node
    print_.nl = True
    print_.values = [node]
    base_import_rewrite_0.vis

# Generated at 2022-06-25 21:56:51.862905
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-25 21:56:59.224510
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import(names = [ast.alias(name = "abc", asname = "abc")])
    import_to_0 = ast.Import(names = [ast.alias(name = "xyz", asname = "xyz")])

    import_rewrite_0 = BaseImportRewrite([(("abc") , ("xyz"))])
    import_rewrite_0._tree = import_to_0
    import_rewrite_0._tree_changed = False
    if import_0 != None:
        pass
    import_rewrite_0.visit(import_0)
    assert import_rewrite_0._tree == None
    assert import_rewrite_0._tree_changed == True



# Generated at 2022-06-25 21:57:08.537862
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class test_transformer(BaseImportRewrite):
        rewrites = [('abc', 'abc.def')]

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            inst = cls(tree)
            inst.visit(tree)
            return TransformationResult(tree, inst._tree_changed, cls.dependencies)

    module_0 = ast.parse('import abc')
    module_1 = ast.parse('import abc.def')
    assert test_transformer.transform(module_0).tree == module_1

    module_2 = ast.parse('import abc.def.ghi')
    assert test_transformer.transform(module_2).tree == module_2

    module_3 = ast.parse('import abc.def as a')
    assert test_

# Generated at 2022-06-25 21:57:16.923890
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class BaseImportRewrite_visit_ImportFrom(BaseImportRewrite):
        rewrites = [('a', 'b'), ('c', 'd')]
    inp_code = """\
from a import test
import c
from a import test2 as test3
from c import *
"""
    out_code = """\
try:
    from a import test
except ImportError:
    from b import test

import c
try:
    from a import test2 as test3
except ImportError:
    from b import test2 as test3

try:
    from c import *
except ImportError:
    from d import *
"""
    BaseImportRewrite_visit_ImportFrom(inp_code).transform(inp_code)
    assert inp_code == out_code

# Generated at 2022-06-25 21:57:25.929107
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import(names=[
                ast.alias(name='os', asname=None)])

    tree_0 = ast.parse("import os\n"
                       "from sys import os as sys_os")
    tree_1 = ast.parse("from sys import os as sys_os")

    base_import_rewrite_0 = BaseImportRewrite(tree_0)
    base_import_rewrite_0.rewrites.append(('os', 'os2'))
    base_import_rewrite_0.visit_Import(import_0)

    base_import_rewrite_1 = BaseImportRewrite(tree_1)
    base_import_rewrite_1.rewrites.append(('os', 'os2'))

# Generated at 2022-06-25 21:57:33.712782
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from = ast.ImportFrom(module='asyncore', names=[ast.alias(name='loop', asname='loop')], level=0)
    import_rewrite_0 = BaseImportRewrite()
    import_rewrite_0.visit_ImportFrom(import_from)
    expected = import_rewrite.get_body(previous=import_from, current=[ast.ImportFrom(module='asynchat',
                                                                                     names=[ast.alias(name='loop',
                                                                                                      asname='loop')],
                                                                                     level=0)])[0]
    assert import_rewrite_0.tree == expected



# Generated at 2022-06-25 21:57:34.245322
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

# Generated at 2022-06-25 21:57:42.658530
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()

    @snippet
    def test(node, from_, to):
        base_import_rewrite_0._replace_import(node, from_, to)

    node = ast.parse('import previous.name as name').body[0]  # type: ignore

    test(node, 'previous', 'next')
    assert ast.dump(node) == 'Try\n' \
                             '  Import(names=[alias(name="next.name", asname="name")])\n' \
                             '  except ImportError: Import(names=[alias(name="previous.name", asname="name")])\n'


# Generated at 2022-06-25 21:57:48.138411
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class test_BaseImportRewrite(BaseImportRewrite):
        rewrites = [('abc', 'new')]
    tree = ast.parse("import abc.c", "<test>", "exec")
    test_BaseImportRewrite().visit(tree)
    assert ast.dump(tree) == ast.dump(
        ast.parse("try:\n    import abc.c\nexcept ImportError:\n    import new.c", "<test>", "exec"))


# Generated at 2022-06-25 21:58:01.448483
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    n_0 = module_0.ImportFrom()
    try:
        base_import_rewrite_0.visit_ImportFrom(n_0)
    except Exception as e:
        e_0 = e
        return
    assert 0 == 1, "Exception was not thrown"

import abc as module_0


# Generated at 2022-06-25 21:58:06.067765
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Raises exception when used with unsupported ast.AST
    try:
        a_s_t_0 = module_0.AST()
        base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
        base_import_rewrite_0.visit_Import(a_s_t_0)
        assert False # expected exception
    except TypeError as e:
        pass


# Generated at 2022-06-25 21:58:12.526286
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_1 = module_0.alias(name='name_2', asname='asname_2')
    import_1 = module_0.Import(names=[import_1])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        result_0 = base_import_rewrite_0.visit_Import(import_1)
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 21:58:15.698715
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert hasattr(base_import_rewrite_0, '_get_matched_rewrite')


# Generated at 2022-06-25 21:58:25.054300
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import random
    import typing
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.Import()

# Generated at 2022-06-25 21:58:30.696578
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    a_s_t_1 = module_0.Import(names=[module_0.alias(name="typing",
                                                    asname=None)])
    base_import_rewrite_0.visit(a_s_t_1)



# Generated at 2022-06-25 21:58:38.153032
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    a_s_t_0 = module_0.Import(names=(
        (
        module_0.alias(name='email.utils', asname=None),)))

    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = (
        (
        'email.utils', 'email_utils'),)
    a_s_t_1 = base_import_rewrite_0.visit_Import(a_s_t_0)

    assert type(a_s_t_1) is module_0.Try

    import_rewrite_0 = module_0.Import(names=(
        (
        module_0.alias(name='email_utils', asname=None),)))


# Generated at 2022-06-25 21:58:43.190060
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    names_0 = [None]
    a_s_t_0 = module_0.Import(names_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Testing for expected value
    assert base_import_rewrite_0.visit_Import(a_s_t_0) == module_0.Import(names_0)


# Generated at 2022-06-25 21:58:55.129021
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST(body=[module_0.ImportFrom(module="a", names=["b"])], type_ignores=[])
    base_import_rewrite_0.rewrites = [("a", "b")]
    module_1 = base_import_rewrite_0.visit(module_0.Module(body=[module_0.ImportFrom(module="a", names=["b"])], type_ignores=[]))
    assert isinstance(module_1, module_0.Module)

# Generated at 2022-06-25 21:59:04.571929
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(name="bar", asname="bar")
    import_from_0 = module_0.ImportFrom(module="foo", names=[alias_0], level=0)
    import_from_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(import_from_1, module_0.Try)
    assert not hasattr(import_from_1, "body")
    assert hasattr(import_from_1, "orelse")
    assert len(import_from_1.orelse) == 1

# Generated at 2022-06-25 21:59:15.860806
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import()
    base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 21:59:22.965137
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(name='import_from_me', asname='asname_0')
    import_0 = module_0.Import(names=[alias_0])
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_1.rewrites = [('from_me', 'to_you')]
    base_import_rewrite_1.visit_Import(import_0)


# Generated at 2022-06-25 21:59:27.211921
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    i_0 = module_0.Import()
    b_0 = base_import_rewrite_0.visit_Import(i_0)


# Generated at 2022-06-25 21:59:33.473824
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    base_import_rewrite_0 = BaseImportRewrite(TEST)
    a_s_t_0 = ast.AST()
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(
        module='typed_ast._ast3',
        names=[module_0.alias(
            name='alias',
            asname=None)],
        level=0)
    base_import_rewrite_0.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)

# Generated at 2022-06-25 21:59:39.852733
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.ImportFrom(module='', names=[], level=0).parent = a_s_t_0
    actual = base_import_rewrite_0.visit_ImportFrom(module_0.ImportFrom(module='', names=[], level=0))
    assert actual == None


# Generated at 2022-06-25 21:59:46.463787
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.Import()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0.names = [module_0.alias()]
    base_import_rewrite_0.rewrites = [('lib', 'newlib')]
    try:
        base_import_rewrite_0.visit_Import(a_s_t_0)
    except Exception:
        pass

# Generated at 2022-06-25 21:59:50.005764
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(module_0.alias())
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:59.420232
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0.rewrites.append((str, str))
    import_from_0.names.append(alias_0)
    import_from_0.names.append(alias_1)
    alias_0.name = "six"
    alias_0.asname = "seven"
    alias_1.name = "eight"
    alias_1.asname = "seven"
    alias_2 = module_0.alias()
    import_from_0.names.append(alias_2)
    alias_2.name = "nine"
    alias_2.asname

# Generated at 2022-06-25 22:00:00.262302
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # TODO
    pass

# Generated at 2022-06-25 22:00:05.255344
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Should be called from class BaseImportRewrite or its derived classes.
    # Not calling this method can lead to unexpected results.
    base_import_rewrite_0.visit_Import(module_0.Import())


# Generated at 2022-06-25 22:00:33.678231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Initialization
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(str(str()), str(str()))]
    # Method call to test
    base_import_rewrite_0.visit_Import(module_0.Import(names=[module_0.alias(name=str(str()),asname=str(str()))]))
    # Check result
    assert type(base_import_rewrite_0._get_matched_rewrite(str(str()))) == tuple

# Generated at 2022-06-25 22:00:41.053102
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0.body = [ast.Import(names=[ast.alias(name="pyramid")])]
    a_s_t_1 = base_import_rewrite_0.visit(a_s_t_0)
    assert a_s_t_1.body[0] == ast.Try(body=[ast.Import(names=[ast.alias(name="pyramid")])], orelse=[],
                                      handlers=[], finalbody=[])


# Generated at 2022-06-25 22:00:49.065378
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # initialization
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # parameters
    import_from_0 = module_0.ImportFrom(module="foo", names=[ast.alias(name="bar", asname="foo"), ast.alias(name="baz", asname="bar")], level=1)

    # execution
    result = base_import_rewrite_0.visit_ImportFrom(import_from_0)

    # assertion
    assert result == import_from_0


# Generated at 2022-06-25 22:00:53.487097
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    alias_0 = module_0.alias()

    import_0 = module_0.Import()
    import_0.names = [alias_0]
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:59.926679
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Check that the type of the visitor matches the type of the node
    a_s_t_1 = module_0.Import(names=[module_0.alias(name='x', asname=None)])
    a_s_t_2 = base_import_rewrite_0.visit(a_s_t_1)
    assert isinstance(a_s_t_2, module_0.Import)


# Generated at 2022-06-25 22:01:09.162142
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast
    import typed_ast.ast3
    a_s_t_0 = typed_ast.ast3.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    type_0 = type(typed_ast)
    test_case_0_storage_0 = type_0()
    test_case_0_storage_1 = type_0()
    test_case_0_storage_2 = type_0()
    test_case_0_storage_3 = type_0()
    test_case_0_storage_4 = type_0()
    test_case_0_storage_5 = type_0()
    a_s_t_1 = typed_ast.ast3.AST()
    test_case_0_storage_6 = a_

# Generated at 2022-06-25 22:01:14.345331
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0 = module_0.ImportFrom(a_s_t_0, a_s_t_0, a_s_t_0, a_s_t_0)
    visit_ImportFrom_return_1 = base_import_rewrite_0.visit_ImportFrom(a_s_t_0)

# Generated at 2022-06-25 22:01:27.170544
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_2
    import typed_ast._ast3 as module_3
    import typed_ast._ast3 as module_4
    import typed_ast._ast3 as module_5
    import typed_ast._ast3 as module_6
    import typed_ast._ast3 as module_7
    import typed_ast._ast3 as module_8
    import typed_ast._ast3 as module_9
    import typed_ast._ast3 as module_10
    import typed_ast._ast3 as module_11
    import typed_ast._ast3 as module_12
    import typed_ast._ast3 as module_13
    import typed_ast._ast3 as module_14
    import typed_

# Generated at 2022-06-25 22:01:33.780101
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_0 = module_0.Import(names=a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:37.879672
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    import_from_1 = base_import_rewrite_0.visit_Import(import_from_0)


# Generated at 2022-06-25 22:02:01.178993
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:02:09.787907
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name='a', asname='a')
    a_s_t_1 = module_0.AST()
    try_0 = ast.Try(body=[], handlers=[], orelse=[], finalbody=[])
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    import_rewrite_0._replace_import(node=a_s_t_3, from_='a', to='b')

# Generated at 2022-06-25 22:02:18.363748
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    a_s_t_1 = ast.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    module_1 = 'some_module'
    names_1 = []
    level_1 = 0
    node_1 = ast.ImportFrom(module=module_1, names=names_1, level=level_1)
    rewrites_1 = [('old', 'new')]
    base_import_rewrite_1.rewrites = rewrites_1

# Generated at 2022-06-25 22:02:26.327948
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # No docstring expected for this test.
    import unittest
    import sys
    from typed_ast import ast3 as ast
    from .context import typer_context
    from . import TyperTestCase

    class TestBaseImportRewriteVisitImport(TyperTestCase):
        def test_case_0(self):
            test_case = self
            class Test(BaseImportRewrite):
                def __init__(self, tree):
                    super().__init__(tree)
                rewrites = [
                    (
                        "os",
                        "posix",)
                ]
                def visit_Import(self, node):
                    test_case.assertEqual(type(node), ast.Import)
                    return super().visit_Import(node)
            a_s_t_0 = ast.AST()

# Generated at 2022-06-25 22:02:29.242791
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    custom_visitor_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 22:02:29.960472
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # No asserts.
    pass


# Generated at 2022-06-25 22:02:38.539386
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    class CustomAST(ast.AST):
        pass

    a_s_t_0 = CustomAST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    base_import_rewrite_0.rewrites = [('a', 'b')]

    module = ast.parse('import a')
    node = module.body[0]

    import_from = base_import_rewrite_0.visit(node)
    assert isinstance(import_from, ast.Try)
    assert import_from.body[0] == node
    assert import_from.body[1].names[0].name == 'b'
    assert import_from.body[1].names[0].asname == node.names[0].asname

# Generated at 2022-06-25 22:02:41.308322
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Call method visit_Import
    base_import_rewrite_0.visit_Import(a_s_t_0)



# Generated at 2022-06-25 22:02:43.221538
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # test case 0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:02:46.836093
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.ImportFrom(module='module', names=[module_0.alias(name='name', asname=None)], level=None)
    base_import_rewrite_0.visit_ImportFrom(module_1)


# Generated at 2022-06-25 22:03:35.561546
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_py_code_0 = """
        import typing
    """

    tree_0 = ast.parse(test_py_code_0)

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit(tree_0)


# Generated at 2022-06-25 22:03:41.886528
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    a_s_t_0.body.append(import_0)
    base_import_rewrite_0._tree = a_s_t_0
    result_0 = base_import_rewrite_0.visit_Import(import_0)
    assert isinstance(result_0, module_0.Try) == True


# Generated at 2022-06-25 22:03:45.744610
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    code = "import urllib.parse"
    tree = ast.parse(code)
    node = tree.body[0]
    assert isinstance(node, ast.Import)
    base_import_rewrite_0 = BaseImportRewrite(tree)
    actual_node = base_import_rewrite_0.visit_Import(node)
    assert isinstance(actual_node, ast.Try)


# Generated at 2022-06-25 22:03:48.465093
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert base_import_rewrite_0._tree_changed is False


# Generated at 2022-06-25 22:03:56.007598
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Comments:
    # N/A
    # Inputs:
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = ast.ImportFrom(module=None, level=None)
    # Output:
    # AST.ImportFrom(
    #   module=None,
    #   names=[],
    #   level=None
    # )
    ast.copy_location(a_s_t_1, None)
    ast.fix_missing_locations(a_s_t_1)
    return (True, [a_s_t_1])


# Generated at 2022-06-25 22:04:02.250485
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typing
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Import(
        names=[module_0.alias(name='typing', asname='typing')]
    )
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        result = base_import_rewrite_0.visit_Import(a_s_t_1)
    except Exception as error:
        raise
    assert(result == a_s_t_1)

# Generated at 2022-06-25 22:04:11.156986
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    @import_rewrite(previous='from abc import bar', current='from def import bar')
    def func():
        pass

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import(names=[])
    base_import_rewrite_0._get_matched_rewrite(None)
    try_1 = base_import_rewrite_0._replace_import(a_s_t_1, '', '')
    a_s_t_2 = module_0.Import(names=[module_0.alias(name='', asname=None)])

# Generated at 2022-06-25 22:04:13.603951
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    try:
        base_import_rewrite_0._replace_import(import_0, "", "")
    except NotImplementedError:
        status = 'not ok'
    else:
        status = 'ok'
    assert status == 'ok'


# Generated at 2022-06-25 22:04:17.995149
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.Import()
    a_s_t_2 = module_0.alias(0, 0)
    a_s_t_1.names = [a_s_t_2]
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1, [], [])
    base_import_rewrite_1.visit_Import(a_s_t_1)


# Generated at 2022-06-25 22:04:26.285612
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import json
    import ast

    # test program
    a_s_t_0 = ast.parse('import foo')
    import_statements = [c for c in ast.walk(a_s_t_0) if isinstance(c, ast.Import)]
    assert len(import_statements) == 1

    # test setup
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('foo', 'bar')]

    # test
    actual = str(astor.to_source(base_import_rewrite_0.visit(a_s_t_0)))
    expected = 'try:\n    import foo\nexcept ImportError:\n    import bar'

# Generated at 2022-06-25 22:05:16.802761
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.Module()
    node_0 = module_0.ImportFrom(module_1, [], [])
    module_0.ImportFrom(module_1, [], [])
    base_import_rewrite_0.visit_ImportFrom(node_0)


# Generated at 2022-06-25 22:05:22.659101
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    names_to_replace = {'wrong': ('string', 'dict')}
    try:
        raise AssertionError(
            'It is impossible to use dict as argument for format')
    except AssertionError:
        pass


# Generated at 2022-06-25 22:05:24.015984
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass


if __name__ == '__main__':
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:05:32.009815
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    module_0_0 = module_0.ImportFrom(names=[module_0.alias(name='C', asname='foo', lineno=10, col_offset=20)], level=1, lineno=10, col_offset=20)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._tree_changed = False
    assert base_import_rewrite_0._tree_changed == False
    base_import_rewrite_0.visit_ImportFrom(module_0_0)
    assert base_import_rewrite_0._tree_changed == False

# Generated at 2022-06-25 22:05:40.268185
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    some_arg_0 = module_0.ImportFrom(level = 0,
                                     module = module_0.Name(),
                                     names = [module_0.alias(name = module_0.Name(),
                                                             asname = None)])
    some_arg_1 = module_0.ImportFrom(level = 0,
                                     module = module_0.Name(),
                                     names = [module_0.alias(name = module_0.Name(),
                                                             asname = None)])
    some_arg_2 = module_0.ImportFrom(level = 0,
                                     module = module_0.Name(),
                                     names = [module_0.alias(name = module_0.Name(),
                                                             asname = None)])

# Generated at 2022-06-25 22:05:46.940324
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 22:05:54.190724
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from test_data import ast_import_from_0
    from test_data import ast_import_from_1
    from test_data import ast_import_from_2
    from test_data import ast_import_from_3
    from test_data import ast_import_from_4

    base_import_rewrite_0 = BaseImportRewrite(None)
    base_import_rewrite_0.visit_ImportFrom(ast_import_from_0)
    base_import_rewrite_0.visit_ImportFrom(ast_import_from_1)
    base_import_rewrite_0.visit_ImportFrom(ast_import_from_2)
    base_import_rewrite_0.visit_ImportFrom(ast_import_from_3)
    base_import_rewrite_0.vis

# Generated at 2022-06-25 22:05:57.580423
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias()
    import_0 = module_0.Import(a_l_i_a_s_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:06:04.622687
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from test_data.module_0.module_1.module_2 import module_3
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    from test_data.module_0.module_1.module_2 import module_3
    #assert False # TODO: implement your test here
    #assert base_import_rewrite_0.visit_ImportFrom(['asd']) == None
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:06:12.881463
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name='typed_ast.types_0.Attribute')
    a_l_i_a_s_1 = module_0.alias(name='typed_ast.types_0.Bytes')
    a_l_i_a_s_2 = module_0.alias(name='typed_ast.types_0.List', asname='List')
    a_l_i_a_s_3 = module_0.alias(name='typed_ast.types_0.NameConstant')