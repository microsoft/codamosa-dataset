

# Generated at 2022-06-25 21:56:45.003806
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(module_0.Import([module_0.alias(name='a', asname='a'), module_0.alias(name='b', asname='b')]))


# Generated at 2022-06-25 21:56:51.522132
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast._ast3 as module_2

    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)

    a_s_t_1 = module_2.Import(names=[module_2.alias(name='module_2')])
    base_import_rewrite_0 = BaseImportRewrite.transform(a_s_t_1)


# Generated at 2022-06-25 21:56:56.174575
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(names=[], module='test')
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:57:00.666287
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast._ast3 as module_0
    import_0 = module_0.Import()
    import_rewrite_0 = BaseImportRewrite(import_0)
    
    # Call method visit_Import of class BaseImportRewrite
    result = import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:07.103849
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    base_node_transformer_0._tree_changed = 0
    alias_0 = module_0.alias(name='', asname='')
    import_0 = module_0.Import(names=[alias_0])
    a_s_t_1 = base_node_transformer_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:14.262452
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_str_0 = 'x1'
    level_int_0 = 711
    names_list_0 = ['x1', 'x1', 'x1']
    import_from_0 = module_0.ImportFrom(module=module_str_0, level=level_int_0, names=names_list_0)
    arg_node_0 = import_from_0
    base_import_rewrite_0.visit_ImportFrom(arg_node_0)


# Generated at 2022-06-25 21:57:23.040194
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    module_0.Name()
    module_0.alias()
    module_0.alias()
    module_0.alias()
    module_0.alias()
    module_0.alias()
    module_0.alias()
    module_0.alias()
    module_0.alias()
    basemap_rewriter_0 = BaseImportRewrite()
    basemap_rewriter_0._get_matched_rewrite(module_0.alias())
    module_0.Import()
    basemap_rewriter_0._replace_import(import_0, module_0.alias(), module_0.alias())
    import_1 = basemap_rewriter_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:29.402355
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_from_0 = module_0.ImportFrom('mod_0', [], 0)
    base_import_rewrite_0.visit(import_from_0)
    import_0 = module_0.Import([])
    base_import_rewrite_0.visit(import_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 21:57:31.591125
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO: test
    pass

    # TODO: test
    pass

    # TODO: test
    pass

    # TODO: test
    pass


# Generated at 2022-06-25 21:57:36.284767
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(names=[], level=0)
    base_import_rewrite_0.visit_ImportFrom(a_s_t_1)

# Generated at 2022-06-25 21:57:47.725906
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(module='', names=[], level=1)
    import_from_1 = module_0.ImportFrom(names=[], level=1)
    class_0 = BaseImportRewrite(a_s_t_0)
    class_0.visit_ImportFrom(import_from_0)
    class_0.visit_ImportFrom(import_from_1)


# Generated at 2022-06-25 21:57:50.430210
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert not base_import_rewrite_0.visit_Import(module_0.AST())


# Generated at 2022-06-25 21:57:53.444212
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a = ast.Import()
    b = ast.Name()
    b.id = 'b'
    a.names = [b]
    tree = BaseImportRewrite(a)
    import_ast = tree.visit_Import(a)
    ast.dump(import_ast)


# Generated at 2022-06-25 21:58:02.057763
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Import(names=[module_0.alias(name='typed_ast.ast3')])]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[module_0.alias(asname='ast3', name='typed_ast.ast3')])
    import_1 = module_0.Import(names=[module_0.alias(asname='ast3', name='typed_ast.ast3')])
    try_0 = module_0.Try(body=[import_0], finalbody=[], handlers=[], orelse=[], type_comment=None)

# Generated at 2022-06-25 21:58:07.657556
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(module='module',
                                        names=['name'],
                                        level=0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('from_', 'to')]
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:58:15.132654
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportFromRewrite(BaseImportRewrite):
        def __init__(self, rewrites: List[Tuple[str, str]]):
            super().__init__()
            self.rewrites = rewrites
    
    import_0 = module_0.ImportFrom(attr=None, id='import_0', level=1, module='a')
    import_from_rewrite_0 = ImportFromRewrite([('a', 'b')])
    assert import_from_rewrite_0.visit_ImportFrom(import_0) == import_from_rewrite_0._replace_import_from_module(import_0, 'a', 'b')


# Generated at 2022-06-25 21:58:23.409051
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_1.body = [a_s_t_2]
    a_s_t_3 = module_0.AST()
    a_s_t_3.value = a_s_t_2
    import_0 = module_0.Import([a_s_t_3])
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:32.081675
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(
        level=0,
        module='module',
        names=[
            module_0.alias(
                asname='asname',
                name='name')])
    base_import_rewrite_0.rewrites = [
        ('rewrite', 'rewrite')]
    base_import_rewrite_0.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)

import abc


# Generated at 2022-06-25 21:58:37.038907
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=0, module='abc', names=[])
    try:
        base_node_transformer_0.visit_ImportFrom(import_from_0)
    except Exception:
        print('expected')
    else:
        raise Exception('expected')


# Generated at 2022-06-25 21:58:48.184935
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_node_transformer_1 = BaseNodeTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    base_node_transformer_2 = BaseNodeTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    base_node_transformer_3 = BaseNodeTransformer(a_s_t_3)
    a_s_t_4 = module_0.AST()
    base_node_transformer_4 = BaseNodeTransformer(a_s_t_4)

# Generated at 2022-06-25 21:59:12.926739
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    i_m_p_0 = module_0.Import()
    n_a_m_e_0 = module_0.alias()
    n_a_m_e_0.name = "attr"
    n_a_m_e_0.asname = "attr"
    i_m_p_0.names = [n_a_m_e_0]
    base_node_transformer_0.rewrites = [("attr", "attr")]
    i_m_p_1 = base_node_transformer_0.visit_Import(i_m_p_0)
    assert i_m_p_1 == i_m

# Generated at 2022-06-25 21:59:21.460547
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast._ast3 as module_0
    import _ast as module_1
    module_0 = module_0
    module_1 = module_1
    a_s_t_0 = module_1.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_1.alias()
    a_s_t_0.body = [a_s_t_1]
    arg_0 = module_0.Import(names=[module_0.alias()])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('foo', 'bar')]
    module_0.Import = module_0.Import
    module

# Generated at 2022-06-25 21:59:29.648640
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    rewrites = []

    from typed_ast import ast3 as ast # type: ignore

    import_0 = ast.Import(names=[])
    from_0 = "from_0"
    to_0 = "to_0"

    import_rewrite_body_0 = ast.AST()

    class BaseImportRewrite_Class_0(BaseImportRewrite):
        rewrites = rewrites

        def _get_matched_rewrite(self, name):
            return (from_0, to_0)

        def _replace_import(self, node, from_, to):
            return import_rewrite_body_0

    base_import_rewrite_class_0 = BaseImportRewrite_Class_0(import_0)


# Generated at 2022-06-25 21:59:39.411717
# Unit test for method visit_Import of class BaseImportRewrite

# Generated at 2022-06-25 21:59:48.494179
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import typed_ast._ast3 as module_1

    node_0 = ast.parse('import collections.abc')
    a_s_t_0 = node_0
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('collections', 'typing')]
    try:
        module_1.Import(names=module_1.alias(name='typing.abc', asname=None))
        module_1.Import(names=module_1.alias(name='collections.abc', asname=None))
    except ImportError:
        pass
    base_import_rewrite_0.visit_Import(node_0)


# Generated at 2022-06-25 21:59:52.891115
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = ast.ImportFrom(module='typing', names=[ast.alias(name='List',asname='List')],level=0)
    ast_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(ast_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:00.736623
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    def test_0():

        # Literal(1.0, type='literal_float', position=None)
        a_s_t_1 = module_0.AST()
        node_0 = module_0.ImportFrom(a_s_t_1, 'literal_float', [a_s_t_0], [a_s_t_0])

        base_node_transformer_0.visit_ImportFrom(node_0)


# Generated at 2022-06-25 22:00:08.821215
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.Import()
    result = base_import_rewrite_0.visit_Import(a_s_t_2)
    # Verify that the result has the same type as the previous instance
    assert type(result) == type(a_s_t_2)


# Generated at 2022-06-25 22:00:12.299223
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    a_s_t_0 = ast.parse("""class A(object): pass""")
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(a_s_t_0)

    assert a_s_t_0 is not None


# Generated at 2022-06-25 22:00:15.439927
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(module_0.Import())


# Generated at 2022-06-25 22:00:53.619156
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    with patch('typed_ast.ast3.Try', side_effect=mock_try):
        # When
        res_0 = base_import_rewrite_0.visit_Import(a_s_t_0)

    # Then
    assert res_0 is mock_try.return_value



# Generated at 2022-06-25 22:00:58.162359
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom(names=[module_0.alias(name='module_0')], module='module_0')
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)



# Generated at 2022-06-25 22:01:04.417172
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:09.365166
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    try:
        node_1 = module_0.Import()
        alias_0 = module_0.alias()
        alias_0.name = "name"
        node_1.names = [alias_0]
        base_import_rewrite_0 = BaseImportRewrite(node_1)
        base_import_rewrite_0.visit(node_1)
    except Exception as e:
        raise e


# Generated at 2022-06-25 22:01:14.392975
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom('import_from_0', [])
    base_import_rewrite_0 = BaseImportRewrite(None)
    a_s_t_1 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_1)
    base_node_transformer_0.visit(import_from_0)
    base_import_rewrite_0.visit(import_from_0)


# Generated at 2022-06-25 22:01:22.105666
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_1 = module_0.Import(names=[
        module_0.alias(name='foo',
                       asname=None)])

    base_import_rewrite_0.visit_Import(import_1)


# Generated at 2022-06-25 22:01:29.996890
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0._get_names_to_replace(import_from_0)
    base_import_rewrite_0._replace_import_from_names(import_from_0, {})
    base_import_rewrite_0._replace_import_from_module(import_from_0, '', '')
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:38.348832
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    import_from_0 = module_0.ImportFrom(names=[module_0.alias(name="module_0", asname=None)], module="module_1", level=0)
    base_import_rewrite_0._get_matched_rewrite(import_from_0.module)
    base_import_rewrite_0._get_names_to_replace(import_from_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:01:50.395298
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.Module()
    import_0 = module_0.Import([module_0.alias(name="abc.example.foo",
                                               asname="bar")])
    module_1.body = [import_0]
    result = base_import_rewrite_0.visit_Import(import_0)
    assert isinstance(result, module_0.Try)
    assert base_import_rewrite_0._tree_changed == True
    assert base_import_rewrite_0.rewrites == []
    assert module_1.body == [result]
    assert isinstance(result, module_0.Try)
    try_

# Generated at 2022-06-25 22:01:54.105449
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='builtins', names=[])
    a_s_t_1 = base_node_transformer_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:03:02.044805
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Input parameters:
    node = module_0.Import(["ast"])
    # Output:
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    function_result = base_import_rewrite_0.visit_Import(node)

    # Annotation assertion
    assert isinstance(function_result, (module_0.Import, module_0.Try))
    # Value assertion
    assert function_result == module_0.Try(body=[module_0.Import(names=["ast"])], handlers=[module_0.ExceptHandler(type=None, name=None, body=[module_0.Import(names=["ast"])])])

    # Reinitialize mock
    typed_ast_mock.reset_

# Generated at 2022-06-25 22:03:08.946564
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    import_1 = module_0.Import()
    # Set up the mock
    import_0.names = import_1
    base_import_rewrite_0 = BaseImportRewrite(module_0.AST())
    base_import_rewrite_0.rewrites = [((base_import_rewrite_0 + base_import_rewrite_0) + (base_import_rewrite_0 + base_import_rewrite_0)), ((base_import_rewrite_0 + base_import_rewrite_0) + (base_import_rewrite_0 + base_import_rewrite_0))]

    # Call the test function

# Generated at 2022-06-25 22:03:13.206575
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.Import()
    a_s_t_2 = base_node_transformer_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 22:03:22.514656
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    a_s_t_6 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_6)
    a_s_t_2 = module_0.AST()
    v_a_l_0 = ast.alias(name="a",
                        asname=None)
    v_a_l_1 = ast.alias(name="b",
                        asname=None)
    assert(not (not (base_import_rewrite_0._tree_changed)))
    import_from_0 = ast.ImportFrom(module="a",
                                  names=[v_a_l_0,
                                         v_a_l_1],
                                  level=1)

# Generated at 2022-06-25 22:03:29.312155
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_0_class_0 = module_0.ClassDef(name='a_s_t_0_class_0', bases=[], keywords=[], body=[], decorator_list=[])
    a_s_t_0.body = [a_s_t_0_class_0]
    a_s_t_0_class_0_alias_0 = module_0.alias(name='a_s_t_0_class_0_alias_0', asname='a_s_t_0_class_0_alias_0_asname_0')
    a_s_t_0_class_0_import_0 = module_0.Import(names=[a_s_t_0_class_0_alias_0])


# Generated at 2022-06-25 22:03:34.665592
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(str(), str())]
    import_from_0 = module_0.ImportFrom(str(), None, int())
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:03:35.356180
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass



# Generated at 2022-06-25 22:03:38.713598
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = ast.ImportFrom()
    base_import_rewrite_0 = BaseImportRewrite(None)
    try:
        assert False
    except:
        pass


# Generated at 2022-06-25 22:03:45.103440
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    import_0.names.append(module_0.alias())
    base_import_rewrite_0._get_matched_rewrite(None)
    base_import_rewrite_0._replace_import(import_0, '', '')
    try:
        base_import_rewrite_0.visit_Import(import_0)
    except:
        print("Exception raised in BaseImportRewrite.visit_Import of test_BaseImportRewrite_visit_Import")
        raise


# Generated at 2022-06-25 22:03:49.057773
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import()
    base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 22:05:16.189634
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = module_0.ImportFrom()
    base_import_rewrite_0 = BaseImportRewrite(module_0)
    base_import_rewrite_0.visit_ImportFrom(module_0)

# Generated at 2022-06-25 22:05:28.686911
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    a_s_t_0 = ast.Import()
    a_s_t_0.names = [ast.alias(name='os', asname='os')]
    base_import_rewrite_0 = BaseImportRewrite([('typed_ast', 'fast_typed_ast')])
    base_import_rewrite_0._tree_changed = False
    base_import_rewrite_0._get_matched_rewrite = lambda name: ('typed_ast', 'fast_typed_ast')
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    base_node_transformer_0._tree_changed = False

# Generated at 2022-06-25 22:05:31.873273
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Init
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()

    # Invocation testing
    result = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:05:36.425173
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    import_0 = module_0.Import(names=[module_0.alias(name='module',asname=None)])
    base_node_transformer_1 = BaseNodeTransformer(a_s_t_1)
    visitor_0 = base_node_transformer_1.visit_Import(import_0)
    assert visitor_0 == import_0


# Generated at 2022-06-25 22:05:43.150148
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_0 = module_0.Import()
    base_node_transformer_0._get_matched_rewrite = mock.Mock()
    base_node_transformer_0._get_matched_rewrite.return_value = None
    result = base_node_transformer_0.visit_Import(import_0)
    result_0 = base_node_transformer_0.generic_visit(import_0)
    assert result == result_0
    base_node_transformer_0._get_matched_rewrite.assert_called_with(None)


# Generated at 2022-06-25 22:05:48.222142
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    imports_0 = a_s_t_1.Import(names=[a_s_t_1.alias(name='collections', asname=None)])
    try:
        base_import_rewrite_0.visit_Import(imports_0)
    except Exception as e:
        assert True
    else:
        assert False


# Generated at 2022-06-25 22:05:53.158142
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites += [('a', 'b')]
    import_0 = ast.Import(names=[ast.alias(name='a', asname='b')])
    a_s_t_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:05:55.961632
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.Import()
    assert base_import_rewrite_0.visit_Import(module_1) == module_1


# Generated at 2022-06-25 22:06:01.283820
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import random

    a_s_t_0 = module_0.parse("import socket")
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    base_node_transformer_0._tree_changed = True
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = a_s_t_0
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:06:10.815354
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import(
        names=[
            module_0.alias(
                name='from1',
                asname=None)],
        lineno=None,
        col_offset=None)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.target = module_0
    base_import_rewrite_0.rewrites = [
        (
            'from1',
            'to1'),
        (
            'from2',
            'to2')]
    base_import_rewrite_0.dependencies = []
    try_0 = base_import_rewrite_0.visit_Import(import_0)
    assert(isinstance(try_0, module_0.Try))