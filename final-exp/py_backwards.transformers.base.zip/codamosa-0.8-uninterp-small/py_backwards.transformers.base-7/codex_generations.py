

# Generated at 2022-06-25 21:56:50.488148
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..transformations.base import BaseImportRewrite
    from typing import List, Tuple
    from typed_ast import (
        ast3 as ast,
    )

    class Test:
        def __init__(self):
            self.rewrites = [
                ("foo", "bar"),
                ("meh", "meh2"),
            ]

        def test(self):
            import foo.bar
            import foo.bar.meh.meh

            import foo.bar2
            import foo2.bar
            import bar.foo

    import_0 = (
        ast.Import(
            names=[
                ast.alias(
                    name="foo.bar",
                    asname=None,
                ),
            ],
        )
    )

# Generated at 2022-06-25 21:56:57.685977
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # template code
    module_0 = ast.parse("""
import os
""")
    
    # compiled code
    a_s_t_0 = module_0
    
    # object initialization
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    
    # test
    a_s_t_1 = base_import_rewrite_0.visit(module_0)
    
    # assertion
    assert(isinstance(a_s_t_1, ast.AST))
    assert(a_s_t_1 == ast.parse("""
import os
""", mode='exec'))



# Generated at 2022-06-25 21:57:01.448973
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:57:08.145851
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Instantiating a fake AST from the fake module
    d_a_m_0 = module_0.AST()
    # Instantiating an object of class BaseImportRewrite with the AST as a
    # parameter
    b_i_r_0 = BaseImportRewrite(d_a_m_0)

    # If a module called "six" exists, the first condition
    # of the if statement should be taken
    t_r_0 = b_i_r_0.visit_Import("six")


# Generated at 2022-06-25 21:57:12.078509
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    ast_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:18.728175
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import(names=[module_0.alias(name='os', asname=None)])
    try:
        base_import_rewrite_2 = base_import_rewrite_0.visit_Import(a_s_t_1)
    except ImportError:
        import os as os
    try:
        import os as os
    except ImportError:
        pass

# Generated at 2022-06-25 21:57:25.762894
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_0 = module_0.Import()
    names_0 = []
    import_0.names = names_0
    a_st_node_0 = import_0
    result = base_import_rewrite_0.visit_Import(a_st_node_0)
    assert isinstance(result, module_0.Import)
    assert base_import_rewrite_0._tree_changed == False


# Generated at 2022-06-25 21:57:33.874266
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    reload(module_0)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    str_0 = "__future__"
    str_1 = "six.moves.configparser"
    import_0 = ast.Import([ast.alias(str_0)])
    try_0 = base_import_rewrite_0.visit_Import(import_0)
    base_import_rewrite_0.rewrites = [(str_0,str_1)]
    try_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:43.316512
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    c_a_l_l_0 = module_0.Call(args=[], keywords=[], starargs=None, kwargs=None)
    n_a_t_0 = module_0.Name(id='foo', ctx=module_0.Load())
    a_l_i_a_s_0 = module_0.alias(name='foo', asname=None)
    i_m_p_0 = module_0.Import(names=[a_l_i_a_s_0])
    t_r_0 = module_0.Try(body=[i_m_p_0], orelse=[], finalbody=[], handlers=[])


# Generated at 2022-06-25 21:57:44.499213
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-25 21:57:57.768360
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    original_source = """\
from imports import test_1
from imports.test_1 import test_2
from imports import test_3 as test_4
"""
    expected_source = """\
try:
    from imports import test_1
except ImportError:
    from imports.test_1 import test_1

try:
    from imports.test_1 import test_2
except ImportError:
    from imports import test_2

try:
    from imports import test_3 as test_4
except ImportError:
    from imports import test_4 as test_4
"""
    original = ast.parse(original_source)  # type: ignore
    expected = ast.parse(expected_source)

    class BaseImportRewriteSubclass(BaseImportRewrite):
        """Subclass for testing."""

# Generated at 2022-06-25 21:58:06.588178
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    typed_ast_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(typed_ast_0)
    
    a_s_t_4 = module_0.AST()
    node_5 = module_0.ImportFrom(module="foo",
                                 names=[module_0.alias(name="foo", asname="bar")],
                                 level=2)
    ast_6 = base_node_transformer_0.generic_visit(node_5)
    assert ast_6.__class__.__name__ is "ImportFrom"
    assert ast_6.names[0].name is "foo"
    assert ast_6.names[0].asname is None
    assert ast_6.names[0].__class__.__name__ is "alias"
    assert ast

# Generated at 2022-06-25 21:58:14.282509
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=['names_0'])
    base_import_rewrite_0._get_matched_rewrite = lambda name: ('from_0', 'to_0')
    base_import_rewrite_0._replace_import = lambda node, from_, to: 'node_0'
    result_0 = base_import_rewrite_0.visit_Import(import_0)
    assert result_0 == 'node_0'


# Generated at 2022-06-25 21:58:15.510050
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:58:19.718679
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
  a_s_t_0 = module_0.AST()
  base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
  node_0 = module_0.ImportFrom(level=None, module='', names=[])
  base_import_rewrite_0.visit_ImportFrom(node_0)


# Generated at 2022-06-25 21:58:21.317196
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass


# Generated at 2022-06-25 21:58:30.696335
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_from_ast_0 = module_0.ImportFrom(
        module='collections',
        names=[
            module_0.alias(
                name='abc',
                asname=None
            )
        ],
        level=0
    )

    import_rewrite_0 = BaseImportRewrite._replace_import_from_module(
        base_import_rewrite_0,
        import_from_ast_0,
        'collections',
        'collections.abc'
    )


# Generated at 2022-06-25 21:58:35.609257
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    rename_me_0 = module_0.rename_me()
    try:
        base_import_rewrite_0.visit_Import(rename_me_0)
    except NameError as err:
        assert err.__class__.__name__ == 'NameError'


# Generated at 2022-06-25 21:58:38.100600
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # AssertionError: <built-in function id> != <built-in function id>
    pass


# Generated at 2022-06-25 21:58:41.551799
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:53.197286
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert False


# Generated at 2022-06-25 21:58:58.204410
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    a_s_t_2 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_2)
    alias_3 = module_0.alias()
    alias_4 = module_0.alias()

    import_5 = module_0.Import(names=[
        alias_3,
     alias_4])

    # Exercise
    union_type_6 = base_import_rewrite_1.visit_Import(import_5)

    # Verify
    assert union_type_6 is import_5


# Generated at 2022-06-25 21:59:04.089064
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typing as module_1

# Generated at 2022-06-25 21:59:12.745962
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import typed_ast._ast3 as module_0
    from typed_ast import ast3 as module_1
    from typed_ast.transforms import BaseImportRewrite
    module_1.ImportFrom(names=[ast.alias(name='abc', asname=None)],
    level=None)
    module_1.ImportFrom(names=[ast.alias(name='abc', asname=None)],
    level=None)


# Generated at 2022-06-25 21:59:18.314446
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='test',
                                                 names=[module_0.alias(name='test',
                                                 asname='test')],
                                                 level=0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:59:26.193611
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
  a_s_t_1 = ast.AST()
  a_s_t_1 = ast.Module([ast.Import([ast.alias(name='typed_ast.ast3', asname=None)])])
  base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
  a_s_t_2 = ast.ImportFrom(module='typed_ast.ast3', names=[ast.alias(name='AST', asname=None)], level=0)
  base_import_rewrite_1.visit_ImportFrom(a_s_t_2)
  assert type(base_import_rewrite_1) == BaseImportRewrite


# Generated at 2022-06-25 21:59:31.415140
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = ((("A", "B"),),)
    import_from_0 = module_0.ImportFrom("A", [], 2)
    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    import_from_1 = module_0.ImportFrom("B", [], 2)
    assert isinstance(a_s_t_1, module_0.Try)

# Generated at 2022-06-25 21:59:38.269277
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.alias(0, 0, ())
    try:
        a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(0)
    except:
        a_s_t_1 = module_0.Try()
    return a_s_t_1

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:59:47.889035
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='some', names=[module_0.alias(name='a', asname=None), module_0.alias(name='b', asname=None)], level=3)
    try:
        module_0.ImportFrom(module='os', names=[module_0.alias(name='path', asname=None)], level=0)
    except ImportError:
        module_0.ImportFrom(module='pathlib', names=[module_0.alias(name='Path', asname=None)], level=0)

# Generated at 2022-06-25 21:59:53.247239
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    try:
        base_import_rewrite_0.visit_ImportFrom(base_import_rewrite_1)
    except ImportError:
        pass



# Generated at 2022-06-25 22:00:26.852675
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=None, module='module_0', names=[], asname=None)
    import_from_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(import_from_1, module_0.ImportFrom)
    assert import_from_1.names == []
    assert import_from_1.asname is None
    assert import_from_1.level is None
    assert import_from_1.module == 'module_0'


# Generated at 2022-06-25 22:00:34.575294
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)

    from_2 = "mypackage.mymodule"
    to_2 = "mypackage.mymodule"
    names_to_replace_2 = {
    "mypackage.mymodule.my_class": ("mypackage.mymodule", "mypackage.mymodule")
    }
    node_2 = module_0.ImportFrom(
    module="mypackage.mymodule",
    names=[module_0.alias(
    name="my_class",
    asname="")],
    level=0)
    rewrote_module_2 = node_2.module.replace(from_2, to_2, 1)

# Generated at 2022-06-25 22:00:44.587886
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_3 = module_0.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_3)
    name_field_3 = module_0.Load()
    module_3 = module_0.Name(id='module', ctx=name_field_3)
    alias_3 = module_0.alias(name='name', asname='asname')
    node_3 = module_0.Import(names=[alias_3])
    rewrote_name_3 = 'name'
    import_as_3 = 'asname'
    body_3 = [module_3]
    import_3 = module_0.Import(names=[module_3])

# Generated at 2022-06-25 22:00:46.779143
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:00:48.373632
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0.Import


# Generated at 2022-06-25 22:00:53.092796
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    alias_0 = module_0.alias('', None)
    import_from_0 = module_0.ImportFrom('', [alias_0], 0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    try_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:59.816010
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_name_0 = 'test'
    names_0 = [module_0.alias(name='a', asname='b', inspect_name='c', attribute='d')]
    level_0 = 0
    node_0 = module_0.ImportFrom(module_name_0, names_0, level_0)
    result_0 = base_import_rewrite_0.visit_ImportFrom(node_0)
    assert result_0 == node_0

# Generated at 2022-06-25 22:01:08.855452
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Simple test
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    a_l_i_a_s_0 = module_0.alias()
    a_l_i_a_s_1 = module_0.alias()

    a_s_t_1 = module_0.AST()
    import_from_0 = module_0.ImportFrom(module=a_s_t_1, names=[a_l_i_a_s_0, a_l_i_a_s_1], level=0)

    base_import_rewrite_0.visit_ImportFrom(import_from_0)



# Generated at 2022-06-25 22:01:14.047688
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    
    # Try/Except is generated for function call BaseImportRewrite.visit_ImportFrom
    try:
        base_import_rewrite_0.visit_ImportFrom(a_s_t_0)
    except ImportError:
        assert True
    else:
        assert False

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:01:26.981885
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias()
    alias_0.name = 'test'
    alias_0.asname = None
    a_s_t_1 = module_0.AST()
    alias_1 = module_0.alias()
    alias_1.name = 'test'
    alias_1.asname = None
    a_s_t_2 = module_0.AST()
    alias_2 = module_0.alias()
    alias_2.name = 'test'
    alias_2.asname = None
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(a_s_t_1)
    base_import

# Generated at 2022-06-25 22:02:08.531113
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_alias_0 = module_0.alias(
        name="typed_ast",
    )
    a_s_t_1 = module_0.Import(
        names=[module_alias_0],
    )
    base_import_rewrite_1 = BaseImportRewrite.visit_Import(base_import_rewrite_0, a_s_t_1)


# Generated at 2022-06-25 22:02:13.673201
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(module=str(), level=str())
    import_from_0 = base_import_rewrite_0.visit_ImportFrom(a_s_t_1)


# Generated at 2022-06-25 22:02:21.690032
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name="test_0", asname=None)
    a_l_i_a_s_2 = module_0.alias(name="test_2", asname=None)
    a_s_t_1 = module_0.AST()
    import_0 = module_0.Import(names=[a_l_i_a_s_0])
    import_2 = module_0.Import(names=[a_l_i_a_s_2])
    a_s_t_2 = module_0.AST()

# Generated at 2022-06-25 22:02:27.451432
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module = "django.contrib.auth", names = [ module_0.alias(name = "User", asname = None), module_0.alias(name = "Group", asname = None), module_0.alias(name = "Permission", asname = None) ], level = None)
    result_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert result_0 == import_from_0


# Generated at 2022-06-25 22:02:31.273632
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(level=0, module='module_0', names=[])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:02:39.618382
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_0 = ast.ImportFrom(
        module='six',
        names=[ast.alias(name='wraps', asname=None)],
        level=0
        )
    test_1 = ast.ImportFrom(
        module='six.wraps',
        names=[ast.alias(name='wraps', asname=None)],
        level=0
        )
    test_cases = [
        (BaseImportRewrite, 'six', 'six.wraps', test_0, test_1),
        ]
    for base_import_rewrite_0 in BaseImportRewrite.rewrites:
        a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:02:46.174365
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = ast.Module()
    module_0.body = [
        ast.Import(names=[
            ast.alias(name='sys',
                      asname=None)])]
    base_import_rewrite_0 = BaseImportRewrite(module_0)
    a_s_t_0 = module_0
    module_1 = ast.Module()

# Generated at 2022-06-25 22:02:49.802806
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    t = BaseImportRewrite(None)
    t._tree_changed = False
    t._get_matched_rewrite = lambda x: ('from', 'to')
    t._replace_import = lambda x, y, z: x
    assert t.visit_Import(ast.parse('import x').body[0]) == ast.parse('try:\n    import x\nexcept ImportError:\n    import to').body[0]
    assert t._tree_changed


# Generated at 2022-06-25 22:02:58.415545
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Simple test
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(
        'typed_ast.ast3',
        'typed_ast.ast3'
    )]
    base_import_rewrite_0.dependencies = []
    a_s_t_1 = module_0.AST()
    module_1 = module_0.Module(
        body=[a_s_t_1]
    )
    a_s_t_2 = module_0.alias(
        name='typed_ast.ast3',
        asname=None
    )

# Generated at 2022-06-25 22:03:04.957576
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Local variable test cases for visit_ImportFrom of class BaseImportRewrite
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    import_from_1 = module_0.ImportFrom(names=[module_0.alias(name='A', asname='B')], level=0, module='foo')
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    import_from_2 = module_0.ImportFrom(names=[module_0.alias(name='*', asname='B')], level=0, module='foo')
    a_s_t_3 = module_0.AST()
    base_

# Generated at 2022-06-25 22:04:34.428542
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite(None)
    module_0 = module_0
    try:
        a_s_t_0 = module_0.AST()
        i_m_p_0 = module_0.Import()
        alias_0 = module_0.alias()
        alias_0.name = None
        i_m_p_0.names = [alias_0]
        result = base_import_rewrite_0.visit_Import(i_m_p_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:04:38.213089
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias("a_name_0")
    import_0 = module_0.Import([alias_0])
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:44.490441
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Given
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [
        module_0.Import(
            names=[
                module_0.alias(
                    name="unittest.mock",
                    asname=None
                )
            ]
        )
    ]
    a_s_t_0.source = "import unittest.mock"
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [
        (
            'unittest.mock',
            'mock'
        )
    ]
    # When

# Generated at 2022-06-25 22:04:50.733364
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import ImportFrom
    a_s_t_2 = module_0.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_2)
    a_s_t_2 = module_0.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_2)
    names_0 = []
    a_s_t_2 = ImportFrom(module="itertools", names=names_0, level=0, lineno=0, col_offset=0)
    actual = base_import_rewrite_3.visit_ImportFrom(a_s_t_2)
    expected = a_s_t_2
    assert expected == actual, 'Expected values do not match actual values for method visit_ImportFrom'

# Generated at 2022-06-25 22:05:00.534585
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom()
    a_s_t_1.module = module_0.alias()
    a_s_t_2 = module_0.alias()
    a_s_t_1.names = [a_s_t_2]
    base_import_rewrite_0.visit_GenericLambda(a_s_t_1)
    a_s_t_1.level = module_0.alias()
    base_import_rewrite_0.visit_GenericLambda(a_s_t_1)


# Generated at 2022-06-25 22:05:03.112205
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = ast.ImportFrom(names=[], module='a')
    module_0 = BaseImportRewrite(import_from_0)
    module_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:05:06.972938
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import()
    res_0 = base_import_rewrite_0.visit_Import(a_s_t_1)
    

# Generated at 2022-06-25 22:05:17.942570
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.Import()
    a_s_t_2 = module_0.alias()
    a_s_t_1.names = [a_s_t_2, a_s_t_2]
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_1.rewrites = [(1, 2), (3, 4)]
    base_import_rewrite_1._replace_import(a_s_t_1, 1, 2)
    base_import_rewrite_1._replace_import(a_s_t_1, 3, 4)


# Generated at 2022-06-25 22:05:26.557241
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    a_s_t_0 = ast.AST()
    # Initialize instance of class BaseImportRewrite
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0) 
    # Initialize module.module of class ImportFrom
    string_1 = "module"
    import_from_0 = ast.ImportFrom(module=string_1, names=[], level=0)
    # Call method visit_ImportFrom
    import_from_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)



# Generated at 2022-06-25 22:05:30.958175
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    import_from_0 = module_0.ImportFrom(a_s_t_1, 0)
    union_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
