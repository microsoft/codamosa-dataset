

# Generated at 2022-06-25 21:56:57.454719
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    i_m_p_o_r_t_0 = module_0.alias()
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(module = "", names = [i_m_p_o_r_t_0], level = "")
    truncated_0 = base_import_rewrite_0.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)

# Generated at 2022-06-25 21:57:05.000332
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    i_m_p_o_r_t_2 = module_0.Import()
    i_m_p_o_r_t_2.names = [module_0.alias()]
    i_m_p_o_r_t_2.names[0].name = 'test.test'
    a_s_t_3 = base_import_rewrite_0.visit_Import(i_m_p_o_r_t_2)
    assert isinstance(a_s_t_3, module_0.Try)


# Generated at 2022-06-25 21:57:14.572082
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # pytest fixtures
    # @pytest.fixture(params=[int, str, tuple])
    # def func_1(request):
    #     return request.param

    # def func_2(func_1):
    #     return func_1()

    # pytest.mark.parametrize('func_1', [(i for i in range(10))], indirect=True)

    # Initialization
    # @pytest.fixture(scope='module', autouse=True)
    # def init_fixture():
    #     BaseImportRewrite.rewrites = [('django', 'asgiref')]
    #     BaseImportRewrite._tree_changed = False

    # Setup
    base_import_rewrite_0 = BaseImportRewrite(None)
    base_import_rewrite_0.rewrites

# Generated at 2022-06-25 21:57:23.524697
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast

    import astor

    a_s_t_0 = ast.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)


    # ------------------------------------------------------------

    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # ------------------------------------------------------------

    a_s_t_1 = ast.Module(body=[
        ast.Import(names=[
            ast.alias(name='typed_ast._ast3', asname=None)])])
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)

# Generated at 2022-06-25 21:57:32.538464
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3
    a_s_t_0 = ast3.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = ast3.AST()
    base_node_transformer_1 = BaseNodeTransformer(a_s_t_1)
    a_s_t_2 = ast3.AST()
    base_node_transformer_2 = BaseNodeTransformer(a_s_t_2)
    a_s_t_3 = ast3.AST()
    base_node_transformer_3 = BaseNodeTransformer(a_s_t_3)
    a_s_t_4 = ast3.AST()

# Generated at 2022-06-25 21:57:39.789406
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    ast_1 = module_0.Import(names=a_s_t_0)
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    base_node_transformer_1 = BaseImportRewrite(a_s_t_0)
    base_node_transformer_2 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(ast_1)


# Generated at 2022-06-25 21:57:42.061852
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:57:48.207357
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    i_0 = module_0.Import()
    base_import_rewrite_0._get_matched_rewrite(i_0.names[0].name)
    base_import_rewrite_0._replace_import(i_0, 'foo', 'bar')
    base_import_rewrite_0.visit_Import(i_0)


# Generated at 2022-06-25 21:57:55.436990
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Create an AST object
    a_s_t_0 = ast.AST()
    assert not a_s_t_0._changed
    # Add a node to the AST
    a_s_t_0.body = [ast.Import(names=[ast.alias(name="b_a_s_e_i_m_p_o_r_t_r_w_r_i_t_e_0",
                                               asname="b_a_s_e_i_m_p_o_r_t_r_w_r_i_t_e_0")])]
    assert a_s_t_0._changed
    # Create an instance of BaseImportRewrite
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 21:57:59.873864
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)

    import_0 = module_0.Import()

    base_node_transformer_0.visit_Import(import_0)
    return


# Generated at 2022-06-25 21:58:18.908893
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    BaseImportRewrite1 = snippet(
        BaseImportRewrite,
        rewrites=[
            ('a.b.c', 'd.e.f')]
    )
    node_Import_rewrite = ast.Import(names=[ast.alias(name='a.b.c.meme', asname='meme')])
    tree = ast.AST()
    node_Try = BaseImportRewrite1(tree).visit(node_Import_rewrite)
    assert node_Try == ast.Try()
    # assert not type(tree) == type(node_Try)


# Generated at 2022-06-25 21:58:24.127241
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseTestRewriter(BaseImportRewrite):
        rewrites = [('os', 'other_os.fn')]

    s = 'import os'
    tree = ast.parse(s)
    rewriter = BaseTestRewriter(tree)
    tree = rewriter.visit(tree)

    assert ast.dump(tree) == 'import other_os.fn as os'



# Generated at 2022-06-25 21:58:31.095732
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestedTransformer(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class DummyAST(ast.AST):
        _fields = tuple()

    tree = DummyAST()
    base_import_rewrite_0 = TestedTransformer(tree)
    import_0 = ast.Import(names=[ast.alias(name='foo',
                                           asname='foo')])
    base_import_rewrite_0.visit_Import(import_0)
    assert base_import_rewrite_0._tree_changed == True


# Generated at 2022-06-25 21:58:34.357836
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..utils.mock_ast import ast_ImportFrom_0
    from .test_cases.visit_ImportFrom_case_0 import rewrite, rewrite_expected

    tree = ast.parse(rewrite)  # type: ignore
    BaseImportRewrite.rewrites = []  # type: List[Tuple[str, str]]
    # BaseImportRewrite.__init__(tree)
    BaseImportRewrite.transform(tree)

    assert ast.dump(tree) == ast.dump(rewrite_expected)

# Generated at 2022-06-25 21:58:39.986156
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Test visit_Import() of class BaseImportRewrite."""
    from typed_ast import parse
    from ..ast_builder import to_ast
    from ..utils import assert_ast_equals_to
    from ..tests import example_ast_1, example_ast_2

    # Test correct import
    correct_import_1 = parse(
        """
        import example.ast_1
        """).body[0]  # type: ast.Import
    correct_import_2 = parse(
        """
        from example.ast_1 import hello
        """).body[0]  # type: ast.ImportFrom

    # Test rewrites
    rewrites = [
        ('example.ast_1', 'example.ast_2')
    ]

    # Test transformed imports

# Generated at 2022-06-25 21:58:44.055229
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    check_result_0 = BaseImportRewrite()
    check_result_1 = ast.Import()
    assert_result = check_result_0.visit_Import(check_result_1)
    assert isinstance(assert_result, ast.Import)


# Generated at 2022-06-25 21:58:48.958804
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    base_import_rewrite_0 = BaseImportRewrite()
    node = ast.ImportFrom(level = 0, module = 'bogus', names = [ast.alias(name = 'bogus_alias', asname = 'bogus_asname')])
    assert base_import_rewrite_0.visit_ImportFrom(node) == node

# Generated at 2022-06-25 21:58:57.776342
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import typed_ast.ast3 as ast

    test_cases = [
        # test_case_0
        ('from module import a',
         'try:\n    from module import a\nexcept ImportError:\n    from new_module import a')
    ]

    for test_case in test_cases:
        base_import_rewrite_0 = BaseImportRewrite()
        base_import_rewrite_0._get_matched_rewrite = lambda name: ('module', 'new_module') if name == 'module' else None

        result = astor.to_source(base_import_rewrite_0.visit(ast.parse(test_case[0])))
        assert result == test_case[1]


# Generated at 2022-06-25 21:59:10.515763
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_, to = ('foo.bar', 'baz.qux')

    import_stmt = ast.parse('import foo.bar').body[0]
    try_stmt = ast.parse('try:\n    import baz.qux\nexcept ImportError:\n    import foo.bar')
    import_stmt_rewrote = BaseImportRewrite._replace_import(BaseImportRewrite(), import_stmt, from_, to)
    assert import_stmt_rewrote == try_stmt.body[0]

    from_, to = ('foo.bar', 'baz.qux')

    import_stmt = ast.parse('import foo.bar.baz as qux').body[0]

# Generated at 2022-06-25 21:59:15.144363
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class MBaseImportRewrite(BaseImportRewrite):
        rewrites = [('foo', 'foo.bar')]

    mnode_0 = ast.parse('import foo').body[0]
    mbase_import_rewrite_0 = MBaseImportRewrite(mnode_0)
    mbase_import_rewrite_0.visit(mnode_0)


# Generated at 2022-06-25 21:59:48.872063
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Unit test for method visit_ImportFrom of class BaseImportRewrite.

    """
    import logging
    import sys

    from typed_ast import parse

    from ..utils.tree import print_tree

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - '
                                  '%(lineno)d - %(levelname)s - '
                                  '%(message)s')
    ch.setFormatter(formatter)
    log.addHandler(ch)

    base_import_rewrite_0 = BaseImportRewrite()

# Generated at 2022-06-25 21:59:54.148934
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class DummyTransformer(BaseImportRewrite):
        rewrites = [('yaml', 'ruamel.yaml')]

    # First case: import module
    import_node = ast.parse('import yaml').body[0]
    transformer = DummyTransformer(None)
    result_node = transformer.visit(import_node)
    assert transformer._tree_changed is True
    assert isinstance(result_node, ast.Try)



# Generated at 2022-06-25 21:59:56.711169
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3 as ast
    tree = ast.parse('import os')
    b = BaseImportRewrite(tree)
    b.visit_Import(tree.body[0])



# Generated at 2022-06-25 22:00:02.394154
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    import_0 = ast.Import()
    ast.copy_location(import_0, import_0)
    import_0.names.append(ast.alias(name='a', asname='b'))
    try_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:10.774631
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    def test_case_0():
        tree_0 = ast.parse(text="""\
from module import SomeClass
""", filename='<whatever>')
        assert len(tree_0.body) == 1
        assert isinstance(tree_0.body[0], ast.Import)
        node_0 = tree_0.body[0]
        assert len(node_0.names) == 1
        assert isinstance(node_0.names[0], ast.alias)
        assert node_0.names[0].name == 'module.SomeClass'
        assert not node_0.names[0].asname
        source_0 = """\
from module import SomeClass
"""
        assert node_0.as_string() == source_0
        rewriter_0 = BaseImportRewrite(tree_0)

# Generated at 2022-06-25 22:00:15.340083
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    str_0 = 'argparse'
    ast.Import_0 = ast.Import(names=[ast.alias(name=str_0, asname=None)])
    ast.Import_0 = base_import_rewrite_0.visit_Import(ast.Import_0)
    base_import_rewrite_0.visit_Import('_')


# Generated at 2022-06-25 22:00:23.447334
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from_module = 'a.b.c'
    to_module = 'a.b.d'
    import_from = ast.ImportFrom(module=from_module,
        names=[ast.alias(name='A', asname=None)], level=0)
    import_rewrites = [(from_module, to_module)]

    class BaseImportRewrite0(BaseImportRewrite):
        rewrites = import_rewrites

    base_import_rewrite_0 = BaseImportRewrite0(None)
    result = base_import_rewrite_0._replace_import_from_module(
        import_from, from_module, to_module)

    assert isinstance(result.body[0], ast.ImportFrom)
    assert from_module not in result.body[0].module

# Generated at 2022-06-25 22:00:27.019349
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('urllib2', 'urllib.request')
        ]
    import_node = ast.Import()
    transformer = Transformer(import_node)
    transformer.visit(import_node)



# Generated at 2022-06-25 22:00:34.754305
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from astor import codegen
    from typed_ast import ast3 as ast
    from numpy import inf
    #
    # Code
    #
    rn_0 = ast.ImportFrom(module='numpy', names=[ast.alias(name='inf', asname=None)], level=0)
    #
    # Unit test
    #
    import_rewrite_0 = BaseImportRewrite(tree=rn_0)
    import_rewrite_0.rewrites = [('numpy', 'numpy.ndarray')]
    rn_1 = import_rewrite_0.visit_ImportFrom(node=rn_0)

# Generated at 2022-06-25 22:00:40.194544
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class _(BaseImportRewrite):
        rewrites = [('typing', 'six')]

    source = """
    import typing
    """

    tree = ast.parse(source)
    _().transform(tree)

    expected = """
    try:
        import typing
    except ImportError:
        import six as typing
    """
    assert ast.dump(tree) == expected



# Generated at 2022-06-25 22:01:16.093555
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 22:01:28.785029
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    def test_0():
        """Test case for a base transformer without any rewrite"""
        base_transformer_0 = BaseImportRewrite()
        import_from_0 = ast.ImportFrom(
            module='abc',
            names=[ast.alias(
                name='abc',
                asname='abc')],
            level=0)
        t = base_transformer_0.visit_ImportFrom(import_from_0)
        assert t == import_from_0

    def test_1():
        """Test case for a transformer that replace import module abc to xyz"""
        class TestTransformer(BaseImportRewrite):
            rewrites = [('abc', 'xyz')]
        transformer_0 = TestTransformer()

# Generated at 2022-06-25 22:01:34.185156
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_program = "from foo import bar"

    tree = ast.parse(test_program)

    base_import_rewrite_0 = BaseImportRewrite(tree)
    node_0 = tree.body[0]

    base_import_rewrite_0.visit_ImportFrom(node_0)


# Generated at 2022-06-25 22:01:38.389099
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('''
    import os
    ''')
    b_i_r = BaseImportRewrite(tree)
    b_i_r.visit(tree)
    print(ast.dump(tree))
    # The following change is made:
    # ast.Import(names=[ast.alias(name='os', asname=None)])


# Generated at 2022-06-25 22:01:46.669926
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Arrange
    base_import_rewrite_0 = BaseImportRewrite()
    import_from_0 = ast.ImportFrom(
        module='',
        names=[
            ast.alias(
                name='',
                asname='')],
        level=1)

    # Act
    result = base_import_rewrite_0.visit_ImportFrom(import_from_0)

    # Assert
    assert type(result) is ast.ImportFrom



# Generated at 2022-06-25 22:01:54.534263
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from ast import parse
    from typed_ast import ast3 as ast

    class TestTransformer(BaseImportRewrite):
        rewrites = [
            # don't forget to add the . or the last token
            ('test_package', 'test_replacement.test_package'),
            ('test_package.test_module', 'test_replacement.test_package.test_module')
        ]

    test_code = '''
    from test_package.test_module import test_function
    '''
    expected_code = '''
    try:
        from test_package.test_module import test_function
    except ImportError:
        from test_replacement.test_package.test_module import test_function
    '''
    tree = parse(test_code)
    result = TestTransformer.transform

# Generated at 2022-06-25 22:02:05.620400
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ast import Import
    basic_tree = Import(names=[ast.alias(name='os',
                                         asname=None),
                               ast.alias(name='sys',
                                         asname='s')])
    transformer = BaseImportRewrite(basic_tree)
    assert transformer.visit_Import(basic_tree) == basic_tree
    assert transformer._tree_changed == False
    rewrote_tree = Import(names=[ast.alias(name='something',
                                           asname=None),
                                 ast.alias(name='else',
                                           asname='e')])
    transformer = BaseImportRewrite(rewrote_tree)
    transformer.rewrites = [("something", "os")]
    assert transformer.visit_Import(rewrote_tree) != rewrote_tree

# Generated at 2022-06-25 22:02:15.141486
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # First test
    alias_0 = alias(name = 'foo', asname = '(as)')
    alias_1 = alias(name = 'bar', asname = 'None')
    alias_list = [alias_0, alias_1]
    import_from = ImportFrom(module = 'foo.bar', names = alias_list, level = 0)
    instance = BaseImportRewrite(tree = import_from)
    instance._tree_changed = False
    instance.rewrites = [('foo.bar', 'foo.baz')]
    line_0 = instance.visit_ImportFrom(node = import_from)
    assert isinstance(line_0, Assignment) == False
    line_1 = instance._tree_changed
    assert line_1 == True
    line_2 = instance.dependencies
    assert line_2 == []

# Generated at 2022-06-25 22:02:23.707826
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test that ImportFrom node is unchanged when not in rewrites
    test_node = ast.ImportFrom(module='unittest', level=0, names=[ast.alias(name='TestCase', asname=None)])
    t = BaseImportRewrite(test_node)
    assert t.visit_ImportFrom(test_node) == test_node
    assert t._tree_changed is False

    # Test that case when module to import has changed
    test_node = ast.ImportFrom(module='builtins', level=0, names=[ast.alias(name='print', asname=None)])
    t = BaseImportRewrite(test_node)
    t.rewrites.append(('builtins', '__builtin__'))
    assert t.visit_ImportFrom(test_node) == ast.Try()

# Generated at 2022-06-25 22:02:29.684884
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Case 0: module name to replace is equal to 'foo'
    base_import_rewrite_0 = BaseImportRewrite()
    base_import_rewrite_0.rewrites = [('foo', 'bar')]
    import_ = ast.Import(
        names=[ast.alias(name='foo',
                         asname=None)])
    base_import_rewrite_0.visit_Import(import_)

    # Case 1: module name to replace is equal to 'foo.bar'
    base_import_rewrite_1 = BaseImportRewrite()
    base_import_rewrite_1.rewrites = [('foo.bar', 'bar.foo')]
    import_ = ast.Import(
        names=[ast.alias(name='foo.bar',
                         asname=None)])
    base_import_rew

# Generated at 2022-06-25 22:03:00.304895
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Input parameters for method visit_Import
    node_0 = ast.Import(names=[ast.alias(name='a', asname='a')])
    base_import_rewrite_0 = BaseImportRewrite(tree_0)
    node_0_result = base_import_rewrite_0.visit_Import(node_0)
    node_0_result_expected = ast.Import(names=[ast.alias(name='a', asname='a')])
    assert node_0_result == node_0_result_expected


# Generated at 2022-06-25 22:03:04.920774
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewrite_visit_Import(BaseImportRewrite):
        rewrites = [('django', 'flask')]

    tree = ast.parse("""
        import django

        something
    """)

    BaseImportRewrite_visit_Import.transform(tree)

    assert 'import django' not in ast.dump(tree)
    assert 'import flask' in ast.dump(tree)
    assert 'extend(django)' in ast.dump(tree)
    assert 'extend(flask)' in ast.dump(tree)



# Generated at 2022-06-25 22:03:10.054928
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    base_import_rewrite_0 = BaseImportRewrite(None)
    base_import_rewrite_0.rewrites = [(None, None)]
    base_import_rewrite_0._tree_changed = False
    alias_0 = ast.alias(name=None, asname=None)
    import_from_0 = ast.ImportFrom(module=None, names=[alias_0], level=None)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    # assert base_import_rewrite_0._tree_changed


# Generated at 2022-06-25 22:03:20.250927
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrite = [('os.path', 'pathlib.Path')]
    import_from = ast.ImportFrom(module='os.path', names=[ast.alias(name='abspath', asname='abspath')], level=0)
    class TestCase(BaseImportRewrite):
        rewrites = rewrite
    from_import = TestCase.get_instance().visit_ImportFrom(import_from)
    assert hasattr(from_import, 'body')
    assert hasattr(from_import, 'orelse')
    assert isinstance(from_import.body[0], ast.ImportFrom)
    assert isinstance(from_import.orelse[0], ast.ImportFrom)

# Generated at 2022-06-25 22:03:27.491987
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    node = ast.ImportFrom(module='py', names=[], level=0)
    base_import_rewrite_0 = BaseImportRewrite(node)
    assert isinstance(base_import_rewrite_0._replace_import_from_module(node, 'py', 'pya'), ast.Try) is True
    assert isinstance(base_import_rewrite_0._replace_import_from_names(node, {'py': ('py', 'pya'), 'py.b': ('py', 'pya')}), ast.Try) is True

# Generated at 2022-06-25 22:03:37.945870
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    from typed_ast import ast3 as ast
    from ast_transformer.transformer import BaseImportRewrite
    import_from_0 = ast.ImportFrom(
        module='typing',
        names=[
            ast.alias(name='Optional',
                      asname=None)],
        level=0)
    base_import_rewrite_0 = BaseImportRewrite(ast.Module(body=[import_from_0],
                                                         type_ignores=[]))
    rewrites = (('typing', 'my_typing'),)
    base_import_rewrite_0.rewrites = rewrites
    base_import_rewrite_0._tree_changed = False

# Generated at 2022-06-25 22:03:45.233437
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    namess = []
    ast_node_0 = ast.ImportFrom(module='', level=1)
    ast_node_0.names = []
    for name in namess:
        node_name = ast.alias(name='', asname='')
        ast_node_0.names.append(node_alias_0)
    ast_node_0.lineno = 0
    ast_node_0.col_offset = 0

    # Get an instance of the VisitTransformersForPython3.BaseImportRewrite class
    base_import_rewrite_0 = BaseImportRewrite()

    # Call the visit_ImportFrom() method
    node_0 = base_import_rewrite_0.visit_ImportFrom(ast_node_0)

    # Check if the call was successful
    assert node_0 and node_

# Generated at 2022-06-25 22:03:46.471751
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import(): 
    from .utils import test_case_0_0
    test_case_0_0()


# Generated at 2022-06-25 22:03:55.041854
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node_1 = ast.Import(names=[
        ast.alias(name='aiohttp',
                  asname=None)])

    node_2 = ast.Import(names=[
        ast.alias(name='aiohttp.client',
                  asname='client')])

    node_3 = ast.Import(names=[
        ast.alias(name='aiohttp.client_exceptions',
                  asname='ClientResponseError')])

    node_4 = ast.Import(names=[
        ast.alias(name='aiohttp.web',
                  asname='HttpBadRequest')])

    node_5 = ast.Import(names=[
        ast.alias(name='aiohttp.web_exceptions',
                  asname='HTTPException')])


# Generated at 2022-06-25 22:04:03.476550
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    from ..typed_ast import ast3 as typed_ast
    from ..typed_ast.ast3 import ast

    # Create AST for:
    # from six import unichr
    body = [typed_ast.ImportFrom(level=0, module='six', names=[typed_ast.alias(name='unichr', asname=None)], lineno=0, col_offset=0)]

    # Create AST for:
    # from typing import cast
    body.append(typed_ast.ImportFrom(level=0, module='typing', names=[typed_ast.alias(name='cast', asname=None)], lineno=0, col_offset=0))

    # Create AST for:
    # from typing import TYPE_CHECKING

# Generated at 2022-06-25 22:04:31.155105
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    source = """import a"""
    tree = ast.parse(source)

    instance = TestImportRewrite(tree)
    ast.fix_missing_locations(instance.visit(tree))

    expected_source = """try:
    import a
except ImportError:
    import b"""

    assert ast.dump(tree, include_attributes=False) == expected_source


# Generated at 2022-06-25 22:04:33.784857
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite = BaseImportRewrite()
    assert base_import_rewrite.visit_Import(ast.Import(names=[ast.alias(name='time', asname=None)])) == ast.Import(names=[ast.alias(name='time', asname=None)])


# Generated at 2022-06-25 22:04:39.856651
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test: Initializes an object of class BaseImportRewrite to check 
    # if it is of the correct type
    base_import_rewrite_0 = BaseImportRewrite()
    # Test: Check if the rewrites member of the class is of the correct type
    assert(isinstance(base_import_rewrite_0.rewrites, list))
    # Test: Check if the dependencies member of the class is of the correct type
    assert(isinstance(base_import_rewrite_0.dependencies, list))
    # Test: Check if the target member of the class is of the correct type
    assert(isinstance(base_import_rewrite_0.target, type(None)))


# Generated at 2022-06-25 22:04:46.308356
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast

    class TestCase(BaseImportRewrite):
        rewrites = [
            ('a', 'b'),
            ('c', 'd'),
        ]

        def _get_matched_rewrite(self, name: Optional[str]) -> Optional[Tuple[str, str]]:
            """Returns rewrite for module name."""
            if name is None:
                return None

            for from_, to in TestCase.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to

            return None

        def _replace_import_from_module(self, node: ast.ImportFrom, from_: str, to: str) -> ast.Try:
            """Replaces import from with try/except with old and new import module."""
           

# Generated at 2022-06-25 22:04:50.868188
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 22:04:54.684337
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    original_0 = ast.parse('import foo', '', 'single')
    instance_0 = BaseImportRewrite(original_0)
    modify_0 = ast.parse('import foo', '', 'single')
    instance_0.modify_0 = modify_0
    instance_0.depends_0 = []
    instance_0.rewrites_0 = []
    instance_0.visit(original_0)


# Generated at 2022-06-25 22:05:05.601070
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewrite(object):
        def visit_Import(self, node):
            return node
    base_import_rewrite_0 = BaseImportRewrite()
    ast_0 = ast.alias(name='', asname='')
    ast_1 = ast.alias(name='', asname='')
    ast_2 = ast.Import(names=[ast_0, ast_1])
    visit_Import_0 = base_import_rewrite_0.visit_Import(ast_2)
    assert visit_Import_0 == ast_2
    ast_3 = ast.alias(name='', asname='')
    ast_4 = ast.alias(name='', asname='')
    ast_5 = ast.Import(names=[ast_3, ast_4])
    visit_Import_1 = base

# Generated at 2022-06-25 22:05:17.329089
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # input arguments for the template
    input_arguments = [
        ast.ImportFrom(module='any_module',
                       names=[
                           ast.alias(name='*',
                                     asname=None),
                           ast.alias(name='any_name',
                                     asname=None),
                           ast.alias(name='any_name1',
                                     asname='any_asname1'),
                           ast.alias(name='any_name2',
                                     asname='any_asname2')],
                       level=0)]
    # end of input arguments
    for arg in input_arguments:
        # run the snippet
        instance = BaseImportRewrite(None)
        res = instance.visit_ImportFrom(arg)
        # assert the result
        assert(isinstance(res, ast.ImportFrom))

# Generated at 2022-06-25 22:05:22.205929
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_rewrite_0 = BaseImportRewrite()
    import_rewrite_1 = BaseImportRewrite()
    import_rewrite_2 = BaseImportRewrite()
    import_rewrite_3 = BaseImportRewrite()
    import_rewrite_4 = BaseImportRewrite()
    import_rewrite_5 = BaseImportRewrite()
    module_0 = ast.Module()

    try:
        node_0 = ast.Import(names=[ast.alias(name='abc', asname='abc')])
        import_rewrite_1.visit_Import(node_0)
    except:
        pass


# Generated at 2022-06-25 22:05:30.579316
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Define class BaseImportRewrite
    class BaseImportRewrite(BaseNodeTransformer):
        rewrites = []  # type: List[Tuple[str, str]]
        # Define method _get_matched_rewrite of class BaseImportRewrite
        def _get_matched_rewrite(self, name):  # type: (Optional[str]) -> Optional[Tuple[str, str]]
            """Returns rewrite for module name."""
            if name is None:
                return None
            for from_, to in self.rewrites:
                if name == from_ or name.startswith(from_ + '.'):
                    return from_, to
            return None
        # Define method _replace_import of class BaseImportRewrite

# Generated at 2022-06-25 22:06:02.205232
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_visitor = BaseImportRewrite()
    # initialize the BaseImportRewrite class
    module_visitor.rewrites = [] #initialize the rewrites list
    module_object = ast.Module() #create a new module object
    import_from_node = ast.ImportFrom(module='collections', names=[ast.alias(name='deque', asname=None)], level=0) #create an ImportFrom node
    module_object.body.append(import_from_node) #append the import from node to the module body
    # add the node to the tree
    module_visitor.visit(module_object) #visit the module object
    
    

# Generated at 2022-06-25 22:06:11.691343
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 22:06:18.298909
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # test missing rewrites
    assert BaseImportRewrite(ast.parse('''
from os import path
from sys import exit, stderr
from io import TextIOBase
''')).visit_ImportFrom(ast.parse('from io import TextIOBase').body[0]) == \
        ast.parse('''
from io import TextIOBase
''').body[0]

    # test: get_replaced_import_from_part
    assert BaseImportRewrite(ast.parse('''
from typing import Optional
'''))._get_replaced_import_from_part(
            ast.parse('from typing import Optional').body[0],
            ast.parse('from typing import Optional').body[0].names[0],
            dict()) == \
        ast.parse('from typing import Optional').body[0]

    #

# Generated at 2022-06-25 22:06:23.499967
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse('''
    from itertools import chain
    from collections import namedtuple
    ''')

    result = BaseImportRewrite.transform(tree)
    result_tree = ast.dump(result.tree)  # 'Module(body=[ImportFrom(module=\'itertools\', names=[alias(name=\'chain\', asname=None)], level=0), ImportFrom(module=\'collections\', names=[alias(name=\'namedtuple\', asname=None)], level=0)])'
    assert result_tree == ast.dump(tree)
    assert result.changed == False


# Generated at 2022-06-25 22:06:28.895469
# Unit test for method visit_ImportFrom of class BaseImportRewrite