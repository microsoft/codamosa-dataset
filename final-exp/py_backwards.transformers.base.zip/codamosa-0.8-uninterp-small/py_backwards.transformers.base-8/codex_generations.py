

# Generated at 2022-06-25 21:56:42.284713
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    import typed_ast.ast3 as ast
    s = 'import flask'
    tree = astor.parse_file(s)
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(tree)


# Generated at 2022-06-25 21:56:50.959212
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0 = module_0.AST()
    import_from_0 = a_s_t_0.ImportFrom(
        module='import_rewrite',
        names=[
            a_s_t_0.alias(
                name='previous',
                asname='current')])
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:56:59.080897
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0.body = [module_0.Import(module_0.alias())]
    base_import_rewrite_0.visit_Import(module_0.Import())
    a_s_t_0.body = [module_0.Import(module_0.alias(name=''))]
    base_import_rewrite_0.visit(module_0.Import())
    base_import_rewrite_0.visit(module_0.Import())
    base_import_rewrite_0.visit_TryExcept(module_0.TryExcept())

# Generated at 2022-06-25 21:57:03.983433
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.Import(names=module_0.alias(name="test", asname="test"))
    #This test is not working as the Before function is not called
    before_test_case_1 = module_0.Import(names=module_0.alias(name="test", asname="test"))
    after_case_1 = base_import_rewrite_0.visit_Import(before_test_case_1)
    assert after_case_1 == before_test_case_1


# Generated at 2022-06-25 21:57:09.174109
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    base_import_rewrite_0 = BaseImportRewrite(ast.AST())
    assert isinstance(base_import_rewrite_0.visit_ImportFrom(ast.ImportFrom(module=ast.Name(id="a", ctx=ast.Load()), names=[ast.alias(name="b", asname="c")], level=0)), ast.Try)


# Generated at 2022-06-25 21:57:12.745310
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_1 = module_0.Import()
    base_import_rewrite_0.visit_Import(import_1)


# Generated at 2022-06-25 21:57:15.239394
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 21:57:17.617858
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    node = ast.parse('import os').body[0]
    inst = BaseImportRewrite(None)
    assert inst.visit_ImportFrom(node) == node


# Generated at 2022-06-25 21:57:24.349706
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_alias_0 = module_0.alias('name', 'asname')

    import_1 = module_0.Import([import_alias_0])
    try_1 = module_0.Try(body=[import_alias_0], handlers=[], orelse=[], finalbody=[])
    assert try_1 in base_import_rewrite_0.visit_Import(import_1)


# Generated at 2022-06-25 21:57:31.924157
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module=str(),
                                        names=[module_0.alias(name=str(), asname=None)],
                                        level=int())
    try:
        base_import_rewrite_0.visit_ImportFrom(import_from_0)
    except Exception as exception_0:
        str_0 = exception_0
    str_1 = str(str_0)
    str_2 = str("Not implemented")
    assert str_1 == str_2

# Generated at 2022-06-25 21:57:40.476041
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse(
"""
import subprocess
"""
    )
    transformer = BaseImportRewrite()
    transformed = transformer.transform(tree)
    assert transformed.root == tree
    assert transformed.changed == False


# Generated at 2022-06-25 21:57:49.623937
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Test with missing attribute names
    try:
        base_import_rewrite_0_0 = BaseImportRewrite()
        base_import_rewrite_0_0.visit_Import()
        assert False
    except AssertionError:
        assert True
    except:
        assert False

    # Test with invalid attribute names_0 (type: str)
    try:
        base_import_rewrite_0_1 = BaseImportRewrite()
        base_import_rewrite_0_1.visit_Import('', )
        assert False
    except AssertionError:
        assert True
    except:
        assert False

    # Test with invalid attribute names_1 (type: str)

# Generated at 2022-06-25 21:57:52.069899
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_rewrite_0 = BaseImportRewrite()
    ast_import_0 = ast.parse("import re")[0]
    ast_try_0 = import_rewrite_0.visit_Import(ast_import_0)


# Generated at 2022-06-25 21:57:54.213372
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse('''import os''')
    tree = BaseImportRewrite.transform(tree).tree

    assert(type(tree.body[0]) == ast.Import)


# Generated at 2022-06-25 21:58:02.907931
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # 0 - Standard case
    # Code generator for the following snippet
    # import random
    from_, to = 'random', 'random_rewrite'
    node = ast.Import(names=[
        ast.alias(name='random',
                  asname='random')])
    node_rewrite = ast.Import(names=[
        ast.alias(name='random_rewrite',
                  asname='random')])
    rewrote = ast.Try(body=[
        node_rewrite],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[
            node])],
        orelse=[],
        finalbody=[])
    # Unit test

# Generated at 2022-06-25 21:58:11.951802
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # TEST CASE 0
    rewrites = [('django.db.models', 'django.contrib.gis.db.models')]
    expected_rewrote = [ast.ImportFrom(module='django.contrib.gis.db.models', names=[ast.alias(name='**', asname=None)], level=0)]
    import_from = ast.ImportFrom(module='django.db.models', names=[ast.alias(name='**', asname=None)], level=0)
    # TEST CASE 0 END

    # TEST CASE 1
    rewrites_1 = [('django.db.models', 'django.contrib.gis.db.models')]

# Generated at 2022-06-25 21:58:21.141769
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    source = 'from six.moves import xrange\nfrom six.moves import range\nfrom six import machine\nmachine.mul(a, b)'
    tree = astor.parse_file(source)

    class TestNodeTransformer(BaseImportRewrite):
        rewrites = [('six.moves', 'six')]

    tree = astor.parse_file(source)

    result = TestNodeTransformer().transform(tree)

    print(result[0])

    print(astor.dump_tree(result[0]))


# Generated at 2022-06-25 21:58:30.577975
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_simple = ast.ImportFrom(module="six",
                                   names=[ast.alias(name="foo")])
    import_as = ast.ImportFrom(module="six",
                               names=[ast.alias(name="foo", asname="bar")])
    import_relative = ast.ImportFrom(module="six",
                                     names=[ast.alias(name="foo")],
                                     level=1)
    import_as_relative = ast.ImportFrom(module="six",
                                        names=[ast.alias(name="foo", asname="bar")],
                                        level=1)


# Generated at 2022-06-25 21:58:38.087417
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    BaseImportRewrite_visit_ImportFrom_param_tree = ast.parse('import requests as req')
    BaseImportRewrite_visit_ImportFrom_param_rewrites = [('requests', 'urllib2')]
    BaseImportRewrite_visit_ImportFrom = BaseImportRewrite(BaseImportRewrite_visit_ImportFrom_param_tree)
    BaseImportRewrite_visit_ImportFrom.rewrites = BaseImportRewrite_visit_ImportFrom_param_rewrites
    BaseImportRewrite_visit_ImportFrom_return = BaseImportRewrite_visit_ImportFrom.visit_Import(BaseImportRewrite_visit_ImportFrom_param_tree.body[0])
    assert isinstance(BaseImportRewrite_visit_ImportFrom_return, ast.Try)
    assert BaseImportRewrite

# Generated at 2022-06-25 21:58:46.052723
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    ast_0 = ast.parse(
        "import json\n"
    )
    expected_0 = ast.parse(
        "try:\n"
        "    import json\n"
        "except ImportError:\n"
        "    import json as json"
    )
    actual_0 = base_import_rewrite_0.visit(ast_0)
    actual_0 = ast.fix_missing_locations(actual_0)
    assert ast.dump(actual_0) == ast.dump(expected_0)


# Generated at 2022-06-25 21:59:03.812573
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite.__new__(BaseImportRewrite)
    node = ast.parse("import foo.bar as baz")
    base_import_rewrite_0 = NodeVisitor.__init__(base_import_rewrite_0, )
    assert BaseImportRewrite.visit_Import(base_import_rewrite_0, node, ) == ast.Try(body=list(ast.Import(names=list(ast.alias(name="foo.bar.baz", asname="baz")))), handlers=list(ast.ExceptHandler(type=ast.Name(id="ImportError", ctx=ast.Store()), name=None, body=list(ast.Import(names=list(ast.alias(name="foo.bar", asname="baz")))))))

# Unit test

# Generated at 2022-06-25 21:59:10.337921
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    assert not base_import_rewrite_0.visit_Import(ast.Import(names=[ast.alias(name='foo',
                                                                              asname=None)]))


# Generated at 2022-06-25 21:59:16.720110
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    transformer = BaseImportRewrite()
    tree = ast.parse("""import a as aa; from b import *; from c import d""")
    transformer.visit(tree)
    assert ast.dump(tree) == "Module(body=[Import(names=[alias(name='a', asname='aa')]), ImportFrom(module='b', names=[alias(name='*', asname=None)], level=0), ImportFrom(module='c', names=[alias(name='d', asname=None)], level=0)])"


# Generated at 2022-06-25 21:59:23.984846
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class ImportRewrite(BaseImportRewrite):
        rewrites = [('a', 'b')]

    tree = ast.parse("from a import a")
    transformer = ImportRewrite(tree)
    transformer.visit(tree)
    assert transformer._tree_changed == False
    tree = ast.parse("import a")
    transformer = ImportRewrite(tree)
    transformer.visit(tree)
    assert transformer._tree_changed == False
    tree = ast.parse("from a import b")
    transformer = ImportRewrite(tree)
    transformer.visit(tree)
    assert transformer._tree_changed == True


# Generated at 2022-06-25 21:59:27.467790
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    actual_result = ast.parse('from collections import Counter, defaultdict').body
    expected_result = ast.parse('from collections import Counter, defaultdict').body
    t = BaseImportRewrite(None)
    t.visit_ImportFrom(actual_result[0])
    assert expected_result == actual_result


# Generated at 2022-06-25 21:59:31.819788
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import ImportFrom
    base_import_rewrite_0 = BaseImportRewrite(None)
    base_import_rewrite_0.rewrites = [(('testcase0', 'testcase1'),)]
    base_import_rewrite_0._tree_changed = bool()
    import_from_0 = ImportFrom(names=[], module='testcase0.testcase2')
    try_0 = try_(body=[import_from_0])
    assert(base_import_rewrite_0.visit_ImportFrom(import_from_0) == try_0)

# Generated at 2022-06-25 21:59:41.546825
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # TODO(demidovich): fix types.
    import six
    import astor
    # import typed_ast
    # import typed_ast.ast3 as ast
    # import typing
    # import typing_extensions
    # import abc
    # import typing_extensions.abc

    test_case_0_import_from_0 = ast.ImportFrom(
        module='abc',
        names=[ast.alias(name='ABC',
                         asname=None)],
        level=0)

    test_case_0 = BaseImportRewrite()

    test_case_0.visit(test_case_0_import_from_0)

    # assert astor.to_source(test_case_0_import_from_0) == 'from abc import ABC\n'

    test_case_0_visit

# Generated at 2022-06-25 21:59:45.779811
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    ast_node_0 = ast.Import(names=[ast.alias(name='test', asname=None)])
    base_import_rewrite_0.visit_Import(ast_node_0)


# Generated at 2022-06-25 21:59:46.934341
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO: Add test for this method
    pass


# Generated at 2022-06-25 21:59:49.901555
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    with pytest.raises(TypeError):
        import_0 = ast.Import(names=[])
        base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:02.225704
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom('', [], 0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)
    assert base_import_rewrite_0._tree_changed == False


# Generated at 2022-06-25 22:00:08.336691
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    rewrites_0 = []
    base_import_rewrite_0.rewrites = rewrites_0
    a_s_t_1 = module_0.AST()
    import_0 = module_0.Import(names=(a_s_t_1,))
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:14.458935
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module0 = module_0
    a_s_t0 = module0.AST()
    base_import_rewrite0 = BaseImportRewrite(a_s_t0)
    module1 = module_0
    import_from0 = module1.ImportFrom(
        module='abstractmethod',
        names=[
            module1.alias(
                name='gofish',
                asname=None)],
        level=None)
    a_s_t1 = module0.AST()
    assert isinstance(base_import_rewrite0.visit_ImportFrom(import_from0), module1.ImportFrom)
    



# Generated at 2022-06-25 22:00:22.684706
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('mock')]
    i_m_p_o_r_t_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_1.rewrites = {'1': ('')}
    i_m_p_o_r_t_0 = module_0.Import()
    a_s_t_0 = module

# Generated at 2022-06-25 22:00:25.651162
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

import ast as module_1


# Generated at 2022-06-25 22:00:30.455176
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[])
    union_0_0 = base_import_rewrite_0.visit_Import(import_0)
    assert isinstance(union_0_0, module_0.Import)
    assert isinstance(union_0_0, module_0.Try)


# Generated at 2022-06-25 22:00:32.317557
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    try:
        pass
    except BaseException as ex:
        assert False, 'AssertionError: ' + str(ex)


# Generated at 2022-06-25 22:00:41.052808
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import([module_0.alias(name='abc', asname=None)], lineno=0, col_offset=0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_1._get_matched_rewrite = lambda name: ('abc', 'def')
    try_0 = base_import_rewrite_1._replace_import(import_0, 'abc', 'def')
    try_1 = base_import_rewrite_0.vis

# Generated at 2022-06-25 22:00:48.126404
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Setup
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node = None # Default value should be set to None

    # Invoke method with arguments
    actual_result = base_import_rewrite_0.visit_ImportFrom(node)

    # Assertion
    assert actual_result is None, "Expected None but got %s" % actual_result


# Generated at 2022-06-25 22:00:53.487476
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class TestCase(BaseImportRewrite):
        def __init__(self):
            TestCase._tree_changed = False
        rewrites = [(None, None)]

    a_s_t_0 = ast.parse("import package")
    base_import_rewrite_0 = TestCase()
    base_import_rewrite_0.visit(a_s_t_0)
    assert not (not TestCase._tree_changed)

test_BaseImportRewrite_visit_Import()


# Generated at 2022-06-25 22:01:09.471738
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(name='tensorflow', asname='tf')
    import_0 = module_0.Import(names=[alias_0])
    mod = import_rewrite.get_module()
    try:
        mod.extend(import_0)
        try:
            mod.extend(base_import_rewrite_0)
        except ImportError:
            pass
    except ImportError:
        pass


# Generated at 2022-06-25 22:01:16.248397
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astunparse

    class Test0(BaseImportRewrite):
        rewrites = [('os', 'typed_ast.os')]

    expected_0 = astunparse.unparse(ast.parse(
        """
        from typed_ast.os import name as os_name
        """))

    tree_0 = ast.parse(
        """
        from os import name
        """
    )
    test_0 = Test0(tree_0)
    result_0 = test_0.visit(tree_0)

    assert astunparse.unparse(result_0) == expected_0

    expected_1 = astunparse.unparse(ast.parse(
        """
        try:
            from os import name
        except ImportError:
            from typed_ast.os import name
        """))

    tree

# Generated at 2022-06-25 22:01:29.045047
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import logging
    from unittest import mock
    from pytype_extensions import NonStrictDefaultArg, DefaultArg

    input_1 = [DefaultArg(typed_ast.ast3.ImportFrom),DefaultArg(str),DefaultArg(str)]


# Generated at 2022-06-25 22:01:33.743847
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 22:01:43.252036
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0 = 0
    a_s_t_1 = module_0.Call(func=1, args=2, keywords=3, starargs=4, kwargs=5)
    base_import_rewrite_0.visit_Call(a_s_t_1)
    a_s_t_1 = 0
    a_s_t_2 = module_0.alias(name=6, asname=7)
    base_import_rewrite_0.visit_alias(a_s_t_2)
    a_s_t_2 = 0
    a_s_t_3 = module_0.Ass

# Generated at 2022-06-25 22:01:50.740853
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    a_s_t_0.body.append(module_0.Import(names=[module_0.alias(name='typing', asname=None)]))
    result = base_import_rewrite_0.visit_Import(a_s_t_0.body[0])


# Generated at 2022-06-25 22:01:56.538308
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_1 = module_0.transformer.ParentNodeTransformer(a_s_t_1)

    class TempNodeTransformer(module_0.transformer.ParentNodeTransformer):
        def __init__(self, tree):
            pass
    temp_node_transformer_0 = TempNodeTransformer(a_s_t_1)

    rewrites = [('foo', 'bar')]
    base_import_rewrite_0.rewrites = rewrites

# Generated at 2022-06-25 22:01:58.052875
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

# Generated at 2022-06-25 22:02:03.705982
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='future', names=[module_0.alias(name='import_function', asname='import_function')], level=0)
    import_from_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert(import_from_0.module == 'future')
    assert(import_from_0.names[0].name == 'import_function')
    assert(import_from_0.names[0].asname == 'import_function')
    assert(import_from_0.level == 0)


# Generated at 2022-06-25 22:02:05.981799
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Call the function to execute the code for test
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:02:36.559633
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom('module', [module_0.alias('name', 'name')], 0)
    try:
        base_import_rewrite_0._replace_import_from_module(i_m_p_o_r_t_f_r_o_m_0, 'from_', 'to')
    except ImportError:
        i_m_p_o_r_t_f_r_o_m_2 = module_0.ImportFrom('module', [module_0.alias('name', 'name')], 0)


# Generated at 2022-06-25 22:02:42.120424
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import defusedxml.ElementTree as module_defusedxml_ElementTree
    a_s_t_0 = module_defusedxml_ElementTree.parse('').getroot()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import xml.etree.ElementTree as module_xml_etree_ElementTree
    a_s_t_1 = module_xml_etree_ElementTree.Element('')
    try:
        extend(a_s_t_1)
    except ImportError:
        extend(a_s_t_1)


# Generated at 2022-06-25 22:02:48.424061
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_1 = module_0.Import([module_0.alias(name='typed_ast.ast3', asname='None')], lineno=0, col_offset=0)
    i_m_p_l_t_2 = base_import_rewrite_0.visit_Import(import_1)

# Generated at 2022-06-25 22:02:48.843300
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert False

# Generated at 2022-06-25 22:02:56.583766
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from .imports_rewrite_data import test_cases_0, test_expectations_0
    from .imports_rewrite_data import test_cases_1, test_expectations_1
    for test_case_0, test_case_1, test_expectation_0, test_expectation_1 in zip(test_cases_0, test_cases_1, test_expectations_0, test_expectations_1):
        a_s_t_0 = module_0.AST()
        base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
        base_import_rewrite_0.rewrites = [(test_case_0, test_case_1)]

# Generated at 2022-06-25 22:03:01.597699
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='a', names=[module_0.alias()])
    union_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(union_0, module_0.ImportFrom)


# Generated at 2022-06-25 22:03:08.584091
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    module_name_0 = 'import_rewrite'
    alias_name_0 = 'some_new_thing'
    alias_0 = module_0.alias(alias_name_0, None)
    names_0 = [alias_0]
    level_0 = 1
    import_from_0 = module_0.ImportFrom(module_name_0, names_0, level_0)
    module_0_0 = 'typed_ast'
    module_0_1 = 'typed_ast.typeshed'
    rewrites_0 = [(module_0_0, module_0_1)]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rew

# Generated at 2022-06-25 22:03:13.853931
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = []
    i_m_p_0 = ast.Import(names=[ast.alias(name='builtins', asname='__builtin__')])
    base_import_rewrite_0.visit_Import(i_m_p_0)
    return i_m_p_0


# Generated at 2022-06-25 22:03:22.868353
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0_0 = module_0.alias()
    alias_0_0.name = "a"
    alias_0_1 = module_0.alias()
    alias_0_1.name = "b"
    alias_0_1.asname = "c"
    alias_0_2 = module_0.alias()
    alias_0_2.name = "d"
    alias_0_2.asname = "e"
    alias_0_3 = module_0.alias()
    alias_0_3.name = "f"
    alias_0_4 = module_0.alias()

# Generated at 2022-06-25 22:03:25.068635
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # TODO: improve tests

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert base_import_rewrite_0 is not None

# Generated at 2022-06-25 22:04:20.046847
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import collections
    import_0 = ast.Import(names=[
    ast.alias(name='collections',
    asname=None)])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [
    ('collections', 'typed_collections')]
    union_0 = base_import_rewrite_0.visit_Import(import_0)
    assert isinstance(union_0, ast.Try)


# Generated at 2022-06-25 22:04:24.842151
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.ImportFrom(names=(module_0.alias(name='ast3', asname=None),), module='typed_ast')
    base_import_rewrite_0.visit_ImportFrom(node_0)
    return bool(base_import_rewrite_0._tree_changed)


# Generated at 2022-06-25 22:04:29.291409
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    names_0 = [ast.alias(name="os", asname=None)]
    node_0 = ast.Import(names=names_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(node_0)


# Generated at 2022-06-25 22:04:35.520156
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_imp_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name='a', asname='a')
    l_s_t_s_0 = [a_l_i_a_s_0]
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(module='a', names=l_s_t_s_0, level=0, lineno=0, col_offset=0)
    a_s_t_1 = base_imp_0.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)

# Generated at 2022-06-25 22:04:39.254049
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    import_from_2 = module_0.ImportFrom(module='sys', level=0)
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    try_3 = base_import_rewrite_1.visit_ImportFrom(import_from_2)

# Generated at 2022-06-25 22:04:43.122391
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    if (True):
        rewrote_module_0 = ""  # type: String
        rewrote_0 = module_0.ImportFrom(module=rewrote_module_0, names=[], level=0)

        base_import_rewrite_0.visit_ImportFrom(rewrote_0)

# Generated at 2022-06-25 22:04:47.496055
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_1.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=None, module='A', names=[], lineno=None, col_offset=None)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)



# Generated at 2022-06-25 22:04:53.875236
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a = ast.Import(names=[ast.alias(name='os.path', asname='path')])
    b = ast.ImportFrom(module='os.path', names=[ast.alias(name='path')], level=0)
    c = ast.ImportFrom(module='os.path', names=[ast.alias(name='path', asname='path')], level=0)
    d = ast.ImportFrom(module='os.path', names=[ast.alias(name='name')], level=0)
    e = ast.ImportFrom(module='os.path', names=[ast.alias(name='name', asname='name')], level=0)
    f = ast.ImportFrom(module='os', names=[ast.alias(name='path')], level=0)

# Generated at 2022-06-25 22:05:01.534581
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias('typed_ast', 'typed_ast')
    import_from_0 = module_0.ImportFrom('typed_ast', [alias_0], 0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:05:11.147772
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    alias_0 = module_0.alias()
    alias_1 = module_0.alias()
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(
        module='pylint.reporters.text', 
        names=[
            alias_0, 
            alias_1, 
        ], 
        level=0, 
    )

    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)