

# Generated at 2022-06-25 21:56:52.293729
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    class BaseImportRewriteSubclass(BaseImportRewrite):
        rewrites = [('pathlib', 'os.path')]

    import_from_1 = ast.ImportFrom(level=0, module='pathlib', names=[ast.alias(name='Path', asname=None)])
    import_from_2 = ast.ImportFrom(level=0, module='os.path', names=[ast.alias(name='Path', asname=None)])
    transform_result = BaseImportRewriteSubclass.transform(import_from_1)
    # print('Transformed:')
    # print(astor.to_source(transform_result.tree))
    assert astor.to_source(transform_result.tree) == astor.to_source(import_from_2)


# Generated at 2022-06-25 21:57:01.061848
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 21:57:10.283892
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class _Transformer(BaseImportRewrite):
        rewrites = [('a', 'b')]

    class _Transformer2(BaseImportRewrite):
        rewrites = [('foo', 'bar')]

    class _Transformer3(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.toto')]

    class _Transformer4(BaseImportRewrite):
        rewrites = [('foo.bar', 'foo.toto')]

    # No rewrite
    no_rewrite = ast.Import(names=[
        ast.alias(name='foo',
                  asname='bar')])
    assert _Transformer.transform(no_rewrite).tree == no_rewrite

# Generated at 2022-06-25 21:57:19.301318
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    """Test for method visit_Import of class BaseImportRewrite"""
    from typed_ast.ast3 import parse
    from ..utils.source_generation.import_ import import_from_module
    import_1 = import_from_module('typed_ast', '*')
    tree = parse(import_1.source)
    rewriter_0 = BaseImportRewrite.__new__(BaseImportRewrite)
    rewrites_0 = []
    rewriter_0.rewrites = rewrites_0
    tree_0 = rewriter_0.visit(tree)
    assert tree_0
    import_from_module_0 = BaseImportRewrite()
    rewrites_1 = []
    import_from_module_0.rewrites = rewrites_1

# Generated at 2022-06-25 21:57:28.191516
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import collections
    import collections.abc as _collections_abc
    import _weakref as _weakref
    import builtins
    import sys as _sys
    import _thread as _thread
    import _dummy_thread as _dummy_thread
    import threading
    import _threading_local as _threading_local
    import _io as _io
    import errno
    import _socket as _socket
    import _ssl as _ssl
    import socket
    import select as _select
    import _selectors as _selectors
    import datetime as _datetime
    import time
    import _posixsubprocess as _posixsubprocess
    import builtins as __builtin__
    import _weakrefset as _weakrefset
    import atexit as _atexit
    import _signal as _signal

# Generated at 2022-06-25 21:57:32.576344
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    node_list = ast.parse("import importlib; importlib.find_loader('a')").body
    ast.fix_missing_locations(node_list)
    assert len(node_list) == 1
    assert isinstance(node_list[0], ast.Import)
    BaseImportRewrite().visit_Import(node_list[0])



# Generated at 2022-06-25 21:57:39.834820
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    astor.code_gen.SourceGenerator.tabsize = 2

    class TestTransformer(BaseImportRewrite):
        rewrites = [('some_module', 'another')]

    source = 'import some_module'

    tree = ast.parse(source)
    test_transformer = TestTransformer(tree)
    test_transformer.visit_Import(tree.body[0])

    assert astor.to_source(tree) == (
        'try:\n'
        '  import some_module\n'
        'except ImportError:\n'
        '  import another\n'
    )


# Generated at 2022-06-25 21:57:45.047230
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    rewrites = [('six', 'typed_astunparse')]
    class BaseImportRewrite_0(BaseImportRewrite):
        rewrites = rewrites
    base_import_rewrite_0 = BaseImportRewrite_0(ast.AST())
    assert False



# Generated at 2022-06-25 21:57:51.822668
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite = BaseImportRewrite()
    base_import_rewrite._tree_changed = True
    
    import_module_0 = ast.Import([ast.alias(name="a")])
    base_import_rewrite._get_matched_rewrite = lambda x: ("a", "a")
    base_import_rewrite._replace_import = lambda x, y, z: ast.Try(ast.Excepthandler(type=ast.Name(id="abc", ctx=ast.Load())), ast.stmt([ast.Import([ast.alias(name="a")])]), [], None)
    
    base_import_rewrite.visit_Import(import_module_0)


# Generated at 2022-06-25 21:57:53.926611
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typed_ast import ast3 as ast
    tree = ast.parse('import math')

    import_rewrite_0 = BaseImportRewrite(tree)
    import_rewrite_1 = BaseNodeTransformer.visit_Import.__get__(import_rewrite_0, BaseImportRewrite)
    import_rewrite_1(tree.body[0])


# Generated at 2022-06-25 21:58:05.623739
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import()
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 21:58:14.757338
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import([module_0.alias(name='a')])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert var_0 == import_0

import_from_0 = module_0.ImportFrom(module='1', names=[module_0.alias(name='a')])
a_s_t_0 = module_0.AST()
base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
var_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:58:20.388421
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        var_0 = base_import_rewrite_0.visit_Import(import_0)
    except:
        assert False

import_from_0 = module_0.ImportFrom()


# Generated at 2022-06-25 21:58:25.054750
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 21:58:34.211825
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_cases import test_case_0
    import unittest

    class TestVisitImport(unittest.TestCase):
        @unittest.mock.patch('typed_ast._ast3.AST')
        def test_method_visit_Import_with_parameter_node__should_return_None(self, mock_AST):
            import_0 = module_0.Import()
            a_s_t_0 = module_0.AST()
            base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
            var_0 = base_import_rewrite_0.visit_Import(import_0)

            mock_AST.assert_called_once()
            self.assertIsNone(var_0)

    test_case_0()

# Generated at 2022-06-25 21:58:37.908754
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    instance = BaseImportRewrite
    instance.rewrites = []
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:46.479353
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


import_1 = module_0.Import()
a_s_t_1 = module_0.AST()
base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
var_1 = base_import_rewrite_1.visit_Import(import_1)


# Generated at 2022-06-25 21:58:52.875482
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    model = {}

    import_0 = ast.Import()
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert type(var_0) == ast.Import


# Generated at 2022-06-25 21:58:59.349941
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        var_0 = base_import_rewrite_0._get_matched_rewrite(import_0.names[0].name)
    except SystemError:
        pass
    except Exception as exc_0:
        print((type(exc_0),))
    try:
        import_0.names.append(module_0.alias(name='module_0', asname='module_0'))
        var_0 = base_import_rewrite_0._get_matched_rewrite(import_0.names[0].name)
    except SystemError:
        pass

# Generated at 2022-06-25 21:59:04.182112
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import()
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:39.442280
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)



# Generated at 2022-06-25 21:59:44.119847
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    return var_0


# Generated at 2022-06-25 21:59:48.040654
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    print(var_0)

# Generated at 2022-06-25 21:59:55.411469
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from .test_context import test_context
    
    # Setup
    import_0 = module_0.Import()
    
    # Target
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    
    # Assertion
    test_context.assert_equals(var_0, import_0)

import_from_0 = module_0.ImportFrom(level=None, module='a.b.c', names=[module_0.alias(name='d', asname=None)])


# Generated at 2022-06-25 22:00:05.121077
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    class BaseImportRewrite_0(BaseImportRewrite):
        rewrites = [('from_0', 'to_1')]
        pass
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite_0(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

# Generated at 2022-06-25 22:00:12.374636
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    var_1 = isinstance(var_0, module_0.Import)
    var_2 = isinstance(var_0, module_0.Try)
    var_3 = base_import_rewrite_0._tree_changed
    
    assert var_1 is not False
    assert var_2 is not True
    assert var_3 is False


# Generated at 2022-06-25 22:00:16.300670
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Setup
    import_from_0 = module_0.ImportFrom()
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    # Procedure call
    var_0 = base_import_rewrite_1.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:22.101093
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert base_import_rewrite_0.visit_Import(import_0) == import_0

import_from_0 = module_0.ImportFrom(module='import_from', names=[module_0.alias(name='name')], level=0)


# Generated at 2022-06-25 22:00:25.869247
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_1 = module_0.Import()
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    var_1 = base_import_rewrite_1.visit_Import(import_1)


# Generated at 2022-06-25 22:00:30.063552
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

if __name__ == '__main__':
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:01:12.969848
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_1 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:23.915341
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

    assert( var_0 == import_0 )

import_1 = module_0.Import()
a_s_t_1 = module_0.AST()
base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
var_1 = base_import_rewrite_1.visit_Import(import_1)


# Generated at 2022-06-25 22:01:28.707248
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:34.151482
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:38.662472
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    expected_1 = module_0.Try()
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert expected_1 == var_0


# Generated at 2022-06-25 22:01:47.001558
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    # assert for expected output with expected type
    assert isinstance(var_0, module_0._ast3.Import)
    assert var_0.names == []


# Generated at 2022-06-25 22:01:48.424576
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:01:52.964972
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:01:55.461035
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_0)

# Generated at 2022-06-25 22:02:02.381311
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = module_0
    import_from_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    
    assert var_0 is import_from_0


# Generated at 2022-06-25 22:03:33.746716
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0 = module_0
    from_0 = from_0
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:41.381591
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typing import Dict
    import typed_ast._ast3 as module_0
    import_from_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0.names = [
        module_0.alias.alias(
            name=None,
            asname=None,
        ),
    ]
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

if __name__ == '__main__':
    test_case_0()
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:03:44.381753
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:49.774721
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert var_0 is import_0

import_from_0 = module_0.ImportFrom(level=0, module='importFrom')

# Generated at 2022-06-25 22:03:52.917405
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    assert var_0 is None

# Generated at 2022-06-25 22:03:56.569071
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:03:59.991239
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)

# Generated at 2022-06-25 22:04:03.727183
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_ImportFrom(import_0)

# Generated at 2022-06-25 22:04:08.253709
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)



# Generated at 2022-06-25 22:04:13.518138
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    result = base_import_rewrite_0.visit_Import(import_0)
    return result

import_from_0 = module_0.ImportFrom()


# Generated at 2022-06-25 22:06:24.652622
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    var_0 = base_import_rewrite_0.visit_Import(import_0)
    pass

import typed_ast._ast3 as module_1
