

# Generated at 2022-06-25 21:56:55.627925
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_tree = ast.parse('''
from six import iteritems
from six.moves import urllib
s = ''
''')
    transformer = BaseImportRewrite(test_tree)
    transformer.rewrites = [
        ('six.moves.urllib', 'six.moves.urllib.parse'),
    ]
    inst = transformer.visit_Import(test_tree.body[0])
    assert isinstance(inst, ast.Try)


# Generated at 2022-06-25 21:57:01.026583
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # type: () -> None
    import_0 = ast.Import(names=[ast.alias(name='pkg',
                                           asname=None)])

    class BaseImportRewrite_0(BaseImportRewrite):
        rewrites = [('pkg', 'new_pkg')]

    BaseImportRewrite_0.transform(import_0)



# Generated at 2022-06-25 21:57:01.533979
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass

# Generated at 2022-06-25 21:57:07.950004
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import(names=[
        ast.alias(name='future', asname=None)])
    base_import_rewrite_0 = BaseImportRewrite(import_0)
    base_import_rewrite_0.rewrites = [('future', 'past')]
    try:
        base_import_rewrite_0.visit(import_0)
    except ImportError:
        pass
    base_import_rewrite_0.visit(import_0)


# Generated at 2022-06-25 21:57:10.818658
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite()
    import_node = ast.parse('import __module_name__')
    assert base_import_rewrite_0.visit(import_node) == import_node


# Generated at 2022-06-25 21:57:18.347075
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    target_func = BaseImportRewrite().visit_Import
    tree = ast.parse('import typing')
    target_func(tree.body[0])

    src_0 = """
try:
    import typing
except ImportError:
    import typing
"""
    dst_0 = ast.parse(src_0)
    assert(target_func(dst_0.body[0]) == dst_0.body[0].body[1].body[0])

    src_1 = """
import datetime
"""
    dst_1 = ast.parse(src_1)
    assert(target_func(dst_1.body[0]) == dst_1.body[0])


# Generated at 2022-06-25 21:57:23.318934
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite_0 = BaseImportRewrite(None)
    ast_import_0 = ast.Import([ast.alias(name="codecs")])
    ast_import_1 = base_import_rewrite_0.visit_Import(ast_import_0)
    assert isinstance(ast_import_1, ast.Import)
    assert ast_import_1.names[0].name == 'codecs'


# Generated at 2022-06-25 21:57:29.935862
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    base_import_rewrite = BaseImportRewrite()
    base_import_rewrite.rewrites = [('a', 'b')]
    base_import_rewrite._tree_changed = False
    node = ast.Import(names=[ast.alias(name='a',
                                       asname=None)])
    try:
        base_import_rewrite.visit_Import(node)
    except:
        assert False, "visit_Import's try block failed"
    else:
        assert True, "visit_Import's try block succeeded"


# Generated at 2022-06-25 21:57:39.076499
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    import ast
    import sys
    class TestTransformer(BaseImportRewrite):
        rewrites = [('some.lib', 'other.lib')]
    code = "import some.lib\nimport other.lib\n"
    tree = astor.parse_file(code)
    transformer = TestTransformer(tree)
    res = transformer.visit(tree)
    expected_result = """\
try:
    import some.lib as lib
except ImportError:
    import other.lib as lib
"""
    assert astor.to_source(res) == expected_result

if __name__ == "__main__":
    import astor
    import ast
    import sys
    class TestTransformer(BaseImportRewrite):
        rewrites = [('some.lib', 'other.lib')]

# Generated at 2022-06-25 21:57:42.663948
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse("from future import print_function", "<test>", "exec")

    import_rewrite_0 = BaseImportRewrite()
    import_rewrite_0.visit_ImportFrom(tree.body[0])

# Generated at 2022-06-25 21:57:52.239194
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    i_m_p_o_r_t_0 = module_0.Import(names= [module_0.alias(name= '', asname= '')])
    base_import_rewrite_0.visit_Import(i_m_p_o_r_t_0)


# Generated at 2022-06-25 21:58:00.121960
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Initialization
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    import_from_0.names = ['1']

    base_import_rewrite_0.rewrites = [(0, 1), ('0', 1)]

    # Method call
    test_result_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)

    # Asserts
    assert import_rewrite.get_body(previous=import_from_0, current=import_from_0)[0] == test_result_0



# Generated at 2022-06-25 21:58:05.025241
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Input parameters
    a_s_t_1 = module_0.ImportFrom()
    # Output parameters
    _IMPORT_FROM_0 = a_s_t_1
    base_import_rewrite_0.visit_ImportFrom(_IMPORT_FROM_0)


# Generated at 2022-06-25 21:58:10.231820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=42, module='foo.bar', names=[])
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:58:15.622977
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.Import()
    node_0.names = [module_0.alias()]
    node_0.names[0].name = "dill"
    node_0.names[0].asname = "dill"
    base_import_rewrite_0.visit_Import(node_0)


# Generated at 2022-06-25 21:58:19.828653
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    try:
        base_import_rewrite_0.visit_ImportFrom(import_from_0)
    except Exception:
        pass


# Generated at 2022-06-25 21:58:29.959780
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = sys.modules[__name__]
    try:
        del module_0.__dict__["test_case_0"]
    except KeyError:
        pass
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    rewrites = [
        ('a.b', 'c.d')
    ]

    class Rewriter(BaseImportRewrite):
        rewrites = rewrites

    a = ast.ImportFrom(module='a.b',
                       names=[
                           ast.alias(name='w')
                       ],
                       level=0)

    rewriter = Rewriter(a)
    try_node = rewriter.visit(a)

# Generated at 2022-06-25 21:58:37.680632
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    c_l_a_s_s_0 = BaseImportRewrite.__dict__['visit_ImportFrom']
    if c_l_a_s_s_0 != BaseImportRewrite.__dict__['visit_ImportFrom']:
        c_l_a_s_s_0.__name__ = BaseImportRewrite.__dict__['visit_ImportFrom'].__name__

    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 21:58:47.379153
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = mock.Mock(spec=typed_ast._ast3.AST)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    type(base_import_rewrite_0).rewrites = mock.PropertyMock(return_value=[])
    type(base_import_rewrite_0)._get_matched_rewrite = mock.Mock(return_value=None)
    a_s_t_1 = mock.Mock(spec=typed_ast._ast3.Import)
    ret_val_0 = base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 21:58:54.954967
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    impo_0 = module_0.ImportFrom(0, "1", [2], 3)
    ret_0 = base_import_rewrite_0.visit_ImportFrom(impo_0)
    assert isinstance(ret_0, module_0.ImportFrom)
    assert ret_0 == impo_0

# Generated at 2022-06-25 21:59:13.808561
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_1 = module_0.Import((module_0.alias(name='test_BaseImportRewrite', asname=None),))
    union_0 = base_import_rewrite_0.visit_Import(import_1)


# Generated at 2022-06-25 21:59:22.366744
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # Call function '_get_matched_rewrite' of class BaseImportRewrite
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_1 = module_0.ImportFrom([""], 1, False, False)
    function_2 = base_import_rewrite_0._get_matched_rewrite(node_1)

    # Call function '_get_names_to_replace' of class BaseImportRewrite
    a_s_t_3 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_3)
    node_4 = module_0.ImportFrom([""], 1, False, False)
    function_5 = base_import_rew

# Generated at 2022-06-25 21:59:29.415318
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[module_0.alias(name='os',asname='os')])
    base_import_rewrite_1 = BaseImportRewrite.visit_Import(base_import_rewrite_0, import_0)
    assert re.match("^try\\:\\n    import os\\nexcept ImportError\\:\\n    import os as os\\n$", base_import_rewrite_1.body[0].body[0].s)


# Generated at 2022-06-25 21:59:38.684403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.Import(names=[
        ast.alias(name='lxml',
                  asname=None)])
    a_s_t_2 = ast.Import(names=[
        ast.alias(name='xml.etree',
                  asname='etree')])

    base_import_rewrite_0 = BaseImportRewrite([
        ('lxml', 'xml')
    ], a_s_t_0)
    assert base_import_rewrite_0.visit(a_s_t_1) == a_s_t_1
    assert base_import_rewrite_0.visit(a_s_t_2) == a_s_t_2


# Generated at 2022-06-25 21:59:39.684018
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    assert True


# Generated at 2022-06-25 21:59:44.681934
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    a_s_t_0 = module_0.Import()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 21:59:52.856973
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = ast.AST()
    alias_0 = ast.alias(name='name_0', asname='asname_0')
    import_0 = ast.Import(names=[alias_0])
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = ast.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_2)

# Generated at 2022-06-25 21:59:55.447405
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = BaseImportRewrite()
    import_0 = module_0.Import()
    a_s_t_0.visit(import_0)


# Generated at 2022-06-25 22:00:05.154840
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    ast_0 = ast.ImportFrom(module='foo', names=[ast.alias(name='bar', asname='foo.bar')], level=1)
    base_import_rewrite_0 = BaseImportRewrite(ast_0)
    assert base_import_rewrite_0.visit_ImportFrom(ast_0) == ast_0

if __name__ == '__main__':
    import sys
    import typing
    import datetime
    if sys.version_info[:2] < (3, 6):
        raise Exception('This test requires python version >= 3.6')

    print('Running unit tests:')
    t0 = datetime.datetime.now()
    test_case_0()
    test_BaseImportRewrite_visit_ImportFrom()
    dt = datetime.datetime

# Generated at 2022-06-25 22:00:09.698880
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_1 = module_0.Import()
    visit_Import_0 = base_import_rewrite_0.visit_Import(import_1)


# Generated at 2022-06-25 22:00:39.861264
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)


# Generated at 2022-06-25 22:00:49.515076
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    names_0 = [module_0.alias(name = 'typed_ast._ast3', asname = None)]
    import_from_0 = module_0.ImportFrom(module = 'typed_ast', names = names_0, level = 0)
    try_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    import_from_1 = module_0.ImportFrom(module = 'typed_ast._ast3', names = names_0, level = 0)
    try_1 = base_import_rewrite_0.visit_ImportFrom(import_from_1)
    assert import_from_0

# Generated at 2022-06-25 22:00:53.587052
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    import_from_0 = module_0.ImportFrom()
    a_s_t_2 = base_import_rewrite_1.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:56.313884
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Test case
    base_import_rewrite_0.visit(None)



# Generated at 2022-06-25 22:01:07.064953
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Test for the following case:
    # import_from_0 = ast.ImportFrom(module='String',
    #                                names=[ast.alias(name='*',
    #                                                 asname=None)],
    #                                level=0)
    # base_import_rewrite_0._get_matched_rewrite(module_0.ImportFrom(module='String',
    #                                                                names=[module_0.alias(name='*',
    #                                                                                      asname=None)],
    #                                                                level=0))
    # base_import_rewrite_0._replace_import_from_names('String',


# Generated at 2022-06-25 22:01:12.751267
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.Module()
    a_s_t_1 = module_0.AST()
    import_0 = module_0.Import(module_1)
    a_s_t_1.body = [
        import_0
    ]
    base_import_rewrite_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:01:18.186328
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # No exception thrown
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        base_import_rewrite_0.visit_ImportFrom(module_0.alias(name='module_0',asname=None))
    except NotImplementedError:
        assert False

import abc as module_1


# Generated at 2022-06-25 22:01:28.672238
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Test ast.ImportFrom
    import_from_0 = module_0.ImportFrom(names=[module_0.alias(name='incircle', asname=None)], module='a', level=0)
    try_0 = base_import_rewrite_0._replace_import_from_names(import_from_0, {'a.incircle': ('a', 'b')})
    assert isinstance(try_0, module_0.Try)

# Generated at 2022-06-25 22:01:35.132765
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    ast_import_from_0 = module_0.ImportFrom()
    base_import_rewrite_0.visit_ImportFrom(ast_import_from_0)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:01:46.743366
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = ast.parse("import a as b")
    a_s_t_0 = module_0
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0_0 = a_s_t_0
    try:
        parent_0 = base_import_rewrite_0.visit(a_s_t_0_0)
    except Exception as e_0:
        try:
            last_0 = parent_0
            parent_0 = base_import_rewrite_0.visit(last_0)
        except Exception as e_1:
            last_0 = parent_0
            parent_0 = base_import_rewrite_0.visit(last_0)
        last_0 = parent_0
        parent_

# Generated at 2022-06-25 22:02:12.870468
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0_0 = module_0.Import(names=module_0.alias(name='module_0', asname='module_0'))
    object_0 = base_import_rewrite_0.visit_Import(a_s_t_0_0)
    return object_0


# Generated at 2022-06-25 22:02:18.403191
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Input parameters
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node = module_0.ImportFrom(module='module_0', names=[module_0.alias(name='alias_0', asname='asname_0')], level=0)

    # Call method
    result = base_import_rewrite_0.visit_ImportFrom(node)

    # Check result
    assert result == 'module_0.alias_0'


# Generated at 2022-06-25 22:02:26.378883
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Test case when node names[0].name is equal to from_
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.Import(names=[module_0.alias(name='name1.name2', asname='name3')])
    try:
        base_import_rewrite_1.visit_Import(a_s_t_2)
    except:
        pass

    # Test case when node names[0].name is startswith from_
    a_s_t_3 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_3)
    a_s_t_4 = module

# Generated at 2022-06-25 22:02:28.167833
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:02:36.084269
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_l_i_a_s_0 = module_0.alias(name='abc', asname='abc1')
    import_0 = module_0.Import(names=[a_l_i_a_s_0])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('abc', 'def')]
    base_import_rewrite_0.visit(import_0)
    base_import_rewrite_0.visit(import_0)
    base_import_rewrite_0.visit(import_0)
    base_import_rewrite_0.visit(import_0)
    base_import_rewrite_0

# Generated at 2022-06-25 22:02:40.362707
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias()
    i_m_p_0 = module_0.Import(names=[alias_0])
    uni_p_0 = base_import_rewrite_0.visit_Import(i_m_p_0)


# Generated at 2022-06-25 22:02:46.894068
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    import_from_alias_0 = module_0.alias(name='a', asname='b')
    import_from_2 = module_0.ImportFrom(module='a', names=[import_from_alias_0], level='b')
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    result_0 = base_import_rewrite_0.visit_ImportFrom(import_from_2)
    assert isinstance(result_0, ast.Try)
    assert result_0.finalbody == []
    assert len(result_0.handlers) == 1
    assert result_0.handlers[0].body == [import_from_2]
    assert result_0.handlers[0].name is None

# Generated at 2022-06-25 22:02:50.913130
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    alias_0 = ast.alias()
    a_s_t_0 = ast.Module([ast.ImportFrom(module='a_s_t_0', names=[alias_0], level=0)])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(ast.ImportFrom(module='a_s_t_0', names=[alias_0], level=0))

# Generated at 2022-06-25 22:02:55.681603
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert base_import_rewrite_0._tree_changed == False
    assert base_import_rewrite_0.visit(a_s_t_0) == a_s_t_0
    assert base_import_rewrite_0._tree_changed == True



# Generated at 2022-06-25 22:03:02.626454
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = ast.ImportFrom(level=0)
    node_0.module = 'a'
    node_0.names = []
    base_import_rewrite_0._get_matched_rewrite(node_0.module)
    base_import_rewrite_0._replace_import_from_module(node_0, 'a', 'b')
    base_import_rewrite_0._replace_import_from_names(node_0, {})
    base_import_rewrite_0.visit_ImportFrom(node_0)


# Generated at 2022-06-25 22:04:02.899750
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(names=[module_0.alias(name="module_4", asname="module_4"), module_0.alias(name="module_5", asname="module_5")], module="module_1", level=1)
    node_0 = base_import_rewrite_0.visit_ImportFrom(ast_node=a_s_t_1)


# Generated at 2022-06-25 22:04:12.106010
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0_0 = module_0.Import(names=[module_0.alias(name='re', asname='re')])
    try_0_0 = base_import_rewrite_0.visit_Import(import_0_0)
    assert(type(try_0_0) == module_0.Try)
    try_0_0 = base_import_rewrite_0.visit_Import(import_0_0)
    assert(type(try_0_0) == module_0.Try)
    try_0_0 = base_import_rewrite_0.visit_Import(import_0_0)

# Generated at 2022-06-25 22:04:20.549585
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Create a mock AST object
    a_s_t_0 = module_0.AST()
    # Create a mock ImportFrom object
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(
        module='a_m_o_d_u_l_e',
        names=[module_0.alias(
            name='a_n_a_m_e',
            asname=None)],
        level=1)
    # Create a mock BaseImportRewrite object
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Call method visit_ImportFrom

# Generated at 2022-06-25 22:04:28.542868
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    source_0 = [module_0.alias(name='module_0', asname='module_0'), module_0.alias(name='module_0', asname='module_0')]
    import_0 = module_0.Import(names=source_0)
    base_import_rewrite_0.visit_Import(import_0).body[0].body[0].body[0].value.values[0].value.values[0]

    base_import_rewrite_0.get_matched_rewrite('module_0')

    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_

# Generated at 2022-06-25 22:04:34.807833
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = ast.alias(
        name = 'test',
        asname = 'test'
    )
    base_import_rewrite_0.visit_ImportFrom(
        node = ast.ImportFrom(
            module = 'test',
            names = [alias_0],
            level = 0
        )
    )
    base_import_rewrite_0.visit_ImportFrom(
        node = ast.ImportFrom(
            module = 'test',
            names = [alias_0],
            level = 0
        )
    )

# Generated at 2022-06-25 22:04:37.562927
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:41.702360
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = a_s_t_0
    import_from_0 = a_s_t_1.ImportFrom(module='none', names=[], level=None)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:04:48.086746
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0_0 = module_0.ImportFrom(module='typed_ast', names=module_0.alias(name='AST', asname=None), level=0)
    base_import_rewrite_0._replace_import_from_names(import_from_0_0, {'typed_ast.AST': ('typed_ast', 'typed_ast')})
    base_import_rewrite_0._replace_import_from_module(import_from_0_0, 'typed_ast', 'typed_ast')
    base_import_rewrite_0.visit_ImportFrom(import_from_0_0)



# Generated at 2022-06-25 22:04:51.654189
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names = [module_0.alias(name = 'name0', asname = 'name1')])
    base_import_rewrite_0.visit(import_0)


# Generated at 2022-06-25 22:04:54.966241
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = ast.AST()
    base_node_transformer_1 = BaseNodeTransformer(a_s_t_1)
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    import_1 = ast.Import()
    base_import_rewrite_1._replace_import(import_1, None, None)
