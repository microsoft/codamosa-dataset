

# Generated at 2022-06-25 21:56:39.664295
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-25 21:56:50.623100
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0_0 = module_0.Import()
    base_import_rewrite_0._get_matched_rewrite = lambda *args, **kwargs: (None, None)
    base_import_rewrite_0._replace_import = lambda *args, **kwargs: module_0_0
    base_import_rewrite_0._tree_changed = bool()
    base_import_rewrite_0.generic_visit = lambda *args, **kwargs: None
    base_import_rewrite_0.visit_Import(module_0_0)
    assert base_import_rewrite_0._tree_changed == bool()


# Generated at 2022-06-25 21:56:58.877337
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias('name_0', None)
    i_m_p_o_r_t_0 = module_0.Import([alias_0])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._get_matched_rewrite = lambda arg0: (None, 'to_0')
    base_import_rewrite_0.generic_visit = lambda arg0: module_0.Try()
    base_import_rewrite_0._replace_import = lambda arg0, arg1, arg2: module_0.Try()

# Generated at 2022-06-25 21:57:08.186530
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast._ast3 as module_0
    from textwrap import dedent
    from typing import List
    import __main__
    import ast
    import sys
    globals_1 = globals()
    globals_2 = globals()
    globals_3 = globals()
    globals_4 = globals()
    globals_5 = globals()
    globals_6 = globals()
    globals_7 = globals()
    globals_8 = globals()
    globals_9 = globals()
    globals_10 = globals()
    globals_11 = globals()
    globals_12 = globals()
    globals_13 = globals()
    globals_14 = globals()
    globals_15 = globals()
    globals_16 = globals

# Generated at 2022-06-25 21:57:16.848482
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = a_s_t_0.Module(body=[a_s_t_0.Import(names=[a_s_t_0.alias(name="os", asname=None)])])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    
    # import ast; ast.parse('''import os''').body[0].names[0].name
    assert a_s_t_0.parse('''import os''').body[0].names[0].name == 'os'
    
    # ast.parse('''import os''').body[0].names[0

# Generated at 2022-06-25 21:57:25.888280
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    str_0 = "foo"
    alias_0 = module_0.alias(name=str_0)
    import_0 = module_0.Import(names=[alias_0])
    rewrote_name_0 = str_0
    import_as_0 = str_0
    rewrote_0 = module_0.Import(names=[module_0.alias(name=rewrote_name_0, asname=import_as_0)])
    import_rewrite_0 = import_rewrite(previous=import_0, current=rewrote_0)
    type_0 = type(import_0)

# Generated at 2022-06-25 21:57:28.204355
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_1.names = [module_0.alias(name=None, asname=None)]
    base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 21:57:33.507777
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Import()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(str, str)]
    base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 21:57:42.573037
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import astor
    module_0 = None
    alias_0 = None
    node_0 = module_0.ImportFrom(names=[alias_0, alias_0], level=0)
    base_import_rewrite_0 = BaseImportRewrite(module_0)
    astor.to_source(base_import_rewrite_0.visit_ImportFrom(node_0))
    a_s_t_0 = module_0.AST()
    node_1 = module_0.ImportFrom(module='threading', level=0)
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_0)
    astor.to_source(base_import_rewrite_1.visit_ImportFrom(node_1))


# Generated at 2022-06-25 21:57:50.852749
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    import_0 = module_0.Import(names=[module_0.alias(name="typed_ast", asname=None)])
    import_1 = module_0.Import(names=[module_0.alias(name="typed_ast", asname=None)])
    module_1 = module_0.Module(body=[import_0])
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_1.rewrites = [("typed_ast", "typed_ast.ast3")]
    try_1 = base_import_rewrite_1.visit_Import(module_1.body[0])

# Generated at 2022-06-25 21:58:03.592227
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = ast.parse('from datetime import datetime').body[0]
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [( 'datetime',  'backports.datetime_fromisoformat' )]
    import_from_0 = base_import_rewrite_0.visit_ImportFrom(node=import_from_0)
    assert type(import_from_0) == ast.Try

# Generated at 2022-06-25 21:58:04.720581
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO: write test
    assert True


# Generated at 2022-06-25 21:58:12.070825
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias()
    a_l_i_a_s_0.name = 'name1'
    a_l_i_a_s_0.asname = 'asname1'
    import_0 = module_0.Import(names=[a_l_i_a_s_0])
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:17.785995
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    expected_0 = module_0.AST()
    ast_0 = ast.AST()
    alias_0 = ast_0.alias(name="a", asname="b")
    imp_0 = ast_0.Import(names=[alias_0])
    actual_0 = base_import_rewrite_0.visit_Import(imp_0)


# Generated at 2022-06-25 21:58:22.115741
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import(names=[ast.alias(name='', asname='')])
    base_import_rewrite_0 = BaseImportRewrite(None)
    with raises(NotImplementedError):
        base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:26.058065
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = ast.parse("import requests")
    base_import_rewrite_0 = BaseImportRewrite(module_0)

    result = base_import_rewrite_0.visit_ImportFrom(module_0.body[0])
    assert result != module_0.body[0]


# Generated at 2022-06-25 21:58:33.678389
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(
        module='abc',
        names=[
            module_0.alias(
                name='abc',
                asname='abc'
            )
        ],
        level=1
    )
    
    try:
        base_import_rewrite_0._replace_import_from_module(a_s_t_1, 'rewrite', 'rewrote')
    except ImportError:
        pass


# Generated at 2022-06-25 21:58:39.476628
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    
    alias_0 = module_0.alias(name="", asname="")
    import_from_0 = module_0.ImportFrom(module="", names=[alias_0], level=0)
    import_rewrite_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert import_rewrite_0 is None


# Generated at 2022-06-25 21:58:49.834736
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias()
    alias_0.asname = None
    alias_0.name = 'foo'
    import_from_0 = module_0.ImportFrom()
    import_from_0.level = 0
    import_from_0.module = None
    import_from_0.names = [alias_0]
    import_from_0.lineno = None
    import_from_0.col_offset = None
    result_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert type(result_0) == module_0.ImportFrom


# Generated at 2022-06-25 21:58:56.899923
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    ast_0 = module_0.AST()
    level_0 = 0
    bltn_exc_0 = ast.Try(body=[ast.ImportFrom(level=level_0, module='abc', names=[ast.alias(asname='abc', name='abc')])], handlers=[], orelse=[], finalbody=[])
    base_import_rewrite_0 = BaseImportRewrite(ast_0)
    base_import_rewrite_0.visit(bltn_exc_0)


# Generated at 2022-06-25 21:59:10.966966
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_2 = module_0.AST()
    name_0 = module_0.alias(name=None, asname=None)
    import_0 = module_0.Import(names=[name_0])
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_2)
    base_import_rewrite_2 = base_import_rewrite_1.visit(import_0)
    base_import_rewrite_3 = base_import_rewrite_2



# Generated at 2022-06-25 21:59:15.861502
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = ast.ImportFrom(level=0, names=[], module='foo')
    # Actual result
    assert base_import_rewrite_0.visit_ImportFrom(import_from_0) == import_from_0

# Generated at 2022-06-25 21:59:22.976022
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(None, None)
    a_s_t_1 = module_0.AST()
    import_from_0 = module_0.ImportFrom(None, [alias_0], 0)
    a_s_t_2 = module_0.AST()
    try_0 = module_0.Try(None, [], [], None, None)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:59:26.957559
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0_0 = module_0.Module(body=a_s_t_0)
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.dependencies = []
    base_import_rewrite_0._rewrites = []
    base_import_rewrite_0._tree_changed = ''
    base_import_rewrite_0.target = module_0.CompilationTarget('', '', '', '', '', '', '')
    assert base_import_rewrite_0.visit(module_0_0) == module_0_0
    assert base_import_rewrite_0.visit

# Generated at 2022-06-25 21:59:31.534214
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import sys
    import io

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out

        a_s_t_0 = ast.parse('import os\n')
        base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

        sys.stdout = saved_stdout

        assert out.getvalue().strip() == ast.dump(ast.parse('import os')).strip()
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-25 21:59:37.326334
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0.visit(a_s_t_1)
    return(base_import_rewrite_0.visit(a_s_t_1))


# Generated at 2022-06-25 21:59:42.453207
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    try:
        base_import_rewrite_1 = base_import_rewrite_0.visit(a_s_t_1)
    except:
        assert False
    return True


# Generated at 2022-06-25 21:59:44.820985
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='full_import_from_module', names=None, level=None)
    import_from_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert type(import_from_1) == module_0.ImportFrom


# Generated at 2022-06-25 21:59:46.343434
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0.AST()
    BaseImportRewrite()
    module_0.Import()



# Generated at 2022-06-25 21:59:52.892022
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    foo_0 = module_0.alias()
    foo_0.name = "foo"
    foo_0.asname = None
    list_0 = list()
    list_0.append(foo_0)
    import_0 = module_0.Import(names=list_0)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('foo', 'bar')]
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:10.199949
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_0 = module_0.Import(
        names=[module_0.alias(
            name='foo',
            asname='bar')])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('foo', 'baz')]
    base_import_rewrite_0._replace_import(import_0, *base_import_rewrite_0.rewrites[0])


# Generated at 2022-06-25 22:00:15.107426
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.Name()
    module_2 = module_0.alias(name="")
    list_0 = [module_2]
    module_3 = module_0.Import(names=list_0)
    base_import_rewrite_0.visit_Import(module_3)


# Generated at 2022-06-25 22:00:23.270904
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 22:00:28.240392
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_1 = module_0.Import(names=[module_0.alias(name='_thread', asname='_thread')])
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    module_0.Import(names=[module_0.alias(name='_thread', asname='_thread')])


# Generated at 2022-06-25 22:00:36.043512
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Create mock import statement AST
    node_0 = module_0.Import(names=[module_0.alias(name="x." + "y", asname=None)])

    # Create mock BaseImportRewrite instance
    base_import_rewrite_0 = BaseImportRewrite(None)
    assert base_import_rewrite_0._get_matched_rewrite("x." + "y") == ("x." + "y", "z")

    # Call visit_Import method
    actual_result_0 = base_import_rewrite_0.visit_Import(node_0)
    expected_result_0 = module_0.Try(body=[module_0.Import(names=[module_0.alias(name="z", asname=None)])], orelse=[], finalbody=[])
    assert actual_result_0 == expected

# Generated at 2022-06-25 22:00:45.940578
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test snippet
    module_0 = 'foo.bar'
    a_s_t_0 = ast.parse('from foo.bar import baz').body[0]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    target_0 = ast.parse('from foo.bar import baz').body[0]
    base_import_rewrite_1 = BaseImportRewrite(target_0)
    class_0 = base_import_rewrite_1.__class__
    names_0 = base_import_rewrite_1.__dict__
    base_import_rewrite_1.rewrites = [('foo', 'bar')]

# Generated at 2022-06-25 22:00:54.714724
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    import typed_ast

    import_0 = ast.ImportFrom(
        level=4,
        module='osdfjkdfbads',
        names=[
            ast.alias(
                asname=None,
                name='fadfafd'
            )
        ]
    )

    base_import_rewrite_0 = BaseImportRewrite(import_0)
    base_import_rewrite_0.rewrites = [
        ('from_0', 'to_0')
    ]


# Generated at 2022-06-25 22:01:04.609927
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(fromlist=[], level=None, module='0', names=[])
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    rewrotes = [
        base_import_rewrite_0._get_replaced_import_from_part(import_from_0, alias, {'0.0': ('0', '0')})
        for alias in import_from_0.names]
    assert rewrotes == [import_from_0]


# Generated at 2022-06-25 22:01:09.086398
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    method_param_0 = a_s_t_0
    a_s_t_0.rewrites = [("a.b", "c.d")]
    method_result_0 = base_import_rewrite_0.visit_Import(method_param_0)
    assert isinstance(method_result_0, a_s_t_0)


# Generated at 2022-06-25 22:01:15.875773
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = test_case_0()
    import_from_0 = ast.ImportFrom(
        module='django.db.models',
        names=[ast.alias(name='models', asname=None)],
        level=0
    )
    base_import_rewrite_0 = module_0.base_import_rewrite_0
    name_0 = 'django.db.models'
    module_0 = test_case_0()
    import_from_1 = ast.ImportFrom(
        module='django.db.models',
        names=[ast.alias(name='django.db.models.Model', asname=None)],
        level=0
    )
    base_import_rewrite_1 = module_0.base_import_rewrite_0

# Generated at 2022-06-25 22:01:33.559716
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_case_0()


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:01:34.371665
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    ...


# Generated at 2022-06-25 22:01:45.815771
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typing import List, Tuple, Union, Optional, Iterable, Dict
    import typed_ast._ast3 as module_0
    import_13 = module_0.ImportFrom(names=[[]])
    names_to_replace_14 = {}
    base_import_rewrite_15 = BaseImportRewrite(module_0.AST())
    import_13.names[0].name = 'foo'
    import_13.names[0].asname = 'foo'
    import_13.module = 'foo'
    try:
        a_s_t_16 = module_0.alias(name='foo', asname='foo')
    except:
        a_s_t_16 = module_0.alias(name='foo', asname='foo')
    a_s_t_16.name = 'foo'
   

# Generated at 2022-06-25 22:01:54.078173
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    a_s_t_3 = module_0.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_3)
    a_s_t_4 = module_0.AST()
    base_import_rewrite_4 = BaseImportRewrite(a_s_t_4)

# Generated at 2022-06-25 22:02:01.297325
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(0, 0, 0, 0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:02:07.484893
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # AssertionError: AssertionError: Actual tree: AST()

    # AssertionError: AssertionError: Actual tree: AST()

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.target = None
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.dependencies = []



# Generated at 2022-06-25 22:02:12.646317
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_from_0 = module_0.ImportFrom(from_=None, names=(module_0.alias(name='Test', asname=None),), level=0)

    base_import_rewrite_0.visit_Import(import_from_0)



# Generated at 2022-06-25 22:02:19.862884
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Case 1
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    n_a_m_e_0 = module_0.Name()
    n_a_m_e_1 = module_0.Name()
    n_a_m_e_2 = module_0.Name()
    n_a_m_e_3 = module_0.Name()
    n_a_m_e_4 = module_0.Name()
    n_a_m_e_5 = module_0.Name()
    n_a_m_e_6 = module_0.Name()
    n_a_m_e_7 = module_0.Name()
    n_a_m_e_8

# Generated at 2022-06-25 22:02:27.344184
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor as module_0
    import ast as module_1
    import sys as module_2
    import os as module_3
    import typing as module_4
    a_s_t_0 = module_1.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_1.alias(name='astor', asname='module_0')
    node_0 = module_1.Import(names=[alias_0])
    try_0 = module_1.Try(body=[node_0], finalbody=[], handlers=[], orelse=[])
    assert base_import_rewrite_0.visit_Import(node_0) == try_0


# Generated at 2022-06-25 22:02:34.015250
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import()
    a_s_t_1.names = [module_0.alias(name='pytest', asname='pytest')]
    try:
        base_import_rewrite_0.visit_Import(a_s_t_1)
    except AttributeError:
        pass
    a_s_t_2 = module_0.Import()
    a_s_t_2.names = [module_0.alias(name='unittest', asname='unittest')]

# Generated at 2022-06-25 22:03:37.284277
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Test visit_ImportFrom method of class BaseImportRewrite."""

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_from_0 = module_0.ImportFrom(names=[module_0.alias(name='test'), module_0.alias(name='test_test')], level=0)
    base_import_rewrite_0.rewrites = [('.test', '.test_test')]
    # Function call
    result = base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:03:44.676147
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    module_0.alias(alias_0=alias_0, name_0=name_0, asname_0=asname_0)
    asname_0 = "temp_asname_0"
    name_0 = "temp_name_0"
    alias_0 = "temp_alias_0"
    base_import_rewrite_0.rewrites.append((from__0, to_0))
    from__0 = "temp_from__0"
    to_0 = "temp_to_0"
    module_0.Import(names_0=names_0)

# Generated at 2022-06-25 22:03:48.380426
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias()
    import_0 = module_0.Import(names=[alias_0])
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:54.611208
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0.body = [module_0.Import(['module_00'])]
    base_import_rewrite_0._get_matched_rewrite = lambda name: None
    base_import_rewrite_0.visit_Import = method_visit_Import_0
    base_import_rewrite_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:03:55.498723
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert True


# Generated at 2022-06-25 22:03:58.762896
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.AST()
    base_import_rewrite_1.visit_Import(a_s_t_2)


# Generated at 2022-06-25 22:04:08.612584
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    ast_import_0 = module_0.Import(names=_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    ast_import_1 = module_0.Import(names=_0)
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    ast_import_2 = module_0.Import(names=_0)

# Generated at 2022-06-25 22:04:17.301093
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    a_s_t_0.lineno = 4
    a_s_t_0.col_offset = 3
    a_s_t_0.end_lineno = 3

    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [a_s_t_0]
    a_s_t_1.lineno = 3
    a_s_t_1.col_offset = 3
    a_s_t_1.end_lineno = 5
    a_s_t_1.end_col_offset = 5
    
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)


# Generated at 2022-06-25 22:04:24.843407
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0n_0 = module_0.alias()
    module_0n_1 = module_0.alias()
    module_0n_2 = module_0.alias()
    module_0n_3 = module_0.alias()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    i_m_p_o_r_t_0 = module_0.Import(names=[module_0n_0, module_0n_1, module_0n_2, module_0n_3])
    module_0n_4 = module_0.alias()


# Generated at 2022-06-25 22:04:32.245255
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(a_s_t_0, a_s_t_0, a_s_t_0)
    import_from_0.module = a_s_t_0
    import_from_0.names = a_s_t_0
    import_from_0.level = a_s_t_0
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    rewrotes_0 = a_s_t_0
    rewrote_module_0 = a_s_t_0
    rewrote_name_0 = a_s_t_0
    rewrote_module_1 = a_s_t_0
    rewrote_module