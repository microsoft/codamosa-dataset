

# Generated at 2022-06-25 21:56:48.560932
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Arrange
    statement = "import foo"
    node = ast.parse(statement).body[0]
    # Act
    import_rewrite_1 = BaseImportRewrite()
    result = import_rewrite_1.visit_ImportFrom(node)
    # Assert
    assert isinstance(result, ast.Try) == False


# Generated at 2022-06-25 21:56:55.347713
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewrite_0(BaseImportRewrite):

        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)

        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            pass

    base_import_rewrite_0 = BaseImportRewrite_0(ast.AST())
    base_import_rewrite_0.visit_Import(ast.Import([ast.alias(name="re")]))



# Generated at 2022-06-25 21:57:05.077638
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    class _TestClass(BaseImportRewrite):

        rewrites = [('a1', 'a2'), ('b1', 'b2')]

    _TestClass.transform(ast.parse('import a1'))
    _TestClass.transform(ast.parse('import a1.b1'))

    _TestClass.transform(ast.parse('import a1 as a'))
    _TestClass.transform(ast.parse('import a1.b1 as b'))

    _TestClass.transform(ast.parse('import e1.e2.e3 as f'))
    _TestClass.transform(ast.parse('import e1.e2.e3.e4 as g'))
    _TestClass.transform(ast.parse('import e1.e2 as f'))

# Generated at 2022-06-25 21:57:12.706456
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast.ast3 import parse
    from . import BaseTransformer
    tree = parse("""
import datetime

a = datetime.timedelta(1)
""")
    class TestTransformer(BaseImportRewrite):
        rewrites = [('datetime', 'dateutil.parser')]

    trans = TestTransformer(tree)
    trans.visit(tree)
    assert str(tree) == """
try:
    import datetime as datetime
except ImportError:
    import dateutil.parser as datetime

a = datetime.timedelta(1)
"""


# Generated at 2022-06-25 21:57:16.115049
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class CustomImportRewrite(BaseImportRewrite):
        rewrites = [
            ('os', 'my.new.os'),
            ('time', 'my.new.time')]

    CustomImportRewrite().visit(ast.parse('import os, time'))


# Generated at 2022-06-25 21:57:22.724382
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from typed_ast import ast3 as ast
    
    class BaseImportRewrite_visit_ImportFrom_TestCase(BaseImportRewrite):
        rewrites = [('old', 'new')]
    
    # Case 0
    node = ast.parse('from old import a')
    rewrited = BaseImportRewrite_visit_ImportFrom_TestCase.transform(node)
    assert rewrited.result == 'try:\n    from new import a\nexcept ImportError:\n    from old import a'
    assert rewrited.changed
    assert rewrited.dependencies == ['old', 'new']

# Generated at 2022-06-25 21:57:24.265033
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    assert False, "TODO: Implement"


# Generated at 2022-06-25 21:57:33.160132
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    #
    # Inputs
    #
    class BaseImportRewriteImpl(BaseImportRewrite):
        rewrites = [
            ('django.utils', 'pycharm_django_utils'),
            ('test.test', 'test1.test1')]
    import_0 = ast.Import(names=[
        ast.alias(name='django.utils.translation',
                  asname='translation'),
    ])

    #
    # Class under test
    #
    base_import_rewrite_0 = BaseImportRewriteImpl()

    #
    # Expected output
    #
    result = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:37.855540
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class Transformer(BaseImportRewrite):
        rewrites = [('six.moves', 'toSix.moves'),]

    tree = ast.parse('import six.moves as sm')
    Transformer.transform(tree)
    assert ast.dump(tree) == 'try:\n    import toSix.moves as sm\nexcept ImportError:\n    import six.moves as sm'


# Generated at 2022-06-25 21:57:47.623191
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..test_utils.test_config import test_python_version, test_target_version

    import typed_ast.ast3 as ast
    from typed_ast import ast3 as typed_ast

    if test_python_version < 3.6:
        raise Exception('Python 3.6 or higher is required')

    from . import ast_fixer

    transformer = BaseImportRewrite()
    tree = typed_ast.parse(
        """
module = True
import some_module

if module:
    import some_other_module
""", 'test', mode='exec')
    tree = ast_fixer.fix_missing_locations(tree)
    transformer.visit(tree)
    print(typed_ast.unparse(tree))
    print(ast.dump(tree))


# Generated at 2022-06-25 21:57:57.643768
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module="a", names=[], level=0)
    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(a_s_t_1, module_0.ImportFrom)


# Generated at 2022-06-25 21:58:06.403058
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typing
    import astunparse
    source = '''
from a import b, c, d
from e import *
from f import g
from h import i


'''
    parsed = ast.parse(source)
    typed_ast.ast3.fix_missing_locations(parsed)
    sources = [
        'a.b',
        'a.c',
        'a.d',
        'e',
        'f',
        'h'
    ]
    replaces = [
        'aa.b',
        'aa.c',
        'aa.d',
        'ee.e',
        'ff.g',
        'hh.i'
    ]

# Generated at 2022-06-25 21:58:15.471702
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_5 = module_0.AST()
    base_import_rewrite_5 = BaseImportRewrite(a_s_t_5)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_0 = module_0.ImportFrom()
    try_0 = base_import_rewrite_0.visit_ImportFrom(a_s_t_0)
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    assert type(try_0) == type(base_import_rewrite_5)
    assert type(try_0) == type(a_s_t_2)


# Generated at 2022-06-25 21:58:16.665232
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0.AST()
    # TODO: Write the test



# Generated at 2022-06-25 21:58:22.642873
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_0 = module_0.ImportFrom(level=0, module='x', names = [])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        assert base_import_rewrite_0.visit_ImportFrom(import_from_0)
    except AssertionError:
        raise

import ast as module_1


# Generated at 2022-06-25 21:58:27.391291
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import([module_0.alias(name='typed_ast.ast3', asname=None)])
    try_0 = base_import_rewrite_0.visit_Import(import_0) # type: ignore


# Generated at 2022-06-25 21:58:36.416921
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_alias_0 = module_0.alias(name='foo', asname=None)
    a_alias_1 = module_0.alias(name='bar', asname='bar')
    l_list_0 = [a_alias_0, a_alias_1]
    a_importfrom_0 = module_0.ImportFrom(module='foo', names=l_list_0, level=1)
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = []

# Generated at 2022-06-25 21:58:47.942499
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Test 1
    a_s_t_0 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_0)

    # Test 2
    a_s_t_0 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_0)

    # Test 3
    a_s_t_0 = module_0.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_0)

    # Test 4
    a_s_t_0 = module_0.AST()
    base_

# Generated at 2022-06-25 21:58:55.659762
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_2 = module_0.Import(names=[module_0.alias(name='abc', asname='alias')])
    try_3 = base_import_rewrite_0.visit_Import(import_2)
    assert type(try_3) == module_0.Try


# Generated at 2022-06-25 21:59:04.946215
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0.ast = a_s_t_1
    a_s_t_2 = module_0.AST()
    base_import_rewrite_0.context = a_s_t_2
    a_s_t_3 = module_0.AST()
    base_import_rewrite_0.target = a_s_t_3
    a_s_t_4 = module_0.AST()
    base_import_rewrite_0.body = a_s_t_4
    a_s_t_5 = module_0.AST()

# Generated at 2022-06-25 21:59:24.902790
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(
        level=1,
        from_=True,
        module="sys",
        names=[
            module_0.alias(
                name="argv",
                asname=None
            )
        ])
    try_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(try_0, module_0.Try)
    assert try_0.body is None
    assert try_0.handlers is not None

# Generated at 2022-06-25 21:59:30.315972
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    import_0 = module_0.Import(names=[a_s_t_1])
    try_0 = base_import_rewrite_0.visit_Import(import_0)
    # AssertionError: Expected <class 'typed_ast.ast3.Try'> but got <class 'typed_ast._ast3.Import'>


# Generated at 2022-06-25 21:59:31.337972
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Result is 1
    pass 


# Generated at 2022-06-25 21:59:35.405571
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.Import()
    try:
        base_import_rewrite_0.visit_Import(node_0)
    except Exception as exc:
        pass


# Generated at 2022-06-25 21:59:45.291219
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    # Instance
    node_0 = module_0.Import(lineno=None, col_offset=None)
    node_0_0 = module_0.alias(lineno=None, col_offset=None)
    node_0_0.name = "anystr"
    node_0.names = [ node_0_0 ]
    base_import_rewrite_0 = BaseImportRewrite.__new__(BaseImportRewrite)
    base_import_rewrite_0.rewrites = [ ("anystr", "anystr") ]
    # Call
    res_0 = base_import_rewrite_0.visit_Import(node_0)
    assert res_0 == node_0


# Generated at 2022-06-25 21:59:50.159424
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(name='name')
    import_0 = module_0.Import(names=[alias_0])
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:55.447461
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = BaseImportRewrite(5)
    a_s_t_2 = ast.AST()
    subtype_0, subtype_1 = type(a_s_t_1), type(a_s_t_2)
    # Check if method visit_ImportFrom of class BaseImportRewrite has been
    # overridden
    assert(BaseImportRewrite.visit_ImportFrom != ast.NodeTransformer.visit_ImportFrom)


# Generated at 2022-06-25 22:00:00.031589
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    import_from_0 = module_0.ImportFrom()
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:07.252325
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(name='', asname='')
    alias_1 = module_0.alias(name='', asname='')
    import_from_0 = module_0.ImportFrom(module='', names=[alias_0, alias_1], level='')
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:00:09.574025
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:00:28.861654
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[
    ])
    base_import_rewrite_0.dependencies = []
    base_import_rewrite_0.error = ValueError()
    base_import_rewrite_0.rewrites = []
    base_import_rewrite_0.target = "s"

    assert_equal(base_import_rewrite_0.visit_Import(import_0), import_0)


# Generated at 2022-06-25 22:00:33.978080
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0_0 = module_0.Import()
    base_import_rewrite_0_res = base_import_rewrite_0.visit_Import(import_0_0)
    assert isinstance(base_import_rewrite_0_res, module_0.Import)


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:00:44.057900
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    from ast import parse, Import, dump
    from typed_ast import ast3 as ast

    if sys.version_info.minor >= 6:
        # Asserts that Python's ast module can load and dump our
        # own typed_ast.ast3
        parse(dump(ast.AST()))

    class MyImportRewrite(BaseImportRewrite):
        rewrites = [
            ('xml.etree.ElementTree', 'xml.etree.cElementTree'),
        ]

    class MyImportRewrite2(BaseImportRewrite):
        rewrites = [
            ('xml.etree.ElementTree', 'xml.etree.cElementTree'),
            ('foo.bar', 'foo.baz')
        ]


# Generated at 2022-06-25 22:00:53.055380
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0._tree = a_s_t_1
    base_import_rewrite_0._tree_changed = True
    a_s_t_2 = module_0.alias(name=None, asname=None)
    a_s_t_3 = module_0.alias(name=None, asname=None)
    a_s_t_4 = module_0.alias(name=None, asname=None)
    a_s_t_5 = module_0.alias(name=None, asname=None)
    a_s_t_

# Generated at 2022-06-25 22:00:56.584353
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0 = ast.Module()
    import_2 = ast.Import(names=[ast.alias(name='string',
                                    asname=None)])
    module_0.body = [import_2]
    assert BaseImportRewrite.transform(module_0).changed == False
    assert module_0.body[0] == import_2


# Generated at 2022-06-25 22:00:58.358572
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO: ??
    return True

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:01:08.347504
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    as_0 = module_0.alias(name=None, asname=None)
    as_1 = module_0.alias(name=None, asname=None)
    as_2 = module_0.alias(name=None, asname=None)
    a_s_t_1 = module_0.ImportFrom()
    a_s_t_1.module = None
    a_s_t_1.names = [as_0]
    a_s_t_1.level = 0
    a_s_t_2 = module_0.ImportFrom()
    a_s_t_2.module = None
    a_s_t_2.names = [as_1, as_2]

# Generated at 2022-06-25 22:01:15.385733
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    ast_0 = module_0.AST()
    import_0 = module_0.Import(names=[])
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_2)
    a_s_t_3 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_3)
    
    # Setup given data
    base_import_rewrite_0.rewrites.append(('previous', 'current'))
    base_import

# Generated at 2022-06-25 22:01:23.593667
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_0 = module_0.Import(names=[module_0.alias(name='foo', asname=None)])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try_0 = base_import_rewrite_0.visit_Import(import_0)
    print(try_0)


# Generated at 2022-06-25 22:01:31.627004
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import base64
    body = base64.b64decode(b'Ym9keQ==')
    body = body.decode('utf-8')
    body = ast.parse(body)
    body = body.body[0]
    body = body.value
    import_0 = module_0.Import(names=[
        module_0.alias(name='math',
                       asname=None),
        module_0.alias(name='time',
                       asname=None)])
    import_1 = module_0.Import(names=[
        module_0.alias(name='math',
                       asname=None),
        module_0.alias(name='time',
                       asname='t')])

# Generated at 2022-06-25 22:01:50.781187
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # TODO
    pass


# Generated at 2022-06-25 22:01:54.992181
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import()
    a_s_t_1.names = [module_0.alias(name='test', asname=None)]
    a_s_t_2 = base_import_rewrite_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 22:02:06.065948
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name='__future__', asname=None)
    a_l_i_a_s_1 = module_0.alias(name='typed_ast', asname=None)
    i_m_p_o_r_t_0 = module_0.Import(names=[a_l_i_a_s_0, a_l_i_a_s_1])
    try:
        module_0.Import(names=[a_l_i_a_s_0, a_l_i_a_s_1])
    except ImportError:
        pass
   

# Generated at 2022-06-25 22:02:15.293504
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Local variables
    a_s_t_0 = None
    rewrotes_0 = [None, None, None, None]
    base_import_rewrite_0 = None
    rewrotes_1 = [None, None, None, None]
    names_to_replace_0 = dict()

    # Procedure body
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._replace_import_from_module(alias_0, names_to_replace_0, node_0, rewrotes_1)

# Generated at 2022-06-25 22:02:21.838907
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module = [ast.Import(names=[ast.alias(name='os.path',
                                          asname=None)]), ast.Import(names=[ast.alias(name='os',
                                                                                      asname='op')])]
    a_s_t_0 = ast.Module(body=module)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module[1]
    import_0 = base_import_rewrite_0.visit_Import(node=import_0)
    assert import_0.names[0].name == 'os'


# Generated at 2022-06-25 22:02:24.917609
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(a_s_t_0)


# Generated at 2022-06-25 22:02:28.414332
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    i_4 = module_0.Import(names=[module_0.alias(name='typed_ast',asname='ast3')])
    base_import_rewrite_1.visit_Import(i_4)
    assert False # TODO: implement your test here



# Generated at 2022-06-25 22:02:36.373511
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_3 = module_0.AST()
    import_from_0 = module_0.ImportFrom()
    import_from_0 = module_0.ImportFrom()
    import_from_0.names = [a_s_t_1, a_s_t_3]
    a_s_t_2 = module_0.AST()
    import_from_0.names = [a_s_t_1, a_s_t_3]
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_

# Generated at 2022-06-25 22:02:40.946080
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.Import([module_0.alias(name='abc', asname='abc')])
    try:
        base_import_rewrite_0.visit_Import(a_s_t_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:02:46.249767
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():

    import typed_ast.ast3 as ast

    class BaseImportRewriteSubclass(BaseImportRewrite):
        pass

    a_s_t_0 = ast.AST()
    import_0 = ast.Import(names=[ast.alias(name='', asname='')])
    base_import_rewrite_subclass_0 = BaseImportRewriteSubclass(a_s_t_0)
    base_import_rewrite_subclass_0.rewrites = [('', '')]
    assert base_import_rewrite_subclass_0.visit_Import(import_0) == import_0


# Generated at 2022-06-25 22:03:41.904896
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    test_case_0()

if __name__ == '__main__':
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:03:46.767984
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_1 = module_0.ImportFrom(module='', level=2, names=[module_0.alias(name='', asname='')])
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    result1 = base_import_rewrite_2.visit_ImportFrom(import_from_1)
    assert isinstance(result1, module_0.ImportFrom)
    assert result1.level == 2


# Generated at 2022-06-25 22:03:52.881132
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.alias(name='re')
    a_s_t_2 = ast.Import(names=[a_s_t_1])
    result_0 = base_import_rewrite_0.visit_Import(a_s_t_2)
    assert type(result_0) is ast.Try


# Generated at 2022-06-25 22:04:01.408469
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ..standard_library import _os

    target_ast = ast.parse('from os.path import sep, join')
    target = BaseImportRewrite(target_ast)
    result = target.visit(target_ast) # type: ast.ImportFrom

    if not isinstance(result, ast.Try):
        raise Exception

    assert result.body.length == 1
    assert result.orelse.length == 1
    assert result.body[0].type == 'ImportFrom'
    assert result.orelse[0].type == 'ImportFrom'


# Generated at 2022-06-25 22:04:10.343936
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    ast_59 = module_0.Import()
    ast_59.names = [ module_0.alias() ]
    ast_59.names[0].name = 'Transformer'
    ast_59.names[0].asname = 'BaseTransformer'
    ast_59.lineno = 0
    ast_59.col_offset = 0
    ast_59.end_lineno = 0
    ast_59.end_col_offset = 0
    try:
        _ast_59 = base_import_rewrite_0.visit_Import(ast_59)
    except Exception as e:
        pass


# Generated at 2022-06-25 22:04:14.265081
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = ast.Import()
    base_import_rewrite_0 = BaseImportRewrite(import_0)
    a_s_t_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:21.886025
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast

    import typed_ast._ast3 as module_0
    import_from_0 = module_0.ImportFrom()
    module_0.alias(import_from_0, 'name', alias_0)
    a_s_t_0 = module_0.ImportFrom()
    import_from_0.names.append(a_s_t_0)
    level_0 = module_0.Const(value=0, lineno=0)
    module_0.alias(import_from_0, 'level', level_0)
    module_0.alias(import_from_0, 'lineno', 0)
    module_0.alias(import_from_0, 'col_offset', 0)
    module_0.alias(import_from_0, 'ctx', None)


# Generated at 2022-06-25 22:04:29.656412
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    rewrite_0_name_0_name_0 = "module"
    rewrite_0_name_0_asname_0 = None
    rewrite_0_name_0_0 = ast.alias(rewrite_0_name_0_name_0, rewrite_0_name_0_asname_0)
    rewrite_0_name_0 = [rewrite_0_name_0_0]
    rewrite_0_0 = ast.Import(rewrite_0_name_0)
    rewrite_0 = rewrite_0_0
    base_import_rewrite_0._replace_import(rewrite_0, "from_", "to")

# Unit

# Generated at 2022-06-25 22:04:32.713095
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # User input for BaseImportRewrite.visit_Import
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:04:35.962283
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    alias_1 = module_0.alias()
    import_0 = module_0.Import([alias_1])
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    try_0 = base_import_rewrite_1.visit_Import(import_0)


# Generated at 2022-06-25 22:05:48.182762
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    try:
        a_l_i_a_s_0 = module_0.alias()
        import_from_0 = module_0.ImportFrom(names=[a_l_i_a_s_0], module="", level=None)
        base_import_rewrite_1.visit_ImportFrom(import_from_0)
    except AttributeError as err:
        print('AttributeError: ', err)
    except ImportError as err:
        print('ImportError: ', err)
    except EOFError as err:
        print('EOFError: ', err)

# Generated at 2022-06-25 22:05:55.506876
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    module_0_ImportFrom_0 = module_0.ImportFrom(a_s_t_0, 'a_s_t_0.module_0', ['a_s_t_0.module_0.test_case_1'], 0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._tree_changed = False

# Generated at 2022-06-25 22:06:03.854808
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    input_0 = (
        module_0.ImportFrom(module='typed_ast.ast3', names=[module_0.alias(name='Module', asname=None)], level=0)
    )
    input_1 = BaseImportRewrite(module_0.AST())
    input_2 = (
        module_0.ImportFrom(module='typed_ast.ast3', names=[module_0.alias(name='Module', asname=None)], level=0)
    )
    input_3 = BaseImportRewrite(module_0.AST())

# Generated at 2022-06-25 22:06:09.256680
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[module_0.alias(name='new_name', asname='new_name')])
    try:
        base_import_rewrite_0.visit_Import(import_0)
    except ImportError:
        pass

# Generated at 2022-06-25 22:06:16.585407
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..utils.snippet import snippet
    from ..utils.ast import parse
    from ..utils.source import source

    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_2
    import typed_ast._ast3 as module_3
    import typed_ast._ast3 as module_4
    import typed_ast._ast3 as module_5
    import typed_ast._ast3 as module_6
    import typed_ast._ast3 as module_7


# Generated at 2022-06-25 22:06:19.858072
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert a_s_t_1 is not None


# Generated at 2022-06-25 22:06:20.778443
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    try:
        assert False
        return
    except:
        pass


# Generated at 2022-06-25 22:06:25.104265
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0 = ast.Module()
    import_0 = ast.Import()
    module_0.body.append(import_0)
    base_import_rewrite_0 = BaseImportRewrite(module_0)
    base_import_rewrite_0._get_matched_rewrite = lambda x: ('a', 'b')
    base_import_rewrite_0._replace_import = lambda x, y, z: import_0
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:06:30.337965
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    alias_0_0 = module_0.alias('test', 'test1')
    a_s_t_0_0 = module_0.Import([alias_0_0])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        result_0 = base_import_rewrite_0.visit_Import(a_s_t_0_0)
    except Exception as e:
        result_0 = None
    assert_var_name = 'result_0'
    assert_test_name = 'test_BaseImportRewrite_visit_Import'
    assert_expected = None
    assert_value = result_0
    assert_result = assert_expected == assert_value