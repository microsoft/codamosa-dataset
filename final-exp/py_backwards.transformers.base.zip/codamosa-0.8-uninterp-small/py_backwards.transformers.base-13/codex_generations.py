

# Generated at 2022-06-25 21:56:51.401856
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test create a_s_t_0

    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    a_s_t_0.names = []
    a_s_t_0.args = []
    a_s_t_0.defaults = []
    a_s_t_0.fields = []
    a_s_t_0.comprehension = []
    a_s_t_0.decorator_list = []
    a_s_t_0.orelse = []
    a_s_t_0.finalbody = []
    a_s_t_0.keys = []
    a_s_t_0.values = []
    a_s_t_0.elts = []
    a_

# Generated at 2022-06-25 21:56:59.138948
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    from ...utils import method_test_template

    def test_func(test_case, test_instance):
        import typed_ast._ast3 as module_0
        a_s_t_0 = module_0.ImportFrom()

        # Call method
        x_t_1 = test_instance.visit_ImportFrom(a_s_t_0)

        # Assert return type
        assert x_t_1 is None

    class TestInstance:
        def visit_ImportFrom(self, a_s_t_0):
            return None

    class TestCase:
        pass

    test_instance = TestInstance()
    test_case = TestCase()

    method_test_template(test_func, test_case, test_instance)


# Generated at 2022-06-25 21:57:08.459781
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast
    # Instantiate an instance of class ImportFrom
    import_from = ast.ImportFrom(module='some.module',
                                 names=[ast.alias(name='SomeName',
                                                  asname=None), ast.alias(name='SomeTwo',
                                                                          asname='some_two')],
                                 level=0)
    a_s_t_1 = module_0.AST()
    rewrites_0 = [('six', 'six2')]
    # Instantiate an instance of class BaseImportRewrite with arguments
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1, rewrites=rewrites_0)
    # Call method visit_ImportFrom with arguments import_from
    function_result_1 = base_import_rewrite_1.visit_

# Generated at 2022-06-25 21:57:09.324138
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    pass


# Generated at 2022-06-25 21:57:17.936291
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias(name='name_0', asname='asname_0')
    import_from_0 = module_0.ImportFrom(module='module_0', names=[alias_0], level='level_0')
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    base_import_rewrite_0.rewrites = [('module_0', 'module_1')]
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    base_import_rewrite_0.rewrites = [('name_0', 'name_1')]
    base

# Generated at 2022-06-25 21:57:27.262823
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    a_s_t_3 = module_0.AST()
    base_import_rewrite_3 = BaseImportRewrite(a_s_t_3)
    a_s_t_4 = module_0.AST()

# Generated at 2022-06-25 21:57:36.327037
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_names_0 = "['baz']"
    import_0 = ast.Import(names=[ast.alias(name="baz",
                                          asname=None)])
    import_names_1_0 = ast.alias(name="baz",
                                 asname=None)

    a_s_t_0.body = [import_0]
    a_t_n_0 = module_0.Assign(target=a_s_t_0,
                              iter=None,
                              value=None,
                              type_comment=None)

# Generated at 2022-06-25 21:57:46.153643
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 21:57:50.324327
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try_0 = module_0.Try()
    ast_alias_0 = module_0.alias(alias_0_name, alias_0_asname)
    module_0.ImportFrom(try_0, ast_alias_0, alias_0_astore)


# Generated at 2022-06-25 21:57:54.147247
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(lineno=1, col_offset=1)
    base_import_rewrite_0.visit_ImportFrom(a_s_t_1)


# Generated at 2022-06-25 21:58:03.381119
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.Import(names=[module_0.alias(name='socketio', asname='socketio')])
    base_import_rewrite_0_e = BaseImportRewrite.visit_Import(base_import_rewrite_0, a_s_t_0)


# Generated at 2022-06-25 21:58:07.170941
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    module_0 = ast.Module(body=[])

    # Test
    base_import_rewrite_0.visit_Import(module_0)


# Generated at 2022-06-25 21:58:13.116750
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias()
    alias_0.name = "module_name"
    alias_0.asname = ""
    import_0 = module_0.Import()
    import_0.names = [alias_0]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:18.445489
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(name="name_0", asname="name_1")
    a_s_t_2 = module_0.Import(names=[alias_0])
    base_import_rewrite_0.visit(a_s_t_2)


# Generated at 2022-06-25 21:58:23.609935
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = alias(name='', asname='')
    i_m_p_0 = Import(names=[alias_0])
    base_import_rewrite_0.visit_Import(i_m_p_0)


# Generated at 2022-06-25 21:58:30.935473
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name='name_0', asname='asname_0')
    i_m_p_o_r_t_0 = module_0.Import(names=[a_l_i_a_s_0])
    base_import_rewrite_0.visit_Import(i_m_p_o_r_t_0)


# Generated at 2022-06-25 21:58:34.958623
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(None, None, None, None)
    base_import_rewrite_0.visit_ImportFrom(a_s_t_1)


# Generated at 2022-06-25 21:58:45.395670
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.stmt(ImportFrom(module='foo', level=0, names=[alias(name='bar', asname='bar')]))]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = base_import_rewrite_0.visit(a_s_t_0)

# Generated at 2022-06-25 21:58:56.258586
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import types
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    import_0 = module_0.Import()
    namespace_0 = module_0.NameSpace()
    alias_0 = module_0.alias()
    module_0.alias.name = type.__new__(str)
    module_0.alias.asname = type.__new__(str)
    module_0.alias.__init__(module_0.alias.name, module_0.alias.asname)
    module_0.Import.names = [alias_0]
    module_0.Import.__init__(module_0.Import.names)
    module_0.import_0 = import_0
    module_0.import_0.names[0] = module

# Generated at 2022-06-25 21:59:03.813254
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    typed_ast_0 = module_0.ImportFrom(module=a_s_t_0, level=1)
    typed_ast_1 = module_0.ImportFrom(module=a_s_t_0, level=1)
    typed_ast_2 = base_import_rewrite_0.visit_ImportFrom(typed_ast_0)
    try:
        typed_ast_2 == typed_ast_1
    except ValueError:
        pass


# Generated at 2022-06-25 21:59:22.064529
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias()
    a_s_t_0.names.append(a_l_i_a_s_0)
    import_0 = module_0.Import()
    import_0.names.append(a_l_i_a_s_0)
    base_import_rewrite_0.visit_Import(import_0)



# Generated at 2022-06-25 21:59:28.081919
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_2 = module_0.ImportFrom(level=23, module='w', names=[module_0.alias(name='k', asname=None), module_0.alias(name='t', asname='w')])
    a_s_t_2 = base_import_rewrite_0.visit_ImportFrom(a_s_t_2)

# Generated at 2022-06-25 21:59:31.117435
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0 = module_0
    import_0 = module_0.Import(names=[])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:40.797560
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from ast import ImportFrom, alias
    import_fro_0 = ImportFrom(module="six", names=[alias(name="foo")])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0, rewrites=[("six", "new_six")])
    t_r_y_0 = base_import_rewrite_0.visit_ImportFrom(import_fro_0)
    assert (isinstance(t_r_y_0, Try))
    assert (isinstance(t_r_y_0.handlers[0].body[1], ImportFrom))
    assert (t_r_y_0.handlers[0].body[1].module == "new_six")

# Generated at 2022-06-25 21:59:45.698478
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    i_m_p_0 = module_0.Import()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(i_m_p_0)


# Generated at 2022-06-25 21:59:49.589644
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_0 = module_0.ImportFrom(module="a",names=["b"])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    assert base_import_rewrite_0.visit_ImportFrom(import_0) is import_0


# Generated at 2022-06-25 21:59:56.043179
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Test when node.level is not equal to 0
    import_from_0 = module_0.ImportFrom(names=["a_s_t"], module="typed_ast", level=1)
    import_from_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert isinstance(import_from_0, module_0.ImportFrom)

# Generated at 2022-06-25 22:00:04.070586
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()

    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._get_matched_rewrite = lambda node_0: None

    import_0 = module_0.Import(names=[module_0.alias(name='num_py.pi',asname=None)])

    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:00:11.028721
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.ImportFrom(module = module_0.Name(id = "foo", ctx = module_0.Load()), level = 0, names = [module_0.alias(name = "bar", asname = None)])
    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(module_1)
    assert isinstance(a_s_t_1, module_0.Try)


# Generated at 2022-06-25 22:00:18.339889
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    rewrites_0 = ('', '')
    import_1 = module_0.Import(names=[])
    __traceback_info_0 = (import_1, rewrites_0)
    rewrites_0 = ('', '')
    import_2 = module_0.Import(names=[])
    __traceback_info_0 = (import_2, rewrites_0)
    rewrites_0 = ('', '')
    import_3 = module_0.Import(names=[])
    __traceback_info_0 = (import_3, rewrites_0)
    rewrites_0 = ('', '')
    import_

# Generated at 2022-06-25 22:00:53.775048
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    a_s_t_0 = module_0.AST()

    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    assert base_import_rewrite_0 is not None

    import_alias_0 = module_0.alias()
    import_alias_0.name = 'typed_ast.ast3'

    import_names_0 = module_0.Import()
    import_names_0.names = [import_alias_0]

    # Act
    a_s_t_0 = BaseImportRewrite.visit_Import(base_import_rewrite_0, import_names_0)

    # Assert
    assert a_s_t_0 is not None

    assert isinstance(a_s_t_0, module_0.Try)


# Generated at 2022-06-25 22:00:58.635564
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Input
    node = ast.ImportFrom(module='std.ctypes', names=[ast.alias(name='*')], level=0)
    # Expected output
    try_expr_0 = ast.Try()
    # Procedure
    try_expr_0 = base_import_rewrite_0._replace_import_from_module(node, 'std', 'stdlib')
    # Validate
    assert(try_expr_0 == ast.Try())


# Generated at 2022-06-25 22:01:08.578288
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_l_i_a_s_0 = module_0.alias(name='', asname=None)
    a_l_i_a_s_1 = module_0.alias(name='test_visit_Import', asname=None)
    a_l_i_a_s_2 = module_0.alias(name='test_visit_Import_new', asname=None)
    import_0 = module_0.Import(names=[a_l_i_a_s_1])
    expected_0 = module_0.Import(names=[a_l_i_a_s_2])
    actual_0 = base_import_

# Generated at 2022-06-25 22:01:15.559129
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from typing import List, Tuple

    import typed_ast._ast3 as module_0

    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Adding stubs to rewrites field
    import_1 = module_0.Import()
    alias_0 = module_0.alias()
    alias_0.name = "alias_0.name"
    import_1.names = [alias_0]
    base_import_rewrite_0.rewrites = [(alias_0.name, "alias_0.name")]

    # Calling visit_Import method with parameter import_1
    result = base_import_rewrite_0.visit_Import(import_1)
    assert result is not None

# Generated at 2022-06-25 22:01:25.768195
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias(name='asyncio',asname=None)
    import_from_0 = module_0.ImportFrom(module='module0',names=[alias_0],level=0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._get_matched_rewrite = lambda x: None
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:01:31.161524
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    stmt_import_0_0 = ast.Import(names=[
        ast.alias(name="six.moves.urllib",
                  asname=None)])
    a_s_t_0 = stmt_import_0_0
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [("six.moves", "six_moves")]
    base_import_rewrite_0.visit_Import(stmt_import_0_0)


# Generated at 2022-06-25 22:01:37.553313
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Import(names=[module_0.alias(name='typed_ast')])]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit(a_s_t_0)
    assert a_s_t_0.body == [module_0.Import(names=[module_0.alias(name='typed_ast')])]


# Generated at 2022-06-25 22:01:41.401847
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._tree_changed = 0 # type: ignore
    base_import_rewrite_0._get_matched_rewrite(None)


# Generated at 2022-06-25 22:01:53.176949
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    a_s_t_0.col_offset = int()
    a_s_t_0.end_lineno = int()
    a_s_t_0.lineno = int()
    a_s_t_0.col_offset = int()
    a_s_t_0.end_col_offset = int()
    a_s_t_0.level = int()
    a_s_t_0.end_lineno = int()
    a_s_t_0.lineno = int()
    a_s_t_0.col_offset = int()
    a_s_t_0.end_lineno = int()
    a_s_t_0.lineno = int()
    a_s_t_

# Generated at 2022-06-25 22:02:02.004256
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.ImportFrom(0, 'string', [], 0)
    base_import_rewrite_0.visit_ImportFrom(node_0)
    # TODO: derive_type(base_import_rewrite_0.visit(node_0))


# Generated at 2022-06-25 22:03:04.837146
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import typed_ast.ast3
    a_s_t_0 = typed_ast.ast3.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = typed_ast.ast3.Import()
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:09.605068
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        a_s_t_1 = module_0.AST()
        base_import_rewrite_0.rewrites = [('abc', 'def')]
        base_import_rewrite_0.visit_Import(a_s_t_1)
    except Exception as inst:
        pass


# Generated at 2022-06-25 22:03:20.814392
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = []
    module_0.Module(body=a_s_t_1.body)
    a_s_t_2 = module_0.AST()
    a_s_t_2.body = [a_s_t_1]
    module_0.Module(body=a_s_t_2.body)
    import_0 = module_0.Import()
    import_0.names = []
    module_0.Import(names=import_0.names)

# Generated at 2022-06-25 22:03:27.968413
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = []
    from_ = 'from'
    to = 'to'
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = rewrites
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_1.rewrites = [(from_, to)]
    a_s_t_2 = module_0.AST()
    base_import_rewrite_2 = BaseImportRewrite(a_s_t_2)
    base_import_rewrite_2.rewrites = [(from_, to)]


# Generated at 2022-06-25 22:03:36.966358
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Setup
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    old_node_0 = module_0.Import(names=[module_0.alias(name='typed_ast',
                                                       asname=None)])

    # Invocation
    result_0 = base_import_rewrite_0.visit_Import(old_node_0)

    # Verification
    try:
        assert result_0 == old_node_0
    except:
        base_import_rewrite_0.visit_Import(old_node_0)


# Generated at 2022-06-25 22:03:41.828740
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_9 = ast.Import(names=['a'])
    base_import_rewrite_0.visit(import_9)
    visited_attribute_of_import_9 = getattr(import_9, 'visited', None)
    assert(visited_attribute_of_import_9 is not None)


# Generated at 2022-06-25 22:03:46.168336
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import(names=[module_0.alias(name='typed_ast.ast3',
                                                     asname=None)])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_1 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:03:51.559709
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=0, module='name', names=[module_0.alias(asname='asname', name='name')])
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:03:59.027995
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_0 = module_0.Import(names=[module_0.alias(name='a')])
    base_import_rewrite_0._get_matched_rewrite = lambda name: ('', '')
    base_import_rewrite_0._replace_import = lambda node, from_, to: module_0.Try(body=[module_0.Import(names=[module_0.alias(name='a')])], orelse=[module_0.Import(names=[module_0.alias(name='a')])], finalbody=[])
    base_import_rewrite_0.visit(import_0)


# Generated at 2022-06-25 22:04:03.656625
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.Module(
        body=[
        ]
    )
    assert base_import_rewrite_0.visit(node_0) == node_0


# Generated at 2022-06-25 22:06:10.703503
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module='six',
                                        names=[module_0.alias(name='*'),
                                               module_0.alias(name='iteritems')],
                                        level=0)
    try_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert(try_0.body[0].value.value.get_code() == "import six")
    assert(try_0.body[0].value.value.values[0].asname == "six")
    assert(try_0.body[0].value.value.values[0].name == "six")

# Generated at 2022-06-25 22:06:17.626025
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[module_0.alias(name='collections.abc', asname='abc')])
    result_0 = base_import_rewrite_0.visit_Import(import_0)
    assert type(result_0) is module_0.Try
    assert result_0.body is not None
    assert result_0.body[0] is not None
    assert type(result_0.body[0]) is module_0.Pass
    assert result_0.finalbody is not None
    assert result_0.finalbody[0] is not None
    assert type(result_0.finalbody[0]) is module_

# Generated at 2022-06-25 22:06:20.913896
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_ast = ast.parse('from multiprocessing.dummy import Pool')
    test_visit = BaseImportRewrite(test_ast)
    test_visit.visit(test_ast)
    expected_ast = ast.parse('from multiprocessing import Pool\nfrom multiprocessing.dummy import Pool')
    assert ast.dump(expected_ast) == ast.dump(test_ast)

# Generated at 2022-06-25 22:06:26.661538
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    # Get source code
    source_code = inspect.getsource(test_BaseImportRewrite_visit_ImportFrom)
    # Set up context
    setup_context(source_code)

    # Create an instance of BaseImportRewrite class
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    # Create an instance of ClassDef class
    class_0 = module_0.ClassDef(name='Class0',
                                bases=[],
                                keywords=[],
                                body=[],
                                decorator_list=[])
    base_import_rewrite_0.visit(class_0)

    # Create an instance of FunctionDef class

# Generated at 2022-06-25 22:06:29.575842
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # This line raises an exception, rewriting fails
    #base_import_rewrite_0.visit_Import(a_s_t_0)

import typed_ast._ast3 as module_1
