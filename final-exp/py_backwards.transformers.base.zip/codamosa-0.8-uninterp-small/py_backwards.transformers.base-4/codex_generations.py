

# Generated at 2022-06-25 21:56:37.866030
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias()
    a_s_t_1 = module_0.AST()
    alias_1 = module_0.alias()
    import_from_0 = module_0.ImportFrom(module = "", names = [], level = 1)
    import_from_1 = module_0.ImportFrom(module = "", names = [alias_0, alias_1], level = 1)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_1)


# Generated at 2022-06-25 21:56:47.604690
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    all_rewrite_0 = [('typed_ast', 'typed_ast'), ('typed_ast', 'typed_ast.ast3')]
    rewrites_0 = set()
    rewrites_0 = rewrites_0.union({'typed_ast'})
    rewrites_0 = rewrites_0.union({'typed_ast.ast3'})
    base_import_rewrite_0.rewrites = [rewrites_0.pop() for _ in range(len(rewrites_0))]
    rewrote_name_0 = 'typed_ast'
    import_as_0 = None
    rewrote

# Generated at 2022-06-25 21:56:55.909927
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_node_0_0 = module_0.Import()
    import_node_0_0.names.append(module_0.alias("name_0_0"))
    node_0_0 = base_import_rewrite_0.visit_Import(import_node_0_0)
    assert type(node_0_0) == module_0.Import
    assert node_0_0.names[0].name == "name_0_0"


# Generated at 2022-06-25 21:57:00.282602
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    test_object_0 = module_0.Import()
    try:
        base_import_rewrite_0.visit_Import(test_object_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 21:57:09.667716
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    module_0.AST()
    BaseImportRewrite.rewrites = []
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import()
    base_import_rewrite_0.visit_Import(import_0)
    BaseImportRewrite.rewrites = [('')]
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    import_1 = module_0.Import(names=[module_0.alias(name='')])
    base_import_rewrite_1.visit_Import(import_1)

# Generated at 2022-06-25 21:57:14.620831
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    node = ast.Import(names=[
        ast.alias(name="old_module",
                  asname=None)])  # type: ast.Import

    result = base_import_rewrite_0.visit_Import(node)

    assert result == node



# Generated at 2022-06-25 21:57:17.001189
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

# Generated at 2022-06-25 21:57:21.161442
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import(['astropy'])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:57:28.110689
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('names', 'names_')]
    i_m_p_0 = module_0.Import(names=[module_0.alias(name='names', asname=None)])
    transform_0 = BaseImportRewrite.transform(i_m_p_0)
    assert transform_0 == TransformationResult(None, True, [])

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 21:57:32.169334
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=0)
    base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 21:57:57.086696
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test 0
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level = 0, module = 'logging', names = [module_0.alias(name = 'getLogger', asname = None)])
    import_from_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert_equal(type(import_from_0), module_0.ImportFrom, 'AssertionError: {0}'.format(type(import_from_0)))
    assert_equal(import_from_0.level, 0, 'AssertionError: {0}'.format(import_from_0.level))
   

# Generated at 2022-06-25 21:58:01.485500
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    with pytest.raises(NotImplementedError):
        a_s_t_0 = module_0.AST()
        base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
        base_import_rewrite_0.visit_Import(a_s_t_0)


# Generated at 2022-06-25 21:58:05.778025
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    names_0 = [module_0.alias(name='a')]
    import_0 = module_0.Import(names=names_0)

    result = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:58:11.271910
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(None)
    try:
        base_import_rewrite_0.visit_Import(import_0)
        assert 0, "Expected exception"
    except AssertionError:
        pass


# Generated at 2022-06-25 21:58:19.574323
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom(
        lineno=0,
        col_offset=0,
        level=0,
        module='',
        names=[],
        type_comment=None
    )
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    method_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)    
    assert isinstance(method_0, module_0.AST)


# Generated at 2022-06-25 21:58:26.501318
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    a_s_t_1 = module_0.Import(module_0.alias(name='module_0',
                                             asname=None),
                              module_0.alias(name='module_1',
                                             asname=None))
    assert base_import_rewrite_0.visit_Import(a_s_t_1) == a_s_t_1


# Generated at 2022-06-25 21:58:33.525385
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.AST()
    import_from_0 = module_0.ImportFrom(module_1, [], 0)
    module_0.Try(module_1, [], [], [], 0, None)
    module_0.alias(module_0.alias(module_0.alias(module_1, "Module0"), "module_0"), "module_1")


# Generated at 2022-06-25 21:58:41.831903
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Import()
    a_s_t_2 = module_0.alias()
    a_s_t_1.names = [a_s_t_2, ]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._get_matched_rewrite(a_s_t_1.names[0].name)
    base_import_rewrite_0._replace_import(a_s_t_1, *base_import_rewrite_0._get_matched_rewrite(a_s_t_1.names[0].name))

# Generated at 2022-06-25 21:58:45.352506
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 21:58:50.054379
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    test_code = 'import a'
    root = ast.parse(test_code)
    node = root.body[0]
    class_0 = BaseImportRewrite(root)
    base_node_transformer_0 = class_0.visit(node)
    assert isinstance(base_node_transformer_0, ast.Try)


# Generated at 2022-06-25 21:59:13.256872
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    str_0 = "Module"
    str_1 = "Module"
    str_2 = "AsName"
    alias_0 = module_0.alias(str_1, asname=str_2)
    import_1 = module_0.Import(names=[alias_0])
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    str_3 = "Module"
    str_4 = "Module"
    str_5 = "AsName"
    alias_1 = module_0.alias(str_4, asname=str_5)

# Generated at 2022-06-25 21:59:18.212344
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    alias_0 = module_0.alias(name='name_0', asname=None)
    import_0 = module_0.Import(names=[alias_0])
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 21:59:26.956504
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    from datetime import datetime
    from types import ModuleType
    
    module_0 = ModuleType('testModule')
    
    module_0.datetime = datetime
    
    module_0.a_s_t_0 = module_0.datetime.astimezone
    
    target = module_0.a_s_t_0
    
    module_0.a_s_t_1 = module_0.a_s_t_0
    
    expected = module_0.a_s_t_1
    
    module_0.a_s_t_2 = module_0.a_s_t_0
    
    module_0.a_s_t_3 = ("")
    
    module_0.a_s_t_4 = module_0.a_s_t_

# Generated at 2022-06-25 21:59:30.185700
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.Import()
    node_1 = base_import_rewrite_0.visit_Import(node_0)


# Generated at 2022-06-25 21:59:38.805015
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.Import([module_0.alias(name='a', asname=None)])
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_0._tree_changed = True
    base_import_rewrite_0._get_matched_rewrite = lambda arg_0: (arg_0, 'b')
    base_import_rewrite_0.rewrites = [(('c', 'd'),)]
    base_import_rewrite_0.visit_Import(a_s_t_0)


# Generated at 2022-06-25 21:59:46.184168
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_from_0 = module_0.ImportFrom(names=[], module='foo', level=0)
    t_y_p_e_0 = type(import_from_0)
    union_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    assert type(union_0) == t_y_p_e_0


# Generated at 2022-06-25 21:59:54.483465
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Assignment to a_s_t_2.Module
    a_s_t_2 = module_0.Module()
    # Assignment to a_s_t_4.Name
    a_s_t_4 = module_0.Name()
    a_s_t_4.id = 1
    # Assignment to a_s_t_4.ctx
    a_s_t_6 = module_0.Load()
    a_s_t_4.ctx = a_s_t_6
    # Assignment to a_s_t_8.Alias
    a_s_t_8 = module_0.alias()
    a_s_t_

# Generated at 2022-06-25 22:00:04.279178
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.ImportFrom()
    module_0.Import

# Generated at 2022-06-25 22:00:11.194892
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    module_0_0 = a_s_t_0.body[0]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_from_0 = ast.ImportFrom(module=a_from_0.module,
                              names=module_0_0.names,
                              level=a_from_0.level)
    a_from_1 = ast.ImportFrom(module=module_0_0.module,
                              names=a_from_1.names,
                              level=module_0_0.level)

# Generated at 2022-06-25 22:00:12.008005
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_case_0()

# Generated at 2022-06-25 22:00:33.026989
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast

    __tracebackhide__ = True

# Generated at 2022-06-25 22:00:39.239630
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    tree = ast.parse(textwrap.dedent("""
        import testModule
        import testModule.testModule1
        import testModule.testModule2 as testModule2
        """))
    tree = BaseImportRewrite.transform(tree)
    print(astunparse.unparse(tree))
    assert astunparse.unparse(tree) == textwrap.dedent("""
        import testModule
        import testModule.testModule1
        import testModule.testModule2 as testModule2
        """)


# Generated at 2022-06-25 22:00:43.981153
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    tree = ast.parse(test_case_0.__code__.co_consts[0])
    transformer = BaseImportRewrite(tree)
    node = tree.body[0]
    expected = ast.ImportFrom(module='testModule',
                              names=[],
                              level=0)
    assert transformer.visit_ImportFrom(node) == expected

# Generated at 2022-06-25 22:00:47.072645
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewriter = BaseImportRewrite(None)
    module = ast.parse(str_0, 'example_file.py')
    rewriter.visit(module)

if __name__ == '__main__':
    test_BaseImportRewrite_visit_Import()

# Generated at 2022-06-25 22:00:50.741295
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # test input, expected output
    test_cases = [
        (1, 2),
        (2, 3)
    ]

    for i, test_case in enumerate(test_cases):
        print(i)
        assert test_case[0] == test_case[1]

# Generated at 2022-06-25 22:00:54.143436
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    rewrites = [('itertools', 'iterators')]

    class BaseImportRewriteMock(BaseImportRewrite):
        rewrites = rewrites

    BaseImportRewriteMock.transform(ast.parse(test_case_0.__annotations__[str_0]))

# Generated at 2022-06-25 22:00:56.128972
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_str = 'import testModuleName'
    str_1 = 'import testModuleName'

    if str_1 != import_str:
        import testModuleName


# Generated at 2022-06-25 22:01:00.657590
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..utils.inspect import get_ast, get_node_targets

    tree = get_ast(test_case_0)
    node = list(get_node_targets(tree, ast.Import))[0]

    # Instantiate the class and check that the output is correct
    BaseImportRewrite(tree).visit_Import(node)


# Generated at 2022-06-25 22:01:04.798536
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Calling the function with arguments
    str_1 = test_case_0()

    assert str_1 == 'testModule'


# Generated at 2022-06-25 22:01:09.952447
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    rewrites = [('test1', 'test2')]
    node = ast.parse(str_0).body[0]

    import_rewrite_0 = BaseImportRewrite(node)
    import_rewrite_0.rewrites = rewrites

    import_rewrite_0.visit_ImportFrom(node)

# Generated at 2022-06-25 22:01:23.866097
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # pass
    try:
        str_0 = 'testModule'
    except ImportError:
        str_0 = 'testModule'

    assert str_0 == 'testModule'


# Generated at 2022-06-25 22:01:31.790790
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    str_0 = 'testModule'
    str_1 = 'testModule_1'
    str_2 = 'testModule.testModule_2.testModule_3'
    str_3 = 'testModule_2'
    str_4 = 'testModule_3'
    module_name = 'import {0} as {1}\nimport {2} as {3}\nimport {4}'.format(str_2, str_3, str_0, str_1, str_4)
    node_0 = ast.parse(module_name).body[0]
    node_1 = ast.parse(module_name).body[1]
    node_2 = ast.parse(module_name).body[2]
    class_0 = BaseImportRewrite()

# Generated at 2022-06-25 22:01:39.283664
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import ast
    import astunparse
    import python_modernize

    mod = ast.parse(test_case_0.__code__.co_consts[0])
    python_modernize.log.debug(astunparse.unparse(mod))

    rewriter = python_modernize.refactor.ConvertModuleImports('testModule', 'test.test_module')
    new_mod = rewriter.visit(mod)
    python_modernize.log.debug(astunparse.unparse(new_mod))

    assert astunparse.unparse(new_mod) == "try:\n    import testModule\nexcept ImportError:\n    import test.test_module\n"

# Generated at 2022-06-25 22:01:47.456296
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    def try_import_0(from_, to):
        import_rewrite(from_, to)
    BaseImportRewrite = BaseImportRewrite()
    Import_0 = ast.Import(str_0)
    ast.ImportFrom(str_0)
    try_import_0(Import_0)

    # import testModule
    # try:
    #     import testModule
    # except ImportError:
    #     import testModule as testModule


# Generated at 2022-06-25 22:01:49.132603
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Create an instance of class BaseImportRewrite
    # Call method visit_ImportFrom
    # assert ...
    pass


# Generated at 2022-06-25 22:01:52.798460
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Setup
    import_1 = ast.ImportFrom(module='testModule')

    Instance_0 = BaseImportRewrite.transform(import_1)

    # Assertion
    assert isinstance(Instance_0, ast.ImportFrom)


# Generated at 2022-06-25 22:02:04.659368
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    str_1 = '__import__'
    str_2 = 'testModule'
    str_3 = 'testModule'
    str_4 = 'testModule'
    str_5 = 'testModule'
    int_0 = 0
    str_6 = '__import__'
    str_7 = 'testModule'
    str_8 = 'testModule'
    str_9 = 'testModule'
    str_10 = 'testModule'
    int_1 = 0
    str_11 = '__import__'
    str_12 = 'testModule'
    str_13 = 'testModule'
    str_14 = 'testModule'
    str_15 = 'testModule'
    int_2 = 0
    obj_0 = BaseImportRewrite()
    obj_0.rewrites = []
    obj_0

# Generated at 2022-06-25 22:02:08.494893
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    str_0 = 'testModule'
    obj_0 = BaseImportRewrite_visit_ImportFrom()
    str_1 = 'testModule'
    obj_0.visit_ImportFrom(str_1)
    return None


# Generated at 2022-06-25 22:02:16.867200
# Unit test for method visit_ImportFrom of class BaseImportRewrite

# Generated at 2022-06-25 22:02:21.978354
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Local variables
    var_0 = None
    var_1 = None
    # Create an instance of BaseImportRewrite
    var_0 = BaseImportRewrite()
    # Call method visit_ImportFrom
    var_1 = var_0.visit_ImportFrom(var_0)
    # assert var_1 == None

if __name__ == '__main__':
    test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 22:02:40.713231
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try:
        import_1 = module_0.Import(names=module_0.alias(name='2.1', asname='2.1'))
        base_import_rewrite_0.visit_Import(import_1)
    except Exception as e:
        print("Exception: {}".format(e))


# Generated at 2022-06-25 22:02:44.030149
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_.rewrites = [("import_names", "import_names_0")]
    x1 = base_import_rewrite_.visit_Import(base_import_rewrite_.rewrites)


# Generated at 2022-06-25 22:02:50.325301
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import(names=[module_0.alias(name='x1', asname=None)])
    import_1 = module_0.Import(names=[module_0.alias(name='x2', asname=None)])
    import_2 = module_0.Import()
    try_0 = module_0.Try()
    try_0.body = [import_1]
    try_0.handlers = [module_0.ExceptHandler(type=None, name=None, body=[])]
    try_0.orelse = []
    try_0.finalbody = []
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0._

# Generated at 2022-06-25 22:02:58.868935
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.tree_changed = 0
    base_import_rewrite_0.rewrites = [(str(), str())]
    import_0 = module_0.Import()
    import_0.names = [module_0.alias()]
    import_0.names[0].name = str()
    import_0.names[0].asname = None
    import_0.names[0].asname = str()
    try_0 = module_0.Try()
    try_0.body = [import_0]
    try_0.body = None
    try_0.body = []

# Generated at 2022-06-25 22:03:06.462940
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Init signature
    signature_0 = ast.ImportFrom(module='str', names=[], level=1)
    # Assert type
    assert isinstance(signature_0, ast.ImportFrom)
    # Init body
    body_0 = []
    # Init decorator_list
    decorator_list_0 = []
    # Init returns
    returns_0 = None
    # Init args
    args_0 = ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    # Init name
    name_0 = 'a'
    # Init arg
    arg_

# Generated at 2022-06-25 22:03:13.377312
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    import_from_2 = module_0.ImportFrom(module='test_module', level=0,
                                        names=[module_0.alias(name='a', asname=None)])
    a_s_t_1.body = [import_from_2]
    a_s_t_1.body[0].names[0].name = 'b'  # <-- may change the type of the argument
    try_3 = base_import_rewrite_0.visit_ImportFrom(a_s_t_1.body[0])

# Generated at 2022-06-25 22:03:21.064961
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    try_0 = module_0.Try()
    attributes_0 = a_s_t_0.typed_fields_default
    list_0 = attributes_0.get('body')
    list_0.append(try_0)
    base_import_rewrite_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:03:22.216543
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a = BaseImportRewrite([])
    a.visit_Import([])


# Generated at 2022-06-25 22:03:25.456305
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_from_0 = module_0.ImportFrom()
    transformer_0 = base_import_rewrite_0.visit_ImportFrom(import_from_0)
    pass


# Generated at 2022-06-25 22:03:29.367572
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom(names=[module_0.alias(name='_a', asname=None)], level=None)

    # Call method
    base_import_rewrite_0.visit_ImportFrom(a_s_t_1)

# Generated at 2022-06-25 22:04:02.675736
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import sys
    import ast
    import tempfile
    import textwrap
    import typing
    import types

    code = '''
    import typing
    '''

    expected_code = '''
    try:
        import typing
    except ImportError:
        import typing
    '''

    source_ast = compile(code, '<string>', 'exec', flags=ast.PyCF_ONLY_AST)
    expected_ast = compile(expected_code, '<string>', 'exec', flags=ast.PyCF_ONLY_AST)

    module = types.ModuleType(__name__)
    module.__file__ = __file__
    sys.modules[__name__] = module

    base_import_rewrite_0 = BaseImportRewrite(source_ast)

    # Compare expected and received ASTs
    received

# Generated at 2022-06-25 22:04:10.645923
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    source_lines_1 = ["from past.utils import old_div"]
    source_code_1 = "\n".join(source_lines_1)
    import_0 = ast.parse(source_code_1).body[0]
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    result_1 = base_import_rewrite_0.visit_Import(import_0)
    assert str(result_1) == "try:\n    from past.builtins import old_div\nexcept ImportError:\n    from builtins import div as old_div" == str(result_1)


# Generated at 2022-06-25 22:04:19.100403
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    i_m_p_0 = module_0.Import(names=[module_0.alias(name='ast', asname=None)])
    a_s_t_0.body.append(i_m_p_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [('typed_ast', 'asttyped')]

# Generated at 2022-06-25 22:04:23.563446
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Create an instance of class BaseImportRewrite with argument a_s_t_0
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Call method visit_ImportFrom of base_import_rewrite_0 with argument import_from_0
    return base_import_rewrite_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:04:28.096269
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    ast_alias_0 = module_0.alias()
    ast_import_0 = module_0.Import(names=[ast_alias_0])
    base_import_rewrite_0.visit_Import(ast_import_0)


# Generated at 2022-06-25 22:04:34.398844
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.alias()
    a_s_t_2 = module_0.alias(a_s_t_1, module_0.Str('a'))
    a_s_t_3 = module_0.alias(a_s_t_1, module_0.Str('b'))
    a_s_t_4 = module_0.alias(a_s_t_1, module_0.Str('c'))
    a_s_t_5 = module_0.alias(a_s_t_1, module_0.Str('d'))
    a_s_t_6 = module_

# Generated at 2022-06-25 22:04:41.162280
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    rewrotes = module_0.ImportFrom(level=1, module='a.b', names=[
        module_0.alias(asname='c', name='d')])
    node = module_0.ImportFrom(level=1, module='a.b', names=[
        module_0.alias(asname='e', name='f')])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(
        'a.b',
        'a.b'
    )]

# Generated at 2022-06-25 22:04:46.644824
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_node_2 = ast.Import(names=[ast.alias(name='six.moves.queue',
                                                asname='queue')])

    try:
        extend(import_node_2)
    except ImportError:
        extend(ast.Import(names=[ast.alias(name='queue',
                                           asname='queue')]))

    try:
        extend(ast.Import(names=[ast.alias(name='six.moves.queue',
                                           asname='queue')]))
    except ImportError:
        extend(ast.Import(names=[ast.alias(name='queue',
                                           asname='queue')]))

# Generated at 2022-06-25 22:04:52.913868
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = None  # type: Optional[str]
    rewrite_0 = None  # type: Tuple[str, str]
    alias_0 = None  # type: ast.alias
    names_to_replace_0 = None  # type: Dict[str, Tuple[str, str]]
    names_to_replace_0 = {
    }
    node_0 = None  # type: ast.ImportFrom
    alias_0 = ast.alias(name='name_0', asname=alias_0)
    node_0 = ast.ImportFrom(module=module_0, names=[alias_0], level=node_0)
    rewrite_0 = (
    )
    names_to_replace_0 = {
    }
    module_0 = None  # type: Optional[str]

# Generated at 2022-06-25 22:04:55.692161
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    for rewrite in BaseImportRewrite.rewrites:
        import_from = ast.ImportFrom(module=rewrite[0],
                                     names=[rewrite[0].split('.')[-1]],
                                     level=0)
        result = BaseImportRewrite(None).visit(import_from)
        assert type(result) != ast.ImportFrom

# Generated at 2022-06-25 22:05:52.463601
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    full_name_1 = 'os.path'
    name_1 = 'path'
    module_name_1 = 'os'
    level_1 = 0
    alias_1 = ast.alias(name_1, None)
    node_1 = ast.ImportFrom(module_name_1, [alias_1], level_1)
    base_import_rewrite_1.visit_ImportFrom(node_1)


# Generated at 2022-06-25 22:05:53.276127
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    assert False,"TODO"



# Generated at 2022-06-25 22:05:58.738670
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(names=[module_0.alias(asname=None, name='*')], level=0, module='os')
    ast_2 = base_import_rewrite_1.visit_ImportFrom(i_m_p_o_r_t_f_r_o_m_0)
    assert isinstance(ast_2, module_0.ImportFrom)


# Generated at 2022-06-25 22:06:08.772079
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Set imports
    module_0 = module_0
    import_from_0 = module_0.ImportFrom
    import_0 = module_0.Import
    # Create objects
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    import_1 = import_0(names=[])
    # Set fields
    base_import_rewrite_1.rewrites = [(
        'a', 'b')]
    # Call method
    returned_value_0 = base_import_rewrite_1.visit_ImportFrom(import_1)
   

# Generated at 2022-06-25 22:06:12.881485
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.target = 'import time'
    a_s_t_0_0 = a_s_t_0
    assert a_s_t_0_0 == base_import_rewrite_0.visit_Import(a_s_t_0_0)



# Generated at 2022-06-25 22:06:17.792874
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_1 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.Import(names=[
        module_0.alias(name=None,
                       asname=None)],
                             lineno=None,
                             col_offset=None)
    a_s_t_3 = base_import_rewrite_1.visit_Import(a_s_t_2)


# Generated at 2022-06-25 22:06:19.520455
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    a_l_i_a_s_0 = module_0.alias("a", "b")
#import typed_ast


# Generated at 2022-06-25 22:06:25.030595
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    input_0 = module_0.Import(names=[module_0.alias(name='foo.bar', asname='bar')])
    expected_output_0 = module_0.Import(names=[module_0.alias(name='foo.bar', asname='bar')])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = [(str, str)]
    actual_output_0 = base_import_rewrite_0.visit_Import(input_0)
    assert actual_output_0 == expected_output_0
