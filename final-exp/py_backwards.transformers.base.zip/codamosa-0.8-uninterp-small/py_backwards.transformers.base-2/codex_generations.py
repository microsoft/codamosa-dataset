

# Generated at 2022-06-25 21:56:35.125715
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names = [module_0.alias(name = "math", asname = "math_alias")])
    import_1 = base_node_transformer_0.visit_Import(import_0)


# Generated at 2022-06-25 21:56:37.690510
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    
    python_s_t_0 = ast.parse("from typing import Union")
    base_import_rewrite_0 = BaseImportRewrite()
    base_import_rewrite_0.visit_ImportFrom(python_s_t_0.body[0])

# Generated at 2022-06-25 21:56:45.660223
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_rewrite_from_0 = module_0.ImportFrom()
    base_import_rewrite_0 = BaseImportRewrite()
    try:
        result_0 = base_import_rewrite_0.visit_ImportFrom(import_rewrite_from_0)
    except Exception as error:
        print("Test case 0:", str(error))
        raise Exception
    else:
        if import_rewrite_from_0.module == result_0.module:
            print("Test case 1:")
        else:
            print("Test case 2:")

test_BaseImportRewrite_visit_ImportFrom()

# Generated at 2022-06-25 21:56:55.646032
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # AST is <class '_ast.Module'>
    module_0 = ast.Module(body=[
        ast.ImportFrom(
            module='foo',
            names=[ast.alias(name='*',
                             asname=None)],
            level=0),
        ast.ImportFrom(
            module='foo.bar',
            names=[ast.alias(name='baz',
                             asname=None),
                   ast.alias(name='qux',
                             asname=None)],
            level=0)])
    base_import_rewrite_0 = BaseImportRewrite(module_0)
    assert base_import_rewrite_0._tree_changed == False
    ast_1 = base_import_rewrite_0.visit_ImportFrom(module_0.body[0])

# Generated at 2022-06-25 21:57:05.152494
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    node_0 = module_0.ImportFrom(level=0, module='test')
    result_0 = base_node_transformer_0.visit_ImportFrom(node_0)
    assert isinstance(result_0, ast.Try)
    node_1 = ast.parse('from b import insert')
    result_1 = base_node_transformer_0.visit_ImportFrom(node_1)
    assert isinstance(result_1, ast.Try)
    node_2 = ast.parse('from b import insert')
    result_2 = base_node_transformer_0.visit_ImportFrom(node_2)

# Generated at 2022-06-25 21:57:12.476302
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = module_0.Import(names=[module_0.alias()])
    method_result_1 = base_import_rewrite_0.visit_Import(import_0)
    assert method_result_1 is None, "base_import_rewrite_0.visit_Import(import_0) returned %s instead of %s" % (method_result_1, None)


# Generated at 2022-06-25 21:57:21.356831
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_0 = module_0.Import()
    import_0.names.append(module_0.alias())
    import_0.names[0].name = 'foo'
    import_0.names[0].asname = 'foo'
    import_0.col_offset = 0
    import_0.lineno = 0
    base_import_rewrite_0 = BaseImportRewrite(import_0)
    base_import_rewrite_0._tree_changed = bool()
    base_import_rewrite_0._get_matched_rewrite(arg_0='foo')

# Generated at 2022-06-25 21:57:29.602916
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Creation of object
    a_s_t_0 = module_0.AST()
    # Creation of object
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    # Creation of object
    module_1 = module_0.Name(id="module", ctx=module_0.Load())
    # Creation of object
    module_2 = module_0.alias(name="name", asname="asname")
    # Creation of object
    module_3 = module_0.Import(names=[module_2])
    # Invoking method visit_Import of base_import_rewrite_0 with module_3
    base_import_rewrite_0.visit_Import(module_3)


# Generated at 2022-06-25 21:57:38.750099
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    i_m_p_0 = module_0.ImportFrom(
        level=0,
        module="m1")
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite()

    t_r_y_0 = base_import_rewrite_0.visit_ImportFrom(i_m_p_0)
    assert isinstance(t_r_y_0, module_0.Try)
    assert t_r_y_0.body is None
    assert t_r_y_0.handlers is None
    assert t_r_y_0.finalbody is None
    assert t_r_y_0.orelse is None


# Generated at 2022-06-25 21:57:45.922441
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    """Test for method visit_ImportFrom"""
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    node_0 = module_0.ImportFrom(level=1, module='', names=[])
    # Check that:
    result_0 = base_node_transformer_0.visit_ImportFrom(node_0)
    # result is equal to node_0
    assert result_0 == node_0


# Generated at 2022-06-25 21:58:08.134559
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import ast


# Generated at 2022-06-25 21:58:16.820019
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from_0, to_0 = 'os', 'posix'
    arg0 = 'os'
    arg1 = 'posix'
    rewrites_0 = [('os', 'posix')]

    class BaseImportRewrite_0(BaseImportRewrite):
        rewrites = []

    baseimportrewrite_0 = BaseImportRewrite_0(rewrites=rewrites_0)

    class BaseImportRewrite_1(BaseImportRewrite):
        rewrites = rewrites_0

    baseimportrewrite_1 = BaseImportRewrite_1(rewrites=rewrites_0)

    class BaseImportRewrite_2(BaseImportRewrite):
        rewrites = rewrites_0

    baseimportrewrite_2 = BaseImportRewrite_2(rewrites=rewrites_0)


# Generated at 2022-06-25 21:58:24.171198
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import astor
    base_import_rewrite_0 = BaseImportRewrite(
        ast.parse(
            'import foo'))
    base_import_rewrite_0._get_matched_rewrite('foo')
    base_import_rewrite_0._replace_import(ast.parse('import foo'), 'foo',
                                          'bar')
    assert astor.to_source(
        base_import_rewrite_0.visit(ast.parse(
            'import foo'))) == 'try:\n    import foo\nexcept ImportError:\n    import bar\n'


# Generated at 2022-06-25 21:58:33.448750
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class TestBaseImportRewrite(BaseImportRewrite):
        rewrites = [('tensorflow', 'tensorflow_test')]
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            self.visit_count = 0
        def visit_Import(self, node: ast.Import) -> Union[ast.Import, ast.Try]:
            self.visit_count += 1
            return super().visit_Import(node)

# Generated at 2022-06-25 21:58:38.021350
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class Transformer(BaseImportRewrite):
        rewrites = [
            ('argparse', 'docopt'),
            ('argparse.ArgumentParser', 'docopt')
        ]

    tree = ast.parse('from argparse import ArgumentParser')
    result = Transformer.transform(tree)
    assert isinstance(result[0].body[0], ast.Try)
    assert isinstance(result[0].body[0].body[0], ast.ImportFrom)
    # TODO: Check values


# Generated at 2022-06-25 21:58:48.523575
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewriteTest(BaseImportRewrite):
        rewrites = [
            ('os', 'my_os'),
        ]

    import_ast = ast.parse('import os').body[0]
    try_expected = ast.Try(body=[
        ast.Import(names=[ast.alias(name='os', asname=None)]),
    ],
        handlers=[ast.ExceptHandler(type=ast.Name(id='ImportError', ctx=ast.Load()),
                                    name=None,
                                    body=[
                                        ast.Import(names=[ast.alias(name='my_os', asname=None)])
                                    ])],
        orelse=[],
        finalbody=[])
    assert BaseImportRewriteTest().visit(import_ast) == try_expected



# Generated at 2022-06-25 21:58:57.468157
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # test for case: node is not None, rewrite is not None
    node = ast.Import()
    rewrite = ('from_', 'to')
    inst = BaseImportRewrite(node)

    result = inst._replace_import(node, rewrite[0], rewrite[1])

    assert isinstance(result, ast.Try)
    assert inst._tree_changed is True

    # test for case: node is None, rewrite is not None
    node = None
    rewrite = ('from_', 'to')
    inst = BaseImportRewrite(node)

    result = inst._replace_import(node, rewrite[0], rewrite[1])

    assert isinstance(result, ast.Try)
    assert inst._tree_changed is True



# Generated at 2022-06-25 21:59:10.076994
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Test case 1
    class TestCase_1_Base(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    node = ast.parse('from six import string_types')
    target = TestCase_1_Base.transform(node)
    print(ast.dump(target.tree))
    assert ast.dump(target.tree) == 'Module(body=[ImportFrom(module=\'six.moves\', names=[alias(name=\'string_types\', asname=None)], level=0)])'

    # Test case 2
    class TestCase_2_Base(BaseImportRewrite):
        rewrites = [('six', 'six.moves')]
    node = ast.parse('from six import (string_types)')
    target = TestCase_2_Base.transform

# Generated at 2022-06-25 21:59:19.153851
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # Case 0
    from_0 = "argparse"
    to_0 = "argparse"
    t_0 = BaseImportRewrite()
    t_0.rewrites = [(from_0, to_0)]
    t_0.rewrites.extend(BaseImportRewrite.rewrites)
    tree_0 = ast.parse("import argparse\n")
    t_0.transform(tree_0)

    # Case 1
    from_1 = "a"
    to_1 = "b"
    t_1 = BaseImportRewrite()
    t_1.rewrites = [(from_1, to_1)]
    t_1.rewrites.extend(BaseImportRewrite.rewrites)
    tree_1 = ast.parse("import argparse\n")

# Generated at 2022-06-25 21:59:27.690591
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    from ..types import CompilationTarget
    from ..utils.snippet import extend

    import sys

    # need to put path to rst render module in path
    sys.path.append('../')

    rewrites = [
        ('rst_render', 'rst_render.rst_render')]

    try:
        extend(rewrites)
    except ImportError:
        extend(rewrites)

    obj_0 = BaseImportRewrite(None)

    def import_rewrite_preprocessed_0(previous, current):
        try:
            extend(rewrites)
        except ImportError:
            extend(rewrites)


# Generated at 2022-06-25 21:59:49.025434
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Setup
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    base_node_transformer_0.rewrites = [
        ('a', 'b')
    ]
    base_node_transformer_0.dependencies = [
        'a'
    ]
    base_node_transformer_0.dependencies = [
        'b'
    ]
    import_from_0 = module_0.ImportFrom(module="a",
                                        names=[
                                        module_0.alias(name="a",
                                        asname="a")],
                                        level=1)

    # Exercise
    result_0 = base_node_transformer_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 21:59:56.536211
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # Instantiate a BaseImportRewrite
    base_node_transformer_0 = BaseNodeTransformer()
    a_s_t_0 = ast.AST()
    # Instantiate a ImportFrom
    module_0 = None
    names_0 = []
    level_0 = None
    import_from_0 = ast.ImportFrom(module=module_0, names=names_0, level=level_0)
    # Call method visit_ImportFrom of BaseImportRewrite with arguments
    # import_from_0
    # Expecting a Try
    try:
        base_node_transformer_0.visit_ImportFrom(import_from_0)
    except BaseException:
        assert False



# Generated at 2022-06-25 21:59:57.506624
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():

    assert True == True

# Generated at 2022-06-25 22:00:02.703351
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_from_0 = module_0.ImportFrom(module_0, names_0, level_0)
    result = base_import_rewrite_0.visit_ImportFrom(import_from_0)

# Generated at 2022-06-25 22:00:06.776587
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.Import()
    base_node_transformer_0.visit_Import(a_s_t_1)


# Generated at 2022-06-25 22:00:10.460591
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():


    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    import_0 = ast.Import()
    base_import_rewrite_0_copy_0 = base_import_rewrite_0.visit(import_0)


# Generated at 2022-06-25 22:00:14.590750
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.ImportFrom(module='module_0', names=['a_s_t_0'], level='0')
    base_import_rewrite_0.visit_ImportFrom(module_1)

# Generated at 2022-06-25 22:00:16.472859
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)


# Generated at 2022-06-25 22:00:22.750306
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    a_s_t_2 = module_0.AST()
    import_0 = module_0.Import(names = [module_0.alias(name = "string_a", asname = None)])
    module_0.copy_location(import_0, a_s_t_2)
    result = base_import_rewrite_0.visit_Import(import_0)



# Generated at 2022-06-25 22:00:29.398346
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    b_a_s_t_0 = module_0.Import(names=[module_0.alias(name='a', asname='a', internal=True, partial_clsname='Alias')])
    try:
        int_0 = base_import_rewrite_0.visit_Import(b_a_s_t_0)
    except Exception as e_0:
        print(type(e_0), e_0)
    else:
        print('OK!')

# Generated at 2022-06-25 22:00:50.972927
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites = []
    a_s_t_1 = module_0.Import(names=[module_0.alias(name=__name__, asname=None)])
    base_import_rewrite_0._replace_import(a_s_t_1, 'test_transforms.visitors', 'test_transforms.visitors')
    assert True


# Generated at 2022-06-25 22:00:54.613820
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_1)
    base_node_transformer_0.visit_ImportFrom(a_s_t_2)


# Generated at 2022-06-25 22:00:58.991550
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    class_type_0 = BaseImportRewrite()
    class_type_0.rewrites = []
    a_s_t_0 = module_0.ImportFrom(level=0, module=None, names=[], lineno=0, col_offset=0)
    try:
        class_type_0.visit_ImportFrom(a_s_t_0)
    except:
        pass


# Generated at 2022-06-25 22:01:08.699966
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom('lorem', [], 1)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.rewrites.append((
        'lorem',
        'ipsum'))

    # Unit test for the unit test

    # Unit test for the unit test

    # Unit test for the assert

    # Unit test for the assert
    assert isinstance(base_import_rewrite_0.visit_ImportFrom(import_from_0), module_0.Try)

    # Unit test for the assert

    # Unit test for the assert
    assert base_import_rewrite_0._tree

# Generated at 2022-06-25 22:01:15.661192
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    import_node_0 = a_s_t_0.import_type('a')

    base_import_rewrite_type_0 = BaseImportRewrite
    base_import_rewrite_type_0.rewrites = [('a', 'b')]

    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    unit_test_result_0 = base_import_rewrite_0.visit_Import(import_node_0)

    expected_result_0 = snippet.get_body(previous=import_node_0,  # type: ignore
                                         current=ast.Import(names=[ast.alias(name='b.a',
                                                                             asname='a')]))[0]

   

# Generated at 2022-06-25 22:01:28.476526
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()

    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)

    import_0 = module_0.Import(names=[
        module_0.alias(name='sqlalchemy', asname=None),
        module_0.alias(name='sqlalchemy.orm', asname=None),
        module_0.alias(name='sqlalchemy.ext.declarative', asname=None)])

# Generated at 2022-06-25 22:01:38.622858
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom()
    try:
        import_0 = base_node_transformer_0.visit_ImportFrom(a_s_t_1)
        raise RuntimeError("Test Failed")
    except:
        pass

    try:
        import_1 = base_node_transformer_0.visit_ImportFrom(a_s_t_1)
        raise RuntimeError("Test Failed")
    except:
        pass


# Generated at 2022-06-25 22:01:47.835968
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    alias_0 = module_0.alias(ast_0, ast_0)
    import_0 = module_0.Import(names_0, ast_0)
    __call__1_0 = base_import_rewrite_0.visit_Import(import_0)


# Generated at 2022-06-25 22:01:55.065238
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    module_0 = ast.Module([
        ast.Assign(
            targets=[
                ast.Name(
                    id='L2',
                    ctx=ast.Store())],
            value=ast.Num(n=5)),
        ast.Import(
            names=[
                ast.alias(
                    name='module_4',
                    asname=None)]),
        ast.ImportFrom(
            module='module_4',
            names=[
                ast.alias(
                    name='L5',
                    asname='L6')],
            level=None)])
    base_import_rewrite_0 = BaseImportRewrite(module_0)
    base_import_rewrite_0.visit_ImportFrom(module_0.body[2])


# Generated at 2022-06-25 22:01:55.843356
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    pass

# Generated at 2022-06-25 22:02:29.011482
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = ast.Import()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)


# Generated at 2022-06-25 22:02:37.027600
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a = [
        ast.arg(arg='arg_0', annotation=None)
    ]
    f = ast.FunctionDef(name='f', args=ast.arguments(args=a, vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    g = ast.FunctionDef(name='g', args=ast.arguments(args=a, vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    m = ast.Module([f, g])
    base_node_transformer_0 = BaseImportRewrite(m)

# Generated at 2022-06-25 22:02:43.934815
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    import_0 = module_0.Import()
    import_rewrite_0 = BaseImportRewrite()
    rewrite_0 = rewrite_0
    base_import_rewrite_0 = BaseImportRewrite()
    import_1 = module_0.Import()
    class_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    list_0 = module_0.List()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_2 = import_2
    try_0 = module_0.Try()
    a_s_t_1 = module_0.AST()
    import_3 = import_3
    base_node_transformer_1 = BaseNodeTransformer(a_s_t_1)
   

# Generated at 2022-06-25 22:02:50.246826
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrire_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_1)

    import_from_0 = module_0.ImportFrom()
    import_from_0.level = 0

    ast_node_0 = base_import_rewrire_0.visit_ImportFrom(import_from_0)

    base_import_rewrire_0.visit_ImportFrom(import_from_0)

    base_import_rewrire_0._replace_import_from_module(import_from_0, '_random', 'typing')

# Unit test

# Generated at 2022-06-25 22:02:58.812446
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    class BaseImportRewrite_visit_Import_Transformer0(BaseImportRewrite):
        rewrites = [(0, 1)]
        dependencies = []
        def visit_Import(self, node):
            if node:
                self._tree_changed = True
                return node
            return None
        def visit_ImportFrom(self, node):
            return None
        def visit(self, node):
            return node
    class BaseImportRewrite_visit_Import_Transformer1(BaseImportRewrite):
        rewrites = [(0, 1)]
        dependencies = []
        def visit_Import(self, node):
            if node:
                self._tree_changed = True
                return node
            return None
        def visit_ImportFrom(self, node):
            return None
        def visit(self, node):
            return node

# Generated at 2022-06-25 22:03:04.892647
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    test_BaseImportRewrite_visit_ImportFrom_obj = BaseImportRewrite()
    test_BaseImportRewrite_visit_ImportFrom_ob_0 = module_0.AST()
    test_BaseImportRewrite_visit_ImportFrom_ob_1 = module_0.ImportFrom(names=test_BaseImportRewrite_visit_ImportFrom_ob_0.names, module=test_BaseImportRewrite_visit_ImportFrom_ob_0.module, level=test_BaseImportRewrite_visit_ImportFrom_ob_0.level)
    test_case_0(test_BaseImportRewrite_visit_ImportFrom_obj, test_BaseImportRewrite_visit_ImportFrom_ob_1)

# Generated at 2022-06-25 22:03:10.421117
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    import_from_s_t_0 = module_0.ImportFrom(level=0, module="module_1",
                                            names=[module_0.alias(name="name_0", asname="asname_1")])
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    base_import_rewrite_0.visit_ImportFrom(import_from_s_t_0)
    a_s_t_0.body = [import_from_s_t_0]


# Generated at 2022-06-25 22:03:17.081604
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_1 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    do_something_0 = module_0.Import(names=[module_0.alias(name="do_something", asname=None)])
    base_import_rewrite_0.visit(do_something_0)


# Generated at 2022-06-25 22:03:23.022148
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseImportRewrite(a_s_t_0)
    i_m_p_o_r_t_0 = module_0.Import(names=[])
    base_node_transformer_0.visit_Import(i_m_p_o_r_t_0)


# Generated at 2022-06-25 22:03:29.907565
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom("A.B", [module_0.alias(name="C")], 1)
    base_import_rewrite_0.visit_ImportFrom(a_s_t_1)
    import_0 = module_0.ImportFrom("B.C", [module_0.alias(name="C")], 1)
    import_1 = module_0.ImportFrom("A.B", [module_0.alias(name="C")], 1)

# Generated at 2022-06-25 22:04:33.293226
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    with pytest.raises(NotImplementedError):
        base_import_rewrite_0.visit_ImportFrom([])

# Generated at 2022-06-25 22:04:38.250565
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    import_from_0 = module_0.ImportFrom(level=0, module='foo', 
                                        names=[module_0.alias(name='foo', 
                                                              asname=None)])
    class DerivedClass_0(BaseImportRewrite):
        pass

    derived_class_0 = DerivedClass_0(a_s_t_0)
    result = derived_class_0.visit_ImportFrom(import_from_0)

    assert result == import_from_0


# Generated at 2022-06-25 22:04:39.467279
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    # TODO: Unit test for method visit_ImportFrom of class BaseImportRewrite
    assert False



# Generated at 2022-06-25 22:04:45.949989
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    # A test case with the module of NodeTransformer
    a_s_t_0 = ast.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_node_0 = ast.Import(names=[ast.alias(name="abc", asname=None)])
    import_node_0_return_value = base_node_transformer_0.visit_Import(import_node_0)
    assert  isinstance(import_node_0_return_value, ast.Import)
    # A test case with the module of NodeTransformer
    a_s_t_1 = ast.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)

# Generated at 2022-06-25 22:04:49.281677
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    ast_import_0 = module_0.Import(names = [module_0.alias(name = 'a_s_t', asname = 'a_s_t')])
    assert BaseImportRewrite.transform(ast_import_0)


# Generated at 2022-06-25 22:04:52.823967
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
    import_from_0 = module_0.ImportFrom(level=None,names=["abc"],module="abc")
    import_from_1 = base_node_transformer_0.visit_ImportFrom(import_from_0)


# Generated at 2022-06-25 22:05:03.112905
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    a_s_t_1 = module_0.ImportFrom()
    a_s_t_1.module = "base_import_rewrite_0"

# Generated at 2022-06-25 22:05:12.687732
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_1 = module_0.AST()
    alias_0 = module_0.alias(name='list', asname=None)
    f_rom_0 = 'list'
    list_0 = module_0.List([
        alias_0],
        ctx=None)
    import_from_0 = module_0.ImportFrom(module=f_rom_0,
                                        names=list_0,
                                        level=1)
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_1)
    base_import_rewrite_1 = base_import_rewrite_0._replace_import_from_module(import_from_0, f_rom_0, 'typing')


# Generated at 2022-06-25 22:05:18.625816
# Unit test for method visit_ImportFrom of class BaseImportRewrite
def test_BaseImportRewrite_visit_ImportFrom():
    a_s_t_0 = module_0.AST()
    base_import_rewrite_0 = BaseImportRewrite(a_s_t_0)
    module_1 = module_0.ImportFrom(a_s_t_0, [])
    a_s_t_1 = base_import_rewrite_0.visit_ImportFrom(module_1)


# Generated at 2022-06-25 22:05:22.214474
# Unit test for method visit_Import of class BaseImportRewrite
def test_BaseImportRewrite_visit_Import():
    a_s_t_0 = module_0.AST()
    base_node_transformer_0 = BaseNodeTransformer(a_s_t_0)
