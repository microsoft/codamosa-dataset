

# Generated at 2022-06-17 06:02:22.649826
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('\'foo\\\'bar\'') == 'foo\\\'bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote('\\"foo"') == '\\"foo"'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\\\"') == 'foo\\\\\\\\'

# Generated at 2022-06-17 06:02:36.225211
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == '"foo\'"'

# Generated at 2022-06-17 06:02:45.036948
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'
    assert unquote('"foo"bar"baz') == '"foo"bar"baz'

# Generated at 2022-06-17 06:02:58.522393
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('foo')
    assert not is_quoted('"')
    assert not is_quoted("'")
    assert not is_quoted('\\"')
    assert not is_quoted("\\'")
    assert not is_quoted('"\\"')

# Generated at 2022-06-17 06:03:05.675248
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\"bar\\\\\\""') == 'foo\\\\\\"bar\\\\\\"'
    assert unquote('"foo\\\\\\"bar\\\\\\"baz"') == 'foo\\\\\\"bar\\\\\\"baz'
    assert unquote('"foo\\\\\\"bar\\\\\\"baz\\\\\\""') == 'foo\\\\\\"bar\\\\\\"baz\\\\\\"'
   

# Generated at 2022-06-17 06:03:13.925467
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\\"bc"') == 'a\\"bc'
    assert unquote("'a\\'bc'") == "a\\'bc"
    assert unquote('"a\\"b\\"c"') == 'a\\"b\\"c'
    assert unquote("'a\\'b\\'c'") == "a\\'b\\'c"
    assert unquote('"a\\\\bc"') == 'a\\\\bc'
    assert unquote("'a\\\\bc'") == 'a\\\\bc'
    assert unquote('"a\\\\\\"bc"') == 'a\\\\\\"bc'
    assert unquote("'a\\\\\\'bc'") == "a\\\\\\'bc"

# Generated at 2022-06-17 06:03:22.195763
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo\\"bar') == 'foo\\"bar'
    assert unquote('foo\\"bar"') == 'foo\\"bar"'
    assert unquote('"foo\\"bar') == '"foo\\"bar'
   

# Generated at 2022-06-17 06:03:31.454020
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo\'\\"') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'
    assert unquote('"foo\'\\"\\""') == 'foo\'\\"\\"'
    assert unquote('"foo\'\\"\\"\\""') == 'foo\'\\"\\"\\"'

# Generated at 2022-06-17 06:03:39.043357
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'

# Generated at 2022-06-17 06:03:51.600036
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'
    assert unquote('"foo"bar"baz') == '"foo"bar"baz'