

# Generated at 2022-06-17 06:02:22.803914
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\"bar\\\\\\""') == 'foo\\\\\\"bar\\\\\\"'

# Generated at 2022-06-17 06:02:34.050104
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"

# Generated at 2022-06-17 06:02:43.926274
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote("'foo'bar") == "'foo'bar"

# Generated at 2022-06-17 06:02:54.279963
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:02.422886
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote("'foo\\'bar") == "'foo\\'bar"
    assert unquote("foo\\'bar'") == "foo\\'bar'"
    assert unquote("foo\\'bar") == "foo\\'bar"
    assert unquote("'foo\\'bar\\'baz'") == "foo\\'bar\\'baz"
    assert unquote("'foo\\'bar\\'baz") == "'foo\\'bar\\'baz"

# Generated at 2022-06-17 06:03:12.839449
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:24.136703
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\\"bc"') == 'a"bc'
    assert unquote('"a\\\\bc"') == 'a\\bc'
    assert unquote('"a\\"b\\"c"') == 'a"b"c'
    assert unquote('"a\\\\b\\\\c"') == 'a\\b\\c'
    assert unquote('"a\\\\\\"b\\\\\\"c"') == 'a\\"b\\"c'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('"abc\'') == '"abc\''
    assert unquote('\'abc"') == '\'abc"'
    assert unquote('\'abc\'') == 'abc'


# Generated at 2022-06-17 06:03:32.163765
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('\\"foo\\"')
    assert not is_quoted("\\'foo\\'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('"foo"bar')
    assert not is_quoted("'foo'bar")
    assert not is_quoted('foo')


# Generated at 2022-06-17 06:03:44.301896
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello"\'') == 'hello"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert un

# Generated at 2022-06-17 06:03:52.828440
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'
    assert un