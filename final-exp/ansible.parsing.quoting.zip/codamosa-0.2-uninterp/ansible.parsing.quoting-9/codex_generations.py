

# Generated at 2022-06-17 06:02:22.334061
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo""bar"') == 'foo"bar'
    assert unquote('""foo""') == '"foo"'
    assert unquote('""foo"') == '"foo'
    assert unquote('"foo""') == 'foo"'
    assert unquote('"foo" "bar"') == '"foo" "bar"'
    assert unquote('"foo"bar')

# Generated at 2022-06-17 06:02:36.109641
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('\\"foo"')
    assert not is_quoted("\\'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_

# Generated at 2022-06-17 06:02:44.974017
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar') == 'foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('"foo"bar"baz"') == 'foo"bar"baz'

# Generated at 2022-06-17 06:02:58.523965
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('\\"foo\\"') == '\\"foo\\"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote('"foo"\\"') == '"foo"\\"'
    assert unquote('\\"foo"') == '\\"foo"'
    assert un

# Generated at 2022-06-17 06:03:05.242070
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'
    assert unquote('"foo"bar"baz') == '"foo"bar"baz'

# Generated at 2022-06-17 06:03:13.529776
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('hello') == 'hello'
    assert unquote('"hello\\""') == 'hello"'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'hello\\''") == "hello'"
    assert unquote("'hello\\'") == "'hello\\'"
    assert unquote("'hello\\'\\''") == "hello\\''"
    assert unquote("'hello\\'\\'") == "'hello\\'\\'"

# Generated at 2022-06-17 06:03:22.709814
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:31.676955
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo" "bar"') == '"foo" "bar"'
    assert unquote('"foo" "bar') == '"foo" "bar'
    assert unquote('foo" "bar"') == 'foo" "bar"'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-17 06:03:39.200460
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'

# Generated at 2022-06-17 06:03:51.770763
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello" world') == '"hello" world'
    assert unquote('"hello\\""') == '"hello\\""'
    assert unquote('"hello\\\\""') == '"hello\\\\"'
    assert unquote('"hello\\\\\\""') == '"hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == '"hello\\\\\\\\"'
    assert unquote('"hello\\\\\\\\\\""') == '"hello\\\\\\\\\\"'
    assert unquote('"hello\\\\\\\\\\\\""') == '"hello\\\\\\\\\\\\"'