

# Generated at 2022-06-17 06:02:22.739962
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('""foo""') == '"foo"'
    assert unquote('""foo"') == '"foo'
    assert unquote('"foo""') == 'foo"'
    assert unquote('"foo" "bar"') == 'foo" "bar'
    assert unquote('"foo" "bar') == 'foo" "bar'

# Generated at 2022-06-17 06:02:29.586134
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-17 06:02:41.280396
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo\'"') == 'foo\''
    assert unquote("'foo\"'") == 'foo"'
    assert unquote('"foo\\"') == 'foo\\'
    assert unquote("'foo\\'") == 'foo\\'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote("'foo\\\\'") == 'foo\\\\'
    assert unquote('"foo\\\\\\"') == 'foo\\\\\\'

# Generated at 2022-06-17 06:02:56.099298
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo"bar'
    assert unquote("'foo\\'bar'") == "foo'bar"
    assert unquote('"foo\\\\"') == 'foo\\'
    assert unquote("'foo\\\\'") == "foo\\"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'') == 'foo\''
    assert unquote('"foo"bar"') == 'foo"bar"'

# Generated at 2022-06-17 06:03:02.062757
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:16.971351
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo""bar"') == 'foo"bar'
    assert unquote('"""foo"""') == '"foo"'
    assert unquote("'''foo'''") == "'foo'"
    assert unquote("'foo''bar'") == 'foo''bar'

# Generated at 2022-06-17 06:03:25.366732
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\'') == 'hello\''
    assert unquote('"hello\\"') == 'hello\\"'
    assert unquote('"hello\\\\"') == 'hello\\\\'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\"') == 'hello\\\\\\\\'
    assert unquote

# Generated at 2022-06-17 06:03:38.066668
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\'bar"')
    assert not is_quoted("'foo\"bar'")
    assert not is_quoted('"foo\\"bar"')
    assert not is_quoted("'foo\\'bar'")
    assert not is_quoted('"foo\\\\"bar"')
    assert not is_quoted("'foo\\\\'bar'")

# Generated at 2022-06-17 06:03:44.726132
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'

# Generated at 2022-06-17 06:03:52.849811
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote('"foo""bar"') == 'foo""bar'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\\'") == "'foo\\'"
    assert unquote("'foo''bar'") == "foo''bar"
    assert unquote("foo") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("'foo\\'")