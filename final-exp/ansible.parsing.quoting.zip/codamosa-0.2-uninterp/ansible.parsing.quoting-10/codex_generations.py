

# Generated at 2022-06-17 06:02:20.871194
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:02:27.365594
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo""bar"') == '"foo""bar"'
    assert un

# Generated at 2022-06-17 06:02:36.076649
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"


# Generated at 2022-06-17 06:02:44.481844
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hel"lo') == 'hel"lo'
    assert unquote('hel\'lo') == 'hel\'lo'
    assert unquote('"hel\\"lo"') == 'hel"lo'
    assert unquote("'hel\\'lo'") == 'hel\'lo'
    assert unquote('"hel\\\\lo"') == 'hel\\lo'
    assert unquote("'hel\\\\lo'") == 'hel\\lo'


# Generated at 2022-06-17 06:02:58.494280
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('""foo""') == '"foo"'
    assert unquote('""foo"') == '"foo'
    assert unquote('"foo""') == 'foo"'
    assert unquote('"foo" "bar"') == 'foo" "bar'
    assert unquote('"foo" "bar') == 'foo" "bar'
    assert unquote('"foo"bar')

# Generated at 2022-06-17 06:03:05.642829
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('\\"foo\\"') == '\\"foo\\"'
    assert unquote('"\\"foo\\""') == '\\"foo\\"'
    assert unquote('"foo"bar') == 'foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'

# Generated at 2022-06-17 06:03:12.286628
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('\\"foo\\"')
    assert not is_quoted("\\'foo\\'")


# Generated at 2022-06-17 06:03:24.086222
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"bar"') == 'foo\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'

# Generated at 2022-06-17 06:03:32.137289
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\'\\""') == 'hello\'\\""'
    assert unquote('"hello\'\\""') == 'hello\'\\""'
    assert unquote('"hello\'\\""') == 'hello\'\\""'
    assert unquote('"hello\'\\""') == 'hello\'\\""'

# Generated at 2022-06-17 06:03:44.297879
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote("'hello\"'") == 'hello\"'
    assert unquote('"hello\"') == 'hello\"'
    assert unquote("'hello\'") == 'hello\''
    assert unquote('"hello" world') == '"hello" world'
    assert unquote("'hello' world") == "'hello' world"