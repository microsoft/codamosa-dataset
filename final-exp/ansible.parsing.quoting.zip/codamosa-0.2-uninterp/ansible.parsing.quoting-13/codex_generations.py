

# Generated at 2022-06-17 06:02:17.847061
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:02:24.932044
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"') == 'foo\\"'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\\\"') == 'foo\\\\\\\\'
    assert unquote('"foo\\\\\\\\\\""') == 'foo\\\\\\\\\\"'

# Generated at 2022-06-17 06:02:33.508869
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted('"foo\'bar"')
    assert not is_quoted('"foo\\"bar"')


# Generated at 2022-06-17 06:02:43.620866
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == '"foo"bar"'

# Generated at 2022-06-17 06:02:51.182912
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo')
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:00.761853
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\\\"') == 'foo\\\\\\\\'
    assert unquote('"foo\\\\\\\\\\""') == 'foo\\\\\\\\\\"'
    assert unquote('"foo\\\\\\\\\\"bar"') == 'foo\\\\\\\\\\"bar'
    assert unquote('"foo\\\\\\\\\\\\""') == 'foo\\\\\\\\\\\\"'

# Generated at 2022-06-17 06:03:16.074288
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\\\"') == 'foo\\\\\\\\'
    assert unquote('"foo\\\\\\\\\\""') == 'foo\\\\\\\\\\"'
    assert unquote('"foo\\\\\\\\\\"bar"') == 'foo\\\\\\\\\\"bar'
    assert unquote('"foo\\\\\\\\\\\\""') == 'foo\\\\\\\\\\\\"'

# Generated at 2022-06-17 06:03:30.457805
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar')
    assert not is_quoted("'foo'bar")
    assert not is_quoted('"fo\'o"')
    assert not is_quoted("'fo\"o'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:38.640521
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar"baz"') == 'foo"bar"baz'

# Generated at 2022-06-17 06:03:51.485766
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\""') == 'hello\\\\\\\\\\"'