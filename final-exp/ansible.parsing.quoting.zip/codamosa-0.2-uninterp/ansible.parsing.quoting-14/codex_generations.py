

# Generated at 2022-06-17 06:02:21.952711
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo\'\\"') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'

# Generated at 2022-06-17 06:02:35.864043
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\'') == 'hello\''
    assert unquote('"hello\\"') == 'hello\\"'
    assert unquote('"hello\\\\"') == 'hello\\\\'
    assert unquote('"hello\\\\\\"') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\"') == 'hello\\\\\\\\'
    assert unquote

# Generated at 2022-06-17 06:02:44.862878
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'

# Generated at 2022-06-17 06:02:58.527125
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar""') == '"foo"bar"'
    assert unquote('""foo"bar""') == '"foo"bar"'
    assert unquote('""foo"bar"') == '"foo"bar"'

# Generated at 2022-06-17 06:03:05.241367
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo\\"bar') == '"foo\\"bar'
    assert unquote("'foo\\'bar") == "'foo\\'bar"
    assert unquote('foo\\"bar"') == 'foo\\"bar"'
    assert unquote("foo\\'bar'") == "foo\\'bar'"
   

# Generated at 2022-06-17 06:03:13.517373
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote("'foo\\'") == "'foo\\'"
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote

# Generated at 2022-06-17 06:03:24.369686
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote("foo") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("'foo'bar") == "'foo'bar"
    assert unquote("foo'bar") == "foo'bar"
    assert unquote("foo\\'bar") == "foo\\'bar"
    assert unquote("foo'bar'baz") == "foo'bar'baz"

# Generated at 2022-06-17 06:03:38.035181
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo\'\\"') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'
    assert unquote('"foo\'\\""') == 'foo\'\\"'

# Generated at 2022-06-17 06:03:44.725963
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\'bar"')
    assert not is_quoted("'foo\"bar'")
    assert not is_quoted('"foo\\"bar"')
    assert not is_quoted("'foo\\'bar'")
    assert not is_quoted('"foo\\\\"bar"')
    assert not is_quoted("'foo\\\\'bar'")

# Generated at 2022-06-17 06:03:52.850432
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar"baz"') == 'foo"bar"baz'