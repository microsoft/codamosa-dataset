

# Generated at 2022-06-17 06:02:22.779349
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'') == '"hello\''
    assert unquote('"hello\\"') == '"hello\\"'
    assert unquote('"hello\\\\"') == '"hello\\\\"'
    assert unquote('"hello\\\\\\""') == '"hello\\\\\\""'
    assert unquote('"hello\\\\\\\\"') == '"hello\\\\\\\\"'
    assert unquote('"hello\\\\\\\\\\""') == '"hello\\\\\\\\\\""'

# Generated at 2022-06-17 06:02:36.346718
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\'') == 'hello\''
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\"'

# Generated at 2022-06-17 06:02:45.080189
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('test"')
    assert not is_quoted("test'")
    assert not is_quoted('"test""')
    assert not is_quoted("'test''")
    assert not is_quoted('"test"test"')
    assert not is_quoted("'test'test'")
    assert not is_quoted('"test\\""')
    assert not is_quoted("'test\\''")
    assert not is_quoted('"test\\\\""')
    assert not is_quoted("'test\\\\''")
    assert not is_quoted('"test\\\\\\""')


# Generated at 2022-06-17 06:02:55.268525
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar\\"') == '"foo"bar\\"'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'

# Generated at 2022-06-17 06:03:03.306361
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote("'foo\"")

# Generated at 2022-06-17 06:03:17.087350
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\\\"') == 'foo\\\\\\\\'
    assert unquote('"foo\\\\\\\\\\""') == 'foo\\\\\\\\\\"'
    assert unquote('"foo\\\\\\\\\\"bar"') == 'foo\\\\\\\\\\"bar'


# Generated at 2022-06-17 06:03:24.033874
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:30.010708
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted('"fo"o"')
    assert not is_quoted('"foo\\""')


# Generated at 2022-06-17 06:03:39.859805
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo\\"bar') == '"foo\\"bar'
    assert unquote("'foo\\'bar") == "'foo\\'bar"
    assert unquote('foo\\"bar"') == 'foo\\"bar"'
    assert unquote("foo\\'bar'") == "foo\\'bar'"
   

# Generated at 2022-06-17 06:03:52.229288
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'hello\\''") == "'hello\\''"
    assert unquote("'hello'world'") == "'hello'world'"
    assert unquote("'hello\"'") == "'hello\"'"
    assert unquote("'hello\"world'") == "'hello\"world'"
    assert unquote("\"hello'") == "\"hello'"
    assert unquote("\"hello'world\"") == "\"hello'world\""
    assert unquote("\"hello\\\"\"") == "\"hello\\\"\""
    assert unquote("\"hello\\\"world\"") == "\"hello\\\"world\""