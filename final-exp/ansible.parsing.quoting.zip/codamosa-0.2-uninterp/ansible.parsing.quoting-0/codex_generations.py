

# Generated at 2022-06-17 06:02:11.797633
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted("hello'")
    assert not is_quoted('"hello\'')
    assert not is_quoted("'hello\"")
    assert not is_quoted('hello')


# Generated at 2022-06-17 06:02:18.710479
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-17 06:02:25.163724
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\\\""') == 'foo\\\\\\"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar\\"') == '"foo"bar\\"'
   

# Generated at 2022-06-17 06:02:31.146893
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('foo')
    assert not is_quoted('"')
    assert not is_quoted("'")
    assert not is_quoted('\\"')
    assert not is_quoted("\\'")
    assert not is_quoted('"\\"')

# Generated at 2022-06-17 06:02:42.227167
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('\\"foo"')
    assert not is_quoted("\\'foo'")
    assert not is_quoted('"foo\\"bar"')
    assert not is_quoted("'foo\\'bar'")

# Generated at 2022-06-17 06:02:57.060629
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('\\"foo"')
    assert not is_quoted("\\'foo'")
    assert not is_quoted('foo')
    assert not is_quoted('"')
    assert not is_quoted("'")

# Generated at 2022-06-17 06:03:04.702944
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote("'foo\"")

# Generated at 2022-06-17 06:03:17.777758
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello" world') == '"hello" world'
    assert unquote('"hello\\" world') == '"hello\\" world'
    assert unquote('"hello" world"') == '"hello" world"'
    assert unquote('"hello" world"') == '"hello" world"'
    assert unquote('"hello" world\\"') == '"hello" world\\"'
    assert unquote('"hello" world\\""') == '"hello" world\\""'

# Generated at 2022-06-17 06:03:33.976643
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'

# Generated at 2022-06-17 06:03:42.696909
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo""bar"') == 'foo"bar'
    assert unquote('"foo""bar') == 'foo""bar'
    assert unquote('"foo"\'bar\'') == 'foo\'bar\''