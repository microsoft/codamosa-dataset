

# Generated at 2022-06-17 06:02:18.831127
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('hello') == 'hello'
    assert unquote('"hello\\""') == '"hello\\""'
    assert unquote('"hello\\\\""') == 'hello\\\\'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\""') == 'hello\\\\\\\\\\"'
    assert unquote('"hello\\\\\\\\\\\\""') == 'hello\\\\\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\\\\\""') == 'hello\\\\\\\\\\\\\\"'
    assert unquote('"hello\\\\\\\\\\\\\\""') == 'hello\\\\\\\\\\\\\\"'

# Generated at 2022-06-17 06:02:25.214764
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\""') == 'hello\\\\\\\\\\"'

# Generated at 2022-06-17 06:02:34.050204
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert is_quoted('"foo\""')
    assert is_quoted("'foo\''")


# Generated at 2022-06-17 06:02:42.080227
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'

# Generated at 2022-06-17 06:02:54.970402
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('\\"foo"')
    assert not is_quoted("\\'foo'")


# Generated at 2022-06-17 06:03:03.047043
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == 'foo\\\'bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote("'foo\"")

# Generated at 2022-06-17 06:03:17.028856
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('\\"foo\\"') == '\\"foo\\"'
    assert unquote('"\\"foo\\""') == '\\"foo\\"'
    assert unquote('"foo\\"') == 'foo\\"'
    assert unquote('"foo"\\"') == 'foo"\\"'
    assert unquote('"foo"bar') == '"foo"bar'

# Generated at 2022-06-17 06:03:25.385375
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo\'bar"') == '"foo\'bar"'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\bar"') == 'foo\\\\bar'
    assert unquote('"foo\\\\"bar"') == 'foo\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'


# Generated at 2022-06-17 06:03:34.774250
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted("hello'")
    assert not is_quoted('"hello\'')
    assert not is_quoted("'hello\"")


# Generated at 2022-06-17 06:03:45.640208
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar"baz"') == '"foo"bar"baz"'