

# Generated at 2022-06-17 06:02:20.897634
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('"foo\\"bar\'') == 'foo\\"bar\''
    assert unquote("'foo\\'bar\"") == "foo\\'bar\""
    assert un

# Generated at 2022-06-17 06:02:27.393928
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\\"bc"') == 'a\\"bc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('"abc\\"') == '"abc\\"'
    assert unquote('"abc\\"\\"') == '"abc\\"\\"'
    assert unquote('"abc\\"\\""') == 'abc\\"\\"'
    assert unquote('"abc\\"\\"\\""') == '"abc\\"\\"\\"'
    assert unquote('"abc\\"\\"\\"\\""') == 'abc\\"\\"\\"'

# Generated at 2022-06-17 06:02:37.308516
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"bar"') == 'foo\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'

# Generated at 2022-06-17 06:02:47.989065
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote("foo") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("'foo\\'") == "'foo\\'"
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote("'foo\\'bar") == "'foo\\'bar"
    assert unquote('"foo\\"bar') == '"foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"


# Generated at 2022-06-17 06:02:57.099731
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('"foo\\\\\\""')
    assert not is_quoted("'foo\\\\\\''")


# Generated at 2022-06-17 06:03:03.880941
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('""foo""') == '"foo"'
    assert unquote('""foo"') == '"foo'
    assert unquote('"foo""') == 'foo"'
    assert unquote('"foo" "bar"') == 'foo" "bar'
    assert unquote('"foo" "bar') == 'foo" "bar'
    assert unquote('"foo"bar')

# Generated at 2022-06-17 06:03:17.402806
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''

# Generated at 2022-06-17 06:03:25.472204
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote('"foo\\\\"') == '"foo\\\\"'
    assert unquote('"foo\\\\\\"') == '"foo\\\\\\"'
    assert unquote('"foo\\\\\\\\"') == '"foo\\\\\\\\"'
    assert unquote('"foo\\\\\\\\\\"') == '"foo\\\\\\\\\\"'

# Generated at 2022-06-17 06:03:37.259378
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar')
    assert not is_quoted("'foo'bar")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")


# Generated at 2022-06-17 06:03:46.650184
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello\\""') == '"hello\\""'
    assert unquote('"hello\\\\""') == 'hello\\\\'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\""') == 'hello\\\\\\\\\\"'
    assert unquote('"hello\\\\\\\\\\\\""') == 'hello\\\\\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\\\\\""') == 'hello\\\\\\\\\\\\\\"'