

# Generated at 2022-06-17 06:02:22.662793
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\'\\"') == 'hello\'\\"'
    assert unquote('"hello\'\\""') == 'hello\'\\"'
    assert unquote('"hello\'\\""') == 'hello\'\\"'
    assert unquote('"hello\'\\\\""') == 'hello\'\\\\"'

# Generated at 2022-06-17 06:02:36.225729
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"bar"') == 'foo\\\\"bar'

# Generated at 2022-06-17 06:02:44.331792
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('test"')
    assert not is_quoted("test'")
    assert not is_quoted('test')
    assert not is_quoted('"test""')
    assert not is_quoted("'test''")
    assert not is_quoted('"test\\""')
    assert not is_quoted("'test\\''")
    assert not is_quoted('"test\\\\""')
    assert not is_quoted("'test\\\\''")


# Generated at 2022-06-17 06:02:58.465141
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo\\\\"') == 'foo\\\\'
    assert unquote('"foo\\\\"bar"') == 'foo\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'
    assert unquote('"foo\\\\\\"bar"') == 'foo\\\\\\"bar'

# Generated at 2022-06-17 06:03:05.641621
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\'') == 'hello\''
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\"'

# Generated at 2022-06-17 06:03:13.900623
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\""') == 'hello\\\\\\\\\\"'

# Generated at 2022-06-17 06:03:24.485544
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('"hello\'"') == 'hello\'"'
    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\\\""') == 'hello\\\\"'
    assert unquote('"hello\\\\\\""') == 'hello\\\\\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\\\\\'
    assert unquote('"hello\\\\\\\\\\""') == 'hello\\\\\\\\\\"'

# Generated at 2022-06-17 06:03:38.046299
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'') == '"foo\''

# Generated at 2022-06-17 06:03:44.725534
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\\"bc"') == 'a\\"bc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('"abc"d') == '"abc"d'
    assert unquote('"abc\\"') == '"abc\\"'
    assert unquote('"abc\\"d') == '"abc\\"d'
    assert unquote('"a\\\\bc"') == 'a\\\\bc'
    assert unquote('"a\\\\\\"bc"') == 'a\\\\\\"bc'
    assert unquote('"a\\\\\\\\bc"') == 'a\\\\\\\\bc'

# Generated at 2022-06-17 06:03:52.849845
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted("'foo\\'")
    assert not is_quoted('\\"foo"')
    assert not is_quoted("\\'foo'")
    assert not is_quoted('"foo\\"bar"')
    assert not is_quoted("'foo\\'bar'")