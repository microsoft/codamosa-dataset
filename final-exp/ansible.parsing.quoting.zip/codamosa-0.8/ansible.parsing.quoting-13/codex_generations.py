

# Generated at 2022-06-11 08:43:34.206346
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'bar'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")


# Generated at 2022-06-11 08:43:41.063354
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test\"") == "test"
    assert unquote("\"test") == "test"
    assert unquote("test\"") == "test"
    assert unquote("'test'") == "test"
    assert unquote("'test") == "test"
    assert unquote("test'") == "test"
    assert unquote("\"test'") == "test'"
    assert unquote("'test\"") == "test\""
    assert unquote("\"te\\\"st'") == "te\\\"st'"
    assert unquote("'te\\\"st\"") == "te\\\"st\""


# Generated at 2022-06-11 08:43:44.252139
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('\\"foo"')
    assert not is_quoted('"foo\\"')
    assert not is_quoted('foo')


# Generated at 2022-06-11 08:43:52.811426
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'''abc'''") == "'''abc'''"
    assert unquote('"""abc"""') == '"""abc"""'
    assert unquote("'a''bc'") == "a''bc"
    assert unquote('"a""bc"') == 'a""bc'

# http://docs.python.org/2/library/string.html#format-string-syntax
# http://docs.python.org/2/library/stdtypes.html#string-formatting-operations



# Generated at 2022-06-11 08:43:54.443773
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted("foo") == False
    assert is_quoted("\"foo") == False


# Generated at 2022-06-11 08:44:01.530821
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert not is_quoted('foo "bar"')
    assert is_quoted('"bar"')
    assert is_quoted('"bar" "baz"')
    assert is_quoted('"bar\\" baz"')
    assert not is_quoted('"bar"baz"')
    assert not is_quoted('"bar\\" baz')
    assert is_quoted("'bar'")
    assert is_quoted('"bar\\""')

# Generated at 2022-06-11 08:44:06.550448
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('test1')
    assert is_quoted('"test2"')
    assert is_quoted("'test3'")
    assert not is_quoted("'test4\\'")
    assert not is_quoted('"test5\\"')
    assert not is_quoted('"test6\\"')


# Generated at 2022-06-11 08:44:09.589201
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")



# Generated at 2022-06-11 08:44:14.941579
# Unit test for function unquote
def test_unquote():
    assert (unquote('"abc"') == 'abc')
    assert (unquote("'abc'") == 'abc')
    assert (unquote("'a'bc'") == "'a'bc'")
    assert (unquote("'a''bc'") == "'a''bc'")
    assert (unquote("'a\\'bc'") == "a'bc")

# Generated at 2022-06-11 08:44:17.363118
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"whot"') == True
    assert is_quoted('whot') == False
