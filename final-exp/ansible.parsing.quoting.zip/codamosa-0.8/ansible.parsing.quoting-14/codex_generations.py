

# Generated at 2022-06-11 08:43:36.636992
# Unit test for function is_quoted

# Generated at 2022-06-11 08:43:44.702162
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello world"') == 'hello world'
    assert unquote('"""hello"""') == '"""hello"""'
    assert unquote('" hello world "') == ' hello world '
    assert unquote('"\\"hello world\\""') == '\\"hello world\\"'
    assert unquote('"\\"hello world\\""', True) == '\\"hello world\\"'
    assert unquote('test') == 'test'


# Generated at 2022-06-11 08:43:48.626320
# Unit test for function unquote
def test_unquote():
    assert unquote('foo')    == 'foo'
    assert unquote('"foo"')  == 'foo'
    assert unquote("'foo'")  == 'foo'
    assert unquote("'foo\\'") == "'foo\\'"

# Generated at 2022-06-11 08:43:57.279984
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('''"ab'c"''') == "ab'c"
    assert unquote('''"ab"c"''') == '"ab"c"'
    assert unquote('''""''') == ''
    assert unquote('''"a\\\\\\"c"''') == 'a\\\\\\"c'

# Generated at 2022-06-11 08:44:02.149447
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"ab\\"c"') == 'ab\\"c'
    assert unquote('"ab\'c"') == "ab'c"
    assert unquote('"a"b"c"') == 'a"b"c'



# Generated at 2022-06-11 08:44:12.596603
# Unit test for function unquote
def test_unquote():
    assert unquote('"this is a test"') == 'this is a test'
    assert unquote("this is a test") == 'this is a test'
    assert unquote('"this \'is\' a test"') == "this 'is' a test"
    assert unquote("'this \"is\" a test'") == 'this "is" a test'
    assert unquote("'this \"is\" a test'") == 'this "is" a test'
    assert unquote('"this \"is\" a test"') == 'this "is" a test'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'

# Generated at 2022-06-11 08:44:22.947942
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hel\'lo"') == "hel\'lo"
    assert unquote('"hel"lo"') == '"hel"lo"'
    assert unquote('\'hel"lo\'') == 'hel"lo"'
    assert unquote('""') == ''
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('hel"lo') == 'hel"lo'
    assert unquote('hel\'lo') == 'hel\'lo'
    assert unquote('hello') == 'hello'
    assert unquote('\'"hel"lo"\'') == '\'"hel"lo"\''

# This is used to test 'is_quoted'

# Generated at 2022-06-11 08:44:28.089238
# Unit test for function unquote
def test_unquote():
    assert unquote(r'"foobar"') == "foobar"
    assert unquote(r"'foobar'") == "foobar"
    assert unquote(r'"foo\"bar"') == r'foo\"bar'
    assert unquote(r"'foo\'bar'") == r"foo\'bar"
    assert unquote(r"'foobar") == "'foobar"

# Generated at 2022-06-11 08:44:29.993358
# Unit test for function unquote
def test_unquote():
    assert(unquote("'hello world'") == "hello world")

# Generated at 2022-06-11 08:44:36.396063
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\'bar'") == "foo\'bar"

