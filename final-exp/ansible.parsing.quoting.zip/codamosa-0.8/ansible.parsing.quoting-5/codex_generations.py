

# Generated at 2022-06-11 08:43:31.118586
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'



# Generated at 2022-06-11 08:43:33.685287
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd\\"') == 'abcd\\"'



# Generated at 2022-06-11 08:43:37.354478
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'fo\\'o'") == "fo\\'o"
    assert unquote("'fo\\\"o'") == 'fo\\"o'

# Generated at 2022-06-11 08:43:44.417705
# Unit test for function unquote
def test_unquote():
     assert unquote("foo") == "foo"
     assert unquote("\"foo\"") == "foo"
     assert unquote("'foo'") == "foo"
     assert unquote("'foo")  == "'foo"
     assert unquote("foo'")  == "foo'"
     assert unquote("'foo bar") == "'foo bar"
     assert unquote("foo bar'") == "foo bar'"
     assert unquote("'foo\"b\"ar'") == "'foo\"b\"ar'"
     assert unquote("'fo\"o\"b ar'") == "'fo\"o\"b ar'"


# Generated at 2022-06-11 08:43:51.907202
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("\"foo\"") == True
    assert is_quoted("'foo\"") == False
    assert is_quoted("\"foo'") == False
    assert is_quoted("\"foo'\"") == False
    assert is_quoted("'foo\'") == False
    assert is_quoted("\"foo\"'") == False
    assert is_quoted("\"foo\"\"bar\"") == False



# Generated at 2022-06-11 08:43:58.611142
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote('"foo bar baz"') == "foo bar baz"
    assert unquote('"foo bar \\" baz"') == 'foo bar " baz'
    assert unquote('"foo bar \\\" baz"') == 'foo bar \\" baz'
    assert unquote('"foo bar \\\\\\" baz"') == 'foo bar \\\\" baz'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('bar"foo"') == 'bar"foo"'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-11 08:44:02.429065
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"test"') == True)
    assert (is_quoted('"test') == False)
    assert (is_quoted('test"') == False)
    assert (is_quoted('"test\\"') == False)


# Generated at 2022-06-11 08:44:06.497435
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('\'"test\'"')


# Generated at 2022-06-11 08:44:13.490150
# Unit test for function unquote
def test_unquote():
    assert 'name' == unquote('"name"')
    assert "name with ' embedded quote" == unquote('"name with \' embedded quote"')
    assert 'name with " embedded quote' == unquote("'name with \" embedded quote'")
    assert '"name starts with quote"' == unquote('"\\"name starts with quote\\""')
    assert '"name ends with quote"' == unquote('"""name ends with quote""')
    assert 'name is plain' == unquote('name is plain')



# Generated at 2022-06-11 08:44:18.882095
# Unit test for function unquote
def test_unquote():
    assert unquote('"bob"') == 'bob'
    assert unquote('"bob\\\\"') == 'bob\\'
    assert unquote('bob') == 'bob'
    assert unquote('"bob\\\\"fred"') == 'bob\\"fred'
    assert unquote('bob"fred"') == 'bob"fred"'