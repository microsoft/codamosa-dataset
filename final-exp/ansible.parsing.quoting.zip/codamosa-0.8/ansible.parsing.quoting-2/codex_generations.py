

# Generated at 2022-06-11 08:43:34.062875
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'Testing'") == True
    assert is_quoted("\"Testing\"") == True
    assert is_quoted("Testing") == False
    assert is_quoted("'Test\\'ing'") == False


# Generated at 2022-06-11 08:43:42.996158
# Unit test for function unquote
def test_unquote():
    assert('example' == unquote('example'))
    assert('example' == unquote('"example"'))
    assert('example' == unquote('\'example\''))
    assert('"example"' == unquote('"\\"example\\""'))
    assert("'example'" == unquote("'\\'example\\''"))
    assert('"example"' == unquote("'\"example\"'"))
    assert("'example'" == unquote('\'"example"\''))
    assert('\\\"example\\"' == unquote('\\\"example\\"'))
    assert('\\\'example\\\'' == unquote("\\\'example\\\'"))
    assert('example with spaces' == unquote('"example with spaces"'))
    assert('example with spaces' == unquote("'example with spaces'"))



# Generated at 2022-06-11 08:43:53.297458
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('""') == ''
    assert unquote('"') == '"'
    assert unquote('"bar\\"') == '"bar\\"'
    assert unquote('"bar\\""') == 'bar"'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\'foo') == '\'foo'
    assert unquote('foo\'') == 'foo\''
    assert unquote('\'\'') == ''
    assert unquote('\'') == '\''
    assert unquote('\'bar\\\'') == '\'bar\\\''
    assert unquote('\'bar\\\'\'') == 'bar\''

# Generated at 2022-06-11 08:43:58.166543
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('test"test') == 'test"test'
    assert unquote('"test"test') == '"test"test'
    assert unquote('test\\"test') == 'test\\"test'
    assert unquote('"test"test"') == '"test"test"'

# Generated at 2022-06-11 08:44:08.198012
# Unit test for function unquote
def test_unquote():
    assert unquote(u'foo')                  == u'foo'
    assert unquote(u'"foo"')                == u'foo'
    assert unquote(u"'foo'")                == u'foo'
    assert unquote(u'"foo" bar')            == u'"foo" bar'
    assert unquote(u'"foo\' bar"')          == u"foo\' bar"
    assert unquote(u'"foo\' \\" bar"')      == u'foo\' \\" bar'
    assert unquote(u'"foo\' \\" bar" baz')  == u'"foo\' \\" bar" baz'
    assert unquote(u'"foo \\" bar" baz')    == u'"foo \\" bar" baz'

# Generated at 2022-06-11 08:44:13.638656
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('test') == 'test'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"\'"') == '\''



# Generated at 2022-06-11 08:44:19.043387
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"pungi"')
    assert is_quoted("'mongo'")
    assert not is_quoted('"double quote string with embedded \" quote"')
    assert not is_quoted('"double quote string with embedded \\" quote"')
    assert not is_quoted("'single quote string with embedded ' quote'")


# Generated at 2022-06-11 08:44:29.143481
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello' ") == "'hello' "
    assert unquote(" ''") == " ''"
    assert unquote("'hello") == "'hello"
    assert unquote("hello '") == "hello '"
    assert unquote("'hello\"") == "'hello\""
    assert unquote("\"hello'") == "\"hello'"
    assert unquote("'hello' world") == "'hello' world"
    assert unquote("\\'hello\\'") == "\\'hello\\'"
    assert unquote("\"hello\\\"") == "hello\\\""
    assert unquote("hello world") == "hello world"

# TODO: This needs to be moved to utils2.
#       The

# Generated at 2022-06-11 08:44:38.134728
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'hel\"lo'") == 'hel"lo'

    assert unquote('"hello\\""') == 'hello\\"'
    assert unquote('"hello\\"') == 'hello\\"'
    assert unquote('"hello\"') == 'hello"'
    assert unquote('"hello"\\"') == 'hello"\\'

# Generated at 2022-06-11 08:44:46.698281
# Unit test for function unquote
def test_unquote():
    from nose import SkipTest
    raise SkipTest()

    def test_one(data, expected):
        result = unquote(data)
        if result != expected:
            raise AssertionError()

    # simple checks
    test_one('"abc"', 'abc')
    test_one('abc', 'abc')
    test_one('"abc', '"abc')
    test_one('abc"', 'abc"')
    test_one('""', '')
    test_one('"', '"')
    test_one('""a', '""a')
    test_one('"a"b', '"a"b')

