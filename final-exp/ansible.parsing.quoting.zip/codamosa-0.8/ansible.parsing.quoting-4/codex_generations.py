

# Generated at 2022-06-11 08:43:31.988937
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'Hello world'") == True)
    assert(is_quoted("Hello world") == False)
    assert(is_quoted("'Hello world") == False)
    assert(is_quoted("Hello world'") == False)
    assert(is_quoted("\"Hello world\"") == True)
    assert(is_quoted("\"Hello world") == False)
    assert(is_quoted("Hello world\"") == False)



# Generated at 2022-06-11 08:43:40.494314
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("hel'lo'") == "hel'lo'"
    assert unquote("'hel\\'lo'") == 'hel\\' + 'lo'
    assert unquote("'hel\\\\'lo'") == 'hel\\' + 'lo'
    assert unquote("'hel\\\\\\'lo'") == 'hel\\\\' + 'lo'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""""') == ''
    assert unquote('"\\"') == '\\'
    assert unquote("'\\''") == "'"
    assert unquote("'\\\\''") == "\\"
   

# Generated at 2022-06-11 08:43:46.427881
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"hello\'"') == "hello\'"

    assert unquote('hello') == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote('"hello') == '"hello'

    assert unquote("let's go") == "let's go"
    assert unquote('"let\'s go"') == "let\'s go"

# Generated at 2022-06-11 08:43:53.988177
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a\\'b'") == "a\\'b"
    assert unquote("'a'b'") == "'a'b'"
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote("a") == "a"
    assert unquote("'a") == "'a"
    assert unquote("a'") == "a'"
    assert unquote("a'a") == "a'a"

# Generated at 2022-06-11 08:43:59.198609
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted("test")
    assert not is_quoted("\"test")
    assert not is_quoted("'test")
    assert not is_quoted("'test\"")
    assert not is_quoted("test'")
    assert not is_quoted("test\"")
    assert is_quoted("'test\'s thing'")
    assert is_quoted('"test\\"s thing"')
    assert is_quoted('"test\\\\"')
    assert is_quoted("'test\\\\'")


# Generated at 2022-06-11 08:44:04.240449
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") != 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote('"foo\\"') == 'foo"'

# Generated at 2022-06-11 08:44:14.727969
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('"test"') == True
    assert is_quoted('"""test"""') == True
    assert is_quoted('"""test\""""') == True
    assert is_quoted('"""test"""') == True
    assert is_quoted('\'\'') == True
    assert is_quoted('\'test\'') == True
    assert is_quoted('\'\'\'test\'\'\'') == True
    assert is_quoted('\'\'\'test\\\'\'\'\'') == True
    assert is_quoted('\'\'\'test\'\'\'') == True
    assert is_quoted('"""test\""""') == True
    assert is_quoted('"""test') == False
    assert is_quoted('\'\'\'test') == False

# Generated at 2022-06-11 08:44:21.582671
# Unit test for function unquote
def test_unquote():
    assert unquote("'123'") == '123'
    assert unquote("'12''3'") == '12''3'
    assert unquote("'12'3'") == "'12'3'"
    assert unquote("'12''34'") == '12''34'
    assert unquote("'123") == "'123"
    assert unquote("123'") == "123'"
    assert unquote("'123'456'") == "'123'456'"
    assert unquote("") == ""



# Generated at 2022-06-11 08:44:27.295109
# Unit test for function unquote
def test_unquote():
    # Check empty string
    assert unquote('') == ''
    # Check unquoted single word
    assert unquote('foobar') == 'foobar'
    # Check quoted single word
    assert unquote('"foobar"') == 'foobar'
    # Check unquoted single word with leading and trailing spaces
    assert unquote('  foobar  ') == '  foobar  '
    # Check quoted single word with leading and trailing spaces
    assert unquote('  "foobar"  ') == 'foobar'
    # Check unquoted two words
    assert unquote('foo bar') == 'foo bar'
    # Check quoted two words
    assert unquote('"foo bar"') == 'foo bar'
    # Check unquoted two words with leading, middle and trailing spaces
    assert unquote(' foo  bar  ')

# Generated at 2022-06-11 08:44:33.780979
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\"") == "'foo\""
    assert unquote("\"foo'") == "\"foo'"
    assert unquote("'foo'bar") == "'foo'bar"

