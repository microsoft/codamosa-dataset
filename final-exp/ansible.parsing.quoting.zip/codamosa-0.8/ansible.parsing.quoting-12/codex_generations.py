

# Generated at 2022-06-11 08:43:39.073929
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"') is False
    assert is_quoted('"blah') is False
    assert is_quoted('blah"') is False
    assert is_quoted('"blah"') is True
    assert is_quoted('""') is True
    assert is_quoted("'") is False
    assert is_quoted("'blah") is False
    assert is_quoted("blah'") is False
    assert is_quoted("'blah'") is True
    assert is_quoted("''") is True
    assert is_quoted('\"') is False
    assert is_quoted('\"blah') is False
    assert is_quoted('blah\"') is False
    assert is_quoted('\"blah\"') is True
    assert is_quoted('\"\"')

# Generated at 2022-06-11 08:43:41.100382
# Unit test for function unquote
def test_unquote():
    assert unquote('"original"') == 'original'
    assert unquote('\'original\'') == 'original'
    assert unquote('original') == 'original'

# Generated at 2022-06-11 08:43:47.110532
# Unit test for function unquote
def test_unquote():
    ''' Function unquote returns a string without quotes if the
        string starts and ends with the same quotes
    '''
    assert unquote('"foobar"') == 'foobar'

    ''' Function unquote returns a string including quotes if the
        string does not starts and ends with the same quotes
    '''
    assert unquote('"foobar""') == '"foobar""'
    assert unquote('foobar"') == 'foobar"'

# Generated at 2022-06-11 08:43:56.396133
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"testing"')
    assert is_quoted("'testing'")
    assert not is_quoted("testing'")
    assert not is_quoted('testing"')
    assert not is_quoted("'testing")
    assert not is_quoted("testing'")
    assert not is_quoted("'testing")
    assert not is_quoted("\"testing")
    assert not is_quoted("testing\"")
    assert not is_quoted("")
    assert not is_quoted("'")
    assert not is_quoted("\"")
    assert is_quoted("''")
    assert is_quoted("\"\"")
    assert is_quoted("'foo'")
    assert is_quoted("\"foo\"")

# Generated at 2022-06-11 08:44:02.619319
# Unit test for function unquote
def test_unquote():
    assert 'test' == unquote('"test"')
    assert "test'" == unquote("'test'")
    assert "test'\"" == unquote("'test\"'")
    assert "'test'\"" == unquote('"test\'"')
    assert "test'" == unquote("test'")
    assert "test'\"" == unquote("test'\"")
    assert "test" == unquote("test")
    assert "te'st" == unquote("te'st")

# Generated at 2022-06-11 08:44:10.418490
# Unit test for function unquote
def test_unquote():
    for d in (
        'foobar',
        '"foobar"',
        "'foobar'",
        '"foo\'bar"',
        "'foo\"bar'",
        '\\"foobar\\"',           # quoted, but escaped quote
        '"foo\\"bar"',            # quoted, but escaped quote
        '"foobar"baz',            # quoted, but not escaped
        '"foobar"?'               # quoted, but not escaped
    ):
        assert is_quoted(d) == (d != 'foobar')
        assert unquote(d) == 'foobar'

# Generated at 2022-06-11 08:44:17.545051
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('""hello""') == '"hello"'
    assert unquote("''hello''") == "'hello'"
    assert unquote('"hello""') == 'hello"'
    assert unquote("'hello''") == "hello'"
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello') == 'hello'



# Generated at 2022-06-11 08:44:23.608909
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("'") == "'"
    assert unquote("'abcd'") == "abcd"
    assert unquote("abcd") == "abcd"
    assert unquote("abcd'") == "abcd'"
    assert unquote("'abcd") == "'abcd"
    assert unquote("'abcd\\''") == "abcd\\'"
    assert unquote("\"abcd\\\"\"") == "abcd\\\""

# Generated at 2022-06-11 08:44:31.680474
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted('"test') == False
    assert is_quoted("'test") == False
    assert is_quoted('test"') == False
    assert is_quoted("test'") == False
    assert is_quoted('"test\\""') == False
    assert is_quoted('"test"\\""') == True
    assert is_quoted('""') == True
    assert is_quoted('''"test"''') == True


# Generated at 2022-06-11 08:44:38.765096
# Unit test for function is_quoted
def test_is_quoted():
    for datum in [
                  '"quoted"',
                  "'quoted'",
                  '"""quoted"""',
                  "'''quoted'''",
                  '"quoted\\""',
                  ]:
        assert is_quoted(datum)

    for datum in [
                  'unquoted',
                  '"unquote"d',
                  "'unquote'd",
                  "'''quoted''",
                  '"""quoted"',
                  ]:
        assert not is_quoted(datum)
