

# Generated at 2022-06-11 08:43:37.542925
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted('"test"') == True )
    assert( is_quoted("'test'") == True )
    assert( is_quoted('"test\\""') == False )
    assert( is_quoted("'test\\''") == False )
    assert( is_quoted('"test"foo') == False )
    assert( is_quoted("'test'foo") == False )
    assert( is_quoted('test') == False )
    assert( is_quoted('"') == False )
    assert( is_quoted("'") == False )


# Generated at 2022-06-11 08:43:45.316284
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"hello world\"")
    assert is_quoted("\"hello world") == False
    assert is_quoted("hello world") == False
    assert is_quoted("\"hello \"world\"") == False
    assert is_quoted("\"hello \\\"world\"")
    assert is_quoted("\'hello world\'")
    assert is_quoted("\'hello world") == False
    assert is_quoted("hello world") == False
    assert is_quoted("\'hello \'world\'") == False
    assert is_quoted("\'hello \\\'world\'")
    assert is_quoted("\'hello \\\"world\'")


# Generated at 2022-06-11 08:43:55.462835
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('foo bar"') == 'foo bar"'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo bar\"') == '"foo bar'
    assert unquote('"foo bar\""') == '"foo bar'
    assert unquote('foo bar" "foo bar') == 'foo bar" "foo bar'
    assert unquote(' "foo bar" "foo bar" ') == 'foo bar" "foo bar'
    assert unquote(' "foo bar" "foo bar" "') == ' "foo bar" "foo bar" "'

# Generated at 2022-06-11 08:44:00.314909
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote('"te""st"') == 'te""st'
    assert unquote("'te'st'") == "te'st"
    assert unquote('"te\"st"') == 'te\"st'

# Generated at 2022-06-11 08:44:05.672323
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('"""') == '""'
    assert unquote("'''") == "''"
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote("'hello world ''s") == "hello world ''s"



# Generated at 2022-06-11 08:44:13.440262
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"



# Generated at 2022-06-11 08:44:20.783267
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"this is quoted"')
    assert not is_quoted('this is not quoted')
    assert 'this is quoted' == unquote('"this is quoted"')
    assert '"this is not unquoted"' == unquote('"this is not unquoted"')
    assert '"this is not unquoted"' == unquote('\'"this is not unquoted"\'')
    assert '"this is not unquoted"' == unquote('"\\"this is not unquoted\\""')

#

# Generated at 2022-06-11 08:44:26.898957
# Unit test for function unquote
def test_unquote():
    assert unquote("\"'\""), "'"
    assert unquote("'\"'"), '"'
    assert unquote("\"'\"'\""), "'"
    assert unquote("\"'\"\"'\""), "'"
    assert unquote("'\"'\"'\""), '"'
    assert unquote("''"), ''
    assert unquote("'''"), '\''
    assert unquote("'''\""), '\''
    assert unquote("''\"'"), '"'
    assert unquote("\"\""), ''
    assert unquote("'''\"'\""), '\'"'
    assert unquote("\"\"\""), '"'
    assert unquote("\"\"\"\""), '""'
    assert unquote("\"\"\"\"\""), '"""'
    assert unquote("\"\"\"\"\"\""), '""""'
   

# Generated at 2022-06-11 08:44:30.781873
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == 'foo'
    assert unquote("'foo") == 'foo'
    assert unquote("foo") == 'foo'



# Generated at 2022-06-11 08:44:41.903416
# Unit test for function unquote
def test_unquote():
    # simple cases
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello\'') == 'hello\''
    assert unquote('"hello" world') == 'hello" world'
    assert unquote("'hello' world") == 'hello\' world'
    assert unquote("'hello world") == "'hello world"
    assert unquote("hello world'") == "hello world'"

    # test of escaped quotes
    # escaped at start or end of string should not unquote
    assert unquote(r'"hello\"') == r'"hello\"'