

# Generated at 2022-06-11 08:43:38.833132
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('hello') == "hello"
    assert unquote('"hello') == '"hello'
    assert unquote('hello\'"') == 'hello\'"'
    assert unquote('''"hello'"''') == '"hello"'
    assert unquote('"""hello"""') == 'hello'
    assert unquote('"""\'hello\'"""') == '"""\'hello\'"""'
    assert unquote('r"hello"') == "rhello"
    assert unquote("r'hello'") == "rhello"
    assert unquote('r"hello\"') == 'r"hello"'
    assert unquote('r"""hello"""') == 'rhello'

#
# This utility function is used to merge two diction

# Generated at 2022-06-11 08:43:48.252200
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('"""foo"""') == '"""foo"""'
    assert unquote("'''foo'''") == "'''foo'''"
    assert unquote('r"foo"') == 'r"foo"'
    assert unquote("b'foo'") == "b'foo'"
    assert unquote("b'\\\\'") == "b'\\\\'"
    assert unquote('"\\\\"') == "\\\\"


# Generated at 2022-06-11 08:43:56.558401
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("''")
    assert is_quoted("'foobar'")
    assert is_quoted("'a'")
    assert is_quoted('"b"')
    assert not is_quoted("foo")
    assert not is_quoted("")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert is_quoted("'a \" b'")
    assert is_quoted("'a \' b'")
    assert is_quoted("\"a \' b\"")
    assert is_quoted("\"a \" b\"")
    assert not is_quoted("\"a \" b")
    assert not is_quoted("a ' b")



# Generated at 2022-06-11 08:44:01.146921
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"ab\\"c"') == 'ab\\"c'
    assert unquote("'ab\\'c'") == "ab\\'c"

# Generated at 2022-06-11 08:44:05.341200
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo\"bar"') == 'foo"bar'



# Generated at 2022-06-11 08:44:11.526538
# Unit test for function unquote
def test_unquote():
    assert unquote('"a quoted string"') == 'a quoted string'
    assert unquote("'a quoted string'") == 'a quoted string'
    assert unquote("not a quoted string") == "not a quoted string"
    assert unquote("'a string with a ' quote in it") == "a string with a ' quote in it"
    assert unquote("a string with a \" quote in it") == 'a string with a " quote in it'

# Generated at 2022-06-11 08:44:17.962332
# Unit test for function unquote
def test_unquote():
    assert unquote("'abc'") == "abc"
    assert unquote("'abc") == "'abc"
    assert unquote("abc'") == "abc'"
    assert unquote("'ab\"c'") == 'ab"c'
    assert unquote("'ab\'c'") == "ab'c"
    assert unquote("'ab\'\'c'") == "ab''c"
    assert unquote("\"ab'c\"") == "ab'c"


# Generated at 2022-06-11 08:44:21.049220
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"ab"c"') == '"ab"c"'


# Generated at 2022-06-11 08:44:23.475525
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"ab\"c"') == 'ab\"c'


# Generated at 2022-06-11 08:44:34.150449
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('\\"') == '\\"'
    assert unquote('""\\"') == '""\\"'
    assert unquote('\\""') == '\\""'
    assert unquote('""\\""') == '""\\""'
    assert unquote('\\\\"') == '\\\\"'
    assert unquote('""\\\\"') == '""\\\\"'
    assert unquote('\\\\""') == '\\\\""'
    assert unquote('""\\\\""') == '""\\\\""'
    assert unquote('\\"\\"') == '\\"\\"'
    assert unquote('""\\"\\"') == '""\\"\\"'