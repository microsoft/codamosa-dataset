

# Generated at 2022-06-11 08:43:36.446389
# Unit test for function unquote
def test_unquote():
    assert unquote('"this is a quoted string"') == 'this is a quoted string'
    assert unquote('"this is a quoted string\'"') == 'this is a quoted string\''
    assert unquote('this is a quoted string') == 'this is a quoted string'
    assert unquote("'this is a quoted string'") == 'this is a quoted string'
    assert unquote("'this is a quoted string''") == 'this is a quoted string\''


# Generated at 2022-06-11 08:43:40.761914
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote('"a\'') == 'a\''
    assert unquote('a') == 'a'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'
    assert unquote('"a"b"') == '"a"b"'



# Generated at 2022-06-11 08:43:44.252792
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == "test"
    assert unquote("\"test\"") == "test"
    assert unquote("'test\"") == "'test\""
    assert unquote("test") == "test"

# vim: set et ts=4 sts=4 sw=4

# Generated at 2022-06-11 08:43:53.174189
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a"b"c"') == '"a"b"c"'
    assert unquote("'a'b'c'") == "'a'b'c'"
    assert unquote('"abc""def"') == 'abc""def"'
    assert unquote("'abc''def'") == "abc'def'"
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"
    assert unquote('abc"') == 'abc"'
    assert unquote("abc'") == 'abc\''


# Generated at 2022-06-11 08:44:02.288817
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\\'") == "'foo\\'"
    assert unquote("'foo'\\") == "'foo'\\"
    assert unquote("foo") == "foo"
    assert unquote("'foo\\''") == "'foo'\\''"
    assert unquote("'foo'bar") == "'foo'bar"
    assert unquote("'foo\"'") == "'foo\"'"
    assert unquote("\"foo'") == "\"foo'"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo\\""') == 'foo"'

# Generated at 2022-06-11 08:44:06.361149
# Unit test for function unquote
def test_unquote():
    assert 'test' == unquote('test')
    assert 'test' == unquote('"test"')
    assert 'test' != unquote('"test"')
    assert r'test' == unquote(r'"test"')
    assert 'test' == unquote(r'"test\\"')



# Generated at 2022-06-11 08:44:12.595883
# Unit test for function unquote
def test_unquote():
    ''' test whether unquote behaves as expected '''
    assert unquote('"test"')   == 'test'
    assert unquote('test')     == 'test'
    assert unquote("'test'")   == 'test'
    assert unquote("'test")    == "'test"
    assert unquote("test'")    == "test'"
    assert unquote('"t\"est"') == 't\"est'



# Generated at 2022-06-11 08:44:18.829772
# Unit test for function unquote
def test_unquote():
    assert unquote('hello') == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello\'s"') == 'hello\'s'
    assert unquote('"hello\'"') == 'hello\''


# Generated at 2022-06-11 08:44:29.002676
# Unit test for function unquote
def test_unquote():
    assert unquote("bar") == 'bar'
    assert unquote('"bar"') == 'bar'
    assert unquote("'bar'") == 'bar'
    assert unquote('"bar\\"') == '"bar\\"'
    assert unquote("'bar'") == 'bar'
    assert unquote("'ba''r'") == "ba'r"
    assert unquote('"""bar') == '"bar'
    assert unquote('"bar""') == 'bar"'
    assert unquote('"""bar"""') == '"bar"'
    assert unquote('"ba""r"') == 'ba"r'
    assert unquote('"""ba""r"""') == '"ba"r"'
    assert unquote('"ba"\\""r"') == 'ba"\\""r'

# Generated at 2022-06-11 08:44:39.283586
# Unit test for function unquote
def test_unquote():
    assert unquote("\"hello world\"") == "hello world"
    assert unquote("'hello world'") == "hello world"
    assert unquote("\\\"hello world\"") == "\"hello world\""
    assert unquote("'hello world\"") == "'hello world\""
    assert unquote("\"hello world'") == "\"hello world'"
    assert unquote("\"hello 'wor'ld\"") == "hello 'wor'ld"
    assert unquote("\"hello \"\"world\"\"\"") == 'hello "world"'
    assert unquote("\"hello \"\" 'world' \"\"\"") == 'hello " \'world\' "'
    assert unquote("'hello \"world\"'") == 'hello \"world\"'
    assert unquote("\\'hello world\\'") == "'hello world'"