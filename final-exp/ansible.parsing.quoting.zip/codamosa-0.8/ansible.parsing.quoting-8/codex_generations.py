

# Generated at 2022-06-11 08:43:35.074871
# Unit test for function unquote
def test_unquote():
    ''' test the unquote function '''
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\\bc"') == 'a\\bc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('"a"b"c"') == 'a"b"c'
    assert unquote('"a\'bc"') == 'a\'bc'

# Generated at 2022-06-11 08:43:43.941050
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('foo"')
    assert not is_quoted('"foo"bar"')
    assert is_quoted('"foo\""')
    assert is_quoted("'foo\'" )

    assert is_quoted('"foo\'"')
    assert is_quoted("'foo\"")
    assert not is_quoted('"foo\'"bar"')
    assert not is_quoted("'foo\"bar'")

    assert not is_quoted('foo')
    assert not is_quoted('')

# Generated at 2022-06-11 08:43:54.336558
# Unit test for function unquote
def test_unquote():
    test_values = [
        ('"this is a quoted string"', 'this is a quoted string'),
        ("'this is also a quoted string'", 'this is also a quoted string'),
        ('this is a non-quoted string', 'this is a non-quoted string'),
        ('"quoted string with a \'single quote\'"', 'quoted string with a \'single quote\''),
        ("'quoted string with a \"double quote\"'", 'quoted string with a \"double quote\"'),
        ("'quoted string with escaped \\'single quote\\''", "'quoted string with escaped \\'single quote\\''"),
        ('"quoted string with escaped \\"double quote\\""', '"quoted string with escaped \\"double quote\\""'),
    ]

# Generated at 2022-06-11 08:43:59.406823
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted('"test') == False
    assert is_quoted("'test") == False
    assert is_quoted('test"') == False
    assert is_quoted("test'") == False
    assert is_quoted('\\"test\\"') == False


# Generated at 2022-06-11 08:44:09.640026
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted("'hello'")
    assert is_quoted("'hello''") == False
    assert is_quoted("'hello\\''")
    assert is_quoted("'hello' world") == False
    assert is_quoted("''") == False
    assert is_quoted("") == False
    assert is_quoted("'hello\\ world'")
    assert is_quoted("'hello\\\\ world'")
    assert is_quoted('"hello world"')
    assert is_quoted('"hello world\\"') == False
    assert is_quoted('"hello world\\""')
    assert is_quoted('"""hello"" world"')
    assert is_quoted('"""hello""" world"') == False
    assert is_quoted('"""hello\""" world"')
    assert is_quoted

# Generated at 2022-06-11 08:44:16.258545
# Unit test for function unquote
def test_unquote():
    assert unquote('"Hello, World"') == 'Hello, World'
    assert unquote('\'Hello, World\'') == 'Hello, World'
    assert unquote('"Hello, World"\'') == '"Hello, World"\''
    assert unquote('\'Hello, World"') == '\'Hello, World"'
    assert unquote('Hello, World') == 'Hello, World'
    assert unquote('"Hello""World"') == 'Hello""World'


# Generated at 2022-06-11 08:44:21.844997
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("foo") == "foo"
    assert unquote('"foo\\""') == 'foo"'
    assert unquote("'foo\\''") == "foo'"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'


# Generated at 2022-06-11 08:44:27.701239
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo\\""') == 'foo"'
    assert unquote('"\\"foo\\""') == '"foo"'
    assert unquote('"foo""') == 'foo"'
    assert unquote('""foo"') == '"foo'



# Generated at 2022-06-11 08:44:36.908195
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('foo"')
    assert not is_quoted('')

    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote('foo"') == 'foo"'
    assert unquote('') == ''

# Generated at 2022-06-11 08:44:44.861100
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a"')
    assert is_quoted("'a'")
    assert is_quoted('"a') == False
    assert is_quoted("'a") == False
    assert is_quoted('a"') == False
    assert is_quoted("a'") == False
    assert is_quoted('"a""b"') == False
    assert is_quoted("'a''b'") == False
    assert is_quoted('"\\"a"') == False
    assert is_quoted("'\\'a'") == False
