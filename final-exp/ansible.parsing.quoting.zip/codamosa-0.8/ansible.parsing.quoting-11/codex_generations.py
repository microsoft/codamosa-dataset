

# Generated at 2022-06-11 08:43:39.460396
# Unit test for function unquote
def test_unquote():
    ''' Unit tests for function unquote '''
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('""""') == '""'
    assert unquote('"""""""') == '""""'
    assert unquote("'") == "'"
    assert unquote("''") == ''
    assert unquote("''''") == "''"
    assert unquote("'''''''") == "''''"
    assert unquote("foo") == "foo"
    assert unquote(r'foo\'') == r'foo\''
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote('"foo"bar') == '"foo"bar'

# Generated at 2022-06-11 08:43:49.517117
# Unit test for function unquote
def test_unquote():
    assert unquote(None)                                             == None
    assert unquote('')                                               == ''
    assert unquote('"abc"')                                          == 'abc'
    assert unquote('""')                                             == ''
    assert unquote("'abc'")                                          == 'abc'
    assert unquote("''")                                             == ''
    assert unquote('"a\\"bc"')                                       == 'a"bc'
    assert unquote("'a\\'bc'")                                       == "a'bc"
    assert unquote('"a\\"b\\"c"')                                    == 'a"b"c'
    assert unquote("'a\\'b\\'c'")                                    == "a'b'c"

# Generated at 2022-06-11 08:43:56.291503
# Unit test for function unquote
def test_unquote():
    assert unquote("'abc'") == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\\"bc\\""') == 'a\\"bc\\"'
    assert unquote('\'a\\"bc\\"\'') == 'a\\"bc\\"'
    assert unquote('abc') == 'abc'
    assert unquote('\'abc') == '\'abc'
    assert unquote('abc\'') == 'abc\''
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'



# Generated at 2022-06-11 08:44:00.861595
# Unit test for function unquote
def test_unquote():
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo\'bar"') == "foo\'bar"

# taken from here: http://stackoverflow.com/a/3703176

# Generated at 2022-06-11 08:44:04.677877
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"what"')
    assert is_quoted("'what'")
    assert not is_quoted("what")
    assert not is_quoted("'wh\"at'")
    assert not is_quoted('"wh\'at"')



# Generated at 2022-06-11 08:44:15.178969
# Unit test for function unquote
def test_unquote():
    # test string with quotes removed
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    # test string with quotes removed
    assert unquote('foo\'"\'"') == "foo'"
    assert unquote("foo'\"\"'") == "foo\""
    # test string with quotes removed
    assert unquote("'foo\'\"\"'") == "foo\""
    assert unquote("\"foo'\"\"\"") == "foo'"
    # test string with unchanged quotes
    assert unquote("'\"'") == "'\"'"
    assert unquote("'\'") == "'\'"
    assert unquote("'\\'") == "'\\'"
    # test string with unchanged quotes
    assert unquote('"\'\'"') == '"\'\'"'
    assert unquote

# Generated at 2022-06-11 08:44:21.975548
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted("tes't")
    assert is_quoted("'te'st'")
    assert is_quoted('"te"st"')
    assert is_quoted('"te\\"st"')
    assert is_quoted('"te\\\\"st"')


# Generated at 2022-06-11 08:44:24.452390
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc"d') == '"abc"d'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'bc'") == "'a'bc'"



# Generated at 2022-06-11 08:44:35.077155
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"test\"") is True
    assert is_quoted("'test'") is True
    assert is_quoted("'test") is False
    assert is_quoted("test\"") is False
    assert is_quoted("''test\'") is False
    assert is_quoted("\"test\"\"\"") is False
    assert is_quoted("'test'''") is False
    assert is_quoted("\"test\"'") is False
    assert is_quoted("'test'\"") is False
    assert is_quoted("'test\\''") is False
    assert is_quoted("\"test\\\"\"") is False
    assert is_quoted("\"\\\"\"") is False
    assert is_quoted("'\\''") is False

# Generated at 2022-06-11 08:44:40.392159
# Unit test for function unquote
def test_unquote():
    assert unquote('"test data"') == 'test data'
    assert unquote("'test data'") == 'test data'
    assert unquote('"test data') != 'test data'
    assert unquote("'test data") != 'test data'
    assert unquote('test data"') != 'test data'
    assert unquote('test data') == 'test data'