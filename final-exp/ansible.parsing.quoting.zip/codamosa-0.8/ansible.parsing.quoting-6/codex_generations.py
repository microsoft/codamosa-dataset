

# Generated at 2022-06-11 08:43:31.201977
# Unit test for function unquote
def test_unquote():
    assert unquote('"test1"') == 'test1'
    assert unquote('test1') == 'test1'
    assert unquote('"test1') == '"test1'



# Generated at 2022-06-11 08:43:37.542413
# Unit test for function is_quoted
def test_is_quoted():
    quotes = ['""', "''", "'test'", '"testing"', '"test\'ing"',
              '"escaped\\"quotes"', '"so\\ many\\ escaped\\\\ quotes"',
              '"with space"', '"multiple \' quotes"']
    verbs = ["isn't quoted", "is quoted"]
    for quote in quotes:
        assert is_quoted(quote) == True
        assert is_quoted(unquote(quote)) == False
    
    for quote in quotes:
        for verb in verbs:
            print(('%s %s' % (quote, verb)))


# Generated at 2022-06-11 08:43:41.175007
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"hel\"lo"') == 'hel"lo'
    assert unquote("'hel\\'lo'") == "hel'lo"
    assert unquote("'hel") == "hel"

# Generated at 2022-06-11 08:43:45.542350
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('""foo"') == False
    assert is_quoted('""foo""') == True


# Generated at 2022-06-11 08:43:47.877788
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'



# Generated at 2022-06-11 08:43:53.904538
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('""""') == '""'
    assert unquote('\\"') == '\\"'
    assert unquote('\\\\"') == '\\\\"'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('"foo""') == 'foo"'


# Generated at 2022-06-11 08:43:57.003543
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"\"foo\""') == '"foo"'
    assert unquote("'" '"foo"' "'") == '"foo"'

# Generated at 2022-06-11 08:44:00.960382
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted("'test\"\"'")
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted("''test''")


# Generated at 2022-06-11 08:44:03.580804
# Unit test for function unquote
def test_unquote():
    if unquote('"foo"') != 'foo':
        raise AssertionError
    if unquote('"foo') == '"foo':
        raise AssertionError

# Generated at 2022-06-11 08:44:07.787695
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('abcd') is False
    assert is_quoted('"abcd"') is True
    assert is_quoted("'abcd'") is True
    assert is_quoted('"a\\"bcd"') is True

