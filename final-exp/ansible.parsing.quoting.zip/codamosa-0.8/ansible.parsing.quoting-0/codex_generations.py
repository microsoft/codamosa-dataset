

# Generated at 2022-06-11 08:43:31.662955
# Unit test for function unquote
def test_unquote():
    assert(unquote('foo')     == 'foo')
    assert(unquote('"foo"')   == 'foo')
    assert(unquote("'foo'")   == 'foo')
    assert(unquote('"foo\'"') == '"foo\'')

# Generated at 2022-06-11 08:43:34.462191
# Unit test for function unquote
def test_unquote():
    assert unquote('"example"') == 'example'
    assert unquote('\'example\'') == 'example'
    assert unquote('"exam\\"ple"') == 'exam"ple'
    assert unquote('example') == 'example'

# Generated at 2022-06-11 08:43:41.025654
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == 'test'
    assert unquote("\"test\"") == 'test'
    assert unquote("\"test") == '"test'
    assert unquote("test\"") == 'test"'
    assert unquote("test") == 'test'
    assert unquote("'test") == "'test"
    assert unquote('"test') == '"test'
    assert unquote("\\\"test\"") == '\\"test"'
    assert unquote('\\\'test"') == '\\\'test"'
    assert unquote('"\\\'test"') == '\\\'test'


# Generated at 2022-06-11 08:43:47.457659
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'hello world'")
    assert is_quoted("\"hello world\"")
    assert is_quoted('hello') is False
    assert is_quoted("'hello world\'") is False
    assert is_quoted('"hello world"\\') is False
    assert is_quoted('"hello world\\"') is False


# Generated at 2022-06-11 08:43:50.608566
# Unit test for function unquote
def test_unquote():
    assert unquote('"example"') == 'example'
    assert unquote("'example'") == 'example'
    assert unquote("'example") == "'example"
    assert unquote("example'") == "example'"

# Generated at 2022-06-11 08:43:54.068586
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test\\""') == '"test"'
    assert unquote("'test\\''") == "'test'"
    assert unquote('test') == 'test'

# Generated at 2022-06-11 08:43:57.352494
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo\\""') == '"foo\\""'
    assert unquote('""') == ''

# Generated at 2022-06-11 08:44:07.366572
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"This is a test"')
    assert is_quoted("'This is also a test'")
    assert not is_quoted('This is not a test')
    assert not is_quoted('"This is not a test" Test Test')
    assert not is_quoted('This is not a test "Test Test"')
    assert not is_quoted('"This is " not a test "Test Test"')
    assert not is_quoted('"This is not a test Test Test')
    assert not is_quoted('\\"This is not a test Test Test')

    assert unquote('"This is a test"') == "This is a test"
    assert unquote("'This is also a test'") == "This is also a test"

# Generated at 2022-06-11 08:44:11.115516
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-11 08:44:20.086730
# Unit test for function unquote
def test_unquote():
    if not unquote('"test"') == "test":
        raise AssertionError()
    if not unquote("'test'") == "test":
        raise AssertionError()
    if not unquote('"test') == '"test':
        raise AssertionError()
    if not unquote("'test") == "'test":
        raise AssertionError()
    if not unquote('test"') == 'test"':
        raise AssertionError()
    if not unquote("test'") == "test'":
        raise AssertionError()
    if not unquote('"test""') == '"test""':
        raise AssertionError()
