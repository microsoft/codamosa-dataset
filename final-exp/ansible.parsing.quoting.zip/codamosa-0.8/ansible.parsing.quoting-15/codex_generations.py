

# Generated at 2022-06-11 08:43:39.845438
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("foo") == False)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("\"foo'") == False)
    assert(is_quoted("'foo\"") == False)
    assert(is_quoted("\"foo\"") == True)
    assert(is_quoted("\"foo\"\"\"") == False)
    assert(is_quoted("'foo\\''") == True)
    assert(is_quoted("'foo\\\\'") == True)
    assert(is_quoted("'foobar'") == True)
    assert(is_quoted("'foobar\\''") == False)


# Generated at 2022-06-11 08:43:48.358568
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('\\"abc"') == '\\"abc"'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('\'abc') == '\'abc'
    assert unquote('abc\'') == 'abc\''
    assert unquote('\\\'abc\'') == '\\\'abc\''
    assert unquote('abc') == 'abc'
    assert unquote('abc\\') == 'abc\\'
    assert unquote('"abc\\"') == 'abc\\"'

# Generated at 2022-06-11 08:43:57.169261
# Unit test for function unquote
def test_unquote():
    data = '"foo"'
    assert unquote(data) == 'foo'
    data = '"foo'
    assert unquote(data) == '"foo'
    data = "'foo'"
    assert unquote(data) == 'foo'
    data = '"foo\""bar"'
    assert unquote(data) == 'foo"bar'
    data = '"foo" bar "'
    assert unquote(data) == 'foo" bar "'
    data = '"foo" bar "'
    assert unquote(data) == 'foo" bar "'
    data = "'foo' bar '"
    assert unquote(data) == "'foo' bar '"
    data = 'foo'
    assert unquote(data) == 'foo'
    data = '"foo'
    assert unquote(data) == '"foo'

# Generated at 2022-06-11 08:44:01.520771
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"") == False
    assert is_quoted("'") == False
    assert is_quoted("abc") == False
    assert is_quoted("\"abc\"") == True
    assert is_quoted("'abc'") == True
    assert is_quoted("'ab\\'c'") == True



# Generated at 2022-06-11 08:44:09.777713
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"')    == "abc"
    assert unquote("'abc'")    == "abc"
    assert unquote('"""abc"""')  == '"abc"'
    assert unquote("'''abc'''")  == "'abc'"
    assert unquote('"""a\bc"""') == '"a\bc"'
    assert unquote("'''a'bc'''") == "'a'bc'"
    assert unquote('"""a\\bc"""') == '"a\\bc"'
    assert unquote("'''a'b\\c'''") == "'a'b\\c'"

# Generated at 2022-06-11 08:44:12.736452
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc\\"') == 'abc\\'
    assert unquote('"abc') == '"abc'

# Generated at 2022-06-11 08:44:16.161142
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo''") == "'foo''"
    assert unquote("''foo'") == "''foo'"


# Generated at 2022-06-11 08:44:19.949348
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"') == True
    assert is_quoted('"hello"world"') == False
    assert is_quoted('') == False
    assert is_quoted('hello world') == False


# Generated at 2022-06-11 08:44:24.120571
# Unit test for function unquote
def test_unquote():
     assert unquote('"foo"') == 'foo'
     assert unquote('"foo\\"bar"') == 'foo\\"bar'
     assert unquote("'foo'") == 'foo'
     assert unquote("foo") == 'foo'
     assert unquote("'foo") == "'foo"
     assert unquote('"foo') == '"foo'

# Generated at 2022-06-11 08:44:33.574310
# Unit test for function unquote
def test_unquote():
    print('Testing unquote()')
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"he\"llo"') == 'he"llo'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hel\'lo'") == 'hel\'lo'
    assert unquote("'''hello'''") == 'hello'
    assert unquote("'''hel'lo'''") == 'hel\'lo'
    assert unquote('"""hello"""') == 'hello'
    assert unquote('"""hel"lo"""') == 'hel"lo'
    assert unquote("''''''") == ''
    assert unquote("'") == ''