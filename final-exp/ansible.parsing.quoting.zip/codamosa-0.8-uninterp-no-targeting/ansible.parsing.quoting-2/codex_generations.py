

# Generated at 2022-06-20 23:19:31.979008
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote("\"foo\"") == 'foo'
    assert unquote("'bar'") == 'bar'
    assert unquote("'bar") != 'bar'
    assert unquote("bar'") != 'bar'
    assert unquote("foo") == "foo"
    assert unquote("\"foo") != 'foo'
    assert unquote("'foo\"") != 'foo'



# Generated at 2022-06-20 23:19:39.345311
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('\'"test"\'') == False
    assert is_quoted('"test\'"') == False
    assert is_quoted('"test"quoted') == False
    assert is_quoted('\'test\'') == True
    assert is_quoted('\'test') == False
    assert is_quoted('test\'') == False
    assert is_quoted('test\'') == False
    assert is_quoted('test"') == False
    assert is_quoted('"test') == False
    assert is_quoted('test"quoted') == False


# Generated at 2022-06-20 23:19:42.771053
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'

# Generated at 2022-06-20 23:19:46.992505
# Unit test for function unquote
def test_unquote():
    assert unquote('"quoted string"') == "quoted string"
    assert unquote("'quoted string'") == "quoted string"
    assert unquote("'quoted string''") == "'quoted string'"


# Generated at 2022-06-20 23:19:53.203404
# Unit test for function unquote
def test_unquote():
    assert unquote('"FOO"') == 'FOO'
    assert unquote("'FOO'") == 'FOO'
    assert unquote('FOO') == 'FOO'
    assert unquote('"FOO') == '"FOO'
    assert unquote('FOO"') == 'FOO"'
    assert unquote('"FOO\\"') == 'FOO"'   # even though the internal " looks like a quote.


# Generated at 2022-06-20 23:19:59.089718
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"fo\\"o"') == 'fo\\"o'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'fo\\'o'") == "fo\\'o"


# Generated at 2022-06-20 23:20:04.494068
# Unit test for function unquote
def test_unquote():
    assert is_quoted("\"hello\"")
    assert not is_quoted("\"hello'")
    assert not is_quoted("hello")
    assert unquote("\"hello\"") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("hello") == "hello"

# Generated at 2022-06-20 23:20:14.600158
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"foo\"") # String quoted with double quotes
    assert is_quoted("'foo'") # String quoted with single quotes
    assert not is_quoted("\"foo") # String not quoted
    assert not is_quoted("'foo") # String not quoted

    # Single quotes inside double quotes
    assert is_quoted("\"'foo'\"")

    # Unquoted escaped quotes
    assert not is_quoted("'foo\\'")
    assert not is_quoted("\"foo\\\"")

    # Escaped double quotes inside single quotes
    assert not is_quoted("'foo\\\"'")

    # Escaped single quotes inside double quotes
    assert not is_quoted("\"foo\\\'\"")


# Generated at 2022-06-20 23:20:20.221813
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('"abc') == False
    assert is_quoted('abc"') == False
    assert is_quoted('\'abc"') == False
    assert is_quoted('"abc\'') == False
    assert is_quoted('"a\\"bc"') == False
    assert is_quoted('\'a"bc\'') == False


# Generated at 2022-06-20 23:20:29.496465
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert is_quoted('"foo"')
    assert not is_quoted('"foo\\"')
    assert is_quoted('"foo\\""')
    assert is_quoted("'foo'")
    assert not is_quoted("foo")
    assert not is_quoted('foo"')
    assert not is_quoted('"foo')
    assert not is_quoted('"foo\\""')
    assert not is_quoted('"foo\\"')
    assert is_quoted('"foo\\""')
    assert unquote('"foo\\""') == 'foo"'