

# Generated at 2022-06-20 23:19:27.581526
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted('"foo\\"bar"')
    assert not is_quoted('foobar"')
    assert not is_quoted('"foobar')
    assert not is_quoted('"foo\\"bar')
    assert not is_quoted('foobar')
    assert not is_quoted('"foo"\'bar"')
    assert not is_quoted('"foo\'bar"')


# Generated at 2022-06-20 23:19:35.373886
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == 'foo'
    assert unquote('"foo"bar') == 'foo"bar'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"') == 'foo"'
    assert unquote('"foo\\\\"') == 'foo\\'
    assert unquote('"foo\\\\\\"') == 'foo\\\\"'
    assert unquote('""') == ''
    assert unquote('"\\""') == '\\"'
    assert unquote('"\\\\"') == '\\\\'

# Generated at 2022-06-20 23:19:39.345569
# Unit test for function is_quoted
def test_is_quoted():
    data1 = "test"
    assert is_quoted(data1)==False
    data2 = "'test'"
    assert is_quoted(data2)
    data3 = '''"test"'''
    assert is_quoted(data3)
    data4 = '''"te'st"'''
    assert is_quoted(data4)


# Generated at 2022-06-20 23:19:45.626743
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted('"foo')  == False)
    assert(is_quoted('foo"')  == False)
    assert(is_quoted('"foo\\"bar"') == True)
    assert(is_quoted('"foo\\\'bar"') == False)


# Generated at 2022-06-20 23:19:48.719575
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("hello")


# Generated at 2022-06-20 23:19:55.919165
# Unit test for function is_quoted
def test_is_quoted():
    # Success cases
    print(is_quoted('"this is quoted"'))
    print(is_quoted("'this is also quoted'"))
    print(is_quoted('"this \"is\" quoted"'))
    print(is_quoted("'this 'is' also quoted'"))

    # Failure cases
    print(is_quoted('"this is not'))
    print(is_quoted("'this is also not"))
    print(is_quoted('"this is not'))
    print(is_quoted("'this "is" also not"))


# Generated at 2022-06-20 23:19:59.669020
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('abcd') == False
    assert is_quoted('"abcd"') == True
    assert is_quoted("'abcd'") == True
    assert is_quoted('"abcd\\"') == False
    assert is_quoted("'abcd\\'") == False
    assert is_quoted('"abcd\\""') == True


# Generated at 2022-06-20 23:20:11.525953
# Unit test for function unquote
def test_unquote():
    assert unquote(r""" "foo" """) == 'foo'
    assert unquote(r""" "foo" 'bar' """) == r""" "foo" 'bar' """
    assert unquote(r""" 'foo' """) == 'foo'
    assert unquote(r""" foo """) == r""" foo """
    assert unquote(r""" foo """) == r""" foo """
    assert unquote(r""" 'foo""") == r""" 'foo"""
    assert unquote(r""" foo' """) == r""" foo' """
    assert unquote(r""" "foo' """) == r""" "foo' """
    assert unquote(r""" 'foo" """) == r""" 'foo" """
    assert unquote(r""" foo """) == r""" foo """

# Generated at 2022-06-20 23:20:21.500527
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo bar'")
    assert is_quoted('"foo bar"')
    assert not is_quoted("'foo bar")
    assert not is_quoted('"foo bar')
    assert not is_quoted("foo bar")
    assert not is_quoted("foo 'bar'")
    assert not is_quoted("foo \"bar\"")
    assert not is_quoted("'foo \'bar\'")

    assert is_quoted("'foo bar\"'")
    assert is_quoted("\"foo bar'\"")
    assert not is_quoted("'foo bar\\''")
    assert not is_quoted('"foo bar\\""')
    assert not is_quoted("'foo bar\"")
    assert not is_quoted('"foo bar\'')

    assert is_qu

# Generated at 2022-06-20 23:20:25.107324
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'bar'")
    assert not is_quoted('"foo\'"')
    assert not is_quoted('baz')
