

# Generated at 2022-06-20 23:19:27.344141
# Unit test for function unquote
def test_unquote():
    in_list = [
        '"test"',
        "'test'",
        'test',
    ]
    out_list = [
        'test',
        'test',
        'test',
    ]
    for i,o in zip(in_list,out_list):
        assert unquote(i) == o
        assert unquote(o) == o

# Generated at 2022-06-20 23:19:36.620851
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote('\\"foo"') == '\\"foo"' # quotes escaped with a backslash are NOT considered quotes
    assert unquote('"foo\\"') == '"foo\\"' # quotes escaped with a backslash are NOT considered quotes
    assert unquote('\\"foo\\"') == '\\"foo\\"' # quotes escaped with a backslash are NOT considered quotes
    assert unquote('\\"foo') == '\\"foo' # quotes escaped with a backslash are NOT considered quotes
    assert unquote('"foobar"') == "foobar"
    assert unquote('"""foobar"""') == '"foobar"' # literal quotes within quotes
    assert unquote('""foobar""') == '"foobar"'

# Generated at 2022-06-20 23:19:45.137005
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"test"') == True)
    assert(is_quoted('"test') == False)
    assert(is_quoted('test"') == False)
    assert(is_quoted('test') == False)
    assert(is_quoted('"test\\"') == False)
    assert(is_quoted("'test'") == True)
    assert(is_quoted("'test") == False)
    assert(is_quoted("test'") == False)
    assert(is_quoted("test") == False)
    assert(is_quoted("'test\\'") == False)

# Generated at 2022-06-20 23:19:47.474896
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'


# Generated at 2022-06-20 23:19:56.991155
# Unit test for function unquote
def test_unquote():
    if unquote('"abc"') != 'abc':
        raise AssertionError("unquote('\"abc\"') should equal abc")

    if unquote("'abc'") != 'abc':
        raise AssertionError("unquote(\"'abc'\") should equal abc")

    if unquote("'a'bc'") != "'a'bc'":
        raise AssertionError("unquote(\"'a'bc'\") should equal 'a'bc'")

    if unquote("'ab''c'") != "'ab''c'":
        raise AssertionError("unquote(\"'ab''c'\") should equal 'ab''c'")


# Generated at 2022-06-20 23:20:08.384538
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"x"')
    assert not is_quoted("'x'")
    assert is_quoted('"""x"""')
    assert is_quoted("'''x'''")
    assert not is_quoted("'x")
    assert not is_quoted("x'")
    assert not is_quoted('"x')
    assert not is_quoted("x\"")
    assert not is_quoted("'x\"")
    assert not is_quoted("\"x'")
    assert not is_quoted('"x"x')
    assert not is_quoted("'x'x")
    assert not is_quoted('"""x"""x')
    assert not is_quoted("'''x'''x")
    assert not is_quoted("'xx'")

# Generated at 2022-06-20 23:20:13.244320
# Unit test for function is_quoted
def test_is_quoted():
	assert is_quoted('"test"') == True
	assert is_quoted("'test'") == True
	assert is_quoted("'test") == False
	assert is_quoted('test') == False
	assert is_quoted('\"test') == False
	assert is_quoted('test\"') == False



# Generated at 2022-06-20 23:20:20.755789
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert is_quoted("'test\\''")
    assert is_quoted("'test'")
    assert not is_quoted("'test\\'''")
    assert is_quoted("u'test'")
    assert is_quoted("u'\u043f\u0440\u0438\u0432\u0435\u0442'")
    assert not is_quoted("''test\\''")
    assert not is_quoted("''test\\'''")
    assert not is_quoted("test")


# Generated at 2022-06-20 23:20:27.404835
# Unit test for function unquote
def test_unquote():

    assert "test" == unquote('test')
    assert "test" == unquote('"test"')
    assert "'test'" == unquote("'test'")
    assert "test"  == unquote("'test'")
    assert "test"  == unquote('"test"')
    assert "test'ing"  == unquote('"test\'ing"')
    assert "t'e'st"  == unquote("'t\\'e\\'st'")
    assert "test"  == unquote("'test")
    assert "test"  == unquote('"test')
    assert '"test'  == unquote('\\"test')
    assert 'test'  == unquote('"test\\"')
    assert 'test\\'  == unquote('"test\\\\"')

# Generated at 2022-06-20 23:20:34.472487
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'123'")
    assert not is_quoted('"123')
    assert not is_quoted("123")
    assert unquote("'123'") == "123"
    assert unquote("\"123\"") == "123"
    assert unquote("'" + '\\' + "\"foo") == '"foo'

if __name__ == '__main__':
    from subprocess import call
    import pytest
    exitcode = call(['py.test', '-v'])
    raise SystemExit(exitcode)