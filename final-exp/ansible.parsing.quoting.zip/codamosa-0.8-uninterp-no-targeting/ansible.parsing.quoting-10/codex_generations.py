

# Generated at 2022-06-20 23:19:36.553367
# Unit test for function is_quoted
def test_is_quoted():
    # Test 1, Unquoted strings
    assert not is_quoted('ansible')
    assert not is_quoted('ansible"')
    assert not is_quoted("ansible'")
    assert not is_quoted("ansible's")

    # Test 2, Quoted strings
    assert is_quoted("'ansible'")
    assert is_quoted('"ansible"')

    # Test 3, Quoted strings with quotes
    assert is_quoted("'ansible's'")
    assert is_quoted('"ansible\'s"')

    # Test 4, Quoted strings with backslash
    assert is_quoted("'ansible\\'s'")
    assert is_quoted("'ansible\\'s'")
    assert is_quoted("'ansible\\'s'")

#

# Generated at 2022-06-20 23:19:39.579060
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string"')
    assert is_quoted("'string'")
    assert is_quoted("' string '")
    assert not is_quoted("' string")
    assert not is_quoted('string')
    assert not is_quoted("'string\'")
    assert not is_quoted('')



# Generated at 2022-06-20 23:19:44.933078
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"alpha"')
    assert is_quoted("'alpha'")
    assert is_quoted("'a\\'lpha'")
    assert not is_quoted("alpha")
    assert not is_quoted('"a"lpha"')
    assert not is_quoted("'a\"lpha'")


# Generated at 2022-06-20 23:19:55.723360
# Unit test for function unquote
def test_unquote():
    assert unquote("example") == "example"
    assert unquote("'example'") == "example"
    assert unquote("\"example\"") == "example"
    assert unquote("'example") == "'example"
    assert unquote("example'") == "example'"
    assert unquote("\"example") == "\"example"
    assert unquote("example\"") == "example\""
    assert unquote("'example'") == "example"
    assert unquote("\"example\"") == "example"
    assert unquote("'example'") == "example"
    assert unquote("'example\\'") == "example\\'"
    assert unquote("\"example\\\"") == "example\\\""
    assert unquote("exa'ple'") == "exa'ple'"
    assert unquote("exa\"ple\"")

# Generated at 2022-06-20 23:19:59.016234
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted("'a'bc'")
    assert not is_quoted('a"bc')
    assert not is_quoted('"a""bc"')
    assert not is_quoted("'a''bc'")



# Generated at 2022-06-20 23:20:07.936911
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'1'") == True
    assert is_quoted("'hi'") == True
    assert is_quoted('"1"') == True
    assert is_quoted('"hi"') == True
    assert is_quoted("'hi' hi") == False
    assert is_quoted("'hi''hi'") == False
    assert is_quoted("'1'\"") == False
    assert is_quoted("'1'\"\"") == False



# Generated at 2022-06-20 23:20:13.491595
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('test"')
    assert not is_quoted("test'")
    assert is_quoted('"test\\"')
    assert is_quoted("'test\\'")


# Generated at 2022-06-20 23:20:18.544207
# Unit test for function unquote
def test_unquote():
    assert unquote('"value"') == "value"
    assert unquote('"va\"lue"') == "va\"lue"
    assert unquote('"value\\""') == "value\""
    assert unquote('"value"') != "\"value\""
    assert unquote('value') == "value"
    assert unquote('') == ""

# Generated at 2022-06-20 23:20:25.762407
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"This is quoted"')
    assert is_quoted("'This as well'")
    assert not is_quoted("This isn't")
    assert unquote('"This is quoted"') == "This is quoted"
    assert unquote("'This as well'") == "This as well"
    assert unquote("This isn't") == "This isn't"



# Generated at 2022-06-20 23:20:34.391125
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('') is False
    assert is_quoted('"') is False
    assert is_quoted('foo') is False
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo\\"bar"') is False
    assert is_quoted('"foo"bar"') is False
    assert is_quoted("'foo\\'bar'") is False
    assert is_quoted("'foo'bar'") is False
    assert is_quoted('"foo"bar"') is False
    assert is_quoted("'foo'bar'") is False

