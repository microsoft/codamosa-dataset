

# Generated at 2022-06-20 23:19:29.500890
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'foo \"bar\" foo'")
    assert is_quoted('''"foo"''')



# Generated at 2022-06-20 23:19:35.758222
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo\'') == False
    assert is_quoted("'foo\"") == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted('foo"') == False
    assert is_quoted("foo'") == False
    assert is_quoted('"foo\\"') == True



# Generated at 2022-06-20 23:19:40.402782
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted(r'"Quotes at the start and end"')
    assert is_quoted(r"'Quotes at the start and end'")
    assert not is_quoted(r"No quotes here")
    assert not is_quoted(r"No quotes here'")
    assert not is_quoted(r'"No quotes here')
    assert is_quoted(r'"\"Quotes\" at the start and end"')
    assert is_quoted(r"'\"Quotes\" at the start and end'")
    assert is_quoted(r"'Quote at start and end \"'")


# Generated at 2022-06-20 23:19:47.128191
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo")
    assert not is_quoted("'foo'\"")
    assert is_quoted(r"\'foo\'")
    assert is_quoted(r'"\\"foo\\""')



# Generated at 2022-06-20 23:19:51.688070
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted(r'"foo"')
    assert not is_quoted(r'"foo\"')
    assert not is_quoted(r'"foo')
    assert is_quoted(r"'foo'")
    assert not is_quoted(r"'foo\'")
    assert not is_quoted(r"'foo")


# Generated at 2022-06-20 23:19:56.571107
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted('\'test\'')
    assert not is_quoted('"test')
    assert not is_quoted('test\'')
    assert not is_quoted('test')
    assert not is_quoted('')
    assert not is_quoted('"""')
    assert not is_quoted('"""test"""')


# Generated at 2022-06-20 23:19:59.288273
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('test')
    assert is_quoted('"test"')
    assert is_quoted('"test\\"') == False
    assert is_quoted("'test'")
    assert is_quoted("'test\\'") == False


# Generated at 2022-06-20 23:20:06.346285
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert is_quoted('"test"')
    assert is_quoted("'test\"'")
    assert not is_quoted("'test\\'")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("'test")
    assert not is_quoted("test'")


# Generated at 2022-06-20 23:20:12.251170
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted\"") == True

# Generated at 2022-06-20 23:20:15.681843
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote("\"hello\"") == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote("'hello\\''") == "'hello\\''"