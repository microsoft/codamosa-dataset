

# Generated at 2022-06-20 23:19:32.786920
# Unit test for function unquote
def test_unquote():
    assert unquote('"string"') == 'string'
    assert unquote('"string') != 'string'
    assert unquote('string"') != 'string'
    assert unquote('foo"string"') != 'string'
    assert unquote('"foo""bar""baz"') == 'foo"bar"baz'





# Generated at 2022-06-20 23:19:37.801272
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == "foo"
    assert unquote("'\\'foo'") == "'foo"
    assert unquote("'f\\'oo'") == "f'oo"
    assert unquote("'fo\\'o'") == "fo'o"
    assert unquote("'foo\\''") == "foo'"

# tests to ensure unquote is not breaking anything

# Generated at 2022-06-20 23:19:40.710299
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote("foobar") == 'foobar'
    assert unquote('"foo\"bar"') == 'foo"bar'
    assert unquote("'foo'bar'") == "foo'bar"
    assert unquote("foo'bar'") == "foo'bar'"

# Generated at 2022-06-20 23:19:48.343264
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("''")
    assert is_quoted('""')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted("fo''o")
    assert not is_quoted("fo'o'")
    assert not is_quoted("foo")
    assert not is_quoted("'fo''o'")


# Generated at 2022-06-20 23:19:51.837850
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("hello") == 'hello'
    assert unquote("'hello' there") == "'hello' there"

# Generated at 2022-06-20 23:19:53.907619
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo\\''")
    assert not is_quoted('"foo\\""')
    assert not is_quoted('foo')
    assert not is_quoted('')


# Generated at 2022-06-20 23:19:56.288660
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('test') == 'test'

# Generated at 2022-06-20 23:20:04.830468
# Unit test for function unquote
def test_unquote():
    def test(value, expected):
        result = unquote(value)
        if result != expected:
            raise AssertionError("unquote(%r) returned %r instead of %r" % (value, result, expected))
        # make sure the result is quoted
        result2 = unquote(result)
        if result != result2:
            raise AssertionError("unquote(%r) did not return a quoted string as expected (%r)" % (value, result2))

    yield test, '"val"', 'val'
    yield test, "'val'", 'val'
    yield test, '"val', '"val'

# Generated at 2022-06-20 23:20:09.362239
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('"he\'llo"')


# Generated at 2022-06-20 23:20:19.845273
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"this is quoted\"") == True
    assert is_quoted("\"this \\\"is\\\" quoted\"") == True
    assert is_quoted("'this is quoted'") == True
    assert is_quoted("'this \\'is\\' quoted'") == True
    assert is_quoted("'this \\\'is\\\' quoted'") == True
    assert is_quoted("\"this is \"quoted\"") == False
    assert is_quoted("\"this is 'quoted'\"") == False
    assert is_quoted("'this is \"quoted\"'") == False
    assert is_quoted("'this is \\'quoted\\''") == False
    assert is_quoted("'this is 'quoted'") == False