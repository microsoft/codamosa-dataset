

# Generated at 2022-06-20 23:19:30.773887
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"foo\"") == True
    assert is_quoted("\'foo\'") == True
    assert is_quoted("\"foo") == False
    assert is_quoted("\'foo") == False
    assert is_quoted("foo") == False


# Generated at 2022-06-20 23:19:38.585966
# Unit test for function unquote
def test_unquote():
    assert unquote('test') == 'test'
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('"te\\"st"') == 'te\\"st'
    assert unquote("'test'") == 'test'
    assert unquote("'test") == "'test"
    assert unquote("test'") == "test'"
    assert unquote("'te\\'st'") == "te\\'st"
    assert unquote("'te\\'st") == "'te\\'st"
    assert unquote("te\\'st'") == "te\\'st'"
    assert unquote("te\\'st") == "te\\'st"


# Generated at 2022-06-20 23:19:43.561439
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo') == 'foo'

# ------------------------------------------------------------------------------


# Generated at 2022-06-20 23:19:54.712438
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"')==True)
    assert(is_quoted("'foo'")==True)
    assert(is_quoted('"foo"bar')==False)
    assert(is_quoted('foo"bar"')==False)
    assert(is_quoted('foo')==False)
    assert(is_quoted('"foo"bar"')==False)
    assert(is_quoted('foobar')==False)
    assert(is_quoted('"foo"b"ar"')==False)
    assert(is_quoted('"fo"ob"ar"')==False)
    assert(is_quoted('"f"o"o"b"a"r"')==False)
    assert(is_quoted('"""foo"""')==True)

# Generated at 2022-06-20 23:19:57.859214
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('\'foo"') == '\'foo"'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo\'"') == '"foo\'"'



# Generated at 2022-06-20 23:20:02.401456
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"single\'"')
    assert is_quoted('\'double\"')
    assert is_quoted('\'single\'')
    assert not is_quoted('\'single"')
    assert not is_quoted('"double"')


# Generated at 2022-06-20 23:20:11.286112
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted('"foo\\"') is False
    assert is_quoted("'foo'")
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted("'foo\\'") is False
    assert is_quoted('"foo"bar"') is False
    assert is_quoted('"foo\'"') is False
    assert is_quoted('"foo\\"bar"') is False



# Generated at 2022-06-20 23:20:16.850517
# Unit test for function is_quoted
def test_is_quoted():
    '''
    Test is_quoted function
    '''
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc')
    assert not is_quoted("'abc")
    assert not is_quoted("'ab\"c'")
    assert not is_quoted('"ab\'c"')


# Generated at 2022-06-20 23:20:23.343675
# Unit test for function is_quoted
def test_is_quoted():
    actual = is_quoted('"foo"')
    assert(actual)

    actual = is_quoted('\'foo\'')
    assert(actual)

    actual = is_quoted('\'foo"')
    assert(not actual)

    actual = is_quoted('"foo\'')
    assert(not actual)

    actual = is_quoted('\'foo"')
    assert(not actual)

    actual = is_quoted('foo')
    assert(not actual)



# Generated at 2022-06-20 23:20:29.317488
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"This is quoted"') == True
    assert is_quoted("'This is quoted'") == True
    assert is_quoted("This is not quoted") == False
    assert is_quoted("'This \"is\" quoted'") == True
    assert is_quoted("'This is not quoted\\'") == False
    assert is_quoted("'rsh \'test\' \"foo\"'") == False  # this string is not quoted

