

# Generated at 2022-06-20 23:19:31.749224
# Unit test for function unquote
def test_unquote():
    # Test if unquote removes the quotes correctly
    assert unquote('"a"') == 'a'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'
    assert unquote('"a\\""') == 'a"'
    assert unquote('a') == 'a'
    assert unquote('a\\"') == 'a"'
    assert unquote('a\\\\"') == 'a\\'
    assert unquote('a\\\\\\"') == 'a\\"'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'
    assert unquote('"a"') == 'a'
    assert unquote('\\"a\\"') == '"a"'

# Generated at 2022-06-20 23:19:38.108576
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted("''")
    assert is_quoted('"foo"')
    assert is_quoted('""')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted("foo")
    assert not is_quoted("'''")
    assert not is_quoted("'''foo'bar'")
    assert not is_quoted('""foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert not is_quoted('"foo"bar"')


# Generated at 2022-06-20 23:19:43.485466
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert not is_quoted('"foobar\\""')
    assert not is_quoted('foobar')
    assert not is_quoted('foobar"')
    assert not is_quoted('"foobar')
    assert not is_quoted('')
    assert is_quoted("'barfoo'")


# Generated at 2022-06-20 23:19:48.216652
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"hello"')
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'

# Generated at 2022-06-20 23:19:53.265291
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"hello world\"") == True
    assert is_quoted("'hello world'") == True
    assert is_quoted('"hello world') == False
    assert is_quoted("'hello world") == False
    assert is_quoted("'hello world\'quoted\'") == False


# Generated at 2022-06-20 23:19:54.753016
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted('foo') == False


# Generated at 2022-06-20 23:20:03.160549
# Unit test for function unquote
def test_unquote():
    """
    >>> test_unquote()
    unquote 'test' returned 'test', expected 'test'
    unquote '"test"' returned 'test', expected 'test'
    unquote '"test\\"" returned '"test"', expected '"test\\""
    unquote '\\"test\\"' returned '"test"', expected '"test"'
    unquote '\\"test"' returned '"test', expected '"test"'
    unquote '"test' returned '"test', expected '"test"'
    """
    from collections import namedtuple
    TEST = namedtuple('TEST', 'in_, out')

# Generated at 2022-06-20 23:20:13.048232
# Unit test for function is_quoted
def test_is_quoted():
    real_quoted_strs = [
        '"hello"',
        "'hello'",
        '"""hello"""',
        "'''hello'''"
    ]
    real_unquoted_strs = [
        '"hello',
        "'hello",
        '"""hello',
        "'''hello",
        "''hello''",
        '""hello""',
        '"hello""',
        "'hello''"
    ]
    for quoted_str in real_quoted_strs:
        assert is_quoted(quoted_str)

    for unquoted_str in real_unquoted_strs:
        assert (not is_quoted(unquoted_str))


# Generated at 2022-06-20 23:20:22.515575
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote('"hello world') == '"hello world'
    assert unquote('hello world"') == 'hello world"'

# Quoting from RFC 3986, Appendix A (dealing with reserved and unreserved characters)
# except we add ~ and ! to the list of unreserved (legal in RFC, but not in practice)
# and we also don't deal with sub-delims, because they're not valid in our context.
#
# gen-delims  = ":" / "/" / "?" / "#" / "[" / "]" / "@"
# sub-delims  = "!" / "$" / "&" / "'" / "(" / ")"
#              / "*" / "+" / "," / ";" / "="
# reserved    = gen-delims

# Generated at 2022-06-20 23:20:32.614771
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert not is_quoted('"foobar\\""')
    assert not is_quoted("'foobar\\''")
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted('foobar"')
    assert not is_quoted("foobar'")
    assert not is_quoted('\\"foobar"')
    assert not is_quoted("\\'foobar'")
    assert not is_quoted(' \\"foobar"')
    assert not is_quoted(" \\'foobar'")
    assert not is_quoted(' "foobar"')
    assert not is_quoted(" 'foobar'")