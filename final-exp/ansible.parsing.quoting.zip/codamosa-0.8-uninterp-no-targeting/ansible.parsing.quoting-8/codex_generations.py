

# Generated at 2022-06-20 23:19:32.346805
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted('"foo"') != True:
        raise AssertionError('non-quoted test failed')
    if is_quoted('\'foo\'') != True:
        raise AssertionError('non-quoted test failed')
    if is_quoted('foo') == True:
        raise AssertionError('quoted test failed')
    if is_quoted('fo\'o') == True:
        raise AssertionError('quoted test failed')
    if is_quoted('fo"o') == True:
        raise AssertionError('quoted test failed')
    if is_quoted('"foo"bar') == True:
        raise AssertionError('quoted test failed')

# Generated at 2022-06-20 23:19:38.169669
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"ab\\"c"') == 'ab\\"c'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('\'ab\\\'c\'') == 'ab\\\'c'
    assert unquote('"ab\'c"') == 'ab\'c'
    assert unquote('\'ab"c\'') == 'ab"c'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'



# Generated at 2022-06-20 23:19:45.181244
# Unit test for function unquote
def test_unquote():
    assert unquote('test string') == 'test string'
    assert unquote('"test string"') == 'test string'
    assert unquote("'test string'") == 'test string'
    assert unquote('"te\\"st string"') == 'te\\"st string'
    assert unquote('"test st\\ring"') == 'test st\\ring'
    assert unquote('"this is a \\n multi-line \\"string\\" \\\\"') == 'this is a \n multi-line "string" \\'

# Generated at 2022-06-20 23:19:55.647791
# Unit test for function unquote
def test_unquote():
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd"') == 'abcd'
    assert unquote('"abcd') == '"abcd'
    assert unquote('abcd"') == 'abcd"'
    assert unquote('"ab"cd"') == '"ab"cd"'
    assert unquote('"ab\\"cd"') == 'ab\\"cd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote("'abcd") == "'abcd"
    assert unquote("abcd'") == "abcd'"
    assert unquote("'ab'cd'") == "'ab'cd'"
    assert unquote("'ab\\'cd'") == "ab\\'cd"



# Generated at 2022-06-20 23:19:59.193546
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("'hello\"")
    assert not is_quoted("'hello''")
    assert not is_quoted("hello")


# Generated at 2022-06-20 23:20:09.960987
# Unit test for function is_quoted
def test_is_quoted():
    #correct
    assert is_quoted('"testing"')
    assert is_quoted('"testing"')
    assert is_quoted("'testing'")
    assert is_quoted("'testing'")
    assert is_quoted("'" + '\\'+ '"' + "'")
    assert is_quoted("'" + '"' + "'")
    #false
    assert not is_quoted("'testing")
    assert not is_quoted("test'ing")
    assert not is_quoted("tes'ting'")
    assert not is_quoted("'testin'g")
    assert not is_quoted("testin'g'")
    assert not is_quoted("'test'ing")



# Generated at 2022-06-20 23:20:18.685690
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a"')
    assert is_quoted("'a'")
    assert is_quoted("'a\\'s'")
    assert not is_quoted("'a'foo'")
    assert not is_quoted("'a")
    assert not is_quoted("a\"")
    assert is_quoted("'a\"s'")
    assert is_quoted("'a\"s\\' ")
    assert not is_quoted("'a\"s\\'")
    assert not is_quoted("'a\"s\\")
    assert is_quoted("'a\"s\\''")


# Generated at 2022-06-20 23:20:30.356229
# Unit test for function is_quoted

# Generated at 2022-06-20 23:20:37.570120
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"single"')
    assert is_quoted("'single'")
    assert is_quoted('"double"')
    assert is_quoted("'double'")
    assert not is_quoted('"mix"\'ed') # don't quote mixed quotes
    assert not is_quoted('unquoted')
    assert not is_quoted('"back\\"slashes"')
    assert not is_quoted('"escaped_slash\\"')


# Generated at 2022-06-20 23:20:41.223177
# Unit test for function unquote
def test_unquote():
    assert 'book' == unquote('"book"')
    assert 'book' == unquote("'book'")
    assert 'book' == unquote('book')
    assert 'book' == unquote('"book')

