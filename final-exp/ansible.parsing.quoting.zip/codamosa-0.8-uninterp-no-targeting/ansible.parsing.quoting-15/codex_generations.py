

# Generated at 2022-06-20 23:19:29.152975
# Unit test for function unquote
def test_unquote():
    assert(unquote('') == '')
    assert(unquote('"abc"') == 'abc')
    assert(unquote('\'abc\'') == 'abc')
    assert(unquote('"abc\'') == '"abc\'')
    assert(unquote('"abc\'d"') == 'abc\'d')
    assert(unquote('"ab\'c"') == 'ab\'c')
    assert(unquote('""') == '')
    assert(unquote('\'\'') == '')


# Generated at 2022-06-20 23:19:31.937421
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"')
    assert is_quoted("'hello world'")
    assert not is_quoted('"hello \"world"')
    assert not is_quoted('hello "world"')


# Generated at 2022-06-20 23:19:32.958295
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'

# Generated at 2022-06-20 23:19:42.098002
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('"test"ing') == '"test"ing'
    assert unquote('"test\\"') == '"test\\"'
    assert unquote('"test\\\\"') == '"test\\\\"'
    assert unquote('""') == ''
    assert unquote('"') == '"'
    assert unquote('"\\"') == '"\\"'
    assert unquote('\\"') == '\\"'
    assert unquote('\\\\"') == '\\\\"'
    assert unquote('\\\\\\"') == '\\\\\\"'

# Generated at 2022-06-20 23:19:49.496575
# Unit test for function unquote
def test_unquote():
    assert unquote('this is unquoted') == 'this is unquoted'
    assert unquote('"this is quoted"') == 'this is quoted'
    assert unquote('"this is quoted with a space"') == 'this is quoted with a space'
    assert unquote('"this is quoted with a backslash\\""') == 'this is quoted with a backslash"'
    assert unquote("'this is quoted with a space'") == 'this is quoted with a space'
    assert unquote('') == ''



# Generated at 2022-06-20 23:19:57.766509
# Unit test for function unquote
def test_unquote():
    assert unquote("\"toto\"") == "toto"
    assert unquote("\"toto") == "\"toto"
    assert unquote("toto\"") == "toto\""
    assert unquote("\"toto\\\"") == "\"toto\\\""
    assert unquote("'toto'") == "toto"
    assert unquote("'toto") == "'toto"
    assert unquote("toto'") == "toto'"
    assert unquote("'toto\\'") == "'toto\\'"
    assert unquote("'toto\\\"") == "'toto\\\""
    assert unquote("\"toto\\'") == "\"toto\\'"

# Generated at 2022-06-20 23:20:08.941138
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("$foo") == False
    assert is_quoted("'$foo'") == True
    assert is_quoted("'\\''$foo'") == True
    assert is_quoted("'\\''$foo") == False
    assert is_quoted("'\\'foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("\"foo\"") == True
    assert is_quoted("\"'\"") == True
    assert is_quoted("\"'\"'") == False
    assert is_quoted("''") == True
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("") == False

# Unit tests for function unquote

# Generated at 2022-06-20 23:20:17.921035
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('This is a test') == 'This is a test'
    assert unquote('"This is a test"') == 'This is a test'
    assert unquote("'This is a test'") == 'This is a test'
    assert unquote('"This \'is\' a test"') == "This 'is' a test"
    assert unquote("'This \"is\" a test'") == 'This "is" a test'
    assert unquote('"This is a test\\""') == 'This is a test"'
    assert unquote("'This is a test\\''") == "This is a test'"



# Generated at 2022-06-20 23:20:23.111488
# Unit test for function is_quoted
def test_is_quoted():
    test_str = 'hello'
    assert not is_quoted(test_str)
    test_str = '"hello"'
    assert is_quoted(test_str)
    test_str = "'hello'"
    assert is_quoted(test_str)
    test_str = "'hell\"o'"
    assert is_quoted(test_str)
    test_str = "'hello\''"
    assert not is_quoted(test_str)



# Generated at 2022-06-20 23:20:24.598955
# Unit test for function is_quoted
def test_is_quoted():
    examples = [('"hello"', True), ("'hello'", True), ('hello', False), ('"hello', False), ('hello"', False)]
    for example in examples:
        assert(is_quoted(example[0]) == example[1])

