

# Generated at 2022-06-20 23:19:36.034503
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted("'simple quoted string'") == True
    assert is_quoted('"simple quoted string"') == True
    assert is_quoted("'quoted string with single quote (') in it'") == True
    assert is_quoted('"quoted string with double quote (\") in it"') == True
    assert is_quoted("'quoted string with single quote (\\') and double quote (\\\") in it'") == True
    assert is_quoted('"quoted string with single quote (\') and double quote (\") in it"') == True
    assert is_quoted("''") == False
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo' bar") == False
    assert is_quoted

# Generated at 2022-06-20 23:19:39.810878
# Unit test for function unquote
def test_unquote():
    test_data = [
        '"This is a quoted string"',
        '\'This is another quoted string\'',

        # some simple edge cases
        '',
        '"',
        '\'',
        '""',
        '\'\'',
    ]

    for data in test_data:
        assert data == (unquote(unquote(data))), "Failed to re-quoted string test: %s == %s" % (data, unquote(unquote(data)))

# Generated at 2022-06-20 23:19:50.855697
# Unit test for function unquote
def test_unquote():
    # Template is valid regardless of quotes
    valid_testcases = [
        ('"test"', 'test'),
        ("'test'", 'test'),
        ('"test"', 'test'),
        ("'test'", 'test'),
        ('"test"', '"test"'),
        ("'test'", "'test'"),
        ("test", 'test'),
        ("test", "test"),
        ("test", '"test"'),
        ("test", "'test'"),
        ("test", 'test'),
        ("test", "test"),
        ("test", '"test"'),
        ("test", "'test'"),
        ("test'", "test'"),
        ("'test", "'test"),
        ("test'", "'test'"),
        ("'test", "test"),
    ]

    # Template is invalid if quotes are

# Generated at 2022-06-20 23:19:59.118699
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"')
    assert is_quoted("'hello world'")
    assert not is_quoted('"hello world')
    assert not is_quoted("'hello world")
    assert not is_quoted('hello world"')
    assert not is_quoted("hello world'")
    assert not is_quoted('"hello world\\"')
    assert not is_quoted("'hello world\\'")
    assert not is_quoted('\'hello world\'')
    assert not is_quoted('"hello world" more')
    assert not is_quoted('hello world')
    assert is_quoted('"hello world\\""')
    assert is_quoted("'hello world\\''")



# Generated at 2022-06-20 23:20:01.959919
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"abc"') == 'abc'



# Generated at 2022-06-20 23:20:07.740611
# Unit test for function unquote
def test_unquote():
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote('\'foobar\'') == 'foobar'
    assert unquote('\\"foobar\\"') == '"foobar"'
    assert unquote('\\"foo\\"bar"') == '"foo"bar"'


# Generated at 2022-06-20 23:20:14.094596
# Unit test for function unquote
def test_unquote():
    assert unquote(u'hello') == u'hello'
    assert unquote(u'"hello"') == u'hello'
    assert unquote(u'"hello') == u'"hello'
    assert unquote(u'hello"') == u'hello"'
    assert unquote(u'"hello\'"') == u'"hello\'"'
    assert unquote(u'"hello\\""') == u'"hello\\"'

# split args (can handle quoted strings with spaces)

# Generated at 2022-06-20 23:20:17.920833
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('test') == 'test'
    assert unquote('"test""') == 'test""'



# Generated at 2022-06-20 23:20:20.918615
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"he\\"llo"') == 'he"llo'


# Generated at 2022-06-20 23:20:24.895735
# Unit test for function unquote
def test_unquote():
    assert unquote('"ab"') == 'ab'
    assert unquote('"a\\"b"') == 'a\\"b'
    assert unquote("'ab'") == 'ab'
    assert unquote('"ab') == '"ab'
    assert unquote("'ab") == "'ab"

# backwards compatibility with old versions of python which
# were missing the newer string functions