

# Generated at 2022-06-20 23:19:25.232186
# Unit test for function unquote
def test_unquote():
    assert unquote('"some string"') == 'some string'
    assert unquote("'some string'") == 'some string'
    assert unquote('"some string\\"') == 'some string\\"'
    assert unquote('"some string"') != 'some string"'
    assert unquote('some string') == 'some string'

# Generated at 2022-06-20 23:19:30.811504
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True, "'foo' was not quoted"
    assert is_quoted("'foo") == False, "'foo' was quoted"
    assert is_quoted("\"foo\"") == True, "\"foo\" was not quoted"
    assert is_quoted("\"foo") == False, "\"foo\" was quoted"
    assert is_quoted("''") == False, "'' was quoted"


# Generated at 2022-06-20 23:19:37.890848
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('bar') == 'bar'
    assert unquote("'fo\\'o'") == "fo\\'o"
    assert unquote('"fo\\"o"') == 'fo\\"o'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"""foo"""') == 'foo'
    assert unquote("'''foo'''") == 'foo'
    assert unquote("'' 'foo'") == "'foo'"
    assert unquote('""" \\"foo"') == '\\"foo'


# Generated at 2022-06-20 23:19:42.923303
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert is_quoted('"foo" "bar"')
    assert not is_quoted('"foo" bar')
    assert not is_quoted('"fo\\o')
    assert not is_quoted('baz')



# Generated at 2022-06-20 23:19:50.014256
# Unit test for function is_quoted
def test_is_quoted():
    test_data = [
        ("'foo'", True),
        ('"foo"', True),
        ('foo', False),
        ('"foo', False),
        ('foo"', False),
        ('"foo\\"bar"', False),
    ]

    for (input, expected) in test_data:
        actual = is_quoted(input)
        assert actual == expected, '%s: expected %s, but got %s' % (repr(input), repr(expected), repr(actual))


# Generated at 2022-06-20 23:19:59.003296
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote("'t\"est'") == 't"est'
    assert unquote("\"t'est\"") == "t'est"
    assert unquote("'te\\'st'") == "te\\'st"
    assert unquote("'te\\\\st'") == "te\\\\st"
    assert unquote("\"te\\\\st\"") == "te\\\\st"
    assert unquote("\"te\\\\\\\"st\"") == "te\\\\\\\"st"
    assert unquote("\"te\\\\\\\"s\\\"t\"") == "te\\\\\\\"s\\\"t"
    assert unquote("\"te\\\\\\\\st\"") == "te\\\\\\\\st"

# Generated at 2022-06-20 23:20:10.977321
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert not is_quoted("'abc")
    assert not is_quoted("ab'c")
    assert not is_quoted("ab\"c")
    assert not is_quoted("'ab'c'")
    assert not is_quoted("\"a\"bc\"")
    assert not is_quoted("\"abc\"\"")
    assert is_quoted("''")
    assert not is_quoted("'")
    assert not is_quoted("'''")
    assert is_quoted('"ab\\"c"')
    assert not is_quoted("\'a\'bc\'")
    assert not is_quoted("\"ab\'c\"")
    assert not is_quoted("\'ab\"c\'")


# Generated at 2022-06-20 23:20:14.148137
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test\\""')

# Generated at 2022-06-20 23:20:17.972316
# Unit test for function unquote
def test_unquote():
    assert unquote('test') == 'test'
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test') == '"test'
    assert unquote("'test") == "'test"

# Generated at 2022-06-20 23:20:23.740110
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote(r"'hello\'s world'") == "hello\'s world"
    assert unquote("'hello's world'") == "'hello's world'"
    assert unquote('"hello\\"s world"') == 'hello"s world'
    assert unquote('"hello"s world"') == '"hello"s world"'
    assert unquote('hello') == 'hello'