

# Generated at 2022-06-20 23:19:33.892899
# Unit test for function unquote
def test_unquote():
    assert 'a' == unquote("'a'")
    assert 'a' == unquote('"a"')
    assert 'a b' == unquote('"a b"')
    assert 'a b' == unquote("'a b'")
    assert '''a "b"''' == unquote('''"a \"b\""''')
    assert '''a 'b''' == unquote("'''a 'b'''")
    assert 'a \'b' == unquote("'a \\'b'")
    assert 'a "b' == unquote('"a \\"b"')
    assert 'a "b' == unquote("'a \\\"b'")
    assert 'a \'b' == unquote('"a \\\'b"')

# Generated at 2022-06-20 23:19:39.344958
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo')
    assert not is_quoted('foo')
    assert is_quoted("'foo'")
    assert not is_quoted("foo'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo")


# Generated at 2022-06-20 23:19:44.056007
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") != 'hello'
    assert unquote("hello'") != 'hello'
    assert unquote("hello") == 'hello'
    assert unquote("'hel\"lo'") == 'hel"lo'


# Generated at 2022-06-20 23:19:54.514565
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"')         == 'foo'
    assert unquote('"foo bar"')     == 'foo bar'
    assert unquote('"foo\"bar"')    == 'foo\"bar'
    assert unquote('"foo\\"bar"')   == 'foo\\"bar'
    assert unquote('"foo\\""')      == 'foo\\"'
    assert unquote('"foo"bar')      == '"foo"bar'
    assert unquote('foo"')          == 'foo"'
    assert unquote('foo\\"')        == 'foo\\"'
    assert unquote('foo\\\'bar')    == 'foo\\\'bar'
    assert unquote('"foo\\\'bar"')  == 'foo\\\'bar'



# Generated at 2022-06-20 23:19:59.371569
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"a"') == True)
    assert(is_quoted("'a'") == True)
    assert(is_quoted('"a"+"b"') == False)
    assert(is_quoted('"a\\""') == True)
    assert(is_quoted('"a\\""+"c"') == False)
    assert(is_quoted('a') == False)
    assert(is_quoted('') == False)


# Generated at 2022-06-20 23:20:08.983439
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('unquoted_string')
    assert is_quoted("'quoted_string'")
    assert is_quoted('"quoted_string"')
    assert is_quoted("'quoted_string\"") == False
    assert is_quoted("\"quoted_string'") == False
    assert is_quoted("'quoted_stri\\'ng'") == False
    assert is_quoted("'q\\'uoted_string'")
    assert is_quoted("'quoted_stri\\\"ng'") == False
    assert is_quoted("'quoted_stri\\\\ng'")

# Generated at 2022-06-20 23:20:15.580507
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world!"') == 'hello world!'
    assert unquote("'hello world!'") == 'hello world!'
    assert unquote('hello world!') == 'hello world!'
    assert unquote('"hello world!') != 'hello world!'
    assert unquote('hello world!"') != 'hello world!'
    assert unquote('"hello world!') == '"hello world!'
    assert unquote('hello world!"') == 'hello world!"'


# Generated at 2022-06-20 23:20:20.960418
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"example"')
    assert is_quoted("'example'")
    assert is_quoted("'ex\\'ample'")
    assert is_quoted("'ex\\\\ample'")
    assert not is_quoted("'ex\\ample'")
    assert not is_quoted("example")
    assert not is_quoted("")
    assert not is_quoted("'exam\\ple'")


# Generated at 2022-06-20 23:20:27.140291
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted("'string'") == True)
    assert( is_quoted("'string with \"double quotes\"'") == True)
    assert( is_quoted("\"string with single \' quotes\"") == True)
    assert( is_quoted("\'string with single \' quotes\'") == True)
    assert( is_quoted("\"string with escaped \\\" quotes\"") == True)
    assert( is_quoted("\'string with escaped \\\' quotes\'") == True)
    assert( is_quoted("string without quotes") == False)
    assert( is_quoted("\'string without ending quotes") == False)
    assert( is_quoted("string without ending quotes\'") == False)


# Generated at 2022-06-20 23:20:30.709020
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"

