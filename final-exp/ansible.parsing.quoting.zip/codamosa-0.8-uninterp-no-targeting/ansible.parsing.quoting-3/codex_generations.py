

# Generated at 2022-06-20 23:19:34.257432
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"v1"')
    assert is_quoted("'v1'")
    assert not is_quoted('v1')
    assert unquote('"v1"') == 'v1'
    assert unquote('"v1') == '"v1'
    assert unquote("'v1'") == 'v1'
    assert unquote("'v1") == "'v1"
    assert unquote("v1") == "v1"

# Generated at 2022-06-20 23:19:37.012716
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('foo')



# Generated at 2022-06-20 23:19:41.197178
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted('foobar"')
    assert not is_quoted("foobar'")
    assert not is_quoted('"foobar\\"')
    assert not is_quoted("'foobar\\'")
    assert is_quoted('"\\"foobar\\""')
    assert is_quoted("'\\'foobar\\''")


# Generated at 2022-06-20 23:19:50.358831
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("just a string") == False
    assert is_quoted("'just string'") == True
    assert is_quoted("'just string") == False
    assert is_quoted("just string'") == False
    assert is_quoted('"just string"') == True
    assert is_quoted("\"just string\"") == True
    assert is_quoted('"just string') == False
    assert is_quoted("'escaped \\\' quote'") == False
    assert is_quoted("'escaped \\' quote'") == False
    assert is_quoted('"escaped \" quote"') == True


# Generated at 2022-06-20 23:19:55.180591
# Unit test for function is_quoted
def test_is_quoted():
    true_tests = ['"this"', "'this'", '"\\"this\\""']
    false_tests = ['this', '"this', 'this"']

    for test in true_tests:
        assert is_quoted(test)

    for test in false_tests:
        assert not is_quoted(test)


# Generated at 2022-06-20 23:20:01.511434
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foobar"') == True)
    assert(is_quoted('foobar"') == False)
    assert(is_quoted('"foobar') == False)
    assert(is_quoted('"foobar ') == False)
    assert(is_quoted('"foobar" ') == False)
    assert(is_quoted('\'foobar\' ') == False)
    assert(is_quoted('\'foobar\'') == True)
    assert(is_quoted('foobar\'') == False)
    assert(is_quoted('\'foobar') == False)
    assert(is_quoted('\'foo\\\'bar\'') == True)
    assert(is_quoted('\'foo\\\'bar') == False)

# Generated at 2022-06-20 23:20:06.871725
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'he\\'llo'")
    assert not is_quoted('hello')
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello\'')


# Generated at 2022-06-20 23:20:13.943219
# Unit test for function unquote
def test_unquote():
    mystrings = ['good',
                 '"good"',
                 '"good',
                 '"good',
                 'good"',
                 '"goo"d"',
                 '"goo\"d"',
                 'good\\"',
                 '\"good',
                 '\"good\"',
                 ]

    for mystring in mystrings:
        unquoted = unquote(mystring)

# Generated at 2022-06-20 23:20:17.777713
# Unit test for function unquote
def test_unquote():
    assert unquote("''") == ''
    assert unquote("'test'") == 'test'
    assert unquote("'test\\''") == 'test\''
    assert unquote("test") == 'test'
    assert unquote("'test") == "'test"

# Generated at 2022-06-20 23:20:25.397544
# Unit test for function unquote
def test_unquote():
    assert unquote('"""foo"""') == '"""foo"""'
    assert unquote('''''foo''''') == '''''foo'''''
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"""foo') == '"""foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"fo\\o"') == '"fo\\o"'

#=====
