

# Generated at 2022-06-25 04:01:16.282274
# Unit test for function unquote
def test_unquote():
    str_0 = '356kVh@"KP`x9+uq['
    var_0 = is_quoted(str_0)
    assert var_0 == False
    str_1 = "`%cM7g2q(1uH7X~o\\"
    var_1 = unquote(str_1)
    assert var_1 == '`%cM7g2q(1uH7X~o\\'
    str_2 = "\"n4[\"n4["
    var_2 = unquote(str_2)
    assert var_2 == "n4[\"n4["
    str_3 = "91+X9;_:Cj?(Q%\\"
    var_3 = is_quoted(str_3)
    assert var_3 == False
    str

# Generated at 2022-06-25 04:01:26.640418
# Unit test for function unquote
def test_unquote():
    str_1 = '356kVh@"KP`x9+uq['
    assert unquote(str_1) == '356kVh@"KP`x9+uq['

    str_2 = '356kVh@"KP`x9+uq[\'356kVh@"KP`x9+uq[356kVh@"KP`x9+uq['
    assert unquote(str_2) == '356kVh@"KP`x9+uq['

    str_3 = '356kVh@"KP`x9+uq[356kVh@"KP`x9+uq[356kVh@"KP`x9+uq[356kVh@"KP`x9+uq['
    assert un

# Generated at 2022-06-25 04:01:33.231165
# Unit test for function unquote
def test_unquote():
    str_0 = 'Z7V$^*B+:J^Pc49'
    str_1 = unquote(str_0)
    assert str_1 == 'Z7V$^*B+:J^Pc49'
    str_0 = "Z7V$^*B+:J^Pc49"
    str_1 = unquote(str_0)
    assert str_1 == 'Z7V$^*B+:J^Pc49'
    str_0 = '"Z7V$^*B+:J^Pc49"'
    str_1 = unquote(str_0)
    assert str_1 == 'Z7V$^*B+:J^Pc49'
    str_0 = "'Z7V$^*B+:J^Pc49'"
    str

# Generated at 2022-06-25 04:01:40.947414
# Unit test for function unquote
def test_unquote():
    str_0 = '356kVh@"KP`x9+uq['
    str_1 = '["foo", "bar"]'
    str_2 = 'bar'
    str_3 = '["foo"]'
    str_4 = '["foo", "bar"]'
    str_5 = '["foo"]'
    str_6 = 'bar'
    str_7 = '["foo"]'
    str_8 = '["foo", "bar"]'
    str_9 = '["foo"]'
    str_10 = 'bar'
    str_11 = '["foo"]'
    str_12 = '["foo", "bar"]'
    str_13 = '["foo"]'
    str_14 = 'bar'
    str_15 = '["foo"]'

# Generated at 2022-06-25 04:01:51.573987
# Unit test for function is_quoted
def test_is_quoted():
    str_0 = '356kVh@"KP`x9+uq['
    var_0 = is_quoted(str_0)
    assert var_0 == False

    str_1 = '0'
    var_1 = is_quoted(str_1)
    assert var_1 == False

    str_2 = '`'
    var_2 = is_quoted(str_2)
    assert var_2 == False

    str_3 = '"`OF9\x1b\\\t2'
    var_3 = is_quoted(str_3)
    assert var_3 == True

    str_4 = '""'
    var_4 = is_quoted(str_4)
    assert var_4 == True

    str_5 = '"""'

# Generated at 2022-06-25 04:01:53.996408
# Unit test for function unquote
def test_unquote():
    str_0 = '"some string"'
    str_1 = 'some string'
    str_2 = unquote(str_0)
    assert str_1 == str_2


if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-25 04:01:58.423600
# Unit test for function unquote
def test_unquote():
    assert unquote('"356kVh@"KP`x9+uq[') == '356kVh@"KP`x9+uq['
    assert unquote("'356kVh@'KP`x9+uq[") == '356kVh@\'KP`x9+uq['
    assert unquote("356kVh@'KP`x9+uq[") == "356kVh@'KP`x9+uq["


# Generated at 2022-06-25 04:02:05.418193
# Unit test for function unquote
def test_unquote():
    args = ['string']
    hostname = "testhost"
    port = 22
    

# Generated at 2022-06-25 04:02:06.717288
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-25 04:02:14.093360
# Unit test for function unquote
def test_unquote():
    assert unquote('"value"') == 'value'
    assert unquote("'value'") == 'value'
    assert unquote('"value\\"') == 'value\\"'
    assert unquote('"value""') == '"value""'
    assert unquote('value\\"') == 'value\\"'
    assert unquote('') == ''

