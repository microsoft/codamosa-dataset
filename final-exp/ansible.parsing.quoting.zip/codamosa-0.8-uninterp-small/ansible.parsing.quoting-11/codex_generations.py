

# Generated at 2022-06-25 04:01:08.225016
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('\'test\'')
    assert True == is_quoted('"test"')
    assert True == is_quoted('"test"\\')
    assert False == is_quoted('\'test\\\'')
    assert False == is_quoted('\\\'test\\\'')
    assert False == is_quoted('test')
    assert False == is_quoted('""')



# Generated at 2022-06-25 04:01:11.304234
# Unit test for function unquote
def test_unquote():
    l = ('"abc"', "'abc'", 'abc"', "abc'", '"abc', "abc'", '"a""bc"')

    with open("./tests/unittest_data/unquoted.txt", "r") as unquoted_data_file:
        expected_list = [line.strip() for line in unquoted_data_file]

    result_list = [unquote(x) for x in l]

    assert result_list == expected_list

# Generated at 2022-06-25 04:01:14.678798
# Unit test for function is_quoted
def test_is_quoted():
    str_1 = '"foo"'
    var_1 = is_quoted(str_1)
    assert var_1 == True
    str_2 = 'foo'
    var_2 = is_quoted(str_2)
    assert var_2 == False


# Generated at 2022-06-25 04:01:18.691337
# Unit test for function unquote
def test_unquote():
    assert unquote('"test_str"') == 'test_str'


# Generated at 2022-06-25 04:01:22.676450
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted('hello') == False
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True


# Generated at 2022-06-25 04:01:29.379514
# Unit test for function unquote
def test_unquote():
    assert unquote("'I am quoted'") == 'I am quoted'
    assert unquote("'I am also quoted'") == 'I am also quoted'
    assert unquote("'I am \"double quoted\"'") == 'I am \"double quoted\"'
    assert unquote("\"I am single quoted\"") == 'I am single quoted'
    assert unquote("I am not quoted") == 'I am not quoted'
    assert unquote("And \"I\" am 'double quoted'") == "And \"I\" am 'double quoted'"
    assert unquote("And \"I am 'double quoted'\"") == 'And "I am \'double quoted\'"'

# Test if True

# Generated at 2022-06-25 04:01:37.672961
# Unit test for function unquote
def test_unquote():
    assert unquote('"/foo/bar"') == '/foo/bar'
    assert unquote("'foo/bar'") == 'foo/bar'
    assert unquote('"/foo/bar') == '/foo/bar'
    assert unquote("'/foo/bar'") == '/foo/bar'
    assert unquote('/foo/bar"') == '/foo/bar"'
    assert unquote('foo/bar"') == 'foo/bar"'

# Generated at 2022-06-25 04:01:46.366312
# Unit test for function unquote
def test_unquote():
    # print(unquote("'foo'"))
    # print(unquote("\"foo\""))
    # print(unquote("\\\"foo\"")) # should return "\"foo\""
    # print(unquote("\"foo\\\"")) # should return "\"foo\\\""
    # print(unquote("foo"))
    # print(unquote(""))
    # print(unquote("\""))
    # print(unquote("'foo"))
    # $ python -c 'print("\\\"")'
    # "
    print(unquote("\\\""))



# Generated at 2022-06-25 04:01:54.633835
# Unit test for function unquote
def test_unquote():
    assert unquote('"this is quoted"') == 'this is quoted'
    assert unquote("'this is quoted'") == 'this is quoted'

    assert unquote('test') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('""test""') == '""test""'

    assert unquote('""test"" "foo"') == '""test"" "foo"'
    assert unquote('"test"" "foo"') == 'test" "foo"'

# Generated at 2022-06-25 04:02:06.187427
# Unit test for function unquote
def test_unquote():
    assert unquote("test1") == "test1"
    assert unquote("test2") == "test2"
    assert unquote("test3") == "test3"
    assert unquote("test4") == "test4"
    assert unquote("test5") == "test5"
    assert unquote("test6") == "test6"
    assert unquote("test7") == "test7"
    assert unquote("test8") == "test8"
    assert unquote("test9") == "test9"
    assert unquote("test10") == "test10"
    assert unquote("test11") == "test11"
    assert unquote("test12") == "test12"
    assert unquote("test13") == "test13"
    assert unquote("test14") == "test14"