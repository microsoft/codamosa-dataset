

# Generated at 2022-06-25 04:01:11.015058
# Unit test for function unquote
def test_unquote():
    complex_0 = None
    var_0 = unquote(complex_0)
    assert var_0 == None
    complex_1 = "test"
    var_1 = unquote(complex_1)
    assert var_1 == "test"
    complex_2 = "test\\"
    var_2 = unquote(complex_2)
    assert var_2 == "test\\"
    complex_3 = "test\\\\"
    var_3 = unquote(complex_3)
    assert var_3 == "test\\\\"
    complex_4 = "test\\\\\\\\"
    var_4 = unquote(complex_4)
    assert var_4 == "test\\\\\\\\"
    complex_5 = "test\\\\\\\\\\"
    var_5 = unquote(complex_5)
    assert var_5 == "test\\\\\\\\\\"
   

# Generated at 2022-06-25 04:01:14.834526
# Unit test for function unquote
def test_unquote():
    # Arguments:
    complex_0 = None
    var_0 = unquote(complex_0)

    complex_1 = 'None'
    var_1 = unquote(complex_1)

    complex_2 = '"test_string"'
    var_2 = unquote(complex_2)



# Generated at 2022-06-25 04:01:23.632010
# Unit test for function unquote
def test_unquote():
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict(complex_0=False)
    m = AnsibleModule(argument_spec=module_args)
    if not test_case_0():
        failed()

    m.exit_json(changed=False)


from ansible.module_utils.basic import *
from ansible.module_utils.pycompat24 import get_exception

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *
from ansible.module_utils.six.moves.urllib.parse import urlencode

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 04:01:32.355446
# Unit test for function unquote
def test_unquote():
    # Print purpose of test
    print('\nTesting unquote method...', end='')

    # Test unquote
    # unquote_0
    var_0 = unquote(None)
    # unquote_1
    var_1 = unquote('')
    # unquote_2
    var_2 = unquote('None')
    # unquote_3
    var_3 = unquote('"None"')
    # unquote_4
    var_4 = unquote('"None\'"')

    # Print outcome of test
    if var_0 is None and var_1 == '' and var_2 == 'None' and var_3 == 'None' and var_4 == 'None\'':
        print('\tOK')
    else:
        print('\tNOK')



# Generated at 2022-06-25 04:01:33.630358
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('\'test\'') == 'test'
    assert unquote('test') == 'test'

    assert var_0 == None

# Generated at 2022-06-25 04:01:41.187437
# Unit test for function unquote
def test_unquote():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_native

    out = StringIO()

    def test_data(result, data):
        assert result == data

    # Test 'None' as data
    test_data(unquote(None), None)
    # Test quoted data
    test_data(unquote('"foo"'), 'foo')
    test_data(unquote("'foo'"), 'foo')
    # Test data with escaped quotes
    test_data(unquote(r'"foo\"bar"'), r'foo"bar')
    test_data(unquote(r"'foo\'bar'"), r"foo'bar")
    # Test data with a different quote char at the beginning and end
    test_data(unquote('"foo\''), '"foo\'')

# Generated at 2022-06-25 04:01:45.289435
# Unit test for function unquote
def test_unquote():
    # Testing for when complex is None
    test_case_0()
    # Testing for when complex is string
    complex_1 = 'bar'
    var_1 = unquote(complex_1)
    assert var_1 == 'bar'

# Generated at 2022-06-25 04:01:49.925871
# Unit test for function unquote
def test_unquote():
    # Unquote
    var_0 = '"james cammarata"'
    res_0 = unquote(var_0)
    assert res_0 == 'james cammarata'
    # Unquote
    var_2 = '"\\"testing\\""'
    res_2 = unquote(var_2)
    assert res_2 == '"testing"'


# Generated at 2022-06-25 04:01:58.288233
# Unit test for function unquote
def test_unquote():
    assert unquote(None) == None
    assert unquote('"\'"') == '\''
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\'foo') == 'foo'
    assert unquote('foo\'') == 'foo\''
    assert unquote('foo') == 'foo'
    assert unquote('foo = "hi"') == 'foo = "hi"'
    assert unquote('') == ''
    assert unquote('"""') == ''
    assert unquote('\'\'\'') == ''



# Generated at 2022-06-25 04:01:59.329156
# Unit test for function unquote
def test_unquote():
    args = dict(data="a\nb")
    unquote(**args)