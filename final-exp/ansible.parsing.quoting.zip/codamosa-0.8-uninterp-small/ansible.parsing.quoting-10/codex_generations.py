

# Generated at 2022-06-25 04:01:12.120251
# Unit test for function unquote
def test_unquote():
    set_p = set()
    var_p = unquote(set_p)

    assert(var_p == set_p)


# Generated at 2022-06-25 04:01:13.770967
# Unit test for function unquote
def test_unquote():
    set_0 = set()
    var_0 = unquote(set_0)
    assert var_0 == set_0


# Generated at 2022-06-25 04:01:14.834023
# Unit test for function unquote
def test_unquote():
    var_0 = unquote('')
    assert var_0 == ''



# Generated at 2022-06-25 04:01:22.436678
# Unit test for function unquote
def test_unquote():
    set_0 = set()
    var_1 = unquote(set_0)
    assert var_1 == set_0

    set_1 = {'1', '2', '3'}
    var_2 = unquote(set_1)
    assert var_2 == set_1

    set_2 = {'4', '5', '6'}
    var_3 = unquote(set_2)
    assert var_3 == set_2

# Generated at 2022-06-25 04:01:30.137083
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("'foo'bar") == "'foo'bar"
    assert unquote("'foo'\"bar\"") == "'foo'\"bar\""
    assert unquote("'foo\\'bar") == "'foo\\'bar"
    assert unquote("'foo'\"bar\"") == "'foo'\"bar\""
    assert unquote("'foo'\"bar\\\"") == "'foo'\"bar\\\""
    assert unquote("'foo'\"bar\\\"baz\"") == "'foo'\"bar\\\"baz\""

# Generated at 2022-06-25 04:01:33.472693
# Unit test for function is_quoted
def test_is_quoted():
    # Check default value
    assert is_quoted("bob")

# Generated at 2022-06-25 04:01:39.564789
# Unit test for function unquote
def test_unquote():
    assert (unquote("""hello""")) == "hello"

# Generated at 2022-06-25 04:01:44.859558
# Unit test for function unquote
def test_unquote():
    assert unquote(b"\"abc\"") == "abc"
    assert unquote(b"'abc'") == "abc"

    # raw string
    assert unquote(br"\"abc\"") == "\"abc\""
    assert unquote(br"'abc'") == "'abc'"

    # not a string
    assert unquote(None) == None

# Generated at 2022-06-25 04:01:52.816856
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'s'") == True
    assert is_quoted("'s") == False
    assert is_quoted("s\'") == False
    assert is_quoted("\"s\"") == True
    assert is_quoted("\"s") == False
    assert is_quoted("s\"") == False
    assert is_quoted("'s'") == True
    assert is_quoted("\"s\"") == True
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("\\\'") == False
    assert is_quoted("\\\"") == False



# Generated at 2022-06-25 04:01:57.772355
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'foo'") == True)
    assert(is_quoted('"foo"') == True)
    assert(is_quoted('"foo"g') == False)
    assert(is_quoted('foo') == False)
    assert(is_quoted('') == False)
    assert(is_quoted('"foo\"') == False)
    assert(is_quoted("'foo\'") == False)
    assert(is_quoted("''") == False)
