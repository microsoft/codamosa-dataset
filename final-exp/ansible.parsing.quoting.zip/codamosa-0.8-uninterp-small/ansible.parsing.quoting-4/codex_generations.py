

# Generated at 2022-06-25 04:01:11.936938
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("'test'") == "test"
    assert unquote("'test") == "'test"

# Generated at 2022-06-25 04:01:14.783369
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted('hello'))
    assert(is_quoted('"hello"'))
    assert(is_quoted("'hello'"))
    assert(not is_quoted('"hello'))
    assert(not is_quoted("'hello"))


# Generated at 2022-06-25 04:01:19.865601
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') is True
    assert is_quoted("'test'") is True
    assert is_quoted('"test\\"') is False
    assert is_quoted("'test\\'") is False


# Generated at 2022-06-25 04:01:23.575729
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == 'hello'
    # Test case example
    assert unquote("'hello'") == "hello"


# Generated at 2022-06-25 04:01:28.283083
# Unit test for function unquote
def test_unquote():
    int_1 = 639
    var_1 = unquote(int_1)
    assert var_1 == 639

# Generated at 2022-06-25 04:01:31.686128
# Unit test for function unquote
def test_unquote():
    int_0 = "test"
    var_0 = unquote(int_0)
    assert var_0 == "test"

    int_1 = "test"
    var_1 = unquote(int_1)
    assert var_1 == "test"

    int_2 = "test"
    var_2 = unquote(int_2)
    assert var_2 == "test"


# Generated at 2022-06-25 04:01:35.086922
# Unit test for function unquote
def test_unquote():
    assert unquote("hello") == "hello", "unquote does not work"

# Unit tests for function test_unquote()

# Generated at 2022-06-25 04:01:41.525092
# Unit test for function unquote
def test_unquote():
    from jinja2 import Environment

    # Attempt to reconstruct original data
    env = Environment()
    tmpl = env.from_string("""{{ lookup('template', 'test_templates/test_unquote.j2') }}""")
    rendered = tmpl.render()

# Generated at 2022-06-25 04:01:44.578147
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'

# Generated at 2022-06-25 04:01:45.412951
# Unit test for function unquote
def test_unquote():
    assert unquote("'Hello World!'") == "Hello World!", "'Hello World!' formating failed"