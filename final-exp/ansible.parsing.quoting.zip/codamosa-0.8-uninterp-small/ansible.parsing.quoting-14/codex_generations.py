

# Generated at 2022-06-25 04:01:16.294589
# Unit test for function unquote
def test_unquote():
    str_2 = "whatever"
    var_2 = unquote(str_2)
    assert var_2 == "whatever"

    str_3 = "'whatever'"
    var_3 = unquote(str_3)
    assert var_3 == "whatever"

    str_4 = "\"whatever\""
    var_4 = unquote(str_4)
    assert var_4 == "whatever"

    str_5 = "'whate\"ver'"
    var_5 = unquote(str_5)
    assert var_5 == "whate\"ver"

    str_6 = "\"whate'ver\""
    var_6 = unquote(str_6)
    assert var_6 == "whate'ver"

    str_7 = "\"whate'ver\""

# Generated at 2022-06-25 04:01:24.707426
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted( '"Test"' ) is True, "No Quotes"
    assert is_quoted( "'Test'" ) is True, "No Quotes"
    assert is_quoted( 'Test' ) is False, "No Quotes"
    assert is_quoted( '\'"Test\'"' ) is False, "No Quotes"
    assert is_quoted( None ) is False, "No Quotes"


# Generated at 2022-06-25 04:01:28.184946
# Unit test for function unquote
def test_unquote():
    test_case_0()

# Generated at 2022-06-25 04:01:33.506873
# Unit test for function unquote
def test_unquote():
    str_0 = "'plain old string'"
    var_0 = unquote(str_0)
    str_1 = '"plain old string"'
    var_1 = unquote(str_1)
    str_2 = 'plain old string'
    var_2 = unquote(str_2)
    str_3 = "'plain old string'"
    var_3 = unquote(str_3)
    str_4 = '"plain old string"'
    var_4 = unquote(str_4)
    str_5 = "'plain old string'"
    var_5 = unquote(str_5)
    str_6 = '"plain old string"'
    var_6 = unquote(str_6)
    str_7 = "'plain old string'"
    var_7 = unquote(str_7)
    str_8

# Generated at 2022-06-25 04:01:41.119980
# Unit test for function unquote
def test_unquote():
    str_0 = None
    assert unquote(str_0) == None
    str_1 = "str_1"
    assert unquote(str_1) == "str_1"
    str_2 = "\\\"str_1"
    assert unquote(str_2) == "\\\"str_1"
    str_3 = "\"str_1\""
    assert unquote(str_3) == "str_1"
    str_4 = "\"str_1"
    assert unquote(str_4) == "\"str_1"
    str_5 = "\\\"str_1\""
    assert unquote(str_5) == "\\\"str_1\""
    str_6 = "\"str_1\\\""

# Generated at 2022-06-25 04:01:49.994644
# Unit test for function unquote
def test_unquote():
    assert 'string' == unquote('"string"')
    assert 'str"ing' == unquote('"str\\"ing"')
    assert 'string' == unquote("'string'")
    assert 'str\'ing' == unquote("'str\\'ing'")
    assert 'str"ing' == unquote("str\"ing")
    assert 'str"ing' == unquote("str\\\"ing")
    assert 'string' == unquote("string")
    assert 'string' == unquote("'string")
    assert 'string' == unquote('"string')
    assert '' == unquote("''")
    assert '' == unquote('""')



# Generated at 2022-06-25 04:01:59.134516
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('""""') == '"'
    assert unquote('"\\""') == '\\"'
    assert unquote('"\\""\\""') == '\\"\\"'
    assert unquote('"""') == '"'
    assert unquote('"') == '"'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""""') == '"'
    assert unquote('"\\""') == '\\"'
    assert unquote('"\\""\\""') == '\\"\\"'
    assert unquote('"""') == '"'
    assert unquote('"') == '"'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""""') == '"'

# Generated at 2022-06-25 04:02:09.354751
# Unit test for function unquote

# Generated at 2022-06-25 04:02:18.897787
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcde"') == 'abcde'
    assert unquote("'abcde'") == 'abcde'
    assert unquote('"ab cde"') == 'ab cde'
    assert unquote("'ab cde'") == 'ab cde'
    assert unquote('"a b c d e"') == 'a b c d e'
    assert unquote("'a b c d e'") == 'a b c d e'
    assert unquote("'a b c d e'") == 'a b c d e'
    assert unquote("'abcde") == "'abcde"
    assert unquote("abcde'") == "abcde'"
    assert unquote("'ab'cd'e'") == "'ab'cd'e'"

# Generated at 2022-06-25 04:02:28.462678
# Unit test for function is_quoted
def test_is_quoted():
    # We define a few input values to test
    # with.
    str_0 = None
    str_1 = 'Simple string'
    str_2 = '"Double quoted string"'
    str_3 = "'Single quoted string'"

    result = is_quoted(str_0)
    # We should get a False as a result.
    assert result is False

    result = is_quoted(str_1)
    # We should get a False as a result.
    assert result is False

    result = is_quoted(str_2)
    # We should get a True as a result.
    assert result is True

    result = is_quoted(str_3)
    # We should get a True as a result.
    assert result is True

