

# Generated at 2022-06-23 05:00:49.628042
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('\'test2\'') == True
    assert is_quoted('"test3') == False
    assert is_quoted('test4"') == False
    assert is_quoted('"test5\\"') == False
    assert is_quoted('"test6"') == True


# Generated at 2022-06-23 05:00:54.310502
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello\\''") == False
    assert is_quoted('"hello!\\""') == False
    assert is_quoted("1234") == False
    assert is_quoted("") == False


# Generated at 2022-06-23 05:00:59.460063
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo\'"') == '"foo\'"'
    assert unquote("'foo\\'") == "'foo\\'"

# Generated at 2022-06-23 05:01:07.690069
# Unit test for function is_quoted
def test_is_quoted():
    for v in ('""', "''"):
        assert is_quoted(v)

    for v in ('"a"', "'b'"):
        assert is_quoted(v)

    for v in ("'a'", '"b"'):
        assert is_quoted(v)

    for v in ('""', '""', '"a"b"', "''", "a''", '"a\\""b"'):
        assert not is_quoted(v)



# Generated at 2022-06-23 05:01:19.669523
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"""foo"""') == '"foo"'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\'\'\'foo\'') == '\'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\'"foo\'"') == '"foo"'
    assert unquote('\"foo\"') == 'foo'
    assert unquote('\\"foo\\"') == '\\"foo\\"'
    assert unquote('"foo\\"') == 'foo\\"'

# Generated at 2022-06-23 05:01:26.632126
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert not is_quoted("foo")
    assert is_quoted("\"bar\"")
    assert is_quoted("''")
    assert not is_quoted("'''")
    assert not is_quoted("''''")
    assert not is_quoted("'")
    assert is_quoted("\"\"")
    assert not is_quoted("\"\"\"")
    assert not is_quoted("\"\"\"\"")
    assert not is_quoted("\"")
    assert not is_quoted("\\\"")
    assert not is_quoted("\"\\'")

# unit test for function unquote

# Generated at 2022-06-23 05:01:31.704573
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"blah"')
    assert is_quoted("'blah'")
    assert is_quoted('"blah\\"blah"')
    assert not is_quoted('"blah\\"')
    assert not is_quoted('blah"')
    assert not is_quoted('"blah')


# Generated at 2022-06-23 05:01:35.695793
# Unit test for function unquote
def test_unquote():
    cases = [
        ('"test"', 'test'),
        ('\'test\'', 'test'),
        ('"test', '"test'),
        ('\'test', '\'test'),
    ]
    for case in cases:
        assert unquote(case[0]) == case[1]


# Generated at 2022-06-23 05:01:43.974920
# Unit test for function unquote
def test_unquote():
    assert unquote('"example string"') == 'example string'
    assert unquote('"example \'string\'"') == 'example \'string\''
    assert unquote("'example string'") == 'example string'
    assert unquote("'example \"string\"'") == 'example \"string\"'
    assert unquote("'example \'string\' with quotes'") == 'example \'string\' with quotes'
    assert unquote('example string') == 'example string'
    assert unquote("example string") == "example string"
    assert unquote("'example string") == "'example string"
    assert unquote("example string'") == "example string'"
    assert unquote("example \"string\"") == "example \"string\""
    assert unquote("example \'string\'") == "example \'string\'"

# Generated at 2022-06-23 05:01:49.236631
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("abc")
    assert is_quoted("'abc'")
    assert is_quoted('"abc"')
    assert not is_quoted('"ab\\"c"')
    assert not is_quoted("'ab\\'c'")



# Generated at 2022-06-23 05:01:55.349433
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo"baz')
    assert not is_quoted('foo\'bar')
    assert not is_quoted('foo\\"bar')
    assert is_quoted('"foo"bar"')
    assert is_quoted('"foo bar"')
    assert is_quoted('"foo bar" baz')
    assert is_quoted('\'foo bar\' baz')


# Generated at 2022-06-23 05:02:04.094226
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')
    assert not is_quoted(u'hello')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('"hello\'')


# Generated at 2022-06-23 05:02:07.647805
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"fo\'o"') == "fo\'o"

# Generated at 2022-06-23 05:02:12.967885
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"test\"') == False
    assert is_quoted('t"est') == False
    assert is_quoted('test"') == False


# Generated at 2022-06-23 05:02:20.726338
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("'hello\"")
    assert not is_quoted("'hello\\'")
    assert not is_quoted("hello")
    assert is_quoted("\\'hello\\'")


# Generated at 2022-06-23 05:02:25.303873
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("foo")


# Generated at 2022-06-23 05:02:29.798872
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo\\""') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo"\\""') == False


# Generated at 2022-06-23 05:02:30.987985
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert i

# Generated at 2022-06-23 05:02:37.460508
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'") == True
    assert is_quoted("'test") == False
    assert is_quoted("test'") == False
    assert is_quoted("\"test\"") == True
    assert is_quoted("\"test") == False
    assert is_quoted("test\"") == False
    assert is_quoted("\"test\\\"") == False
    assert is_quoted("test'") == False
    assert is_quoted("'test\\\'") == False


# Generated at 2022-06-23 05:02:45.124982
# Unit test for function unquote
def test_unquote():
    import pytest
    args = ['test', '"test"', "'test'",
            'test\\"', '"test\\"', "'test\\'",
            "test\\\\", "test\\'", "test\\\"",
            '"test\\"', "'test\\'", '"test\\\\"', "'test\\\\'"
            ]
    expectation = ['test', 'test', 'test',
                   'test"', 'test"', "test'",
                   'test\\\\', "test\\'", "test\\\"",
                   'test\\"', "test\\'", 'test\\\\', 'test\\\\'
                   ]

    def test_func(args, expectation):
        assert unquote(args) == expectation

    for test in zip(args, expectation):
        yield test_func, test[0], test[1]



# Generated at 2022-06-23 05:02:49.770549
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('\'quoted\'')
    assert is_quoted('"quoted"')
    assert not is_quoted('"quote"d')
    assert not is_quoted('no-quote')
    assert not is_quoted('"quote\\"')


# Generated at 2022-06-23 05:02:56.668596
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo\\'") == False
    assert is_quoted("\"foo\"") == True
    assert is_quoted("\"foo") == False
    assert is_quoted("foo\"") == False
    assert is_quoted("\"foo\\\"") == False
    assert is_quoted("'foo\"") == False
    assert is_quoted("\"foo'") == False


# Generated at 2022-06-23 05:03:06.037307
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"') == False
    assert is_quoted('"""') == False
    assert is_quoted("'''") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo\\'foo'") == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo\\"foo"') == False
    assert is_quoted("'foo bar'") == False
    assert is_quoted("'foo bar'") == False
    assert is_quoted("'foo\"bar'") == False
    assert is_quoted("\"foo'bar\"") == False
    assert is_quoted("'foo bar'") == False
    assert is_quoted('"foo bar"') == False

# Generated at 2022-06-23 05:03:16.990525
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo')  == '"foo'
    assert unquote("'foo")  == "'foo"
    assert unquote('foo"')  == 'foo"'
    assert unquote('foo\'"')  == 'foo\'"'
    assert unquote('"foo\'')  == '"foo\''
    assert unquote('') == ''

# Generated at 2022-06-23 05:03:24.749292
# Unit test for function unquote
def test_unquote():
    # Simple unquote
    assert(unquote("'foo'") == 'foo')

    # No change
    assert(unquote("bar") == "bar")

    # Double quotes
    assert(unquote('"bar"') == 'bar')

    # Escapes (should be maintained)
    assert(unquote("'bar\\'s'") == "bar\\'s")
    assert(unquote('"bar\\"s"') == 'bar\\"s')
    assert(unquote("bar\\'s") == "bar\\'s")
    assert(unquote('bar\\"s') == 'bar\\"s')
    return True

# Generated at 2022-06-23 05:03:33.777811
# Unit test for function is_quoted
def test_is_quoted():
    cases = (
        ("'hello'", True),
        ('"hello"', True),
        ('"hello', False),
        ("'hello", False),
        ('''"'"''', True),
        ("'\"'", True),
        ('"\\"', False),
        ('"\\\\"', True),
        ('this_is_not_quoted', False),
        ('"hello\\"', False),
        ('"hello"_is_also_not_quoted', False),
    )
    for (data, expected) in cases:
        result = is_quoted(data)
        if result != expected:
            raise AssertionError("Expected %s, actual %s" % (expected, result))
    print("PASS: test_is_quoted")


# Generated at 2022-06-23 05:03:44.430009
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('"hel"lo"') == '"hel"lo"'
    assert unquote('"hel"lo') == '"hel"lo'
    assert unquote('"hello\\""') == '"hello\\"'
    assert unquote('"hello\\"') == '"hello\\"'


# Notes:
# We don't try to handle CRLF sequences as they are not valid YAML, and not seen in practice.

# TODO: find a way to check dicts generated from inventory plugins

# Generated at 2022-06-23 05:03:50.936676
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo\\""') == 'foo"'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\\''") == "foo'"

# Generated at 2022-06-23 05:03:57.757761
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted("\"hello\"") == True
    assert is_quoted("\"hello\'") == False
    assert is_quoted("\"hello\\'") == False
    assert is_quoted("'hello\\\"") == False
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted('"hello') == False
    assert is_quoted("'hello' 'world'") == False


# Generated at 2022-06-23 05:04:08.114458
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted("'test'")
    assert is_quoted('"test"')
    assert is_quoted("'test\\'s test'")
    assert is_quoted('"test\\"s test"')
    assert is_quoted("''")
    assert is_quoted('""')

    assert not is_quoted('')
    assert not is_quoted('test')
    assert not is_quoted("'test")
    assert not is_quoted('"test')
    assert not is_quoted("test'")
    assert not is_quoted('test"')
    assert not is_quoted('"test"test"')
    assert not is_quoted("'test'test'")

    assert not is_quoted("'test\\'")

# Generated at 2022-06-23 05:04:12.828759
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted("hello'")
    assert not is_quoted('"hello\'"')
    assert not is_quoted("'hello\'")
    assert not is_quoted('"hello\\""')

    assert is_quoted('"hello\""')
    assert not is_quoted('"hello\\"')


# Generated at 2022-06-23 05:04:16.560471
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('no quote')
    assert is_quoted('"quoted string"')
    assert is_quoted("'quoted string'")
    assert not is_quoted("'quote with a \\'")
    assert not is_quoted('"quote with a \\"')

# Generated at 2022-06-23 05:04:26.741268
# Unit test for function unquote
def test_unquote():
    # Test simple strings
    assert unquote('test') == 'test'
    assert unquote('test\'') == 'test\''
    assert unquote('\'test') == '\'test'
    assert unquote('\"test') == '\"test'
    assert unquote('tes\\\'t') == 'tes\\\'t'

    # Test all possible \" and \' combinations
    assert unquote('\"test\"') == 'test'
    assert unquote('\"test\\\"\"') == 'test\\\"'
    assert unquote('\"test\\\\\"') == 'test\\\\'
    assert unquote('\"test\\\\\\\"\"') == 'test\\\\\\\"'
    assert unquote('\"test\\\\\\\\\"') == 'test\\\\\\\\'
    assert unquote('\"test\\\\\\\\\\\"\"') == 'test\\\\\\\\\\\"'

# Generated at 2022-06-23 05:04:33.134869
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False
    assert is_quoted('') == False
    assert is_quoted('""') == False
    assert is_quoted('"\\"') == False
    assert is_quoted('"hello"hi') == False
    assert is_quoted('"hi"hello"') == False


# Generated at 2022-06-23 05:04:40.272421
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('foo"')
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote('foo"') == 'foo"'

# Generated at 2022-06-23 05:04:44.040563
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == 'foo\\\'bar'



# Generated at 2022-06-23 05:04:49.674861
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("'test\"")
    assert not is_quoted("test\"'")


# Generated at 2022-06-23 05:05:00.408861
# Unit test for function is_quoted
def test_is_quoted():
    unquoted = "unquoted"
    # test both single and double quoted strings
    assert(is_quoted(unquoted) == False)
    assert(is_quoted('"{0}"'.format(unquoted)) == True)
    assert (is_quoted("'{0}'".format(unquoted)) == True)
    assert (is_quoted('"{0}"'.format("'")) == False)
    assert (is_quoted("'{0}'".format('"')) == False)
    assert (is_quoted("'{0}'".format("'foo")) == False)
    assert (is_quoted("'{0}'".format("foo'")) == False)
    assert (is_quoted("'{0}'".format("'foo")) == False)

# Generated at 2022-06-23 05:05:07.628105
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test\"") == "test"
    assert unquote("'test'") == "test"
    assert unquote("test") == "test"
    assert unquote("\"test\"test") == "test\"test"
    assert unquote("test\"test") == "test\"test"
    assert unquote("test'string'") == "test'string'"
    assert unquote("\"test'string\"") == "test'string"
    assert unquote("\"test\\\"string\"") == "test\"string"


# Generated at 2022-06-23 05:05:16.753543
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo\""') == True
    assert is_quoted('"foo\\""') == False
    assert is_quoted('"foo"bar"') == False
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo'bar'") == False
    assert is_quoted("'foo\\''") == False



# Generated at 2022-06-23 05:05:23.631169
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert is_quoted('"hello\'"')
    assert is_quoted('"hello\\""')
    assert not is_quoted('"hello"world')
    assert not is_quoted('hello"')
    assert not is_quoted('"hell"o"')
    assert not is_quoted('"""hello"""')
    assert not is_quoted('\'"hello"')
    assert not is_quoted('"hello\'"')
    assert not is_quoted('hello')
    assert not is_quoted('')



# Generated at 2022-06-23 05:05:29.770009
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('hello')
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('\\"')
    assert is_quoted('"\\""')
    assert is_quoted("'\\''")
    assert not is_quoted("'\\'")


# Generated at 2022-06-23 05:05:41.409015
# Unit test for function is_quoted
def test_is_quoted():
    # normal quotes
    assert is_quoted('"this is a quoted string"')
    assert is_quoted("'this is also quoted'")
    # with escaped quotes
    assert is_quoted(r'"this \"is\" quoted"')
    assert is_quoted(r'"this \'is\' quoted"')
    # it considers only the first and last character
    assert is_quoted(r'''"this \'is\' "quoted"''')
    assert is_quoted(r'''"this "is" \'quoted\'"''')
    # not quoted
    assert not is_quoted('"this is not quoted') # missing ending quote
    assert not is_quoted('this is not quoted"') # missing starting quote
    assert not is_quoted('''"this is "not" quoted"''') # not matching starting and ending quote

# Generated at 2022-06-23 05:05:51.507407
# Unit test for function is_quoted
def test_is_quoted():
    print("is_quoted() ...")
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted("'\\'hello\\''") == True
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False
    assert is_quoted("'hello\\''") == False
    assert is_quoted('"\\"hi\\""') == True
    assert is_quoted('"\\"hi\\""') == True
    assert is_quoted('"\\"hi\\\\\\"') == False
    assert is_quoted('"\\\\"') == True
    assert is_quoted('"\\\\\\""') == False
    print("is_quoted() OK")


# Generated at 2022-06-23 05:05:58.650417
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"

# add 'HOST_INTERNAL_VARIABLE' for other groups
_host_internal_vars = ['ansible_version', 'group_names', 'inventory_hostname',
                       'inventory_hostname_short', 'inventory_file', 'inventory_dir',
                       'config_file', 'playbook_dir', 'omit']

__all__ = ['HostVars', 'combine_vars', 'is_quoted', 'unquote']



# Generated at 2022-06-23 05:06:04.894014
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert is_quoted('"hell\\"o"')
    assert not is_quoted('"hell\\o"')
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")


# Generated at 2022-06-23 05:06:08.957652
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote('"\""') == '"'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'



# Generated at 2022-06-23 05:06:10.974816
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'


# Generated at 2022-06-23 05:06:14.740369
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"This is a quote"')
    assert is_quoted("'Another one'")
    assert is_quoted("'no escape\\''")
    assert not is_quoted("no escape'")
    assert not is_quoted("'no escape")
    assert not is_quoted("no escape")


# Generated at 2022-06-23 05:06:19.168018
# Unit test for function unquote
def test_unquote():
    assert unquote("'whatever'") == "whatever"
    assert unquote("whatever") == "whatever"
    assert unquote("'whatever") == "'whatever"

# Test for issue #18891

# Generated at 2022-06-23 05:06:22.685267
# Unit test for function unquote
def test_unquote():
    assert unquote(u'"foo"') == u'foo'
    assert unquote(u'"foo\\"bar"') == u'foo\\"bar'
    assert unquote(u'foo') == u'foo'
    assert unquote(u'\\"foo\\"') == u'\\"foo\\"'



# Generated at 2022-06-23 05:06:26.994706
# Unit test for function unquote
def test_unquote():
    assert unquote('""') is ''
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo"bar') == 'foo"bar'
    assert unquote('foobar') == 'foobar'


# Generated at 2022-06-23 05:06:31.924689
# Unit test for function unquote
def test_unquote():
    assert unquote('"x"') == 'x'
    assert unquote('"\\"x"') == '\\"x'
    assert unquote('x') == 'x'
    assert unquote('"xy"') == 'xy'

# Generated at 2022-06-23 05:06:35.736778
# Unit test for function unquote
def test_unquote():
    assert unquote('test') == 'test'
    assert unquote('test"') == 'test"'
    assert unquote('"test') == '"test'
    assert unquote('"test"') == 'test'
    assert unquote('""test""') == '"test"'
    assert unquote('"test""') == 'test"'


# Generated at 2022-06-23 05:06:46.905291
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') != 'hello'
    assert unquote('hello"') != 'hello'
    assert unquote('"""hello"""') == '"hello"'
    assert unquote('"""hello') != '"hello'
    assert unquote('hello"""') != 'hello"'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello\\""') != 'hello"'
    assert unquote('"hello\\\\""') == 'hello\\'
    assert unquote('"hello\\\\\\""') != 'hello\\"'
    assert unquote('"hello\\\\\\\\""') == 'hello\\\\'

# Generated at 2022-06-23 05:06:50.129283
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("'foo'") == "foo"
    assert unquote("'foo") == "'foo"



# Generated at 2022-06-23 05:06:53.377783
# Unit test for function unquote
def test_unquote():
    assert unquote('"string"') == 'string'
    assert unquote("'string'") == 'string'
    assert unquote("'foo'bar'") == "'foobar'"


# Generated at 2022-06-23 05:06:59.910597
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"test string"')
    assert is_quoted('"super string"')
    assert not is_quoted("'test string'")
    assert not is_quoted("test string")
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote("\"test\"") == "test"

# Generated at 2022-06-23 05:07:02.575699
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is quoted"')
    assert not is_quoted("'this isn't quoted'")
    assert is_quoted("'this is quoted, but with escaped quote (\\')'")


# Generated at 2022-06-23 05:07:05.536888
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo') == False
    assert is_quoted('"fo\\"o"') == False


# Generated at 2022-06-23 05:07:08.545091
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")



# Generated at 2022-06-23 05:07:13.809677
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"zoo"')
    assert is_quoted("'zoo'")

    assert not is_quoted("'zoo")
    assert not is_quoted("zoo")
    assert not is_quoted("zoo'")
    assert not is_quoted("'zoo\"")
    assert not is_quoted("\"zoo'")


# Generated at 2022-06-23 05:07:20.986981
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'Hello world'")
    assert is_quoted('"Hello world"')
    assert is_quoted('"Hello world\\"') == False
    assert is_quoted('\\"Hello world') == False
    assert is_quoted('"Hello world') == False
    assert is_quoted('Hello world"') == False
    assert is_quoted('"Hello world" ')
    assert is_quoted("'Hello world' ")


# Generated at 2022-06-23 05:07:25.194664
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"hello" world') == '"hello" world'



# Generated at 2022-06-23 05:07:28.293308
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote('a') == 'a'



# Generated at 2022-06-23 05:07:34.605447
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"helloworld"') == True
    assert is_quoted("'helloworld'") == True
    assert is_quoted('"hello''world"') == False
    assert is_quoted('"helloworld') == False
    assert is_quoted('helloworld"') == False
    assert is_quoted('"hello"\'') == False
    assert is_quoted('"hello\""') == True
    assert is_quoted('''"hello"''') == False


# Generated at 2022-06-23 05:07:39.897668
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("this is quoted") == True
    assert is_quoted('this is quoted') == True
    assert is_quoted('this is not quoted') == False
    assert is_quoted('this is\\" quoted') == False
    assert is_quoted('\\"this is quoted\\"') == True


# Generated at 2022-06-23 05:07:50.436825
# Unit test for function unquote
def test_unquote():
    assert (unquote('"abc"') == 'abc')
    assert (unquote("'abc'") == 'abc')
    assert (unquote("'ab\\'c'") == "ab\\'c")
    assert (unquote("'ab\\\"c'") == 'ab\\"c')
    assert (unquote("\\'\\'") == "\\'\\'")
    assert (unquote('"ab\\\'c"') == "ab\\\'c")
    assert (unquote('"""abc""def"""') == '"abc""def"')
    assert (unquote('"abc') == '"abc')
    assert (unquote('abc') == 'abc')
    assert (unquote('""') == '')
    assert (unquote('"') == '"')
    assert (unquote('') == '')



# Generated at 2022-06-23 05:07:57.122862
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert is_quoted('"foo\\""')
    assert is_quoted("'foo\\''")
    assert is_quoted('"foo\\\\\\""')
    assert is_quoted("'foo\\\\\\''")



# Generated at 2022-06-23 05:08:02.057579
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"""test"""')
    assert not is_quoted('"""test"')
    assert not is_quoted('"""test')
    assert is_quoted('\'\'\'test\'\'\'')
    assert not is_quoted('\'\'\'test\'')
    assert not is_quoted('\'\'\'test')


# Generated at 2022-06-23 05:08:13.611900
# Unit test for function unquote
def test_unquote():
    if unquote("'foo bar'") != 'foo bar':
        raise Exception("unquote is broken.")
    if unquote('"foo bar"') != 'foo bar':
        raise Exception("unquote is broken.")
    if unquote("'foobar'") != "foobar":
        raise Exception("unquote is broken.")
    if unquote('"foobar"') != "foobar":
        raise Exception("unquote is broken.")
    if unquote("'foo'bar'") != "foo'bar":
        raise Exception("unquote is broken.")
    if unquote('"foo"bar"') != "foo\"bar":
        raise Exception("unquote is broken.")
    if unquote("foobar") != "foobar":
        raise Exception("unquote is broken.")

# Generated at 2022-06-23 05:08:17.944557
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"abc"')
    assert is_quoted('\'abc\'')
    assert is_quoted('"abc"def') == False
    assert is_quoted('\'abc\'def') == False
    assert unquote('"abc"') == 'abc'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('\'abc') == '\'abc'

# Generated at 2022-06-23 05:08:28.699682
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'

    assert unquote('"foo')  == '"foo'
    assert unquote("'foo")  == "'foo"
    assert unquote('foo"')  == 'foo"'
    assert unquote('foo\'"')== 'foo\'"' 
    assert unquote('"foo\'')== '"foo\''
    assert unquote('"foo')  == '"foo'
    assert unquote("'foo")  == "'foo"
    assert unquote('foo"')  == 'foo"'
    assert unquote('foo\'"')== 'foo\'"' 
    assert unquote('"foo\'')== '"foo\''

    assert unquote('"foo\'')== '"foo\''


# Generated at 2022-06-23 05:08:36.117277
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\\"bar"') == 'foo\\\"bar'
    assert unquote('"foo\\\\bar"') == 'foo\\\\bar'
    assert unquote('"foo' + '\\' + 'nbar"') == 'foo\nbar'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-23 05:08:42.454286
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("an_example") == 'an_example'
    assert unquote("1") == '1'
    assert unquote("True") == 'True'
    assert unquote("\"True\"") == '"True"'
    assert unquote("'True'") == "'True'"

# This is also a test of the unquote function.

# Generated at 2022-06-23 05:08:47.961682
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo"bar"') == False
    assert is_quoted('"foobar"') == True
    assert is_quoted('"f\'o\'o"') == True
    assert is_quoted('"f\\"o\\"o"') == False


# Generated at 2022-06-23 05:08:53.297308
# Unit test for function unquote
def test_unquote():
    assert 'abcd' == unquote('abcd')
    assert 'abcd' == unquote('"abcd"')
    assert 'abcd' == unquote('\'abcd\'')
    assert 'ab"cd' == unquote('"ab\\"cd"')
    assert 'ab\'cd' == unquote('\'ab\\\'cd\'')
    assert 'ab"c\'d' == unquote('\'ab"c\\\'d\'')
    assert 'ab\\c"d' == unquote('"ab\\\\c\\"d"')

# Generated at 2022-06-23 05:09:04.310712
# Unit test for function unquote
def test_unquote():
    assert (unquote("'single quoted string'")) == "single quoted string"
    assert (unquote('"double quoted string"')) == "double quoted string"
    assert (unquote('"This string has \' quoted symbols inside"')) == "This string has ' quoted symbols inside"
    assert (unquote('"This string has \' other quoted \' symbols inside"')) == 'This string has \' other quoted \' symbols inside'
    assert (unquote('"This string has \\" double quoted \\" symbol inside"')) == 'This string has " double quoted " symbol inside'
    assert (unquote('This string has no quotes')) == 'This string has no quotes'
    assert (unquote('\'This string has " double quoted " symbol inside\'')) == 'This string has " double quoted " symbol inside'

# Generated at 2022-06-23 05:09:09.458814
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == 'test'
    assert unquote('"""test"""') == '''test'''
    assert unquote('"test"') == 'test'
    assert unquote('"""test') != '"""test'
    assert unquote("'test") != "'test"
    assert unquote("test") == 'test'


# Generated at 2022-06-23 05:09:20.043483
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("'foo") == False)
    assert(is_quoted("foo'") == False)
    assert(is_quoted("'foo\"") == False)
    assert(is_quoted("'foo\\'") == False)
    assert(is_quoted("'foo\\''") == True)
    assert(is_quoted('"foo\\""') == True)
    assert(is_quoted('"foo"bar"') == False)
    assert(is_quoted('"foo""bar"') == False)


# Generated at 2022-06-23 05:09:31.075943
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"""foo"""') == '"""foo"""'
    assert unquote("'''foo'''") == "'''foo'''"
    assert unquote('''"foo"''') == '''"foo"'''
    assert unquote('''"fo'o"''') == '''"fo'o"'''
    assert unquote('''"fo\\o"''') == '''"fo\\o"'''
    assert unquote('''"fo\\"o"''') == '''"fo\\"o"'''

# Generated at 2022-06-23 05:09:39.002992
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test_string"') == True
    assert is_quoted("'test_string'") == True
    assert is_quoted('"te\\"st_string') == False
    assert is_quoted("'te\\'st_string") == False
    assert is_quoted('') == False
    assert is_quoted('"test_string') == False
    assert is_quoted("'test_string") == False
    assert is_quoted('test_string"') == False
    assert is_quoted("test_string'") == False
    assert is_quoted('"test_string" "test_string2"') == False
    assert is_quoted("'test_string' 'test_string2'") == False
    assert is_quoted('""test_string"') == False

# Generated at 2022-06-23 05:09:44.010532
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted(r'"\""')
    assert not is_quoted(r'"\"')


# Generated at 2022-06-23 05:09:48.416296
# Unit test for function unquote
def test_unquote():
    assert unquote('"Hello World"') == 'Hello World'
    assert unquote('"Hello "World"') == '"Hello "World"'
    assert unquote(u'"H\xe9llo"') == u'H\xe9llo'
    assert unquote(u"H\xe9llo") == u'"H\xe9llo"'

# Generated at 2022-06-23 05:09:55.637995
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('"\\"hello"') == '"hello'
    assert unquote("'\\'hello'") == "'hello"
    assert unquote('"hello\\""') == 'hello"'
    assert unquote("'hello\\''") == "hello'"


# Generated at 2022-06-23 05:10:04.925389
# Unit test for function is_quoted
def test_is_quoted():
    # truthy
    assert is_quoted("''")
    assert is_quoted("'test'")
    assert is_quoted('"test"')
    assert is_quoted("'test with apostrophe'")
    assert is_quoted('"test with apostrophe"')
    assert is_quoted("'test with \"double quote\"'")
    assert is_quoted("'test with \"double quote\" and apostrophe'")
    assert is_quoted("'test with 'single quote' and apostrophe'")
    assert is_quoted("\"test with 'single quote' and apostrophe\"")
    assert is_quoted("\"test with \\\"escape double quote\\\" and apostrophe\"")
    assert is_quoted("'test with \\\'escape single quote\\\' and apostrophe'")
    # falsey


# Generated at 2022-06-23 05:10:11.470924
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"bla"')
    assert is_quoted("'bla'")
    assert not is_quoted("'bla")
    assert not is_quoted("bla")
    assert not is_quoted("{'src': 'file.j2'}")
    assert is_quoted('"\\"bla\\""')
    assert is_quoted("'\\'bla\\''")


# Generated at 2022-06-23 05:10:15.130059
# Unit test for function unquote
def test_unquote():
    data = '"abcd" "abcd" "abcd"'
    assert unquote(data) == 'abcd" "abcd" "abcd'


# Generated at 2022-06-23 05:10:25.720265
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted('"te""st"')
    assert not is_quoted('"te\"st"')
    assert not is_quoted('"te\"s\"t"')
    assert not is_quoted('"te\"s\"t"')
    assert is_quoted("'test'")
    assert is_quoted("'te'st'")
    assert not is_quoted("'te's\"t'")
    assert not is_quoted("'te's\"t'")
    assert not is_quoted("'te's\"t'")
    assert not is_quoted('"')
    assert not is_quoted("'")
    assert not is_quoted('"testing')
    assert not is_quoted("'testing")

# Generated at 2022-06-23 05:10:33.896246
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\"bc"') == 'a"bc'
    assert unquote('"ab\"c"') == 'ab"c'
    assert unquote('\'a\\\'bc\'') == 'a\'bc'
    assert unquote('\'ab\\\'c\'') == 'ab\'c'


# Generated at 2022-06-23 05:10:42.317390
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('\'hello\'')
    assert not is_quoted('"hello"')
    assert is_quoted(r'"foo\""')
    assert is_quoted(r"'foo\''")



# Generated at 2022-06-23 05:10:51.221746
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("'hi'")
    assert is_quoted("'hi'")
    assert is_quoted('"hi"')
    assert not is_quoted("'hi'a")
    assert not is_quoted("'hia'")
    assert not is_quoted("'hia")
    assert not is_quoted("hia'")
    assert not is_quoted("hi'")
    assert not is_quoted("'hi")
    assert not is_quoted("'hi\"")
    assert is_quoted("'hi\\\"'")
