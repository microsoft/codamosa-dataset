

# Generated at 2022-06-23 05:00:54.086173
# Unit test for function unquote
def test_unquote():
    assert unquote('"Hello, World"') == 'Hello, World'
    assert unquote("'Hello, World'") == 'Hello, World'
    assert unquote('Hello, "World"') == 'Hello, "World"'
    assert unquote('Hello, "Worl\\"d"') == 'Hello, "Worl\\"d"'
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('"\\"') == '"\\"'
    assert unquote('Hello, World') == 'Hello, World'
    print('Assertions passed')

test_unquote()

# Generated at 2022-06-23 05:00:58.203416
# Unit test for function unquote
def test_unquote():
    print('Testing unquote()')
    assert unquote('test') == 'test'
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'

# Generated at 2022-06-23 05:01:02.893656
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'foo'") == True )
    assert(is_quoted('"foo"') == True )
    assert(is_quoted("foo") == False )


# Generated at 2022-06-23 05:01:09.432738
# Unit test for function unquote
def test_unquote():
    assert "abcd" == unquote("abcd")
    assert "abcd" == unquote("'abcd'")
    assert "abcd" == unquote('"abcd"')
    assert "abcd" == unquote("'abcd'")
    assert "abcd" == unquote('"abcd"')
    assert "abcd" == unquote("'abcd")
    assert "abcd" == unquote('"abcd')


# Generated at 2022-06-23 05:01:16.752392
# Unit test for function unquote
def test_unquote():
    assert 'test' == unquote('test')
    assert '' == unquote('')
    assert 'test' == unquote('"test"')
    assert "test's" == unquote("'test\\'s'")
    assert "test's" == unquote('"test\'s"')
    assert "test\"s" == unquote('"test\\"s"')
    assert "test\"s" == unquote("'test\"s'")
    assert 'test\\n' == unquote('"test\\\\n"')
    assert 'test\\\\n' == unquote("'test\\\\\\\\n'")



# Generated at 2022-06-23 05:01:19.187927
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'


# Generated at 2022-06-23 05:01:28.014845
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted(None)
    assert not is_quoted("")
    assert not is_quoted("foo")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo\'')
    assert not is_quoted('foo\'"')
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert is_quoted("'\"foo\"'")


# Generated at 2022-06-23 05:01:36.270160
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('""') is False
    assert is_quoted('"foo"') is True
    assert is_quoted('"foo\\""') is True
    assert is_quoted('"foo\\"') is False
    assert is_quoted('"\\"foo\\""') is True
    assert is_quoted('\'foo\'') is True
    assert is_quoted('\'foo\\\'') is True
    assert is_quoted('\'foo\\\'') is True
    assert is_quoted('\'\\\'foo\\\'\'') is True


# Generated at 2022-06-23 05:01:40.483831
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foobar') == 'foobar'
    assert unquote("'foobar'") == "foobar"
    assert unquote('"foobar"') == "foobar"



# Generated at 2022-06-23 05:01:45.553969
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo\\"')
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted('foo')
    assert not is_quoted(None)


# Generated at 2022-06-23 05:01:52.680218
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote("'hello \"worl\"d'") == 'hello \"worl\"d'
    assert unquote("''") == ''
    assert unquote("'") == "'"
    assert unquote("'hello world") == "'hello world"
    assert unquote("hello world'") == 'hello world\''
    assert unquote("\\'hello world\\'") == "'hello world'"


# Generated at 2022-06-23 05:02:02.638319
# Unit test for function unquote
def test_unquote():
    results = []
    should_be = []

    results.append(unquote(None))
    should_be.append(None)
    results.append(unquote('""'))
    should_be.append('')
    results.append(unquote("''"))
    should_be.append('')
    results.append(unquote('"foo"'))
    should_be.append('foo')
    results.append(unquote("'foo'"))
    should_be.append('foo')
    results.append(unquote('B"foo"'))
    should_be.append('B"foo"')
    results.append(unquote("B'foo'"))
    should_be.append("B'foo'")
    results.append(unquote("'foo\\'bar'"))

# Generated at 2022-06-23 05:02:07.171501
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == "hello world"
    assert unquote("'hello world'") == "hello world"
    assert unquote('\\"hello world\\"') == '\\"hello world\\"'
    assert unquote('"hello world') == '"hello world'
    assert unquote('hello world"') == 'hello world"'
    assert unquote('hello world') == 'hello world'


# Generated at 2022-06-23 05:02:16.211447
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('nope')
    assert not is_quoted('"nope')
    assert not is_quoted('nope"')
    assert is_quoted('"yes"')
    assert is_quoted("'yes'")
    assert is_quoted('"yes\\""')
    assert is_quoted(r'"yes\""')
    assert not is_quoted(r'"yes\"')
    assert not is_quoted(r'"yes\"\\')



# Generated at 2022-06-23 05:02:21.277907
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('\'foo') == '\'foo'
    assert unquote('\"foo\'') == '\"foo\''
    assert unquote('\"foo') == '"foo'



# Generated at 2022-06-23 05:02:28.690725
# Unit test for function unquote
def test_unquote():
    assert unquote("a") == "a"
    assert unquote("'a'") == "a"
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == "a"
    assert unquote("'ab'") == "ab"
    assert unquote("'a''b'") == "a'b"
    assert unquote("a'b") == "a'b"
    assert unquote("'a") == "'a"
    assert unquote("a\"b") == "a\"b"



# Generated at 2022-06-23 05:02:34.954276
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"Hello, World!"'))
    assert(not is_quoted('Hello, World!"'))
    assert(not is_quoted('"Hello, World!'))
    assert(not is_quoted('"Hello, World!""'))
    assert(not is_quoted('"Hello, \'World!"'))
    assert(not is_quoted('"Hello, \'World!\\""'))
    assert(not is_quoted('"Hello, \'World!\\""'))


# Generated at 2022-06-23 05:02:38.251139
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('foo')


# Generated at 2022-06-23 05:02:50.756205
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('abc') == False
    assert is_quoted('') == False
    assert is_quoted('"abc') == False
    assert is_quoted('abc"') == False
    assert is_quoted('"abc"') == True
    assert is_quoted('"a\\"bc"') == True
    assert is_quoted('"\\"abc"') == False
    assert is_quoted('"a\\"bc\\""') == True
    assert is_quoted('"ab\\"c"') == True
    assert is_quoted('\'abc\'') == True
    assert is_quoted('\'a\\\'bc\'') == True
    assert is_quoted('\'\\\'abc\'') == False
    assert is_quoted('\'a\\\'bc\\\'\'')

# Generated at 2022-06-23 05:02:58.285184
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted("'fo\\'o'")
    assert not is_quoted("\"fo\'o\"")
    assert not is_quoted("'fo\"o'")
    assert not is_quoted("\"fo\\\"o\"")
    assert not is_quoted("fo'o")
    assert not is_quoted("fo\"o")
    assert not is_quoted("'foo")
    assert not is_quoted("\"foo")
    assert not is_quoted("foo'")
    assert not is_quoted("foo\"")


# Generated at 2022-06-23 05:03:02.270779
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('""') == False)
    assert(is_quoted('"') == False)
    assert(is_quoted('"foo bar"') == True)
    assert(is_quoted('"foo bar"\\') == False)


# Generated at 2022-06-23 05:03:11.326478
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('""') == ""
    assert unquote("''") == ""
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("'foo bar") == "'foo bar"
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('"fo\\o"') == 'fo\\o'
    assert unquote('"fo\\\\o"') == 'fo\\\\o'
    assert unquote('invalid') == 'invalid'



# Generated at 2022-06-23 05:03:17.987278
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('\\"foobar\\"') == '\\"foobar\\"'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') is None
    assert unquote('"foo') is None
    assert unquote('foo"') is None


# Generated at 2022-06-23 05:03:24.261291
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted("'test") == False
    assert is_quoted("'test\"") == True
    assert is_quoted("'here is\\' a test'") == True
    assert is_quoted("'here is\' a test'") == False

# unit test for function unquote

# Generated at 2022-06-23 05:03:27.372486
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote("foo") == "foo"



# Generated at 2022-06-23 05:03:32.331729
# Unit test for function unquote
def test_unquote():
    assert unquote("'Here is the first line\n'") == "Here is the first line\n"
    assert unquote('"Here is the second line\n"') == "Here is the second line\n"
    assert unquote("'Here is the third line\n") == "'Here is the third line\n"
    assert unquote("Here is the fourth line\n") == "Here is the fourth line\n"


# Generated at 2022-06-23 05:03:38.604348
# Unit test for function unquote
def test_unquote():

    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('hel"lo') == 'hel"lo'
    assert unquote('"hello') == '"hello'
    assert unquote('hello\'') == 'hello\''
    assert unquote('"hell\"o') == 'hell\"o'


# Generated at 2022-06-23 05:03:47.834280
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"f"oo"') == 'f"oo'
    assert unquote('"fo\'o"') == 'fo\'o'
    assert unquote('\'fo"o\'') == 'fo"o'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"""foo"""') == '"foo"'
    assert unquote('"""foo\'"bar""') == '"foo\'"bar"'


# Generated at 2022-06-23 05:03:52.299110
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo"')
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo\\""') == False
    assert is_quoted('\'"foo"\'')
    assert is_quoted('"foo""bar"') == False


# Generated at 2022-06-23 05:04:03.690089
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('""') is True)
    assert (is_quoted("''") is True)
    assert (is_quoted('"a"') is True)
    assert (is_quoted("'a'") is True)
    assert (is_quoted('\'a\'') is True)
    assert (is_quoted('"""') is False)
    assert (is_quoted('""a') is False)
    assert (is_quoted('a""') is False)
    assert (is_quoted('"a""') is False)
    assert (is_quoted('"a" "') is False)
    assert (is_quoted('a') is False)
    assert (is_quoted('"') is False)
    assert (is_quoted('"a') is False)

# Generated at 2022-06-23 05:04:14.380610
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'ab\\'c'") == "ab'c"
    assert unquote("'ab\\'c")  == "'ab\\'c"
    assert unquote("\\'abc")   == "'abc"
    assert unquote("\\'ab'c")  == "'ab'c"
    assert unquote("\\''abc")  == "''abc"
    assert unquote("''abc")    == "abc"
    assert unquote("abc")      == "abc"
    assert unquote("'abc")     == "'abc"
    assert unquote('"abc')     == '"abc'
    assert unquote("'ab\"c'")  == "ab\"c"

# Generated at 2022-06-23 05:04:24.953620
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('\\"abc"') == '\\"abc"'
    assert unquote('\'"abc"') == '\'"abc"'
    assert unquote('"abc\\"') == '"abc\\"'
    assert unquote('"abc\'"') == '"abc\'"'
    assert unquote('"""abc"""') == '"""abc"""'
    assert unquote('"""abc') == '"""abc'
    assert unquote('abc"""') == 'abc"""'
    assert unquote('""abc""') == '"abc"'
    assert unquote('"""\\""""') == '"""\\""""'

# Generated at 2022-06-23 05:04:30.659475
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted("'test\\''") == False
    assert is_quoted("'test'foo") == False
    assert is_quoted("\"test\"foo") == False
    assert is_quoted("foo") == False
    assert is_quoted("'foo") == False


# Generated at 2022-06-23 05:04:40.520477
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"silly walk"') is True
    assert is_quoted('"silly \'walk\'"') is True
    assert is_quoted('"silly \"walk\""') is True
    assert is_quoted('"silly \\\'walk\\\'"') is True
    assert is_quoted('\'silly walk\'') is True
    assert is_quoted('\'silly \'walk\'\'') is True
    assert is_quoted('\'silly \"walk\"\'') is True
    assert is_quoted('\'silly \\\'walk\\\'\'') is True
    assert is_quoted('"silly \'walk\'"') is True
    assert is_quoted('\'silly "walk"\'') is True


# Generated at 2022-06-23 05:04:49.726010
# Unit test for function is_quoted
def test_is_quoted():
    # Shouldn't be quoted
    assert not is_quoted('')
    assert not is_quoted('abc')
    assert not is_quoted('"abc')
    assert not is_quoted('abc"')
    assert not is_quoted('"abc"foo')

    # Should be quoted
    assert is_quoted('""')
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert is_quoted('"abc\""')
    assert is_quoted("'foo'bar")
    assert is_quoted('"foo bar"')


# Generated at 2022-06-23 05:04:56.774157
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo\\'") == False
    assert is_quoted("foo") == False
    assert is_quoted("'foo'bar") == False
    assert is_quoted("foo'bar'") == False
    assert is_quoted('"foo"bar') == False
    assert is_quoted("foo\"bar\"") == False


# Generated at 2022-06-23 05:05:00.783505
# Unit test for function unquote
def test_unquote():
    assert 'foo' == unquote('"foo"')
    assert 'foo' == unquote("'foo'")
    assert 'foo' == unquote("foo")
    assert '"foo"' == unquote('\\"foo\\"')

# Generated at 2022-06-23 05:05:09.355496
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("''")
    assert is_quoted("\"\"")
    assert is_quoted("\"foo\"")
    assert is_quoted("\"'\"")

    assert not is_quoted("\"'\"'")
    assert not is_quoted("\"'\"\"")
    assert not is_quoted("'\"")
    assert not is_quoted("'\"\"")
    assert not is_quoted("\"\"\"")
    assert not is_quoted("''\"")
    assert not is_quoted("foo")
    assert not is_quoted("\"')")
    assert not is_quoted("'\")")


# Generated at 2022-06-23 05:05:12.903462
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted\"")
    assert is_quoted("'quoted'")
    assert not is_quoted("\"quoted")
    assert not is_quoted("unquoted")


# Generated at 2022-06-23 05:05:22.193458
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"bar"') == 'bar'
    assert unquote('"!bar"') == '!bar'
    assert unquote('"bar!"') == 'bar!'
    assert unquote('"!bar!"') == '!bar!'
    assert unquote('"bar!"baz') == '"bar!"baz'  # no double quotes, so should return original
    assert unquote("'foo'") == 'foo'
    assert unquote("'bar'") == 'bar'
    assert unquote("!'bar'") == '!bar'
    assert unquote("'bar!'") == 'bar!'
    assert unquote("!'bar!'") == '!bar!'
    assert unquote("'bar!'baz") == "'bar!'baz"  # no single quotes, so

# Generated at 2022-06-23 05:05:27.574124
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"test"') == True)
    assert(is_quoted("'test'") == True)
    assert(is_quoted("'test") == False)
    assert(is_quoted("test'") == False)
    assert(is_quoted("'test''test'") == False)

# Generated at 2022-06-23 05:05:33.675804
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("'\'foo'") == False
    assert is_quoted("'\"foo'") == False
    assert is_quoted("\"foo") == False
    assert is_quoted("\"foo\"") == True
    assert is_quoted("\"'foo\"") == False
    assert is_quoted("\"\\\"foo\"") == False


# Generated at 2022-06-23 05:05:35.997375
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\\'s'") == "foo\\'s"



# Generated at 2022-06-23 05:05:39.990634
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo")  == "'foo"
    assert unquote('"foo')  == '"foo'
    assert unquote('foo')   == 'foo'

# Generated at 2022-06-23 05:05:50.394132
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"") == False
    assert is_quoted("'") == False
    assert is_quoted("'a\"b") == False
    assert is_quoted("a\"b'") == False
    assert is_quoted("\"a'b\"") == False
    assert is_quoted("''") == False
    assert is_quoted("\"\"") == False
    assert is_quoted("'a'") == True
    assert is_quoted("'ab'") == True
    assert is_quoted("'ab\\'c'") == True
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"ab\"") == True
    assert is_quoted("\"ab\\\"c\"") == True


# Generated at 2022-06-23 05:05:55.908721
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted("abc"))
    assert(is_quoted("'abc'"))
    assert(is_quoted('"abc"'))
    assert(not is_quoted('"ab\\"c"'))
    assert(not is_quoted("'ab\\'c'"))


# Generated at 2022-06-23 05:06:01.299264
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote("foobar") == 'foobar'
    assert unquote('"foo\"bar"') == 'foo"bar'
    assert unquote("'foo\'bar'") == "foo'bar"


# Generated at 2022-06-23 05:06:06.585595
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted("'quoted\"")
    assert not is_quoted("'quoted\'")
    assert not is_quoted("'quoted\\'")
    assert not is_quoted("quoted")
    assert not is_quoted('')


# Generated at 2022-06-23 05:06:11.339125
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('\'test\'') == 'test'
    assert unquote('"test\\""') == '"test\\""'
    assert unquote('test') == 'test'
    assert unquote('test\\""') == 'test\\""'

test_unquote()

# Generated at 2022-06-23 05:06:18.684324
# Unit test for function unquote
def test_unquote():
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"""foobar"""') == '"foobar"'
    assert unquote("'''foobar'''") == "'foobar'"
    assert unquote("'foobar") == "'foobar"
    assert unquote('"foobar') == '"foobar'

# Generated at 2022-06-23 05:06:21.197790
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test\"") == "test"
    assert unquote("\'test\'") == "test"
    assert unquote("\"\"test\"\"") == "\"test\""


# Generated at 2022-06-23 05:06:29.692348
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"')
    assert is_quoted("'Hello'")
    assert is_quoted("'This is a \"test\"'")
    assert not is_quoted("'This is a \"test\"")
    assert not is_quoted('"This is a \'test\'"')
    assert not is_quoted("'This has a \\\' in it'")
    assert not is_quoted("'This has a \\\" in it'")
    assert not is_quoted("'This has a \\\' in it")


# Generated at 2022-06-23 05:06:39.172494
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("''") == False
    assert is_quoted("'") == False
    assert is_quoted("a") == False
    assert is_quoted("abc") == False
    assert is_quoted("'abc'") == True
    assert is_quoted("\"abc\"") == True
    assert is_quoted("'ab'c'") == False
    assert is_quoted("'ab'\"c\"") == False
    assert is_quoted("\"ab\"'c'") == False
    assert is_quoted("'ab'\"c\"'de'f\"gh\"") == False
    assert is_quoted("\"ab'c\"") == False
    assert is_quoted("'ab\"c'") == False
    assert is_quoted

# Generated at 2022-06-23 05:06:44.052114
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('hello') == False
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('\\"hello"') == False


# Generated at 2022-06-23 05:06:46.816289
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"

# Generated at 2022-06-23 05:06:53.162331
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello, world'") == "hello, world"
    assert unquote('"hello, world"') == "hello, world"
    assert unquote("'hello, world") == "'hello, world"
    assert unquote('"hello, world') == '"hello, world'
    assert unquote("hello, world'") == "hello, world'"
    assert unquote('hello, world"') == 'hello, world"'


# Generated at 2022-06-23 05:06:59.705358
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('') == False

    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False

    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False

    assert is_quoted('"foo\\"bar"') == True
    assert is_quoted("'foo\\'bar'") == True


# Generated at 2022-06-23 05:07:10.927224
# Unit test for function is_quoted
def test_is_quoted():

    quotes = [
        ("'foo'",True),
        ('"foo"',True),
        ("''foo'",False),
        ('""foo"',False),
        ('"foo"bar"',False),
        ('"foo',False),
        ('foo"',False),
        ('\"foo\"',True),
        ('\"foo\\\"\"',True),
        ('foo',False),
        ('"foo\\"',False),
        ('"foo\\\"bar"',True),
        ('\'foo',False),
        ('foo\'',False),
        ('foo',False),
        ('\'foo\\\'',False),
        ('\'foo\\\'bar\'',True),
        ('\'foo\'',True),
        ('"foo\'bar"',True),
    ]


# Generated at 2022-06-23 05:07:15.716485
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"') == False
    assert is_quoted('"abc"') == True
    assert is_quoted('"a\\b"') == False
    assert is_quoted('"a\\\\b"') == True
    assert is_quoted('\'abc\'') == True

# Generated at 2022-06-23 05:07:25.134213
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') is True
    assert is_quoted('\'"hello"\'') is True
    assert is_quoted('"hello" world') is False
    assert is_quoted('"hello""') is False
    assert is_quoted('"""hello"""') is False
    assert is_quoted('"hello""') is False
    assert is_quoted('\'"hello"') is False
    assert is_quoted('""hello"') is False
    assert is_quoted('\\"hello"') is False
    assert is_quoted('hello"') is False
    assert is_quoted('hello') is False
    assert is_quoted('"hello') is False
    assert is_quoted('') is False



# Generated at 2022-06-23 05:07:30.587373
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo\'')
    assert not is_quoted('\'foo"')
    assert not is_quoted('foo')


# Generated at 2022-06-23 05:07:37.233368
# Unit test for function is_quoted
def test_is_quoted():
    ''' ensure is_quoted returns true if string is quoted, false if it isnt '''
    # Test single character
    assert not is_quoted('a')
    # Test quotes
    assert is_quoted('"')
    assert is_quoted("'")
    # Test escaped quotes
    assert not is_quoted("'\\''")
    assert not is_quoted('"\\""')
    # Test strings
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    # Test multi-line strings
    assert is_quoted("'''foo'''")
    assert is_quoted("\"\"\"foo\"\"\"")



# Generated at 2022-06-23 05:07:39.965052
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False


# Generated at 2022-06-23 05:07:48.961004
# Unit test for function is_quoted
def test_is_quoted():
    assert(True  == is_quoted('"test"'))
    assert(True  == is_quoted("'test'"))
    assert(False == is_quoted('"test'))
    assert(False == is_quoted("test'"))
    assert(False == is_quoted('test'))
    assert(True  == is_quoted('"test with escape char \'"'))
    assert(True  == is_quoted('"test with escape char \\"'))
    assert(False == is_quoted('"test with escape char \\'))
    assert(False == is_quoted('"test with escape char \\""'))


# Generated at 2022-06-23 05:07:54.966299
# Unit test for function is_quoted
def test_is_quoted():
    list_test = {
        'hello': False,
        '"hello"': True,
        '"hello': False,
        '\'hello': False,
        '"hello\'': False,
        '"insert space"': True,
        '\'insert space\'': True
    }
    for test_string, value in list_test.items():
        assert(is_quoted(test_string) == value)


# Generated at 2022-06-23 05:07:57.379058
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert not is_quoted('test')


# Generated at 2022-06-23 05:08:02.580215
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo\\""')
    assert not is_quoted('\\"foo\\"')
    assert not is_quoted('"foo"bar"')
    assert not is_quoted('\'foo\'')
    assert not is_quoted('\'foo\\\'\'')
    assert not is_quoted('\\\'foo\\\'\'')
    assert not is_quoted('\'foo\'bar\'')


# Generated at 2022-06-23 05:08:10.836806
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is quoted"')
    assert is_quoted("'this is also quoted'")
    assert is_quoted('"test backslash \\\\"') is False
    assert is_quoted('"test backslash \\\\ "')
    assert is_quoted('"test unterminated quote') is False
    assert is_quoted('"test unterminated quote\\') is False
    assert is_quoted('test unquoted"') is False
    assert is_quoted('"test unquoted"test unquoted') is False

# Generated at 2022-06-23 05:08:18.923104
# Unit test for function unquote
def test_unquote():
    assert unquote('"quoted_string"') == 'quoted_string'
    assert unquote("'quoted_string'") == 'quoted_string'
    assert unquote('"\\"quoted\\"_string"') == '"quoted"_string'
    assert unquote("'\\'quoted\\'_string'") == "'quoted'_string"
    assert unquote("unquoted_string") == 'unquoted_string'
    assert unquote("'quoted_string")  == "'quoted_string"


# Generated at 2022-06-23 05:08:26.331812
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abc"') == True)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted('"ab\\"c"') == False)
    assert(is_quoted("'ab\\'c'") == False)
    assert(is_quoted('"abc') == False)
    assert(is_quoted('abc"') == False)
    assert(is_quoted('"abc\'') == False)
    assert(is_quoted('abc') == False)
    assert(is_quoted('abcdef') == False)
    assert(is_quoted('"') == False)
    assert(is_quoted("'") == False)


# Generated at 2022-06-23 05:08:35.542046
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"foobar"')
    assert is_quoted("'barfoo'")
    assert is_quoted('"foo bar"')
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted('foobar"')
    assert not is_quoted("foobar'")
    assert not is_quoted('')

    assert unquote('"foobar"') == 'foobar'
    assert unquote('"foobar') == '"foobar'
    assert unquote('"foo bar"') == 'foo bar'

# Generated at 2022-06-23 05:08:41.574879
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\""') == 'foo\\"'
    assert unquote("'foo\\''") == 'foo\\\''
    assert unquote('"fo\\"o"') == 'fo\\"o'
    assert unquote("'fo\\'o'") == 'fo\\\'o'

# Generated at 2022-06-23 05:08:49.536345
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\\"bc"') == 'a"bc'
    assert unquote('"a\\\\bc"') == 'a\\bc'
    assert unquote('a\\"bc') == 'a\\"bc'
    assert unquote('a\\\\"bc"') == 'a\\\\"bc"'
    assert unquote('a\\\\bc') == 'a\\\\bc'

# Generated at 2022-06-23 05:08:52.517979
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert not is_quoted("'test'")
    assert not is_quoted("'test\\'")
    assert not is_quoted("\"test\\\"")
    assert not is_quoted("\"test")


# Generated at 2022-06-23 05:08:59.409441
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("abc") == "abc"
    assert unquote("") == ""
    assert unquote('"a\"c"') == 'a\"c'
    assert unquote("'a\"c'") == 'a\"c'
    assert unquote("\"a\'c\"") == "a\'c"
    assert unquote("'a\'c'") == "a\'c"
    assert unquote("'a\'c\"") == "'a\'c\""

# Generated at 2022-06-23 05:09:04.974815
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foobar')
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted('foobar"')
    assert not is_quoted("foobar'")
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")


# Generated at 2022-06-23 05:09:14.802242
# Unit test for function unquote
def test_unquote():
    assert unquote('"Hello"') == 'Hello'
    assert unquote("'Hello'") == 'Hello'
    assert unquote('Hello') == 'Hello'
    assert unquote('"Hell\'o"') == 'Hell\'o'
    assert unquote('"Hell""o"') == 'Hell""o'
    assert unquote('"Hell""o"') == 'Hell""o'
    assert unquote('"Hell\"""o"') == 'Hell\"""o'
    assert unquote('"Hell\'o"') == 'Hell\'o'
    assert unquote('"\\\"Hello\\\""') == '\\\"Hello\\\"'
    assert unquote('"\\"Hello\\""') == '\\"Hello\\"'



# Generated at 2022-06-23 05:09:24.586076
# Unit test for function is_quoted
def test_is_quoted():
    assert False == is_quoted('foo')
    assert False == is_quoted('"foo')
    assert False == is_quoted('foo"')
    assert False == is_quoted("'foo")
    assert False == is_quoted("foo'")
    assert False == is_quoted('"foo\'"')
    assert True == is_quoted('"foo"')
    assert True == is_quoted("'foo'")
    assert True == is_quoted('""')
    assert True == is_quoted("''")
    assert False == is_quoted('"""')
    assert False == is_quoted("'''")
    assert False == is_quoted('"foo""')


# Generated at 2022-06-23 05:09:32.047686
# Unit test for function unquote
def test_unquote():
    # Tests with success
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote("'test \\'s'") == "test \\'s"
    assert unquote('"test \\"s"') == 'test \\"s'
    # Tests with failure
    assert unquote('"test') != "test"
    assert unquote('test"') != "test"
    assert unquote("'test") != "test"
    assert unquote("test'") != "test"

# Generated at 2022-06-23 05:09:41.981892
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert is_quoted("'hello world'")
    assert not is_quoted("hello")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("'hello\"")
    assert not is_quoted("")
    assert not is_quoted("''")
    assert not is_quoted("\"\"")
    assert not is_quoted("'")
    assert not is_quoted("'\n")
    assert not is_quoted("'\\''")

    assert unquote("'hello'") == "hello"
    assert unquote("\"hello\"") == "hello"

# Generated at 2022-06-23 05:09:49.517060
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') == False)
    assert(is_quoted('abc') == False)
    assert(is_quoted('"abc"') == True)
    assert(is_quoted('\'abc\'') == True)
    assert(is_quoted('"a\\"bc"') == True)
    assert(is_quoted('\'a\\\'bc\'') == True)
    assert(is_quoted('"a\\"b\\"c"') == True)
    assert(is_quoted('\'a\\"b\\"c\'') == True)


# Generated at 2022-06-23 05:09:53.348186
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"ab\"c"') == 'ab"c'

# Generated at 2022-06-23 05:09:57.099964
# Unit test for function is_quoted
def test_is_quoted():
    res = is_quoted('this string is not quoted')
    assert res == False
    res = is_quoted('"this string is quoted"')
    assert res == True
    res = is_quoted('"this string also quoted\'"')
    assert res == False


# Generated at 2022-06-23 05:10:06.049526
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("'foo") == False)
    assert(is_quoted("foo'") == False)
    assert(is_quoted("'foo\"") == False)
    assert(is_quoted("\"foo\"") == True)
    assert(is_quoted("\"foo") == False)
    assert(is_quoted("foo\"") == False)
    assert(is_quoted("\"foo\'") == False)
    assert(is_quoted("\"foo\"bar\"") == False)
    assert(is_quoted("'foo'bar'") == False)
    assert(is_quoted("'foo\\'") == False)
    assert(is_quoted("'foo'\\''") == False)

# Unit test

# Generated at 2022-06-23 05:10:10.576975
# Unit test for function is_quoted
def test_is_quoted():
    data = ['\'hello\'',
            '\"hello\"',
    	    '\'hel\'\'lo\'',
    	    '\"hel\"\"lo\"']
    for sample in data:
    	print(sample, is_quoted(sample))
	

# Generated at 2022-06-23 05:10:14.461495
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc"d') == '"abc"d'
    assert unquote('\'"abc"\'') == '\'"abc"\''

# Generated at 2022-06-23 05:10:20.725729
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('test') is False
    assert is_quoted('"test"') == True
    assert is_quoted('"tes\"t"') == False
    assert is_quoted('"tes\\\\t"') == False
    assert is_quoted('\'test\'') == True
    assert is_quoted('\'tes"t\'') == False
    assert is_quoted('\'tes\\\\t\'') == False

# Generated at 2022-06-23 05:10:24.865174
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted('"foobar')


# Generated at 2022-06-23 05:10:34.308573
# Unit test for function unquote
def test_unquote():
    assert unquote("'boo'") == 'boo'
    assert unquote("boo") == 'boo'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("foo bar") == 'foo bar'
    assert unquote("foo bar'") == "foo bar'"
    assert unquote("'foo bar") == "'foo bar"
    assert unquote("'foo''bar'") == "foo'bar"
    assert unquote("\"foo\"'bar'") == "foo'bar"
    assert unquote("foo\\'bar") == "foo\\'bar"
    assert unquote("'foo\\'bar'") == "foo'bar"
    assert unquote("\"foo\\\"bar\"") == "foo\"bar"

# Generated at 2022-06-23 05:10:44.690336
# Unit test for function is_quoted
def test_is_quoted():
    # Unquoted
    assert is_quoted("abc") == False

    # Single quote
    assert is_quoted("'abc'") == True
    assert is_quoted("'abc") == False
    assert is_quoted("abc'") == False

    # Double quote
    assert is_quoted('"abc"') == True
    assert is_quoted('"abc') == False
    assert is_quoted('abc"') == False

    # Escaped double quote doesn't count
    assert is_quoted('"ab\\"c"') == True
    assert is_quoted('"ab\\"c') == False
    assert is_quoted('ab\\"c"') == False


# Generated at 2022-06-23 05:10:54.510941
# Unit test for function unquote
def test_unquote():
    assert unquote("''") == ''
    assert unquote("'hello world'") == 'hello world'
    assert unquote("'hello world\'s'") == "hello world's"
    assert unquote("'hello world\\''") == "hello world\\'"
    assert unquote("'''") == "\\'"