

# Generated at 2022-06-23 05:00:50.965250
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo") == "foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\\'bar") == "foo\\'bar"
    assert unquote("foo'bar\\'") == "foo'bar\\'"
    assert unquote("\"foo\\'bar\"") == "foo\\'bar"

# Generated at 2022-06-23 05:00:58.106231
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert is_quoted('"123"')
    assert not is_quoted('"ab\\"c"')
    assert not is_quoted('"abc')
    assert not is_quoted('abc"')
    assert not is_quoted('a"bc')
    assert not is_quoted('"a"b"c"')


# Generated at 2022-06-23 05:01:04.717504
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello\'')
    assert not is_quoted('hello')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')


# Generated at 2022-06-23 05:01:13.036464
# Unit test for function unquote
def test_unquote():
    assert(unquote('"some/path/somefile"') == 'some/path/somefile')
    assert(unquote('some/path/somefile') == 'some/path/somefile')
    assert(unquote('"some/path/somefile') == '"some/path/somefile')
    assert(unquote('some/path/somefile"') == 'some/path/somefile"')
    assert(unquote('/"some/path/somefile/"') == '/"some/path/somefile/"')


# Generated at 2022-06-23 05:01:18.668132
# Unit test for function unquote
def test_unquote():
    assert "foo" == unquote('foo')
    assert "foo" == unquote('"foo"') # Really, this should be an error
    assert "foo" == unquote("'foo'")
    assert "foo" == unquote('"foo')
    assert "foo" == unquote("'foo")
    assert "" == unquote('""')
    assert "" == unquote("''")
    assert "foo\"bar" == unquote('foo\\"bar')



# Generated at 2022-06-23 05:01:26.428448
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('\'hello\'') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('\'hello') == '\'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('\'hello\"') == '\'hello\"'
    assert unquote('\"hello\'') == '\"hello\''
    assert unquote('\"hello\"') == 'hello'
    assert unquote('\'hello\'') == 'hello'


# Generated at 2022-06-23 05:01:33.813802
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted(u'"foo\u2019"')
    assert not is_quoted('"')
    assert not is_quoted('foo"')
    assert not is_quoted(u'"foo')
    assert not is_quoted(u'foo')
    assert not is_quoted(u"foo\u2019")
    assert not is_quoted(u'"foo\u2019"')



# Generated at 2022-06-23 05:01:41.434204
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('no_quotes')
    assert not is_quoted('no_quotes_on_right"')
    assert not is_quoted('"no_quotes_on_left')
    assert not is_quoted('"no_quotes_on_right')
    assert not is_quoted('no_quotes_on_left"')
    assert not is_quoted('bogus_quote')
    assert is_quoted('"double_quotes"')
    assert is_quoted('\'single_quotes\'')


# Generated at 2022-06-23 05:01:45.927714
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote("hello") == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote('"hello') == '"hello'
    assert unquote('\\"') == '\\"'
    assert unquote('\\"hello') == '\\"hello'


# Generated at 2022-06-23 05:01:49.703330
# Unit test for function unquote
def test_unquote():
     assert unquote('"hello world"') == 'hello world'
     assert unquote('"hello world') == '"hello world'
     assert unquote("'hello world'") == 'hello world'
     assert unquote("'hello world") == "'hello world"

# Generated at 2022-06-23 05:01:54.252206
# Unit test for function unquote
def test_unquote():
    assert "abcd" == unquote("'abcd'")
    assert "abcd" == unquote("\"abcd\"")
    assert "abcd" == unquote("abcd\"")
    assert "abcd" == unquote("'abcd")
    assert "abcd" == unquote("'abcd\\'")
    assert "abcd\\" == unquote("'abcd\\'")



# Generated at 2022-06-23 05:01:57.462387
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo"bar'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-23 05:02:11.254821
# Unit test for function is_quoted
def test_is_quoted():
    true_data = [
        ("`echo 'hello'`", True),
        ('"hello"', True),
        ("'hello'", True),
        ('"hell\"o"', True),
        ("'hell\"o'", True),
        ('"test #1"', True),
        ("'test #1'", True),
        ('"test #1\\n"', True),
        ("'test #1\\n'", True),
        ('""', True),
        ("''", True),
        ('"', False),
        ("'", False),
        ('', False),
        ('\\"', False),
        ("\\'", False),
    ]
    for (data, answer) in true_data:
        passed = is_quoted(data)

# Generated at 2022-06-23 05:02:23.040563
# Unit test for function unquote
def test_unquote():
    assert(unquote("'test'") == "test")
    assert(unquote('"test"') == "test")
    assert(unquote("'test") == "'test")
    assert(unquote('"test') == '"test')
    assert(unquote("test'") == "test'")
    assert(unquote('test"') == 'test"')
    assert(unquote('"test') == '"test')
    assert(unquote("'test\"") == 'test"')
    assert(unquote('"test\'"') == "test'")
    assert(unquote("'test\\\\'") == "test\\\\")
    assert(unquote("test\\\\'") == "test\\\\'")
    assert(unquote("'test\\\\") == "'test\\\\")

# Generated at 2022-06-23 05:02:28.737025
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('"foo"')
    assert True == is_quoted("'foo'")
    assert False == is_quoted('"foo\'"')
    assert False == is_quoted('foo')
    assert False == is_quoted('""')
    assert False == is_quoted("''")
    assert False == is_quoted('"')
    assert False == is_quoted("'")


# Generated at 2022-06-23 05:02:37.553519
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"a"b') == '"a"b'
    assert unquote("'a'b") == "'a'b"
    assert unquote('a') == 'a'
    assert unquote("a") == 'a'
    assert unquote('a"') == 'a"'
    assert unquote("a'") == "a'"

# Generated at 2022-06-23 05:02:43.283498
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote("'t\\'e\\'s\\'t'") == "t\\'e\\'s\\'t"
    assert unquote('"t\\"e\\"s\\"t"') == 't\\"e\\"s\\"t'
    assert unquote("'test\\'") == "'test\\'"
    assert unquote('"test\\"') == '"test\\"'

# Generated at 2022-06-23 05:02:53.498252
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello', "'hello' without quotes is '%s'" % unquote('hello')
    assert unquote("'hello'") == 'hello', "'hello' without quotes is '%s'" % unquote("'hello'")
    assert unquote('hello"') == 'hello"', "'hello' without quotes is '%s'" % unquote('hello"')
    assert unquote("hello'") == "hello'", "'hello' without quotes is '%s'" % unquote("hello'")
    assert unquote('"hello') == '"hello', "'hello' without quotes is '%s'" % unquote('"hello')
    assert unquote("'hello") == "'hello", "'hello' without quotes is '%s'" % unquote("'hello")



# Generated at 2022-06-23 05:03:00.669474
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert is_quoted("'foo\"bar'")

    assert not is_quoted("'foo\"bar")
    assert not is_quoted('"foobar')
    assert not is_quoted("foo\"bar'")


# Generated at 2022-06-23 05:03:09.685802
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo"bar"')
    assert not is_quoted("'foo'bar'")
    assert is_quoted('''"foo"''')
    assert is_quoted('''"foo'bar"''')


# Generated at 2022-06-23 05:03:14.036656
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"silly quoted string"')
    assert is_quoted('\'silly quoted string\'')
    assert is_quoted('"silly quoted string\\""')
    assert not is_quoted('"silly quoted string"\'')
    assert not is_quoted('\'silly quoted string"')
    assert not is_quoted('\'silly quoted string\\""')
    assert not is_quoted('\\"silly quoted string\\""')
    assert not is_quoted('\\"silly quoted string"')
    assert not is_quoted('"silly quoted string\\\'"')
    assert not is_quoted('\'silly quoted string\\\'"')



# Generated at 2022-06-23 05:03:23.516872
# Unit test for function unquote
def test_unquote():

    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('foo') == 'foo'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote('foo"""bar"') == 'foo"""bar"'

    assert unquote("") == ""
    assert unquote("''") == ""
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo'bar") == "'foo'bar"
    assert unquote("foo") == "foo"
    assert unquote("foo'bar") == "foo'bar"
    assert unquote("foo'''bar'") == "foo'''bar'"

# Generated at 2022-06-23 05:03:28.152877
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'''hello'''")
    assert not is_quoted("'''hello")
    assert not is_quoted("hello")


# Generated at 2022-06-23 05:03:35.678083
# Unit test for function unquote
def test_unquote():

    # Single quotes
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'

    # Backslash escaped quotes
    assert unquote("'fo\\'o'") == "fo'o"
    assert unquote("\"fo\\\"o\"") == 'fo"o'

    # Backslash escaped backslashes
    assert unquote("'fo\\\\o'") == 'fo\\o'
    assert unquote("\"fo\\\\o\"") == 'fo\\o'

    # Empty String
    assert unquote("''") == ''
    assert unquote("\"\"") == ''

    # No quotes
    assert unquote("no quotes") == 'no quotes'
    assert unquote("single 'single' quotes") == "single 'single' quotes"

# Generated at 2022-06-23 05:03:47.120579
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('') == ''
    assert unquote('""') == '""'
    assert unquote('"\\"foo\\""') == '"\\"foo\\""'
    assert unquote('"\'foo\'"') == '"\'foo\'"'
    assert unquote('"\\"foo\\""') == '"\\"foo\\""'
    assert unquote('"\'foo\'"') == '"\'foo\'"'
    assert unquote('"\\\'foo\\\'"') == '"\\\'foo\\\'"'
    assert unquote('"\\\\"foo\\\\""') == '"\\\\"foo\\\\""'

# Generated at 2022-06-23 05:03:54.571214
# Unit test for function unquote
def test_unquote():
    assert (unquote('"hello world"') == 'hello world')
    assert (unquote('"hello world')  == '"hello world')
    assert (unquote('hello world"')  == 'hello world"')
    assert (unquote('hello world')   == 'hello world')
    assert (unquote('"""hello world"""')   == 'hello world')
    assert (unquote("''''hello world'''") == 'hello world')
    
    

# Generated at 2022-06-23 05:04:05.568624
# Unit test for function unquote
def test_unquote():
    assert unquote("bar") == "bar"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote("'foo'bar") == "'foo'bar"
    assert unquote('foo"bar"') == 'foo"bar"'
    assert unquote('foo\'bar\'') == 'foo\'bar\''
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('"foo\\\\"bar"') == 'foo\\\\"bar'
    assert unquote("'foo\\\\'bar'") == "foo\\\\'bar"


# Generated at 2022-06-23 05:04:16.289357
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote('"ab"') == 'ab'
    assert unquote('"a\\"b"') == 'a"b'
    assert unquote('"ab\\""') == 'ab"'
    assert unquote('"\\"a\\"b\\""') == '"a"b"'
    assert is_quoted('"a"') == True
    assert is_quoted('a') == False
    assert is_quoted('"""') == False
    assert is_quoted('\\"a') == False
    assert is_quoted('\\\\"a') == False
    assert unquote('a') == 'a'
    assert unquote('\\"a') == '\\"a'
    assert unquote('"""') == '""'


# Generated at 2022-06-23 05:04:23.692333
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote("\\'foo'") == "\\'foo'"
    assert unquote("\\'foo") == "\\'foo"
    assert unquote("foo\\'") == "foo\\'"

# Generated at 2022-06-23 05:04:29.612270
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted("test'")
    assert not is_quoted('test"')
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('\\"test\\"')


# Generated at 2022-06-23 05:04:35.600822
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\"") == "foo\""
    assert unquote("'foo\"") == "'foo\""
    assert unquote("\"foo'") == "\"foo'"
    assert unquote("foo") == "foo"

# Generated at 2022-06-23 05:04:40.871011
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') is True)
    assert(is_quoted("'foo'") is True)
    assert(is_quoted("'foo") is False)
    assert(is_quoted("foo'") is False)
    assert(is_quoted("'foo\"") is False)
    assert(is_quoted("'foo\\\"") is False)
    assert(is_quoted("\"foo\\\"") is False)



# Generated at 2022-06-23 05:04:47.680936
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert not is_quoted('"foobar')
    assert not is_quoted('foobar"')
    assert not is_quoted('"foobar"baz')
    # \ is not an escape char
    assert is_quoted(r'"foo\"bar"')
    assert is_quoted(r'"foo\\bar"')
    assert is_quoted(r'"foo\\\"bar"')
    assert is_quoted(r'"foo\\\"bar\""')
    assert is_quoted(r'"foo\'bar"')
    assert is_quoted(r'"foo\\\'bar"')
    assert is_quoted(r'"foo\\\'bar\'"')


# Generated at 2022-06-23 05:04:52.116114
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo""bar"') == 'foo"bar'
    assert unquote('"foo\'bar"') == "foo'bar"
    assert unquote('"foo\\"bar"') == 'foo"bar'

# Generated at 2022-06-23 05:04:59.284631
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo\""') == False


# Generated at 2022-06-23 05:05:04.583819
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted("'test")
    assert not is_quoted("'te\\'st'")
    assert not is_quoted("test")
    assert not is_quoted("\"test")
    assert not is_quoted("'test\"")


# Generated at 2022-06-23 05:05:07.932029
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\"\"bar'") == 'foo"bar'


# Generated at 2022-06-23 05:05:16.431891
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"') == True
    assert is_quoted('Hello"') == False
    assert is_quoted('"Hello') == False
    assert is_quoted('"Hello""') == False
    assert is_quoted('"Hello\"') == False
    assert is_quoted('\'Hello\'') == True
    assert is_quoted('Hello\'') == False
    assert is_quoted('\'Hello') == False
    assert is_quoted('\'Hello\'\'') == False
    assert is_quoted('\'Hello\\\'') == False


# Generated at 2022-06-23 05:05:19.510400
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted("'test\\'") == False
    assert is_quoted('"tes\\"t"') == False


# Generated at 2022-06-23 05:05:29.732399
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert not is_quoted('"not quoted"')
    assert not is_quoted('\\"quoted\\"')
    assert not is_quoted('"quote\\"')
    assert not is_quoted('"quote"')
    assert is_quoted("'quoted'")
    assert not is_quoted("'not quoted'")
    assert not is_quoted("\\'quoted\\'")
    assert not is_quoted("'quote\\'")
    assert not is_quoted("'quote'")
    assert not is_quoted('almost')


# Generated at 2022-06-23 05:05:35.561332
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted('\'test\'')
    assert not is_quoted('abcdef')
    assert not is_quoted('"abcdef"g')
    assert is_quoted('"abc\\"def"')
    assert not is_quoted('\\"abcdef\\"')
    assert is_quoted('"abcdef\\\\"')
    assert is_quoted('"abcdef\\\\\\""')


# Generated at 2022-06-23 05:05:46.562443
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'ab''c'") == "ab''c"
    assert unquote("'a''bc'") == "a''bc"
    assert unquote("'ab'c'") == "'ab'c"
    assert unquote("'ab'c") == "'ab'c"
    assert unquote("'ab'\\c'") == "'ab'\\c"
    assert unquote("'ab'\\'c'") == "'ab'\\'c"
    assert unquote("''") == ''
    assert unquote("'abc") == "'abc"
    assert unquote('"abc') == '"abc'
    assert unquote("ab'c") == "ab'c"

# Generated at 2022-06-23 05:05:53.214426
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'hello\"") is False
    assert is_quoted('"hello\'') is False
    assert is_quoted('hello') is False
    assert is_quoted('"hello" world!') is False

# Generated at 2022-06-23 05:06:02.954909
# Unit test for function is_quoted
def test_is_quoted():
    # These are quoted
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"\\"test\\""')
    assert is_quoted("'\\'test\\''")
    assert is_quoted('''"'test'"''')
    assert is_quoted("'''test'''")
    assert is_quoted('''"'\\'test'\\'"''')
    assert is_quoted("'''\"test\"'''")
    assert is_quoted('"\\"\\"test\\"\\""')
    assert is_quoted("'''\"\"test\"\"'''")
    assert is_quoted('"\\""\\"test\\""\\""')

    # These aren't quoted
    assert not is_quoted('"test')


# Generated at 2022-06-23 05:06:12.032799
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"') == True
    assert is_quoted('"foo\"bar"') == False
    assert is_quoted('\'foobar\'') == True
    assert is_quoted('\'foo\'bar\'') == False
    assert is_quoted("'foo'bar'") == False
    assert is_quoted("'foo\'bar'") == False
    assert is_quoted("foo") == False
    assert is_quoted("'foo'bar") == False
    assert is_quoted("\"foo\"bar") == False

# Generated at 2022-06-23 05:06:21.040929
# Unit test for function unquote
def test_unquote():
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'bc") == "'a'bc"
    assert unquote("'a''bc'") == "a''bc"
    assert unquote("'a\''bc'") == "a\''bc"
    assert unquote("'a\''bc") == "'a\''bc"
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote('"foo"') == "foo"
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('''"foo'bar''') == "foo'bar"

# Generated at 2022-06-23 05:06:32.627710
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted("foo")
    assert not is_quoted("'foobar'foo")
    assert not is_quoted('"foobar"foo')
    assert not is_quoted("'foo\\'bar")
    assert not is_quoted('"foo\\"bar')
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foobar") == "'foobar"
    assert unquote('"foobar') == '"foobar'
    assert unquote("foo") == "foo"

# Generated at 2022-06-23 05:06:38.392072
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcsdfsf') == '"abcsdfsf'
    assert unquote('abcsdfsf') == 'abcsdfsf'
    assert unquote('abcsdf"sf') == 'abcsdf"sf'

# Generated at 2022-06-23 05:06:45.488331
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    

# common python idiom to support python 2 and 3 string types
# http://stackoverflow.com/questions/6710381/how-to-check-whether-a-variable-is-an-unicode-string-or-a-regular-string
try:
    unicode
except NameError:
    # Python 3
    basestring = (str, bytes)
else:
    # Python 2
    basestring = basestring



# Generated at 2022-06-23 05:06:56.952960
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('"')

    assert not is_quoted('foo')
    assert not is_quoted('foo"bar')
    assert not is_quoted('foo\'bar')
    assert not is_quoted('foo\'bar"baz')

    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo"')

    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted('"foo"bar"baz')
    assert is_quoted("'foo'bar'baz")
    assert is_quoted('"foo\'bar"baz')
    assert is_quoted("'foo\"bar'baz")

# Generated at 2022-06-23 05:07:05.559186
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove leading and trailing quotes if the string starts
    and ends with the same quotes.  It should not remove quotes if the string
    does not start and end with the same type of quotes. '''

    # unquote should remove leading and trailing single or double quotes
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'

    # unquote should work even if the string contains escaped quotes
    assert unquote("\"foo\\\"bar\"") == "foo\"bar"
    assert unquote("'foo\\'bar'") == "foo'bar"


# Generated at 2022-06-23 05:07:14.047129
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'quoted'")
    assert is_quoted('"quoted"')
    assert is_quoted("'do not enter'")
    assert is_quoted('"do not enter"')
    assert not is_quoted("'do not enter\'")
    assert not is_quoted("'do not enter\\'")
    assert not is_quoted("'")
    assert not is_quoted("'nospaces")
    assert not is_quoted("'no spaces'")
    assert not is_quoted("noquotes")
    assert not is_quoted("'badescape \\' ")


# Generated at 2022-06-23 05:07:18.228537
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\\""') == 'foo"'
    assert unquote("'foo\\''") == "foo'"

# Generated at 2022-06-23 05:07:27.391916
# Unit test for function is_quoted
def test_is_quoted():
    # Test when the value is not quoted.
    data = 'foobar'
    assert is_quoted(data) == False
    assert data == 'foobar'

    # Test when the value is quoted.
    data = '"foobar"'
    assert is_quoted(data) == True
    assert data == '"foobar"'

    # Test when there is a backslash at the end of the quote
    data = "'foobar\\"
    assert is_quoted(data) == False
    assert data == "'foobar\\"

    # Test when there is a backslash before the ending quote
    data = "'foobar\\'"
    assert is_quoted(data) == True
    assert data == "'foobar\\'"

    # Test when the value is not quoted, but the first and last char are the same

# Generated at 2022-06-23 05:07:36.129840
# Unit test for function unquote
def test_unquote():
    assert unquote("hello") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("\"hello\"") == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("\"hello") == "\"hello"
    assert unquote("hello\"") == "hello\""
    assert unquote("\"hello\"\"") == "hello\""
    assert unquote("\"hello\"\"\"") == "hello\""
    assert unquote("\"hello\"'") == "hello\"'"
    assert unquote("'hello'\"") == "hello'\""
    assert unquote("'hello\"") == "'hello\""
    assert unquote("\"hello'") == "\"hello'"

# Generated at 2022-06-23 05:07:42.536251
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("abc") == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted("'abc'") == True
    assert is_quoted('"abc"') == True
    assert is_quoted('"a\\bc"') == False
    assert is_quoted("'a\\bc'") == False

# Generated at 2022-06-23 05:07:47.784887
# Unit test for function is_quoted
def test_is_quoted():

    assert(is_quoted('"abc"') == True)
    assert(is_quoted('"abc') == False)
    assert(is_quoted('\'abc\'') == True)
    assert(is_quoted('\'abc') == False)
    assert(is_quoted('123') == False)



# Generated at 2022-06-23 05:07:52.154038
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted('test"')


# Generated at 2022-06-23 05:08:01.042379
# Unit test for function is_quoted
def test_is_quoted():
    # is_quoted(data)
    assert is_quoted("'This is the first paragraph.\n\nThis is the second.'")
    assert not is_quoted("\"This is the first paragraph.\n\nThis is the second.\"")
    assert is_quoted("\"It's 'been' a while.\n\nIt has.\"")
    assert is_quoted("''")
    assert is_quoted("'''")
    assert is_quoted("'a'")
    assert is_quoted("'quoted string'")
    assert is_quoted("\"quoted string\"")
    assert is_quoted("'quoted \"string\"'")
    assert is_quoted("\"quoted 'string'\"")

# Generated at 2022-06-23 05:08:05.485663
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo"bar')
    assert not is_quoted("'foo'bar")


# Generated at 2022-06-23 05:08:16.871597
# Unit test for function unquote
def test_unquote():
    '''test unquote'''
    data = """unquoted string"""
    assert unquote(data) == data
    data = '''"quoted string"'quote char at EOL' '''
    assert not is_quoted(data)
    assert unquote(data) == data

# Generated at 2022-06-23 05:08:23.736643
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'hello\\'") == False
    assert is_quoted('"hello"world') == False
    assert is_quoted('"hello') == False
    assert is_quoted('') == False
    assert is_quoted('hello') == False
    assert is_quoted('"hello""') == False
    assert is_quoted('"""hello"""') == False
    assert is_quoted('"""hello', raw=True) == False
    assert is_quoted('"""hello', raw=False) == True


# Generated at 2022-06-23 05:08:29.362908
# Unit test for function unquote
def test_unquote():
    assert unquote('k') == 'k'
    assert unquote("k") == 'k'
    assert unquote("'k'") == 'k'
    assert unquote('k\\"') == 'k\\"'
    assert unquote("\"k\"") == 'k'
    assert unquote("\"k'") == "\"k'"
    assert unquote("'k\"") == "'k\""
    assert unquote("\"'k'\"") == "'k'"

# Generated at 2022-06-23 05:08:39.681834
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello world'") is True
    assert is_quoted('"hello world"') is True
    assert is_quoted('"hello \'world\'"') is True
    assert is_quoted("'hello \"world\"'") is True
    assert is_quoted("'hello \"world\"'") is True
    assert is_quoted("'hello \"world") is False
    assert is_quoted("'hello world'") is True
    assert is_quoted('"hello world') is False
    assert is_quoted("hello world") is False
    assert is_quoted('"hello \'world"') is False
    assert is_quoted("'hello \"world'") is False


# Generated at 2022-06-23 05:08:43.033358
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('bar') == 'bar'
    assert unquote('\'"foo\'"') == '"foo"'
    assert unquote('') == ''


# Generated at 2022-06-23 05:08:48.175530
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted('"""foo"""')
    assert is_quoted("'''foo'''")
    assert is_quoted('"""foo"bar\'baz"""')
    assert not is_quoted('"foo"bar"baz"')
    assert not is_quoted('"""foobar"""')


# Generated at 2022-06-23 05:08:52.144095
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote("hello") == "hello"
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote("'hel\"lo'") == "hel\"lo"


# Generated at 2022-06-23 05:08:57.478334
# Unit test for function unquote
def test_unquote():
    assert unquote('"') == ''
    assert unquote('""') == ''
    assert unquote('""a') == 'a'
    assert unquote('"ab"') == 'ab'
    assert unquote('"ab""') == 'ab'
    assert unquote('"ab" "cd"') == '"ab" "cd"'


# Generated at 2022-06-23 05:09:05.760890
# Unit test for function unquote
def test_unquote():
    ''' test for function unquote '''
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('hello') == 'hello'
    assert unquote('"hel\\"lo"') == 'hel"lo'
    assert unquote('"hel\\\\lo"') == 'hel\\lo'
    assert unquote('"hello\\""') == 'hello"'
    assert unquote('"hello\\\\"') == 'hello\\'
    assert unquote('"hello\\\\\\""') == 'hello\\"'



# Generated at 2022-06-23 05:09:13.200194
# Unit test for function unquote
def test_unquote():
    assert unquote("'this is a quoted string'") == "this is a quoted string"
    assert unquote('"this is a quoted string"') == "this is a quoted string"
    assert unquote("this is not a quoted string (but it has quotes)") == "this is not a quoted string (but it has quotes)"
    assert unquote("'this is a quoted string") == "'this is a quoted string"
    assert unquote("this is not a quoted string") == "this is not a quoted string"
    assert unquote("this is not a quoted 'string'") == "this is not a quoted 'string'"
    assert unquote("this is not a quoted \"string\"") == "this is not a quoted \"string\""
    assert unquote("'this is not a quoted \"string\"'") == "this is not a quoted \"string\""


# Generated at 2022-06-23 05:09:16.497173
# Unit test for function unquote
def test_unquote():
    data1 = "foo"
    data2 = "\"foo\""
    assert unquote(data1) == data1
    assert unquote(data2) == "foo"


# Generated at 2022-06-23 05:09:22.116506
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted(u'abc')
    assert is_quoted(u"'abc'")
    assert is_quoted(u'"abc"')
    assert is_quoted(u"'a''bc'")
    assert not is_quoted(u"'ab''c'")
    assert is_quoted(u"'a\\'bc'")


# Generated at 2022-06-23 05:09:31.737411
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo'foo") == "'foo'foo"
    assert unquote("'foo\"foo'") == 'foo"foo'
    assert unquote("foo\"foo'") == 'foo"foo'
    assert unquote("foo\"foo") == 'foo"foo'
    assert unquote("'foo\"foo") == 'foo"foo'

# Generated at 2022-06-23 05:09:35.287497
# Unit test for function unquote
def test_unquote():
    assert unquote("hello") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("\"hello\"") == "hello"
    assert unquote("'\"hello\"'") == "\"hello\""
    assert unquote("\"'hello'\"") == "'hello'"


# Generated at 2022-06-23 05:09:42.353371
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("test")
    assert is_quoted("test") == "test"
    assert is_quoted("'test'")
    assert is_quoted('"test"')

    assert not is_quoted("'test")
    assert not is_quoted("test'")

    assert not is_quoted("'test\\''")
    assert is_quoted("'test\\'\\'")

    assert not is_quoted("'test\\'")
    assert not is_quoted("'test'\\''")


# Generated at 2022-06-23 05:09:51.000478
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('h"ello')
    assert not is_quoted('"hello""')
    assert is_quoted('"hello\\""')
    assert is_quoted("'hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("h'ello")
    assert is_quoted("'''hello'''")
    assert is_quoted("'hello\\''")


# Generated at 2022-06-23 05:10:01.331877
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('"this is not quoted"')
    assert not is_quoted("'this is not quoted'")
    assert is_quoted("'this is quoted'")
    assert is_quoted('"this is quoted"')
    assert is_quoted("''")
    assert is_quoted('""')
    assert is_quoted("'''")
    assert is_quoted('""""')
    assert is_quoted("'\"'")
    assert is_quoted('"\'"')
    assert is_quoted("'this \"is\" quoted'")
    assert is_quoted('"this \'is\' quoted"')
    assert not is_quoted("'this is not \\'quoted'")
    assert not is_quoted('"this is not \\"quoted"')

# Unit

# Generated at 2022-06-23 05:10:08.127690
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('test')
    assert not is_quoted('"test"')
    assert not is_quoted('\'"test"\'')
    assert is_quoted('"test')
    assert is_quoted('test"')
    assert is_quoted('"test"')
    assert is_quoted('"""test"""')
    assert is_quoted("'''test'''")
    assert not is_quoted('')


# Generated at 2022-06-23 05:10:13.477734
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted('test"')
    assert is_quoted('"test"')
    assert is_quoted('"test\""')
    assert not is_quoted('"test\"')


# Generated at 2022-06-23 05:10:19.809688
# Unit test for function unquote
def test_unquote():
    assert 'bob' == unquote('"bob"')
    assert 'bob' == unquote("'bob'")
    assert 'bob' == unquote("'bob")
    assert '"bob"' == unquote('"""bob"""')
    assert '"bob"' == unquote("'''bob'''")
    assert '"bob"' == unquote("'''bob'''")


# Generated at 2022-06-23 05:10:26.450552
# Unit test for function unquote
def test_unquote():
    assert unquote("'test1'") == "test1"
    assert unquote("'test1") == "'test1"
    assert unquote("test1'") == "test1'"
    assert unquote("'test1\"") == "'test1\""
    assert unquote("\"test1\"") == "test1"
    assert unquote("\"'test1\"") == "\"'test1"
    assert unquote("\"test1") == "\"test1"
    assert unquote("test1") == "test1"

# Generated at 2022-06-23 05:10:33.172424
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo") == "foo"
    assert unquote("'foo's bar'") == "'foo's bar'"

'''
# vim: expandtab:tabstop=4:shiftwidth=4
'''

# Generated at 2022-06-23 05:10:38.441832
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'


# Generated at 2022-06-23 05:10:42.809160
# Unit test for function is_quoted
def test_is_quoted():

    assert not is_quoted("test")
    assert not is_quoted('')

    assert is_quoted('"test"')
    assert is_quoted("'test'")

    assert is_quoted('"test""')
    assert is_quoted("'test''")


# Generated at 2022-06-23 05:10:53.510602
# Unit test for function is_quoted
def test_is_quoted():
    # Test True cases
    assert is_quoted('"single quotes"')
    assert is_quoted('"mismatched quotes"\'')
    assert is_quoted("'mismatched quotes\"'")
    assert is_quoted('\'double quotes"\'')
    assert is_quoted('\'mismatched quotes"\'')
    assert is_quoted("'mismatched quotes'\"")

    # Test False cases
    assert not is_quoted('mismatched quotes"')
    assert not is_quoted('mismatched quotes\'')
    assert not is_quoted('"mismatched quotes')
    assert not is_quoted("'mismatched quotes")
    assert not is_quoted('"mismatched quotes\'')
    assert not is_quoted("'mismatched quotes\"")