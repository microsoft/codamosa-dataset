

# Generated at 2022-06-23 05:00:58.540103
# Unit test for function is_quoted
def test_is_quoted():
  assert is_quoted('"a"')  == True
  assert is_quoted('\'a\'')== True
  assert is_quoted('a')    == False
  assert is_quoted('\'a')  == False
  assert is_quoted('a\'')  == False
  assert is_quoted('"a')   == False
  assert is_quoted('a"')   == False
  assert is_quoted('"')    == False
  assert is_quoted('"a\\"')  == False
  assert is_quoted('"a\\\\"')  == False
  assert is_quoted('"a\\\'"')  == False
  assert is_quoted('"a\\\\\'"')== False


# Generated at 2022-06-23 05:01:10.969969
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('abc')
    assert not is_quoted("'ab'c'")
    assert is_quoted("'ab'\"c'")
    assert unquote("'ab'\"c'") == "'ab'\"c'"
    assert unquote("'ab''c'") == "ab'c"
    assert unquote("''abc''") == "abc"
    assert unquote("'ab\"c'") == 'ab"c'
    assert unquote("\"ab'c\"") == "ab'c"

# Generated at 2022-06-23 05:01:15.893183
# Unit test for function is_quoted
def test_is_quoted():
    is_quoted_test_data = {
        '"testing': False,
        'testing"': False,
        '"testing"': True,
        '"test\\"ing"': False,
        '"test\\\\"': True,
    }

    for test in is_quoted_test_data:
        yield is_quoted_test, test, is_quoted_test_data[test]


# Generated at 2022-06-23 05:01:21.744181
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo\\""') == 'foo"'
    assert unquote('\'foo"\'') == 'foo"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'
    assert unquote('\\\\"foo\\\\"') == '\\"foo\\"'


# Generated at 2022-06-23 05:01:28.892938
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted(None)
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('foo\'bar')
    assert not is_quoted('foo\'bar')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")



# Generated at 2022-06-23 05:01:35.221743
# Unit test for function unquote
def test_unquote():
    assert unquote("'a'") == "a"
    assert unquote("\"a\"") == "a"
    assert unquote("'a'\"double\"") == "a\"double\""
    assert unquote("'a'\"double\"'quotes'") == "a\"double\"'quotes'"
    assert unquote('"a\'single quote"') == "a'single quote"
    assert unquote("'a\"double quote'") == "a\"double quote"


# Generated at 2022-06-23 05:01:39.012115
# Unit test for function unquote
def test_unquote():
    assert(unquote("'data'") == "data")
    assert(unquote("\"data\"") == "data")
    assert(unquote("'data\"") == "'data\"")
    assert(unquote("\"data'") == "\"data'")
    assert(unquote("data") == "data")

# Generated at 2022-06-23 05:01:44.589110
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('"""test"""') == True
    assert is_quoted('"test\\""') == True
    assert is_quoted('"test""') == False
    assert is_quoted('test""') == False
    assert is_quoted('"test') == False
    assert is_quoted('test\\"') == False
    assert is_quoted('test\\test2') == False


# Generated at 2022-06-23 05:01:53.913473
# Unit test for function unquote
def test_unquote():
    if not unquote("\''") == "\''":
        raise AssertionError("unit test for unquote() failed")
    if not unquote("'test'") == "test":
        raise AssertionError("unit test for unquote() failed")
    if not unquote('"test"') == "test":
        raise AssertionError("unit test for unquote() failed")
    if not unquote('a"test"') == 'a"test"':
        raise AssertionError("unit test for unquote() failed")
    if not unquote('"test\'"') == '"test\'"':
        raise AssertionError("unit test for unquote() failed")
    print("unquote() unit tests passed")

test_unquote()

# Generated at 2022-06-23 05:01:59.745036
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("foo") == False
    assert is_quoted("'foo\'") == False
    assert is_quoted("\"foo\"") == True
    assert is_quoted("\"foo\'") == False


# Generated at 2022-06-23 05:02:02.958246
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('\'hello\'')
    assert not is_quoted('hello')
    assert not is_quoted('hello\'')


# Generated at 2022-06-23 05:02:13.074825
# Unit test for function unquote
def test_unquote():
    assert unquote('"a string"') == 'a string'
    assert unquote("'a string'") == 'a string'
    assert unquote('a string') == 'a string'
    assert unquote("'''a string'''") == "'a string'"
    assert unquote('"""a string"""') == '"a string"'
    assert unquote("'a \\\"string'") == 'a \\"string'
    assert unquote("'a \\\\string'") == "a \\string"
    assert unquote("'a \\nstring'") == "a \nstring"
    assert unquote("'a \\\'string'") == "a 'string"
    assert unquote("'a \\\\\\string'") == "a \\string"
    assert unquote('"') == '"'

# Generated at 2022-06-23 05:02:24.176223
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'a'") == True
    assert is_quoted("'a\\'") == True  # False positive, but matches behaviour of unquote
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"a\\\"") == True  # False positive, but matches behaviour of unquote

    assert is_quoted("'a") == False
    assert is_quoted("a'") == False
    assert is_quoted("'a\\'") == False
    assert is_quoted("\"a") == False
    assert is_quoted("a\"") == False
    assert is_quoted("\"a\\\"") == False

    assert is_quoted("'a\\'\"") == False
    assert is_quoted("\"a\\\"'") == False
    assert is_qu

# Generated at 2022-06-23 05:02:32.854904
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string with quotes"')
    assert is_quoted('"string with escaped quote \" string"')
    assert is_quoted("'string with escaped quote \\' string'")
    assert is_quoted("'string with quotes'")
    assert is_quoted("\"string with escaped quote \\\" string\"")
    assert is_quoted("'string with escaped quote \\\\\' string'")
    assert not is_quoted("'string with escaped quote \" string'")
    assert not is_quoted('"string with escaped quote \\\' string"')
    assert not is_quoted("string with trailing quote'")
    assert not is_quoted("'string with leading quote")


# Generated at 2022-06-23 05:02:36.968054
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('"abcdef"')
    assert True == is_quoted("'abcdef'")
    assert False == is_quoted('abcdef')


# Generated at 2022-06-23 05:02:42.568370
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("'foo bar") == "'foo bar"
    assert unquote("foo bar'") == "foo bar'"
    assert unquote("'foo bar\"") == "'foo bar\""
    assert unquote("\"foo bar'") == "\"foo bar'"
    assert unquote("\"foo bar\"") == 'foo bar'
    assert unquote('\"foo bar\"') == 'foo bar'
    assert unquote('\"foo bar\"') == "foo bar"


# Generated at 2022-06-23 05:02:47.730900
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('') == False
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo\\""') == False
    assert is_quoted('"foo\\\\""') == True


# Generated at 2022-06-23 05:02:53.805254
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"John"') == True
    assert is_quoted('"John') == False
    assert is_quoted('John"') == False
    assert is_quoted('John') == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False
    assert is_quoted('John" "Doe') == False
    assert is_quoted('"John""') == False


# Generated at 2022-06-23 05:02:58.422250
# Unit test for function unquote
def test_unquote():
    data_in = '"this is a test"'
    data_out = 'this is a test'
    assert unquote(data_in) == data_out


# Generated at 2022-06-23 05:03:05.758702
# Unit test for function unquote
def test_unquote():
    # Case 1: starting and end quote are the same
    # Case 1.1: double quote
    assert unquote('"hello"') == 'hello'
    # Case 1.2: single quote
    assert unquote("'hello'") == 'hello'
    # Case 2: starting and end quote are not the same
    assert unquote("'hello") == "'hello"
    assert unquote('"hello') == '"hello'
    # Case 3: there are no starting and end quote
    assert unquote('hello') == 'hello'
    # Case 4: there is one starting and end quote
    assert unquote('"hello') == '"hello'

# Generated at 2022-06-23 05:03:14.892153
# Unit test for function unquote
def test_unquote():
    assert 'foo' == unquote('"foo"')
    assert 'foo' == unquote('"foo')
    assert '"foo"' == unquote('"""foo"""')
    assert 'foo' == unquote("'foo'")
    assert 'foo bar' == unquote('foo bar')


# Generated at 2022-06-23 05:03:22.580779
# Unit test for function unquote
def test_unquote():
    assert is_quoted("''")
    assert is_quoted('""')
    assert is_quoted("'abc'")
    assert is_quoted('"abc"')
    assert not is_quoted("'a\\'bc'")
    assert not is_quoted('"a\\"bc"')
    assert unquote("'abc'") == "abc"
    assert unquote('"abc"') == "abc"
    assert unquote("'a\\'bc'") == "'a\\'bc'"
    assert unquote('"a\\"bc"') == '"a\\"bc"'
    assert unquote("\"'\"") == "\"'"

# Generated at 2022-06-23 05:03:27.652808
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote("'tes''t'") == "tes't"
    assert unquote('"tes""t"') == "tes\"t"

# Generated at 2022-06-23 05:03:35.804520
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('foo\'')
    assert not is_quoted('foo\'"bar')
    assert not is_quoted('foo"bar\'')
    assert is_quoted('foobar')
    assert is_quoted('"foobar"')
    assert is_quoted('"foobar')
    assert is_quoted('foobar"')
    assert is_quoted("'foobar'")
    assert is_quoted("'foobar")
    assert is_quoted("foobar'")
    assert is_quoted('"""foobar"""')

# Generated at 2022-06-23 05:03:40.448733
# Unit test for function unquote
def test_unquote():
    assert unquote("hello") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote('"hello') == '"hello'



# Generated at 2022-06-23 05:03:48.036013
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo\\"bar"') is True
    assert is_quoted("'foo\\'bar'") is True
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted('"foo\\"') is False
    assert is_quoted("'foo\\'") is False


# Generated at 2022-06-23 05:03:54.897826
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'     # simple outter quotes
    assert unquote('"foo bar"') == 'foo bar'   # embedded spaces
    assert unquote('"foo \'bar\'"') == 'foo \'bar\''   # embedded quotes
    assert unquote('"foo \\"bar\\""') == 'foo \\"bar\\"'   # escaped emedded quotes
    assert unquote('"foo bar"') == 'foo bar'   # embedded spaces
    assert unquote('"foo bar"') == 'foo bar'   # embedded spaces
    assert unquote('"foo bar"') == 'foo bar'   # embedded spaces
    assert unquote('\'"foo"\'') == '"foo"'     # quotes with outer single quotes
    assert unquote('\'"foo bar"\'') == '"foo bar"'   # quotes

# Generated at 2022-06-23 05:04:05.618781
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"val"')
    assert is_quoted("'val'")
    assert is_quoted("'val\\'") == False
    assert is_quoted("'val") == False
    assert is_quoted('"val') == False
    assert is_quoted('val"') == False
    assert is_quoted("val'") == False
    assert is_quoted('""') == False
    assert is_quoted("''") == False
    assert is_quoted('') == False
    assert is_quoted(None) == False
    assert is_quoted(False) == False
    assert is_quoted(True) == False
    assert is_quoted('"val""') == False
    assert is_quoted("'val''") == False

# Generated at 2022-06-23 05:04:13.412964
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"quoted"') == True
    assert is_quoted("'quoted'") == True
    assert is_quoted('"quoted\\"') == False
    assert is_quoted("'quoted\\'") == False

    assert unquote('"quoted"') == 'quoted'
    assert unquote("'quoted'") == 'quoted'
    assert unquote('"quoted\\"') == '"quoted\\"'
    assert unquote("'quoted\\'") == "'quoted\\'"


# Generated at 2022-06-23 05:04:24.075159
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'bar'") == 'bar'
    # make sure it plays nicely with string modules
    from string import digits as d, maketrans as m
    assert unquote(d.maketrans(d[10], d[0])) == d.translate(m(d[10], d[0]))
    # make sure it is idempotent
    assert unquote(unquote(unquote('""'))) == ''
    # make sure it doesn't unquote strings that don't start and end with the same quote
    assert unquote('"foobar\'') == '"foobar\''
    assert unquote('foo"') == 'foo"'
    assert unquote('""""') == '""'
    # make sure it doesn't unquote an uneven number

# Generated at 2022-06-23 05:04:29.750958
# Unit test for function unquote
def test_unquote():
    # Test normal case, no backslash escape
    assert unquote('"foo"') == 'foo'

    # Backslash escape quotes
    assert unquote('"foo\\"bar"') == 'foo\\"bar'

    # Quotes not at start and end of string
    assert unquote('"foo"bar"') == '"foo"bar"'


# Generated at 2022-06-23 05:04:39.550677
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test\\"quotes"') == 'test\\"quotes'
    assert unquote('test') == 'test'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"a""b"') == 'a""b'
    assert unquote('"a\'b"') == "a\'b"
    assert unquote("'a\"b'") == 'a"b'
    assert unquote("'a\'b'") == "a\'b"
    assert unquote('""""') == ''

# Backward compatible alias
un_quote = unquote

# Generated at 2022-06-23 05:04:43.172351
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"""test"""')
    assert is_quoted("'''test'''")
    assert not is_quoted('"test')
    assert not is_quoted("'test")


# Generated at 2022-06-23 05:04:54.624931
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted(u"") == False
    assert is_quoted(u"a") == False

    # Basic quote test
    assert is_quoted(u"'") == False
    assert is_quoted(u'"') == False
    assert is_quoted(u"'foo'") == True
    assert is_quoted(u'"foo"') == True

    # Escapes
    assert is_quoted(u"'foo\'bar'") == False
    assert is_quoted(u"'foo\\'bar'") == False
    assert is_quoted(u"'foo\\\"bar'") == False
    assert is_quoted(u"'foo\\\\bar'") == False

    # Quotes inside quotes
    assert is_quoted(u"'foo'bar'") == False

# Generated at 2022-06-23 05:05:06.606495
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('"foo" bar') == '"foo" bar'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo""bar"') == 'foo""bar'
    assert unquote('"""foo"""') == '"foo"'
    assert unquote(u'"foo" \u2713') == u'foo \u2713'
    assert unquote('"foo\\"bar"') == 'foo"bar'
    assert unquote('"foo \\\\\\n bar"') == 'foo \\\\n bar'
    assert unquote('"foo" "bar"') == 'foo" "bar'

# Generated at 2022-06-23 05:05:17.684919
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("this is a string")
    assert is_quoted("'this is a string'")
    assert not is_quoted("'this is a string")
    assert is_quoted("this is a string'")
    assert is_quoted("'this is a \"string\"'")
    assert is_quoted("\"this is a 'string'\"")
    assert not is_quoted("this is a \"string\"")
    assert not is_quoted("this is a 'string'")
    assert not is_quoted("'this is a \"string\"")
    assert not is_quoted("\"this is a 'string'\"")
    assert not is_quoted("'this is a \"string\"'\nother line")

# Generated at 2022-06-23 05:05:28.241584
# Unit test for function unquote
def test_unquote():
    assert unquote('"\\"\\"\\"') == '"""'
    ''' escaped backslash should not be unescaped. '''
    assert unquote('"\\"') == '"'
    assert unquote('\'"\'"\'') == '"""', unquote('\'"\'"\'')
    assert unquote('\'') == '\''
    assert unquote('"') == '"'
    assert unquote('"""') == '"""'
    assert unquote('') == ''

# Generated at 2022-06-23 05:05:31.886132
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote(" 'foo' ") == " 'foo' "



# Generated at 2022-06-23 05:05:35.844887
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('\"hello\"') == '\"hello\"'

# Generated at 2022-06-23 05:05:42.566919
# Unit test for function unquote
def test_unquote():
    # Test failure cases
    test_string = "This is quoted"
    assert (unquote(test_string) == test_string)

    test_string = "\"This is quoted"
    assert (unquote(test_string) == test_string)

    test_string = "This is not quoted\""
    assert (unquote(test_string) == test_string)

    # Test success case
    test_string = '"This is quoted"'
    assert (unquote(test_string) == "This is quoted")

# Generated at 2022-06-23 05:05:49.560394
# Unit test for function unquote
def test_unquote():
    assert(unquote("'Hello world'") == 'Hello world')
    assert(unquote("Hello world") == 'Hello world')
    assert(unquote("") == '')
    assert(unquote("'Hello world") == "'Hello world")
    assert(unquote("Hello world'") == "Hello world'")
    assert(unquote("'Hello world\"") == "'Hello world\"")
    assert(unquote("\"Hello world'") == "\"Hello world'")
    assert(unquote("\"Hello world\"") == 'Hello world')


# Generated at 2022-06-23 05:05:54.878762
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('hello') == "hello"
    assert unquote('"hello') == "hello"
    assert unquote('hello"') == "hello"

# Generated at 2022-06-23 05:06:00.242833
# Unit test for function unquote
def test_unquote():
    assert(unquote('"test string"') == 'test string')
    assert(unquote("'test string'") == 'test string')
    assert(unquote("'test string") == "'test string")
    assert(unquote("test string'") == "test string'")
    assert(unquote("'test string\"") == "'test string\"")

# TODO: move this function to utils3

# Generated at 2022-06-23 05:06:10.509252
# Unit test for function unquote
def test_unquote():
    # test simple types
    assert None == unquote(None)
    assert True == unquote(True)
    assert False == unquote(False)
    assert 0 == unquote(0)
    assert 'string' == unquote('string')

    # test unquoted string
    assert 'string' == unquote('string')

    # test quoted string
    assert 'string' == unquote('"string"')
    assert "string's" == unquote("\"string's\"")
    assert 'str,ing' == unquote("'str,ing'")

    # test quote escaping in quoted string
    assert 'str"ing' == unquote("\"str\\\"ing\"")
    assert "str'ing" == unquote("\"str\\'ing\"")

    # test unquoted string with quotes at end
    assert "string\"" == un

# Generated at 2022-06-23 05:06:20.968679
# Unit test for function is_quoted
def test_is_quoted():
    # This is a list of tuples, each tuple has a value and a result
    # The result is what is_quoted should return when called with the value.
    # Example: (r'"foo"' , True)
    # This means that is_quouted(r'"foo"') should return True
    tests = [
        (r"'foo'", True),
        (r'"foo"', True),
        (r'""', True),
        (r"''", True),
        (r"'foo bar'", True),
        (r'"foo bar"', True),
        (r"'foo", False),
        (r'"foo', False),
        (r'foo"', False),
        (r'foo"', False),
        (r"'foo 'bar'", False),
        (r'"foo "bar"', False),
    ]

# Generated at 2022-06-23 05:06:27.431121
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")

    assert not is_quoted('"abc"d')
    assert not is_quoted("'abc'd")

    assert not is_quoted('"ab\"c"')
    assert not is_quoted('"ab\'c"')

    assert not is_quoted('\'"abc"\'')


# Generated at 2022-06-23 05:06:32.778853
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("hello") == "hello"


# Generated at 2022-06-23 05:06:43.526278
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') is False
    assert is_quoted('"') is False
    assert is_quoted('""""') is False
    assert is_quoted('""a"') is False
    assert is_quoted('"a""') is False
    assert is_quoted('') is False
    assert is_quoted('"\\""') is False
    assert is_quoted('"a"') is True
    assert is_quoted("'a'") is True
    assert is_quoted("''a''") is False
    assert is_quoted("'\\''") is False
    assert is_quoted("a'b'a") is False


# Generated at 2022-06-23 05:06:54.465259
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("test")
    assert not is_quoted("\"test\\\"")
    assert not is_quoted("%test%")
    assert not is_quoted("%test\\%")
    assert not is_quoted("%test%\\")
    assert not is_quoted("%test\\%\\")
    assert not is_quoted("%test\\\\%")
    assert not is_quoted("test%test%test")
    assert is_quoted("\"test\"")
    assert is_quoted("'test'")
    assert is_quoted("'test\\''")
    assert is_quoted("%test%")
    assert is_quoted("%test\\%")
    assert is_quoted("%test%\\")
    assert is_quoted("%test\\%\\")


# Generated at 2022-06-23 05:06:57.876462
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('test') == False
    assert is_quoted('"test"') == True
    assert is_quoted('"te\'"st"') == False
    assert is_quoted('''"te"st"''') == False


# Generated at 2022-06-23 05:07:06.319803
# Unit test for function is_quoted
def test_is_quoted():
    # True
    assert is_quoted('"bob"')
    assert is_quoted("'bob'")
    assert is_quoted("'bob \"foo\"'")
    assert is_quoted("\"bob 'foo'\"")
    assert is_quoted("\"bob 'foo'\"")
    assert is_quoted('"bob \'foo\'"')
    assert is_quoted("\"bob \'foo\'\"")
    assert not is_quoted("'bob \'foo\'\"")
    assert not is_quoted('"bob \'foo\'')
    assert not is_quoted('"bob \'foo\'"')
    # False
    assert not is_quoted('bob')
    assert not is_quoted('"bob')

# Generated at 2022-06-23 05:07:13.479913
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("'foo' 'bar") == False
    assert is_quoted("'foo' 'bar'") == False
    assert is_quoted("'foo''bar'") == False
    assert is_quoted("'foo\"bar'") == False
    assert is_quoted("\"foo\"") == True
    assert is_quoted("\"foo\\\"bar\"") == True


# Generated at 2022-06-23 05:07:25.051472
# Unit test for function unquote
def test_unquote():
    string = "'''"
    assert unquote(string) == string
    string = "'abc"
    assert unquote(string) == string
    string = "abc'"
    assert unquote(string) == string
    string = "'abc'"
    assert unquote(string) == 'abc'
    string = "''abc''"
    assert unquote(string) == "''abc''"
    string = "\"\"\""
    assert unquote(string) == string
    string = "\"abc"
    assert unquote(string) == string
    string = "abc\""
    assert unquote(string) == string
    string = "\"abc\""
    assert unquote(string) == 'abc'
    string = "\"\"abc\"\""
    assert unquote(string) == "\"\"abc\"\""

# Generated at 2022-06-23 05:07:33.284012
# Unit test for function is_quoted
def test_is_quoted():
    def _assert_is_quoted(data, expected):
        actual = is_quoted(data)
        assert actual == expected, "actual: %s, expected: %s" % (actual, expected)

    _assert_is_quoted('123456789', False)
    _assert_is_quoted('"123456789"', True)
    _assert_is_quoted('\'123456789\'', True)
    _assert_is_quoted('"12345678\\"9"', True)
    _assert_is_quoted('"12345678\\\\"9"', True)


# Generated at 2022-06-23 05:07:42.120458
# Unit test for function unquote
def test_unquote():
    assert unquote("no") == "no"
    assert unquote("'yes'") == "yes"
    assert unquote("\"yes\"") == "yes"
    assert unquote("'no'") == "no"
    assert unquote("\"no\"") == "no"
    assert unquote("\\'yes\\'") == "\\'yes\\'"
    assert unquote("\\\"yes\\\"") == "\\\"yes\\\""
    assert unquote("\"\\\"yes\\\"\"") == '"yes"'
    assert unquote("'\\'yes\\''") == "'yes'"



# Generated at 2022-06-23 05:07:49.310883
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo\\""') == '"foo"'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\'') == '"foo\''
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\\''") == "'foo'"
    assert unquote("'foo\"'") == 'foo"'

# ------------------------------------------------------------------------------


# Generated at 2022-06-23 05:07:59.373874
# Unit test for function unquote
def test_unquote():
    import sys
    import os
    import subprocess
    import tempfile

    (fd, tmp_file) = tempfile.mkstemp()
    os.close(fd)
    my_file = open(tmp_file, 'w')


# Generated at 2022-06-23 05:08:08.947053
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'hello'") == True)
    assert(is_quoted("'hello") == False)
    assert(is_quoted("hello'") == False)
    assert(is_quoted("'hello\"") == False)
    assert(is_quoted("\"hello\"") == True)
    assert(is_quoted("\"hello") == False)
    assert(is_quoted("hello\"") == False)
    assert(is_quoted("\"hello'") == False)
    assert(is_quoted("'''hello'") == False)
    assert(is_quoted("'''hello'''") == True)
    assert(is_quoted("'''hello") == False)
    assert(is_quoted("hello'''") == False)

# Generated at 2022-06-23 05:08:15.765692
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('"foo"') == True
    assert is_quoted("''") == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"""') == False
    assert is_quoted('"foo') == False
    assert is_quoted("'''") == False
    assert is_quoted("'foo") == False


# Generated at 2022-06-23 05:08:16.378823
# Unit test for function unquote
def test_unquote():
    test

# Generated at 2022-06-23 05:08:22.980691
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'spam'") == True)
    assert(is_quoted("x'x") == False)
    assert(is_quoted("\"x\"") == True)
    assert(is_quoted("'x'x") == False)
    assert(is_quoted("'x") == False)
    assert(is_quoted("x'") == False)
    assert(is_quoted("x") == False)
    assert(is_quoted("'") == False)
    assert(is_quoted("'a\\'b'") == True)



# Generated at 2022-06-23 05:08:28.699966
# Unit test for function unquote
def test_unquote():
    assert(unquote('"hello world"') == "hello world")
    assert(unquote("'hello world'") == "hello world")
    assert(unquote("'hello world") == "'hello world")
    assert(unquote('"hello world') == '"hello world')
    assert(unquote("hello world") == "hello world")
    assert(unquote("'hello\\' world'") == "'hello\\' world'")


# Generated at 2022-06-23 05:08:37.649270
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\\"bc"') == 'a"bc'
    assert unquote("'a\\'bc'") == "a'bc"
    assert unquote('') == ''
    assert unquote('''"'a\\'bc'"''') == "a'bc"

# Generated at 2022-06-23 05:08:47.203489
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'this'")
    assert is_quoted("'this") == False
    assert is_quoted("this'") == False
    assert is_quoted("\"this\"")
    assert is_quoted("\"this") == False
    assert is_quoted("this\"") == False
    assert is_quoted("\"\"") == False
    assert is_quoted("''") == False
    assert is_quoted("'Don\\'t'")
    assert is_quoted("'Don\\'t") == False
    assert is_quoted("'") == False
    assert is_quoted("'thi") == False
    assert is_quoted("'thi\\") == False
    assert is_quoted("'thi\\'") == False

# Generated at 2022-06-23 05:08:54.411281
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo\'"') == False
    assert is_quoted('"foo\\"') == False
    assert is_quoted('"foo"bar"') == False
    assert is_quoted("'foo'") == True
    assert is_quoted("''") == True
    assert is_quoted("'foo") == False

    assert is_quoted("`foo'") == False
    assert is_quoted("foo\"") == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo") == False
    assert is_quoted("foo\\") == False
    assert is_quoted("foo") == False
    assert is_quoted("foo bar") == False

# Generated at 2022-06-23 05:08:59.692823
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('h"ello') == 'h"ello'
    assert unquote("h'ello") == "h'ello"
    assert unquote("'h\"ello'") == "h\"ello"


# Generated at 2022-06-23 05:09:07.596330
# Unit test for function unquote
def test_unquote():
    cases = [
        ('"hello"', "hello"),
        ('\'hello\'', "hello"),
        ('"hello', '"hello'),
        ('\'hello', '\'hello'),
        ('hello"', 'hello"'),
        ('hello\'', 'hello\''),
        ('"hello\'"', '"hello\'"'),
        ('"hello\""', "hello\""),
        ('"\"hello"', '"\"hello"'),
    ]

    for test, expected in cases:
        result = unquote(test)
        assert result == expected

# Generated at 2022-06-23 05:09:18.758179
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"""') == False
    assert is_quoted('\\"') == False
    assert is_quoted('\\\\\\"') == False
    assert is_quoted('""""') == False

    assert is_quoted('"a"') == True
    assert is_quoted('"\\a"') == True
    assert is_quoted('"\\\\a"') == True
    assert is_quoted('"\\""') == True
    assert is_quoted('"\\\\""') == True

    assert is_quoted("'a'") == True
    assert is_quoted("'\\a'") == True
    assert is_quoted("'\\\\a'") == True

# Generated at 2022-06-23 05:09:27.665123
# Unit test for function is_quoted
def test_is_quoted():
    ''' function is_quoted.py should detect if a string starts and ends with the same quotes '''

    s = 'test'
    assert not is_quoted(s) # should return False

    s = '"test"'
    assert is_quoted(s) # should return True

    s = '\'test\''
    assert is_quoted(s) # should return True

    s = '"test\''
    assert not is_quoted(s) # should return False

    s = '"test\\"'
    assert not is_quoted(s) # should return False

    s = '"test\""'
    assert is_quoted(s) # should return True

# Generated at 2022-06-23 05:09:38.116513
# Unit test for function unquote
def test_unquote():
    assert unquote('""')                                                  == ''
    assert unquote('"abc"')                                               == 'abc'
    assert unquote('abc')                                                 == 'abc'
    assert unquote('"abc')                                                == '"abc'
    assert unquote('abc"')                                                == 'abc"'
    assert unquote('"a\\"bc"')                                            == 'a\\"bc'
    assert unquote('"a\\\\bc"')                                           == 'a\\\\bc'
    assert unquote('"a\"bc"')                                             == 'a"bc'
    assert unquote('"a\\\\\"bc"')                                         == 'a\\\\\"bc'
    assert unquote('"a\\\\\\"bc"')                                        == 'a\\\\\\"bc'

# Generated at 2022-06-23 05:09:48.462608
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted('"hello"'):
        raise AssertionError('the string "hello" is quoted')
    if not is_quoted("'hello'"):
        raise AssertionError("the string 'hello' is quoted")
    if is_quoted('"hello'):
        raise AssertionError('the string "hello is not quoted')
    if is_quoted("'hello"):
        raise AssertionError("the string 'hello is not quoted")
    if is_quoted("'he\"ll\"o'"):
        raise AssertionError("the string 'he\"ll\"o' is not quoted")
    if is_quoted("'he'll'o'"):
        raise AssertionError("the string 'he'll'o' is not quoted")


# Generated at 2022-06-23 05:09:59.222882
# Unit test for function unquote
def test_unquote():
    for q in ('"', "'"):
        assert unquote(q + "foo" + q) == "foo"
        assert unquote(q + "foo" + q + "bar" + q) == "foo" + q + "bar"
        assert unquote(q + "foo" + q + "bar") == "foobar"
        assert unquote("foo" + q + "bar" + q + "baz" + q) == "foobarbaz"
        assert unquote("foo" + q + "bar" + q) == "foobar"
        assert unquote("foo") == "foo"
        assert unquote("foo" + q + "bar") == "foobar"
        assert unquote(q + "foo") == q + "foo"
        assert unquote(q + q) == q

# Generated at 2022-06-23 05:10:04.966408
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"joe"')
    assert is_quoted("'joe'")
    assert not is_quoted('joe')
    assert not is_quoted('"joe')
    assert not is_quoted("'joe")
    assert not is_quoted('\"joe')
    assert not is_quoted("\'joe")
    assert not is_quoted('"joe\"')
    assert not is_quoted("\'joe\'")


# Generated at 2022-06-23 05:10:11.938499
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"a"')
    assert is_quoted('"a\\"b"')
    assert is_quoted("'a'")
    assert is_quoted("'a\\'b'")

    assert not is_quoted('"a\\"')
    assert not is_quoted('\\a"')
    assert not is_quoted('a"')
    assert not is_quoted('a')


# Generated at 2022-06-23 05:10:21.272451
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("test")
    assert not is_quoted("'test\\'")
    assert is_quoted("\"'test'\"")
    assert is_quoted("\"\\\"'test'\"")
    assert not is_quoted("\"'test\"")
    assert not is_quoted("\"test'\"")
    assert not is_quoted("\"test\"")
    assert not is_quoted("\"'test\\\"")



# Generated at 2022-06-23 05:10:24.236726
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote('\'hello world\'') == 'hello world'
    assert unquote('hello world') == 'hello world'

# Generated at 2022-06-23 05:10:30.421183
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo\\"') == '"foo\\"'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\\'") == "'foo\\'"
    assert unquote("foo") == "foo"

# Generated at 2022-06-23 05:10:35.474067
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test"test') == '"test"test'
    assert unquote("'test'") == 'test'
    assert unquote("'test'test") == "'test'test"


# from http://stackoverflow.com/a/16696317

# Generated at 2022-06-23 05:10:42.620759
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote("'hello world") != "hello world"
    assert unquote("hello world") == "hello world"
    assert unquote("'hello 'world") == "'hello 'world"
    assert unquote("'hello \\'world'") == "'hello \\'world"

# Generated at 2022-06-23 05:10:44.856685
# Unit test for function unquote
def test_unquote():
    if unquote("'test'") != 'test':
        raise AssertionError("unquote failed")


# Generated at 2022-06-23 05:10:52.360593
# Unit test for function unquote
def test_unquote():
    assert unquote("foobar") == "foobar"
    assert unquote("'foobar'") == "foobar"
    assert unquote('"foobar"') == "foobar"
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote("\\'foobar") == "\\'foobar"
    assert unquote("\"foo\"bar\"") == "\"foo\"bar\""
    assert unquote("\"foo\\\"bar\"") == "foo\\\"bar"


# DEPRECATED