

# Generated at 2022-06-23 05:00:55.149589
# Unit test for function is_quoted
def test_is_quoted():
    # By design, it does not handle escaped characters
    assert not is_quoted('foo')
    assert not is_quoted('\'foo\'')
    assert not is_quoted('"foo"')
    assert not is_quoted('"foo\'"')
    assert not is_quoted('\'foo"')

    assert is_quoted('"foo"')
    assert is_quoted('\'"foo\'"')

    assert not is_quoted('"foo\\"foo"')
    assert not is_quoted('\'foo\\"foo\'')
    assert not is_quoted('"foo\'foo"')
    assert not is_quoted('"foo\'foo')
    assert not is_quoted('\'foo\'foo"')
    assert not is_quoted('\'foo"foo')
    assert is_qu

# Generated at 2022-06-23 05:01:02.935550
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('"a\\""') == 'a"'
    assert unquote('\'"a"\'') == '"a"'
    assert unquote('\'"a\\"\'') == '"a"'
    assert unquote('"\\"a\\""') == '\\"a\\"'

# Here start the functions that raise error on invalid YAML
# (but only if strict: yes)


# Generated at 2022-06-23 05:01:09.480260
# Unit test for function unquote
def test_unquote():
    assert unquote(u'"foobar"') == u'foobar'
    assert unquote(u'foobar') == u'foobar'
    assert unquote(u'''"foo\"bar"''') == u'''"foo\"bar"'''
    assert unquote(u'''foobar''') == u'''foobar'''
    assert unquote(u'\'"foobar"\'') == u'\'"foobar"\''


# Generated at 2022-06-23 05:01:15.700130
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo\\\"bar"')
    assert is_quoted("'foo'")
    assert is_quoted("'foo\\\'bar'")
    assert not is_quoted('"foo\\\"bar"baz')
    assert not is_quoted(' \\"foo\\" ')
    assert not is_quoted('"')
    assert not is_quoted('foo')
    assert not is_quoted('')


# Generated at 2022-06-23 05:01:22.563820
# Unit test for function unquote
def test_unquote():
    # Test all possible quotes
    cases = [
      ('test', 'test'),
      ('test"', 'test"'),
      ('test\\"', 'test\\"'),
      ('"test', '"test'),
      ('\\"test', '\\"test'),
      ('""test""', '"test"'),
      ('"""test"""', '"""test"""'),
      ('"""test', '"""test"'),
      ('test\\""', 'test\\""'),
      ('test""', 'test""')
    ]
    for (value, expected) in cases:
        assert(expected == unquote(value))

# Generated at 2022-06-23 05:01:26.285252
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test\\""') == '"test"'
    assert unquote('') == ''
    assert unquote('\\""') == '\\"'

# Generated at 2022-06-23 05:01:32.803660
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'

    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"
    assert unquote('foo\\bar') == 'foo\\bar'


# Generated at 2022-06-23 05:01:39.974955
# Unit test for function is_quoted
def test_is_quoted():
    # test string without quotes
    data = "unquoted string"
    assert not is_quoted(data)

    # test string with quotes but where the second to last char is a \
    data = "'quoted string with \\\"single quotes\\\"'"
    assert not is_quoted(data)

    # test string with single quotes
    data = "'quoted string with \'single quotes\''"
    assert is_quoted(data)

    # test string with double quotes
    data = '"quoted string with \"double quotes\""'
    assert is_quoted(data)



# Generated at 2022-06-23 05:01:48.865958
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"') == 'foo"'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\\'") == "foo'"
    assert unquote("'foo\\''") == "foo'"
    assert unquote("'foo\\'bar'") == "foo'bar"
    assert unquote("'foo\\\"bar'") == "foo\"bar"
    assert unquote("'foo\\\\bar'") == "foo\\bar"
    assert unquote("'foo\nbar'") == "foo\nbar"
    assert unquote("foo\\nbar") == "foo\\nbar"

# Generated at 2022-06-23 05:01:59.696691
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("abc")           == False, "abc is not quoted"
    assert is_quoted("\"abc\"")       == True, "\"abc\" is quoted"
    assert is_quoted("\"abc")         == False, "\"abc is not quoted"
    assert is_quoted("  \"abc\"  ")   == True, "\"abc\" enclosed in spaces is quoted"
    assert is_quoted("\'abc'")        == True, "\"abc\" is quoted"
    assert is_quoted("\"abc'")        == False, "\"abc is not quoted"
    assert is_quoted("\"a\\\"bc\"")   == True, "\"a\\\"bc\" is quoted"
    assert is_quoted("\"a\\\"bc")     == False, "\"a\\\"bc is not quoted"

#

# Generated at 2022-06-23 05:02:04.285810
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"bar"') == 'bar'
    assert unquote(r'"foo\""') == r'"foo\"'
    assert unquote(r'"foo\""') != r'foo\"'
    assert unquote('"foo" and "bar"') == '"foo" and "bar"'

# Generated at 2022-06-23 05:02:14.305596
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('abc') == False
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('"""') == False
    assert is_quoted('"abc') == False
    assert is_quoted("'a\"bc'") == True
    assert is_quoted('"a\\bc"') == False



# Generated at 2022-06-23 05:02:17.262732
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foobar'")
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar") is False


# Generated at 2022-06-23 05:02:19.515266
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted('''"hello"''') == Tru

# Generated at 2022-06-23 05:02:24.663594
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('\'test\'')
    assert is_quoted('"test\\""')
    assert is_quoted('\'test\'\'')
    assert not is_quoted('test')
    assert not is_quoted('"test\'')
    assert not is_quoted('\'test"')


# Generated at 2022-06-23 05:02:36.382595
# Unit test for function is_quoted
def test_is_quoted():
    data_set = [
      ("'asdf'", True),
      ('"asdf"', True),
      ("'a\\'s\\'d\\'f'", False),
      ('"a\\"s\\"d\\"f"', False),
      ("'asdf'asdf", False),
      ("asdf'asdf'", False),
      ("a\\'s\\'d\\'f'", False),
    ]

    for data, expected in data_set:
        result = is_quoted(data)
        if result != expected:
            raise AssertionError("%s failed, expected %s and got %s" % (data, expected, result))


# Generated at 2022-06-23 05:02:41.767113
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"\\"foo\\""') == '"foo"'
    assert unquote("'''foo'''") == "'foo'"
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote('foo') == 'foo'



# Generated at 2022-06-23 05:02:43.954178
# Unit test for function is_quoted
def test_is_quoted():
    '''
    Basic test for the function is_quoted.
    '''
    assert is_quoted('"foobar"')
    assert not is_quoted('"foobar')



# Generated at 2022-06-23 05:02:51.121659
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('\'test\'') == 'test'
    assert unquote('test') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('"test\'s"') == 'test\'s'
    assert unquote('"test\'s"') == "test's"
    assert unquote('"test\\"s"') == 'test\\"s'

# Generated at 2022-06-23 05:02:58.764567
# Unit test for function is_quoted
def test_is_quoted():
    # Test Quoted Strings
    assert(is_quoted('"foobar"') is True)
    assert(is_quoted("'foobar'") is True)
    assert(is_quoted("'foo'bar'") is False)

    # Test strings with escaped quotes
    assert(is_quoted('"foo\"bar"') is False)
    assert(is_quoted("'foo\'bar'") is False)

    # Test single character (non quoted) strings
    assert(is_quoted("f") is False)
    assert(is_quoted("'") is False)
    assert(is_quoted("\"") is False)

    # Test empty string
    assert(is_quoted("") is False)


# Generated at 2022-06-23 05:03:04.681021
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'test'")
    assert unquote("'test'") == "test"

    assert is_quoted('"test"')
    assert unquote('"test"') == "test"

    assert not is_quoted("test")
    assert unquote("test") == "test"

    assert unquote('"testing \\"escape\\""') == 'testing "escape"'
    assert unquote("'testing \\\'escape\\\''") == "testing 'escape'"



# Generated at 2022-06-23 05:03:19.387576
# Unit test for function is_quoted
def test_is_quoted():
    # Test string
    assert is_quoted('test') == False
    assert is_quoted('"test"') == True
    assert is_quoted('\'test\'') == True
    assert is_quoted('\'test') == False
    assert is_quoted('test\'') == False
    assert is_quoted('"test') == False
    assert is_quoted('te"st') == False
    assert is_quoted('te\'st') == False
    # Test escaped quote
    assert is_quoted('"test\\""') == True
    assert is_quoted('\'test\\""') == False
    assert is_quoted('\'test\\\'\'') == True
    assert is_quoted('"test\\\'""') == False


# Generated at 2022-06-23 05:03:29.329433
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('he"h') == False
    assert is_quoted('he\'h') == False
    assert is_quoted('"helo"h') == False
    assert is_quoted('"he\\"h') == False
    assert is_quoted('"he\\\\"h') == False
    assert is_quoted('"he\\\\\\"h') == False
    assert is_quoted('"he\\\\"h') == False
    assert is_quoted('""he"h') == False
    assert is_quoted('"he"h""') == False
    assert is_quoted('') == False
    assert is_quoted(None) == False


# Generated at 2022-06-23 05:03:39.304391
# Unit test for function is_quoted
def test_is_quoted():
    ''' unquote should correctly identify if quoted or not '''
    assert is_quoted("'test'")
    assert not is_quoted("'test")
    assert is_quoted('"test"')
    assert not is_quoted('"test')
    assert is_quoted('"""test"""')
    assert is_quoted("'''test'''")
    assert not is_quoted("''test'''")
    assert not is_quoted("''test'")
    assert not is_quoted("'test''")
    assert not is_quoted('"""test')
    assert not is_quoted("'''test")


# Generated at 2022-06-23 05:03:49.231188
# Unit test for function unquote
def test_unquote():
    '''
    Test the unquote function.
    '''
    tests = [
        # input     # expected output
        [ 'u"foo"',    'foo' ],
        [ '"foo"',     'foo' ],
        [ "'foo'",     'foo' ],
        [ '"foo',      '"foo' ],
        [ '"foo"bar"', '"foo"bar"' ],
        [ '"f\\"oo"',  'f\\"oo' ],
        [ 'f\\"oo"',   'f\\"oo"' ],
        [ '"f\\"oo"',  'f\\"oo' ],
        [ '\\"foo"',   '\\"foo"']
    ]

    for test_input, expected_output in tests:
        output = unquote(test_input)

# Generated at 2022-06-23 05:03:53.712915
# Unit test for function unquote

# Generated at 2022-06-23 05:03:58.558473
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("test'") == "test'"
    assert unquote("'test") == "'test"
    assert unquote("\"test\"") == "test"
    assert unquote("'test'") == "test"


# Generated at 2022-06-23 05:04:03.330706
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"fo\\"o"') == 'fo\\"o'
    assert unquote("'fo\\'o'") == 'fo\\\'o'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-23 05:04:08.523132
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted('test"')
    assert not is_quoted("test")


# Generated at 2022-06-23 05:04:15.968748
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('"tes\"t"') == 'tes"t'
    assert unquote('"te\'st"') == 'te\'st'

# Generated at 2022-06-23 05:04:21.139211
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"test\\"') == False
    assert is_quoted("'test\\'") == False
    assert is_quoted('"test\\""')
    assert is_quoted("'test\\''")


# Generated at 2022-06-23 05:04:27.009535
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted('"foo')
    assert not is_quoted('foo')
    assert not is_quoted('"foo\\"')


# Generated at 2022-06-23 05:04:31.439018
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('"foo\'s bar"') == "foo's bar"



# Generated at 2022-06-23 05:04:36.623773
# Unit test for function unquote
def test_unquote():
    assert unquote('"bam"') == 'bam'
    assert unquote('"b\'am"') == 'b\'am'
    assert unquote("'b\"am'") == 'b"am'
    assert unquote('bam') == 'bam'
    assert unquote("b'am") == "b'am"
    assert unquote('b"am') == 'b"am'


# Generated at 2022-06-23 05:04:39.859877
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('bar')
    assert is_quoted('"foo"bar"')
    assert is_quoted('"foo')
    assert is_quoted('foo"')

# Generated at 2022-06-23 05:04:43.665119
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"f\\"oo"') == 'f"oo'
    assert unquote("'f\\'oo'") == "f'oo"



# Generated at 2022-06-23 05:04:55.074971
# Unit test for function unquote

# Generated at 2022-06-23 05:05:01.415949
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""data"""') == True
    assert is_quoted("'''data'''") == True
    assert is_quoted('"data""') == False
    assert is_quoted("'data''") == False
    assert is_quoted('\\"data\\"') == False
    assert is_quoted("\\'data\\'") == False


# Generated at 2022-06-23 05:05:11.113556
# Unit test for function is_quoted
def test_is_quoted():
    '''
    make sure the is_quoted function returns true for single and double quoted strings
    without spaces inside
    '''
    assert(is_quoted('"hans"') == True)
    assert(is_quoted('"hans') == False)
    assert(is_quoted('\'hans\'') == True)
    assert(is_quoted('\'hans') == False)
    assert(is_quoted('hans') == False)
    assert(is_quoted('\'hans ') == False)
    assert(is_quoted('"hans ') == False)
    # Strings with escaped quotes
    assert(is_quoted('"hans\\""') == False)
    assert(is_quoted('"hans\\"') == False)

# Generated at 2022-06-23 05:05:18.493035
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"f\'oo"') == True
    assert is_quoted('"f\\"oo"') == True
    assert is_quoted('"f\\\\oo"') == True
    assert is_quoted('"f\\\\\\"oo"') == True


# Generated at 2022-06-23 05:05:24.910607
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Foo"')==True
    assert is_quoted("'Foo'")==True
    assert is_quoted('"Foo(bar)"')==True
    assert is_quoted("'Foo(bar)'")==True
    assert is_quoted('"Foo(bar)\\\\"')==True
    assert is_quoted('"Foo" with in-line spaces')==False
    assert is_quoted("'Foo' with in-line spaces")==False
    assert is_quoted('"Bar with Newline\n"')==False


# Generated at 2022-06-23 05:05:29.062209
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test\\"') == '"test\\"'
    assert unquote("'test\\'") == "'test\\'"
    assert unquote('test2') == 'test2'


# Generated at 2022-06-23 05:05:34.855021
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"blah"') == True
    assert is_quoted("'blah'") == True
    assert is_quoted('"blah\\"') == False
    assert is_quoted("'blah\\'") == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('"blah') == False
    assert is_quoted("'blah") == False



# Generated at 2022-06-23 05:05:38.109487
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello\'')
    assert not is_quoted('hello')



# Generated at 2022-06-23 05:05:43.796399
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted('"ab\'c"')
    assert is_quoted('"ab\\"c"')
    assert not is_quoted('"ab\\"c\\"')
    assert not is_quoted('\'"ab"c"')
    assert not is_quoted('"abc')
    assert not is_quoted('')


# Generated at 2022-06-23 05:05:45.966652
# Unit test for function unquote
def test_unquote():
    res = unquote('"hello"')
    assert res == "hello"
    res = unquote("'hello'")
    assert res == "hello"

# Generated at 2022-06-23 05:05:52.274468
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert is_quoted("'abc\\''")
    assert not is_quoted("'abc'xyz'")
    assert not is_quoted('"abc\\""')
    assert not is_quoted('abc')


# Generated at 2022-06-23 05:05:57.510213
# Unit test for function unquote
def test_unquote():
    assert 'test string' == unquote('"test string"')
    assert 'test string' == unquote("'test string'")
    assert 'test string"' == unquote('"test string"')
    assert 'test string"' == unquote('test string')

#
# This code is taken from ansible.vars.unsafe_proxy and is in the public domain.
#

# Generated at 2022-06-23 05:06:05.510754
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted("'hey'")
    assert is_quoted("'h\"e\"y'")
    assert is_quoted("'h\\'e\\'y'")
    assert is_quoted("\"hello\"")
    assert is_quoted("\"hey\"")
    assert is_quoted("\"h\'e\'y\"")
    assert is_quoted("\"h\\\"e\\\"y\"")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("''hello'")
    assert not is_quoted("'hello''")
    assert not is_quoted("hello")
    assert not is_quoted("\"hello")

# Generated at 2022-06-23 05:06:11.848989
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert is_quoted('"')
    assert is_quoted('"foo"')
    assert not is_quoted('"foo\\"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo\\'")
    assert not is_quoted('"foo\\""')



# Generated at 2022-06-23 05:06:14.006060
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-23 05:06:17.570496
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\\"bc"') == 'a\\"bc'



# Generated at 2022-06-23 05:06:22.795607
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('''"ab'c"''') == "ab'c"
    assert unquote("'''ab\"c'") == 'ab"c'

# Generated at 2022-06-23 05:06:29.591382
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\\'bar'") == "foo'bar"
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('baz') == 'baz'
    assert unquote('"baz') == '"baz'
    assert unquote('baz"') == 'baz"'

# Generated at 2022-06-23 05:06:33.212146
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"ex5"') == True
    assert is_quoted('"ex5\'"') == False
    assert is_quoted('foo') == False



# Generated at 2022-06-23 05:06:45.247251
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'quoted'") == True)
    assert(is_quoted("'quote\\'d'") == True)
    assert(is_quoted("'quote\"d'") == True)
    assert(is_quoted("'quote\"d\\''") == True)
    assert(is_quoted("'quoted") == False)
    assert(is_quoted("quoted'") == False)
    assert(is_quoted("'quoted\"") == True)
    assert(is_quoted("\"quoted\"") == True)
    assert(is_quoted("\"quote\\\"d\"") == True)
    assert(is_quoted("\"quote'd\"") == True)
    assert(is_quoted("\"quote'd\\\"\"") == True)

# Generated at 2022-06-23 05:06:48.917992
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'

# Generated at 2022-06-23 05:06:55.096608
# Unit test for function unquote
def test_unquote():
    assert unquote('"test string"') == 'test string'
    assert unquote("'test string'") == 'test string'
    assert unquote("'test \"string'") == 'test \"string'
    assert unquote('"test \'string"') == 'test \'string'
    assert unquote('"test string') == '"test string'
    assert unquote("'test string") == "'test string"


# Generated at 2022-06-23 05:07:03.574327
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') is True)
    assert(is_quoted('\'foo\'') is True)
    assert(is_quoted('foo') is False)
    assert(is_quoted('"foo\'"') is False)
    assert(is_quoted('"foo\'bar"') is True)
    assert(is_quoted('"foo\\"bar"') is False)
    assert(is_quoted('"foo\\\\"') is True)
    assert(is_quoted('"foo\\\\\\""') is False)
    assert(is_quoted('"foo\\\\\\\\"') is True)
    assert(is_quoted('""') is True)
    assert(is_quoted('"\'"') is False)
    assert(is_quoted('"\\"') is False)


# Generated at 2022-06-23 05:07:09.016185
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted("simple string")
    assert not is_quoted("'not quoted'")
    assert not is_quoted("\\'quoted'")
    assert is_quoted("'quoted'")
    assert is_quoted("'quoted but with escaped \\\' in it'")
    assert is_quoted('"quoted but with escaped \\\\\\" in it"')
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")


# Generated at 2022-06-23 05:07:14.212445
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted('"hello\\""')
    assert not is_quoted('hello"')
    assert not is_quoted('"hello')


# Generated at 2022-06-23 05:07:21.903890
# Unit test for function unquote
def test_unquote():
    assert unquote("test")=="test"
    assert unquote("'Test'")=="Test"
    assert unquote("\"Test\"")=="Test"
    assert unquote("Test'")=="Test'"
    assert unquote("'Test")=="'Test"
    assert unquote("''Test''")=="Test"
    assert unquote("\\'Test\\'")=="'Test'"
    assert is_quoted("'Test'") == True
    assert is_quoted("\"Test\"") == True
    assert is_quoted("'Test") == False



# Generated at 2022-06-23 05:07:25.422330
# Unit test for function unquote
def test_unquote():
    test_string = "This is a test"
    assert(unquote(test_string) == test_string)
    test_quoted = '"This is a test"'
    assert(unquote(test_quoted) == test_string)

# Generated at 2022-06-23 05:07:35.137858
# Unit test for function is_quoted
def test_is_quoted():
    s = r"""
        a = foo
        b = "foo bar"
        c = 'foo bar'
        d = "foo 'bar'"
        e = 'foo "bar"'
        f = "foo\"bar"
        g = 'foo"bar'
        h = "foo\'bar"
        i = 'foo"bar'
        j = "foo\"bar"
        k = "foo\\"
    """
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert is_quoted('"foo bar"')
    assert is_quoted("'foo bar'")
    assert is_quoted("'foo \"bar'")

# Generated at 2022-06-23 05:07:46.479069
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted("''foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo\\"bar"') == True
    assert is_quoted('"foo\\"bar') == False
    assert is_quoted('"foo"bar"') == False
    assert is_quoted('"foo\'bar"') == True
    assert is_quoted('"foo\'bar') == False
    assert is_quoted('"foo"bar') == False

# Generated at 2022-06-23 05:07:53.455898
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("\"test\"") == "test"
    assert unquote("'test'") == 'test'
    assert unquote("\"'test'\"") == "'test'"
    assert unquote("'\"test\"'") == '"test"'
    assert unquote("\"test with \\\"quotes\\\" inside\"") == "test with \\\"quotes\\\" inside"
    assert unquote("\"test\" with \"extra stuff\"") == "\"test\" with \"extra stuff\""

# Generated at 2022-06-23 05:07:58.844341
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'This string is quoted'") == True
    assert is_quoted("'This \"string\" is quoted'") == True
    assert is_quoted("'This string is \"quoted\"'") == True
    assert is_quoted("'This string is not \"quoted\"'") == False
    assert is_quoted("'This string ends in a slash\\'") == False


# Generated at 2022-06-23 05:08:08.273793
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo\\"bar"') == True
    assert is_quoted("'foo\\'bar'") == True
    assert is_quoted('"foobar"') == True
    assert is_quoted("test") == False
    assert is_quoted("'test'") == True
    assert is_quoted('"test"') == True
    assert is_quoted('"foo') == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo\"bar'") == True
    assert is_quoted('""') == True
    assert is_quoted('') == False



# Generated at 2022-06-23 05:08:17.390931
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('"')
    assert not is_quoted('"""')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'foo bar'")
    assert not is_quoted("'\''")
    assert not is_quoted("\"\"\"")
    assert not is_quoted("\"a'")
    assert not is_quoted("'b\"")
    assert not is_quoted("\"a'b\"")
    assert not is_quoted("'a\"b'")


# Generated at 2022-06-23 05:08:27.272885
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted("'foo'"))
    assert( is_quoted('"foo"'))
    assert( is_quoted('"fo\'o"'))
    assert( not is_quoted('"fo\\"o"'))
    assert( not is_quoted('"fo\\\\"o"'))
    assert( is_quoted('"fo\\\\\\"o"'))
    assert( not is_quoted('"fo\\\'"')) # this is a string with a single quote (\\') and a closing double quote (")
    assert( not is_quoted("'"))
    assert( not is_quoted("'foo"))
    assert( not is_quoted("foo'"))


# Generated at 2022-06-23 05:08:35.789941
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"') == True
    assert is_quoted("'foobar'") == True
    assert is_quoted("foobar") == False
    assert is_quoted("'foobar") == False
    assert is_quoted("foobar'") == False
    assert is_quoted("\"foobar") == False
    assert is_quoted("\"foo\"bar") == False
    assert is_quoted("'foo\\'bar'") == True
    assert is_quoted("foo\\'bar'") == False


# Generated at 2022-06-23 05:08:44.103542
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('""""')
    assert is_quoted('\'"\'')
    assert is_quoted('"foo"')
    assert is_quoted('"foo""')
    assert is_quoted('"foo')
    assert is_quoted('foo"')
    assert is_quoted('"""foo"""')
    assert is_quoted('"""foo\\"""')
    assert is_quoted('''"foo\\"''')
    assert is_quoted('''"foo"''')
    assert not is_quoted('"""foo"""bar"""')
    assert is_quoted('"""foo"""bar""""')


# Generated at 2022-06-23 05:08:51.160918
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'bar'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo\'')
    assert not is_quoted("'foo\"")
    assert not is_quoted('\'foo"')
    assert not is_quoted('\'foo')
    assert not is_quoted('foo\'')
    assert not is_quoted('"foo\\"')
    assert not is_quoted('foo')


# Generated at 2022-06-23 05:08:56.221359
# Unit test for function unquote
def test_unquote():
    assert unquote('this is a string') == 'this is a string'
    assert unquote('"this is a string"') == 'this is a string'
    assert unquote('\'this is a string\'') == 'this is a string'
    assert unquote('"this is a string') == '"this is a string'
    assert unquote('this is a string\'') == 'this is a string\''
    assert unquote('"this is a string\'') == '"this is a string\''
    assert unquote('\'this is a string\"') == '\'this is a string\"'
    assert unquote('\"this is a string\"') == '\"this is a string\"'
    assert unquote('\'this is a string\\"') == '\'this is a string\\"'


# Generated at 2022-06-23 05:09:02.474621
# Unit test for function unquote
def test_unquote():
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\"") == "foo\""
    assert unquote("'foo'") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("foo") == "foo"

# Generated at 2022-06-23 05:09:05.761694
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hel'lo'") == "'hel'lo'"

# Generated at 2022-06-23 05:09:16.138773
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Test"') == True
    assert is_quoted('\'"Test"\'') == False
    assert is_quoted('"Test\'s"') == True
    assert is_quoted('"Test\\"s"') == True
    assert is_quoted('"Test\\\\\\"s"') == False
    assert is_quoted('\'"Test\\"s"\'') == False
    assert is_quoted('\'"Test\\\'s"\'') == False
    assert is_quoted('"Test\\"s"') == True
    assert is_quoted('\'"Test"\'') == False
    assert is_quoted('"Test') == False
    assert is_quoted('Test"') == False
    assert is_quoted('"Test"s') == False


# Generated at 2022-06-23 05:09:26.534629
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"abc\\"') == '"abc\\"'
    assert unquote("'abc\\'") == "'abc\\'"
    assert unquote('"abc\\""') == '"abc\\""'
    assert unquote("'abc\\''") == "'abc\\''"
    assert unquote('"""') == '"'
    assert unquote("'''") == "'"
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"
    assert unquote('abc') == 'abc'
    assert unquote('"a"b"c"') == '"a"b"c"'

# Generated at 2022-06-23 05:09:33.582197
# Unit test for function unquote
def test_unquote():
    assert ('abc' == unquote('abc'))
    assert ('abc' == unquote('"abc"'))
    assert ('a"bc' == unquote('a"bc"'))
    assert ('"a"bc' == unquote('"a"bc'))
    assert ("a''bc" == unquote("a''bc"))
    assert ("'a''bc" == unquote("'a''bc"))
    assert ("'ab''c'" == unquote("'ab''c'"))
    assert ("'ab'c'" == unquote("'ab'c'"))


# Generated at 2022-06-23 05:09:37.980687
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo\'"') == False
    assert is_quoted('\'foo"\'') == True
    assert is_quoted('"foo') == False


# Generated at 2022-06-23 05:09:44.987407
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('test"')
    assert not is_quoted("test'")
    assert not is_quoted('test')
    assert not is_quoted('"test"test')
    assert not is_quoted('"test\\""')


# Generated at 2022-06-23 05:09:48.032222
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquo

# Generated at 2022-06-23 05:09:56.453114
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"") == False
    assert is_quoted("''") == False
    assert is_quoted("'hello'") == True
    assert is_quoted("'hel''lo'") == True
    assert is_quoted("\"hello\"") == True
    assert is_quoted("\"hel\"\"lo\"") == True
    assert is_quoted("'hel\"lo'") == True
    assert is_quoted('"hel\'lo"') == True
    assert is_quoted('"hel\\"lo"') == False
    assert is_quoted('"hel\\\\"lo"') == True

# Generated at 2022-06-23 05:10:03.067050
# Unit test for function is_quoted
def test_is_quoted():
    class TestFailed(Exception):
        pass

    def test_is_quoted(should_be_quoted, should_not_be_quoted):
        """ Test string to check if it should be quoted. """

        # Test one, should be quoted

# Generated at 2022-06-23 05:10:13.723781
# Unit test for function unquote
def test_unquote():
    assert unquote(u"a'b") == u"a'b"
    assert unquote(u"a\"b") == u"a\"b"
    assert unquote(u"'a\'b'") == u"a'b"
    assert unquote(u"'a\"b'") == u"a\"b"
    assert unquote(u"'a\"b\\'") == u"'a\"b\\'"
    assert unquote(u"a'b'") == u"a'b"
    assert unquote(u"\"a'b\"") == u"a'b"
    assert unquote(u"'a\'b") == u"'a\'b"

# Generated at 2022-06-23 05:10:20.367351
# Unit test for function unquote
def test_unquote():
    assert 'this is a test' == unquote('"this is a test"')
    assert "this is a test of 'quotes'" == unquote('"this is a test of \'quotes\'"')
    assert '"this is a test of quotes"' == unquote('"this is a test of quotes"')
    assert 'this is a test' == unquote("'this is a test'")
    assert 'this is a test' == unquote('this is a test')


# Generated at 2022-06-23 05:10:30.729518
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('"hello\\""') == False
    assert is_quoted("'hello'")
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted("'hello\\''") == False
    assert is_quoted('"hello\\"') == False
    assert is_quoted('hello\\"') == False
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('"hello\\"') == False
    assert is_quoted('hello\\"') == False


# Generated at 2022-06-23 05:10:35.766538
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"
    assert unquote('abc"') == 'abc"'
    assert unquote('abc\'"') == 'abc\'"'

# Generated at 2022-06-23 05:10:41.923910
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert is_quoted("'escape\\'d'")
    assert is_quoted('"escape"d"')

    assert not is_quoted('"not quoted')
    assert not is_quoted("'not quoted")
    assert not is_quoted("unquoted")


# Generated at 2022-06-23 05:10:44.820608
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('nothing interesting')
    assert is_quoted('"interesting"')
    assert not is_quoted('"\\"')
    assert is_quoted("'\\''")



# Generated at 2022-06-23 05:10:51.738156
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('foo"')
    assert not is_quoted("'foo'bar")
    assert not is_quoted("'foo\"")
    assert not is_quoted("\"foo'")
    assert is_quoted("'foo\'bar'")
    assert is_quoted("\"foo\'bar\"")
    assert is_quoted('"foo\\"bar"')
