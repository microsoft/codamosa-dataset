

# Generated at 2022-06-23 05:00:50.063805
# Unit test for function unquote
def test_unquote():
    assert (unquote('"test"') == 'test')
    assert (unquote('test')   == 'test')
    assert (unquote('"\\"test\\""') == '"test"')

# Generated at 2022-06-23 05:00:53.080634
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"')      == 'foo'
    assert unquote('"foo" bar')  == '"foo" bar'
    assert unquote('foo bar')    == 'foo bar'
    assert unquote('foo "bar"')  == 'foo "bar"'

# Generated at 2022-06-23 05:00:58.591626
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("\"foobar\"")
    assert is_quoted("'foobar'")
    assert not is_quoted('foobar')
    assert not is_quoted('"foobar')
    assert not is_quoted('foobar"')
    assert not is_quoted("'foobar")
    assert not is_quoted('foobar"')
    assert not is_quoted('"foo"bar"')


# Generated at 2022-06-23 05:01:07.847956
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"quoted string"') == True)
    assert (is_quoted('"quoted \" string"') == False)
    assert (is_quoted('not quoted string') == False)
    assert (is_quoted('" two quotes "') == False)
    assert (is_quoted('') == False)
    assert (is_quoted('""') == False)
    assert (is_quoted('"') == False)
    assert (is_quoted('""""') == False)


# Generated at 2022-06-23 05:01:14.996976
# Unit test for function unquote
def test_unquote():
    assert unquote('hello') == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello"') == 'hello"'
    assert unquote("hello'") == "hello'"
    assert unquote('"he\'llo"') == 'he\'llo'
    assert unquote("'he\"llo'") == 'he\"llo'
    assert unquote("'hello\'world'") == "hello\'world"



# Generated at 2022-06-23 05:01:20.678107
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("'foo") == False)
    assert(is_quoted('"foo"') == True)
    assert(is_quoted('"foo') == False)
    assert(is_quoted('foo') == False)
    assert(is_quoted('"foo\\""') == True)
    assert(is_quoted("'foo\\''") == True)



# Generated at 2022-06-23 05:01:28.139301
# Unit test for function is_quoted
def test_is_quoted():
    in_quote = ['', '"', '"a', "abc'abc", '"abc', 'abc"', 'abc\\"abc']
    not_in_quote = ["abc", '"ab"c"', "ab'c'", "a\\'bc'", "'abc", "a'bc", 'a"bc', '"ab"c"']
    for quote in in_quote:
        assert is_quoted(quote) == True
    for noquote in not_in_quote:
        assert is_quoted(noquote) == False


# Generated at 2022-06-23 05:01:33.574260
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("test") == False
    assert is_quoted("'test'") == True
    assert is_quoted("'test") == False
    assert is_quoted("test'") == False
    assert is_quoted("''test'") == False
    assert is_quoted("'test''") == False
    assert is_quoted("'test' 'something'") == False


# Generated at 2022-06-23 05:01:38.384569
# Unit test for function unquote
def test_unquote():
    assert 'a => b' == unquote('"a => b"')
    assert 'a => b' == unquote("'a => b'")
    assert 'a => b' != unquote('a => b')
    assert 'a => b' == unquote("'a => b")
    assert 'a => b' == unquote("a => b'")


# Generated at 2022-06-23 05:01:45.507234
# Unit test for function unquote
def test_unquote():
    assert unquote("'abc'") == "abc"
    assert unquote("'a\"bc'") == "a\"bc"
    assert unquote("'a\"bc'") == "a\"bc"
    assert unquote("'a'bc'") == "'a'bc"
    assert unquote("\"ab'c\"") == "ab'c"
    assert unquote("'\"ab'c\"'") == "\"ab'c\""
    assert unquote("'\"ab\\'c\"'") == "\"ab'c\""
    assert unquote("'abc'") == "abc"
    assert unquote("\"abc\"") == "abc"

# Generated at 2022-06-23 05:01:55.119714
# Unit test for function unquote
def test_unquote():
    def run(test_case):
        input, output = test_case
        assert unquote(input) == output
    mapping = (
        ("'test'", "test"),
        ("\"test\"", "test"),
        ("'test", "'test"),
        ("\"test", "\"test"),
        ("'test' ", "'test' "),
        ("\"test\" ", "\"test\" "),
        (" 'test'", " 'test'"),
        (" \"test\"", " \"test\""),
        # escaped quotes
        ("\"test\\\"\"", "test\\\""),
        ("\"test\\\\\"", "test\\\\"),
        ("'test\\''", "test\\'"),
        ("'test\\\\'", "test\\\\"),
    )
    for test_case in mapping:
        yield run, test_case

# Generated at 2022-06-23 05:02:03.009410
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted('"foo')
    assert not is_quoted('foo')
    assert not is_quoted('')


# Generated at 2022-06-23 05:02:06.872253
# Unit test for function unquote
def test_unquote():
    assert unquote('"xyz"') == 'xyz'
    assert unquote("'xyz'") == 'xyz'
    assert unquote('"xyz') == '"xyz'
    assert unquote('xyz"') == 'xyz"'
    assert unquote('"x\"z"') == 'x"z'



# Generated at 2022-06-23 05:02:14.460980
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('te"st"') is False
    assert is_quoted("te'st'") is False
    assert is_quoted('"test') is False
    assert is_quoted("'test") is False
    assert is_quoted('test"') is False
    assert is_quoted("test'") is False
    assert is_quoted('') is False
    assert is_quoted('"test\\"') is False
    assert is_quoted("'test\\'") is False


# Generated at 2022-06-23 05:02:16.634427
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")


# Generated at 2022-06-23 05:02:20.861151
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"bar"') == 'bar'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('"foo""bar"') == 'foo""bar'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-23 05:02:24.962639
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"data"')
    assert is_quoted("'data'")
    assert not is_quoted('data"')
    assert not is_quoted("data'")

# Unit tests for function unquote

# Generated at 2022-06-23 05:02:29.360942
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test\\"') == '"test\\"'
    assert unquote('test') == 'test'

# Generated at 2022-06-23 05:02:33.156334
# Unit test for function unquote
def test_unquote():
    assert unquote('"') == '"'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('"\\"hello"') == '\\"hello'

# Generated at 2022-06-23 05:02:38.357387
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"""hello"""') == '"""hello"""'
    assert unquote("'''hello'''") == "'''hello'''"
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello" world') == '"hello" world'


# Generated at 2022-06-23 05:02:43.814641
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")

    assert not is_quoted('"test\\""')
    assert not is_quoted("'test\\''")
    assert not is_quoted("test")


# Generated at 2022-06-23 05:02:54.225108
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True

    assert is_quoted('"test') == False
    assert is_quoted("'test") == False

    assert is_quoted('te"st"') == False
    assert is_quoted("te'st'") == False

    assert is_quoted('test') == False
    assert is_quoted('test "test"') == False

    assert is_quoted('""') == True

# Generated at 2022-06-23 05:03:05.367375
# Unit test for function unquote
def test_unquote():
    if unquote('foo') != 'foo':
        raise Exception("unquote failed to unquote simple text")
    if unquote('"foo"') != 'foo':
        raise Exception("unquote failed to strip quotes")
    if unquote("'foo'") != 'foo':
        raise Exception("unquote failed to strip quotes")
    if unquote("\"foo\"") != 'foo':
        raise Exception("unquote failed to strip quotes")
    if unquote("'foo'") != 'foo':
        raise Exception("unquote failed to strip quotes")
    if unquote("'foo'bar'") != "'foo'bar'":
        raise Exception("unquote failed to leave quoted text alone")
    if unquote("\\'foo") != "'foo":
        raise Exception("unquote failed to leave escaped quotes")

# Generated at 2022-06-23 05:03:09.685638
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Foo"') == True
    assert is_quoted('"Foo') == False
    assert is_quoted('Foo"') == False
    assert is_quoted('"Foo\\"') == False
    assert is_quoted('"Foo"Bar') == False



# Generated at 2022-06-23 05:03:14.551110
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('a') == 'a'
    assert unquote('"a') == '"a'
    assert unquote("'a") == "'a"
    assert unquote("'ab cd e'") == "ab cd e"
    assert unquote("'ab cd e'") == "ab cd e"
    assert unquote("'ab \' cd e'") == "ab \' cd e"


# Generated at 2022-06-23 05:03:21.688389
# Unit test for function is_quoted
def test_is_quoted():
    in_str = "test"
    assert not is_quoted(in_str)
    in_str = 'test'
    assert not is_quoted(in_str)
    in_str = '"test"'
    assert is_quoted(in_str)
    in_str = "'test'"
    assert is_quoted(in_str)
    in_str = "\"test\""
    assert is_quoted(in_str)
    in_str = "'test'"
    assert is_quoted(in_str)



# Generated at 2022-06-23 05:03:31.516250
# Unit test for function unquote
def test_unquote():
    assert 'foo' == unquote('"foo"')
    assert 'foo "bar"' == unquote('"foo \\"bar\\""')
    assert 'bar baz' == unquote('\'bar baz\'')
    assert 'f"o"o' == unquote('"' + 'f\\"o\\"o' + '"')
    assert 'f\'o"o' == unquote('"' + 'f\\\'o\\"o' + '"')
    assert 'foobar' == unquote('foobar')
    assert '\'foo' == unquote('\'foo')
    assert 'foo\'' == unquote('foo\'')
    assert '\'foo\'' == unquote('\'foo\'')

if __name__ == "__main__":
    import sys
    import pytest

# Generated at 2022-06-23 05:03:42.481807
# Unit test for function unquote

# Generated at 2022-06-23 05:03:49.825958
# Unit test for function unquote
def test_unquote():
    assert unquote('"Hello world"') == "Hello world"
    assert unquote('Hello world"') == 'Hello world"'
    assert unquote('"Hello world') == '"Hello world'
    assert unquote('"Hello \" world"') == 'Hello \" world'

# Generated at 2022-06-23 05:03:57.919694
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a"') == True
    assert is_quoted("'a'") == True
    assert is_quoted("'a\\'") == True
    assert is_quoted('"a\\""') == True
    assert is_quoted('a') == False
    assert is_quoted('"a') == False
    assert is_quoted("'a") == False
    assert is_quoted('a"') == False
    assert is_quoted('a"') == False
    assert is_quoted('"a"b') == False
    assert is_quoted('"""ab"""') == True


# Generated at 2022-06-23 05:04:02.591351
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted('"test\\"') == False
    assert is_quoted('test"') == False
    assert is_quoted('"test') == False
    assert is_quoted('test') == False


# Generated at 2022-06-23 05:04:06.311333
# Unit test for function is_quoted
def test_is_quoted():

    assert(is_quoted('"foo"') == True)
    assert(is_quoted('foo') == False)
    assert(is_quoted('"foo') == False)
    assert(is_quoted('"foo\\""') == True)
    assert(is_quoted('"foo\\"') == False)



# Generated at 2022-06-23 05:04:13.707604
# Unit test for function is_quoted
def test_is_quoted():
    assert( not is_quoted('"a') )
    assert( not is_quoted('"ab"c') )
    assert( not is_quoted('"ab\\"') )
    assert( not is_quoted('"ab"c') )
    assert( is_quoted('"ab"') )
    assert( is_quoted('\'"ab"\'') )
    assert( is_quoted('\\"ab\\"') )
    assert( is_quoted('\\\\"ab\\\\"') )


# Generated at 2022-06-23 05:04:19.538751
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('\\"hello"') == '\\"hello"'
    assert unquote('hello\\"') == 'hello\\"'
    assert unquote(r'"hello\n"') == r'hello\n'
    assert unquote('"\\u1234"') == '\\u1234'
    assert unquote('\\"\\u1234\\"') == '\\"\\u1234\\"'



# Generated at 2022-06-23 05:04:23.630670
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a"bc"') == '"a"bc"'
    assert unquote('"a\\"bc"') == 'a\\"bc'


# Generated at 2022-06-23 05:04:34.129046
# Unit test for function unquote

# Generated at 2022-06-23 05:04:42.413917
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("'hell'o'")
    assert is_quoted('"hello"')
    assert not is_quoted('"hel"lo"')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('\'"hello"')
    assert not is_quoted('"hello\'"')
    assert not is_quoted("'hello\\'")
    assert not is_quoted('"hello\\"')

    assert not is_quoted("hello")
    assert not is_quoted("hel'lo")
    assert not is_quoted("'hel'lo")

# Generated at 2022-06-23 05:04:47.954862
# Unit test for function unquote
def test_unquote():
    # test regular quotes
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'

    # test mismatched quotes
    assert unquote('"test\'') == '"test\''
    assert unquote("'test\"") == "'test\""

    # test unquoted
    assert unquote('test') == 'test'

# Generated at 2022-06-23 05:04:55.731510
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('"test"')
    assert True == is_quoted("'test'")
    assert False == is_quoted('"test')
    assert False == is_quoted("'test")
    assert False == is_quoted("test'")
    assert False == is_quoted('test"')
    assert False == is_quoted('"tes"t"')
    assert False == is_quoted("'tes't'")
    assert False == is_quoted('"tes\\"t"')



# Generated at 2022-06-23 05:05:07.229711
# Unit test for function unquote
def test_unquote():

    quoted = "\"This is a quoted string\""
    unquoted = "This is a quoted string"
    assert unquote(quoted) == unquoted

    double_quoted = "\"This is a quoted string with 'inside quotes'\""
    double_unquoted = "This is a quoted string with 'inside quotes'"
    assert unquote(double_quoted) == double_unquoted

    single_quoted = "'This is a quoted string with \"inside quotes\"'"
    single_unquoted = "This is a quoted string with \"inside quotes\""
    assert unquote(single_quoted) == single_unquoted

    potential_quoted = "\"This is a quoted string"
    assert unquote(potential_quoted) == potential_quoted

    potential_quoted = "This is a quoted string\""


# Generated at 2022-06-23 05:05:13.451252
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"value"')
    assert is_quoted("'value'")
    assert not is_quoted('value')
    assert not is_quoted('"value')
    assert not is_quoted("'value")
    assert not is_quoted("\"value'")
    assert not is_quoted("'value\"")


# Generated at 2022-06-23 05:05:22.623348
# Unit test for function unquote
def test_unquote():
    assert unquote(u'abcd') == u'abcd'
    assert unquote(u'"abcd"') == u'abcd'
    assert unquote(u"'abcd'") == u'abcd'
    assert unquote(u"'ab\"cd'") == u'ab\"cd'
    assert unquote(u'"abcd\\"') == u'abcd"'
    assert unquote(u'"ab\\"cd"') == u'ab\\"cd'
    assert unquote(u'"\\"abcd"') == u'\\"abcd'
    assert unquote(u'"""abcd"""') == u'abcd"'
    assert unquote(u'\'\'\'abcd"\'') == u"abcd'"

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 05:05:31.130836
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("\"foo\"") == True
    assert is_quoted("'foo\"") == False
    assert is_quoted("foo\\'") == False
    assert is_quoted("foo\\\"") == False
    assert is_quoted("\"foo\\\"") == False
    assert is_quoted("'foo\\'") == False
    assert is_quoted("\"foo\\\"bar\"") == True
    assert is_quoted("'foo\\'bar'") == True


# Generated at 2022-06-23 05:05:37.689920
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote("'foo'bar'") == "'foo'bar'"


# Generated at 2022-06-23 05:05:41.550344
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\'bc"') == 'a\'bc'
    assert unquote('"ab\\"c"') == 'ab\\"c'
    assert unquote('"a\\"b"') == 'a"b'

test_unquote()

# Generated at 2022-06-23 05:05:49.414872
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"') == False)
    assert(is_quoted('"""') == False)
    assert(is_quoted('""a') == False)
    assert(is_quoted('a""') == False)
    assert(is_quoted('"a"') == True)
    assert(is_quoted('"""a"""') == True)
    assert(is_quoted('"a\\""') == True)
    assert(is_quoted('"a\\"a"') == True)
    assert(is_quoted('"a\\\\""') == True)


# Generated at 2022-06-23 05:05:57.813526
# Unit test for function unquote
def test_unquote():
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule

    def main():
        test_unquote()

        module = AnsibleModule(
            argument_spec=dict(
                data=dict(required=True),
            )
        )
        result = dict(
            changed=False,
            data=unquote(module.params['data']),
        )
        module.exit_json(**result)

    main

# Generated at 2022-06-23 05:06:03.933282
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo')  == '"foo'
    assert unquote("'foo")  == "'foo"
    assert unquote('foo"')  == 'foo"'
    assert unquote('foo\'"')  == 'foo\'"'
    assert unquote('foo\'"bar')  == 'foo\'"bar'



# Generated at 2022-06-23 05:06:09.055453
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote('foobar"') == 'foobar"'
    assert unquote('"foobar') == '"foobar'
    assert unquote('"foobar\\"') == 'foobar"'
    assert unquote('foobar') == 'foobar'
    assert unquote('') == ''

# Generated at 2022-06-23 05:06:14.815626
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello" world') == '"hello" world'
    assert unquote('"hello"world') == '"hello"world'
    assert unquote('hello world') == 'hello world'
    assert unquote('"hello\\" world"') == '"hello\\" world"'

# Generated at 2022-06-23 05:06:23.187848
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a b c"') == 'a b c'
    assert unquote('\'a b c\'') == 'a b c'
    assert unquote('"a b c"') == 'a b c'
    assert unquote('"a \\"bc"') == 'a "bc'
    assert unquote('\'a \\\'bc\'') == 'a \\\'bc'
    assert unquote('\'a b c\'') == 'a b c'
    assert unquote('a b c') == 'a b c'



# Generated at 2022-06-23 05:06:26.982859
# Unit test for function unquote
def test_unquote():
    assert unquote("'\"'") == '"'
    assert unquote("'\"'") == '"'
    assert unquote("''") == ''
    assert unquote("'a'") == 'a'
    assert unquote("'a") == "'a"
    assert unquote("a'") == "a'"

# Generated at 2022-06-23 05:06:34.307271
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo bar"') == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo bar") == "'foo bar"
    assert unquote("foo bar'") == "foo bar'"
    assert unquote("'foo''bar'") == "'foo''bar'"
    assert unquote("foo bar") == "foo bar"
    assert unquote("'foo \'bar\' foo'") == "foo \'bar\' foo"

# Generated at 2022-06-23 05:06:45.978683
# Unit test for function unquote
def test_unquote():
    assert unquote('"str"') == 'str'
    assert unquote("'str'") == 'str'
    assert unquote("'str") == "'str"
    assert unquote("str'") == "str'"
    assert unquote("str") == "str"
    assert unquote("'s\\'tr'") == "s\\'tr"
    assert unquote("'s\\\"tr'") == 's\\\"tr'
    assert unquote("'s\\\"tr\\'\"") == 's\\\"tr\\\'', "unquote failed on string with escaped quotes: %r" % unquote("'s\\\"tr\\'\"")
    assert unquote("'s\\'tr\"") == "s\\'tr\""
    assert unquote("'s\\'tr'\"") == "s\\'tr'"

# Generated at 2022-06-23 05:06:50.140010
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"TEST"')
    assert is_quoted("'TEST'")
    assert not is_quoted('TEST')
    assert not is_quoted('"TEST')
    assert not is_quoted("'TEST")



# Generated at 2022-06-23 05:07:00.074364
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("a") == False
    assert is_quoted("'a'") == True
    assert is_quoted('"a\\""') == True
    assert is_quoted('\\"a') == False
    assert is_quoted('"\\"') == False
    assert is_quoted('"a\\"b"') == True
    assert is_quoted('"a\\\\"') == True
    assert is_quoted('"a\\\\\\"') == False
    assert is_quoted('"a\\\\\\\\"') == True
    assert is_quoted('"a\\\\\\\\\\""') == True
    assert is_quoted('"a\\\\\\\\\\\\\\""') == False
    assert is_quoted('"a') == False
    assert is_quoted('"') == False

# Generated at 2022-06-23 05:07:03.972193
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'



# Generated at 2022-06-23 05:07:10.487415
# Unit test for function unquote
def test_unquote():
    assert unquote('')                       == ''
    assert unquote('"')                      == ''
    assert unquote('""')                     == ''
    assert unquote('"foo"')                  == 'foo'
    assert unquote('foo')                    == 'foo'
    assert unquote('"foo\\"bar"')            == 'foo\\"bar'
    assert unquote('"foo\n"')                == 'foo\n'



# Generated at 2022-06-23 05:07:15.823987
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted('"foo\'"')
    assert not is_quoted('"foo\\"')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo')


# Generated at 2022-06-23 05:07:25.540287
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\\"bc"') == 'a\\"bc'
    assert unquote('"ab\\"c"') == 'ab\\"c'
    assert unquote('"a\\"b\\"c"') == 'a\\"b\\"c'
    assert unquote('a"b\\"c"') == 'a"b\\"c'
    assert unquote('"a"b"c"') == '"a"b"c"'
    assert unquote('"abc') == '"abc'
    assert unquote('"ab\\\\c"') == 'ab\\\\c'
    assert unquote('"ab\\\\"') == 'ab\\\\'
    assert unquote('"ab\\\\\\\\"') == 'ab\\\\\\\\'
    assert unquote('ab\\c')

# Generated at 2022-06-23 05:07:28.479411
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'



# Generated at 2022-06-23 05:07:35.583857
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted('"foo"') == True
    assert is_quoted('"fo\\"o"') == True
    assert is_quoted('\'"foo"\'') == False
    assert is_quoted('"foo\'"') == True
    assert is_quoted('\'"foo\'"') == False
    assert is_quoted('\'foo\'') == True
    assert is_quoted('\'foo"') == False
    assert is_quoted('"foo\'') == False



# Generated at 2022-06-23 05:07:41.585880
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('\'hello\'')
    assert not is_quoted('hello')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('\'hello')
    assert not is_quoted('hello\'')
    assert not is_quoted('"hello\\"')
    assert is_quoted('"hell\\\\o"')


# Generated at 2022-06-23 05:07:45.209626
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"')
    assert is_quoted("'abcd'")
    assert not is_quoted("'abcd")
    assert not is_quoted("abcd'")


# Generated at 2022-06-23 05:07:52.672308
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"random string"')
    assert not is_quoted('random"string"')
    assert not is_quoted('"random string')
    assert not is_quoted('random string"')
    assert is_quoted("\"/random string'")
    assert is_quoted("\"/random string'\"")
    assert is_quoted("\"/random' string\"")
    assert not is_quoted("\"/random string\\\"")
    assert not is_quoted("\"/random' string\\\"")


# Generated at 2022-06-23 05:08:02.129280
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'hello'")
    assert is_quoted("'hel\"lo'")
    assert is_quoted("'hel\\'lo'")
    assert is_quoted("'hel''lo'")
    assert is_quoted("'hel\\\\lo'")
    assert is_quoted("'hel\\\\\\'lo'")
    assert not is_quoted("'hel\\\\\\''lo'")
    assert not is_quoted("'hel\\\\\\'lo")
    assert is_quoted('"hello"')
    assert is_quoted('"hel\\"lo"')
    assert is_quoted('"hel\\\\lo"')
    assert is_quoted('"hel\\\\\\"lo"')
    assert is_quoted('"hel\\"\\"lo"')
    assert not is_quoted

# Generated at 2022-06-23 05:08:05.692452
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted string"') is True
    assert is_quoted('unquoted string') is False
    assert is_quoted('"quoted string') is False


# Generated at 2022-06-23 05:08:11.081932
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('foo') == "foo"
    assert unquote('\"foo\"') == '\"foo\"'
    assert unquote('"foo\"') == '"foo\"'
    assert unquote('\'foo\"') == '\'foo\"'



# Generated at 2022-06-23 05:08:17.659219
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"double quoted string"')
    assert is_quoted("'single quoted string'")
    assert is_quoted("'quoted string \\\"with escaped quotation\\\"'")
    assert not is_quoted("'quoted string \"with unescaped quotation\"'")
    assert not is_quoted("'quoted string" + chr(255) + " with unprintable chars'")
    assert not is_quoted("not quoted string")


# Generated at 2022-06-23 05:08:21.400251
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo\"bar"') == 'foo\"bar'
    assert unquote('"foo\\\\\"bar"') == 'foo\\\"bar'

# Generated at 2022-06-23 05:08:31.124540
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"hello world"') == True)
    assert(is_quoted('"hello \'world"') == False)
    assert(is_quoted('"hello \\"world"') == False)
    assert(is_quoted('"hello \"world"') == True)
    assert(is_quoted('"hello world"') == True)
    assert(is_quoted('"hello world') == False)
    assert(is_quoted('hello world"') == False)
    assert(is_quoted('hello world') == False)
    assert(is_quoted("'hello world'") == True)
    assert(is_quoted("'hello \"world'") == False)
    assert(is_quoted("'hello \\\"world'") == False)

# Generated at 2022-06-23 05:08:36.165131
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted string"')
    assert is_quoted("'quoted string'")
    assert is_quoted('\'quoted string\'')
    assert not is_quoted('"quoted string\'')
    assert not is_quoted('"quoted string')


# Generated at 2022-06-23 05:08:42.118696
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'

    # Test that "\'" is not unquoted
    assert unquote("'\\\''") == "'\\\'"

# Generated at 2022-06-23 05:08:46.627924
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"ab\"c"') == 'ab"c'



# Generated at 2022-06-23 05:08:51.234725
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo\\'bar'") == "foo'bar"



# Generated at 2022-06-23 05:09:01.994416
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'bar\'') == 'bar'

    assert unquote('"foo\\"bar"') == 'foo"bar'
    assert unquote('\'foo\\"bar\'') == 'foo"bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('\'foo\\\'bar\'') == 'foo\\\'bar'

    # this one is weird and probably wont happen but we don't want to
    # accidentally remove the wrong set of quotes
    assert unquote('"foo\'bar\'"') == "foo\'bar\'"

    assert unquote('"a\\\'b"') == "a\'b"
    assert unquote('"a\\"b"') == 'a"b'



# Generated at 2022-06-23 05:09:05.192144
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('\'hello\'') == 'hello'
    assert unquote('"hello') == '"hello'


# Generated at 2022-06-23 05:09:10.919269
# Unit test for function unquote
def test_unquote():
    data = [
        ('"blah"', 'blah'),
        ('blah', 'blah'),
        ('\'blah', '\'blah'),
        ('blah\'', 'blah\''),
        ('"blah\'', '"blah\''),
        ('blah"', 'blah"'),
        ('\'"blah\'', '\'"blah\''),
        ('blah\'"', 'blah\'"'),
    ]
    for item in data:
        assert unquote(item[0]) == item[1]



# Generated at 2022-06-23 05:09:15.394653
# Unit test for function unquote
def test_unquote():
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\"") == "foo\""
    assert unquote("\"\"") == ""


# Generated at 2022-06-23 05:09:26.253171
# Unit test for function unquote
def test_unquote():
    assert unquote('"a b"') == 'a b'
    assert unquote("'a b'") == 'a b'

    assert unquote('"') == '"'
    assert unquote("'") == "'"

    assert unquote('\\"a"') == '\\"a"'
    assert unquote("\\'a'") == "\\'a'"

    assert unquote('\\"') == '\\"'
    assert unquote("\\'") == "\\'"

    assert unquote('"a\\"b"') == 'a\\"b'
    assert unquote("'a\\'b'") == "a\\'b"

    assert unquote('a"a\\"b"b') == 'a"a\\"b"b'

# Generated at 2022-06-23 05:09:28.452764
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert not is_quoted('"test')
    assert not is_quoted('test')


# Generated at 2022-06-23 05:09:35.362167
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('unquoted')
    assert not is_quoted('"a quoted string')
    assert not is_quoted("'a quoted string")
    assert not is_quoted('a "quoted" string')
    assert not is_quoted('a \'quoted\' string')
    assert is_quoted('"a quoted string"')
    assert is_quoted("'a quoted string'")
    assert is_quoted('"a \\ quoted string"')


# Generated at 2022-06-23 05:09:43.706786
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert is_quoted("'test''")
    assert is_quoted("'test\'")
    assert is_quoted("\"test\"")
    assert is_quoted("\"test\"\"")
    assert is_quoted("\"test\\\"")
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("\"test")
    assert not is_quoted("test\"")


# Generated at 2022-06-23 05:09:47.402126
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == "test"
    assert unquote("''") == ""
    assert unquote("'no end quote") == "'no end quote"
    assert unquote("no quotes") == "no quotes"
    assert unquote('"') == '"'

# Generated at 2022-06-23 05:09:52.908760
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote('"hello world') == '"hello world'
    assert unquote('hello world"') == 'hello world"'
    assert unquote('hello world') == 'hello world'
    assert unquote('"hello world\\""') == 'hello world\\"'
    assert unquote('') == ''



# Generated at 2022-06-23 05:10:00.770267
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('wtf"') is False
    assert is_quoted('"wtf') is False
    assert is_quoted('wtf') is False
    assert is_quoted('"wtf"') is True
    assert is_quoted('"wtf') is False
    assert is_quoted('"wtf\'') is False
    assert is_quoted('"wtf\""') is False
    assert is_quoted('\'"wtf"\'') is True
    assert is_quoted('\'wtf"') is False
    assert is_quoted('"wtf\'"') is False


# Generated at 2022-06-23 05:10:04.499106
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted("foo") == False
    assert is_quoted('"foo\\"') == False


# Generated at 2022-06-23 05:10:15.617420
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"test\\""')
    assert not is_quoted('"test\\"')
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted('test"')
    assert not is_quoted('"test')
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test\\""') == 'test\\"'
    assert unquote('"test\\"') == '"test\\"'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('"test') == '"test'

# Generated at 2022-06-23 05:10:23.147988
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'bar'")
    assert is_quoted('"baz\\"') == False
    assert is_quoted('\'baz\'')
    assert is_quoted('"foo\\"bar"')
    assert is_quoted('"foo\\"bar\\"baz"')
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted('\'"foo"\'') == False


# Generated at 2022-06-23 05:10:26.828190
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'test'") == True
    assert is_quoted("'test") == False
    assert unquote("'test'") == "test"
    assert unquote("'test") == "'test"
    assert unquote("test") == "test"



# Generated at 2022-06-23 05:10:35.667603
# Unit test for function unquote
def test_unquote():
    assert unquote("'string'") == 'string'
    assert unquote('"string"') == 'string'
    assert unquote("'string") == 'string'
    assert unquote('"string') == 'string'
    assert unquote("'no_quote") == 'no_quote'
    assert unquote('"no_quote') == 'no_quote'
    assert unquote("'no_quote'") == 'no_quote'
    assert unquote('"no_quote"') == 'no_quote'
    assert unquote('no_quote') == 'no_quote'


# Generated at 2022-06-23 05:10:39.472555
# Unit test for function unquote
def test_unquote():
    data = ['foo', '"foo"', '"foo\\""', "'foo'", "'foo\\''"]
    for str in data:
        assert unquote(str) == 'foo'



# Generated at 2022-06-23 05:10:44.819314
# Unit test for function unquote
def test_unquote():
    test_inputs = {
        '"testing1"': 'testing1',
        '"testing2': '"testing2',
        'testing3"': 'testing3"',
        '"testing4\\""': 'testing4"',
        '"testing5\\\\"': 'testing5\\',
    }

    for input, output in test_inputs.items():
        assert unquote(input) == output



# Generated at 2022-06-23 05:10:53.825831
# Unit test for function is_quoted
def test_is_quoted():
    # True
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'\"foo\"'")
    assert is_quoted("\"'foo'\"")
    assert is_quoted("\"'\"")
    assert is_quoted("\'\"\"")
    assert is_quoted("'\"\'\"\"'")
    # False
    assert not is_quoted('\\"foo"')
    assert not is_quoted('"foo"bar')
    assert not is_quoted('"fo\'o"')
    assert not is_quoted('\'fo"o\'')
    assert not is_quoted('foobar')
