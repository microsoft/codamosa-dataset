

# Generated at 2022-06-23 05:00:47.711750
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"') == False
    assert is_quoted('abc"') == False
    assert is_quoted('"abc') == False
    assert is_quoted('"abc"') == True



# Generated at 2022-06-23 05:00:52.476306
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello\\""') == False
    assert is_quoted("'hello\\''") == False
    assert is_quoted('"hello" world"') == False
    assert is_quoted("'hello' world'") == False
    assert is_quoted('hello') == False


# Generated at 2022-06-23 05:00:59.332869
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote('"hello') == '"hello'
    assert unquote("hello'") == "hello'"
    assert unquote('hello"') == 'hello"'
    assert unquote("'hello\\''") == "'hello\\''"
    assert unquote('"hello\\""') == '"hello\\""'



# Generated at 2022-06-23 05:01:11.104353
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('') == False
    assert is_quoted('""') == False
    assert is_quoted('"') == False
    assert is_quoted('4') == False
    assert is_quoted("'") == False
    assert is_quoted("''") == False
    assert is_quoted("abc") == False
    assert is_quoted("hello there") == False
    assert is_quoted("'hello there'") == True
    assert is_quoted("\"hello there\"") == True
    assert is_quoted("\"hello there\'") == False
    assert is_quoted("'hello there\"") == False

# Generated at 2022-06-23 05:01:18.871367
# Unit test for function unquote
def test_unquote():
    assert unquote('"stuff"') == 'stuff'
    assert unquote("'stuff'") == 'stuff'
    assert unquote('st"uff') == 'st"uff'
    assert unquote('stu"ff') == 'stu"ff'
    assert unquote('"stu"ff') == 'stu"ff'
    assert unquote('stu"ff"') == 'stu"ff"'
    assert unquote('"stu"ff"') == 'stu"ff"'
    assert unquote('st"u"ff') == 'st"u"ff'
    assert unquote('"st"u"ff"') == 'st"u"ff"'


# Generated at 2022-06-23 05:01:23.253142
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""') == False
    assert is_quoted('"') == False
    assert is_quoted('"test"') == True
    assert is_quoted('\"test\"') == False # An escaped quote
    assert is_quoted('"""test"""') == True
    assert is_quoted('"""test"') == False # Missing closing quote
    assert is_quoted('"test"""') == False # Missing opening quote


# Generated at 2022-06-23 05:01:29.340233
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote("hello") == "hello"
    assert unquote("'hello") != "hello"
    assert unquote("hello'") != "hello"
    assert unquote('"hello"') == "hello"
    assert unquote('"hello') != "hello"
    assert unquote("hello") == "hello"
    assert unquote("hello'") != "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("'a\\'b'") == "a\\'b"

# Generated at 2022-06-23 05:01:34.075717
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True


# Generated at 2022-06-23 05:01:40.083772
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo bar"') == True)
    assert(is_quoted("'foo bar'") == True)
    assert(is_quoted('foo bar') == False)
    assert(is_quoted('"foo bar') == False)
    assert(is_quoted('foo bar"') == False)
    assert(is_quoted('"foo \'bar"') == True)
    assert(is_quoted('"foo \'bar\'"') == True)


# Generated at 2022-06-23 05:01:43.135463
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("hello")

# Generated at 2022-06-23 05:01:48.546059
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted("''") == True
    assert is_quoted("'a'") == True
    assert is_quoted('"""') == True
    assert is_quoted('"a"') == True

    assert is_quoted('"') == False
    assert is_quoted('\'') == False
    assert is_quoted('"a') == False
    assert is_quoted('a"') == False
    assert is_quoted('a') == False

    assert is_quoted('\\"') == False



# Generated at 2022-06-23 05:01:53.418223
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('foo"')
    assert not is_quoted('"foo\\"')
    assert is_quoted('"f\\"oo"')

# Generated at 2022-06-23 05:01:56.233042
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'


# Generated at 2022-06-23 05:02:07.902703
# Unit test for function unquote
def test_unquote():
    data_list = [
        ('"string"', 'string'),
        ('"\'string\'"', '\'string\''),
        ('"string\'', '"string\''),
        ('\'string"', '\'string"'),
        ('\"string\"', '"string"'),
        ('\'string\'', 'string'),
        ('\'string\'', 'string'),
        ('string', 'string'),
        ('"string', '"string'),
        ('string"', 'string"'),
    ]

    for data in data_list:
        assert unquote(data[0]) == data[1]

# Generated at 2022-06-23 05:02:12.013913
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"\\"foo\\""') == '"foo"'
    assert unquote('"\\"foo"') == '"foo'
    assert unquote('"""foo"""') == '"foo"'

# Generated at 2022-06-23 05:02:19.369598
# Unit test for function is_quoted
def test_is_quoted():
    # test if we get True for quoted strings
    assert is_quoted("'test'") == True
    assert is_quoted('"test"') == True

    # test if we get False for empty and single char strings
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("t") == False

    # test if we get False for unquoted strings
    assert is_quoted("'test") == False
    assert is_quoted('"test') == False
    assert is_quoted("'test\"") == False
    assert is_quoted("\"test'") == False


# Generated at 2022-06-23 05:02:21.684476
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("abc") == 'abc'

# Generated at 2022-06-23 05:02:29.762417
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"') == True, "string containing quotes"
    assert is_quoted("'Hello'") == True, "string containing quotes"
    assert is_quoted("'Hello") == False, "string containing quotes"
    assert is_quoted("Hello'") == False, "string containing quotes"
    assert is_quoted("'Hello' ") == False, "string containing quotes"
    assert is_quoted(" 'Hello'") == False, "string containing quotes"
    assert is_quoted("'He'llo'") == False, "string containing quotes"


# Generated at 2022-06-23 05:02:35.231219
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted("\"foo'")
    assert not is_quoted("'foo\"")
    assert not is_quoted("'foo\\'")
    assert is_quo

# Generated at 2022-06-23 05:02:43.916282
# Unit test for function is_quoted
def test_is_quoted():
    unquoted_string = 'foo'
    assert not is_quoted(unquoted_string)

    quoted_single_string = "'foo'"
    assert is_quoted(quoted_single_string)

    quoted_double_string = '"foo"'
    assert is_quoted(quoted_double_string)

    single_quotes_in_string = 'foo "bar"'
    assert not is_quoted(single_quotes_in_string)

    double_quotes_in_string = 'foo "bar"'
    assert not is_quoted(double_quotes_in_string)

    escaped_quotes_string = '"foo\\""'
    assert not is_quoted(escaped_quotes_string)

    escaped_quotes_string = '\'foo\\\'\''

# Generated at 2022-06-23 05:02:54.305004
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello')
    assert not is_quoted('')
    assert not is_quoted('"""hello"""')
    assert is_quoted('"hell\"o"')
    assert is_quoted("'hell\"o'")
    assert is_quoted("'" + "hello" + "'")
    assert is_quoted('"' + "hello" + '"')
    assert is_quoted('"' + "hello" + "\\'") is False
    assert is_quoted("'hello' \"world\"")
    assert is_quoted("['hello', \"world\"]")
    assert is_

# Generated at 2022-06-23 05:03:01.891490
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\'foo\\\'bar') == '\'foo\\\'bar'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo\\\"bar"') == 'foo\\\"bar'

# Generated at 2022-06-23 05:03:10.431301
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo\"') == '"foo\"'
    assert unquote("'foo\'") == "'foo\'"
    assert unquote('"foo\"baz"') == 'foo\"baz'
    assert unquote("'foo\'baz'") == 'foo\'baz'

# Generated at 2022-06-23 05:03:17.046447
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted('"foo\'"')
    assert not is_quoted("'foo\"")
    assert not is_quoted('foo')
    assert not is_quoted('')
    assert not is_quoted('"')
    assert not is_quoted("'")


# Generated at 2022-06-23 05:03:23.583856
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote('"abc\\""') == '"abc"'
    assert unquote("'abc'") == "abc"
    assert unquote("'abc\\''") == "'abc'"
    assert unquote('"ab\\"c"') == 'ab"c'
    assert unquote("'ab\\'c'") == "ab'c"

# Generated at 2022-06-23 05:03:29.323631
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo\\"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"bar') == False
    assert is_quoted('foo') == False
    assert is_quoted('') == False


# Generated at 2022-06-23 05:03:36.536738
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo\\""')
    assert is_quoted('"foo\\\\""')
    assert is_quoted('\'foo\'')
    assert is_quoted('\'foo\\\'\'')
    assert is_quoted('\'foo\\\\\'\'')
    assert not is_quoted('foo')


# Generated at 2022-06-23 05:03:46.419128
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert not is_quoted('\\"foo\\"')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('\'foo')
    assert not is_quoted('foo\'')
    assert not is_quoted('"foo\'')
    assert not is_quoted('\'foo"')
    assert is_quoted('"foo"')
    assert is_quoted('\'foo\'')
    assert is_quoted('\"foo"')
    assert is_quoted('\'foo\"')


# Generated at 2022-06-23 05:03:52.934007
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"test\\" -X GET"')
    assert not is_quoted('\'test\\" -X GET"')
    assert not is_quoted('test')
    assert not is_quoted('')


# Generated at 2022-06-23 05:04:01.864223
# Unit test for function is_quoted
def test_is_quoted():

    assert(is_quoted('"test"') == True)
    assert(is_quoted('"test') == False)
    assert(is_quoted('test"') == False)
    assert(is_quoted('test') == False)
    assert(is_quoted('"test""') == False)
    assert(is_quoted('"""test"""') == True)
    assert(is_quoted('') == False)
    assert(is_quoted('""') == True)
    assert(is_quoted('"this is "test""') == False)
    assert(is_quoted('"this is test"') == True)
    assert(is_quoted('"this is test""') == False)
    assert(is_quoted('"this is ""test""') == False)

# Generated at 2022-06-23 05:04:09.564006
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert is_quoted('"a\\"b"')
    assert is_quoted("'a\\'b'")
    assert not is_quoted('\\"')
    assert not is_quoted("\\'")
    assert not is_quoted('"')
    assert not is_quoted("'")
    assert not is_quoted('abc')


# Generated at 2022-06-23 05:04:15.425352
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'

# Generated at 2022-06-23 05:04:22.224590
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote("\"test\"") == "test"
    assert unquote("'w\\'t'") == "w\\'t"
    assert unquote("'w\"t'") == "w\"t"
    assert unquote("'w\\\\'") == "w\\\\"
    assert unquote('"w\\\\"') == "w\\\\"


# Generated at 2022-06-23 05:04:29.611804
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert is_quoted("'hell\"o'")
    assert is_quoted('"hell\'o"')
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted('hello\'"')
    assert not is_quoted("hello'\"")


# Generated at 2022-06-23 05:04:37.722315
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted('"test\\"') == False
    assert is_quoted("'test'")
    assert is_quoted("'test\\'") == False
    assert is_quoted('""') == False
    assert is_quoted("''") == False
    assert is_quoted('"foo\\"bar"')
    assert is_quoted('"foo\\"bar') == False
    assert is_quoted("'foo\\'bar") == False
    assert is_quoted("'foo\\'bar'")


# Generated at 2022-06-23 05:04:39.757757
# Unit test for function unquote
def test_unquote():
    assert 'string' == unquote("'string'")
    assert 'string' == unquote('"string"')
    assert 'string' == unquote("string")


# Generated at 2022-06-23 05:04:45.282557
# Unit test for function is_quoted
def test_is_quoted():
    cases = [
        ("foo", False),
        ("'foo'", True),
        ('"foo"', True),
        ("'foo", False),
        ("foo'", False),
        ('"fo\\o"', False),
        ("'fo\\'o'", False),
    ]
    for case in cases:
        assert is_quoted(case[0]) == case[1]


# Generated at 2022-06-23 05:04:49.942968
# Unit test for function is_quoted
def test_is_quoted():
    data = ['foo', '"foo"', '"f\\"oo"', "'foo'", "'f\\'oo'"]
    for d in data:
        assert is_quoted(d) == (d[0] == d[-1] and d[0] in ('"', "'"))


# Generated at 2022-06-23 05:04:56.208472
# Unit test for function unquote
def test_unquote():
    assert unquote("my string") == "my string"
    assert unquote("\"my string\"") == "my string"
    assert unquote("'my string'") == "my string"
    assert unquote("my\\ string") == "my\\ string"
    assert unquote("'my\\' string'") == "my\\' string"
    assert unquote("\"my\\\" string\"") == "my\\\" string"


# Generated at 2022-06-23 05:04:58.352050
# Unit test for function unquote
def test_unquote():
    data = '"test"'
    assert unquote(data) == 'test'

# Generated at 2022-06-23 05:05:01.073636
# Unit test for function unquote
def test_unquote():
    assert(unquote("'foo'") == 'foo')
    assert(unquote('"foo"') == 'foo')
    assert(unquote('foo') == 'foo')

# Generated at 2022-06-23 05:05:06.246492
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'\"") == False
    assert is_quoted('"\'') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False



# Generated at 2022-06-23 05:05:13.762792
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")

    assert not is_quoted('test"')
    assert not is_quoted('test')

    assert not is_quoted('"test')
    assert not is_quoted("'test")

    assert not is_quoted('"test\'"')
    assert not is_quoted("'test\'\"")

    assert not is_quoted('""')
    assert not is_quoted("''")


# Generated at 2022-06-23 05:05:22.531767
# Unit test for function unquote
def test_unquote():
    # correct quotes
    assert unquote('"Hello world!"') == 'Hello world!'
    assert unquote("'Hello world!'") == 'Hello world!'
    # quotes with line breaks
    assert unquote('"Hello\nWorld!"') == "Hello\nWorld!"
    # single quotes inside double quotes
    assert unquote('"Hello \'world\'!"') == "Hello 'world'!"
    # escaped quotes
    assert unquote(r'"Hello \"world\"!"') == r'Hello "world"!'
    # no quotes
    assert unquote('Hello World!') == 'Hello World!'
    # empty string
    assert unquote('') == ''
    # too many quotes
    assert unquote('"""Hello World!"""') == '"Hello World!"'

# Generated at 2022-06-23 05:05:31.062647
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('""test""') == False
    assert is_quoted('"test""') == False
    assert is_quoted('\\"test"') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False
    assert is_quoted('"test') == False
    assert is_quoted('test') == False
    assert is_quoted('test"') == False



# Generated at 2022-06-23 05:05:42.184195
# Unit test for function is_quoted
def test_is_quoted():
    # Test Quotes
    assert(is_quoted('') is False)
    assert(is_quoted('ab') is False)
    assert(is_quoted('"a"') is True)
    assert(is_quoted("'a'") is True)
    assert(is_quoted('"a') is False)
    assert(is_quoted("'a") is False)
    assert(is_quoted('a"') is False)
    assert(is_quoted("a'") is False)
    assert(is_quoted('"a""') is False)
    assert(is_quoted('"a"""') is False)
    assert(is_quoted('"""a"') is False)
    assert(is_quoted('"a') is False)

# Generated at 2022-06-23 05:05:47.607108
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"ab\"c"') == 'ab\"c'
    assert unquote('abc') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'ab\'c'") == 'ab\'c'
    assert unquote('"a"b"c"') == '"a"b"c"'


# Generated at 2022-06-23 05:05:50.154748
# Unit test for function unquote
def test_unquote():
    assert unquote('"example"') == 'example'
    assert unquote("'example'") == 'example'
    assert unquote('example') == 'example'


# Generated at 2022-06-23 05:05:56.662822
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo\\"') == False
    assert is_quoted("'foo\\'") == False
    assert is_quoted("'foo'bar'") == False
    assert is_quoted('"foo"bar"') == False


# Generated at 2022-06-23 05:06:02.918958
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted("'test\"test'") == False
    assert is_quoted('"""test"""') == False
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted(u"\xabtest\xbb") == True

# Generated at 2022-06-23 05:06:10.206629
# Unit test for function unquote
def test_unquote():
    assert unquote('"bar"') == 'bar'
    assert unquote("'bar'") == 'bar'
    assert unquote("'ba\'r'") == "ba\'r"
    assert unquote("bar") == "bar"
    assert unquote("'bar") == "'bar"
    assert unquote("bar'") == "bar'"
    assert unquote(None) == None


# Generated at 2022-06-23 05:06:15.486369
# Unit test for function is_quoted
def test_is_quoted():
    unquoted_data = 'foo bar'
    single_quoted_data = "'foo bar'"
    double_quoted_data = '"foo bar"'

    assert not is_quoted(unquoted_data)
    assert is_quoted(single_quoted_data)
    assert is_quoted(double_quoted_data)


# Generated at 2022-06-23 05:06:25.425703
# Unit test for function unquote
def test_unquote():
    ''' tests unquote function '''

    unquoted = 'hello'

    double_quoted = '"hello"'
    single_quoted = "'hello'"

    double_quoted_with_escaped_quote = '"hel\"lo"'
    single_quoted_with_escaped_quote = "'hel\'lo'"

    assert unquote(unquoted) == unquoted
    assert unquote(double_quoted) == unquoted
    assert unquote(single_quoted) == unquoted

    assert unquote(double_quoted_with_escaped_quote) == double_quoted_with_escaped_quote
    assert unquote(single_quoted_with_escaped_quote) == single_quoted_with_escaped_quote



# Generated at 2022-06-23 05:06:34.403775
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"just a quoted string"') == True)
    assert(is_quoted('"junk') == False)
    assert(is_quoted('\\"junk') == False)
    assert(is_quoted('\\"junk\\"') == True)
    assert(is_quoted('junk') == False)
    assert(is_quoted('') == False)
    assert(is_quoted('""') == False)
    assert(is_quoted('"') == False)
    assert(is_quoted('"""') == False)
    assert(is_quoted('"""junk"""') == True)


# Generated at 2022-06-23 05:06:39.603580
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('hello') == False
    assert is_quoted('') == False

# Generated at 2022-06-23 05:06:44.710474
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted("'foo\\'bar'")


# Generated at 2022-06-23 05:06:52.838731
# Unit test for function is_quoted
def test_is_quoted():
    non_quoted_data = ('foo', 'foo"bar', '"foobar"baz"')
    quoted_data = ('"foo"', "'foo'")
    escaped_quotes = ('"foo\"bar"', "'foo\'bar'")

    for data in non_quoted_data:
        assert not is_quoted(data)

    for data in quoted_data:
        assert is_quoted(data)

    for data in escaped_quotes:
        assert not is_quoted(data)



# Generated at 2022-06-23 05:07:00.765647
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\\\'foo\\\'') == '\\\'foo\\\''
    assert unquote('foo') == 'foo'
    assert unquote('"f\'oo\'"') == 'f\'oo\''
    assert unquote('"foo\\n"') == 'foo\\n'
    assert unquote('"foo" bar') == '"foo" bar'
    assert unquote('"a\\nb"') == 'a\\nb'
    assert unquote('"a\\"b"') == 'a\\"b'
    assert unquote('"a\\\\b"') == 'a\\b'

# Generated at 2022-06-23 05:07:11.984754
# Unit test for function unquote
def test_unquote():
    if unquote('') != '':
        raise ("unquote('') should return ''")
    if unquote('foo') != 'foo':
        raise ("unquote('foo') should return 'foo'")
    if unquote('"foo"') != 'foo':
        raise ("unquote('\"foo\"') should return 'foo'")
    if unquote("'foo'") != 'foo':
        raise ("unquote(\"'foo'\") should return 'foo'")
    if unquote('"fo\\"o"') != 'fo\\"o':
        raise ("unquote('\"fo\\\"o\"') should return 'fo\\\"o'")

# Generated at 2022-06-23 05:07:20.560543
# Unit test for function unquote

# Generated at 2022-06-23 05:07:25.510254
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote('foo"') != 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo\'"') == 'foo\''


# Generated at 2022-06-23 05:07:35.171170
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo\\"bar"') == 'foo"bar'
    assert unquote('"foo\\"bar') == 'foo"bar'
    assert unquote('"foo"bar"') == 'foobar'
    assert unquote('\\"foo\\"') == '"foo"'
    assert unquote('"foo""bar') == 'foo"bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\'bar') == 'foo\'bar'
    assert unquote('"foo"\'bar"') == 'foo\'bar'
    assert unquote

# Generated at 2022-06-23 05:07:46.532053
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'               # unquoted string
    assert unquote('''"foo"''') == 'foo'         # double quoted string
    assert unquote("'''foo'") == 'foo'           # single quoted string
    assert unquote(''' "foo" ''') == ' "foo" '   # string with surrounding spaces
    assert unquote('''"foo"bar"''') == '"foo"bar"', unquote('''"foo"bar"''')  # string with no closing quote
    assert unquote('''"foo" "bar"''') == '"foo" "bar"'  # string with spaces in it
    assert unquote('''"foo\\\"bar"''') == '"foo\\\"bar"'  # string with escaped quote in it

# Generated at 2022-06-23 05:07:49.606235
# Unit test for function unquote
def test_unquote():
    assert unquote("\"spaced value\"") == "spaced value"
    assert unquote("spaced value") == "spaced value"
    assert unquote("'spaced value'") == "spaced value"



# Generated at 2022-06-23 05:07:55.653431
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote("'test") == "'test"
    assert unquote("test'") == "test'"
    assert unquote('"test') == '"test'
    assert unquote('test') == 'test'
    assert unquote('\\"test\\"') == '\\"test\\"'
    assert unquote('"\\"test\\""') == '\\"test\\"'

# Generated at 2022-06-23 05:07:59.529509
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote("'foo'bar") == "'foo'bar"


# Generated at 2022-06-23 05:08:05.442916
# Unit test for function unquote
def test_unquote():
    ''' basic tests for the unquote function '''
    assert unquote(r'"abc"') == r'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a \\"bc"') == r'a \\"bc'
    assert unquote('\'a \\"bc\'') == r'a \\"bc'
    assert unquote('"a \\\'bc"') == r"a \\\'bc"
    assert unquote(r'"a \'bc"') == r"a \'bc"
    assert unquote('\'a \\bc\'') == r'a \\bc'
    assert unquote(r'"abc"') == r'abc'

# Generated at 2022-06-23 05:08:10.835343
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo"bar"')
    assert is_quoted('""foo""')
    assert is_quoted('"""foobar"')
    assert is_quoted('"foo"')



# Generated at 2022-06-23 05:08:16.677318
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foobar"') is True)
    assert(is_quoted('"foo\"bar"') is False)
    assert(is_quoted('\'foobar\'') is True)
    assert(is_quoted('\'foo\\\'bar\'') is False)
    assert(is_quoted('foobar') is False)


# Generated at 2022-06-23 05:08:20.638858
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted('\'foo\'') == True
    assert is_quoted('"foo\'') == False
    assert is_quoted('"foo\\\'') == False
    assert is_quoted('foo') == False


# Generated at 2022-06-23 05:08:26.732336
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("'foo\\''") == "'foo\\''"
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo\\""') == 'foo\\"'



# Generated at 2022-06-23 05:08:38.443056
# Unit test for function is_quoted
def test_is_quoted():
    # check single quoted strings
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("'fo''o'") == True
    assert is_quoted("'fo'o'") == False
    assert is_quoted("'fo'") == True
    assert is_quoted("'fo''") == False
    assert is_quoted("'fo\\''") == True
    assert is_quoted("'fo\\'o'") == False
    assert is_quoted("'fo\\'") == True
    assert is_quoted("'fo\\'''") == False

    # check double quoted strings
    assert is_quoted('"foo"') == True

# Generated at 2022-06-23 05:08:44.115759
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is quoted"')
    assert not is_quoted('"the quote at the end is escaped, so it is not really at the end\\"')
    assert is_quoted("'this is quoted too'")
    assert not is_quoted("'the quote at the start is escaped, so it is not really at the start\\'")
    assert not is_quoted('this is not quoted')



# Generated at 2022-06-23 05:08:49.941553
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted('"test\\""') == True
    assert is_quoted('test') == False

# Generated at 2022-06-23 05:08:57.441609
# Unit test for function unquote
def test_unquote():
    assert is_quoted("'foo bar'")
    assert not is_quoted("'foo bar\\'")
    assert not is_quoted("s'foo bar'")
    assert not is_quoted(" 'foo bar'")
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("'foo''bar'") == "foo'bar"

# Generated at 2022-06-23 05:09:05.249866
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"xxx"')
    assert is_quoted('\'xxx\'')
    assert not is_quoted('"xxx\'')
    assert not is_quoted('\'xxx"')
    assert not is_quoted('xxx')
    assert not is_quoted('"xx\'')
    assert not is_quoted('\'xx"')
    assert not is_quoted('"xx\'')
    assert not is_quoted('xxx"')
    assert not is_quoted('xxx\'')


# Generated at 2022-06-23 05:09:13.523214
# Unit test for function unquote
def test_unquote():
    data1a = '"foo"'
    data1b = "'foo'"
    data2a = '"foo bar"'
    data2b = "'foo bar'"
    data3 = '" \\" foo "'
    data4 = 'foo'
    assert unquote(data1a) == 'foo'
    assert unquote(data1b) == 'foo'
    assert unquote(data2a) == 'foo bar'
    assert unquote(data2b) == 'foo bar'
    assert unquote(data3) == '" \\ foo "'
    assert unquote(data4) == 'foo'

# Generated at 2022-06-23 05:09:19.470727
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('"hello world"') == True
    assert is_quoted("'hello world'") == True
    assert is_quoted('"hello world') == False
    assert is_quoted("'hello world)") == False
    assert is_quoted('hello world') == False


# Generated at 2022-06-23 05:09:30.302868
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo"\\"')
    assert is_quoted('foo\\""')
    assert is_quoted('"foo"')
    assert is_quoted('"foo" ')
    assert is_quoted('"foo" "bar"')
    assert is_quoted('"""foo"""')
    assert is_quoted('\'"foo"\'')
    assert is_quoted('"foo')
    assert is_quoted('foo"')
    assert is_quoted('\"foo\"')
    assert is_quoted('\"foo\"')
    assert is_quoted('\\"foo\\"')

# Generated at 2022-06-23 05:09:34.335424
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"

# Generated at 2022-06-23 05:09:41.585436
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'1'") == True)
    assert(is_quoted("'hello'") == True)
    assert(is_quoted("\"hello\"") == True)
    assert(is_quoted("\"hello") == False)
    assert(is_quoted("hello\"") == False)
    assert(is_quoted("'hello") == False)
    assert(is_quoted("hello'") == False)


# Generated at 2022-06-23 05:09:45.134640
# Unit test for function unquote
def test_unquote():
    assert unquote('"this is a test"') == 'this is a test'
    assert unquote("'this is a test'") == 'this is a test'
    assert unquote("this is a test") == 'this is a test'

# Generated at 2022-06-23 05:09:56.701573
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"toto"') == True
    assert is_quoted('"toto\'"') == True
    assert is_quoted('"tot"o"') == True
    assert is_quoted('\'tot"o\'') == True

    assert is_quoted("'toto'") == True
    assert is_quoted("'toto\"'") == True
    assert is_quoted("'tot'o'") == True
    assert is_quoted("\"tot'o\"") == True

    assert is_quoted("\"toto'") == False
    assert is_quoted("'toto'\"") == False
    assert is_quoted("'toto''") == False
    assert is_quoted('"toto"\'') == False
    assert is_qu

# Generated at 2022-06-23 05:10:01.507355
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('test"')
    assert not is_quoted('test"')
    assert not is_quoted('test')


# Generated at 2022-06-23 05:10:12.241807
# Unit test for function is_quoted
def test_is_quoted():
    # No quotes
    assert not is_quoted('abcd')

    # Single quote
    assert is_quoted("'abcd'")
    assert not is_quoted("a'bcd'")
    assert not is_quoted("'abcd")

    # Double quote
    assert is_quoted('"abcd"')
    assert not is_quoted('a"bcd"')
    assert not is_quoted('"abcd')

    # Mixed
    assert is_quoted('"ab\'cd"')
    assert not is_quoted('"ab\'cd\'')

    # Mixed with escapes
    assert is_quoted('"ab\\"cd"')
    assert not is_quoted('"ab\\"cd\\""')


# Generated at 2022-06-23 05:10:20.115530
# Unit test for function is_quoted
def test_is_quoted():
    # fail without quotes
    assert is_quoted("test") == False

    # fail if quotes not on outside
    assert is_quoted("'test'") == False

    # fail if multi-line
    assert is_quoted("'test\ntest'") == False

    # fail if quote is escaped
    assert is_quoted("'\"test\"'") == False

    # success if quoted
    assert is_quoted("'test'") == True
    assert is_quoted('"test"') == True


# Generated at 2022-06-23 05:10:30.636487
# Unit test for function unquote
def test_unquote():
    assert unquote(None) == unquote(None)

    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"""hello"""') == '"hello"'
    assert unquote('"hello""') == '"hello"'
    assert unquote('"""hello"') == '"""hello"'
    assert unquote('"""hello"') == '"""hello"'
    assert unquote('"""hello') == '"""hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'

    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"') == 'foo'
    assert un

# Generated at 2022-06-23 05:10:36.429075
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello world'")
    assert is_quoted('"hello world"')
    assert not is_quoted("'hello world")
    assert not is_quoted("hello world'")
    assert not is_quoted("hello world")
    assert not is_quoted("'hello world\\''")
    assert not is_quoted('"hello world\\""')


# Generated at 2022-06-23 05:10:41.345427
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert is_quoted('"test"')
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("test")



# Generated at 2022-06-23 05:10:44.694497
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == "hello world"
    assert unquote('hello world') == "hello world"
    assert unquote("'hello world'") == "hello world"