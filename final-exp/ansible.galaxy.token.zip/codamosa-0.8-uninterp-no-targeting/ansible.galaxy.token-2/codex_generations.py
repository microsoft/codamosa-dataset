

# Generated at 2022-06-20 14:46:42.982827
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    display.verbosity = 4
    token = GalaxyToken()
    token.set('TestToken')

    # check that the token file is created
    assert os.path.exists(to_bytes(C.GALAXY_TOKEN_PATH))
    mode = oct(os.stat(to_bytes(C.GALAXY_TOKEN_PATH)).st_mode & 0o777)
    assert mode == '0600'

    # check that the token file is correctly written
    with open(to_bytes(C.GALAXY_TOKEN_PATH)) as f:
        assert yaml_load(f) == {'token': 'TestToken'}

# Generated at 2022-06-20 14:46:52.511530
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():

    print("Testing constructor of class GalaxyToken")

    # Happy path: No arguments
    # Expected: object instance
    g = GalaxyToken()
    assert(isinstance(g, GalaxyToken))

    # Happy path: token arg
    # Expected: object instance
    g = GalaxyToken(token='c0f6a3a6e2c4e4d6d20a6170e1f77299c8aa0e10')
    assert(isinstance(g, GalaxyToken))

    # Unhappy path: token arg
    # Expected: TypeError
    g = GalaxyToken(token=123)
    assert(isinstance(g, GalaxyToken))

    # Unhappy path: token arg
    # Expected: TypeError

# Generated at 2022-06-20 14:46:55.055536
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken(auth_url='http://example.com', access_token='token')

    assert kct.auth_url == 'http://example.com'
    assert kct.access_token == 'token'


# Generated at 2022-06-20 14:46:57.629101
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token="abcd1234")
    header = token.headers()
    assert header['Authorization'] == 'Bearer None'


# Generated at 2022-06-20 14:47:02.433702
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'test_token'
    token_object = GalaxyToken()
    before_token = token_object.get()
    token_object.set(token)
    assert(token_object.get() == token)
    token_object.set(before_token)
    assert(token_object.get() == before_token)

# Generated at 2022-06-20 14:47:07.099754
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = 'testuser'
    password = 'testpass'
    token = BasicAuthToken(username, password)
    assert token.get() == 'dGVzdHVzZXI6dGVzdHBhc3M='



# Generated at 2022-06-20 14:47:11.321278
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    basic_auth_token = BasicAuthToken(username='admin', password='secret')
    headers = basic_auth_token.headers()
    assert headers == {'Authorization': 'Basic YWRtaW46c2VjcmV0\n'}


# Generated at 2022-06-20 14:47:13.558528
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)

# Generated at 2022-06-20 14:47:20.716462
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    file_name = 'test_token.yml'
    with open(file_name, 'w') as f:
        yaml_dump({'token': 'foo'}, f)
    token = GalaxyToken(file_name)
    token.set('bar')
    assert token.get() == 'bar'
    os.remove(file_name)

# Generated at 2022-06-20 14:47:25.000774
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    t = GalaxyToken('1234567890abcdef')
    t.set('0987654321abcdef')
    assert '1234567890abcdef' != t.config['token']
    assert '0987654321abcdef' == t.config['token']



# Generated at 2022-06-20 14:47:34.151448
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('Basic', 'Basic')
    token.get()
    assert token.headers() == {'Authorization': 'Basic Basic'}

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=['-vrsx', os.path.abspath(__file__)]))

# Generated at 2022-06-20 14:47:37.135124
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    assert galaxy_token.get() is None
    galaxy_token.set('abc123')
    assert galaxy_token.get() == 'abc123'

# Generated at 2022-06-20 14:47:42.539731
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Valid username/password
    BasicAuthToken("foo", "bar")

    # Valid username/no password
    BasicAuthToken("foo")

    # Invalid username/valid password
    try:
        BasicAuthToken("", "bar")
    except TypeError as e:
        pass
    else:
        raise TypeError("BasicAuthToken didn't fail to construct as expected!")

# Generated at 2022-06-20 14:47:45.840562
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()

    assert token.b_file == to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    assert token._config == None


# Generated at 2022-06-20 14:47:49.774242
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    GalaxyToken = GalaxyToken(token='my token')
    class Dummy(object):
        def __init__(self, value):
            self.value = value

    headers = GalaxyToken.headers()
    assert(isinstance(headers, dict))
    assert('Authorization' in headers)
    assert(headers['Authorization']=='Token my token')


# Generated at 2022-06-20 14:47:54.893829
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    class TestTokenHeadersKeycloakToken(KeycloakToken):
        def __init__(self, *args, **kwargs):
            pass

    test_instance = TestTokenHeadersKeycloakToken()
    test_instance.get = lambda: "TestToken"

    assert test_instance.headers() == {"Authorization": "Bearer TestToken"}


# Generated at 2022-06-20 14:47:57.401669
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    if not hasattr(BasicAuthToken, 'get'):
        return False
    else:
        return True


# Generated at 2022-06-20 14:47:59.103434
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert gt is not None

# Generated at 2022-06-20 14:48:03.041812
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    from ansible.module_utils.keycloak_utils import KeycloakToken
    token = KeycloakToken(access_token='sometoken', auth_url='somelogin', client_id='someclient')
    header = token.headers()
    assert header['Authorization'] == 'Bearer %s' % token.get()

# Generated at 2022-06-20 14:48:05.389603
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('username', 'password')
    assert token.headers() == {
        'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='
    }

# Generated at 2022-06-20 14:48:13.464434
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    token_path = tempfile.mktemp()
    token = GalaxyToken(token_path)
    token.set(token_path)
    token.save()

# Generated at 2022-06-20 14:48:15.582884
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = "abcd1234"
    t = GalaxyToken("")
    t.set(token)
    assert t.get() == token

# Generated at 2022-06-20 14:48:17.780232
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='
    token_object = BasicAuthToken('username', 'password')
    assert token_object.get() == token


# Generated at 2022-06-20 14:48:23.331953
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson

    with patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.galaxy_token.open_url') as mock_open_url:
        token = KeycloakToken(access_token='dummy_access_token', auth_url='dummy_auth_url')
        data = {'access_token': 'dummy_access_token'}
        mock_open_url.configure_

# Generated at 2022-06-20 14:48:26.604907
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'admin'
    password = 'pass'
    token = 'Basic YWRtaW46cGFzcw=='
    basicAuth = BasicAuthToken(username, password)
    assert token == basicAuth.get()


# Generated at 2022-06-20 14:48:33.608793
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    import ansible.module_utils.six.moves.urllib.parse as urllib
    test_username = 'test_username'
    test_password = 'test_password'
    assert urllib.quote(test_username) == 'test_username'
    assert urllib.quote(test_password) == 'test_password'
    basic_auth_token = BasicAuthToken(test_username, test_password)
    assert basic_auth_token.get() == 'dGVzdF91c2VybmFtZTp0ZXN0X3Bhc3N3b3Jk'

# Generated at 2022-06-20 14:48:40.339179
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken(access_token='testtoken')
    headers = k.headers()
    assert headers['Authorization'] == 'Bearer testtoken'

    k = KeycloakToken(access_token='testtoken', client_id='theclientid')
    headers = k.headers()
    assert headers['Authorization'] == 'Bearer testtoken'



# Generated at 2022-06-20 14:48:42.174883
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='password123')
    expected_headers = {'Authorization': 'Token password123'}
    assert token.headers() == expected_headers

# Generated at 2022-06-20 14:48:43.101099
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoTokenSentinel()

# Unit tests for constructor of class KeycloakToken

# Generated at 2022-06-20 14:48:48.595432
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    ''' Unit test for method set of GalaxyToken class '''
    token = 'abcdefghijklmnopqrstuvwxyz'
    gt = GalaxyToken()
    gt.set(token)
    assert gt.get() == token
    assert 'token: ' + token in open(C.GALAXY_TOKEN_PATH).read()


# Generated at 2022-06-20 14:48:52.360675
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)

# Generated at 2022-06-20 14:48:55.006652
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken("my token")
    token.set("my token")
    assert token.headers()['Authorization'] == "Token my token"


# Generated at 2022-06-20 14:49:06.157122
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    config_content = ''
    config_path = './ansible.cfg'
    with open(config_path, 'w') as f:
        f.write(config_content)
    token = GalaxyToken()
    assert token.get() is None

    config_content = '''
galaxy_token_file = /tmp/token.yml
'''
    with open(config_path, 'w') as f:
        f.write(config_content)
    token = GalaxyToken()
    assert token.get() is None

    config_content = '''
galaxy_token_file = /tmp/token.yml
token = fake-token
'''
    with open('./token.yml', 'w') as f:
        f.write(config_content)
    token = GalaxyToken()

# Generated at 2022-06-20 14:49:10.172989
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = 'testtoken'
    G = GalaxyToken()
    G.set(test_token)
    assert G.get() == test_token


# Generated at 2022-06-20 14:49:14.564051
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    """
    Test to ensure that ansible.galaxy.api.NoTokenSentinel properly
    overrides __new__ to return itself.
    """
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)


# Generated at 2022-06-20 14:49:19.787817
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    r = BasicAuthToken('testuser', 'testpass')
    assert r.get() == 'dGVzdHVzZXI6dGVzdHBhc3M='
    assert r.headers() == {'Authorization': 'Basic dGVzdHVzZXI6dGVzdHBhc3M='}


# Generated at 2022-06-20 14:49:25.243464
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    config = { 'token' : 'test_token' }
    t = GalaxyToken()
    t._config = config
    t.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    os.unlink(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-20 14:49:29.891872
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    token = '1meow'
    gt = GalaxyToken(token)
    # test for 'empty state'
    assert gt.config == {}
    # save token
    gt.set(token)
    # test for 'saved state'
    assert gt.config == {'token': token}

# Generated at 2022-06-20 14:49:33.798641
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    args = [""]
    kwargs = {"": ""}
    token = NoTokenSentinel.__new__(NoTokenSentinel, *args, **kwargs)
    assert token


# Generated at 2022-06-20 14:49:38.662101
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='access_token')
    assert token.access_token == 'access_token'
    assert token.auth_url is None
    assert token.validate_certs == True
    assert token.client_id == 'cloud-services'


# Generated at 2022-06-20 14:49:43.040796
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('token')
    assert token.headers() == {'Authorization': 'Token token'}

# Generated at 2022-06-20 14:49:51.591883
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    s = NoTokenSentinel()
    assert s.__class__.__name__ == 'NoTokenSentinel'
    assert s.__str__() == 'NoTokenSentinel'
    assert s.__repr__() == 'NoTokenSentinel'


# Generated at 2022-06-20 14:50:00.785787
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():

    import tempfile

    class DisplayMock:

        def __init__(self):
            self.vvv_count = 0

        def vvv(self, msg):
            if 'Created' in msg:
                self.vvv_count += 1

    display = DisplayMock()
    token = GalaxyToken(token='foo')

    # check that token file is created on first set()
    with tempfile.TemporaryDirectory() as temp_dir:
        C.GALAXY_TOKEN_PATH = os.path.join(temp_dir, 'galaxy_config')
        token.set('foo')
        assert token.config['token'] == 'foo'
        assert display.vvv_count == 1
        # check that token file is not recreated on second set()
        token.set('foo')

# Generated at 2022-06-20 14:50:06.191434
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # Create a dummy file
    # file = open("/tmp/dummyfile", "w")
    # file.write("message\n")
    # file.close()

    galaxyToken = GalaxyToken()
    headers = galaxyToken.headers()
    assert headers == {}, "Headers should be empty"

    galaxyToken.set('GalaxyToken')
    headers = galaxyToken.headers()
    assert headers == {'Authorization': 'Token GalaxyToken'}, "Headers should not be empty"

# Generated at 2022-06-20 14:50:11.823927
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_stored = "my_token"
    gt = GalaxyToken(token=token_stored)
    if gt.get() != token_stored:
        raise AssertionError("token stored: %s, token got: %s" % (token_stored, gt.get()))

# Generated at 2022-06-20 14:50:13.514160
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    obj = NoTokenSentinel()
    assert isinstance(obj, object) is True

# Generated at 2022-06-20 14:50:17.357363
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    test = BasicAuthToken('username', 'password')
    expected = {'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='}
    assert test.headers() == expected

# Generated at 2022-06-20 14:50:22.401527
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('Username', 'Password')
    header = token.headers()
    assert header == {'Authorization': 'Basic VXNlcm5hbWU6UGFzc3dvcmQ='}

    token = BasicAuthToken('Username', None)
    header = token.headers()
    assert header == {'Authorization': 'Basic VXNlcm5hbWU6'}



# Generated at 2022-06-20 14:50:27.439901
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    ''' Creates the token object
    '''
    access_token = 'accesstoken'
    auth_url = 'http://localhost/'
    validate_certs = False
    token = KeycloakToken(access_token, auth_url, validate_certs)
    assert token.access_token == access_token
    assert token.auth_url == auth_url
    assert token.validate_certs is False


# Generated at 2022-06-20 14:50:31.716309
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    """
    Class NoTokenSentinel can not be instantiated, should throw RuntimeError
    """
    try:
        NoTokenSentinel("toto")
        assert False, "NoTokenSentinel can not be instantiated"
    except RuntimeError:
        assert True


# Generated at 2022-06-20 14:50:45.242931
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Test NoTokenSentinel
    token = GalaxyToken(NoTokenSentinel()).get()
    assert not token

    # Test no token
    token = GalaxyToken().get()
    assert not token

    # Test existing token
    existing_token = 'existing_token'
    token = GalaxyToken(token=existing_token).get()
    assert token == existing_token

    # Test existing invalid token
    existing_token = {'invalid_token': 'token'}
    token = GalaxyToken(token=existing_token).get()
    assert not token

    # Test existing token in token file
    token_file = 'tests/galaxy/test_token'
    f = os.open(token_file, os.O_RDWR | os.O_CREAT)
    token = GalaxyToken(token=existing_token)._read()


# Generated at 2022-06-20 14:50:52.779072
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    tests = [
        dict(
            token=None,
            expected=None
        ),
        dict(
            token='foobar',
            expected='Token foobar'
        )
    ]

    for test in tests:
        # FIXME: pytest for side-effects is hard
        gtoken = GalaxyToken(test['token'])
        headers = gtoken.headers()
        actual = headers.get('Authorization', None)
        assert actual == test['expected'], "Expected %s, got %s" % (test['expected'], actual)



# Generated at 2022-06-20 14:50:58.798339
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    test_obj = KeycloakToken(auth_url="www.example.com", access_token="super_secret_token")
    assert test_obj.auth_url == "www.example.com"
    assert test_obj._form_payload() == "grant_type=refresh_token&client_id=cloud-services&refresh_token=super_secret_token"
    assert test_obj.token_type == 'Bearer'
    assert test_obj.get() is None
    assert test_obj.headers() == {'Authorization': 'Bearer None'}



# Generated at 2022-06-20 14:51:08.524482
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'pass')
    expected_token = 'dXNlcjpwYXNz'
    actual_token = token.get()
    assert actual_token == expected_token

    token = BasicAuthToken('user', '')
    expected_token = 'dXNlcjo='
    actual_token = token.get()
    assert actual_token == expected_token

    token = BasicAuthToken('user')
    expected_token = 'dXNlcjo='
    actual_token = token.get()
    assert actual_token == expected_token

# Generated at 2022-06-20 14:51:10.837564
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    g = GalaxyToken("")
    g.config = {"token": "foo"}
    headers = g.headers()
    assert headers['Authorization'] == 'Token foo'


# Generated at 2022-06-20 14:51:18.837294
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create tmp file
    tmp_file = '/tmp/galaxy_test_save12345'
    open(tmp_file, 'w').close()
    os.chmod(tmp_file, S_IRUSR | S_IWUSR)  # owner has +rw

    test_token = '12345678901234'
    galaxy_token_obj = GalaxyToken()
    galaxy_token_obj.b_file = to_bytes(tmp_file, errors='surrogate_or_strict')

    # Test "KeyError: 'token'" exception
    with open(galaxy_token_obj.b_file, 'w') as f:
        yaml_dump('aaaa', f, default_flow_style=False)

# Generated at 2022-06-20 14:51:22.052984
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    ret = BasicAuthToken('user', 'pass')
    assert ret.get() == 'dXNlcjpwYXNz'

# Generated at 2022-06-20 14:51:29.866660
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'asdf1234asdf'
    auth_url = 'http://dummy'
    validate_certs = True
    client_id = 'client_id'
    expected_token = 'Bearer %s' % access_token
    k = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=validate_certs, client_id=client_id)
    assert k.headers() == {'Authorization': expected_token}



# Generated at 2022-06-20 14:51:32.101446
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert type(token) is NoTokenSentinel

# Generated at 2022-06-20 14:51:36.822450
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='ThisIsAToken')
    headers = token.headers()
    assert 'Authorization' in headers
    assert headers['Authorization'] == 'Bearer ' + token.get()



# Generated at 2022-06-20 14:51:52.196999
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.yaml import yaml_load
    import os

    display.vvv = lambda *a, **k: None

    # Create the empty token file
    galaxy_token_file = 'test_token_file'
    open(galaxy_token_file, 'a').close()
    os.chmod(galaxy_token_file, S_IRUSR | S_IWUSR)

    galaxy_token_file2 = 'test_token_file2'
    galaxy_token_file3 = 'test_token_file3'
    open(galaxy_token_file2, 'a').close()
    os.chmod(galaxy_token_file2, S_IRUSR | S_IWUSR)


# Generated at 2022-06-20 14:52:03.143390
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    test_values = (
        # Refresh token, auth url, results
        ('test_refresh_token', 'test_auth_url', KeycloakToken('test_refresh_token', 'test_auth_url')),
        ('test_refresh_token', 'http://prefix.com/suffix/', KeycloakToken('test_refresh_token', 'http://prefix.com/suffix/')),
        ('test_refresh_token', 'http://prefix.com/suffix', KeycloakToken('test_refresh_token', 'http://prefix.com/suffix')),
    )

    for refresh_token, auth_url, results in test_values:
        result = KeycloakToken(refresh_token, auth_url)

# Generated at 2022-06-20 14:52:07.567631
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    g_token = GalaxyToken()
    assert isinstance(g_token.headers(), dict)
    assert 'Authorization' in g_token.headers() and \
        g_token.headers()['Authorization'] == 'Token %s' % g_token.get()


# Generated at 2022-06-20 14:52:08.808990
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert isinstance(token, GalaxyToken)


# Generated at 2022-06-20 14:52:17.031921
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    if not os.path.exists(C.GALAXY_TOKEN_PATH):
        assert False

    token.set('123')
    assert token.get() == '123'

# Generated at 2022-06-20 14:52:29.319181
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url_ok = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    auth_url_ko = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token2'
    access_token_ko = 'ko'
    access_token_ok = 'ok'
    client_id_ko = 'ko'
    client_id_ok = 'ok'

    token_ko = KeycloakToken(auth_url=auth_url_ko, access_token=access_token_ko, client_id=client_id_ko)

# Generated at 2022-06-20 14:52:36.826959
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'foo'
    password = 'bar'
    expected_token = 'Basic Zm9vOmJhcg=='
    token = BasicAuthToken(username, password)
    assert token.get() == expected_token

# Generated at 2022-06-20 14:52:43.667501
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_Galaxy = GalaxyToken('test_token')
    assert test_Galaxy.get() is None
    test_Galaxy.set(NoTokenSentinel)
    assert test_Galaxy.get() is None
    test_Galaxy.set('set_token')
    assert test_Galaxy.get() == 'set_token'
    test_Galaxy.set(None)
    assert test_Galaxy.get() is None


# Generated at 2022-06-20 14:52:48.074560
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    username = 'alice'
    password = 'secret'
    kt = KeycloakToken(username, password)
    expected = 'Bearer %s' % KeycloakToken._encode_token(username, password)
    assert kt.headers()['Authorization'] == expected

# Generated at 2022-06-20 14:52:50.768681
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('refresh_token')

    headers = token.headers()

    assert('Authorization' in headers)
    assert(headers['Authorization'] == 'Bearer None')



# Generated at 2022-06-20 14:53:07.322642
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    """Unit test for method headers of class GalaxyToken"""
    import json
    import ast

    # Generates a token for testing
    token_file = open(C.GALAXY_TOKEN_PATH, 'w')
    token_dict = {}
    token_dict['token'] = 'DUMMY_TOKEN'
    token_file.write(json.dumps(token_dict))

    # Creates a GalaxyToken object
    galaxy_token = GalaxyToken()

    # Get header
    header = galaxy_token.headers()

    # Parses the header
    header_str = str(header)
    header_dict = ast.literal_eval(header_str)

    assert 'Token DUMMY_TOKEN' in header_dict.values()

    # Cleans a file for the test
    token_file.close()
   

# Generated at 2022-06-20 14:53:22.388289
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # test initialization with a token
    token = KeycloakToken('this is a token')
    assert token is not None
    assert token.access_token == 'this is a token'
    assert token.client_id is None

    token = KeycloakToken('this is a token', client_id='foo')
    assert token is not None
    assert token.access_token == 'this is a token'
    assert token.client_id == 'foo'

    # test initialization with no token
    token = KeycloakToken()
    assert token is not None
    assert token.access_token is None
    assert token.client_id is None

    token = KeycloakToken(None, client_id='foo')
    assert token is not None
    assert token.access_token is None
    assert token.client_id == 'foo'



# Generated at 2022-06-20 14:53:25.973798
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='foo', auth_url='https://www.ansible.com/')
    assert(token._token is None)
    assert(token.access_token == 'foo')
    assert(token.auth_url == 'https://www.ansible.com/')


# Generated at 2022-06-20 14:53:31.323692
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('username', 'password')
    headers = token.headers()
    if not headers.keys() is ['Authorization']:
        raise Exception('headers is not correct')
    if not headers['Authorization'] is 'Basic dXNlcm5hbWU6cGFzc3dvcmQ=':
        raise Exception('headers is not correct')

# Generated at 2022-06-20 14:53:33.062053
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nosentinel = NoTokenSentinel()
    assert nosentinel
    assert isinstance(nosentinel, NoTokenSentinel)


# Generated at 2022-06-20 14:53:38.202677
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('foo', 'bar')
    assert token.get() == 'Zm9vOmJhcg=='
    token = BasicAuthToken('foo')
    assert token.get() == 'Zm9vOg=='



# Generated at 2022-06-20 14:53:40.871267
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('my_token')
    assert token.headers() == {'Authorization': 'Token my_token'}



# Generated at 2022-06-20 14:53:41.520286
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()


# Generated at 2022-06-20 14:53:49.496095
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloaktoken = KeycloakToken(access_token='LfRgUabKjY1YH0Q0MtZRX9XpBUjB0oV7hJ3qFxV7c4a',
                                  auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                                  validate_certs=True,
                                  client_id='cloud-services')

# Generated at 2022-06-20 14:53:51.886912
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    t = NoTokenSentinel()
    assert t is not None
    assert type(t) is NoTokenSentinel


# Generated at 2022-06-20 14:53:59.465474
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken(token="c98d0a13e0d41c8a")
    assert token.get() == "c98d0a13e0d41c8a"

# Generated at 2022-06-20 14:54:01.100112
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    for token, expect_token in [(NoTokenSentinel, None), ('', None), ('test_value', 'test_value')]:
        gt = GalaxyToken(token)
        assert gt.get() == expect_token


# Generated at 2022-06-20 14:54:03.211517
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    test_token = NoTokenSentinel()
    assert test_token is not None

# Generated at 2022-06-20 14:54:08.663204
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken(token='token').get()
    assert token == 'token'
    token = GalaxyToken(token=None).get()
    assert token is None
    token = GalaxyToken(None).get()
    assert token is None


# Generated at 2022-06-20 14:54:09.848001
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
   gt = GalaxyToken()
   assert gt.save() == None

# Generated at 2022-06-20 14:54:13.296314
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'ASDFGHJ'
    galaxy_token = GalaxyToken(None)
    galaxy_token.set(token)
    assert galaxy_token.get() == token
    assert galaxy_token.config['token'] == token

# Generated at 2022-06-20 14:54:16.684047
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(auth_url='http://foo', access_token='fog')
    kt.get()
    assert kt.headers() == {'Authorization': 'Bearer %s' % kt.get()}

# Generated at 2022-06-20 14:54:23.342476
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Method should return a different object every time it is called
    assert NoTokenSentinel() is not NoTokenSentinel()

# Create token object for testing
b64_token = BasicAuthToken('username@redhat.com', 'password')

# Unit tests for method _encode_token of class BasicAuthToken

# Generated at 2022-06-20 14:54:34.407708
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    from ansible.compat.tests import mock

    class KeycloakTokenTestCase(unittest.TestCase):

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            # Given
            access_token = '1a2b3c4d'
            auth_url = 'http://example.com'
            validate_certs = True
            client_id = None

            keycloak_token = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=validate_certs, client_id=client_id)

            # When
            response = keycloak_token.get()

            # Then

# Generated at 2022-06-20 14:54:38.963415
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'foo'
    auth_url = 'https://localhost/auth'
    token = KeycloakToken(access_token=access_token,auth_url=auth_url)
    assert token.auth_url == auth_url
    assert token.access_token == access_token
    assert token.token_type == 'Bearer'

# Generated at 2022-06-20 14:54:46.266308
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():

    galaxy_token = GalaxyToken()
    galaxy_token.set("test")

    assert galaxy_token.get() == "test"


# Generated at 2022-06-20 14:54:48.216497
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token_from_constructor = GalaxyToken()
    token_from_read = GalaxyToken().get()

# Generated at 2022-06-20 14:54:56.815884
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    # Create temporary directory
    os.makedirs('./test_tmp')
    # Create temporary token file
    os.mknod('./test_tmp/test_token_file.yml')
    # Create temporary galaxy token
    token = GalaxyToken()
    # Set token value for temporary token file
    token.set('test_token_value')
    # Run method save
    token.save()
    # Read from temporary token file
    with open('./test_tmp/test_token_file.yml', 'r') as f:
        config = yaml_load(f)
    # Check if saved token value is correct
    assert config == {'token': 'test_token_value'}


# Generated at 2022-06-20 14:54:59.527881
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = 'admin'
    password = 'password'
    b = BasicAuthToken(username, password)
    headers = b.headers()
    token = b.get()

    # The length of the token must be greater than 28 because
    # the base64 encoder encodes 3 bytes of data into 4 characters,
    # and the length of the user name and password are
    # both 9 characters long.
    assert len(token) > 28
    assert headers['Authorization'] == 'Basic YWRtaW46cGFzc3dvcmQ='

# Generated at 2022-06-20 14:55:07.458946
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-20 14:55:10.138186
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    for token in [GalaxyToken(), GalaxyToken('abc')]:
        assert token.headers() == {'Authorization': 'Token abc'}

# Generated at 2022-06-20 14:55:21.184364
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    #username is none
    username = None
    password = None
    token = BasicAuthToken('username', password)
    assert token.get() == 'dXNlcm5hbWU6'

    #password is none
    username = None
    password = None
    token = BasicAuthToken(username, None)
    assert token.get() == 'OnBhc3N3b3Jk'

    #username and password are not none
    username = 'username'
    password = 'password'
    token = BasicAuthToken(username, password)
    assert token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

    #username is not string
    username = ['username']
    password = 'password'
    token = BasicAuthToken(username, password)
    assert token

# Generated at 2022-06-20 14:55:30.084951
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-20 14:55:34.205849
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'keycloak-token'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    obj = KeycloakToken(access_token, auth_url)
    assert obj.get()


# Generated at 2022-06-20 14:55:41.384194
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    t = BasicAuthToken('user', 'pass')
    assert t.get() == "dXNlcjpwYXNz"
    t = BasicAuthToken('user')
    assert t.get() == "dXNlcjo="
    t = BasicAuthToken('user', None)
    assert t.get() == "dXNlcjo="
    t = BasicAuthToken('user', 'pa:s:s')
    assert t.get() == "dXNlcjpwYTpzOnM="
    t = BasicAuthToken('user', '')
    assert t.get() == "dXNlcjo="

# Generated at 2022-06-20 14:55:49.225836
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert str(sentinel) == '<ansible.module_utils.ansible_galaxy.api.NoTokenSentinel object at 0x0>'

# Generated at 2022-06-20 14:55:53.018793
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken('12345', 'https://sso.example.com',
                        validate_certs=True, client_id='cloud-services')
    actual = kct.headers()
    expected = {'Authorization': 'Bearer 12345'}
    assert actual == expected


# Generated at 2022-06-20 14:55:57.959940
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken("test", "https://example.org", False, "test_client")
    assert keycloak_token._form_payload() == "grant_type=refresh_token&client_id=test_client&refresh_token=test"

# Generated at 2022-06-20 14:56:00.788596
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel().__class__.__name__ == 'NoTokenSentinel'


# Generated at 2022-06-20 14:56:03.227067
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('username', 'password')
    assert token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:56:09.114061
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('user', 'pass')
    headers = token.headers()
    assert 'Authorization' in headers
    assert headers['Authorization'] == 'Basic dXNlcjpwYXNz'
    assert 'Authorization' in headers
    assert headers['Authorization'] == 'Basic dXNlcjpwYXNz'

# Generated at 2022-06-20 14:56:14.842327
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    token.token = "5e5c6bd5e64c4f0d8fe7bf5b1ba0f722"
    assert token.headers() == {'Authorization': 'Token 5e5c6bd5e64c4f0d8fe7bf5b1ba0f722'}

    token.token = None
    assert token.headers() == {}

# Generated at 2022-06-20 14:56:16.428041
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = 'test'
    galaxy_token = GalaxyToken(token)
    assert galaxy_token.get() == token

# Generated at 2022-06-20 14:56:20.391600
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token_test = BasicAuthToken('test', 'test')
    assert token_test.get() == 'dGVzdDp0ZXN0'


# Generated at 2022-06-20 14:56:23.901538
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    b = BasicAuthToken('someuser', 'somepassword')
    assert b.token_type == 'Basic'
    assert b.get() == 'c29tZXVzZXI6c29tZXBhc3N3b3Jk'