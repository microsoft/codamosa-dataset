

# Generated at 2022-06-20 14:47:01.262685
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    ''' test constructor and basic operations of BasicAuthToken'''
    bt = BasicAuthToken('testuser', 'testpass')
    assert bt.username == 'testuser'
    assert bt.password == 'testpass'
    assert set(list(bt.headers().values())) == set(['Basic dGVzdHVzZXI6dGVzdHBhc3M='])
    assert bt._token is None
    assert bt._encode_token('testuser', 'testpass') == 'dGVzdHVzZXI6dGVzdHBhc3M='
    # Regex for Authorization header value
    assert set(list(bt.headers().values())) == set(['Basic dGVzdHVzZXI6dGVzdHBhc3M='])
    # test with none for

# Generated at 2022-06-20 14:47:13.737153
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import shutil
    from ansible.module_utils.yaml import yaml_load
    from ansible.module_utils.six import StringIO

    class MyTestFile(StringIO):
        def close(self):
            pass

    # Test no token file exists
    token = GalaxyToken()
    token.set('password1')
    assert os.path.isfile(token.b_file)
    assert token.get() == 'password1'

    # Test token file exists but is empty
    token = GalaxyToken()
    token.set('password2')
    assert os.path.isfile(token.b_file)
    assert token.get() == 'password2'

    # Test token file exists and is populated
    token = GalaxyToken()
    token.set('password3')
    assert os.path.isf

# Generated at 2022-06-20 14:47:21.179143
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():

    token = KeycloakToken("12345678910")
    headers = token.headers()
    assert(headers['Authorization'] == 'Bearer None')

    token2 = KeycloakToken("12345678910")
    token2._token = '12345678910'
    headers2 = token2.headers()
    assert(headers2['Authorization'] == 'Bearer 12345678910')

# Generated at 2022-06-20 14:47:30.367411
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.galaxy import token

    # Check that save creates a file when not exists
    try:
        os.remove('testfile.yaml')
    except OSError:
        pass
    token_ = token.GalaxyToken()
    assert os.path.isfile('testfile.yaml') == False

    token.save('testfile.yaml')
    assert os.path.isfile('testfile.yaml') == True

    # Check that save writes the configuration
    token_ = token.GalaxyToken()
    token_.config = {'test_key': 'test_value'}
    token.save('testfile.yaml')
    with open('testfile.yaml', 'r') as f:
        res = yaml_load(f)

# Generated at 2022-06-20 14:47:35.071099
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    user = 'user'
    passwd = 'password'
    token = BasicAuthToken(user, passwd)
    encoded_token = token.get()

    assert encoded_token == 'dXNlcjpwYXNzd29yZA=='

# Generated at 2022-06-20 14:47:37.665317
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test')
    token.access_token = 'test'
    assert 'Bearer test' in token.headers()['Authorization']

# Generated at 2022-06-20 14:47:43.058837
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    result = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert type(result) == KeycloakToken
    assert result.access_token == 'test_access_token'
    assert result.auth_url == 'test_auth_url'
    assert result.validate_certs is True


# Generated at 2022-06-20 14:47:53.582270
# Unit test for method headers of class GalaxyToken

# Generated at 2022-06-20 14:48:05.340048
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    TOKEN = 'irrelevant'
    URL = 'irrelevant'
    client_id = 'irrelevant'
    kct = KeycloakToken(TOKEN, URL, client_id=client_id)

    # New Token
    kct._token = None
    payload = 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (client_id, TOKEN)
    display.vvv(payload)
    kct.get()
    display.vvv(kct._token)
    assert kct._token == TOKEN

    # Already have the token
    kct._token = TOKEN
    payload = 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (client_id, TOKEN)

# Generated at 2022-06-20 14:48:12.988925
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test',
                          auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          validate_certs=True,
                          client_id='cloud-services')
    token

# Generated at 2022-06-20 14:48:25.577452
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # Setup
    galaxy_token = GalaxyToken()
    galaxy_token.config = {}
    token = 'token'

    # Execute
    galaxy_token.set(token)

    # Verify
    assert token == galaxy_token.get()



# Generated at 2022-06-20 14:48:32.867064
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    from tempfile import NamedTemporaryFile

    # create and populate temporary config file
    config_file = NamedTemporaryFile(prefix='ansible.cfg', delete=False)
    config_file.write(b'[galaxy]\n')
    config_file.write(b'api_server = https://galaxy.example.com\n')
    config_file.write(b'token_path = /path/to/token_file.yml\n')
    config_file.close()

    # create config data object
    config_data = ConfigData(config_file.name)

    # read ansible.cfg
    config_data.parse()

    # create and populate galaxy token file
    galaxy_token_file = NamedTem

# Generated at 2022-06-20 14:48:43.720800
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    file_location = '/tmp/test_GalaxyToken_save'
    token = 'abc1234'
    galaxy_token = GalaxyToken(token=token)
    assert not os.path.exists(file_location)
    galaxy_token.b_file = to_bytes(file_location, errors='surrogate_or_strict')
    galaxy_token.save()
    assert os.path.exists(file_location)
    with open(file_location, 'r') as f:
        assert yaml_load(f) == {'token': token}
    if os.path.exists(file_location):
        os.remove(file_location)

# Generated at 2022-06-20 14:48:46.852909
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert isinstance(gt, GalaxyToken)
    assert gt.token_type == 'Token'



# Generated at 2022-06-20 14:48:49.213538
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    assert galaxy_token.get() == galaxy_token.config.get('token', None)

# Generated at 2022-06-20 14:48:56.826253
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken('some-token')
    assert isinstance(token, GalaxyToken)

    # After saving, the config file should contain the token
    token.save()
    assert token.get() == 'some-token'

    # After deleting the token config file and setting another token, it
    # should be saved and read correctly
    with open(C.GALAXY_TOKEN_PATH, 'w'):
        pass
    token.set('another-token')

    assert token.get() == 'another-token'

# Generated at 2022-06-20 14:49:02.326346
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():

    token = GalaxyToken()

    # Test set with a valid token
    token.set('test_token')

    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == 'test_token'



# Generated at 2022-06-20 14:49:03.000636
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    pass

# Generated at 2022-06-20 14:49:09.999524
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken("test", "testtest")
    assert token.get() == "dGVzdDp0ZXN0dGVzdA=="

# Generated at 2022-06-20 14:49:17.057269
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kk = KeycloakToken('', '', False)
    assert kk.client_id == 'cloud-services'

    kk = KeycloakToken('', '', False, 'testid')
    assert kk.client_id == 'testid'


if C.GALAXY_TOKEN_PATH:
    DEFAULT_TOKEN = GalaxyToken()
else:
    DEFAULT_TOKEN = NoTokenSentinel()

# Generated at 2022-06-20 14:49:34.331579
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import u

    # Create a temporary file to store a Ansible Vault encrypted token
    vault_file = 'TEST_VAULT_FILE'
    token_file = 'TEST_TOKEN_FILE'

    # Create a token
    token = GalaxyToken(token=u('A test token'))

    # Write the token to a temporary Vault file
    token.set(u('a test vault token'))
    vault_password = VaultLib().encrypt_string(to_text(token.get()), name=None)
    with open(vault_file, 'w') as f:
        f.write(vault_password)

    # Encrypt the token
    with open(vault_file, 'r') as f:
        token

# Generated at 2022-06-20 14:49:43.230499
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    import tempfile
    import os

    # Create token file and save
    file = tempfile.NamedTemporaryFile(delete=False)
    token = 'thisisnotarealansiblegalaxytoken'
    t = GalaxyToken(token=token)
    t.save()

    # Read token file for verification
    with open(file.name, "r") as f:
        data = yaml_load(f)
        f.close()

    # Verify
    assert data['token'] == token
    os.unlink(file.name)

# Generated at 2022-06-20 14:49:52.061497
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = '123'
    gt = GalaxyToken()
    gt.set(token)
    assert gt.get() == token
    assert gt.config['token'] == token
    assert gt.config['url'] == C.GALAXY_SERVER



# Generated at 2022-06-20 14:49:53.242571
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    notoken = NoTokenSentinel()
    assert notoken


# Generated at 2022-06-20 14:50:03.953648
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    args = {
        'auth_url': 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
        'client_id': 'cloud-services',
        'validate_certs': True,
    }

    kt = KeycloakToken(**args)

    data = {'access_token': 'no-real-token-here'}
    kt.get()
    assert kt._token is None
    kt._token = data['access_token']
    assert kt._token == data['access_token']
    headers = {'Authorization': '%s %s' % ('Bearer', data['access_token'])}
    assert headers == kt.headers()
    kt._token = None
    assert headers == kt.headers

# Generated at 2022-06-20 14:50:15.529095
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        username=dict(required=True, type='str'),
        password=dict(private=True, type='str', no_log=True),
    ))

    username = module.params["username"]
    password = module.params["password"]

    auth = BasicAuthToken(username, password)

    if auth.username != username:
        raise Exception("Username should be {0}, not {1}".format(username, auth.username))

    if auth.password != password:
        raise Exception("Password should be {0}, not {1}".format(password, auth.password))

# Generated at 2022-06-20 14:50:16.992309
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    test_object = GalaxyToken()
    assert isinstance(test_object, GalaxyToken)
    return


# Generated at 2022-06-20 14:50:27.336124
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # 1. with no access_token
    access_token = None
    auth_url = 'http://127.0.0.1'
    validate_certs = True
    client_id = 'my_client_id'
    token = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    assert token.access_token == access_token
    assert token.auth_url == auth_url
    assert token.validate_certs == validate_certs
    assert token.client_id == client_id
    assert token.token_type == 'Bearer'
    assert token.get() is None

    # 2. with access_token
    access_token = '12345'
    auth_url = 'http://127.0.0.1'
    validate_certs = True
   

# Generated at 2022-06-20 14:50:32.513726
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    class MockToken(GalaxyToken):
        def _read(self):
            with open(os.path.join(os.path.dirname(__file__), 'token.yml')) as f:
                return yaml_load(f)

    token = MockToken(token=None).get()
    assert token == 'abcdefg12345678'

# Generated at 2022-06-20 14:50:39.158026
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    print(BasicAuthToken._encode_token('test', 'test'))
    assert BasicAuthToken._encode_token('test', 'test') == 'dGVzdDp0ZXN0'
    assert BasicAuthToken._encode_token('test', '') == 'dGVzdDo='
    assert BasicAuthToken._encode_token('test', None) == 'dGVzdDo='

# Unit Tests

# Generated at 2022-06-20 14:50:53.180338
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('anonymous', 'none')
    print(token.get())
    print(token.headers())


# Generated at 2022-06-20 14:50:55.603342
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_object = KeycloakToken('offline_token_example')
    assert test_object.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-20 14:51:00.002691
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    k = KeycloakToken('mock_access_token', 'mock_auth_url', True, 'mock_client_id')

    assert(k.token_type == 'Bearer')
    assert(k.access_token == 'mock_access_token')
    assert(k.auth_url == 'mock_auth_url')
    assert(k._token == None)
    assert(k.validate_certs == True)
    assert(k.client_id == 'mock_client_id')


# Generated at 2022-06-20 14:51:11.940310
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = 'toto'
    password = 'tata'
    token = BasicAuthToken._encode_token(username, password)
    assert username == 'toto'
    assert password == 'tata'
    assert token == 'dG90bzp0YXRh'
    assert not BasicAuthToken._encode_token(None, None)
    assert not BasicAuthToken._encode_token(None, 'titi')
    assert BasicAuthToken._encode_token('toto', None) == 'dG90bzo='
    assert BasicAuthToken._encode_token('toto', '') == 'dG90bzo='

    ba = BasicAuthToken(username, password)
    assert ba.get() == 'dG90bzp0YXRh'
    assert ba.username == 'toto'

# Generated at 2022-06-20 14:51:22.562981
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    import os
    from stat import S_IRUSR, S_IWUSR
    token = "123"
    class_g = GalaxyToken(token)
    # test whether the construction works
    assert class_g.b_file == "~/.ansible/galaxy/token"
    # test whether the class has a file
    os.chdir(os.path.expanduser('~'))
    file_path = "".join([os.path.expanduser('~'),'/.ansible/galaxy/token'])
    assert os.path.exists(file_path)
    # test whether the file is open
    with open(file_path, 'r') as file_open:
        assert file_open.name == file_path
        assert file_open.mode == 'r'
    # test whether the method get

# Generated at 2022-06-20 14:51:24.406229
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('testtoken1234')

# Generated at 2022-06-20 14:51:33.999562
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    # create instance of class with token
    galaxy_token = GalaxyToken(token=NoTokenSentinel())

    # check that no token was returned
    assert galaxy_token.get() == None

    # create instance of class with token
    galaxy_token = GalaxyToken(token="12345")

    # check that the set token was returned
    assert galaxy_token.get() == "12345"

    # create instance of class with no token
    galaxy_token = GalaxyToken(token=None)

    # check that the set token was returned
    assert galaxy_token.get() == None

# Generated at 2022-06-20 14:51:43.057613
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import io
    import os
    import tempfile
    from ansible.module_utils.common.yaml import yaml_load, yaml_dump

    token_contents = "eyJpc3MiOiJTc2lFbnZpby"
    galaxy_token_helper = GalaxyToken(token=token_contents)

    # Enclose all test in a temporary directory
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Set a temporary config file
    config_file = io.BytesIO()
    config_file.name = 'tocken_file.yml'

    # Write the config file
    yaml_dump({}, config_file, default_flow_style=False)

    # Set the global token file location
    original_token_file = C.GAL

# Generated at 2022-06-20 14:51:50.636842
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = 'testing'
    file_name = 'ansible.cfg'
    # create ansible.cfg
    with open(file_name, 'w') as f:
        f.write('[galaxy]\ntoken = %s\n' % token)

    # test get
    gt = GalaxyToken()
    assert gt.get() == token

    # remove file
    os.remove(file_name)


# Unit test method set of class GalaxyToken

# Generated at 2022-06-20 14:51:57.952813
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    # test no token
    token = GalaxyToken()

    assert(token.get() is None)

    # test token in config
    token.config = {'token':'test_token'}

    assert(token.get() == 'test_token')


# Generated at 2022-06-20 14:52:28.389523
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    from ansible.galaxy.token import KeycloakToken

    t = KeycloakToken('dasdasdasdasd')

    t.get()
    headers = t.headers()

    assert headers['Authorization'] == 'Bearer %s' % t._token

# Generated at 2022-06-20 14:52:31.956640
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    expected_config = {'token' : 'testtoken'}
    actual_config = {'token' : ''}
    token.set('testtoken')
    actual_config['token'] = token.get()
    assert actual_config == expected_config


# Generated at 2022-06-20 14:52:44.767072
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Pass with username and password
    token = BasicAuthToken('user', 'apassword').get()
    assert token == 'dXNlcjphcGFzc3dvcmQ=', 'Base64 encoding of user:apassword is not correct.'
    # Pass with username only
    token = BasicAuthToken('user').get()
    assert token == 'dXNlcjo=', 'Base64 encoding of user: is not correct.'
    token = BasicAuthToken('user', '').get()
    assert token == 'dXNlcjo=', 'Base64 encoding of user: is not correct.'
    # Pass with username and password that has special characters
    token = BasicAuthToken('user', 'a-password').get()

# Generated at 2022-06-20 14:52:47.749187
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('foo')
    headers = token.headers()
    assert headers == {'Authorization': 'Bearer None'}



# Generated at 2022-06-20 14:52:51.311366
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
  kct = KeycloakToken(access_token='123456789', auth_url='https://auth.url.example.com', validate_certs=True, client_id='test_client_id')
  assert kct.access_token == '123456789'
  assert kct.auth_url == 'https://auth.url.example.com'
  assert kct.validate_certs
  assert kct.client_id == 'test_client_id'


# Generated at 2022-06-20 14:52:53.471086
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken().get()
    assert token is not None

# Generated at 2022-06-20 14:53:05.724866
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    from ansible import constants as C

    C.GALAXY_TOKEN_PATH = tempfile.mkstemp()[1]
    galax = GalaxyToken()

    # Test GalaxyToken class constructor
    assert galax is not None
    galax.set('mytoken')
    assert galax.get() == 'mytoken'
    galax.save()

    with open(C.GALAXY_TOKEN_PATH) as f:
        data = yaml_load(f)
    assert data['token'] == 'mytoken'

    C.GALAXY_TOKEN_PATH = tempfile.mkstemp()[1]
    galax = GalaxyToken()
    assert galax.get()

# Generated at 2022-06-20 14:53:11.537221
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    def mock_resp(read):
        resp_object = type('obj', (object,), {'read': read})
        return resp_object

    resp = mock_resp(lambda: '{"access_token": "test_token"}')

    # Patch open_url function
    import sys
    import builtins
    if '__builtin__' not in sys.modules:
        setattr(builtins, 'open_url', lambda *args, **kwargs: resp)

    # Create instance
    token = KeycloakToken('test_refresh_token')

    # Get headers
    headers = token.headers()

    # Assert results
    assert headers == {'Authorization': 'Bearer test_token'}



# Generated at 2022-06-20 14:53:15.079531
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    token.config['token'] = 'foobar'

    assert token.headers() == {'Authorization': 'Token foobar'}



# Generated at 2022-06-20 14:53:17.282743
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    token = NoTokenSentinel()
    assert isinstance(token, NoTokenSentinel)
    assert token

# Generated at 2022-06-20 14:53:45.083248
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    t = BasicAuthToken('user', 'pass')
    assert t.get() == 'Basic dXNlcjpwYXNz'

# Generated at 2022-06-20 14:53:47.187212
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():

    token = NoTokenSentinel()
    return True

# Generated at 2022-06-20 14:53:54.710442
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """ Unit test for KeycloakToken get method """
    access_token = 'access_token'
    auth_url = 'https://auth.url'
    validate_certs = 'validate_certs'
    client_id = 'client_id'

    access_token_object = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    assert access_token_object.get() is None

# Generated at 2022-06-20 14:53:57.671892
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'pass')
    assert token._token is None
    assert token.get() == 'dXNlcjpwYXNz'
    assert token._token is not None


# Generated at 2022-06-20 14:54:07.670545
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    test_cases = [
        {
            "username": "jondoe",
            "password": "1234567890",
            "expected_token": 'Basic am9uZG9lOjEyMzQ1Njc4OTA=',
        },
        {
            "username": "my_user",
            "password": "my_passw0rd!",
            "expected_token": "Basic bXlfdXNlcjpteV9wYXNzdzByZCE=",
        },
    ]

    for test_case in test_cases:
        basic_auth_token = BasicAuthToken(username=test_case["username"], password=test_case["password"])
        assert basic_auth_token.headers()['Authorization'] == test_case["expected_token"]

# Generated at 2022-06-20 14:54:08.954538
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    return token

# Generated at 2022-06-20 14:54:11.122983
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('foo')
    assert token.config['token'] == 'foo'


# Generated at 2022-06-20 14:54:13.594201
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # Check for the token initialization in the provided file
    token_file_obj = GalaxyToken()
    assert token_file_obj._config == {}

# Generated at 2022-06-20 14:54:22.018556
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import os
    import sys
    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(my_path)
    from ansible.module_utils.basic import AnsibleModule
    # get params
    module = AnsibleModule(argument_spec={
        'client_id': {'required': True},
        'auth_url': {'required': True},
        'access_token': {'required': True},
        'validate_certs': {'required': True}
    })

# Generated at 2022-06-20 14:54:23.317302
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    pass


# Generated at 2022-06-20 14:55:15.636958
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # Test constructor of class NoTokenSentinel
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)

# Generated at 2022-06-20 14:55:18.018012
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    foo = NoTokenSentinel()
    assert foo is not None
    assert foo.__dict__ == {}

# Generated at 2022-06-20 14:55:25.052012
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    import tempfile

    class DummyConfig(object):
        def __init__(self):
            self.GALAXY_TOKEN_PATH = tempfile.mktemp()

    C.config = DummyConfig()

    g = GalaxyToken()
    token = g.get()
    assert token is None

    g.set("testtoken")
    token = g.get()
    assert token == "testtoken"
    g.set("newtoken")
    token = g.get()
    assert token == "newtoken"

# Generated at 2022-06-20 14:55:32.537319
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # setup test token
    token = GalaxyToken()
    token.set('12345')

    # test token is saved on disk
    token.save()
    saved_token = None
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        saved_token = yaml_load(f)['token']
    assert token.get() == saved_token



# Generated at 2022-06-20 14:55:37.912426
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Given
    token = KeycloakToken(access_token = 'foo', auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

    # When
    token._form_payload = lambda: 'foo'
    token.get()



# Generated at 2022-06-20 14:55:48.861475
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # expect success
    try:
        KeycloakToken(access_token='1234567890-abcdefghijklmnopqrstuv',
                      auth_url='https://sso.redhat.com/auth/realms')
    except TypeError as e:
        assert False, 'KeycloakToken constructor failed with exception: %s' % e

    # expect failure
    try:
        KeycloakToken(access_token='1234567890-abcdefghijklmnopqrstuv',
                      auth_url='https://sso.redhat.com/auth/realms',
                      validate_certs='True')
    except TypeError as e:
        assert True, 'KeycloakToken constructor failed with exception: %s' % e

# Generated at 2022-06-20 14:55:51.161770
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bt = BasicAuthToken('foo', 'bar')
    assert bt.get() == 'Zm9vOmJhcg=='

# Generated at 2022-06-20 14:55:53.326047
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    tmp_token = KeycloakToken()
    assert type(tmp_token) == KeycloakToken


# Generated at 2022-06-20 14:55:56.369134
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    assert id(nts) == id(NoTokenSentinel())


# Generated at 2022-06-20 14:55:57.818286
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    tk = GalaxyToken()
    assert tk.config is not None

