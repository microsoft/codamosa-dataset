

# Generated at 2022-06-20 14:46:38.147274
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nodisk = NoTokenSentinel()
    assert nodisk
    assert nodisk.__dict__ == ({})



# Generated at 2022-06-20 14:46:41.674197
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token_string = 'testtoken12345678'
    gt = GalaxyToken(token=test_token_string)
    gt.save()

    gt_read = GalaxyToken()
    assert test_token_string == gt_read.get(), 'write and read of a token not working'


# Generated at 2022-06-20 14:46:47.945660
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    display.verbosity = 4

    def _check_headers(expected, actual):
        assert isinstance(actual, dict)
        assert set(expected) == set(list(actual.keys()))
        assert expected['Authorization'] == actual['Authorization']

    g = GalaxyToken('abcdef')
    _check_headers({'Authorization': 'Token abcdef'}, g.headers())

    g = GalaxyToken('')
    _check_headers({}, g.headers())

    g = GalaxyToken(None)
    _check_headers({}, g.headers())

    g = GalaxyToken(NoTokenSentinel)
    _check_headers({}, g.headers())



# Generated at 2022-06-20 14:46:48.762214
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    t = NoTokenSentinel()
    assert t is not None

# Generated at 2022-06-20 14:46:52.949279
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer foo'


# Generated at 2022-06-20 14:46:55.448684
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken(username='zhangsan', password='12345678901')
    assert token.username == 'zhangsan'
    assert token.password == '12345678901'
    assert token.token_type == 'Basic'

# Generated at 2022-06-20 14:46:58.289377
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken(username='admin', password='password')
    assert token.get() == 'YWRtaW46cGFzc3dvcmQ='



# Generated at 2022-06-20 14:47:05.078833
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers(): # pylint: disable=invalid-name
    # data
    token = 'abcdefghijklmnopqrstuvwxyz'
    expected_headers = {'Authorization': 'Token abcdefghijklmnopqrstuvwxyz'}

    # action
    token_obj = GalaxyToken(token)
    headers = token_obj.headers()

    # asserts
    assert headers == expected_headers, headers


# Generated at 2022-06-20 14:47:07.799372
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set("foo")
    assert token.get() == "foo"


if __name__ == '__main__':
    import pytest
    pytest.main([])

# Generated at 2022-06-20 14:47:09.154576
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert(NoTokenSentinel())

# Generated at 2022-06-20 14:47:15.758674
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    assert BasicAuthToken('user', 'pass').get() == 'dXNlcjpwYXNz'
    assert BasicAuthToken('user', '').get() == 'dXNlcjo='
    assert BasicAuthToken('user', None).get() == 'dXNlcjo='

# Generated at 2022-06-20 14:47:21.132912
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Read password from a file
    with open('test_password_file.txt') as f:
        password = f.readline()
    token = BasicAuthToken('test_user', password)
    headers = token.headers()
    assert (headers['Authorization'].split()[0] == 'Basic')


# Generated at 2022-06-20 14:47:30.346900
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    galaxy_token_path = 'tests/galaxy_token_path/test'
    t = GalaxyToken()
    t.b_file = galaxy_token_path

    assert not os.path.isfile(galaxy_token_path)
    t.save()
    with open(galaxy_token_path) as galaxy_token_file:
        contents = galaxy_token_file.read()
        assert contents == "{}"

    out = StringIO()
    yaml_dump({'token': None}, out)
    out.seek(0)
    assert out.read() == '{}\n'

    out = StringIO()
    yaml_dump({'token': 'xxxxxxxxxxxxxxxx'}, out)

# Generated at 2022-06-20 14:47:38.349976
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    k = KeycloakToken(access_token='abc', auth_url='https://hello.com', validate_certs=True, client_id='cloud-services')
    # Test for attributes
    assert k.token_type == 'Bearer'
    assert k._token == None
    assert k.access_token == 'abc'
    assert k.auth_url == 'https://hello.com'
    assert k.validate_certs == True
    assert k.client_id == 'cloud-services'


# Generated at 2022-06-20 14:47:41.641627
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    c = GalaxyToken()
    c.set('abc')
    assert c.config['token'] == 'abc'
    c.set(NoTokenSentinel)
    assert c.config['token'] is None


# Generated at 2022-06-20 14:47:42.457251
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    x = NoTokenSentinel()



# Generated at 2022-06-20 14:47:46.073752
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'p@ssword')
    assert token.get() == 'dXNlcjpwQHNzd29yZA=='



# Generated at 2022-06-20 14:47:49.635797
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    t = KeycloakToken('some_token', auth_url='some_auth_url')
    assert t.access_token == 'some_token'
    assert t.auth_url == 'some_auth_url'
    assert t.validate_certs == True
    assert t.client_id == 'cloud-services'



# Generated at 2022-06-20 14:47:53.287831
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken('test_token')
    assert token is not None
    assert token.config == {}



# Generated at 2022-06-20 14:47:54.932552
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken().get()
    assert token is None


# Generated at 2022-06-20 14:48:00.765751
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(auth_url="http://auth2.com", access_token='1234')
    validate_certs = False
    expected_headers = {'Authorization': 'Bearer 1234'}
    assert kct.headers() == expected_headers

# Generated at 2022-06-20 14:48:08.531462
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    import unittest

    class BasicAuthToken_get_TestCase(unittest.TestCase):
        def setUp(self):
            from ansible.galaxy import tokens
            self.t = tokens.BasicAuthToken(username='admin', password='admin')

        def test_get(self):
            expected = b'Basic YWRtaW46YWRtaW4='
            actual = self.t.get()
            self.assertEqual(len(expected), len(actual))
            self.assertEqual(actual, expected)

        def test_get_password_none(self):
            ''' verify that password=None is accepted '''
            self.t = tokens.BasicAuthToken(username='admin', password=None)
            expected = b'Basic YWRtaW46'
            actual = self.t.get()
            self

# Generated at 2022-06-20 14:48:10.974231
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken("foo", "bar")
    user_headers = {'Authorization': 'Basic Zm9vOmJhcg=='}
    assert token.headers() == user_headers

# Generated at 2022-06-20 14:48:14.225411
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'abcdefg'
    galaxy_token = GalaxyToken()
    galaxy_token.set(token)
    assert galaxy_token.get() == token

# Generated at 2022-06-20 14:48:23.922258
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()

    # Assert that the token is not set
    assert not token.get()
    assert token.config == {}

    # Set token to 'test' and save it
    token.set('test')
    assert token.get() == 'test'
    assert token.config == {'token': 'test'}

    # Test key error when reading token file
    token._config = 1
    assert token.config == {}

    # Test key error when reading token file
    token._config = 'test'
    assert token.config == {}

    # Test token file not found error when reading token file
    token.b_file = 'test_token_path'
    assert token.config == {}


# Generated at 2022-06-20 14:48:24.825011
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    x = NoTokenSentinel()
    assert True
    str(x)
    True


# Generated at 2022-06-20 14:48:29.852427
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    test_cases = [
        { 'token': 'abc123' },
        { 'token': None },
        { 'token': NoTokenSentinel() },
        { 'token': 'abc123', 'other': 'foo' },
        { 'other': 'foo' },
        { }
    ]

    for test_case in test_cases:
        gt = GalaxyToken(token=test_case.get('token', None))
        assert gt.get() == test_case.get('token', None)

# Generated at 2022-06-20 14:48:31.426312
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    t1 = GalaxyToken()
    assert isinstance(t1, GalaxyToken)

# Generated at 2022-06-20 14:48:34.587019
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    no_token_sentinel = NoTokenSentinel()
    assert isinstance(no_token_sentinel, NoTokenSentinel)



# Generated at 2022-06-20 14:48:44.053236
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'test_access_token'
    auth_url = 'test_auth_url'
    validate_certs = True
    client_id = None
    kct = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    if kct.access_token != access_token or kct.auth_url != auth_url or \
       kct.validate_certs != validate_certs or kct.client_id != client_id:
        raise Exception("KeycloakToken constructor failed")



# Generated at 2022-06-20 14:48:56.497773
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='my-offline-token', auth_url='url', validate_certs=True)
    assert token.access_token == 'my-offline-token'
    assert token.auth_url == 'url'
    assert token.validate_certs is True
    assert token.client_id == 'cloud-services'
    token = KeycloakToken(access_token='my-offline-token', auth_url='url', validate_certs=True, client_id='my-client')
    assert token.client_id == 'my-client'

# Generated at 2022-06-20 14:49:05.174031
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import requests
    from io import BytesIO
    class FakeResponse(BytesIO):
        def __init__(self, content=None, status_code=200):
            super(FakeResponse, self).__init__(content)
            self.status_code = status_code

    def mock_open_url(url, data=None, validate_certs=True, method='GET', **kwargs):
        return FakeResponse(json.dumps({'access_token': 'test_token',}).encode('utf-8'))

    # Patch the open_url for the test
    open_url_orig = open_url
    open_url = mock_open_url

    # Test method

# Generated at 2022-06-20 14:49:05.934367
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert type(NoTokenSentinel('a')) is NoTokenSentinel


# Generated at 2022-06-20 14:49:19.341421
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # TypeErrors
    # Test when username and password are None
    token = BasicAuthToken(username=None, password=None)
    token.get()

    # TypeError (username)
    token = BasicAuthToken(username=dict(), password=None)
    token.get()

    # TypeError (password)
    token = BasicAuthToken(username='username', password=dict())
    token.get()

    # ValueErrors
    # Test when username is empty string
    token = BasicAuthToken(username='', password='password')
    token.get()

    # Test when username is empty string, even when password is None
    token = BasicAuthToken(username='', password=None)
    token.get()

    # ValueError

# Generated at 2022-06-20 14:49:22.214541
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token
    token = GalaxyToken(token=None)
    assert token


# Generated at 2022-06-20 14:49:27.055437
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    C.GALAXY_TOKEN_PATH = '~/.ansible_galaxy/token'
    C.GALAXY_SERVER = 'https://galaxy.ansible.com'
    token = GalaxyToken()
    token.set('foo')
    assert token.get() == 'foo'

# Generated at 2022-06-20 14:49:37.554590
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from test.support.unit import unittest

    class dummy_display:

        def __init__(self):
            self.content = []

        def vvv(self, data):
            self.content.append(data)

    class dummy_C:
        GALAXY_TOKEN_PATH = '/tmp/ansible_galaxy.token'

    C = dummy_C()
    display = dummy_display()
    token = GalaxyToken(None)
    token.save()
    assert os.path.exists(to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict'))
    os.unlink(to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict'))



# Generated at 2022-06-20 14:49:39.281512
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('fake-token')
    expected_token_header = {'Authorization': 'Token fake-token'}
    assert token._token is None
    assert token.headers() == expected_token_header

# Generated at 2022-06-20 14:49:52.004040
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # test user with password
    user = 'ansibleuser'
    password = 'ansiblepassword'
    b = BasicAuthToken(user, password)
    assert b.headers() == {'Authorization': 'Basic YW5zaWJsZXVzZXI6YW5zaWJsZXBhc3N3b3Jk'}
    assert b.get() == 'YW5zaWJsZXVzZXI6YW5zaWJsZXBhc3N3b3Jk'

    # test user without password
    user2 = 'ansibleuser2'
    b2 = BasicAuthToken(user2)
    assert b2.headers() == {'Authorization': 'Basic YW5zaWJsZXVzZXIyOg=='}

# Generated at 2022-06-20 14:49:53.569348
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    config = GalaxyToken()
    assert None == config.get()

# Generated at 2022-06-20 14:50:05.849535
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a test KeycloakToken
    kc_token = KeycloakToken('access-token', 'http://auth.url')
    assert isinstance(kc_token, KeycloakToken)
    assert hasattr(kc_token, 'access_token')

    # TODO: Mock the call to open_url() and test the payload
    #  def _form_payload(self):
    #        return 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (self.client_id,
    #                                                                           self.access_token)

    # Assign a dummy access token
    kc_token._token = 'access-token'
    assert kc_token.get() == kc_token._token

    # TODO: Mock the call to open

# Generated at 2022-06-20 14:50:14.310737
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # arrange
    inst_keycloak_token = KeycloakToken('test_access_token', 'https://test_auth_url', True, 'test_client_id')
    inst_keycloak_token._token = 'test_token'
    expected_output = {'Authorization': 'Bearer test_token'}

    # act
    output = inst_keycloak_token.headers()

    # assert
    assert output == expected_output


# Generated at 2022-06-20 14:50:20.913469
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    user = 'bob'
    pw = 'p4ssw0rd'
    token = 'Ym9iOnA0c3N3MHJk'
    # Test username and password parameter
    batoken = BasicAuthToken(username=user, password=pw)
    assert token == batoken.get()
    # Test username only
    batoken = BasicAuthToken(username=user)
    assert token == batoken.get()


# Generated at 2022-06-20 14:50:26.931046
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    b_file = 'test_galaxy_token_file'

    token_file = GalaxyToken(token=token)
    token_file.b_file = b_file
    token_file.save()

    assert os.path.isfile(b_file)

    with open(b_file, 'r') as f:
        config = yaml_load(f)

    assert token == config.get('token', None)


# Generated at 2022-06-20 14:50:31.179478
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(access_token="mock_access_token", auth_url="mock_auth_url", validate_certs=True, client_id="mock_client_id")
    keycloak_token.get()
    assert True

# Generated at 2022-06-20 14:50:37.618219
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('abc123', 'https://example.com', False)
    assert token.access_token == 'abc123', "access_token not set"
    assert token.auth_url == 'https://example.com', "auth_url not set"
    assert token.client_id == 'cloud-services', "client_id not set"
    assert token.validate_certs == False, "validate_certs not set"

# Generated at 2022-06-20 14:50:45.684050
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'token.yaml'))
    token = {'token': 'test_token'}

    with open(token_path, 'w') as f:
        yaml_dump(token, f, default_flow_style=False)

    p = GalaxyToken(None)
    p.b_file = to_bytes(token_path)

    os.environ['HOME'] = os.path.dirname(token_path)
    token_1 = p.get()

    os.remove(token_path)


# Generated at 2022-06-20 14:50:54.951784
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from io import StringIO
    from ansible.module_utils._text import to_bytes

    config = {'token': 'mytesttoken',
              'ignore_certs': True}
    fp = StringIO()
    yaml_dump(config, fp, default_flow_style=False)
    expected_result = fp.getvalue()
    galaxy_token = GalaxyToken()
    galaxy_token._config = config
    galaxy_token.save()
    with open(to_bytes(C.GALAXY_TOKEN_PATH), 'r') as f:
        result = f.read()

    assert result == expected_result

# Generated at 2022-06-20 14:51:10.184599
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    ''' Unit test for GalaxyToken class constructor '''
    token = '123'
    test_galaxy_token = GalaxyToken(token)
    galaxy_token_file_path = C.GALAXY_TOKEN_PATH
    test_galaxy_token_file_path = galaxy_token_file_path + '.test'
    C.GALAXY_TOKEN_PATH = test_galaxy_token_file_path
    test_galaxy_token.save()

    # Test without any token file
    test_galaxy_token_2 = GalaxyToken()

    test_galaxy_token_2_config = test_galaxy_token_2.config
    if test_galaxy_token_2_config:
        assert 'test_galaxy_token_2_config should be empty'

    # Test with a token file


# Generated at 2022-06-20 14:51:13.322385
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    basic_token = BasicAuthToken('admin', 'admin')
    expected = 'QWRtaW46YWRtaW4='
    assert basic_token.get() == expected

# Generated at 2022-06-20 14:51:21.082991
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('test', 'test')
    assert to_text(token.get()) == 'dGVzdDp0ZXN0'


# Generated at 2022-06-20 14:51:24.164429
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('foo', 'bar')
    assert to_text(token.get()) == 'Zm9vOmJhcg=='

# Generated at 2022-06-20 14:51:25.900353
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    no_token = NoTokenSentinel()
    assert no_token is not None

# Generated at 2022-06-20 14:51:28.679490
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set("some token")

    # check that this has been saved as new saved token
    assert token.get() == "some token"

# Generated at 2022-06-20 14:51:36.021266
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    result = BasicAuthToken('user')
    assert result is not None
    assert result.username == 'user'
    assert result.password is None

    result = BasicAuthToken('user', 'password')
    assert result is not None
    assert result.username == 'user'
    assert result.password == 'password'

    result = BasicAuthToken('user', '')
    assert result is not None
    assert result.username == 'user'
    assert result.password == ''



# Generated at 2022-06-20 14:51:40.206479
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token_test = BasicAuthToken('testuser', 'testpassword')
    token = token_test.get()
    assert token == 'dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'



# Generated at 2022-06-20 14:51:46.544549
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = os.getenv('GALAXY_ACCOUNT_TOKEN')
    kt = KeycloakToken(access_token=access_token, auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    print(kt.get())

# Generated at 2022-06-20 14:51:54.692868
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # Test with no token set:
    token = GalaxyToken()
    assert token.get() is None
    # Test with a token, persist it to file, then reload it:
    test_token = 'TestToken'
    token.set(test_token)
    assert test_token == token.get()
    token_file = '/tmp/galaxy_token'
    token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token.save()
    token = GalaxyToken()
    token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token_retrieved = token.get()
    os.remove(token_file)
    assert test_token == token_retrieved

# Generated at 2022-06-20 14:52:01.636846
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken('12345', 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kct.headers() == {'Authorization': 'Bearer None'}
    assert kct.get() == None
    kct._token = 'abc'
    assert kct.headers() == {'Authorization': 'Bearer abc'}

# Generated at 2022-06-20 14:52:09.988462
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    # Create a galaxy_token object
    galaxy_token = GalaxyToken('dummy_token')
    u_token = to_text(C.GALAXY_TOKEN_PATH)
    # Assert the file is not present before calling save
    assert not os.path.isfile(u_token)
    galaxy_token.save()
    # Assert the file is present now
    assert os.path.isfile(u_token)
    # Assert there is no token in the file as default val for token is None
    with open(u_token, 'r') as f:
        config = yaml_load(f)
    assert 'token' not in config
    os.remove(u_token)



# Generated at 2022-06-20 14:52:17.704004
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert(NoTokenSentinel() is not None)

# Generated at 2022-06-20 14:52:20.383125
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('test-token')
    assert token.headers() == {'Authorization': 'Token test-token'}


# Generated at 2022-06-20 14:52:22.627206
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    at = GalaxyToken()
    at.set('foo')
    assert at.headers()['Authorization'] == 'Token foo'

# Generated at 2022-06-20 14:52:31.473126
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'ABC'
    file_bytes = to_bytes('token: %s' % token, errors='surrogate_or_strict')

    galaxy_token = GalaxyToken()

    file_mock = MagicMock()
    file_mock.write.return_value = None

    open_mock = MagicMock(return_value=file_mock)

    with patch('ansible_galaxy.token.open', open_mock):
        galaxy_token.set(token)
        open_mock.assert_called_with(galaxy_token.b_file, 'w')
        file_mock.write.assert_called_with(file_bytes)



# Generated at 2022-06-20 14:52:35.814697
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    if C.GALAXY_TOKEN_PATH:
        t = GalaxyToken()
    else:
        t = GalaxyToken(token=NoTokenSentinel())

    headers = t.headers()

    if C.GALAXY_TOKEN_PATH:
        assert headers['Authorization'].startswith('Token')

    else:
        assert 'Authorization' not in headers



# Generated at 2022-06-20 14:52:38.700679
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test')
    result = token.headers()
    assert result == {'Authorization': 'Bearer test'}

# Generated at 2022-06-20 14:52:39.739084
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is NoTokenSentinel()


# Generated at 2022-06-20 14:52:50.035546
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-20 14:52:55.091054
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    auth = BasicAuthToken('username', 'password')
    enc = auth.get()
    assert (enc == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ=')

# Generated at 2022-06-20 14:52:57.282096
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('secret')
    assert token.headers() == {'Authorization': 'Bearer secret'}

# Generated at 2022-06-20 14:53:06.206754
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    cls = NoTokenSentinel
    args = ()
    kwargs = {}
    result = cls.__new__(cls, *args, **kwargs)
    assert isinstance(result, cls)

# Generated at 2022-06-20 14:53:12.303637
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import pytest
    from shutil import copyfile
    from ansible.errors import AnsibleError

    b_file = 'token_file'
    b_file2 = 'token_file2'

    if os.path.exists(b_file):
        os.remove(b_file)
    if os.path.exists(b_file2):
        os.remove(b_file2)

    # Test token saving
    token_object = GalaxyToken(token=None)
    token_object._config = dict(token={'mock.user': 'value'})
    token_object.b_file = to_bytes(b_file, errors='surrogate_or_strict')
    token_object.save()
    assert os.path.isfile(b_file)

    # Test save overwrites file
   

# Generated at 2022-06-20 14:53:23.656018
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_tokens = {
        'tok': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJsb2NhbGhvc3QiLCJzdWIiO',
        'tok2': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJsb2NhbGhvc3QiLCJzdWIi',
    }
    gt = GalaxyToken(test_tokens['tok'])
    headers = gt.headers()
    assert(headers['Authorization'] == 'Token %s' % test_tokens['tok'])

# Generated at 2022-06-20 14:53:29.936921
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken('refresh_token')
    assert kt.headers() == {'Authorization': 'Bearer None'}
    kt.access_token = '123456789'
    assert kt.headers() == {'Authorization': 'Bearer None'}
    kt.auth_url = 'https://keycloak.example.com/auth/realms/master/protocol/openid-connect/token'
    assert kt.headers() == {'Authorization': 'Bearer None'}
    kt.client_id = 'my_client_id'
    assert kt.headers() == {'Authorization': 'Bearer None'}
    kt.get()
    assert kt.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-20 14:53:36.062590
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('test_token')
    headers = token.headers()
    assert isinstance(headers, dict), "Wrong type"
    assert 'Authorization' in headers, "Wrong type"
    assert headers['Authorization'] == 'Token test_token', "Wrong value"


# Generated at 2022-06-20 14:53:45.719244
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    os.chdir(C.DEFAULT_LOCAL_TMP)
    # Remove file from previous test
    if os.path.exists(C.GALAXY_TOKEN_PATH):
        os.remove(C.GALAXY_TOKEN_PATH)
    t = GalaxyToken()
    t.set('Test String')
    # Check if file has been created
    assert os.path.exists(C.GALAXY_TOKEN_PATH)
    t = GalaxyToken()
    # Check if file has been loaded
    assert t.get() == 'Test String'
    # Remove file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-20 14:53:52.896587
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():

    # test if username is a string
    username = 'username'
    password = 'password'
    test_1 = BasicAuthToken(username, password)
    assert test_1.username == username

    # test if username is a unicode
    username = u'\u0123'
    password = 'password'
    test_1 = BasicAuthToken(username, password)
    assert test_1.username == username

# Generated at 2022-06-20 14:54:04.468769
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    basic_auth_token = BasicAuthToken('test', 'test')
    assert basic_auth_token.get() == 'dGVzdDp0ZXN0'
    basic_auth_token = BasicAuthToken('test', b'test')
    assert basic_auth_token.get() == 'dGVzdDp0ZXN0'
    basic_auth_token = BasicAuthToken('test')
    assert basic_auth_token.get() == 'dGVzdDo='
    basic_auth_token = BasicAuthToken(b'test', 'test')
    assert basic_auth_token.get() == 'dGVzdDp0ZXN0'
    basic_auth_token = BasicAuthToken(b'test', b'test')

# Generated at 2022-06-20 14:54:09.411734
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    obj = BasicAuthToken('username', 'password')
    assert obj.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:54:19.360016
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:54:34.781255
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('ansible', 'password')
    assert token.get() == 'YW5zaWJsZTpwYXNzd29yZA=='
    assert token.headers() == {'Authorization': 'Basic YW5zaWJsZTpwYXNzd29yZA=='}

# Generated at 2022-06-20 14:54:41.015772
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes("galaxy_token_test", errors='surrogate_or_strict')
    try:
        if os.path.isfile(b_file):
            os.remove(b_file)
        # Create token file
        token_file = GalaxyToken()
        token_file.b_file = b_file
        token_file.set("new_token")
        token_file.save()
        assert os.path.isfile(b_file)
    finally:
        # Remove token file if exists
        if os.path.isfile(b_file):
            os.remove(b_file)

# Generated at 2022-06-20 14:54:46.382897
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kc_token = KeycloakToken(auth_url='foo', access_token='bar')
    assert 'Authorization' in kc_token.headers()
    assert 'Bearer' == kc_token.headers()['Authorization'].split()[0]
    assert 'bar' == kc_token.headers()['Authorization'].split()[1]

# Generated at 2022-06-20 14:54:51.011618
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    test_username = 'username'
    test_password = 'password'
    token = BasicAuthToken(test_username, test_password)
    token_string = token.get()
    assert token_string == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    headers = token.headers()
    assert headers['Authorization'] == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:54:54.958392
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    class MockResponse:
        content = b'{"access_token": "some_token"}'

    token = KeycloakToken(access_token='my_access_token', auth_url='https://example.com/token')
    token.open_url = MockResponse

    retval = token.get()
    assert retval == "some_token"

# Generated at 2022-06-20 14:54:57.920648
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    with open(C.GALAXY_TOKEN_PATH, 'w') as f:
        yaml_dump({'token': 'unittest'}, f, default_flow_style=False)

    gt = GalaxyToken()
    gt.set('changed')
    assert gt.get() == 'changed'

# Generated at 2022-06-20 14:54:59.603687
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    testing_token = BasicAuthToken(username="admin", password="password")
    assert testing_token.get() == "YWRtaW46cGFzc3dvcmQ="


# Generated at 2022-06-20 14:55:02.524008
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kt = KeycloakToken('abcd1234', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    return kt



# Generated at 2022-06-20 14:55:06.193761
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    t = GalaxyToken()
    t.set('dummy-token')
    assert t.get() == 'dummy-token'


# Generated at 2022-06-20 14:55:10.458716
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'user'
    password = 'password'
    token = BasicAuthToken(username, password)
    token_get = token.get()
    token_expected = 'dXNlcjpwYXNzd29yZA=='
    assert token_get == token_expected

# Generated at 2022-06-20 14:55:38.122584
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # - is the test token file created and chmod 0600?
    #   - is the test token file opened
    # - if the file is malformed, is it still read?
    #   - if the file is malformed is it still written?
    # - if the file is empty is an empty dict returned?
    #   - if the file is empty, is it still written?
    # - if defaults are not passed, do they get written to the file?
    #   - if defaults are empty, do they get written to the file?
    pass

# Generated at 2022-06-20 14:55:39.738179
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = 'hello'
    password = 'world'
    token = BasicAuthToken(username, password)
    print(token.get())



# Generated at 2022-06-20 14:55:43.413360
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token="random")
    assert token.get() == "random"
    assert token.headers() == {'Authorization': 'Bearer random'}

# Generated at 2022-06-20 14:55:53.451920
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''
    This tests the method "get" of class KeycloakToken to see that it returns an access token
    that it has retrieved from the OpenShift keycloak API. It first tests to see if get returns
    the expected token when the auth_url is a valid keycloak server and the access_token is
    valid. It then tests to see that get returns None when the auth_url is not a valid keycloak
    server.
    '''
    # arrange
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-20 14:55:57.766038
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test'
    galaxy_token = GalaxyToken()
    galaxy_token.set(token)
    assert galaxy_token.get() == token
    assert 'token' in galaxy_token.config


# Generated at 2022-06-20 14:56:04.224882
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    #Make sure default headers work
    access_token = 'mylittlepony'
    auth_url = 'https://galaxy.url.com'
    kl = KeycloakToken(access_token=access_token,
                       auth_url=auth_url)
    headers = kl.headers()
    assert headers['Authorization'] == 'Bearer %s' % access_token
    assert headers['User-Agent'] == user_agent()

# Generated at 2022-06-20 14:56:14.668605
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Basic
    ## With password
    auth_token = BasicAuthToken('username', 'password')
    assert auth_token.headers() == {'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='}
    ## No password
    auth_token = BasicAuthToken('username', '')
    assert auth_token.headers() == {'Authorization': 'Basic dXNlcm5hbWU6'}
    ## No password
    auth_token = BasicAuthToken('username', None)
    assert auth_token.headers() == {'Authorization': 'Basic dXNlcm5hbWU6'}

# Generated at 2022-06-20 14:56:17.187294
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token.config == {}
    token = GalaxyToken("abcdefg")
    assert token._token == "abcdefg"
    assert token.config == {}


# Generated at 2022-06-20 14:56:21.161582
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    """Tests get method of class BasicAuthToken"""
    assert BasicAuthToken('username', 'password').get() == BasicAuthToken._encode_token('username', 'password')

# Generated at 2022-06-20 14:56:23.594122
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    token.set('foo')
    headers = token.headers()
    assert headers['Authorization'] == 'Token foo'