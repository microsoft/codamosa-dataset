

# Generated at 2022-06-20 14:46:52.153756
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == ''
    token = KeycloakToken(access_token='test_access_token_2', auth_url='test_auth_url')
    assert token.get() == ''


# Generated at 2022-06-20 14:46:54.435269
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    """ Test for method __new__ of class NoTokenSentinel
        Test whether __new__ returns an object of class NoTokenSentinel
        """
    test = NoTokenSentinel()
    assert isinstance(test, NoTokenSentinel)


# Generated at 2022-06-20 14:46:56.565799
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    """ Test the set method of GalaxyToken class """
    gt = GalaxyToken()
    gt.set(None)
    assert {} == gt._config


# Generated at 2022-06-20 14:47:07.643189
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
   token = KeycloakToken('qwerty', 'https://www.example.com/auth/token', validate_certs=True, client_id='cloud-services')
   assert token.access_token == 'qwerty'
   assert token.auth_url == 'https://www.example.com/auth/token'
   assert token.validate_certs == True
   assert token.client_id == 'cloud-services'
   assert token.test_form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=qwerty'
   assert token.get() == None
   assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-20 14:47:19.280445
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    t_case_1 = [
        'vagrant',
        'vagrant',
        'Basic dmFncmFudDp2YWdyYW50'
    ]
    t_case_2 = [
        None,
        'password',
        'Basic OnBhc3N3b3Jk'
    ]
    t_case_3 = [
        '',
        'password',
        'Basic OnBhc3N3b3Jk'
    ]
    t_case_4 = [
        'user',
        None,
        'Basic dXNlcjo='
    ]
    t_case_5 = [
        'user',
        '',
        'Basic dXNlcjo='
    ]

# Generated at 2022-06-20 14:47:29.515313
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    '''
    test_GalaxyToken_save
    save method of GalaxyToken
    '''
    import sys
    import os

    if sys.version_info[0] < 3:
        open_func = '__builtin__.open'
        chmod_func = '__builtin__.os.chmod'
    else:
        open_func = 'builtins.open'
        chmod_func = 'os.chmod'

    # create and chmod u+rw
    mock_open = mocker.mock_open()
    mocker.patch('%s' % open_func, mock_open)
    mocker.patch('%s' % chmod_func)
	
    # test1: exist
    test_config = {"a": 1, "b": 2}
    galaxy_token1 = GalaxyToken

# Generated at 2022-06-20 14:47:32.979701
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    t = KeycloakToken(access_token='refresh_token', auth_url="http://auth_url.com")
    assert t.get() == 'access_token'

# Generated at 2022-06-20 14:47:35.917059
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    assert GalaxyToken().headers() == {}
    token = "some-token"
    assert GalaxyToken(token).headers() == {"Authorization": "Token some-token"}



# Generated at 2022-06-20 14:47:42.226082
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Test case: username only
    testBasicAuthToken = BasicAuthToken('username')
    assert testBasicAuthToken.get() == 'Basic dXNlcm5hbWU6'

    # Test case: username and password
    testBasicAuthToken = BasicAuthToken('username', 'password')
    assert testBasicAuthToken.get() == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:47:43.693321
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    client = GalaxyToken()
    token = client.get()
    assert token == ""


# Generated at 2022-06-20 14:47:49.627077
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken('123456789')
    actual = token.get()
    assert(actual == '123456789')


# Generated at 2022-06-20 14:47:53.287750
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {"Authorization": "Bearer 1234567890"}


# Generated at 2022-06-20 14:47:55.502147
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    KeycloakToken(access_token='keycloak_token', auth_url='http://auth_url.com')

# Generated at 2022-06-20 14:47:57.364209
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='mytoken', auth_url='https://myauthurl.com')

# Generated at 2022-06-20 14:48:00.602710
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    tempfile.tempdir = '/tmp'
    token = GalaxyToken()
    token.set('secret')
    token.save()

    with open(token.b_file, 'r') as f:
        assert 'secret' in f.readline()

# Generated at 2022-06-20 14:48:02.210847
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken('test-token')
    assert gt.get() == 'test-token'



# Generated at 2022-06-20 14:48:05.333298
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    file = './unit_test_token'
    gt = GalaxyToken(token)
    gt.b_file = to_bytes(file, errors='surrogate_or_strict')
    gt.config['token'] = token
    gt.save()

    with open(gt.b_file, 'r') as f:
        config = yaml_load(f)

    assert(config['token'] == token)
    os.remove(file)


# Generated at 2022-06-20 14:48:09.054942
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test with no password
    token = BasicAuthToken('foo')
    headers = token.headers()
    assert(headers['Authorization'] == 'Basic Zm9vOg==')

    # Test with password
    token = BasicAuthToken('foo', 'bar')
    headers = token.headers()
    assert(headers['Authorization'] == 'Basic Zm9vOmJhcg==')

# Generated at 2022-06-20 14:48:11.930808
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('username')
# None type variable should be turned into '' string
    assert token.password == ''
# None type variable should be turned into '' string
    assert token.get() == 'dXNlcm5hbWU6'


# Generated at 2022-06-20 14:48:17.218113
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # success case
    token = KeycloakToken('access_token')
    assert token.get() == 'access_token'

    # failure case
    token = KeycloakToken('')
    assert token.get() is None


# Generated at 2022-06-20 14:48:25.812871
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # this is just a fake test to make the new token work in 2.6
    BasicAuthToken('test', 'pass')



# Generated at 2022-06-20 14:48:27.417733
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = "123"
    auth_url = "http://auth.url"
    o = KeycloakToken(access_token=access_token, auth_url=auth_url)

    assert o.get() == access_token

# Generated at 2022-06-20 14:48:32.706773
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = 'testuser'
    password = 'testpassword'
    auth_token = BasicAuthToken(username, password)
    headers = auth_token.headers()
    assert headers['Authorization'] == 'Basic ' + auth_token.get()

# Generated at 2022-06-20 14:48:36.323246
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken()
    token.get = lambda: 'test_token'
    headers = token.headers()
    assert headers.get('Authorization', None) == 'Bearer test_token'


# Generated at 2022-06-20 14:48:41.920315
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    try:
        token_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
        # delete the token file if it was there before
        if os.path.isfile(token_file):
            os.remove(token_file)
    except IOError:
        # file could not be opened
        return False

    # Creating a new token file
    token = GalaxyToken()
    return os.path.isfile(token_file)


# Generated at 2022-06-20 14:48:45.267923
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken()
    assert gt._read() == {}, "GalaxyToken is not properly initialized"


# Generated at 2022-06-20 14:48:55.798586
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Note: password is not checked by kc server
    USER = 'user@example.com'
    PASSWORD = 'SOMEPASSWORD'

    # make an offline ticket
    ot = KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/redhat-external/tokens/grants/access',
                       username=USER,
                       password=PASSWORD)
    # print(ot.headers())
    # make the request, check the structure of the jwt
    jwt_token = ot._token

    # extract the refresh token from the jwt
    refresh_token = jwt_token.split('.')[1]
    # base64 decode the refresh token
    decoded_refresh_token = base64.b64decode(refresh_token)
    # read the

# Generated at 2022-06-20 14:49:04.114024
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    """
    Rationale:
    - The class NoTokenSentinel is only used to test if the sentinel object is set.
    - This is a workaround for the lack of a proper `None` value in a Python class as described here:
    https://stackoverflow.com/questions/1325673/instance-of-a-python-class-with-no-attributes
    - This class does not really need to be tested.
    """
    # Action
    instance = NoTokenSentinel()
    # Assert
    assert instance is NoTokenSentinel

# Generated at 2022-06-20 14:49:09.407856
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    '''
    Test setup
    '''

# Generated at 2022-06-20 14:49:13.553576
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    obj = GalaxyToken()
    assert obj.headers() == {}, 'Default headers should be empty'

    obj._token = "test123"
    assert obj.headers() == {'Authorization': 'Token test123'}



# Generated at 2022-06-20 14:49:24.599539
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken("test@test.test", "testtest")
    assert token.headers() == {'Authorization': 'Basic dGVzdEB0ZXN0LnRlc3Q6dGVzdHRlc3Q='}

# Generated at 2022-06-20 14:49:33.467086
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    try:
        f = open('/tmp/test_GalaxyToken_save.txt', 'w')
        os.chmod('/tmp/test_GalaxyToken_save.txt', S_IRUSR | S_IWUSR)
    except Exception as e:
        print(e)
        raise
    token = GalaxyToken()
    token.set('test')
    token.save()
    if open('/tmp/test_GalaxyToken_save.txt', 'r').read() != 'token: test\n':
        print('save failed')
    os.remove('/tmp/test_GalaxyToken_save.txt')

# Generated at 2022-06-20 14:49:36.630147
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    config = GalaxyToken(token=None)
    assert isinstance(config._config, dict)
    assert isinstance(config.config, dict)



# Generated at 2022-06-20 14:49:43.460917
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='wit is een token', auth_url='https://rs.automation.test/auth/realms/master/protocol/openid-connect/token')
    assert kt.headers() == {'Authorization': 'Bearer fffe8a8a-0eb7-48ab-b266-e2e2ccc42d0d'}

# Generated at 2022-06-20 14:49:44.084668
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass

# Generated at 2022-06-20 14:49:51.636599
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token.b_file.decode('utf-8') == C.GALAXY_TOKEN_PATH, \
        "token.b_file's value is wrong, it should be equal to C.GALAXY_TOKEN_PATH"
    assert token._config is None, "token._config's value is wrong, it should be equal to None"
    assert token._token is None, "token._token's value is wrong, it should be equal to None"

# Generated at 2022-06-20 14:49:54.323676
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    auth_token = BasicAuthToken('username', 'password')
    assert auth_token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:49:55.603392
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO
    pass


# Generated at 2022-06-20 14:49:59.675460
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = {
        "token": "123456",
        "ignore_certs": True
    }
    g = GalaxyToken()
    f = g.set(test_token)
    assert g.config == test_token
    assert f is None


# Generated at 2022-06-20 14:50:05.496253
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('3ed3d33f-8bcb-4a9a-9b71-5c5c5d5e5f67')
    token.auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    # This exception is raised because of a lack of token validation
    try:
        print(token.get())
    except Exception as e:
        print(e)


# Generated at 2022-06-20 14:50:20.815401
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'access_token'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True
    client_id = None
    kc = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    assert kc.access_token == access_token
    assert kc.auth_url == auth_url
    assert kc.validate_certs == validate_certs
    assert kc.client_id == client_id


# Generated at 2022-06-20 14:50:30.464856
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    import re
    import base64

    token_fixture = 'Basic YW5zaWJsZS5jb206YW5zaWJsZS5jb20='
    username = 'ansible.com'
    password = 'ansible.com'
    token = BasicAuthToken(username, password).headers()['Authorization']
    assert token == token_fixture, 'Basic Token string returned should be equal to the one fixed'



# Generated at 2022-06-20 14:50:34.436099
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    gt = GalaxyToken()
    gt.set('12345')
    assert gt.get() == '12345'
    token = gt.config['token']
    assert token == '12345'



# Generated at 2022-06-20 14:50:36.287052
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = NoTokenSentinel()
    mytoken = GalaxyToken(token)
    assert mytoken
    assert mytoken.config

# Generated at 2022-06-20 14:50:40.949185
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    _token = 'test_token'
    obj = GalaxyToken()
    assert obj._token is None
    assert obj.headers() == {}
    obj.set(_token)
    assert obj._token == _token
    assert obj.headers()['Authorization'] == 'Token test_token'


# Generated at 2022-06-20 14:50:43.392653
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('user', 'passwd')
    token_headers = token.headers()
    assert 'Authorization' in token_headers

# Generated at 2022-06-20 14:50:46.306964
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    t = GalaxyToken()
    token = 'test_token'
    t.set(token)
    assert t.config['token'] == token


# Generated at 2022-06-20 14:50:50.218717
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('my_username', 'my_password')
    expected = {'Authorization': 'Basic bXlfdXNlcm5hbWU6bXlfcGFzc3dvcmQ='}
    assert expected == token.headers()


# Generated at 2022-06-20 14:50:51.574698
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel().__new__(NoTokenSentinel) is not None

# Generated at 2022-06-20 14:50:54.618858
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    class MockBasicAuthToken(BasicAuthToken):
        headers = None
        def get(self):
            return 'MOCKTOKEN'

    token = MockBasicAuthToken('USERNAME')
    token.headers()
    assert isinstance(token.headers, dict)

# Generated at 2022-06-20 14:51:13.536551
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'some-access-token'
    client_id = 'some-client-id'
    auth_url = 'https://some-auth-url/'
    validate_certs = True

# Generated at 2022-06-20 14:51:20.871046
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token_data = {'token': 'my_token'}
    token = GalaxyToken()
    token._config = token_data

    assert token.headers() == {'Authorization': 'Token my_token'}


# Generated at 2022-06-20 14:51:23.981082
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    print ("Testing GalaxyToken get method")
    token = GalaxyToken()
    print ("Token: ", token.get())


# Generated at 2022-06-20 14:51:27.029610
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    _token = 'testtoken'
    token = GalaxyToken(_token)
    token.set(_token)
    assert to_text(token.get()) == _token


# Generated at 2022-06-20 14:51:29.971541
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test = KeycloakToken(access_token='1234567890')
    assert test.headers()['Authorization'] == 'Bearer 1234567890'



# Generated at 2022-06-20 14:51:38.509263
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    class test_GalaxyToken(GalaxyToken):
        def __init__(self):
            self.b_file = '/tmp/ansible_token'
            self._config = {'token': 'MYTOKEN'}

    t = test_GalaxyToken()
    t.save()
    with open('/tmp/ansible_token', 'r') as f:
        assert "MYTOKEN" in f.read()

# Generated at 2022-06-20 14:51:42.206728
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = 'test-token'
    token_obj = GalaxyToken()
    token_obj.set(test_token)
    assert token_obj.get() == test_token

# Generated at 2022-06-20 14:51:46.430791
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # Constructor with token
    token = GalaxyToken('test_token')
    assert token.get() == 'test_token'
    # Constructor with no token
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-20 14:51:49.809892
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = "eyJhbGciOiJSUzI1NiJ9.xxxx"
    galaxy_token = GalaxyToken(token)
    assert(galaxy_token._token == token)


# Generated at 2022-06-20 14:51:55.462649
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'a-valid-token'
    galaxy_token = GalaxyToken()
    galaxy_token.set(token)
    assert galaxy_token.get() == token

# Generated at 2022-06-20 14:52:12.449730
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    galaxy_token.set('test_token')
    assert galaxy_token.config['token'] == 'test_token'


# Generated at 2022-06-20 14:52:18.170896
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    test_token = 'faketoken'
    t = GalaxyToken(test_token)
    # Write the token to a test token file
    t.save()
    # Make sure get method returns the correct token
    assert t.get() == test_token

# Generated at 2022-06-20 14:52:20.259842
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert sentinel is not None
    assert sentinel == NoTokenSentinel

# Generated at 2022-06-20 14:52:24.299387
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloaktoken = KeycloakToken(access_token='test_token')
    token = keycloaktoken.get()
    assert token == 'test_token', 'test_KeycloakToken_get() Failed. Bad token returned.'


# Generated at 2022-06-20 14:52:30.357974
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    token = KeycloakToken()
    assert token.get() == None

    token = KeycloakToken(access_token='my_access_token')
    assert token.get() == 'my_access_token'

    token = KeycloakToken(access_token='new_access_token')
    assert token.get() == 'new_access_token'



# Generated at 2022-06-20 14:52:31.663637
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is not None



# Generated at 2022-06-20 14:52:37.902692
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Create BasicAuthToken
    b = BasicAuthToken('user', 'password')
    assert b.username == 'user', 'The username was not set correctly'
    assert b.password == 'password', 'The password was not set correctly'
    print("test_BasicAuthToken() passed.")

test_BasicAuthToken()

# Generated at 2022-06-20 14:52:47.978659
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    ba_test1 = BasicAuthToken("user1", "secret")
    assert ba_test1 is not None
    assert ba_test1.token_type == 'Basic'
    assert ba_test1.username == 'user1'
    assert ba_test1.password == 'secret'
    assert ba_test1.get() == b'Basic dXNlcjE6c2VjcmV0'
    assert ba_test1.headers() == {'Authorization': 'Basic dXNlcjE6c2VjcmV0'}

    ba_test2 = BasicAuthToken("user2")
    assert ba_test2 is not None
    assert ba_test2.token_type == 'Basic'
    assert ba_test2.username == 'user2'
    assert ba_test2.password is None
    assert ba

# Generated at 2022-06-20 14:52:51.358972
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    test_token = KeycloakToken("test_token")
    assert test_token.get() is None
    test_token._token = "test_token_2"
    assert test_token.get() == "test_token_2"
    test_token.headers()

# Generated at 2022-06-20 14:52:55.324838
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    auth_token = BasicAuthToken('foo', 'bar')
    headers = auth_token.headers()
    assert headers == {'Authorization': 'Basic Zm9vOmJhcg=='}

# Generated at 2022-06-20 14:53:40.809853
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token_fixture = 'abc123'
    url_fixture = 'http://foo.bar'
    cid_fixture = 'my_client_id'
    # Test 1, defaults
    token = KeycloakToken(token_fixture, url_fixture)
    assert token.access_token == token_fixture
    assert token.auth_url == url_fixture
    assert token.client_id == 'cloud-services'

    # Test 2, with client_id
    token = KeycloakToken(token_fixture, url_fixture, client_id=cid_fixture)
    assert token.access_token == token_fixture
    assert token.auth_url == url_fixture
    assert token.client_id == cid_fixture

# Generated at 2022-06-20 14:53:42.498883
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    t = GalaxyToken()
    eq_(t.get(), None)



# Generated at 2022-06-20 14:53:43.725361
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()



# Generated at 2022-06-20 14:53:46.162754
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'admin'
    password = 'admin'
    token = BasicAuthToken(username, password)
    assert token.get() == 'Basic YWRtaW46YWRtaW4='


# Generated at 2022-06-20 14:53:51.128350
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken('test_token')
    assert token.get() is None
    token.config = {'token': 'test_token_returned'}
    assert token.get() == 'test_token_returned'


# Generated at 2022-06-20 14:53:54.309478
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken(username='foo', password='bar')
    assert token.headers() == {'Authorization': 'Basic Zm9vOmJhcg=='}


# Generated at 2022-06-20 14:54:05.445335
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token="123456"
    path="./test_token.yml"
    config={'token':token}

    def _read():
        with open(path, 'r') as f:
            config = yaml_load(f)
            if config and not isinstance(config, dict):
                return {}
        return config or {}

    # ensure the file does not exist
    if os.path.exists(path):
        os.remove(path)

    tok=GalaxyToken(token)
    tok.b_file=path
    tok._config = config
    tok.save()

    # verify the file exists
    if not os.path.exists(path):
        raise Exception("File %s does not exists" % path)

    # verify the file was written with the correct content

# Generated at 2022-06-20 14:54:08.562099
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token_file = '/tmp/ansible-galaxy-token-test'
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    assert galaxy_token.config == {}
    # Clean up
    os.remove(to_native(galaxy_token.b_file))



# Generated at 2022-06-20 14:54:11.280341
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_obj = GalaxyToken()
    test_obj._token = 'foobar'
    assert test_obj.headers() == { 'Authorization': 'Token foobar' }

# Generated at 2022-06-20 14:54:15.573684
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    arg1 = "Token"
    arg2 = "test"
    expected = {"Authorization": "Token test"}
    GalaxyToken.token_type = arg1
    GalaxyToken._token = arg2
    result = GalaxyToken.headers()
    assert result == expected


# Generated at 2022-06-20 14:55:27.407062
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:55:29.360960
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert isinstance(token.config, dict)

# Generated at 2022-06-20 14:55:32.891204
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    headers = BasicAuthToken('username', 'password').headers()
    # Verifies if the value returned in the headers is correct
    assert headers['Authorization'] == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:55:36.083707
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token="test")
    assert token.headers()['Authorization'] == 'Bearer test'



# Generated at 2022-06-20 14:55:39.596368
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    assert token.config['token'] == 'test'
    # should unset token
    token.set(None)
    assert token.get() is None
    assert token.config['token'] is None



# Generated at 2022-06-20 14:55:43.618132
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = 'secret-token'
    gt = GalaxyToken(token=token)
    assert gt.get() == token, 'The wrong token was loaded from %s' % gt.b_file



# Generated at 2022-06-20 14:55:47.247118
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    test_token = '12345'
    galaxy_token = GalaxyToken(token=test_token)
    token = galaxy_token.get()
    assert token == '12345'


# Generated at 2022-06-20 14:55:49.996840
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    no_token = NoTokenSentinel()
    assert str(no_token) == "<NoTokenSentinel (will ignore cmdline and GALAXY_TOKEN_PATH)>"

# Generated at 2022-06-20 14:55:51.265988
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    got = GalaxyToken('Token').get()
    want = None
    assert(got == want)



# Generated at 2022-06-20 14:55:52.834859
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    x = NoTokenSentinel()
    assert x