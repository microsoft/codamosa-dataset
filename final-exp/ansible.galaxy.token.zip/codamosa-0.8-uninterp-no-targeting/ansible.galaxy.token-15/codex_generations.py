

# Generated at 2022-06-20 14:46:46.468214
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken('refresh_token')
    headers = kt.headers()
    assert headers == {'Authorization': 'Bearer None'}


# Generated at 2022-06-20 14:46:47.385358
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel()

# Generated at 2022-06-20 14:46:48.608994
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    t = BasicAuthToke

# Generated at 2022-06-20 14:46:50.836925
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    a = BasicAuthToken('foo', 'bar')
    b = BasicAuthToken('foo')
    assert a.headers() == b.headers()

# Generated at 2022-06-20 14:47:01.612077
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:47:10.624332
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    t = KeycloakToken(access_token='test access token',
                      auth_url='https://fake.com/',
                      validate_certs=False,
                      client_id='test client id')
    assert t.access_token == 'test access token'
    assert t.auth_url == 'https://fake.com/'
    assert t.validate_certs == False
    assert t.client_id == 'test client id'
    assert t.get() != None
    assert t.headers()['Authorization'] == 'Bearer '+t.get()

# Generated at 2022-06-20 14:47:17.499470
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    config = token.config
    token.config = None
    assert token._config is None
    assert config
    assert isinstance(config, dict)

# Generated at 2022-06-20 14:47:28.743241
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = "https://sso.redhat.com"
    client_id = "cloud-services"

# Generated at 2022-06-20 14:47:44.517002
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test the Token with the username and password
    token = BasicAuthToken('test_user1', 'test_passwd1')
    token_headers = token.headers()
    assert "Authorization" in token_headers.keys()
    assert token_headers['Authorization'] == 'Basic dGVzdF91c2VyMTp0ZXN0X3Bhc3N3ZDE='

    # Test the Token with the username and empty password
    token = BasicAuthToken('test_user2', '')
    token_headers = token.headers()
    assert "Authorization" in token_headers.keys()
    assert token_headers['Authorization'] == 'Basic dGVzdF91c2VyMjo='

    # Test the Token with the username and password contains ':'

# Generated at 2022-06-20 14:47:54.506996
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():

    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'cloud-services'
    # The token must be a valid offline token.  An offline token from SSO can be obtained using
    # curl -X POST -u '<user>:<password>' -H 'Content-Type: application/x-www-form-urlencoded' -d 'client_id=<client_id>&grant_type=password' https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token
    # The value of the offline_token can then be used as the access_token in the KeycloakToken
    # constructor.
    access_token = '<offline_token>'

# Generated at 2022-06-20 14:48:04.392039
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    token.config = dict()
    token.config['token'] = 'test_token'
    assert (token.headers() == {'Authorization': 'Token test_token'})

# Generated at 2022-06-20 14:48:10.375188
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token_data = {'token': '12345'}
    with open(C.GALAXY_TOKEN_PATH, 'w') as f:
        yaml_dump(token_data, f, default_flow_style=False)

    token = GalaxyToken()

    headers = token.headers()

    assert 'token' in token.config
    assert token.config['token'] == '12345'
    assert headers['Authorization'] == 'Token 12345'

    os.remove(C.GALAXY_TOKEN_PATH)


# Generated at 2022-06-20 14:48:17.533997
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    k = KeycloakToken(access_token='my_token', auth_url='http://my.auth.server')
    assert k.access_token == 'my_token'
    assert k.auth_url == 'http://my.auth.server'
    assert k.client_id == 'cloud-services'


# Generated at 2022-06-20 14:48:30.571776
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = "abcd12345678"
    auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    client_id = "cloud-services"
    validate_certs = False
    token = KeycloakToken(access_token, auth_url, validate_certs, client_id).get()

    # Overwriting the get method in the KeycloakToken class
    def get_mock_token(self):
        return token

    KeycloakToken.get = get_mock_token

    # Overwriting the open_url method in the open_url module

# Generated at 2022-06-20 14:48:34.165057
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    g = GalaxyToken('abc')
    headers = g.headers()
    assert 'Authorization' in headers
    assert headers['Authorization'] == 'Token abc'


# Generated at 2022-06-20 14:48:41.410468
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    import unittest

    class TestTokenMethods(unittest.TestCase):
        def test_BasicAuthToken(self):
            token = BasicAuthToken('u', 'p')
            assert token.username == 'u'
            assert token.password == 'p'
            token = BasicAuthToken('u')
            assert token.username == 'u'
            assert token.password is None

    test_token = TestTokenMethods()
    test_token.test_BasicAuthToken()

# Generated at 2022-06-20 14:48:43.823556
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)


# Generated at 2022-06-20 14:48:52.155093
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected_bearer = "Bearer"
    token = "adfasdlfkjasl;dfjlas;djf"
    kctoken = KeycloakToken(token)
    assert kctoken.headers()["Authorization"] == expected_bearer + " " + token


# Generated at 2022-06-20 14:49:04.158612
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    from tempfile import gettempdir
    from ansible.compat import win_path_to_unix
    fake_token = 'FAKE_TOKEN'
    fake_file = os.path.join(gettempdir(), 'test_galaxy_token')
    galaxy_token = GalaxyToken(fake_token)
    galaxy_token.b_file = win_path_to_unix(fake_file)
    galaxy_token.set(fake_token)
    assert os.path.exists(fake_file)
    assert os.path.getsize(fake_file) > 0
    with open(fake_file, 'r') as f:
        written_token = yaml_load(f).get('token')
    assert written_token == fake_token
    os.remove(fake_file)

# Generated at 2022-06-20 14:49:05.326822
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = 'foo'
    my_galaxy_token = GalaxyToken(token)
    assert my_galaxy_token.get() == token


# Generated at 2022-06-20 14:49:16.381660
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    g = GalaxyToken()
    assert 'Authorization' not in g.headers()

    g = GalaxyToken(token='token')
    assert g.get() == 'token'
    assert 'Authorization' in g.headers()


# Generated at 2022-06-20 14:49:21.582034
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('foo', 'bar', validate_certs=False)
    assert(token.access_token == 'foo')
    assert(token.auth_url == 'bar')
    assert(token.validate_certs == False)



# Generated at 2022-06-20 14:49:32.941087
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    my_auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    my_access_token = "foo"

    kc = KeycloakToken(access_token=my_access_token, auth_url=my_auth_url)
    assert kc._form_payload() == "grant_type=refresh_token&client_id=cloud-services&refresh_token=foo"

    kc = KeycloakToken(access_token=my_access_token, auth_url=my_auth_url, client_id="other-client")
    assert kc._form_payload() == "grant_type=refresh_token&client_id=other-client&refresh_token=foo"

# Generated at 2022-06-20 14:49:37.848919
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    import os
    import ansible.constants as C
    os.environ['ANSIBLE_GALAXY_TOKEN_PATH'] = 'testpath'
    token = GalaxyToken().get()
    assert 'testpath' == C.GALAXY_TOKEN_PATH
    assert token is None

# Generated at 2022-06-20 14:49:40.856842
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken("foo", "bar")
    assert token.get() == "Basic Zm9vOmJhcg=="
    token = BasicAuthToken("foo")
    assert token.get() == "Basic Zm9vOg=="
    token = BasicAuthToken("foo", "")
    assert token.get() == "Basic Zm9vOg=="


# Generated at 2022-06-20 14:49:45.551792
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken()
    assert token.access_token == None
    assert token.auth_url == None
    assert token.validate_certs == True
    assert token.client_id == 'cloud-services'
    assert token._token == None



# Generated at 2022-06-20 14:49:57.181635
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''Unit test for method get of class KeycloakToken
        and _form_payload of class KeycloakToken'''
    expect_result = {'access_token': 'qwertyuiop', 'expires_in': 7200, 'refresh_expires_in': 1800,
                     'refresh_token': 'asdfghjkl', 'token_type': 'bearer'}
    expect_result_st = json.dumps(expect_result)
    expect_payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=asdfghjkl'

# Generated at 2022-06-20 14:50:06.385701
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    ''' Return a dictionary with entries:
    'Authorization': 'Bearer <access_token>'
    '''
    from ansible.plugins.galaxy.api.keycloak import KeycloakToken
    from ansible.module_utils.six import PY3
    import random
    import string

    # Create random token of bogus characters
    length = random.randint(1, 128)
    rnd = [random.choice(string.ascii_letters) for n in range(length)]
    access_token = ''.join(rnd)

    # Create a random auth URL
    length = random.randint(1, 128)
    rnd = [random.choice(string.ascii_letters) for n in range(length)]
    auth_url = ''.join(rnd)

    # Create a random client_

# Generated at 2022-06-20 14:50:10.141547
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w+') as f:
        yaml_dump({'token': 'foobar'}, f, default_flow_style=False)
    state = GalaxyToken(token=NoTokenSentinel())
    state.config['token'] = 'barfoo'
    state.save()
    with open(path, 'r') as f:
        config = yaml_load(f)
    os.remove(path)
    assert config == {'token': 'barfoo'}

# Generated at 2022-06-20 14:50:16.600416
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='123')
    assert token.token_type == 'Bearer'
    assert token.access_token == '123'
    assert token.auth_url is None
    assert token.validate_certs is True
    assert token.client_id == 'cloud-services'
    # TODO: Assert that the payload is constructed correctly


# Generated at 2022-06-20 14:50:25.711046
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken('123456789')
    assert keycloak_token.access_token == '123456789'
    assert keycloak_token.auth_url == C.GALAXY_KEYCLOAK_SERVER



# Generated at 2022-06-20 14:50:28.971248
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Create class __new__ object
    nts_class_instance = NoTokenSentinel
    assert nts_class_instance.__new__



# Generated at 2022-06-20 14:50:31.827875
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bat = BasicAuthToken('testuser', 'testpassword')
    assert bat.username == 'testuser'
    assert bat.password == 'testpassword'
    return

# Generated at 2022-06-20 14:50:32.946770
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert bool(NoTokenSentinel()) is True

# Generated at 2022-06-20 14:50:43.980277
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # Setup
    import inspect
    import sys

    # Get the token to be passed to KeycloakToken
    def get_token(data):
        return data
    # Get the 'auth_url' to be passed to KeycloakToken
    def get_auth_url(data):
        return data
    # Get the 'client_id' to be passed to KeycloakToken
    def get_client_id(data):
        return data
    # Get the class name
    cls = str(KeycloakToken.__class__).replace("<class 'ansible.galaxy.token.", "").replace("'>", "")
    # Get the method names from KeycloakToken class
    methodlist = [method for method in dir(KeycloakToken) if callable(getattr(KeycloakToken, method))]
    # Remove the '

# Generated at 2022-06-20 14:50:45.766228
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('new_token')
    assert token.get() == 'new_token'


# Generated at 2022-06-20 14:50:49.374799
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('bob', 'bobspassword').get()
    assert token == 'Ym9iOmJvYnNwYXNzd29yZA=='


# test suite for class GalaxyToken

# Generated at 2022-06-20 14:50:49.848953
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    s = NoTokenSentinel()
    assert not s

# Generated at 2022-06-20 14:50:54.559289
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    class TestBasicAuthToken(BasicAuthToken):
        def __init__(self, username, password=None):
            super(TestBasicAuthToken, self).__init__(username, password)

    my_token = TestBasicAuthToken('my_username', 'my_password')
    expected = 'Basic ' + TestBasicAuthToken._encode_token('my_username', 'my_password')
    assert expected == my_token.headers().get('Authorization')

# Generated at 2022-06-20 14:51:02.297511
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    t = KeycloakToken(auth_url='http://auth.url', access_token='access_token')
    print(t.get())

if __name__ == '__main__':
    test_KeycloakToken_get()

# Generated at 2022-06-20 14:51:09.869682
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # confirm the token is created as expected
    token = BasicAuthToken('user', 'pass')
    assert token.get() == 'dXNlcjpwYXNz'

# Generated at 2022-06-20 14:51:18.270716
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    expected_output = {'Authorization': 'Token 498f2aa2d7b1e0d54ee0b8708e6f743'}

    file_content = """
---
# Ansible Galaxy token file
token: '498f2aa2d7b1e0d54ee0b8708e6f743'
"""
    # Mock the class
    class mock_GalaxyToken(object):
        def __init__(self, b_file):
            self.b_file = b_file
        def _read(self):
            return yaml_load(file_content)

    # Build the object
    my_GalaxyToken = mock_GalaxyToken('')

    assert my_GalaxyToken._read() == yaml_load(file_content)
    assert my_GalaxyToken.headers()

# Generated at 2022-06-20 14:51:23.007007
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    basic_auth_token = BasicAuthToken('testuser', 'testpassword')
    assert basic_auth_token.get() == 'dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'
    basic_auth_token = BasicAuthToken('testuser', None)
    assert basic_auth_token.get() == 'dGVzdHVzZXI6'

# Generated at 2022-06-20 14:51:26.321886
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_token = GalaxyToken('my_test_token')
    headers = test_token.headers()
    assert headers['Authorization'] == 'Token my_test_token'



# Generated at 2022-06-20 14:51:27.465145
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()


# Generated at 2022-06-20 14:51:37.252724
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test case where only username and no password passed in
    token = BasicAuthToken('foo_username', '')
    assert token.headers() == {'Authorization': 'Basic Zm9vX3VzZXJuYW1lOg=='}
    # Test case where username and password passed in
    token = BasicAuthToken('foo_username', 'foo_password')
    assert token.headers() == {'Authorization': 'Basic Zm9vX3VzZXJuYW1lOmZvb19wYXNzd29yZA=='}



# Generated at 2022-06-20 14:51:50.273683
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # happy path
    bt = BasicAuthToken('foo', 'bar')
    assert bt.token_type == 'Basic'
    assert bt.username == 'foo'
    assert bt.password == 'bar'
    assert bt.get() == 'Zm9vOmJhcg=='

    # password empty means same thing as no password
    bt = BasicAuthToken('foo')
    assert bt.get() == 'Zm9vOg=='

    # non-unicode username and password
    bt = BasicAuthToken(b'foo', b'bar')
    assert bt.get() == 'Zm9vOmJhcg=='
    bt = BasicAuthToken(b'foo')
    assert bt.get() == 'Zm9vOg=='
    bt

# Generated at 2022-06-20 14:52:04.957962
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:52:08.925481
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    c = BasicAuthToken('unit-test', 'unit-test')
    headers = c.headers()
    assert headers
    assert headers['Authorization'] == 'Basic dW5pdC10ZXN0OnVuaXQtdGVzdA=='

# Generated at 2022-06-20 14:52:23.028977
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    if os.path.isfile('/tmp/ansible_galaxy'):
        os.remove('/tmp/ansible_galaxy')

    mytoken = GalaxyToken()

    # Token file doesn't exist
    assert len(mytoken._config) == 0
    assert mytoken.get() is None

    # Set a token
    mytoken.set('TestToken')
    assert mytoken.get() == 'TestToken'

    # Reset the object
    mytoken = GalaxyToken()

    # Now it exists
    assert len(mytoken._config) == 1
    assert mytoken.get() == 'TestToken'

# Generated at 2022-06-20 14:52:41.783671
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    tok = BasicAuthToken('name')
    assert tok.username == 'name'
    assert tok.password == None
    assert tok.get()

# test helper function _encode_token

# Generated at 2022-06-20 14:52:45.835290
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert gt.get() is None

    gt = GalaxyToken(token='123')
    assert gt.get() == '123'

    assert 'Authorization' not in gt.headers()

    gt = GalaxyToken(token='abc')
    asse

# Generated at 2022-06-20 14:52:54.285325
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    ansible_username = 'ansible'
    ansible_password = 'ansible'

    username = 'test_user'
    password = 'test_password'

    input_username = 'test_user'
    input_password = 'test_password'

    input_b64_token = BasicAuthToken(input_username, input_password).get()
    b64_token = 'dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='
    assert input_b64_token == b64_token

    ansible_b64_token = BasicAuthToken(ansible_username, ansible_password).get()
    assert ansible_b64_token != b64_token



# Generated at 2022-06-20 14:53:06.575406
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:53:15.678857
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='test_access_token',
                          auth_url='http://test_auth_url.com')
    assert token.access_token == 'test_access_token'
    assert token.auth_url == 'http://test_auth_url.com'

# Generated at 2022-06-20 14:53:25.761637
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://sso.something.com/auth/realms/new_realm/protocol/openid-connect/token'
    access_token = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjY0YzZiYjEyMDhjMDRjNT';  # Fake base64 encoded JWT token
    client_id = None

    kctoken = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=True, client_id=client_id)

    assert kctoken.access_token == access_token
    assert kctoken.auth_url == auth_url
    assert kctoken.validate_certs == True
    assert kctoken.client_id == 'cloud-services'




# Generated at 2022-06-20 14:53:41.300318
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a fake auth_server-like object to respond to requests
    class FakeAuthServer(object):
        def __init__(self, auth_url, payload):
            self.auth_url = auth_url
            self.payload = payload
        def POST(self, url, data, validate_certs, method, http_agent):
            # Make sure the request is properly formed
            if url != self.auth_url:
                raise Exception('Bad auth url: %s' % url)
            if data != self.payload:
                raise Exception('Bad payload: %s' % data)
            if validate_certs != False:
                raise Exception('Bad validate_certs: %s' % validate_certs)
            if method != 'POST':
                raise Exception('Bad method: %s' % method)

# Generated at 2022-06-20 14:53:43.029258
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is not None

# Generated at 2022-06-20 14:53:50.187995
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-20 14:53:51.575483
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    assert galaxy_token.get() == None

# Generated at 2022-06-20 14:54:14.979575
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken._encode_token('username', 'password') == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    assert BasicAuthToken._encode_token('username', '') == 'dXNlcm5hbWU6'
    assert BasicAuthToken._encode_token('username', None) == 'dXNlcm5hbWU6'
    assert BasicAuthToken._encode_token('username', b'password') == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    assert BasicAuthToken._encode_token('username', b'') == 'dXNlcm5hbWU6'

# Generated at 2022-06-20 14:54:17.570420
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    from ansible.module_utils import basic
    result = basic.AnsibleModule(argument_spec={}).exit_json()
    import types
    assert isinstance(result, types.ModuleType)



# Generated at 2022-06-20 14:54:19.977312
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ktoken = KeycloakToken('access_token', client_id='test_client_id')
    assert ktoken._token is None
    ktoken.get()
    assert ktoken._token == 'access_token'

# Generated at 2022-06-20 14:54:23.342186
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    obj = KeycloakToken(auth_url="http://mock-auth-url",
                        access_token="mock_token",
                        validate_certs=True,
                        client_id="cloud-services")



# Generated at 2022-06-20 14:54:24.664870
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    assert nts is nts
    assert nts is NoTokenSentinel()

# Generated at 2022-06-20 14:54:26.288803
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    tok = GalaxyToken()
    assert tok.get() is None
    tok = GalaxyToken('mock_token')
    assert tok.get() == 'mock_token'

# Generated at 2022-06-20 14:54:31.203252
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_data = [
        {
            'token': 'b10aa3a7aab591c8496f7a9f2a2c7d23b4e4e749',
            'expected_file': '''token: b10aa3a7aab591c8496f7a9f2a2c7d23b4e4e749
''',
        },
        {
            'token': None,
            'expected_file': '''token:
''',
        },
    ]
    for test in test_data:
        display.vvv('test is %s' % test)
        token = GalaxyToken()
        token.set(test['token'])
        # Need to read the token file to confirm it was written correctly
        written_token = token._read().get('token', None)


# Generated at 2022-06-20 14:54:38.024878
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    test_username = 'johndoe'
    test_password = 'password'
    test_username_password = 'johndoe:password'
    test_token = BasicAuthToken(test_username, test_password)
    assert(test_token.username == test_username)
    assert(test_token.get() == base64.b64encode(to_bytes(test_username_password, encoding='utf-8', errors='surrogate_or_strict')).decode("utf-8"))

# Unit tests for method _encode_token of class BasicAuthToken

# Generated at 2022-06-20 14:54:40.921498
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    """ Check if NoTokenSentinel.__new__ return an istance of NoTokenSentinel. """
    t = NoTokenSentinel()
    assert isinstance(t, NoTokenSentinel)

# Generated at 2022-06-20 14:54:42.408182
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)

# Generated at 2022-06-20 14:55:09.175216
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    """
    Ensure set method of class GalaxyToken writes out the token
    """
    from ansible.utils.path import unfrackpath
    from shutil import rmtree

    galaxy_token_path = unfrackpath("$HOME/.ansible/galaxy/token")
    galaxy_token_file = 'test_galaxy_token_file'

# Generated at 2022-06-20 14:55:13.476471
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # for a valid url, it should return a token
    k1 = KeycloakToken(access_token='foobar', auth_url='https://sso.redhat.com/auth/realms/redhat-internal/protocol/openid-connect/token')
    assert k1.get() is not None

    # for a valid url, it should return a token
    k2 = KeycloakToken(access_token='foobar', auth_url='https://sso.redhat.com/auth/realms/redhat-internal/protocol/openid-connect/token', client_id='cloud-services')
    assert k2.get() is not None

# Generated at 2022-06-20 14:55:17.196502
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = 'admin'
    password = 'password'
    result = BasicAuthToken(username, password).headers()
    assert result['Authorization'] == 'Basic ' + BasicAuthToken._encode_token(username, password)

# Generated at 2022-06-20 14:55:17.818113
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    pass

# Generated at 2022-06-20 14:55:20.051408
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert(token is not None)

# Unit test BasicAuthToken

# Generated at 2022-06-20 14:55:24.369680
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    t1 = BasicAuthToken('foo', 'bar')
    assert t1.get() == 'Zm9vOmJhcg=='

    t2 = BasicAuthToken('foo', None)
    assert t2.get() == 'Zm9vOg=='



# Generated at 2022-06-20 14:55:31.634145
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://sso.cloud.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    token = 'some token'
    kct = KeycloakToken(token, auth_url)
    kct_client_id = KeycloakToken(token, auth_url, client_id='cloud.redhat.com')
    assert (kct.client_id == 'cloud-services')
    assert (kct_client_id.client_id == 'cloud.redhat.com')
    assert (kct_client_id._form_payload() == 'grant_type=refresh_token&client_id=cloud.redhat.com&refresh_token=some token')

# Generated at 2022-06-20 14:55:33.484559
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    assert KeycloakToken(access_token='acc_token', auth_url='auth_url').headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-20 14:55:39.059007
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    import pytest
    from ansible.galaxy.token import NoTokenSentinel

    with pytest.raises(TypeError) as excinfo:
        NoTokenSentinel(foo='bar')

    assert "type object 'NoTokenSentinel' has no __init__ method" in to_text(excinfo.value)

# Generated at 2022-06-20 14:55:48.905735
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test for case when user passes in username and password
    basic_auth_token_1 = BasicAuthToken('TestUser', 'TestPassword')
    expected_header_1 = {'Authorization': 'Basic ' + basic_auth_token_1.get()}
    assert basic_auth_token_1.headers() == expected_header_1

    # Test for case when user only passes in username and no password
    basic_auth_token_2 = BasicAuthToken('TestUser')
    expected_header_2 = {'Authorization': 'Basic ' + basic_auth_token_2.get()}
    assert basic_auth_token_2.headers() == expected_header_2