

# Generated at 2022-06-20 14:46:49.766540
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='a')
    headers = kt.headers()
    assert headers['Authorization'] == 'Bearer None', 'test_headers() of class KeycloakToken failed!'


# Generated at 2022-06-20 14:47:00.936373
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Test getting a token from GalaxyToken
    def _test(test_token, test_config, expected_result):
        t = GalaxyToken(token=test_token)
        t._config = test_config
        assert t.get() == expected_result

    #
    # Test data
    #

    test_token = '12345'
    test_config_with_token = {'token': '67890'}
    test_config_no_token = {}

    #
    # Run tests
    #

    _test(test_token, test_config_with_token, test_token)
    _test(test_token, test_config_no_token, test_token)
    _test(None, test_config_with_token, '67890')

# Generated at 2022-06-20 14:47:02.594847
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert(sentinel is not None)


# Generated at 2022-06-20 14:47:07.186658
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    t = GalaxyToken()
    token = "abcd1234"
    t.set(token)
    assert t.headers() == {'Authorization': 'Token %s' % (token)}, "GalaxyToken headers is not correct"



# Generated at 2022-06-20 14:47:11.406350
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test intended to check if the token is encoded
    token = BasicAuthToken("mike", "password")
    assert (token.get() != "mike:password")
    # Test intended to check if headers is method returns a dictionary
    assert isinstance(token.headers(), dict)

# Generated at 2022-06-20 14:47:16.264440
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    filename = '/tmp/test_GalaxyToken_set.txt'
    token = 'test_token_set'
    t = GalaxyToken()
    t.b_file = filename
    t.set(token)
    assert t.get() == token
    assert t.config == {'token': token}
    os.remove(filename)

# Generated at 2022-06-20 14:47:18.705195
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nt = NoTokenSentinel(1,2)
    assert type(nt) == NoTokenSentinel

# Generated at 2022-06-20 14:47:19.858618
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert type(NoTokenSentinel()) == type(None)

# Generated at 2022-06-20 14:47:23.116601
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    try:
        BasicAuthToken('foo:bar')
    except TypeError as e:
        assert "Can't convert 'str' object to" in str(e)

# Generated at 2022-06-20 14:47:26.728874
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    obj = BasicAuthToken(username='TestUser', password='TestPassword')
    ret = obj.get()
    assert ret == 'VGVzdFVzZXI6VGVzdFBhc3N3b3Jk'


# Generated at 2022-06-20 14:47:34.711225
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    our_token = "Token 1234567890"
    token.set(our_token)
    assert token.get() == our_token
    token.set(None)
    assert token.get() is None


# Generated at 2022-06-20 14:47:46.752835
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    '''
    Unit test for method `get` of class `GalaxyToken`.
    '''
    C.GALAXY_TOKEN_PATH = './test/galaxy_token_file.txt'
    test_token = None
    test_path = './test/galaxy_token_file.txt'
    test_file = 'test_token'

    # Test Case 1: The galaxy token file is not created
    open(test_path, 'w').close()
    os.chmod(test_path, S_IRUSR | S_IWUSR)  # owner has +rw
    galaxy_token = GalaxyToken(test_token)
    assert galaxy_token.get() is None

    # Test Case 2: The galaxy token file is not created

# Generated at 2022-06-20 14:47:52.871864
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-20 14:48:02.649220
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # test username with no password
    token = BasicAuthToken('admin')
    assert token.username == 'admin'
    assert token.password is None

    # test username with password
    token = BasicAuthToken('admin', 'password')
    assert token.username == 'admin'
    assert token.password == 'password'

    # test username and password with special characters
    token = BasicAuthToken('admin', 'you-can-%totally_b@se64_this+')
    assert token.username == 'admin'
    assert token.password == 'you-can-%totally_b@se64_this+'


# Generated at 2022-06-20 14:48:05.780833
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    bat = BasicAuthToken('username', 'password')
    token = bat.get()
    assert token == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:48:13.239846
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    import unittest

    class TestBasicAuthToken:
        def __init__(self, username, password=None):
            self.username = username
            self.password = password
            self._token = None

    class test_BasicAuthToken_get_class(unittest.TestCase):

        def test_basic_token_get_with_username_and_password(self):
            tbt = TestBasicAuthToken('test_ansible', 'password')
            self.assertIsInstance(tbt.get(), unicode)
            self.assertEquals('dGVzdF9hbnNpYmxlOnBhc3N3b3Jk',tbt.get())

        def test_basic_token_get_username_value_is_none(self):
            tbt = TestBasicAuthToken(None, 'password')


# Generated at 2022-06-20 14:48:19.375801
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nts_instance = NoTokenSentinel(access_token=None, auth_url=None, validate_certs=None, client_id=None)
    assert isinstance(nts_instance, NoTokenSentinel)
    assert nts_instance.__class__ == NoTokenSentinel


# Generated at 2022-06-20 14:48:21.203921
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('123')
    assert token.headers()['Authorization'] == 'Token 123'


# Generated at 2022-06-20 14:48:30.747185
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    '''Unit test for method save of class GalaxyToken'''
    import shutil
    import tempfile
    import os

    ORIGFILE = 'test_galaxy_token.yml'
    TESTFILE = 'test_galaxy_token_test.yml'

    _dir = tempfile.mkdtemp()

# Generated at 2022-06-20 14:48:34.841636
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('username', 'password')
    assert(token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ=')


# Generated at 2022-06-20 14:48:52.042900
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('test_user:test_password')
    assert token.get() == 'dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='
    token = BasicAuthToken(to_bytes('test_user:test_password'))
    assert token.get() == 'dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='
    token = BasicAuthToken(username='test_user', password='test_password')
    assert token.get() == 'dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='
    token = BasicAuthToken(username=to_bytes('test_user'), password=to_bytes('test_password'))

# Generated at 2022-06-20 14:49:04.065344
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    ''' test that headers sends the correct client_id

    - create a KeycloakToken
    - call headers
    - assert headers has 'Authorization: Bearer <token>'
    '''
    from ansible.module_utils.six import PY3
    from ansible.module_utils.urls import open_url

    # this is just for unit testing, so validate_certs actually needs to be False
    # so that Requests does not check server certificates
    galaxy_token = KeycloakToken('abc123', auth_url='https://sso.redhat.com/auth/realms/redhat/protocol/openid-connect/token', validate_certs=False)

    assert galaxy_token.token_type == 'Bearer'


# Generated at 2022-06-20 14:49:11.025053
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    class Response:
        def __init__(self,response):
            self.response = response
            self.status_code = 200

        def read(self):
            return self.response


# Generated at 2022-06-20 14:49:17.908298
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    usr_pass = BasicAuthToken(username='test_usr', password='test_pass')
    token = 'dGVzdF91c3I6dGVzdF9wYXNz'
    assert usr_pass.get() == token
    assert usr_pass.headers() == {'Authorization': 'Basic %s' %usr_pass.get()}


# Generated at 2022-06-20 14:49:21.582479
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = "user"
    password = "pass"
    token_from_BasicAuthToken = BasicAuthToken(username, password)
    token_from_BasicAuthToken.get()

# Generated at 2022-06-20 14:49:25.288028
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abcdef', auth_url='http://nourl')
    assert token.headers()['Authorization'] == 'Bearer abcdef'


# Unit tests for method get and set of class GalaxyToken

# Generated at 2022-06-20 14:49:27.145140
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)

# Generated at 2022-06-20 14:49:29.432801
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts_objs = NoTokenSentinel()
    assert type(nts_objs) is NoTokenSentinel, "Should get NoTokenSentinel obj"

# Generated at 2022-06-20 14:49:38.664599
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import json
    import os
    import tempfile
    import pytest

    token = GalaxyToken()

    d = tempfile.mkdtemp()
    try:
        old_dir = os.getcwd()
        os.chdir(d)

        token.b_file = os.path.join(d, 'test_galaxy_token_save')
        token.set('foo')
        with open(token.b_file, 'r') as f:
            f_data = yaml_load(f)
        assert f_data == {'token': 'foo'}

        os.chdir(old_dir)
    except:
        pytest.fail('test_GalaxyToken_save raises unexpected exceptions')
    finally:
        os.chdir(old_dir)
    os.rmdir(d)

# Generated at 2022-06-20 14:49:45.998142
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # password is optional
    token = BasicAuthToken('myusername', 'mypassword')
    assert token.get() == 'bXl1c2VybmFtZTpteXBhc3N3b3Jk'

    # if no password, use empty string
    token = BasicAuthToken('myusername')
    assert token.get() == 'bXl1c2VybmFtZTo='

# Generated at 2022-06-20 14:49:54.725147
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    new = KeycloakToken(access_token='12345',auth_url='https://sso.redhat.com/auth/realms/cloud-services/protocol/openid-connect/token')
    new.get()



# Generated at 2022-06-20 14:50:02.101245
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    """
    The ansible configuration file for galaxy token is not existed,
    it should create one and set it to {}.
    """
    test_token_file = '/tmp/galaxy_token_file.yml'
    C.GALAXY_TOKEN_PATH = test_token_file
    token = GalaxyToken()
    token.get()
    assert os.path.isfile(test_token_file)

    """
    The ansible configuration file for galaxy token is existed,
    it should read the token from the configuration file.
    """
    with open(test_token_file, 'w') as f:
        f.write('token: abc')
    token = GalaxyToken()
    assert token.get() == 'abc'


# Generated at 2022-06-20 14:50:06.301203
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken('c1e737cdd5b84497b1f9b5f715e3b3f8')
    assert token.get() == 'c1e737cdd5b84497b1f9b5f715e3b3f8'
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-20 14:50:10.931413
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken('dGVzdGluZyBmb3IgY2xhc3M=')
    assert token.get() == 'dGVzdGluZyBmb3IgY2xhc3M='

# Generated at 2022-06-20 14:50:12.733940
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    a = NoTokenSentinel()
    assert isinstance(a, NoTokenSentinel)

# Generated at 2022-06-20 14:50:23.051916
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'abc123'
    token_file = '/tmp/test_galaxy'
    token_obj = GalaxyToken(token)
    token_obj.save()
    with open(token_file, 'r') as f:
        test_token = yaml_load(f)
    assert isinstance(test_token, dict), "Failed to parse %s" % test_token
    assert 'token' in test_token, "Failed to find token in %s" % test_token
    assert test_token['token'] == token, "Token '%s' in %s does not match expected token '%s'." % (test_token['token'], test_token, token)

# Generated at 2022-06-20 14:50:27.554608
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    t = KeycloakToken('access_token', 'auth_url')
    assert t.access_token == 'access_token'
    assert t.auth_url == 'auth_url'


# Generated at 2022-06-20 14:50:39.115313
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.mock import patch

    import mock

    class MockResponse(object):
        def __init__(self, mock_read):
            self.read = mock_read

    token = 'fake_token'
    refresh_token = 'fake_refresh_token'
    auth_url = 'https://auth.example.com/auth/realms/master/protocol/openid-connect/token'
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=%s' % refresh_token
    mock_read = mock.MagicMock(return_value='{"token_type": "Bearer", "access_token": "%s"}' % token)
    mock_

# Generated at 2022-06-20 14:50:47.633721
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-20 14:50:50.271457
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    tok = KeycloakToken('test')
    expected_result = {'Authorization': 'Bearer test'}
    assert tok.headers() == expected_result

# Generated at 2022-06-20 14:51:10.259188
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.galaxy import GalaxyToken
    import shutil

    token_file = 'mytoken_test'
    if os.path.isfile(token_file):
        os.remove(token_file)
    os.environ['ANSIBLE_GALAXY_TOKEN_PATH'] = token_file
    temp_token = 'temporary_token'
    new_token = 'new_token'

    gt = GalaxyToken(new_token)

    # Test saving non existing file
    gt.save()
    with open(token_file, 'r') as f:
        content = yaml_load(f)

    assert content['token'] == new_token

    # Test saving existing file
    gt.set(temp_token)
    gt.save()

# Generated at 2022-06-20 14:51:12.738242
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    tok = NoTokenSentinel()
    if tok:
        tok = tok
    del tok

# Generated at 2022-06-20 14:51:20.882409
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='123456')
    headers = token.headers()
    token_type = headers['Authorization'].split()[0]
    assert token_type == 'Bearer'


# Generated at 2022-06-20 14:51:27.908403
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    assert(token.headers()['Authorization'] == 'Token None')
    # Set the token
    token.set('fake_token')
    assert(token.headers()['Authorization'] == 'Token fake_token')
    # Save the token
    token.save()
    # Set the token
    token.set('fake_token')
    assert(token.headers()['Authorization'] == 'Token fake_token')
    # Get the token
    token.get()
    assert(token.headers()['Authorization'] == 'Token fake_token')
    # Remove the token
    token.set(None)
    assert(token.headers()['Authorization'] == 'Token None')
    # Set the token
    token.set('fake_token')

# Generated at 2022-06-20 14:51:31.996567
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = "test token"
    token_path = 'GalaxyToken'
    galaxy_token = GalaxyToken(token=token)
    galaxy_token.set(token)
    assert galaxy_token.config['token'] == token

# Generated at 2022-06-20 14:51:38.846343
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    b64val = base64.b64encode(b'user:passwd')
    token = BasicAuthToken('user', 'passwd')
    assert token.get() == b64val
    token = BasicAuthToken('user', None)
    b64val = base64.b64encode(b'user:')
    assert token.get() == b64val


# Generated at 2022-06-20 14:51:42.999139
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = "12345"
    gt = GalaxyToken()
    gt.set(token)
    assert gt.headers()['Authorization'] == 'Token %s' % token


# Generated at 2022-06-20 14:51:46.376365
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_token = GalaxyToken('test')
    assert test_token.headers() == {'Authorization': 'Token test'}


# Generated at 2022-06-20 14:51:47.561826
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel()

# Generated at 2022-06-20 14:51:51.227392
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = 'abcdefg'
    galaxy_token = GalaxyToken(token)
    assert galaxy_token.headers() == {'Authorization': 'Token %s' % token}



# Generated at 2022-06-20 14:52:06.455389
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(access_token='refresh_token', validate_certs=True, auth_url='http://url')
    assert keycloak_token.get() == 'access_token'
    keycloak_token._token = None
    assert keycloak_token.get() == 'access_token'

# Generated at 2022-06-20 14:52:11.906557
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'some token'
    galaxy_token = GalaxyToken(token)

    # Token is being set correctly
    galaxy_token.set(token)
    assert galaxy_token.get() == token

    # Token is being save correctly
    galaxy_token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

    # Invalid token
    galaxy_token.set(None)
    assert galaxy_token.get() is None or galaxy_token.get() == ''



# Generated at 2022-06-20 14:52:16.228294
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()

    assert token is not None
    assert token.b_file == C.GALAXY_TOKEN_PATH

# Generated at 2022-06-20 14:52:28.832633
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Given a KeycloakToken object
    #  - with a defined offline token,
    #  - when function 'get' is called,
    #  - and it succeeds in retrieving a temp token
    #  - then return value should be as defined in 'data'
    kt = KeycloakToken(auth_url=None, access_token=None)

# Generated at 2022-06-20 14:52:30.809745
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    token.set('12345')
    assert token.headers()['Authorization'] == 'Token 12345'


# Generated at 2022-06-20 14:52:31.997440
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    assert nts is nts

# Generated at 2022-06-20 14:52:44.767838
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import configparser

    bad_types = [True, None, 5, {1: 2}, 'test']
    good_types = [False, configparser.RawConfigParser()]
    good_types.extend(({}, {'token': None}, {'token': 'token'}, {'token': 'token', 'other': 'thing'}))
    good_types.append({'token': None} if PY3 else {'token': 'None'})
    good_types.append({'token': 'token'} if PY3 else {'token': 'token', 'token': None})

    # Config, Expected Output

# Generated at 2022-06-20 14:52:45.805017
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel()

# Generated at 2022-06-20 14:52:54.752535
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    '''
        Test for token retrieval from ansible.cfg
    '''
    token_file_path = os.path.join(os.path.dirname(__file__), 'token_file.yml')
    # Create token file with token information
    try:
        with open(token_file_path, 'w') as f:
            f.write("token:123456")
    except IOError as e:
        print("I/O error({0}) while creating token file: {1}".format(e.errno, e.strerror))
    else:
        token = GalaxyToken(token_file_path)
        assert token.get() == '123456'
        os.remove(token_file_path)


if __name__ == '__main__':
    test_GalaxyToken_get()

# Generated at 2022-06-20 14:53:06.932295
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    class MockToken(GalaxyToken):
        # Mock the _read method so that we can test the save method.
        def _read(self):
            return {}

    t = MockToken(token='test')
    t.save()  # Calling the save method.

    # Creating an ansible.cfg file with following content.
    ansible_config = open('ansible.cfg', 'w')
    ansible_config.write('[galaxy]\n')
    ansible_config.write('token_file = .galaxy_token')
    ansible_config.close()

    # Reading the contents of .galaxy_token file.
    galaxy_token = open('.galaxy_token', 'r')
    token_file_contents = galaxy_token.read()
    galaxy_token.close()

    # Asserting if new

# Generated at 2022-06-20 14:53:33.977622
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    if os.path.isfile('/tmp/galaxy_token'):
        os.remove('/tmp/galaxy_token')

    token = GalaxyToken()
    token.set('fake token')

    assert token.get() == 'fake token'
    assert os.path.isfile('/tmp/galaxy_token')

    # cleanup
    os.remove('/tmp/galaxy_token')

test_GalaxyToken_set()

# Generated at 2022-06-20 14:53:37.216267
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel) # Type check
    # Check that __new__ returns one only object
    assert NoTokenSentinel() is NoTokenSentinel()



# Generated at 2022-06-20 14:53:38.977541
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is not None


# Generated at 2022-06-20 14:53:40.427203
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken('token')
    assert token.config['token'] == 'token'
    assert token.config == {'token': 'token'}

# Generated at 2022-06-20 14:53:46.248282
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    if not os.environ.get('TEST_KEYCLOAK_TOKEN_GET'):
        return

    token = KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          access_token='mY1ff1N1t0k3n')

    print("Token: %s" % token.get())

# Generated at 2022-06-20 14:53:58.382420
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='access_token_string', auth_url='https://sso.redhat.com/auth/realms/myrealm/protocol/openid-connect/token')
    token.get()
    headers = token.headers()

# Generated at 2022-06-20 14:54:03.164815
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # test for GalaxyToken
    # Explicitly setting the key/value fields
    gt = GalaxyToken()
    assert gt.b_file == C.GALAXY_TOKEN_PATH
    assert gt._token is None
    assert gt._config is None


# Generated at 2022-06-20 14:54:04.806198
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth = KeycloakToken(access_token='test token')
    assert auth.headers()['Authorization'] == 'Bearer test token'

# Generated at 2022-06-20 14:54:12.123233
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken('foo').get() == BasicAuthToken('foo', '').get()
    assert BasicAuthToken('foo', 'bar').get() == BasicAuthToken('foo', 'bar').get()
    assert BasicAuthToken('foo', 'bar').get() != BasicAuthToken('foo', 'baz').get()
    assert BasicAuthToken('foo', 'bar').get() != BasicAuthToken('foobar', 'bar').get()



# Generated at 2022-06-20 14:54:21.162859
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # testing KeycloakToken()
    # test case: no access_token, auth_url, and validate_certs
    token = KeycloakToken()
    try:
        assert(not token.get())
    except Exception as e:
        print('Error: %s' % e.message)
    headers = token.headers()
    assert(len(headers) == 0)

    # testing KeycloakToken('ACCESS_TOKEN', 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', True)
    token = KeycloakToken('ACCESS_TOKEN',
                          'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          True)
    token_str = token

# Generated at 2022-06-20 14:55:09.007681
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from requests.exceptions import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    access_token = 'foobar'
    auth_url = 'http://cloud.redhat.com/api/token'
    kt = KeycloakToken(access_token=access_token, auth_url=auth_url)
    assert kt.get() == 'mock_token'
    kt = KeycloakToken(access_token='bad_token', auth_url=auth_url)
    assert kt.get() is None
    kt = KeycloakToken(access_token='401_error', auth_url=auth_url)
    assert kt.get() is None

# Generated at 2022-06-20 14:55:13.912347
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='dummy-token', auth_url='https://dev-sso-prod.cloud.redhat.com/auth/realms/cloud-services/protocol/openid-connect/token')
    kct.get()
    assert kct._token == 'dummy-token'



# Generated at 2022-06-20 14:55:20.140276
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token_file = '/etc/ansible/galaxy_token'
    galaxy_token = GalaxyToken(token=None)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.set('123456789')
    assert galaxy_token.get() == '123456789'
    os.remove(token_file)

# Generated at 2022-06-20 14:55:26.542418
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken(access_token="1111", auth_url="http://example.com/sso")
    assert keycloak_token.access_token == "1111"
    assert keycloak_token.auth_url == "http://example.com/sso"
    keycloak_token = KeycloakToken(access_token="1111", auth_url="http://example.com/sso", validate_certs=False)
    assert keycloak_token.validate_certs == False

# Generated at 2022-06-20 14:55:28.089117
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    a = GalaxyToken()
    assert isinstance(a, GalaxyToken)



# Generated at 2022-06-20 14:55:33.653141
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Success
    assert KeycloakToken('2.0/kubectl').headers() == {'Authorization': 'Bearer 2.0/kubectl'}
    # Failure
    assert KeycloakToken('2.0/kubectl').headers() != {'Authorization': 'Bearer 2.1/kubectl'}


# Generated at 2022-06-20 14:55:42.293487
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    from ansible.module_utils.six import PY2

    from ansible.galaxy import token

    token_file = tempfile.mktemp()
    galaxy_token = token.GalaxyToken()
    galaxy_token.b_file = to_bytes(token_file)

    galaxy_token.set('to1ken')
    galaxy_token.save()

    if PY2:
        with open(to_bytes(token_file), 'r') as f:
            yaml_file = yaml_load(f)

    with open(token_file, 'r') as f:
        yaml_file = yaml_load(f)

    if PY2:
        assert 'to1ken' == yaml_file.get('token')

# Generated at 2022-06-20 14:55:53.096887
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'test_token'
    auth_url = 'http://some.url'
    validate_certs = False
    client_id = 'test_client'
    response = '{"access_token":"new_token","token_type":"Bearer","refresh_token":"refresh_token","expires_in":1200,"scope":"role_list","id_token":"id_token"}'
    # OpenUrlMock has a side-effect, so it is safe to declare it in a local variable
    OpenUrlMock = OpenUrlMock(response)

# Generated at 2022-06-20 14:56:04.909082
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_auth_url = 'http://localhost:8000/auth/realms/test-realm/protocol/openid-connect/token'
    test_access_token = 'test-access-token'
    test_client_id = 'test-client-id'
    test_token = 'test-token'

    token = KeycloakToken(access_token=test_access_token, auth_url=test_auth_url, client_id=test_client_id)

    import httpretty
    from ansible.module_utils.urls import open_url

    def request_callback(request, uri, response_headers):
        return 200, response_headers, test_token


# Generated at 2022-06-20 14:56:11.259324
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken('user1', 'pass1').get() == 'dXNlcjE6cGFzczE='
    assert BasicAuthToken('user2', '').get() == 'dXNlcjI6'
    assert BasicAuthToken('user3').get() == 'dXNlcjM6'
