

# Generated at 2022-06-20 14:46:55.072917
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    # Setup galaxy token class
    token_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible-galaxy-token-test')
    os.environ['ANSIBLE_GALAXY_TOKEN_PATH'] = token_path
    token_loader = GalaxyToken()

    # Setup expected values given test1.yaml
    auth_url = 'https://keycloak.example.com/auth/realms/ansible/protocol/openid-connect/token'

# Generated at 2022-06-20 14:46:56.641201
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken()
    token.set('sometoken')
    assert token.get() == 'sometoken'

# Generated at 2022-06-20 14:47:07.055877
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = None
    token_b = b'4L4RY'
    token_s = u'4L4RY'  # unicode

    gt = GalaxyToken(token)
    assert not gt
    assert token == gt.get()
    assert {} == gt.config

    gt = GalaxyToken(token_b)
    assert not gt
    assert token_s == gt.get()
    assert {'token': token_s} == gt.config

    gt = GalaxyToken(token_s)
    assert not gt
    assert token_s == gt.get()
    assert token_s == gt.get()



# Generated at 2022-06-20 14:47:10.431591
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    headers = GalaxyToken().headers()
    assert 'Authorization' not in headers
    headers = GalaxyToken('abc123').headers()
    assert headers['Authorization'] == 'Token abc123'


# Generated at 2022-06-20 14:47:22.324175
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token_file_path = '/tmp/token'
    token = 'test_token'
    gt = GalaxyToken(token=None)
    gt.b_file = to_bytes(token_file_path, errors='surrogate_or_strict')
    gt.set(token)
    assert gt.get() == token

if __name__ == '__main__':
    test_GalaxyToken_set()
    print('test_GalaxyToken_set passed')

# Generated at 2022-06-20 14:47:30.760455
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Token file not found, create and chmod u+rw
    open('tokenfile.yaml', 'w').close()
    os.chmod('tokenfile.yaml', S_IRUSR | S_IWUSR)  # owner has +rw
    token_example = {'token': 'thisisatesttoken'}
    token = GalaxyToken()
    token.set(token_example['token'])
    token.save()
    with open('tokenfile.yaml', 'r') as f:
        content = yaml_load(f)
    assert token_example == content

    # Token file exists, open and chmod u+rw
    token_example = {'token': 'thisisatesttoken', 'token2': 'thisisanothertesttoken'}
    token = GalaxyToken()

# Generated at 2022-06-20 14:47:35.957860
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='mytocken', auth_url='http://localhost', client_id='myid')
    token.get()
    headers = token.headers()
    except_headers = {'Authorization': 'Bearer %s' % token.get()}
    assert headers == except_headers

# Generated at 2022-06-20 14:47:38.055024
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():

    nt = NoTokenSentinel()
    assert type(nt) is NoTokenSentinel


# Generated at 2022-06-20 14:47:40.464716
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='foo')
    headers = token.headers()
    assert headers['Authorization'] == 'Token foo'


# Generated at 2022-06-20 14:47:44.753433
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'toto'
    password = 'tata'
    token = BasicAuthToken(username, password).get()
    expected_token = 'dG90bzp0YXRh'
    assert token == expected_token, 'token %s is not equal to %s' % (token, expected_token)

# Generated at 2022-06-20 14:47:58.022370
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager()

    token_path = str(config_manager.get_setting_value('GALAXY_TOKEN_PATH'))

    # clean up any existing config file
    if os.path.isfile(token_path):
        os.remove(token_path)

    # test writing to token file
    token = GalaxyToken()
    token.set('abcdefg')

    with open(token_path, 'r') as f:
        written_token = yaml_load(f)

    assert written_token == {'token': 'abcdefg'}, 'expect the token to be written to the token file'

    # test that the token is read from config file when it exists
    token = GalaxyToken()

# Generated at 2022-06-20 14:48:03.942943
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_path = ".test_galaxy_token"
    token_val = "test_token_val"
    token = GalaxyToken(token_val)
    token.save()
    try:
        fp = open(token_path, "r")
        content = fp.read()
        fp.close()
        assert token_val in content
    except IOError as e:
        assert False, "Failed to read token file: %s" % e
    finally:
        # Clean up temp token file
        os.remove(token_path)

# Generated at 2022-06-20 14:48:07.855874
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    if isinstance(nts, NoTokenSentinel):
        assert True
    else:
        assert False

    if repr(nts) == '<ansible.galaxy.token.NoTokenSentinel object at (unknown address)>':
        assert True
    else:
        assert False

# Generated at 2022-06-20 14:48:08.562156
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass



# Generated at 2022-06-20 14:48:10.159817
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert isinstance(NoTokenSentinel(123), NoTokenSentinel)

# Generated at 2022-06-20 14:48:14.224580
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    if not isinstance(gt, GalaxyToken):
        raise AssertionError("Not an instance of class GalaxyToken")


# Generated at 2022-06-20 14:48:27.307660
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import sys
    import yaml

    if sys.version_info[0] == 2:
        import __builtin__ as builtins  # pylint: disable=redefined-builtin
    else:
        import builtins

    from ansible.utils.display import Display

    old_open_func = builtins.open

    def open_mock_side_effect(*args, **kwargs):
        if args[0] == 'ansible.cfg':
            return old_open_func('./test_galaxy_token_ansible.cfg', 'r')
        if args[0] == C.GALAXY_TOKEN_PATH:
            return old_open_func('./test_galaxy_token', 'r')

# Generated at 2022-06-20 14:48:33.528069
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    config = galaxy_token.config
    token = galaxy_token.get()
    if token:
        assert(isinstance(token, str))
        assert(config.get('token') == token)
    else:
        assert(config.get('token') is None)

# Generated at 2022-06-20 14:48:37.685240
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token = 'abc123'
    expected_headers = {'Authorization': 'Bearer abc123'}
    headers = KeycloakToken(access_token=test_token).headers()
    assert headers == expected_headers

# Generated at 2022-06-20 14:48:46.245982
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token="example-keycloak-token", auth_url="https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token")
    assert token.access_token == "example-keycloak-token"
    assert token.auth_url == "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"


# Generated at 2022-06-20 14:48:54.475894
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('abcdefghijklmnopqrstuvwxyz', 'https://my.auth.url.com')
    assert token

# Generated at 2022-06-20 14:49:04.797323
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Test setup
    token_file = '.test_galaxy_token'
    configuration = {'token': 'test_token'}
    expected_token = {'token': 'test_token'}

    # Test body
    token = GalaxyToken(token=None)
    token.b_file = token_file
    token._config = configuration
    token.save()

    # Test end
    assert os.path.isfile(token_file)
    with open(token_file, 'r') as f:
        result = yaml_load(f)
        assert result['token'] == expected_token['token']

    os.remove(token_file)


# Test for method get of class GalaxyToken

# Generated at 2022-06-20 14:49:06.159847
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bat = BasicAuthToken('username', '123')
    assert bat.get() == 'dXNlcm5hbWU6MTIz'



# Generated at 2022-06-20 14:49:09.250206
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    a = NoTokenSentinel()
    b = NoTokenSentinel()
    assert a == b

# Generated at 2022-06-20 14:49:11.933515
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    print('Test hitting token')
    token = GalaxyToken(token="12345")
    token.set("6789")
    return token.get()

# Generated at 2022-06-20 14:49:22.416694
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file_path = "/tmp/galaxy_token"
    token_test = "ThisIsATestToken"

    if os.path.isfile(token_file_path):
        os.remove(token_file_path)

    galaxy_token = GalaxyToken()
    galaxy_token.set(token_test)

    with open(token_file_path, 'r') as f:
        assert token_test in f.read()

    assert galaxy_token.get() == token_test

    os.remove(token_file_path)


if __name__ == '__main__':
    test_GalaxyToken_save()

# Generated at 2022-06-20 14:49:23.051837
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass

# Generated at 2022-06-20 14:49:29.147301
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken("beth", "x")
    assert token.get() == "YmV0aDp4"

# Generated at 2022-06-20 14:49:32.339075
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)
    assert repr(sentinel) == '<NoTokenSentinel>'

# Generated at 2022-06-20 14:49:38.193416
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    config1 = {'token': '123'}
    expected1 = config1['token']

    config2 = {}
    expected2 = None

    def run(config, expected):
        token = GalaxyToken()
        token._config = config
        result = token.get()
        assert result == expected

    run(config1, expected1)
    run(config2, expected2)



# Generated at 2022-06-20 14:49:51.426694
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    assert isinstance(token.headers(), dict)
    assert 'Authorization' in token.headers()



# Generated at 2022-06-20 14:49:53.828888
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    galaxy_token = GalaxyToken()
    assert galaxy_token.config is not None
    assert isinstance(galaxy_token.config, dict)

# Generated at 2022-06-20 14:49:55.252358
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)



# Generated at 2022-06-20 14:49:58.554314
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token = KeycloakToken('test-access-token')
    assert test_token.headers() == {'Authorization': 'Bearer ' + test_token.get()}


# Generated at 2022-06-20 14:50:06.124965
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    class Display:
        def __init__(self):
            self.vvv_count = 0

        def vvv(self, msg):
            self.vvv_count += 1
            print("%d - %s" % (self.vvv_count, msg))

    display = Display()
    # Create a GalaxyToken object
    my_token = GalaxyToken()
    # Set the value for the token
    my_token.set("123")
    # Create a new GalaxyToken object with the value of the previous
    new_token = GalaxyToken(my_token.get())
    # Verify that we got the expected value
    assert new_token.get() == "123"


# Generated at 2022-06-20 14:50:07.609623
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass


# Generated at 2022-06-20 14:50:12.495323
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    from ansible.galaxy.token import KeycloakToken
    keycloak_token = KeycloakToken()
    headers = keycloak_token.headers()
    assert ('Authorization' in headers)
    assert (headers['Authorization'] == 'Bearer None')


# Generated at 2022-06-20 14:50:15.059032
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    t = BasicAuthToken('my_username', 'my_password')
    assert t.headers() == {'Authorization': 'Basic bXlfdXNlcm5hbWU6bXlfcGFzc3dvcmQ='}


# Generated at 2022-06-20 14:50:22.751385
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_path = os.path.join(os.path.expanduser("~"), '.ansible', 'galaxy.token')
    if not os.path.isfile(token_path):
        with open(token_path, 'w') as f:
            f.write('')
    t = GalaxyToken('test')
    t.save()
    with open(token_path, 'r') as f:
        assert f.read() == 'token: test\n'
    os.remove(token_path)

# Generated at 2022-06-20 14:50:26.534651
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken()
    gt.get()
    assert isinstance(gt.config, dict)


# Generated at 2022-06-20 14:50:43.558797
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    import unittest
    token = '<OFFLINE_TOKEN_FROM_SSO>'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    kt = KeycloakToken(token, auth_url)
    assert kt.validate_certs is True
    assert kt.client_id == 'cloud-services'

# Generated at 2022-06-20 14:50:49.375158
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    test_keycloak_token = KeycloakToken('Hello')
    assert test_keycloak_token.token_type == 'Bearer'
    assert test_keycloak_token.access_token == 'Hello'
    assert test_keycloak_token.validate_certs is True
    assert test_keycloak_token.client_id == 'cloud-services'

# Generated at 2022-06-20 14:50:57.887049
# Unit test for method get of class GalaxyToken

# Generated at 2022-06-20 14:51:09.813732
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():

    # Create a temporary file to test with
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    open(b_file, 'w').close()
    os.chmod(b_file, S_IRUSR | S_IWUSR)  # owner has +rw

    # Create token object
    token = GalaxyToken(token=None)

    # Set the file to contain a token
    token.set('foobar')

    # Validate that the file contains a validly formatted token
    with open(b_file, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == 'foobar'


# Generated at 2022-06-20 14:51:12.989809
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set(NoTokenSentinel)
    assert token.config['token'] is None, 'Failed to set ansible.cfg token to None.'

# Generated at 2022-06-20 14:51:20.870898
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    auth = BasicAuthToken('test', 'test')
    assert auth.username == 'test'
    assert auth.password == 'test'
    assert auth._token is None
    assert auth.token_type == 'Basic'


# Generated at 2022-06-20 14:51:26.376306
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    test_username = 'username'
    test_password = 'password'
    test_token = 'dXNlcm5hbWU6cGFzc3dvcmQ='
    token = BasicAuthToken(test_username, test_password)
    assert token.get() == test_token

# Generated at 2022-06-20 14:51:27.184279
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel


# Generated at 2022-06-20 14:51:40.099547
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    from ansible.galaxy.token import KeycloakToken

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.kct = KeycloakToken()

        def test_get(self):
            self.kct.auth_url = 'https:\//www.ansible.com'
            self.kct.access_token = '12345678mn'
            self.kct._form_payload = lambda: 'grant_type=refresh_token&client_id=cloud-services&refresh_token=12345678mn'
            self.kct._token = 'xyz'

            result = self.kct.get()
            self.assertEqual(result, self.kct._token)


# Generated at 2022-06-20 14:51:49.739321
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    filename = tempfile.mktemp(dir=".")
    # Create an empty file
    open(filename, 'w').close()

    gt = GalaxyToken()
    gt._config = {'token': 'fake_token'}
    gt.b_file = filename.encode('utf-8')
    gt.save()

    with open(filename, mode='r') as f:
        assert yaml_load(f).get('token') == 'fake_token'

    os.remove(filename)

# Generated at 2022-06-20 14:52:23.145803
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # TODO: add a test galaxy token file and test _read method
    # need to mock open() and get yaml_dump to use it instead of a file
    t = GalaxyToken()
    assert isinstance(t.config, dict)
    t = GalaxyToken(token=NoTokenSentinel)
    assert isinstance(t.config, dict)
    t = GalaxyToken(token='test')
    assert isinstance(t.config, dict)

# Generated at 2022-06-20 14:52:25.915570
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    expected_output = {'Authorization': 'Token null'}
    x = GalaxyToken(token='null')
    assert expected_output == x.headers()


# Generated at 2022-06-20 14:52:31.436920
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='fake_access_token', auth_url='fake_auth_url', validate_certs=True, client_id='fake_client')
    assert token.access_token == 'fake_access_token'
    assert token.auth_url == 'fake_auth_url'
    assert token.validate_certs == True
    assert token.client_id == 'fake_client'

# Generated at 2022-06-20 14:52:33.891926
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('admin', 'password')
    assert token._token == 'YWRtaW46cGFzc3dvcmQ=', 'BasicAuthToken constructed improperly.'
    return token



# Generated at 2022-06-20 14:52:41.278039
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='h8zgHwjd', auth_url='http://keycloak.acme.inc', client_id='galaxy-cli')
    assert token.access_token == 'h8zgHwjd'
    assert token.auth_url == 'http://keycloak.acme.inc'
    assert token.client_id == 'galaxy-cli'


# Generated at 2022-06-20 14:52:43.157493
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    test_instance = NoTokenSentinel()
    assert isinstance(test_instance, NoTokenSentinel)
    return True

# Generated at 2022-06-20 14:52:45.187890
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='abc')
    assert token.access_token == 'abc'



# Generated at 2022-06-20 14:52:48.606116
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    t = GalaxyToken()
    c = t.config
    t1 = t.get()
    t2 = c.get('token', None)
    assert(t1==t2)


# Generated at 2022-06-20 14:52:53.267579
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    galaxy_token.set('test_token')
    ret1 = galaxy_token.get()
    galaxy_token.set(NoTokenSentinel)
    ret2 = galaxy_token.get()
    assert ret1 == 'test_token'
    assert ret2 is None

# Generated at 2022-06-20 14:53:05.506511
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.parsing.vault import VaultLib
    from ansible.cli.vault import VaultEditor
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError


# Generated at 2022-06-20 14:53:52.758754
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxytoken = GalaxyToken()
    display.vvv('test_GalaxyToken_get %s' % galaxytoken.get())
    assert(galaxytoken.get() == "")


# Generated at 2022-06-20 14:53:56.920363
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('sometoken', 'http://authsomeurl')
    headers = token.headers()
    assert 'Authorization' in headers
    s = headers['Authorization']
    assert 'Bearer' in s
    assert 'sometoken' in s

# Generated at 2022-06-20 14:53:57.944437
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_content = 'abcde1234'
    token = GalaxyToken(token_content)
    assert token.get() == token_content


# Generated at 2022-06-20 14:54:02.204999
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    TEST_TOKEN = {'token': 'abc:abc'}

    d = tempfile.mkdtemp()
    b_d = to_bytes(d, errors='surrogate_or_strict')
    file = os.path.join(b_d, b'galaxy.token')

    test_object = GalaxyToken()
    test_object.b_file = file

    test_object._token = TEST_TOKEN['token']
    test_object.save()

    with open(file, 'r') as f:
        config = yaml_load(f)

    shutil.rmtree(d)
    assert TEST_TOKEN == config



# Generated at 2022-06-20 14:54:03.798455
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken()
    assert token.get() == None

# Generated at 2022-06-20 14:54:09.001691
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bt = BasicAuthToken('username', 'password')
    assert bt.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:54:12.073340
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_token = GalaxyToken('testtoken')
    headers = test_token.headers()
    assert isinstance(headers, dict)
    assert headers['Authorization'] == 'Token testtoken'



# Generated at 2022-06-20 14:54:15.443925
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('user', 'pass')
    headers = token.headers()
    assert headers == {'Authorization': 'Basic dXNlcjpwYXNz'}


# Generated at 2022-06-20 14:54:16.302597
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():

    assert NoTokenSentinel()


# Generated at 2022-06-20 14:54:24.327970
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    class FakeGalaxyToken(GalaxyToken):

        def __init__(self):
            super(FakeGalaxyToken, self).__init__()
            self._config = {}

    # Test the function _read
    token = FakeGalaxyToken()
    assert token._read() == {}

    token.set('abcdef')
    # Test the variable _token
    assert token._token == 'abcdef'
    # Test the saved token
    assert token.config == {'token': 'abcdef'}



# Generated at 2022-06-20 14:55:57.598815
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    expected = 'test'
    g_t = GalaxyToken(expected)
    assert g_t.get() == expected

# Generated at 2022-06-20 14:56:02.037821
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    tok = BasicAuthToken('james', 'bond')
    assert tok.username == 'james' and tok.password == 'bond'
    assert tok.get() == 'amFtZXM6Ym9uZA=='

# Generated at 2022-06-20 14:56:13.722276
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ansible_cfg = "[galaxy_server]\nurl = https://galaxy.ansible.com"

# Generated at 2022-06-20 14:56:16.467272
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = "user"
    password = "password"
    token = BasicAuthToken(username, password)
    assert token.username == "user"
    assert token.password == "password"

# Generated at 2022-06-20 14:56:18.407055
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    for i in range(0,10):
        NoTokenSentinel()

# Generated at 2022-06-20 14:56:24.243062
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'user'
    password = 'password'
    bt = BasicAuthToken(username, password)
    token = bt.get()
    # The token must be equals to user:password encoded in base64
    assert token == 'dXNlcjpwYXNzd29yZA==', 'Basic Auth Token is not equal to user:password encoded in base64'


# Generated at 2022-06-20 14:56:30.405659
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken.get(BasicAuthToken('test','password'))
    assert token == 'dGVzdDpwYXNzd29yZA=='
    token = BasicAuthToken.get(BasicAuthToken('username',None))
    assert token == 'dXNlcm5hbWU6'
    token = BasicAuthToken.get(BasicAuthToken('username'))
    assert token == 'dXNlcm5hbWU6'
    token = BasicAuthToken.get(BasicAuthToken(None,'password'))
    assert token == 'OnBhc3N3b3Jk'

# Generated at 2022-06-20 14:56:39.647611
# Unit test for constructor of class KeycloakToken