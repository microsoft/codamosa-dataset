

# Generated at 2022-06-20 14:46:46.081145
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    k = KeycloakToken(access_token='xxxx')
    assert k.access_token == 'xxxx'


# Generated at 2022-06-20 14:46:49.439483
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():

    basic = BasicAuthToken('test-username', 'test-password')
    assert basic.get() == 'Basic dGVzdC11c2VybmFtZTp0ZXN0LXBhc3N3b3Jk'

# Generated at 2022-06-20 14:46:52.082997
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('abcde')
    assert token.access_token == 'abcde'
    assert token.client_id == 'cloud-services'
    assert token.validate_certs == True


# Generated at 2022-06-20 14:46:53.253865
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel


# Generated at 2022-06-20 14:46:54.128865
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    return token.headers()


# Generated at 2022-06-20 14:47:00.508940
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    assert BasicAuthToken('user', 'pass')


if __name__ == '__main__':
    test_BasicAuthToken()

# Generated at 2022-06-20 14:47:06.390983
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    obj = BasicAuthToken('username', 'password')
    assert obj.username == 'username'
    assert obj.password == 'password'
    assert obj.token_type == 'Basic'
    assert obj.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    assert obj._token == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:47:09.873593
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    mc = BasicAuthToken('testuser', 'testpassword')
    assert mc.get() == 'Basic dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'


# Generated at 2022-06-20 14:47:16.335522
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken(auth_url='https://auth.url', access_token='offline token')

    assert keycloak_token.client_id == 'cloud-services'
    assert keycloak_token.auth_url == 'https://auth.url'
    assert keycloak_token.access_token == 'offline token'
    assert keycloak_token.validate_certs
    assert not keycloak_token._token


# Generated at 2022-06-20 14:47:18.333587
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is NoTokenSentinel()


# Generated at 2022-06-20 14:47:25.793096
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set("abc123def456")
    assert token.get() == "abc123def456"



# Generated at 2022-06-20 14:47:27.447835
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel()



# Generated at 2022-06-20 14:47:34.527326
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url="http://www.google.com"
    access_token="123123123123123123123123123123123"
    kctoken = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id="client-id")
    assert kctoken.auth_url == auth_url
    assert kctoken.client_id == "client-id"


# Generated at 2022-06-20 14:47:38.852664
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken(access_token='fake_token', auth_url='https://example.com/token_url')
    assert kct.access_token == 'fake_token'
    assert kct.auth_url == 'https://example.com/token_url'

# Generated at 2022-06-20 14:47:40.969815
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    _sentinel = NoTokenSentinel()
    assert isinstance(_sentinel, NoTokenSentinel)


# Generated at 2022-06-20 14:47:42.702608
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    t = KeycloakToken("access_token")
    headers = t.headers()
    assert headers['Authorization'] == 'Bearer access_token'

# Generated at 2022-06-20 14:47:43.574665
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoTokenSentinel()
    pass

# Generated at 2022-06-20 14:47:46.153959
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('uname', 'pwd')
    headers = token.headers()
    assert headers['Authorization'].startswith('Basic ')


# Generated at 2022-06-20 14:47:48.524034
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('username', 'password').get()
    assert token == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-20 14:47:56.021190
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token="refresh-token", auth_url="https://auth.url")
    token.get()
    assert token.headers() == {'Authorization': 'Bearer %s' % token._token}


# Generated at 2022-06-20 14:48:05.641309
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://example.com/auth-endpoint'
    access_token = 'not a real access token'

    test_case = KeycloakToken(auth_url=auth_url, access_token=access_token)

    assert test_case.auth_url == auth_url
    assert test_case.access_token == access_token
    assert test_case.validate_certs == True
    assert test_case.client_id == 'cloud-services'



# Generated at 2022-06-20 14:48:09.054313
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken(username='test')
    assert token.token_type == 'Basic'
    assert token.username == 'test'
    assert token.password is None

    token = BasicAuthToken(username='test', password='test')
    assert token.token_type == 'Basic'
    assert token.username == 'test'
    assert token.password == 'test'

# Generated at 2022-06-20 14:48:11.043096
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken(username='username', password='password')
    got = token.headers()
    expect = {'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='}
    assert got == expect

# Generated at 2022-06-20 14:48:15.932396
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = "1234567890"
    galaxy_token = GalaxyToken(token=token)
    assert galaxy_token.headers() == {'Authorization': 'Token 1234567890'}


# Generated at 2022-06-20 14:48:18.562919
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # test
    k1 = KeycloakToken(access_token='test', auth_url='test')
    k1.get()

# Generated at 2022-06-20 14:48:24.250485
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # empty constructor
    test_token = KeycloakToken()
    assert test_token is not None
    assert test_token.access_token is None
    assert test_token.auth_url is None

    # constructor with access_token
    test_token = KeycloakToken(access_token='secret_token',
                               auth_url='http://sso.redhat.com',
                               validate_certs=False,
                               client_id='cloud-services')
    assert test_token is not None
    assert test_token.access_token == 'secret_token'
    assert test_token.auth_url == 'http://sso.redhat.com'
    assert test_token.validate_certs is False
    assert test_token.client_id == 'cloud-services'



# Generated at 2022-06-20 14:48:40.134966
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests.exceptions
    token = 'my_token'
    auth = 'https://auth.redhat.com/token'

    def mock_open_url(url, data, validate_certs=True, method='POST'):
        if method == 'POST':
            return {'access_token': 'new_token'}
        raise requests.exceptions.RequestException("Error")

    original_open_url = open_url
    open_url = mock_open_url

    keycloak_token = KeycloakToken(access_token=token, auth_url=auth)
    assert keycloak_token.get() == 'new_token'

    # If the url is wrong, it should return the token provided
    keycloak_token = KeycloakToken(access_token=token, auth_url=None)

# Generated at 2022-06-20 14:48:48.038887
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    gt = GalaxyToken()
    token = gt.get()
    test_token = 'test'
    assert token != test_token
    gt.set(test_token)
    token = gt.get()
    assert token == test_token
    gt.set(None)
    token = gt.get()
    assert token == test_token
    gt.set(NoTokenSentinel)
    token = gt.get()
    assert token is None



# Generated at 2022-06-20 14:48:56.190817
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Create a KeycloakToken
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-20 14:49:06.968487
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import httpretty

    @httpretty.activate
    def test_token():
        '''
        KeycloakToken.get():
        - POSTs to 'auth_url'
        - sets 'Authorization' header to 'Bearer <access_token>'

        Returns the access_token returned by the server
        '''
        host = 'http://www.example.com'
        auth_url = '%s/auth/realms/redhat' % host
        client_id = 'cloud-services'
        token = 'asdfasdf'


# Generated at 2022-06-20 14:49:15.194132
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # Test config
    test_config = { 'a': 'b' }
    # Test token
    test_token = 'ABCDEF'

    # Create testable class
    galaxy_token = GalaxyToken(token=test_token)

    # Check saved config
    assert test_token == galaxy_token.get()


# Generated at 2022-06-20 14:49:18.358087
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    key = 'key'
    value = 'value'
    token = GalaxyToken()
    token.config[key] = value
    assert token.get() == value


# Generated at 2022-06-20 14:49:19.394229
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()


# Generated at 2022-06-20 14:49:26.874681
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    i = BasicAuthToken('foo')
    assert i.username == 'foo'
    assert i.password is None
    assert i.get() == b'Zm9vOg=='

    i = BasicAuthToken('foo', 'bar')
    assert i.username == 'foo'
    assert i.password == 'bar'
    assert i.get() == b'Zm9vOmJhcg=='

# Generated at 2022-06-20 14:49:32.637048
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    assert KeycloakToken('QWxhZGRpbjpPcGVuU2VzYW1l').headers() == {'Authorization': 'Bearer QWxhZGRpbjpPcGVuU2VzYW1l'}


# Generated at 2022-06-20 14:49:45.396132
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Test Base64 encoding
    # Test Base64 encoding of empty password
    u = 'username'
    p = ''
    b = BasicAuthToken(username=u, password=p)
    expected_token = 'dXNlcm5hbWU6'
    assert b.get() == expected_token

    # Test Base64 encoding of non-empty password
    u = 'username'
    p = 'password'
    b = BasicAuthToken(username=u, password=p)
    expected_token = 'dXNlcm5hbWU6cGFzc3dvcmQ='
    assert b.get() == expected_token

    # Test Base64 encoding allows non-ascii characters in password
    u = 'username'

# Generated at 2022-06-20 14:49:50.391832
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    bt = BasicAuthToken('foo', 'bar')
    assert(bt.headers() == {'Authorization': 'Basic Zm9vOmJhcg=='})



# Generated at 2022-06-20 14:50:00.185315
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ''' Unit test for method get of class KeycloakToken '''
    import unittest.mock as mock
    from ansible.module_utils.six.moves.urllib.error import HTTPError, URLError
    from ansible.module_utils.urls import ConnectionError, SSLValidationError
    from ansible.module_utils.six import PY3, BytesIO

    class TestKeycloakToken(KeycloakToken):

        def _form_payload(self):
            return 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (self.client_id,
                                                                               self.access_token)

    token = 'eyJhbGciOiJSUzI1N'

# Generated at 2022-06-20 14:50:04.850008
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    t = NoTokenSentinel()
    assert t

# Generated at 2022-06-20 14:50:14.970162
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Test init of class BasicAuthToken with empty password
    test1 = BasicAuthToken('test_user', '')
    assert test1.username == 'test_user'
    assert test1.password == ''
    assert test1._token == 'Base64 encoded token'

    # Test init of class BasicAuthToken with non-empty password
    test2 = BasicAuthToken('test_user', 'test_pass')
    assert test2.username == 'test_user'
    assert test2.password == 'test_pass'
    assert test2._token == 'Base64 encoded token'


# Generated at 2022-06-20 14:50:22.857338
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Create a test file with the content
    my_test_file = 'my_test_file'
    config = {"token": "mytoken"}
    file = open(my_test_file, 'w')
    yaml_dump(config, file, default_flow_style=False)
    file.close()

    # Now read the content of the file
    token = GalaxyToken()
    assert token.config == config
    assert token.get() == "mytoken"

    os.remove(my_test_file)



# Generated at 2022-06-20 14:50:29.832337
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create an object of class KeycloakToken
    kct = KeycloakToken('c5fcf394-a903-464f-831b-fc49caeb8d25')

    try:
        # Call method get of KeycloakToken
        kct.get()
    # If there is any exception
    except Exception:
        return False
    
    return True

# Generated at 2022-06-20 14:50:36.745810
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('user', 'password')
    assert token.get() == 'dXNlcjpwYXNzd29yZA=='
    assert token.headers()['Authorization'] == 'Basic dXNlcjpwYXNzd29yZA=='

    token = BasicAuthToken('admin', None)
    assert token.get() == 'YWRtaW46'
    assert token.headers()['Authorization'] == 'Basic YWRtaW46'

# Generated at 2022-06-20 14:50:39.035403
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)



# Generated at 2022-06-20 14:50:42.587112
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    config = {
        'token': 'foo'
    }
    token._config = config
    token.save()
    token2 = GalaxyToken()
    assert token.b_file == token2.b_file
    assert token2._config == config

# Generated at 2022-06-20 14:50:45.260100
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = "user"
    password = "pass"
    token = BasicAuthToken(username, password)
    assert token.get() == token._encode_token(username, password)

# Generated at 2022-06-20 14:50:48.453030
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('admin', 'abc123')
    token_string = token.get()
    if token_string != 'YWRtaW46YWJjMTIz':
        raise Exception('Test failed')

# Generated at 2022-06-20 14:50:50.696898
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
  token = '{ "token": "xxxx-xxxx-xxxx" }'
  assert (token == '{ "token": "xxxx-xxxx-xxxx" }')

# Generated at 2022-06-20 14:50:58.709544
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'abc'
    auth_url = 'https://url/'
    validate_certs = True
    client_id = 'cloud-services'
    kt = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    # No token is set, get() will get a new one
    resp = open_url.return_value
    resp.read.return_value = '{"access_token": "def", "token_type": "Bearer"}'
    assert kt._token is None
    token = kt.get()
    assert token == 'def'
    assert kt._token == 'def'

    # A token is set, get() will return the existing one

# Generated at 2022-06-20 14:51:00.732339
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() == NoTokenSentinel()



# Generated at 2022-06-20 14:51:14.120296
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:51:18.429101
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    expected_headers = {'Authorization': 'Token dY11YXRsYXgtdG9rZW4='}
    token = GalaxyToken('test_token')
    headers = token.headers()
    assert headers == expected_headers


# Generated at 2022-06-20 14:51:20.331068
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    token = NoTokenSentinel()
    assert isinstance(token, NoTokenSentinel)


# Generated at 2022-06-20 14:51:28.940851
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():

    token = BasicAuthToken('username', 'password')
    assert token.headers()['Authorization'] == "Basic dXNlcm5hbWU6cGFzc3dvcmQ="

    token = BasicAuthToken('username', None)
    assert token.headers()['Authorization'] == "Basic dXNlcm5hbWU6"

    token = BasicAuthToken('username', 1)
    assert token.headers()['Authorization'] == "Basic dXNlcm5hbWU6MQ=="



# Generated at 2022-06-20 14:51:37.419560
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    #Test Case A: When token=None
    token=None
    base = GalaxyToken(None)
    base.set(token)

    #Test Case B: When token!=None
    token='12345'
    base = GalaxyToken(None)
    base.set(token)

    #Test Case C: When token=NoTokenSentinel
    token=NoTokenSentinel
    base = GalaxyToken(None)
    base.set(token)


# Generated at 2022-06-20 14:51:45.031963
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    import sys
    class MockArgs(object):
        def __init__(self):
            self.username = 'foo'
            self.password = 'bar'

    # sys.modules gets modified during the execution of the below code and so gets
    # reset before the test begins. For example, collections.namedtuple starts out
    # as None but takes on the value of the namedtuple class after the first import.
    # If this doesn't get reset, the test will fail because it will try to call the
    # namedtuple class and not be able to.
    backup_sys_modules = dict(sys.modules)


# Generated at 2022-06-20 14:51:50.753036
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token="dummy_refresh_token")

    from unittest.mock import patch, mock_open

    m = mock_open()
    with patch.object(open_url, 'open', m, create=True):
        token.get()

    assert {"Authorization": "Bearer aaa.bbb.ccc"} == token.headers()

# Generated at 2022-06-20 14:52:05.546162
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test with a user supplied password
    username = 'admin'
    password = 'password'
    token = 'Basic YWRtaW46cGFzc3dvcmQ='
    bt = BasicAuthToken(username, password)
    assert token == bt.get()
    assert token == bt.headers().get('Authorization').split()[1]

    # Test without a password
    username = 'admin'
    password = None
    token = 'Basic YWRtaW4='
    bt = BasicAuthToken(username, password)
    assert token == bt.get()
    assert token == bt.headers().get('Authorization').split()[1]

    # Test with a None username
    username = None
    password = 'password'
    bt = BasicAuthToken(username, password)
    assert not bt

# Generated at 2022-06-20 14:52:08.169405
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bat = BasicAuthToken(u'username', u'password')
    assert bat.username == 'username'
    assert bat.password == 'password'


# Generated at 2022-06-20 14:52:18.548447
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=abcdef'
    data = {'access_token': '12345'}
    data_text = to_text(json.dumps(data))

    expected_token_type = 'Bearer'
    expected_token_value = '12345'
    expected_authorization = '%s %s' % (expected_token_type, expected_token_value)

    class FakeRequest(object):
        def __init__(self, resp):
            self.resp = resp

        def read(self):
            return self.resp

    class FakeOpenUrl(object):
        def __init__(self, resp):
            self.urlopen = FakeRequest(resp)


# Generated at 2022-06-20 14:52:22.043974
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    t = NoTokenSentinel()
    assert t

# Generated at 2022-06-20 14:52:24.760239
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'ABC'
    obj = GalaxyToken()
    obj.set(token)
    assert token == obj.get()


# Generated at 2022-06-20 14:52:34.673429
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.system import System
    from ansible.module_utils.facts.system import distribution as distro_module

    class mock_open_url:
        def __init__(self, url, data, validate_certs, method, http_agent):
            self.data = data
            self.method = method
            self.http_agent = http_agent

        def read(self):
            return '{"access_token": "test"}'

    open_url_old = open_url
    open_url = mock_open_url

    distro = Distribution()
    system = System()
    distro.populate()

    # If a distribution is returned then we are not windows

# Generated at 2022-06-20 14:52:42.199754
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_auth_url = 'http://test'
    test_token = '123456'
    token = KeycloakToken(access_token=test_token, auth_url=test_auth_url, validate_certs=True, client_id='test')
    assert token.headers() == {'Authorization': 'Bearer 123456'}
    assert token.get() == '123456'
    assert token.headers() == {'Authorization': 'Bearer 123456'}

# Generated at 2022-06-20 14:52:50.159668
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Default, blank file
    token = GalaxyToken()
    assert token.config == {}
    assert token.get() is None

    # Contents of file, valid token
    b_file = to_bytes("tests/galaxy/test_token_file", errors='surrogate_or_strict')
    token = GalaxyToken(token=b_file)
    assert token.config == {'token': b_file}
    assert token.get() == b_file

    # No file, sentinel
    token = GalaxyToken(token=NoTokenSentinel)
    assert token.config == {'token': None}
    assert token.get() is None

# Generated at 2022-06-20 14:52:54.230979
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    headers = GalaxyToken(token='testing').headers()
    assert headers == {'Authorization': 'Token testing'}



# Generated at 2022-06-20 14:53:03.027264
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kt = KeycloakToken(access_token='1234567', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert kt is not None
    assert kt.access_token == '1234567'
    assert kt.auth_url == 'http://localhost:8080/auth/realms/master/protocol/openid-connect/token'
    assert kt.validate_certs is True
    assert kt.client_id == 'cloud-services'



# Generated at 2022-06-20 14:53:04.934374
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is not None


# Generated at 2022-06-20 14:53:14.789244
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    assert BasicAuthToken('username', 'password').get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    assert BasicAuthToken('username', '').get() == 'dXNlcm5hbWU6'
    assert BasicAuthToken('username', None).get() == 'dXNlcm5hbWU6'
    assert BasicAuthToken('username', b'password').get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    assert BasicAuthToken('username', b'').get() == 'dXNlcm5hbWU6'
    assert BasicAuthToken('username', b'\xC3\x9C').get() == u'dXNlcm5hbWU6w7c='
    assert Basic

# Generated at 2022-06-20 14:53:17.441213
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is NoTokenSentinel()
    assert sentinel is not None


# Generated at 2022-06-20 14:53:23.894857
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    b = BasicAuthToken(username='testusername', password='testpassword')
    h = b.headers()
    assert(h == {'Authorization': 'Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA==\n'})


# Generated at 2022-06-20 14:53:30.214823
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # mock data
    # message will be loaded from a file stored locally
    mock_token = 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJiY3VqdzBX'
    mock_url = 'https://sso-dev.cloud.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    mock_validate_certs = True
    mock_client_id = 'cloud-services'

    t = KeycloakToken(access_token=mock_token,
                      auth_url=mock_url,
                      validate_certs=mock_validate_certs,
                      client_id=mock_client_id)

# Generated at 2022-06-20 14:53:32.939387
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoToken = NoTokenSentinel()
    assert isinstance(NoToken, NoTokenSentinel)

# Generated at 2022-06-20 14:53:39.598829
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = "some-access-token-123"
    auth_url = "https://example.com"
    token = KeycloakToken(access_token, auth_url)
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer %(access_token)s' % {'access_token': access_token}


# Generated at 2022-06-20 14:53:41.310568
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert isinstance(token, GalaxyToken)

# Generated at 2022-06-20 14:53:43.275531
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    expected_token = b'YWRtaW46'
    token_obj = BasicAuthToken('admin', 'admin')
    token = token_obj.get()
    assert expected_token == token



# Generated at 2022-06-20 14:53:46.279754
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    t = GalaxyToken()
    t.set('test_token')
    assert t.get() == 'test_token'
    assert t.headers()['Authorization'] == 'Token test_token'

# Generated at 2022-06-20 14:53:50.418158
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('test_token')
    tokenDict = token.headers()
    assert tokenDict['Authorization'] == 'Token test_token'

# Generated at 2022-06-20 14:53:52.523036
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('foo','bar')
    assert token.get() == 'Zm9vOmJhcg=='


# Generated at 2022-06-20 14:53:55.390482
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    kv = GalaxyToken().headers()
    assert 'Authorization' in kv
    assert kv['Authorization'].startswith('Token ')


# Generated at 2022-06-20 14:54:05.203228
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    REDHAT_SSO_URL = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    token = KeycloakToken(auth_url=REDHAT_SSO_URL)
    assert token.auth_url == REDHAT_SSO_URL
    assert token.validate_certs is True
    assert token.client_id == 'cloud-services'

# Generated at 2022-06-20 14:54:10.197033
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken(access_token='test', auth_url='test.com')
    h = k.headers()
    assert h['Authorization'] == 'Bearer None'

# Generated at 2022-06-20 14:54:12.416397
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken(token=NoTokenSentinel)
    assert token.config == {}, 'GalaxyToken config should not include token'


# Generated at 2022-06-20 14:54:16.642190
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    t = C.GALAXY_TOKEN_PATH
    gt = GalaxyToken(token=t)
    assert gt.token_type == 'Token'
    assert gt.b_file == to_bytes(t, errors='surrogate_or_strict')


# Generated at 2022-06-20 14:54:18.868561
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer access_token'


# Generated at 2022-06-20 14:54:20.417397
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    instance = NoTokenSentinel()
    assert isinstance(instance, NoTokenSentinel)

# Generated at 2022-06-20 14:54:27.140977
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    expected = {'access_token': '12345'}
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=tocken'
    token = KeycloakToken(access_token='tocken', auth_url='auth_url')

    # replace open_url()
    import __builtin__
    def my_open_url(uri, data=None, validate_certs=True, method=None, http_agent=None):
        assert uri == 'auth_url'
        assert data == payload
        assert validate_certs is True
        assert method == 'POST'
        assert http_agent == C.USER_AGENT
        class resp:
            def read(self):
                return json.dumps(expected)
        return resp()


# Generated at 2022-06-20 14:54:30.698649
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(auth_url=None, access_token=None)
    assert token.headers() == {'Authorization': 'Bearer None'}
    token = KeycloakToken(auth_url='http://foo.com', access_token='FOO')
    assert token.headers() == {'Authorization': 'Bearer FOO'}


# Generated at 2022-06-20 14:54:33.799595
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('test', 'test')
    assert to_native(token.headers().get('Authorization')) == 'Basic dGVzdDp0ZXN0'

# Generated at 2022-06-20 14:54:41.047346
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken.token_type + " " + "aToken"
    b_file = to_bytes('/tmp/galaxy_token')
    # token file not found, create and chmod u+rw
    open(b_file, 'w').close()
    os.chmod(b_file, S_IRUSR | S_IWUSR)  # owner has +rw
    # Call set from GalaxyToken class
    gtoken = GalaxyToken(token)
    gtoken.set(token)
    # Read written file and verify the content
    with open(b_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token

    # Delete temp file
    os.remove(b_file)

# Generated at 2022-06-20 14:54:46.300602
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('some_token')
    assert token.headers() == {
        'Authorization': 'Bearer %s' % token.get()
    }

# Generated at 2022-06-20 14:54:53.884602
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    obj = BasicAuthToken(username='test.user', password='test.password')
    assert obj.get() == 'dGVzdC51c2VyOnRlc3QucGFzc3dvcmQ='
    obj = BasicAuthToken(username='test.user', password='')
    assert obj.get() == 'dGVzdC51c2VyOg=='
    obj = BasicAuthToken(username='test.user')
    assert obj.get() == 'dGVzdC51c2VyOg=='

# Generated at 2022-06-20 14:55:04.046448
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.urls import open_url

    test_access_token = 'test_access_token'
    test_auth_url = 'https://url/with/valid/tls/cert'
    test_validate_certs = True
    test_client_id = 'test_client_id'

    # Create a mock https connection to test with
    connection = MockHttpsConnection()
    old_open_url = open_url
    open_url = connection.mocked_open_url

    # Setup expected responses
    payload = 'grant_type=refresh_token&client_id=test_client_id&refresh_token=test_access_token'
    expected_request_data = to_bytes(payload, errors='surrogate_or_strict')
    expected_request_headers

# Generated at 2022-06-20 14:55:07.522593
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'


# Generated at 2022-06-20 14:55:14.997477
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_access_token='abcdefghijk'
    test_url='some_url.com'
    test_validate_certs=True
    valid_client_id=None
    kct=KeycloakToken(access_token=test_access_token,
                      auth_url=test_url,
                      validate_certs=test_validate_certs,
                      client_id=valid_client_id)
    headers=kct.headers()
    assert headers['Authorization'] == 'Bearer %s' % kct.get()

# Generated at 2022-06-20 14:55:21.227951
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():

    # test authenticated user
    token = BasicAuthToken('user_name', 'user_passwd')
    assert token.get() == 'Basic dXNlcl9uYW1lOnVzZXJfcGFzc3dk'

    # test unauthenticated user
    token = BasicAuthToken('user_name')
    assert token.get() == 'Basic dXNlcl9uYW1lOg=='

# Generated at 2022-06-20 14:55:25.194986
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # No token defined
    gal_token = GalaxyToken()
    assert gal_token.headers() == {}

    # Token defined
    gal_token = GalaxyToken(token='test_token')
    assert gal_token.headers() == {'Authorization': 'Token test_token'}

# Generated at 2022-06-20 14:55:33.990571
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # Set galaxy token
    token = 'Zbw1ZszfZsjfZszsZszsZszsZszsZszs'
    gtoken = GalaxyToken(token)
    gtoken.set(token)
    assert gtoken.get() == 'Zbw1ZszfZsjfZszsZszsZszsZszsZszs'

    # Clear the galaxy token
    gtoken.set(None)
    assert gtoken.get() is None

# Generated at 2022-06-20 14:55:36.133751
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    x = NoTokenSentinel()


# Generated at 2022-06-20 14:55:41.170949
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import yaml
    stream = open('config.yaml', 'r')
    data = yaml.safe_load(stream)
    print(data['access_token'])
    kctoken = KeycloakToken(access_token=data['access_token'],
                            auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                            validate_certs=True)
    print(kctoken.get())

# Generated at 2022-06-20 14:55:48.358046
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = 'angrydwarf'
    password = 'foobar'
    test = BasicAuthToken(username, password)
    expected = 'Basic YW5ncnlkd2FyZjo='
    assert test.get() == expected
    assert test.headers()['Authorization'] == expected

# Generated at 2022-06-20 14:55:54.295880
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes('token.yml')
    with open(b_file, 'w') as f:
        yaml_dump(token_config, f, default_flow_style=False)
    with open(b_file, 'r') as f:
        token_config_readed = yaml_load(f)
    assert token_config_readed['token'] == '1234567890'
    if os.path.isfile(b_file):
        os.remove(b_file)

token_config = {'token': '1234567890'}

# Generated at 2022-06-20 14:55:59.471602
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    gt = GalaxyToken()
    test_token = 'test-token'
    gt.set(test_token)
    assert gt.get() == test_token
    assert 'token' in gt.config
    assert gt.config['token'] == test_token

# Generated at 2022-06-20 14:56:08.403916
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    import pytest
    B64_VALUE = 'YW5zaWJsZTpBbnNpYmxl'
    at = BasicAuthToken('ansible', 'Ansible')
    assert at.headers() == {'Authorization': 'Basic YW5zaWJsZTpBbnNpYmxl'}, \
        "basic auth headers not populated"
    at = BasicAuthToken('ansible', None)
    assert at.headers() == {'Authorization': 'Basic YW5zaWJsZTo='}, \
        "basic auth headers not populated"
    at = BasicAuthToken('ansible', '')
    assert at.headers() == {'Authorization': 'Basic YW5zaWJsZTo='}, \
        "basic auth headers not populated"
    # test that a password with non-ASCII chars does not

# Generated at 2022-06-20 14:56:18.097426
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    config_file = 'test_galaxy.token'
    token_file = to_bytes(config_file, errors='surrogate_or_strict')
    if os.path.isfile(token_file):
        display.vvv('Deleting %s' % to_text(token_file))
        os.unlink(token_file)

    token = u'abcdef'
    t = GalaxyToken(token)
    t.save()

    if os.path.isfile(token_file):
        display.vvv('Deleting %s' % to_text(token_file))
        os.unlink(token_file)

    token = u'123456'
    t = GalaxyToken(token)
    t.save()

    assert os.path.isfile(token_file)


# Generated at 2022-06-20 14:56:23.240017
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    expected_token = "bGluZXM6cHV0aWw="
    token = BasicAuthToken("lines", "putil")
    assert token.get() == expected_token, "expected token: %s != %s" % (token.get(), expected_token)


# Generated at 2022-06-20 14:56:25.618355
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken('fake_token')
    token.config = {'token': 'fake_token'}
    assert token.get() == 'fake_token'

# Generated at 2022-06-20 14:56:26.864267
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token_sentinel = NoTokenSentinel()
    assert token_sentinel

# Generated at 2022-06-20 14:56:28.048944
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    obj = NoTokenSentinel()
    assert obj is not None


# Generated at 2022-06-20 14:56:35.287244
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Test getting the token from a file
    GALAXY_TOKEN_PATH = C.GALAXY_TOKEN_PATH
    token = "mytoken"
    with open(GALAXY_TOKEN_PATH, 'w') as f:
        f.write(token)
    galaxy_token = GalaxyToken()
    assert token == galaxy_token.get()

    # Test no token path
    galaxy_token = GalaxyToken(token=NoTokenSentinel)
    assert None == galaxy_token.get()