

# Generated at 2022-06-20 14:46:53.684699
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    class TokenFileMock:
        def __init__(self, file_name):
            self.file_name = file_name
            self.value = None

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def write(self, value):
            self.value = value

    class DisplayMock:
        def __init__(self):
            pass

        def vvv(self, value):
            pass

    display_mock = DisplayMock()
    config = {'token': 'This is my token'}

    metadata = {'username': 'some_username', 'password': 'some_password'}
    token = GalaxyToken(NoTokenSentinel())._read()
    token = token.update(metadata)


# Generated at 2022-06-20 14:47:01.271704
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.set('token')
    galaxy_token.save()
    assert galaxy_token.config['token'] == 'token'


# Generated at 2022-06-20 14:47:10.656993
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():

    token = BasicAuthToken('user', 'password')
    assert token.headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}

    token = BasicAuthToken('user', None)
    assert token.headers() == {'Authorization': 'Basic dXNlcjo='}

    token = BasicAuthToken('user', '')
    assert token.headers() == {'Authorization': 'Basic dXNlcjo='}

    token = BasicAuthToken('user', b'')
    assert token.headers() == {'Authorization': 'Basic dXNlcjo='}

    token = BasicAuthToken('user', b'password')
    assert token.headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}

# Generated at 2022-06-20 14:47:26.295912
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3

    username = 'test'
    password = 'hunter2'
    token = BasicAuthToken(username, password)
    assert token.get() == 'Basic dGVzdDpodW50ZXIy'

    if PY3:
      username = 'test'
      password = b'hunter2'
      token = BasicAuthToken(username, password)
      assert token.get() == 'Basic dGVzdDpodW50ZXIy'

    display.display = lambda x, **kw: x
    display.verbosity = 4

    username = 'test'
    password = b'hunter2'
    display.display = lambda x, **kw: x
    display.verbosity = 2

# Generated at 2022-06-20 14:47:30.004830
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    mytoken = "mytoken"
    token = GalaxyToken(mytoken)
    headers = token.headers()
    assert(headers["Authorization"] == "Token mytoken")
    assert(len(headers) == 1)


# Generated at 2022-06-20 14:47:32.731458
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    c = gt.config
    assert c is not None


# Generated at 2022-06-20 14:47:36.001760
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    auth=BasicAuthToken('chouse')
    token=auth.get()
    assert token == "Y2hvdXNlOg==", 'Failed to generate correct token'



# Generated at 2022-06-20 14:47:45.628622
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token_type = 'Bearer'
    auth_url = 'https://auth.example.com'
    access_token = '012345678901234567890123456789012345678901234567890123456789abcd'
    token = KeycloakToken(access_token=access_token, auth_url=auth_url)
    headers = token.headers()

    # Expect headers to be a dict with key 'Authorization'
    assert isinstance(headers, dict)
    assert 'Authorization' in headers.keys()
    # Expect value of 'Authorization' to be in format 'Bearer <access_token>'
    assert headers['Authorization'] == '{} {}'.format(token_type, token.get())


# Generated at 2022-06-20 14:47:49.547119
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # initialize
    gt = GalaxyToken()
    expect = 'secret'
    gt.set(expect)

    # test if method set is working
    actual = gt.get()
    if actual == expect:
        return True

    # print when failed
    print('GalaxyToken.set is not working')
    return False



# Generated at 2022-06-20 14:47:54.580599
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token=None, auth_url=None, validate_certs=True, client_id="cloud-services")
    token.access_token = "test access token"
    token.auth_url = "test auth_url"
    resp = token.get()
    assert resp is not None

# Generated at 2022-06-20 14:48:00.686153
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() is not None
    assert token.get() == 'test_token'


if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-20 14:48:08.469040
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    class FakeModule:
        def __init__(self):
            self.params = {
                'data': {
                    'tokens': {
                        'id': 'dummy_token',
                        'secret': 'dummy_secret',
                        'expires': 'dummy_expiry',
                    },
                    'token': 'dummy_token'
                },
                'force': False
            }

        def params(self, s):
            return True

    tmpdir = tempfile.mkdtemp()
    token_file = os.path.join(tmpdir, 'galaxy_token')
    test_token = 'dummy_token'
    module = FakeModule()
    token = GalaxyToken(token=test_token)

    # save the token

# Generated at 2022-06-20 14:48:10.107117
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nts = NoTokenSentinel()
    assert isinstance(nts, NoTokenSentinel)

# unit test for method __init__ of class KeycloakToken

# Generated at 2022-06-20 14:48:20.576003
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    client_id = 'client_id'
    auth_url = 'auth_url'
    access_token = 'access_token'
    token = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id)
    # check the instance variables
    assert token.client_id == client_id
    assert token.access_token == access_token
    assert token.auth_url == auth_url
    # call get, no need to check the returned values, just check it can be called
    _ = token.get()


# Generated at 2022-06-20 14:48:24.701861
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('foo', 'bar')
    assert 'Authorization' in token.headers()
    assert token.headers()['Authorization'] == 'Basic Zm9vOmJhcg=='



# Generated at 2022-06-20 14:48:26.192379
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    obj = BasicAuthToken('admin', 'admin')
    obj.get()



# Generated at 2022-06-20 14:48:29.909932
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    original_access_token = "aaabbbcccdddeeefffggghhh"
    original_auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    original_client_id = "cloud-services"

    instance = KeycloakToken(access_token=original_access_token, auth_url=original_auth_url, client_id=original_client_id)

    # test default values
    assert(instance.access_token == original_access_token)
    assert(instance.auth_url == original_auth_url)
    assert(instance.client_id == original_client_id)

# Generated at 2022-06-20 14:48:39.677871
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # Check that existing token is empty
    token = GalaxyToken(token='')
    assert token.get() is None

    # Update token to valid token
    test_token = 'xfyh6bcyxm7d5nnfrvffe7ty'
    token.set(test_token)
    assert token.get() == test_token

    # Second set overwrites the pre-existing token
    test_token = 'w3dv3bdx894st4fg4fw4tdt'
    token.set(test_token)
    assert token.get() == test_token


# Generated at 2022-06-20 14:48:48.338239
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # create an instance of class GalaxyToken
    gt = GalaxyToken()
    # call method set using "test_token". Set token in config
    gt.set("test_token")
    # create an instance of class GalaxyToken
    gt1 = GalaxyToken()
    # get token from config. It should be "test_token"
    token = gt1.get()
    # remove the token file
    os.remove(gt.b_file)
    # assert the token is "test_token"
    assert(token == "test_token")

# Generated at 2022-06-20 14:48:58.847795
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    def _test(token, username, password, error_message=None):
        test_token = BasicAuthToken(username, password)
        assert token == test_token.get(), error_message

    # test with valid data
    _test('dXNlcm5hbWU6cGFzc3dvcmQ=', 'username', 'password', 'BasicAuthToken_get: Incorrect encoding of username:password')
    _test('dXNlcm5hbWU6', 'username', '', 'BasicAuthToken_get: Incorrect encoding of username:')
    _test('dXNlcm5hbWU6', 'username', None, 'BasicAuthToken_get: Incorrect encoding of username:')

# Generated at 2022-06-20 14:49:08.351140
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Note that this function is executed even when not specifying the -t option
    # when running the ansible-galaxy command.
    # The tests must be selected based on the (short) description of the test
    # because the unittest framework is not used.

    # Test NoTokenSentinel.__new__()
    token = NoTokenSentinel()
    assert token

    # Test that the test framework is not included in the pythonpath
    # by adding a test for another module.
    # This can be removed when the tests are fixed.
    import ansible.galaxy.main
    assert ansible.galaxy.main



# Generated at 2022-06-20 14:49:09.941537
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    print(NoTokenSentinel())
    print(NoTokenSentinel)


# Generated at 2022-06-20 14:49:14.456529
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    _token = GalaxyToken(token="test_token")
    assert _token.get() == 'test_token'
    _token._token = None
    _token.config['token'] = 'test_token_config'
    assert _token.get() == 'test_token_config'


# Generated at 2022-06-20 14:49:25.333446
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # test valid values
    token = KeycloakToken("offline_access", "auth.url", True, 'client.id')
    assert token.access_token == "offline_access"
    assert token.auth_url == "auth.url"
    assert token.validate_certs == True
    assert token.client_id == "client.id"
    # test default values
    token = KeycloakToken("offline_access", "auth.url")
    assert token.access_token == "offline_access"
    assert token.auth_url == "auth.url"
    assert token.validate_certs == True
    assert token.client_id == "cloud-services"


# Generated at 2022-06-20 14:49:33.211601
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    result = BasicAuthToken("myusername", 'mypassword').headers()

    # If you supply a password, it should be encoded in the result
    assert BasicAuthToken("myusername", 'mypassword').headers()['Authorization'] == 'Basic bXl1c2VybmFtZTpteXBhc3N3b3Jk'
    # If you supply no password, an empty one should be encoded in the result
    assert BasicAuthToken("myusername").headers()['Authorization'] == 'Basic bXl1c2VybmFtZTo='

# Generated at 2022-06-20 14:49:46.038834
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    """Unit test for constructor of class KeycloakToken."""
    kc_token = KeycloakToken(access_token='access_token',
                             auth_url='the url',
                             validate_certs=True,
                             client_id='client_id')

    # Check for existence of the following members:
    assert hasattr(kc_token, 'access_token')
    assert hasattr(kc_token, 'auth_url')
    assert hasattr(kc_token, 'validate_certs')
    assert hasattr(kc_token, 'client_id')

    # Check members values:
    assert kc_token.access_token == 'access_token'
    assert kc_token.auth_url == 'the url'
    assert kc_token.validate_certs == True
   

# Generated at 2022-06-20 14:49:52.088159
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Test case when keycloak token is available

    # When:
    KeycloakToken_Instance = KeycloakToken(access_token='abcdefg_0123456789', auth_url='http://www.example.com')

    # Then:
    assert KeycloakToken_Instance.headers() == {'Authorization': 'Bearer abcdefg_0123456789'}



# Generated at 2022-06-20 14:49:54.514440
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(auth_url="http://auth_url", access_token="accesstoken")

    token.get()

# Generated at 2022-06-20 14:49:57.181227
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    assert galaxy_token.config is not None

    galaxy_token._read()
    assert galaxy_token.config is not None

# Generated at 2022-06-20 14:50:02.766193
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # Test no token set
    t = GalaxyToken()
    t._config = {}
    assert t.headers().get('Authorization') is None
    t._config['token'] = None
    assert t.headers().get('Authorization') is None
    # Test token set
    t._config['token'] = "foo"
    assert t.headers().get('Authorization') == "Token foo"

# Unit tests for method headers of class BasicAuthToken

# Generated at 2022-06-20 14:50:09.088559
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    test_username = "test_username"
    test_password = "test_password"
    token = BasicAuthToken(test_username, test_password)
    headers = token.headers()
    expected_token = "Basic %s" % BasicAuthToken._encode_token(test_username, test_password)
    assert headers['Authorization'] == expected_token

# Generated at 2022-06-20 14:50:11.446996
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken(token='test')
    assert gt.config['token'] == 'test'


# Generated at 2022-06-20 14:50:23.509364
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():

    # Test with one argument
    kt = KeycloakToken()

    # Test with two arguments
    kt = KeycloakToken(auth_url='http://auth.url/token')
    assert kt.access_token is None
    assert kt.auth_url == 'http://auth.url/token'
    assert kt.validate_certs is True
    assert kt.client_id == 'cloud-services'
    assert kt._token is None
    # Test with three arguments
    kt = KeycloakToken(auth_url='http://auth.url/token', validate_certs=False)
    assert kt.access_token is None
    assert kt.auth_url == 'http://auth.url/token'
    assert kt.validate_certs is False
    assert kt.client_

# Generated at 2022-06-20 14:50:33.725185
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import shutil
    import tempfile
    import pytest
    import yaml

    with tempfile.NamedTemporaryFile('r+') as f:
        f.write('token: Bar')
        f.seek(0)
        token = GalaxyToken()
        token.b_file = f.name
        token_dict = token._read()
        assert dict(token_dict) == {'token': 'Bar'}
        token.set('foo')
        token_dict = yaml.load(open(f.name, 'r'))
        assert dict(token_dict) == {'token': 'foo'}

# Generated at 2022-06-20 14:50:37.669568
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('johndoe', 'secret_password').get()
    # Verify token
    assert token == 'am9obmRvZTpzZWNyZXRfcGFzc3dvcmQ='
    assert isinstance(token, str)



# Generated at 2022-06-20 14:50:40.641170
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken()
    assert token.get() is None
    token.set('testtoken')
    assert token.get() == 'testtoken'


# Generated at 2022-06-20 14:50:44.727126
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    b_token = BasicAuthToken('testuser', 'testpassword')
    headers = b_token.headers()
    assert 'Authorization' in headers
    assert headers['Authorization'] == 'Basic dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'


# Generated at 2022-06-20 14:50:50.368494
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():

    gt = GalaxyToken()
    if os.path.isfile(gt.b_file):
        os.remove(gt.b_file)
    gt.set('123456')
    assert gt.get() == '123456'

if __name__ == '__main__':
    #python -m galaxy.auth - GalxyToken.set
    test_GalaxyToken_set()

# Generated at 2022-06-20 14:50:51.303891
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert(NoTokenSentinel() is NoTokenSentinel())

# Generated at 2022-06-20 14:50:57.022407
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken
    username = 'user1'
    password = 'password'
    token_type = 'Basic'
    actual_value = token._encode_token(username, password)
    expected_value = 'dXNlcjE6cGFzc3dvcmQ='
    assert actual_value == expected_value, \
        "test_BasicAuthToken: expected: %s, actual: %s" % (expected_value, actual_value)

if __name__ == '__main__':
    test_BasicAuthToken()

# Generated at 2022-06-20 14:51:05.008583
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = 'foo'
    galaxy_token = GalaxyToken(token)
    assert token == galaxy_token.get()
    headers = galaxy_token.headers()
    assert headers['Authorization'] == '%s %s' % (galaxy_token.token_type, token)



# Generated at 2022-06-20 14:51:06.234608
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token.config == {}
    assert token._read() == {}
    assert token._config is None


# Generated at 2022-06-20 14:51:11.106414
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    # Test a new galaxy token file
    gtoken = GalaxyToken(token="this is a token")
    gtoken.save()
    assert os.path.isfile(gtoken.b_file) == True
    created_token = open(gtoken.b_file).read()
    assert created_token == "token: this is a token"
    # Test for changing the token file
    gtoken = GalaxyToken(token="this is a new token")
    gtoken.save()
    created_token = open(gtoken.b_file).read()
    assert created_token == "token: this is a new token"
    # Test for changing the token file
    gtoken = GalaxyToken()
    gtoken.save()
    created_token = open(gtoken.b_file).read()
    assert created_token == ""

# Generated at 2022-06-20 14:51:23.007324
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-20 14:51:26.206055
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Initialize
    username = 'admin'
    password = 'redhat_password'
    token = BasicAuthToken(username=username, password=password).get()
    encoded_token = 'YWRtaW46cmVkaGF0X3Bhc3N3b3Jk'
    assert token == encoded_token

# Generated at 2022-06-20 14:51:27.732531
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    obj = GalaxyToken()
    assert(obj)



# Generated at 2022-06-20 14:51:31.841858
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    obj = KeycloakToken(access_token='foo')
    assert isinstance(obj.headers(), dict)
    assert obj.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-20 14:51:35.410273
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}



# Generated at 2022-06-20 14:51:37.294735
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is NoTokenSentinel()

# Generated at 2022-06-20 14:51:38.933022
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoTokenSentinel()


# Generated at 2022-06-20 14:51:55.001793
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('faketoken')
    assert token.headers() == {'Authorization': 'Token faketoken'}

# Generated at 2022-06-20 14:51:57.409187
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    tokenholder = GalaxyToken(token='thisisatoken')
    assert tokenholder.get() == 'thisisatoken'
    assert tokenholder.get() == tokenholder.config['token']

# Generated at 2022-06-20 14:51:59.193779
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    test = NoTokenSentinel()

    assert(test is not None)

# Generated at 2022-06-20 14:52:00.874036
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    s = NoTokenSentinel()
    assert isinstance(s, NoTokenSentinel)

# Generated at 2022-06-20 14:52:10.271135
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # Set up a new blank file for testing
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    open(b_file, 'w').close()
    os.chmod(b_file, S_IRUSR | S_IWUSR)  # owner has +rw

    # Test when token is set to an empty token
    token = GalaxyToken()
    token.set('')

    # Check that the token file is empty
    assert os.stat(b_file).st_size == 0

    # Test when token is set to a valid token
    token = GalaxyToken()
    token.set('test')

    # Check that the token file contains a valid token
    with open(b_file, 'r') as f:
        token = yaml

# Generated at 2022-06-20 14:52:12.217362
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    c = GalaxyToken()
    c.set('1234567890')
    assert c.get() == '1234567890'



# Generated at 2022-06-20 14:52:25.813633
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import json
    import urllib.parse as urlparse
    _token = None
    _token = KeycloakToken(access_token=None,
                           auth_url='http://localhost:8080/auth/realms/{}/protocol/openid-connect/token'.format('master'),
                           validate_certs=True,
                           client_id=None)
    _token.access_token = open('offline.ticket.refresh_token.txt', 'r').read()
    _headers = _token.headers()
    _payload = _token._form_payload()
    _r = requests.post(_token.auth_url, data=_payload, headers=_headers)
    _r.raise_for_status()
    _json = json.loads(_r.text)
   

# Generated at 2022-06-20 14:52:33.415118
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    import pytest
    basic_auth_token = BasicAuthToken(username='test_username', password='test_password')
    if basic_auth_token.get() != "dGVzdF91c2VybmFtZTp0ZXN0X3Bhc3N3b3Jk":
        pytest.fail()
    if basic_auth_token.headers() != {"Authorization": "Basic dGVzdF91c2VybmFtZTp0ZXN0X3Bhc3N3b3Jk"}:
        pytest.fail()


# Generated at 2022-06-20 14:52:37.182936
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken('a_refresh_token', 'an_auth_url', False)
    k.get()
    assert k.headers() == {'Authorization': 'Bearer ' + k._token}

# Generated at 2022-06-20 14:52:45.982438
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # no token in file
    token = GalaxyToken()
    assert token.get() is None
    # token in file, not sanitized
    token = GalaxyToken()
    with open(token.b_file, 'w') as f:
        yaml_dump('foo', f, default_flow_style=False)
    assert token.get() is None
    # token in file, sanitized
    token = GalaxyToken()
    token.set('foo')
    assert token.get() == 'foo'
    os.remove(token.b_file)
    assert token.get() is None


# Generated at 2022-06-20 14:53:08.489577
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    ''' Unit test to verify the headers method of class KeycloakToken '''
    from ansible.errors import AnsibleError
    from ansible.module_utils.six.moves import StringIO
    from ansible.galaxy.token import KeycloakToken

    BACKUP_STDOUT = None
    output = None
    token = KeycloakToken(access_token='abc', auth_url='http://example.com/auth')

    try:
        BACKUP_STDOUT = sys.stdout
        output = StringIO()
        sys.stdout = output
        headers = token.headers()
        assert(headers == {'Authorization': 'Bearer abc'})
    except Exception as err:
        raise AnsibleError("Error: unit test KeycloakToken_headers failed")
    finally:
        sys.stdout = BACKUP_STDOUT


# Generated at 2022-06-20 14:53:18.751966
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_file_path = '/home/foo'
    token_file_content = 'token: fake_token'

    token = GalaxyToken(None)

    # Test when token file is not present
    token._config = None
    token._token = None
    token.b_file = to_bytes(token_file_path, errors='surrogate_or_strict')

    assert token.get() is None

    # Test when token file is present with invalid content
    token._config = None
    token._token = None
    token.b_file = to_bytes(token_file_path, errors='surrogate_or_strict')

    with open(token_file_path, 'w') as f:
        f.write('abc')

    assert token.get() is None

    # Test when token file is present with valid content

# Generated at 2022-06-20 14:53:21.306283
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    assert KeycloakToken('ABLahBLah').headers() == {'Authorization': 'Bearer ABLahBLah'}

# Generated at 2022-06-20 14:53:24.242700
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = '12345'

    galaxy_token = GalaxyToken()
    galaxy_token.set(token)

    config = galaxy_token.config
    assert 'token' in config
    assert config['token'] == token


# Generated at 2022-06-20 14:53:28.529924
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    offline_token = 'some-long-secret-of-some-kind'

    token = KeycloakToken(offline_token, auth_url)

    assert token.auth_url == auth_url
    assert token.access_token == offline_token
    assert token.client_id == 'cloud-services'


# Generated at 2022-06-20 14:53:32.845330
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    ''' Unit test for method get of class GalaxyToken '''
    # Create GalaxyToken with empty token
    gtoken = GalaxyToken()
    # Call get method
    assert gtoken.get() is None
    # Create GalaxyToken with token
    gtoken1 = GalaxyToken("1234")
    # Call get method
    assert gtoken1.get() == "1234"


# Generated at 2022-06-20 14:53:36.436128
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    t = GalaxyToken()
    t.set('foo')
    headers = t.headers()
    assert headers['Authorization'] == 'Token foo'


# Generated at 2022-06-20 14:53:41.174450
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'pass')
    assert token.get() == b'Basic dXNlcjpwYXNz'
    token = BasicAuthToken('user')
    assert token.get() == b'Basic dXNlcjo='


# Generated at 2022-06-20 14:53:43.387781
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    t = GalaxyToken()
    t.set('test_token')
    assert t.get() == 'test_token'

# Generated at 2022-06-20 14:53:47.311881
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    user_token_str = 'abc'
    token = GalaxyToken(user_token_str)
    assert token.get() == user_token_str

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 14:54:24.654251
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken(access_token='secret', auth_url='https://sso.redhat.com/auth', client_id='super-secret')
    assert k.headers() == {'Authorization': 'Bearer secret'}


# Generated at 2022-06-20 14:54:27.853408
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('asdf')
    assert 'Authorization' in token.headers()
    assert 'Bearer' in token.headers().get('Authorization')
    assert token.headers().get('Authorization').startswith('Bearer ')



# Generated at 2022-06-20 14:54:32.030878
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('test', 'test')
    headers = token.headers()
    assert headers == {'Authorization': 'Basic dGVzdDp0ZXN0'}

# Generated at 2022-06-20 14:54:35.955920
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxysession = GalaxyToken()
    if os.path.exists(galaxysession.b_file):
        os.remove(galaxysession.b_file)

    galaxysession.save()
    assert os.path.exists(galaxysession.b_file)

# Generated at 2022-06-20 14:54:38.416063
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # arrange
    token = 'test token'
    token_object = GalaxyToken(token)
    
    # act
    retrieved_token = token_object.get()

    # assert
    assert (token == retrieved_token)

# Generated at 2022-06-20 14:54:43.750605
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url = 'https://test/test'
    # If a token is not given, it will be defined as a
    # sentinel object NoTokenSentinel
    test_keycloak_token = KeycloakToken(None, auth_url)
    expected = {
        'Authorization': 'Bearer None'
    }
    assert test_keycloak_token.headers() == expected

    # If a token is given, it will be used instead of the
    # Sentinel object.
    test_keycloak_token2 = KeycloakToken('some_token', auth_url)
    expected = {
        'Authorization': 'Bearer some_token'
    }
    assert test_keycloak_token2.headers() == expected


# Generated at 2022-06-20 14:54:54.394993
# Unit test for method get of class GalaxyToken

# Generated at 2022-06-20 14:54:59.400306
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    basictok = BasicAuthToken('user', 'password')
    assert(basictok.password == 'password')
    assert(basictok.username == 'user')
    assert(basictok.get() == "dXNlcjpwYXNzd29yZA==")


# Generated at 2022-06-20 14:55:02.298922
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken(username='demouser', password='demopassword')

    assert token.get() == to_text('ZGVtb3VzZXI6ZGVtb3Bhc3N3b3Jk')



# Generated at 2022-06-20 14:55:14.404067
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-20 14:56:00.350515
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # No Token
    token = GalaxyToken()
    headers = token.headers()
    assert not headers

    # Token
    token = GalaxyToken('token')
    headers = token.headers()
    assert headers



# Generated at 2022-06-20 14:56:02.618762
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('mytoken')
    assert token.headers()['Authorization'] == 'Token mytoken'


# Generated at 2022-06-20 14:56:08.136669
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_instance = GalaxyToken(token=None)
    test_instance.config = {'token': '1234'}
    assert test_instance.headers() == {'Authorization': 'Token 1234'}
    test_instance.config = {'token': None}
    assert test_instance.headers() == {}

# Generated at 2022-06-20 14:56:11.392757
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken('test-token')
    result = gt.headers()
    assert result['Authorization'] == 'Token test-token'



# Generated at 2022-06-20 14:56:19.738554
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-20 14:56:28.437401
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    access_token = "ZDJmN2Q3OWMxODI3YzYzMTlhOWE0YTRiNTQ2YTM5ZGY6ZmI1ZDcxMWMtYjYwYy00N2I2LWJhZmItMGMzMjhmZDUxMjEz"
    token = KeycloakToken(access_token=access_token, auth_url=auth_url)
    print(token.get())
    auth_token = token.headers()
    print(auth_token)


# Generated at 2022-06-20 14:56:30.176849
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert isinstance(token, GalaxyToken)



# Generated at 2022-06-20 14:56:35.248514
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Setup
    gt = GalaxyToken()
    original_token = gt.get()
    gt.config['token'] = 'test'

    # Exercise
    result = gt.get()

    # Verify
    assert result == 'test'

    # Cleanup
    gt.config['token'] = original_token
    gt.save()

