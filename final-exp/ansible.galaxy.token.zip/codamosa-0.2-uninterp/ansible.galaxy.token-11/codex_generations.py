

# Generated at 2022-06-16 21:32:57.639348
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:07.579306
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:10.339282
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set(None)
    assert token.get() == None

# Generated at 2022-06-16 21:33:12.091870
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://example.com/auth')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:14.279669
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:27.639335
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'token.yml'), 'w')
    f.write('token: abcdefghijklmnopqrstuvwxyz')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'token.yml'), errors='surrogate_or_strict')

    # Read the file
    with open(token.b_file, 'r') as f:
        config = yaml.load(f)

    # Check that the token is the same as

# Generated at 2022-06-16 21:33:30.101858
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:34.351522
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    token = GalaxyToken()

    # Create a token file
    token.save()

    # Check if the token file is created
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

    # Remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:33:38.169083
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='1234567890')
    assert kt.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:33:48.362891
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:04.501785
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:34:08.504972
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:34:11.277087
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}

# Generated at 2022-06-16 21:34:14.689021
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    assert token.get() is None

# Generated at 2022-06-16 21:34:23.810765
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with no access_token
    token = KeycloakToken()
    assert token.get() is None

    # Test with access_token
    token = KeycloakToken(access_token='test_access_token')
    assert token.get() is None

    # Test with access_token and auth_url
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() is None


# Generated at 2022-06-16 21:34:27.049669
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:36.449909
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import os.path
    import shutil
    import stat
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test_galaxy_token')
    with open(file_path, 'w') as f:
        f.write('')
    # Change the mode of the file
    os.chmod(file_path, stat.S_IRUSR | stat.S_IWUSR)  # owner has +rw

    # Create an instance of GalaxyToken
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = file_path

    # Test save method
    galaxy_token.set('test_token')
    galaxy_

# Generated at 2022-06-16 21:34:39.052524
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:42.574955
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://example.com/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:34:46.871202
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}

# Generated at 2022-06-16 21:35:12.327636
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:35:15.418585
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:35:18.284680
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:21.517213
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:24.450763
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:28.779957
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set(None)
    assert token.get() is None
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:35:40.404882
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:44.784897
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:35:47.448830
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:35:51.911876
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345', auth_url='http://example.com')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:35:57.158048
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='http://test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:36:02.914648
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:05.161981
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:36:08.333637
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:21.169020
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:22.597400
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:36:25.564461
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='http://example.com/auth')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:36:28.523156
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:37.341716
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    token_path = os.path.join(temp_dir, 'token.yml')
    token = GalaxyToken()
    token.b_file = to_bytes(token_path, errors='surrogate_or_strict')
    token.set('test_token')
    assert token.get() == 'test_token'
    shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:36:39.926718
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test')
    token.get = lambda: 'test'
    assert token.headers() == {'Authorization': 'Bearer test'}

# Generated at 2022-06-16 21:36:50.542704
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:36:53.302372
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:36:56.756441
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo', auth_url='https://example.com')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:37:08.752760
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    from ansible.module_utils.urls import open_url

    class FakeResponse(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    def fake_open_url(url, data=None, validate_certs=True, method='GET', http_agent=None):
        return FakeResponse(json.dumps({'access_token': 'fake_token'}))

    old_open_url = open_url
    open_url = fake_open_url
    try:
        token = KeycloakToken(access_token='fake_access_token', auth_url='fake_auth_url')
        assert token.get() == 'fake_token'
    finally:
        open_url = old_open_url


#

# Generated at 2022-06-16 21:37:10.918464
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:37:13.407353
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:37:17.991792
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='my_token', auth_url='http://example.com')
    assert token.get() == 'my_token'


# Generated at 2022-06-16 21:37:21.306731
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:24.124393
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:37:26.810103
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:37:42.939298
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:37:48.662020
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:37:51.763588
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:37:55.288208
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'


# Generated at 2022-06-16 21:37:58.897353
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:38:03.679054
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(path, errors='surrogate_or_strict')

    # Write a token to the temporary file
    token.set('test')

    # Read the token from the temporary file
    with open(token.b_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == 'test'

    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-16 21:38:06.308828
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:38:19.088041
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:30.846659
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.galaxy.token import KeycloakToken

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.keycloak_token = KeycloakToken(access_token='access_token', auth_url='auth_url')

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "access_token"}'
            self.assertEqual(self.keycloak_token.get(), 'access_token')

    unittest.main()

# Generated at 2022-06-16 21:38:37.828730
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import tempfile
    import shutil

    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.request import Request

    from ansible.galaxy.token import GalaxyToken

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a galaxy token file
    galaxy_token_file = os.path.join(tmpdir, 'galaxy_token')
    galaxy_token = GalaxyToken(galaxy_token_file)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    #

# Generated at 2022-06-16 21:39:02.131712
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temp directory
    tmpfile = os.path.join(tmpdir, 'test.yml')
    # Create a token
    token = GalaxyToken(token='test')
    # Set the token file to the temp file
    token.b_file = tmpfile
    # Save the token
    token.save()
    # Check if the token is saved in the temp file
    with open(tmpfile, 'r') as f:
        data = yaml.load(f)
        assert data['token'] == 'test'
    # Remove the temp directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:39:04.181778
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:10.652479
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:39:19.560138
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('test')
    f.close()

    # Create a GalaxyToken object with the temporary file
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'), errors='surrogate_or_strict')

    # Set the token
    token.set('test_token')

    # Read the file
    f = open(os.path.join(tmpdir, 'test.yml'), 'r')
    content = f.read()
    f.close()

   

# Generated at 2022-06-16 21:39:27.901806
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:29.349883
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:37.313200
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import mock
    import sys
    import json
    from ansible.module_utils.urls import open_url

    # Mock the open_url method
    with mock.patch.object(open_url, '__call__', return_value=mock.Mock(read=lambda: json.dumps({'access_token': 'test_token'}))) as mock_open_url:
        # Create a KeycloakToken object
        kt = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
        # Call the get method
        token = kt.get()
        # Check the token
        assert token == 'test_token'
        # Check the open_url method

# Generated at 2022-06-16 21:39:49.621788
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    # Create a GalaxyToken object
    token = GalaxyToken()
    # Set the file path of the GalaxyToken object
    token.b_file = os.path.join(tmpdir, 'test.yml')
    # Set the token of the GalaxyToken object
    token.set('test')
    # Save the token to the file
    token.save()
    # Read the file
    with open(os.path.join(tmpdir, 'test.yml'), 'r') as f:
        # Read the content of the file
        data

# Generated at 2022-06-16 21:39:52.431882
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'test_url', False, 'test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:54.745262
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:40:36.617148
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:40:48.889065
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'testfile'), 'w')
    f.write('test')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'testfile'))

    # Set the token
    token.set('testtoken')

    # Read the token
    with open(token.b_file, 'r') as f:
        config = yaml.load(f)

    # Check the token
    assert config['token'] == 'testtoken'

   

# Generated at 2022-06-16 21:41:00.791878
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:03.304977
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:05.624884
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:08.950262
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:41:11.585907
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token = KeycloakToken(access_token='test_access_token')
    assert keycloak_token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:41:16.680536
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() == None
    token.set(NoTokenSentinel)
    assert token.get() == None

# Generated at 2022-06-16 21:41:22.499899
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test'
    token_file = '/tmp/test_galaxy_token'
    galaxy_token = GalaxyToken(token=token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:41:25.433584
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:42:28.868296
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:42:40.281441
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:42.943297
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:52.832765
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils.six import StringIO
    import tempfile
    import os

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = path

    # Write a token to the temporary file
    token.set('test_token')

    # Read the token from the temporary file
    with open(path, 'r') as f:
        config = yaml_load(f)

    # Check that the token is the same
    assert config['token'] == 'test_token'

    # Remove the temporary file
    os.remove(path)