

# Generated at 2022-06-16 21:33:02.698488
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:33:04.536298
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:33:11.717742
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:16.984657
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:23.041653
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kct.headers() == {'Authorization': 'Bearer 1234567890'}

# Generated at 2022-06-16 21:33:31.093028
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token')

    token = GalaxyToken()
    token.b_file = token_file
    token.set('test_token')

    assert os.path.isfile(token_file)

    with open(token_file) as f:
        assert yaml_load(f) == {'token': 'test_token'}

    shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:33:44.097104
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url


# Generated at 2022-06-16 21:33:51.978349
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    token = GalaxyToken()
    # Set the token
    token.set('test')
    # Save the token
    token.save()
    # Read the token file
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)
    # Check if the token is saved correctly
    assert config['token'] == 'test'

# Generated at 2022-06-16 21:33:54.600413
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:57.183499
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='access_token')
    assert token.headers() == {'Authorization': 'Bearer access_token'}

# Generated at 2022-06-16 21:34:04.160456
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:12.940286
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('token: test')
    f.close()

    # Create an instance of GalaxyToken
    gt = GalaxyToken()
    gt.b_file = os.path.join(tmpdir, 'test.yml')

    # Set a new token
    gt.set('test2')

    # Read the file
    f = open(os.path.join(tmpdir, 'test.yml'), 'r')
    data = yaml.load(f)
    f.close()

    # Check if the token

# Generated at 2022-06-16 21:34:24.095251
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(path, errors='surrogate_or_strict')

    # Set the token
    token.set('test_token')

    # Read the token
    with open(path, 'r') as f:
        config = yaml_load(f)

    # Check the token
    assert config['token'] == 'test_token'

    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-16 21:34:28.285809
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:34:37.177501
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'test_GalaxyToken_save'), errors='surrogate_or_strict')

    # Write a token to the file
    token.set('test_token')

    # Read the token from the file
    with open(token.b_file, 'r') as f:
        config = yaml.load(f)

    # Check that the token

# Generated at 2022-06-16 21:34:39.689983
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:52.581144
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:34:54.353056
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:35:06.706151
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:17.815012
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:27.591269
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:30.349946
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:35:34.172758
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:36.638415
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:47.684393
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:51.802804
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:36:01.564261
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import os.path
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('token: test')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = os.path.join(tmpdir, 'test.yml')
    gt._config = {'token': 'test'}

    # Call save method
    gt.save()

    # Check that the file has been updated
    with open(gt.b_file, 'r') as f:
        config = yaml.load(f)

# Generated at 2022-06-16 21:36:05.649314
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert kt.get() == 'test_token'


# Generated at 2022-06-16 21:36:17.831387
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    from ansible.module_utils.common.yaml import yaml_load
    from ansible.module_utils.common.yaml import yaml_dump
    from ansible.module_utils.galaxy_token import GalaxyToken

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_galaxy_token')

    # Test if file is created
    token = GalaxyToken()
    token.b_file = temp_file
    token.set('test_token')
    assert os.path.isfile(temp_file)

    # Test if file is written correctly
    with open(temp_file, 'r') as f:
        config = yaml_load(f)
    assert config

# Generated at 2022-06-16 21:36:21.592959
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:37.604833
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:36:48.042669
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.kct = KeycloakToken(access_token='test_token',
                                     auth_url='http://test_url',
                                     validate_certs=True,
                                     client_id='test_client')

        @mock.patch.object(open_url, '__call__')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_token"}'
            self.assertEqual(self.kct.get(), 'test_token')

    unittest.main()

# Generated at 2022-06-16 21:36:57.591388
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:00.515067
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:11.893382
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:15.996770
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:37:21.128131
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True, client_id='test_client_id')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:23.918073
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='123456789')
    assert token.headers() == {'Authorization': 'Bearer 123456789'}


# Generated at 2022-06-16 21:37:32.683406
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(path, errors='surrogate_or_strict')

    # Save a token
    token.set('test_token')

    # Read the token file
    with open(token.b_file, 'r') as f:
        config = yaml_load(f)

    # Check the token is saved
    assert config['token'] == 'test_token'

    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-16 21:37:36.014631
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:00.618721
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:38:03.087226
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='12345', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kt.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:38:15.910808
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:18.685135
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:25.572650
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:28.413860
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:36.335936
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:40.249336
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123456789', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    token.get()
    assert token._token == '123456789'

# Generated at 2022-06-16 21:38:42.358268
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:46.108323
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='my_access_token', auth_url='https://my_auth_url')
    assert token.get() == 'my_access_token'


# Generated at 2022-06-16 21:39:47.638948
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:57.546974
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:40:03.664861
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:40:07.647497
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:40:11.793079
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:40:22.367377
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    tmpdir = tempfile.mkdtemp()
    try:
        token_file = os.path.join(tmpdir, 'token')
        token = GalaxyToken(token=None)
        token.b_file = token_file
        token.set('test_token')
        assert os.path.isfile(token_file)
        with open(token_file, 'r') as f:
            data = yaml.load(f)
            assert data['token'] == 'test_token'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:40:24.867507
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:37.098232
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:40:40.149707
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:44.292363
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:42:28.378656
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:39.978044
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123456789', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:42:42.102528
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:42:43.787825
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='foo')
    assert kt.headers() == {'Authorization': 'Bearer foo'}

# Generated at 2022-06-16 21:42:54.782771
# Unit test for method get of class KeycloakToken