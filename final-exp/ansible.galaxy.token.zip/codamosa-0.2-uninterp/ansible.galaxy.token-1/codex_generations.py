

# Generated at 2022-06-16 21:33:00.989004
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    gt = GalaxyToken()
    gt.set('test_token')
    assert gt.get() == 'test_token'
    gt.save()
    assert gt.get() == 'test_token'

# Generated at 2022-06-16 21:33:03.334076
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:33:05.472968
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:08.332187
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test_url', False, 'test_client')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:11.461297
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='access_token', auth_url='auth_url')
    assert token.get() == 'access_token'


# Generated at 2022-06-16 21:33:13.415009
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:26.607188
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:29.520791
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:32.169245
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:34.904281
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:57.846537
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:34:04.349030
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    token_file = os.path.join(tmpdir, 'token')

    try:
        token = GalaxyToken(token_file)
        token.set('test')
        assert token.get() == 'test'

        token.set(None)
        assert token.get() is None
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:34:07.064893
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:34:09.991480
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='my_access_token', auth_url='my_auth_url')
    assert token.headers() == {'Authorization': 'Bearer my_access_token'}


# Generated at 2022-06-16 21:34:13.018664
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:34:26.451223
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:36.227190
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:41.912067
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token2 = GalaxyToken()
    assert token2.get() == 'test_token'
    token.set(None)
    token.save()
    token3 = GalaxyToken()
    assert token3.get() is None

# Generated at 2022-06-16 21:34:44.968262
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:34:48.110161
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:34:59.825149
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:35:03.504360
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:15.423937
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:27.116789
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:29.601682
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:35:41.743455
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:35:43.736539
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:35:46.475847
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:50.599565
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:35:55.382264
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:36:14.459695
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:25.743429
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import builtins

    # Create a config file
    config = configparser.ConfigParser()
    config.add_section('galaxy')
    config.set('galaxy', 'token', 'test')
    config.set('galaxy', 'ignore_certs', 'True')
    config.set('galaxy', 'server', 'https://galaxy.ansible.com')
    config.set('galaxy', 'verify_ssl', 'True')
    config.set('galaxy', 'ignore_certs', 'True')
    config.set('galaxy', 'ignore_certs', 'True')

# Generated at 2022-06-16 21:36:28.646775
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:41.470076
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('foo')
    f.close()

    # Create a GalaxyToken object with the temporary file
    gt = GalaxyToken(token='test')
    gt.b_file = to_bytes(os.path.join(tmpdir, 'test'), errors='surrogate_or_strict')

    # Save the token
    gt.save()

    # Check the content of the file
    f = open(os.path.join(tmpdir, 'test'), 'r')
    assert f.read() == 'token: test\n'

# Generated at 2022-06-16 21:36:44.333664
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:47.052967
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:50.060441
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:58.532603
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = os.path.join(tmpdir, 'test_GalaxyToken_save')
    # Create a token
    token = GalaxyToken(token='test_GalaxyToken_save')
    # Set the token file
    token.b_file = tmpfile
    # Save the token
    token.save()
    # Read the token file
    with open(tmpfile, 'r') as f:
        data = yaml.load(f)
    # Check the token
    assert data['token'] == 'test_GalaxyToken_save'
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:37:03.764569
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:37:06.252077
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:37:28.058782
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    from ansible.module_utils.common.yaml import yaml_load

    token_file = tempfile.NamedTemporaryFile(delete=False)
    token_file.close()
    token_file_path = token_file.name

    token = 'test_token'
    token_obj = GalaxyToken(token=token)
    token_obj.save()

    with open(token_file_path, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == token

    os.remove(token_file_path)

# Generated at 2022-06-16 21:37:31.436663
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    token.get()
    assert token._token == 'test_access_token'

# Generated at 2022-06-16 21:37:43.804214
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:45.710339
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test')
    assert token.get() == 'test'


# Generated at 2022-06-16 21:37:47.561176
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO: test KeycloakToken.get()
    pass


# Generated at 2022-06-16 21:37:52.001463
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:55.781926
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='https://test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:38:00.710781
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:38:02.300123
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:38:07.463278
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.save()
    assert token.get() == 'test'
    token.set(None)
    assert token.get() == None
    token.save()
    assert token.get() == None

# Generated at 2022-06-16 21:38:24.394963
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests_mock
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Create a KeycloakToken object
    kct = KeycloakToken(access_token='test_token', auth_url='https://test_url')

    # Mock the open_url method
    with requests_mock.Mocker() as m:
        # Mock the response of the open_url method
        m.post('https://test_url', text='{"access_token": "test_access_token"}')

        # Call the get method of the KeycloakToken object
        token = kct.get()

    # Check the token returned by the get method
    assert token == 'test_access_token'

    # Check the payload sent to the Keycloak server

# Generated at 2022-06-16 21:38:27.079284
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:38:31.436906
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/test_token_file'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:38:37.436011
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='abcdef', auth_url='http://example.com')
    assert token.get() == 'abcdef'

    # Test with an invalid token
    token = KeycloakToken(access_token='abcdef', auth_url='http://example.com')
    assert token.get() == 'abcdef'

# Generated at 2022-06-16 21:38:41.454436
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() == None
    token.set('')
    assert token.get() == ''
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:38:45.378327
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:38:57.426933
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:06.352838
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test.yml')

    try:
        token = GalaxyToken()
        token.b_file = to_bytes(test_file, errors='surrogate_or_strict')
        token.config = {'token': 'test'}
        token.save()

        with open(test_file, 'r') as f:
            config = yaml.load(f)

        assert config == {'token': 'test'}
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-16 21:39:10.074773
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:39:12.575559
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:39:34.586866
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:45.092406
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:55.928681
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.six import PY3

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Write something to the file
    if PY3:
        os.write(fd, b'foo')
    else:
        os.write(fd, 'foo')

    # Close the file
    os.close(fd)

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()

    # Set the token file path
    galaxy_token.b_file = path

    # Set the token
    galaxy_token.set('bar')

    # Read the token file

# Generated at 2022-06-16 21:40:02.101124
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:10.531066
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    from ansible.module_utils.common.yaml import yaml_load

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, "test_file")
    open(file_path, 'a').close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()

    # Set the file path of the GalaxyToken object
    galaxy_token.b_file = file_path

    # Set the token of the GalaxyToken object
    galaxy_token.set('test_token')

    # Save the token to the file
    galaxy_token.save()

    # Read the token from the file

# Generated at 2022-06-16 21:40:22.902612
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:25.656597
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:40:35.090388
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    token._token = 'test_token'
    assert token.get() == 'test_token'

    # Test case 2
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    token._token = None
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:37.881254
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:42.391542
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:04.637770
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='offline_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    token.get()

# Generated at 2022-06-16 21:41:08.222731
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:41:10.891932
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:41:22.706409
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:31.396816
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:34.236255
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:37.774522
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo', auth_url='https://example.com/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == 'foo'


# Generated at 2022-06-16 21:41:40.431270
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:41.460578
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:49.244097
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token')
    token = 'abcdefghijklmnopqrstuvwxyz'

    # Test save
    gt = GalaxyToken(token)
    gt.save()

    # Test file exists
    assert os.path.isfile(token_file)

    # Test file content
    with open(token_file, 'r') as f:
        config = yaml.load(f)
    assert config['token'] == token

    # Cleanup
    shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:42:36.560556
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config['token'] = 'test'
    token.save()
    assert token.config['token'] == 'test'

# Generated at 2022-06-16 21:42:39.282097
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:42:41.792843
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:42:44.032200
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:42:48.628385
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:42:51.519043
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}
