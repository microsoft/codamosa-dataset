

# Generated at 2022-06-16 21:32:57.503927
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo', auth_url='https://example.com')
    assert token.get() == 'foo'


# Generated at 2022-06-16 21:33:01.876336
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer %s' % token.get()}


# Generated at 2022-06-16 21:33:04.132017
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:33:11.181011
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('foo')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = os.path.join(tmpdir, 'test')

    # Call the save method
    token.save()

    # Check the file content
    f = open(os.path.join(tmpdir, 'test'), 'r')
    assert f.read() == '{}'
    f.close()

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:33:16.623169
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:19.552834
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:33:22.878856
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:33.877733
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the file path
    token.b_file = path

    # Set the token
    token.set('test_token')

    # Save the token
    token.save()

    # Check that the file exists
    assert os.path.isfile(path)

    # Check that the file contains the token
    with open(path, 'r') as f:
        config = yaml_load(f)
        assert config['token'] == 'test_token'

    # Remove the temporary directory
   

# Generated at 2022-06-16 21:33:37.505124
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:40.622472
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:13.589920
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:17.312628
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert kct.get() == 'test_access_token'


# Generated at 2022-06-16 21:34:21.420559
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:25.665364
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:34:35.709898
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:48.850206
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    token_file = os.path.join(tmpdir, 'token.yml')
    open(token_file, 'w').close()

    # Create an instance of GalaxyToken
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = token_file

    # Set the token
    galaxy_token.set('test')

    # Save the token
    galaxy_token.save()

    # Check the token
    with open(token_file, 'r') as f:
        config = yaml.load(f)
        assert config['token'] == 'test'

    # Remove the temporary directory
    shutil.rmt

# Generated at 2022-06-16 21:34:52.528839
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:34:54.504448
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:34:56.956652
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:34:58.620413
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo')
    assert token.get() == 'foo'

# Generated at 2022-06-16 21:35:04.321887
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:07.326132
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:35:17.756272
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:27.592077
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test the case when access_token is None
    kct = KeycloakToken(access_token=None, auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kct.get() is None

    # Test the case when access_token is not None
    kct = KeycloakToken(access_token='test_access_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kct.get() == 'test_access_token'


# Generated at 2022-06-16 21:35:39.150251
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:50.762817
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save.yml')

    # Set a token
    token.set('test_token')

    # Read the token file
    with open(token.b_file, 'r') as f:
        data = yaml.load(f)

    # Check the token
    assert data['token'] == 'test_token'

   

# Generated at 2022-06-16 21:35:55.968043
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:36:03.745909
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.common.yaml import yaml_load

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Write something to the file
    os.write(fd, b'foo')
    os.close(fd)

    # Create a GalaxyToken object
    gt = GalaxyToken()

    # Set the path of the GalaxyToken object
    gt.b_file = path

    # Save the GalaxyToken object
    gt.save()

    # Read the file
    with open(path, 'r') as f:
        config = yaml_load(f)

    # Check the file content
   

# Generated at 2022-06-16 21:36:07.326007
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:36:11.052180
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:16.391771
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='12345')
    assert kct.get() == '12345'


# Generated at 2022-06-16 21:36:26.994137
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    kt = KeycloakToken(access_token='valid_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kt.get() == 'valid_token'

    # Test with an invalid token
    kt = KeycloakToken(access_token='invalid_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kt.get() == 'invalid_token'

    # Test with a valid token and a client_id

# Generated at 2022-06-16 21:36:39.973868
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:42.347074
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer None'


# Generated at 2022-06-16 21:36:51.642717
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:59.657363
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:03.876135
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:37:06.360600
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:37:15.069411
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:18.476300
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='foo')
    assert kt.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:37:24.317835
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token', 'test_url', True, 'test_client_id')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:37:35.057596
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:38.155409
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:42.721192
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:37:45.499017
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:37:49.961498
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:52.662616
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:02.304972
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    try:
        temp_dir = tempfile.mkdtemp()
        token_file = os.path.join(temp_dir, 'token')
        token = GalaxyToken(token_file)
        token.set('test_token')
        with open(token_file, 'r') as f:
            assert yaml.safe_load(f) == {'token': 'test_token'}
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:38:05.354497
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:38:18.169925
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    class TestKeycloakToken(unittest.TestCase):

        def setUp(self):
            self.mock_open_url = mock.patch('ansible.module_utils.urls.open_url')
            self.mock_open_url_instance = self.mock_open_url.start()
            self.mock_open_url_instance.return_value = mock.Mock()
            self.mock_open_url_instance.return_value.read.return_value = '{"access_token": "test_token"}'
            self.mock_open_url_instance.return_value.getcode.return_value = 200
            self.mock_open

# Generated at 2022-06-16 21:38:45.733472
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:48.111113
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test')
    assert token.headers() == {'Authorization': 'Bearer test'}


# Generated at 2022-06-16 21:39:00.260033
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils.six import StringIO
    import tempfile
    import os
    import yaml

    token_file = tempfile.NamedTemporaryFile(delete=False)
    token_file.close()
    token_file_path = token_file.name
    token_file_path = token_file_path.encode('utf-8')

    token = 'abcdefghijklmnopqrstuvwxyz'
    token_obj = GalaxyToken(token)
    token_obj.b_file = token_file_path
    token_obj.save()

    with open(token_file_path, 'r') as f:
        config = yaml.load(f)

    assert config['token'] == token

    os.remove(token_file_path)

# Generated at 2022-06-16 21:39:02.434678
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    assert token.get() is None


# Generated at 2022-06-16 21:39:09.897161
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:19.042425
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # create a temp directory
    tmpdir = tempfile.mkdtemp()

    # create a file in the temp directory
    tmpfile = os.path.join(tmpdir, 'test_galaxy_token')

    # create a token
    token = GalaxyToken()

    # set the token file
    token.b_file = to_bytes(tmpfile, errors='surrogate_or_strict')

    # set the token
    token.set('test_token')

    # save the token
    token.save()

    # read the token file
    with open(tmpfile, 'r') as f:
        config = yaml.load(f)

    # check the token
    assert config['token'] == 'test_token'

    # remove the

# Generated at 2022-06-16 21:39:21.506878
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:29.080204
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='valid_token', auth_url='https://valid_url')
    assert token.get() == 'valid_token'

    # Test with an invalid token
    token = KeycloakToken(access_token='invalid_token', auth_url='https://valid_url')
    assert token.get() == 'invalid_token'

    # Test with a valid token and a valid auth_url
    token = KeycloakToken(access_token='valid_token', auth_url='https://valid_url')
    assert token.get() == 'valid_token'

    # Test with a valid token and an invalid auth_url
    token = KeycloakToken(access_token='valid_token', auth_url='https://invalid_url')
    assert token.get

# Generated at 2022-06-16 21:39:33.383274
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()

    token_file = open(C.GALAXY_TOKEN_PATH, 'r')
    token_content = token_file.read()
    token_file.close()

    assert token_content == 'token: test_token\n'


# Generated at 2022-06-16 21:39:34.645887
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO: mock the open_url call
    pass

# Generated at 2022-06-16 21:39:41.209274
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('foo')
    assert token.get() == 'foo'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:39:43.517308
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:46.864863
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:57.102621
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:09.145407
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import responses

    # Test with a valid token

# Generated at 2022-06-16 21:40:12.162611
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:19.329134
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/test_token_file'
    token_obj = GalaxyToken(token)
    token_obj.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token_obj.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:40:29.081796
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:32.492731
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:35.088521
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='123456789')
    assert token.headers() == {'Authorization': 'Bearer 123456789'}


# Generated at 2022-06-16 21:40:53.999313
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:57.795811
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345', auth_url='https://auth.url')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:41:00.423282
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:03.801081
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com/auth/realms/test/protocol/openid-connect/token')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:06.385785
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:15.300178
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:17.921899
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://auth.url')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:41:26.094913
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    token.get()

# Generated at 2022-06-16 21:41:37.118349
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    token_file = os.path.join(tmpdir, 'token')
    open(token_file, 'w').close()

    # Create a token
    token = GalaxyToken()

    # Set the token file
    token.b_file = token_file

    # Set the token
    token.set('test')

    # Save the token
    token.save()

    # Read the token
    with open(token_file, 'r') as f:
        config = yaml.load(f)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check the token
    assert config['token'] == 'test'

# Generated at 2022-06-16 21:41:46.942526
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:24.262316
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='abc123', auth_url='https://auth.url')
    assert token.get() == 'abc123'


# Generated at 2022-06-16 21:42:28.934671
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token', 'test_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:42:32.791767
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:42:36.508717
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:42:38.860030
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:46.401004
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1:
    #   - access_token is None
    #   - auth_url is None
    #   - validate_certs is True
    #   - client_id is None
    #   - _token is None
    #   - _form_payload() returns 'grant_type=refresh_token&client_id=cloud-services&refresh_token='
    #   - resp.read() returns '{"access_token": "test_token"}'
    #   - data.get('access_token') returns 'test_token'
    #   - _token is 'test_token'
    #   - get() returns 'test_token'
    access_token = None
    auth_url = None
    validate_certs = True
    client_id = None
    _token = None

# Generated at 2022-06-16 21:42:49.799383
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo', auth_url='http://example.com')
    assert token.get() == 'foo'
