

# Generated at 2022-06-16 21:32:57.845242
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:01.431611
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token="test_token", auth_url="https://test_url.com")
    assert token.get() == "test_token"


# Generated at 2022-06-16 21:33:09.456951
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:17.287039
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test_file"), "w")
    f.write("foo\n")
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, "test_file"), errors='surrogate_or_strict')

    # Set the token
    token.set("test_token")

    # Read the token
    with open(token.b_file, 'r') as f:
        config = yaml.load(f)

    # Check the

# Generated at 2022-06-16 21:33:23.586775
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.access_token == 'test_token'
    assert token.auth_url == 'test_url'
    assert token.validate_certs == True
    assert token.client_id == 'cloud-services'


# Generated at 2022-06-16 21:33:24.571016
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:27.215724
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:29.255664
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:33.023352
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='test_token')
    assert token.get() == 'test_token'

    # Test with an invalid token
    token = KeycloakToken(access_token=None)
    assert token.get() is None

# Generated at 2022-06-16 21:33:37.000080
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:45.243583
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:33:57.412361
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:59.945750
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}

# Generated at 2022-06-16 21:34:07.403471
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a KeycloakToken object
    kct = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    # Call the get method
    kct.get()
    # Check the token is not None
    assert kct._token is not None
    # Check the token is a string
    assert isinstance(kct._token, str)
    # Check the token is not empty
    assert kct._token != ''

# Generated at 2022-06-16 21:34:12.443347
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/test_token_file'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()

    with open(token_file, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:34:14.732867
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:34:25.147177
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test.yml')
    token = 'test_token'
    token_obj = GalaxyToken(token)
    token_obj.save()
    with open(test_file, 'r') as f:
        data = yaml.load(f)
    assert data['token'] == token
    shutil.rmtree(test_dir)

# Generated at 2022-06-16 21:34:29.412002
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)


# Generated at 2022-06-16 21:34:43.506620
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:55.499778
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.galaxy.token import KeycloakToken
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.token = KeycloakToken(access_token='foo', auth_url='https://example.com')

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "bar"}'
            self.assertEqual(self.token.get(), 'bar')

    unittest.main()

# Generated at 2022-06-16 21:35:13.881035
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:17.713288
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:20.085685
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:23.701996
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:27.168508
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:35:38.613872
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:42.135472
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='http://example.com')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:35:53.609341
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:56.723267
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:58.138863
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}

# Generated at 2022-06-16 21:36:52.224979
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:36:54.252973
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:56.377169
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:58.714476
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:37:02.565413
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'test_url', True, 'test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:12.935179
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.galaxy.token import KeycloakToken

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.keycloak_token = KeycloakToken(access_token='test_access_token',
                                                auth_url='test_auth_url',
                                                validate_certs=True,
                                                client_id='test_client_id')

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_access_token"}'

# Generated at 2022-06-16 21:37:20.501161
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:37:27.795997
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        token_file = os.path.join(tmpdir, 'token')
        token = GalaxyToken()
        token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
        token.set('test_token')
        assert token.get() == 'test_token'
        token.set(None)
        assert token.get() is None
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:37:31.566212
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    token.set('test2')
    token.save()
    assert token.get() == 'test2'

# Generated at 2022-06-16 21:37:35.009071
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:58.622899
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:01.862297
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        token_file = os.path.join(tmpdir, 'token.yml')
        token = GalaxyToken(token_file)
        token.set('test_token')
        assert token.get() == 'test_token'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:38:05.018303
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:38:07.372548
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:11.683478
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:13.092924
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:15.856600
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:38:18.631899
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:25.545565
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:30.367019
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token = GalaxyToken()
    token.set('test_token')
    token.save()

    # Read the token file
    token = GalaxyToken()
    assert token.get() == 'test_token'

    # Remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:38:53.509287
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:38:57.370964
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:39:07.143782
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:17.911363
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    token_file = os.path.join(tmpdir, 'token.yml')
    open(token_file, 'w').close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = token_file

    # Set the token
    galaxy_token.set('test_token')

    # Check that the token was saved
    with open(token_file, 'r') as f:
        assert yaml.load(f) == {'token': 'test_token'}

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:39:19.627469
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo')
    assert token.get() == 'foo'

# Generated at 2022-06-16 21:39:21.653266
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:39:24.042298
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:30.092174
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:39:35.155900
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:39:37.292520
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:40:52.833176
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:40:54.127499
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:41:05.322139
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests_mock
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import parse_qs

    token = KeycloakToken(access_token='test_access_token', auth_url='https://test_auth_url')
    with requests_mock.Mocker() as m:
        m.post('https://test_auth_url', text='{"access_token": "test_access_token_returned"}')
        assert token.get() == 'test_access_token_returned'

    # test that the client_id is passed in the request

# Generated at 2022-06-16 21:41:08.779978
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:11.097742
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:16.001877
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:41:18.230907
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:26.324651
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the file path of the GalaxyToken object
    token.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'), errors='surrogate_or_strict')

    # Set the token of the GalaxyToken object
    token.set('test')

    # Save the token
    token.save()

    # Read the token file

# Generated at 2022-06-16 21:41:31.708567
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:41:33.970840
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:29.651563
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:42:40.912604
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:43.123458
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test', auth_url='http://test.com')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:42:54.230832
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), 'w')
    f.write(yaml.dump({'token': 'test_token'}))
    f.close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = to_bytes(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), errors='surrogate_or_strict')

    # Check if the token is the same
    assert galaxy_token.get() == 'test_token'

    # Set a new token