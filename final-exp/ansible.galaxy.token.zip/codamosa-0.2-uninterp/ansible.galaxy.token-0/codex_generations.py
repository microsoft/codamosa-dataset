

# Generated at 2022-06-16 21:33:01.345871
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with no access token
    token = KeycloakToken()
    assert token.get() is None

    # Test with access token
    token = KeycloakToken(access_token='test_access_token')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:33:09.394394
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1:
    #   - access_token is None
    #   - auth_url is None
    #   - validate_certs is True
    #   - client_id is None
    #   - _token is None
    #   - _form_payload() returns 'grant_type=refresh_token&client_id=cloud-services&refresh_token='
    #   - open_url() returns a response object with read() returning '{"access_token": "foo"}'
    #   - _token is set to 'foo'
    #   - get() returns 'foo'
    access_token = None
    auth_url = None
    validate_certs = True
    client_id = None
    _token = None

# Generated at 2022-06-16 21:33:12.470879
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:14.596885
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:33:27.952426
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:30.843301
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:33.958949
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:33:37.604686
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:33:42.300832
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:33:43.902599
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO: test KeycloakToken.get()
    pass

# Generated at 2022-06-16 21:33:52.074599
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:34:03.345808
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:05.509472
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:14.072562
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='abcdefg', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    token.get()

# Generated at 2022-06-16 21:34:15.627133
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:34:29.619432
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url


# Generated at 2022-06-16 21:34:34.716705
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:47.875518
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'), errors='surrogate_or_strict')

    # Set the token
    token.set('test')

    # Read the file
    with open(token.b_file, 'r') as f:
        data = yaml.load(f)

    # Check the token
    assert data['token'] == 'test'

    # Remove

# Generated at 2022-06-16 21:34:51.409177
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:34:53.832155
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:13.479539
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()

    # Set the file path of the GalaxyToken object
    galaxy_token.b_file = to_bytes(temp_file.name, errors='surrogate_or_strict')

    # Write the token to the temporary file
    galaxy_token.set('test_token')

    # Read the token from the temporary file
    with open(galaxy_token.b_file, 'r') as f:
        config = yaml_load(f)

    # Assert that the token is correct


# Generated at 2022-06-16 21:35:21.735076
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save.yml')

    # Set the token
    galaxy_token.set('test_token')

    # Read the token
    with open(galaxy_token.b_file, 'r') as f:
        config = yaml.load(f)

    # Check the token
    assert config['token']

# Generated at 2022-06-16 21:35:24.826237
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:35:36.902825
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:40.588879
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:35:45.973059
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config = {'token': 'test'}
    token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        assert yaml_load(f) == {'token': 'test'}
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:35:58.300566
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file = os.path.join(tmpdir, 'test_galaxy_token')

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()

    # Set the file path
    galaxy_token.b_file = to_bytes(file, errors='surrogate_or_strict')

    # Set the token
    galaxy_token.set('test_token')

    # Check the file exists
    assert os.path.isfile(file)

    # Check the file is readable and writable by the owner

# Generated at 2022-06-16 21:36:01.339506
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    token.get()
    assert token._token == '1234567890'

# Generated at 2022-06-16 21:36:05.421354
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:36:17.632740
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:29.034572
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:36:36.072424
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:36:45.465313
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = os.path.join(tmpdir, 'test')

    # Save the token
    galaxy_token.set('test')

    # Check the token
    assert galaxy_token.get() == 'test'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:36:56.415278
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:59.828670
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='test_access_token', auth_url='https://test_auth_url')
    assert kct.headers() == {'Authorization': 'Bearer test_access_token'}

# Generated at 2022-06-16 21:37:03.459340
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:13.508337
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('---\n')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'), errors='surrogate_or_strict')

    # Set the token
    token.set('test')

    # Read the file
    f = open(os.path.join(tmpdir, 'test.yml'), 'r')
    data = yaml.safe_load(f)
   

# Generated at 2022-06-16 21:37:18.472325
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='test_access_token')
    assert kct.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:37:22.167593
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:32.642739
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:52.048723
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlunparse
    from ansible.module_utils.six.moves.urllib.parse import quote

# Generated at 2022-06-16 21:37:55.159807
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:01.307366
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a KeycloakToken object
    kct = KeycloakToken(access_token='test_token', auth_url='test_url')

    # Call the get method
    kct.get()

    # Check the value of _token
    assert kct._token == 'test_token'

# Generated at 2022-06-16 21:38:07.015298
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os

    tmp_dir = tempfile.mkdtemp()
    token_file = os.path.join(tmp_dir, 'token.yml')
    token = GalaxyToken()
    token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token.set('test_token')
    assert token.get() == 'test_token'
    assert os.path.isfile(token_file)
    os.remove(token_file)
    os.rmdir(tmp_dir)

# Generated at 2022-06-16 21:38:11.294229
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:19.478851
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    tmpdir = tempfile.mkdtemp()
    try:
        token_file = os.path.join(tmpdir, 'token')
        token = GalaxyToken(token_file)
        token.set('abc123')
        token.save()

        with open(token_file, 'r') as f:
            data = yaml.load(f)

        assert data['token'] == 'abc123'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:38:23.045576
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abc123')
    assert token.headers() == {'Authorization': 'Bearer abc123'}


# Generated at 2022-06-16 21:38:27.474611
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:29.607157
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:36.963535
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import stat
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'ansible.cfg'), 'w')
    f.write('[galaxy]\n')
    f.write('server_list = galaxy.ansible.com\n')
    f.write('ignore_certs = True\n')
    f.write('token_file = %s\n' % os.path.join(tmpdir, 'token'))
    f.close()

    # Create a token file in the temporary directory
    f = open(os.path.join(tmpdir, 'token'), 'w')

# Generated at 2022-06-16 21:38:45.317422
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:38:57.369433
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import requests
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.response import addinfourl
    from ansible.module_utils.six.moves.urllib.response import addclosehook

# Generated at 2022-06-16 21:38:59.751686
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'

# Generated at 2022-06-16 21:39:08.513546
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:18.494226
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:20.932973
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:23.358644
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:27.606886
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:30.662838
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:35.155836
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:48.869908
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:39:52.110524
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:54.787519
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:00.012386
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='123456789')
    assert token.headers() == {'Authorization': 'Bearer 123456789'}


# Generated at 2022-06-16 21:40:04.064807
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    token.get()
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'

# Generated at 2022-06-16 21:40:06.384344
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:40:10.957279
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test'


# Generated at 2022-06-16 21:40:23.387492
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:26.756120
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:40:30.686758
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test.com', False, 'test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:14.475426
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = '12345'
    token_file = '/tmp/ansible-galaxy-token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:41:17.347995
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:19.895217
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:29.199852
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:32.509270
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:35.565901
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:41:45.674389
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')

        @mock.patch('ansible.galaxy.token.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_access_token"}'
            self.assertEqual(self.token.get(), 'test_access_token')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestKeycloakToken)
    unittest.Text

# Generated at 2022-06-16 21:41:54.955481
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    test_token = 'test_token'
    test_file = tempfile.mkstemp()[1]

    token = GalaxyToken(token=test_token)
    token.b_file = to_bytes(test_file, errors='surrogate_or_strict')
    token.save()

    with open(test_file, 'r') as f:
        config = yaml.load(f)

    assert config['token'] == test_token

    os.remove(test_file)

# Generated at 2022-06-16 21:42:03.542455
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1:
    #   - token is None
    #   - auth_url is None
    #   - validate_certs is True
    #   - client_id is None
    #   - _token is None
    #   - _form_payload() returns 'grant_type=refresh_token&client_id=cloud-services&refresh_token=None'
    #   - open_url() returns a response with body '{"access_token": "test_access_token"}'
    #   - _token is set to 'test_access_token'
    #   - get() returns 'test_access_token'
    token = None
    auth_url = None
    validate_certs = True
    client_id = None
    _token = None

# Generated at 2022-06-16 21:42:06.880507
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'