

# Generated at 2022-06-16 21:33:08.270507
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:14.970952
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_token = 'test_token'

    token = GalaxyToken(token=test_token)
    token.save()

    with open(test_file, 'r') as f:
        config = yaml.load(f)

    assert config['token'] == test_token

    shutil.rmtree(test_dir)

# Generated at 2022-06-16 21:33:18.605523
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:33:22.826164
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:33:33.837550
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:45.920538
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:50.092626
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:52.833620
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='my_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer my_token'

# Generated at 2022-06-16 21:34:04.104200
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    import stat

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file
    (fd, path) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = path

    # Test save
    token.set('test_token')
    token.save()

    # Check file permissions
    assert stat.S_IMODE(os.stat(path).st_mode) == (stat.S_IRUSR | stat.S_IWUSR)

    # Check file content
    with open(path, 'r') as f:
        config = yaml.load(f)

# Generated at 2022-06-16 21:34:06.099311
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123456789')
    assert token.get() == '123456789'


# Generated at 2022-06-16 21:34:13.294577
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='12345', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert kt.get() == '12345'

# Generated at 2022-06-16 21:34:15.490621
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:24.317645
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    with open(b_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(b_file)

# Generated at 2022-06-16 21:34:34.728418
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:38.287135
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:41.913340
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:43.520809
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='foo')
    assert kt.headers() == {'Authorization': 'Bearer foo'}



# Generated at 2022-06-16 21:34:56.192977
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:58.829534
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:02.336961
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:09.361747
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:35:13.210691
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    assert galaxy_token.get() == token
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:35:15.684268
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:23.110802
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import yaml
    from ansible.module_utils.common.yaml import yaml_load
    from ansible.module_utils.common.yaml import yaml_dump
    from ansible.galaxy.token import GalaxyToken
    from ansible.module_utils._text import to_bytes, to_text

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token')
    token_file_b = to_bytes(token_file, errors='surrogate_or_strict')

    # Create a token file
    token = 'test_token'
    token_dict = {'token': token}

# Generated at 2022-06-16 21:35:26.037874
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:37.775347
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:44.571052
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        token_file = os.path.join(temp_dir, 'token.yml')
        token = GalaxyToken(token_file)
        token.set('test_token')
        assert token.get() == 'test_token'
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:35:52.303035
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

    # Test case 2
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    token._token = 'test_token'
    assert token.get() == 'test_token'



# Generated at 2022-06-16 21:35:55.276836
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:36:03.398660
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:19.730801
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = os.path.join(tmpdir, 'test.yml')

    # Set the token
    token.set('test')

    # Read the file
    with open(token.b_file, 'r') as f:
        data = yaml.load(f)

    # Check the token
    assert data['token'] == 'test'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:36:21.060167
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:23.569777
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test', auth_url='http://test.com')
    assert token.get() == 'test'


# Generated at 2022-06-16 21:36:27.118026
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:40.058431
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token_file = '/tmp/ansible_galaxy_token'
    token = '1234567890'
    token_dict = {'token': token}
    with open(token_file, 'w') as f:
        yaml_dump(token_dict, f, default_flow_style=False)

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')

    # Read the token file
    config = galaxy_token._read()
    assert config == token_dict

    # Change the token
    new_token = '0987654321'
    galaxy_token.set(new_token)

    # Read the token file
    config = galaxy_token._read

# Generated at 2022-06-16 21:36:42.443820
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:43.865279
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:36:45.307909
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:47.913355
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:57.487600
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:51.146184
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:52.728222
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:37:56.007916
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='http://example.com')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:38:06.697961
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:19.479524
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:32.106437
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:35.670332
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'

# Generated at 2022-06-16 21:38:38.867353
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:46.965647
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token_file = '/tmp/ansible_galaxy_token.yml'
    token_file_b = to_bytes(token_file, errors='surrogate_or_strict')
    open(token_file_b, 'w').close()
    os.chmod(token_file_b, S_IRUSR | S_IWUSR)  # owner has +rw

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = token_file_b

    # Set token
    galaxy_token.set('test_token')

    # Read token file
    with open(token_file_b, 'r') as f:
        config = yaml_load(f)

    # Check token

# Generated at 2022-06-16 21:38:52.101364
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True, client_id='test_client_id')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'

# Generated at 2022-06-16 21:39:17.632137
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:20.800808
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='http://localhost/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:39:22.865271
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:39:26.758156
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:36.048584
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:39.645815
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:42.738575
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:39:45.336539
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:48.624091
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='test_token')
    assert kt.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:51.514788
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:15.974272
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:40:26.913152
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:33.996284
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:38.455605
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token.yml')

    token = GalaxyToken()
    token.b_file = token_file
    token.set('my_token')
    token.save()

    with open(token_file, 'r') as f:
        config = yaml_load(f)

    assert config == {'token': 'my_token'}

    shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:40:50.275783
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:53.240371
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:04.452657
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:07.972285
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:09.953316
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:41:19.586602
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests_mock
    with requests_mock.Mocker() as m:
        m.post('https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
               json={'access_token': 'test_token'})
        token = KeycloakToken(access_token='test_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
        assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:15.463184
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    token._token = 'test_token'
    assert token.get() == 'test_token'

    # Test case 2
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    token._token = None
    assert token.get() == 'test_token'

    # Test case 3
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    token._token = 'test_token'


# Generated at 2022-06-16 21:42:19.937701
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() == None
    token.set(NoTokenSentinel)
    assert token.get() == None

# Generated at 2022-06-16 21:42:24.060619
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:42:31.636293
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set(None)
    assert token.get() is None
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:42:34.642003
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    # Create a token
    token = 'test_token'
    # Set the token
    galaxy_token.set(token)
    # Get the token
    token_get = galaxy_token.get()
    # Check if the token is the same
    assert token == token_get
    # Delete the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:42:37.569399
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:42:39.472199
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:42:42.198240
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:42:44.929267
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:42:47.837242
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers == {'Authorization': 'Bearer 12345'}
