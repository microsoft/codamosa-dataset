

# Generated at 2022-06-16 21:33:01.726628
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:33:04.934399
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a KeycloakToken object
    token = KeycloakToken(access_token='test_token', auth_url='test_url')

    # Call the method get
    result = token.get()

    # Check the result
    assert result == 'test_token'

# Generated at 2022-06-16 21:33:08.037401
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:33:10.467526
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True, client_id='test_client_id')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:33:12.148762
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'

# Generated at 2022-06-16 21:33:13.549722
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:33:26.713439
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:29.623935
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:37.632385
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:40.303253
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:49.783535
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:33:53.330458
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

    # Cleanup
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:33:56.238528
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:34:06.938430
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:34:10.538008
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:34:13.115962
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:15.897629
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:34:20.158816
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:34:23.871349
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}

# Generated at 2022-06-16 21:34:27.122055
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='test_token')
    assert kt.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:34:42.016600
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:34:45.454166
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:34:48.915383
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:51.649221
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:54.511934
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='foo', auth_url='http://example.com')
    assert kt.get() == 'foo'


# Generated at 2022-06-16 21:34:57.477104
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:35:01.578707
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:35:14.141214
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:26.594414
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:34.616521
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/ansible_galaxy_token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:36:12.973920
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:36:15.227103
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:36:18.192456
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    token.get()
    assert token._token == 'test_token'

# Generated at 2022-06-16 21:36:21.889233
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:25.262771
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url.com')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:34.104140
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/galaxy_token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:36:44.993997
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the token file to the temporary file
    token.b_file = os.path.join(tmpdir, 'test.yml')

    # Set the token
    token.set('test')

    # Read the token file
    with open(token.b_file, 'r') as f:
        data = yaml.load(f)

    # Check the token is set
    assert data['token'] == 'test'

    # Remove the

# Generated at 2022-06-16 21:36:53.335574
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:56.136086
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:07.937288
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:35.008503
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:37:37.700367
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:37:41.705512
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:37:44.993945
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:49.420799
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:37:52.576391
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'


# Generated at 2022-06-16 21:37:55.944686
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='http://example.com')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:38:00.447365
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:03.291929
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    assert token.get() is None

# Generated at 2022-06-16 21:38:06.042205
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:15.929725
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:25.167575
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:28.360200
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    assert token.get() == 'test_token'
    token.set(None)
    assert token.get() == None
    token.save()
    assert token.get() == None

# Generated at 2022-06-16 21:39:31.280692
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='abcdefg')
    assert kt.headers() == {'Authorization': 'Bearer abcdefg'}

# Generated at 2022-06-16 21:39:38.264905
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'
    token.set(NoTokenSentinel)
    assert token.get() is None

# Generated at 2022-06-16 21:39:41.546822
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:39:43.477525
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:39:46.125473
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}

# Generated at 2022-06-16 21:39:48.627201
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test')
    assert token.get() == 'test'


# Generated at 2022-06-16 21:39:51.452887
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:42:38.724215
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import mock
    import requests

    # Create a mock response object
    mock_response = mock.Mock()
    mock_response.read.return_value = json.dumps({'access_token': '12345'})

    # Mock the open_url function
    with mock.patch('ansible.module_utils.urls.open_url', return_value=mock_response) as mock_open_url:
        # Create a KeycloakToken object
        token = KeycloakToken(access_token='12345', auth_url='http://example.com')

        # Call the get method
        token.get()

        # Assert that the open_url function was called

# Generated at 2022-06-16 21:42:46.307191
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:49.693822
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'
