

# Generated at 2022-06-16 21:33:07.469845
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1:
    #   - access_token is None
    #   - auth_url is None
    #   - validate_certs is True
    #   - client_id is None
    #   - _token is None
    #   - _form_payload() returns 'grant_type=refresh_token&client_id=cloud-services&refresh_token='
    #   - open_url() returns a response with a body of '{"access_token": "test_token"}'
    #   - _token should be set to 'test_token'
    token = KeycloakToken(access_token=None, auth_url=None, validate_certs=True, client_id=None)
    token._token = None

# Generated at 2022-06-16 21:33:09.467580
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:17.286680
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.write('{"token": "test_token"}')
    f.close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = to_bytes(os.path.join(tmpdir, 'test_file'), errors='surrogate_or_strict')

    # Test the save method
    galaxy_token.set('new_token')
    galaxy_token.save()
    assert galaxy_token.get() == 'new_token'

    # Remove the temporary directory
    shutil.rmtree

# Generated at 2022-06-16 21:33:21.541582
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:33:24.114955
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url', validate_certs=True, client_id='test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:34.646326
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):

        def setUp(self):
            self.token = KeycloakToken(access_token='test_token', auth_url='test_url')

        @mock.patch.object(open_url, '__call__')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_token"}'
            self.assertEqual(self.token.get(), 'test_token')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestKeycloakToken)
    unittest.TextTestRunner(verbosity=2).run

# Generated at 2022-06-16 21:33:38.916426
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:48.773916
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1:
    #   - access_token is not None
    #   - auth_url is not None
    #   - validate_certs is True
    #   - client_id is None
    #   - _token is None
    #   - _form_payload() returns 'grant_type=refresh_token&client_id=cloud-services&refresh_token=<access_token>'
    #   - open_url() returns a response with a body containing 'access_token'
    #   - json.loads() returns a dict containing 'access_token'
    #   - _token is set to 'access_token'
    #   - get() returns 'access_token'
    access_token = 'access_token'
    auth_url = 'auth_url'
    validate_certs = True
   

# Generated at 2022-06-16 21:33:59.627846
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the token file path
    token.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save.yml')

    # Save the token
    token.save()

    # Check if the token file is created
    assert os.path.isfile(token.b_file)

    # Check if the token file is empty
    assert os.stat(token.b_file).st_size

# Generated at 2022-06-16 21:34:03.804254
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '12345'



# Generated at 2022-06-16 21:34:09.477697
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:34:22.343565
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:33.895895
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:39.154225
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:34:51.846744
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:54.846105
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:01.420571
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:05.109281
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:11.562213
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token2 = GalaxyToken()
    assert token2.get() == 'test_token'
    token.set(None)
    token.save()
    token3 = GalaxyToken()
    assert token3.get() is None

# Generated at 2022-06-16 21:35:17.487764
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='valid_token', auth_url='https://auth.url')
    assert token.get() == 'valid_token'

    # Test with an invalid token
    token = KeycloakToken(access_token='invalid_token', auth_url='https://auth.url')
    assert token.get() == 'invalid_token'

# Generated at 2022-06-16 21:35:26.201977
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import requests
    import responses

    url = 'http://example.com/auth/realms/master/protocol/openid-connect/token'

# Generated at 2022-06-16 21:35:29.179004
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('access_token', 'auth_url', True, 'client_id')
    assert token.get() == 'access_token'


# Generated at 2022-06-16 21:35:40.682472
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import stat
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), 'w')
    # Write a yaml file
    f.write('token: test_token')
    f.close()
    # Create a GalaxyToken object
    gt = GalaxyToken()
    # Set the file path
    gt.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save.yml')
    # Set the token
    gt.set('test_token')
    # Save the token
    gt.save()
    # Read the file

# Generated at 2022-06-16 21:35:52.088515
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:01.716983
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:14.976901
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import json
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):

        def setUp(self):
            self.token = KeycloakToken(access_token='test_access_token',
                                       auth_url='https://test_auth_url',
                                       validate_certs=True,
                                       client_id='test_client_id')


# Generated at 2022-06-16 21:36:21.889142
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/test_token_file'
    token_obj = GalaxyToken(token)
    token_obj.b_file = token_file
    token_obj.save()
    with open(token_file, 'r') as f:
        assert f.read() == 'token: test_token\n'
    os.remove(token_file)

# Generated at 2022-06-16 21:36:24.292408
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:37.709544
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:39.456640
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config['token'] = 'test'
    token.save()
    assert token.config['token'] == 'test'

# Generated at 2022-06-16 21:36:45.225006
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:49.489865
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:36:52.184216
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:36:59.986029
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.test_token = KeycloakToken(access_token='test_token', auth_url='test_url')

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_access_token"}'
            self.assertEqual(self.test_token.get(), 'test_access_token')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestKeycloakToken)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-16 21:37:03.185969
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:37:05.760923
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}

# Generated at 2022-06-16 21:37:14.661131
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import unittest
    import mock
    from ansible.module_utils.urls import open_url

    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code

        def json(self):
            return self.json_data

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.kct = KeycloakToken(access_token='12345', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')


# Generated at 2022-06-16 21:37:18.356561
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='abc', auth_url='http://example.com')
    assert token.get() == 'abc'


# Generated at 2022-06-16 21:37:22.900013
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:37:33.215409
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import os
    import json
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError

    class MockResponse(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    class MockOpenUrl(object):
        def __init__(self, data):
            self.data = data

        def __call__(self, url, data, validate_certs, method, http_agent):
            if self.data is None:
                raise HTTPError(url, 404, 'Not Found', {}, None)

# Generated at 2022-06-16 21:37:50.564941
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = path

    # Test that the file is created
    assert not os.path.isfile(path)
    token.save()
    assert os.path.isfile(path)

    # Test that the file is chmod u+rw
    assert stat.S_IMODE(os.stat(path).st_mode) == stat.S_IRUSR | stat.S_IWUSR

    # Test that the file

# Generated at 2022-06-16 21:38:01.851303
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import requests_mock
    import json

    # Create a mock response
    mock_response = requests.Response()
    mock_response.status_code = 200

# Generated at 2022-06-16 21:38:08.690685
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = path

    # Set the token
    token.set('test')

    # Save the token
    token.save()

    # Open the file
    with open(path, 'r') as f:
        # Load the content
        content = yaml.load(f)

    # Check the content
    assert content == {'token': 'test'}

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:38:13.651098
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import yaml
    import os.path
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    b_file = to_bytes(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), errors='surrogate_or_strict')
    open(b_file, 'w').close()
    os.chmod(b_file, S_IRUSR | S_IWUSR)  # owner has +rw

    # Create an instance of GalaxyToken
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = b_file

    # Call the save method
    galaxy_token.save()

    # Check the file has been created
   

# Generated at 2022-06-16 21:38:18.907569
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a KeycloakToken object
    kct = KeycloakToken(access_token='test', auth_url='test', validate_certs=True, client_id='test')
    # Call the method get
    kct.get()
    # Check if the method get returns a token
    assert kct._token is not None


# Generated at 2022-06-16 21:38:21.104090
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:25.811940
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:38:28.645278
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:31.155054
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer foo'


# Generated at 2022-06-16 21:38:37.797409
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    # Create a temp file
    tmpfile = os.path.join(tmpdir, 'test_GalaxyToken_save')

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = to_bytes(tmpfile, errors='surrogate_or_strict')

    # Set the token
    gt.set('test_token')

    # Check the token is saved
    with open(tmpfile, 'r') as f:
        data = yaml.load(f)
        assert data['token'] == 'test_token'

    # Cleanup
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:39:03.321860
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:06.022721
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:39:10.841881
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    assert token.headers() == {'Authorization': 'Token test'}

# Generated at 2022-06-16 21:39:14.268905
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345', auth_url='http://example.com/auth')
    assert token.headers() == {'Authorization': 'Bearer 12345'}



# Generated at 2022-06-16 21:39:17.330767
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:26.313380
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:28.425758
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='http://example.com/auth')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:39:31.329368
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:39:35.245760
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:38.524905
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:39:48.353286
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:39:51.235980
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:53.590550
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:40:00.509324
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:04.064651
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:40:07.154178
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'

# Generated at 2022-06-16 21:40:13.465834
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:40:16.495979
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:21.490160
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test', auth_url='test', validate_certs=True, client_id='test')
    token.get()
    assert token.headers() == {'Authorization': 'Bearer %s' % token._token}


# Generated at 2022-06-16 21:40:30.002261
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:51.623556
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:02.661921
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:05.139093
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:41:08.395537
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:10.381215
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:41:17.877145
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.galaxy.token import GalaxyToken
    from ansible.module_utils.six import StringIO
    import yaml

    token = GalaxyToken()
    token.set('test_token')
    token.save()

    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml.load(f)

    assert config['token'] == 'test_token'

# Generated at 2022-06-16 21:41:20.446250
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:22.416029
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:26.220127
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:41:28.466609
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:53.783196
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:42:02.876638
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')

# Generated at 2022-06-16 21:42:08.595368
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:42:13.764860
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == 'test'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:42:20.077690
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a KeycloakToken object
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True, client_id='test_client_id')
    # Call the get method
    token.get()
    # Check the value of the _token attribute
    assert token._token == 'test_access_token'


# Generated at 2022-06-16 21:42:22.992270
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:42:25.441228
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:42:28.999190
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:42:32.394361
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:42:36.153822
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    assert token.get() == 'test_token'