

# Generated at 2022-06-16 21:33:08.893198
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    import json

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.keycloak_token = KeycloakToken(access_token='test_access_token',
                                                auth_url='test_auth_url',
                                                validate_certs=True,
                                                client_id='test_client_id')

        def test_get(self):
            with mock.patch('ansible.module_utils.urls.open_url') as mock_open_url:
                mock_open_url.return_value = mock.MagicMock(read=lambda: json.dumps({'access_token': 'test_access_token'}))

# Generated at 2022-06-16 21:33:12.397966
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:33:15.023544
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:33:18.669341
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:33:22.878183
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:33:33.877764
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:37.513232
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234')
    assert token.headers() == {'Authorization': 'Bearer 1234'}


# Generated at 2022-06-16 21:33:40.628243
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:49.698443
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.token = KeycloakToken('test_token', 'http://test_url', True, 'test_client_id')

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_access_token"}'
            self.assertEqual(self.token.get(), 'test_access_token')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestKeycloakToken)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-16 21:34:00.750437
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:06.988847
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:08.799340
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:34:12.493928
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:34:25.922450
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:35.951364
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:37.472805
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:34:42.857750
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token2 = GalaxyToken()
    assert token2.get() == 'test_token'
    token.set(None)
    token.save()
    token3 = GalaxyToken()
    assert token3.get() == None

# Generated at 2022-06-16 21:34:47.129791
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:49.492242
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:52.817797
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:34:59.108099
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:35:12.205080
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:17.416593
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        token_file = os.path.join(tmpdir, 'token.yml')
        token = GalaxyToken(token_file)
        token.set('test_token')
        assert token.get() == 'test_token'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:35:29.004476
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = os.path.join(tmpdir, 'test.yml')

    # Set the token
    token.set('test')

    # Save the token
    token.save()

    # Check the token file
    with open(token.b_file, 'r') as f:
        data = yaml.load(f)
        assert data['token'] == 'test'

    # Remove the temporary directory


# Generated at 2022-06-16 21:35:33.541127
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:35:36.097679
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:35:47.591560
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:59.595519
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    token_file = os.path.join(tmpdir, 'token.yml')
    open(token_file, 'w').close()
    os.chmod(token_file, S_IRUSR | S_IWUSR)  # owner has +rw

    # Create an instance of GalaxyToken
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = token_file

    # Set the token
    galaxy_token.set('test_token')

    # Read the token file
    with open(token_file, 'r') as f:
        config = yaml.load(f)

    # Check the token

# Generated at 2022-06-16 21:36:03.911122
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:36:09.359699
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    token = GalaxyToken()
    # Create a token file
    token.save()
    # Check if the token file is created
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    # Remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:36:24.425890
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:37.808967
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:48.260612
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, "test_GalaxyToken_save"), "wb")
    f.write(b"# This file is empty")
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = os.path.join(tmpdir, "test_GalaxyToken_save")

    # Set the token
    gt.set("test_token")

    # Check that the token is set
    assert gt.get() == "test_token"

    # Check that the file has been created

# Generated at 2022-06-16 21:36:57.624822
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:59.538617
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345')
    assert token.get() == '12345'

# Generated at 2022-06-16 21:37:03.705373
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:09.816007
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:12.141914
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:37:16.786959
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test.com/auth/realms/test/protocol/openid-connect/token', False)
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:37:20.192885
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}

# Generated at 2022-06-16 21:37:47.561306
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:58.470602
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('foo')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = os.path.join(tmpdir, 'test')

    # Save the token
    token.set('bar')

    # Check the content of the file
    f = open(os.path.join(tmpdir, 'test'), 'r')
    assert f.read() == 'token: bar\n'
    f.close()

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:38:02.245090
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:38:05.704482
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:09.594152
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:12.496518
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:17.361891
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('abcdefghijklmnopqrstuvwxyz', 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:38:20.232498
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-16 21:38:33.043909
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:43.861273
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import stat

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token')
    token = 'mytoken'

    # Create token file
    gt = GalaxyToken()
    gt.set(token)
    gt.save()

    # Check token file
    assert os.path.isfile(token_file)
    assert stat.S_IMODE(os.stat(token_file).st_mode) == (stat.S_IRUSR | stat.S_IWUSR)
    with open(token_file, 'r') as f:
        assert yaml_load(f) == {'token': token}

    # Cleanup
    shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:38:57.820882
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:39:00.741945
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:02.119139
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:39:04.830741
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='access_token', auth_url='auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:39:09.600413
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:39:12.281201
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:15.333894
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:17.916443
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:26.861721
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:29.901508
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:40:26.704922
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:30.613621
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test', auth_url='test', validate_certs=True, client_id='test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:40:33.396396
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:36.130925
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:39.095814
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:50.722817
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token_file = '/tmp/ansible_galaxy_token'
    token_file_b = to_bytes(token_file, errors='surrogate_or_strict')
    open(token_file_b, 'w').close()
    os.chmod(token_file_b, S_IRUSR | S_IWUSR)  # owner has +rw

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = token_file_b

    # Set the token
    token.set('my_token')

    # Read the token file
    with open(token_file_b, 'r') as f:
        config = yaml_load(f)

    # Check the token
    assert config['token'] == 'my_token'

    # Remove

# Generated at 2022-06-16 21:40:53.754633
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:40:59.811112
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:01.937396
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:41:04.494299
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:41:31.714409
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:36.725524
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'w')
    f.close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    # Set the path of the token file
    galaxy_token.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save')

    # Set the token
    galaxy_token.set('test_token')

    # Read the token file
    with open(galaxy_token.b_file, 'r') as f:
        config = yaml.load(f)

    # Check the token
   

# Generated at 2022-06-16 21:41:39.401060
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:41:42.607893
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:41:45.617355
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:41:48.679738
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:42:00.228582
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='valid_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == 'valid_token'

    # Test with an invalid token
    token = KeycloakToken(access_token='invalid_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == 'invalid_token'

    # Test with a valid token and a client_id

# Generated at 2022-06-16 21:42:12.907992
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:16.056562
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:42:20.163779
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token = KeycloakToken(access_token='test_access_token')
    assert keycloak_token.headers() == {'Authorization': 'Bearer test_access_token'}

# Generated at 2022-06-16 21:42:56.791533
# Unit test for method get of class KeycloakToken