

# Generated at 2022-06-16 21:33:00.669468
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:04.024961
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()

    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == 'test_token'

# Generated at 2022-06-16 21:33:07.755633
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    token = GalaxyToken()

    # Create a token file
    token.save()

    # Check if the token file is created
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

    # Remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:33:10.881203
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:13.180723
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:33:15.162091
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:33:18.230753
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:33:21.826250
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:24.551315
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:28.510803
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-16 21:33:34.015244
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:46.088365
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the token file
    token.b_file = path

    # Set the token
    token.set('test')

    # Save the token
    token.save()

    # Read the token file
    with open(path, 'r') as f:
        config = yaml.load(f)

    # Delete the temporary directory
    shutil.rmtree(tmpdir)

    # Check that the token is saved
    assert config['token'] == 'test'

# Generated at 2022-06-16 21:33:50.524494
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'


# Generated at 2022-06-16 21:33:53.725988
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='http://example.com')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:33:56.616135
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test_url.com', True, 'test_client_id')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:33:59.577368
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:34:09.247781
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import responses

    # Mock the response from the Keycloak server
    responses.add(responses.POST,
                  'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                  json={'access_token': 'test_access_token'},
                  status=200)

    # Create a KeycloakToken object
    kct = KeycloakToken(access_token='test_offline_token',
                        auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                        validate_certs=True)

    # Call the get method
    token = kct.get()

    # Check the token returned
    assert token == 'test_access_token'

   

# Generated at 2022-06-16 21:34:14.880323
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import stat
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_galaxy_token'), 'w')
    f.close()
    # Create a GalaxyToken object
    gt = GalaxyToken()
    # Set the token file path
    gt.b_file = os.path.join(tmpdir, 'test_galaxy_token')
    # Set the token
    gt.set('test_token')
    # Save the token
    gt.save()
    # Read the token file
    with open(gt.b_file, 'r') as f:
        # Load the token file
        config = y

# Generated at 2022-06-16 21:34:18.588350
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='https://auth.url.com')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:34:22.061936
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123', auth_url='https://example.com')
    assert token.get() == '123'


# Generated at 2022-06-16 21:34:36.341687
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:48.964508
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:53.122497
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:54.407473
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:35:06.816844
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:15.141600
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = path

    # Save a token
    token.set('test_token')

    # Check that the token was saved
    with open(path, 'r') as f:
        assert yaml_load(f) == {'token': 'test_token'}

    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-16 21:35:22.757857
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    '''
    Test the save method of GalaxyToken
    '''
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    token_file = os.path.join(tmpdir, 'token')
    # Create a GalaxyToken object
    token = GalaxyToken()
    # Set the token file
    token.b_file = token_file
    # Set the token
    token.set('test_token')
    # Save the token
    token.save()
    # Check if the token file exists
    assert os.path.isfile(token_file)
    # Read the token file
    with open(token_file, 'r') as f:
        data = yaml.load(f)

# Generated at 2022-06-16 21:35:35.348822
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:37.649814
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:35:40.865012
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:50.891556
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:01.029654
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:05.697946
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='https://example.com/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == '12345'

# Generated at 2022-06-16 21:36:17.876888
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import configparser

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temp directory
    path = os.path.join(tmpdir, "ansible.cfg")
    with open(path, 'w') as f:
        f.write("[galaxy]\n")
        f.write("server_list = galaxy.ansible.com, galaxy2.ansible.com\n")
        f.write("ignore_certs = True\n")
        f.write("token_file = %s\n" % C.GALAXY_TOKEN_PATH)

    # Set the ANSIBLE_CON

# Generated at 2022-06-16 21:36:21.646270
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:36:29.165500
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 1:
    #   - access_token = 'foo'
    #   - auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    #   - validate_certs = True
    #   - client_id = 'cloud-services'
    #   - _token = None
    #   - _form_payload() = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=foo'
    #   - resp = {'access_token': 'bar'}
    #   - data = {'access_token': 'bar'}
    #   - _token = 'bar'
    #   - return 'bar'
    access_token = 'foo'

# Generated at 2022-06-16 21:36:33.949017
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:36:44.855066
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    filename = os.path.join(tmpdir, 'test_GalaxyToken_save.yml')
    # Create a GalaxyToken object
    token = GalaxyToken()
    # Set the file property of the object
    token.b_file = filename
    # Set the token property of the object
    token.set('test_token')
    # Save the token to the file
    token.save()
    # Read the file
    with open(filename, 'r') as f:
        # Load the yaml content
        data = yaml.load(f)
        # Check if the token is in the file

# Generated at 2022-06-16 21:36:47.509287
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:36:51.862866
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with empty access_token
    token = KeycloakToken(access_token='')
    assert token.get() is None

    # Test with valid access_token
    token = KeycloakToken(access_token='12345')
    assert token.get() == '12345'

# Generated at 2022-06-16 21:37:04.215489
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:05.396245
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:37:08.400873
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() == None

# Generated at 2022-06-16 21:37:10.623597
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:12.548820
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:37:17.424408
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:37:21.172658
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:37:29.184139
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):

        @mock.patch('ansible.module_utils.urls.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "test_token"}'
            token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
            self.assertEqual(token.get(), 'test_token')

    unittest.main()

# Generated at 2022-06-16 21:37:31.859261
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abc123')
    assert token.headers() == {'Authorization': 'Bearer abc123'}


# Generated at 2022-06-16 21:37:34.413629
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:00.884152
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:38:08.381805
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'w')
    f.write('foo\n')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the file path
    token.b_file = to_bytes(os.path.join(tmpdir, 'test_GalaxyToken_save'), errors='surrogate_or_strict')

    # Set the token
    token.set('bar')

    # Read the file
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'r')

# Generated at 2022-06-16 21:38:12.443956
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:38:15.213678
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:18.306218
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:28.460957
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temp file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)
    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = path
    # Set the token
    gt.set('test')
    # Read the token file
    with open(path, 'r') as f:
        config = yaml_load(f)
    # Check the token
    assert config['token'] == 'test'
    # Remove the temp file
    os.remove(path)

# Generated at 2022-06-16 21:38:36.364539
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_galaxy_token')


# Generated at 2022-06-16 21:38:38.001414
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:40.522111
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:38:44.530264
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:39:18.342901
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:39:20.754364
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:39:23.181632
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:26.883010
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:39:29.487110
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:39:32.708214
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token2 = GalaxyToken()
    assert token2.get() == 'test_token'

# Generated at 2022-06-16 21:39:35.985705
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('abc123')
    assert token.get() == 'abc123'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:39:39.190270
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:39:50.241025
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:53.326637
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer foo'


# Generated at 2022-06-16 21:40:24.314764
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:28.231341
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:32.442888
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer %s' % token.get()


# Generated at 2022-06-16 21:40:44.817367
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:53.371289
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.write('foo\n')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = os.path.join(tmpdir, 'test_file')

    # Set a token
    token.set('test_token')

    # Read the token file
    f = open(os.path.join(tmpdir, 'test_file'), 'r')
    token_file = f.read()
    f.close()

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:40:56.546235
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:41:08.183285
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:15.854991
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:24.915063
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import os.path
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save.yml'), 'w')
    f.write("""
---
token: test_token
""")
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save.yml')

    # Set the token
    gt.set('test_token')

    # Read the token
    token = gt.get()

    # Check that the token is correct

# Generated at 2022-06-16 21:41:27.808958
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:07.460438
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:42:19.330703
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:21.508257
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    assert galaxy_token.get() == token

# Generated at 2022-06-16 21:42:29.945644
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:32.965545
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:42:43.068323
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:45.853895
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:42:48.722981
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:51.620004
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token', 'test_url')
    assert token.headers() == {'Authorization': 'Bearer None'}
