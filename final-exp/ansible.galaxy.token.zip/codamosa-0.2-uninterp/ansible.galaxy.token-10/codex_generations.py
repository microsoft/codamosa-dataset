

# Generated at 2022-06-16 21:32:58.813883
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('foo')
    token.save()
    assert token.get() == 'foo'

# Generated at 2022-06-16 21:33:08.233445
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:11.683979
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:33:14.240887
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:33:17.831950
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:33:30.473778
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:33.284729
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:33:35.746127
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:33:39.527221
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:49.081521
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:01.009379
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    token = GalaxyToken()

    # Create a token file
    token.save()

    # Check if the token file is created
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

    # Check if the token file is readable
    assert os.access(C.GALAXY_TOKEN_PATH, os.R_OK)

    # Check if the token file is writable
    assert os.access(C.GALAXY_TOKEN_PATH, os.W_OK)

    # Remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:34:03.911161
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 12345'


# Generated at 2022-06-16 21:34:06.315544
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='abc123')
    assert kt.headers() == {'Authorization': 'Bearer abc123'}


# Generated at 2022-06-16 21:34:13.074366
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:16.700305
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:34:20.032649
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:32.457675
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:45.211443
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:48.731839
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:34:58.766803
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:05.053568
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:09.280791
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo', auth_url='http://example.com')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:35:12.156454
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:35:16.676003
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:35:19.268011
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:23.254809
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'


# Generated at 2022-06-16 21:35:26.232878
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:30.352224
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set(NoTokenSentinel())
    assert token.get() is None

# Generated at 2022-06-16 21:35:34.172569
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:36.986821
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='access_token', auth_url='auth_url')
    token.get()
    assert token._token == 'access_token'


# Generated at 2022-06-16 21:35:51.750300
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:58.433300
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/ansible_galaxy_token'
    token_obj = GalaxyToken(token)
    token_obj.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token_obj.save()

    with open(token_file, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:36:00.041854
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='abcdefg', auth_url='http://example.com')
    assert token.get() == 'abcdefg'

# Generated at 2022-06-16 21:36:13.872401
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:16.760119
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'

# Generated at 2022-06-16 21:36:19.500063
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:22.790852
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert kct.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:36:25.152768
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:28.057551
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:36:32.775321
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:36:40.807234
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:36:44.534223
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:47.193418
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:36:52.315345
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.save()
    token = GalaxyToken()
    assert token.get() == 'test_token'
    token.set(None)
    token.save()
    token = GalaxyToken()
    assert token.get() is None

# Generated at 2022-06-16 21:36:55.309778
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:06.884837
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:09.992426
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:12.627076
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test_token', 'https://test_url.com', False, 'test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:26.087345
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('token: test')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'))

    # Save the token
    gt.set('test2')

    # Check the file content
    f = open(os.path.join(tmpdir, 'test.yml'), 'r')
    assert f.read() == 'token: test2\n'
    f.close()

    #

# Generated at 2022-06-16 21:37:28.890338
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:37:46.565135
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:37:56.185834
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token = GalaxyToken()
    token.set('test_token')
    token.save()

    # Test if the token file is created
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

    # Test if the token file is readable
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == 'test_token'

    # Remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:38:00.772784
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:38:05.880911
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:38:18.731976
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Create a token
    token = GalaxyToken(token='test')

    # Set the file path
    token.b_file = temp_file

    # Save the token
    token.save()

    # Check if the file exists
    assert os.path.isfile(temp_file)

    # Read the file
    with open(temp_file, 'r') as f:
        config = yaml.load(f)

    # Check if the token is saved
    assert config['token'] == 'test'

    # Remove the temporary directory
    shutil

# Generated at 2022-06-16 21:38:21.516222
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:26.982383
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:38:29.658171
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:38:33.913394
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert token.get() == 'test_token'

    # Test with an invalid token
    token = KeycloakToken(access_token=None, auth_url='https://test.com')
    assert token.get() is None

# Generated at 2022-06-16 21:38:44.389350
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:29.491474
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}

# Generated at 2022-06-16 21:39:32.086126
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:39:44.087387
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError

    class MockResponse(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    class MockOpenURL(object):
        def __init__(self, data):
            self.data = data


# Generated at 2022-06-16 21:39:47.290673
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:50.059267
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:39:53.510773
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='http://test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:39:55.705688
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:40:01.910129
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:04.742595
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:11.840155
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('token: abcdefg')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()

    # Set the file path
    gt.b_file = os.path.join(tmpdir, 'test.yml')

    # Set the token
    gt.set('1234567')

    # Read the file
    f = open(os.path.join(tmpdir, 'test.yml'), 'r')
    data = yaml.load(f)

# Generated at 2022-06-16 21:40:21.120263
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:29.794910
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:32.713604
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:40:34.886787
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='12345', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kt.get() == '12345'


# Generated at 2022-06-16 21:40:44.386381
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token.yml')
    token = GalaxyToken()
    token.b_file = to_bytes(token_file)
    token.set('test_token')
    token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == 'test_token'
    shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:40:53.161672
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:55.576776
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:40:58.938197
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:41:04.646681
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the file path of the GalaxyToken object
    token.b_file = tmpfile.name

    # Set the token of the GalaxyToken object
    token.set('test_token')

    # Save the token
    token.save()

    # Read the token file
    with open(token.b_file, 'r') as f:
        config = yaml_load(f)

    # Check the token
    assert config['token'] == 'test_token'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:41:08.565741
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:41:21.283904
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:27.882288
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:35.471112
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/ansible_galaxy_token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.save()
    with open(token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token
    os.remove(token_file)

# Generated at 2022-06-16 21:41:38.233499
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:41.026324
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:41:43.515259
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:51.173334
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_token = 'test_token'


# Generated at 2022-06-16 21:41:53.918034
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:56.277234
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:41:58.468981
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:42:27.546679
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    token_file = os.path.join(temp_dir, 'token.yml')

    try:
        gt = GalaxyToken()
        gt.b_file = token_file
        gt.set('test_token')

        with open(token_file, 'r') as f:
            config = yaml_load(f)

        assert config['token'] == 'test_token'
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:42:31.058881
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:42:35.766954
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:42:44.581193
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url


# Generated at 2022-06-16 21:42:47.021804
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}

# Generated at 2022-06-16 21:42:57.234897
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import requests
    import responses
    from ansible.module_utils.urls import open_url

    # Mock the response from the keycloak server