

# Generated at 2022-06-16 21:33:01.345404
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:33:04.933304
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True, client_id='test_client_id')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:33:07.021848
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:33:15.965071
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.token = KeycloakToken(access_token='test_token', auth_url='test_url')

        @mock.patch('ansible.galaxy.token.open_url')
        def test_get_success(self, mock_open_url):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = '{"access_token": "test_access_token"}'
            mock_open_url.return_value = mock_resp


# Generated at 2022-06-16 21:33:19.388300
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'



# Generated at 2022-06-16 21:33:31.787275
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:44.330403
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('token: test')
    f.close()

    # Create an instance of GalaxyToken
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'), errors='surrogate_or_strict')

    # Test that the token is correctly read
    assert galaxy_token.get() == 'test'

    # Test that the token is correctly set
    galaxy_token.set('test2')
    assert galaxy_token.get() == 'test2'



# Generated at 2022-06-16 21:33:57.231332
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:07.775132
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:15.544075
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:31.217251
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'w')
    f.write('foo')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = to_bytes(os.path.join(tmpdir, 'test_GalaxyToken_save'))

    # Set the token
    gt.set('bar')

    # Check the content of the file
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'r')
    assert f.read() == 'token: bar\n'

   

# Generated at 2022-06-16 21:34:42.906966
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temporary file
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a GalaxyToken object with the temporary file
    token = GalaxyToken()
    token.b_file = to_bytes(tmp_file.name, errors='surrogate_or_strict')

    # Save a token
    token.set('test_token')

    # Read the temporary file
    with open(tmp_file.name, 'r') as f:
        config = yaml_load(f)

    # Check the token is saved
    assert config['token'] == 'test_token'

    # Remove the temporary file
    os.remove(tmp_file.name)

# Generated at 2022-06-16 21:34:47.180554
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:34:50.760246
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:34:53.732334
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:00.978035
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:04.321710
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:35:06.942954
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890')
    assert token.get() == '1234567890'


# Generated at 2022-06-16 21:35:17.968474
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()

    # Set the file path of the GalaxyToken object
    gt.b_file = os.path.join(tmpdir, 'test_file')

    # Set the token of the GalaxyToken object
    gt.set('test_token')

    # Save the GalaxyToken object
    gt.save()

    # Read the file

# Generated at 2022-06-16 21:35:21.980413
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:35:35.718951
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:35:40.587243
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:44.174949
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}

# Generated at 2022-06-16 21:35:46.562693
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:50.709144
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='dummy_token')
    assert token.headers() == {'Authorization': 'Bearer dummy_token'}


# Generated at 2022-06-16 21:35:53.169824
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo', auth_url='http://example.com')
    assert token.get() == 'foo'

# Generated at 2022-06-16 21:35:57.072691
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url', validate_certs=True, client_id='test_client_id')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:00.363931
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345', auth_url='https://example.com/auth/realms/myrealm/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:36:14.216899
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:17.259290
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='test_token', auth_url='https://test.com')
    assert kt.get() == 'test_token'


# Generated at 2022-06-16 21:36:34.308140
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:36:37.709493
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:48.129815
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:52.797534
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:36:55.972927
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:58.275058
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abcdefg')
    assert token.headers() == {'Authorization': 'Bearer abcdefg'}


# Generated at 2022-06-16 21:36:59.944670
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:03.701838
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:07.558461
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock
    from ansible.module_utils.urls import open_url

    class TestKeycloakToken(unittest.TestCase):
        def setUp(self):
            self.token = KeycloakToken(access_token='12345', auth_url='https://auth.example.com')

        @mock.patch('ansible.galaxy.token.open_url')
        def test_get(self, mock_open_url):
            mock_open_url.return_value.read.return_value = '{"access_token": "abcdef"}'
            self.assertEqual(self.token.get(), 'abcdef')

    unittest.main()

# Generated at 2022-06-16 21:37:10.125343
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:18.253467
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:37:27.524759
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests_mock
    from ansible.module_utils.urls import open_url

    # Mock the open_url call
    with requests_mock.Mocker() as m:
        m.post('https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
               text='{"access_token": "1234567890"}')
        token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
        assert token.get() == '1234567890'

# Generated at 2022-06-16 21:37:30.706410
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='foo')
    assert kt.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:37:33.635995
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:37:46.068361
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')

# Generated at 2022-06-16 21:37:57.694769
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import os.path
    import shutil
    import stat
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    token_file = os.path.join(tmpdir, 'token.yml')
    with open(token_file, 'w') as f:
        f.write('')
    # Change the mode of the file
    os.chmod(token_file, stat.S_IRUSR | stat.S_IWUSR)  # owner has +rw

    # Create an instance of GalaxyToken
    token = GalaxyToken()
    token.b_file = token_file

    # Call the method save
    token.set('test_token')
    token.save()

    # Check the

# Generated at 2022-06-16 21:38:01.851843
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:38:14.689853
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = os.path.join(tmpdir, 'test.yml')

    # Set the token
    gt.set('test_token')

    # Read the file
    with open(gt.b_file, 'r') as f:
        data = yaml.load(f)

    # Check the token
    assert data['token'] == 'test_token'

    # Remove the temporary directory

# Generated at 2022-06-16 21:38:19.042419
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set('test2')
    assert token.get() == 'test2'
    token.set('test3')
    assert token.get() == 'test3'

# Generated at 2022-06-16 21:38:25.787130
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:30.672795
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:38:32.959354
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:38:43.820755
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # create a temp dir
    tmpdir = tempfile.mkdtemp()
    # create a temp file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    # close the file
    os.close(fd)
    # remove the file
    os.remove(path)
    # create a token
    token = GalaxyToken()
    # set the token file
    token.b_file = path
    # set the token
    token.set('test_token')
    # save the token
    token.save()
    # read the token
    with open(path, 'r') as f:
        data = yaml.load(f)
    # remove the temp dir
    shutil.rmtree(tmpdir)
   

# Generated at 2022-06-16 21:38:46.656706
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo', auth_url='http://example.com')
    assert token.get() == 'foo'

# Generated at 2022-06-16 21:38:49.304710
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:39:01.726345
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:09.193250
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = tmpfile
    # Set the token
    token.set('test_token')

    # Read the token file
    with open(tmpfile, 'r') as f:
        config = yaml.load(f)

    # Check the token
    assert config['token'] == 'test_token'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 21:39:12.004386
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test', auth_url='http://test.com')
    assert token.get() == 'test'


# Generated at 2022-06-16 21:39:15.076566
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:39:17.492144
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('1234567890')
    assert token.get() == '1234567890'
    token.set(None)
    assert token.get() == None

# Generated at 2022-06-16 21:39:43.317310
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token_file = '/tmp/test_token'
    token = 'test_token'
    token_obj = GalaxyToken(token)
    token_obj.save()

    # Check if the token file is created
    assert os.path.isfile(token_file)

    # Check if the token is saved in the token file
    with open(token_file, 'r') as f:
        config = yaml_load(f)
        assert token == config['token']

    # Remove the token file
    os.remove(token_file)


# Generated at 2022-06-16 21:39:54.538501
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.yml'), 'w')
    f.write('token: test_token')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(os.path.join(tmpdir, 'test.yml'), errors='surrogate_or_strict')

    # Read the file
    config = token._read()

    # Check the token
    assert config['token'] == 'test_token'

    # Set the token
    token.set('new_token')

    # Read the file
    config = token._read

# Generated at 2022-06-16 21:40:08.197995
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    import filecmp

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Create a token
    token = GalaxyToken(token='12345')

    # Set the token file
    token.b_file = to_bytes(tmpfile.name, errors='surrogate_or_strict')

    # Set the token

# Generated at 2022-06-16 21:40:20.143758
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError

    # Mock the open_url method

# Generated at 2022-06-16 21:40:29.558390
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:40:31.183764
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:33.882826
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:36.990952
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:40:49.180473
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:01.001688
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:11.461627
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:41:15.772774
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:41:18.450983
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:25.472591
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = to_bytes(path, errors='surrogate_or_strict')

    # Save the token
    token.set('test_token')

    # Read the token from the file
    with open(token.b_file, 'r') as f:
        config = yaml_load(f)

    # Check the token
    assert config['token'] == 'test_token'

    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-16 21:41:27.020086
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:41:32.640660
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer None'}
    token.get()
    assert token.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-16 21:41:43.112788
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:46.132312
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_access_token'


# Generated at 2022-06-16 21:41:50.332468
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:41:57.090662
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    token_file = os.path.join(test_dir, 'test_token')
    token = GalaxyToken(token=None)
    token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token.set('test_token')
    assert token.get() == 'test_token'
    shutil.rmtree(test_dir)

# Generated at 2022-06-16 21:42:09.410453
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:42:12.172513
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:42:23.557474
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:28.752485
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:42:31.743131
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:42:34.676585
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'

# Generated at 2022-06-16 21:42:37.557232
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:42:45.584597
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:42:48.043449
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:42:57.897823
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    token_file = os.path.join(tmpdir, 'token.yml')
    open(token_file, 'w').close()

    # Create a GalaxyToken object
    token = GalaxyToken()
    token.b_file = token_file

    # Set the token
    token.set('test_token')

    # Save the token
    token.save()

    # Read the token
    with open(token_file, 'r') as f:
        config = yaml.load(f)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check that the token is saved correctly