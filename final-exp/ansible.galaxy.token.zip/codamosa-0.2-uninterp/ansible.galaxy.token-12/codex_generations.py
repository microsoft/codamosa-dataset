

# Generated at 2022-06-16 21:33:08.719863
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:13.221031
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a valid token
    token = KeycloakToken(access_token='123456789')
    assert token.get() == '123456789'

    # Test with an invalid token
    token = KeycloakToken(access_token=None)
    assert token.get() is None



# Generated at 2022-06-16 21:33:20.375551
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the token
    token.set('test_token')

    # Save the token
    token.save()

    # Read the token
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)

    # Check if the token is saved
    assert config.get('token') == 'test_token'

# Generated at 2022-06-16 21:33:21.871602
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:33:33.250388
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:45.458025
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:33:57.623238
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:08.084017
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a token file
    token_file = '/tmp/test_galaxy_token'
    token_file_b = to_bytes(token_file, errors='surrogate_or_strict')
    open(token_file_b, 'w').close()
    os.chmod(token_file_b, S_IRUSR | S_IWUSR)  # owner has +rw

    # Create a token
    token = GalaxyToken()
    token.set('test_token')

    # Save the token
    token.save()

    # Read the token
    with open(token_file_b, 'r') as f:
        config = yaml_load(f)

    # Check if the token is saved correctly
    assert config['token'] == 'test_token'

    # Remove the token file

# Generated at 2022-06-16 21:34:10.653641
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer 1234567890'


# Generated at 2022-06-16 21:34:24.150025
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:36.304489
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:34:37.720839
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abc123')
    assert token.headers() == {'Authorization': 'Bearer abc123'}


# Generated at 2022-06-16 21:34:40.578614
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://auth.example.com')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:34:44.140704
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:34:47.960522
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:34:50.947189
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:34:53.425899
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}

# Generated at 2022-06-16 21:34:56.108253
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:35:09.018768
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:18.934514
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:37.815720
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:35:49.373871
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:35:52.355301
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer test_token'


# Generated at 2022-06-16 21:35:55.767940
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'
    token.set(None)
    token.save()
    assert token.get() is None

# Generated at 2022-06-16 21:35:57.454558
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:35:59.756451
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'

# Generated at 2022-06-16 21:36:13.578756
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:16.891190
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert kt.get() == 'test_access_token'


# Generated at 2022-06-16 21:36:21.115074
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:36:22.523084
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    token.save()
    assert token.get() == 'test'

# Generated at 2022-06-16 21:36:33.370820
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    token.get()
    assert token._token == '12345'

# Generated at 2022-06-16 21:36:36.285617
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:38.564199
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:36:48.935119
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:36:51.410631
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:36:53.818215
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:36:56.508843
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='http://example.com')
    assert token.get() == '1234567890'

# Generated at 2022-06-16 21:36:58.845316
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:37:04.192276
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123456789', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert token.get() == '123456789'


# Generated at 2022-06-16 21:37:06.641826
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:37:17.809442
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:21.173146
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:37:23.976013
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abc')
    assert token.headers() == {'Authorization': 'Bearer abc'}


# Generated at 2022-06-16 21:37:26.969668
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:37:31.054438
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with no token
    token = KeycloakToken()
    assert token.get() is None

    # Test with a token
    token = KeycloakToken(access_token='test')
    assert token.get() == 'test'

# Generated at 2022-06-16 21:37:36.193657
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://example.com/auth/realms/master/protocol/openid-connect/token')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:37:40.991718
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert kt.get() == '1234567890'


# Generated at 2022-06-16 21:37:43.904958
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123456789')
    assert token.get() == '123456789'


# Generated at 2022-06-16 21:37:56.344816
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234567890', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-16 21:38:01.363624
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo', auth_url='https://example.com')
    assert token.headers() == {'Authorization': 'Bearer foo'}


# Generated at 2022-06-16 21:38:43.485445
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:38:55.679978
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:06.313943
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    import yaml
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'w')
    f.write('test')
    f.close()

    # Create a GalaxyToken object
    gt = GalaxyToken()
    gt.b_file = os.path.join(tmpdir, 'test_GalaxyToken_save')

    # Save the GalaxyToken object
    gt.save()

    # Check the file
    f = open(os.path.join(tmpdir, 'test_GalaxyToken_save'), 'r')
    data = yaml.load(f)
    f.close

# Generated at 2022-06-16 21:39:17.721618
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:26.694978
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:39:29.707023
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer foo'


# Generated at 2022-06-16 21:39:32.248621
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:39:35.811841
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:39:39.923625
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-16 21:39:48.509471
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')

# Generated at 2022-06-16 21:40:17.848483
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='12345')
    assert token.headers() == {'Authorization': 'Bearer 12345'}


# Generated at 2022-06-16 21:40:23.780359
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config = {'token': 'test_token'}
    token.save()

    with open(token.b_file, 'r') as f:
        config = yaml_load(f)

    assert config == {'token': 'test_token'}
    os.remove(token.b_file)

# Generated at 2022-06-16 21:40:28.612995
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}


# Generated at 2022-06-16 21:40:36.939373
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'galaxy_token')
    try:
        token = GalaxyToken()
        token.b_file = temp_file
        token.set('test_token')
        token.save()
        with open(temp_file, 'r') as f:
            assert yaml_load(f) == {'token': 'test_token'}
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-16 21:40:39.994115
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://example.com')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:44.134770
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='https://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:40:47.732940
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890', auth_url='https://example.com/auth')
    assert token.headers() == {'Authorization': 'Bearer 1234567890'}


# Generated at 2022-06-16 21:40:59.648700
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-16 21:41:02.280855
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set(None)
    assert token.get() is None

# Generated at 2022-06-16 21:41:04.448698
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()
    assert token.get() == 'test_token'

# Generated at 2022-06-16 21:41:55.094316
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.common.yaml import yaml_load, yaml_dump
    from ansible.module_utils.urls import open_url
    from ansible.galaxy.token import GalaxyToken

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_galaxy_token'), 'w')
    f.close()

    # Create a GalaxyToken object
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = to_bytes(os.path.join(tmpdir, 'test_galaxy_token'), errors='surrogate_or_strict')

    # Set the token
    galaxy_token.set

# Generated at 2022-06-16 21:41:57.764118
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:42:09.931079
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.write('Hello World')
    f.close()

    # Create a GalaxyToken object
    token = GalaxyToken()

    # Set the file path
    token.b_file = to_bytes(os.path.join(tmpdir, 'test_file'), errors='surrogate_or_strict')

    # Set the token
    token.set('test_token')

    # Read the file
    f = open(os.path.join(tmpdir, 'test_file'), 'r')
    data = f.read()
    f.close()



# Generated at 2022-06-16 21:42:13.216387
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='http://test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:42:15.287557
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo', auth_url='http://example.com')
    assert token.get() == 'foo'

# Generated at 2022-06-16 21:42:19.006149
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert token.get() == 'test_token'


# Generated at 2022-06-16 21:42:22.010595
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert token.get() == 'test_access_token'


# Generated at 2022-06-16 21:42:25.538565
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='12345', auth_url='http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.get() == '12345'


# Generated at 2022-06-16 21:42:29.434372
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-16 21:42:32.395079
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_access_token')
    assert token.headers() == {'Authorization': 'Bearer test_access_token'}
