

# Generated at 2022-06-10 23:56:52.855084
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-10 23:57:03.623375
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes('/tmp/ansible_galaxy_token_test.txt', errors='surrogate_or_strict')
    open(b_file, 'w').close()
    galaxy = GalaxyToken()
    galaxy._config = {'token': 'test_token'}
    galaxy.b_file = b_file

    galaxy.save()
    content = None
    with open(b_file, 'r') as f:
        content = yaml_load(f)

    assert content == {'token': 'test_token'}
    os.remove(b_file)



# Generated at 2022-06-10 23:57:06.863972
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    KCT = KeycloakToken('refresh_token', 'https://auth.dev.cloud.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert (KCT.get() is not None)


# Generated at 2022-06-10 23:57:09.674912
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='foo')
    expected = {'Authorization': 'Bearer None'}
    assert token.headers() == expected



# Generated at 2022-06-10 23:57:15.465833
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.galaxy import __file__ as galaxy_path
    galaxy_dir = os.path.dirname(galaxy_path)
    galaxy_token_file_path = os.path.join(galaxy_dir, '.ansible_galaxy_token')
    token_file_path = os.path.join(galaxy_dir, '.galaxy_token_test')
    galaxy_token_file_exists = os.path.exists(galaxy_token_file_path)
    token_file_exists = os.path.exists(token_file_path)
    if galaxy_token_file_exists:
        # remove token file if exists
        os.remove(galaxy_token_file_path)

# Generated at 2022-06-10 23:57:18.982910
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # create KeycloakToken
    kc_token = KeycloakToken('access_token', 'auth_url')

    # Mock payload for testing
    kc_token._form_payload = lambda : 'payload'

    # Mock response (TODO: is this a suitable mock?)
    kc_token.resp = lambda s: s

    assert kc_token.get() == 'payload'



# Generated at 2022-06-10 23:57:30.783089
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''
    This function tests the get method of the KeycloakToken class to ensure
    it properly decodes the access_token and returns it.
    '''
    # Create a KeycloakToken with a token to access the test mock server.

# Generated at 2022-06-10 23:57:43.400937
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Import here to avoid circular imports
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import requests
    import mock
    import os.path

    class MockResponse(object):
        def __init__(self, status_code, reason, data):
            self.status_code = status_code
            self.reason = reason
            self.data = data

# Generated at 2022-06-10 23:57:49.152589
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    gtoken = GalaxyToken()
    gtoken.config['token'] = '12345678901234567890123456789012345678901234567890'
    gtoken.save()

    assert os.path.isfile(gtoken.b_file) is True, 'Galaxy token file does not exist'

# Generated at 2022-06-10 23:57:54.159848
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = '00000000-0000-0000-0000-000000000000'
    auth_url = 'https://foo.bar'
    ktk = KeycloakToken(access_token=access_token, auth_url=auth_url)
    assert ktk.get() is None
    ktk._token = 'token'
    assert ktk.get() == 'token'


# Generated at 2022-06-10 23:58:09.329298
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    from ansible.module_utils.six import BytesIO
    b_file = to_bytes(tempfile.mktemp())

# Generated at 2022-06-10 23:58:17.506527
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token_val = {"token":"faketoken"}
    token.set(token_val)
    token.save()
    token2 = GalaxyToken()
    token2_val = token2.get()
    assert token_val is not None
    assert token_val == token2_val
    os.remove(C.GALAXY_TOKEN_PATH)

test_GalaxyToken_save()

# Generated at 2022-06-10 23:58:21.740800
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken('faketoken', auth_url='https://sso.redhat.com/auth/realms/ansible/protocol/openid-connect/token',
                       validate_certs=True)
    assert kt.headers() == {'Authorization': 'Bearer abc'}

# Generated at 2022-06-10 23:58:33.454353
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          access_token="123456789",
                          client_id='cloud-services')
    token.get()

# Generated at 2022-06-10 23:58:40.648265
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with not token defined
    a = KeycloakToken()
    assert(a.get() is None)

    # Test with a token defined
    access_token = '123456'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    a = KeycloakToken(access_token, auth_url)
    assert(a.get() is not None)



# Generated at 2022-06-10 23:58:50.868797
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os

    def is_file_exist(file_path):
        return os.path.isfile(file_path)

    def get_file_size(file_path):
        statinfo = os.stat(file_path)
        return statinfo.st_size

    token = '12345'
    file_path = "~/ansible_test_token"

    galaxy_token = GalaxyToken(token)
    if not is_file_exist(file_path):
        galaxy_token.save()

    assert(token == galaxy_token.get())

    # When save() is called again, size of the file will be increased.
    size_of_original_file = get_file_size(file_path)
    galaxy_token.save()

# Generated at 2022-06-10 23:58:53.906475
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloakToken = KeycloakToken(access_token="test_token", auth_url="test_url", validate_certs=True, client_id='test_client_id')
    assert keycloakToken.headers()['Authorization'] == 'Bearer test_token'

# Generated at 2022-06-10 23:58:58.290338
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    k = KeycloakToken(access_token=base64.b64encode(b'1234567890'), auth_url='https://google.com/auth/api', validate_certs=True, client_id='test')
    assert(k.get().startswith('eyJhb'))


# Generated at 2022-06-10 23:59:10.265516
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-10 23:59:22.317863
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    action = 'Opened'
    if not os.path.isfile(b_file):
        # token file not found, create and chmod u+rw
        open(b_file, 'w').close()
        os.chmod(b_file, S_IRUSR | S_IWUSR)  # owner has +rw
        action = 'Created'
    with open(b_file, 'r') as f:
        config = yaml_load(f)
    display.vvv('%s %s' % (action, to_text(b_file)))

# Generated at 2022-06-10 23:59:43.323822
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    from unittest import mock

    # suppress warning message by 'requests'
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    def run_test(response_body, expected):

        with mock.patch('requests.session') as mock_session:
            mock_session().request.return_value.read.return_value = response_body

            kt = KeycloakToken("auth_url", False, None)
            kt.access_token = "some_token"
            token = kt.get()
            assert token == expected

    # test response_body
    # parse it as JSON string
    # and get token attribute

# Generated at 2022-06-10 23:59:47.492174
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    my_token = KeycloakToken()
    my_token.set('my_token')
    print(my_token.headers())
    # Output: {'Authorization': 'Bearer my_token'}


# Generated at 2022-06-10 23:59:53.643785
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''
    tests method get of class KeycloakToken
    '''
    token = KeycloakToken('fake_access_token', 'https://my_auth_url/auth/realms/my_realm/protocol/openid-connect/token', False)

    token_string = token.get()

    assert token_string == 'my_fake_token'

# Generated at 2022-06-10 23:59:57.047449
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected = {'Authorization': 'Bearer some_token'}
    token = KeycloakToken(access_token='some_token')
    assert token.headers() == expected


# Generated at 2022-06-11 00:00:08.954892
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import unittest.mock as mock
    import json

    class Response:
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    class MyMock(mock.MagicMock):
        def __init__(self, *args, **kwargs):
            super(MyMock, self).__init__(*args, **kwargs)
            self.response = Response(json.dumps({"access_token": "a1"}).encode())

        def open_url(self, url, data=None, validate_certs=True, method='GET', http_agent=None):
            return self.response

    token_data = 'test_token'
    token_url = 'auth.example.org'
    mocked_object

# Generated at 2022-06-11 00:00:18.025682
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    file_path = "./token_test_file"
    if os.path.isfile(file_path):
        os.remove(file_path)

    token = GalaxyToken()
    token.b_file = file_path

    # open without existing file
    token.save()
    assert os.path.isfile(file_path)

    # open with existing file
    token.save()
    assert os.path.isfile(file_path)

    # delete file
    os.remove(file_path)
    assert not os.path.isfile(file_path)



# Generated at 2022-06-11 00:00:20.207615
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('some_refresh_token')
    assert token.get() == 'some_access_token'


# Generated at 2022-06-11 00:00:33.118979
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import os
    import json
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.request import Request, urlopen
    from ansible.module_utils.six.moves import StringIO

    class MockRequest(Request):
        headers = {}

        def __init__(self, url, data=None, headers={}, origin_req_host=None, unverifiable=False, method=None):
            Request.__init__(self, url, data=data, headers=headers, origin_req_host=origin_req_host, unverifiable=unverifiable)
            self.method = method
            self.add_

# Generated at 2022-06-11 00:00:47.662120
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # mock the real open_url
    import tempfile
    mock_json = {'access_token': 'mock_token'}
    mock_resp = tempfile.TemporaryFile("w+b")
    mock_resp.write(bytes(json.dumps(mock_json), 'utf-8'))
    mock_resp.seek(0)

    orig_open_url = open_url
    open_url = lambda *argv, **kwargs: mock_resp

    kct = KeycloakToken(access_token='mock_token', auth_url='mock_url')
    assert kct.get() == 'mock_token'
    assert kct.headers() == {'Authorization': 'Bearer mock_token'}

    # restore the original open_url
    open_url = orig_open_url

# Generated at 2022-06-11 00:00:49.688348
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('test', auth_url='test')
    assert token.get() == 'test'


# Generated at 2022-06-11 00:01:13.275421
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # init galaxy token
    galaxy_token = GalaxyToken(token = "test_save")
    # get the token which should be None
    token = galaxy_token.get()
    assert token is None
    # save the galaxy token
    galaxy_token.save()
    # get the token which should return the one we had set
    token = galaxy_token.get()
    assert token == "test_save"

# Generated at 2022-06-11 00:01:21.298312
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_path = C.GALAXY_TOKEN_PATH
    galaxy_token_path_unit_test = '/tmp/ansible-galaxy-token.yml'
    C.GALAXY_TOKEN_PATH = galaxy_token_path_unit_test
    galaxy_token = GalaxyToken()
    sample_token = 'abcdefghijklmnopqrstuvwxyz123456'
    galaxy_token.set(sample_token)
    galaxy_token_file = open(galaxy_token_path_unit_test, 'r')
    galaxy_token_content = galaxy_token_file.read()
    galaxy_token_file.close()
    os.remove(galaxy_token_path_unit_test)
    C.GALAXY_TOKEN_PATH = galaxy_token_path


# Generated at 2022-06-11 00:01:31.088222
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = "sample token"
    expected_token_file_content = "token: sample token"
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    # now read the file and make sure it contains the correct data
    with open(galaxy_token.b_file,'r') as fd:
        # remove newline character from expected content
        assert expected_token_file_content == fd.read().strip()
    os.unlink(galaxy_token.b_file)

# Generated at 2022-06-11 00:01:36.711380
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token = GalaxyToken()
    # verify the file created and token saved
    test_token.set('test_token')
    assert test_token.get() == 'test_token'
    # verify the file modified and token saved
    test_token.set('test_token_modified')
    assert test_token.get() == 'test_token_modified'

# Generated at 2022-06-11 00:01:39.816631
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k_token = KeycloakToken('abc')
    assert 'Authorization' in k_token.headers()
    assert 'abc' in k_token.headers()['Authorization']

# Generated at 2022-06-11 00:01:40.216907
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    pass

# Generated at 2022-06-11 00:01:50.565265
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    from ansible.galaxy.token import GalaxyToken

    token_file = tempfile.mkstemp(prefix="ansible_galaxy_token_",
                                  suffix="_unittest")
    galaxy_token = GalaxyToken(token_file[1])
    test_token = "thisismydummytoken"
    galaxy_token.set(test_token)

    # check if token is correctly set
    assert galaxy_token.get() == test_token

    # read the file manuel, to see if it was correctly saved
    token_file_content = ""
    with open(token_file[1], 'r') as f:
        token_file_content = yaml_load(f)

    assert token_file_content["token"] == test_token


# Generated at 2022-06-11 00:01:54.901983
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='test', auth_url='test', validate_certs=True)
    h = kt.headers()
    assert h == {'Authorization': 'Bearer None'}

# Generated at 2022-06-11 00:02:05.409838
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create test token file
    token_file = os.path.expanduser('~') + '/.ansible/tmp'
    test_directory = os.path.dirname(token_file)
    if not os.path.exists(test_directory):
        os.makedirs(test_directory)
    open(token_file, 'a').close()

    # Create test content of token file
    test_content = {
        'token': 'test'
    }

    # Save test content to token file
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = token_file
    galaxy_token.config = test_content
    galaxy_token.save()

    # Read content of token file and check if it is equals to test content

# Generated at 2022-06-11 00:02:14.852926
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.galaxy.test.test_galaxy import MockResp

    client_id = 'test-client-id'
    access_token = 'test-access-token'
    auth_url = 'test-auth-url'
    sut = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id)

    #########################################################
    # Test 1: Get token from cache

    # Setup
    expected = 'abc123'
    # Execute
    sut._token = expected
    actual = sut.get()

    # Verify/Assert
    assert actual == expected

    #########################################################
    # Test 2: Refresh token - success

    # Setup
    data = {'access_token':'123abc'}
    # Execute
    actual = sut

# Generated at 2022-06-11 00:03:02.170311
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import tempfile
    import hashlib
    import shutil

    with tempfile.NamedTemporaryFile() as temp_file:
        temp_path = temp_file.name


# Generated at 2022-06-11 00:03:10.606744
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    kc_token = KeycloakToken(access_token='123456789abcdef0',
                             auth_url='https://10.0.0.1/auth/realms/somerealm/protocol/openid-connect/token')

# Generated at 2022-06-11 00:03:15.227744
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', access_token='c8569b1a-3106-4fdd-b2f2-8de00b71f893')
    assert 'Bearer' in keycloak_token.get()

# Generated at 2022-06-11 00:03:22.727873
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # For testing to get around http
    class MockResponse():
        def read(self):
            return json.dumps({'access_token': 'fake_token'}).encode('utf-8')
    # Setup
    token = KeycloakToken(access_token='fake_token', auth_url='http://foo.com')
    token.open_url = lambda *args, **kwargs: MockResponse()

    # Test
    assert token.headers() == {'Authorization': 'Bearer fake_token'}

# Generated at 2022-06-11 00:03:30.484365
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_path = 'tests/galaxy_token'
    galaxy_token = GalaxyToken()
    galaxy_token.set('This token is set in the unit test')
    galaxy_token.save()
    token_file = open(galaxy_token_path).read()
    token_dict = yaml_load(token_file)
    assert token_dict == {'token': 'This token is set in the unit test'}
    # Cleanup test file after test is complete
    os.remove(galaxy_token_path)

# Generated at 2022-06-11 00:03:37.100638
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # save a simple key-value in the galaxy_token_file
    galaxy_token_file = '/tmp/token.yml'
    token = GalaxyToken()
    token.config = {'token': 'BogusToken'}
    token.b_file = to_bytes(galaxy_token_file)
    token.save()

    # read and check the galaxy_token_file
    with open(galaxy_token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == 'BogusToken'

# Generated at 2022-06-11 00:03:49.089908
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = "https://auth.example.com/token"
    access_token = "23456789"
    client_id = "cloud-services"
    token_class = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id)

# Generated at 2022-06-11 00:03:49.780464
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    pass

# Generated at 2022-06-11 00:03:59.732512
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """
    Unit tests for GalaxyToken.save method
    """
    import tempfile
    import shutil
    import os.path
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 00:04:12.674752
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(
        access_token='a5f0b539-13f7-4f9b-8fa2-4af4a4c4f4e4',
        auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
        validate_certs=True,
        client_id='cloud-services')

    token = keycloak_token.get()

# Generated at 2022-06-11 00:05:02.731514
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    def mock_open_url(*args, **kwargs):
        return mockresp

    mockresp = MagicMock(spec=HTTPResponse, read=lambda: b'{"access_token":"foo_access_token"}')
    with patch.object(GalaxyToken, 'open_url', side_effect=mock_open_url):
        auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
        sut = KeycloakToken(access_token='foo_rs_refresh_token', auth_url=auth_url)
        assert sut.get() == 'foo_access_token'



# Generated at 2022-06-11 00:05:07.784773
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    t = KeycloakToken(access_token="dummy_access_token", auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert t.get() == 'dummy_access_token'

# Generated at 2022-06-11 00:05:14.097133
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = 'test_GalaxyToken_save'
    token = 'sometokennow'
    token_obj = GalaxyToken(token)

    assert(not os.path.exists(b_file))
    token_obj.save()
    assert(os.path.exists(b_file))

    # clean up
    os.unlink(b_file)

# Generated at 2022-06-11 00:05:17.353455
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    my_token = KeycloakToken('a_token', 'https://example.com')
    assert my_token.headers() == {'Authorization': 'Bearer a_token'}

# Generated at 2022-06-11 00:05:22.520144
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO: Create mock urlopen to return token
    auth_url = 'https://cloud.redhat.com/api/token/refresh'
    access_token = 'test/testrefreshtoken/test/testrefreshtoken/test/testrefreshtoken'
    token = KeycloakToken(auth_url=auth_url, access_token=access_token)
    expected = 'test/testrefreshtoken/test/testrefreshtoken/test/testrefreshtoken'
    result = token.get()
    assert token._token == expected
    assert result == expected

# Generated at 2022-06-11 00:05:26.726738
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'
    token.set('new_token')
    assert token.get() == 'new_token'

# Generated at 2022-06-11 00:05:37.899979
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:05:41.369235
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'access_token_value'
    auth_url = "https://auth_url.com/token"
    keycloak_token = KeycloakToken(access_token, auth_url)
    assert keycloak_token.get() == 'access_token_value'

# Generated at 2022-06-11 00:05:50.658505
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:06:01.299852
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ''' test_KeycloakToken_get
    '''
    auth_url = "https://auth.test.com"
    access_token = "access_token"
    client_id = "test_client_id"
    token = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id)

    # execute
    token._token = None
    token._form_payload = MagicMock()
    token._form_payload.return_value = "mock_payload"
    token.get()

    # assert
    token._form_payload.assert_called_with()
    assert token._token == "mock_token"
