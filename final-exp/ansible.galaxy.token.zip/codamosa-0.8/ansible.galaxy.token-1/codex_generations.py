

# Generated at 2022-06-10 23:56:42.416426
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Test that headers returns the correct value
    kct = KeycloakToken(access_token="test_access_token",
                        auth_url="test_auth_url",
                        validate_certs=True,
                        client_id="test_client_id")
    kct._token = "test_token"
    assert kct.headers() == {'Authorization': 'Bearer test_token'}



# Generated at 2022-06-10 23:56:44.418714
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kc_token = KeycloakToken('a-token-value')
    assert kc_token.get() == 'a-token-value'

# Generated at 2022-06-10 23:56:48.880612
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='test_access_token',
                        auth_url='test_url',
                        validate_certs=True,
                        client_id=None)
    assert kct.get() == 'test_token'

# Generated at 2022-06-10 23:56:59.774401
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token = 'test_access_token'
    test_auth_url = 'https://test_auth_url:8080/auth/realms/test_realm/protocol/openid-connect/token'
    test_validate_certs = True
    test_client_id = 'test_client'
    kct = KeycloakToken(test_token, test_auth_url, test_validate_certs, test_client_id)
    assert('Authorization' in kct.headers())
    assert(kct.headers()['Authorization'] == 'Bearer test_access_token')

# Generated at 2022-06-10 23:57:10.363773
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-10 23:57:15.964839
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-10 23:57:28.126829
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ca_path = os.path.join(os.path.dirname(__file__), "fixtures", "cacert.pem")
    token = KeycloakToken(access_token='offline-token',
                          auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          validate_certs=ca_path)
    token.get()

# Generated at 2022-06-10 23:57:29.709406
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='1234566789', auth_url='https://auth_url.com')
    assert token.get() == 'my_token'

# Generated at 2022-06-10 23:57:36.921926
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # assumed settings
    access_token = '1234567890'
    auth_url = 'https://foo.bar.com/auth/realms/redhat_subscriptions/protocol/openid-connect/token'
    client_id = 'cloud-services'

    # test without access_token
    kt = KeycloakToken()
    kt.get()
    assert kt._token is None, "access_token is None"

    # test with access_token
    kt = KeycloakToken(access_token, auth_url)
    kt.get()
    assert kt._token is not None, "access_token is not None"
    assert kt.get() == kt._form_payload(), \
        "token is not stored properly"

# Generated at 2022-06-10 23:57:47.244261
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():

    kt = KeycloakToken(access_token="access_token", auth_url='https://auth.url')
    # check that the function returns a dict with the expected header
    f = kt.headers()
    assert isinstance(f, dict)
    assert f['Authorization'] == 'Bearer access_token'

    # check that a token previously obtained is returned if present
    kt._token = "the_old_token"
    f = kt.headers()
    assert isinstance(f, dict)
    assert f['Authorization'] == 'Bearer the_old_token'

    # check that the function returns a dict with the expected header
    kt = KeycloakToken(access_token="access_token_with_spaces", auth_url='https://auth.url')
    f = kt.headers()

# Generated at 2022-06-10 23:58:01.676629
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='faketoken')
    token.get()

# Generated at 2022-06-10 23:58:11.196274
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'foo'
    auth_url = 'http://127.0.0.1/bar'
    user_agent_string = 'UserAgent'
    client_id = 'client'

    token = KeycloakToken(access_token=access_token,
                          auth_url=auth_url,
                          validate_certs=False,
                          client_id=client_id)

    # mock open_url() function

# Generated at 2022-06-10 23:58:25.283763
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import unittest
    import mock
    import responses


# Generated at 2022-06-10 23:58:37.856737
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import copy
    import json

    from ansible.module_utils.common.yaml import yaml_load
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # read the test_keycloak_token.yml file
    __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
    with open(os.path.join(__location__, 'test_keycloak_token.yml'), 'rb') as f:
        data = yaml_load(f)

    # get test cases from the test_keycloak_token.yml file
    cases = data.get('cases')


# Generated at 2022-06-10 23:58:43.661438
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import mock

    class KeycloakToken_Test(unittest.TestCase):
        '''Unit test for method get of class KeycloakToken.'''

        def setUp(self):
            self._real_open_url = open_url
            # mock open_url method
            open_url = mock.Mock()
            self.mock_resp = mock.Mock()
            self.mock_resp.read = mock.Mock(return_value="read return value")
            self.mock_resp.close = mock.Mock()
            self.mock_resp.getcode = mock.Mock(return_value=200)
            open_url.return_value = self.mock_resp

        def tearDown(self):
            open_url = self._real_open_url

       

# Generated at 2022-06-10 23:58:47.446004
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='1234567890')
    expected = {'Authorization': 'Bearer 1234567890'}
    actual = token.headers()
    assert actual == expected


# Generated at 2022-06-10 23:58:56.279610
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    # Arrange
    kct = KeycloakToken(auth_url='https://foo.bar/auth/realms/baz/protocol/openid-connect/token',
                        access_token='abcdefghijklmnopqrstuvwxyz',
                        validate_certs=True)

    # Arrange - mock open_url
    open_url_called = False
    args = {}

    def mock_open_url(*args, **kwargs):
        nonlocal open_url_called, args
        open_url_called = True
        args = {'url': args[0], 'data': args[1], 'headers': kwargs['headers']}
        response = FakeResponse()

# Generated at 2022-06-10 23:59:00.089774
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(None)
    # Check if correct value is returned when kt._token is None
    assert kt.headers() == {'Authorization': 'Bearer None'}

    # Check if correct value is returned when kt._token is set
    kt._token = 'dummy_token'
    assert kt.headers() == {'Authorization': 'Bearer dummy_token'}

# Generated at 2022-06-10 23:59:10.265822
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token_url = 'https://auth.ansible.com/token'
    token = 'my_token' 
    validate_certs = True
    client_id = 'my_client_id'

    sub_object = KeycloakToken(token, token_url, validate_certs, client_id)
    assert(sub_object.access_token==token)
    assert(sub_object.auth_url==token_url)
    assert(sub_object.validate_certs==validate_certs)
    assert(sub_object.client_id==client_id)
    assert(sub_object.get()=='access_token')
    headers = sub_object.headers()
    assert(headers['Authorization']=='Bearer access_token')

# Generated at 2022-06-10 23:59:22.317923
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-10 23:59:30.700331
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    #_token no necesita valores para poder hacer la prueba
    class_object = KeycloakToken(access_token='', auth_url='', validate_certs=False, client_id=None)

    assert class_object._token == None, "Valor inicial incorrecto"

    #TODO: Revisar la forma de pasarle el json.load
    #result = class_object.get()
    #assert class_object._token == ""


# Generated at 2022-06-10 23:59:33.595623
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('abcdefghijklmnopqrstuvwxyz')
    assert token.headers()['Authorization'] == 'Bearer None'


# Generated at 2022-06-10 23:59:45.586907
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """ """

    # Set the following 'global' variables to allow
    # return data to be checked.

    # Use of a mutable will allow use of side_effect
    # to test various scenarios.
    _token_call_count = []

    # The tokens returned from the Keycloak server
    _auth_response_data = []

    # Test data for the token passed to the Keycloak server
    _payload_data = []

    # Tested method.
    def _token_get():

        if _token_call_count[0] == 0:
            _token_call_count[0] = _token_call_count[0] + 1

            return _auth_response_data[0]

        return _auth_response_data[1]

    # Mock the OpenURL method.

# Generated at 2022-06-10 23:59:58.141893
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from mock import patch, call
    from ansible.galaxy.token import KeycloakToken
    payload = ("grant_type=refresh_token&client_id=cloud-services&refresh_token=offline_token_123")
    auth_url = "https://auth.url"
    token_value = "1234567890"

    # test - online token found in config
    with patch("ansible.galaxy.token.open_url") as open_url_mock:
        open_url_mock.return_value.read.return_value = to_bytes(json.dumps(dict(access_token=token_value)))
        token = KeycloakToken("offline_token_123", auth_url)
        assert token.get() == token_value
        open_url_mock.assert_called_

# Generated at 2022-06-11 00:00:09.841521
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = 'http://test.com'
    client_id = 'test_client_id'
    access_token = 'test_access_token'
    validate_certs = True

    test_urlopen = lambda *args, **kwargs: args[0]
    test_json_load = lambda x: x

    # Test 1: Happy path
    with mock.patch('ansible.galaxy.token.open_url', test_urlopen):
        with mock.patch('ansible.galaxy.token.json.loads', test_json_load):
            token = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id, validate_certs=validate_certs)
            token.get()
            assert token._token == access_token

# Generated at 2022-06-11 00:00:15.608469
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(auth_url="https://sso.redhat.com/auth/realms/redhat/protocol/openid-connect/token",
                                   access_token="f6d85f6c-e4a4-4ca4-a7e4-c2eb0f88e8a8")
    keycloak_token.get()

# Generated at 2022-06-11 00:00:19.495918
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO: mock out open_url
    KC = KeycloakToken(access_token='MOCK_TOKEN', auth_url=None)
    token = KC.get()
    assert token == 'MOCK_TOKEN'



# Generated at 2022-06-11 00:00:22.811360
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_obj = KeycloakToken(access_token='token')
    assert test_obj.headers() == {'Authorization': 'Bearer token'}

# Generated at 2022-06-11 00:00:29.437680
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(None, 'https://keycloak_auth_url', False)
    assert keycloak_token.get() is None

    keycloak_token = KeycloakToken('fake_offline_token', 'https://keycloak_auth_url', False)
    assert keycloak_token.get() == 'fake_access_token'

# Generated at 2022-06-11 00:00:33.821455
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token="dummytoken", auth_url="http://dummyurl.com")
    assert token.get() == None
    # TODO: Test the case when data is not None
    # TOdO: Test the case when data is empty


# Generated at 2022-06-11 00:00:46.273391
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass



# Generated at 2022-06-11 00:00:54.683221
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    os.chdir('test/unit/galaxy/static')

    galaxy_token_path = './galaxy.token.test'
    b_galaxy_token_path = to_bytes(galaxy_token_path, errors='surrogate_or_strict')

    token_file_exists = os.path.isfile(b_galaxy_token_path)

    # create a test token file
    galaxy_token_file = open(b_galaxy_token_path, 'w')
    galaxy_token_file.write('token: galaxy_token')
    galaxy_token_file.close()
    os.chmod(b_galaxy_token_path, S_IRUSR | S_IWUSR)  # owner has +rw

    # test whether the method 'save' of the class GalaxyToken will overwrite the

# Generated at 2022-06-11 00:01:08.497297
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:01:14.280710
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token_string'
    new_token = GalaxyToken(token)
    new_token.save()
    config = new_token._read()
    assert config['token'] == token
    # remove the token file
    os.remove(C.GALAXY_TOKEN_PATH)
    assert not os.path.isfile(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-11 00:01:21.013996
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """
    KeycloakToken.get() will perform a POST request to self.auth_url that sends a refresh_token to
    obtain another token. Returns a token.
    """
    import requests_mock
    with requests_mock.Mocker() as m:
        m.post('http://www.example.com/token/refresh',
               text=json.dumps({
                   'access_token': 'thetoken',
                   'refresh_token': 'thetoken'}))
        kct = KeycloakToken(access_token='thetoken', auth_url='http://www.example.com/token/refresh')
        assert kct.get() == 'thetoken'

# Generated at 2022-06-11 00:01:33.894295
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    input_json = '''{
        "access_token": "eyJraWQiOiJw",
        "expires_in": 28800,
        "refresh_expires_in": 604800,
        "refresh_token": "eyJraWQiOiJw",
        "token_type": "bearer",
        "id_token": "eyJraWQiOiJw",
        "not-before-policy": 1602687306,
        "session_state": "d76e8d1b-ef0f-4d7c-9884-e2fa2b480079"
    }'''
    with open("/tmp/token.out", "w") as fout:
        fout.write(input_json)
        fout.close()

    k

# Generated at 2022-06-11 00:01:42.886815
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create temporary file for testing
    import tempfile

    temp_dir = tempfile.mkdtemp()

    test_file = os.path.join(temp_dir, 'test.yaml')

    with open(test_file, 'w') as f:
        f.write('foo')

    token = GalaxyToken(token='bar')

    token.set(token='bar')

    assert os.path.isfile(test_file)
    assert token.get() == 'bar'

    # Cleanup
    os.unlink(test_file)
    os.rmdir(temp_dir)

# Generated at 2022-06-11 00:01:45.949728
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abc')
    hdrs = token.headers()
    assert hdrs['Authorization'] == 'Bearer %s' % token.get()

# Generated at 2022-06-11 00:01:56.660048
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    ''' Unittest for method save of class GalaxyToken. Checks if the given token is successfully stored. '''

    from ansible.utils.path import makedirs_safe
    test_token_file = C.GALAXY_TOKEN_PATH + '.test'
    makedirs_safe(os.path.dirname(test_token_file))
    display.verbosity = 4

    # Setup test
    test_token = "test_token"
    test_token_header = {'Authorization': 'Token %s' % test_token}

    # Construct test object
    galaxy_token = GalaxyToken(test_token)

    # Execute test
    galaxy_token.save()

    # Compare expected result
    with open(test_token_file, 'r') as f:
        config = yaml_load(f)


# Generated at 2022-06-11 00:02:03.839428
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:02:22.293439
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:02:28.765894
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken("my_offline_token", "https://my.auth.url", client_id="my_client_id")
    headers = kt.headers()
    assert headers.get("Authorization") == 'Bearer my_offline_token_access_token'
    assert headers["Content-Type"] == "application/vnd.rh-sso.token+json"



# Generated at 2022-06-11 00:02:39.233422
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token_type = 'Bearer'
    test_headers = 'Authorization: Bearer None'
    test_auth_url = 'url'
    test_access_token = 'None'
    test_client_id = 'None'

    test_token = KeycloakToken(access_token=test_access_token,
                               auth_url=test_auth_url,
                               validate_certs=True,
                               client_id=test_client_id)

    headers = test_token.headers()
    assert test_token_type in headers['Authorization']

    test_token.access_token = test_access_token
    headers = test_token.headers()
    assert test_headers in headers.values()

# Generated at 2022-06-11 00:02:44.275944
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    msg = ("Configuration file %s could not be saved,"
           " check your permissions." % to_text(C.GALAXY_TOKEN_PATH))
    try:
        token = GalaxyToken(token='fake_token')
        token.save()
    except (OSError, IOError):
        display.error(msg)

# Generated at 2022-06-11 00:02:48.533072
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    access_token=dict(
        access_token="verylongtoken"
    )

    token = KeycloakToken(access_token.get('access_token'))

    assert token


# Generated at 2022-06-11 00:03:01.176304
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """
    Ensure save() method has the expected behaviour.
    """
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser

    # Pass in a no-token sentinel
    token = GalaxyToken(token=NoTokenSentinel())

    # Prepare a config object
    token_config = {'token': '0123456789abcedf0123456789abcdef'}
    token.get = lambda: token_config['token']

    # To prevent the method writing to the file system,
    # redirect stdout to a StringIO as temporary file
    # with its contents as in-memory file
    temp_file = StringIO()
    token.save = lambda: yaml_dump(token.get(), temp_file, default_flow_style=False)

    #

# Generated at 2022-06-11 00:03:10.045206
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:03:12.061923
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    KT = KeycloakToken(access_token='SOMETOKEN', auth_url='SOME_URL')
    assert KT.headers() == {'Authorization': 'Bearer SOMETOKEN'}

# Generated at 2022-06-11 00:03:14.360628
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    c = GalaxyToken()
    c.set('foobar-token')
    c.save()
    c2 = GalaxyToken()
    assert c2.get() == c.get()

# Generated at 2022-06-11 00:03:19.337688
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='RndAccessToken')
    token.get()
    expected_header = {
        'Authorization': 'Bearer %s' % token.get()
    }
    assert (token.headers() == expected_header)


# Generated at 2022-06-11 00:03:36.653479
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Case 1: token set, return access_token
    myToken = KeycloakToken(access_token='access_token')
    expected = {'Authorization': 'Bearer access_token'}
    assert myToken.headers() == expected

    # Case 2: access_token not set, return _token
    myToken = KeycloakToken('access_token')
    expected = {'Authorization': 'Bearer access_token'}
    assert myToken.headers() == expected

    # Case 3: access_token not set and _token not set, return None
    myToken = KeycloakToken()
    expected = {'Authorization': 'Bearer None'}
    assert myToken.headers() == expected


# Generated at 2022-06-11 00:03:48.506529
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_auth_url = "https://sso.test.redhat.com/auth/realms/test/protocol/openid-connect/token"

# Generated at 2022-06-11 00:03:58.866686
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    authurl = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    token = KeycloakToken(access_token='xyz', auth_url=authurl)

    # ----- test the encodings of the url work like requests
    url = to_native(token.auth_url)
    assert url == 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    assert to_text(url) == u'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-11 00:04:09.949933
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    print("Testing GalaxyToken.save()...")

    # Initialize GalaxyToken object
    galaxy_token = GalaxyToken()

    # Create test file and set token
    token = 'abcdefghijklmnopqrstuvwxyz'
    config = {'token': token}
    galaxy_token.set(token)
    galaxy_token.save()

    # Read token file and compare contents to the config
    with open(galaxy_token.b_file, 'r') as f:
        config_read = yaml_load(f)
    assert config == config_read

    # Remove test file
    os.remove(galaxy_token.b_file)


# Generated at 2022-06-11 00:04:13.952946
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected = {'Authorization': 'Bearer testtoken2'}
    token = KeycloakToken(access_token='testtoken', auth_url='testurl', client_id='testclient', validate_certs=True)
    token._token = 'testtoken2'
    assert token.headers() == expected

# Generated at 2022-06-11 00:04:23.661788
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = "0a0cd07c-961b-4e20-8fcf-a08e01d92273"
    auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    validate_certs = True
    client_id = "cloud-services"

# Generated at 2022-06-11 00:04:29.303529
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken('token1')
    token.save()
    assert token.config == {'token': 'token1'}
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    with open(b_file, 'r') as f:
        config = yaml_load(f)
    assert config == {'token': 'token1'}
    os.remove(b_file)

# Generated at 2022-06-11 00:04:38.394728
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    auth_url = "https://auth.example.com/auth/realms/example/protocol/openid-connect/token"
    client_id = "cloud-services"
    token = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id)
    payload = 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (client_id, access_token)
    token.get()
    assert token._form_payload() == payload


# Generated at 2022-06-11 00:04:40.604473
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    tok = KeycloakToken(auth_url="http://auth.url", access_token="offline.token")
    assert tok.get() == "access.token"

# Generated at 2022-06-11 00:04:44.197948
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config['token'] = '12345'
    token.save()
    assert os.path.exists(to_bytes(C.GALAXY_TOKEN_PATH))

# Generated at 2022-06-11 00:05:15.993698
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils import six
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    token_file = os.path.join(tempdir, "galaxy_token.yaml")
    token_file_b = to_bytes(token_file, errors='surrogate_or_strict')
    token = '1337'

    config = {'token': token}

    t = GalaxyToken()
    t.b_file = token_file_b
    t._config = config
    t._token = token

    t.save()

    with open(token_file, 'r') as f:
        result = yaml_load(f)

    assert result['token'] == token
    six.assertCountEqual(result.keys(), config.keys())

   

# Generated at 2022-06-11 00:05:23.235184
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils.six.moves.builtins import input
    GALAXY_TOKEN_PATH = '/tmp/galaxy_token'
    C.GALAXY_TOKEN_PATH = GALAXY_TOKEN_PATH
    # clear the file if exists
    try:
        os.remove(C.GALAXY_TOKEN_PATH)
    except OSError:
        pass
    # Test
    g = GalaxyToken()
    g.save()
    # Test if the file exists
    assert os.path.exists(C.GALAXY_TOKEN_PATH)
    # Test if an empty dict is saved in the file
    with open(GALAXY_TOKEN_PATH) as myfile:
        assert yaml_load(myfile) == {}
    # Test with

# Generated at 2022-06-11 00:05:33.626727
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    token = GalaxyToken()

    token_file_name = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    if os.path.isfile(token_file_name):
        os.remove(token_file_name)
    elif not os.path.isdir(os.path.dirname(token_file_name)):
        os.makedirs(os.path.dirname(token_file_name))

    token_string = '123456789012345678901234567890'
    token.set(token_string)
    assert token.get() == token_string

    token.save()

# Generated at 2022-06-11 00:05:35.422046
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    return token.get()

# Generated at 2022-06-11 00:05:46.334290
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import re
    import os


# Generated at 2022-06-11 00:05:54.909319
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:06:04.726095
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    # Mock the open_url call
    import __builtin__
    original_open_url = __builtin__.open_url
    __builtin__.open_url = lambda url, data, validate_certs, method, http_agent: {'status': {'code': 0}, 'read': lambda: '{"access_token": "fake_token"}'}

    token = KeycloakToken(auth_url="https://sso.redhat.com/auth", access_token="fake_offline_token")

    encoded_token = token.get()

    assert encoded_token == "fake_token"

    __builtin__.open_url = original_open_url

# Generated at 2022-06-11 00:06:08.922837
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_obj = KeycloakToken(access_token='abc', auth_url='https://abc.abc.com/auth/realms/abc/protocol/openid-connect/token')

    assert keycloak_token_obj.headers() == {'Authorization': 'Bearer abc'}

# Generated at 2022-06-11 00:06:12.144866
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token = KeycloakToken('test_token', 'test_auth_url')
    test_token.get = lambda: 'test_token'
    assert test_token.headers() == {'Authorization': 'Bearer test_token'}


# Generated at 2022-06-11 00:06:13.996630
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kc = KeycloakToken('123', 'http://auth.url')
    assert isinstance(kc.get(), Text)
    assert kc.get() is '123'