

# Generated at 2022-06-10 23:56:41.714100
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create KeycloakToken object
    token = KeycloakToken(access_token='my_token')

    # Test simple call of get
    assert token.get() == 'my_token'

    # Test with object that return a token
    token = KeycloakToken(access_token=KeycloakToken(access_token='my_token'))
    assert token.get() == 'my_token'

# Generated at 2022-06-10 23:56:44.853683
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='sometoken')
    assert token.get() == 'sometoken'


# Generated at 2022-06-10 23:56:49.098669
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected_result = {'Authorization': 'Bearer None'}
    keycloaktoken = KeycloakToken('None')
    actual_result = keycloaktoken.headers()
    assert expected_result == actual_result


# Generated at 2022-06-10 23:56:52.371447
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken()
    kct.access_token = "abcd"
    kct.auth_url = "http://url.com"
    assert kct.headers() == {'Authorization': 'Bearer '}


# Generated at 2022-06-10 23:57:00.379383
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    fake_resp = type('FakeResponse', (object,), {'read': lambda: json.dumps({'access_token': 'fake-access-token'})})
    open_url = lambda url, data, validate_certs: fake_resp
    token = KeycloakToken(auth_url='http://my-auth.url/', access_token='fake-access-token')
    assert token.get() == 'fake-access-token'

# Generated at 2022-06-10 23:57:10.579774
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken('foobar')
    assert keycloak_token.access_token == 'foobar'
    assert keycloak_token.auth_url is None
    assert keycloak_token.validate_certs
    assert keycloak_token.client_id == 'cloud-services'

    keycloak_token = KeycloakToken('foobar', 'https://auth.example.org', False)
    assert keycloak_token.access_token == 'foobar'
    assert keycloak_token.auth_url == 'https://auth.example.org'
    assert not keycloak_token.validate_certs
    assert keycloak_token.client_id == 'cloud-services'


# Generated at 2022-06-10 23:57:11.744542
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test')
    assert token.get() == 'test'

# Generated at 2022-06-10 23:57:17.574458
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    token_file_path = "/tmp/test_galaxy_token.yaml"

    token = GalaxyToken()

    # Test if file is created
    token.save()
    assert os.path.isfile(token_file_path) == True

    # Test if file is chmoded
    assert oct(os.stat(token_file_path).st_mode)[4:] == '664'

    # Test if file is empty
    file = open(token_file_path, "r")
    lines = file.read()
    assert lines == "{}"

# Generated at 2022-06-10 23:57:24.475356
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token="nonexistent"
    auth_url="https://gce.example.com/galaxy/token"
    client_id="nonexistent"
    kc_token = KeycloakToken(access_token, auth_url, client_id=client_id)

    assert kc_token.headers() == {'Authorization': 'Bearer none'}


# Generated at 2022-06-10 23:57:33.286710
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # TODO: add test for non-default client_id value
    cls = KeycloakToken(access_token='offline-token',
                        auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert cls.client_id == 'cloud-services'

    cls = KeycloakToken(access_token='offline-token',
                        auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                        client_id='ansible')
    assert cls.client_id == 'ansible'



# Generated at 2022-06-10 23:57:43.354693
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    class Config(object):
        galaxy_token_path = 'token.txt'
    cfg = Config()
    token = GalaxyToken()
    token.save(cfg)
    assert os.path.exists(cfg.galaxy_token_path)

# Generated at 2022-06-10 23:57:49.907025
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token = "hello"
    test_config = GalaxyToken(test_token)
    config = test_config.config
    assert config['token'] == test_token
    new_test_token = config['token']

    test_config.set(test_token)
    config = test_config.config
    assert config['token'] == new_test_token
    assert new_test_token == test_token

# Generated at 2022-06-10 23:57:53.382685
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    t = KeycloakToken(auth_url='https://localhost/getToken')
    assert t._form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token='



# Generated at 2022-06-10 23:57:57.541141
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='a', auth_url='http://b')
    assert kt.headers() == {'Authorization': 'Bearer None'}



# Generated at 2022-06-10 23:58:06.092526
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test the token has been correctly retrieved from the class
    test_token = KeycloakToken(access_token='c89d30f6-558a-4eb5-abb7-f33b1aa57dfb', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-10 23:58:08.094604
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    gt = GalaxyToken()
    gt.config = {'token': 'test456'}
    gt.save()
    assert gt._read() == {'token': 'test456'}


# Generated at 2022-06-10 23:58:10.605014
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test')
    assert token.token_type == 'Bearer'


# Generated at 2022-06-10 23:58:19.837630
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Arrange
    access_token = '1234'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'cloud-services'
    token_manager = KeycloakToken(access_token, auth_url, validate_certs=True, client_id=client_id)

    # Act
    token = token_manager.get()

    # Assert
    assert token != None


# Generated at 2022-06-10 23:58:31.900325
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-10 23:58:42.967759
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import shutil
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.common.yaml import yaml_load
    import ansible.constants as C
    import tempfile

    tempdir = tempfile.mkdtemp()
    token_file = os.path.join(tempdir, 'galaxy_token')

    # Test when file does not exist
    galaxy_token = GalaxyToken(None)
    galaxy_token.b_file = token_file

# Generated at 2022-06-10 23:59:01.198499
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import shutil
    tmp_dir = os.path.join(os.getcwd(), '.ansible')
    b_file = os.path.join(tmp_dir, 'ansible.cfg')
    token = '12345'
    config = {'token': token}
    token_file = GalaxyToken(token)

    try:
        os.mkdir(tmp_dir)
        token_file.save()

        # Test if file ansible.cfg was created
        assert os.path.isfile(b_file)

        # Test if file ansible.cfg has default content
        with open(b_file, 'r') as f:
            assert yaml_load(f) == config
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-10 23:59:04.813722
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    t = KeycloakToken(access_token='access_token', auth_url='https://auth.url', client_id='client_id')
    assert t.headers() == {'Authorization': 'Bearer access_token'}

# Generated at 2022-06-10 23:59:14.948994
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Given an auth_url, a client_id and a refresh_token
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'cloud-services'
    refresh_token = 'RHM_TOKEN_HERE'

    # and a KeycloakToken object initialized with the previous parameters
    token = KeycloakToken(access_token=refresh_token, auth_url=auth_url, client_id=client_id)

    # When calling the get method of the KeycloakToken object
    token_result = token.get()

    # Then a token is returned
    assert token_result is not None

# Generated at 2022-06-10 23:59:18.056994
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k_token = KeycloakToken(access_token='dummy_token')
    assert k_token.headers().get('Authorization') == 'Bearer dummy_token'



# Generated at 2022-06-10 23:59:31.344665
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-10 23:59:42.349804
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = 'https://auth.prod.foo.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    access_token = 'eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lk'
    client_id = 'cloud-services'
    validate_certs = True

    token = KeycloakToken(access_token=access_token,
                          auth_url=auth_url,
                          validate_certs=validate_certs,
                          client_id=client_id)

    token.get()
    assert token._token
    assert token.get() == token._token
    assert token.headers()


# Generated at 2022-06-10 23:59:48.373557
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = 'TOKEN'
    auth_url = 'http://127.0.0.1/'
    client_id = 'cloud-services'

    display.verbosity = 4
    auth = KeycloakToken(access_token=token, auth_url=auth_url, client_id=client_id)
    assert auth.get() == token
    display.verbosity = 0



# Generated at 2022-06-10 23:59:54.369993
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # assume the GALAXY_TEST_TOKEN_PATH exists
    token = GalaxyToken(token='foo')
    token.save()
    with open(C.GALAXY_TEST_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == 'foo'


# Generated at 2022-06-11 00:00:06.203086
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:00:14.176286
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:00:39.890330
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:00:43.694796
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test',
                          auth_url='http://localhost:8080/auth',
                          validate_certs=False,
                          client_id='')
    assert token.get() == 'test'


# Generated at 2022-06-11 00:00:49.141979
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    url = "https://test-keycloak-server.example.com/auth/realms/master/protocol/openid-connect/token"
    token = "test-refresh-token"
    kc = KeycloakToken(access_token=token, auth_url=url, validate_certs=True, client_id=None)
    assert kc.get() == 'test-access-token'


# Generated at 2022-06-11 00:00:55.590756
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('refresh_token', 'auth_url', False, 'client_id')
    assert token._form_payload() == 'grant_type=refresh_token&client_id=client_id&refresh_token=refresh_token'
    assert token.get() == 'access_token'
    assert token.headers() == {'Authorization': 'Bearer access_token'}



# Generated at 2022-06-11 00:01:08.984137
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    ''' Test saving a token file '''
    from tempfile import mkdtemp
    from shutil import rmtree
    from textwrap import dedent

    tmpdir = to_bytes(mkdtemp(), errors='strict')
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    workdir = os.path.join(tmpdir, b_file)


# Generated at 2022-06-11 00:01:18.893349
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # mock access_token, auth_url, validate_certs, client_id
    access_token = '13131'
    auth_url = 'http://localhost/auth'
    validate_certs = True
    client_id = 'clientid'

    # mock open_url response headers
    resp = {'body': {'access_token': '1111', 'other': 'xxx'}}

    # mock open_url response object
    resp_obj = {'read': lambda: json.dumps(resp)}

    # mock open_url
    class OpenUrl:
        def __init__(self, url, data, val_certs, method, http_agent):
            self.url = url
            self.data = data
            self.val_certs = val_certs
            self.method = method
            self.http_agent

# Generated at 2022-06-11 00:01:32.619602
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # test with only access_token
    test_token = KeycloakToken(access_token='test_access_token')
    test_headers = test_token.headers()
    assert test_headers['Authorization'] == 'Bearer test_access_token'

    # test with token
    test_token = KeycloakToken(access_token='test_access_token', auth_url='http://test_auth_url/')
    test_headers = test_token.headers()
    assert test_headers['Authorization'] == 'Bearer test_access_token'

    # test with auth_url and token
    test_token = KeycloakToken(access_token='test_access_token', auth_url='http://test_auth_url/')
    test_headers = test_token.headers()
    assert test_headers['Authorization']

# Generated at 2022-06-11 00:01:43.860265
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    #
    # Case 1: Create a new token file in a non existing directory
    #
    token_file = 'test-token-file'
    test_token_file = os.path.join('test-new-dir', token_file)
    test_token_dir = os.path.dirname(test_token_file)

    if os.path.exists(test_token_dir):
        os.rmdir(test_token_dir)
    if os.path.exists(test_token_file):
        os.remove(test_token_file)

    test_token = GalaxyToken()
    test_token.b_file = to_bytes(test_token_file, errors='surrogate_or_strict')
    test_token.config['token'] = 'test-token'

# Generated at 2022-06-11 00:01:46.983104
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken("somekey")
    headers = token.headers()
    assert(headers['Authorization'] == 'Bearer somekey')


# Generated at 2022-06-11 00:01:52.104863
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = 'https://sso.redhat.com/auth/realms/fabric8/protocol/openid-connect/token'
    access_token = 'dummy'
    validate_certs = True

    kt = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=validate_certs)
    print (kt.get())


# Generated at 2022-06-11 00:02:31.919391
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    aToken = KeycloakToken("ftoken", "furl")
    aToken._token = "test_atoken"
    headers = aToken.headers()
    assert headers['Authorization'] == 'Bearer test_atoken'

# Generated at 2022-06-11 00:02:42.106514
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from mock import patch

    class MockHTTPErrorInRead(HTTPError):
        def read(self):
            return b'{"error": "invalid_grant", "error_description": "Token expired"}'

    class MockHTTPErrorNotInRead(HTTPError):
        def read(self):
            return b'Not in a read'

    class MockHTTPResponse(object):
        def read(self):
            return b'{"access_token": "accesstoken"}'

    with patch('ansible.galaxy.token.open_url') as open_url_mock:
        open_url_mock.side_effect

# Generated at 2022-06-11 00:02:54.694029
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # construct a mock response
    class MockResponse():
        def read(self):
            return b'{"access_token": "kctoken", "expires_in": 1800, "refresh_expires_in": 1800, "refresh_token": "kctoken_refresh", "token_type": "Bearer", "not-before-policy": 0, "session_state": "session-state", "scope": "scope"}'
    # mock open_url
    old_open_url = open_url.open_url
    open_url.open_url = lambda *args, **kwargs: MockResponse()
    # construct a token
    token = KeycloakToken('kctoken_refresh', 'https://www.redhat.com/kctoken_endpoint', True, 'client_id')
    # get token
    token

# Generated at 2022-06-11 00:02:58.412496
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Setup
    k = KeycloakToken(access_token='abc')

    # Exercise
    ret = k.headers()

    # Verify
    assert ret['Authorization'] == 'Bearer abc'



# Generated at 2022-06-11 00:03:01.488751
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """ Test the get() method of class KeycloakToken """
    assert KeycloakToken(access_token='abc').get() == 'abc'


# Generated at 2022-06-11 00:03:04.621639
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('token', 'http://url', True, 'client-id')
    assert str(token.get()) == 'token'
    assert token.headers() == {'Authorization': 'Bearer token'}

# Generated at 2022-06-11 00:03:10.115084
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    tokentest = GalaxyToken()
    with open(b_file, 'r') as f:
        config = yaml_load(f)
    if config and isinstance(config, dict):
        tokentest.set('testtoken')
        with open(b_file, 'r') as f:
            config = yaml_load(f)
    assert config.get('token', None) == 'testtoken'

# Generated at 2022-06-11 00:03:11.896217
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    t = KeycloakToken(
        access_token="SomeToken",
        auth_url="http://someurl.com"
    )

    t.get()


# Generated at 2022-06-11 00:03:15.195590
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token="dummy_token", auth_url="auth_url", validate_certs=True, client_id="client_id")
    headers = {'Authorization': 'Bearer dummy_token'}
    assert token.headers() == headers

# Generated at 2022-06-11 00:03:27.144307
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import json
    import httpretty
    from ansible.galaxy.token import KeycloakToken

    response_data = {
        'access_token': 'foo',
        'expires_in': 3600,
        'refresh_expires_in': 1800,
        'refresh_token': 'bar',
        'token_type': 'bearer',
        'not-before-policy': 0,
        'session_state': 'acbacbe-abce-1ab1-ab12-9d73a1c8bff0',
        'scope': 'account'
    }

    def request_callback(request, uri, response_headers):
        return [200, response_headers, json.dumps(response_data)]


# Generated at 2022-06-11 00:04:20.649909
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """Test for KeycloakToken.get"""

    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-11 00:04:32.081216
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """Test to make sure save() funciton writes to file"""

    import tempfile

    # Confirms that the file path is created correctly
    # and that the token is saved
    os.environ['HOME'] = tempfile.gettempdir()
    write_file = os.path.join(tempfile.gettempdir(), '.ansible', 'tmp', 'galaxy_token')
    expected_output = {'token': 'abc123'}
    test_token = GalaxyToken('abc123')
    test_token.save()

    with open(write_file, 'r') as f:
        actual_output = yaml_load(f)

    assert expected_output == actual_output

    # Confirms that the file path is created correctly
    # and that the token is saved

# Generated at 2022-06-11 00:04:37.309706
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='refresh_token',
                          auth_url='https://auth.url/',
                          validate_certs=True,
                          client_id='cloud_services')

    assert token.get() == 'refresh_token'



# Generated at 2022-06-11 00:04:41.020194
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('refresh_token')
    token.get()
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer %s' % token.get(),\
        "KeycloakToken.headers() ValueError Incorrect token"


# Generated at 2022-06-11 00:04:44.627213
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'abcdefghij'
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    assert galaxy_token.get() == token
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-11 00:04:48.015696
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    tok = KeycloakToken(access_token='foobar', auth_url='foo', client_id='bar')
    headers = tok.headers()
    assert len(headers.keys()) == 1
    assert headers['Authorization'] == 'Bearer foobar'


# Generated at 2022-06-11 00:05:00.693339
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest

    class KeycloakTokenTestCase(unittest.TestCase):
        def setUp(self):
            self.qt = KeycloakToken('abcd')

        def test_get_token(self):
            self.assertEqual(self.qt.get(), '1234')

    qt_get_orig = KeycloakToken.get

    def qt_get_mock(self):
        return '1234'

    KeycloakToken.get = qt_get_mock

    qt_suite = unittest.TestLoader().loadTestsFromTestCase(KeycloakTokenTestCase)
    unittest.TextTestRunner(verbosity=2).run(qt_suite)

    KeycloakToken.get = qt_get_orig



# Generated at 2022-06-11 00:05:04.058051
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os
    import shutil

    tf = tempfile.mkdtemp()
    tfile = os.path.join(tf, 't.yml')
    try:
        os.makedirs(tf)
        g = GalaxyToken().set('foobar')
        g.save()
        with open(tfile, 'r') as f:
            v = yaml_load(f)
        assert v == {'token': 'foobar'}, v
    finally:
        shutil.rmtree(tf)



# Generated at 2022-06-11 00:05:16.496035
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:05:21.529745
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # test with a token
    token1 = KeycloakToken(access_token='test_token', auth_url='http://test')
    assert token1.get() == 'test_token'
    # test with no token
    token2 = KeycloakToken(access_token='', auth_url='http://test')
    assert token2.get() == ''

# Generated at 2022-06-11 00:06:12.699164
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Mock token returned by the Keycloak server and the output of method get
    mock_token = 'mock_token'
    mock_get_output = 'mock_get_output'

    # Mock open_url
    mock_url = 'mock_url'
    mock_payload = 'mock_payload'
    mock_ssl_verification = True
    mock_method = 'POST'
    mock_agent = 'agent'
    mock_read_output = 'mock_read_output'
    mock_headers = {'Authorization': 'Bearer mock_token'}

    # Mock object for open_url

# Generated at 2022-06-11 00:06:14.253710
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken('foo')
    assert kt.headers() == {'Authorization': 'Bearer foo'}

# Generated at 2022-06-11 00:06:19.268596
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='some_offline_token', auth_url='https://some_auth_url')
    token.get()
    assert token._token == 'some_access_token'


# Generated at 2022-06-11 00:06:28.614400
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # TODO: Replace with a unittest.
    # We need to test that a file is created, and that it is readable
    # by the owner, and not by other users.
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    remove_old_file(b_file)
    token = '123'
    galaxy_token = GalaxyToken(token)
    assert not os.path.isfile(b_file)
    galaxy_token.save()
    assert os.path.isfile(b_file)
    assert os.stat(b_file).st_mode & S_IRUSR == S_IRUSR
    assert os.stat(b_file).st_mode & S_IWUSR == S_IWUSR
   