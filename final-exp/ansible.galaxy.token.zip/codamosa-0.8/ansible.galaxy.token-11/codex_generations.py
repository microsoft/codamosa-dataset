

# Generated at 2022-06-10 23:56:44.133248
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token_obj = KeycloakToken(access_token='123456')
    # The _token is None
    assert token_obj._token == None
    assert token_obj.get() == 'abcdef'
    # The _token has been set
    assert token_obj._token == 'abcdef'
    # Ensure that the getter is idempotent
    assert token_obj.get() == 'abcdef'

# Generated at 2022-06-10 23:56:49.447391
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = '12345'
    filename = '/tmp/test_this.yml'
    b_filename = to_bytes(filename)
    tokenFile = GalaxyToken(token)
    assert tokenFile.config == {}
    tokenFile.save()
    with open(b_filename, 'r') as f:
        config = yaml_load(f)
    assert config == {'token': token}
    os.remove(b_filename)

# Generated at 2022-06-10 23:56:56.215725
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import os
    import json
    import uuid
    import time
    #
    # - build a test KeycloakToken instance
    #    - auth_url must point to a valid keycloak server.
    #
    fileName = '/tmp/ansible_test_' + str(uuid.uuid4())
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    #
    # - call the method get
    #   - KeycloakToken will request a token from auth_url
    #
    token = KeycloakToken.get(auth_url)
    #
    # - validate response
    #   - make sure the field 'access_token' is present
    #   - access_token should not be

# Generated at 2022-06-10 23:57:07.468924
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test_token'
    token_file = '/tmp/ansible_test_token'
    b_token_file = to_bytes(token_file, errors='surrogate_or_strict')

    config = {'token': token}

    with open(b_token_file, 'w') as f:
        yaml_dump(config, f, default_flow_style=False)

    gt = GalaxyToken(token=NoTokenSentinel())
    gt.b_file = b_token_file
    gt.save()

    with open(b_token_file, 'r') as f:
        config = yaml_load(f)

    assert config.get('token') == token

# Generated at 2022-06-10 23:57:16.725838
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import time
    import datetime
    token = GalaxyToken()
    token.set('foo')
    assert token.config['token'] == 'foo'
    assert token.get() == 'foo'
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    # file date changed
    date_old = os.path.getmtime(C.GALAXY_TOKEN_PATH)
    time.sleep(6)
    token.save()
    date_new = os.path.getmtime(C.GALAXY_TOKEN_PATH)
    assert date_new > date_old

    # check if a non dict is saved we just replace with an empty dict

# Generated at 2022-06-10 23:57:19.307085
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ktoken = KeycloakToken()
    token = ktoken.get()
    assert token == None

# Generated at 2022-06-10 23:57:22.542098
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('foo')
    assert token.config['token'] == 'foo'


# Generated at 2022-06-10 23:57:32.591614
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Make sure that the `get` method works without a KeycloakToken
    kt = KeycloakToken()
    if kt.get() is not None:
        raise AssertionError("KeycloakToken.get() should return None when no token is set")

    # Make sure that the `get` method works with a KeycloakToken
    kt.access_token = "deadbeefdeadbeefdeadbeef"
    kt.auth_url = "https://code.engineering.redhat.com/auth"
    # TODO: try a real refresh token in the variable above and uncomment the
    # code below
    # rt = kt.get()
    # if rt is None:
    #     raise AssertionError("KeycloakToken.get() should not be None")

# Generated at 2022-06-10 23:57:41.692490
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # create temp test file for GalaxyToken
    fd, token_path = tempfile.mkstemp()
    os.close(fd)

    gt = GalaxyToken()
    gt.b_file = token_path
    gt.set('test_token')
    gt.save()

    gt_new = GalaxyToken()
    gt_new.b_file = token_path
    # assert token saved in temp file
    assert gt_new.get() == 'test_token'
    # remove temp file
    os.remove(token_path)

# Generated at 2022-06-10 23:57:49.157382
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = '4351f4a4-e9ea-4c64-9b54-82c97f6a0a72'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

    token = KeycloakToken(access_token=access_token, auth_url=auth_url)

# Generated at 2022-06-10 23:57:59.133754
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
   kct = KeycloakToken(auth_url='http://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', access_token='adfadsf')
   assert kct.auth_url == 'http://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
   assert kct.access_token == 'adfadsf'

# Generated at 2022-06-10 23:58:01.931080
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='test', auth_url='test', validate_certs='test', client_id='test')
    kct.get()
    
test_KeycloakToken_get()

# Generated at 2022-06-10 23:58:11.292207
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # A token dict returned from auth_url
    token_dict = {'access_token':'FDWE4354FEFRE4'}
    # mocking a GET request to auth_url
    import mock
    with mock.patch('ansible.module_utils.galaxy.token.open_url', return_value=str(token_dict)) as mock_url_get:
        # Create a token object
        token = KeycloakToken('token-1234', 'https://sso.redhat.com', True, 'foo-client')
        # Call the get method
        returned = token.get()
        # Assert that the method returns the access_token
        assert returned == token_dict['access_token']
        url = 'https://sso.redhat.com'

# Generated at 2022-06-10 23:58:21.976148
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-10 23:58:25.723706
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    os.unlink(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-10 23:58:37.949400
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url = "https://auth.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"

# Generated at 2022-06-10 23:58:45.729295
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    t = KeycloakToken("1234")
    assert t.headers() == {'Authorization': 'Bearer None'}

    t.access_token = "1234"
    assert t.headers() == {'Authorization': 'Bearer None'}

    t.auth_url = "https://abc.redhat.com"
    assert t.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-10 23:58:50.481947
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    assert KeycloakToken(access_token='aXcWV7XMfQAQ2jD_vO8WjA').get() == 'aXcWV7XMfQAQ2jD_vO8WjA'


# Generated at 2022-06-10 23:58:57.038782
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('offline_token', 'auth_url', True, 'client_id')
    assert token._token is None
    assert token.client_id == 'client_id'
    assert token.auth_url == 'auth_url'
    assert token.validate_certs is True
    assert token.get() is None
    assert token.headers().get('Authorization') is None
    return token

# Generated at 2022-06-10 23:59:09.977055
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    import os
    import sys
    import subprocess

    if sys.version_info[0] < 3:
        import mock
    else:
        from unittest import mock

    test_environment = dict(os.environ)
    test_environment.pop("KCPASSWORD", None)
    test_environment.pop("KCPASSWORDFILE", None)

    token_str = "deadbeef"
    token_url = "https://my.auth/realms/ansible/broker/redhat_id/token"
    client_id = "deadbeef"

    with mock.patch("subprocess.check_output") as mock_output:
        mock_output.return_value = token_str
        t = KeycloakToken(auth_url=token_url, client_id=client_id)

# Generated at 2022-06-10 23:59:38.465435
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(auth_url="https://auth.redhat.com", access_token='token', client_id='my-client')
    token = kt.get()
    assert token == 'Bearer'
    headers = kt.headers()
    assert headers == {'Authorization': 'Bearer token'}

# Generated at 2022-06-10 23:59:42.704291
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    l = GalaxyToken()
    l.set("a")
    assert l.get() == "a"
    l.set("b")
    assert l.get() == "b"
    l.set(None)
    assert l.get() is None


# Generated at 2022-06-10 23:59:52.195080
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:00:04.686009
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = "f0e978d6-d1a1-4dcc-91e1-9f7e28f9e8e7"
    auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    validate_certs = True
    client_id = None

# Generated at 2022-06-11 00:00:11.995744
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kc_token = KeycloakToken('real_access_token', auth_url='auth_url', client_id='client_id')
    try:
        kc_token.get()
    except Exception as e:
        assert e, e
    else:
        raise Exception("KeycloakToken.get() must raise Exception for unit testing")

    headers = kc_token.headers()
    assert headers['Authorization'].startswith('Bearer ')
    headers['Authorization'] = headers['Authorization'][7:]
    assert headers['Authorization'] == 'real_access_token'



# Generated at 2022-06-11 00:00:19.919314
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = '123'
    temp_token_file = 'test_token'
    b_temp_token_file = to_bytes(temp_token_file, errors='surrogate_or_strict')
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    with open(b_temp_token_file, 'r') as f:
        config = yaml_load(f)
        assert config['token'] == token
    os.remove(b_temp_token_file)

# Generated at 2022-06-11 00:00:31.402282
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a GalaxyToken object
    g = GalaxyToken()

    # Create a new file
    file_path = 'token_file'

    # Write some content
    data = "token: abcdefghijk"
    with open(file_path, 'w') as file:
        file.write(data)

    # Change modes
    mode = 0o600
    os.chmod(file_path, mode)

    # Save this content in the token file
    g.save(file_path)

    # Open the token file and check the mode
    st = os.stat(file_path)
    os.chmod(file_path, st.st_mode)
    assert st.st_mode == mode

# Generated at 2022-06-11 00:00:36.581712
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = '/tmp/test_GalaxyToken'
    test_token = '1234567890123456789'
    gt = GalaxyToken(token=test_token)
    gt.save()

    with open(b_file, 'r') as f:
        config = yaml_load(f)


    assert test_token == config['token']
    # cleanup
    os.remove(b_file)




# Generated at 2022-06-11 00:00:40.820983
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = "TOKEN"
    url = "URL"
    auth_url = url + "/token"
    fake_resp = {'access_token': token}
    auth_token = KeycloakToken(token, auth_url)
    assert auth_token.get() == token


# Generated at 2022-06-11 00:00:49.594834
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    username = 'test'
    password = 'test'
    access_token = 'test'
    auth_url = 'https://auth.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'test'
    # Define test object
    k = KeycloakToken(access_token, auth_url, True, client_id)
    # Define test method
    def test_method(self):
        return self.get()
    # Set get as test method
    setattr(KeycloakToken, 'get', test_method)
    # Run test
    k.get()

# Generated at 2022-06-11 00:01:20.088599
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    foo = KeycloakToken(access_token='access_token', auth_url='auth_url')
    assert foo.get() == 'access_token'


# Generated at 2022-06-11 00:01:33.278736
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.urls import open_url
    from ansible.galaxy.user_agent import user_agent


# Generated at 2022-06-11 00:01:44.054915
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """
    Code duplicated from test_galaxy_module.py
    """
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)

    module = TestModule(argument_spec={})
    test_token_file = '/var/tmp/ansible_test_galaxy_token_file'
    try:
        token = GalaxyToken(test_token_file)
        token.set('test_token_save')
        config = token._read()
        assert config['token'] == 'test_token_save'
    finally:
        os.remove(test_token_file)

# Generated at 2022-06-11 00:01:55.493130
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')

    with open(b_file, 'r') as f:
        config = yaml_load(f)

    if config and not isinstance(config, dict):
        raise AssertionError('Token file %s malformed, unable to read it' % to_text(b_file))

    config = config or {}
    config['token'] = 'this_is_a_new_token'

    with open(b_file, 'w') as f:
        yaml_dump(config, f, default_flow_style=False)

    with open(b_file, 'r') as f:
        new_config = yaml_load(f)

    if new_config != config:
        raise

# Generated at 2022-06-11 00:01:57.932706
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token="<offline_access_token>")
    assert kct.get() == "<online_access_token>"


# Generated at 2022-06-11 00:02:06.994556
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    class test_case():
        def __init__(self,access_token, client_id):
            self.access_token = access_token
            self.client_id = client_id
            self.auth_url = None
            self.validate_certs = True

    def test():
        access_token = "accessToken"
        client_id = None
        test_obj = test_case(access_token,client_id)

        keycloak_obj = KeycloakToken(access_token,auth_url,validate_certs,client_id)
        keycloak_obj.headers()


# Generated at 2022-06-11 00:02:15.492054
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils.common import tempfile
    from ansible.module_utils.six import PY3

    with tempfile.NamedTemporaryFile() as tmpfile:
        galaxy_token = GalaxyToken(token=None)
        galaxy_token.b_file = tmpfile.name

        if PY3:
            test_token = "It worked for 'PY3'"
        else:
            test_token = "It worked for 'PY2'"

        galaxy_token.set(test_token)
        with open(tmpfile.name, 'r') as f:
            token_saved = yaml_load(f)

        assert token_saved['token'] == test_token, "token set and token read don't match"



# Generated at 2022-06-11 00:02:20.467996
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    map_pairs = [
        (None, None),
        ("me@example.com", "my_token"),
        ("another@host.com", "another_token")
        ]
    for (auth_url, auth_token) in map_pairs:
        kct = KeycloakToken(access_token=auth_token, auth_url=auth_url)
        print("get(): %s" % kct.get())


# Generated at 2022-06-11 00:02:22.827427
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kc = KeycloakToken(auth_url='https://user-token-auth.com', access_token='a1b2c3')
    assert kc.get() == 'a1b2c3'

# Generated at 2022-06-11 00:02:33.718248
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.galaxy.token import GalaxyToken
    token = 'QQk7sjoGgteslVpnjx3qD3y7EqlF6g'
    expected_content = 'token: {}'.format(token)
    token_file = 'tests/data/token_test.yml'

    galaxy_token = GalaxyToken()
    galaxy_token._config = {'token': token}
    galaxy_token.b_file = token_file

    # test save
    galaxy_token.save()
    assert os.path.isfile(token_file)
    with open(token_file, 'r') as f:
        assert f.read() == expected_content



# Generated at 2022-06-11 00:03:05.485056
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    server_address = 'https://sso.redhat.com/auth/realms/ansible-galaxy/protocol/openid-connect/token'
    refresh_token = '<my-refresh-token>'
    k = KeycloakToken(access_token=refresh_token, auth_url=server_address, validate_certs=False)
    token = k.get()
    print(token)
    assert token.startswith('eyJ')


# Generated at 2022-06-11 00:03:17.347380
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    c_file = './test_GalaxyToken_save'
    c_file_contents = 'test_GalaxyToken_saves'
    old_token = 'test_old_token'

    # Create test file
    if not os.path.isfile(c_file):
        # token file not found, create and chmod u+rw
        open(c_file, 'w').close()
        os.chmod(c_file, S_IRUSR | S_IWUSR)  # owner has +rw

    # Write infos
    with open(c_file, 'w') as f:
        yaml_dump({'token':old_token}, f, default_flow_style=False)

    token = GalaxyToken(token=c_file_contents)
    token.save()

    # Read file and

# Generated at 2022-06-11 00:03:28.671579
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''
      Test the get method of the KeycloakToken class.
    '''
    # Create the KeycloakToken object
    kct = KeycloakToken(access_token='refresh_token=offline-token', auth_url='https://sso.redhat.com/auth/realms/acme/protocol/openid-connect/token', validate_certs=True, client_id='cloud-services')
    # Mock the payload that the KeycloakToken class forms when it makes a request to the Keycloak server
    kct._form_payload = Mock()
    # Mock the function that takes a payload and makes a request to the Keycloak server
    kct._make_request = Mock()
    # Mock the function that takes a response and extracts an access token from it

# Generated at 2022-06-11 00:03:36.799175
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import os
    import logging
    import tempfile
    import datetime
    import yaml

    logging.basicConfig(level=logging.DEBUG)

    # mimick the settings from ansible-config
    test = {}
    test['offline_token'] = os.getenv('GALAXY_OFFLINE_TOKEN')
    test['sso_url'] = os.getenv('GALAXY_SSO_URL')
    test['validate_certs'] = False
    test['client_id'] = os.getenv('GALAXY_CLIENT_ID')
    test['user_agent'] = 'ansible/2.6.0 (linux-gnu python 2.7.5)'


# Generated at 2022-06-11 00:03:40.465301
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = NoTokenSentinel()
    g = GalaxyToken(token)
    try:
        g.save()
    except:
        pass
    else:
        assert False, 'Expected token to be a file not a directory'


# Generated at 2022-06-11 00:03:48.506520
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'testtoken'
    galaxy_token = GalaxyToken(token)
    # save the token to a temporary file
    b_file = to_bytes('test_token_file', errors='surrogate_or_strict')
    galaxy_token.b_file = b_file
    galaxy_token.save()
    # read it back out and make sure it is the same
    galaxy_token2 = GalaxyToken()
    galaxy_token2.b_file = b_file
    assert galaxy_token2.get() == token

# Generated at 2022-06-11 00:03:49.391287
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken('test_token')
    token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-11 00:03:50.541041
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='abc')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer abc'

# Generated at 2022-06-11 00:04:00.111013
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    class Resp:
        def __init__(self, status=None, msg=None, data=None):
            self.status = status
            self.msg = msg
            self.data = data

        def read(self):
            return self.data

    kct = KeycloakToken(access_token=None, auth_url=None)

    def _open_url(url, data, **kwargs):
        data = json.loads(data)
        assert data['grant_type'] == 'refresh_token'
        assert data['client_id'] == 'cloud-services'
        assert data.get('refresh_token') is None
        return Resp(status=200, msg='Success', data='{"access_token": "foo"}')

    # Test unautorized
    kct._open_url = _open_url


# Generated at 2022-06-11 00:04:12.899306
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-11 00:04:58.556887
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'testtoken'
    b_file = '/tmp/ansible_galaxy_token'
    galaxy_token = GalaxyToken(token)
    galaxy_token.b_file = b_file
    galaxy_token.save()
    # check the file was created
    assert os.path.isfile(b_file)
    # clean up
    os.remove(b_file)


# Generated at 2022-06-11 00:05:04.036314
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token._config = {'token': 'abcdefghijklmnopqrstuv'}
    token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        assert f.read() == token._config
    os.remove(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-11 00:05:16.957743
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(auth_url='https://tasks.example.com', access_token='offline_token')
    # mock the open function to return a mock url
    token.open_url = mock.MagicMock()
    token.open_url.return_value = 'mock_url'
    # mock the json.loads function to return a mock dictionary
    token.json = mock.MagicMock()
    token.json.loads.return_value = '{"access_token": "token_to_be_returned"}'

    # This is the mocked get request to the Keycloak server
    token.get()
    # Check that the request contains the correct url, headers and payload

# Generated at 2022-06-11 00:05:21.891017
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token = KeycloakToken('a_very_valid_token_1234567890', auth_url="http://test-auth-url.com")
    actual_headers = test_token.headers()
    expected_headers = {'Authorization': 'Bearer None'}
    assert actual_headers == expected_headers



# Generated at 2022-06-11 00:05:35.269038
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:05:46.160564
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    old_open = open
    open_filename = None
    try:
        global open

        def fake_open(filename, mode):
            nonlocal open_filename
            open_filename = filename
            return old_open(filename, mode)

        open = fake_open

        token = GalaxyToken(token=NoTokenSentinel())
        # A galaxy token is not present
        assert not os.path.isfile(C.GALAXY_TOKEN_PATH)
        # Changed galaxy token
        token.set('unit_test_token')
        # A galaxy token is created
        assert os.path.isfile(C.GALAXY_TOKEN_PATH)
        # A galaxy token is saved
        expected = token._read()
        assert expected['token'] == 'unit_test_token'
    finally:
        open = old_

# Generated at 2022-06-11 00:05:49.745058
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='some_random_token', auth_url='fake_url')
    token.get() # assign 'self._token' to a value - mandatory first call if using get() method
    token_headers = token.headers()
    expected_token_headers = {'Authorization': 'Bearer %s' % token._token}
    assert expected_token_headers == token_headers

# Generated at 2022-06-11 00:06:01.901995
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import urllib2
    import json
    import urlparse

    class MockResponse(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    class MockUrlOpener(object):
        def __init__(self, response=None, headers=None):
            self.response_data = response
            self.headers = headers

        def open(self, url, data=None):
            if not self.response_data:
                return None

            # Check it's called with the right args
            # Only check certain keys because of blacklisted fields like the client id
            expected = {'grant_type': 'refresh_token', 'client_id': 'cloud-services'}

# Generated at 2022-06-11 00:06:11.281978
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_path = C.GALAXY_TOKEN_PATH
    C.GALAXY_TOKEN_PATH = 'test_webgalaxy'
    expected_output = {'token': 'abcd'}
    expected_error = {'error': 'This is an error'}
    gt = GalaxyToken('abcd')
    gt.save()
    with open('test_webgalaxy', 'r') as f:
        test_file = yaml_load(f)
    assert test_file == expected_output

    gt.set(expected_error)
    gt.save()
    with open('test_webgalaxy', 'r') as f:
        test_file = yaml_load(f)
    assert test_file == expected_error


# Generated at 2022-06-11 00:06:18.690855
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os

    def read_file():
        with open(to_bytes(GALAXY_TOKEN_PATH, errors='surrogate_or_strict'), 'r') as f:
            return yaml_load(f)

    temp_dir = tempfile.mkdtemp(prefix='ansible-test-galaxy-token')
    GALAXY_TOKEN_PATH = os.path.join(to_bytes(temp_dir), b'ansible.galaxy.token')

    # Check if the file was successfully created
    assert os.path.isfile(GALAXY_TOKEN_PATH)

    galaxy_token = GalaxyToken("03b541da28e74ba0b5d676c7cb646335")
    galaxy_token.save()

    # Check if the token was correctly saved