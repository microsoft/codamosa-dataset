

# Generated at 2022-06-10 23:56:35.375967
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = 'abc-def'
    kct = KeycloakToken('abc-def', 'https://sso.redhat.com')
    assert kct.headers() == {'Authorization': 'Bearer %s' % token}



# Generated at 2022-06-10 23:56:38.399063
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test')
    headers = token.headers()
    assert 'Authorization' in headers
    assert headers['Authorization'] == 'Bearer test'


# Generated at 2022-06-10 23:56:48.417446
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    access_token = 'offline_token'
    validate_certs = True
    client_id = 'cloud-services'
    x = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    expected_payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=offline_token'
    res = x._form_payload()
    assert res == expected_payload

    headers = {'Authorization': 'Bearer dW5kZWZpbmVk'}
    res = x.headers()
    assert res == headers

# Generated at 2022-06-10 23:56:52.207394
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='some-refresh-token')
    result = kt.headers()
    # print(result)
    # {'Authorization': 'Bearer 442399c9-3fde-4e64-aaf3-b2e4d4d4a04a'}

# Generated at 2022-06-10 23:57:06.146285
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    s = KeycloakToken(client_id='test-client-id', access_token='test-access-token')

# Generated at 2022-06-10 23:57:08.684349
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    key_token = KeycloakToken(access_token='foo')
    headers = key_token.headers()
    assert headers['Authorization'] == "Bearer foo"

# Generated at 2022-06-10 23:57:11.301189
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    o = KeycloakToken(access_token='foo', auth_url='https://auth.url')
    assert o.get() == 'foo'



# Generated at 2022-06-10 23:57:18.420866
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    input_access_token = 'xxx-xxx'
    input_auth_url = 'https://sso.openshift.com/auth/realms/redhat-external/protocol/openid-connect/token'
    input_validate_certs = False
    input_client_id = 'cloud-services'

    # Create obj test
    obj_test = KeycloakToken(access_token=input_access_token, auth_url=input_auth_url,
                             validate_certs=input_validate_certs, client_id=input_client_id)

    # Get test
    obj_test.get()

    # Return test
    return obj_test._token



# Generated at 2022-06-10 23:57:30.325220
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create temporary file
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile('w+b', delete=False) as named_temp_file:
        token_file = named_temp_file.name

# Generated at 2022-06-10 23:57:43.134800
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import requests
    import responses

    # Set up mock server responses
    # First assumption is that the user has a valid token

# Generated at 2022-06-10 23:58:00.378060
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='thisIsAToken', auth_url='https://authserver.com')
    assert token.headers()['Authorization'] == 'Bearer %s' % token.get()



# Generated at 2022-06-10 23:58:07.864015
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    client_id = 'cloud-services'
    offline_token = "MmMmZjNjZDUtYTc4MC00YmFlLTgwYTItN2E0OGJiZTgyZjQzQ2Y3YmVjMzAtNGY3Yy00MzEzLWJjNDItNTBjZDgzNDIyMjVk"
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True

    token = KeycloakToken(auth_url=auth_url, access_token=offline_token, client_id=client_id, validate_certs=validate_certs)
    token.get()

# Generated at 2022-06-10 23:58:20.583775
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    offline_token = 'fake_offline_token'
    request_token = KeycloakToken(auth_url=url, access_token=offline_token)

    # Check token returned is not None
    response_token = request_token.get()
    assert response_token is not None
    assert isinstance(response_token, (str, unicode))

    # Check token returned is 66 characters
    assert len(response_token) == 66

    # Check token returned is a Keycloak access token
    assert response_token[:4] == 'eyJh'

# Generated at 2022-06-10 23:58:24.292974
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'test-access-token'
    auth_url = 'test-auth-url'
    validate_certs = True

    test_obj = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=validate_certs)

    headers = test_obj.headers()
    assert 'Authorization' in headers
    assert headers['Authorization'].split()[0] == 'Bearer'
    assert headers['Authorization'].split()[1] == test_obj.get()


# Generated at 2022-06-10 23:58:26.642615
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='123', auth_url='http://auth_url')
    expected_headers = {'Authorization': 'Bearer None'}
    assert kct.headers() == expected_headers

# Generated at 2022-06-10 23:58:30.838272
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    obj = KeycloakToken("abc123", "http://localhost", False, "test_client")
    actual_result = obj.headers()
    expected_result = {"Authorization": "Bearer "}
    assert actual_result == expected_result


# Generated at 2022-06-10 23:58:34.229542
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken('foo')
    assert 'Authorization' in kct.headers()
    assert 'Bearer' in kct.headers()['Authorization']


# Generated at 2022-06-10 23:58:44.149907
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    # Test 1
    # - The KeycloakToken class is mocked
    # - The _form_payload method is mocked
    # - The open_url method is mocked
    # - The _form_payload method is called, it returns 'payload01'
    # - The open_url method is called and return a response with
    #   - the read method returns '{"access_token":"tocken01"}'
    # - The KeycloakToken.get() method returns 'tocken01'
    access_token = 'access_token01'
    auth_url = 'auth_url01'
    validate_certs = 'validate_certs01'
    client_id = 'client_id01'
    payload = 'payload01'
    token = 'tocken01'


# Generated at 2022-06-10 23:58:56.914007
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = to_bytes(os.path.join(C.DEFAULT_LOCAL_TMP, to_text('galaxy_test_tocken_file')), errors='surrogate_or_strict')

# Generated at 2022-06-10 23:59:07.602343
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    #  - body is form encoded
    #    - 'grant_type' is 'refresh_token'
    #    - 'client_id' is 'cloud-services'
    kct = KeycloakToken('some_refresh_token', auth_url='https://somewhere.com/oauth2/token')
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=some_refresh_token'
    assert kct._form_payload() == payload

    # TODO: Write a set of test cases for the rest of this class


# Generated at 2022-06-10 23:59:44.903220
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # test without payload
    kt = KeycloakToken()
    assert kt.get() is None
    assert kt.headers() == {}

    # test with valid payload
    kt = KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/ansible/protocol/openid-connect/token',
                       access_token='offlinetoken')
    kt.get()
    assert kt._form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=offlinetoken'
    assert kt.headers() == {'Authorization': 'Bearer accesstoken'}

    # test with invalid payload

# Generated at 2022-06-10 23:59:52.523385
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-10 23:59:59.757800
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    KT = KeycloakToken('mock_token', 'mock_url')

    result = KT.get()
    assert result == 'mock_token', "%r != %r" % (result, 'mock_token')

    KT._token = 'mock_token'
    result = KT.get()
    assert result == 'mock_token', "%r != %r" % (result, 'mock_token')

# Generated at 2022-06-11 00:00:03.296907
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(auth_url='https://example.com', access_token='test_token')
    assert token.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-11 00:00:16.910252
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-11 00:00:26.508384
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import urlopen

    import types
    import inspect
    import requests

    # check that we're mocking the open_url() function from the urls module
    assert to_text(inspect.getsource(open_url)) == to_text(inspect.getsource(urlopen))

    # preserve the original method
    open_url_orig = open_url

    def _open_url(url, *args, **kwargs):
        class FakeUrl(object):
            def read(self):
                return json.dumps(dict(access_token='new_offline_token'))

            def getcode(self):
                return 200

        return FakeUrl()

   

# Generated at 2022-06-11 00:00:29.500926
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    at = KeycloakToken()
    at.get()
    assert at.headers() == {'Authorization': 'Bearer %s' % at._token}


# Generated at 2022-06-11 00:00:36.082727
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """
    Test the save method of GalaxyToken
    """
    file_name = 'test_GalaxyToken_save.yaml'
    # New config structure
    config = {'key': 'value', 'list': [1, 2, 3]}
    # Save new config
    GalaxyToken()._write(config, file_name)
    # Read previously saved config
    config_read = GalaxyToken()._read(file_name)
    # Delete config file
    os.remove(file_name)
    assert config == config_read

# Generated at 2022-06-11 00:00:41.714074
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    pt = to_bytes(os.path.join('test', 'integration', 'targets', 'galaxy'), errors='surrogate_or_strict')
    old_dir = os.getcwd()
    os.chdir(pt)
    gt = GalaxyToken()
    gt.set('111')
    gt.save()
    t = gt.get()
    os.chdir(old_dir)
    assert t == '111'



# Generated at 2022-06-11 00:00:46.006945
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
  data = {}
  data['token'] = '123'
  data['another_property']= 'xyz'
  token = GalaxyToken()
  token.save(data)


# Generated at 2022-06-11 00:01:43.198308
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    ck = KeycloakToken(access_token='12345678')
    h = ck.headers()
    assert h['Authorization'] == 'Bearer 12345678'


# Generated at 2022-06-11 00:01:47.084991
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = 'MyKeycloakToken'
    my_token = KeycloakToken(access_token=token)
    headers = my_token.headers()
    assert headers['Authorization'] == 'Bearer %s' % token



# Generated at 2022-06-11 00:01:49.600833
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='dummy_token',
                          auth_url='https://dummy_url.com')
    token.get()
    former_token = token._token
    token.get()
    assert former_token == token._token


# Generated at 2022-06-11 00:01:52.467462
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    file_name = 'tmp/galaxy_token.yml'
    token = GalaxyToken()
    token.config = {'token': 'TOKEN'}
    token.b_file = to_bytes(file_name, errors='surrogate_or_strict')
    token.save()

    with open(file_name, 'r') as f:
        config = yaml_load(f)

    assert config == token.config

# Generated at 2022-06-11 00:01:57.516501
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='foo')
    assert kt.get() == 'foo'
    kt = KeycloakToken(access_token='bar')
    assert kt.get() == 'bar'
    kt = KeycloakToken(auth_url='https://example.com/auth/realms/foo/protocol/openid-connect/token')
    assert kt.get() is None
    kt = KeycloakToken(auth_url='https://example.com/auth/realms/foo/protocol/openid-connect/token', access_token='foo')
    assert kt.get() is None

# Generated at 2022-06-11 00:02:04.467019
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    C.GALAXY_TOKEN_PATH = '/tmp/test_GalaxyToken'
    token = GalaxyToken('AAA-BBB-CCC')
    token.save()
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)
    assert config.get('token') == 'AAA-BBB-CCC'
    os.unlink(C.GALAXY_TOKEN_PATH)
    pass

# Generated at 2022-06-11 00:02:08.413229
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken("testtoken",
                          "https://auth.example.com/auth/realms/testrealm/protocol/openid-connect/token",
                          client_id="testclient_id")
    token.get()


# Generated at 2022-06-11 00:02:12.680285
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kctoken = KeycloakToken(access_token='offline-token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', validate_certs=True)
    assert kctoken.get() == 'access_token'


# Generated at 2022-06-11 00:02:13.925101
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken().get()


# Generated at 2022-06-11 00:02:20.803404
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """Ensure GalaxyToken.save() works as expected
    """
    file_name = 'test_GalaxyToken'
    file_path = os.path.join(C.DEFAULT_LOCAL_TMP, file_name)

    # Remove token file, if it exists
    if os.path.isfile(file_path):
        os.remove(file_path)

    token = 'notabearerasdf1234'

    # Create token file, set token
    gt = GalaxyToken()
    gt.b_file = file_path
    gt.set(token)

    # Read token file and verify token
    with open(file_path, 'r') as f:
        data = yaml_load(f)

# Generated at 2022-06-11 00:04:21.034790
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    import unittest.mock
    from ansible_collections.notstdlib.moveitallout.tests.unit.cloud.cloudkube_test_data import access_token, auth_url
    k = KeycloakToken(access_token, auth_url)
    def mocked_get():
        # imitates the output of open_url()
        headers = {
            'content-type': 'application/json'
        }
        with open('./data/access_token.json', 'r') as f:
            data = json.load(f)
        data['access_token'] = access_token
        response = unittest.mock.MagicMock()
        response.read = unittest.mock.MagicMock(return_value=data)
        response.getheaders = unittest.mock.Magic

# Generated at 2022-06-11 00:04:29.707958
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # create fake server response
    # - response includes access_token
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=my_offline_token'

# Generated at 2022-06-11 00:04:36.594506
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile

    f = tempfile.NamedTemporaryFile()
    os.chmod(f.name, 0o644)

    gt = GalaxyToken()
    gt.set('foo')
    gt.save()

    assert os.path.isfile(f.name)
    with open(f.name, 'r') as f:
        assert f.read().startswith('token: foo')

# Generated at 2022-06-11 00:04:49.223008
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    import unittest.mock as mock
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils._text import to_native


# Generated at 2022-06-11 00:04:52.047948
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('access_token', 'auth_url', 'validate_certs', 'client_id')
    response = token.get()
    assert response

# Generated at 2022-06-11 00:04:56.524133
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('test_token', 'test_url')
    my_headers = token.headers()
    assert my_headers == {'Authorization': 'Bearer None'}, \
           "test_KeycloakToken_headers: Expected: {'Authorization': 'Bearer None'}, Actual %s" % my_headers
 

# Generated at 2022-06-11 00:05:02.904599
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    username = 'john'
    password = 'secret'
    auth = BasicAuthToken(username, password)
    token = '1234'
    # check if save works with BasicAuthToken
    galaxy_token = GalaxyToken(auth)
    galaxy_token.set(token)
    assert galaxy_token.get() == token
    galaxy_token.save()
    assert galaxy_token.get() == token
    # check if save works with string token
    galaxy_token = GalaxyToken(token)
    galaxy_token.save()
    assert galaxy_token.get() == token

# Generated at 2022-06-11 00:05:06.430508
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kc_token = KeycloakToken(access_token='my-token')
    assert kc_token.headers() == {'Authorization': 'Bearer my-token'}

# Generated at 2022-06-11 00:05:13.320078
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token = 'test'
    test_config = {'skip_cert_verify': True, 'token': test_token}
    gt = GalaxyToken(test_token)
    gt.config = test_config
    gt.save()
    gt2 = GalaxyToken()
    assert gt2.config == test_config
    os.unlink(C.GALAXY_TOKEN_PATH)


# Generated at 2022-06-11 00:05:16.639439
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(client_id = 'client', access_token = 'token')
    assert kt.headers() == {'Authorization': 'Bearer token'}