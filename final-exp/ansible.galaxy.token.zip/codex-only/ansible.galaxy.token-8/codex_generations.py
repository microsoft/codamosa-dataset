

# Generated at 2022-06-22 20:35:52.542717
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = 'aaaaabbbbbccccc'
    gt = GalaxyToken(token)
    assert gt.get() == token



# Generated at 2022-06-22 20:36:00.548573
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    d = GalaxyToken()

    import ansible.constants as C
    # - change ansible.cfg GALAXY_TOKEN_PATH to a temporary file
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    d.b_file = b_file
    config = d.config

    # - delete the temporary file
    os.unlink(b_file)

    if not isinstance(config, dict):
        raise AssertionError('config is not a dict:\n\t%s' % config)

if __name__ == '__main__':
    test_GalaxyToken()

# Generated at 2022-06-22 20:36:03.952792
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = 'test_user'
    password = 'test_password'
    error_msg = "test_user:test_password\n"
    assert error_msg in BasicAuthToken._encode_token(username, password)

# Generated at 2022-06-22 20:36:07.903639
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken('foo','abc').get() == 'Zm9vOmFiYw=='
    assert BasicAuthToken('foo').get() == 'Zm9vOg=='



# Generated at 2022-06-22 20:36:09.203375
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is NoTokenSentinel()

# Generated at 2022-06-22 20:36:20.768749
# Unit test for constructor of class GalaxyToken

# Generated at 2022-06-22 20:36:22.266542
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is not None

# Generated at 2022-06-22 20:36:29.361982
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    # Test for case when GALAXY_TOKEN_PATH is defined and contains token
    token = "qwertyuiopasdfghjklzxcvbnm"
    GALAXY_TOKEN_PATH = "test_GalaxyToken_get_1"
    with open(GALAXY_TOKEN_PATH, 'w') as f:
        yaml_dump({"token": token}, f, default_flow_style=False)
    os.environ['GALAXY_TOKEN_PATH'] = GALAXY_TOKEN_PATH
    galaxy_token = GalaxyToken()
    assert token == galaxy_token.get()
    os.unlink(GALAXY_TOKEN_PATH)
    del os.environ['GALAXY_TOKEN_PATH']

    # Test for case when GALAX

# Generated at 2022-06-22 20:36:31.094448
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)



# Generated at 2022-06-22 20:36:38.594615
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
   print("Running test_BasicAuthToken()...")
   # test
   try:
       my_BasicAuthToken = BasicAuthToken("user", "password")
       if my_BasicAuthToken is not None:
           print("An object of class 'BasicAuthToken' was successfully created.")
   except Exception as e:
       print("Creation of object of class Basic_Auth_Token' has failed.")
       print("The following exception was thrown: ")
       print(e)
   finally:
       print("test_BasicAuthToken() has been executed.")
       print("") # new line

test_BasicAuthToken()

# Generated at 2022-06-22 20:36:49.288358
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    '''
    Test method __new__ of class NoTokenSentinel
    '''
    import sys
    import types

    # Save the builtin __new__ method of class object
    orig_object___new__ = object.__new__

    # Set a mock __new__ method for class object
    def mock_object___new__(cls):
        return orig_object___new__(cls)
    object.__new__ = mock_object___new__

    # Create a NoTokenSentinel object
    _NoTokenSentinel___new__ = NoTokenSentinel()

    # Check the type of the NoTokenSentinel object
    if not type(_NoTokenSentinel___new__) == NoTokenSentinel:
        raise AssertionError("The type of _NoTokenSentinel___new__ should be NoTokenSentinel")
    # Restore the

# Generated at 2022-06-22 20:36:55.815211
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file = '/tmp/test_ansible_galaxy_galaxy_token.yml'

    # create config file
    token = GalaxyToken()
    token.set('token1')
    assert os.path.isfile(token_file) is True

    # overwrite config file
    token = GalaxyToken()
    token.set('token2')
    assert os.path.isfile(token_file) is True

    # remove config file
    token = GalaxyToken(token=None)
    token.save()
    assert os.path.isfile(token_file) is False
    # cleanup
    os.remove(token_file)


# Generated at 2022-06-22 20:36:57.152186
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    r = GalaxyToken()
    assert type(r) == GalaxyToken


# Generated at 2022-06-22 20:37:04.241309
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    bat = BasicAuthToken('username')

    # no password
    expected = {'Authorization': 'Basic dXNlcm5hbWU6'}
    assert bat.headers() == expected

    # password
    bat = BasicAuthToken('username', 'password')
    expected = {'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='}
    assert bat.headers() == expected

    # non-ascii password
    bat = BasicAuthToken('username', '\u2713')
    expected = {'Authorization': 'Basic dXNlcm5hbWU64pyT'}
    assert bat.headers() == expected

    # non-ascii username
    bat = BasicAuthToken('\u2713')

# Generated at 2022-06-22 20:37:15.552056
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    import filecmp

    test_file = "test.yaml"
    test_token = "testtoken"

    old_file = "test_old.yaml"
    old_token = "testoldtoken"

    gt = GalaxyToken()

    # A new file should be created with the token.
    gt.set(test_token)
    os.rename(test_file, old_file)
    gt.set(old_token)

    assert filecmp.cmp(test_file, old_file), "The file should be the same since the token has not changed."

    # The token should be changed if different than the current token.
    gt.set(test_token)
    os.rename(test_file, old_file)
    gt.set(test_token)

    assert not filecmp.cmp

# Generated at 2022-06-22 20:37:19.162829
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.config['token'] = 'foo'
    galaxy_token.save()

# Generated at 2022-06-22 20:37:21.960225
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    headers = BasicAuthToken('foouser','foopass').headers()
    assert headers['Authorization'] == 'Basic Zm9vdXNlcjpmb29wYXNz'

# Generated at 2022-06-22 20:37:33.566627
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-22 20:37:44.714907
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # test case
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    my_config = {'test_key': 'test_value'}

    # remove token file before test
    if os.path.isfile(b_file):
        os.remove(b_file)

    # run test
    GalaxyToken().set(my_config)

    # after save config to token file, open token file and read it
    with open(b_file, 'r') as f:
        my_open_config = yaml_load(f)

    # assert test result
    assert my_config == my_open_config

# Generated at 2022-06-22 20:37:52.136972
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    import sys
    pyversion = sys.version_info[0]

    pswd = 'myPassword'
    token = BasicAuthToken(username='myUser', password='myPassword')

    # we use b'' to test bytes
    # we use u'' to test str
    # we use '' to test both

    if pyversion == 3:
        if isinstance(pswd, bytes):
            assert isinstance(token.get(), str)
        elif isinstance(pswd, str):
            assert isinstance(token.get(), str)
        else:
            raise AssertionError("Unknown type for password")
    else:
        if isinstance(pswd, bytes):
            assert isinstance(token.get(), bytes)
        elif isinstance(pswd, str):
            assert isinstance(token.get(), str)

# Generated at 2022-06-22 20:37:54.105237
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel()


# Generated at 2022-06-22 20:38:05.517949
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file = C.GALAXY_TOKEN_PATH + ".test"
    t = GalaxyToken()
    t.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    t.save()
    assert(os.path.isfile(token_file))
    with open(to_bytes(token_file, errors='surrogate_or_strict'), 'w') as f:
        f.write(to_bytes('{}', errors='surrogate_or_strict'))
    t.save()
    assert(os.path.isfile(token_file))
    os.unlink(to_bytes(token_file, errors='surrogate_or_strict'))



# Generated at 2022-06-22 20:38:13.085604
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken(access_token=None, auth_url=None, validate_certs=True, client_id=None)
    assert(kct is not None)

    kct = KeycloakToken(access_token="", auth_url="", validate_certs=True, client_id=None)
    assert(kct is not None)

    kct = KeycloakToken(access_token="", auth_url="", validate_certs=True, client_id="")
    assert(kct is not None)

    kct = KeycloakToken(access_token="", auth_url="", validate_certs=True, client_id="client_id")
    assert(kct is not None)


# Generated at 2022-06-22 20:38:21.207018
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'test_username'
    password = 'test_password'
    token = "%s:%s" % (username, password)
    b64_val = base64.b64encode(token)
    b64_val_str = to_text(b64_val)
    token_test = BasicAuthToken(username, password)
    token_test.get()
    assert token_test._token == b64_val_str, "_token doesn't match b64_val_str"

# Generated at 2022-06-22 20:38:24.198723
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    from ansible.module_utils.common.collections import ImmutableDict

    obj1 = NoTokenSentinel()
    obj2 = NoTokenSentinel()

    assert obj1
    assert obj2

    assert obj1 is obj2

    assert obj1.__dict__ == obj2.__dict__ == ImmutableDict()

# Generated at 2022-06-22 20:38:35.017706
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    print("")
    print("Running tests for class GalaxyToken method get")
    print("")
    print("Testing with a valid value")
    b_file = to_bytes("test/galaxy_token", errors='surrogate_or_strict')
    config = {"token": "valid_token"}
    with open(b_file, 'w') as f:
        yaml_dump(config, f, default_flow_style=False)
    galaxy_token = GalaxyToken()
    assert galaxy_token.get() == "valid_token", "Unable to get the token value"
    print("")

    print("Testing with an invalid value")
    config = {"token": "invalid_token"}

# Generated at 2022-06-22 20:38:39.054993
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken()
    headers = gt.headers()
    assert headers['Authorization'].startswith('Token')


# Generated at 2022-06-22 20:38:49.040597
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'keycloak_token'
    auth_url = 'auth_url'
    validate_certs = True
    client_id = 'client_id'
    token = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=validate_certs, client_id=client_id)

    token.access_token = access_token
    token.auth_url = auth_url
    token.validate_certs = validate_certs
    token.client_id = client_id

    token._token = 'token'

    token._form_payload = lambda : 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (client_id, access_token)

    token.get = lambda : token._

# Generated at 2022-06-22 20:38:51.931510
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='supersecret', auth_url='https://stage-api.cloud.redhat.com/v1/sso/token')
    headers = kct.headers()
    assert headers['Authorization'] == 'Bearer supersecret'

# Generated at 2022-06-22 20:39:01.027180
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # When file does not exist
    # Then it should create the file
    token_file = "/tmp/test_GalaxyToken_get.txt"
    if os.path.exists(token_file):
        os.remove(token_file)
    token = GalaxyToken()
    token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token.get()
    assert os.path.exists(token_file)

    # When file is valid yaml
    # Then it should read it
    with open(token_file, 'w') as f:
        yaml_dump({'token': "abc123"}, f, default_flow_style=False)
    token = GalaxyToken()

# Generated at 2022-06-22 20:39:03.604498
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)

# Generated at 2022-06-22 20:39:05.530041
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert gt
    assert gt.config == {}


# Generated at 2022-06-22 20:39:17.637775
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    try:  # pragma: no cover
        # Python 2
        from urllib2 import Request, urlopen
        from urllib import urlencode
    except ImportError:  # pragma: no cover
        # Python 3
        from urllib.request import Request, urlopen
        from urllib.parse import urlencode

    def post(url, body):
        request = Request(url)
        request.add_header('Content-Type', 'application/x-www-form-urlencoded')
        response = urlopen(request, data=body)
        return to_native(response.read().decode('utf-8'))

    class MockAuthUrl(object):
        def __init__(self, text):
            self.text = text

        def read(self):
            return self.text


# Generated at 2022-06-22 20:39:21.890112
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    KeycloakToken(access_token='test_refresh_token', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', client_id='cloud-services')

# Generated at 2022-06-22 20:39:25.005528
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    user = BasicAuthToken('username', 'password')
    headers = user.headers()
    assert headers['Authorization'] == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='



# Generated at 2022-06-22 20:39:36.022480
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:39:37.497904
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    test_token = NoTokenSentinel()
    assert test_token


# Generated at 2022-06-22 20:39:40.608860
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    t = GalaxyToken()
    assert isinstance(t, GalaxyToken)


# Is the ansible config file readable or do we have permission to write it?

# Generated at 2022-06-22 20:39:44.202876
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('my_token', 'http://localhost:8080', validate_certs=False, client_id=None)
    assert token


# Generated at 2022-06-22 20:39:47.229600
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token1 = GalaxyToken().get()
    assert token1 == None

    token2 = GalaxyToken(token='123').get()
    assert token2 == '123'



# Generated at 2022-06-22 20:39:54.467976
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    import os

    # Test if GALAXY_TOKEN_PATH can be changed
    os.environ['GALAXY_TOKEN_PATH'] = '/tmp/test_galaxy_token'
    token = GalaxyToken()

    # Clean up
    os.environ.clear()
    os.remove(token.b_file)

    # Test if GALAXY_TOKEN_PATH can be changed
    token = GalaxyToken()

    # Clean up
    os.remove(token.b_file)


if __name__ == '__main__':
    test_GalaxyToken()

# Generated at 2022-06-22 20:40:05.388589
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-22 20:40:13.511106
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    b_file = to_bytes('/tmp/test_galaxy_token_file', errors='surrogate_or_strict')
    os.system('rm -f %s' % b_file)
    gt = GalaxyToken()
    gt.set('test_token')
    assert os.path.isfile(b_file)
    os.system('rm -f %s' % b_file)
    gt = GalaxyToken()
    gt.set(NoTokenSentinel)
    assert not os.path.isfile(b_file)
    os.system('rm -f %s' % b_file)

# Generated at 2022-06-22 20:40:18.226629
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    test_username = "test_username"
    test_password = "test_password"
    basic_auth_token = BasicAuthToken(test_username, test_password)
    headers = basic_auth_token.headers()
    basic_auth_token_authorization = headers['Authorization']
    assert basic_auth_token_authorization == "Basic dGVzdF91c2VybmFtZTp0ZXN0X3Bhc3N3b3Jk"

# Generated at 2022-06-22 20:40:19.936670
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    my_obj = NoTokenSentinel()
    assert isinstance(my_obj, NoTokenSentinel)


# Generated at 2022-06-22 20:40:26.988115
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Declare a mock object that implements the same methods than class GalaxyToken
    # This will allow mocking the method yaml_load
    class GalaxyTokenMock():
        def __init__(self, token=None):
            self._config = {}
            self._token = token

        @property
        def config(self):
            return self._config

        def set(self, token):
            self._token = token

        def get(self):
            return self._token

    galaxy_token_mock = GalaxyTokenMock()

    # Test the edge cases
    assert None is galaxy_token_mock.get()
    galaxy_token_mock.set('abc')
    assert 'abc' == galaxy_token_mock.get()

# Generated at 2022-06-22 20:40:38.156275
# Unit test for method get of class GalaxyToken

# Generated at 2022-06-22 20:40:41.537315
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('refresh_token')
    token._form_payload = Mock(return_value='grant_type=refresh_token')
    token.get()

# Generated at 2022-06-22 20:40:49.801314
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.constants import GALAXY_TOKEN_PATH
    import yaml
    import os
    import os.path

    # Create a config file

    config = {'email': 'me@home.com', 'token': 'abcd'}
    token = GalaxyToken(token=config['token'])
    token.set(config['token'])
    token.save()

    # Read config back

    with open(GALAXY_TOKEN_PATH, 'r') as stream:
        token_file = yaml.load(stream)
        assert token_file['token'] == config['token']

    # Cleanup

    os.remove(GALAXY_TOKEN_PATH)


# Generated at 2022-06-22 20:41:00.336190
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file = os.path.join(os.path.dirname(__file__), u"test_galaxy_token")
    config = {u'token': u'fake_token', u'url': u'http://galaxy.server/api/', u'ignore_certs': False}
    gt = GalaxyToken(None)
    gt.b_file = token_file
    gt._config = config
    gt.save()
    gt._config = None
    cfg2 = gt.config
    assert (config == cfg2)
    os.remove(token_file)



# Generated at 2022-06-22 20:41:03.232477
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():

    # Test if it get the right token
    token = BasicAuthToken('username', 'password')

    assert token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-22 20:41:12.501234
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    t = KeycloakToken(access_token="long-token-for-testing", auth_url="https://www.example.com")
    print("The test is about to try to obtain a token")
    h = t.headers()
    print("The test has obtained a token")
    print("The token is = %s" % h['Authorization'])
    if h['Authorization'] == 'Bearer long-returned-token':
        print("The test has succeeded")
    else:
        print("The test has failed")

#test_KeycloakToken_headers()

# Generated at 2022-06-22 20:41:14.922020
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = '12345'
    gt = GalaxyToken()
    assert gt.config == {}
    gt.set(token)
    assert gt.config == {'token': token}


# Generated at 2022-06-22 20:41:16.394679
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    auth_token = GalaxyToken()
    assert auth_token



# Generated at 2022-06-22 20:41:18.774372
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    notoken = NoTokenSentinel()
    assert notoken is not None

# Generated at 2022-06-22 20:41:30.209134
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import os
    import pytest
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    import ssl

    # Build KeycloakToken instance using parameters
    access_token = os.environ['TEST_ACCESS_TOKEN']
    auth_url = os.environ['TEST_AUTH_URL']
    validate_certs = True
    client_id = 'cloud-services'
    kct = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    # Expected response from Keycloak

# Generated at 2022-06-22 20:41:33.700146
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('abc')
    assert token.headers() == {'Authorization': 'Token abc'}
    token = GalaxyToken(None)
    assert token.headers() == {}


# Generated at 2022-06-22 20:41:38.893762
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    b_test = BasicAuthToken('test_user', 'test_password')
    assert b_test.get() == 'dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='
    b_test2 = BasicAuthToken('test_user', None)
    assert b_test2.get() == 'dGVzdF91c2VyOg=='

# Generated at 2022-06-22 20:41:50.991480
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import pytest
    from ansible.test.test_utils.test_collection_galaxy import MockConfig
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = None
    from ansible.cli.galaxy import _get_collections
    from ansible.constants import GALAXY_TOKEN_PATH

    test_token = 'test_token'
    test_collections = {'fake_collection_name': 'fake_collection_namespace'}

    with MockConfig() as mock_clicfg:

        with pytest.raises(Exception) as excp:
            _get_collections()

        expected_msg = "Unable to save token %s: No such file or directory" % GALAXY_TOKEN_PATH
        assert expected_msg == str(excp.value)

       

# Generated at 2022-06-22 20:41:54.899497
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    token = NoTokenSentinel()
    assert isinstance(token, NoTokenSentinel)


# Generated at 2022-06-22 20:41:57.821852
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    print("Testing constructor for class GalaxyToken...")
    token = GalaxyToken()
    assert token is not None
    print("Testing constructor for class GalaxyToken... Passed")


# Generated at 2022-06-22 20:42:00.993124
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    cls = NoTokenSentinel.__new__(NoTokenSentinel)

# Generated at 2022-06-22 20:42:06.406136
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token=NoTokenSentinel)
    headers = token.headers()
    assert headers == {}, headers
    token.set('dfdsfsdf')
    headers = token.headers()
    assert headers == {'Authorization': 'Token dfdsfsdf'}, repr(headers)

# Generated at 2022-06-22 20:42:09.078132
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token="123123123", auth_url="https://auth.url")

# Generated at 2022-06-22 20:42:19.854832
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import os
    import sys
    import json

    # Import patching modules
    from ansible.module_utils.urls import open_url, Response

    import ansiblegalaxy.token

    class TestKeycloakToken(ansiblegalaxy.token.KeycloakToken):
        def __init__(self, access_token):
            self.access_token = access_token
            self.auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
            self._token = None
            self.validate_certs = True
            self.client_id = 'cloud-services'


# Generated at 2022-06-22 20:42:25.701024
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # given
    token = 'this-is-a-token'
    config = {'token': token, 'url': 'http://unknown'}

    # when
    result = GalaxyToken(token).get()

    # then
    assert token == result

    # when
    galaxy_token = GalaxyToken()
    galaxy_token._config = config
    result = galaxy_token.get()

    # then
    assert token == result


# Generated at 2022-06-22 20:42:27.455336
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)

# Generated at 2022-06-22 20:42:36.278203
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken(access_token='offline_token')
    assert keycloak_token.access_token == 'offline_token'

    keycloak_token = KeycloakToken(access_token='offline_token', auth_url='http://authurl/')
    assert keycloak_token.auth_url == 'http://authurl/'

    keycloak_token = KeycloakToken(access_token='offline_token', auth_url='http://authurl/', client_id='id')
    assert keycloak_token.client_id == 'id'

    keycloak_token = KeycloakToken(access_token='offline_token', auth_url='http://authurl/', validate_certs=False)
    assert not keycloak_token.validate_cert

# Generated at 2022-06-22 20:42:38.857113
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    no_token = NoTokenSentinel()
    assert isinstance(no_token, NoTokenSentinel), 'NoTokenSentinel constructor returned a non-NoTokenSentinel object'

# Generated at 2022-06-22 20:42:50.806145
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Class variables
    b_file = '/fake/path/ansible.cfg'
    b_token = '25568a56-c65d-43ca-934b-46297db09f42'
    b_token_file_content = 'token: %s\n' % b_token.encode('utf-8')

    # Mocks that use class variable(s)
    def m_open(path, mode):
        # file was opened?
        assert path == b_file

        # correct open mode used?
        assert mode == 'r'
        return f

    def m_read():
        # read file content
        return b_token_file_content

    def m_is_file(path):
        # file existence check
        return path == b_file

    # Monkey patched mocks

# Generated at 2022-06-22 20:42:53.440128
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken()
    gt.set('my-token')
    assert gt.headers() == {'Authorization': 'Token my-token'}


# Generated at 2022-06-22 20:42:59.838607
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('usr', 'pwd')
    assert token.headers() == { 'Authorization': 'Basic dXNyOnB3ZA==' }
    token = BasicAuthToken('usr', None)
    assert token.headers() == { 'Authorization': 'Basic dXNyOg==' }
    token = BasicAuthToken(None, 'pwd')
    assert token.headers() == { 'Authorization': 'Basic OnB3ZA==' }
    token = BasicAuthToken(None, None)
    assert token.headers() == { 'Authorization': 'Basic Og==' }

# Generated at 2022-06-22 20:43:00.792864
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is not None

# Generated at 2022-06-22 20:43:03.346705
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    t = BasicAuthToken("user", "password")

    h = t.headers()
    assert 'Authorization' in h
    assert h['Authorization'] == 'Basic %s' % t.get()

# Generated at 2022-06-22 20:43:04.304424
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    s = NoTokenSentinel()
    return True

# Generated at 2022-06-22 20:43:16.381823
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Test a unix password
    unix_password = 'I#@$*#@K!*#@)K!R@(#*@K$R@#(*K$R@(*#K$R@(#K$RKnsible'

# Generated at 2022-06-22 20:43:25.731372
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_file = '/tmp/test_GalaxyToken.yml'
    token_test = GalaxyToken(token=None)
    test_token = {'token': 'test'}

    token_test.config = test_token
    token_test.b_file = to_bytes(test_file, errors='surrogate_or_strict')

    token_test.set(None)
    assert token_test.get() == test_token['token']

    token_test.set(token_test.token_type)
    assert token_test.get() == token_test.token_type

# Generated at 2022-06-22 20:43:30.575503
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test without instance
    try: BasicAuthToken._encode_token()
    except TypeError: pass
    else: return "Failed: Method BasicAuthToken._encode_token() without arguments should raise TypeError"

    # Test with instance and with non-text username and password (default for password is None)
    token = BasicAuthToken("foo", "bar")
    try: result = token.get()
    except TypeError: return "Failed: Method get() of BasicAuthToken instance should return text"
    else: pass
    if result != "Zm9vOmJhcg==": return "Failed: Method get() of BasicAuthToken instance should return 'Zm9vOmJhcg==': '%s' received" % result

    # Test with instance, with non-text username and text password
    token = BasicAuthToken

# Generated at 2022-06-22 20:43:35.824854
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('c0c7ff11-0b2a-4f9c-9a0b-57d74db97b49', 'http://localhost:8080/auth/realms/master/protocol/openid-connect/token')
    assert token.headers()['Authorization'] == 'Bearer None'

# Generated at 2022-06-22 20:43:39.799854
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    test_token = BasicAuthToken("myusername", "mysecrettoken")
    token = test_token.get()
    assert token == "bXl1c2VybmFtZTpteXNlY3JldHRva2Vu"



# Generated at 2022-06-22 20:43:43.451602
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = 'foo'
    gt = GalaxyToken(token)
    assert gt.headers() == {'Authorization': 'Token foo'}


# Generated at 2022-06-22 20:43:52.046008
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:43:58.722912
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token = KeycloakToken('abc', auth_url='abc', validate_certs=False, client_id='cloud-services')
    assert keycloak_token.access_token == "abc"
    assert keycloak_token.auth_url == "abc"
    assert keycloak_token.validate_certs == False
    assert keycloak_token.client_id == "cloud-services"
    assert keycloak_token.get() == "abc"


# Generated at 2022-06-22 20:44:02.397237
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    ''' Test for method headers of class BasicAuthToken
    '''
    auth = BasicAuthToken('test', 'password')
    output = auth.headers()
    assert output['Authorization'] == 'Basic dGVzdDpwYXNzd29yZA=='

# Generated at 2022-06-22 20:44:10.289510
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os.path
    import tempfile

    token = 'abcdef'
    token_file = tempfile.NamedTemporaryFile()
    galaxy_token = GalaxyToken()
    galaxy_token.b_file = token_file.name
    galaxy_token.set(token)
    assert os.path.isfile(token_file.name)
    with open(token_file.name) as f:
        assert yaml_load(f) == {'token': token}

# Generated at 2022-06-22 20:44:21.327094
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():

    # Default constructor call
    at = KeycloakToken()
    assert at is not None
    assert at.access_token is None
    assert at.auth_url is None
    assert at._token is None
    assert at.validate_certs is True
    assert at.client_id == 'cloud-services'

    # Constructor call with parameters
    at = KeycloakToken(access_token='abc')
    assert at is not None
    assert at.access_token == 'abc'
    assert at.auth_url is None
    assert at._token is None
    assert at.validate_certs is True
    assert at.client_id == 'cloud-services'

    at = KeycloakToken(auth_url='http://auth_url.com', validate_certs=False, client_id='my_client_id')

# Generated at 2022-06-22 20:44:23.667211
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('a', 'b').headers()
    expected_headers = {'Authorization': 'Basic YTpi'}
    assert token == expected_headers

# Generated at 2022-06-22 20:44:27.771999
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken("username", "password")
    expected_header = {'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='}
    assert token.headers() == expected_header

# Generated at 2022-06-22 20:44:30.537310
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Check that __new__ returns the same object
    assert NoTokenSentinel() is NoTokenSentinel()

# Generated at 2022-06-22 20:44:37.095810
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    mock_file = "tests/unit/module_utils/galaxy_token_test_file.yml"
    token = GalaxyToken()
    token.b_file = to_bytes(mock_file)
    token.set("test")
    token.save()
    token.set(None)
    token.save()
    os.unlink(mock_file)

# Generated at 2022-06-22 20:44:40.439546
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    test_user = 'test'
    test_password = 'password'

    basicAuthToken = BasicAuthToken(test_user, test_password)
    expected_token = to_text(b'Basic dGVzdDpwYXNzd29yZA==')
    assert basicAuthToken.get() == expected_token
    headers = basicAuthToken.headers()
    assert headers['Authorization'] == expected_token

# Generated at 2022-06-22 20:44:43.259346
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    no_token_singleton = NoTokenSentinel()
    assert no_token_singleton is NoTokenSentinel()


# Generated at 2022-06-22 20:44:46.914713
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():

    # Set a token
    galaxy_token = GalaxyToken()
    galaxy_token.set('mytoken')

    # Check the token
    assert galaxy_token.get() == 'mytoken'

    # Remove the Galaxy token file
    os.remove(C.GALAXY_TOKEN_PATH)


# Generated at 2022-06-22 20:44:56.432363
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Test with empty password
    username = 'Juanito'
    password = ''
    token = BasicAuthToken(username, password)
    assert token.get() == 'SnVhbml0bzo='

    # Test with None password
    username = 'Juanito'
    password = None
    token = BasicAuthToken(username, password)
    assert token.get() == 'SnVhbml0bzo='

    # Test with password
    username = 'Juanito'
    password = 'secret'
    token = BasicAuthToken(username, password)
    assert token.get() == 'SnVhbml0bzpzZWNyZXQ='


# Generated at 2022-06-22 20:45:01.265200
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    token = 'example_token'

    kt = KeycloakToken(access_token=token, auth_url=url)
    headers = kt.headers()

    # Test expected headers
    assert headers.get('Authorization') == 'Bearer %s' % kt.get()


# Generated at 2022-06-22 20:45:06.884638
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    t = GalaxyToken('1234')
    assert t.get() == '1234'
    assert t.headers() == {'Authorization': 'Token 1234'}
    t.set('5678')
    assert t.get() == '5678'
    assert t.headers() == {'Authorization': 'Token 5678'}

# Generated at 2022-06-22 20:45:11.937049
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken(username='admin', password='admin')
    assert token.get() is not None
    token1 = BasicAuthToken(username='admin', password=None)
    assert token1.get() is not None


# Generated at 2022-06-22 20:45:13.528131
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='abcdef')
    headers = token.headers()
    assert headers == {'Authorization': 'Token abcdef'}



# Generated at 2022-06-22 20:45:26.146276
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_path = 'galaxy.token'
    token_file = open(token_path, 'w')
    wrong_token_file = open('wrong_galaxy.token', 'w')
    token_file.write('token: test')
    token_file.close()
    wrong_token_file.write('asd: asd')
    wrong_token_file.close()

    tk = GalaxyToken()
    assert tk.b_file == 'galaxy.token'
    tk.b_file = 'wrong_galaxy.token'
    assert tk.get() is None
    tk.b_file = token_path
    assert tk.get() == 'test'

    os.remove(token_path)
    os.remove('wrong_galaxy.token')
    # The test will throw error if

# Generated at 2022-06-22 20:45:28.064346
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    t = BasicAuthToken('foo', 'bar')
    assert t.get() == 'Zm9vOmJhcg=='


# Generated at 2022-06-22 20:45:35.520816
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os

    test_token = 'abc123'
    expected_config = {'token': test_token}

    with tempfile.NamedTemporaryFile() as tmp:
        galaxy_token = GalaxyToken(token=test_token)
        galaxy_token.save()

        with open(tmp.name, 'r') as f:
            config = yaml_load(f)

        assert config == expected_config


# Generated at 2022-06-22 20:45:36.602202
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    u = NoTokenSentinel()
    assert u is not None


# Generated at 2022-06-22 20:45:39.768575
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    t = BasicAuthToken('test', 'test')
    assert t.get() == 'dGVzdDp0ZXN0'

# Generated at 2022-06-22 20:45:41.320324
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()

    assert isinstance(token, GalaxyToken)

# Generated at 2022-06-22 20:45:44.690737
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('xyz')
    assert token.config['token'] == 'xyz'

# Generated at 2022-06-22 20:45:54.265078
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    base_test_token_path = '/tmp/galaxy-token-test'
    test_token_path = to_text('%s-%d' % (base_test_token_path, os.getpid()), encoding='utf-8', errors='surrogate_or_strict')

    orig_token_path = C.GALAXY_TOKEN_PATH
