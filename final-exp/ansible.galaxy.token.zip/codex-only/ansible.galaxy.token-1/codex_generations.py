

# Generated at 2022-06-22 20:35:49.559006
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken()

    assert gt.get() == None, 'Token not initialized'

    gt.set('tokenexample')

    assert gt.get() == 'tokenexample', 'Method get not working'

# Generated at 2022-06-22 20:35:51.476193
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Single instance of NoTokenSentinel object is returned
    assert NoTokenSentinel() == NoTokenSentinel()

# Generated at 2022-06-22 20:35:53.247528
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set("test_token")
    token.save()
    assert "test_token" == token._read()['token']

# Generated at 2022-06-22 20:35:58.275149
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('foo', 'bar')
    assert token.get() == 'Zm9vOmJhcg=='
    token = BasicAuthToken('foo')
    assert token.get() == 'Zm9vOg=='
    token = BasicAuthToken('foo', None)
    assert token.get() == 'Zm9vOg=='

# Generated at 2022-06-22 20:36:04.412810
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'test_access_token'
    kt = KeycloakToken(access_token=access_token)
    headers = kt.headers()
    assert headers['Authorization'] == 'Bearer %s' % access_token


# Generated at 2022-06-22 20:36:14.948656
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves import unittest

# Generated at 2022-06-22 20:36:18.019762
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # Simply pass, test_NoTokenSentinel will raise an exception if it fails
    NoTokenSentinel()

# Generated at 2022-06-22 20:36:20.555964
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Coverage for the __new__ method
    # Couldn't get to 100% for some reason
    t = NoTokenSentinel()
    assert t is not None

# Generated at 2022-06-22 20:36:22.170285
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('testuser', 'testpassword')
    test_token = token.get()
    username_passwd = base64.b64decode(test_token).decode()
    assert username_passwd == 'testuser:testpassword'

# Generated at 2022-06-22 20:36:32.722203
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # test for username with characters that may cause encoding issues
    username = 'test1@example.com'
    password = 'passWord'
    token = BasicAuthToken(username, password)
    assert token.get() == 'dGVzdDFAZXhhbXBsZS5jb206cGFzc1dvcmQ='
    # test for username that contains only ASCII characters
    username = 'test2'
    password = None
    token = BasicAuthToken(username, password)
    assert token.get() == 'dGVzdDI6'

# Generated at 2022-06-22 20:36:37.945181
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    ansible_cfg_server_with_no_token = NoTokenSentinel()
    get_token_method = getattr(ansible_cfg_server_with_no_token, 'get_token')
    no_token_message = "Galaxy token from ansible.cfg is not available"
    assert get_token_method() == no_token_message, "NoTokenSentinel did not return expected message"



# Generated at 2022-06-22 20:36:41.293865
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # Testing for the instance of class
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)

# Generated at 2022-06-22 20:36:48.005532
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Check for normal username and password
    token = BasicAuthToken('username', 'password')
    assert token.username == 'username'
    assert token.password == 'password'

    # Check for username with special characters
    token = BasicAuthToken('username@example.com')
    assert token.username == 'username@example.com'
    assert token.password == None

    # Check for username with colon
    token = BasicAuthToken('us:er')
    assert token.username == 'us:er'
    assert token.password == None


# Generated at 2022-06-22 20:36:56.407299
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Check for expected error on empty password
    # and empty username
    try:
        token = BasicAuthToken("", "")
    except Exception:
        pass
    else:
        raise AssertionError("BasicAuthToken should throw an exception on empty username and password")
        # Check for expected error on empty password
    # and valid username
    try:
        token = BasicAuthToken("username")
    except Exception:
        pass
    else:
        raise AssertionError("BasicAuthToken should throw an exception on empty password")
    # Check for expected error empty username
    # and valid password
    try:
        token = BasicAuthToken("", "password")
    except Exception:
        pass
    else:
        raise AssertionError("BasicAuthToken should throw an exception on empty username")
    # Check for expected error on None password
    #

# Generated at 2022-06-22 20:36:57.950086
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert sentinel is not None


# Generated at 2022-06-22 20:37:01.345371
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # create a galaxy_token instance
    galaxy_token = GalaxyToken()
    # set a token
    test_token = "token1"
    galaxy_token.set(test_token)
    # call read() to test the set() method
    config = galaxy_token._read()
    # check if token is correct
    assert config['token'] == test_token

# Generated at 2022-06-22 20:37:04.783662
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    """
    Test set method of class GalaxyToken
    """
    token = GalaxyToken()
    token.set('mytoken')
    assert token.get() == 'mytoken'


# Generated at 2022-06-22 20:37:14.243502
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Show that BasicAuthToken needs a password
    username = 'testuser'
    try:
        BasicAuthToken(username)
    except Exception as e:

        # Assert that the error message output is expected
        assert('Password must be provided if username passed in' in e.args)
        pass

    # Show that BasicAuthToken works with the password provided
    try:
        assert BasicAuthToken(username, 'testpass').get() == 'dGVzdHVzZXI6dGVzdHBhc3M=' # base64 encoded testuser:testpass
    except Exception as e:
        assert(False)



# Generated at 2022-06-22 20:37:18.154504
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    auth = BasicAuthToken('myname', 'mypwd')
    token = auth.headers()['Authorization']
    assert token == 'Basic bXluYW1lOm15cHdk', 'Expect "Basic bXluYW1lOm15cHdk", but get "%s"' % token

# Generated at 2022-06-22 20:37:25.514567
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set("abcd")

    config = token.config
    assert config == {'token': 'abcd'}

    token.save()
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        yaml_config = yaml_load(f)

    assert yaml_config['token'] == token.config['token']

# Generated at 2022-06-22 20:37:33.475164
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = 'foo'
    password = 'bar'
    username2 = 'foo2'
    password2 = 'bar2'

    token = BasicAuthToken(username, password)
    token2 = BasicAuthToken(username2, password2)

    expected_headers = {}
    expected_headers['Authorization'] = 'Basic Zm9vOmJhcg=='
    expected_headers2 = {}
    expected_headers2['Authorization'] = 'Basic Zm9vMjpiYXIy'

    assert token.headers() == expected_headers
    assert token2.headers() == expected_headers2

# Generated at 2022-06-22 20:37:37.657169
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    b = BasicAuthToken('abc')
    t = b.get()
    assert t == b'YWJjOg=='

# Generated at 2022-06-22 20:37:46.932461
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # Test Constructor
    kct = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url')
    assert kct.access_token == 'test_access_token'
    assert kct.auth_url == 'test_auth_url'
    assert kct.validate_certs == True
    assert kct.client_id == 'cloud-services'
    assert 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % ('cloud-services', 'test_access_token') == kct._form_payload()

# Generated at 2022-06-22 20:37:53.496283
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.galaxy import _token

    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-22 20:37:55.530182
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('foo')
    assert token.token_type == 'Bearer'



# Generated at 2022-06-22 20:38:06.989248
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # This is expected to run with the CWD in the root of the ansible code.
    username = 'testuser'
    password = 'testpassword'
    token = 'dGVzdHVzZXI6dGVzdHBhc3N3b3Jk' # username:password
    b64_auth = BasicAuthToken(username, password)
    assert b64_auth is not None
    assert b64_auth.token_type == 'Basic'
    assert b64_auth.username == 'testuser'
    assert b64_auth.password == 'testpassword'
    assert b64_auth.get() == token
    assert b64_auth.headers().get('Authorization') == 'Basic %s' % token


if __name__ == '__main__':
    import pytest


# Generated at 2022-06-22 20:38:18.200103
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    sys_username = 'testuser'
    cli_username = 'user_from_cli'
    cli_password = 'secret'
    file_username = 'user_from_file'
    file_password = 'file_secret'
    success = False
    try:
        auth_token_from_sys = BasicAuthToken(sys_username)
        auth_token_from_sys.get()
    except TypeError:
        success = True
    assert success

    success = False
    try:
        auth_token_from_cli = BasicAuthToken(cli_username, cli_password)
        auth_token_from_cli.get()
    except TypeError:
        success = True
    assert success

    success = False

# Generated at 2022-06-22 20:38:21.272646
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'a_token'

    # Init class GalaxyToken
    galaxy_token = GalaxyToken(token)
    # Call the method save()
    galaxy_token.save()

    assert token == galaxy_token.get()

# Generated at 2022-06-22 20:38:22.587777
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)

# Generated at 2022-06-22 20:38:25.518930
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nts = NoTokenSentinel()
    assert isinstance(nts, NoTokenSentinel)



# Generated at 2022-06-22 20:38:33.372561
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    my_token = BasicAuthToken('x', 'y')
    assert my_token.username == 'x'
    assert my_token.password == 'y'
    assert my_token.get() == 'eDo6eQ=='
    assert my_token.token_type == 'Basic'
    assert my_token.headers() == {'Authorization': 'Basic eDo6eQ=='}


# Generated at 2022-06-22 20:38:38.629236
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak = KeycloakToken(access_token='abc')
    headers = keycloak.headers()
    assert headers['Authorization'] == 'Bearer None'


# Generated at 2022-06-22 20:38:46.748197
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    import sys
    import unittest

    from ansible.galaxy.token import KeycloakToken

    class TestKeycloakToken(unittest.TestCase):

        def setUp(self):
            self.test_keycloak_token = KeycloakToken()

        def test_init(self):
            self.assertIsInstance(self.test_keycloak_token, KeycloakToken)

    suite = unittest.TestLoader().loadTestsFromModule(TestKeycloakToken())
    unittest.TextTestRunner(verbosity=3).run(suite)

if __name__ == '__main__':
    if 'TEST_KEYCLOAK_TOKEN' in os.environ:
        test_KeycloakToken()

# Generated at 2022-06-22 20:38:51.626298
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # test with no token
    token = GalaxyToken()
    assert token.headers() == {}

    # test with token
    token = GalaxyToken('token')
    assert token.headers() == {'Authorization': 'Token token'}

# Generated at 2022-06-22 20:38:57.755080
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # Note: This is the un-encrypted token.
    https_galaxy_server = 'https://cloud.redhat.com/api/automation-hub/api/'
    test_token = 'TEST-TOKEN'
    obj = GalaxyToken(token=test_token)
    expected_token_header = 'Token TEST-TOKEN'
    assert obj.headers()['Authorization'] == expected_token_header



# Generated at 2022-06-22 20:39:01.747886
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    no_token_sentinel = NoTokenSentinel()

    assert type(no_token_sentinel) == NoTokenSentinel


# Generated at 2022-06-22 20:39:05.232895
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    t = GalaxyToken(token=NoTokenSentinel)
    assert t.config == {}
    t = GalaxyToken(token='foo')
    assert t.config['token'] == 'foo'

# Generated at 2022-06-22 20:39:10.498508
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'test token'
    gx_token = GalaxyToken()
    gx_token.set(token)

    assert gx_token.get() == token



# Generated at 2022-06-22 20:39:13.809838
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Test with no token
    token = GalaxyToken()
    assert token.get() is None

    # Test with token
    token = GalaxyToken("test_token")
    assert token.get() == "test_token"


# Generated at 2022-06-22 20:39:14.383113
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    pass

# Generated at 2022-06-22 20:39:17.592232
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Arrange
    class_object = BasicAuthToken(username='bob', password='pass')

    # Act
    result = class_object.get()

    # Assert
    assert result == 'Ym9iOnBhc3M='

# Generated at 2022-06-22 20:39:21.453639
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Setup Galaxy Token
    t = GalaxyToken()

    # Save galaxy token
    t.save()

    # Remove galaxy token
    os.remove(C.GALAXY_TOKEN_PATH)



# Generated at 2022-06-22 20:39:26.671728
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # test with token
    token = "blahtokenblah"
    test_galaxy_token = GalaxyToken(token=token)
    assert test_galaxy_token.get() == token
    assert test_galaxy_token.headers() == {'Authorization': 'Token %s' % token}
    # test without token
    test_galaxy_token = GalaxyToken()
    assert test_galaxy_token.get() == None
    assert test_galaxy_token.headers() == {}

# Generated at 2022-06-22 20:39:32.236474
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Open the token file to be able to read the updated version
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    f = open(b_file, 'r')
    # Set that file as the GalaxyToken._config dict
    config = yaml_load(f)
    # Delete the variable so that there is not a memory leak
    del f
    # Reset the variable stored in the file to None
    token = config['token']
    config['token'] = None
    # Save the variable
    g = GalaxyToken()
    g._config = config
    g.save()
    # Open the file to be able to read it and check that the variable is None
    f = open(b_file, 'r')

# Generated at 2022-06-22 20:39:36.122790
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken(None)
    galaxy_token._config = {}
    assert galaxy_token.get() == None
    galaxy_token._config = {'token': '12345'}
    assert galaxy_token.get() == '12345'


# Generated at 2022-06-22 20:39:37.133122
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert token

# Generated at 2022-06-22 20:39:44.889717
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    cfc = GalaxyToken()
    cfc = GalaxyToken(None)
    cfc = GalaxyToken(NoTokenSentinel)
    cfc = GalaxyToken(token='CUSTOM_TOKEN')
    assert cfc.config == {'token': None}
    assert cfc.get() is None
    cfc.set(None)
    assert cfc.config == {'token': None}
    assert cfc.get() is None

# Generated at 2022-06-22 20:39:47.894740
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    gt = GalaxyToken()
    assert gt.get() is None
    gt.set('foo')
    assert gt.get() == 'foo'



# Generated at 2022-06-22 20:39:56.791887
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    assert BasicAuthToken('user', 'pass').headers()['Authorization'] == 'Basic dXNlcjpwYXNz'
    assert BasicAuthToken('user', '').headers()['Authorization'] == 'Basic dXNlcjo='
    assert BasicAuthToken('user', None).headers()['Authorization'] == 'Basic dXNlcjo='
    assert BasicAuthToken('user').headers()['Authorization'] == 'Basic dXNlcjo='
    assert BasicAuthToken(u'user').headers()['Authorization'] == u'Basic dXNlcjo='
    assert BasicAuthToken(None, 'pass').headers()['Authorization'] == 'Basic OnBhc3M='
    assert BasicAuthToken(username=None, password='').headers()['Authorization'] == 'Basic Og=='

# Generated at 2022-06-22 20:39:58.504917
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    ansible_cfg_token_noval = NoTokenSentinel()
    assert ansible_cfg_token_noval is not None
    assert str(ansible_cfg_token_noval) == "NoTokenSentinel()"

# Generated at 2022-06-22 20:39:59.911176
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    obj = NoTokenSentinel()
    assert type(obj) is NoTokenSentinel


# Generated at 2022-06-22 20:40:02.102570
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    t = GalaxyToken()
    assert isinstance(t, GalaxyToken)
    assert t.config is not None
    assert isinstance(t.config, dict)

# Generated at 2022-06-22 20:40:07.460513
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    base = BasicAuthToken('foo', 'bar')
    assert base.headers()['Authorization'] == 'Basic Zm9vOmJhcg=='

    base = BasicAuthToken('anonymous')
    assert base.headers()['Authorization'] == 'Basic YW5vbnltb3Vz'

    base = BasicAuthToken('anonymous', None)
    assert base.headers()['Authorization'] == 'Basic YW5vbnltb3Vz'

# Generated at 2022-06-22 20:40:10.460508
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken("abc", "https://sso.redhat.com", True, "cloud-services")
    headers = kt.headers()
    assert headers['Authorization'] is not None

# Generated at 2022-06-22 20:40:15.877017
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = "abc123"
    # On Linux GalaxyToken.token_type should default to 'Token'
    token_type = 'Token'
    expected_header = 'Token abc123'
    
    t = GalaxyToken(token=token)
    assert t.token_type == token_type
    assert t.headers() == {'Authorization': expected_header}

# Generated at 2022-06-22 20:40:18.593486
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    test_token = 'test_token'
    galaxy_token = GalaxyToken()
    galaxy_token.set(test_token)
    assert galaxy_token.get() == test_token

# Generated at 2022-06-22 20:40:24.324909
# Unit test for method headers of class BasicAuthToken

# Generated at 2022-06-22 20:40:29.378838
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()

    if not isinstance(sentinel, NoTokenSentinel):
        raise AssertionError('sentinel is not an instance of NoTokenSentinel')


# Generated at 2022-06-22 20:40:36.461039
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('foo')
    assert token.get() is None
    token = KeycloakToken('foo', auth_url='https://example.com', validate_certs=False)
    assert token.get() is None
    token = KeycloakToken('foo', auth_url='https://example.com')
    assert token.get() is None
    token = KeycloakToken('foo', auth_url='https://example.com', client_id='baz')
    assert token.get() is None

# Generated at 2022-06-22 20:40:43.002687
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    bt = BasicAuthToken('user', 'pass')
    assert bt.get() == 'dXNlcjpwYXNz'

    bt = BasicAuthToken('user', '')
    assert bt.get() == 'dXNlcjo='

    bt = BasicAuthToken('user', None)
    assert bt.get() == 'dXNlcjo='

# Generated at 2022-06-22 20:40:46.123798
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'xfbewuf3qn3nq3h2nu43'
    token_obj = GalaxyToken()
    token_obj.set(token)
    assert token == token_obj.get()


# Generated at 2022-06-22 20:40:49.276664
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = '1234'
    test_obj = GalaxyToken(token)
    assert(test_obj.get() == token)
    assert(test_obj.headers() == {'Authorization': 'Token ' + token})


# Generated at 2022-06-22 20:41:01.233781
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # test setup
    # 1. file exists
    # 2. file is created by ansible
    # 3. file is readable/writable by owner

    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')

    def _cleanup():
        if os.path.isfile(b_file):
            os.remove(b_file)

    _cleanup()
    galaxy_token = GalaxyToken()
    assert not os.path.isfile(b_file)
    galaxy_token.save()

    assert os.path.isfile(b_file)
    assert os.access(b_file, os.R_OK | os.W_OK)

    # cleanup
    _cleanup()



# Generated at 2022-06-22 20:41:04.065364
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('admin', 'mysecret')
    headers = token.headers()
    expected = {'Authorization': 'Basic YWRtaW46bXlzZWNyZXQ='}
    assert headers == expected

# Generated at 2022-06-22 20:41:07.734256
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    x = BasicAuthToken('xxx', 'xxx')
    x.get()
    x.headers()

# Generated at 2022-06-22 20:41:16.376195
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:41:20.794477
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kt = KeycloakToken(auth_url='https://auth.url.com', access_token='fake_token')
    assert kt.auth_url == 'https://auth.url.com'
    assert kt.access_token == 'fake_token'



# Generated at 2022-06-22 20:41:24.640652
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    header = BasicAuthToken('test', 'password').headers()
    header_dict = header['Authorization']
    expected = "Basic dGVzdDpwYXNzd29yZA=="
    assert header_dict == expected

# Generated at 2022-06-22 20:41:36.595724
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:41:39.474373
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    try:
        x = NoTokenSentinel()
    except TypeError as e:
        assert False, "NoTokenSentinel constructor failed"

# Generated at 2022-06-22 20:41:46.878429
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():

    # test case for headers of GalaxyToken class
    # when token is not none
    token = 'fake_token'
    galaxy_token = GalaxyToken(token)
    assert galaxy_token.headers() == {'Authorization': 'Token %s' % token}

    # test case for headers of GalaxyToken class
    # when token is none
    galaxy_token = GalaxyToken()
    assert galaxy_token.headers() == {}



# Generated at 2022-06-22 20:41:49.630735
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    user = ""
    password = ""
    token = BasicAuthToken(user, password)

    if token.get() == "Og==":
        return True
    else:
        return False

# Generated at 2022-06-22 20:41:57.087127
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    token_string = galaxy_token.get()
    assert token_string == None

    galaxy_token = GalaxyToken(token="this_is_a_token")
    token_string = galaxy_token.get()
    assert token_string == "this_is_a_token"

    config = {'token': 'Token this_is_a_token'}
    galaxy_token = GalaxyToken()
    galaxy_token._config = config
    token_string = galaxy_token.get()
    assert token_string == "this_is_a_token"



# Generated at 2022-06-22 20:41:59.939725
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    basicAuthToken = BasicAuthToken('testuser', 'testpassword')
    assert basicAuthToken.headers() == {'Authorization': 'Basic dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'}

# Generated at 2022-06-22 20:42:03.001706
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    from ansible.galaxy.token import NoTokenSentinel
    nts = NoTokenSentinel()
    assert nts


# Generated at 2022-06-22 20:42:15.400918
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.config.manager import ConfigManager
    from ansible.utils.path import unfrackpath

    cm = ConfigManager()

    # Test no file
    if os.path.isfile(C.GALAXY_TOKEN_PATH):
        os.remove(C.GALAXY_TOKEN_PATH)
    assert not os.path.isfile(C.GALAXY_TOKEN_PATH)

    token = GalaxyToken()
    assert token.get() is None

    # Test empty file
    open(C.GALAXY_TOKEN_PATH, 'a').close()
    token = GalaxyToken()
    assert token.get() is None

    # Test invalid file

# Generated at 2022-06-22 20:42:23.504005
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    import ansible.constants as C

    C.GALAXY_TOKEN_PATH = '/tmp/test_galaxy_token_file'
    os.system('echo "token: TEST_TOKEN_VALUE" > %s' % C.GALAXY_TOKEN_PATH)

    token = GalaxyToken()
    actual = token.headers()
    expected = {'Authorization': 'Token TEST_TOKEN_VALUE'}

    assert actual == expected

    os.system('rm %s' % C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-22 20:42:31.153529
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Test create a new file
    test_file = C.GALAXY_TOKEN_PATH + '.test'
    config = GalaxyToken(NoTokenSentinel)
    config.b_file = to_bytes(test_file, errors='surrogate_or_strict')
    try:
        config.save()
    except IOError:
        assert False, 'Fail to create the new file'

    # Test write a token into a file
    token = '1234'
    config.set(token)

    assert os.path.isfile(test_file)

    with open(test_file, 'r') as f:
        token_value = yaml_load(f)

    assert token_value == {'token': token}

    # Test change the token value
    token = '5678'

# Generated at 2022-06-22 20:42:34.522968
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken()
    gt.config = {'token': 'mock_token'}
    assert(gt.get() == 'mock_token')

# Generated at 2022-06-22 20:42:39.466066
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    """
    This ut is testing the basic auth token get method
    """
    user_name = 'test_my_name'
    pass_word = 'test_my_password'
    token_obj = BasicAuthToken(user_name, pass_word)
    res = token_obj.get()
    assert 'Basic' in res



# Generated at 2022-06-22 20:42:44.412362
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(auth_url='https://sso.redhat.com/auth', access_token='FAKE_TOKEN')
    expected = {'Authorization': 'Bearer FAKE_TOKEN'}
    assert token.headers() == expected

# Generated at 2022-06-22 20:42:47.383688
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    t = GalaxyToken(token='test-token')
    t.set(token='new-test-token')
    assert t.config['token'] == 'new-test-token'

# Generated at 2022-06-22 20:42:48.901106
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken()
    assert gt.get() is None

# Generated at 2022-06-22 20:42:52.254212
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken('ABCD1234')
    hdrs = kt.headers()

    assert 'Authorization' in hdrs
    assert hdrs['Authorization'] == "Bearer ABCD1234"


# Generated at 2022-06-22 20:42:54.900217
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert isinstance(gt.config, dict), "Expected a dict, got %s" % type(gt.config)



# Generated at 2022-06-22 20:42:57.912481
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    obj = NoTokenSentinel()
    assert obj is not None, 'obj is None'


# Generated at 2022-06-22 20:43:05.563539
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Test for error case: username is empty and password is None
    try:
        BasicAuthToken(username = "",password = None)
    except TypeError as detail:
        assert str(detail) == "Username and password are required"
    except:
        # Error case not covered
        assert False

    # Test for error case: username is empty and password is wrong type
    try:
        BasicAuthToken(username = "",password = 0)
    except TypeError as detail:
        assert str(detail) == "Username and password are required"
    except:
        # Error case not covered
        assert False

    # Test for normal case: username and password is normal type
    BasicAuthToken(username="test", password="test")

# Generated at 2022-06-22 20:43:09.429673
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bat = BasicAuthToken('test','test')
    assert bat.get() == 'dGVzdDp0ZXN0'
    assert bat.headers()['Authorization'] == 'Basic dGVzdDp0ZXN0'



# Generated at 2022-06-22 20:43:10.047247
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoTokenSentinel()

# Generated at 2022-06-22 20:43:22.445718
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    if not os.path.exists("test_data/keycloak_test_data.json"):
        return
    import json
    import requests
    from ansible.module_utils.urls import open_url

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.keycloak_token import KeycloakToken

    # with open("test_data/keycloak_test_data.json") as f:
    #     test_data = json.load(f)


# Generated at 2022-06-22 20:43:25.473523
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='foo').get()
    assert token == 'eyJhb ...'

# Generated at 2022-06-22 20:43:27.770905
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is not NoTokenSentinel()

# Unit tests for class KeycloakToken

# Generated at 2022-06-22 20:43:32.189058
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is not NoTokenSentinel
    assert repr(sentinel) == 'NoTokenSentinel'
    assert str(sentinel) == 'NoTokenSentinel'



# Generated at 2022-06-22 20:43:34.147978
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert isinstance(gt, GalaxyToken)



# Generated at 2022-06-22 20:43:38.877287
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    config = {'token': 'test_token'}
    token = GalaxyToken('')
    token._config = config
    token.set('new_token')
    assert token.get() == 'new_token'
    assert token._config['token'] == 'new_token'


# Generated at 2022-06-22 20:43:44.861300
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'pass')
    assert token.get() == 'dXNlcjpwYXNz'
    token = BasicAuthToken('user', '')
    assert token.get() == 'dXNlcjo='
    token = BasicAuthToken('user', None)
    assert token.get() == 'dXNlcjo='

# Generated at 2022-06-22 20:43:46.890937
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    dummy_sentinel = NoTokenSentinel()
    assert isinstance(dummy_sentinel, NoTokenSentinel)


# Generated at 2022-06-22 20:43:54.403243
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username1 = "user"
    password1 = "password"
    username2 = "user"
    password2 = ""
    username3 = "user"
    password3 = None
    username4 = "user"
    password4 = "p@ssword"
    token_class = BasicAuthToken(username1, password1)
    assert token_class.get() == "Basic dXNlcjpwYXNzd29yZA=="
    token_class = BasicAuthToken(username2, password2)
    assert token_class.get() == "Basic dXNlcjo="
    token_class = BasicAuthToken(username3, password3)
    assert token_class.get() == "Basic dXNlcjo="
    token_class = BasicAuthToken(username4, password4)
    assert token_class.get()

# Generated at 2022-06-22 20:44:00.189940
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    '''
    Unit test to check the return value of the KeycloakToken.headers() method.
    '''
    # Arrange
    instance = KeycloakToken(access_token='foo', auth_url='bar')
    instance._token = 'token'
    expected = 'Bearer token'

    # Act
    actual = instance.headers()['Authorization']

    # Assert
    assert actual == expected

# Generated at 2022-06-22 20:44:03.358646
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # Here we want to test we can call the constructor without raising errors
    try:
        token = NoTokenSentinel()
    except Exception as e:
        raise AssertionError("Couldn't construct NoTokenSentinel object.") from e

    return token

# Generated at 2022-06-22 20:44:16.315186
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    from ansible.galaxy.token import GalaxyToken
    from tempfile import NamedTemporaryFile
    from shutil import copyfile

    token = 'XXXXX'
    bugzilla_id = '123456789'
    b_config_file = '/tmp/test_GalaxyToken_set.yml'
    b_config_file_tmp = '/tmp/test_GalaxyToken_set.tmp.yml'

    # Create a test config file
    with NamedTemporaryFile(
            prefix='config.',
            suffix='.yml',
            dir=to_bytes('/tmp'),
            delete=False
    ) as config_file:

        # Create a temporary config file with a bugzilla_id
        config_file.write(to_bytes('galaxy_server_list:\n'))

# Generated at 2022-06-22 20:44:19.371948
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    basic_auth_token = BasicAuthToken('username', 'password')
    headers = basic_auth_token.headers()
    assert(headers['Authorization']) == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-22 20:44:23.298095
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    actual = sentinel.__new__(NoTokenSentinel)
    assert actual is sentinel, "The sentinel was not returned on __new__"

# Unit tests for method _encode_token of class BasicAuthToken

# Generated at 2022-06-22 20:44:31.666657
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    import json
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict

    class TestBasicAuthToken(unittest.TestCase):

        def setUp(self):
            self.username = '123'
            self.password = '321'
            self.token = '%s %s' % (BasicAuthToken.token_type,
                                    BasicAuthToken._encode_token(self.username, self.password))
            self.expected_headers = ImmutableDict({'Authorization': self.token})

        def test_headers(self):
            self.assertEqual(
                BasicAuthToken(self.username, self.password).headers(),
                self.expected_headers
            )

        def test_headers_without_password(self):
            self.assertEqual

# Generated at 2022-06-22 20:44:43.570882
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # BasicAuthToken.headers() should return a dictionary with the key 'Authorization' and a string with Basic and the base64 encoded username:password
    # Case 1: when called with username but without password
    my_token = BasicAuthToken('username')
    result1 = my_token.headers()
    expected_result1 = {'Authorization': 'Basic dXNlcm5hbWU6'}
    assert result1 == expected_result1, "In BasicAuthToken.headers() with username but without password, the result should be dictionary with the key 'Authorization' and a string with Basic and the base64 encoded username:password"

    # Case 2: when called with username and password
    my_token = BasicAuthToken('username', 'password')
    result2 = my_token.headers()

# Generated at 2022-06-22 20:44:45.936875
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    token = "Test"
    galaxy_token.set(token)
    assert galaxy_token.config['token'] == token


# Generated at 2022-06-22 20:44:49.071402
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    galaxy_token.set('test')
    assert galaxy_token.config['token'] == 'test'


# Generated at 2022-06-22 20:44:58.522306
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = "testtoken"
    token_file = "/tmp/test.token"

    test_token = GalaxyToken(token = token)
    test_token.b_file = token_file

    # Check that the token is set
    assert token == test_token.get()

    # Check that the token file is created
    assert os.path.isfile(test_token.b_file)

    # Check that the token is set in the token file
    test_token.save()
    with open(test_token.b_file, 'r') as f:
        config = yaml_load(f)
        assert token == config.get('token', None)
    os.remove(test_token.b_file)

# Generated at 2022-06-22 20:45:07.082378
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Test with Basic auth token just username and password
    obj_test_1 = BasicAuthToken('username1', 'password1')
    assert obj_test_1.get() == 'dXNlcm5hbWUxOnBhc3N3b3JkMQ=='

    # Test with Basic auth token just username
    obj_test_2 = BasicAuthToken('username2')
    assert obj_test_2.get() == 'dXNlcm5hbWUyOg=='

# Generated at 2022-06-22 20:45:09.890451
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    assert isinstance(GalaxyToken(token='token'), GalaxyToken)


# Generated at 2022-06-22 20:45:12.296322
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('admin')
    assert token
    assert token.username == 'admin'
    assert token.password is None



# Generated at 2022-06-22 20:45:14.835167
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='testToken')
    assert token.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-22 20:45:20.333399
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    token = NoTokenSentinel()

    #
    # test 1, expected is NoTokenSentinel
    #
    result = token.__new__(NoTokenSentinel)

    assert isinstance(result, NoTokenSentinel)
    assert result.__class__.__name__ == "NoTokenSentinel"

# Generated at 2022-06-22 20:45:22.152654
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    from ansible.galaxy.token import NoTokenSentinel

    token = NoTokenSentinel()

    assert token is not None

# Generated at 2022-06-22 20:45:25.036007
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected_header = {'Authorization': 'Bearer foo'}
    instance = KeycloakToken("foo")
    instance._token = "foo"
    assert instance.headers() == expected_header

# Generated at 2022-06-22 20:45:26.884036
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    f = NoTokenSentinel()
    if f is not NoTokenSentinel:
        raise AssertionError('NoTokenSentinel should always return itself')

# Generated at 2022-06-22 20:45:28.049513
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert isinstance(token.config, dict)

# Generated at 2022-06-22 20:45:28.618206
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    pass

# Generated at 2022-06-22 20:45:33.733515
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    test_token = 'deadbeef'
    test_config = {
        'token': test_token
    }
    test_config_file = '/tmp/test_galaxy_token.yml'

    with open(test_config_file, 'w') as f:
        yaml_dump(test_config, f, default_flow_style=False)

    galaxy_token = GalaxyToken(token=test_config_file)

    assert galaxy_token.get() == test_token

    os.unlink(test_config_file)

# Generated at 2022-06-22 20:45:35.723049
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    print("\n***** test_kct_default_const")
    kct = KeycloakToken()
    assert kct.client_id == 'cloud-services'


# Generated at 2022-06-22 20:45:39.505654
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    btoken = BasicAuthToken("so", "pwd")
    assert btoken.get() == "c286Og=="


# Generated at 2022-06-22 20:45:50.664331
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # Usage:
    # from ansible.galaxy.token import *
    # test_GalaxyToken_headers()
    import sys
    sys.path.append('../ansible_collections/ansible/galaxy')
    from token import *
    import unittest
    class MyTestCase(unittest.TestCase):
        def test_GalaxyToken_headers(self):
            token = GalaxyToken()
            token.get()
            token.headers()
            token.set('abcdefg')
            token.save()
    suite = unittest.TestLoader().loadTestsFromTestCase(MyTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)