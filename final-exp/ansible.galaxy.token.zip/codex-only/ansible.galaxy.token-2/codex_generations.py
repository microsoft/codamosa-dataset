

# Generated at 2022-06-22 20:35:50.042361
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    f = open("test_galaxy_token_file.yaml", "w")
    t = GalaxyToken()
    t.set("test-token")
    f.close()
    os.remove("test_galaxy_token_file.yaml")

# Generated at 2022-06-22 20:35:52.544129
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # GalaxyToken.get returns None if C.GALAXY_TOKEN_PATH is not set in the configuration file
    galaxy_token = GalaxyToken()
    assert galaxy_token.get() is None

# Generated at 2022-06-22 20:35:54.851260
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token.config == {}
    token.set('test')
    assert token.config == {'token': 'test'}
    assert token.get() == 'test'



# Generated at 2022-06-22 20:35:57.076558
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken()
    assert gt.headers() == {}

    gt.set('foo')
    assert gt.headers() == {'Authorization': 'Token foo'}

# Generated at 2022-06-22 20:36:01.236030
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    token_instance = GalaxyToken(token="test123")
    assert token_instance.get() == "test123"
    # deleting the file
    if os.path.isfile(token_instance.b_file):
        os.remove(token_instance.b_file)
    token_instance = GalaxyToken(token=None)
    assert token_instance.get() is None


# Generated at 2022-06-22 20:36:04.413317
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    user = "testuser"
    passwd = "testpasswd!"
    basic = BasicAuthToken(user, passwd)
    if basic.username != user:
        raise ValueError("BasicAuthToken username wrong")



# Generated at 2022-06-22 20:36:08.565898
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='fakeaccesstoken', auth_url='http://fakeurl.com')
    headers = token.headers()
    assert headers["Authorization"] == "Bearer fakeaccesstoken"

    assert GalaxyToken(token=NoTokenSentinel).get() is None

# Generated at 2022-06-22 20:36:09.783390
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoTokenSentinel()

# Generated at 2022-06-22 20:36:12.405838
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected_auth_headers = {"Authorization": "Bearer foo"}
    t = KeycloakToken(auth_url="http://localhost", access_token="foo")
    assert t.headers() == expected_auth_headers

# Generated at 2022-06-22 20:36:19.816486
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    """
    write the token to the token file
    """
    token = 'testToken'
    token_file = C.GALAXY_TOKEN_PATH
    galaxyToken = GalaxyToken(token)
    galaxyToken.set(token)

    with open(token_file) as f:
        config = yaml_load(f)
        assert config.get('token') == token
    os.remove(token_file)



# Generated at 2022-06-22 20:36:24.424217
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''
    Tests KeycloakToken.get() method.
    '''
    import sys
    if sys.version_info[0] < 3:
        # On Python 2 we need to import a urllib2 stub to test KeycloakToken
        from ansible_mock import Mock
        urllib2 = Mock()
    else:
        import urllib.request
        from unittest.mock import Mock
        urllib2 = Mock()

    # Mock objects
    response = Mock()
    request = Mock()
    r_open = Mock()
    r_info = Mock()

    CLIENT_ID = 'my_client_id'
    REFRESH_TOKEN = 'my_refresh_token'
    ACCESS_TOKEN = 'my_access_token'

# Generated at 2022-06-22 20:36:31.684200
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'asd'
    auth_url = 'https://jirapoc.ansible.com/auth/realms/Ansible-Dev/protocol/openid-connect/token'
    token = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=False)
    r = token.get()
    assert r is not None



# Generated at 2022-06-22 20:36:34.729669
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bat=BasicAuthToken('username','password')
    assert bat.get() == "dXNlcm5hbWU6cGFzc3dvcmQ="

# Generated at 2022-06-22 20:36:42.187630
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    try:
        os.remove(C.GALAXY_TOKEN_PATH)
    except:
        pass

    # Create a dummy token
    token = GalaxyToken(token='my-token')
    token.save()

    # Ensure that the token file contains the token we just saved
    assert(token._read()['token'] == 'my-token')

# Generated at 2022-06-22 20:36:52.018550
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # empty password
    username = 'foo'
    password = ''
    token = BasicAuthToken(username, password)
    assert token == 'Basic Zm9vOg=='
    # password as None
    username = 'foo'
    password = None
    token = BasicAuthToken(username, password)
    assert token == 'Basic Zm9vOg=='
    # utf-8 password
    username = 'foo'
    password = u'passw\xc3\xb6rd'
    token = BasicAuthToken(username, password)
    assert token == 'Basic Zm9vOnBhc3N3w7xyZA=='
    # only username
    username = 'foo'
    token = BasicAuthToken(username)
    assert token == 'Basic Zm9vOg=='
    # assert token is not

# Generated at 2022-06-22 20:36:55.999077
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    b_file = to_bytes('test_file')
    with open(b_file, 'w') as f:
        f.write('token: a')
    token = GalaxyToken()
    token.b_file = b_file

    assert token.headers() == {'Authorization': 'Token a'}
    os.remove(b_file)

# Generated at 2022-06-22 20:37:06.689461
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_token = KeycloakToken(access_token='12345')
    assert auth_token.auth_url == None
    assert auth_token.access_token == '12345'
    assert auth_token._token == None
    assert auth_token.validate_certs == True
    assert auth_token.client_id == 'cloud-services'

    # Test that client_id can be passed in constructor
    auth_token = KeycloakToken(access_token='12345', client_id='12345')
    assert auth_token.client_id == '12345'

    # Test that auth_url can be passed in constructor
    auth_token = KeycloakToken(access_token='12345', auth_url='http://sso.redhat.com')

# Generated at 2022-06-22 20:37:08.445238
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert token is not None


# Generated at 2022-06-22 20:37:14.331693
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    '''Unit test for method headers of class GalaxyToken'''

    # No value set
    t = GalaxyToken()
    assert {} == t.headers()

    # Empty value set
    t.set('')
    assert {} == t.headers()

    # Actual value set
    t.set('foobar')
    assert {'Authorization': 'Token foobar'} == t.headers()



# Generated at 2022-06-22 20:37:17.105794
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'password')
    assert token.get() == 'dXNlcjpwYXNzd29yZA=='


# Generated at 2022-06-22 20:37:26.465748
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    user_token = 'my_user_token'
    token = GalaxyToken(user_token)
    #test 1
    assert token.headers() == {'Authorization': 'Token my_user_token'}
    #test 2
    token._token = None
    token._config = {'token': 'new_user_token'}
    assert token.headers() == {'Authorization': 'Token new_user_token'}
    #test 3
    token._config = {'token': None}
    assert token.headers() == {}


# Generated at 2022-06-22 20:37:31.085878
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('username', 'password')
    assert token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    token = BasicAuthToken('username')
    assert token.get() == 'dXNlcm5hbWU6'

# Generated at 2022-06-22 20:37:36.256816
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken()
    token._config = {'token': 'abc'}
    assert token.get() == 'abc'
    token._token = 'xyz'
    assert token.get() == 'xyz'


# Generated at 2022-06-22 20:37:47.203230
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # token is None
    token = GalaxyToken(token=None)
    assert token.get() is None

    # C.GALAXY_TOKEN_PATH does not exist
    token = GalaxyToken(token=NoTokenSentinel())
    assert token.get() is None

    # C.GALAXY_TOKEN_PATH exists, but empty
    with open(C.GALAXY_TOKEN_PATH, 'w') as f:
        f.write('')
    token = GalaxyToken(token=NoTokenSentinel())
    assert token.get() is None
    os.remove(C.GALAXY_TOKEN_PATH)

    # C.GALAXY_TOKEN_PATH exists and contains a token

# Generated at 2022-06-22 20:37:52.448572
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Check all the cases
    assert BasicAuthToken(username='foo').headers() == {'Authorization': 'Basic Zm9vOg=='}
    assert BasicAuthToken(username='foo', password='bar').headers() == {'Authorization': 'Basic Zm9vOmJhcg=='}
    assert BasicAuthToken(username='foo', password='bar:baz').headers() == {'Authorization': 'Basic Zm9vOmJhcjpiYXo='}
    assert BasicAuthToken(username='foo:bar').headers() == {'Authorization': 'Basic Zm9vOmJhcjo='}
    assert BasicAuthToken(username='foo:bar', password='baz').headers() == {'Authorization': 'Basic Zm9vOmJhcjpiYXo='}

# Generated at 2022-06-22 20:38:00.925406
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    assert BasicAuthToken('test', 'test').get() == 'dGVzdDp0ZXN0'
    assert BasicAuthToken('test').get() == 'dGVzdDo='
    assert BasicAuthToken('test', None).get() == 'dGVzdDo='
    try:
        # noinspection PyUnresolvedReferences
        from ansible.module_utils.parsing.convert_bool import boolean
        assert BasicAuthToken('test', boolean(1)).get() == 'dGVzdDox'
    except ImportError:
        pass

# Generated at 2022-06-22 20:38:04.489021
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    try:
        kc = KeycloakToken(auth_url='test', client_id='test')
    except Exception as ex:
        assert(False, "Exception %s raised while testing KeycloakToken" % ex)

# Generated at 2022-06-22 20:38:06.208531
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    assert isinstance(nts, NoTokenSentinel)

# Generated at 2022-06-22 20:38:09.296365
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    basicAuth = BasicAuthToken("dummy", "dummy")
    headers = basicAuth.headers()
    assert headers['Authorization'] == 'Basic ZHVtbXk6ZHVtbXk=', "Failed to create BasicAuthToken object."

# Generated at 2022-06-22 20:38:13.260260
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import urllib3
    try:
        token = KeycloakToken('mt_token')
        test_token = token.get()
        if not len(test_token) == 32:
            return False

    except urllib3.exceptions.SSLError as exc:
        return False

    return True

# Generated at 2022-06-22 20:38:20.963804
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = "myUser"
    password = "myPassword"

    token = BasicAuthToken(username, password)
    token2 = BasicAuthToken(username)
    token3 = BasicAuthToken(username, None)

    assert token.get() == token2.get()
    assert token2.get() == token3.get()
    assert token3.get() == b"bXlVc2VyOm15UGFzc3dvcmQ="

# Generated at 2022-06-22 20:38:21.791447
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token

# Generated at 2022-06-22 20:38:24.288991
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='offline_token')
    token.get()


# Generated at 2022-06-22 20:38:27.663271
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    x = NoTokenSentinel()
    assert x.__new__(NoTokenSentinel) is x
    assert x.__new__(NoTokenSentinel, *(1, 2), **{}) is x

# Generated at 2022-06-22 20:38:36.362048
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # If no argument
    t = GalaxyToken()
    assert t.config == {}

    t = GalaxyToken("token")
    assert t._token == "token"
    t._token = None

    # If the config file is not exist
    path = "tests/unit/galaxy/token_nofile"
    t = GalaxyToken(token=None, path=path)
    assert t.b_file == path
    assert t.config == {}
    # Make sure a file got created
    assert os.path.isfile(path)
    os.remove(path)

    # If the config file is malformed
    with open("tests/unit/galaxy/token", "r") as input:
        data = yaml_load(input)

# Generated at 2022-06-22 20:38:40.865330
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = 'token.yml'
    token = 'sometoken'
    configuration = {'token': token}

    tok = GalaxyToken(token=token)
    tok.b_file = b_file
    tok.save()

    with open(b_file, 'r') as f:
        saved_config = yaml_load(f)
    os.remove(b_file)

    assert saved_config == configuration

# Generated at 2022-06-22 20:38:44.617661
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken()
    assert kct.auth_url is None
    assert kct.validate_certs is True
    assert kct.client_id == 'cloud-services'


# Generated at 2022-06-22 20:38:47.006152
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken(token='fake')
    assert gt.get() == 'fake'
    gt = GalaxyToken()
    assert not gt.get()

# Generated at 2022-06-22 20:38:49.624271
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'foo'
    password = 'bar'
    token = BasicAuthToken(username, password)

    assert token.get() == 'Zm9vOmJhcg=='


# Generated at 2022-06-22 20:38:58.474414
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.urls import open_url
    auth_url = 'http://localhost:5000/realms/master/protocol/openid-connect/token'
    client_id = 'test_client'
    token_file = '/tmp/token_file'
    with open(token_file, 'w') as f:
        f.write('blah')
    kct = KeycloakToken(access_token=token_file, auth_url=auth_url, client_id=client_id)
    assert kct.get() == 'blah'
    os.remove(token_file)


# Generated at 2022-06-22 20:39:02.695243
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_gt = GalaxyToken(None)
    test_gt.set('test_token')
    assert test_gt._token == 'test_token'



# Generated at 2022-06-22 20:39:11.641123
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    url = 'http://localhost/'
    token = '1234567890'
    client_id = 'client_id'

# Generated at 2022-06-22 20:39:13.337765
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.set('test_token')
    token.save()



# Generated at 2022-06-22 20:39:15.513324
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    g = GalaxyToken()
    g._config = {'token': '12345'}
    assert g.get() == '12345'


# Generated at 2022-06-22 20:39:20.780225
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # read token from a file
    token = GalaxyToken().get()
    assert token is None

    # write token in the Galaxy token file, then get it and delete the file
    token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOmZhbHNlfQ.TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ'
    config = {
        'galaxy_token': token
    }

# Generated at 2022-06-22 20:39:24.814952
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('testuser', 'testpassword')
    assert token.username == 'testuser'
    assert token.password == 'testpassword'
    assert token.get() == 'dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'


# Generated at 2022-06-22 20:39:26.446951
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    assert GalaxyToken(None).headers() == {}



# Generated at 2022-06-22 20:39:32.047681
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken(None, None).get() == 'Og=='
    assert BasicAuthToken('', '').get() == 'Og=='
    assert BasicAuthToken('', 'test').get() == 'OnRlc3Q='
    assert BasicAuthToken('test', '').get() == 'dGVzdDo='
    assert BasicAuthToken('test', 'test').get() == 'dGVzdDp0ZXN0'
    assert BasicAuthToken(None, 'test').get() == 'Olt0ZXN0'
    assert BasicAuthToken('test', None).get() == 'dGVzdDpb'
    assert BasicAuthToken('test', 'test test').get() == 'dGVzdDp0ZXN0IHRlc3Q='

# Generated at 2022-06-22 20:39:33.301032
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)

# Generated at 2022-06-22 20:39:36.291877
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    """ Check BasicAuthToken class constructor. """
    token = BasicAuthToken('username', 'password')
    assert token.username == 'username'
    assert token.password == 'password'



# Generated at 2022-06-22 20:39:39.525768
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    a = GalaxyToken("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert a.get() == "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"

# Generated at 2022-06-22 20:39:40.554530
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    KeycloakToken()

# Generated at 2022-06-22 20:39:51.154992
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    test_username = 'test_user'
    test_none_password = None
    test_zero_length_password = ''
    test_password = 'test_pass'

    token_none_password = BasicAuthToken(test_username, test_none_password)
    token_zero_length_password = BasicAuthToken(test_username, test_zero_length_password)
    token_password = BasicAuthToken(test_username, test_password)

    assert isinstance(token_none_password, BasicAuthToken)
    assert isinstance(token_zero_length_password, BasicAuthToken)
    assert isinstance(token_password, BasicAuthToken)


# Generated at 2022-06-22 20:39:56.068344
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Given a class with a method headers
    # When called with username and/or password
    # Then the class return a dictionary with token_type as key and value encoded with base64
    assert BasicAuthToken('admin', 'password').headers() == {'Authorization': 'Basic YWRtaW46cGFzc3dvcmQ='}
    assert BasicAuthToken('admin').headers() == {'Authorization': 'Basic YWRtaW4='}

# Generated at 2022-06-22 20:40:06.770448
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:40:15.132014
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import shutil
    import filecmp
    import os

    tempdir = tempfile.mkdtemp(prefix='ansible_test_GalaxyToken_save')
    C.GALAXY_TOKEN_PATH = os.path.join(tempdir, 'token')

    token = GalaxyToken()
    token.set('faketoken')
    token.save()

    path_good = os.path.join(os.path.dirname(__file__), 'data', 'GalaxyToken_save')
    assert filecmp.cmp(C.GALAXY_TOKEN_PATH, os.path.join(path_good, 'token'))

    shutil.rmtree(tempdir)

# Generated at 2022-06-22 20:40:18.337508
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    x = NoTokenSentinel()
    assert x is not None
    assert x is not False
    assert x is not ''

# Unit tests for class BasicAuthToken

# Generated at 2022-06-22 20:40:26.302307
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():

    class MockDisplay():
        def __init__(self):
            self.args = None

        def vvv(self, args):
            self.args = args

    # set up mocks
    orig_display = display
    mockDisplay = MockDisplay()
    display = mockDisplay

    # test that config has token and token is returned
    expected = {'Authorization': 'Token tester1'}
    gt = GalaxyToken(token='tester1')
    result = gt.headers()
    assert expected == result

    # test that config has no token and no token is returned
    expected = {}
    gt = GalaxyToken(token=None)
    result = gt.headers()
    assert expected == result

    # revert display object back to original object
    display = orig_display


# Generated at 2022-06-22 20:40:37.419064
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    """Unit tests for headers method of class GalaxyToken"""
    display.verbosity = 3

    token_string = 'token_string'
    headers = GalaxyToken(token_string).headers()
    # Test with token passes into constructor
    assert headers.get('Authorization') == 'Token token_string'

    g_token = GalaxyToken()
    g_token.set(token_string)
    headers = g_token.headers()
    # Test with token passes into the set function
    assert headers.get('Authorization') == 'Token token_string'

    g_token = GalaxyToken()
    g_token.save()
    headers = g_token.headers()
    # Test with no token
    assert headers.get('Authorization') is None

# Generated at 2022-06-22 20:40:47.697953
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Prepare test data
    access_token = 'access_token'
    auth_url = 'auth_url'
    client_id = 'client_id'
    # Create instance of class KeycloakToken
    keycloak_token = KeycloakToken(access_token, auth_url, client_id=client_id)
    # Get actual result
    result = keycloak_token.get()
    # Get expected results

# Generated at 2022-06-22 20:40:49.497275
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    t = GalaxyToken()
    assert t.get() == None

    t._config = {'token': 'my-token'}
    assert t.get() == 'my-token'



# Generated at 2022-06-22 20:40:50.072463
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    pass

# Generated at 2022-06-22 20:40:52.610247
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('testtoken')

    assert token.headers(), {'Authorization': 'Token testtoken'}

# Generated at 2022-06-22 20:40:56.978524
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    assert not token.headers()

    token.set("foobar")
    headers = token.headers()
    assert headers
    assert headers['Authorization'].endswith("foobar")


# Generated at 2022-06-22 20:41:00.653994
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts1 = NoTokenSentinel()
    nts2 = NoTokenSentinel()

    assert nts1 is nts2

if __name__ == '__main__':
    test_NoTokenSentinel()

# Generated at 2022-06-22 20:41:03.824171
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken()
    assert gt.headers() == {}

    token = 'fake'
    gt = GalaxyToken(token)
    assert gt.headers() == {'Authorization': 'Token %s' % token}


# Generated at 2022-06-22 20:41:12.582806
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Make sure a config is created when the file does not exist
    g = GalaxyToken('token')
    try:
        os.remove(g.b_file)
    except OSError:
        pass
    g.save()
    os.stat(g.b_file)
    # Make sure the token is actually stored
    g.save()


if __name__ == '__main__':
    import sys
    func = getattr(sys.modules[__name__], sys.argv[1])
    func(*sys.argv[2:])

# Generated at 2022-06-22 20:41:16.088819
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(access_token='test_token')
    assert keycloak_token.get() == 'test_token'


# Generated at 2022-06-22 20:41:22.730122
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_file = '/tmp/ansible_galaxy_token'
    gt = GalaxyToken()
    gt.b_file = to_bytes(token_file)
    # token file not found, create and chmod u+rw
    open(gt.b_file, 'w').close()
    os.chmod(gt.b_file, S_IRUSR | S_IWUSR)  # owner has +rw

    # token file exists and is accessible
    with open(gt.b_file, 'w') as f:
        f.write('token: abcd1234')

    t = gt.get()
    assert t == 'abcd1234'

    # token file exists but is empty
    with open(gt.b_file, 'w') as f:
        pass

    t = gt.get

# Generated at 2022-06-22 20:41:31.244989
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    print("\nTest KeycloakToken")
    token = KeycloakToken("access_token", "auth_url", "validate_certs", "client_id")
    assert token.access_token == "access_token", "Unexpected token"
    assert token.auth_url == "auth_url", "Unexpected url"
    assert token.validate_certs == "validate_certs", "Unexpected certificate"
    assert token.client_id == "client_id", "Unexpected client_id"


# Generated at 2022-06-22 20:41:35.408693
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken('testtoken')
    assert gt.get() == 'testtoken', "get not returning previously stored token"
    gt._token = 'anothertoken'
    assert gt.get() == 'anothertoken', "get not returning previously stored token"



# Generated at 2022-06-22 20:41:38.517805
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('foo').get()
    assert token == 'foo'

# dummy token class used for tests

# Generated at 2022-06-22 20:41:43.674706
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    auth = BasicAuthToken('foo', 'bar')
    assert auth.token_type == 'Basic'
    assert auth.get() == 'Zm9vOmJhcg=='
    assert auth.headers() == {'Authorization': 'Basic Zm9vOmJhcg=='}


# Generated at 2022-06-22 20:41:51.909789
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'some_token'
    auth_url = 'https://keycloak.example.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'some_client_id'

    t = KeycloakToken(access_token=access_token, auth_url=auth_url, client_id=client_id)

    assert t.access_token == access_token
    assert t.auth_url == auth_url
    assert t.client_id == client_id


# Generated at 2022-06-22 20:42:02.629914
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'cloud-services'

# Generated at 2022-06-22 20:42:06.522587
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    gt = GalaxyToken()
    gt.set('token_test')
    token_test = gt.get()
    assert token_test == 'token_test'


# Generated at 2022-06-22 20:42:09.174209
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nosent = NoTokenSentinel()
    assert hasattr(nosent, 'token_type')



# Generated at 2022-06-22 20:42:12.392733
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kcToken = KeycloakToken(access_token='test-token')
    headers = kcToken.headers()
    assert(headers['Authorization'] == 'Bearer test-token')



# Generated at 2022-06-22 20:42:17.441815
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # When auth_url and access_token are not None
    # Then function should run without Exception
    KeycloakToken(access_token='abc', auth_url='https://foobar.com').headers()

    

# Generated at 2022-06-22 20:42:21.361079
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    galaxy_token = GalaxyToken(token='fake_token')
    assert galaxy_token.headers() == {'Authorization': 'Token fake_token'}

    galaxy_token = GalaxyToken()
    assert galaxy_token.headers() == {}

# Generated at 2022-06-22 20:42:33.696990
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    import json
    import base64
    import mock
    import io

    def mock_open_url(url, data=None, *args, **kwargs):
        if url == 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token':
            mock_resp = mock.Mock(name='Response')
            mock_resp.read = mock.Mock(name='read', return_value=json.dumps({'access_token': 'test_token'}))
            mock_resp.code = 200
            return mock_resp


# Generated at 2022-06-22 20:42:39.147350
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    galaxy_token.set("test_token")

    # get token from file, then compare with token passed as parameter
    token = galaxy_token._read()['token']
    assert token == "test_token"

    galaxy_token._config = {}
    galaxy_token.save()
    galaxy_token._config = None


# Generated at 2022-06-22 20:42:48.224935
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    class MockBasicAuthToken():
        def __init__(self, username, password=None):
            self.username = username
            self.password = password

        def get(self):
            return self._get()

        def _get(self):
            return "{0}:{1}".format(self.username, self.password)

    basic_token = MockBasicAuthToken('admin', 'password')
    headers = basic_token.headers()
    assert headers['Authorization'] == 'Basic YWRtaW46cGFzc3dvcmQ=', headers['Authorization']



# Generated at 2022-06-22 20:42:58.657900
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:43:01.136991
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('access_token', 'auth_url', True)
    response = token.headers()
    assert response['Authorization'] == 'Bearer None'


# Generated at 2022-06-22 20:43:04.176831
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
   test=KeycloakToken("ABCDEFGH")
   assert test.access_token == "ABCDEFGH"


# Generated at 2022-06-22 20:43:15.808058
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Given:
    offline_token_file = '/tmp/galaxy_token'
    offline_token = 'abcdef'
    with open(offline_token_file, 'w') as f:
        f.write(offline_token)
    os.chmod(offline_token_file, S_IRUSR | S_IWUSR)  # owner has +rw
    token = KeycloakToken(offline_token, auth_url='auth_url')
    token.get()
    # When:
    token_data = token._form_payload()
    # Then:
    assert(token_data == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=abcdef')


# Generated at 2022-06-22 20:43:26.197090
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
   # test dict returned by headers when username and password provided
   auth = BasicAuthToken('user')
   assert auth.headers() == {'Authorization': 'Basic dXNlcjo='}

   # test dict returned by headers when username and no password provided
   auth = BasicAuthToken('user', password=None)
   assert auth.headers() == {'Authorization': 'Basic dXNlcjo='}

   # test dict returned by headers when username and password provided with special characters
   auth = BasicAuthToken('user', 'pass:word:')
   assert auth.headers() == {'Authorization': 'Basic dXNlcjpwYXNzOndvcmQ6'}

# Generated at 2022-06-22 20:43:34.496564
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken()
    assert token.auth_url is None
    assert token.client_id is None
    assert token.validate_certs is True
    assert token._token is None
    assert token.access_token is None

    token = KeycloakToken('access_token')
    assert token.auth_url is None
    assert token.client_id is None
    assert token.validate_certs is True
    assert token._token is None
    assert token.access_token == 'access_token'

    token = KeycloakToken(auth_url='https://auth.url',
                          validate_certs=False,
                          client_id='myclient')
    assert token.auth_url == 'https://auth.url'
    assert token.client_id == 'myclient'
    assert token.valid

# Generated at 2022-06-22 20:43:40.273072
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Since this method relies on kc_token_file as ansible.conf file
    # it is necessary that this file exists and is valid
    assert KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                         access_token='test').headers() == {'Authorization': 'Bearer test'}

# Generated at 2022-06-22 20:43:50.583629
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    from mock import patch

    from tempfile import mkdtemp
    from shutil import rmtree

    def write_file(data, filename):
        with open(filename, 'w') as f:
            yaml_dump(data, f, default_flow_style=False)

    token = 'some token'

    basedir = mkdtemp()
    b_file = to_bytes('%s/galaxy_token' % basedir, errors='surrogate_or_strict')
    write_file({'token': token}, b_file)

    galaxy_token = GalaxyToken()
    galaxy_token.b_file = b_file

    with patch.object(galaxy_token, '_read') as mock__read:
        mock__read.return_value = {'token': token}

        # check if

# Generated at 2022-06-22 20:43:54.690237
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    a = GalaxyToken()
    a.set('testtoken')
    assert a.get() == 'testtoken'
    assert a.config['token'] == 'testtoken'


# Generated at 2022-06-22 20:43:59.145892
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    assert BasicAuthToken('user', 'passwd').get() == 'Basic dXNlcjpwYXNzd2Q='
    assert BasicAuthToken('user', None).get() == 'Basic dXNlcjo='
    assert BasicAuthToken('user').get() == 'Basic dXNlcjo='


# Generated at 2022-06-22 20:44:01.167557
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('username', 'password')
    assert token.token_type == 'Basic'
    token.password = None
    assert token.password is None

# Generated at 2022-06-22 20:44:05.856978
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    # Mocking
    auth_url = 'foo.com'
    validate_certs = True
    client_id = 'cloud-services'

    kct = KeycloakToken(access_token=access_token, auth_url=auth_url, validate_certs=validate_certs, client_id=client_id)
    assert kct.access_token == 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    assert kct.auth_url == 'foo.com'
    assert kct.validate_certs == True
    assert kct.client_id == 'cloud-services'


# Generated at 2022-06-22 20:44:13.672470
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken(access_token="fake-token", auth_url="https://auth.example.com")
    assert kct.access_token == "fake-token"
    assert kct.auth_url == "https://auth.example.com"
    assert kct.client_id == "cloud-services"

# unit test for method _form_payload()

# Generated at 2022-06-22 20:44:15.168047
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()

    assert sentinel is not None

# Generated at 2022-06-22 20:44:15.960936
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert sentinel is NoTokenSentinel()

# Generated at 2022-06-22 20:44:18.523479
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bt = BasicAuthToken('foo', 'bar')
    assert bt.token_type == 'Basic'
    assert bt.username == 'foo'
    assert bt.password == 'bar'

# Generated at 2022-06-22 20:44:21.795107
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    # Given
    galaxy_token = GalaxyToken()
    token = 'token'
    # When
    galaxy_token.set(token)
    # Then
    assert galaxy_token.get() == token

# Generated at 2022-06-22 20:44:23.729983
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    myToken = GalaxyToken()
    assert(myToken.get() is None)

# Generated at 2022-06-22 20:44:25.646844
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    user = 'cloud_user'
    password = 'cloud_pass'

    token = BasicAuthToken(user, password)

# Generated at 2022-06-22 20:44:32.836529
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    from collections import namedtuple
    from unittest.mock import patch

    keycloak_token = KeycloakToken('TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST', 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', True, 'cloud-services')

# Generated at 2022-06-22 20:44:38.821908
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token_obj = GalaxyToken()
    token_type = token_obj.token_type
    token_val = token_obj.get()
    rtn_val = token_obj.headers()
    assert isinstance(rtn_val, dict), "Returned value from headers is not a dictionary"
    assert 'Authorization' in rtn_val, "'Authorization' key is not returned in headers"
    auth_val = rtn_val['Authorization']
    auth_parts = auth_val.split()
    assert len(auth_parts) == 2, "Authorization key has more than two parts"
    assert auth_parts[0] == token_type, "Satrt of Authorization value is not what was expected"
    assert auth_parts[1] == token_val, "Token value is not what was expected"

# Generated at 2022-06-22 20:44:40.227503
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    g = GalaxyToken('mytoken')
    g.set('new_token')
    assert g.get() == 'new_token'


# Generated at 2022-06-22 20:44:42.096523
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bat = BasicAuthToken('test', 'test')
    assert bat.username == 'test'
    assert bat.password == 'test'
    assert bat.get() == 'dGVzdDp0ZXN0'

# Generated at 2022-06-22 20:44:45.977295
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken("faketoken")
    headers = gt.headers()

    assert "Token" == headers['Authorization'].split(" ")[0]
    assert "faketoken" == headers['Authorization'].split(" ")[1]



# Generated at 2022-06-22 20:44:47.301478
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    NoTokenSentinel()

# Generated at 2022-06-22 20:44:55.123671
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    '''Unit tests for KeycloakToken'''
    token = KeycloakToken(access_token="foobar", auth_url="http://localhost:8080/auth/realms/master/protocol/openid-connect/token")
    assert token.token_type == 'Bearer'
    assert token.access_token == 'foobar'
    assert token.auth_url == 'http://localhost:8080/auth/realms/master/protocol/openid-connect/token'
    assert token.validate_certs == True


# Generated at 2022-06-22 20:45:00.493691
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token="refresh_token", auth_url=None)
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer None'
    token._token = 'mytoken'
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer mytoken'



# Generated at 2022-06-22 20:45:05.739905
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    """
    >>> NoTokenSentinel()
    <ansible.module_utils.common.galaxy.token.NoTokenSentinel object at 0x7f5e6cc94470>
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 20:45:07.127102
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    token.config
    assert token == token

# Generated at 2022-06-22 20:45:09.307738
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = 'temp_token'
    test_GTO = GalaxyToken(token)
    assert test_GTO.headers() == {'Authorization': 'Token temp_token'}, "Unable to generate header for GalaxyToken"
    token = None
    test_GTO = GalaxyToken(token)
    assert test_GTO.headers() == {}, "Unable to generate header for GalaxyToken"


# Generated at 2022-06-22 20:45:20.715019
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('test')
    assert token.access_token == 'test'
    assert token.validate_certs == True
    assert token.client_id == 'cloud-services'
    token = KeycloakToken('test2', auth_url='https://www.example.com', validate_certs=False, client_id='ac')
    assert token.access_token == 'test2'
    assert token.auth_url == 'https://www.example.com'
    assert token.validate_certs == False
    assert token.client_id == 'ac'
    token = KeycloakToken('test3', client_id='ad')
    assert token.client_id == 'ad'


# Generated at 2022-06-22 20:45:29.600305
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # empty username and password -> expect empty string
    bt = BasicAuthToken('', '')
    assert bt.get() == ''

    # simple username and password -> expect expected string
    bt = BasicAuthToken('username', 'password')
    assert bt.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

    # username which is the same as password
    bt = BasicAuthToken('password', 'password')
    assert bt.get() == 'cGFzc3dvcmQ6cGFzc3dvcmQ='

    # utf-8 characters in username

# Generated at 2022-06-22 20:45:35.939765
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(None)

    # test request for access token
    access_token = '1234'
    auth_url = 'http://localhost'
    token.access_token = access_token
    token.auth_url = auth_url
    expected_headers = {
        'Authorization': 'Bearer None',
    }
    assert token.headers() == expected_headers

# Generated at 2022-06-22 20:45:43.230228
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('test')
    assert token.access_token == 'test'
    assert token.client_id == 'cloud-services'
    assert token.auth_url == None

    token = KeycloakToken('access_token', 'auth_url', True, 'client_id')
    assert token.access_token == 'access_token'
    assert token.auth_url == 'auth_url'
    assert token.client_id == 'client_id'
    assert token.validate_certs is True


# Generated at 2022-06-22 20:45:49.340457
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(
        access_token='123',
        auth_url='http://example.com/auth/token',
        validate_certs='true',
    )

    # Test access_token is Base64 encoded string
    assert kct.get() == '123'

    # Test access_token is Bearer type
    assert kct.token_type == 'Bearer'
