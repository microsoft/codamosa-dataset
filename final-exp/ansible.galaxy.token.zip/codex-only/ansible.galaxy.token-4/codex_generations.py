

# Generated at 2022-06-22 20:35:56.564987
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    data = 'abc123'
    # Test with token
    token = GalaxyToken(token=data)
    assert token.get() == data
    assert token.headers() == dict(Authorization='Token %s' % data)

    # Test without token
    token = GalaxyToken()
    assert token.headers() == dict()



# Generated at 2022-06-22 20:36:02.712091
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # test user with empty password
    user1 = BasicAuthToken(username='test1', password='')
    assert user1.get() == 'dGVzdDE6Jw=='
    assert user1.headers() == {'Authorization': 'Basic dGVzdDE6Jw=='}

    # test user with password
    user2 = BasicAuthToken(username='test2', password='test2')
    assert user2.get() == 'dGVzdDI6dGVzdDI='
    assert user2.headers() == {'Authorization': 'Basic dGVzdDI6dGVzdDI='}



# Generated at 2022-06-22 20:36:04.261756
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is NoTokenSentinel()


# Generated at 2022-06-22 20:36:12.765950
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import shutil
    from ansible.module_utils._text import to_bytes, to_native
    TEST_TOKEN_FILE = u'test_galaxy_token_1'
    token = NoTokenSentinel()
    b_file = to_bytes(TEST_TOKEN_FILE, errors='surrogate_or_strict')
    config = {'token': token}
    gt = GalaxyToken(token)
    gt._config = config
    gt.b_file = b_file
    gt.save()
    with open(b_file, 'r') as f:
        new_config = yaml_load(f)
    assert config == new_config
    # Clean up
    os.remove(b_file)



# Generated at 2022-06-22 20:36:20.083787
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token="mytoken", auth_url="http://dummy/url")
    assert token
    assert isinstance(token, KeycloakToken)
    assert token.access_token == "mytoken"
    assert token.auth_url == "http://dummy/url"
    # Defaults:
    assert token.validate_certs
    assert token.client_id == "cloud-services"


# Generated at 2022-06-22 20:36:28.138079
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-22 20:36:31.785021
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    bt = BasicAuthToken('admin', 'test')
    auth_str = bt.get()
    assert(auth_str == 'YWRtaW46dGVzdA==')



# Generated at 2022-06-22 20:36:33.312934
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # Constructor should not raise error
    NoTokenSentinel()

# Generated at 2022-06-22 20:36:36.791380
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'password')
    assert token.get() == 'dXNlcjpwYXNzd29yZA=='
    token = BasicAuthToken('user')
    assert token.get() == 'dXNlcjo='

# Generated at 2022-06-22 20:36:45.155670
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('user1', 'password1')
    assert token.token_type == 'Basic'
    assert token.username == 'user1'
    assert token.password == 'password1'
    encoded_token = token.get()
    decoded = base64.b64decode(encoded_token).decode('utf-8')
    assert decoded == 'user1:password1'
    assert token.headers() == {'Authorization': 'Basic dXNlcjE6cGFzc3dvcmQx'}



# Generated at 2022-06-22 20:36:49.063222
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_token = KeycloakToken(access_token='aToken', auth_url='http://example.org', validate_certs=False)
    test_token._token = '12345'
    r = test_token.headers()
    assert r == {'Authorization': 'Bearer 12345'}

# Generated at 2022-06-22 20:36:59.056021
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-22 20:37:10.291060
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    try:
        os.remove(C.GALAXY_TOKEN_PATH)
    except FileNotFoundError:
        pass

    GALAXY_TOKEN_PATH = C.GALAXY_TOKEN_PATH
    TEST_TOKEN = 'FAKE_TOKEN'

    def _setup():
        with open(GALAXY_TOKEN_PATH, "wb") as f:
            f.write(b"---\n")
            f.write(b"token: ''\n")
            f.write(b"url: 'foobar.com'\n")

    def _teardown():
        os.remove(C.GALAXY_TOKEN_PATH)

    _setup()
    token = GalaxyToken()
    token.set(TEST_TOKEN)

# Generated at 2022-06-22 20:37:16.124219
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():

    access_token = 'aabbccddeeff'
    auth_url = 'http://auth.example.com'
    validate_certs = True
    kct = KeycloakToken(access_token, auth_url, validate_certs)
    assert kct is not None


# Because we use KeycloakToken to verify access_token
# so we don't need to test it

# Generated at 2022-06-22 20:37:19.285030
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    token = NoTokenSentinel()
    assert token
    assert token.__class__ is NoTokenSentinel


# Generated at 2022-06-22 20:37:20.602999
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    pass


# Generated at 2022-06-22 20:37:27.677747
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token is not None
    token = GalaxyToken(token="test-token")
    assert token is not None
    assert token.get() == "test-token"
    token.set("test-token2")
    assert token.get() == "test-token2"
    assert token.headers() == {'Authorization': 'Token test-token2'}


# Generated at 2022-06-22 20:37:33.062710
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Test if the same object is returned (and it is an object)
    assert NoTokenSentinel() is NoTokenSentinel()
    # Test if the object is of right type
    assert isinstance(NoTokenSentinel(), object)
    # Test if the object raises error when a single argument is passed
    try:
        NoTokenSentinel(1)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 20:37:43.318527
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Test for BaseAuthToken headers for Username and Password
    token = BasicAuthToken('test', password='test1')
    headers = token.headers()
    assert headers['Authorization'] == 'Basic dGVzdDp0ZXN0MQ=='
    # Test for BaseAuthToken headers for Username only
    token = BasicAuthToken('test')
    headers = token.headers()
    assert headers['Authorization'] == 'Basic dGVzdDp'
    # Test for BaseAuthToken headers with no arguments
    token = BasicAuthToken(username=None, password=None)
    headers = token.headers()
    assert headers['Authorization'] == 'Basic Ont9'

# Generated at 2022-06-22 20:37:45.117688
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    assert isinstance(nts, NoTokenSentinel)

# Generated at 2022-06-22 20:37:47.487826
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    # Arrange
    # Act
    result = NoTokenSentinel(1, 2)
    # Assert
    assert result == NoTokenSentinel(1, 2)

# Generated at 2022-06-22 20:37:50.358062
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken('hello')
    assert token.get() == 'hello'
    token = GalaxyToken(None)
    assert token.get() is None


# Generated at 2022-06-22 20:37:54.594459
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    NoToken = NoTokenSentinel()
    token = GalaxyToken(NoToken)

    assert token.get() == NoToken.__new__(NoToken)

    token = GalaxyToken('test')
    assert token.get() == 'test'



# Generated at 2022-06-22 20:38:01.426249
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    token_path = '/home/jiangxiao/.ansible/galaxy_token_test'
    token = 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'
    galaxy_token = GalaxyToken(None)
    galaxy_token.b_file = token_path
    galaxy_token._token = token
    assert(galaxy_token.get() == token)

    with open(token_path, 'w') as f:
        f.write(yaml_dump({'token': token}))
    assert(galaxy_token.get() == token)

# Generated at 2022-06-22 20:38:03.496227
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken().get()
    assert isinstance(token, str)


# Generated at 2022-06-22 20:38:06.149900
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)

# Generated at 2022-06-22 20:38:08.562077
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    token = "abcd"
    galaxy_token.set(token)
    assert token == galaxy_token.get()



# Generated at 2022-06-22 20:38:13.922298
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('user', 'secret')
    assert token.token_type == 'Basic'
    assert token.get() == 'Basic dXNlcjpzZWNyZXQ='



# Generated at 2022-06-22 20:38:15.745999
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)

# Generated at 2022-06-22 20:38:18.463915
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    obj = NoTokenSentinel()
    assert isinstance(obj, NoTokenSentinel)
    assert obj

# Generated at 2022-06-22 20:38:25.841855
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    class A(object):
        def __init__(self, a, b):
            pass

    class B(object):
        def __init__(self, a, b, c):
            pass

    assert type(A.__new__(A, 'a', b='b')) == A
    assert type(B.__new__(B, 'a', b='b', c='c')) == B
    assert type(NoTokenSentinel.__new__(NoTokenSentinel)) == NoTokenSentinel
    assert type(NoTokenSentinel.__new__(NoTokenSentinel, 'a', b='b')) == NoTokenSentinel
    assert type(NoTokenSentinel.__new__(NoTokenSentinel, 'a', b='b', c='c')) == NoTokenSentinel
    assert type(NoTokenSentinel)

# Generated at 2022-06-22 20:38:36.241935
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Case 1:
    # Simple case of username and password
    b_a_t = BasicAuthToken("test-user", "test-pass")
    assert b_a_t.get() == 'dGVzdC11c2VyOnRlc3QtcGFzcw=='

    # Case 2:
    # Username is invalid
    b_a_t = BasicAuthToken("")
    assert b_a_t.get() == 'Og=='

    # Case 3:
    # Password is invalid
    b_a_t = BasicAuthToken("test-user", "")
    assert b_a_t.get() == 'dGVzdC11c2VyOg=='

    # Case 4:
    # Username and password are invalid
    b_a_t = BasicAuthToken("", "")


# Generated at 2022-06-22 20:38:37.127292
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    x = NoTokenSentinel()
    assert x

# Generated at 2022-06-22 20:38:46.458962
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    refresh_token = 'QGc2R6OWCg6TfTjcFJoJZzHVZBnQwUXrvdaBJ_yfgEI'
    keycloak_token = KeycloakToken(access_token=refresh_token,
                                   auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    assert keycloak_token.token_type == 'Bearer'
    assert keycloak_token.access_token == refresh_token
    assert keycloak_token.auth_url == 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'


# Generated at 2022-06-22 20:38:56.033316
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    if not os.path.isfile(C.GALAXY_TOKEN_PATH):
        with open(C.GALAXY_TOKEN_PATH, 'w') as f:
            yaml_dump({'token': 'abcdef'}, f, default_flow_style=False)

    token = GalaxyToken()
    assert token.get() == 'abcdef'

    token = GalaxyToken('fake-token')
    assert token.get() == 'fake-token'

    token = GalaxyToken(NoTokenSentinel())
    assert token.get() is None



# Generated at 2022-06-22 20:39:08.779882
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(auth_url='https://foo', access_token='123456')

# Generated at 2022-06-22 20:39:15.772486
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    GALAXY_TOKEN_PATH = './ansible_galaxy_token'
    token = GalaxyToken(token='test_token')
    token.set('test_token')

# Generated at 2022-06-22 20:39:17.405868
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken(token='hereisthetoken').get()
    assert token == 'hereisthetoken'

# Generated at 2022-06-22 20:39:25.873665
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiI0MWQ4'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True
    token = KeycloakToken(access_token, auth_url, validate_certs)
    assert token.headers() == {'Authorization': 'Bearer eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiI0MWQ4'}



# Generated at 2022-06-22 20:39:28.217830
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    sentinel = NoTokenSentinel()
    assert isinstance(sentinel, NoTokenSentinel)


# Generated at 2022-06-22 20:39:34.371584
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    b = BasicAuthToken('ansible','mypass')
    assert(b.get() == 'YW5zaWJsZTpteXBhc3M=')
    # Test encoing with a password that contains a ':'
    b = BasicAuthToken('ansible',':mypass:')
    assert(b.get() == 'YW5zaWJsZTokbXlwYXNzOg==')

# Generated at 2022-06-22 20:39:38.152637
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('someusername', 'somepassword')
    assert token.get() == 'c29tZXVzZXJuYW1lOnNvbWVwYXNzd29yZA=='



# Generated at 2022-06-22 20:39:45.555835
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    bt = BasicAuthToken('user', 'password')
    assert bt.token_type == 'Basic'
    assert bt._token == 'dXNlcjpwYXNzd29yZA=='
    assert bt.get() == 'dXNlcjpwYXNzd29yZA=='
    assert bt.headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}

# Generated at 2022-06-22 20:39:55.576723
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    tok = GalaxyToken()
    tok._token = 'c25ad0ab0b89de8b7e9b9ed61e7c3e1e8f7aa994d6f46b6f5789b876c6e9d9d0'
    # check token
    assert tok._token == 'c25ad0ab0b89de8b7e9b9ed61e7c3e1e8f7aa994d6f46b6f5789b876c6e9d9d0'
    # check headers

# Generated at 2022-06-22 20:39:56.797853
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token is not None

# Generated at 2022-06-22 20:40:01.584683
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:40:05.511511
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    assert token.headers() == {}
    token.set('mytoken')
    assert token.headers() == {'Authorization': "Token mytoken"}


# Generated at 2022-06-22 20:40:08.760359
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = 'username'
    password = 'password'
    assert BasicAuthToken(username, password).get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-22 20:40:12.307872
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken(token="123456789")
    token.save()
    with open(token.b_file, 'r') as f:
        content = yaml_load(f)

    assert token.config == content
    os.remove(token.b_file)

# Generated at 2022-06-22 20:40:19.699165
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    class Config():
        pass

    config = Config()
    config.galaxy_server = 'https://galaxy.ansible.com'
    config.auth_url = None

    # Test without optional args
    token = KeycloakToken(access_token='test_access_token')
    assert token.access_token == 'test_access_token'
    assert token.auth_url == 'https://auth.ansible.com/oauth/token'
    assert token.client_id == 'cloud-services'

    # Test with optional valid args
    token = KeycloakToken(access_token='test_access_token',
                          auth_url='https://auth.example.com/token',
                          client_id='example-client')
    assert token.access_token == 'test_access_token'
    assert token.auth

# Generated at 2022-06-22 20:40:21.347064
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # the constructor is never called, so we only need to confirm it exists:
    NoTokenSentinel()

# Generated at 2022-06-22 20:40:27.213470
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('username', 'password')
    headers = token.headers()
    assert headers == {'Authorization': 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='}

    token = BasicAuthToken('username', '')
    headers = token.headers()
    assert headers == {'Authorization': 'Basic dXNlcm5hbWU6'}

    token = BasicAuthToken('username')
    headers = token.headers()
    assert headers == {'Authorization': 'Basic dXNlcm5hbWU6'}



# Generated at 2022-06-22 20:40:32.652803
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken("test token")
    res = token.headers()
    assert res["Authorization"] == "Bearer None"
    token._token = "test"
    res = token.headers()
    assert res["Authorization"] == "Bearer test"


# Generated at 2022-06-22 20:40:42.166446
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:40:48.144720
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():

    test_value = 'test_value'

    # Verify that method returns an instance of the class.
    assert (
        isinstance(
            NoTokenSentinel(
                test_value
            ),
            NoTokenSentinel
        )
    )

    # Verify that method returns an instance of the class that does not have
    # attribute set on the class.
    assert (
        not hasattr(
            NoTokenSentinel(
                test_value
            ),
            test_value
        )
    )


# Generated at 2022-06-22 20:40:55.662835
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'ansible'
    password = 'mypassword'
    token = BasicAuthToken._encode_token(username, password)
    assert token == 'YW5zaWJsZTpteXBhc3N3b3Jk'
    token = BasicAuthToken(username, password).get()
    assert token == 'YW5zaWJsZTpteXBhc3N3b3Jk'


# Generated at 2022-06-22 20:41:04.262690
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    '''
    Writing on the file system is a bit tricky to unit test, so we instead
    check that the input is correct.
    This is an integration test, not a unit test.
    '''
    import tempfile

    token_file_path = tempfile.mktemp()
    token_file = GalaxyToken(b_file=token_file_path)
    token_file.config['token'] = 'this is my token'
    token_file.save()

    with open(token_file_path, 'r') as f:
        data = f.read()

    assert data == 'token: this is my token\n'

    os.unlink(token_file_path)

# Generated at 2022-06-22 20:41:15.286892
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Provide credentials as username and password
    token = BasicAuthToken('testuser', 'testpass')
    # Correct header should be used
    assert(token.headers()['Authorization'] == 'Basic dGVzdHVzZXI6dGVzdHBhc3M=')

    # Provide credentials as username and password in env vars
    token = BasicAuthToken('$TESTUSER', '$TESTPASS')
    # Correct header should be used
    assert(token.headers()['Authorization'] == 'Basic dGVzdHVzZXI6dGVzdHBhc3M=')

    # Provide credentials as username only in env vars and leave password blank
    token = BasicAuthToken('$TESTUSER', '')
    # Same header as before should be used

# Generated at 2022-06-22 20:41:19.421586
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    test_token = 'test_access_token'
    # get token from config file
    token = GalaxyToken(token=NoTokenSentinel()).get()
    assert token is None
    # set token
    token = GalaxyToken()
    token.set(test_token)
    # get token
    assert token.get() == test_token


# Generated at 2022-06-22 20:41:24.160626
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert not hasattr(token, 'access_token')
    assert not hasattr(token, 'auth_url')
    assert not hasattr(token, '_token')
    assert not hasattr(token, 'validate_certs')
    assert not hasattr(token, 'client_id')



# Generated at 2022-06-22 20:41:30.929101
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token.config == {}
    assert token.get() is None
    assert token.headers() == {}

    token = GalaxyToken(token='token')
    assert 'token' in token.config
    assert token.get() == 'token'
    assert token.headers() == {'Authorization': 'Token ' + 'token'}

# Unit test of constructor of class BasicAuthToken

# Generated at 2022-06-22 20:41:39.114748
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Test when there is a token provided
    test = KeycloakToken(access_token="1234", auth_url="http://example.com")
    result = test.get()
    assert (result == '1234')
    result = test.headers()
    assert (result['Authorization'] == "Bearer 1234")

    # Test when there is a token not provided
    test2 = KeycloakToken(access_token="", auth_url="http://example.com")
    result = test2.get()
    assert (result == None)
    result = test2.headers()
    assert (result['Authorization'] == "Bearer None")

# Generated at 2022-06-22 20:41:41.574041
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    assert GalaxyToken().get() == None
    assert GalaxyToken(NoTokenSentinel()).get() == None

# Generated at 2022-06-22 20:41:45.822561
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    assert(isinstance(token.headers(), dict))
    assert(token.headers().keys() == ['Authorization'])
    assert(token.headers()['Authorization'] == 'Token None')


# Generated at 2022-06-22 20:41:47.557227
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert token is NoTokenSentinel


# Generated at 2022-06-22 20:41:57.552602
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    args = {}
    args['access_token'] = None
    args['auth_url'] = None
    args['validate_certs'] = True
    args['client_id'] = None

    auth_token = KeycloakToken(**args)

    if (auth_token.access_token != None):
        raise Exception("test_KeycloakToken: access_token should be empty")
    if (auth_token.auth_url != None):
        raise Exception("test_KeycloakToken: auth_url should be empty")
    if (auth_token.validate_certs != True):
        raise Exception("test_KeycloakToken: validate_certs should be True")
    if (auth_token.client_id != None):
        raise Exception("test_KeycloakToken: client_id should be empty")

# Unit

# Generated at 2022-06-22 20:42:07.171943
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token.config == {}, 'GalaxyToken().config should return an empty dict'
    token = GalaxyToken('fake_token')
    assert token.config == {'token': 'fake_token'}, 'GalaxyToken().config should return a dict with a the value \'fake_token\''
    token = GalaxyToken(token='fake_token')
    assert token.config == {'token': 'fake_token'}, 'GalaxyToken().config should return a dict with a the value \'fake_token\''
    token = GalaxyToken(token='fake_token')
    assert token.config == {'token': 'fake_token'}, 'GalaxyToken().config should return a dict with a the value \'fake_token\''
    token = GalaxyToken(NoTokenSentinel())

# Generated at 2022-06-22 20:42:12.212672
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken(access_token='abc')
    assert {'Authorization': 'Bearer abc'} == k.headers()
    k = KeycloakToken(access_token='xyz')
    assert {'Authorization': 'Bearer xyz'} == k.headers()



# Generated at 2022-06-22 20:42:24.775604
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    ''' Creates an instance of GalaxyToken class and verifies the token is written
    to the expected file.
    '''
    # Create instance of GalaxyToken class
    test_token = GalaxyToken('ABC')
    # Create temp file where the token will be written to
    # (by default this location is /tmp/.ansible_galaxy)
    tmp_file = '/tmp/test.galaxy_token'
    test_token._config = {'token': 'ABC'}
    test_token.b_file = tmp_file
    # Write token to temp file
    test_token.save()
    # Open the temp file and store its contents in a list
    with open(tmp_file) as fp:
        content = fp.readlines()
    # Remove the temp file
    os.remove(tmp_file)
    # Verify

# Generated at 2022-06-22 20:42:27.754259
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    GalaxyToken_token = GalaxyToken(token='fake_token')
    assert 'Token fake_token' == GalaxyToken_token.headers()['Authorization']


# Generated at 2022-06-22 20:42:30.879293
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_GalaxyToken = GalaxyToken()
    test_GalaxyToken.set('test123')
    assert test_GalaxyToken.config.get('token') == 'test123'


# Generated at 2022-06-22 20:42:33.944980
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    a = BasicAuthToken('test', 'password')
    b = BasicAuthToken('test', 123)
    assert a.get() == b.get()
    assert a.token_type == b.token_type


# Generated at 2022-06-22 20:42:41.268029
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    '''
    Test set method of class GalaxyToken
    '''
    token_file = '/tmp/test_galaxy_token'
    with open(token_file, 'w') as f:
        yaml_dump({}, f)
    galaxy_token = GalaxyToken(token=NoTokenSentinel())
    galaxy_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    galaxy_token.set('my_token')
    assert galaxy_token.get() == 'my_token'


# Generated at 2022-06-22 20:42:44.458282
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('mytoken')
    assert token.headers() == {'Authorization': 'Token mytoken'}


# Generated at 2022-06-22 20:42:48.750027
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # Test with a token
    galaxy_token = GalaxyToken('1234567890')
    assert galaxy_token.headers() == {'Authorization': 'Token 1234567890'}

    # Test without a token
    galaxy_token = GalaxyToken()
    assert galaxy_token.headers() == {}


# Generated at 2022-06-22 20:42:58.489520
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    assert BasicAuthToken('user', 'password').headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}
    assert BasicAuthToken('user').headers() == {'Authorization': 'Basic dXNlcjo='}
    assert BasicAuthToken('user', '!@#$%^&*()').headers() == {'Authorization': 'Basic dXNlcjohQCMkJV4mKigp'}
    assert BasicAuthToken('user', b'password').headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}
    assert BasicAuthToken('user', u'password').headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}

# Generated at 2022-06-22 20:43:02.333196
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    user_test = 'user'
    pass_test = 'password'
    token_test = 'dXNlcjpwYXNzd29yZA=='
    #test creation object
    bat = BasicAuthToken(user_test, pass_test)

    assert token_test == bat.get()


# Generated at 2022-06-22 20:43:14.307609
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://sso.redhat.com/auth/realms/ansible/protocol/openid-connect/token'
    token = 'f69b9c2b-e6b2-48e7-86ba-2cfe7f22f348'

    token = KeycloakToken(token=token, auth_url=auth_url)

# Generated at 2022-06-22 20:43:26.610936
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # Validate that the constructor requires arguments auth_url and access_token
    # The rest of the parameters are optional
    url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

    # Constructor should fail if auth_url is not provided
    try:
        auth = KeycloakToken(auth_url=None, access_token='12345678')
    except TypeError:
        pass
    except:
        raise AssertionError("Expected TypeError for missing auth_url")

    # Constructor should fail if access_token is not provided
    try:
        auth = KeycloakToken(auth_url=url, access_token=None)
    except TypeError:
        pass

# Generated at 2022-06-22 20:43:30.055621
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    x = NoTokenSentinel()
    assert x is not None
    assert x.__class__ == NoTokenSentinel
    return

# Generated at 2022-06-22 20:43:41.578310
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    import os
    import sys
    import tempfile
    import uuid
    import yaml

    test_token = to_text(uuid.uuid4())

    token_file = to_bytes(tempfile.NamedTemporaryFile().name, errors='surrogate_or_strict')
    galaxy_token = GalaxyToken(token=NoTokenSentinel)
    galaxy_token.b_file = token_file

    # token file not found, create and chmod u+rw
    open(galaxy_token.b_file, 'w').close()
    os.chmod(galaxy_token.b_file, S_IRUSR | S_IWUSR)  # owner has +rw
    assert not os.path.isfile(galaxy_token.b_file)

    # write a token to the file
   

# Generated at 2022-06-22 20:43:44.055060
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    # Constructor: create a BasicAuthToken object
    # Assume that the password is not None
    token1 = BasicAuthToken("user1", "password1")
    assert token1.get() == "dXNlcjE6cGFzc3dvcmQx"

    # Assume that the password is None
    token2 = BasicAuthToken("user1")
    assert token2.get() == "dXNlcjE6"

# Generated at 2022-06-22 20:43:48.329478
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel is NoTokenSentinel()
    assert NoTokenSentinel() is not NoTokenSentinel()
    # Only one object should be available
    assert not isinstance(NoTokenSentinel(), NoTokenSentinel)



# Generated at 2022-06-22 20:43:49.899552
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    pass

# Generated at 2022-06-22 20:43:52.325197
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken('123456')
    assert(token.get() == '123456')

# Generated at 2022-06-22 20:43:54.539550
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    a = NoTokenSentinel()
    b = NoTokenSentinel()
    assert a is b

# Generated at 2022-06-22 20:43:58.963873
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('testuser', 'testpassword')
    expected_headers = {
        'Authorization': 'Basic dGVzdHVzZXI6dGVzdHBhc3N3b3Jk'
    }

    assert token.headers() == expected_headers

# Generated at 2022-06-22 20:44:05.224170
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    # From the cloud.redhat.com docs:
    # https://access.redhat.com/terms-based-registry/
    # Offline tokens should be refreshed by POSTing a form-encoded body with the following parameters:
    # 'request_token' is the offline token stored in ansible.cfg
    # 'grant_type' is 'refresh_token'
    # 'client_id' is 'cloud-services'
    # TODO: test with a real offline token (one created via login -u <username> -p <password>)
    #       and real refresh_token (one created by the refresh_token API)

    os.environ['GALAXY_TOKEN_PATH'] = 'test_token_file'
    os.environ['GALAXY_SERVER'] = 'https://cloud.redhat.com'


# Generated at 2022-06-22 20:44:10.710113
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    # Create a GalaxyToken that has a token set
    GT = GalaxyToken('anExampleToken')
    # Call headers with the token
    result = GT.headers()
    assert(result['Authorization'] == 'Token anExampleToken')


# Generated at 2022-06-22 20:44:21.751784
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """
    In case of wrong auth_url, this test case should return False
    In case of right auth_url, but wrong access_token, this test case should return False
    In case of right auth_url and right access_token, this test case should return True
    """
    # 1. test with wrong auth_url
    keycloakToken = KeycloakToken(access_token='123456', auth_url='http://not_a_valid_address.com')
    if keycloakToken.get():
        raise Exception("Auth_url not defined, but get method returned True")

    # 2. test with wrong access_token
    keycloakToken = KeycloakToken(access_token='123456', auth_url='http://cloud.redhat.com/api/sso/token')

# Generated at 2022-06-22 20:44:31.122099
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    """Verify GalaxyToken.get returns token if token is present in ansible.cfg."""
    token_in_cfg = 'abcdefghijklmnopqrstuvwxyz0123456789'
    conf_path = 'ansible.cfg'
    conf_path_content = """[defaults]
galaxy_server_listen_port = 8001
galaxy_server = http://localhost:8001
galaxy_server_token = {token}
""".format(token=token_in_cfg)
    galaxy_token = GalaxyToken()
    with open(conf_path, 'w') as fd:
        fd.write(conf_path_content)
    galaxy_token.b_file = conf_path
    assert galaxy_token.get() == token_in_cfg

# Generated at 2022-06-22 20:44:32.896300
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = 'user1'
    password = 'password1'
    token = "Basic dXNlcjE6cGFzc3dvcmQx"
    assert(BasicAuthToken._encode_token(username, password) == token)

# Generated at 2022-06-22 20:44:35.167945
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('user', 'password')
    assert token.get()
    assert token.get() == 'dXNlcjpwYXNzd29yZA=='



# Generated at 2022-06-22 20:44:37.750771
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # pylint: disable=unused-variable
    sentinel = NoTokenSentinel('abc', 'efg')

# Generated at 2022-06-22 20:44:38.951143
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kt = KeycloakToken('TEST_TOKEN')

    assert kt


# Generated at 2022-06-22 20:44:48.383321
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
  import unittest
  import os

  b_token_1 = BasicAuthToken(os.environ.get("GALAXY_TEST_USERNAME"))
  b_token_2 = BasicAuthToken(os.environ.get("GALAXY_TEST_USERNAME"), os.environ.get("GALAXY_TEST_PASSWORD"))
  token_1 = b_token_1.headers()
  token_2 = b_token_2.headers()
  b_token_1.get()
  b_token_2.get()

# Generated at 2022-06-22 20:44:50.796368
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken("test", "test")
    assert token.get() == "dGVzdDp0ZXN0"

# Generated at 2022-06-22 20:45:00.731233
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"

# Generated at 2022-06-22 20:45:02.220500
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    assert GalaxyToken()



# Generated at 2022-06-22 20:45:04.117084
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
  NOTS = NoTokenSentinel()
  assert True


# Generated at 2022-06-22 20:45:05.068194
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken()
    return kct

# Generated at 2022-06-22 20:45:16.221518
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # import here to avoid import loop
    from ansible.galaxy.token import GalaxyToken
    import tempfile
    fd, filename = tempfile.mkstemp(prefix='ansible_test_galaxy_token')
    display.vvv('Created %s' % filename)
    b_file = to_bytes(filename, errors='surrogate_or_strict')
    token_test = GalaxyToken()
    token_test.b_file = b_file
    token_test.set('test_token')
    read_token = token_test._read()
    token_test.save()
    assert read_token == {'token': 'test_token'}

# Generated at 2022-06-22 20:45:17.913553
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert isinstance(NoTokenSentinel(), NoTokenSentinel)



# Generated at 2022-06-22 20:45:27.985948
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = 'eyJhbGc...'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True
    client_id = None
    kc = KeycloakToken(access_token=token, auth_url=auth_url,
                       validate_certs=validate_certs, client_id=client_id)
    assert kc.access_token == token
    assert kc.auth_url == auth_url
    assert kc.validate_certs == validate_certs
    assert kc.client_id == 'cloud-services'


# Generated at 2022-06-22 20:45:34.055969
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    import tempfile
    from ansible.module_utils.common.yaml import yaml_load

    test_dir = tempfile.mkdtemp(dir='/tmp')
    test_token = '123456789'
    f = open('%s/test.txt' % test_dir, 'w')
    f.close()

    gt = GalaxyToken(token=test_token)
    gt.set(test_token)
    gt.save()

    with open('%s/test.txt' % test_dir, 'r') as f:
        assert yaml_load(f).get('token') == test_token

# Generated at 2022-06-22 20:45:39.414065
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    assert token.config != {'token': '1234'}
    token._config = None
    token.set('1234')  # necessary for the next assert to pass
    assert token.config == {'token': '1234'}

# Generated at 2022-06-22 20:45:45.410255
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken("abcd", "https://unittest")
    assert token.headers() == {'Authorization': 'Bearer None'}
    token._token = "token"
    assert token.headers() == {'Authorization': 'Bearer token'}



# Generated at 2022-06-22 20:45:49.857105
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = 'galaxy_token'
    token = GalaxyToken(b_file)
    try:
        token.save()
        assert os.path.isfile(b_file)
    finally:
        if os.path.isfile(b_file):
            os.remove(b_file)

# Generated at 2022-06-22 20:45:59.251660
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    good_token = '123456789'
    obj = GalaxyToken(good_token)

    assert good_token == obj.get()

    with open(obj.b_file, 'w') as f:
        yaml_dump({'token': good_token}, f, default_flow_style=False)

    assert good_token == obj.get()

    # Malformed token
    with open(obj.b_file, 'w') as f:
        f.write('%123456789')

    assert None is obj.get()