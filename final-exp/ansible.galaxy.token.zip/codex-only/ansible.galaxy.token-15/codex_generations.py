

# Generated at 2022-06-22 20:35:50.424249
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert token

# Generated at 2022-06-22 20:35:57.826855
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():

    kct = KeycloakToken()
    assert kct
    assert kct.access_token is None
    assert kct.auth_url is None
    assert kct.token_type == 'Bearer'
    assert kct.validate_certs is True
    assert kct.client_id == 'cloud-services'

    kct = KeycloakToken(access_token='bogus_access_token', auth_url='bogus_auth_url',\
                        validate_certs=False, client_id='bogus_client_id')
    assert kct
    assert kct.access_token == 'bogus_access_token'
    assert kct.auth_url == 'bogus_auth_url'
    assert kct.token_type == 'Bearer'
    assert kct.validate

# Generated at 2022-06-22 20:36:01.673934
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token is not None
    assert token.config == {}

# Generated at 2022-06-22 20:36:04.861668
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nts = NoTokenSentinel()
    assert repr(nts) == '<ansible.module_utils.galaxy_token.NoTokenSentinel object at 0x7f1f3b9e9d00>'

# Generated at 2022-06-22 20:36:13.292156
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:36:24.749261
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    username = 'testuser'
    password = 'password'
    btoken = BasicAuthToken(username, password)
    token = btoken.get()
    assert token == 'dGVzdHVzZXI6cGFzc3dvcmQ='
    btoken = BasicAuthToken(username, None)
    token = btoken.get()
    assert token == 'dGVzdHVzZXI6'
    btoken = BasicAuthToken(username, 5)
    token = btoken.get()
    assert token == 'dGVzdHVzZXI6NQ=='
    btoken = BasicAuthToken(username, 'password')
    token = btoken.get()
    assert token == 'dGVzdHVzZXI6cGFzc3dvcmQ='
    btoken = BasicAuth

# Generated at 2022-06-22 20:36:36.997258
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # use a valid HTTP header
    username = 'user'
    password = 'pass'
    ba_token = BasicAuthToken(username, password)
    assert ba_token.headers() == {'Authorization': 'Basic dXNlcjpwYXNz'}

    # use a valid HTTP header with ASCII char
    username = 'user'
    password = 'päss'
    ba_token = BasicAuthToken(username, password)
    assert ba_token.headers() == {'Authorization': 'Basic dXNlcjpww7tz'}

    # use a valid HTTP header with unicode char
    username = u'user'
    password = u'päss'
    ba_token = BasicAuthToken(username, password)

# Generated at 2022-06-22 20:36:41.444762
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='1a2bcdef')
    headers = token.headers()
    assert headers == {'Authorization': 'Token 1a2bcdef'}, 'Token is not correct'



# Generated at 2022-06-22 20:36:45.916130
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='d40cd3f0-7b9c-45a6-abd6-c316f7cb34cb')
    assert token.headers() == {'Authorization': 'Token d40cd3f0-7b9c-45a6-abd6-c316f7cb34cb'}


# Generated at 2022-06-22 20:36:54.141270
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-22 20:36:57.153701
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    k = KeycloakToken('myrefreshtoken', auth_url="http://myauthurl.com")
    assert k.get() is not None
    assert k.headers() is not None

# Generated at 2022-06-22 20:37:00.423046
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    k = KeycloakToken(auth_url='https://cloud.redhat.com', validate_certs=False,
                      access_token='00000000-0000-0000-0000-000000000000')
    assert k.auth_url == 'https://cloud.redhat.com'


# Generated at 2022-06-22 20:37:02.307828
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # test_GalaxyToken_save:
    token = GalaxyToken()
    token.set('test')
    # check if token is set to 'test'
    assert token.get() == 'test'


# Generated at 2022-06-22 20:37:08.973390
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():

    # basic_auth_token.password is None
    basic_auth_token = BasicAuthToken('admin')
    assert basic_auth_token._encode_token('admin', None) == basic_auth_token.get()

    # basic_auth_token.password is not None
    basic_auth_token = BasicAuthToken('admin', 'password')
    assert basic_auth_token._encode_token('admin', 'password') == basic_auth_token.get()

# Generated at 2022-06-22 20:37:15.016655
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_build_path = os.path.join(os.path.dirname(__file__),
                                   'test_data',
                                   'ansible.cfg')
    C.GALAXY_TOKEN_PATH = test_build_path
    token = GalaxyToken(token='testtoken')
    token.set('testtoken2')
    assert token.get() == 'testtoken2'

# Generated at 2022-06-22 20:37:19.816892
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    import tempfile
    import os

    token_path = tempfile.mkstemp()[1]
    # Set the GALAXY_TOKEN_PATH environment variable to write token to temp file
    os.environ['GALAXY_TOKEN_PATH'] = token_path
    galaxy_token = GalaxyToken()
    assert galaxy_token.get() is None
    galaxy_token.set('token')
    assert galaxy_token.get() == 'token'
    os.remove(token_path)


# Generated at 2022-06-22 20:37:21.982367
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    from ansible.module_utils import basic
    obj = basic.NoTokenSentinel()
    del obj


# Generated at 2022-06-22 20:37:24.361247
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken().get()
    assert token is None


# Generated at 2022-06-22 20:37:28.536327
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    obj = KeycloakToken('testing')
    assert to_text(obj._form_payload()) == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=testing'


# Generated at 2022-06-22 20:37:37.774463
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    class KeycloakTokenMock(KeycloakToken):
        def __init__(self, access_token=None, auth_url=None, validate_certs=True, client_id=None):
            self.access_token = access_token
            self.auth_url = auth_url
            self._token = None
            self.validate_certs = validate_certs
            self.client_id = client_id
            if self.client_id is None:
                self.client_id = 'cloud-services'

    kct = KeycloakTokenMock('token', 'url', False, 'id')

    def test_get():
        kct.get()
        assert kct._token is None

    def test_headers():
        kct.headers()
        assert kct.headers() == {}

# Generated at 2022-06-22 20:37:39.406210
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    assert NoTokenSentinel() is NoTokenSentinel()



# Generated at 2022-06-22 20:37:48.925383
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    test_token = "mytokenabcd"
    # 1. an empty token file
    b_file = to_bytes('./token_file', errors='surrogate_or_strict')
    open(b_file, 'w').close()
    config = GalaxyToken()._read()
    assert config == {}

    # 2. a token file with one token
    config['token'] = test_token
    with open(b_file, 'w') as f:
        yaml_dump(config, f, default_flow_style=False)
    assert GalaxyToken().get() == test_token

    # 3. a token file with multiple tokens, but only one section
    config['test_key'] = "test_value"

# Generated at 2022-06-22 20:37:54.535515
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken(access_token="test")
    headers = {}
    expected_headers = {}
    expected_headers['Authorization'] = 'Bearer None'
    assert k.headers() == headers
    k.get()
    expected_headers['Authorization'] = 'Bearer None'
    assert k.headers() == expected_headers


# Generated at 2022-06-22 20:38:00.093294
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    mytoken = BasicAuthToken('myuser', 'mypassword')
    assert mytoken.get() == b'bXl1c2VyOm15cGFzc3dvcmQ='

    mytoken = BasicAuthToken('myuser', None)
    assert mytoken.get() == b'bXl1c2VyOg=='

# Generated at 2022-06-22 20:38:01.720648
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    galaxyToken = GalaxyToken()
    assert (isinstance(galaxyToken, GalaxyToken))

# Generated at 2022-06-22 20:38:06.161611
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken('chouseknecht', 'Th1sIsStrongP@ssw0rd!').get() == 'Y2hvdXNla25lY2h0OkxoMXNJc1N0cm9uZ1BAc3N3MHJkIQ=='


# Generated at 2022-06-22 20:38:14.020591
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():

    # create token file
    token_path = '/tmp/token.yml'
    token_file = open(token_path, 'w')
    token_file.write("token: 0000000000000000000")
    token_file.close()

    # init GalaxyToken with token file
    token = GalaxyToken()

    # compare local token with token in token file
    if token.get() != '0000000000000000000':
        os.remove(token_path)
        assert False

    # create token file with non token data
    token_file = open(token_path, 'w')
    token_file.write("some data")
    token_file.close()

    # init GalaxyToken with token file
    token = GalaxyToken()

    # compare local token with token in token file
    if token.get():
        os.remove(token_path)
       

# Generated at 2022-06-22 20:38:20.804865
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken('a token')

    class test_get:
        def __init__(self):
            self._token = None

        def get(self):
            return self._token

    token.get = test_get()
    token.get._token = "my_token"

    assert token.headers() == {'Authorization': 'Bearer my_token'}


# Generated at 2022-06-22 20:38:31.081507
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    print("\n----------- test_get_KeycloakToken -----------")
    ktoken = KeycloakToken('aaa', 'http://localhost:8080')
    print(ktoken.access_token)
    print(ktoken.auth_url)
    print(ktoken.validate_certs)
    print(ktoken.client_id)

    ktoken = KeycloakToken('bbb', 'http://localhost:8080', False, 'ccc')
    print(ktoken.access_token)
    print(ktoken.auth_url)
    print(ktoken.validate_certs)
    print(ktoken.client_id)


# Generated at 2022-06-22 20:38:32.450115
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    galaxyToken = GalaxyToken()

# Generated at 2022-06-22 20:38:43.149519
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    try:
        b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
        if os.path.isfile(b_file):
            os.remove(b_file)
        token = GalaxyToken(token='a_token')
        token.save()
        with open(b_file, 'r') as f:
            config = yaml_load(f)
            assert config['token'] == 'a_token'
    # clean up the tokens.yml file
    except Exception:
        os.remove(b_file)

# Generated at 2022-06-22 20:38:48.147548
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url = "https://test.test.test"
    client_id = "cloud-services"
    token = KeycloakToken(auth_url=auth_url, client_id=client_id)
    token.access_token = "1/hfadsg7ahfjasd8f7sQsdfsdfsdfsdfsdfsdfsdfsdfsdfasdfa7dasdfasdf"
    assert 'Authorization' == token.headers().keys()[0]
    assert token.headers().values()[0] == 'Bearer %s' % token.get()

'''
Unit Test for method get of class KeycloakToken
'''

# Generated at 2022-06-22 20:38:58.971039
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    tok = KeycloakToken('dummy')
    assert isinstance(tok, KeycloakToken)
    assert tok.access_token == 'dummy'
    assert tok.auth_url == None
    assert tok._token == None
    assert tok.validate_certs == True

    tok = KeycloakToken('dummy', auth_url='https://sso.redhat.com', validate_certs=False)
    assert isinstance(tok, KeycloakToken)
    assert tok.access_token == 'dummy'
    assert tok.auth_url == 'https://sso.redhat.com'
    assert tok._token == None
    assert tok.validate_certs == False

    return True


# Generated at 2022-06-22 20:39:10.345571
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken()
    assert token.auth_url is None
    assert token.validate_certs == True
    assert token.client_id is None

    token = KeycloakToken(access_token=None, auth_url=None, validate_certs=True, client_id=None)
    assert token.access_token is None
    assert token.auth_url is None
    assert token.validate_certs == True
    assert token.client_id is None

    token = KeycloakToken(access_token='access_token', auth_url='auth_url', validate_certs=True, client_id=None)
    assert token.access_token == 'access_token'
    assert token.auth_url == 'auth_url'
    assert token.validate_certs == True

# Generated at 2022-06-22 20:39:18.102881
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # empty password
    token = BasicAuthToken('username', '').get()
    assert token == 'Basic dXNlcm5hbWU6', 'token is incorrect'

    # no password
    token = BasicAuthToken('username').get()
    assert token == 'Basic dXNlcm5hbWU6', 'token is incorrect'

    # password in bytearray
    token = BasicAuthToken('username', bytearray('password', 'utf-8')).get()
    assert token == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ=', 'token is incorrect'


# Generated at 2022-06-22 20:39:27.644862
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Override default C.GALAXY_TOKEN_PATH to a temp file
    galaxy_token_path = '/tmp/galaxy_token_path'
    C.GALAXY_TOKEN_PATH = galaxy_token_path

    # Create a dummy token
    token = 'abc'

    # Write the token to the temp file
    token_obj = GalaxyToken(token)
    token_obj.save()

    # Read temp file and see if it's the same as the token we wrote
    token_read = GalaxyToken()
    assert token_read.get() == token

    # Remove the temp file and change C.GALAXY_TOKEN_PATH back to default
    os.remove(galaxy_token_path)
    C.GALAXY_TOKEN_PATH = '/etc/ansible/galaxy.token'

# Generated at 2022-06-22 20:39:34.948978
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    t = GalaxyToken()
    # token set to None and no token in file
    assert t.headers() == {}
    # token set to None but token in file
    t.set('foo')
    assert t.headers() == {'Authorization': 'Token foo'}
    # token set and in file
    t._token = 'bar'
    assert t.headers() == {'Authorization': 'Token bar'}
    # token set to None and no token in file
    t._token = None
    assert t.headers() == {}

# Generated at 2022-06-22 20:39:47.610294
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_path = '/tmp/tokenfile'
    # Create a token
    token = GalaxyToken()
    # Remove the token file
    if os.path.isfile(token_path):
        os.remove(token_path)
    # Save the token to the default path
    token.save()
    # Check that the token file has been created
    assert os.path.isfile(token_path)
    # Delete the token file
    if os.path.isfile(token_path):
        os.remove(token_path)
    # Create a new GalaxyToken object with a custom token path
    token = GalaxyToken(token_path)
    # Save the token
    token.save()
    # Check that the token file has been created
    assert os.path.isfile(token_path)
    # Delete the token file

# Generated at 2022-06-22 20:39:56.644458
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # get with password
    assert BasicAuthToken('username', 'password').get() == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='
    # get without password
    assert BasicAuthToken('username').get() == 'Basic dXNlcm5hbWU6'
    # get with complex password
    assert BasicAuthToken('username', '=?%2*').get() == 'Basic dXNlcm5hbWU6PSUyKg=='
    # get with username = '='
    assert BasicAuthToken('=', '=?%2*').get() == 'Basic PTw9PyUyKg=='
    # get with username = '?='

# Generated at 2022-06-22 20:40:00.023852
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken(token='test_token')
    assert token.get() == 'test_token'
    assert token.headers() == {'Authorization': 'Token test_token'}



# Generated at 2022-06-22 20:40:05.798910
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken('abc', 'https://example.com/auth/realms/ansible/protocol/openid-connect/token')
    assert token.access_token == 'abc'
    assert token.auth_url == 'https://example.com/auth/realms/ansible/protocol/openid-connect/token'
    assert token.validate_certs is True
    assert token.client_id is None


# Generated at 2022-06-22 20:40:15.488502
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    os.environ["ANSIBLE_CONFIG"] = os.path.dirname(os.path.dirname(__file__)) + "/test_data/ansible.cfg"
    os.environ["ANSIBLE_GALAXY_TOKEN"] = "test_token"
    import ansible.config
    ansible.config.core.load_config_file()
    os.environ.pop("ANSIBLE_GALAXY_TOKEN")
    os.environ.pop("ANSIBLE_CONFIG")
    # Assert that GALAXY_TOKEN_PATH is defined and points to ansible.cfg dir
    cfg = ansible.config.loader.get_config_file(C.CONFIG_FILE)
    assert cfg and os.path.isfile(cfg)
    assert C.GAL

# Generated at 2022-06-22 20:40:18.545047
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()
    assert not galaxy_token.config
    # No token file exists
    assert not galaxy_token._read()
    assert not galaxy_token.get()

# Generated at 2022-06-22 20:40:26.810998
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import unittest
    from unittest.mock import Mock, patch
    from ansible.errors import AnsibleError

    class TestKeycloakTokenGet(unittest.TestCase):

        def setUp(self):
            self.url = 'https://auth.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-22 20:40:31.771385
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    galaxy_token = GalaxyToken()  # Test No value set
    galaxy_token.get()

    # Test a value has been set
    galaxy_token.set('TestToken')
    assert galaxy_token.get() == 'TestToken'



# Generated at 2022-06-22 20:40:38.763397
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'foo'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True
    client_id = 'cloud-services'
    kc_token = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    assert kc_token.client_id == client_id
    assert kc_token.auth_url == auth_url
    assert kc_token.access_token == access_token


# Generated at 2022-06-22 20:40:41.214049
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert isinstance(token.config, dict)
    assert token.config == {}


# Generated at 2022-06-22 20:40:43.617497
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    nots = NoTokenSentinel()
    assert nots is nots
    assert NoTokenSentinel.__new__ is object.__new__

# Generated at 2022-06-22 20:40:47.354890
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken(username='admin')
    assert token.get() == 'YWRtaW46'
    token = BasicAuthToken(username='admin', password='password')
    assert token.get() == 'YWRtaW46cGFzc3dvcmQ='


# Generated at 2022-06-22 20:40:48.313770
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    gt = GalaxyToken()
    assert gt is not None


# Generated at 2022-06-22 20:40:58.644184
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():

    # Define a token
    mytoken = 'mytoken'

    # Create a directory for testing the class GalaxyToken
    test_dirname = os.path.abspath("./test_token")
    if not os.path.exists(test_dirname):
        os.makedirs(test_dirname)

    # Define a file for GalaxyToke
    test_file_name = os.path.join(test_dirname, "token.yml")

    # Define the parameters for the constructor of class GalaxyToken
    token = mytoken
    b_file = to_bytes(test_file_name, errors='surrogate_or_strict')

    # Instantiate class GalaxyToken
    gt = GalaxyToken(token=token)

    # Check that the token has been set

# Generated at 2022-06-22 20:41:02.179402
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='blah')
    assert token.headers() == {'Authorization': 'Token blah'}
    token.set('foo')
    assert token.headers() == {'Authorization': 'Token foo'}



# Generated at 2022-06-22 20:41:04.992755
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token = KeycloakToken(access_token='a-really-long-token')
    assert keycloak_token.headers() == {'Authorization': 'Bearer f-a-really-long-token'}

# Generated at 2022-06-22 20:41:06.580910
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    from ansible.config.galaxy import GalaxyToken
    gt = GalaxyToken(token="test_token")
    assert gt.get() == "test_token"


# Generated at 2022-06-22 20:41:08.410215
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    k = KeycloakToken(access_token='test_access_token')
    headers = k.headers()
    print(headers)
    assert headers['Authorization'] == 'Bearer test_access_token'

# Generated at 2022-06-22 20:41:09.257254
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = NoTokenSentinel()
    assert token is not None


# Generated at 2022-06-22 20:41:13.197757
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    username = "redhat"
    password = "r3dhat"
    t = BasicAuthToken(username, password)
    assert t.get() == "cmVkaGF0OnIzZGhhdA=="
    assert t.headers() == {"Authorization": "Basic cmVkaGF0OnIzZGhhdA=="}



# Generated at 2022-06-22 20:41:18.303345
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import random
    import string
    random_word = ''.join(random.choice(string.ascii_letters) for i in range(6))

    token = GalaxyToken(token="test")
    assert token.get() == 'test'

    token.set(random_word)
    assert token.get() == random_word

# Generated at 2022-06-22 20:41:22.687373
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    """
    Tests the get method of class GalaxyToken
    """
    galaxy_token = GalaxyToken()
    token = u'12345'
    galaxy_token._config = {'token': token}

    assert galaxy_token.get() == token


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-22 20:41:25.061750
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    t = GalaxyToken('example')
    t.set('diff_example')
    assert t.get() == 'diff_example'



# Generated at 2022-06-22 20:41:36.975579
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    import shlex

    def validate_token_value(username, password, expected):
        t = BasicAuthToken(username, password)
        assert t.get() == expected

    validate_token_value('a', 'b', 'YTpi')
    validate_token_value('some user', 'some password', 'c29tZSB1c2VyOnNvbWUgcGFzc3dvcmQ=')

    # Test that the token does not have encoding issues with Unicode username and password
    username_with_unicode = 'M\xe4x'
    password_with_unicode = 'Passw\xf6rd'
    b64_token = BasicAuthToken._encode_token(username_with_unicode, password_with_unicode)

# Generated at 2022-06-22 20:41:43.989798
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    basicAuthToken = BasicAuthToken(username="abc", password="123")
    assert basicAuthToken.token_type == 'Basic'
    basicAuthToken.username == "abc"
    assert basicAuthToken.get() == "YWJjOjEyMw=="
    basicAuthToken.set("321")
    assert basicAuthToken.get() == "321"
    assert basicAuthToken.headers() == {'Authorization': 'Basic 321'}

# Generated at 2022-06-22 20:41:46.075176
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken()
    assert gt.headers() == {}

# Generated at 2022-06-22 20:41:49.015934
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token_str = "test_token"
    obj = GalaxyToken(token=token_str)
    assert obj.get() == token_str

test_GalaxyToken_get()

# Generated at 2022-06-22 20:41:55.683414
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # test without password
    expected_token_type = 'Basic'
    expected_username = 'foo'
    expected_password = None

    ba_token = BasicAuthToken(expected_username)
    assert ba_token.get() == 'Zm9vOg=='

    # test with password
    expected_password = 'bar'
    ba_token = BasicAuthToken(expected_username, expected_password)
    assert ba_token.get() == 'Zm9vOmJhcg=='


# Generated at 2022-06-22 20:41:59.657110
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token = "access-token", auth_url = "https://auth-url")
    assert token.access_token == "access-token"
    assert token.auth_url == "https://auth-url"
    assert token.validate_certs


# Generated at 2022-06-22 20:42:11.689592
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = '12345'
    config = {}
    config['token'] = token
    gt = GalaxyToken(token=token)
    # Patch the private method _read with a function that always return config
    gt._read = lambda: config
    assert gt.get() == token

    # Test that GalaxyToken._read returns {} when the token file does not exist
    gt._read = lambda: {}
    assert gt.get() is None

    # Test that GalaxyToken._read returns {} when the token file exists but has malformed content
    token = '12345'
    gt._read = lambda: 123
    assert gt.get() is None


# Generated at 2022-06-22 20:42:18.665405
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    b = BasicAuthToken("user", "pass")
    assert "Basic" == b.token_type
    assert "Basic dXNlcjpwYXNz" == b.get()
    assert "Basic dXNlcjpwYXNz" == b.headers()["Authorization"]

    # unittest.main()

# Generated at 2022-06-22 20:42:22.784611
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_text = 'asdf1234'
    token_file = '/tmp/token'

    g = GalaxyToken(token_text)
    g.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    g.save()

    with open(token_file, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == token_text
    os.remove(token_file)



# Generated at 2022-06-22 20:42:34.352759
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-22 20:42:37.155007
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    result = GalaxyToken()
    result.set('12345')
    assert result.get() == '12345'



# Generated at 2022-06-22 20:42:46.050905
# Unit test for constructor of class KeycloakToken

# Generated at 2022-06-22 20:42:50.047528
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    import mock
    with mock.patch.object(GalaxyToken, '_read') as mock_read:
        mock_read.return_value = '{"token":"test_token"}'
        token = GalaxyToken()
        assert token.get() == 'test_token'

# Generated at 2022-06-22 20:42:51.756266
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinal = NoTokenSentinel()
    assert isinstance(sentinal, NoTokenSentinel)



# Generated at 2022-06-22 20:42:56.418173
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='at', auth_url='aurl', client_id='client_id')
    assert token._form_payload() == 'grant_type=refresh_token&client_id=client_id&refresh_token=at'
    assert token.token_type == 'Bearer'

# Generated at 2022-06-22 20:42:58.960291
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken('someToken')
    token.set('newToken')
    assert token.get() == 'newToken'
    assert token._token == 'newToken'


# Generated at 2022-06-22 20:43:01.450072
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
   token = GalaxyToken(token='my-token')
   token.get()
   assert token.headers() == { 'Authorization': 'Token my-token' }


# Generated at 2022-06-22 20:43:11.100539
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file = 'test_GalaxyToken_save'
    b_token_file = to_bytes(token_file, errors='surrogate_or_strict')
    gt = GalaxyToken('test_token')
    gt.b_file = b_token_file
    # save the token
    gt.save()

    # read the token
    with open(b_token_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == 'test_token'

    # remove the token
    os.remove(b_token_file)

test_GalaxyToken_save()

# Generated at 2022-06-22 20:43:23.000979
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-22 20:43:24.745994
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    _ = NoTokenSentinel()

# Generated at 2022-06-22 20:43:33.825001
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():

    # Create a valid GalaxyToken
    token_path = '/tmp/galaxy_token.yml'
    token = "new_token"
    config = dict()
    config['token'] = token
    with open(token_path, 'w') as f:
        yaml_dump(config, f, default_flow_style=False)
    galaxy_token_test = GalaxyToken(token=None)
    galaxy_token_test.b_file = to_bytes(token_path, errors='surrogate_or_strict')
    galaxy_token = galaxy_token_test.get()
    os.remove(token_path)
    assert token == galaxy_token

    # Create a non valid GalaxyToken
    token_path = '/tmp/galaxy_token.yml'

# Generated at 2022-06-22 20:43:34.846610
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    result = NoTokenSentinel()
    assert result

# Generated at 2022-06-22 20:43:36.384772
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    testGalaxyToken = GalaxyToken()
    return testGalaxyToken

# Generated at 2022-06-22 20:43:43.389070
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    class TestGalaxyToken(GalaxyToken):
        ''' Class to storing and retrieving local galaxy token '''
        def __init__(self, token=None):
            self.b_file = '/tmp/.ansible/galaxy_token'
            self._config = None
            self._token = token

    token = TestGalaxyToken()

    token.set('notarealtoken')
    assert token.get() == 'notarealtoken'



# Generated at 2022-06-22 20:43:48.956858
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    GALAXY_TOKEN_PATH = 'tmp.token'
    token = 'dummy_token'
    token_object = GalaxyToken(GALAXY_TOKEN_PATH, token)
    token_object.save()
    assert os.path.isfile(GALAXY_TOKEN_PATH) == True
    token_object._read()
    assert token_object.config['token'] == token
    os.remove(GALAXY_TOKEN_PATH)

# Generated at 2022-06-22 20:43:50.704605
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    sentinel = NoTokenSentinel()
    assert sentinel



# Generated at 2022-06-22 20:43:53.634318
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token._config is None
    assert token._token is None



# Generated at 2022-06-22 20:43:55.279777
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    g = GalaxyToken()
    assert isinstance(g, GalaxyToken)

# Generated at 2022-06-22 20:43:58.077155
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    t = GalaxyToken()
    assert t.headers() == {}
    t.set('1234')
    assert t.headers() == {'Authorization': 'Token 1234'}

# Generated at 2022-06-22 20:43:59.424266
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken()
    assert token.token_type == 'Bearer'

# Generated at 2022-06-22 20:44:02.536888
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    #Supposed path of file to open does not exist
    token = GalaxyToken()
    token.b_file = "./galaxy_token"
    #so we create it
    open(token.b_file, 'w').close()
    #and set token to save for next test
    token.set('fake_token')

    #Open the file
    with open(token.b_file, 'r') as f:
        content = f.read()

    #remove it when we're done
    os.remove(token.b_file)

    #check content
    assert content == "token: 'fake_token'\n"

# Generated at 2022-06-22 20:44:10.022366
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """ Tests for GalaxyToken.save() """

    import tempfile
    import os

    (temp_fd, temp_path) = tempfile.mkstemp()
    os.close(temp_fd)

    token = GalaxyToken()
    token.b_file = to_bytes(temp_path)
    token.set('abc123')
    assert token.config['token'] == 'abc123'

    # Cleanup
    os.unlink(temp_path)

# Generated at 2022-06-22 20:44:17.441207
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='access_token_value', auth_url='auth_url_value')
    token.validate_certs = False
    assert token._form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=access_token_value'
    token.get()
    assert token._token == 'access_token'
    assert token.headers() == {'Authorization': 'Bearer access_token'}


# Generated at 2022-06-22 20:44:18.967668
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(auth_url="http://localhost")
    assert kt.get()==''

# Generated at 2022-06-22 20:44:21.153040
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = GalaxyToken('test')
    test_token.set('fake_token')



# Generated at 2022-06-22 20:44:24.908603
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # NoTokenSentinel has no token, it is safe to call get()
    ansible_cfg_server = NoTokenSentinel()
    ansible_cfg_server.get()

    # NoTokenSentinel does not have a headers() method
    assert not hasattr(ansible_cfg_server, 'headers')

# Generated at 2022-06-22 20:44:35.239965
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Create a BasicAuthToken
    t = BasicAuthToken('username', 'password')

    # Get the headers
    headers = t.headers()

    # The returned headers should be a dict
    assert isinstance(headers, dict)
    # The headers should include a key named "Authorization"
    assert 'Authorization' in headers

    # The Authorization header should include Basic followed by a space and a base-64 encoded string "username:password"
    assert headers['Authorization'] == 'Basic dXNlcm5hbWU6cGFzc3dvcmQ='

    # Create a BasicAuthToken without a password
    t = BasicAuthToken('username')

    # Get the headers
    headers = t.headers()

    # The returned headers should be a dict
    assert isinstance(headers, dict)
    # The headers should include a key named

# Generated at 2022-06-22 20:44:39.298139
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = NoTokenSentinel()
    g = GalaxyToken(token)
    assert g.headers() == {}

    g.set("abc")
    assert 'Authorization' in g.headers()
    assert g.headers()['Authorization'] == 'Token abc'



# Generated at 2022-06-22 20:44:44.570604
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    token = GalaxyToken(token=NoTokenSentinel())

    cfg = token.config
    assert cfg is None
    assert token.b_file == to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    assert token._config is None
    assert token._token is NoTokenSentinel()

# Generated at 2022-06-22 20:44:52.058107
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    class request_mock:
        headers = {}
        text = {'token':'My_token'}

    token_expected = 'Basic ZGVtbzp0ZXN0'
    ba_token = BasicAuthToken('demo', 'test')
    token_received = ba_token.get()
    assert token_expected == token_received, 'token expected: %s, token received: %s' % (token_expected, token_received)

# Generated at 2022-06-22 20:44:58.308741
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    token = NoTokenSentinel()

    assert token.__new__ is NoTokenSentinel.__new__
    assert token.__init__ is NoTokenSentinel.__init__
    assert token.__str__ is NoTokenSentinel.__str__
    assert token.__doc__ is NoTokenSentinel.__doc__

    assert token is not NoTokenSentinel()
    assert str(token) == '<Ansible Galaxy token not configured>'



# Generated at 2022-06-22 20:45:05.707487
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import datetime
    import os
    import stat
    import tempfile
    import time

    from ansible.module_utils.common.yaml import yaml_load

    # Create temporary yaml file
    (fd, temp_file_name) = tempfile.mkstemp('.yml')
    # Store the file permission
    file_stat = os.stat(temp_file_name)
    os.close(fd)

    # Create and save the token
    galaxy_token = GalaxyToken()
    galaxy_token.config = {'token': 'TEST_TOKEN', 'expire': datetime.datetime.max}
    galaxy_token.b_file = temp_file_name
    galaxy_token.save()

    # Verify token has been written to the file

# Generated at 2022-06-22 20:45:09.178179
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken(username='demo', password='demo123')
    assert token.get() == 'ZGVtbzpkZW1vMTIz'

# Generated at 2022-06-22 20:45:11.989727
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('blah')
    assert token.get() == 'blah'


# Generated at 2022-06-22 20:45:14.112916
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    if NoTokenSentinel() is not NoTokenSentinel():
        assert False


# Generated at 2022-06-22 20:45:26.813482
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    import time

    # __init__()
    print(">>>test_KeycloakToken_headers(): test __init__()...")

# Generated at 2022-06-22 20:45:33.845797
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken(username=u'admin', password=u'apple')
    assert isinstance(token, BasicAuthToken)

    assert token.get() == u'Basic YWRtaW46YXBwbGU='
    assert token.headers() == {'Authorization': u'Basic YWRtaW46YXBwbGU='}



# Generated at 2022-06-22 20:45:38.235805
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_token', auth_url='test_auth_url')
    assert token.headers() == {'Authorization': 'Bearer %s' % token.get()}


# Generated at 2022-06-22 20:45:45.821612
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Tests the following code:
    #
    #   with open(self.b_file, 'w') as f:
    #       yaml_dump(self.config, f, default_flow_style=False)
    #
    # Here, C.GALAXY_TOKEN_PATH is defined as example_token_file.
    # File example_token_file is created and its contents are compared
    # to what is expected.
    contents = {'token': 'my_token'}

    test_token_file = 'example_token_file'

# Generated at 2022-06-22 20:45:51.125744
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token = KeycloakToken("offline_token",
                                   validate_certs=True,
                                   client_id="client_id",
                                   auth_url="auth_url")

    tok_headers = keycloak_token.headers()
    assert tok_headers['Authorization'] == keycloak_token.token_type + ' ' + keycloak_token.get()