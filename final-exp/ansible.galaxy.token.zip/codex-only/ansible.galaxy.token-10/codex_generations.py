

# Generated at 2022-06-22 20:35:53.068910
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    tk = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True)
    assert tk._form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=test_access_token'
    tk.get()
    assert tk._token is None
    assert tk.headers() == {'Authorization': 'Bearer None'}

# Generated at 2022-06-22 20:36:02.133175
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    """Unit test.

    Checks that username and password are correctly encoded in BasicAuthToken.get
    """
    from ansible.utils.listify import listify_lookup_plugin_terms
    username = 'test_user'
    password = 'test_pass'
    expected = 'dGVzdF91c2VyOnRlc3RfcGFzcw=='  # base64 encoded 'test_user:test_pass'

    token = BasicAuthToken(username, password)
    assert token.get() == expected

    # test passlist
    password = listify_lookup_plugin_terms(paths=['test_pass'], variances=['identity'], convert_bare=False, basedir=None)
    expected = 'dGVzdF91c2VyOmRlZmF1bHQ=' 

# Generated at 2022-06-22 20:36:04.105665
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # Constructor
    sentinel = NoTokenSentinel()

    # Constructor implicitly checked
    assert sentinel

# Generated at 2022-06-22 20:36:06.077161
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken(token='test')
    assert token.get() == 'test'


# Generated at 2022-06-22 20:36:11.959134
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    import unittest
    class test_class(unittest.TestCase):
        def setUp(self):
            self.username = 'admin'
            self.password = 'admin'
            self.basic_auth_token = BasicAuthToken(self.username, self.password)
        def test_BasicAuthToken_headers(self):
            self.assertEqual(self.basic_auth_token.headers()['Authorization'], 'Basic YWRtaW46YWRtaW4=')
    unittest.main()

# Generated at 2022-06-22 20:36:13.695932
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken()
    assert token is not None


# Generated at 2022-06-22 20:36:15.996160
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    bt = BasicAuthToken('foo', 'bar')
    print(bt.get())
    print(bt.headers())



# Generated at 2022-06-22 20:36:20.870429
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # Testing empty token
    token = GalaxyToken()
    assert token.get() is None

    # Testing token with a string value
    token = GalaxyToken('test')
    assert token.get() == 'test'



# Generated at 2022-06-22 20:36:28.609641
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    access_token = 'asdfasdflkjalskdfj'
    auth_url = 'http://kerberos.lan'
    validate_certs = False
    client_id = 'ansible'

    expected = '{"access_token": "gfhjklsdfg123456", "token_type": "Bearer"}'

    k = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    k._form_payload = lambda: 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (client_id, access_token)

    def mock_open_url(*args, **kwargs):
        resp = Mock()
        resp.read.return_value = expected
        return resp


# Generated at 2022-06-22 20:36:32.293674
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('test_user', None)
    headers = token.headers()
    assert headers == {'Authorization': u'Basic dGVzdF91c2VyOg=='}

# Generated at 2022-06-22 20:36:39.502068
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # test return none
    gt = GalaxyToken()
    assert gt.get() is None

    # test return None with invalid yaml
    gt = GalaxyToken(token='not-nice-token')
    with open(gt.b_file, 'w') as f:
        f.write('not-nice-yaml:')
    assert gt.get() is None

    # test return token
    gt = GalaxyToken(token='nice-token')
    with open(gt.b_file, 'w') as f:
        f.write('token: nice-token')
    assert gt.get() == 'nice-token'



# Generated at 2022-06-22 20:36:43.698938
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username = 'username'
    password = 'password'
    basic_auth_token = BasicAuthToken(username, password)
    assert basic_auth_token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='

# Generated at 2022-06-22 20:36:44.941943
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken()
    assert token is not None

# Generated at 2022-06-22 20:36:48.482059
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token='<KEYCLOAK_TOKEN>',
                          auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    print(token.get())

# Generated at 2022-06-22 20:36:54.310533
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    galaxy_token = GalaxyToken()

    # Test with no token set
    assert galaxy_token.get() is None
    assert galaxy_token.headers() == {}

    # Test with token set
    galaxy_token = GalaxyToken('asdf')
    assert galaxy_token.get() == 'asdf'
    assert galaxy_token.headers() == {'Authorization': 'Token asdf'}

# Generated at 2022-06-22 20:37:01.070633
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'test-token'
    target_file = '/tmp/token_file'

    def _read(file):
        with open(file, 'r') as f:
            config = yaml_load(f)
        assert config == {'token': token}

    galaxy_token = GalaxyToken(token=token)
    galaxy_token.b_file = target_file
    galaxy_token.save()
    _read(target_file)
    os.remove(target_file)



# Generated at 2022-06-22 20:37:05.573424
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    from ansible.galaxy.token import NoTokenSentinel
    s = NoTokenSentinel()
    assert s is NoTokenSentinel
    assert s is NoTokenSentinel()

    s2 = NoTokenSentinel(0)
    assert s is s2



# Generated at 2022-06-22 20:37:16.561651
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:37:20.446672
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = 'test'
    gt = GalaxyToken()
    gt.set(token)
    assert gt.config['token'] == token



# Generated at 2022-06-22 20:37:21.270693
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    assert GalaxyToken()

# Generated at 2022-06-22 20:37:32.977378
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Unit test for KeycloakToken.headers()
    #
    # This is a bit of a throw-away test in that it is really only
    #  testing that the method exists and will accept a parameter.
    #
    # It also tests that the expected return type is a 'dict',
    #  and that a KeyError is raised when the 'Authorization'
    #  key is missing
    #
    # The returned values are not evaluated.
    #
    # It does use the input value to construct a header.

    # Define a token value
    token = "0123456789ABCDEF0123456789abcdef"

    # Construct a KeycloakToken object
    t = KeycloakToken(access_token=token)

    # Run the method
    headers = t.headers()

    # Verify the required type is returned


# Generated at 2022-06-22 20:37:36.692136
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = BaseToken.create('galaxy_token')
    headers = token.headers()
    assert token
    assert headers


# Generated at 2022-06-22 20:37:38.141440
# Unit test for method __new__ of class NoTokenSentinel

# Generated at 2022-06-22 20:37:40.856792
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('user', 'pass').headers()
    assert token == {'Authorization': 'Basic dXNlcjpwYXNz'}

# Generated at 2022-06-22 20:37:43.777209
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='test', auth_url='http://auth.example.com/token')

    kt.get()
    assert kt._token == 'test'



# Generated at 2022-06-22 20:37:45.994788
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken(auth_url='http://example.com')
    assert kct.auth_url == 'http://example.com'

# Generated at 2022-06-22 20:37:50.139344
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('blah')
    assert token.config['token'] == 'blah'
    assert token.get() == 'blah'

# Generated at 2022-06-22 20:37:52.750566
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set("1234567890")
    assert token.get() == "1234567890"

# Generated at 2022-06-22 20:37:57.700071
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('test', 'vault')
    token.get()
    assert token._token == 'dGVzdDp2YXVsdA=='
    token = BasicAuthToken('test')
    token.get()
    assert token._token == 'dGVzdDo='



# Generated at 2022-06-22 20:38:01.933217
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    assert BasicAuthToken._encode_token('foo', 'bar') == u'Zm9vOmJhcg=='
    assert BasicAuthToken._encode_token('foo', None) == u'Zm9vOg=='

# Generated at 2022-06-22 20:38:03.984381
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('1234')
    print(token.headers())
    print('1234' == token.get())

# Generated at 2022-06-22 20:38:06.584310
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    username, password = 'username', 'password'
    b = BasicAuthToken(username, password)
    assert b._encode_token(username, password) == b.get()

# Generated at 2022-06-22 20:38:10.355671
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    bat = BasicAuthToken('admin')
    assert bat.headers() == {'Authorization': 'Basic YWRtaW4'}, 'The headers of BasicAuthToken are not correct!'
    bat = BasicAuthToken('admin', 'changeME')
    assert bat.headers() == {'Authorization': 'Basic YWRtaW46Y2hhbmdlTUU='}, 'The headers of BasicAuthToken are not correct!'

# Generated at 2022-06-22 20:38:13.055778
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    """Test the get() method of class GalaxyToken"""
    token = GalaxyToken()
    token.config = {'token': 'foo'}
    assert token.get() == 'foo'
    token.config = {}
    assert token.get() is None


# Generated at 2022-06-22 20:38:18.921701
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    class FakeOpenUrl(object):
        def read(self, validate_certs=False):
            data = {'access_token': 'test_access_token'}
            return json.dumps(data)

    keycloak_token = KeycloakToken(access_token='test_access_token')
    keycloak_token.open_url = FakeOpenUrl()
    token = keycloak_token.get()
    assert token == 'test_access_token'



# Generated at 2022-06-22 20:38:22.383445
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    token = KeycloakToken(access_token="koala",
                          auth_url="https://auth.ansible.com/auth",
                          validate_certs=False,
                          client_id="cloud-services")
    assert isinstance(token, KeycloakToken)


# Generated at 2022-06-22 20:38:23.439512
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    nts = NoTokenSentinel()
    assert(nts)


# Generated at 2022-06-22 20:38:31.279039
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('foo', 'bar')
    assert token.username == 'foo'
    assert token.password == 'bar'
    assert token.get() == 'Zm9vOmJhcg=='
    assert token.headers() == {'Authorization': 'Basic Zm9vOmJhcg=='}


TOKEN_MAP = {
    'galaxy': GalaxyToken,
    'basic_auth': BasicAuthToken,
    'keycloak': KeycloakToken,
}



# Generated at 2022-06-22 20:38:36.543949
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    # None values shall blow up
    try:
        NoTokenSentinel(None)
    except TypeError:
        pass
    else:
        raise Exception("The NoTokenSentinel should have raised an Exception on a None")

    # Anything other than None shall work
    test_sentinel = NoTokenSentinel("asdf")
    if test_sentinel is None:
        raise Exception("The test_sentinel should exist!")


# Generated at 2022-06-22 20:38:38.585082
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken(token='some_tok')
    assert token.headers() == {'Authorization': 'Token some_tok'}


# Generated at 2022-06-22 20:38:45.390596
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    import mock
    with mock.patch('ansible.galaxy.user_agent.user_agent') as mock_user_agent:
        mock_user_agent.return_value = 'agent-xyz'
        with mock.patch('ansible.galaxy.token.GalaxyToken._read') as mock_read:
            mock_read.return_value = {'token': '1234'}
            token = GalaxyToken()
            token.set('4321')
            assert token.config['token'] == '4321'


# Generated at 2022-06-22 20:38:53.460543
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Arrange
    # Because method get of class KeycloakToken uses calls to open_url(),
    # which uses module urllib2, the Arrange step involves setting up a
    # MockResponse with a response body. That response body is JSON
    # with key 'access_token', which will be returned by method get() of
    # class KeycloakToken.
    class MockResponse(object):
        def __init__(self, body):
            self.body = body
        def read(self):
            return self.body

    # The Arrange step also involves setting up a mock open_url function,
    # to replace the real open_url function, which will be called by method
    # get() of class KeycloakToken. The mock function returns the MockResponse
    # defined above.

# Generated at 2022-06-22 20:38:55.586644
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    a = BasicAuthToken('me', 'password')
    assert isinstance(a.get(), str)


# Generated at 2022-06-22 20:38:57.118203
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    BasicAuthToken('test', 'test123')


# Generated at 2022-06-22 20:39:00.805800
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_token = KeycloakToken(access_token='test', auth_url='http://test/url')
    assert test_token.get() != None

# Generated at 2022-06-22 20:39:04.352779
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(access_token='foobar')
    assert kt.headers()['Authorization'] == 'Bearer foobar'


# Generated at 2022-06-22 20:39:09.042004
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    # Create new galaxy token
    galaxy_token = GalaxyToken()
    assert(galaxy_token.config == {})

    # Create new galaxy token with token
    galaxy_token = GalaxyToken("token")
    assert(galaxy_token.config == {"token": "token"})

# Test the GalaxyToken's set, get and save functions

# Generated at 2022-06-22 20:39:15.513346
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    assert GalaxyToken().get() is None

    token_file = '/tmp/ansible-galaxy-token'
    token = 'foobar'

    class FakeToken(GalaxyToken):
        b_file = token_file

    # Create mock token file
    with open(token_file, 'w') as f:
        yaml_dump({'token': token}, f, default_flow_style=False)

    assert FakeToken().get() == token

    # Remove mock token file
    os.remove(token_file)

# Generated at 2022-06-22 20:39:17.184820
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    g = GalaxyToken()
    assert g.config == {}, 'configuration without token should be an empty dictionary.'

# Generated at 2022-06-22 20:39:24.427945
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('test_user')
    assert token.get() == 'dGVzdF91c2VyOg=='
    token = BasicAuthToken('test_user', 'test_password')
    assert token.get() == 'dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='
    token = BasicAuthToken('test_user', None)
    assert token.get() == 'dGVzdF91c2VyOg=='

# Generated at 2022-06-22 20:39:26.595705
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('test_token')
    assert token.get() == 'test_token'

# Generated at 2022-06-22 20:39:28.289689
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert NoTokenSentinel() is NoTokenSentinel()



# Generated at 2022-06-22 20:39:36.880682
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    temp_file = '/tmp/galaxy.yml'
    token_file = open(temp_file, "a")

    try:
        token_file.write("token: hi")
        token_file.close()

        token = GalaxyToken()

        token._config = {'token': 'hi2'}
        token.b_file = to_bytes(temp_file, errors='surrogate_or_strict')
        token.save()

        token = open(temp_file, "r")
        assert token.read() == "token: hi2"

    finally:
        token_file.close()
        os.remove(temp_file)

# Generated at 2022-06-22 20:39:40.090333
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    t = GalaxyToken(token='1234')
    h = t.headers()
    assert h['Authorization'] == 'Token 1234'


# Generated at 2022-06-22 20:39:44.936645
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = 'test_token'
    token = GalaxyToken(None)
    token.set(test_token)
    assert test_token == token._token
    # Convert it back to the dictionary
    assert test_token == token.config['token']


# Generated at 2022-06-22 20:39:55.021703
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    """
    Unit test for constructor of class BasicAuthToken
    """
    from ansible.utils.unsafe_proxy import wrap_var

    token = BasicAuthToken('test-user', 'test-password')
    assert token.get() == 'dGVzdC11c2VyOnRlc3QtcGFzc3dvcmQ='

    token = BasicAuthToken('test-user')
    assert token.get() == 'dGVzdC11c2VyOg=='

    token = BasicAuthToken(username=1234, password=5678)
    assert token.get() == 'MTIzNDo1Njc4'

    token = BasicAuthToken(username='a', password='a')
    token.username = wrap_var(token.username)  # Make it appear to be a variable

# Generated at 2022-06-22 20:40:05.746723
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # A happy scenario
    token = KeycloakToken('12345678-90ab-cdef-1234-567890abcdef',
                          'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          validate_certs=False).get()

# Generated at 2022-06-22 20:40:07.897057
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    no_token = NoTokenSentinel()
    assert no_token is not None


# Generated at 2022-06-22 20:40:11.575272
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    # Act
    basic_auth_token = BasicAuthToken('testuser', 'testpass')

    # Assert
    assert basic_auth_token.headers() == {'Authorization': 'Basic dGVzdHVzZXI6dGVzdHBhc3M='}


# Generated at 2022-06-22 20:40:19.252580
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import tempfile

    (fd, path) = tempfile.mkstemp()
    token = GalaxyToken(token=123)

    # Test that the right file is created
    token.b_file = path
    token.save()
    assert os.path.exists(path)
    os.remove(path)

    # Test that the right permissions are set
    token.b_file = path
    token.save()
    assert os.stat(path).st_mode == (S_IRUSR | S_IWUSR)
    os.remove(path)

    # Test that a wrong file permissions fails
    os.close(fd)
    token.b_file = path
    token.save()
    assert os.stat(path).st_mode != (S_IRUSR | S_IWUSR)

# Generated at 2022-06-22 20:40:21.260928
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    token = BasicAuthToken('test_user', 'test_password')
    assert token.token_type == 'Basic'


# Generated at 2022-06-22 20:40:23.519900
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    expected = {'Authorization': 'Basic c2FuZGk6Zm9v'}
    actual = BasicAuthToken('sandi', 'foo').headers()
    assert expected == actual

# Generated at 2022-06-22 20:40:29.433473
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    # Check if the initial state is empty
    assert token.get() is None
    # Set a new token
    token.set('newtoken')
    # Get the token to verify it.
    assert token.get() == 'newtoken'


# Generated at 2022-06-22 20:40:39.124510
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    # Test with valid input values
    tokens = [
        {'username': 'svs', 'password': 'pass', 'expected_token': 'c3ZzOnBhc3M=\n'},
        {'username': 'user', 'password': '', 'expected_token': 'dXNlcjo='},
        {'username': 'user', 'password': None, 'expected_token': 'dXNlcjo='},
        {'username': 'user:user', 'password': '', 'expected_token': 'dXNlcjp1c2VyOg=='}
    ]
    for t in tokens:
        username = t['username']
        password = t['password']
        expected_token = t['expected_token']

        auth_token = BasicAuthToken(username, password)
        token = auth_token

# Generated at 2022-06-22 20:40:41.764742
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    actual = NoTokenSentinel()
    expected = NoTokenSentinel
    assert isinstance(actual, expected)



# Generated at 2022-06-22 20:40:47.331024
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    auth_token = BasicAuthToken('username', 'password')
    assert auth_token.username == 'username'
    assert auth_token.password == 'password'

    auth_token = BasicAuthToken('username', '')
    assert auth_token.username == 'username'
    assert auth_token.password == ''

    auth_token = BasicAuthToken('username')
    assert auth_token.username == 'username'
    assert auth_token.password == None


# Generated at 2022-06-22 20:40:50.944549
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    # desired output
    output_1 = '123'
    output_2 = None

    # tests
    # test with no arguments
    assert GalaxyToken().get() == output_2
    # test with argument
    assert GalaxyToken(123).get() == output_1


# Generated at 2022-06-22 20:41:00.654334
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken()
    # return None when no token is found
    assert token.get() is None
    # return the token when found
    token.config = {'token': 'test token'}
    assert token.get() == 'test token'
    # return the last token override when multiple are found
    token.config = {'token': ['test token', 'test token2']}
    assert token.get() == 'test token2'
    # return None when no token is found in an empty dict
    token.config = {}
    assert token.get() is None


# Generated at 2022-06-22 20:41:02.475010
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    obj = NoTokenSentinel()
    assert obj

# Generated at 2022-06-22 20:41:08.269767
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    bat = BasicAuthToken('ansible')
    token = bat.get()
    assert token == u'YW5zaWJsZTpwYXNzd29yZA=='


# Generated at 2022-06-22 20:41:11.163987
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = GalaxyToken()
    original_token = test_token.get()
    test_token.set('brand_new_token')
    assert original_token != test_token.get()


# Generated at 2022-06-22 20:41:18.601895
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    '''
    Test the unauthenticated case
    '''
    token = GalaxyToken()
    assert token.get() == None
    '''
    Test that a token is present and can be decoded
    '''
    token = GalaxyToken(base64.b64encode(b"test:test"))
    assert token._read()['token'] == base64.b64encode(b"test:test")


# Generated at 2022-06-22 20:41:22.265937
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('test_user', 'test_password')
    headers = token.headers()
    assert headers == {'Authorization': 'Basic dGVzdF91c2VyOnRlc3RfcGFzc3dvcmQ='}



# Generated at 2022-06-22 20:41:25.113245
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('username', 'password').get()
    assert token == 'dXNlcm5hbWU6cGFzc3dvcmQ='



# Generated at 2022-06-22 20:41:26.587079
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    token = GalaxyToken().get()
    assert token is not None



# Generated at 2022-06-22 20:41:30.313147
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    gal_token = GalaxyToken()
    gal_token.set('sometoken')
    token = gal_token.get()
    assert token == 'sometoken'



# Generated at 2022-06-22 20:41:33.343155
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    token.set('12345')
    assert token.headers() == {'Authorization': 'Token 12345'}


# Generated at 2022-06-22 20:41:38.921597
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token = 'abcdefghijklmnopqrstuvwxyz-0123456789'

    g = GalaxyToken(test_token)
    g.save()

    # Verify that the token is in the file
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        g_config = yaml_load(f)

    assert g_config['token'] == test_token


# Generated at 2022-06-22 20:41:40.487883
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken("faketoken")
    headers = token.headers()
    assert(headers['Authorization'] == 'Bearer None')

# Generated at 2022-06-22 20:41:45.718131
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = '1234567890'
    gt = GalaxyToken(token)
    gt.save()

    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        c = yaml_load(f)
    assert c == dict(token=token)

# Generated at 2022-06-22 20:41:48.759783
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    gt = GalaxyToken('fake-token')
    headers = gt.headers()
    assert('Authorization' in headers)
    assert(headers['Authorization'] == 'Token fake-token')

# Generated at 2022-06-22 20:41:50.267252
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    assert not isinstance(NoTokenSentinel(), NoTokenSentinel)



# Generated at 2022-06-22 20:41:53.019490
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    tok = KeycloakToken(auth_url='https://dummyurl', access_token='dummy_token')
    assert tok is not None


# Generated at 2022-06-22 20:41:54.254085
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    assert GalaxyToken()

# Generated at 2022-06-22 20:41:57.763453
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    test_token = "test_token"
    test_token_class = GalaxyToken(None)
    test_token_class.set(test_token)
    assert test_token_class.get() == test_token


# Generated at 2022-06-22 20:42:07.197558
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    # Write test cases
    test_cases = [
        # Empty token
        dict(
            token=None,
            expected='''---
token: ''
...
'''
        ),
        # Non-empty token
        dict(
            token='test_token',
            expected='''---
token: test_token
...
'''
        )
    ]

    # Store current home dir
    old_home = os.path.expanduser('~')

    # Change home dir to temp folder
    # GalaxyToken will then save the token to the temp folder
    os.environ['HOME'] = os.path.expanduser('~') + '/tmp'

    # Make sure fake home dir exists

# Generated at 2022-06-22 20:42:10.002746
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    user = 'user'
    pwd = 'password'
    token = BasicAuthToken(user,pwd)
    assert token.username == 'user'
    assert token.password == 'password'
    assert token.get() == 'dXNlcjpwYXNzd29yZA=='


# Generated at 2022-06-22 20:42:12.984882
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken()
    header = token.headers()
    assert header == {}

    token.set('foobar')
    header = token.headers()
    assert header == {'Authorization': 'Token foobar'}

# Generated at 2022-06-22 20:42:16.383168
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    ansible_cfg_token = NoTokenSentinel()
    assert isinstance(ansible_cfg_token, NoTokenSentinel)

# Generated at 2022-06-22 20:42:26.876322
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:42:29.253812
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    x = BasicAuthToken('foo', 'bar')
    assert x.get() == 'Zm9vOmJhcg=='

# Generated at 2022-06-22 20:42:32.044727
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():
    ''' Test whether NoTokenSentinel is a singleton class'''
    tok1 = NoTokenSentinel()
    tok2 = NoTokenSentinel()
    assert tok1 is tok2


# Generated at 2022-06-22 20:42:36.757748
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token_obj = KeycloakToken('access_token', 'auth_url', True, 'client_id')
    expected_headers = {'Authorization': 'Bearer None'}
    assert token_obj.headers() == expected_headers

# Generated at 2022-06-22 20:42:44.052296
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    user = 'user'
    passwd = 'password'

    t = BasicAuthToken(user, passwd)
    token = t.get()
    assert(token == 'dXNlcjpwYXNzd29yZA==')
    assert(t.headers()['Authorization'] == 'Basic dXNlcjpwYXNzd29yZA==')

    t = BasicAuthToken(user, None)
    token = t.get()
    assert(token == 'dXNlcjo=')
    assert(t.headers()['Authorization'] == 'Basic dXNlcjo=')

# Generated at 2022-06-22 20:42:48.380399
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('username', 'password')
    assert token.get() == 'dXNlcm5hbWU6cGFzc3dvcmQ='
    token2 = BasicAuthToken('username')
    assert token2.get() == 'dXNlcm5hbWU6'

# Generated at 2022-06-22 20:42:55.308711
# Unit test for constructor of class BasicAuthToken
def test_BasicAuthToken():
    assert BasicAuthToken._encode_token('test', 'test') == 'dGVzdDp0ZXN0'
    assert BasicAuthToken('test', 'test').headers()['Authorization'] == 'Basic dGVzdDp0ZXN0'
    assert BasicAuthToken('test').headers()['Authorization'] == 'Basic dGVzdDo='
    assert BasicAuthToken(None, 'test').headers()['Authorization'] == 'Basic OnRlc3Q='
    assert BasicAuthToken(123, 456).headers()['Authorization'] == 'Basic MTIzOjQ1Ng=='

# Generated at 2022-06-22 20:43:01.013718
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(auth_url='token_url', access_token='access_token')
    # Set a token to return in headers
    kct._token = 'response_token'
    # Assert the token returned in headers is the same as the one set above
    assert(kct.headers()['Authorization'] == 'Bearer response_token')


# Generated at 2022-06-22 20:43:03.846375
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    test_token = GalaxyToken("TestToken")
    headers_dict = test_token.headers()
    assert type(headers_dict) == type({})
    assert headers_dict['Authorization'] == 'Token TestToken'


# Generated at 2022-06-22 20:43:06.420291
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    ft = GalaxyToken('test-token')
    ft.set('test-token')
    ft.save()
    assert ft.get() == 'test-token'
    os.unlink(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-22 20:43:10.041211
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token1 = GalaxyToken('test_token')
    token2 = GalaxyToken('test_token2')
    assert token1.get() == 'test_token'
    assert token2.get() == 'test_token2'

# Generated at 2022-06-22 20:43:15.654423
# Unit test for method __new__ of class NoTokenSentinel
def test_NoTokenSentinel___new__():  # pylint: disable=invalid-name
    '''Unit test for method __new__ of class NoTokenSentinel'''
    obj = NoTokenSentinel()  # pylint: disable=no-value-for-parameter
    assert isinstance(obj, NoTokenSentinel)


# Generated at 2022-06-22 20:43:25.885134
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import tempfile
    import os

    tempdir = tempfile.mkdtemp()
    token = 'test-token'
    token_file = os.path.join(tempdir, 'token_file')
    g = GalaxyToken(token=token)
    g.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    g.save()

    with open(token_file, 'r') as f:
        config = yaml_load(f)

    # Verify that we have written the token to the file
    assert config['token'] == token
    os.remove(token_file)
    os.removedirs(tempdir)

# Generated at 2022-06-22 20:43:28.240271
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    token = BasicAuthToken('test1')
    assert token.get() == b'Basic dGVzdDE6'
    token = BasicAuthToken('test2', 'password')
    assert token.get() == b'Basic dGVzdDI6cGFzc3dvcmQ='

# Generated at 2022-06-22 20:43:35.484374
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    config_file = '/tmp/ansible-galaxy-token.yaml'
    b_config_file = to_bytes(config_file, errors='surrogate_or_strict')
    token = 'abcdefghijklmnopqrstuvwxyz0123456789'
    obj = GalaxyToken(token=token)
    obj.b_file = b_config_file
    obj.set(token)
    display.vvv('Contents of %s' % config_file)
    with open(b_config_file, 'r') as f:
        display.vvv(f.read())
    assert os.path.isfile(b_config_file)
    with open(b_config_file, 'r') as f:
        config = yaml_load(f)
    assert config['token']

# Generated at 2022-06-22 20:43:39.158358
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token_str = 'keycloaktokenstr'
    test_token = KeycloakToken(access_token=token_str)
    token_headers = test_token.headers()
    assert token_headers['Authorization'] == 'Bearer ' + token_str


# Generated at 2022-06-22 20:43:49.771830
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken('foo')
    assert token.get() == 'Zm9vOg=='
    assert token.headers() == {'Authorization': 'Basic Zm9vOg=='}
    token = BasicAuthToken('foo', None)
    assert token.get() == 'Zm9vOg=='
    assert token.headers() == {'Authorization': 'Basic Zm9vOg=='}
    token = BasicAuthToken('foo', '')
    assert token.get() == 'Zm9vOg=='
    assert token.headers() == {'Authorization': 'Basic Zm9vOg=='}
    token = BasicAuthToken('foo', 'bar')
    assert token.get() == 'Zm9vOmJhcg=='

# Generated at 2022-06-22 20:44:02.013386
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import urllib2
    from ansible.module_utils.urls import urlopen, ConnectionError
    import mock
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError

    k_token = KeycloakToken('FAKE_TOKEN', 'https://sso.redhat.com/auth/realms/redhat')


# Generated at 2022-06-22 20:44:11.337484
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    import sys
    from ansible.module_utils._text import to_text
    if sys.version_info[0] >= 3:
        password = to_text(b'passwd', encoding='utf-8', errors='surrogate_or_strict')
    else:
        password = to_text(b'passwd', errors='surrogate_or_strict', nonstring='passthru')
    token = BasicAuthToken('username', password)
    assert token.get() == to_text(b'Basic dXNlcm5hbWU6cGFzc3dk')

# Generated at 2022-06-22 20:44:17.439878
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()

    def _read():
        with open(token.b_file, 'r') as f:
            return yaml_load(f)

    token.set("123")
    assert _read()['token'] == "123"
    token.set("456")
    assert _read()['token'] == "456"
    os.remove(token.b_file)

# Generated at 2022-06-22 20:44:21.706100
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    token = GalaxyToken(token="mocktoken")
    assert token._token == "mocktoken"
    assert token.b_file == to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    assert token._config is None


# Generated at 2022-06-22 20:44:31.070401
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-22 20:44:32.679014
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    token = BasicAuthToken(username='user', password='password')
    assert token.headers() == {'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='}


# Generated at 2022-06-22 20:44:34.153855
# Unit test for constructor of class GalaxyToken
def test_GalaxyToken():
    assert isinstance(GalaxyToken(), GalaxyToken)

# Generated at 2022-06-22 20:44:44.082716
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_token = '<auth token>'
    auth_url = '<auth url>'
    validate_certs = True
    k = KeycloakToken(access_token=auth_token, auth_url=auth_url, validate_certs=validate_certs)
    k._form_payload = MagicMock(return_value='<payload>')
    k._get_response = MagicMock(return_value='{"access_token":"<new token>"}')

    k.get()

    k._form_payload.assert_called_once()
    k._get_response.assert_called_once_with('<payload>', '<auth url>', validate_certs)

# Generated at 2022-06-22 20:44:46.019012
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('XXXXX')
    assert token.config['token'] == 'XXXXX'


# Generated at 2022-06-22 20:44:51.278440
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kct = KeycloakToken()
    assert kct.client_id == 'cloud-services'
    assert kct.auth_url is None
    assert kct.access_token is None
    assert kct.validate_certs is True
    assert kct._token is None



# Generated at 2022-06-22 20:45:00.314693
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = 'teste_token'
    auth_url = 'test_auth_url'
    client_id = 'test_client_id'

    keycloakToken = KeycloakToken(token, auth_url, client_id=client_id)
    keycloakToken.get()

    assert keycloakToken._token == token
    assert keycloakToken._form_payload() == 'grant_type=refresh_token&client_id=%s&refresh_token=%s' % (client_id, token)



# Generated at 2022-06-22 20:45:05.201233
# Unit test for method get of class GalaxyToken
def test_GalaxyToken_get():
    gt = GalaxyToken()

    # Test None
    assert gt.get() == None

    # Test retrieved
    gt._config = {'token' : 'test_token'}
    assert gt.get() == 'test_token'


# Generated at 2022-06-22 20:45:12.529700
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kt1 = KeycloakToken('xxxxx', auth_url='https://localhost/auth', validate_certs=False, client_id='ansible-test')
    assert(kt1.client_id == 'ansible-test')
    assert(kt1.access_token == 'xxxxx')
    assert(kt1.auth_url == 'https://localhost/auth')
    assert(not kt1.validate_certs)


# Generated at 2022-06-22 20:45:13.631165
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():
    t = NoTokenSentinel()
    assert t
    assert t is NoTokenSentinel

# Generated at 2022-06-22 20:45:17.753079
# Unit test for constructor of class NoTokenSentinel
def test_NoTokenSentinel():

    display.display('')
    display.display('######### Unit test for class NoTokenSentinel #########')
    o = NoTokenSentinel()
    assert o is not None, 'Failed to instantiate'

# Generated at 2022-06-22 20:45:25.473966
# Unit test for method headers of class BasicAuthToken
def test_BasicAuthToken_headers():
    name = 'knight'
    pw = 'pass'

    b64_val = base64.b64encode(to_bytes('%s:%s' % (name, pw), encoding='utf-8'))
    token = to_text(b64_val)

    obj = BasicAuthToken(name, pw)
    obj_token = obj.get()
    headers = obj.headers()

    assert token == obj_token
    assert headers['Authorization'] == 'Basic %s' % obj_token

# Generated at 2022-06-22 20:45:27.986320
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    token = GalaxyToken()
    token.set('test')
    actual = token.get()
    assert actual == 'test', 'Unexpected token value after call to set()'



# Generated at 2022-06-22 20:45:30.952597
# Unit test for method set of class GalaxyToken
def test_GalaxyToken_set():
    galaxy_token = GalaxyToken()
    galaxy_token.set('test_token')
    assert galaxy_token.get() == 'test_token'

# Generated at 2022-06-22 20:45:38.237021
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    from ansible.module_utils.six.moves import io
    import io as io_mod

    import os
    os.environ["ANSIBLE_GALAXY_TOKEN_PATH"] = '/tmp/ansible_galaxy_token_path'
    token = GalaxyToken()
    token.save()
    assert os.path.exists('/tmp/ansible_galaxy_token_path')

# Generated at 2022-06-22 20:45:40.988188
# Unit test for method headers of class GalaxyToken
def test_GalaxyToken_headers():
    token = GalaxyToken('test_token')
    token_type = token.get_token_type()
    test_token = token.get()
    headers = token.headers()
    assert headers['Authorization'] == '{0} {1}'.format(token_type, test_token)


# Generated at 2022-06-22 20:45:47.631244
# Unit test for method get of class BasicAuthToken
def test_BasicAuthToken_get():
    b = BasicAuthToken('test_user', 'test_pass')
    assert b.get() == 'Basic dGVzdF91c2VyOnRlc3RfcGFzcw=='
    b = BasicAuthToken('test_user')
    assert b.get() == 'Basic dGVzdF91c2VyOg=='