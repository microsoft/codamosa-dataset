

# Generated at 2022-06-24 19:28:08.455344
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()


# Generated at 2022-06-24 19:28:09.558499
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    keycloak_token_0 = KeycloakToken()
    assert True


# Generated at 2022-06-24 19:28:12.511715
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # First, save than read
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.set('mytoken')
    saved_token = galaxy_token_1.get()
    assert saved_token == 'mytoken'


# Generated at 2022-06-24 19:28:19.719232
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:28:22.880622
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.set("test_token")
    galaxy_token.save()


# Generated at 2022-06-24 19:28:29.510018
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # test case 0
    galaxy_token_0 = GalaxyToken()
    token_0 = KeycloakToken(access_token=NoTokenSentinel(), auth_url='https://cloud.redhat.com/api/token', validate_certs=True, client_id='cloud-services')
    try:
        result = token_0.get()
    except Exception as exception:
        display.display('Error: %s' % exception)
    else:
        display.display('Success: %s' % to_text(result, errors='surrogate_or_strict'))


# Generated at 2022-06-24 19:28:37.574788
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-24 19:28:47.841976
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    def my_resp(self):
        return self
    def my_read(self):
        return '{"access_token": "Good-Token"}'
    my_resp.read = my_read
    test_token = 'a-test-token'
    test_auth_url = 'https://auth.url'
    test_client_id = 'client-id'
    original_open_url = open_url
    open_url = my_resp
    kt = KeycloakToken(test_token, auth_url=test_auth_url, client_id=test_client_id)
    token = kt.get()
    assert token == 'Good-Token'
    open_url = original_open_url


# Generated at 2022-06-24 19:28:55.514405
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    assert not os.path.isfile(galaxy_token_0.b_file), 'Galaxy token file not present'
    galaxy_token_0.set('token')
    assert os.path.isfile(galaxy_token_0.b_file), 'Galaxy token file not created'
    os.remove(galaxy_token_0.b_file)
    assert not os.path.isfile(galaxy_token_0.b_file), 'Galaxy token file not deleted'


# Generated at 2022-06-24 19:29:00.690720
# Unit test for constructor of class KeycloakToken
def test_KeycloakToken():
    kc_token = KeycloakToken('foo-bar', 'https://www.example.com/')
    assert kc_token.access_token == 'foo-bar'
    assert kc_token.auth_url == 'https://www.example.com/'
    assert kc_token.validate_certs == True
    assert kc_token.client_id == 'cloud-services'
    assert kc_token._token == None
    assert kc_token.token_type == 'Bearer'


# Generated at 2022-06-24 19:29:14.840191
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    args = dict(access_token='my_access_token',
                auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    expected_token = 'my_access_token'
    expected_auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    expected_token_type = 'Bearer'
    my_token = KeycloakToken(**args)
    headers = my_token.headers()
    actual_token = my_token.get()
    actual_auth_url = my_token.auth_url
    actual_token_type = my_token.token_type
    assert(actual_token == expected_token)

# Generated at 2022-06-24 19:29:17.388940
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.config = {}
    galaxy_token_0.save()


# Generated at 2022-06-24 19:29:20.401477
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken('foo')
    assert kt.token_type == 'Bearer'
    assert kt.get() == 'foo'


# Generated at 2022-06-24 19:29:25.653852
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken()
    assert token.headers() == {}

    token = KeycloakToken('testtoken')
    headers = token.headers()
    assert headers['Authorization'] == 'Bearer None'

if __name__ == '__main__':
    test_case_0()
    test_KeycloakToken_headers()

# Generated at 2022-06-24 19:29:30.242250
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.set("Test_GalaxyToken_save")
    assert galaxy_token_1.get() == "Test_GalaxyToken_save"

if __name__  == "__main__":
    test_case_0()
    test_GalaxyToken_save()

# Generated at 2022-06-24 19:29:40.616567
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken(access_token="mock_access_token", auth_url="mock_auth_url", validate_certs=True, client_id="mock_client_id")
    with open("test/ansible_galaxy/fixtures/keycloak_token.json") as json_file:
        keycloak_token_json_response = json.load(json_file, encoding="utf-8")
    with open("test/ansible_galaxy/fixtures/keycloak_token_req.json") as json_file:
        keycloak_token_json_request = json.load(json_file, encoding="utf-8")
    try:
        keycloak_token_0.get()
    except Exception as exception:
        assert type(exception) == Exception

# Generated at 2022-06-24 19:29:43.841173
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """Tests for the `get` method of the KeycloakToken class"""

    # Test case 1
    galaxy_token_0 = GalaxyToken()
    assert galaxy_token_0.get() == None


# Generated at 2022-06-24 19:29:49.947035
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_0 = KeycloakToken(access_token='access_token_0',
                                   auth_url='auth_url_0',
                                   validate_certs=False,
                                   client_id='client_id_0')
    try:
        token = galaxy_token_0.headers()
        assert token.get('Authorization') == "Bearer None"
    finally:
        del galaxy_token_0

# Generated at 2022-06-24 19:29:51.641155
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = GalaxyToken()
    print(galaxy_token_0.get())


# Generated at 2022-06-24 19:29:54.478432
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_case_0()



# Generated at 2022-06-24 19:30:00.770649
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    GalaxyToken().save()


# Generated at 2022-06-24 19:30:10.282769
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    tok = KeycloakToken(access_token='atok', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')

# Generated at 2022-06-24 19:30:13.869362
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    print('''
    Test the output type of the method KeycloakToken.headers is a dictionary
    ''')
    kct = KeycloakToken(access_token='foo', auth_url='bar', validate_certs=True, client_id='baz')
    kct_headers = kct.headers()
    print('''
    The type of kct_headers is: %s
    ''' % type(kct_headers))


# Generated at 2022-06-24 19:30:15.986621
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Arrange
    token = KeycloakToken(access_token='sometoken', auth_url='somewhere')

    # Act
    r = token.get()

    # Assert
    assert type(r) is str



# Generated at 2022-06-24 19:30:24.215201
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    #test with access_token and auth_url
    auth_url = 'https://sso.stage.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-24 19:30:27.382848
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_1 = KeycloakToken(access_token='foo')
    galaxy_token_1.get()

# Generated at 2022-06-24 19:30:39.916450
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Create a KeycloakToken instance
    token = KeycloakToken(access_token="ABCD1234", auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    # Get headers
    headers = token.headers()
    if not isinstance(headers, dict):
        raise AssertionError("Expected type: <type 'dict'>, Actual type: %s" % type(headers))
    if 'Authorization' not in headers:
        raise AssertionError("Expected result: %s, Actual result: %s" % ('Authorization' in headers, headers))
    expected = 'Bearer ABCD1234'
    actual = headers['Authorization']

# Generated at 2022-06-24 19:30:43.608923
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.set('test')
    galaxy_token_1.save()


# Generated at 2022-06-24 19:30:53.568390
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ''' Unit test for method get of class KeycloakToken '''
    # Create new KeycloakToken object
    #
    # NOTE: keys must be strings, no getattr(obj, key)
    kct = KeycloakToken(access_token='test_access_token',
                        auth_url='test_auth_url',
                        validate_certs='False')

    kct_dict = kct.__dict__
    assert kct_dict == {'access_token': 'test_access_token',
                        'auth_url': 'test_auth_url',
                        'validate_certs': 'False',
                        'client_id': 'cloud-services',
                        '_token': None}

# Generated at 2022-06-24 19:30:55.886266
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save() # Should not raise any exceptions


# Generated at 2022-06-24 19:31:05.967027
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1._config = {'token': 'Token'}
    galaxy_token_1.save()
    assert os.access(C.GALAXY_TOKEN_PATH, os.F_OK)


# Generated at 2022-06-24 19:31:07.702598
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken()
    assert None is kct.headers()


# Generated at 2022-06-24 19:31:12.046174
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 123
    auth_url = 'http://example.com'
    validate_certs = True
    galaxy_token_0 = KeycloakToken(access_token, auth_url, validate_certs)
    res = galaxy_token_0.headers()


# Generated at 2022-06-24 19:31:15.867591
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0_ = KeycloakToken(access_token='', auth_url='https://sso.redhat.com/auth/realms/ansible/protocol/openid-connect/token', validate_certs=True, client_id='cloud-services')
    pass



# Generated at 2022-06-24 19:31:20.800939
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken(access_token='test_access_token', auth_url='test_url')
    keycloak_token_0.get()

# Generated at 2022-06-24 19:31:25.698049
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken('refresh_token')
    assert(isinstance(keycloak_token, KeycloakToken))
    assert(keycloak_token.access_token == 'refresh_token')
    assert(keycloak_token.auth_url == None)
    assert(keycloak_token._token == None)
    assert(keycloak_token.validate_certs == True)


# Generated at 2022-06-24 19:31:29.490302
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_token = KeycloakToken(access_token='test_token', auth_url='test_url')
    assert test_token.get() == 'test_token'


# Generated at 2022-06-24 19:31:32.101618
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    k_token = KeycloakToken(auth_url='https://example.com', access_token='a-token')
    k_token.get()
    assert k_token._token == 'a-token'


# Generated at 2022-06-24 19:31:36.755966
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 19:31:40.014135
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_0 = KeycloakToken(access_token='access_token_0')
    galaxy_token_0._token = '_token_0'
    assert galaxy_token_0.headers() == {'Authorization': 'Bearer _token_0'}


# Generated at 2022-06-24 19:31:49.877033
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token = KeycloakToken(access_token='test_access_token', auth_url='test_auth_url', validate_certs=True)
    galaxy_token.get()


# Generated at 2022-06-24 19:32:02.126152
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'secret'
    auth_url = 'http://10.50.35.31/auth/realms/red/protocol/openid-connect/token'
    keycloak_token_1 = KeycloakToken(access_token=access_token, auth_url=auth_url)

# Generated at 2022-06-24 19:32:11.402052
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = KeycloakToken(access_token='http://example.com', auth_url='http://example.com', validate_certs=True, client_id=None)
    # AssertionError: False is not true : KeycloakToken._token not initialized
    if galaxy_token_0._token:
        display.display('KeycloakToken._token initialized')
    else:
        display.display('KeycloakToken._token not initialized')
    # AssertionError: False is not true : KeycloakToken.get() failed to return _token
    if str(galaxy_token_0.get()) == str(galaxy_token_0._token):
        display.display('KeycloakToken.get() returned _token')

# Generated at 2022-06-24 19:32:14.819591
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():

    kct = KeycloakToken(auth_url="https://sso.redhat.com", access_token="1234567890")
    assert kct.headers() == {"Authorization": "Bearer 1234567890"}


# Generated at 2022-06-24 19:32:16.218481
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    pass


# Generated at 2022-06-24 19:32:25.172010
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:32:29.881792
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # class KeycloakToken initialization
    gt = GalaxyToken()
    kt = KeycloakToken(access_token=gt.get(), auth_url='http://auth.path.to/access/token')
    # unit test
    print(kt.get())


# Generated at 2022-06-24 19:32:39.596873
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''
        This test case tests the get method of the KeycloakToken class
        It tests a normal case where the token file is present and contains a token
    '''
    token_file = "test_files/save_files/galaxy_token"
    auth_url = 'https://sso.redhat.com/auth/realms/ansible-sso/protocol/openid-connect/token'
    client_id = 'cloud-services'
    open(token_file, 'w').close()

# Generated at 2022-06-24 19:32:42.030264
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    a_token = KeycloakToken('offline_token','auth_url','client_id')
    a_token.get()


# Generated at 2022-06-24 19:32:43.297844
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    k = KeycloakToken('offline_token')
    assert k.get() is None


# Generated at 2022-06-24 19:33:10.929979
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:33:11.909302
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    KeycloakToken.headers()


# Generated at 2022-06-24 19:33:16.325991
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    t = GalaxyToken()
    try: os.remove(C.GALAXY_TOKEN_PATH)
    except: pass
    t.set('test_token')
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        data = json.load(f)
    assert data == {"token": "test_token"}


# Generated at 2022-06-24 19:33:22.464822
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(auth_url='https://127.0.0.1:8443/auth/realms/master/protocol/openid-connect/token', access_token='aaabbb')

    result = kt.get()
    assert result == None


# Generated at 2022-06-24 19:33:32.393085
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:33:34.326100
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.save()

# Generated at 2022-06-24 19:33:41.525118
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass_token = KeycloakToken(access_token='rlyLongTokenDontUseThisItsFake')
    assert pass_token.get() == 'rlyLongTokenDontUseThisItsFake'
    assert pass_token.headers()['Authorization'] == 'Bearer rlyLongTokenDontUseThisItsFake'


# Generated at 2022-06-24 19:33:43.750288
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # test case 0
    keycloak_token_0 = KeycloakToken()
    assert keycloak_token_0.get() != None


# Generated at 2022-06-24 19:33:47.501422
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_1 = GalaxyToken()

    assert galaxy_token_0.headers() == galaxy_token_1.headers()

    galaxy_token_2 = GalaxyToken('1234')
    galaxy_token_3 = GalaxyToken('5678')

    assert galaxy_token_2.headers() != galaxy_token_3.headers()



# Generated at 2022-06-24 19:33:55.092111
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken("7f1b4d42-4d3e-4b30-9e29-6a0fbc8fe5d5", "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token")
    keycloak_token_0.get()


# Generated at 2022-06-24 19:34:08.532626
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    '''KeycloakToken_get'''
    keycloak_token = KeycloakToken(access_token="mock_access_token", auth_url="mock_auth_url")
    keycloak_token_01 = KeycloakToken(access_token="mock_access_token", auth_url="mock_auth_url")
    keycloak_token_02 = KeycloakToken(access_token="mock_access_token", auth_url="mock_auth_url")
    keycloak_token_02.access_token = "changed_mock_access_token"
    test_case_0()

    # testing
    assert not keycloak_token.get()
    keycloak_token_01._token = "mock_token"
    assert keycloak_token_01.get()

# Generated at 2022-06-24 19:34:09.888493
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken('some_token')
    kct_res = kct.get()
    assert type(kct_res) == str


# Generated at 2022-06-24 19:34:16.093418
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()

    assert(os.path.isfile(galaxy_token_1.b_file))
    galaxy_token_1.config['token'] = 'test_token'
    galaxy_token_1.save()

    galaxy_token_2 = GalaxyToken()
    assert(galaxy_token_2.config.get('token') == 'test_token')

    # Cleanup
    os.remove(galaxy_token_1.b_file)
    assert(not os.path.isfile(galaxy_token_1.b_file))



# Generated at 2022-06-24 19:34:26.702206
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create uninitialized token
    galaxy_token = GalaxyToken()

    # Save it
    galaxy_token.save()

    # Remove the file and re-test
    try:
        os.remove(to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict'))
    except OSError:
        pass

    try:
        uid = os.getuid()
    except AttributeError:
        uid = '?'  # windows does not have uid

    display.vvv('Token file %s removed' % C.GALAXY_TOKEN_PATH)
    galaxy_token.save()

    assert os.path.isfile(to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict'))

# Generated at 2022-06-24 19:34:32.915305
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:34:43.949348
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create a new token file
    token_file = "/tmp/test.token"
    token_file_content = {'token': 'dummy_token'}
    with open(token_file, 'w') as f:
        yaml_dump(token_file_content, f, default_flow_style=False)

    # Create a new GalaxyToken
    test_token = GalaxyToken()
    # Overload the token file to test token file
    test_token.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    test_token._config = {}
    test_token._config['token'] = 'test_token'
    test_token.save()
    # Open the file, check if the content is correct

# Generated at 2022-06-24 19:34:52.668733
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-24 19:34:59.318755
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token0 = KeycloakToken(access_token="5e5d4493-f7a3-48c3-835c-57c9a7f2e78b",
                           auth_url="https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token")
    print(token0.get())


# Generated at 2022-06-24 19:35:05.638682
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = KeycloakToken(auth_url='http://sso.redhat.com',
                                   access_token="123456",
                                   validate_certs=True,
                                   client_id=None)
    result = galaxy_token_0.get()
    assert True



# Generated at 2022-06-24 19:35:11.536238
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.config = {'foo': 'bar'}
    galaxy_token.save()
    with open(galaxy_token.b_file, 'r') as f:
        config = yaml_load(f)
    os.remove(galaxy_token.b_file)
    assert config == {'foo': 'bar'}

# Run tests
#test_case_0()
#test_GalaxyToken_save()

# Generated at 2022-06-24 19:35:31.811379
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    k_token = KeycloakToken('test-token', 'https://auth.url', False, 'test-client')
    assert k_token.get() == 'test-token'


# Generated at 2022-06-24 19:35:41.800025
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    # Setup
    access_token = 'thisIsAnAccessToken'
    auth_url = 'https://example.com'
    client_id = 'my-client'
    keycloak = KeycloakToken(access_token, auth_url, client_id=client_id)

    # Test with raw token
    raw_token = 'thisIsARawToken'
    keycloak._token = raw_token
    assert keycloak.get() == raw_token

    # Test without raw token
    keycloak._token = None

    # Update the get method of the NetworkMock
    payload = keycloak._form_payload()
    open_url_mock = NetworkMock()
    open_url_mock.set_get_response(payload)

    #  Redirect open_url to NetworkMock
    old

# Generated at 2022-06-24 19:35:45.781403
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken({'token': 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'})
    # This causes the token file to be written
    galaxy_token_0.save()


# Generated at 2022-06-24 19:35:49.478960
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    file_name = "test_GalaxyToken_save.yml"
    galaxy_token_save = GalaxyToken()

    # test if save works by checking the write file
    galaxy_token_save.set("some token test")
    galaxy_token_save.save()

    with open(galaxy_token_save.b_file, 'r') as f:
        config = list(yaml_load_all(f))
        assert config[0].get("token") == "some token test"

    os.remove(file_name)

# Generated at 2022-06-24 19:35:54.931689
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='my_token', auth_url='https://server.url', client_id='client-id')
    kct.get()


# Generated at 2022-06-24 19:35:58.676768
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_keycloak_token = KeycloakToken(access_token='refresh_token',
                                        auth_url='token_url')
    test_keycloak_token.get()
    assert test_keycloak_token.headers() == {'Authorization': 'Bearer null'}



# Generated at 2022-06-24 19:36:07.692228
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-24 19:36:18.161738
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """ Test save method of class GalaxyToken"""
    temp_file = '/tmp/galaxy_token.yml'
    tmp_token = GalaxyToken(token="test_token")
    assert not os.path.isfile(temp_file)
    tmp_token.b_file = '/tmp/galaxy_token.yml'
    tmp_token.save()
    assert os.path.isfile(temp_file)
    os.remove(temp_file)
    # Test file exists
    tmp_token.save()
    assert os.path.isfile(temp_file)
    os.remove(temp_file)


# Generated at 2022-06-24 19:36:27.046572
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Case 1:
    # - No Token Sentinal - this represents the case where the token has been
    #   deleted (ansible-galaxy login -q) or never existed (generated
    #   ansible.cfg with 'galaxy_token: null')
    # - Token should be None
    kt0 = KeycloakToken(access_token=NoTokenSentinel)
    assert kt0.get() is None

    # Case 2:
    # - Token does not exist in ansible.cfg
    # - Token should be None
    kt1 = KeycloakToken()
    assert kt1.get() is None

    # Case 3:
    # - Token is present in ansible.cfg
    # - Token should not be None
    access_token = '1234'

# Generated at 2022-06-24 19:36:33.684824
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = 'http://auth.url/'
    auth_token = '123456'
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=%s' % auth_token
    auth_retval = '{\"access_token\": \"valid_access_token\"}'
    # Run test
    token_obj = KeycloakToken(auth_token, auth_url)
    assert token_obj.get() == 'valid_access_token'


# Generated at 2022-06-24 19:37:03.584694
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    t = GalaxyToken()
    t.set('test')
    print(t.get())
    t.save()
    tg = GalaxyToken()
    print(tg.get())
    assert(tg.get() == t.get())

if __name__ == "__main__":
    test_case_0()
    test_GalaxyToken_save()

# Generated at 2022-06-24 19:37:05.819555
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_0 = KeycloakToken()
    headers_0 = galaxy_token_0.headers()


# Generated at 2022-06-24 19:37:06.982647
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.save()


# Generated at 2022-06-24 19:37:16.599402
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct_a = KeycloakToken(access_token='abcdefg')
    assert 'Authorization' in kct_a.headers().keys()
    assert 'Bearer' == kct_a.headers()['Authorization'][:6]
    assert 'abcdefg' == kct_a.headers()['Authorization'][7:]

    kct_b = KeycloakToken(access_token='12345')
    assert 'Authorization' in kct_b.headers().keys()
    assert 'Bearer' == kct_b.headers()['Authorization'][:6]
    assert '12345' == kct_b.headers()['Authorization'][7:]


# Generated at 2022-06-24 19:37:26.723953
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_0 = KeycloakToken(auth_url="https://cloud.redhat.com/api/token/refresh/", access_token="access_token_0", validate_certs=False)
    result = galaxy_token_0.headers()

# Generated at 2022-06-24 19:37:31.550678
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Unit test config
    access_token = '<my_test_token_value>'
    auth_url = '<my_test_auth_url>'

    kt = KeycloakToken(access_token=access_token, auth_url=auth_url)

    token = kt.get()

    # Assertions
    assert token is not None


# Generated at 2022-06-24 19:37:39.816846
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:37:40.849703
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.save()


# Generated at 2022-06-24 19:37:48.470486
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = 'access_token_123'

    # initialize a token object
    test_token = KeycloakToken(access_token=token)

    # test when the token is explicitly set
    token_1 = test_token.get()
    if token != token_1:
        raise AssertionError("test_KeycloakToken_get: expected '%s', got '%s" % (token, token_1))

    # test set the token to None
    test_token._token = None
    token_2 = test_token.get()
    if token != token_2:
        raise AssertionError("test_KeycloakToken_get expected '%s', got '%s" % (token, token_2))


# Generated at 2022-06-24 19:37:50.085534
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='XYZ', auth_url='http://foo.com/token')
    assert(token.get() == 'ZYX')
