

# Generated at 2022-06-24 19:28:05.828831
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken(access_token='access_token_0', auth_url='auth_url_0', validate_certs=True, client_id='client_id_0')
    token = keycloak_token_0.get()


# Generated at 2022-06-24 19:28:12.598037
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='d5199f60-c5e9-4b1c-aec0-a1ee1510e678', auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token')
    print(token.get())

if __name__ == "__main__":
    test_KeycloakToken_get()

# Generated at 2022-06-24 19:28:19.586495
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token_file = os.path.join(C.ROLE_CACHE_PATH, '.cloud-token')
    #assert os.path.isfile(token_file)
    f = open(token_file, 'r')
    data = json.load(f)
    f.close()
    access_token = data['access_token']
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

    keycloak_token_0 = KeycloakToken(access_token=access_token, auth_url=auth_url)
    headers = keycloak_token_0.get()
    print(headers)
    assert len(headers) > 0


# Generated at 2022-06-24 19:28:23.081853
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.config = { 'token': 'mocked token' }
    galaxy_token_0.save()


# Generated at 2022-06-24 19:28:31.134638
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:28:33.327436
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = ''
    auth_url = ''
    validate_certs = True
    client_id = ''
    kt = KeycloakToken(token, auth_url, validate_certs, client_id)
    print(kt.get())


# Generated at 2022-06-24 19:28:34.617842
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_2 = GalaxyToken()


# Generated at 2022-06-24 19:28:46.975223
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:28:50.848026
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.set(None)
    galaxy_token.save()
    config = galaxy_token.config
    assert 'token' not in config
    assert config == {}


# Generated at 2022-06-24 19:28:55.758810
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():

    galaxy_token_0 = GalaxyToken()
    config = {'token': 'meowcat'}
    galaxy_token_0.config = config

    with open('test.yml', 'w') as f:
        yaml_dump({}, f, default_flow_style=False)

    galaxy_token_0.save()


# Generated at 2022-06-24 19:29:03.753622
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # create a test KeycloakToken instance
    test_KeycloakToken = KeycloakToken('testKeycloakTokenaccess_token', 'testKeycloakTokenauth_url')

    # mock the return value for KeycloakToken.get
    test_KeycloakToken._token = 'testValue'

    # perform the test call
    testReturnValue = test_KeycloakToken.get()

    # ensure that the method call was successful
    assert testReturnValue == 'testValue'


# Generated at 2022-06-24 19:29:06.524384
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken(access_token = 'None')
    response_0 = keycloak_token_0.get()



# Generated at 2022-06-24 19:29:09.091388
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with a successful response
    t = KeycloakToken(auth_url='https://master.cloud.engineyard.com/api/v2/users/auth_token', access_token='something')
    t.get()


if __name__ == '__main__':
    test_case_0()
    test_KeycloakToken_get()

# Generated at 2022-06-24 19:29:17.023513
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken("keycloak_token_0")

    # Execution of _form_payload
    assert keycloak_token_0._form_payload() == "grant_type=refresh_token&client_id=cloud-services&refresh_token=keycloak_token_0"

    # Re-excecution of _form_payload
    assert keycloak_token_0._form_payload() == "grant_type=refresh_token&client_id=cloud-services&refresh_token=keycloak_token_0"

    # Execution of get
    keycloak_token_0._token = "keycloak_token_0"
    assert keycloak_token_0.get() == "keycloak_token_0"
    keycl

# Generated at 2022-06-24 19:29:21.778504
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Arrange
    # TODO: add params to instantiate object
    keycloak_token_0 = KeycloakToken()
    # Act
    result_value_0 = keycloak_token_0.headers()
    # Assert
    assert result_value_0 is not None


# Generated at 2022-06-24 19:29:25.703820
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    try:
        galaxy_token.save()
    except Exception as e:
        # TODO: need to fix the expected exception here
        assert(e.__class__.__name__ == '')


# Generated at 2022-06-24 19:29:27.031216
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # TODO: write test
    raise NotImplementedError()



# Generated at 2022-06-24 19:29:33.638940
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with no token sentinel
    keycloak_token_0 = KeycloakToken()
    keycloak_token_0.access_token = NoTokenSentinel()
    keycloak_token_0.get()
    # Test with good token
    keycloak_token_1 = KeycloakToken()
    keycloak_token_1.access_token = 42
    assert keycloak_token_1.get() == 42


# Generated at 2022-06-24 19:29:37.404679
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct0 = KeycloakToken(access_token='test_access_token',
                         auth_url='test_auth_url',
                         validate_certs=True)
    kct0._token = 'test_token'
    assert kct0.get() == 'test_token'
                

# Generated at 2022-06-24 19:29:43.753685
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('dummy_token', 'https://dummy_url', False, 'dummy_client')
    # Mock the open_url. Return a mock response
    import unittest.mock
    open_url_mock = unittest.mock.Mock()
    open_url_mock.return_value.read.return_value = '{"access_token": "dummy_new_token"}'
    unittest.mock.patch("ansible.module_utils.urls.open_url", open_url_mock).start()
    assert token.get() == 'dummy_new_token'


# Generated at 2022-06-24 19:29:57.688900
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:30:08.509298
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:30:15.593525
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-24 19:30:17.102341
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = KeycloakToken()
    assert galaxy_token_0.get() is None


# Generated at 2022-06-24 19:30:19.253624
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_0 = KeycloakToken()
    assert galaxy_token_0.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-24 19:30:25.056737
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test case 0
    keycloak_token_0 = KeycloakToken(access_token='', auth_url='https://test.test', client_id='test')

    # Make sure the token is empty
    assert keycloak_token_0.get() == None

    # Test case 1
    keycloak_token_1 = KeycloakToken(access_token='', auth_url='https://test.test', client_id='test')

    # Make sure the token is empty
    assert keycloak_token_1.get() == None



# Generated at 2022-06-24 19:30:29.532973
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token_headers = GalaxyToken().headers
    assert 'Authorization' in galaxy_token_headers
    assert 'Token' in galaxy_token_headers['Authorization']


# Generated at 2022-06-24 19:30:31.809477
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken()
    assert keycloak_token.get() is None


# Generated at 2022-06-24 19:30:37.625915
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token_1 = NoTokenSentinel()
    keycloakToken_test = KeycloakToken(access_token=token_1, auth_url='https://foo', validate_certs=True, client_id='cloud-services')
    keycloakToken_test.get()

# Generated at 2022-06-24 19:30:40.314890
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='<ACCESS_TOKEN>')
    assert token.headers() == {'Authorization': 'Bearer <ACCESS_TOKEN>'}



# Generated at 2022-06-24 19:30:49.116431
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    # TODO: Implement test for method save of class GalaxyToken


# Generated at 2022-06-24 19:30:58.029875
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    import tempfile
    import random
    import string
    import ssl
    import os
    import shutil

    # testing get on user with no token (no token in ansible.cfg)
    test_token = KeycloakToken(access_token=None, auth_url=None)
    assert test_token.get() is None

    # testing get on user with no token (could not open connection)
    test_token = KeycloakToken(access_token='test', auth_url='https://google.com')
    assert test_token.get() is None

    # testing get on user with no token (invalid offline token)
    test_cert = tempfile.NamedTemporaryFile(delete=False)
    test_cert.close()

# Generated at 2022-06-24 19:31:03.323138
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Create test data
    galaxy_token_data = {
        'token': 'some_token',
    }
    galaxy_token_0 = GalaxyToken(galaxy_token_data)
    # unit test call
    galaxy_token_0.save()
    # assert the result
    assert True



# Generated at 2022-06-24 19:31:07.821797
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    # Case 1. Not set
    k = KeycloakToken(access_token='not_set')
    assert(k.get() == None)
    # Case 2. valid
    k = KeycloakToken(access_token='test_access_token')
    assert(k.get() == 'test_access_token')


# Generated at 2022-06-24 19:31:17.615385
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """
    Test the GalaxyToken save method.
        - Create token file
        - write data to it
        - confirm data was written and file has _rw_ permissions
    """
    # absolute path to the example token file
    b_file_path = os.path.abspath('./test_galaxy_token.yml')
    # delete any existing file
    if os.path.exists(b_file_path):
        os.remove(b_file_path)

    galaxy_token_0 = GalaxyToken(token=NoTokenSentinel)
    galaxy_token_0.b_file = b_file_path
    galaxy_token_0.config = {'token': 'token_value'}
    galaxy_token_0.save()

    # confirm that the token file was created

# Generated at 2022-06-24 19:31:27.017759
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:31:32.308627
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_config_0 = {'key': 'value'}
    test_file_0 = to_bytes('/home/vagrant/ansible-test/test_data/galaxy_token/token_0')
    # TODO: Add more tests
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0._config = test_config_0
    galaxy_token_0.b_file = test_file_0
    galaxy_token_0.save()


# Generated at 2022-06-24 19:31:39.016411
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.config = {'token': '89e2238511c24a2980b8d04e43909dbb', 'last_modified': '2017-02-10T19:29:56.117118'}
    galaxy_token_0.save()



# Generated at 2022-06-24 19:31:44.746684
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken(access_token='test', auth_url='test')
    s = kct.get()
    if s == None:
        return (False, 'get() return empty object')
    else:
        return (True, 'test_KeycloakToken_get passed')


# Generated at 2022-06-24 19:31:57.100679
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:32:06.144662
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    test_token = 'test token'
    galaxy_token.set(test_token)
    del galaxy_token
    galaxy_token = GalaxyToken()
    token = galaxy_token.get()
    assert token == test_token
    galaxy_token.set(None)
    del galaxy_token


if __name__ == '__main__':
    import sys
    globals()[sys.argv[1]]()

# Generated at 2022-06-24 19:32:08.031953
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token="foo")
    assert kt.get() == "foo"


# Generated at 2022-06-24 19:32:19.084273
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.yaml import YAML
    from ansible.module_utils.yaml import YAMLDumper
    from ansible.module_utils.yaml import YAMLLoader
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    open_mock = mock.mock_open()

# Generated at 2022-06-24 19:32:22.902393
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.set('new_token')
    assert galaxy_token_1.get() == 'new_token'


# Generated at 2022-06-24 19:32:34.060684
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(auth_url="https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token")

# Generated at 2022-06-24 19:32:40.070712
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    ''' Unit tests for KeycloakToken.get method '''
    token = KeycloakToken(access_token="0123456789abcdefghijklmnopqrstuvwxyz",
                          auth_url='https://auth.foo.com/auth/realms/master/protocol/openid-connect/token')
    token.get()


if __name__ == '__main__':
    test_case_0()
    test_KeycloakToken_get()

# Generated at 2022-06-24 19:32:42.326685
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    print('Testing headers of class KeycloakToken')
    galaxy_token_1 = KeycloakToken()
    print(galaxy_token_1.headers())


# Generated at 2022-06-24 19:32:48.566536
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='my_access_token', auth_url='my_auth_url', validate_certs=True, client_id='my_client_id')
    print(kct.headers())



# Generated at 2022-06-24 19:32:50.918211
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token = 'token_test'
    galaxy_token_0 = GalaxyToken(test_token)
    assert test_token == galaxy_token_0.get()


# Generated at 2022-06-24 19:32:52.850528
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='a', auth_url='b')
    token.get()


# Generated at 2022-06-24 19:33:02.418985
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('testkeycloaktoken')
    result = token.get()
    assert result == 'testkeycloaktoken', ("Result: %s" % result)


# Generated at 2022-06-24 19:33:11.960583
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(access_token='eyJ1c2VyX25hbWUiOiJKb2UiLCJzY2', auth_url='/net.keycloak/token', validate_certs=True, client_id=None)
    assert keycloak_token.access_token == True
    assert keycloak_token.auth_url == True
    assert keycloak_token.validate_certs == True
    assert keycloak_token.client_id == None
    assert keycloak_token._form_payload() == True
    assert keycloak_token.get() == True


# Generated at 2022-06-24 19:33:15.630334
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    obj = KeycloakToken(access_token="TEST_VALUE", auth_url="TEST_VALUE", client_id="TEST_VALUE", validate_certs=False)
    ret = obj.get()

    assert ret is None


# Generated at 2022-06-24 19:33:24.205698
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='a_thing',
                          validate_certs=True,
                          auth_url='https://auth.url.example.com/auth/realms/realm_name/protocol/openid-connect/token',
                          client_id='test-client')

    headers = token.headers()

    assert headers['Authorization'] == "Bearer %s" % token.get()



# Generated at 2022-06-24 19:33:25.869504
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = GalaxyToken()
    assert galaxy_token_0.get() == None

# Generated at 2022-06-24 19:33:32.642531
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Initialize test values
    access_token = 'fake_access_token'
    auth_url = 'http://auth.url'
    validate_certs = False
    client_id = 'fake_client_id'

    token = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    token.get()


# Generated at 2022-06-24 19:33:34.687621
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    result = KeycloakToken('access_token_foobar')
    assert 'Authorization' in result.headers()

# Generated at 2022-06-24 19:33:38.360175
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = KeycloakToken(access_token="access_token_0", auth_url="auth_url_1", validate_certs="validate_certs_2")
    assert galaxy_token_0.get() == "access_token_0"



# Generated at 2022-06-24 19:33:41.537019
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(access_token='abc', auth_url='/some/url')
    headers = kct.headers()
    assert headers['Authorization'] == 'Bearer abc', 'token type should be Bearer'


# Generated at 2022-06-24 19:33:44.809204
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'test_token_string'
    auth_url = 'url'
    token = KeycloakToken(access_token=access_token, auth_url=auth_url)
    payload = 'grant_type=refresh_token&client_id=cloud-services&refresh_token=test_token_string'
    token_return = token.get()
    assert token_return is None


# Generated at 2022-06-24 19:34:16.442930
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    # When running this test alone, C.GALAXY_TOKEN_PATH is undefined
    # so we need to use a temporary path to a galaxy token file.
    # Construct a temporary path.
    import tempfile
    tmpdir = tempfile.mkdtemp()
    tmpgalaxytokenfile = tmpdir + '/galaxy_token_unittest'

    # GalaxyToken needs the token file
    with open(tmpgalaxytokenfile, 'w') as f:
        yaml_dump({'token': 'dummy'}, f, default_flow_style=False)

    # KeycloakToken needs the user's offline token from Red Hat Single Sign On
    rhsso_offline_token = 'dummy_offline_token'  # Get it from rhsso.redhat.com

# Generated at 2022-06-24 19:34:21.222415
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='myaccess_token', auth_url='http://authurl.com')
    assert kt.get() == 'myaccess_token'
    kt.access_token = 'KLKLKLLK'
    assert kt.get() == 'KLKLKLLK'


# Generated at 2022-06-24 19:34:22.268952
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken()
    token.get()

# Generated at 2022-06-24 19:34:28.208251
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken(auth_url='https://auth.example.com/token', access_token='the_access_token')
    h = kt.headers()
    assert h['Authorization'] == 'Bearer %s' % kt.token_type


# Generated at 2022-06-24 19:34:33.986122
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    galaxy_token_0 = KeycloakToken(access_token='access_token_0',
                                   auth_url='auth_url_1',
                                   validate_certs=True,
                                   client_id='client_id_3')
    token = galaxy_token_0.get()



# Generated at 2022-06-24 19:34:37.417888
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_galaxy_token = GalaxyToken()
    assert os.path.isfile(test_galaxy_token.b_file)
    test_galaxy_token.set("test_toke")
    test_galaxy_token.save()
    test_galaxy_token_2 = GalaxyToken()
    assert test_galaxy_token_2.config == {'token': 'test_toke'}



# Generated at 2022-06-24 19:34:39.330927
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:34:47.855845
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'e5a9b9d0-9a6c-4b8e-a2a1-271516b0c567'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    client_id = 'ansible-galaxy-cli'

    KeycloakToken_0 = KeycloakToken(access_token, auth_url, True, client_id)
    KeycloakToken_0.get()
    assert KeycloakToken_0._token is not None


# Generated at 2022-06-24 19:34:52.977223
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.config = [
        {
            'version': '1.0',
            'token': 'foo'
        }
    ]
    galaxy_token_1.save()


# Generated at 2022-06-24 19:34:58.259915
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a token
    token = KeycloakToken("https://testing.ansible.com", True)

    # Set the access token
    token.access_token = 12345

    # Call get and make sure the token is returned
    assert token.get() == 12345


# Generated at 2022-06-24 19:36:04.287294
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token="a94a8fe5ccb19ba61c4c0873d391e987982fbbd3", auth_url="https://auth.example.com")
    token.get()



# Generated at 2022-06-24 19:36:08.358774
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='some_valid_token', auth_url='https://auth.url.com/auth/realms/dev/token')
    assert token.get() == 'some_valid_token'


# Generated at 2022-06-24 19:36:14.507161
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_token = "test_token"
    galax_token = GalaxyToken(token=test_token)
    galax_token.save()

    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)

    assert config['token'] == test_token


# Generated at 2022-06-24 19:36:25.808864
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloaktokentest0 = KeycloakToken(access_token=None, auth_url=None, validate_certs=True, client_id=None)
    keycloaktokentest0.auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    keycloaktokentest0.access_token = 'mF_9.B5f-4.1JqM'
    assert keycloaktokentest0.auth_url == 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    assert keycloaktokentest0.access_token == 'mF_9.B5f-4.1JqM'


# Generated at 2022-06-24 19:36:32.000752
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='refresh_token', auth_url='auth_url')
    assert token.get() is None
    assert token._form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=refresh_token'


# Generated at 2022-06-24 19:36:38.361266
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    test_obj = KeycloakToken("2345678901234567890123456789012",
                             "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token",
                             validate_certs=True,
                             client_id="cloud-services")
    test_obj.get()


# Generated at 2022-06-24 19:36:41.436760
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken()
    display.display('keycloak_token_0.headers() = %s' % keycloak_token_0.headers())


# Generated at 2022-06-24 19:36:43.480451
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config = {'token' : 'tokenvalue'}
    assert(token.save()) == None



# Generated at 2022-06-24 19:36:45.375799
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    auth_0 = GalaxyToken()
    auth_1 = GalaxyToken()
    # TODO: implement
    pass


# Generated at 2022-06-24 19:36:47.820630
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('A')
    assert token.get() == 'A'


# Generated at 2022-06-24 19:37:11.307828
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='123')
    assert token.headers() == {'Authorization': 'Bearer b'}


# Generated at 2022-06-24 19:37:18.412196
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token = KeycloakToken(access_token='dummy', auth_url='dummy')
    token = keycloak_token.get()
    expected = 'dummy'
    assert token == expected, 'keycloak_token.get() is %r (should be %r)' % (token, expected)
    headers = keycloak_token.headers()
    expected = {'Authorization': 'Bearer dummy'}
    assert headers == expected, 'keycloak_token.headers() is %r (should be %r)' % (headers, expected)


# Generated at 2022-06-24 19:37:20.209935
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    tkn = KeycloakToken('abc123')
    assert tkn.headers() == {'Authorization': 'Bearer None'}


# Generated at 2022-06-24 19:37:30.366371
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-24 19:37:32.173954
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    t = KeycloakToken(access_token='ACCESS_TOKEN')
    assert t.get() == 'ACCESS_TOKEN'


# Generated at 2022-06-24 19:37:39.054491
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # object to perform test case
    token = GalaxyToken()

    # case 0:
    #   - token is not set
    #   - the file is not created
    #   - expected result: no file is created
    # perform the test case
    #assert not os.path.exists(token.b_file)
    token.save()
    assert os.path.exists(token.b_file)

    # case 1:
    #   - token is set
    #   - the file is created
    #   - expected result: file is created and the content is the token
    # perform the test case
    token.set('dummy_token')
    token.save()
    assert os.path.exists(token.b_file)

# Generated at 2022-06-24 19:37:50.508908
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:37:57.346209
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    import json
    json_object = json.loads(open_url.__code__.co_consts[1])