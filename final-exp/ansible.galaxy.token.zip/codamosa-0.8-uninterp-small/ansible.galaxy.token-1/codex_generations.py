

# Generated at 2022-06-24 19:28:04.218655
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    return


# Generated at 2022-06-24 19:28:11.900457
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token = 'access_token'
    auth_url = 'http://www.google.com'
    validate_certs = True
    client_id = 'client_id'
    keycloak_token_0 = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    assert keycloak_token_0.headers() == [('Authorization', 'Bearer Token'), ('Authorization', 'Token')]


# Generated at 2022-06-24 19:28:15.465745
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    str_0 = 'RFD@'
    basic_auth_token_0 = BasicAuthToken(str_0)
    galaxy_token_0 = GalaxyToken(basic_auth_token_0)
    galaxy_token_0.save()


# Generated at 2022-06-24 19:28:16.799566
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    str_0 = 'tKi>'
    galaxy_token_0 = GalaxyToken(str_0)
    galaxy_token_0.save()


# Generated at 2022-06-24 19:28:25.434444
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    str_0 = 'ybWH[j'
    str_1 = 'WgfZ7v'
    str_2 = '=t'
    str_3 = 'PQ7n'
    str_4 = 'xq9X~'
    access_token_0 = str_1
    auth_url_0 = str_2
    validate_certs_0 = False
    client_id_0 = str_3
    keycloak_token_0 = KeycloakToken(access_token_0, auth_url_0, validate_certs_0, client_id_0)
    str_5 = '{+}'
    str_6 = '<fk=o'
    str_7 = 'sF'
    str_8 = 'X'
    access_token_1 = str_7


# Generated at 2022-06-24 19:28:27.456333
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    # AssertionError: AssertionError: {'token': None} != {}
    # assert token.save() == {}


# Generated at 2022-06-24 19:28:36.196833
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    sso_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-24 19:28:40.239535
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'u_XS'
    keycloak_token_0 = KeycloakToken(access_token)
    keycloak_token_0.get()


# Generated at 2022-06-24 19:28:42.415261
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()


# Generated at 2022-06-24 19:28:45.514219
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    str_0 = 'NAUF}'
    str_1 = 'W^Z{R.%:!'
    keycloak_token_0 = KeycloakToken(str_0, str_1)
    keycloak_token_0.get()


# Generated at 2022-06-24 19:29:00.057322
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    print('Testing headers')

# Generated at 2022-06-24 19:29:02.708730
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    no_token_sentinel_0 = NoTokenSentinel()
    keycloak_token_0 = KeycloakToken(auth_url=no_token_sentinel_0, validate_certs=True)
    keycloak_token_0.headers()


# Generated at 2022-06-24 19:29:06.128526
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_save_0 = GalaxyToken()
    with open(galaxy_token_save_0.b_file, 'w') as f:
        yaml_dump(galaxy_token_save_0.config, f, default_flow_style=False)

if __name__ == "__main__":
    test_GalaxyToken_save()

# Generated at 2022-06-24 19:29:07.122499
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.save()


# Generated at 2022-06-24 19:29:14.650354
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Setup
    b_file = '/tmp/ansible_test_file'
    a_galaxy_token = GalaxyToken()
    # Pre-assert
    assert a_galaxy_token.config == {}
    # Test
    a_galaxy_token.save()
    # Post-assert
    try:
        os.remove(b_file)
    except OSError as e:
        if e.errno != errno.ENOENT:  # errno.ENOENT = no such file or directory
            raise  # re-raise exception if a different error occurred


# Generated at 2022-06-24 19:29:22.589095
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    no_token_sentinel_0 = NoTokenSentinel()
    keycloak_token_0 = KeycloakToken(no_token_sentinel_0)

    try:
        keycloak_token_0.get()
        assert False
    except:
        pass

    keycloak_token_0 = KeycloakToken(no_token_sentinel_0)
    keycloak_token_0._token = 'dummy_token'
    keycloak_token_0.get()


# Generated at 2022-06-24 19:29:28.392657
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token_0 = 'access_token_0'
    access_token_1 = 'access_token_1'
    access_token_2 = 'access_token_2'
    auth_url_0 = 'auth_url_0'
    auth_url_1 = 'auth_url_1'
    auth_url_2 = 'auth_url_2'
    validate_certs_0 = 'validate_certs_0'
    validate_certs_1 = 'validate_certs_1'
    validate_certs_2 = 'validate_certs_2'
    keycloak_token_0 = KeycloakToken(access_token=access_token_0, auth_url=auth_url_0, validate_certs=validate_certs_0)
    keycloak_token_

# Generated at 2022-06-24 19:29:37.768807
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:29:43.330286
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    TEST_FILE_NAME = 'test.file'
    TEST_FILE = os.path.join(os.path.dirname(__file__), TEST_FILE_NAME)
    obj_GalaxyToken = GalaxyToken()
    obj_GalaxyToken.set('hello')
    obj_GalaxyToken.b_file = to_bytes(TEST_FILE_NAME, errors='surrogate_or_strict')
    obj_GalaxyToken.save()
    assert os.path.isfile(TEST_FILE)
    os.remove(TEST_FILE)


# Generated at 2022-06-24 19:29:48.733954
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token_0 = None
    url_0 = 'https://sso.redhat.com/auth/realms/rh-cloud/protocol/openid-connect/token'
    validate_0 = True
    client_id_0 = None

    kt_0 = KeycloakToken(token_0, url_0, validate_0, client_id_0)
    headers_0 = kt_0.headers()
    return headers_0


# Generated at 2022-06-24 19:30:01.639832
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct_0 = KeycloakToken(access_token='access_token_0', auth_url='auth_url_1')

    headers_0 = kct_0.headers()
    assert headers_0 == {'Authorization': '%s %s' % ('Bearer', kct_0.get())}, 'Expected header value did not match'


# Generated at 2022-06-24 19:30:07.356272
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken('abcd', 'http://example.com', False)
    assert kct.token_type == 'Bearer'
    assert kct.access_token == 'abcd'
    assert kct.validate_certs == False
    assert kct.auth_url == 'http://example.com'
    assert kct.headers() == {'Authorization': 'Bearer abcd'}


# Generated at 2022-06-24 19:30:15.279068
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    b_file = '/tmp/test_save'
    token = 'test_token'
    config = {'token' : token}

    galaxToken = GalaxyToken()
    galaxToken._config = config
    galaxToken.b_file = b_file

    galaxToken.save()

    # test file created
    assert os.path.isfile(b_file)
    file_config = None
    with open(b_file, 'r') as f:
        file_config = yaml_load(f)

    # make sure content is correct
    assert config == file_config


# Generated at 2022-06-24 19:30:19.881608
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    no_token_sentinel_0 = NoTokenSentinel()
    access_token = "9gIx7M-pU6"
    auth_url = "https://auth.acme.com/auth/realms/acme/protocol/openid-connect/token"
    validate_certs = False
    kc_token_0 = KeycloakToken(access_token, auth_url, validate_certs)
    kc_token_0.get()


# Generated at 2022-06-24 19:30:26.186259
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'foo'
    auth_url = 'https://example.com/token'
    token = 'bar'
    class FakeReponse(object):
        def read(self):
            return json.dumps({'access_token': token})

    class FakeOpener(object):
        def __init__(self, *args, **kwargs):
            return FakeReponse()

    old_open_url = open_url
    open_url = FakeOpener
    kc_token = KeycloakToken(access_token, auth_url)
    assert kc_token.get() == token
    open_url = old_open_url



# Generated at 2022-06-24 19:30:33.059726
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', 
                       access_token='U6wyMAQ6_eBc0V7AxbOc-uK7N1s0Eq4x')
    print(kt.get())
    print(kt.headers())


# Generated at 2022-06-24 19:30:42.159992
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token_0 = 'dummy_access_token'
    auth_url_0 = 'https://id.devgssci.devlab.phx1.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs_0 = True
    client_id_0 = 'cloud-services'
    galaxy_service_token = KeycloakToken(access_token_0, auth_url_0, validate_certs_0, client_id_0)
    expected = {
        'Authorization': 'Bearer %s' % 'dummy_access_token'
    }
    headers = galaxy_service_token.headers()
    assert headers == expected


# Generated at 2022-06-24 19:30:46.612820
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'Zf5WtCvWCN-g1JyhNcbcWQ'
    test_obj = GalaxyToken()
    test_obj.set(token)
    test_obj.save()
    assert open(C.GALAXY_TOKEN_PATH).read() == "token: {}\n".format(token)
    os.remove(C.GALAXY_TOKEN_PATH)


# Generated at 2022-06-24 19:30:50.128158
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken('fubar')
    galaxy_token.save()

    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-24 19:30:52.943415
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    no_token_sentinel_0 = NoTokenSentinel()
    galaxy_token_0 = GalaxyToken(no_token_sentinel_0)
    galaxy_token_0.config = {'token': 'test string'}
    galaxy_token_0.save()



# Generated at 2022-06-24 19:31:11.603497
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = '<access_token>'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True
    client_id = 'cloud-services'
    keycloak_token_0 = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    _token = keycloak_token_0.get()
    assert _token

    access_token = '<access_token>'
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    validate_certs = True
    client_id = None
    keycloak_token_0 = KeycloakToken

# Generated at 2022-06-24 19:31:19.313533
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    vars = {'server': 'sso.redhat.com', 'validate_certs': True,
            'auth_url': 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'}
    # Load Token from ansible.cfg
    token = GalaxyToken(token=NoTokenSentinel)

    keys = [
        'offline_access_token',
        'offline_access_token_expires_in',
        'offline_access_token_issued_at',
        'offline_access_token_expiration_time'
    ]

    kt0 = KeycloakToken(access_token=token.get(), auth_url=vars['auth_url'],
                        validate_certs=vars['validate_certs'])

# Generated at 2022-06-24 19:31:28.182154
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with access_token = None
    access_token = None
    auth_url = 'https://example.net'
    validate_certs = True
    client_id = 'cloud-services'
    test_instance = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    assert test_instance != None
    # Test with access_token having value 'A0000000001'
    access_token = 'A0000000001'
    auth_url = 'https://example.net'
    validate_certs = True
    client_id = 'cloud-services'
    test_instance = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    assert test_instance != None


# Generated at 2022-06-24 19:31:29.449885
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()


# Generated at 2022-06-24 19:31:30.900745
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()


# Generated at 2022-06-24 19:31:34.315379
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.set('token')
    galaxy_token_0.save()

# Generated at 2022-06-24 19:31:44.707088
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:31:56.997203
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:31:58.992871
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()



# Generated at 2022-06-24 19:32:02.708922
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()


# Generated at 2022-06-24 19:32:37.067019
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    b_payload = to_bytes('grant_type=refresh_token&client_id=cloud-services&refresh_token=WOW_TOKEN_GOES_HERE', errors='surrogate_or_strict')
    b_resp_data = to_bytes('{"access_token": "LOTS_OF_DATA", "expires_in": 10, "refresh_expires_in": 1800000, "refresh_token": "NEW_WOW_TOKEN_GOES_HERE", "token_type": "bearer", "not-before-policy": 0, "session_state": "71c0d385-0d59-4c55-a735-f301f6e7e789", "scope": "profile email"}', errors='surrogate_or_strict')

# Generated at 2022-06-24 19:32:45.226712
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    auth_url_0 = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    access_token_0 = 'OAQb2V4mW8-wEw_YHMzixrQr1XIsXd6oR0aD_U6gO7w'
    validate_certs_0 = False
    client_id_0 = 'cloud-services'
    keycloak_token_0 = KeycloakToken(access_token=access_token_0,
                                     auth_url=auth_url_0,
                                     validate_certs=validate_certs_0,
                                     client_id=client_id_0)
    headers_0 = keycloak_token_0.headers()
    assert headers_0

# Generated at 2022-06-24 19:32:47.103253
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token_obj = KeycloakToken('-valid-offline-token-')
    assert token_obj.get() == 'bearer token'


# Generated at 2022-06-24 19:32:52.043367
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    no_token_sentinel_1 = NoTokenSentinel()
    keycloak_token_0 = KeycloakToken(no_token_sentinel_1)
    try:
        keycloak_token_0.headers()
    except NameError as err:
        print(err)


if __name__ == '__main__':
    test_case_0()
    test_KeycloakToken_headers()

# Generated at 2022-06-24 19:32:54.817479
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('ABC123', 'https://www.example.com')
    assert token.get() == None
    token.access_token = 'abc123'
    assert token.get() == None


# Generated at 2022-06-24 19:33:00.369051
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    no_token_sentinel_0 = NoTokenSentinel()
    keycloak_token_1 = KeycloakToken(access_token=None, auth_url=None,
                                     validate_certs=None, client_id=no_token_sentinel_0)
    token = keycloak_token_1.headers()


# Generated at 2022-06-24 19:33:03.959691
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    username = 'ansible'
    password = 'password'
    token = BasicAuthToken(username, password)

    galaxy_token_0 = GalaxyToken(token)
    galaxy_token_0.save()


# Generated at 2022-06-24 19:33:10.236263
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    true = True
    false = False
    check_0 = KeycloakToken()
    expected_0 = {'Authorization': 'Bearer None'}
    actual_0 = check_0.headers()
    display.vvv('KeycloakToken_headers: expected_0 = %s, actual_0 = %s' % (expected_0, actual_0))
    assert expected_0 == actual_0


# Generated at 2022-06-24 19:33:11.960197
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_save_0 = GalaxyToken(NoTokenSentinel())
    galaxy_token_save_0.save()

# Generated at 2022-06-24 19:33:16.572701
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken()
    token.config['url'] = 'http://localhost'
    token.config['token'] = 'foobar'
    token.save()

    with open(to_bytes(C.GALAXY_TOKEN_PATH), 'r') as f:
        expected_result = f.read()

    os.remove(C.GALAXY_TOKEN_PATH)
    assert(expected_result == 'url: http://localhost\ntoken: foobar\n')


# Generated at 2022-06-24 19:34:08.586950
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:34:14.633928
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token._config = {
        "token": "foo",
        "server": "test",
    }
    galaxy_token.save()
    with open(galaxy_token.b_file, 'r') as f:
        config = yaml_load(f)
        assert config == galaxy_token._config

# Generated at 2022-06-24 19:34:17.436908
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    no_token_sentinel_0 = NoTokenSentinel()
    galaxy_token_0 = GalaxyToken(no_token_sentinel_0)
    galaxy_token_0.save()


# Generated at 2022-06-24 19:34:27.957185
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken(auth_url='/keycloak/auth/realms/redhat-external/protocol/openid-connect/token')
    #
    # method headers
    #
    # empty input
    headers = kct.headers()
    assert headers.get('Authorization') == 'Bearer None'
    # filled input
    kct.access_token = 'rc-token-123456'
    headers = kct.headers()
    assert headers.get('Authorization') == 'Bearer rc-token-123456'
    # filled but bad input
    kct.access_token = '/keycloak/auth/realms/redhat-external/protocol/openid-connect/token'
    headers = kct.headers()

# Generated at 2022-06-24 19:34:31.588031
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()


# Generated at 2022-06-24 19:34:42.107440
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:34:47.117316
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='example_token', auth_url='https://example.com/auth')
    try:
        assert token.get() == 'token_example'
    except Exception as err:
        raise AssertionError("Method get of class KeycloakToken does not return the correct value")


# Generated at 2022-06-24 19:34:53.795288
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken(
        access_token='http://example.com?q=param',
        auth_url='http://example.com?q=param',
        validate_certs=True,
        client_id='http://example.com?q=param')
    test_token = keycloak_token_0.get()
    assert type(test_token) == str


# Generated at 2022-06-24 19:34:55.965348
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    GalaxyToken_1 = GalaxyToken()
    # TODO: Test not implemented


# Generated at 2022-06-24 19:34:58.130260
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token_0 = GalaxyToken()
    galaxy_token_0.save()


# Generated at 2022-06-24 19:36:26.148668
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = None
    auth_url = "https://sso.redhat.com/auth/realms/ansible_cloud/protocol/openid-connect/token"
    validate_certs = True
    client_id = None
    token = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    token.get()


# Generated at 2022-06-24 19:36:30.168769
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()
    keycloak_token_0.get()



# Generated at 2022-06-24 19:36:33.986216
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH), "Galaxy token file has been deleted."

if __name__ == '__main__':
    test_GalaxyToken_save()

# Generated at 2022-06-24 19:36:44.377653
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file_name = '/tmp/ansible-galaxy-token'
    config = {}

    gt = GalaxyToken()
    b_file = to_bytes(token_file_name, errors='surrogate_or_strict')
    gt._config = {}
    gt.b_file = b_file
    gt.config = config
    gt.save()

    gt = GalaxyToken()
    gt.b_file = b_file
    gt.config = config
    cfg = gt._read()
    if cfg != config:
        raise Exception('Galaxy token file %s save and read are not idempotent (\n%s\n%s\n)' % (to_text(token_file_name), cfg, config))


# Generated at 2022-06-24 19:36:50.671282
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'test_value'
    auth_url = 'test_value'
    validate_certs = 'test_value'
    client_id = 'test_value'
    k1 = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    # Call method
    m1 = k1.get()

# Generated at 2022-06-24 19:36:55.333625
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = ''
    auth_url = ''
    validate_certs = True
    client_id = None
    keycloak_token_0 = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    display.vvv(keycloak_token_0.get())



# Generated at 2022-06-24 19:37:05.578398
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    access_token_0 = 'test_value'
    auth_url_0 = 'https://sso.redhat.com/auth/realms/ansible/protocol/openid-connect/token'
    validate_certs_0 = True
    client_id_0 = 'cloud-services'
    basic_auth_token_1 = BasicAuthToken(client_id_0)
    token = basic_auth_token_1.get()
    print(token)
    headers = basic_auth_token_1.headers()
    print(headers)
    # keycloak_token_0 = KeycloakToken(access_token_0, auth_url_0, validate_certs_0, client_id_0)
    # headers = keycloak_token_0.headers()
    # print(headers)

# Unit

# Generated at 2022-06-24 19:37:07.878010
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    no_token_sentinel_1 = NoTokenSentinel()
    keycloak_token_1 = KeycloakToken(no_token_sentinel_1)
    assert keycloak_token_1.headers() == {"Authorization": "Bearer None"}




# Generated at 2022-06-24 19:37:12.163841
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token_0 = '74597b9f-dee6-481a-b00c-3cd3b73e3cd8'
    auth_url_0 = 'https://example.com/'
    validate_certs_0 = True
    client_id_0 = 'cloud-services'
    keycloak_token_0 = KeycloakToken(access_token_0, auth_url_0, validate_certs_0, client_id_0)
    res = keycloak_token_0.get()
    if res is None:
        display.error("Expected to not get None, but got None")


# Generated at 2022-06-24 19:37:17.428368
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    with open(C.GALAXY_TOKEN_PATH, 'w') as f:
        config = {'token': 'test'}
        yaml_dump(config, f, default_flow_style=False)
    with open(C.GALAXY_TOKEN_PATH, 'r') as f:
        config = yaml_load(f)
        assert config['token'] == 'test'
    os.remove(C.GALAXY_TOKEN_PATH)