

# Generated at 2022-06-24 19:28:14.437528
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():

    galaxy_token_0 = GalaxyToken(token=NoTokenSentinel)
    keycloak_token_0 = KeycloakToken('refreshtoken', 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', validate_certs=True, client_id=None)
    assert isinstance(keycloak_token_0.headers(), dict)

    galaxy_token_1 = GalaxyToken(token='token')
    keycloak_token_1 = KeycloakToken('refreshtoken', 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token', validate_certs=True, client_id='clientid')
    assert isinstance(keycloak_token_1.headers(), dict)

    # Done

# Generated at 2022-06-24 19:28:17.194121
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = KeycloakToken(access_token='test_value_3', auth_url='test_value_4', validate_certs=True, client_id='test_value_6')
    assert token.headers() == {'Authorization': 'Bearer test_value_3'}

# Generated at 2022-06-24 19:28:25.623310
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:28:30.648052
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Initialize the object
    # ---------------------
    #
    # Reads the following KeycloakToken attributes from ansible.cfg:
    #  - sso_auth_url
    #  - sso_refresh_token
    #  - sso_client_id
    #  - sso_validate_certs
    # Writes the following KeycloakToken attribute:
    #  - token
    #
    keycloaktoken = KeycloakToken()
    keycloaktoken.token = None
    keycloaktoken.get()

# Generated at 2022-06-24 19:28:34.514747
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    galaxy_token.save()
    assert os.path.isfile(galaxy_token.b_file)
    assert os.access(galaxy_token.b_file, os.R_OK)
    assert os.access(galaxy_token.b_file, os.W_OK)


# Generated at 2022-06-24 19:28:46.944711
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():

    # Initialize test values
    access_token = 'access_token_example'
    auth_url = 'https://auth.example.com'
    validate_certs = True
    client_id = 'client_id_example'
    # Setup mock
    mock_get = mocker.patch('ansible.module_utils.legacy_galaxy.KeycloakToken.get')
    mock_get.return_value = 'access_token_example'
    mock_token_type = mocker.patch('ansible.module_utils.legacy_galaxy.KeycloakToken.token_type')
    mock_token_type.return_value = 'Bearer'

    # Invoke method
    result = KeycloakToken(access_token, auth_url, validate_certs, client_id).headers()

    # Check results


# Generated at 2022-06-24 19:28:52.048868
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='my_offline_token', auth_url='https://endpoint/auth/realms/{realm}/protocol/openid-connect/token')
    token.get()

if __name__ == '__main__':
    test_case_0()
    test_KeycloakToken_get()

# Generated at 2022-06-24 19:28:55.348113
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    """
    Unit test of KeycloakToken.get()
    """
    token = KeycloakToken("test", auth_url="test")
    assert token.get() == None


# Generated at 2022-06-24 19:28:57.634971
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # kc_token.get()
    token = KeycloakToken('sooo long and complicated')
    token.get()
    assert token.access_token == 'sooo long and complicated'


# Generated at 2022-06-24 19:29:04.612912
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:29:12.657867
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_1 = KeycloakToken("test_string_0")
    response = keycloak_token_1.get()
    assert response == None


# Generated at 2022-06-24 19:29:14.794904
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()
    token = keycloak_token_0.get()
    print(token)


# Generated at 2022-06-24 19:29:18.884226
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken(auth_url='https://domain/auth/realms/realm/protocol/openid-connect/token')
    assert not keycloak_token_0.get()



# Generated at 2022-06-24 19:29:29.838039
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # initialise a galaxy token file
    test_token_file = to_bytes(os.path.join(C.GALAXY_TOKEN_PATH, 'test_token.yml'), errors='surrogate_or_strict')
    if not os.path.isfile(test_token_file):
        open(test_token_file, 'w').close()
        os.chmod(test_token_file, S_IRUSR | S_IWUSR)  # owner has +rw

    test_token = GalaxyToken(token='abcdefghijklmnopqrstuvwxyz')
    test_token.save()
    with open(test_token_file, 'r') as f:
        test_file_content = yaml_load(f)

    assert test_token.config == test_file

# Generated at 2022-06-24 19:29:34.251828
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():

    # Lets assume we have an offline token called 'my-token'
    keycloak_token_0 = KeycloakToken('my-token')

    # method headers of class KeycloakToken should return a dictionary
    assert type(keycloak_token_0.headers()) is dict


# Generated at 2022-06-24 19:29:41.719086
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken()
    tmp_config = {'_meta': {'version': 0.8}, 'token': 'a-token'}
    galaxy_token.config = tmp_config
    # Pre-conditions
    assert os.path.isfile(galaxy_token.b_file)
    assert os.path.getsize(galaxy_token.b_file) == 0
    assert galaxy_token.get() == 'a-token'
    # Tested function
    galaxy_token.save()
    # Post-conditions
    assert os.path.isfile(galaxy_token.b_file)
    assert os.path.getsize(galaxy_token.b_file) != 0
    # Clean up
    os.remove(galaxy_token.b_file)



# Generated at 2022-06-24 19:29:43.466156
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()
    # TODO: to be implemented
    print('to be implemented')


# Generated at 2022-06-24 19:29:47.428314
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """Unit test for method save of class GalaxyToken."""

    galaxy_token = GalaxyToken()
    galaxy_token.config = dict(token="SomeRandomToken")

    try:
        galaxy_token.save()
    except IOError as e:
        print("Failed to write galaxy_token.yaml. Error: %s" % e)
        exit(-1)



# Generated at 2022-06-24 19:29:50.526882
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    galaxy_token = GalaxyToken('dummy_token')
    galaxy_token.save()
    assert os.path.isfile(C.GALAXY_TOKEN_PATH)

# Generated at 2022-06-24 19:29:55.283443
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kct = KeycloakToken('mytoken')
    kct.get()
    assert kct.headers()['Authorization'].startswith('Bearer')



# Generated at 2022-06-24 19:30:03.684532
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken(access_token='access_token_0')

    # test exception raise of parameter 'self' of headers
    with pytest.raises(TypeError):
        keycloak_token_0.headers(self=keycloak_token_0)


# Generated at 2022-06-24 19:30:05.805274
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken('test')
    assert keycloak_token.get() == 'test'


# Generated at 2022-06-24 19:30:07.917310
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken()
    headers = keycloak_token_0.headers()
    assert type(headers) == dict

# Generated at 2022-06-24 19:30:17.739337
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_1 = KeycloakToken(access_token='refresh_token_1', auth_url='http://foo')
    keycloak_token_1._token = 'token_1'
    assert keycloak_token_1.headers() == {'Authorization': 'Bearer token_1'}
    keycloak_token_2 = KeycloakToken(access_token=None, auth_url='http://foo')
    keycloak_token_2._token = 'token_2'
    assert keycloak_token_2.headers() == {'Authorization': 'Bearer token_2'}
    keycloak_token_3 = KeycloakToken(access_token='refresh_token_3', auth_url=None)
    keycloak_token_3._token = 'token_3'

# Generated at 2022-06-24 19:30:25.578788
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-24 19:30:29.141129
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken()
    assert expected_0 == keycloak_token_0.headers()

# Generated at 2022-06-24 19:30:33.417329
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    #Test a normal call to the method
    keycloak_token_1 = KeycloakToken(access_token='my-token')
    get_return = keycloak_token_1.get()
    assert get_return == 'my-token'



# Generated at 2022-06-24 19:30:43.105100
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token = KeycloakToken(
        access_token='bogus', auth_url='https://www.google.com/', client_id='cloud-services')
    ret = keycloak_token.get()
    assert (ret is None)

    keycloak_token = KeycloakToken(
        access_token='bogus', auth_url='https://www.google.com/', client_id='cloud-services')
    ret = keycloak_token.get()
    assert(ret is None)

    keycloak_token = KeycloakToken(
        access_token='bogus', auth_url='https://www.google.com/', client_id='cloud-services')
    ret = keycloak_token.get()
    assert(ret is None)


# Generated at 2022-06-24 19:30:48.218222
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken()
    assert isinstance(keycloak_token_0.headers(), dict)


# Generated at 2022-06-24 19:30:51.078073
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken()
    v = keycloak_token_0.headers()
    #assert v == {}



# Generated at 2022-06-24 19:30:56.356995
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = GalaxyToken()
    token.set('foo')
    assert token.get() == 'foo'

# Generated at 2022-06-24 19:31:00.231941
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken()
    expected = { 'Authorization': 'Bearer None' }
    result = keycloak_token_0.headers()
    assert (expected == result)


# Generated at 2022-06-24 19:31:08.739831
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()
    keycloak_token_0.access_token = 'c7ed2b2f-f0b3-403b-98f9-54f9c04d80a1'
    keycloak_token_0.auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'
    keycloak_token_0.client_id = 'cloud-services'
    keycloak_token_0.validate_certs = True

    assert keycloak_token_0.get() is not None


# Generated at 2022-06-24 19:31:11.479321
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    keycloak_token_0 = KeycloakToken()

    assert keycloak_token_0.get() is None


# Generated at 2022-06-24 19:31:17.546154
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    config = {'token': 'test_GalaxyToken_save'}
    galaxy_token = GalaxyToken()
    galaxy_token._config = config
    galaxy_token.save()
    assert os.path.isfile(galaxy_token.b_file), "GalaxyToken.save() assertion failed: token file not found"
    os.remove(galaxy_token.b_file)
    assert not os.path.isfile(galaxy_token.b_file), "GalaxyToken.save() assertion failed: token file still exists"



# Generated at 2022-06-24 19:31:22.147533
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token = KeycloakToken(access_token='the-access-token', auth_url='the-auth-url',
                                   validate_certs=True, client_id='the-client-id')
    assert keycloak_token.headers() == {'Authorization': 'Bearer the-access-token'}


# Generated at 2022-06-24 19:31:24.203705
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    test_instance = GalaxyToken('test_token')
    test_instance.config = {'token': 'test_token'}
    test_instance.save()

# Generated at 2022-06-24 19:31:27.020275
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    try:
        token_impl_0 = KeycloakToken()
        assert token_impl_0.headers() == {'Authorization': 'Bearer None'}
    except Exception:
        assert False


# Generated at 2022-06-24 19:31:32.816093
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken(access_token=None, auth_url=None, validate_certs=None, client_id=None)
    token_expected = 'Bearer None'
    token_returned = token_expected or keycloak_token_0.token_type
    if token_expected is not token_returned:
        print('Eval:')
        print('  Expected: %s' % token_expected)
        print('  Returned: %s' % token_returned)



# Generated at 2022-06-24 19:31:38.371238
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    headers_0 = {'Authorization': 'Bearer 123'}
    keycloak_token_0 = KeycloakToken(access_token='123')

    assert headers_0 == keycloak_token_0.headers()


# Generated at 2022-06-24 19:31:44.737189
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    token = 'thisisatoken'
    auth_url = 'http://authurl.com'
    kc_token = KeycloakToken(token, auth_url)
    headers = kc_token.headers()
    assert headers.get('Authorization', None) == 'Bearer %s' % token

# Generated at 2022-06-24 19:31:47.042899
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()
    assert keycloak_token_0.get() == None


# Generated at 2022-06-24 19:31:51.108333
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    #Tests with the hostname and port of the Keycloak server
    assert test_case_0()._form_payload() == 'grant_type=refresh_token&client_id=cloud-services&refresh_token=None'



# Generated at 2022-06-24 19:31:51.900236
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    pass

# Generated at 2022-06-24 19:31:54.254672
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken()
    assert keycloak_token_0.get() is None


# Generated at 2022-06-24 19:31:59.891183
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # TODO
    '''
    b_file = ''
    token = ''
    config = ''
    # Test with empty token
    expected_result = ''
    actual_result = GalaxyToken._save(b_file, config, token)
    assert actual_result == expected_result
    '''
    pass


# Generated at 2022-06-24 19:32:05.342091
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = 'new_token'
    galaxytoken = GalaxyToken(token)
    galaxytoken.save()
    galaxytoken2 = GalaxyToken()
    if not token == galaxytoken2.get():
        raise AssertionError('token is not same as the new token set')


# Generated at 2022-06-24 19:32:13.183566
# Unit test for method get of class KeycloakToken

# Generated at 2022-06-24 19:32:23.358792
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # Test that save method works if the token file is missing
    test_token_file = '/tmp/test_galaxy_token'
    # Test that save method works if the token file is missing
    if os.path.isfile(test_token_file):
        os.unlink(test_token_file)
    gt = GalaxyToken(None)
    gt.b_file = test_token_file
    gt.config['token'] = 'TestToken'
    gt.save()
    assert os.path.isfile(test_token_file)
    # Test that save method works if the token file is empty
    if os.path.isfile(test_token_file):
        os.unlink(test_token_file)
    gt = GalaxyToken(None)
    gt.b_file = test_

# Generated at 2022-06-24 19:32:28.262259
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # inputs
    keycloak_token_1 = KeycloakToken('auth_url', 'auth_url', 'auth_url')
    # execution
    if keycloak_token_1.get() is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-24 19:33:13.958113
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_path = u'/tmp/test_token_path'
    token_data = {'token': '123', 'a': 'b'}
    with open(token_path, 'w') as f:
        yaml_dump(token_data, f, default_flow_style=False)
    os.chmod(token_path, S_IRUSR | S_IWUSR)  # owner has +rw
    token_obj = GalaxyToken()
    token_obj.b_file = token_path
    token_obj.config = token_data
    token_obj.save()



# Generated at 2022-06-24 19:33:26.945265
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    class Foo(object):
        def __init__(self, body):
            self.body = body

        def read(self):
            return self.body

    access_token = '123'
    auth_url = 'https://www.example.com'
    validate_certs = True
    client_id = 'ansible'

    # arr = [Foo(b'{"access_token": "456"}')]
    arr = [Foo('{"access_token": "456"}')]
    open_url = lambda x, method='POST', data='', *args, **kwargs: arr.pop(0)
    original_open_url = KeycloakToken.open_url
    KeycloakToken.open_url = open_url

# Generated at 2022-06-24 19:33:37.992097
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    # Test 1
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-internal/protocol/openid-connect/token'
    access_token = 'YjFkYzc0YjctYWZlNy00MjhiLWE4ZjEtZWQ2NTNlNjA5ODY5'

    keycloak_token_0 = KeycloakToken(access_token=access_token, auth_url=auth_url)

    # Test 2
    auth_url = 'https://sso.redhat.com/auth/realms/redhat-internal/protocol/openid-connect/token'

# Generated at 2022-06-24 19:33:46.679184
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-24 19:33:57.446466
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    
    # Create a new instance of the class
    t = GalaxyToken()

    # Set the token to run the save test
    t.set('TestToken')

    # Save the token
    t.save()

    # Make sure we are looking at the right file
    file_name = C.GALAXY_TOKEN_PATH
    assert file_name == os.path.expanduser('~/.ansible/galaxy_token')

    # Test for the token's presence in the file
    f = open(file_name, 'r')
    file_contents = f.read()
    f.close()
    
    # If the token is in the file, delete the file
    if 'TestToken' in file_contents:
        os.remove(file_name)
    
    # Verify that the token is in the file


# Generated at 2022-06-24 19:34:00.898536
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    no_token_sentinel_1 = NoTokenSentinel()
    galaxy_token_0 = GalaxyToken(token=no_token_sentinel_1)
    galaxy_token_0.save()
    galaxy_token_1 = GalaxyToken()
    galaxy_token_1.save()


# Generated at 2022-06-24 19:34:02.111202
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kt = KeycloakToken()
    kt.get()
    kt.headers()


# Generated at 2022-06-24 19:34:08.897038
# Unit test for method headers of class KeycloakToken

# Generated at 2022-06-24 19:34:16.963965
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create an instance of KeycloakToken
    token = KeycloakToken()

    # Create a mock object
    token.auth_url = 'https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token'

# Generated at 2022-06-24 19:34:19.661018
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kc_token = KeycloakToken(access_token='abc-xyz')
    rc = kc_token.get()

    assert len(rc) == 0

# Generated at 2022-06-24 19:34:24.788336
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken('token5')
    config = token.config
    config['token'] = 'token5'
    token.save()


# Generated at 2022-06-24 19:34:26.214946
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    headers_0 = KeycloakToken('').headers()


# Generated at 2022-06-24 19:34:35.009412
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    KCT = KeycloakToken(access_token='o_single_quotes_are_used_here',
                        auth_url='https://sso.redhat.com',
                        validate_certs=True,
                        client_id='myclient')

# Generated at 2022-06-24 19:34:38.228204
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='test_access_token',
                          auth_url='https://sso-qa.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
                          validate_certs=True,
                          client_id='cloud-services')
    token.get()


# Generated at 2022-06-24 19:34:39.301392
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token="mock_token")
    kt.get()


# Generated at 2022-06-24 19:34:46.782706
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    import os
    import tempfile
    import yaml
    # Create a temp directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file in the directory
    token_path = temp_dir + '/token.yml'
    fd = open(token_path, 'w')
    fd.close()

    # Create object of class GalaxyToken
    galaxy_token = GalaxyToken(token_path)
    galaxy_token.set('2')

# Generated at 2022-06-24 19:34:53.289535
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    some_token_0 = GalaxyToken('thpHfcW8DwroBgJjFxTrHp7LmX9vGxeLmQnfq3HZ')
    some_token_1 = GalaxyToken(some_token_0)
    some_token_2 = GalaxyToken(some_token_1)
    some_token_3 = GalaxyToken(some_token_2)
    some_token_4 = GalaxyToken(some_token_3)
    some_token_5 = GalaxyToken(some_token_4)
    some_token_6 = GalaxyToken(some_token_5)
    some_token_7 = GalaxyToken(some_token_6)
    some_token_8 = GalaxyToken(some_token_7)
    some_token_9 = GalaxyToken(some_token_8)

# Generated at 2022-06-24 19:34:57.878163
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    expected_result = {'Authorization': 'Bearer test'}
    t = KeycloakToken(access_token='test')
    assert t.headers() == expected_result


# Generated at 2022-06-24 19:35:01.735558
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    KeycloakToken_get = KeycloakToken(access_token='access_token_value', auth_url='auth_url_value',
                                      validate_certs=True, client_id='client_id_value')
    # TODO: Add verification here
    #       See https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/urls.py#L97


# Generated at 2022-06-24 19:35:03.919800
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_0 = GalaxyToken(None)
    token_0._config = {'token': 'token'}
    token_0._token = 'token'
    token_0.save()

# Generated at 2022-06-24 19:35:13.209835
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = "dummy_token"
    b_file = "/tmp/test.galaxy_token"
    token_obj = GalaxyToken(token)
    token_obj.b_file = b_file

    token_obj.set(token)
    token_obj.save()

    result = token_obj.get()
    # Compare result of save with input
    if token == result:
        print("PASSED")
    else:
        print("FAILED")


# Generated at 2022-06-24 19:35:16.575077
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    galaxy_token = GalaxyToken()
    assert galaxy_token.headers() == {}

    username = 'test'
    password = 'test'
    basic_auth = BasicAuthToken(username, password)
    assert basic_auth.headers() == \
           {'Authorization': u'Basic dGVzdDp0ZXN0'}


# Generated at 2022-06-24 19:35:27.238574
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    ''' Unit test for method save of class GalaxyToken. '''
    token_file = '/tmp/galaxy.token'
    token = 'abc'
    token_obj = GalaxyToken()
    token_obj.b_file = to_bytes(token_file, errors='surrogate_or_strict')
    token_obj.set(token)

    # Assert the token file exists
    assert os.path.isfile(to_text(token_obj.b_file))

    # Read in the token file
    with open(token_obj.b_file, 'r') as f:
        config = yaml_load(f)
    assert config['token'] == token

    # Delete the token file
    os.remove(to_text(token_obj.b_file))

    # Assert the token file was deleted
   

# Generated at 2022-06-24 19:35:32.679748
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloak_token_0 = KeycloakToken(access_token='access_token_0', auth_url='auth_url_0', client_id='client_id_0')
    keycloak_token_0._token = None
    keycloak_token_0.get()


# Generated at 2022-06-24 19:35:42.291185
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"

# Generated at 2022-06-24 19:35:48.851845
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():

    keycloak_token_0 = KeycloakToken(access_token='access_token_value')

    # Test when keycloak_token_0._token is None
    keycloak_token_0._token = None
    assert keycloak_token_0.get() == 'access_token_value', 'Test when keycloak_token_0._token is None'

    # Test when keycloak_token_0._token is not None
    keycloak_token_0._token = 'keycloak_token_0._token_value'
    assert keycloak_token_0.get() == 'keycloak_token_0._token_value', 'Test when keycloak_token_0._token is not None'


# Generated at 2022-06-24 19:35:52.546602
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_obj = KeycloakToken(access_token='test_value_1', auth_url='test_value_2', validate_certs=True, client_id='test_value_4')


# Generated at 2022-06-24 19:35:54.919217
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create a token object
    token_0 = KeycloakToken()
    token_0.auth_url = None
    token_0.validate_certs = None
    token_0.client_id = None
    # Retrieve token value
    token_0.get()


# Generated at 2022-06-24 19:35:56.108425
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='123')
    assert token.get() == '123'


# Generated at 2022-06-24 19:35:58.394487
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken(access_token='this_is_token')
    assert token.get() == 'this_is_token'


# Generated at 2022-06-24 19:36:10.750031
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token_file = 'token.yml'
    obj = GalaxyToken()
    file = open(token_file, 'w')
    obj.save(file)
    file.close()
    file = open(token_file, 'r')
    contents = file.read()
    if contents == '':
        return 1
    else:
        return 0


# Generated at 2022-06-24 19:36:20.371275
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Test with the default values for args
    KeycloakToken('this_is_a_refresh_token', auth_url="https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token").get()
    # Test with #1 default args
    KeycloakToken('this_is_a_refresh_token', "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token").get()
    # Test with #2 default args
    KeycloakToken('this_is_a_refresh_token').get()
    # Test with #0 default args
    KeycloakToken(NoTokenSentinel()).get()



# Generated at 2022-06-24 19:36:24.346759
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    url = 'http://192.168.220.145:8080/auth/realms/master/protocol/openid-connect/token'
    token = KeycloakToken(access_token='e5b7d912-8b1e-4c5d-af39-d8afd98f3694', auth_url=url, client_id='ansible')
    assert token.get() != None


# Generated at 2022-06-24 19:36:27.895481
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = ''
    auth_url = ''
    validate_certs = True
    client_id = ''
    test_object = KeycloakToken(access_token, auth_url, validate_certs, client_id)

    # Act
    result = test_object.get()

    # Assert
    assert result == None


# Generated at 2022-06-24 19:36:30.336746
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    keycloaktoken_obj = KeycloakToken("example")
    assert keycloaktoken_obj.get() == None


# Generated at 2022-06-24 19:36:32.667270
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    token = GalaxyToken('test')
    token.set('test')
    token.save()

# Generated at 2022-06-24 19:36:37.145530
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    try:
        galaxy_token = GalaxyToken(token='1234')
        galaxy_token.save()
    except IOError as ioe:
        print("I/O error({0}): {1}".format(ioe.errno, ioe.strerror))


# Generated at 2022-06-24 19:36:42.066792
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # Create instance of KeycloakToken object
    access_token = ""
    auth_url = "https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token"
    validate_certs = True
    client_id = "cloud-services"
    k = KeycloakToken(access_token, auth_url, validate_certs, client_id)
    # Method get called with no parameters
    k.get()


# Generated at 2022-06-24 19:36:50.795433
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    """ test save method of GalaxyToken class.
        in this method an empty yaml file is created and
        if the save method is called, it will dump the
        content of an empty list into the file.
        if the file is not empty, it will dump a test string
        into the file.

    :return: None
    """
    b_file = to_bytes('test_file.yml', errors='surrogate_or_strict')
    token = 'test_token'
    with open(b_file, 'w') as f:
        yaml_dump(['token: %s' % token], f, default_flow_style=False)  # if the file is not empty, dump a test string
    t = GalaxyToken(token)
    t.save()

# Generated at 2022-06-24 19:36:52.824870
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    access_token = 'access_token_test'
    token = KeycloakToken(access_token)

    token.get()



# Generated at 2022-06-24 19:37:19.245427
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    test_case_0()
    token = KeycloakToken(access_token='test_token', auth_url='test_auth_url')
    token.get()
    assert token.headers() == {'Authorization': 'Bearer undefined'}


# Generated at 2022-06-24 19:37:29.080755
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    # - build a request to POST to auth_url
    #  - body is form encoded
    #    - 'request_token' is the offline token stored in ansible.cfg
    #    - 'grant_type' is 'refresh_token'
    #    - 'client_id' is 'cloud-services'
    #       - should probably be based on the contents of the
    #         offline_ticket's JWT payload 'aud' (audience)
    #         or 'azp' (Authorized party - the party to which the ID Token was issued)

    # - extract 'access_token'

# Generated at 2022-06-24 19:37:31.363545
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kt = KeycloakToken(access_token='TEST_REFRESH_TOKEN', auth_url='http://auth.com/auth')
    assert kt.get() == 'TEST_ACCESS_TOKEN'


# Generated at 2022-06-24 19:37:37.582416
# Unit test for method save of class GalaxyToken
def test_GalaxyToken_save():
    # test save method for class GalaxyToken
    b_file = to_bytes(C.GALAXY_TOKEN_PATH, errors='surrogate_or_strict')
    if os.path.isfile(b_file):
        os.unlink(b_file)
    galaxy_token = GalaxyToken()
    galaxy_token.save()
    assert os.path.isfile(b_file)
    if os.path.isfile(b_file):
        os.unlink(b_file)



# Generated at 2022-06-24 19:37:40.724564
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    kc_token_obj = KeycloakToken(access_token='a1', auth_url='http://localhost:8090/auth/realms/master/protocol/openid-connect/token', validate_certs=True, client_id='cloud-services')
    assert kc_token_obj.headers() == {'Authorization': 'Bearer b30K'}


# Generated at 2022-06-24 19:37:42.745181
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    token = KeycloakToken('my_token', 'my_auth_url')
    token.get()


# Generated at 2022-06-24 19:37:50.003065
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    # KeycloakToken.get()
    no_token_sentinel_1 = NoTokenSentinel()
    keycloak_token_0 = KeycloakToken(no_token_sentinel_1)
    try:
        keycloak_token_0.get()
    except AttributeError as e:
        # Ensure that we fail cleanly on bad auth
        assert 'A proper refresh token must be provided' in to_text(e)


# Generated at 2022-06-24 19:37:52.856526
# Unit test for method get of class KeycloakToken
def test_KeycloakToken_get():
    kct = KeycloakToken()
    assert kct.get() is None

    kct = KeycloakToken('e8cf06bb-3c3b-4dbe-9f71-ab5dbc92ac83')
    assert isinstance(kct.get(), str)
    assert kct.get().startswith('eyJhbGciOiJ')


# Generated at 2022-06-24 19:38:03.498137
# Unit test for method headers of class KeycloakToken
def test_KeycloakToken_headers():
    keycloak_token_0 = KeycloakToken(
        access_token='Xz63o_F6U4y6UH0nQ2-Jg62jfS7xEaWZ',
        auth_url='https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token',
        validate_certs=True,
        client_id=None
    )

    result = keycloak_token_0.headers()
