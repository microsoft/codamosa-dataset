

# Generated at 2022-06-11 06:07:41.275492
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual import SunOSVirtualCollector
    os = SunOSVirtualCollector()
    if os._platform != 'SunOS':
        print("test_SunOSVirtualCollector() failed")

# Generated at 2022-06-11 06:07:42.679396
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:07:52.811285
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    obj = SunOSVirtual()
    obj.module.run_command = MagicMock(return_value=(0, '', ''))
    obj.module.get_bin_path = MagicMock(return_value=True)

    #
    # Test to detect if a global zone is not itself virtualised.
    #
    obj.module.run_command = MagicMock(return_value=(0, '/lib/svc/method/svc-vboxguest', ''))
    obj.module.get_bin_path = MagicMock(return_value=True)
    facts = obj.get_virtual_facts()
    assert (facts['virtualization_type'] == 'virtualbox')
    assert (facts['virtualization_role'] == 'guest')

# Generated at 2022-06-11 06:07:58.833850
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a unit test for constructor of class SunOSVirtualCollector.
    It checks that SunOSVirtualCollector instantiates the subclass SunOSVirtual.
    """
    virtual = SunOSVirtualCollector(load_on_init=False)
    if not isinstance(virtual, SunOSVirtual):
        raise AssertionError("SunOSVirtualCollector does not instantiate the subclass SunOSVirtual.")

# Generated at 2022-06-11 06:08:00.273815
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(dict())
    assert s.platform == 'SunOS'

# Generated at 2022-06-11 06:08:08.051632
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()


# Generated at 2022-06-11 06:08:09.069838
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual(dict())

# Generated at 2022-06-11 06:08:11.161857
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:08:12.766339
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._platform == 'SunOS'
    assert v._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:21.110992
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import pytest

    mock_module = pytest.Mock()

    mock_module.get_bin_path.return_value = "MOCK"

    mock_module.run_command.return_value = (0, 'global', '')

    virtual_obj = SunOSVirtual(mock_module)
    assert virtual_obj.get_virtual_facts() == {}

    mock_module.run_command.return_value = (0, 'testzone', '')
    assert virtual_obj.get_virtual_facts() == {'container': 'zone', 'virtualization_tech_host': {'zone'}}

    mock_module.run_command.return_value = (1, '', '')
    assert virtual_obj.get_virtual_facts()

# Generated at 2022-06-11 06:08:46.667936
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    facts = SunOSVirtual(module)
    assert facts.platform == 'SunOS'
    assert facts.get_virtual_facts() == {}


# Generated at 2022-06-11 06:08:48.130135
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.fact_class is SunOSVirtual



# Generated at 2022-06-11 06:08:59.725049
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Use pseudo-class to avoid importing sunos_virtual module
    class TestSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            pass

        def get_bin_path(self, name):
            if name == 'zonename':
                return 'zonename'
            return None

        def get_file_content(self, path):
            return None

        def run_command(self, command):
            if command == 'zonename':
                rc = 0
            else:
                rc = 1
            return (rc, '', '')

    virtual_machine = TestSunOSVirtual(None)

    # Zones
    assert virtual_machine.get_virtual_facts()['virtualization_tech_guest'] == set(['zone'])

# Generated at 2022-06-11 06:09:01.450111
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'



# Generated at 2022-06-11 06:09:03.117172
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'
    assert v.virtual == dict()

# Generated at 2022-06-11 06:09:06.570666
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict(), dict()).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts

# Generated at 2022-06-11 06:09:07.873486
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-11 06:09:10.856519
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    unittest_facts = SunOSVirtual({})
    results = unittest_facts.get_virtual_facts()
    assert results['virtualization_role'] == 'guest'


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 06:09:12.301400
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyModule()
    virtual = SunOSVirtual(module)
    assert len(virtual.get_virtual_facts()) > 0

# Generated at 2022-06-11 06:09:14.971633
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.module.__class__.__name__ == 'AnsibleModule'

# Generated at 2022-06-11 06:10:03.915143
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    d = SunOSVirtualCollector(None)
    assert d._fact_class._platform == 'SunOS'

# Generated at 2022-06-11 06:10:05.301011
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == "SunOS"

# Generated at 2022-06-11 06:10:13.120302
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # The virtual class needs to be initialized outside of the function for the tests to work correctly
    SunOSVirtual.init()
    delattr(SunOSVirtual, '_initialized')

    collector = VirtualCollector()
    # We need to reset the known_types otherwise collectors register themselves
    # We do not want that for these tests.
    for property in collector.__dict__:
        if '_VirtualCollector__known_types' == property:
            delattr(collector, property)
            # Clear the registered types
            collector._VirtualCollector__collectors.clear()
            # Then re-add SunOS since we want to keep the rest
            collector._VirtualCollector__collectors['SunOS']

# Generated at 2022-06-11 06:10:14.221211
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector().platform == 'SunOS'

# Generated at 2022-06-11 06:10:15.831142
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts


# Generated at 2022-06-11 06:10:18.130039
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos._fact_class is SunOSVirtual
    assert sunos._platform == 'SunOS'

# Generated at 2022-06-11 06:10:21.019736
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None, None)
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None

# Generated at 2022-06-11 06:10:28.226542
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.community.general.tests.unit.compat.mock import mock_open
    from ansible_collections.community.general.tests.unit.modules.utils import set_module_args
    from ansible_collections.community.general.plugins.module_utils.facts.virtual.sunos.sunos import SunOSVirtual

    m = mock_open(read_data="")
    m.return_value.readlines.return_value = [
    ]

    with mock.patch('ansible_collections.community.general.plugins.module_utils.facts.virtual.sunos.sunos.open', m, create=True):
        SunOSVirtual.platform = 'SunOS'
        v = SunOSVirtual(ansible_module=None)
        # Zones not supported.
        assert v.get_virtual

# Generated at 2022-06-11 06:10:30.129649
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:32.554376
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:11:24.895074
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._platform == 'SunOS'
    assert v._fact_class.platform == 'SunOS'
    assert v._fact_class.get_virtual_facts() == {}

# Generated at 2022-06-11 06:11:35.334273
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = ['/usr/sbin/zonename', '/usr/sbin/virtinfo', '/usr/sbin/smbios']

# Generated at 2022-06-11 06:11:37.229697
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sc = SunOSVirtualCollector()
    assert sc.platform == 'SunOS'
    assert sc._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:11:46.492235
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import os
    import sys
    # Give the path to our custom modules (for test only, not in real environnement)
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../'))
    # Give the path to the required module
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../../../lib/python'))
    from ansible.module_utils.facts.utils import get_file_lines

    # Fake input data
    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params
            self

# Generated at 2022-06-11 06:11:57.959496
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    ''' sunos_virtual_test.py: test_SunOSVirtual '''

    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, 'global', ''))
            self.get_bin_path = Mock(return_value='/usr/sbin/zoneinfo')

    class MockSunOSVirtual(SunOSVirtual):
        ''' A subclass of SunOSVirtual that allows mocking the SunOSVirtual constructor '''
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 06:12:00.174529
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:12:08.609870
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fixture_data = dict(SunOSVirtual.fixture_data())
    fixture_data['get_bin_path'] = lambda x: x
    fixture_data['run_command'] = lambda x: (0, '', '')
    result = dict(SunOSVirtual(fixture_data, None).get_virtual_facts())
    assert result['virtualization_type'] == 'zone'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['zone'])
    assert result['virtualization_tech_host'] == set(['zone'])
    assert result['container'] == 'zone'

# Generated at 2022-06-11 06:12:15.153345
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    host_tech = set(['zone'])
    guest_tech = set(['zone'])
    virtual_facts = {
        'virtualization_tech_guest': guest_tech,
        'virtualization_tech_host': host_tech,
        'virtualization_type': 'zone',
        'virtualization_role': 'host',
        'container': 'zone'
    }
    os_virt = SunOSVirtual(None)
    os_virt.populate()
    os_virt.facts['ansible_virtualization_facts'] = virtual_facts
    assert os_virt.facts == virtual_facts

# Generated at 2022-06-11 06:12:17.157068
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(module=None)
    assert v.platform == 'SunOS'
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-11 06:12:27.507561
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual as _SunOSVirtual
    sunos_virtual = _SunOSVirtual(dict())

    # Test 1: global zone
    # install mock function run_command
    def run_command(self, cmd, check_rc=True, close_fds=True):
        if cmd == 'zonename':
            return (0, "global", '')
        else:
            return (0, "", '')

    # install mock function get_bin_path
    def get_bin_path(self, executable):
        if executable == 'zonename':
            return '/usr/sbin/zonename'
        else:
            return None
    sunos_virtual.module.run_command = run_command
    sunos_virtual.module.get_bin_path = get_

# Generated at 2022-06-11 06:14:25.267023
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:14:27.751863
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.facts == {}
    assert v.platform == 'SunOS'
    assert v.module is None
    assert v.module_name is None
    assert v.module_args == {}
    assert v.paths == {}
    assert v.api is None

# Generated at 2022-06-11 06:14:35.473334
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    sunos = SunOSVirtual(module=module)
    virtual_facts = sunos.get_virtual_facts()

    expected_virtual_facts = {'virtualization_tech_guest': {'zone', 'vmware'},
                              'virtualization_tech_host': {'zone'},
                              'virtualization_type': 'vmware',
                              'virtualization_role': 'guest',
                              'container': 'zone'}

    assert virtual_facts == expected_virtual_facts


# Fake AnsibleModule

# Generated at 2022-06-11 06:14:43.904678
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pytest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    # Create a MockedModule to mock base_class properties
    mocked_module = patch.multiple(
        'ansible.module_utils.facts.virtual.base.AnsibleModule',
        get_bin_path=lambda x,y: '/usr/bin/' + y
    )

    # Include the module so its functions can be used here
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.sunos import SunOSVirtual

    class MockedSunOSVirtual(SunOSVirtual):
        def __new__(cls, module):
            obj = super(SunOSVirtual, cls).__new__(cls, module)
            obj.module = module
            return obj

# Generated at 2022-06-11 06:14:46.616274
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Create a SunOSVirtualCollector object.
    '''
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == "SunOS"

# Generated at 2022-06-11 06:14:48.361390
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({'module': None})
    assert virtual
    assert virtual.run() == {}


# Generated at 2022-06-11 06:14:59.323231
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class TestModule:
        def __init__(self, module_name, bin_path=None):
            if bin_path is None:
                bin_path = {}
            self.module_name = module_name
            self.bin_path = bin_path
            self.params = {}

        def fail_json(self, msg=None, **kwargs):
            self.msg = msg

        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            return self.bin_path.get(cmd, None)

        def run_command(self, cmd):
            return self.run_command_out[cmd]


# Generated at 2022-06-11 06:15:03.196211
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    result = dict(
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
        container=None,
        virtualization_role=None,
        virtualization_type=None
    )
    collector = SunOSVirtualCollector(dict(), dict(module=dict()))
    assert collector.get_virtual_facts() == result

# Generated at 2022-06-11 06:15:04.907125
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector
    assert vc._fact_class == SunOSVirtual
    assert vc._platform == 'SunOS'


# Generated at 2022-06-11 06:15:06.667388
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._fact_class == 'SunOSVirtual'
    assert obj._platform == 'SunOS'