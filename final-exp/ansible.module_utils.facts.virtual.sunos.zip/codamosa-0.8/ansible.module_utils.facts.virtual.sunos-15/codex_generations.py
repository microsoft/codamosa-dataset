

# Generated at 2022-06-11 06:07:42.774703
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt = SunOSVirtualCollector()
    assert virt.platform == 'SunOS'
    assert virt.__class__.__name__ == 'SunOSVirtualCollector'
    assert virt._fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-11 06:07:44.209434
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    i = SunOSVirtual(None)
    assert i.get_virtual_facts() == {}

# Generated at 2022-06-11 06:07:45.949385
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:07:55.221964
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fake_module = FakeAnsibleModule()
    fake_module.params = {}
    fake_module.run_command = FakeAnsibleRunCommand()
    # define a fake zonename command output
    # zonename has returned 0 and the name of the zone is testzone
    fake_module.run_command.set_fake_response(0,
                                              'testzone\n',
                                              '')

    # define a fake modinfo command output
    # modinfo has return 0 and one line of output
    fake_module.run_command.set_fake_response(0,
                                              'modinfo has return 0 and one line of output\n',
                                              '')
    virtual = SunOSVirtual(fake_module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type']

# Generated at 2022-06-11 06:07:58.285746
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    # Ensure that the constructor of SunOSVirtualCollector sets the _fact_class to SunOSVirtual
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:00.624806
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    kwargs = dict(module=dict())
    virtual = SunOSVirtual(**kwargs)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:08:03.372844
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(
        argument_spec=dict()
    )
    is_sunos = SunOSVirtual(module)
    assert is_sunos.platform == 'SunOS'

# Generated at 2022-06-11 06:08:07.726483
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = SunOSVirtualCollector()
    assert os_facts._platform == 'SunOS'
    assert os_facts.platform == 'SunOS'
    assert os_facts._fact_class == SunOSVirtual
    assert os_facts.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:17.111815
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.get('virtual_facts')['virtualization_type'] == None
    assert 'zone' in virtual_facts.get('virtual_facts')['virtualization_tech_guest']
    assert 'vmware' in virtual_facts.get('virtual_facts')['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts.get('virtual_facts')['virtualization_tech_guest']
    assert 'virtuozzo' in virtual_facts.get('virtual_facts')['virtualization_tech_guest']
    assert 'ldom' in virtual_facts.get('virtual_facts')['virtualization_tech_guest']
    assert 'container' in virtual_facts.get('virtual_facts')['container']

# Generated at 2022-06-11 06:08:18.291506
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert facts.platform == 'SunOS'

# Generated at 2022-06-11 06:08:40.062617
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = type(str("AnsibleModuleMock"), (), {'run_command': AnsibleModuleMock.run_command})
    module.run_command = AnsibleModuleMock.run_command
    module.get_bin_path = AnsibleModuleMock.get_bin_path

    # Mock run_command:
    #   - virtinfo:
    #       - success
    #       - not implemented

# Generated at 2022-06-11 06:08:45.966490
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(side_effect=get_command_output)
    sunos_virtual_facts = SunOSVirtual(module=module).get_virtual_facts()
    assert sunos_virtual_facts['container'] == 'zone'
    assert sunos_virtual_facts['virtualization_type'] == 'vmware'
    assert sunos_virtual_facts['virtualization_role'] == 'guest'
    assert 'vmware' in sunos_virtual_facts['virtualization_tech']
    assert 'zone' in sunos_virtual_facts['virtualization_tech']



# Generated at 2022-06-11 06:08:53.142270
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    module.run_command = run_command
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert dict(
        virtualization_tech_host=set(),
        virtualization_tech_guest=set([u'zone', u'vmware']),
        virtualization_role=u'guest',
        virtualization_type=u'vmware',
        container=u'zone'
    ) == virtual_facts


# Generated at 2022-06-11 06:08:54.155373
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    testclass = SunOSVirtual()

    assert testclass.platform == 'SunOS'

# Generated at 2022-06-11 06:09:04.984973
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a test instance of the SunOSVirtual class
    # and test the get_virtual_facts method
    virtual = SunOSVirtual()
    virtual.module = MockAnsibleModule(
        # The following results are expected when executing
        # the hostname command
        command_results=[
            (0, 'test-hostname\n'),
            # The following results are expected when executing
            # the virtinfo command
            (0, ''),
            # The following results are expected when executing
            # the smbios command
            (0, ''),
            # The following results are expected when executing
            # the zonename command
            (0, 'global\n')
        ]
    )
    virtual_facts = virtual.get_virtual_facts()
    assert "virtualization_type" not in virtual_facts

# Generated at 2022-06-11 06:09:13.533431
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual.
    It creates a SunOSVirtual object and calls get_virtual_facts with different inputs.
    """
    module = FakeModule()
    obj = SunOSVirtual(module)

    # Testing for zone
    module.run_command_json = {
        0: {'rc': 0, 'stdout': 'global', 'stderr': ''}
    }
    obj.get_virtual_facts()
    assert obj.facts['virtualization_tech_host'] == set(['zone'])
    assert obj.facts['virtualization_tech_guest'] == set()
    assert obj.facts['virtualization_type'] == ''
    assert obj.facts['virtualization_role'] == ''
    assert obj.facts['container'] == ''

    # Testing for branded zone


# Generated at 2022-06-11 06:09:24.070468
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    os.environ['PATH'] = '/bin:/sbin'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'container' in facts
    assert facts['virtualization_type'] == 'none'
    assert facts['virtualization_role'] == 'guest'
    assert 'container' not in facts

# Generated at 2022-06-11 06:09:26.131485
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert isinstance(virtual_collector.virtual, SunOSVirtual)


# Generated at 2022-06-11 06:09:28.015360
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Creates an instance of SunOSVirtualCollector
    collector = SunOSVirtualCollector()


# Generated at 2022-06-11 06:09:30.009229
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert (obj._fact_class is SunOSVirtual)
    assert (obj._platform is 'SunOS')

# Generated at 2022-06-11 06:09:57.317048
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.facts['virtualization_role'] == 'guest'
    assert collector.facts['virtualization_type'] == 'vmware'
    assert collector.facts['virtualization_tech_guest'] == 'vmware'
    assert collector.facts['virtualization_tech_host'] == 'zone'

# Generated at 2022-06-11 06:09:58.418192
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:10:00.948487
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}).get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 06:10:08.280278
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    host_facts = dict()
    module = FakeModule()
    SunOSVirtualCollector().populate(module=module, host_facts=host_facts)
    assert host_facts['virtualization_type'] == 'kvm'
    assert host_facts['virtualization_role'] == 'guest'
    assert host_facts['virtualization_tech_host'] == set(['zone'])
    assert host_facts['virtualization_tech_guest'] == set(['kvm'])
    assert host_facts['container'] == 'zone'



# Generated at 2022-06-11 06:10:18.330089
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This is a SunOS-specific subclass of Virtual.
    """
    module = AnsibleModule(
        argument_spec={},
    )

    # Create an instance of the SunOSVirtual fact class.
    fact_class = Virtual('SunOS', module)

    # Create a fact dictionary using the SunOSVirtual get_virtual_facts method.
    fact = {}
    fact_facts = {'facts': fact}
    fact_class.populate()
    fact_facts = fact_class.get_facts(collect_subset=['!all'])

    # Ensure required facts were collected.
    keys_to_check = [
        'virtualization_tech_host',
        'virtualization_tech_guest',
        'virtualization_role',
        'virtualization_type',
    ]


# Generated at 2022-06-11 06:10:26.628168
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_tests = [
        { 'input': 'global', 'expected': {
            'virtualization_type': None,
            'virtualization_role': None,
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            'container': None
        } },
    ]

    # unit tests:
    module = VirtualCollector.get_platform_module('SunOS')
    for test in virtual_tests:
        sunos = module(None)
        sunos.module.run_command = lambda *args, **kwargs: (0, test['input'], None)
        sunos.get_virtual_facts = lambda: None
        result = sunos.populate()
        assert result == test['expected']

# Generated at 2022-06-11 06:10:28.317480
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:10:31.138302
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual({})
    assert sunosvirtual.platform == 'SunOS'
    assert sunosvirtual.get_virtual_facts() == {}


# Generated at 2022-06-11 06:10:40.093123
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of class SunOSVirtual
    sunos_virtual = SunOSVirtual({})

    # Mock a function call
    def mock_run_command(module):
        # simulate function call
        return 0, "", ""

    def mock_get_bin_path(module, path):
        # simulate function call
        return path

    sunos_virtual.module.run_command = mock_run_command
    sunos_virtual.module.get_bin_path = mock_get_bin_path

    # Expect an empty dictionary
    result = sunos_virtual.get_virtual_facts()
    assert type(result) is dict
    assert len(result) == 0

# Generated at 2022-06-11 06:10:44.701349
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor test for class SunOSVirtual.

    Note: This test stub does not test the functionality that comes from
    the base class. It just checks if the class is instantiated correctly.

    :return:
    """
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-11 06:11:41.536463
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    m = SunOSVirtual({})

    # Method get_virtual_facts should return a dict with correct keys and values
    # Method get_bin_path should return a string if the executable exists
    def run_command(cmd, *_):
        """Mock run_command"""

# Generated at 2022-06-11 06:11:44.699289
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert isinstance(vc, VirtualCollector)
    assert isinstance(vc._fact_class, SunOSVirtual)
    assert vc._platform == 'SunOS'


# Generated at 2022-06-11 06:11:55.223819
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virt = SunOSVirtual(module)
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    module.rc = 1
    virtual_facts = virt.get_virtual_facts()
    assert not 'virtualization_tech_guest' in virtual_facts
    assert not 'virtualization_tech_host' in virtual_facts
    assert not 'container' in virtual_facts
    assert not 'virtualization_type' in virtual_facts


# Generated at 2022-06-11 06:11:58.724146
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert isinstance(facts._fact_class, SunOSVirtual)
    assert isinstance(facts._platform, str)
    assert facts._platform == 'SunOS'

# Generated at 2022-06-11 06:12:02.714062
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v1 = SunOSVirtual({})
    assert isinstance(v1, Virtual)
    assert isinstance(v1, SunOSVirtual)
    assert v1.platform == 'SunOS'

# Unit tests for methods
# test_get_virtual_facts()

# Generated at 2022-06-11 06:12:11.328905
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "global\n", '')
    module.get_bin_path.return_value = True
    module.path_exists.return_value = True
    virtual_facts = SunOSVirtual(module).populate()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert 'container' not in virtual_facts


# Generated at 2022-06-11 06:12:13.218954
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.collector.virtual import SunOSVirtual
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:12:14.801504
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 06:12:16.702555
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mod = VirtualCollector({}, {})
    v = SunOSVirtual(mod)
    assert v.platform == 'SunOS'


# Generated at 2022-06-11 06:12:27.048105
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = lambda x: (1, '', '')
    module.get_bin_path = lambda x: '/bin/' + x
    module.file_exists = lambda x: False

    virtual = SunOSVirtual(module=module)
    assert virtual.get_virtual_facts() == {}

    module.command_warnings = {"/usr/bin/zonename": "this command is not known"}
    assert virtual.get_virtual_facts() == {}

    module.command_warnings = {"/usr/bin/zonename": ""}
    module.run_command = lambda x: (0, 'global', '')
    assert virtual.get_virtual_facts() == {'virtualization_tech_host': set(['zone'])}


# Generated at 2022-06-11 06:14:19.824682
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = None
    virt = SunOSVirtual(module)
    ret = virt.get_virtual_facts()
    assert 'virtualization_type' in ret
    assert 'virtualization_role' in ret
    assert 'virtualization_tech_guest' in ret
    assert 'virtualization_tech_host' in ret

# Generated at 2022-06-11 06:14:20.714323
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:14:27.623180
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Set up and run the test
    module = FakeModule()
    facts = SunOSVirtual(module).get_virtual_facts()

    # Verify the returned values
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'zone'}
    assert facts['virtualization_tech_host'] == {'zone'}
    assert facts['container'] == 'zone'


# Unit test supporting class

# Generated at 2022-06-11 06:14:34.556914
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Build test module
    # Build test module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Build test class
    testobj = SunOSVirtual(module)

    # Build test facts
    facts = dict()
    testobj.populate()
    facts.update(testobj.get_facts())

    # Return the tests results
    module.exit_json(changed=False, ansible_facts=facts)


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:14:36.079945
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:14:37.503362
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'


# Generated at 2022-06-11 06:14:41.126652
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Unit tests for the SunOSVirtual constructor.
    """

    for device in ['smbios', 'procfs', 'zonename', 'brands']:
        facter = SunOSVirtual({device: None})
        assert facter.platform == 'SunOS'



# Generated at 2022-06-11 06:14:44.546832
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_object = SunOSVirtual()
    assert isinstance(test_object, SunOSVirtual)
    assert test_object.platform == 'SunOS'
    assert isinstance(test_object._virtual_facts, dict)
    assert test_object._virtual_facts == dict(platform='SunOS')

# Generated at 2022-06-11 06:14:46.078585
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert isinstance(obj, SunOSVirtualCollector)

# Generated at 2022-06-11 06:14:48.708226
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    info = SunOSVirtual(dict(module=None))
    assert info.platform == 'SunOS'
    assert 'virtualization_type' in info.get_virtual_facts()