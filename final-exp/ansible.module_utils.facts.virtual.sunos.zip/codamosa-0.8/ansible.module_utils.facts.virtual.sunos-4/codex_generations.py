

# Generated at 2022-06-11 06:07:39.737725
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector().collect()
    assert isinstance(virtual_facts, dict)


# Generated at 2022-06-11 06:07:42.290509
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v is not None
    assert v._fact_class._platform == 'SunOS'
    assert v._platform == 'SunOS'

# Generated at 2022-06-11 06:07:44.454348
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:07:45.419557
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:07:46.837414
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:07:55.732952
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Arrange
    from ansible.module_utils.facts.virtual.sunos import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual, SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import test_SunOSVirtual_get_virtual_facts as test_get_virtual_facts
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rc = {}
            self.run_command_out = {}
            self.run_command_err = {}
            self.run_command_rc_set = False

        def get_bin_path(self, path):
            return '/bin/' + path

# Generated at 2022-06-11 06:07:58.336567
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual()

    # This test should pass if the constructor of class SunOSVirtual is run
    assert sunos_virtual


# Generated at 2022-06-11 06:08:02.811598
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtualCollector.fetch_virtual_facts()()
    assert virt.platform == 'SunOS'
    assert 'virtualization_type' in virt.facts


if __name__ == '__main__':
    # Unit test for module SunOSVirtual
    test_SunOSVirtual()

# Generated at 2022-06-11 06:08:07.136906
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Construct object
    x = SunOSVirtual({})
    assert x.platform == 'SunOS'
    assert x.virtualization_type is None
    assert x.virtualization_role is None
    assert x.container is None



# Generated at 2022-06-11 06:08:10.417358
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (), {'get_bin_path': lambda self, x: '', 'run_command': lambda self, x: (0, '', '')})
    sunos_virtual = SunOSVirtual(module)

    assert sunos_virtual != None

# Generated at 2022-06-11 06:08:24.604468
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:08:35.221927
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual({})
    # Test with a global zone
    rc, out, err = virtual.module.run_command = lambda x: (0, 'global\n', '')
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_tech_host'] == {'zone'}
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'zone' not in facts
    # Test with a branded zone
    rc, out, err = virtual.module.run_command = lambda x: (1, 'global\n', '')
    virtual.module.file_exists = lambda x: True
    facts = virtual.get_virtual_facts()

# Generated at 2022-06-11 06:08:36.543561
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-11 06:08:37.923678
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert 'SunOS' == facts.platform

# Generated at 2022-06-11 06:08:40.019684
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-11 06:08:40.983879
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:08:44.673626
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.collect()['virtualization_type'] == 'virtualbox'
    assert v.collect()['virtualization_role'] == 'guest'
    assert v.collect()['virtualization_tech_guest'] == set(['virtualbox'])
    assert v.collect()['virtualization_tech_host'] == set([])
    assert v.collect()['container'] == 'zone'

# Generated at 2022-06-11 06:08:50.953749
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Virtual - get_virtual_facts() for SunOS."""
    os = SunOSVirtual({})
    facts = os.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set()

 

# Generated at 2022-06-11 06:08:53.612847
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == "SunOS"
    assert x._fact_class == SunOSVirtual
    assert isinstance(x._facts, SunOSVirtual)

# Generated at 2022-06-11 06:08:56.306456
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 06:09:19.949077
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 06:09:20.963194
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual().get_virtual_facts()

# Generated at 2022-06-11 06:09:25.223966
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.__name__ == 'SunOSVirtual'
test_SunOSVirtualCollector.unittest = ['.test_SunOSVirtualCollector']

# Generated at 2022-06-11 06:09:29.652582
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sys_name = 'SunOS'
    x = SunOSVirtual(dict(module=dict(get_bin_path=lambda x: '/usr/bin/{0}'.format(x),
                                      run_command=lambda x: (0, "stdout", "stderr"))))

    assert x.platform == sys_name
    assert x.get_virtual_facts()

# Generated at 2022-06-11 06:09:33.210684
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import Collector

    # create object for testing
    test_obj = SunOSVirtualCollector(Collector)
    assert test_obj
    assert isinstance(test_obj, SunOSVirtualCollector)



# Generated at 2022-06-11 06:09:36.701362
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert(v._platform == 'SunOS')
    assert(v._fact_class is SunOSVirtual)


# Generated at 2022-06-11 06:09:44.780983
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    virtual = SunOSVirtual(module=None)
    facts = FactCollector(module=None).collect()
    facts_virtual = virtual.get_virtual_facts()
    facts = dict(list(facts.items()) + list(facts_virtual.items()))
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'zone' in facts['virtualization_tech_host']

# Generated at 2022-06-11 06:09:48.497275
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = {}
    os_facts['kernel'] = 'SunOS'
    sunos_virtual_collector = SunOSVirtualCollector(None, os_facts, None)
    assert sunos_virtual_collector.platform == 'SunOS'


# Generated at 2022-06-11 06:09:50.606760
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 06:09:54.714411
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts



# Generated at 2022-06-11 06:10:40.233172
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())

    assert virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:10:41.836182
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-11 06:10:50.611451
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Unit test of the method get_virtual_facts of class SunOSVirtual
    '''

    def get_bin_path(name):
        '''
        stub routine replacing the method get_bin_path of module_utils.facts.virtual.base
        '''
        if name == 'zonename':
            return "/usr/sbin/zonename"
        return None

    def run_command(command):
        '''
        stub routine replacing the method run_command of module_utils.facts.virtual.base
        '''
        if command == "/usr/sbin/zonename":
            return 0, 'global', ''
        return -1, '', ''

    os.path.isdir = lambda path: True
    os.path.exists = lambda path: True
    module_utils.facts.virtual.base.get_

# Generated at 2022-06-11 06:10:52.388532
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MagicMock()
    module.get_bin_path.return_value = None
    obj = SunOSVirtual(module)
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:10:57.670375
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    tests_dir = os.path.dirname(os.path.realpath(__file__))
    mocks_dir = os.path.join(tests_dir, 'mocks', 'SunOSVirtual')
    event = SunOSVirtual(module, mocks_dir)

    assert event._platform == "SunOS"
    assert event._fact_class == SunOSVirtual
    assert event.mocks_dir == mocks_dir


# Generated at 2022-06-11 06:11:05.920739
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, stdout="global\n")
    fact_class = SunOSVirtual(module)
    fact_class.get_virtual_facts()
    assert 'virtualization_tech_host' in fact_class.facts
    assert 'virtualization_tech_guest' in fact_class.facts
    assert 'virtualization_type' in fact_class.facts
    assert 'virtualization_role' in fact_class.facts
    assert 'container' in fact_class.facts
    assert fact_class.facts['virtualization_role'] == 'host'



# Generated at 2022-06-11 06:11:14.503351
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # This test code is written to test method get_virtual_facts of SunOSVirtual class.
    # Virtualization facts of the host will be put into a dictionary
    # and tested against the expected values.

    if os.path.exists('/sbin/zlogin'):
        class Module(object):
            def __init__(self, params):
                self.params = params
            def get_bin_path(self, executable):
                if executable == 'zonename':
                    return '/usr/bin/zonename'
                elif executable == 'modinfo':
                    return '/usr/sbin/modinfo'
                else:
                    return None
            def run_command(self, executable):
                if executable == '/usr/bin/zonename':
                    return 0, "non-global", ""

# Generated at 2022-06-11 06:11:23.135488
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = type('testModule', (object,), dict(run_command=lambda x: ('0', '', '')))
    test_module.get_bin_path = lambda x: '/usr/sbin/' + x

    test_zone = type('testZone', (object,), dict(module=test_module))

    # Test None case
    test_virtual = SunOSVirtual(test_zone)
    assert test_virtual.get_virtual_facts() == {}

    # Test zone case
    test_virtual.module.run_command = lambda x: ('0', 'non-global', '')
    assert test_virtual.get_virtual_facts() == {'container': 'zone'}

    # Test vmware case

# Generated at 2022-06-11 06:11:25.156316
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_obj = SunOSVirtual(dict())
    assert virtual_facts_obj.facts

# Generated at 2022-06-11 06:11:34.150344
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    c = SunOSVirtual({}, {})
    # Test for virtualization_type and virtualization_role
    result = c.get_virtual_facts()
    assert result['virtualization_type'] == 'hypervisor'
    assert result['virtualization_role'] == 'host'

    c.module.run_command = command_test
    # Test for container
    result = c.get_virtual_facts()
    assert result['container'] == 'zone'

    # Test for virtualization_type and virtualization_role
    result = c.get_virtual_facts()
    assert result['virtualization_type'] == 'zone'
    assert result['virtualization_role'] == 'guest'



# Generated at 2022-06-11 06:13:23.013836
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual(dict())

# Generated at 2022-06-11 06:13:30.752681
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pytest

    mocked_module = pytest.Mock()
    mocked_module.run_command.return_value = (
        0,  # Return code
        'LDoms support '
        + '\n'
        + '  Hardware Domains: '
        + '\n'
        + '     Control: 1 '
        + '\n'
        + '     I/O: 0 '
        + '\n'
        + '     Service: 1 '
        + '\n'
        + '     Root: 0 '
        + '\n'
        + '     Guest: 0 '
        + '\n'
        + '  Guest Domains: '
        + '\n'
        + '     Total: 0 ',  # Command output
        None)  # Command
    mocked_module.get_bin_

# Generated at 2022-06-11 06:13:33.654684
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with arguments SunOSVirtualCollector(module)
    fact_class = SunOSVirtualCollector()
    assert SunOSVirtual in fact_class._fact_class_map.values()
    assert fact_class._platform == 'SunOS'

# Generated at 2022-06-11 06:13:34.553861
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:13:43.829894
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('module', (object,), {})()
    class SunOSVirtual(object):
        def __init__(self, *args): pass
    module.get_bin_path = lambda x: ''
    module.run_command = lambda x: (0, '', '')

    virtual = SunOSVirtual(module)

    rc, out, err = module.run_command = lambda x: (1, '', '')
    assert virtual.get_virtual_facts() == {}

    rc, out, err = module.run_command = lambda x: (0, 'global', '')
    assert virtual.get_virtual_facts() == {'virtualization_tech_host': {'zone'}}
    rc, out, err = module.run_command = lambda x: (0, 'zones', '')
    assert virtual.get_

# Generated at 2022-06-11 06:13:54.242604
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/foo')
    module.exists = MagicMock(return_value=True)

    # test return facts for a zone container
    module.run_command = MagicMock(return_value=(0, 'foo\n', ''))
    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['container'] == 'zone'
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 06:14:01.034045
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-11 06:14:03.290588
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    s = SunOSVirtualCollector
    assert s._platform == 'SunOS'
    assert isinstance(s._fact_class(), Virtual)

# Generated at 2022-06-11 06:14:04.725541
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual(dict())
    obj.get_virtual_facts()

# Generated at 2022-06-11 06:14:14.755360
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    obj = SunOSVirtual(module)

    obj.module = module
    obj.module.run_command.return_value = (0, 'global', '')
    virtual_facts = obj.get_virtual_facts()
    assert obj.module.run_command.call_count == 3
    assert virtual_facts == {
        'container': 'zone',
        'virtualization_role': 'host',
        'virtualization_type': 'zone',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'zone'}
    }

    # Test that the function works when zonename is not available
    obj.module = module
    obj.module.get_bin_path.return_value = None
    virtual_facts = obj.get_virtual_facts()
   