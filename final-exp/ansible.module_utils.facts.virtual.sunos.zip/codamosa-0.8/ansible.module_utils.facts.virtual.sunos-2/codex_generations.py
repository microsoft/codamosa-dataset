

# Generated at 2022-06-11 06:07:40.852723
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:07:44.258314
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_SunOSVirtualCollector = SunOSVirtualCollector()
    assert test_SunOSVirtualCollector.platform == 'SunOS'
    assert test_SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:07:46.379030
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor test SunOSVirtualCollector
    """
    coll = SunOSVirtualCollector(None)
    assert coll.platform == 'SunOS'

# Generated at 2022-06-11 06:07:51.675495
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
    )
    set_module_args({})
    virtual_fact = SunOSVirtual(test_module)
    assert isinstance(virtual_fact.get_virtual_facts(), dict)


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-11 06:07:55.584978
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(
        argument_spec={
        }
    )
    s = SunOSVirtual(module)
    assert s._platform == 'SunOS'
    assert s.get_virtual_facts() == {}


# Generated at 2022-06-11 06:07:56.948777
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector('module')
    assert v._platform == 'SunOS'

# Generated at 2022-06-11 06:08:06.423951
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = AnsibleModuleMock({})
    test_SunOSVirtual = SunOSVirtual(module=test_module)
    # the output of virtinfo -p when running on a control domain contains the line "DOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=false", for a guest domain "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false"
    # the output of "smbios" on a branded zone contains the line "Vendor: VMware, Inc.", on a regular zone the output is empty
    test_SunOSVirtual.module.run_command =  MagicMock()

# Generated at 2022-06-11 06:08:11.248491
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Unit test for constructor of class SunOSVirtualCollector
    """
    # Test 1: input is None
    input_object = None
    sunos_virtual_collector = SunOSVirtualCollector(input_object)
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-11 06:08:17.422561
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class TestModule(object):
        def __init__(self, params):
            for key, value in params.items():
                setattr(self, key, value)

        def get_bin_path(self, path):
            class MockObject(object):
                def __init__(self, path):
                    self.path = path

                def __str__(self):
                    return self.path

            if path == 'modinfo':
                return MockObject("/usr/sbin/modinfo")
            elif path == 'zone':
                return MockObject("/bin/zonename")

    # Test simple case
    test_module = TestModule({'run_command': lambda x: (0, '', '')})
    SunOSVirtualCollector(test_module).collect()

    # Test missing modinfo
    test_module = TestModule

# Generated at 2022-06-11 06:08:27.223264
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    import os
    import shutil
    import tempfile

    module_args = dict()

    # Fixture
    tempdir = tempfile.mkdtemp()
    virtual = SunOSVirtual(module_args, tempdir)
    os.mkdir(os.path.join(tempdir, 'proc', 'vz'))
    facts = dict()

    # Test
    facts = virtual.get_virtual_facts()

    # Assert
    assert facts['virtualization_type'] == 'virtuozzo'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['virtuozzo'])
    assert 'virtualization_tech_host' not in facts

    # Cleanup
    shutil.rmtree(tempdir)


# Generated at 2022-06-11 06:08:42.458749
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # set up
    module = None
    args = {}

    # execute
    obj = SunOSVirtual(module, args)
    # assert
    assert SunOSVirtual.platform == "SunOS"

# Generated at 2022-06-11 06:08:49.600135
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class mock_module:
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, cmd, required=False):
            if cmd == 'zonename':
                return '/usr/bin/zonename'

    module = mock_module()
    fact_collector = SunOSVirtualCollector(module)
    assert fact_collector is not None
    assert isinstance(fact_collector, SunOSVirtualCollector)
    assert fact_collector._fact_class is not None
    assert isinstance(fact_collector._fact_class, SunOSVirtual)

# Generated at 2022-06-11 06:09:00.931729
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test data
    # ----------
    # Solaris 10 LDoms
    output_solaris10_ldom_guest = '''
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
    '''
    # Solaris 10 LDoms
    output_solaris10_ldom_host = '''
DOMAINROLE|impl=LDoms|control=true|io=true|service=true|root=true
    '''
    # Solaris 11 LDoms
    output_solaris11_ldom_guest = '''
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
    '''
    # Solaris 11 LDoms

# Generated at 2022-06-11 06:09:03.877765
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    a = SunOSVirtualCollector()
    assert isinstance(a, VirtualCollector)
    assert a._platform == 'SunOS'
    assert a._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:09:09.108986
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = dict()
    facts['kernel'] = 'SunOS'
    SunOSVirtual(facts, None)
    assert facts['virtualization_type'] == 'virtuozzo'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'virtuozzo', 'zone'}


# Generated at 2022-06-11 06:09:14.590484
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    uname_str = 'SunOS python-test 5.11 11.3 sun4v sparc sun4u'
    module = type('AnsibleModule', (object,), dict(
        params=dict(),
        get_bin_path=lambda name: '/usr/sbin/%s' % name,
        run_command=lambda cmd: (0, 'abc', '')
    ))()
    v = SunOSVirtual(module)
    v.get_platform_facts = lambda: dict(uname=uname_str)
    v.uname = uname_str
    return v.get_virtual_facts()

# Generated at 2022-06-11 06:09:18.378089
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == SunOSVirtual().platform
    assert c._fact_class == SunOSVirtual
    assert c._platform == 'SunOS'

# Generated at 2022-06-11 06:09:25.417017
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModule()
    fact_instance = SunOSVirtualCollector(module)
    assert fact_instance.fact_class == SunOSVirtual


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    module = AnsibleModule()
    fact_instance = SunOSVirtualCollector(module)
    fact_instance.collect()
    print('fact_instance.facts: {0}'.format(fact_instance.facts))
    module.exit_json(ansible_facts=fact_instance.facts)

# Generated at 2022-06-11 06:09:34.920305
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    open_mock = MagicMock()
    open_mock.return_value = 'VMware'
    with patch.object(os.path, 'exists', MagicMock(return_value=True)):
        with patch.object(SunOSVirtual, '_get_dmi_system_product_name', MagicMock(return_value='VMware')):
            with patch.object(SunOSVirtual, '_get_dmi_system_vendor', MagicMock(return_value='VMware')):
                with patch.object(SunOSVirtual, '_get_dmi_system_manufacturer', MagicMock(return_value='VMware')):
                    with patch.object(os, 'open', open_mock):
                        virtual_facts = SunOSVirtual(module).get_

# Generated at 2022-06-11 06:09:37.214076
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 06:10:03.475432
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)


# Generated at 2022-06-11 06:10:09.683058
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    # sunos_virtual = SunOSVirtual(module)
    #virtual_facts = sunos_virtual.get_virtual_facts()
    #assert_equals(virtual_facts['virtualization_type'], 'kvm')
    #assert_equals(virtual_facts['virtualization_role'], 'guest')
    #assert_equals(virtual_facts['virtualization_tech_guest'], 'kvm')
    print("Not implemented")

# Generated at 2022-06-11 06:10:20.207114
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.sunos as virtual_sunos
    import ansible.module_utils.facts.virtual.base as virtual_base
    import ansible.module_utils.facts.virtual.collector as virtual_collector

    # Setup mocks
    class MockModule(object):
        def __init__(self):
            self.fail_json = lambda *args, **kwargs: None

        def get_bin_path(self, name):
            return None

        def run_command(self, *args):
            import sys

            if len(args) == 2 and args[0] == ('/usr/sbin/virtinfo -p'):
                return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''


# Generated at 2022-06-11 06:10:24.940733
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    cls = SunOSVirtualCollector()
    if not isinstance(cls._fact_class(), SunOSVirtual):
        raise Exception("Constructor of SunOSVirtualCollector class does not use provided _fact_class (SunOSVirtual)")
    if cls._platform != 'SunOS':
        raise Exception("Constructor of SunOSVirtualCollector class does not use provided _platform (SunOS)")

# Generated at 2022-06-11 06:10:29.134783
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, 'global', ''))
    test_module.get_bin_path = MagicMock(return_value="/usr/bin/zonename")
    SunOSVirtual(module=test_module).get_virtual_facts()

# Generated at 2022-06-11 06:10:30.482361
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    myvirt = SunOSVirtual(None)
    assert myvirt.platform == 'SunOS'

# Generated at 2022-06-11 06:10:34.656463
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('', (), {'get_bin_path': lambda self, _: 'bin_path'})()
    module.run_command = lambda _: (0, '', '')
    SunOSVirtual.get_virtual_facts(module)

# Generated at 2022-06-11 06:10:37.186222
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    obj = SunOSVirtual(module)
    # obj is an instance of SunOSVirtual
    assert isinstance(obj, SunOSVirtual)

# Generated at 2022-06-11 06:10:46.820185
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()

    # Test in global zone
    module.run_command = Mock(return_value=(0, "global\n", ""))
    collector = SunOSVirtualCollector(module=module)
    facts = collector.get_virtual_facts(module)
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'container' not in facts

    # Test in non-global zone
    module.run_command = Mock(return_value=(0, "testzone\n", ""))
    collector = SunOSVirtualCollector(module=module)
    facts = collector.get_virtual_facts(module)
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert facts['container'] == 'zone'

    #

# Generated at 2022-06-11 06:10:53.380815
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    data = {
        'PATH': '/usr/sbin:/usr/bin:/opt/bin',
        'ANSIBLE_MODULE_ARGS': {},
        'ANSIBLE_MODULE_JSON': '{"_ansible_module_name":"setup", "_ansible_version":"2.6.0"}'
    }

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-11 06:11:34.793480
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Mocked global variables and set-up of mocks for SunOSVirtual.get_virtual_facts()
    '''

    # Import modules
    try:
        import ansible.module_utils.facts.virtual.sunos_virtual
        import ansible.module_utils.facts.virtual.sunos_virtual
        from ansible.module_utils.facts.virtual.sunos_virtual import SunOSVirtual
        from ansible.module_utils.facts.virtual.sunos_virtual import SunOSVirtual
        from ansible.module_utils.facts.virtual.sunos_virtual import SunOSVirtual
    except ImportError:
        # Since version 2.5, ansible is not working without pycrypto anymore
        # We have to ignore this during unit testing
        pass

    # Set up mocks for module and class.

    x = ansible

# Generated at 2022-06-11 06:11:36.788578
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = object()
    vc = SunOSVirtualCollector(module)
    assert vc.platform == 'SunOS'



# Generated at 2022-06-11 06:11:41.791502
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-11 06:11:43.549813
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.virtual._platform == 'SunOS'


# Generated at 2022-06-11 06:11:53.520863
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Test for method get_virtual_facts of class SunOSVirtual"""

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual


    class TestModule():
        def get_bin_path(self, bin_path):
            return bin_path
        def run_command(self, command):
            return 0, command, ''

    module = TestModule()
    collector = SunOSVirtualCollector
    virtual_facts_obj = SunOSVirtual(module)

    virtual_facts = virtual_facts_obj.get_virtual_facts()

    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual

# Generated at 2022-06-11 06:11:54.596422
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector is not None

# Generated at 2022-06-11 06:11:57.713812
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:12:05.032697
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a dummy module
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )
    # Queries for which the module does not rely on external commands
    class DummyModule:
        def get_bin_path(self, *args, **kwargs):
            return None
        def run_command(self):
            return 1,'',''

    virtual = SunOSVirtual(DummyModule())
    ret = virtual.get_virtual_facts()
    assert ret == {}

# Generated at 2022-06-11 06:12:09.990449
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Create a SunOSVirtual instance and check the attributes.
    """
    from .. import SunOSVirtual
    n = SunOSVirtual()
    assert n.__module__ == 'ansible.module_utils.facts.virtual.sunos'
    assert n.__class__.__name__ == 'SunOSVirtual'
    assert n.platform == 'SunOS'

# Generated at 2022-06-11 06:12:17.461011
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual.run_command = lambda self: (0, '', '')
    SunOSVirtual.get_bin_path = lambda self, binary: binary
    obj = SunOSVirtual({})
    with open(os.path.join(os.path.dirname(__file__), 'files/smbios.out')) as f:
        SunOSVirtual.run_command = lambda self: (0, f.read(), '')
        facts = obj.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'kvm'}
    assert facts['virtualization_tech_host'] == set()
    assert 'container' not in facts

# Unit tests for class SunOSVirtual

# Generated at 2022-06-11 06:13:33.814069
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.virtualization_tech_host == set()
    assert v.virtualization_tech_guest == set()
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''
    assert v.container == ''

# Generated at 2022-06-11 06:13:35.733841
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts.platform == 'SunOS'
    assert facts._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:13:36.589980
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:13:46.191556
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import ModuleFacts

    # Create a stub module
    class StubModule:
        def __init__(self):
          self.params = {}

        def fail_json(self, *args, **kwargs):
            self.fail = True

        def run_command(self, *args, **kwargs):
          if args == ("modinfo",):
              return 0, "", ""
          elif args == ("zonename",):
              return 0, "global", ""
          elif args == ("virtinfo",):
              return 0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", ""
          elif args == ("smbios",):
              return

# Generated at 2022-06-11 06:13:53.314224
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    sunosvirtual = SunOSVirtual(module)
    facts = sunosvirtual.get_virtual_facts()
    assert facts == {
        'virtualization_tech_guest': set(['zone', 'vmware', 'virtualbox']),
        'virtualization_tech_host': set(['zone']),
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'container': 'zone'
    }


# Generated at 2022-06-11 06:13:55.572553
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.virtualization_type is None
    assert virtual_facts.virtualization_role is None
    assert virtual_facts.container is None

# Generated at 2022-06-11 06:13:58.406502
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._platform == 'SunOS'
    assert x.fact_class == SunOSVirtual


# Generated at 2022-06-11 06:14:00.917579
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create an instance of class SunOSVirtual
    sunos = SunOSVirtual({}, None)
    assert sunos.platform == 'SunOS'
    assert sunos.module is None

# Generated at 2022-06-11 06:14:03.166435
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual = SunOSVirtual(module)
    assert virtual.get_virtual_facts() is None

# Generated at 2022-06-11 06:14:05.797565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:16:30.651569
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual.module = DummyAnsibleModule()

    # Return correct values for a physical machine
    SunOSVirtual.module.run_command = fake_run_command_physical
    result = SunOSVirtual.get_virtual_facts()
    assert result == {}

    # Return correct values for a logical domaining (LDoms) guest machine
    SunOSVirtual.module.run_command = fake_run_command_ldom
    result = SunOSVirtual.get_virtual_facts()
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'ldom'
    assert 'virtualization_role' in result
    assert result['virtualization_role'] == 'guest'

    # Return correct values for a logical domaining (LDoms) host machine
    SunOSVirtual.module.run_command = fake_run_command_

# Generated at 2022-06-11 06:16:31.550732
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    SunOSVirtual(module)


# Generated at 2022-06-11 06:16:32.351229
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:16:33.414513
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Safely test the SunOSVirtual constructor
    """
    SunOSVirtual()

# Generated at 2022-06-11 06:16:37.222320
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    SunOSVirtual.get_virtual_facts(module)
    assert 'virtualization_type' in module.FACTS
    assert 'virtualization_role' in module.FACTS
    assert 'virtualization_tech_guest' in module.FACTS
    assert 'virtualization_tech_host' in module.FACTS


# Generated at 2022-06-11 06:16:39.677384
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    a = SunOSVirtual({'ansible_facts': {}})
    assert a
    assert a._platform == 'SunOS'
    assert a._fact_class is SunOSVirtual


# Generated at 2022-06-11 06:16:40.551918
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()


# Generated at 2022-06-11 06:16:47.761822
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    facts = SunOSVirtual(module)
    assert facts.virtualization_type == 'zone'
    assert facts.virtualization_role == 'guest'
    assert facts.virtualization_tech_guest == set(['zone'])
    assert facts.virtualization_tech_host == set([])
    assert facts.container == 'zone'

    module = FakeAnsibleModule(params={'gather_subset': '!all'})
    facts = SunOSVirtual(module)
    assert facts.virtualization_type == 'zone'
    assert facts.virtualization_role == 'guest'
    assert facts.virtualization_tech_guest == set(['zone'])
    assert facts.virtualization_tech_host == set([])
    assert facts.container == 'zone'


# Generated at 2022-06-11 06:16:48.971514
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts.platform == 'SunOS'

# Generated at 2022-06-11 06:16:57.096811
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible_collections.misc.not_a_real_collection.tests.unit.modules.utils import set_module_args

    module = ansible_module_mock
    set_module_args({})
