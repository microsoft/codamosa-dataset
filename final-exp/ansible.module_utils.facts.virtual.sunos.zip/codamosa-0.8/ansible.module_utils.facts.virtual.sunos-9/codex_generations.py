

# Generated at 2022-06-11 06:07:48.404310
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        ),
        supports_check_mode=True)

    module.run_command = mock.Mock(return_value=(0, '', ''))
    sunos = SunOSVirtual(module=module)

    # If it's a zone, we can determine its role/type
    sunos.module.run_command.return_value = (0, 'global', '')
    expected = dict(virtualization_tech_guest=set(['zone']),
                    virtualization_tech_host=set(),
                    virtualization_type=None,
                    virtualization_role=None,
                    container=None)
    assert expected == sunos.get_virtual_facts()


# Generated at 2022-06-11 06:07:52.925626
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule(dict())
    facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'container' in facts



# Generated at 2022-06-11 06:08:04.071088
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual()

    # 1st test: uname reports SunOS, /proc/vz exists and /proc is mounted
    v.module = MockModule({'sys_info': {'uname_sysname': 'SunOS', 'mounts': [{'mount': '/proc', 'fs_type': 'procfs'}]},
                           'file_exists': ['/proc/vz']})
    assert v.get_virtual_facts() == {'virtualization_type': 'virtuozzo', 'virtualization_role': 'guest',
                                     'virtualization_tech_guest': set(['virtuozzo']),
                                     'virtualization_tech_host': set([]), 'container': None}

    # 2nd test: uname reports SunOS and we are a zone

# Generated at 2022-06-11 06:08:14.259978
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt = SunOSVirtual({})
    virt.module = get_dummy_module()

    # On a global zone
    set_module_args({})
    virt.get_virtual_facts()
    assert not virt.facts['container']
    assert 'zone' in virt.facts['virtualization_tech_host']
    assert not virt.facts['virtualization_tech_guest']
    assert not virt.facts['virtualization_type']
    assert not virt.facts['virtualization_role']

    # On a non-global zone
    set_module_args({'zone': 'local'})
    virt.get_virtual_facts()
    assert virt.facts['container'] == 'zone'
    assert not virt.facts['virtualization_tech_host']
    assert 'zone' in virt.facts['virtualization_tech_guest']


# Generated at 2022-06-11 06:08:21.418509
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, '0', '')

    sunos_virtual = SunOSVirtual(module)

    # Test return values of get_virtual_facts method
    result = sunos_virtual.get_virtual_facts()

    # Return values
    assert result['container'] == 'zone'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'zone'
    assert result['virtualization_tech_guest'] == {'zone'}
    assert result['virtualization_tech_host'] == set()


# Unit test class for SunOSVirtualCollector
#
# TODO: Add other unit tests.

# Generated at 2022-06-11 06:08:23.688498
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    # Check that the module imports
    try:
        SunOSVirtualCollector()
    except ImportError:
        fail("Failed to import the module")

# Generated at 2022-06-11 06:08:28.591100
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a class instance with the module_utils/facts/virtual/SunOS.py arguments
    virtual_instance = SunOSVirtual(dict(module=dict()), dict())

    # Assert that the instance has been initialized correctly
    assert virtual_instance._platform == 'SunOS'
    assert virtual_instance.platform == 'SunOS'



# Generated at 2022-06-11 06:08:29.964632
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({}, None)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:08:32.006000
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({},{},{},[])
    assert obj.platform == 'SunOS'


# Generated at 2022-06-11 06:08:34.395957
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    unit test for class SunOSVirtualCollector
    '''
    result = SunOSVirtualCollector(dict(), 'fake_module').collect()

# Generated at 2022-06-11 06:08:49.346397
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual._platform == "SunOS"
    assert sunos_virtual._fact_class.platform == "SunOS"


# Generated at 2022-06-11 06:08:50.688146
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector

# Generated at 2022-06-11 06:09:01.635039
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    import os

    class MockSystem:
        def __init__(self, out, retval):
            self.s = out
            self.r = retval

        def get_bin_path(self, path, opts=None):
            return '/usr/sbin/' + path

        def run_command(self, cmd, check_rc=True):
            return self.r, self.s, ''

        def file_exists(self, path):
            return self.s == path

    class MockModule:
        def __init__(self, sys):
            self.sys = sys

        def get_bin_path(self, path, opts=None):
            return self.sys.get_bin_path(path)

        def run_command(self, cmd, check_rc=True):
            return self.sys.run

# Generated at 2022-06-11 06:09:11.151613
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-11 06:09:13.354093
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict(module=None))
    assert sunos_virtual.platform == 'SunOS'
    sunos_virtual = SunOSVirtual(dict(module=None))
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:09:20.090636
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Calling the constructor of the class SunOSVirtualCollector
    obj = SunOSVirtualCollector()
    # Checking if the class SunOSVirtualCollector has the attribute _fact_class
    assert hasattr(obj, '_fact_class')
    # Checking if the class _fact_class of class SunOSVirtualCollector has the attribute platform
    assert hasattr(obj._fact_class, 'platform')

# Generated at 2022-06-11 06:09:23.389153
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    virt_collector = SunOSVirtualCollector()
    assert 'SunOS' == virt_collector._platform

# Generated at 2022-06-11 06:09:30.892253
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    if not module.get_bin_path('zonename'):
        module.fail_json(msg="zonename command not found")
    if not module.get_bin_path('modinfo'):
        module.fail_json(msg="modinfo command not found")
    if not module.get_bin_path('smbios'):
        module.fail_json(msg="smbios command not found")
    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    virtual_facts_expected = {}
    assert(virtual_facts_expected == facts)


# Generated at 2022-06-11 06:09:32.367876
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v != None


# Generated at 2022-06-11 06:09:33.800215
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule({})
    SunOSVirtual(module)


# Generated at 2022-06-11 06:09:48.014870
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fact_subclass = SunOSVirtualCollector.factory()
    fact_subclass.module.run_command = run_command_mock

# Generated at 2022-06-11 06:09:49.799130
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # test case 1
    m = SunOSVirtual({})
    assert m.data['virtualization_type'] == 'zone'

# Generated at 2022-06-11 06:09:51.919744
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert issubclass(x._fact_class, Virtual)

# Generated at 2022-06-11 06:09:54.519001
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual



# Generated at 2022-06-11 06:09:56.105911
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:04.909345
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = AnsibleModule(argument_spec={})

    virtual = SunOSVirtual(module)

    assert {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'container': 'zone',
        'virtualization_tech_guest': {'vmware', 'zone'},
        'virtualization_tech_host': set()
    } == virtual.get_virtual_facts()

    # should return the exact same dicts
    assert virtual.get_virtual_facts() == virtual.get_virtual_facts()



# Generated at 2022-06-11 06:10:07.566503
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.get_virtual_facts() == {}
    assert virtual_facts.platform == 'SunOS'



# Generated at 2022-06-11 06:10:09.098182
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:10.487025
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v.platform == 'SunOS'

# Generated at 2022-06-11 06:10:13.668614
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual
    assert obj._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:10:46.246619
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    osx = SunOSVirtual({})
    osx_facts = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': 'vmware',
        'virtualization_tech_host': '',
        'container': ''
    }

    assert osx.get_virtual_facts() == osx_facts
    assert osx_facts != os.x

    # Test for exception
    osx = SunOSVirtual({})
    osx._module.get_bin_path = lambda x: False
    osx_facts = {
        'virtualization_type': None,
    }

    assert osx.get_virtual_facts() == osx_facts
    assert osx_facts != os.x

# Generated at 2022-06-11 06:10:47.571562
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, VirtualCollector)

# Generated at 2022-06-11 06:10:49.179129
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    for key, value in SunOSVirtualCollector().get_facts().items():
        assert value is not None

# Generated at 2022-06-11 06:10:56.000454
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a mock module
    module = type('module', (object,), {})()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/usr/sbin/' + x

    # Create a new instance of SunOSVirtual
    w = SunOSVirtual(module)

    # Test the get_virtual_facts method
    facts = w.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'zone'}
    assert facts['container'] == 'zone'

# Generated at 2022-06-11 06:11:06.043531
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class MockModule(object):
        def __init__(self):
            pass

        def run_command(self, command, check_rc=True, close_fds=True):
            if command == '/usr/sbin/virtinfo -p':
                return 0, "", ""
            elif command == 'zonename':
                return 0, "global\n", ""
            elif command == 'modinfo':
                return 0, "", ""
            elif command == 'smbios':
                return 0, "", ""

        @property
        def get_bin_path(self, command, required=False, opt_dirs=[]):
            # Just return the command - but in real life, this would need to return the full path to an executable
            return command

    module = MockModule()

# Generated at 2022-06-11 06:11:06.911152
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:11:08.856435
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtualCollector(None, 'SunOS', {}, {})
    assert sunos_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 06:11:17.022918
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock(return_value=dict(rc=0, stdout='', stderr=''))
    module.get_bin_path = mock.Mock(return_value=None)

    # Test when we are in a global zone
    module.run_command.return_value = dict(rc=0, stdout='global\n', stderr='')
    virtual = SunOSVirtual(module)
    virtual.get_virtual_facts()
    assert module.run_command.call_count == 1
    module.run_command.assert_called_with('zonename')
    assert virtual.facts == dict(virtualization_tech_host={'zone'})

    # Test when we are in a non global zone
    module.run_command

# Generated at 2022-06-11 06:11:26.711100
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Test the method get_virtual_facts on the SunOSVirtual class
    This is done with a simple mocking.
    '''
    from ansible.module_utils.facts.virtual import SunOSVirtual

    my_obj = SunOSVirtual()
    my_obj.module = FakeAnsibleModule()
    my_obj.module.run_command = fake_run_command
    facts = my_obj.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'


# Generated at 2022-06-11 06:11:33.246195
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt = SunOSVirtual({'module_setup': True}, {})
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_tech_guest'] == set(['zone','kvm'])
    assert facts['container'] == 'zone'

# Generated at 2022-06-11 06:12:22.771355
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    # Check the constructor of class SunOSVirtualCollector
    # (if it runs without exception)
    SunOSVirtualCollector()


# Generated at 2022-06-11 06:12:26.521571
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector(None)
    assert isinstance(c.facts['virtualization_tech_host'], set)
    assert isinstance(c.facts['virtualization_tech_guest'], set)
    assert c.platform == 'SunOS'

# Generated at 2022-06-11 06:12:28.888942
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert (virtual_collector._platform == 'SunOS')
    assert (virtual_collector._fact_class == SunOSVirtual)

# Generated at 2022-06-11 06:12:30.013143
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    f = SunOSVirtualCollector()
    assert f is not None

# Generated at 2022-06-11 06:12:32.870790
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = "ansible.module_utils.facts.virtual.SunOS.SunOSVirtual"
    module = __import__(module, fromlist=[''])
    sunos = module.SunOSVirtual()
    assert sunos is not None

# Generated at 2022-06-11 06:12:38.726860
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand([
        ['zonename', 0, 'global', ''],
        ['modinfo', 0, '60  1 ffffffffff800100  70044   vmware (VMware)', ''],
        ['virtinfo', 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''],
        ['smbios', 0, 'VMware\n', '']
    ])
    module.get_bin_path = FakeGetBinPath(['zonename', 'modinfo', 'virtinfo', 'smbios'])

    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-11 06:12:46.211863
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule(
        dict(
            ansible_facts=dict(
                ansible_os_family='Solaris'
            )
        )
    )

    sunos_virtual = SunOSVirtual(module)

    virtual_facts = sunos_virtual.get_virtual_facts()
    assert type(virtual_facts) is dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts or 'virtualization_type' in virtual_facts


# Generated at 2022-06-11 06:12:47.295325
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:12:49.980151
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-11 06:12:54.518138
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_info = {}
    virtual_info['virtualization_type'] = None
    virtual_info['virtualization_role'] = None
    virtual_info['virtualization_tech_host'] = set()
    virtual_info['virtualization_tech_guest'] = set()
    virtual_info['container'] = None
    module = FakeAnsibleModule()
    obj = SunOSVirtual(module)
    assert obj.get_virtual_facts() == virtual_info


# Generated at 2022-06-11 06:14:42.791758
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_instance = SunOSVirtual(dict())
    assert virtual_instance.platform == 'SunOS'
    assert virtual_instance.get_virtual_facts() == dict()

# Generated at 2022-06-11 06:14:46.909622
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = {'virtualization_role' : None,'virtualization_type' : None,
             'virtualization_tech_guest': set(),'virtualization_tech_host': set(),
             'container' : None}
    v = SunOSVirtual(dict(), facts)
    assert isinstance(v, SunOSVirtual)


# Generated at 2022-06-11 06:14:48.757176
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:14:59.676686
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Import the module
    from ansible.module_utils.facts.virtual import SunOSVirtual

    # Create a test class
    class Test():
        # Create a method to run commands
        def run_command(self, command):
            out = ""
            if command == "zonename":
                out = "global"
            elif command == "virtinfo -p":
                out = "DOMAINROLE|impl=LDoms|control=true|io=true|service=true|root=false\n" # This is a host
                out += "DOMAINROLE|impl=LDoms|control=true|io=true|service=false|root=false\n" # This is also a host
                out += "DOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=true\n" # This

# Generated at 2022-06-11 06:15:01.554304
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual


# Generated at 2022-06-11 06:15:03.398831
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'
    assert v.options == {}



# Generated at 2022-06-11 06:15:04.825896
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector()

    assert facts_collector._platform == 'SunOS'
    assert facts_collector._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:15:06.955331
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import virtual
    vc = virtual.virtual.get('SunOS', {})
    assert isinstance(vc, SunOSVirtualCollector)

# Generated at 2022-06-11 06:15:16.215613
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Test for SunOSVirtual.get_virtual_facts()."""
    # Mock the module
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual as sut

    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = 0, "", ""
    module_mock.get_bin_path.return_value = True
    sut.module = module_mock

    # Invoke get_virtual_facts()
    facts = sut.get_virtual_facts()

    # Assert the method returns an expected dictionary

# Generated at 2022-06-11 06:15:17.490650
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.get_all()