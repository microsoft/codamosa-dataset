

# Generated at 2022-06-11 06:07:39.403812
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This creates an instance of a SunOSVirtualCollector object and
    verifies its constructor
    """
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:07:41.084477
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.__class__.__name__ == "SunOSVirtualCollector"

# Generated at 2022-06-11 06:07:43.261356
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    module.params = {}
    virtual = SunOSVirtual(module)
    assert virtual is not None


# Generated at 2022-06-11 06:07:45.047329
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-11 06:07:45.665419
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({})

# Generated at 2022-06-11 06:07:51.357179
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual(dict())
    assert x.facts['virtualization_role'] == 'guest'
    assert x.facts['virtualization_type'] == 'vmware'
    assert x.facts['virtualization_tech_guest'] == set(['vmware'])
    assert x.facts['virtualization_tech_host'] == set(['zone'])
    assert x.facts['container'] == 'zone'

# Generated at 2022-06-11 06:07:53.873353
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    method = SunOSVirtual(module)
    assert method.get_virtual_facts()['virtualization_role'] == 'guest'



# Generated at 2022-06-11 06:07:56.084618
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a unit test for constructor of class SunOSVirtualCollector
    """

    SunOSVirtualCollector()

# Generated at 2022-06-11 06:07:58.335673
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:01.022174
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test without arguments
    test_virtual = SunOSVirtual({})

    # Test with arguments
    test_virtual = SunOSVirtual({'ansible_facts': {}})

# Generated at 2022-06-11 06:08:19.952649
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual(dict())
    v.module.run_command = lambda *args, **kwargs: (0, '', '')
    v.module.get_bin_path = lambda *args, **kwargs: '/bin/' + args[0]
    assert v.get_virtual_facts() == {
        'virtualization_type': 'zone',
        'virtualization_role': 'host',
        'virtualization_tech_host': {'zone'},
        'virtualization_tech_guest': set(),
        'container': 'zone'
    }

# Generated at 2022-06-11 06:08:30.430592
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # create a fake module
    module = type('AnsibleModule', (object,), {'run_command': run_command})
    # create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # run and test get_virtual_facts for cases where virtualization_type is set
    sunos_virtual.module.run_command = lambda x: (0, "system manufacturer: Xen\nsystem product: HVM DomU\n")
    assert sunos_virtual.get_virtual_facts() == {'virtualization_type': 'xen',
                                                 'virtualization_role': 'guest',
                                                 'virtualization_tech_host': set(),
                                                 'virtualization_tech_guest': set(['xen'])}

# Generated at 2022-06-11 06:08:32.769217
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    if not SunOSVirtualCollector()._platform:
        raise Exception('The attribute _platform should be "SunOS"')

# Generated at 2022-06-11 06:08:34.014923
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

# Generated at 2022-06-11 06:08:37.288951
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert isinstance(sunos_virtual, SunOSVirtualCollector)
    assert sunos_virtual.platform == "SunOS"
    assert sunos_virtual.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:45.358852
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    m = SunOSVirtual(module)

    assert m.get_virtual_facts() == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_guest': {'zone', 'vmware'},
        'virtualization_tech_host': {'zone'}
    }


from ansible.module_utils.facts.virtual.test.test_zone import Test_SunOS_Zone
from ansible.module_utils.facts.virtual.test.test_domaining import Test_SunOS_Domaining
from ansible.module_utils.facts.virtual.test.test_branded_zone import Test_SunOS_BrandedZone

# Generated at 2022-06-11 06:08:47.700218
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    m = SunOSVirtualCollector()
    assert m.platform == 'SunOS'
    assert m.fact_class == SunOSVirtual
    assert m.fact_subclasses == {}

# Generated at 2022-06-11 06:08:49.747236
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:54.261560
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual({})
    assert m.platform == 'SunOS'
    assert m.virtualization_type is None
    assert m.virtualization_role is None
    assert m.virtualization_tech_guest == set()
    assert m.virtualization_tech_host == set()
    assert m.container is None

# Generated at 2022-06-11 06:08:55.778316
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(module=None)
    assert s.platform == 'SunOS'

# Generated at 2022-06-11 06:09:15.742534
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Create a class object
    my_test = SunOSVirtual()
    my_test.module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Set module parameters
    my_test.module.params = {}

    # Change some internal values
    my_test.module.run_command = lambda x: (0, open(x, 'r').read(), '')

    # Run the function
    my_test.get_virtual_facts()

    # Check the result
    assert my_test.virtual_facts['virtualization_tech_guest'] == set(['vmware']), "Incorrect virtualization_tech_guest value"

# Generated at 2022-06-11 06:09:16.568139
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:09:21.233075
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = DummyAnsibleModule()
    fact_class = SunOSVirtual
    collector = SunOSVirtualCollector(module)
    assert collector.platform == 'SunOS'
    assert collector._fact_class == fact_class

# Unit test class for testing SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-11 06:09:24.070368
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class == SunOSVirtual
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-11 06:09:33.212161
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    ansible_module = basic.AnsibleModule({})
    m = SunOSVirtual(ansible_module)
    facts = m.get_facts()

    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'container' in facts

    expected_virtualization_role = 'guest'
    expected_virtualization_type = 'zone'
    expected_virtualization_tech_host = set()
    expected_virtualization_tech_guest = set(['zone'])
    expected_container = 'zone'


# Generated at 2022-06-11 06:09:43.804071
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from collections import namedtuple
    from ansible.module_utils.facts.collector import FactsCollector

    PyModule = namedtuple('PyModule', ['params', 'run_command'])

    # Constructor and __new__ of class FactsCollector will set following attributes
    module_args = {
        'gather_subset': ['all'],
        'filter': '*'
    }
    rc_params = {'rc': 0}
    rc_out = "test"
    rc_err = ""
    rc = namedtuple('rc', rc_params.keys())(*rc_params.values())

    def mock_run_command(self, cmd, check_rc=False, close_fds=True):
        return rc


# Generated at 2022-06-11 06:09:49.082150
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    o = SunOSVirtual({})
    assert o.get_virtual_facts() == {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest', 'container': 'zone'}

    o = SunOSVirtual({'data_source': 'cmdline'})
    assert o.get_virtual_facts() == {'virtualization_type': 'vmware', 'virtualization_role': 'guest'}

# Generated at 2022-06-11 06:09:58.783729
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    #
    # Import module for unittest
    #
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import get_virtual_facts
    #
    # Create a stubbed module
    #
    class StubbedModule:
        def __init__(self,x):
            self.x = x
        def get_bin_path(self, arg):
            if arg == 'smbios':
                return "/usr/sbin/smbios"
            elif arg == 'zonename':
                return "/usr/bin/zonename"
            elif arg == 'virtinfo':
                return "/usr/sbin/virtinfo"
            el

# Generated at 2022-06-11 06:10:00.406729
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(dict())
    assert s.platform == 'SunOS'

# Generated at 2022-06-11 06:10:10.392550
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import VirtualCollector
    import platform
    host_os = platform.system()
    if host_os != 'SunOS':
        module = basic.AnsibleModule(
            argument_spec = dict()
        )
        VirtualCollector.set_module(module)
        result = collector.get_collector_facts(VirtualCollector)
        assert result == {}
        return
    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    VirtualCollector.set_module(module)
    result = collector.get_collector_facts(VirtualCollector)
    assert result.__class__.__name__ == 'dict'

# Generated at 2022-06-11 06:10:40.600776
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(module)
    host_tech = set()
    guest_tech = set()
    assert sunos_virtual.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'container': ''}



# Generated at 2022-06-11 06:10:43.406677
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''Test constructor for SunOSVirtual'''
    virt = SunOSVirtual({})
    assert virt.get_virtual_facts().keys() == set([])


# Generated at 2022-06-11 06:10:45.707728
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 06:10:52.825088
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.basic import AnsibleModule

    module_args = {}
    module = AnsibleModule(module_args)

    # Set up some fake values that are expected in facts['virtual']
    facts = {
        'distribution': 'SunOS',
    }
    virtual = SunOSVirtual(module)
    # Call the code to be tested
    virtual_facts = virtual.get_virtual_facts()
    # Test that the correct values were returned
    assert virtual_facts is not None
    assert 'virtual' in virtual_facts
    assert virtual_facts['virtual'] == 'SunOS'
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-11 06:10:59.229733
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('module', (), {})
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    deps = lambda x: None
    SunOSVirtual.get_distribution = deps
    SunOSVirtualCollector.get_distribution = deps

    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()

    assert facts['virtualization_type'] == 'sunos'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 06:11:08.483791
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import MockModule
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import patched_command

    mock_module = MockModule(argument_spec={})
    mock_module.exit_json = exit_json
    mock_module.fail_json = fail_json

    def make_command(command, executable=None, output='', rc=0):
        def action(*args, **kwargs):
            if args[0] == command:
                return patched_command(command, executable, output=output, rc=rc, stderr="", *args, **kwargs)
            else:
                return patched_command(command, *args, **kwargs)
        return action

    # Test global zone
    virtual = Sun

# Generated at 2022-06-11 06:11:10.063173
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-11 06:11:12.567856
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 06:11:14.127174
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:11:15.905973
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == "SunOS"
    assert virtual_facts._fact_class == "SunOSVirtual"

# Generated at 2022-06-11 06:12:14.269882
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    host_tech = set()
    guest_tech = set()

    # Check if it's a zone
    if os.path.isdir('/native'):
        host_tech.add('zone')
    if os.path.isdir('/.SUNWnative'):
        guest_tech.add('zone')

    # Check if it's a branded zone (i.e. Solaris 8/9 zone)
    if os.path.isdir('/.SUNWnative'):
        guest_tech.add('zone')

    # Detect domaining on Sparc hardware
    if os.path.isdir('/native'):
        guest_tech.add('ldom')


# Generated at 2022-06-11 06:12:15.500572
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:12:17.644450
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtfacts = SunOSVirtual({})
    # Test get_virtual_facts method
    res = virtfacts.get_virtual_facts()
    assert res == {}

# Generated at 2022-06-11 06:12:27.869463
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector

    # Create a test instance of SunOSVirtual
    test_virtuals = SunOSVirtual(VirtualCollector)

    # Create a class instance with a mock get_bin_path method
    class MockVirtual(Virtual):
        class MockModule:
            get_bin_path_values = {
                'zonename': '',
                'virtinfo': '',
                'smbios': '',
                'modinfo': '',
            }

            def get_bin_path(self, binary):
                return self.get_bin_path_values[binary]

        module = MockModule()

    # Create

# Generated at 2022-06-11 06:12:30.671250
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict(module=None))
    assert virt.platform == 'SunOS'
    assert virt.get_virtual_facts() == {}
    assert virt.get_virtual_subclass('SunOS') == SunOSVirtual


# Generated at 2022-06-11 06:12:31.884286
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sos = SunOSVirtual(dict())
    assert sos.platform == 'SunOS'

# Generated at 2022-06-11 06:12:38.277288
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MagicMock()
    virt_obj = SunOSVirtual(module)
    module.get_bin_path.side_effect = lambda x: x

    module.run_command.return_value = (0, "", "")
    module.run_command.side_effect = lambda x: ('global', 0, "", "") if 'zonename' in x else (0, "", "")
    assert virt_obj.get_virtual_facts() == {}

    module.run_command.side_effect = lambda x: ('non-global', 0, "", "") if 'zonename' in x else (0, "", "")
    assert virt_obj.get_virtual_facts() == {'container': 'zone'}

    module.run_command.side_effect = None

# Generated at 2022-06-11 06:12:48.068386
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Test to initialize SunOSVirtual object
    '''
    virtual_obj = SunOSVirtual()
    assert virtual_obj.virtualization_type == "SunOS"
    assert virtual_obj.virtualization_role == "SunOS"
    assert virtual_obj.virtualization_use == "SunOS"
    assert virtual_obj.virtualization_system == "SunOS"
    assert virtual_obj.virtualization_system_version == "SunOS"
    assert virtual_obj.virtualization_hypervisor_version == "SunOS"
    assert virtual_obj.virtualization_hypervisor == "SunOS"
    assert virtual_obj.virtualization_hypervisor_type == "SunOS"
    assert virtual_obj.virtualization_host_name == "SunOS"

# Generated at 2022-06-11 06:12:51.796864
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    print(facts.get_all_facts())
    assert(facts.get_all_facts()['virtualization_type'] == 'kvm')
    assert(facts.get_all_facts()['virtualization_role'] == 'guest')

# Generated at 2022-06-11 06:12:57.421572
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos.fake_solaris_virtual_facts import Fake_SunOSVirtualFacts

    fake_module = Fake_SunOSVirtualFacts()
    virt_facts = SunOSVirtual(module=fake_module)
    virtual_facts = virt_facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_technologies_guest'] == set(['vmware'])
    assert virtual_facts['virtualization_technologies_host'] == set(['zone'])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-11 06:14:54.505095
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    Facter = SunOSVirtualCollector()
    assert Facter._platform == 'SunOS'
    assert Facter._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:15:03.397193
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBox
    from ansible.module_utils.facts.virtual.vmware import VMware

    module = VirtualBox().module
    # Mock the module and the run_command only
    module.run_command = lambda *args, **kwargs: (0, "", "")

    # Execute the method get_virtual_facts
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'virtualbox',
                             'virtualization_role': 'guest',
                             'virtualization_tech_guest': {'virtualbox'},
                             'virtualization_tech_host': set()}

    module = VMware().module
    # Mock the module and the run_command only

# Generated at 2022-06-11 06:15:07.995182
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    facts = virtual.get_all_facts()
    print(facts)
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'zone'
    assert facts['container'] == 'zone'
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'zone' not in facts['virtualization_tech_host']


# Mock module class to help us during unit tests.
# Note: not using 'mock' library because this is not available in python 2.6 and we still want to support it.

# Generated at 2022-06-11 06:15:16.725312
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Dummy module object
    module = type('', (), {})()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    # Dummy facts object
    facts = type('', (), {})()
    setattr(module, 'ansible_facts', facts)
    # Dummy distrib object
    distrib = type('', (), {})()
    setattr(module.ansible_facts, 'distribution', distrib)

    SunOSVirtual(module)
    assert module.ansible_facts['virtualization_type'] == 'xen'
    assert module.ansible_facts['virtualization_role'] == 'guest'
    assert 'xen' in module.ansible_facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:15:18.483144
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sc = SunOSVirtualCollector()
    assert sc.platform is 'SunOS'
    assert sc._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:15:27.638172
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    import os
    import sys
    import mock
    import platform

    try:
        from ansible.module_utils.facts import virtual
    except ImportError:
        sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
        from module_utils.facts import virtual

    # Fake out some module/command invocation data. We don't need it for the
    # tests done here, so fill them with dummy values.
    module_name = 'ansible.module_utils.facts.virtual'
    module_args = {}
    tmp = '/tmp'
    changed = False

    # Create the mock module and set up the needed attributes and methods.

# Generated at 2022-06-11 06:15:35.660326
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class ModuleMock(object):
        def run_command(self, cmd, check_rc=True):
            return 0, '', ''

        def get_bin_path(self, prg):
            return

        @staticmethod
        def fail_json(rc, msg, **kwargs):
            pass

        @staticmethod
        def exit_json(changed=False, ansible_facts=None, **kwargs):
            pass

    class FactsMock(object):
        def __init__(self):
            self.ansible_facts = {}

        def populate(self, module):
            pass

    class SunOSVirtualMock(SunOSVirtual):
        def __init__(self, module):
            SunOSVirtual.__init__(self, module)

        def get_virtual_facts(self):
            return self.virtual_

# Generated at 2022-06-11 06:15:40.568740
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModuleFakeVirtualFacts()
    sunos = SunOSVirtual(module)
    sunosvirtualfacts = sunos.get_virtual_facts()

    assert sunosvirtualfacts['virtualization_tech_guest'] == set()
    assert sunosvirtualfacts['virtualization_tech_host'] == set()
    assert sunosvirtualfacts['virtualization_type'] == 'zone'
    assert sunosvirtualfacts['virtualization_role'] == 'guest'
    assert sunosvirtualfacts['container'] == 'zone'



# Generated at 2022-06-11 06:15:43.600326
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
   obj = SunOSVirtualCollector()
   assert obj._platform == 'SunOS'
   assert obj._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:15:46.099425
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_collector = SunOSVirtualCollector()
    assert test_collector._fact_class == SunOSVirtual
    assert test_collector._platform == 'SunOS'