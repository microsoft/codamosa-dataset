

# Generated at 2022-06-11 06:07:41.564582
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    "Test class constructor"

    # Inject required facts as module params
    module = FakeModule({'ansible_system': 'SunOS'})

    virtual = SunOSVirtual(module)
    v_facts = virtual.get_virtual_facts()

    assert 'SunOS' == v_facts['virtualization_type']

# Generated at 2022-06-11 06:07:51.898503
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = 'test_module'
    test_module.get_bin_path = lambda *args: '/bin/%s' % args[0]
    test_module.run_command = lambda *args: (0, '', '')
    test_module.fail_json = lambda *args: False

    virtual = SunOSVirtual(test_module)

    test_module.run_command = lambda *args: (-1, '', '')
    assert virtual.get_virtual_facts() == {}

    test_module.run_command = lambda *args: (0, 'global', '')
    assert virtual.get_virtual_facts() == {'virtualization_tech_host': {'zone'}}

    test_module.run_command = lambda *args: (0, 'non-global', '')
    assert virtual.get_virtual

# Generated at 2022-06-11 06:07:55.117855
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc._platform == 'SunOS'
    assert svc._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:07:56.175580
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:08:00.125289
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    sunos_virtual = SunOSVirtual(module)
    facts = {}
    if sunos_virtual.is_sunos():
        facts = sunos_virtual.get_virtual_facts()
    assert facts


# Generated at 2022-06-11 06:08:02.960189
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert(virtual_collector.platform == 'SunOS')
    assert(virtual_collector._fact_class == SunOSVirtual)

# Generated at 2022-06-11 06:08:05.754564
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:15.934654
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Load test data
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value=True)
    module.run_command = Mock(return_value=(0, '', ''))
    testfacts = {'virtualization_type': '',
                 'virtualization_role': '',
                 'container': ''}
    virtual = SunOSVirtual(module)

    # Test the case of a branded zone
    module.run_command = mock_runcommand_brandedzone
    testfacts.update({'virtualization_type': '',
                      'virtualization_role': 'guest',
                      'container': 'zone'})
    virtual.get_virtual_facts() == testfacts

    # Test the case of a zone with not virtualized global zone
    module.run_command = mock_runcommand_

# Generated at 2022-06-11 06:08:17.010201
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'

# Generated at 2022-06-11 06:08:19.253230
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt_fact_module = SunOSVirtualCollector()
    assert virt_fact_module._fact_class == SunOSVirtual
    assert virt_fact_module._platform == 'SunOS'

# Generated at 2022-06-11 06:08:49.745567
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    expected = ('SunOS', 'Virtual', 'SunOSVirtual')
    vc = SunOSVirtualCollector()
    facts = vc.collect()
    assert vc.platform == expected[0]
    assert vc.category == expected[1]
    assert vc.fact_class.__name__ == expected[2]
    assert isinstance(facts, dict)
    assert len(facts) > 0

# Generated at 2022-06-11 06:09:01.027426
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a dummy module object
    class SunOSVirtualModule:
        def __init__(self):
            self.run_command_calls = dict()
            self.run_command_calls['zonename'] = 0
            self.run_command_calls['modinfo'] = 0
            self.run_command_calls['virtinfo'] = 0
            self.run_command_calls['smbios'] = 0

        def get_bin_path(self, name):
            # Check if we're called with a correct command name
            if not name in ["zonename", "modinfo", "virtinfo", "smbios"]:
                raise Exception("Invalid command name passed")

            # Return a function that emulates the behavior of the command depending on the testcase

# Generated at 2022-06-11 06:09:02.755557
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:09:04.940338
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:09:13.532070
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ansible_virtual_facts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create a SunOSVirtual object for testing
    virtual_obj = SunOSVirtual()
    virtual_obj._module = ansible_virtual_facts._module
    virtual_obj._dist_version = "5.11"
    virtual_obj.lsb_release = ansible_virtual_facts.lsb_release
    virtual_obj.sysctl = ansible_virtual_facts.sysctl

    # Check if it's a zone
    zonename = virtual_obj.module.get_bin_path('zonename')
    if zonename:
        rc, out, err = virtual_obj.module.run_command(zonename)

# Generated at 2022-06-11 06:09:15.996535
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:09:19.237496
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    sun_os_virtual = SunOSVirtual(module)
    assert sun_os_virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:09:22.875363
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('dummie', (object,), {})()
    module.run_command = os.system

    collector_instance = SunOSVirtualCollector(module)
    assert isinstance(collector_instance, SunOSVirtualCollector)

# Generated at 2022-06-11 06:09:26.135535
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual_data = SunOSVirtual(module)
    result = virtual_data.data
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'container' in result


# Generated at 2022-06-11 06:09:28.014854
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert instance.get_virtual_facts() == {}


# Generated at 2022-06-11 06:10:03.303111
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def run_command(module, cmd):
        if cmd == "zonename":
            return 0, "testzone", ""
        elif cmd == "modinfo":
            return 0, "testvmware", ""
        elif cmd == "virtinfo -p":
            return 0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false\n", ""
        elif cmd == "smbios":
            return 0, "testvmware", ""
        return -1, "", ""

    module = MockModule({})
    module.run_command = run_command
    module.get_bin_path = lambda x: x

    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'container' in virtual_facts

# Generated at 2022-06-11 06:10:08.999113
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Check if the system's module path is available
    module_path = os.environ['MODULEPATH']

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create a mock module
    module = AnsibleModuleMock(module_path)

    s = SunOSVirtual(module)

    # Check if we return the correct platform
    assert s.platform == 'SunOS'



# Generated at 2022-06-11 06:10:19.432979
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    from ansible.module_utils.facts.virtual.posix import PosixVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    import os

    # Create a PosixVirtual instance
    v = SunOSVirtual()

    # Get the virtual facts for this system
    virtual_facts = v.get_virtual_facts()

    # The following fields are specific to SunOSVirtual and should be set
    # - virtualization_type
    # - virtualization_role
    # - container
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts

    # The following fields are specific to PosixVirtual and should be set
   

# Generated at 2022-06-11 06:10:22.154048
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sysname = 'SunOS'
    if sysname == "SunOS":
        virt = SunOSVirtual(dict(module=None))
        assert virt.platform == 'SunOS'

# Generated at 2022-06-11 06:10:23.617295
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    # virtual.get_virtual_facts()

# Generated at 2022-06-11 06:10:26.478517
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos.collector import SunOSVirtualCollector
    vc = SunOSVirtualCollector()
    assert vc._fact_class.platform == 'SunOS'
    assert vc._platform == 'SunOS'


# Generated at 2022-06-11 06:10:37.233204
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import get_module_scratch
    module = get_module_scratch()
    module.run_command = get_command
    module.get_bin_path = get_bin_path

    sunos_virtual = SunOSVirtual(module)
    # SunOS host running in a zone
    module.run_command.side_effect = [
        (0, "global", ""),  # zonename
        (0, "", "")         # modinfo
    ]
    facts = sunos_virtual.get_virtual_facts()
    assert 'zone' in facts['virtualization_tech_host']
    # SunOS host running in a branded zone

# Generated at 2022-06-11 06:10:41.353998
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector can be called without arguments
    and it will return a instance of SunOSVirtualCollector
    """
    collector = SunOSVirtualCollector()

    assert isinstance(collector, SunOSVirtualCollector)
    assert collector.platform == "SunOS"



# Generated at 2022-06-11 06:10:43.288842
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._fact_class is SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-11 06:10:49.684823
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual import SunOSVirtualCollector
    import platform
    import unittest
    # Create an instance of class SunOSVirtualCollector
    sunos_virtualCollector = SunOSVirtualCollector()
    # Check that the value of attribute _platform is correct
    sunos_platform = 'SunOS'
    assert sunos_virtualCollector._platform == sunos_platform
    # Check that the value of attribute _fact_class is correct
    fact_class = SunOSVirtual
    assert sunos_virtualCollector._fact_class == fact_class

# Generated at 2022-06-11 06:11:53.769148
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import os
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.module_utils.facts import ModuleFacts

    class FakeModule:
        def get_bin_path(self, arg):
            return None

        def run_command(self, arg):
            if arg == '/usr/sbin/virtinfo -p':
                return (0, 'DOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=false\n', '')
            return (1, '', '')

    module = FakeModule()
    facts = ModuleFacts().populate_facts(module)

# Generated at 2022-06-11 06:11:58.838225
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual({})
    virtual_facts = m.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:12:02.387715
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({}, {}, {}, [])
    assert s.platform == 'SunOS'
    assert s.virtualization_type is None
    assert s.virtualization_role is None
    assert s.container is None

# Generated at 2022-06-11 06:12:04.717682
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import VirtualCollector

    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 06:12:06.603386
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})
    facts = v.get_virtual_facts()
    assert facts == {}

# Generated at 2022-06-11 06:12:07.982147
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    SunOSVirtual(module)


# Generated at 2022-06-11 06:12:10.486000
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import pprint
    facts = SunOSVirtual()
    facts_dict = facts.get_all()
    pprint.pprint(facts_dict)

# Generated at 2022-06-11 06:12:11.360373
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtualObj = Virtual()
    assert virtualObj is not None
    obj = SunOSVirtual()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:12:18.122627
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command_mock
    v = SunOSVirtual(module)

    # set up expected values
    expected = {}
    expected['virtualization_role'] = 'guest'
    expected['container'] = 'zone'
    expected['virtualization_type'] = 'vmware'
    expected['virtualization_tech_host'] = set(['zone'])
    expected['virtualization_tech_guest'] = set(['zone', 'vmware'])

    # get actual values
    actual = v.get_virtual_facts()

    # Compare expected and actual results
    assert actual == expected


# Generated at 2022-06-11 06:12:20.000138
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    s = SunOSVirtualCollector()
    assert s._platform == 'SunOS'


# Generated at 2022-06-11 06:14:26.335479
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.get_virtual_facts.__name__ == 'get_virtual_facts'
    assert x.get_virtual_facts.__doc__ == 'Return virtualization type and role (guest or host).'
    assert x.__platform == 'SunOS'

# Generated at 2022-06-11 06:14:28.065906
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Runs the constructor of class SunOSVirtual and ensures that SunOSVirtual
    has been properly declared.
    """
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:14:36.960413
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    module = unittest.mock.Mock()
    module.run_command = unittest.mock.MagicMock(
        return_value=(0, 'global\n', '')
    )
    module.get_bin_path = unittest.mock.MagicMock(return_value='/path/to/zonename')

    sunos_virtual = SunOSVirtual(module)

# Generated at 2022-06-11 06:14:43.738165
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.sunos.get_virtual_facts import SunOSVirtual
    from ansible.module_utils._text import to_bytes
    import pprint
    import sys

    fact_collector = FactCollector(module=None)
    sys.modules['ansible.module_utils.facts.collector'] = fact_collector
    virtual = SunOSVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    pprint.pprint(virtual_facts)

# Generated at 2022-06-11 06:14:46.367136
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (object, ), {'run_command': lambda *x: (0, '', '')})()
    obj = SunOSVirtual(module)
    assert isinstance(obj, SunOSVirtual)

# Generated at 2022-06-11 06:14:51.488105
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('', (object,), {})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '', '')
    vc = SunOSVirtualCollector(module)
    assert vc.platform == 'SunOS'
    assert vc.fact_class == SunOSVirtual


# Generated at 2022-06-11 06:14:55.691476
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_facts = SunOSVirtualCollector(dict(), 'ansible_local')
    assert my_facts._platform == 'SunOS'
    assert isinstance(my_facts._fact_class, SunOSVirtual)

# Generated at 2022-06-11 06:15:04.364236
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    module = Mock()
    module.run_command = Mock()
    module.get_bin_path = Mock(side_effect=get_bin_path_side_effect)

# Generated at 2022-06-11 06:15:13.770861
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """ Unit test to validate facts gathering when running on Solaris 11.
        This method has been tested on VirtualBox running Solaris 11.
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class FakeModule(object):
        pass

    fake_module = FakeModule()
    fake_module.get_bin_path = basic.get_bin_path

    test_virtual = SunOSVirtual(fake_module)
    test_collector = SunOSVirtualCollector(fake_module)

    # Example of the output of 'smbios':
    #   System Information
    #   Manufacturer: innotek GmbH
    #   Product: VirtualBox
    #   Version: 1.2
    #   Serial Number: 0
    #   UUID: a9a7039c-24e

# Generated at 2022-06-11 06:15:14.868492
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    col = SunOSVirtualCollector()
    assert col is not None