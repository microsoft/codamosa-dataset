

# Generated at 2022-06-11 06:07:45.047754
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    import os
    from datetime import datetime

    MOCK_ZONENAME_PATH = os.path.join(os.path.dirname(__file__), "mock_bin", "zonename")
    MOCK_VIRTINFO_PATH = os.path.join(os.path.dirname(__file__), "mock_bin", "virtinfo")
    MOCK_SMBIOS_PATH = os.path.join(os.path.dirname(__file__), "mock_bin", "smbios")

    MOCK_ZONENAME_EXPECTED_GLOBALZONE = [0, 'global\n', '']

# Generated at 2022-06-11 06:07:48.500850
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector(None)
    assert collector.platform == 'SunOS'
    assert collector.__class__ == SunOSVirtualCollector
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 06:07:56.627258
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test SunOSVirtual.get_virtual_facts()
    """

    # Mock module
    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, command):
            if command == 'zonename':
                if 'zonename' in self.params:
                    return self.params['zonename']
                else:
                    return None
            if command == 'virtinfo':
                if 'virtinfo' in self.params:
                    return self.params['virtinfo']
                else:
                    return None
            if command == 'smbios':
                if 'smbios' in self.params:
                    return self.params['smbios']
                else:
                    return None

# Generated at 2022-06-11 06:08:06.213629
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # get_virtual_facts should return a dict
    test_module = SunOSVirtual(None)
    virtual_facts = test_module.get_virtual_facts()
    assert isinstance(virtual_facts, dict)

    # The following cases assume we're running on a SPARC machine.

    # Test #1: Run on a physical SPARC machine
    test_module = SunOSVirtual(None)
    test_module.module.run_command = run_command_sparc_physical_machine
    virtual_facts = test_module.get_virtual_facts()
    assert len(virtual_facts) == 0

    # Test #2: Run on a SPARC machine that has a zone installed
    test_module = SunOSVirtual(None)
    test_module.module.run_command = run_command_sparc_zone_guest_machine

# Generated at 2022-06-11 06:08:08.560618
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
	my_SunOSVirtual = SunOSVirtual( dict(module=dict()) )
	assert my_SunOSVirtual.platform == 'SunOS'

# Generated at 2022-06-11 06:08:18.080581
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_result = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'container': 'zone', 'virtualization_tech_guest': set(['xen', 'zone']), 'virtualization_tech_host': set(['zone'])}
    zonename = './utils/unittests/modules/ansible/module_utils/facts/virtual/zonename'
    modinfo = './utils/unittests/modules/ansible/module_utils/facts/virtual/modinfo'
    smbios = './utils/unittests/modules/ansible/module_utils/facts/virtual/smbios'
    sunos_virtual = SunOSVirtual(zonename, modinfo, smbios)
    virtual_facts = sunos_virtual.get_virtual_facts()

# Generated at 2022-06-11 06:08:28.276404
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class args:
        module = None

    os_virtual = SunOSVirtual(args)
    facts = {}
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'vmware'
    virtual_facts['virtualization_role'] = 'guest'
    facts['virtualization'] = virtual_facts

    def get_bin_path(path):
        return '/path/to/'+path

    def run_command(cmd):
        if cmd == '/usr/sbin/zoneadm list':
            return 0, '0:global:running:/::native', ''
        elif cmd == '/path/to/zonename':
            return 0, 'global', ''
        elif cmd == '/path/to/modinfo':
            return 0, 'Module: id="VMware"', ''

# Generated at 2022-06-11 06:08:32.953573
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    facts = SunOSVirtual(module).get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-11 06:08:34.976639
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:08:37.826341
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 06:08:57.577132
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    module.run_command = Mock(return_value=(0, "global", ""))
    virtual = SunOSVirtual(module=module)
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts() == {'virtualization_type': '',
                                           'virtualization_role': '',
                                           'container': '',
                                           'virtualization_tech_guest': set(),
                                           'virtualization_tech_host': ['zone']}



# Generated at 2022-06-11 06:09:07.620908
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-11 06:09:09.965086
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert isinstance(vc, SunOSVirtualCollector)
    assert isinstance(vc._fact_class, SunOSVirtual)

# Generated at 2022-06-11 06:09:11.749311
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:09:18.378076
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.zone import Zone
    from ansible.module_utils.facts.virtual.dmi import Dmi
    from ansible.module_utils.facts.virtual.sysctl import Sysctl

    sc = SunOSVirtualCollector()
    assert sc._platform == 'SunOS'
    assert sc._fact_class == SunOSVirtual
    assert sc._collectors == [Zone, Dmi, Sysctl]

# Generated at 2022-06-11 06:09:24.069187
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict())
    assert virt.virtualization_type == 'zone'
    assert virt.virtualization_role == 'guest'
    assert virt.container == 'zone'
    assert virt.virtual_facts['container'] == 'zone'
    assert virt.virtual_facts['virtualization_type'] == 'zone'
    assert virt.virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:09:33.210437
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    get_virtual_facts() of SunOSVirtual should return a dictionary with the
    following entries:
        virtualization_role: guest
        virtualization_type: vmware
        virtualization_tech_guest: set(['vmware'])
        virtualization_tech_host: set(['zone'])
    """
    from ansible.module_utils.facts.virtual import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    # Build our own fake module.
    module = type('FakeModule', (object,), {})
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    result = SunOSVirtual(module).get_virtual_facts()


# Generated at 2022-06-11 06:09:35.090261
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector('module')

# Generated at 2022-06-11 06:09:36.561808
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:09:37.589600
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

# Generated at 2022-06-11 06:10:02.991549
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    l = SunOSVirtualCollector()
    assert l.platform == 'SunOS'

# Generated at 2022-06-11 06:10:11.952138
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_name = 'ansible.module_utils.facts.virtual.sunos.virtinfo'
    get_bin_path_name = 'ansible.module_utils.facts.virtual.base.get_bin_path'
    run_command_name = 'ansible.module_utils.facts.virtual.base.run_command'
    module_mock = MagicMock()
    get_bin_path_mock = MagicMock(side_effect = lambda arg: arg)
    run_command_mock = MagicMock(return_value = (0, '', ''))

# Generated at 2022-06-11 06:10:14.411287
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class is not None
    assert vc._platform is not None

# Generated at 2022-06-11 06:10:16.604554
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import pytest
    assert 'SunOSVirtual' == SunOSVirtualCollector()._fact_class.__name__

# Generated at 2022-06-11 06:10:26.092716
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    out = """
    nz d 0 0
    unix d 1 1
    nemesis d 1 2
    lo0 d 2 3
    lo0:1 d 2 4
    lo0:2 d 2 5
    lo0:3 d 2 6
    lo0:4 d 2 7
    lo0:5 d 2 8
    lo0:6 d 2 9
    lo0:7 d 2 10
    """
    sunosvirtual = SunOSVirtual(None, 'solaris', out.splitlines())
    assert sunosvirtual is not None

# Generated at 2022-06-11 06:10:27.195793
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector([])
    assert x._platform == 'SunOS'

# Generated at 2022-06-11 06:10:29.135685
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-11 06:10:39.910700
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = SunOSVirtualCollector(None)

    zonename = module.module.get_bin_path('zonename')
    modinfo = module.module.get_bin_path('modinfo')
    virtinfo = module.module.get_bin_path('virtinfo')

    def run_command(cmd):
        return 0, '', ''

    module.module.run_command = run_command
    module.module.get_bin_path = lambda x: '/usr/sbin/' + x

    cmd = '/usr/sbin/' + zonename

    class mock_zonename:
        def __init__(self, module):
            pass

        def run_command(self, cmd):
            return 0, 'global', ''

    zonename_class = mock_zonename(module.module)
    module.module

# Generated at 2022-06-11 06:10:41.885361
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_facts = SunOSVirtualCollector()
    assert sunos_facts._platform == 'SunOS'

# Generated at 2022-06-11 06:10:44.383669
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    assert isinstance(x, VirtualCollector)


# Generated at 2022-06-11 06:11:40.777230
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    os.environ['PATH'] = '/bin:/usr/bin'
    a = SunOSVirtual(dict(module=dict(run_command=None)))
    assert a
    assert a.platform == 'SunOS'



# Generated at 2022-06-11 06:11:42.370030
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts is not None

# Generated at 2022-06-11 06:11:43.364373
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Tests are not run on SunOS
    pass

# Generated at 2022-06-11 06:11:53.177844
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pytest
    import sys

    if sys.version_info[0] == 2:
        pytest.skip("can't run on python2")

    import ansible.module_utils.facts.virtual.sunos as sunos
    Virtual = sunos.SunOSVirtual

    module = object()
    module.get_bin_path = lambda x: 'zonename'
    module.run_command = lambda x: (0, 'global', None)

    h = Virtual(module)
    ret = h.get_virtual_facts()
    assert ret == {'virtualization_tech_host': {'zone'}}

    module.run_command = lambda x: (0, 'non-global', None)
    h = Virtual(module)
    ret = h.get_virtual_facts()

# Generated at 2022-06-11 06:11:55.873062
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector(None, {}, {}, {})
    assert facts_collector.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-11 06:11:58.496332
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector =  SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:12:03.761665
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual('module')
    assert virtual.platform == 'SunOS'
    assert virtual._platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()
    assert virtual.container is None

# Generated at 2022-06-11 06:12:10.434152
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Just make an instance of SunOSVirtualCollector
    """
    instance = SunOSVirtualCollector()

    assert(instance.__class__.__name__ == 'SunOSVirtualCollector')
    assert(instance.__class__.__name__ == SunOSVirtualCollector.__name__)
    assert(instance.__class__.__module__ == 'ansible.module_utils.facts.virtual.sunos')
    assert(instance.__class__.__module__ == SunOSVirtualCollector.__module__)

# Generated at 2022-06-11 06:12:17.662540
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtualization_facts = {}
    facts_list = ['virtualization_role', 'virtualization_type', 'container']

    # Test virtualization role as 'guest' and virtualization type as 'zone'
    module = SunOSVirtual({
        'command': "zonename | grep -xq 'global' || echo ''"
    })
    module._module = {"command": "zonename | grep -xq 'global' || echo ''"}

    virtualization_facts = module.get_virtual_facts()
    assert virtualization_facts.keys() == {'virtualization_role', 'virtualization_type', 'container', 'virtualization_tech_guest', 'virtualization_tech_host'}
    assert virtualization_facts['container'] == 'zone'
    assert virtualization_facts['virtualization_type'] == 'zone'
    assert virtualization

# Generated at 2022-06-11 06:12:27.918462
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    x = SunOSVirtual({})
    x.module.run_command = lambda *args, **kwargs: (0, '', '')
    x.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/%s' % args[0]
    facts = x.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_role'] == 'host'

    x = SunOSVirtual({})
    x.module.run_command = lambda *args, **kwargs: (0, 'global', '')
    x.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/%s' % args[0]

# Generated at 2022-06-11 06:13:51.060125
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts.virtual import SunOSVirtual
    module = sys.modules['ansible'].ModuleUtils.Facts.SunOSVirtual
    module.sunos_virtual_facts = {}
    module.get_bin_path = lambda x: '/bin/' + x
    module.run_command = lambda x: (0, 'vmware', '')
    module.get_file_content = lambda x: '/bin/kvm'
    virtual_facts = SunOSVirtual().get_virtual_facts()

# Generated at 2022-06-11 06:13:59.377175
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Function 'run_command' of module_utils.facts.virtual.sunos.SunOSVirtualCollector is mocked
    # as it is not possible to test it properly, calling command '/usr/sbin/smbios'
    # which is machine specific
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual import (SMBios_Dump, SunOSVirtual)
    import sys
    import unittest
    import mock
    import os

    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

    class SMBios():
        def parse(self):
            return False


# Generated at 2022-06-11 06:14:09.256127
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mock_module = MockModule({})
    mock_module.get_bin_path.side_effect = lambda x: False
    mock_module.run_command.side_effect = lambda x: (0, "", "")

    sunos_virtual = SunOSVirtual(mock_module)
    assert sunos_virtual.platform == 'SunOS'

    # Overwrite the class variable with an empty dictionary.
    # The get_virtual_facts() method should set the dictionary to the
    # expected values.
    sunos_virtual.facts = {}

# Generated at 2022-06-11 06:14:18.203709
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test case 1: zone as a zone
    module = AnsibleModuleMock({})
    virtual = SunOSVirtual(module)
    virtual.module.run_command = run_command_mock
    virtual.module.run_command.side_effect = [
        (0, "global", ""),
        (0, "zone", ""),
        (0, "zoneid: 0", ""),
        (0, "brand: native", ""),
        (0, "brand: native", ""),
    ]
    virtual.module.get_bin_path = get_bin_path_mock
    virtual.module.get_bin_path.return_value = True
    virtual.container = None
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'

    # Test case 2

# Generated at 2022-06-11 06:14:28.313597
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    module.params['file_exists'] = dict()
    module.params['get_bin_path'] = dict()

    # Create a mock for each function of commands.get_bin_path
    module.get_bin_path = MagicMock(side_effect=mocked_get_bin_path)

    # Create a mock for function os.path.exists that returns False by default.
    # os.path.exists is used in several if statements of get_virtual_facts.
    # Each test will change the return value as needed.
    module.file_exists = MagicMock(return_value=False)

    # Create a mock for function module.run_command that returns (0, '', '') by default

# Generated at 2022-06-11 06:14:32.739549
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    sys.path.append("../..")
    from ansible.module_utils.facts.virtual.test_virtual import TestAnsibleModule
    from ansible.module_utils.facts.virtual.sunos.test_facts import get_test_vars
    TestAnsibleModule.get_test_module(SunOSVirtual.get_virtual_facts,get_test_vars())

# Generated at 2022-06-11 06:14:34.612399
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    o = SunOSVirtualCollector()
    assert isinstance(o, SunOSVirtualCollector)

# Generated at 2022-06-11 06:14:36.128267
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts._platform == 'SunOS'
    assert facts.get_virtual_facts() is None
    assert facts.get_virtual_subclasses() is None

# Generated at 2022-06-11 06:14:44.994103
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Class constructor for SunOSVirtual
    """
    module = type('AnsibleModule', (object,), {})
    module.run_command = lambda *args, **kwargs: (1, "", "error")
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/bin/false')
    setattr(module, 'get_fqdn', lambda *args, **kwargs: 'example.com')
    setattr(module, 'exit_json', lambda *args, **kwargs: None)
    setattr(module, 'fail_json', lambda *args, **kwargs: None)
    sunos_virtual = SunOSVirtual(module=module)

    assert sunos_virtual.get_virtual_facts()["virtualization_type"] == 'zone'

# Generated at 2022-06-11 06:14:47.004265
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == "SunOS"
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:17:10.421865
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual


# Generated at 2022-06-11 06:17:12.161867
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(module=None))
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:17:18.616221
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test on a global zone
    module = MockAnsibleModule()
    module.run_command.side_effect = (
        (0, "/bin/zonename\nglobal\n", ""),  # zonename
        (0, "", ""),  # modinfo
        (1, "", ""),  # virtinfo
        (0, "", "")   # smbios
    )
    module.get_bin_path.side_effect = (
        "/bin/zonename",  # zonename
        None,  # modinfo
        None,  # virtinfo
        None   # smbios
    )
    module.isdir.return_value = False

    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {}

    # Test on a