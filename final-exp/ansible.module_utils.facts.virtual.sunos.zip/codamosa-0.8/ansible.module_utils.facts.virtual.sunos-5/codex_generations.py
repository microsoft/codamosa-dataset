

# Generated at 2022-06-11 06:07:42.863592
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual()
    assert s.platform == 'SunOS'
    assert s.virtualization_type == None
    assert s.virtualization_role == None
    assert s.container == None
    assert s.virtualization_tech_guest == set()
    assert s.virtualization_tech_host == set()

# Generated at 2022-06-11 06:07:47.131132
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('MockModule', (object,), {'get_bin_path': lambda x: os.path.exists('/usr/sbin/') and '/usr/sbin/' + x or False})()
    virt_facts = SunOSVirtual(module)
    assert virt_facts.platform == 'SunOS'

# Generated at 2022-06-11 06:07:48.110350
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:07:54.475360
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # The data returned from get_virtual_facts on a Solaris host
    # (Taken from a Solaris 11.3 host)
    vdata = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_host': set(['zone']),
        'virtualization_tech_guest': set(['vmware', 'zone'])
    }

    sunosvirt = SunOSVirtual(None)
    assert(sunosvirt.get_virtual_facts() == vdata)

# Generated at 2022-06-11 06:07:56.078133
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)



# Generated at 2022-06-11 06:08:03.709741
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import ansible.module_utils.facts.virtual.sunos as sunos_virtual
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    obj = sunos_virtual.SunOSVirtualCollector()
    assert isinstance(obj, sunos_virtual.SunOSVirtualCollector)
    assert isinstance(obj, BaseFactCollector)
    assert isinstance(obj.platform, str)
    assert isinstance(obj.fact_class, Virtual)

# Unit tests for SunOSVirtual class

# Generated at 2022-06-11 06:08:06.007409
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  c = SunOSVirtualCollector()
  assert c.platform == 'SunOS'
  assert c._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:08.466873
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'



# Generated at 2022-06-11 06:08:10.990860
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    obj = SunOSVirtualCollector()
    obj2 = Collector()
    assert isinstance(obj, Collector)

# Generated at 2022-06-11 06:08:12.075975
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual


# Generated at 2022-06-11 06:08:26.945593
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == "SunOS"
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:31.418838
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test with no info
    test_virtual = SunOSVirtual(dict())
    assert test_virtual.data == dict()

    # Test with info
    test_virtual = SunOSVirtual(dict(virtualization_type='something'))
    assert test_virtual.data == dict(virtualization_type='something')


# Generated at 2022-06-11 06:08:41.160461
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.SunOSVirtual import SunOSVirtual

    vs = SunOSVirtual({}, True)

    # Test if get_virtual_facts method fails if virtinfo is missing
    vs._module.run_command = lambda x: (1, '', 'virtinfo can only be run from the global zone')
    assert({} == vs.get_virtual_facts())

    # Test if get_virtual_facts method fails if modinfo is missing
    vs._module.run_command = lambda x: (1, '', '')
    assert({} == vs.get_virtual_facts())

    # Test if get_virtual_facts method fails if zone is missing
    vs._module.run_command = lambda x: (1, '', '')
    vs._module.get_bin_path = lambda x: None

# Generated at 2022-06-11 06:08:42.001037
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual({}, None)
    assert m.platform == 'SunOS'

# Generated at 2022-06-11 06:08:42.845365
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

# Generated at 2022-06-11 06:08:46.199196
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Not a lot goes on in the constructor, but we need to make sure that the
    # required platform is set for the class
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:08:56.699482
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    from distutils.version import LooseVersion
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Check for zones
    # ---------------
    # Zone type: Global
    # Expect:
    # - a dict with a key 'virtualization_tech_host' set to {'zone'}
    # - a dict with a key 'virtualization_tech_guest' set to set()
    # - a dict with a key 'virtualization_type' set to None
    # - a dict with a key 'virtualization_role' set to None
    mock_module = MockModule({'zonename': 'global'})
    virtual = SunOSVirtual(mock_module)
    assert {'virtualization_tech_host': {'zone'}} == virtual.get_virtual_facts()
    # Zone

# Generated at 2022-06-11 06:08:59.211302
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)

# Generated at 2022-06-11 06:09:01.353609
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos._fact_class == SunOSVirtual
    assert sunos._platform == 'SunOS'

# Generated at 2022-06-11 06:09:06.668058
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS', "Platform is %s instead of SunOS" % facts._platform
    assert facts._fact_class == SunOSVirtual, "Class is %s instead of SunOSVirtual" % facts._fact_class
    assert issubclass(facts._fact_class, Virtual), "Class %s is not subclass of Virtual" % facts._fact_class


# Generated at 2022-06-11 06:09:32.027735
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.__dict__ == {'_fact_class': SunOSVirtual, '_platform': 'SunOS', '_facts_cache': None}

# Generated at 2022-06-11 06:09:34.510775
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    input_class = {'platform': 'SunOS'}
    obj = SunOSVirtualCollector(input_class)
    assert isinstance(obj, SunOSVirtualCollector)

# Generated at 2022-06-11 06:09:36.033459
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector()
    assert virtual_facts.default_collectors == [SunOSVirtual()]

# Generated at 2022-06-11 06:09:43.915824
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
  # SunOSVirtual.get_virtual_facts() should return a dictionary with the
  # following keys: container, virtualization_type, virtualization_role,
  # virtualization_tech_guest, virtualization_tech_host
  obj = SunOSVirtual()
  expected_virtual_facts = {'container': 'zone',
                            'virtualization_type': 'zone',
                            'virtualization_role': 'guest',
                            'virtualization_tech_guest': set(['zone']),
                            'virtualization_tech_host': set([])}
  assert expected_virtual_facts == obj.get_virtual_facts()

# Generated at 2022-06-11 06:09:46.863416
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class Mock(object):
        pass
    X = SunOSVirtualCollector(Mock(), None)
    assert X._platform == 'SunOS'
    assert X._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:09:48.247619
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_object = SunOSVirtual()
    assert test_object.platform == 'SunOS'

# Generated at 2022-06-11 06:09:50.415001
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # test for expected values
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-11 06:09:54.908030
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 06:10:05.509662
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    result = collector.fetch_all()

    assert result is not None, \
        'The result dict of fetch_all method of SunOSVirtualCollector class ' + \
        'should not be empty'

    assert 'virtualization_tech_guest' in result, \
        'The result dict of fetch_all method of SunOSVirtualCollector class ' + \
        'should contain the virtualization_tech_guest key'

    assert 'virtualization_tech_host' in result, \
        'The result dict of fetch_all method of SunOSVirtualCollector class ' + \
        'should contain the virtualization_tech_host key'


# Generated at 2022-06-11 06:10:08.800852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test to assure that the constructor of class SunOSVirtualCollector works as expected.
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:42.624554
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = MockModule({'load_file': {'output': ' DOMAINROLE|impl=LDoms|control=true|io=true|service=false|root=false\n'}})
    module.get_bin_path = lambda i: '/usr/sbin/virtinfo'
    module.run_command = lambda cmd: (0, ' DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false\n', '')

    virtual = SunOSVirtual(module)

    assert virtual.get_virtual_facts() == {'container': 'zone', 'virtualization_type': None, 'virtualization_role': 'host (control,io)', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-11 06:10:51.103000
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This test case checks if the method `get_virtual_facts` behaves as expected
    :return: Nothing
    """
    # Define the dictionary to be used for the test case
    ansible_facts = {
      'virtualization_type': '',
      'virtualization_role': '',
      'container': '',
      'virtualization_tech_guest': {'zone', 'vmware'},
      'virtualization_tech_host': {'zone'},
    }

    # Instantiate the module
    module = MagicMock()
    module.run_command.return_value = ("0", "VMware", "")
    module.get_bin_path.return_value = "/usr/sbin/virtinfo"

    # Instantiate the `SunOSVirtual` class
    t = SunOSVirtual(module)



# Generated at 2022-06-11 06:10:53.145852
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual({})
    facts = virtual.get_virtual_facts()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts

# Generated at 2022-06-11 06:10:57.190368
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class TestModule:

        def __init__(self):
            self.exit_json = lambda x: x

        @staticmethod
        def get_bin_path(path):
            return path

        @staticmethod
        def run_command(command):
            return 0, '', ''

    fact = SunOSVirtualCollector._fact_class('testmodule')
    fact.get_virtual_facts()

# Generated at 2022-06-11 06:11:07.339635
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mod = FakeAnsibleModule()
    virtual = SunOSVirtual(module=mod)

    # Set fake zonename and modinfo commands to return the right result
    mod.run_command = FakeAnsibleModuleRunCommand(
        {'zonename': {'rc': 0, 'out': 'zone1'},
         'modinfo': {'rc': 0,
                     'out': (
                         'ident: "vmw_ahci"   class: "misc"   '
                         'description:    "AHCI SATA v4"\n'
                         'ident: "vmw_vmci"   class: "misc"   '
                         'description:    "VMCI Sockets"')}})

# Generated at 2022-06-11 06:11:08.562432
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos._platform == 'SunOS'

# Generated at 2022-06-11 06:11:09.814846
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'

# Generated at 2022-06-11 06:11:11.667190
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test SunOSVirtualCollector class constructor"""
    collector = SunOSVirtualCollector()
    assert collector.platform == SunOSVirtualCollector._platform

# Generated at 2022-06-11 06:11:13.180209
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert(virtual_facts._platform == 'SunOS')

# Generated at 2022-06-11 06:11:17.305949
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mymodule = type('module', (object,), {})()
    setattr(mymodule, 'get_bin_path', lambda x: '/some_path')
    setattr(mymodule, 'run_command', lambda x: ('', '', ''))

    v = SunOSVirtual(module=mymodule)

    virtual_facts = v.get_virtual_facts()
    assert virtual_facts == {}


# Generated at 2022-06-11 06:12:06.950852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:12:09.073616
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """This is a test for the constructor of class SunOSVirtualCollector"""
    x = SunOSVirtualCollector()
    assert x.exists() == True

# Generated at 2022-06-11 06:12:11.580212
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    # initialize object for immediate use
    SunOSVirtualCollector()


# Generated at 2022-06-11 06:12:12.937631
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunOSVirtualCollector = SunOSVirtualCollector()
    assert sunOSVirtualCollector is not None

# Generated at 2022-06-11 06:12:22.011012
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value=True)
    sunos_virtual = SunOSVirtual(module=module)

    # Run 1: Zone
    module.run_command.return_value = (0, 'global', '')
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert 'container' in virtual_facts and virtual_facts['container'] == 'zone'
    assert 'virtualization_tech_guest' in virtual_facts and 'zone' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:12:24.369706
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    instance = SunOSVirtual('ansible.module_utils.facts.virtual.sunos')
    assert isinstance(instance, SunOSVirtual)

# Generated at 2022-06-11 06:12:33.136934
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_obj = SunOSVirtual({})
    test_obj.module = MagicMock()

    # set up the test_obj.module.run_command mock
    test_obj.module.run_command.return_value = (0, 'test_zonename_out', 'test_zonename_err')

    # set up the /proc/vz symlink mock
    test_obj.isfile = MagicMock(return_value=False)
    test_obj.islink = MagicMock(return_value=True)
    test_obj.readlink = MagicMock(return_value='/proc/vz/test_readlink')

    # set up the test_obj.module.get_bin_path mock

# Generated at 2022-06-11 06:12:38.833324
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    facts_collector = BaseFactCollector()
    virtual_collector = SunOSVirtualCollector(facts_collector)
    virtual_collector._populate()
    SunOSVirtual_instance = virtual_collector._fact_instances[0]
    virtual_facts = SunOSVirtual_instance.get_virtual_facts()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert type(virtual_facts['virtualization_type']) in [str, type(None)]
    assert 'virtualization_role' in virtual_facts
    assert type(virtual_facts['virtualization_role']) in [str, type(None)]

# Generated at 2022-06-11 06:12:42.146345
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts_obj = SunOSVirtual(dict())
    expected_platform = 'SunOS'
    actual_platform = facts_obj.platform
    assert actual_platform == expected_platform


# Generated at 2022-06-11 06:12:43.275995
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector

# Generated at 2022-06-11 06:14:42.598730
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    print()
    if os.uname()[0] != 'SunOS':
        print('Skipping SunOS tests due to platform')
    else:
        print('SunOSVirtual test')

        v = SunOSVirtual()
        facts = v.get_virtual_facts()
        print(facts)

# Generated at 2022-06-11 06:14:43.862943
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.platform == SunOSVirtual.platform

# Generated at 2022-06-11 06:14:45.835066
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class is SunOSVirtual

# Generated at 2022-06-11 06:14:57.061202
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import Facts
    import ansible_collections.ansible.community.tests.unit.modules.utils as testutils

    module = testutils.get_module_mock()
    module.get_bin_path = lambda _: to_bytes("/bin/true")

    sunos_virtual = SunOSVirtual(module)
    sunos_virtual.get_virtual_facts()

# Generated at 2022-06-11 06:15:05.353220
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    _test_module = 'ansible.module_utils.facts.virtual.test_virtual'
    _test_module_path = os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.path.pardir, os.path.pardir, os.path.pardir, os.path.pardir, os.path.pardir, 'lib', _test_module + '.py'))

    if os.path.exists(_test_module_path):
        module = __import__(_test_module)

# Generated at 2022-06-11 06:15:14.794763
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test virtual and virtual_subtype in class SunOSVirtual
    """
    # Constructor of class SunOSVirtual uses subprocess.Popen to execute shell commands
    # Shell commands will not be executed from unit test and therefore we will test if
    # subprocess.Popen was called
    # The function get_virtual_facts of class SunOSVirtual overrides the function of the
    # super class and therefore we will test it here
    # The constructor of class SunOSVirtual uses the super constructor and therefore
    # we need to call it to make sure that the super class is up to date
    # In Python 2 super without arguments is not allowed and therefore we need to pass
    # self as argument
    # We will use the unittest library to test the constructor and the get_virtual_facts
    # function
    assert SunOSVirtual(None).get_virtual_facts

# Generated at 2022-06-11 06:15:23.627174
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    from ansible.module_utils._text import to_bytes
    import platform

    module = type('', (), {})()
    module.get_bin_path = lambda x: x

# Generated at 2022-06-11 06:15:25.352139
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:15:27.848823
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:15:33.218822
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'
    virtual_facts = {'container': 'zone',
                     'virtualization_role': 'guest',
                     'virtualization_type': 'vmware',
                     'virtualization_tech_guest': set(['zone', 'vmware']),
                     'virtualization_tech_host': set(['zone'])}
    virtual = SunOSVirtual({'ansible_facts': {'virtual': virtual_facts}})
    assert virtual.facts == virtual_facts