

# Generated at 2022-06-11 06:07:47.185703
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test SunOSVirtual.get_virtual_facts()
    """
    # Mock the module
    class ModuleDouble():
        def __init__(self):
            self.run_command_called = False
        def get_bin_path(self, path):
            return path
        def run_command(self, cmd):
            if cmd == "zonename":
                self.run_command_called = True
                return 0, "global", ""
            elif cmd == "virtinfo -p":
                # The output contains multiple lines with different keys like this:
                #   DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
                self.run_command_called = True

# Generated at 2022-06-11 06:07:48.969740
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:07:56.847308
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class SunOSVirtual
    '''
    # No zone but zone binary exists
    module = Mock(run_command=Mock(return_value=(0, 'global', '')))
    module.get_bin_path = Mock(return_value='/usr/sbin/zonename')
    module.get_tmp_path = Mock()
    module.get_bin_path = Mock()
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_tech_host': set(['zone']),
        'virtualization_tech_guest': set()
    }

    # No zone and no zone binary

# Generated at 2022-06-11 06:07:58.880302
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector is not None


# Generated at 2022-06-11 06:08:07.357762
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    virtual = SunOSVirtual(module)

    # Test case:  Check if it's a zone
    virtual.module.get_bin_path.return_value = True
    virtual.module.run_command.return_value = (0, 'foo', '')
    assert virtual.get_virtual_facts() == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['zone']),
        'container': 'zone',
        }

    # Test case:  Check if it's branded zone (i.e. Solaris 8/9 zone)
    virtual.module

# Generated at 2022-06-11 06:08:17.151586
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    if not HAS_SUNOS_MODULE:
        module.fail_json(msg="sunos module is required")

    # Create instance of SunOSVirtual
    my_obj = SunOSVirtual(module)
    virtual_facts = my_obj.get_virtual_facts()

    # Check values of virtual_facts
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:08:26.948101
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Unit test for method get_virtual_facts of class SunOSVirtual
    # Test 'zone'
    module = FakeAnsibleModule(zone_rc=0,zone_out='zone')
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get_virtual_facts()
    assert_equals('zone',facts['container'])

    # Test 'branded zone'
    module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get_virtual_facts()
    assert_equals('zone',facts['container'])

    # Test 'global zone'
    module = FakeAnsibleModule(zone_rc=0,zone_out='global')
    sunos_virtual = SunOSVirtual(module)

# Generated at 2022-06-11 06:08:37.445458
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    facts_obj = SunOSVirtual(module)
    # Default facts
    assert facts_obj.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Zone facts
    module.run_command = lambda x: (0, 'out', '') if x == "/usr/sbin/zonename" else None
    assert facts_obj.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['zone'])
    }

    # Zone facts
    module

# Generated at 2022-06-11 06:08:43.657214
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = Mock(name='module_mock')
    module_mock = Mock(name='module_mock')
    module_mock.run_command.return_value = (0, 'global', '')
    module_mock.get_bin_path.return_value = "/bin/true"

    sunosvirtual = SunOSVirtual(module_mock)
    sunosvirtual.get_virtual_facts()
    assert sunosvirtual.virtualization_tech_host == set(['zone'])
    assert sunosvirtual.virtualization_tech_guest == set()

# Generated at 2022-06-11 06:08:47.639482
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    assert facts['virtualization_tech_host'] == {'zone'}
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_type'] == 'zone'


# Mock class for unit testing.  There's no need to mock the get_bin_path method because it's implemented in the super class

# Generated at 2022-06-11 06:09:01.728500
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:09:04.629915
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_collector = SunOSVirtualCollector()
    assert isinstance(virtual_collector._fact_class, SunOSVirtual)
    assert virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:09:13.354205
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import json
    import platform
    import sys

    if sys.version_info[0] >= 3:
        unicode = str

    facts_dict = {
        'ansible_facts': {
            'virtualization_type': None,
            'virtualization_role': None,
            'container': None,
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        },
    }
    facts_dict_zone_guest = {
        'ansible_facts': {
            'virtualization_type': None,
            'virtualization_role': None,
            'container': 'zone',
            'virtualization_tech_guest': {'zone'},
            'virtualization_tech_host': set(),
        },
    }
    facts_dict_vmware_guest

# Generated at 2022-06-11 06:09:17.508270
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector('dummy')
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:09:24.474157
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'zone', 'vmware'}
    assert virtual_facts['virtualization_tech_host'] == {'zone'}


# Generated at 2022-06-11 06:09:25.994800
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert not hasattr(v, 'platform')
    assert not isinstance(v.module, object)

# Generated at 2022-06-11 06:09:31.536730
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(dict())

    v = SunOSVirtual(module)
    assert v.get_virtual_facts() is None

    v._module.run_command.return_value = (0, "global", "")
    assert v.get_virtual_facts() is not None

    v._module.run_command.return_value = (0, "fakezone", "")
    assert v.get_virtual_facts() is not None

# Generated at 2022-06-11 06:09:38.734436
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test the constructor of class SunOSVirtual.
    This test is specific for the SunOS platform.
    It checks that the Virtual class correctly defines the virtualization_type, virtualization_role and container facts.
    """
    # Initialize class
    v = SunOSVirtual({})
    # Check that nb_cpu is set
    assert 'virtualization_type' in v.facts
    assert 'virtualization_role' in v.facts
    assert 'container' in v.facts
    assert 'virtualization_tech_guest' in v.facts
    assert 'virtualization_tech_host' in v.facts

    # Check that virtualization_type is set to vmware
    os.environ["ANSIBLE_VMWARE"] = "1"
    v = SunOSVirtual({})

# Generated at 2022-06-11 06:09:44.427117
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule({})

    instance = SunOSVirtual(module)

    facts = instance.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set()
    assert facts['container'] == 'zone'


# Generated at 2022-06-11 06:09:47.002517
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fc = SunOSVirtualCollector()
    assert fc.platform == 'SunOS'
    assert issubclass(fc.fact_class, SunOSVirtual)

# Generated at 2022-06-11 06:10:20.823199
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Case 1 - a system without virtualization
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = [None, '/usr/sbin/modinfo']
    module.run_command.side_effect = [
        (0, 'global', ''),
        (1, '', 'virtinfo: not found'),
        (0, '', ''),
    ]
    facts = SunOSVirtual(module).get_virtual_facts()
    assert not facts

    # Case 2 - a zone on a virtual host
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = [None, '/usr/sbin/modinfo', '/usr/sbin/zonename']
    module.run_

# Generated at 2022-06-11 06:10:22.109886
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == 'SunOS'

# Generated at 2022-06-11 06:10:23.573247
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)


# Generated at 2022-06-11 06:10:25.405820
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_obj = SunOSVirtualCollector()
    assert facts_obj._fact_class is SunOSVirtual
    assert facts_obj._platform == 'SunOS'


# Generated at 2022-06-11 06:10:26.553645
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector().collect()
    assert 'virtualization_type' in facts

# Generated at 2022-06-11 06:10:29.135619
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virt_facts = SunOSVirtual(module)
    assert virt_facts.system == "SunOS"



# Generated at 2022-06-11 06:10:35.554532
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module_name = 'ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector'
    c = SunOSVirtualCollector(None, None, None)
    assert c._fact_class.__name__ == 'SunOSVirtual'
    assert c._platform == 'SunOS'
    assert c._module_name == module_name
    assert c._file_name == 'ansible_virtual.fact'


# Generated at 2022-06-11 06:10:45.513543
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # test case 1
    m = type('MockModule', (object,), {})()
    m.run_command = Mock(return_value=(0, 'global\n', ''))
    m.get_bin_path = Mock(return_value='/usr/bin/zonename')
    v = SunOSVirtual(module=m)
    v.get_virtual_facts()
    assert 'zone' in v.facts['virtualization_tech_host']
    assert 'zone' not in v.facts['virtualization_tech_guest']
    assert 'container' not in v.facts

    # test case 2
    m = type('MockModule', (object,), {})()
    m.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-11 06:10:47.761514
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class._platform == 'SunOS'

# Generated at 2022-06-11 06:10:53.708199
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Build module object
    module = MockModule()

    # Build module-like object to call get_virtual_facts
    class Module(object):
        pass
    task = Module()
    task.module = module

    # Call get_virtual_facts
    virtual = SunOSVirtual(task)
    virtual_facts = virtual.get_virtual_facts()

    # Backend-specific tests
    if virtual_facts['virtualization_type'] == 'zone':
        assert virtual_facts['virtualization_role'] in ('guest', 'host')
        assert virtual_facts['virtualization_tech_guest'] == set(['zone'])

# Generated at 2022-06-11 06:11:21.499848
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, dict)

# Generated at 2022-06-11 06:11:27.361618
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'container': ''
    }

    for fact in expected_facts:
        assert virtual.data.get(fact) == expected_facts[fact]

# Generated at 2022-06-11 06:11:28.716727
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual._platform == 'SunOS'

# Generated at 2022-06-11 06:11:31.794451
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec = dict())
    if not module.check_mode:
        module.exit_json(**SunOSVirtual.get_virtual_facts(module))


# Generated at 2022-06-11 06:11:36.074150
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """This function returns a SunOSVirtualCollector object with
    the correct platform and fact class assigned to it.
    """

    sunos_collector = SunOSVirtualCollector()

    assert sunos_collector.platform == 'SunOS'
    assert sunos_collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:11:39.936674
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Unit test for SunOSVirtual."""
    virtual = SunOSVirtual()
    assert virtual.virtualization_type == (
        {'virtualization_type': 'virtualbox',
         'virtualization_role': 'guest',
         'container': 'zone',
         'virtualization_tech_guest': {'zone', 'virtualbox'},
         'virtualization_tech_host': {'zone'}}
    )

# Generated at 2022-06-11 06:11:42.649313
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:11:43.995946
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    TODO: Unit test not implemented yet
    '''
    pass

# Generated at 2022-06-11 06:11:53.079940
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Mock()
    module.run_command = Mock(return_value=(0, "global", ""))
    module.get_bin_path = Mock(side_effect=lambda x: x)
    module.run_command = Mock(side_effect=lambda x: (0, "", ""))
    module.get_bin_path = Mock(side_effect=lambda x: x)

    sunos = SunOSVirtual(module)
    virtual_facts = sunos.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'host'
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'zone' not in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:11:54.161238
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:12:21.026655
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:12:30.549467
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Check whether facts are assigned correctly
    #
    # A sample of the virtualization output that could be generated on a host can be found here:
    # https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/virtual/sunos.py

    class FakeModule(object):
        def get_bin_path(self, arg):
            if arg in ('zonename', 'smbios'):
                return arg
            else:
                return ''

        def run_command(self, arg):
            if arg == "zonename":
                return 0, "testzone", ""
            elif arg == "smbios":
                return 0, "Vendor: VMware\nVirtualBox", ""

# Generated at 2022-06-11 06:12:37.194642
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of the SunOSVirtual class
    virtual_facts = SunOSVirtual({})
    # Make sure we're on a SunOS system
    virtual_facts.module.get_distribution = lambda: "SunOS"
    # Create a fake virtual fact (to avoid using the actual value collected)
    virtual_facts.module.get_bin_path = lambda _: "/some/path"
    # Mock the system calls to get facts
    virtual_facts.module.run_command = lambda cmd: (0, "", "")
    # Check that we get the expected virtualizationfacts
    assert virtual_facts.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                 'virtualization_tech_guest': set()}

# Generated at 2022-06-11 06:12:39.023133
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    fact = SunOSVirtual(module)
    assert fact.platform == 'SunOS'


# Generated at 2022-06-11 06:12:41.573498
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    virtual_facts.get_virtual_facts()
    assert not virtual_facts.facts

# Generated at 2022-06-11 06:12:51.141472
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import Collector, Facts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    import sys

    # check if the constructor returns an instance of SunOSVirtualCollector
    collector = SunOSVirtualCollector(module=None)
    assert isinstance(collector, SunOSVirtualCollector)

    # check if the instance of SunOSVirtualCollector is derived from VirtualCollector class
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

    # check if the instance of SunOSVirtualCollector is derived from Collector class
    assert issubclass(type(collector), Collector)

    # check if the instance of SunOSVirtualCollector has an appropriate _platform attribute

# Generated at 2022-06-11 06:12:57.583132
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import MagicMock, patch
    # Avoid cache, force get_virtual_facts() to gather facts
    with patch.dict(SunOSVirtual.platform_virtual_facts, {}):
        # Get a SunOSVirtual instance
        SV = SunOSVirtual({})
        # Prepare mocks
        SV.module = MagicMock()

# Generated at 2022-06-11 06:12:58.714924
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:12:59.821289
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj is not None

# Generated at 2022-06-11 06:13:01.134149
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == "SunOS"


# Generated at 2022-06-11 06:13:42.517106
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = DummyModule()
    collector = SunOSVirtualCollector(module)

    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual


# Generated at 2022-06-11 06:13:53.105500
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a Virtual class object and assign it to a variable
    virtual = SunOSVirtual()

    # Test 1: unit test for get_virtual_facts method in SunOSVirtual class
    # Input data for testing
    #     VIRTUALIZATION_ROLE is 'guest'
    #     VIRTUALIZATION_TYPE is 'vmware'
    #     IS_CONTAINER is False
    #     VIRTUALIZATION_TECH_HOST is ''
    #     VIRTUALIZATION_TECH_GUEST is 'vmware'
    # Expected results:
    #     virtual_facts is a dictionary
    #     virtual_facts has keys virtualization_role, virtualization_type and virtualization_tech_guest
    #     virtual_facts['virtualization_role'] is 'guest'
    #     virtual_facts['virtual

# Generated at 2022-06-11 06:14:00.389773
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    #
    # 1. Test virtualization_role is set correctly
    #

    # Mock class PathExists
    class PathExists:
        def __init__(self, return_value):
            self.return_value = return_value

        def exists(self, path):
            return self.return_value

    # Mock class Cmd
    class Cmd:
        def __init__(self, return_value):
            self.return_value = return_value

        def rc(self):
            return self.return_value[0]

        def stdout(self):
            return self.return_value[1]

        def stderr(self):
            return self.return_value[2]

    # Mock class Module

# Generated at 2022-06-11 06:14:01.295739
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual()
    assert True

# Generated at 2022-06-11 06:14:06.941188
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # init private class SunOSVirtual
    virtual_provider_name = 'SunOSVirtual'
    virtual_provider_class = SunOSVirtual
    virtual_provider_instance = virtual_provider_class(virtual_provider_name)

    # Run the test
    test_facts = virtual_provider_instance.get_virtual_facts()

    # Assertions
    assert isinstance(test_facts, dict)


# Generated at 2022-06-11 06:14:08.113399
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    v = SunOSVirtual({})
    assert v.platform == 'SunOS'

# Generated at 2022-06-11 06:14:17.598607
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector

    module = AnsibleModule(argument_spec = dict())

    # populate the fact_cache
    facts = {}
    facts['virtualization_type'] = 'openvz'
    facts['virtualization_role'] = 'guest'
    facts['container'] = 'openvz'
    Virtual._fact_cache = facts
    SunOSVirtual._fact_cache = facts
    VirtualCollector._fact_cache = facts

    # The fact_cache is populated
    assert Virtual._fact_cache == facts
    assert SunOSVirtual._fact_cache == facts
    assert VirtualCollector._fact_cache == facts
    # The fact_cache is not empty

# Generated at 2022-06-11 06:14:19.782561
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_inst = SunOSVirtual(dict(), dict())
    assert isinstance(virtual_inst, SunOSVirtual)
    assert isinstance(virtual_inst, Virtual)


# Generated at 2022-06-11 06:14:22.052689
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''Check that the constructor sets the right platform.'''
    sunos_virtual = SunOSVirtual(dict(), '')
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:14:23.287523
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 06:15:31.261690
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    print("Testing SunOSVirtual.get_virtual_facts")

    class MyModule:
        def __init__(self):
            pass

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, msg):
            return 0, '', ''

    class MySunOSVirtual(SunOSVirtual):
        def __init__(self):
            self.module = MyModule()

    virtual_facts = MySunOSVirtual().get_virtual_facts()
    assert virtual_facts == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['zone']),
        'container': 'zone',
    }

    class MyModule:
        def __init__(self):
            pass


# Generated at 2022-06-11 06:15:39.206021
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})

    results = dict()

    # Prepare a class instance to receive calls to mocked methods
    mock_virt = SunOSVirtual(module, results)
    # Mock method calls and return values
    mock_virt.module.run_command.return_value = (0, '', '')

    # Call the method under test
    mock_virt.get_virtual_facts()
    # Check method calls with their parameters and return values
    mock_virt.module.run_command.assert_any_call('zonename')
    mock_virt.module.run_command.assert_any_call('modinfo')
    mock_virt.module.run_command.assert_any_call('virtinfo -p')

    # Assert the results of the method
    assert results['virtualization_tech_guest'] == set()


# Generated at 2022-06-11 06:15:48.447773
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class SunOSVirtual

    The unit test expects a zone called "zone_test" to be present.
    If no zone is found the test is skipped.

    """

    import sys
    if sys.version_info[0] >= 3:
        from unittest.mock import MagicMock, patch
    else:
        from mock import MagicMock, patch

    def run_command_isdir(command):
        if command == 'zonename':
            return 0, "zone_test", ""
        if command == 'modinfo vmware':
            return 0, "", ""
        if command == 'modinfo virtualbox':
            return 0, "", ""

    modinfo_mock = MagicMock(side_effect=run_command_isdir)


# Generated at 2022-06-11 06:15:54.017413
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    v.populate()
    assert isinstance(v.virtual_facts, dict)
    assert v.virtual_facts['virtualization_type'] == 'xen'
    assert v.virtual_facts['virtualization_role'] == 'guest'
    assert v.virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert v.virtual_facts['virtualization_tech_host'] == set([])
    assert v.virtual_facts['container'] is None

# Generated at 2022-06-11 06:15:56.597175
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    base = SunOSVirtualCollector()
    assert base.platform == "SunOS"
    assert base.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:16:03.985248
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Mock class module
    class MockModule:
        def __init__(self):
            self.run_command_value = (0, "", "")
            self.run_command_calls = dict()

        def run_command(self, args):
            if args in self.run_command_calls:
                return self.run_command_calls[args]
            else:
                return self.run_command_value

        def fail_json(self, *args, **kwargs):
            self.called = True

        def get_bin_path(self, arg):
            return None

    # Create instance of class SunOSVirtual
    sunos_virtual = SunOSVirtual()

    # Create an instance of class MockModule
    mock_module = MockModule()

    # Case 1: Check the virtualization type if virtualization technologies are

# Generated at 2022-06-11 06:16:12.027345
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = get_dummy_module()
    x = SunOSVirtual(module)

    # This test is only valid on a SunOS system, but when run in other
    # environments, we just skip it
    if x.platform != 'SunOS':
        return

    x.module.run_command = classmethod(lambda *_: (0, "global", ""))
    x.get_virtual_facts()
    assert (x.virtual_facts['virtualization_tech_host'] == {'zone'})
    assert (x.virtual_facts['container'] == None)
    assert (x.virtual_facts['virtualization_tech_guest'] == set())

    x.module.run_command = classmethod(lambda *_: (0, "foo", ""))
    x.get_virtual_facts()

# Generated at 2022-06-11 06:16:15.298490
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = Fake_ansible_module(
        virtualization_type='zone',
        virtualization_role='host',
        container='zone'
    )
    fact_monitor = SunOSVirtual(module=module)
    print(fact_monitor)
    print(fact_monitor.collect())
    print(fact_monitor.get_virtual_facts())


# Generated at 2022-06-11 06:16:16.609822
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_instance = SunOSVirtual(dict())
    assert isinstance(virtual_instance, SunOSVirtual)



# Generated at 2022-06-11 06:16:17.947490
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.virtinfo == {}
    assert v.platform == 'SunOS'