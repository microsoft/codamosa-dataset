

# Generated at 2022-06-11 06:07:43.328435
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    module = AnsibleModule(argument_spec=dict())
    virt = SunOSVirtual(module)

    # Assert that get_virtual_facts doesn't raise an error
    try:
        virt.get_virtual_facts()
    except Exception as e:
        module.fail_json(msg="Unable to check virtual facts: %s" % to_native(e))

# Generated at 2022-06-11 06:07:46.240870
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v.platform == 'SunOS'
    assert v.fact_class == SunOSVirtual
    assert v.fact_class.platform == 'SunOS'


# Generated at 2022-06-11 06:07:55.433092
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, {}, None).get_virtual_facts()
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'parallels' in virtual_facts['virtualization_tech_guest']
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'kvm' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'virtuozzo' in virtual_facts['virtualization_tech_guest']
    assert 'container' in virtual_facts
    assert 'virtualization_type' in virtual

# Generated at 2022-06-11 06:07:56.809745
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, {})
    assert v.platform == 'SunOS'

# Generated at 2022-06-11 06:07:58.833139
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor test for class SunOSVirtualCollector
    """
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:08:01.028318
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a test class
    test_class = SunOSVirtual()
    # Check the right platform is set
    assert test_class.platform == 'SunOS'

# Generated at 2022-06-11 06:08:08.433053
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return self.bin_path.get(name, None)

        def run_command(self, cmd, check_rc=True):
            command = cmd.split()
            return self.command[command[0]]

    # Test scenario where we're in a zone
    # Here we expect to detect being in a zone but not being virtualized
    bin_path = {}
    bin_path['zonename'] = '/sbin/zonename'
    bin_path['smbios'] = '/usr/sbin/smbios'

# Generated at 2022-06-11 06:08:10.564582
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test the constructor of class SunOSVirtualCollector."""
    assert SunOSVirtualCollector._platform == 'SunOS'


# Generated at 2022-06-11 06:08:14.917787
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = [ '!all', '!any' ]
    module.params['gather_timeout'] = 1
    module.params['filter'] = '*'

    virt_collector = SunOSVirtualCollector(module=module)
    virt_collector.collect()
    virt_facts = virt_collector.get_facts()

    assert virt_facts['virtualization_type'] == 'vmware'
    assert virt_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 06:08:17.072188
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector({})
    assert virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:08:34.486843
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    obj = SunOSVirtualCollector()
    assert obj.platform == "SunOS"
    assert repr(obj._fact_class) == "<class 'ansible.module_utils.facts.virtual.sunos.SunOSVirtual'>"


# Generated at 2022-06-11 06:08:43.404088
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt = SunOSVirtual({})
    # Set up the following facts:
    # - Inside zone
    # - Inside branded zone
    # - With VMware tools installed
    # - With Virtuozzo installation
    # - On a LDoms domain
    # - On a VMware machine
    # - With Parallels SMBIOS
    # - With VirtualBox SMBIOS
    # - With Xen SMBIOS
    # - With KVM SMBIOS
    # - With some SMBIOS
    virt._module.run_command = lambda x: (0, "vmware", "")
    virt._module.get_bin_path = lambda x: x
    virt._module.isdir = lambda x: x == '/.SUNWnative'

    virt.get_virtual_facts = lambda: {}
    virtinfo = virt._module.get_bin_path

# Generated at 2022-06-11 06:08:48.516288
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(
        argument_spec = dict()
    )
    facts_collector = SunOSVirtualCollector(module, 'SunOS', {})
    facts = facts_collector.collect()
    assert facts['virtualization_type'] == 'zone' or 'virtualization_type' in facts
    assert 'virtualization_type' in facts or 'virtualization_tech_guest' in facts or 'virtualization_tech_host' in facts

# Generated at 2022-06-11 06:09:00.012914
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # AnsibleModule class is a little bit overkill I think but I don't see any other
    # way to test its methods without mocking all its methods.
    class AnsibleModule:
        def __init__(self):
            pass

        def get_bin_path(self, name):
            return True

        def run_command(self, cmd):
            return (0, "", "")

    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self):
            self.module = AnsibleModule()

        def get_virtual_facts(self):
            return None

    fact_collector = SunOSVirtualCollector()
    virtual = MockSunOSVirtual()


# Generated at 2022-06-11 06:09:02.526363
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual.__class__.__name__ == 'SunOSVirtualCollector'


# Generated at 2022-06-11 06:09:06.340895
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector().collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:09:13.196527
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    facts_virtual = SunOSVirtual(module)
    assert facts_virtual.get_virtual_facts()['virtualization_type'] == 'ldom'
    assert facts_virtual.get_virtual_facts()['virtualization_role'] == 'host (control)'
    assert facts_virtual.get_virtual_facts()['virtualization_tech_guest'] == set(['zone', 'ldom'])
    assert facts_virtual.get_virtual_facts()['virtualization_tech_host'] == set(['zone'])
    assert facts_virtual.get_virtual_facts()['container'] == 'zone'



# Generated at 2022-06-11 06:09:17.792128
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Dummy test using constructor of class
    """
    c = SunOSVirtualCollector()
    assert c._fact_class == SunOSVirtual
    assert c._platform == 'SunOS'

# Generated at 2022-06-11 06:09:19.340703
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 06:09:21.119946
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:09:37.378638
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts_virtual = SunOSVirtual(None)
    assert facts_virtual.virtualization_type is None
    assert facts_virtual.virtualization_role is None
    assert facts_virtual.container is None

# Generated at 2022-06-11 06:09:40.076612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert isinstance(obj, SunOSVirtualCollector)
    assert isinstance(obj._fact_class, SunOSVirtual)
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 06:09:47.224845
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    virtual = SunOSVirtual(module)

    # global zone
    module.run_command.results = [(0, 'global', '')]
    module.get_bin_path.results = ['/usr/bin/zonename']
    os.path.isdir = FakeOsPathIsDir(False)
    module.run_command.results = [(-1, '', '')]
    facts = virtual.get_virtual_facts()
    assert facts == {
        'virtualization_type': None,
        'virtualization_role': 'host',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set(['zone']),
    }

# Generated at 2022-06-11 06:09:51.678557
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = SunOSVirtual().get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

    assert 'container' in facts
    assert 'virtualization_type_role' in facts

# Generated at 2022-06-11 06:10:01.945128
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # get_virtual_facts when no facts are set in the Virtual class
    module = os.path.realpath(__file__)
    module = os.path.dirname(module)
    module = os.path.dirname(module)
    module = os.path.dirname(module)
    module = os.path.join(module, 'unit', 'module_utils')

    sys.path.insert(0, module)
    from ansible.module_utils.facts import virtual
    v = virtual.Virtual()
    assert v.facts == {}

    # get_virtual_facts when facts for vmware are set in the Virtual class
    v.facts = {'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'container': 'zone'}

# Generated at 2022-06-11 06:10:07.619588
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual()
    assert 'zone' in sunos_virtual.virtualization_tech_host
    assert 'spam' not in sunos_virtual.virtualization_tech_guest
    assert sunos_virtual.virtualization_type == 'spam'
    assert sunos_virtual.virtualization_role == 'spam'
    assert sunos_virtual.container == 'spam'

# Generated at 2022-06-11 06:10:09.165574
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual('ansible.module.get_bin_path')
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-11 06:10:11.311717
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Assign
    collector = SunOSVirtualCollector()
    # Act
    facts = collector.collect()
    # Assert
    assert facts['virtualization_type'] == 'xen'

# Generated at 2022-06-11 06:10:13.714678
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v
    assert v.__class__.__name__ == "SunOSVirtual"


# Generated at 2022-06-11 06:10:24.325515
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
        Unit test for method get_virtual_facts of class SunOSVirtual
        Covers the following cases:
        - Linux running on ESX host
        - Linux running in a VM (VirtualBox)
        - Linux running in a VM (VMware)
        - Linux running in a VM (KVM)
        - Linux running in a container (LXC)
        - Linux running in a container (Docker)
        - Solaris host running LX zone
        - Solaris host running HVM zone (generic Solaris branded zone)
    '''
    import sys
    import os
    from io import StringIO
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    class AnsibleModule:
        def __init__(self):
            self.params = None
            sys.stdout = StringIO()


# Generated at 2022-06-11 06:11:00.082754
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('FakeModule', (object,), {'params': {}})
    fact_collector = SunOSVirtualCollector(module)
    assert fact_collector.facts['virtualization_type'] == 'kvm'
    assert fact_collector.facts['virtualization_role'] == 'guest'
    assert fact_collector.facts['container'] == 'zone'
    assert fact_collector.facts['virtualization_tech_guest'] == set(('vmware', 'virtualbox', 'virtuozzo', 'xen', 'kvm'))
    assert fact_collector.facts['virtualization_tech_host'] == set(('zone',))

# Generated at 2022-06-11 06:11:02.065676
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual({})
    facts = m.get_virtual_facts()
    assert 'virtualization_type' in facts


# Generated at 2022-06-11 06:11:11.227740
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # SunOSVirtual.get_virtual_facts should detect zone on zone and branded zone
    assert SunOSVirtual({}).get_virtual_facts() == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': set(),
    }
    # SunOSVirtual.get_virtual_facts should detect xen domU on M-series

# Generated at 2022-06-11 06:11:18.721883
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Mock()
    module.run_command = Mock()
    module.get_bin_path = Mock(return_value='/bin/false')
    module.run_command.return_value = (1, '', '')
    virtual = SunOSVirtual(module)
    # Should return an empty dict when no commands can be executed
    assert virtual.get_virtual_facts() == {}

    module.get_bin_path = Mock(return_value='/usr/bin/zonename')

# Generated at 2022-06-11 06:11:19.614222
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:11:22.382108
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = dict(systemd=dict(running=True))
    vc = SunOSVirtualCollector(virtual_facts=virtual_facts)
    return vc.get_facts()

# Generated at 2022-06-11 06:11:25.257405
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    v = SunOSVirtual(module)
    assert v._platform == 'SunOS'
    assert v._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:11:35.730170
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import unittest
    class TestModule(object):
        def run_command(self, command, check_rc=True):
            import sys

# Generated at 2022-06-11 06:11:42.041345
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())

    # assert that _platform is set correctly
    assert virtual._platform == 'SunOS'

    # assert that virtualization_tech is populated
    assert virtual.virtualization_tech == ['zone', 'vmware', 'virtualbox']

    # assert that virtualization_tech_guest is populated
    assert virtual.virtualization_tech_guest == ['zone', 'vmware', 'virtualbox']

    # assert that virtualization_tech_host is populated
    assert virtual.virtualization_tech_host == ['zone']

    # assert that virtualization_type is populated
    assert virtual.virtualization_type == ['zone', 'vmware', 'virtualbox']

    # assert that virtualization_role is populated
    assert virtual.virtualization_role == ['guest', 'host']

    # assert that container is populated

# Generated at 2022-06-11 06:11:49.336265
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!any'], type='list')
        )
    )

    # first test: we are in a global zone of a solaris 11.2
    #  or later system and no guest tools are installed
    #  (i.e. this system is not virtualized)
    class MockZoneModule(object):
        def __init__(self, name, path):
            self.name = name
            self.path = path

        def get_bin_path(self, name):
            if name == 'zonename':
                return '/bin/zonename'
            elif name == 'modinfo':
                return '/bin/modinfo'


# Generated at 2022-06-11 06:12:49.805706
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ModuleMock:
        def __init__(self):
            self.run_command_called = 0
            self.run_command_args = []

        def get_bin_path(self, *args):
            return "/bin/foo"

        def run_command(self, *args):
            self.run_command_called = self.run_command_called + 1
            self.run_command_args.append(args)
            if self.run_command_called == 2:
                return (0, "LDOMS\n", "")
            return (1, "", "")

    module_mock = ModuleMock()
    sunos_virtual_mock = SunOSVirtual(module_mock)
    res = sunos_virtual_mock.get_virtual_facts()
    assert module_mock.run

# Generated at 2022-06-11 06:12:52.694657
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    keys = virtual_facts.get_virtual_facts().keys()
    assert 'virtualization_type' in keys
    assert 'virtualization_role' in keys
    assert 'virtualization_keys' in keys
    assert 'container' in keys

# Generated at 2022-06-11 06:12:53.506142
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector().virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:12:55.859555
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj
    assert isinstance(obj, SunOSVirtualCollector)
    assert obj._platform == 'SunOS'
    assert obj._fact_class is not None
    assert obj._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:13:03.579816
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    # Create a SunOSVirtual object for testing purposes
    SunOS_virtual = SunOSVirtual(module)

    # Mock the output of get_bin_path and ldom_bin_path
    SunOS_virtual.module.get_bin_path = Mock(side_effect=lambda x: {'zonename': '/usr/bin/zonename', 'virtinfo': '/usr/sbin/virtinfo'}.get(x, '/bin/' + x))

    # Mock output of run_command method
    SunOS_virtual.module.run_command = Mock(return_value=(0, "virtualization_type|virtualization_role|container", ""))

    # Check case where virtualization_type is 'xen'
    # and virtualization_role is 'guest'
    # and container is '

# Generated at 2022-06-11 06:13:06.929860
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = 'ansible.module_utils.facts.virtual.SunOS.SunOSVirtualCollector'
    obj = SunOSVirtualCollector()
    assert obj.__class__.__name__ == 'SunOSVirtualCollector'
    assert obj._fact_class.__name__ == 'SunOSVirtual'
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 06:13:07.703774
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert True

# Generated at 2022-06-11 06:13:14.905585
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = Virtual(dict(module_defaults=dict()))

    # Test when zonename can be run and it shows we're in the global zone
    m.module.run_command = lambda x: (0, "global", "")
    m.module.get_bin_path = lambda x: "/usr/bin/zonename"
    assert "zone" in m.get_virtual_facts()['virtualization_tech_host']
    assert "global" in m.get_virtual_facts()['virtualization_role']
    assert not "guest" in m.get_virtual_facts()['virtualization_role']

    # Test when zonename can be run and it shows we're in a non-global zone
    m.module.run_command = lambda x: (0, "non-global", "")
    m.module.get_

# Generated at 2022-06-11 06:13:15.675410
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    f = SunOSVirtual()
    assert f is not None

# Generated at 2022-06-11 06:13:16.774022
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt.platform == 'SunOS'

# Generated at 2022-06-11 06:15:08.333543
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Mock the module
    class MockModule:
        def __init__(self):
            self.params = {}


# Generated at 2022-06-11 06:15:11.380858
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert(isinstance(vc, VirtualCollector))
    assert(issubclass(vc._fact_class, Virtual))
    assert(vc.platform == 'SunOS')


# Generated at 2022-06-11 06:15:12.964361
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual


# Generated at 2022-06-11 06:15:13.848586
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:15:17.248138
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    collector = SunOSVirtualCollector(module=module)
    ansible_facts = collector.collect()
    virtual_facts = ansible_facts['ansible_facts']['virtual_facts']
    assert virtual_facts['platform'] == 'SunOS'

# Generated at 2022-06-11 06:15:26.177674
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    def get_bin_path(name):
        return '/usr/sbin/' + name

    module.get_bin_path = get_bin_path

    def run_command(command):
        if command == "/usr/sbin/zonename":
            return 0, "global\n", ""
        elif command == "/usr/sbin/modinfo":
            return 0, "modinfo\n", ""
        elif command == "/usr/sbin/virtinfo -p":
            return 0, "DOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=false\n", ""

# Generated at 2022-06-11 06:15:33.058260
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type(__import__('ansible.module_utils.facts.virtual.sunos', fromlist=['AnsibleModule']))()
    setattr(module, 'run_command', lambda x: (0, '', ''))
    setattr(module, 'get_bin_path', lambda x: x)
    module.exit_json = lambda x: x
    obj = SunOSVirtual(module)
    facts = obj.get_virtual_facts()
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts

# Generated at 2022-06-11 06:15:40.593563
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def _run_module(module_args):
        module_path = os.path.dirname(__file__) + "/../../../../library"  # os.path.dirname(os.path.realpath(__file__))
        module_utils_path = os.path.dirname(__file__) + "/../../../../lib/ansible/module_utils"
        system_module_path = [module_path, module_utils_path]

        # AnsibleModule.__init__(self, argument_spec=None, bypass_checks=False, no_log=False,
        #   check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
        #   required_one_of=None, add_file_common_args=False, supports_check_mode=False,
        #

# Generated at 2022-06-11 06:15:42.510516
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    return "work in progress"

# Generated at 2022-06-11 06:15:44.871404
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    coll = SunOSVirtualCollector()
    assert coll._platform == 'SunOS'
    assert coll._fact_class == SunOSVirtual