

# Generated at 2022-06-11 06:07:41.564997
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test that the _platform attribute is set correctly
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == "SunOS"

# Generated at 2022-06-11 06:07:51.895991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    import platform

    class FakeModule():
        def run_command(self, cmd):
            if 'zonename' in cmd:
                if 'global' in cmd:
                    out = 'global'
                else:
                    out = 'nonglobal'
                return 0, out, ''
            elif 'virtinfo' in cmd:
                if '-p' in cmd:
                    out = 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false'
                else:
                    out = ''
                return 0, out, ''
            else:
                out = ''
                return 0, out, ''

        def get_bin_path(self, name):
            return '/usr/bin/' + name


# Generated at 2022-06-11 06:08:03.107255
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeAnsibleModule.run_command
    module.get_bin_path = FakeAnsibleModule.get_bin_path

    module.run_command.side_effect = [
        (0, 'global', ''),
        (0, "", ""),
        (0, '123|abc=def|foo=true', ''),
        (0, "", ""),
        (0, 'SUNW,T2000|VMware|foo=bar', ''),
    ]


# Generated at 2022-06-11 06:08:04.893454
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    a = SunOSVirtualCollector()
    assert a._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:06.627294
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(None), SunOSVirtualCollector)

# Generated at 2022-06-11 06:08:16.519014
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.virtuozzo import VirtuozzoVirtual
    from ansible.module_utils.facts.virtual.zones import ZonesVirtual
    from ansible.module_utils.facts.virtual.vmware import VMwareVirtual
    from ansible.module_utils.facts.virtual.kvm import KVMVirtual
    from ansible.module_utils.facts.virtual.xen import XenVirtual
    from ansible.module_utils.facts.virtual.virtualbox import VirtualboxVirtual
    from ansible.module_utils.facts.virtual.parallels import ParallelsVirtual

    virt_facts = VirtualCollector(module=None)
    virt_

# Generated at 2022-06-11 06:08:26.155963
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class SunOSModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', '!any']
        def get_bin_path(self, binary, opt_dirs=[]):
            return binary
        def run_command(self, args, check_rc=True, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False, prompt_regex=None):
            if args == 'zonename':
                return (0, 'global\n', '')
            elif args == 'modinfo':
                return (0, '', '')

# Generated at 2022-06-11 06:08:28.179520
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.system == 'SunOS'


# Generated at 2022-06-11 06:08:38.438814
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = lambda *args: (0, '', '')

    virt = SunOSVirtual(module)
    facts = virt.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert facts.get('virtualization_role') == 'guest'
    assert facts.get('virtualization_tech_guest') == {'zone'}
    assert facts.get('virtualization_tech_host') == set()
    assert facts.get('container') == 'zone'

    module.run_command = lambda *args: (1, '', '')

    virt = SunOSVirtual(module)
    facts = virt.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts

# Generated at 2022-06-11 06:08:40.428456
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual(dict(module=None))
    assert virtual_obj.platform == 'SunOS'

# Generated at 2022-06-11 06:08:55.415221
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    o = SunOSVirtualCollector({})
    assert o.platform == 'SunOS'
    assert o._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:08:56.048242
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts_virtual = SunOSVirtual()
    assert facts_virtual is not None

# Generated at 2022-06-11 06:09:04.012539
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual = SunOSVirtual(module)

    assert virtual.get_virtual_facts().get('virtualization_type') == "zone"
    assert virtual.get_virtual_facts().get('virtualization_role') == "guest"
    assert virtual.get_virtual_facts().get('virtualization_tech_guest') == set(['zone'])
    assert virtual.get_virtual_facts().get('virtualization_tech_host') == set()
    assert virtual.get_virtual_facts().get('container') == "zone"

# Generated at 2022-06-11 06:09:07.744823
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    config = {}
    virtual_obj = SunOSVirtual(config)
    assert isinstance(virtual_obj, Virtual)


# Generated at 2022-06-11 06:09:15.064680
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = Mock()
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = True
    # Testing a global zone
    module_mock.get_bin_path.side_effect = [True, False, False]
    virtual_facts_module = SunOSVirtual(module=module_mock)
    virtual_facts = virtual_facts_module.get_virtual_facts()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'container' not in virtual_facts
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'zone'}
    # Testing a branded

# Generated at 2022-06-11 06:09:26.037315
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    def mock_run_command(command):
        out = ""
        rc = 0
        if command.find('modinfo') >= 0:
            out = "filename:       /usr/kernel/fs/zfs/zfs.ko\n"
            out += "description:    ZFS filesystem\n"
            out += "author:         Oracle Corporation\n"
            out += "license:        CDDL\n"
            out += "depends:\n"
            out += "name:           zfs\n"
            out += "modid:          83\n"
            out += "vmware:         unknown"
        elif command.find('zonename') >= 0:
            out = "global"

# Generated at 2022-06-11 06:09:29.696043
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual
    assert SunOSVirtualCollector.collectors == ['SunOSVirtual']

# Generated at 2022-06-11 06:09:31.492188
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:09:33.116696
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual is not None

# Generated at 2022-06-11 06:09:35.347625
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(None)
    assert virt is not None


# Generated at 2022-06-11 06:10:01.314124
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'

# Generated at 2022-06-11 06:10:03.350344
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hypervisor = SunOSVirtual()
    assert hypervisor.platform == 'SunOS'

# Generated at 2022-06-11 06:10:08.025404
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    # Test no params
    assert sunos_virtual.label == 'SunOS'
    # Test platform
    assert sunos_virtual.platform == 'SunOS'
    # Test get_virtual_facts()
    assert sunos_virtual.get_virtual_facts() == {}



# Generated at 2022-06-11 06:10:10.007113
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual(None)
    assert x.platform == 'SunOS'
    assert x.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:10:20.921999
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create the mocks
    virtual = SunOSVirtual({})

    def mock_get_bin_path(path, *args, **kwargs):
        if path == 'zonename':
            return '/path/to/zonename'
        if path == 'virtinfo':
            return '/usr/sbin/virtinfo'
        if path == 'smbios':
            return '/usr/sbin/smbios'
        return None

    def mock_run_command(cmd, *args, **kwargs):

        rc = 0
        out = err = None

        if cmd == '/path/to/zonename':
            rc = 0
            out = 'global'
        # Check if it's a branded zone (i.e. Solaris 8/9 zone)

# Generated at 2022-06-11 06:10:25.081845
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    #
    # Just exercise the constructor of the class and make sure that the
    # SunOSVirtual instance is created and the platform field is set
    #
    module = DummyAnsibleModule()
    virtual_facts_instance = SunOSVirtual(module)
    assert virtual_facts_instance.platform == SunOSVirtual.platform


# Generated at 2022-06-11 06:10:28.362999
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import sys
    sys.modules['ansible'] = object()

    from ansible.module_utils.facts import virtual
    facts = virtual.Virtual()
    assert facts.__class__.__name__ == 'SunOSVirtual'
    assert facts.platform == 'SunOS'

# Generated at 2022-06-11 06:10:29.433914
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:10:33.551442
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual({})
    collector = SunOSVirtualCollector({}, [virt])
    assert isinstance(collector._facts['virtualization'], SunOSVirtual)
    assert collector._facts['virtualization'].platform == 'SunOS'

# Generated at 2022-06-11 06:10:36.507955
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    myclass = SunOSVirtual()
    assert myclass.platform == 'SunOS'
    assert myclass.virtualization_type == ''
    assert myclass.virtualization_role == ''
    assert myclass.container == ''

# Generated at 2022-06-11 06:11:31.700681
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class SunOSVirtual """

    SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-11 06:11:34.588239
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Given
    collector_platform = 'SunOS'

    # When
    collector = SunOSVirtualCollector()

    # Then
    assert collector._platform == collector_platform


# Generated at 2022-06-11 06:11:36.952109
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == SunOSVirtualCollector._platform
    assert x._fact_class == SunOSVirtualCollector._fact_class

# Generated at 2022-06-11 06:11:38.165074
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sc = SunOSVirtualCollector()
    assert sc._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:11:39.867595
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts.facts['virtualization_tech'] == set([])


# Generated at 2022-06-11 06:11:40.776435
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual(dict())


# Generated at 2022-06-11 06:11:48.861171
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # If it's a zone. Should find it's a zone
    m = SunOSVirtual({})
    m.module.run_command = lambda cmd: (0, 'global', '')
    facts = m.get_virtual_facts()
    assert facts.get('virtualization_type') == 'zone'
    assert facts.get('virtualization_role') is None
    assert facts.get('container') == 'zone'

    # If it's a zone. Should find it's a zone
    m = SunOSVirtual({})
    m.module.run_command = lambda cmd: (0, 'zone1', '')
    facts = m.get_virtual_facts()
    assert facts.get('virtualization_type') == 'zone'
    assert facts.get('virtualization_role') is None

    # If it's a branded zone. Should find

# Generated at 2022-06-11 06:12:00.071275
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class MockModule(object):
        def __init__(self):
            self.bin_path_cache = {'zonename': '/usr/sbin/zonename',
                                   'virtinfo': '/usr/sbin/virtinfo',
                                   'smbios': '/usr/sbin/smbios'}

# Generated at 2022-06-11 06:12:01.880945
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:12:12.074878
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.test_virtual import MockModule
    module = MockModule()

    # Test if it's a zone
    module.run_command = lambda cmd, check_rc=True: (0, "zone1\n", '')
    module.get_bin_path = lambda cmd: '/usr/bin/{}'.format(cmd)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_tech_guest' == set(['zone'])
    assert 'virtualization_tech_host' == set()
    assert 'container' == 'zone'

    # Test if it's a branded zone (i.e. Solar

# Generated at 2022-06-11 06:14:19.352877
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.collector import BaseFactsCollector
    from ansible.module_utils.facts.virtual.posix import VirtualCollector as VirtualCollectorPOSIX
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    class MySunOSVirtualCollector(SunOSVirtualCollector):
        def get_all_facts(self, cache=True, fact_caches=None):
            return {'ansible_virtual': {'SunOS': SunOSVirtual(self.module)}}


# Generated at 2022-06-11 06:14:24.973075
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts=SunOSVirtual().get_virtual_facts()
    print(virtual_facts)
    assert type(virtual_facts) is dict
    assert not virtual_facts['virtualization_type']
    assert not virtual_facts['virtualization_role']
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 0


# Generated at 2022-06-11 06:14:28.872006
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()

    assert obj.platform == 'SunOS'
    assert obj.fact_class._platform == 'SunOS'
    assert obj.fact_class.platform == 'SunOS'
    assert obj.fact_class.__class__.__name__ == 'SunOSVirtual'
    assert obj.fact_class.__module__ == 'ansible.module_utils.facts.virtual.sunos'
    assert isinstance(obj, SunOSVirtualCollector)
#

# Generated at 2022-06-11 06:14:30.984852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Calling constructor will initialize _platform
    collector = SunOSVirtualCollector()
    # _platform will be assigned SunOS
    assert collector._platform is 'SunOS'

# Generated at 2022-06-11 06:14:32.179232
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    SunOSVirtualCollector(facts=facts, module=None)

# Generated at 2022-06-11 06:14:39.576253
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Test class constructor for SunOSVirtual"""
    # Constructor without arguments
    newSunOSVirtual = SunOSVirtual()
    assert newSunOSVirtual.platform == 'SunOS'
    # Constructor with argument
    newSunOSVirtual = SunOSVirtual(dict(ANSIBLE_SYSTEM_VERSION='SunOS 5.10'))
    assert newSunOSVirtual.system_version == 'SunOS 5.10'
    # Constructor with argument
    newSunOSVirtual = SunOSVirtual({'ANSIBLE_SYSTEM_VERSION': 'SunOS 5.10', 'ANSIBLE_SYSTEM_NAME': 'SunOS'})
    assert newSunOSVirtual.system_version == 'SunOS 5.10'
    assert newSunOSVirtual.system_name == 'SunOS'


# Generated at 2022-06-11 06:14:40.895152
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector
    x = SunOSVirtualCollector()

# Generated at 2022-06-11 06:14:47.236918
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.virtual.sunos
    from ansible.module_utils.facts import virtual
    import pytest

    collector = SunOSVirtualCollector(
                module=basic.AnsibleModule(
                    argument_spec = dict()
                ),
                subtype_methods=virtual.collect_platform_subset('virtual'),
                platform='SunOS'
    )
    assert collector.platform == 'SunOS'
    assert collector.guest_facts is None

# Generated at 2022-06-11 06:14:52.660335
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = guest_tech
    virtual_facts['virtualization_tech_host'] = host_tech

    virtualFacts = SunOSVirtual(dict())
    assert virtualFacts.get_virtual_facts() == virtual_facts

# Generated at 2022-06-11 06:14:59.282525
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    fact_class = SunOSVirtual({}, module)
    facts = fact_class.get_virtual_facts()

    assert not facts.get('virtualization_type')
    assert not facts.get('virtualization_role')
    assert not facts.get('virtualization_tech_host')
    assert not facts.get('virtualization_tech_guest')
    assert not facts.get('container')


# Mock module for unit tests