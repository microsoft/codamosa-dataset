

# Generated at 2022-06-11 06:07:40.481779
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert type(instance) == SunOSVirtualCollector
    assert instance._platform == 'SunOS'
    assert instance._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:07:50.871249
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize the SunOSVirtual object
    sun_virtual = SunOSVirtual()

    # Prepare test data
    # This is the output of the command "/usr/sbin/virtinfo -p"
    # in a global zone and in a guest domain.
    virtinfo_global = """
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=true
"""
    virtinfo_guest = """
DOMAINROLE|impl=LDoms|control=true|io=true|service=true|root=true
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=true
"""
    # This is the output of the command "zonename"


# Generated at 2022-06-11 06:07:52.303720
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({'ANSIBLE_MODULE_ARGS': {}})
    assert v


# Generated at 2022-06-11 06:08:03.586720
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # This function tests the get_virtual_facts method of the SunOSVirtual class.
    # It should return a dict.
    # It should run the modinfo command.
    # It should run the smbios command.
    # It should run the zonename command.
    # It should run the zfs list command.
    # It should run the virtinfo command.
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.zfs import ZFSVirtual
    from ansible.module_utils.facts.virtual.container.zone import Zone
    import os
    import platform

    # Simulate the values returned by the command_exists method of module_utils.facts.system.distribution.SunOS

# Generated at 2022-06-11 06:08:05.957752
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual = SunOSVirtualCollector()
    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:08:16.132605
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test of method SunOSVirtual.get_virtual_facts
    """
    import contextlib
    from ansible.module_utils import basic
    from ansible.module_utils.facts import virtual

    @contextlib.contextmanager
    def _mocked_module(**kwargs):
        argspec = basic.AnsibleModule.argument_spec
        # Mock AnsibleModule init
        am = basic.AnsibleModule
        am_init = am.__init__
        am_exit_json = am.exit_json
        am_fail_json = am.fail_json

# Generated at 2022-06-11 06:08:23.159266
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.exit_json = MagicMock(return_value=True)
    result = SunOSVirtual().get_virtual_facts(module)
    assertTrue(isinstance(result, dict))
    assertTrue('virtualization_type' in result)
    assertTrue('virtualization_role' in result)
    assertTrue('container' in result)


# Generated at 2022-06-11 06:08:26.698961
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(None)
    assert virt.platform == 'SunOS'
    assert virt.virtualization_type is None
    assert virt.virtualization_role is None
    assert virt.container is None


# Generated at 2022-06-11 06:08:29.012868
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt = SunOSVirtualCollector()
    assert virt._fact_class == SunOSVirtual
    assert virt._platform == 'SunOS'



# Generated at 2022-06-11 06:08:35.074288
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule({})
    obj = SunOSVirtual(module)
    assert obj
    assert obj.virtualization_type == 'xen'
    assert obj.virtualization_role == 'guest'
    assert obj.container == 'zone'
    assert obj.platform == 'SunOS'
    assert obj.virtualization_tech_guest == {'zone', 'xen'}
    assert obj.virtualization_tech_host == {'zone'}

# Generated at 2022-06-11 06:08:51.857195
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict()).platform == 'SunOS'
    assert SunOSVirtual(dict()).virtualization_type is None
    assert SunOSVirtual(dict()).virtualization_role is None
    assert SunOSVirtual(dict()).virtualization_subtype is None
    assert SunOSVirtual(dict()).container is None

# Generated at 2022-06-11 06:08:53.765912
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    f = SunOSVirtual()
    assert f.platform == 'SunOS'
    assert f.facts == dict()

# Generated at 2022-06-11 06:08:56.502988
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt = SunOSVirtual(module)
    assert virt.name == "SunOS"
    assert virt.platform == "SunOS"


# Generated at 2022-06-11 06:09:02.086995
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # test instantiation with no args (will implicitly use PlatformFactCollector class)
    sunos_virtual_collector = SunOSVirtualCollector()
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)
    assert isinstance(sunos_virtual_collector, VirtualCollector)
    assert isinstance(sunos_virtual_collector, object)


# Generated at 2022-06-11 06:09:03.561608
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual

# Generated at 2022-06-11 06:09:08.743113
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.module == module
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.container == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()


# Generated at 2022-06-11 06:09:10.275945
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({'module_name': 'test'})
    assert s.platform == 'SunOS'

# Generated at 2022-06-11 06:09:16.321706
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import shutil
    import tempfile
    import filecmp
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")
    with open(cfgfile, 'w') as f:
        f.write("[defaults]\n")
        f.write("stdout_callback = yaml")

    # Create a temporary 'facts.d' directory
    factsd = os.path.join(tmpdir, "facts.d")
    os.mkdir(factsd)

    # Unit test get_virtual_facts method
    module

# Generated at 2022-06-11 06:09:20.235868
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'global', '') # Simulate output of `zonename` command
    obj = SunOSVirtual(module)
    assert obj.module == module


# Generated at 2022-06-11 06:09:21.909172
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual = SunOSVirtualCollector()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:09:47.438673
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:09:57.062483
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # setup test
    test_sv = SunOSVirtual(module=None)

    # test absent /proc/vz
    with patch('os.path.isdir') as mock_isdir:
        mock_isdir.return_value = False
        virtual_facts = test_sv.get_virtual_facts()

    assert virtual_facts == {}

    # test present /proc/vz without virtuozzo
    with patch('os.path.isdir') as mock_isdir:
        mock_isdir.return_value = True
        with patch.object(SunOSVirtual, '_get_output') as mock_get_output:
            mock_

# Generated at 2022-06-11 06:09:58.097207
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:10:01.600266
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None

# Generated at 2022-06-11 06:10:11.118802
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.sunos as module_utils

    module_utils.VIRT_WHAT = ['/bin/virt-what']
    module_utils.MODINFO = ['/bin/modinfo']
    module_utils.HOSTID = ['/bin/hostid']
    module_utils.ZONENAME = ['/bin/zonename']
    module_utils.VIRTINFO = ['/usr/sbin/virtinfo']
    module_utils.SMBIOS = ['/usr/sbin/smbios']

    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd: (0, '', ''),
        'get_bin_path': lambda self, cmd: cmd[0]
    })()

    v = SunOSVirtual(module=module)

# Generated at 2022-06-11 06:10:22.021568
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, params, tmpdir):
            self.params = params
            self.tmpdir = tmpdir
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_dels = []

        def get_bin_path(self, name):
            if name == 'zonename':
                return '/usr/bin/zonename'
            elif name == 'virtinfo':
                return '/usr/sbin/virtinfo'
            elif name == 'smbios':
                return '/usr/sbin/smbios'
            return None

        def run_command(self, cmd, persist_command=False, is_check_rc=False):
            args = (cmd, persist_command, is_check_rc)
           

# Generated at 2022-06-11 06:10:23.108395
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()

# Generated at 2022-06-11 06:10:24.791921
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts._platform == "SunOS"
    assert len(virtual_facts.virtual_facts) == 0


# Generated at 2022-06-11 06:10:25.945447
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert 'SunOS' in SunOSVirtualCollector.platforms

# Generated at 2022-06-11 06:10:31.871004
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule(
        dict(
            run_command=run_command_mock,
            get_bin_path=lambda _: "/bin/zonename"
        )
    )
    SunOSVirtual(module).get_virtual_facts()
    assert run_command_mock.call_count == 1
    assert run_command_mock.call_args[0][0] == "/bin/zonename"


# Mocking

# Generated at 2022-06-11 06:11:28.962308
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # test the constructor
    collector = SunOSVirtualCollector()
    assert collector.fact_class is SunOSVirtual
    assert collector.platform == 'SunOS'

# Generated at 2022-06-11 06:11:33.199337
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Unit test for constructor of class SunOSVirtualCollector to verify the
    SunOSVirtualCollector class is instantiated correctly.
    '''
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-11 06:11:35.246901
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:11:39.459962
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'global', '')
    mock_module.get_bin_path.return_value = True
    facts = SunOSVirtual(mock_module)
    assert facts.platform == 'SunOS'
    assert facts.virtualization_type == 'zone'
    assert facts.virtualization_role == 'host'

# Generated at 2022-06-11 06:11:42.881177
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = MockModule()
    fact_mock = SunOSVirtual(module_mock)
    fact_mock.get_virtual_facts()
    assert fact_mock.platform == 'SunOS'


# Generated at 2022-06-11 06:11:44.858196
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvirtualcollector = SunOSVirtualCollector()
    assert sunosvirtualcollector.__dict__['_platform'] == 'SunOS'

# Generated at 2022-06-11 06:11:47.107547
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    # Just make sure it runs without blowing up
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ""

# Generated at 2022-06-11 06:11:58.593694
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()


# Generated at 2022-06-11 06:12:01.714375
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector returns an instance of SunOSVirtualCollector
    """
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)



# Generated at 2022-06-11 06:12:04.561738
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = ansible_fake_module()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:14:16.601100
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # These values to be filled in by the test suite
    out_zone = ""
    out_smbios = ""
    out_modinfo = ""
    out_virtinfo = ""

    module = FakeModule(out_zone, out_smbios, out_modinfo, out_virtinfo)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    # Check virtualization_technologies
    # We have a special test here because the order in which the technologies are added to the set is not deterministic.
    # The test asserts that a specific set of technologies is present, but not the order.
    expected_tech_guest = {'vmware', 'virtualbox', 'vmware', 'parallels', 'vmware', 'virtualbox'}

# Generated at 2022-06-11 06:14:26.271559
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    # Virtualization tech guest
    module.run_command = Mock(
        side_effect=tuple([(0, "global", ""), (0, "", ""), (0, "/usr/sbin/modinfo: VMware: no module by that name found")])
    )

    # Virtualization tech host
    module.get_bin_path = Mock(return_value="/usr/sbin/virtinfo")

# Generated at 2022-06-11 06:14:27.596212
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector().collect()
    assert 'sunos' == virtual_facts['ansible_virtualization_type']

# Generated at 2022-06-11 06:14:36.633439
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virt = SunOSVirtual(module=module)

    # Test with no logical domain
    virt.run()
    assert virt.facts['virtualization_type'] == 'xen'
    assert virt.facts['virtualization_role'] == 'guest'
    assert virt.facts['virtualization_tech_guest'] == set(['xen'])
    assert virt.facts['virtualization_tech_host'] == set()

    # Test with logical domain

# Generated at 2022-06-11 06:14:45.755105
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    # Test fixture, with a sample of what may be returned by commands (out) and their return code (rc)

# Generated at 2022-06-11 06:14:56.963002
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class FakeModule(object):
        def __init__(self, params=[]):
            self.params = params

        def get_bin_path(self, name, opt_dirs=[]):
            if name == "zonename":
                return "/usr/bin/zonename"
            if name == "modinfo":
                return "/usr/sbin/modinfo"
            if name == "virtinfo":
                return "/usr/sbin/virtinfo"
            if name == "smbios":
                return "/usr/sbin/smbios"

        def run_command(self, command, check_rc=True):
            return 0, "", ""

    module = FakeModule()

    v = SunOSVirtual(module)

    container = v.get_virtual_facts()['container']
    assert container == 'zone'

   

# Generated at 2022-06-11 06:14:59.604828
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """ Unit test of SunOSVirtualCollector """
    obj = SunOSVirtualCollector()

    assert obj is not None
    assert obj._fact_class.platform == 'SunOS'



# Generated at 2022-06-11 06:15:02.120962
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    ''' Unit test for the constructor and get_facts method of SunOSVirtual '''

    # This is a class not a module.
    # pylint: disable=no-member,import-error
    SunOSVirtual()

# Generated at 2022-06-11 06:15:04.837919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, {})
    assert isinstance(virtual_facts, SunOSVirtual)
    assert hasattr(virtual_facts, 'platform')
    assert type(virtual_facts.platform) == str


# Generated at 2022-06-11 06:15:06.266366
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual
