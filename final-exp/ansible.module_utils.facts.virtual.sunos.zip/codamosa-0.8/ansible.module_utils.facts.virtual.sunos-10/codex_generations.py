

# Generated at 2022-06-11 06:07:46.341507
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class Mock_module:
        def __init__(self, bin_paths = {}):
            self.bin_paths = bin_paths

        def get_bin_path(self, path):
            if self.bin_paths is None:
                return path
            if path in self.bin_paths:
                return self.bin_paths[path]
            return None

        def run_command(self, cmd):
            if cmd == '/usr/sbin/virtinfo -p':
                return 0, virtinfo_output, ''
            elif cmd == 'smbios':
                return 0, smbios_output, ''
            elif cmd == 'zonename':
                return 0, zonename_output, ''
            elif cmd == 'modinfo':
                return 0, modinfo_output, ''

# Generated at 2022-06-11 06:07:48.257226
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert facts.platform == "SunOS"


# Generated at 2022-06-11 06:07:53.122209
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual({}).get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts


# Generated at 2022-06-11 06:08:04.148270
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def mock_get_bin_path(module, *args, **kwargs):
        if args[0] == 'zonename':
            return '/usr/sbin/zonename'
        if args[0] == 'modinfo':
            return '/usr/sbin/modinfo'

    def mock_run_command(module, *args, **kwargs):
        if args[0] == '/usr/sbin/zonename':
            return 0, 'vm-node-001', ''

# Generated at 2022-06-11 06:08:05.198710
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:08:06.939680
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'

# Generated at 2022-06-11 06:08:16.838709
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    import unittest

    class Mock_Module(object):
        def __init__(self):
            self.run_command_result = [0, "", ""]
            self.path = "/usr/bin:/usr/sbin"
            self.run_command_calls = []

        def get_bin_path(self, name):
            self.get_bin_path_name = name
            return self.get_bin_path_return_value

        def run_command(self, args, check_rc=False):
            self.run_command_calls.append((args, check_rc))


# Generated at 2022-06-11 06:08:26.652029
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector

    module = MockModule()
    SunOSVirtualCollector.collect(module=module)

    facts = module.exit_args['ansible_facts']['ansible_virtualization_facts']
    assert 'container' in facts
    assert facts['container'] == 'zone'
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'zone'
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in facts
    assert set(facts['virtualization_tech_guest']) == set({'zone'})
    assert 'virtualization_tech_host' in facts
    assert set(facts['virtualization_tech_host']) == set()



# Generated at 2022-06-11 06:08:37.157230
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.zones import ZonesVirtual
    from ansible.module_utils.facts.virtual.virtuozzo import VirtuozzoVirtual
    from ansible.module_utils.facts.virtual.domaining import DomainingVirtual
    from ansible.module_utils.facts.virtual.smbios import SmbiosVirtual
    from ansible.module_utils.basic import AnsibleModule

    sunos_virtual = SunOSVirtual(AnsibleModule(argument_spec={}))

    # Test via zones
    zones_virtual = ZonesVirtual(AnsibleModule(argument_spec={}))
    def get_virtual_facts_mock_for_zones(self):
        return zones_virtual.get_virtual_facts()

# Generated at 2022-06-11 06:08:39.273501
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    This is a basic constructor test to ensure SunOSVirtual is a subclass of Virtual
    '''
    assert issubclass(SunOSVirtual, Virtual)

# Generated at 2022-06-11 06:08:53.759278
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual({}).platform == 'SunOS'

# Generated at 2022-06-11 06:08:55.219241
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert (SunOSVirtualCollector._platform == 'SunOS')

# Generated at 2022-06-11 06:08:58.062171
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:09:01.449845
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_SunOS_virtual_collector = SunOSVirtualCollector()
    assert my_SunOS_virtual_collector.fact_class == SunOSVirtual
    assert my_SunOS_virtual_collector.platform == 'SunOS'

# Generated at 2022-06-11 06:09:09.020393
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Unit test setup.
    import sys
    original_module_utils_path = list(sys.path)
    test_fact_subclass = SunOSVirtual(None)
    sys.path.append('/path/to/ansible/test/utils')
    from ansible.module_utils import facts
    test_fact_subclass.module = facts.AnsibleModuleStub()

    # Unit test execution.
    virtual_facts = test_fact_subclass.get_virtual_facts()

    # Unit test assertions
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 06:09:12.656114
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = DictModule()
    fact_class = SunOSVirtual
    platform = 'SunOS'
    virtual_collector = SunOSVirtualCollector(module, fact_class, platform)
    assert virtual_collector.fact_class == fact_class
    assert virtual_collector.platform == platform
    assert virtual_collector.module == module

# Generated at 2022-06-11 06:09:16.623291
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual
    assert obj._fact_class()._platform == 'SunOS'

# Generated at 2022-06-11 06:09:19.698666
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual({})
    if SunOSVirtual.platform != 'SunOS':
        return
    virtual_facts = virtual.get_virtual_facts()
    print(virtual_facts)

# Generated at 2022-06-11 06:09:21.119517
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector()._platform == 'SunOS'

# Generated at 2022-06-11 06:09:24.690168
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of class SunOSVirtual
    testobj = SunOSVirtual()
    # Try to get virtual facts, should be none because we're not mocking any commands
    virtual_facts = testobj.get_virtual_facts()
    assert virtual_facts == {}

# Generated at 2022-06-11 06:09:50.908759
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # unit test for constructor of class
    # SunOSVirtualCollector
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:09:58.270813
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a module
    from ansible.module_utils.facts.test import Location
    from ansible.module_utils.facts.test import ModuleTestCase

    module = ModuleTestCase.create_ansible_module(
        dict(virtual_facts=dict()),
        Location((1, 0, 0)),
        'SunOS',
        'ansible.module_utils.facts')

    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:09:59.924335
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:10.059828
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})
    v.module = Mock()
    v.module.run_command = _run_command
    v.module.get_bin_path = _get_path

    v._get_zonename = Mock()
    v._get_zonename.return_value = None
    v._get_virtinfo = Mock()
    v._get_virtinfo.return_value = None

    facts = v.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'container' not in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:10:11.348038
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtualInst = SunOSVirtual()
    assert virtualInst.get_virtual_facts()

# Generated at 2022-06-11 06:10:12.276974
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:10:13.975758
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 06:10:16.544735
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    ''' Unit test for SunOSVirtual '''
    module = SunOSVirtual({})
    assert module.platform == "SunOS"

# Generated at 2022-06-11 06:10:18.784769
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:21.215853
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_class = SunOSVirtual({'module': None})
    assert virtual_class.__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-11 06:11:16.184122
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:11:25.800200
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class MockModule:
        def __init__(self, result):
            self.result = result

        def run_command(self, bin_path, *args, check_rc=True):
            return (0, self.result, '')

        def get_bin_path(self, path):
            cmd_options = {
                "zonename": "zonename",
                "virtinfo": "/usr/sbin/virtinfo",
                "smbios": "smbios",
                "modinfo": "modinfo",
            }
            if path in cmd_options:
                return cmd_options[path]
            else:
                return 'fake_bin'

    # test zone
    result = 'global'
    module = MockModule(result)
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

# Generated at 2022-06-11 06:11:27.221157
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == "SunOS"

# Generated at 2022-06-11 06:11:29.005932
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_result = SunOSVirtual(dict())

    assert virtual_facts_result is not None

# Generated at 2022-06-11 06:11:30.801399
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:11:33.106836
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    lgc = SunOSVirtualCollector()
    assert lgc is not None



# Generated at 2022-06-11 06:11:35.200050
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:11:41.822873
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Creating an instance of class SunOSVirtual
    virtual = SunOSVirtual(dict())

    # Patching method run_command of class SunOSVirtual
    # First look for a non-existent file, when the first if statement is true
    # Then return the correct mocked output from vmware-toolbox-cmd stat
    with patch.object(SunOSVirtual, 'run_command') as mock_command:
        mock_command.return_value = (1, '', '')
        virtual_facts = virtual.get_virtual_facts()
        assert not virtual_facts
        mock_command.return_value = (0, 'VMware Tools: Running', '')
        virtual_facts = virtual.get_virtual_facts()
        assert virtual_facts['virtualization_type'] == 'vmware'
        assert 'virtualization_role' not in virtual_facts

   

# Generated at 2022-06-11 06:11:49.258280
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Test for get_virtual_facts method of SunOSVirtual class"""
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    virtual_object = SunOSVirtual()
    virtual_object.module = MockModule({
        'zonename': '/usr/bin/zonename',
        'modinfo': '/usr/sbin/modinfo',
        'virtinfo': '/usr/sbin/virtinfo',
        'smbios': '/usr/sbin/smbios',
    })
    virtual_object.module.run_command = Mock(return_value=(0, 'test', ''))

# Generated at 2022-06-11 06:11:55.176100
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # instantiate a SunOSVirtualCollector object
    sunos_virtual_collector = SunOSVirtualCollector()

    # Test if instance created is correct type
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)

    # Test if _fact_class attribute is correct type
    assert isinstance(sunos_virtual_collector._fact_class, SunOSVirtual)


# Generated at 2022-06-11 06:14:00.567001
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    SunOSVirtual(module)
    keys = ['container', 'virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']
    d = SunOSVirtual(module).get_virtual_facts()
    assert all(k in d for k in keys)



# Generated at 2022-06-11 06:14:01.792963
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sut = SunOSVirtual()
    assert isinstance(sut, SunOSVirtual)

# Generated at 2022-06-11 06:14:10.478900
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # Make the module available for SunOSVirtual()
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '/usr/lib/brand/ipkg/native', ''))

    # Make sure we collect correct result
    result = SunOSVirtual(module).get_virtual_facts()
    assert result == {'container': 'zone',
                      'virtualization_role': 'guest',
                      'virtualization_tech_guest': set(['zone']),
                      'virtualization_tech_host': set()}



# Generated at 2022-06-11 06:14:18.959899
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a mock module and mock argument specification
    module = type('', (), {})()
    module.check_mode = False
    module.params = {}
    module.run_command = type('', (), {})()
    module.run_command.side_effect = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = type('', (), {})()
    module.get_bin_path.side_effect = lambda *args: True
    # Create an instance of a SunOSVirtual fact class
    sunosvirtual = SunOSVirtual(module)

# Generated at 2022-06-11 06:14:20.875203
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({})
    assert s._platform == 'SunOS'
    assert s._fact_class == SunOSVirtual


# Generated at 2022-06-11 06:14:30.765953
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import Virtual, VirtualCollector
    from ansible.module_utils.facts import ModuleFilesCollector, ModuleStub
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_bytes


    class TestableSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            super(TestableSunOSVirtual, self).__init__(module)

        def _exec_cmd(self, cmd):
            module = self.module
            if cmd == "zonename":
                if module.params['zonename_out'] == "":
                    return 128, '', module.params['zonename_err']
                else:
                    return 0, module.params['zonename_out'], ''
           

# Generated at 2022-06-11 06:14:33.168684
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    virtual_facts_class = SunOSVirtual(module)
    assert virtual_facts_class.platform == 'SunOS'



# Generated at 2022-06-11 06:14:35.727782
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    v = SunOSVirtualCollector(facts, None)
    assert v._platform == "SunOS"
    assert v._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:14:44.294436
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Returns virtual machine facts for SunOS systems."""

    from ansible.module_utils.facts.virtual.sun.sun_virtual import SunOSVirtual
    sv = SunOSVirtual({}, {'python_version': 2, 'ansible_facts': {}})

    # Test on physical host
    # rc = 0
    # out = """
    # bla bla bla
    # Version: VMware ESXi 6.0.0 build-3481922
    # bla bla bla
    # """
    # err = ""
    #
    # sv.module.run_command = MagicMock(return_value=(rc, out, err))
    # sv.get_virtual_facts()
    #
    # assert sv.facts['virtualization_type'] == 'vmware'
    # assert sv.facts['virtualization_role']

# Generated at 2022-06-11 06:14:47.800172
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    data = '''
    virtinfo can only be run from the global zone
    '''
    module = MockModule(data)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts is None
