

# Generated at 2022-06-11 06:07:41.750710
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.__name__ == 'SunOSVirtualCollector'

# Class test for VirtualCollector
# Test instantiation with SunOSVirtualCollector

# Generated at 2022-06-11 06:07:45.145474
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector
    assert isinstance(collector, SunOSVirtualCollector)
    assert isinstance(collector._fact_class, SunOSVirtual)
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 06:07:47.436336
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:07:56.074048
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mocked_module = Mock()
    mocked_module.run_command = Mock(return_value=('', '', ''))
    mocked_module.get_bin_path = Mock(side_effect=lambda x: x if x in ('modinfo', 'smbios') else None)

    testobj = SunOSVirtual(mocked_module)

    #
    # Testing facts for a domaining host.
    #

# Generated at 2022-06-11 06:08:05.794622
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    v = SunOSVirtual(module)
    v.module.run_command = Mock(return_value=(0, 'global', ''))
    v.module.get_bin_path = Mock(return_value='')
    v.get_virtual_facts() == {}

    v.module.run_command = Mock(return_value=(0, 'not-global', ''))
    v.module.get_bin_path = Mock(return_value='')
    v.get_virtual_facts() == {'container': 'zone'}

    v.module.run_command = Mock(return_value=(0, 'not-global', ''))
    v.module.get_bin_path = Mock(return_value='/usr/sbin/virtinfo')

# Generated at 2022-06-11 06:08:10.564581
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Function to test the get_virtual_facts method of class SunOSVirtual
    '''
    SunOSVirtualCollector._module = 'test'
    SunOSVirtualCollector._bin_path = 'test'
    virtual_facts = SunOSVirtualCollector._fact_class.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-11 06:08:16.635945
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test fixture data
    class MockPopen:
        # Mock class instances
        class MockPopenInstance:
            def __init__(self, arg):
                self.arg = arg
                if arg == 'zonename':
                    self.returncode = 0
                    self.communicate = lambda: ('global', None)
                elif arg == 'modinfo':
                    self.returncode = 0
                    self.communicate = lambda: ('{vmware}', None)
                elif arg == 'virtinfo':
                    self.returncode = 0
                    self.communicate = lambda: ('DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', None)
                else:
                    self.returncode = 1
                    self.communicate = lambda: ('', None)


# Generated at 2022-06-11 06:08:26.299089
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test that ansible_facts['virtualization_type'] is set
    """
    # Create a mock module
    module = Mock(return_value=0)
    module.run_command = Mock(return_value=0)
    module.run_command.return_value = (0, '/usr/sbin:/usr/bin:/opt/SUNWspro/bin:/usr/ucb:/opt/sfw/b', '')
    module.get_bin_path = Mock(return_value=True)

    # Create an instance of the SunOSVirtual class with the mock module as argument
    su = SunOSVirtual(module)
    # Run the get_virtual_facts method
    su.get_virtual_facts()
    # Check that virtualization_type is set
    assert 'virtualization_type' in su.facts

# Generated at 2022-06-11 06:08:27.318204
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-11 06:08:35.124115
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = 'ansible.module_utils.facts.virtual.sunos.SunOSVirtual'
    module = __import__(module, fromlist=[''])
    sunos_virtual = module.SunOSVirtual()
    sunos_virtual.module = FakeAnsibleModule()
    facts = sunos_virtual.get_virtual_facts()
    assert facts
    assert facts['virtualization_type'] == 'ldom'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_role'] != 'host'

# Test class that creates the fake module

# Generated at 2022-06-11 06:08:59.531499
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test function get_virtual_facts of class SunOSVirtual
    """
    mock_module = MockModule({
        "MODINFO": """
ID    NAME    SIZE    MODE    RM    COUNTER    BIND    TIMESTAMP    PATH
0    VMNET    1    live    n    0    160    2018-06-27T08:18:20-04:00    /usr/kernel/drv/amd64/VMNET
        """
    })

    facts = SunOSVirtual(mock_module).get_virtual_facts()

    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'container' not in facts

    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'


# Unit tests for class SunOS

# Generated at 2022-06-11 06:09:09.303874
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    msg = 'Failed to find virtualization type on SunOS'
    # vmware facts
    module = FakeModule('SunOS', check_output = 'VMware\n')
    modinfo = '/sbin/modinfo'
    module.get_bin_path = lambda x: modinfo
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'vmware' in virtual_facts['virtualization_type'], msg
    assert 'vmware' in virtual_facts['virtualization_tech_guest'], msg
    assert virtual_facts['virtualization_role'] == 'guest', msg
    assert virtual_facts['virtualization_type'] == 'vmware', msg
    assert 'virtualization_tech_guest' in virtual_facts, msg

# Generated at 2022-06-11 06:09:11.149565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'


# Generated at 2022-06-11 06:09:22.151925
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Unit test to detect virtualization on Solaris 8 hosted on VMware
    module = FakeModule(module_args="", bin_path=dict(modinfo='/usr/sbin/modinfo', zonename='/usr/bin/zonename'))
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['container'] == 'zone'

    # Unit test to detect virtualization on Solaris 10 hosted on VMware

# Generated at 2022-06-11 06:09:28.893673
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "global\n", '')
    module.get_bin_path.side_effect = lambda command: command
    sunos_virtual = SunOSVirtual(module=module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == {'zone'}
    assert virtual_facts['container'] == 'zone'
    module.run_command.return_value = (0, "global\n", '')
    module.get_bin_path.side_effect = lambda command: None

# Generated at 2022-06-11 06:09:37.275465
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, Mock
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import basic
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = Mock()


# Generated at 2022-06-11 06:09:39.158772
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual_fact = SunOSVirtual(dict())
    assert sunos_virtual_fact.platform == 'SunOS'


# Generated at 2022-06-11 06:09:40.172050
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt = SunOSVirtualCollector()

# Generated at 2022-06-11 06:09:44.655487
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Initialize SunOSVirtualCollector object and check its platform
    virt_collector = SunOSVirtualCollector()
    assert virt_collector._platform == 'SunOS'

    # Check is virtual_guest_facts_class property is SunOSVirtual
    assert virt_collector.virtual_guest_facts_class.__name__ == 'SunOSVirtual'


# Generated at 2022-06-11 06:09:46.016945
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule({})
    SunOSVirtual(module)

# Generated at 2022-06-11 06:10:14.363631
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector(None).collect()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 06:10:24.833059
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Tests get_virtual_facts method of class SunOSVirtual in module_utils/facts/virtual/SunOS.py
    """
    module_mock = MockModule()
    module_mock.run_command.side_effect = [
        [90, '', ''],                                                                 # zonename
        [0, os.linesep.join(['VMware Module (%s) 0' % module_mock.get_bin_path('modinfo'),
                             'VirtualBox Module (%s) 0' % module_mock.get_bin_path('modinfo')]), ''], # modinfo
        [0, '', ''],  # virtinfo
        [0, '', 'HVM domU'],  # smbios
    ]

# Generated at 2022-06-11 06:10:30.482477
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector(collect_subset=['virtual'], gather_timeout=10)
    virtual_collector = SunOSVirtualCollector(fact_collector=fact_collector)
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:35.417629
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector(module=None)
    assert facts._platform == 'SunOS'
    assert facts._fact_class.platform == 'SunOS'
    assert issubclass(facts._fact_class, Virtual)

# Unit tests for get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-11 06:10:45.398722
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})

    def get_bin_path(path):
        if path == 'zonename':
            return '/usr/bin/zonename'
        elif path == 'virtinfo':
            return '/usr/sbin/virtinfo'
        elif path == 'smbios':
            return '/usr/sbin/smbios'
        return None

    setattr(v.module, 'get_bin_path', get_bin_path)

    def run_command(cmd):
        if cmd == '/usr/bin/zonename':
            return 0, '/global\n', None
        elif cmd == '/usr/sbin/virtinfo':
            return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false\n', None

# Generated at 2022-06-11 06:10:46.209332
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-11 06:10:48.606946
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector()
    assert facts_collector._platform == 'SunOS'
    assert facts_collector._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:49.037363
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({})

# Generated at 2022-06-11 06:10:56.422823
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-11 06:11:00.481439
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fact_subclass = SunOSVirtual()
    virtual_facts = fact_subclass.get_virtual_facts()
    assert isinstance(virtual_facts.get('virtualization_tech_guest'), set)
    assert isinstance(virtual_facts.get('virtualization_tech_host'), set)

# Generated at 2022-06-11 06:11:52.571399
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v.os_type == 'SunOS'

# Generated at 2022-06-11 06:11:54.453420
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual is not None
    assert virtual.data is not None


# Generated at 2022-06-11 06:11:58.723991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fact_module = SunOSVirtualCollector(dict(), {})
    fact_module.module.run_command = lambda *_, **__: (0, '', '')
    assert 'virtualization_type' in fact_module._fact_class.get_virtual_facts()

# Generated at 2022-06-11 06:12:01.108335
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    output = SunOSVirtualCollector.get_facts()
    assert output['ansible_virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:12:11.372206
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = Mock(return_value=(0, "global", ""))
    module.get_bin_path = Mock(return_value="/usr/sbin/zonename")
    module.facts = dict()

    virtual_facts_collector = SunOSVirtual(module)

    virtual_facts = virtual_facts_collector.get_virtual_facts()

    assert 'container' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-11 06:12:14.036556
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Unit test for constructor of class SunOSVirtualCollector."""
    sunos_virtual = SunOSVirtualCollector()

    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.fact_class._platform == 'SunOS'

# Generated at 2022-06-11 06:12:23.789983
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test setup
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 06:12:28.811627
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = {'distribution': 'SunOS', 'distribution_version': '5.11'}
    things_to_run = {'module_utils.facts.virtual.sunos.SunOSVirtual': os_facts}
    collector = SunOSVirtualCollector(things_to_run, False)
    object_being_tested = collector._objects[0]
    assert object_being_tested._platform == 'SunOS'

# Generated at 2022-06-11 06:12:36.132791
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector(None, None).collect()['ansible_facts']
    if 'ansible_virtualization_type' in facts and \
            facts['ansible_virtualization_type'] != 'zone':
        assert 'ansible_virtualization_role' in facts
        assert 'ansible_container' in facts
        assert 'ansible_virtualization_tech_guest' in facts
        assert 'ansible_virtualization_tech_host' in facts
    else:
        assert 'ansible_virtualization_role' not in facts
        assert 'ansible_container' not in facts
        assert 'ansible_virtualization_tech_guest' not in facts
        assert 'ansible_virtualization_tech_host' not in facts


# Generated at 2022-06-11 06:12:45.948793
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import tempfile
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils._text import to_bytes

    # Create a temporary file for the test and write some data to it
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        filen = tf.name
        tf.write(to_bytes("testing"))

    # Create a fake module for the unit testing

# Generated at 2022-06-11 06:14:48.708532
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class.__name__ == 'SunOSVirtual'
    assert collector._collector_class is None
    assert collector._parent_platforms == ['Platform']
    assert collector._child_platforms is None

# Generated at 2022-06-11 06:14:59.564908
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    with open("unittests/testdata/SunOS_system_properties") as sysprop_file:
        sysprop_output = sysprop_file.read()
    with open("unittests/testdata/SunOS_smbios_f") as smbios_file:
        smbios_output = smbios_file.read()
    with open("unittests/testdata/SunOS_zonename") as zonename_file:
        zonename_output = zonename_file.read()
    with open("unittests/testdata/SunOS_virtinfo") as virtinfo_file:
        virtinfo_output = virtinfo_file.read()

    def sysprop(module, args):
        return 0, sysprop_output, ""

    def smbios(module, args):
        return 0, sm

# Generated at 2022-06-11 06:15:00.735279
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-11 06:15:07.453084
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of SunOSVirtual object
    v = SunOSVirtual({})
    # Check if it has attribute _module
    assert hasattr(v, 'module')
    # Check if it has method get_virtual_facts
    assert callable(getattr(v, 'get_virtual_facts', None))
    # Get the value of attribute _module
    module = v._module
    # Create a new module
    module = type('', (object,), dict(run_command=run_command_mock, get_bin_path=get_bin_path_mock))
    # Set new module as _module attribute
    v._module = module
    # Call method get_virtual_facts

# Generated at 2022-06-11 06:15:09.965202
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec=dict())
    result = SunOSVirtual(module=module)
    assert(result.collect())

# Generated at 2022-06-11 06:15:16.852801
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual instance for testing purpose
    sunos_virtual = SunOSVirtual(None)
    # Mock the module methods
    sunos_virtual.module.run_command = lambda command: (0, "", "")
    sunos_virtual.module.get_bin_path = lambda command: "/usr/sbin/" + command
    # Call the method get_virtual_facts
    facts = sunos_virtual.get_virtual_facts()
    # Check the returned virtualization type
    assert facts['virtualization_type'] == 'kvm'
    # Check the returned virtualization role
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:15:18.918051
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt = SunOSVirtual(module)
    assert virt.platform == "SunOS"
    assert virt.get_virtual_facts() == {}


# Generated at 2022-06-11 06:15:21.309159
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({'module_setup': False})
    # Can't test any properties since they are all the same as superclass

    # Can't test methods since they are all the same as superclass


# Generated at 2022-06-11 06:15:23.163485
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert isinstance(virtual, Virtual)


# Generated at 2022-06-11 06:15:29.977551
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import os
    import sys
    os_path = os.path.realpath(os.path.dirname(sys.argv[0]))
    os.environ['PATH'] = os_path + os.pathsep + os.environ['PATH']
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    collector = SunOSVirtualCollector(module=module)
    facts = collector.get_facts()
    assert facts['virtualization_tech_guest'].issubset(facts['virtualization_tech_host'])
    assert facts['virtualization_type'] in ['vmware', 'virtualbox', 'ldom']