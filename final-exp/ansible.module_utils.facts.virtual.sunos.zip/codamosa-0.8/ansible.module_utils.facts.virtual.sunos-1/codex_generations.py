

# Generated at 2022-06-11 06:07:49.698957
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    import platform
    import sys
    import unittest

    class Mock(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, name, required=False):
            if name in ('zonename', '/usr/bin/zonename'):
                return '/usr/bin/zonename'
            elif name in ('modinfo', '/usr/sbin/modinfo'):
                return '/usr/sbin/modinfo'
            elif name in ('virtinfo', '/usr/sbin/virtinfo'):
                return '/usr/sbin/virtinfo'
            elif name in ('smbios', '/usr/sbin/smbios'):
                return '/usr/sbin/smbios'
            return None


# Generated at 2022-06-11 06:07:51.907201
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(None)
    assert s.get_virtual_facts() is None
    assert s.platform == "SunOS"

# Generated at 2022-06-11 06:07:55.118949
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert isinstance(obj, SunOSVirtualCollector)
    assert isinstance(obj.platform, str)
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 06:08:05.164401
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mock_module = MockModule({})
    mock_module.run_command = Mock(return_value=(0, 'global', ""))

    # If it's a zone check if we can detect if our global zone is itself virtualized.
    # Relies on the "guest tools" (e.g. vmware tools) to be installed

# Generated at 2022-06-11 06:08:15.442542
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import os
    import unittest
    import ansible.module_utils.facts.virtual.sunos as sunos

    class module_mock():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, bin_path):
            return "/usr/bin/" + bin_path

        def run_command(self, bin_path):
            if bin_path == "zonename":
                return 0, "global", ""
            elif bin_path == "modinfo":
                return 0, "modules:", ""
            elif bin_path == "virtinfo":
                return 0, "DOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=false", ""

# Generated at 2022-06-11 06:08:24.656842
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.system.sunos import SunOSSystem
    from ansible.module_utils.facts.system.base import BaseSystem
    from ansible.module_utils._text import to_bytes

    # Test SunOSVirtual().get_virtual_facts() non-zone/global zone
    SunOSVirtual.zones_cmd = '/tmp/zones'

    # Test SunOSVirtual().get_virtual_facts() zone
    SunOSVirtual.zones_cmd = '/tmp/zones'
    SunOSVirtual.modinfo_cmd = '/tmp/modinfo'
    SunOSVirtual.virtinfo_cmd = '/tmp/virtinfo'
    SunOSVirtual.smbios_cmd = '/tmp/smbios'

    # Test Sun

# Generated at 2022-06-11 06:08:28.275827
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: x
    SunOSVirtual_instance = SunOSVirtual(module)
    SunOSVirtual_instance.get_virtual_facts() # should not fail

# Generated at 2022-06-11 06:08:33.563049
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible_collections.ansible.misc.tests.unit.modules.utils import set_module_args
    module_args = dict()
    set_module_args(module_args)
    c = SunOSVirtualCollector()
    assert c.get_virtual_facts().keys() == ['virtualization_tech_host', 'virtualization_tech_guest']

# Generated at 2022-06-11 06:08:42.771905
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    if sys.version_info < (3,):
        open_fixture = '__builtin__.open'
    else:
        open_fixture = 'builtins.open'

# Generated at 2022-06-11 06:08:44.950651
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    assert isinstance(x._fact_class, SunOSVirtual)
    assert x._fact_class.platform == "SunOS"

# Generated at 2022-06-11 06:09:03.208032
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirt = SunOSVirtual()
    assert sunosvirt.platform == "SunOS"
    assert sunosvirt.virtualization_type == {}
    assert sunosvirt.virtualization_role == {}
    assert sunosvirt.container == {}
    assert sunosvirt.virtualization_tech_guest == set()
    assert sunosvirt.virtualization_tech_host == set()


# Generated at 2022-06-11 06:09:12.410415
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule({'PATH': '/usr/bin'})
    virtual = SunOSVirtual(module)

    # zone
    zone_guest_facts = {
        "container": "zone",
        "virtualization_role": "guest",
        "virtualization_type": "zone",
        "virtualization_tech_host": {
            "zone"
        },
        "virtualization_tech_guest": {
            "zone"
        }
    }

    # branded zone

# Generated at 2022-06-11 06:09:13.354520
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)

# Generated at 2022-06-11 06:09:16.351038
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos = SunOSVirtual(None)
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-11 06:09:25.454520
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    setattr(module, 'run_command', MagicMock(return_value=(0, 'global', '')))
    setattr(module, 'get_bin_path', MagicMock(return_value=True))
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert set(['zone', 'global']) == facts['virtualization_tech_host']
    assert set() == facts['virtualization_tech_guest']
    assert 'zone' == facts['container']
    assert 'host' == facts['virtualization_role']
    assert 'zone' == facts['virtualization_type']


# Generated at 2022-06-11 06:09:28.908996
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    result = SunOSVirtual(module).get_virtual_facts()
    assert result.get('virtualization_type') is None
    assert result.get('virtualization_role') is None
    assert result.get('container') is None

# Generated at 2022-06-11 06:09:31.764576
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert isinstance(c, SunOSVirtualCollector)
    assert isinstance(c._fact_class, SunOSVirtual)
    assert hasattr(c, '_platform')

# Generated at 2022-06-11 06:09:34.085223
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Always return 'unknown' as no way to test on non-SunOS
    v = SunOSVirtual()
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-11 06:09:43.916051
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModule(
        argument_spec = dict()
    )
    os_obj=SunOSVirtual(module=module)

    # Test SunOS zone
    os_obj.module.run_command=MagicMock(return_value=(0, "global\n", ""))
    os_obj.get_virtual_facts()
    assert os_obj.facts['virtualization_role'] == 'host'
    assert os_obj.facts['virtualization_type'] == 'zone'
    assert os_obj.facts['virtualization_tech_host'] == set(['zone'])

    # Test SunOS branded zone
    os_obj.module.run_command=MagicMock(return_value=(0, "global\n", ""))
    os_obj.get_virtual_facts()

# Generated at 2022-06-11 06:09:53.710043
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    virtual = SunOSVirtual(module)


# Generated at 2022-06-11 06:10:19.091524
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector().platform == 'SunOS'

# Generated at 2022-06-11 06:10:24.446990
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    virtual_collector = SunOSVirtualCollector(module=module)
    virtual = SunOSVirtual(collector=virtual_collector)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts is not None

# Generated at 2022-06-11 06:10:34.609797
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a simple module to be able to test the method
    m = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    c = SunOSVirtualCollector(m)
    c.collect()

    virtual_facts = c._fact_class.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == {'kvm', 'vmware'}
    assert virtual_facts['virtualization_tech_host'] == {'zone'}
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-11 06:10:36.358022
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert isinstance(v, SunOSVirtual)
    assert isinstance(v, Virtual)

# Generated at 2022-06-11 06:10:40.455843
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Create an instance of SunOSVirtual class.
    """
    # Create an instance of class SunOSVirtual
    sunos_virtual = SunOSVirtual(None)

    # Assert that the SunOSVirtual class has been initialized correctly
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:10:42.751726
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-11 06:10:44.875925
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    try:
        SunOSVirtualCollector()
    except:
        assert 0, 'Failed to create object SunOSVirtualCollector'

# Generated at 2022-06-11 06:10:49.827088
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # If there is no smbios command on the system, we cannot test anything.
    if not os.path.exists('/usr/sbin/smbios'):
        return True

    vm = SunOSVirtual({'module_setup': True})
    assert vm.get_virtual_facts()['virtualization_type'] == 'kvm'
    assert vm.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:10:53.088631
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector.platforms == {'SunOS'}
    assert SunOSVirtualCollector.priority == 13


# Generated at 2022-06-11 06:10:55.477722
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {
        'system': 'SunOS'
    }
    virtual_collector = SunOSVirtualCollector(facts, None)
    assert virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 06:11:48.195003
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of SunOSVirtual
    """
# TODO

# Generated at 2022-06-11 06:11:49.677680
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert True is True

# Generated at 2022-06-11 06:12:01.021306
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class TestModule:
        def get_bin_path(bin_path):
            if bin_path == 'zonename':
                return 1
            if bin_path == 'virtinfo':
                return 1
            return 0

        def run_command(command):
            if command == 'zonename':
                return (0, 'global', '')
            if command == 'smbios':
                return (0, '', '')
            if command == 'smbios -s system-manufacturer':
                return (0, 'Manufacturer', '')
            if command == 'smbios -s system-product-name':
                return (0, 'Product', '')
            if command == 'smbios -s system-version':
                return (0, 'KVM', '')

# Generated at 2022-06-11 06:12:03.265121
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    os_virtual = SunOSVirtual(module)
    module.run_command.assert_called_with("zonename")

# Generated at 2022-06-11 06:12:13.041550
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Define test parameters
    params = {}
    # Define test results
    expected_results = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'container': None,
        'virtualization_tech_guest': set(['xen', 'zone']),
        'virtualization_tech_host': set(['zone'])
    }

    # Define test object
    test_obj = SunOSVirtual(params)

    # Define test responses

# Generated at 2022-06-11 06:12:14.406313
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunv = SunOSVirtual({}, {})
    assert sunv.platform == 'SunOS'



# Generated at 2022-06-11 06:12:24.264637
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a new instance of class SunOSVirtual
    test_instance = SunOSVirtual()

    # Test the virtualization role of a global zone with virtualization
    # technology installed
    facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'virtualbox',
        'virtualization_tech_guest': set(['zone', 'virtualbox']),
        'virtualization_tech_host': set(['zone']),
        'container': 'zone'
    }
    # Inject method run_command into test_instance
    def fake_run_command(command):
        (rc, out, err) = (0, 'VirtualBox\n', '')
        return (rc, out, err)
    test_instance.run_command = fake_run_command
    # Inject method isdir into test_

# Generated at 2022-06-11 06:12:27.508622
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    ubuntu_virtual_collector = SunOSVirtualCollector()
    assert(ubuntu_virtual_collector.platform == 'SunOS')
    assert(ubuntu_virtual_collector.fact_class == SunOSVirtual)


# Generated at 2022-06-11 06:12:35.711136
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create an instance of SunOSVirtual
    sunos_virtual = SunOSVirtual()
    # Update a fake module
    sunos_virtual.module = FakeModule()
    # Create a fake zonename binary
    zonename = FakeBin("zonename", [0, "global"], "")
    sunos_virtual.module.set_bin_path("zonename", zonename)
    # Create a fake modinfo binary
    modinfo = FakeBin("modinfo", [0, "", ""], "")
    sunos_virtual.module.set_bin_path("modinfo", modinfo)
    # Create a fake virtinfo binary
    virtinfo = FakeBin("virtinfo", [0, "", ""], "")
    sunos_virtual

# Generated at 2022-06-11 06:12:39.301180
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.collector import Collector, ModuleDeprecationWarning
    import warnings

    warnings.simplefilter('error', ModuleDeprecationWarning)
    try:
        collector = SunOSVirtualCollector()
    except ModuleDeprecationWarning:
        assert isinstance(collector, Collector)

# Generated at 2022-06-11 06:14:42.472148
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Nothing to test for the moment
    pass

# Generated at 2022-06-11 06:14:52.203187
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    os_virtual = SunOSVirtual()
    os_virtual.module = Mock()

    os_virtual.module.get_bin_path.return_value = '/usr/bin/zonename'

    os_virtual.module.run_command.return_value = (0, 'global\n', '')
    virtual_facts = os_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])

    os_virtual.module.run_command.return_value = (0, 'zones\n', '')
    virtual_facts = os_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['container'] == 'zone'

    os_virtual.module.get_bin_path

# Generated at 2022-06-11 06:14:56.009173
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    facts = SunOSVirtual(None, None)
    assert facts.platform == 'SunOS'

# Generated at 2022-06-11 06:15:04.619748
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Define helper object
    class FakeModule(object):
        class FakeArgs(object):
            gather_subset = []

        def __init__(self):
            self.params = self.FakeArgs()
            self.run_command_calls = []
            self.run_command_patterns = {}
            self.fail_json_msg = None
            self.fail_json_rc = 0
            self.fail_json_exception = None
            self.run_command_exceptions = []
            self.get_bin_path_returns = []

        @property
        def _debug(self):
            return True

        def fail_json(self, msg=None, rc=1, exception=None):
            self.fail_json_msg = msg
            self.fail_json_rc = rc
            self.fail_

# Generated at 2022-06-11 06:15:05.735450
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-11 06:15:09.067408
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt.get_virtual_facts().get('virtualization_type') is None
    assert virt.get_virtual_facts().get('virtualization_type') is None

# Generated at 2022-06-11 06:15:17.649309
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual

    ac = virtual._AnsibleModuleHelper(
        argument_spec=dict(),
        supports_check_mode=False,
        no_log=True,
    )
    s = SunOSVirtual(ac)

    # Test with container.zone
    ac.run_command = get_run_command_mock(0, 'global', '')
    facts = s.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == {'zone'}
    assert facts['container'] == 'zone'

    # Test with sys_info.product_name.sun4v
    s

# Generated at 2022-06-11 06:15:19.899893
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x is not None
    assert x._platform == 'SunOS'
    y = x.get_virtual_facts()
    assert y is None


# Generated at 2022-06-11 06:15:21.457312
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(module=dict()))
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-11 06:15:23.979382
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Returns true if the constructor for class SunOSVirtualCollector works
    """
    obj = SunOSVirtualCollector()
    return obj is not None