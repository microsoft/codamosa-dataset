

# Generated at 2022-06-23 02:34:47.575554
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create class instance to test
    module = AnsibleModuleMock()
    SunOSVirtualObj = SunOSVirtual(module)

    # Not a zone: vmware host
    module.run_command.return_value = (0, 'VMware', '')
    module.get_bin_path.side_effect = lambda x: x

    virtual_facts = SunOSVirtualObj.get_virtual_facts()

    module.run_command.assert_called_with('zonename')
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmware'])

    # Not a zone: vmware guest
    module

# Generated at 2022-06-23 02:34:49.852998
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual(dict(module=dict(params=dict())))
    assert x.platform == 'SunOS'


# Generated at 2022-06-23 02:35:00.748555
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MagicMock()
    file_name = 'file_name'
    file_cont = 'file_cont'
    data = {'file_name': file_cont}

    temp_folder = tempfile.mkdtemp()
    sample_vmware_file = os.path.join(temp_folder, 'vmware_sample_file')
    with open(sample_vmware_file, 'w') as f:
        f.write(file_cont)
    module.get_bin_path.return_value = sample_vmware_file
    module.get_bin_path.return_value = '/bin/zonename'
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.return_value = '/bin/modinfo'

# Generated at 2022-06-23 02:35:10.866371
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()

    # Test zone
    zone = SunOSVirtual(module)
    zone.module.run_command.return_value = (0, "test", None)
    facts = zone.get_virtual_facts()
    assert 'container' in facts and facts['container'] == 'zone'

    # Test branded zone
    zone = SunOSVirtual(module)
    zone.module.run_command.return_value = (0, "global", None)
    zone.module.isdir.return_value = True
    facts = zone.get_virtual_facts()
    assert 'container' in facts and facts['container'] == 'zone'

    # Test vmware ldom guest
    ldom = SunOSVirtual(module)
    ldom.module.run_command.return_value = (0, "VMware", None)
   

# Generated at 2022-06-23 02:35:13.340932
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock({})
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:35:16.812915
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.__class__ == SunOSVirtualCollector

# Test class SunOSVirtualCollector
# Test that SunOSVirtualCollector returns a SunOSVirtual object
#

# Generated at 2022-06-23 02:35:19.684459
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc
    assert vc._fact_class
    assert vc._platform


# Generated at 2022-06-23 02:35:21.330007
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual()
    assert(s.platform == 'SunOS')

# Generated at 2022-06-23 02:35:23.148950
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor of SunOSVirtual class can be called without arguments
    """
    SunOSVirtual()

# Generated at 2022-06-23 02:35:35.167890
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import os
    import sys
    import imp
    import signal
    import platform
    import copy
    import tempfile
    import shutil

    # Set up a mock module
    module = imp.new_module('test_module')
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda arg: arg
    sys.modules['ansible.module_utils.facts.virtual.sunos'] = module

    # Set up a mock module for the base class
    base_module = imp.new_module('virtual')
    sys.modules['ansible.module_utils.facts.virtual.base'] = base_module

    # Set up a mock VirtualCollector
    virtual_collector_module = imp.new_module('virtual_collector')
    virtual_collector

# Generated at 2022-06-23 02:35:45.633028
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()

# Generated at 2022-06-23 02:35:50.336491
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Monty Python's Flying Circus
    """
    virt = SunOSVirtual(None)
    assert virt.platform == 'SunOS', "Run of SunOSVirtual.__init__() should be OK, no exception raised"

if __name__ == '__main__':
    # Test the above code
    test_SunOSVirtual()

# Generated at 2022-06-23 02:35:52.234689
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector(dict())
    assert isinstance(vc, SunOSVirtualCollector)


# Generated at 2022-06-23 02:35:58.709175
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = dict()
    virtual_collector = SunOSVirtualCollector(facts, None)
    assert virtual_collector._facts == facts  # pylint: disable=protected-access
    assert virtual_collector._platform == 'SunOS'  # pylint: disable=protected-access
    assert virtual_collector._fact_class == SunOSVirtual  # pylint: disable=protected-access

# Generated at 2022-06-23 02:36:00.789947
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)

# Generated at 2022-06-23 02:36:12.554639
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)

    # Test output of when we are not in a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value=True)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': 'zone',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'zone'},
        'container': None
    }

    # Test output of when we are in a non global zone
    module.run_command = MagicMock(return_value=(0, 'local', ''))
    module.get_

# Generated at 2022-06-23 02:36:21.650727
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.params = {'gather_subset': "!all,!min"}
    module.run_command = FakeRunCommand([0, "", ""])
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:36:26.159182
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts


# Generated at 2022-06-23 02:36:29.188630
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    module.run_command = Fake_run_command
    virtual = SunOSVirtual(module)
    assert (virtual.platform == 'SunOS')


# Generated at 2022-06-23 02:36:34.690232
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    import unittest
    from ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos.SunOSVirtual import SunOSVirtual
    import ansible.module_utils.facts.virtual as virtual

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def get_bin_path(self, *args, **kwargs):
            return '/bin/' + args[0]

        def run_command(self, *args, **kwargs):
            return 0, '', ''

# Generated at 2022-06-23 02:36:46.888375
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import json

    virtual_facts = SunOSVirtual()

    # Unit test for a global zone on bare metal
    result = virtual_facts.get_virtual_facts()
    assert result == {
        'container': None,
        'virtualization_role': None,
        'virtualization_type': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Unit test for a global zone on bare metal
    result = virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:36:57.984289
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    import os
    import subprocess
    import platform
    import tempfile
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking'))
    from test.units.modules.utils import set_module_args

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp mount point
    tmpmnt = os.path.join(tmpdir, "mnt")
    if not os.path.exists(tmpmnt):
        os.makedirs(tmpmnt)

    # Mount the proc file system
    subprocess.check_call(["mount", "-F", "proc", "/proc", tmpmnt])

    # Save path of the root directory
    rootdir = os.get

# Generated at 2022-06-23 02:37:00.119476
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vm = SunOSVirtual()
    assert vm is not None, "Unable to instantiate SunOSVirtual class"


# Generated at 2022-06-23 02:37:03.119140
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None

# Generated at 2022-06-23 02:37:14.115378
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector.virtual import SunOSVirtual

    # Set up an instance of the class
    test_virtual_instance = SunOSVirtual({'module': mock_module})

    # Create a mock object for module.run_command
    mock_run_command = mock_module.run_command = Mock()

    # Set up the parameters required for module.run_command
    mock_run_command.return_value = 0, '', ''

    # Set up the output of the module.get_bin_path method
    mock_module.get_bin_path.side_effect = ['', '/usr/sbin/virtinfo', '/usr/sbin/smbios']

    # Set up the output of the module.get_file_content method

# Generated at 2022-06-23 02:37:15.984841
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = get_module_mock()
    result = SunOSVirtual(module)
    assert result


# Generated at 2022-06-23 02:37:25.040394
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    sunos = SunOSVirtual(module)
    virtual_facts = sunos.get_virtual_facts()
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'


# Tests for module

# Generated at 2022-06-23 02:37:30.698092
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict(), dict())
    assert isinstance(virt.platform, type(u''))
    assert isinstance(virt.virtualization_type, type(u''))
    assert isinstance(virt.virtualization_role, type(u''))
    assert isinstance(virt.virtualization_system, type(u''))
    assert isinstance(virt.container, type(u''))

# Generated at 2022-06-23 02:37:32.723629
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()

    assert obj.platform == 'SunOS'
    assert obj._fact_class is SunOSVirtual



# Generated at 2022-06-23 02:37:43.922891
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    virtual = SunOSVirtual(module=module)
    virtual._get_zone_name = Mock(return_value=('global', 0, None))
    virtual._get_zonename_output_as_dict = Mock(return_value={'zonename': 'global'})
    virtual._get_zone_brand = Mock(return_value=('native', None))
    virtual._get_virtinfo_edom_role = Mock(return_value=(
        'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false|primary=false\n',
        0, None
    ))
    virtual._get_smbios_output = Mock(return_value='')
    virtual.module.run_command = Mock(return_value=(1, '', ''))


# Generated at 2022-06-23 02:37:45.535206
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc is not None

# Generated at 2022-06-23 02:37:50.321823
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virt_type == 'SunOS'
    assert isinstance(sunos_virtual.virtual, SunOSVirtual)
    assert isinstance(sunos_virtual.virtual, Virtual)

# Generated at 2022-06-23 02:37:51.389916
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:00.206555
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.generic import VirtualInfo
    module = VirtualInfo(dict(ANSIBLE_MODULE_ARGS={'gather_subset': 'all', 'gather_timeout': 10}))

    setattr(module, 'run_command', lambda *args, **kwargs: (0, 'zone\n', ''))
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/bin/zonename')
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['container'] == 'zone'

    setattr(module, 'run_command', lambda *args, **kwargs: (1, '', 'virtinfo does not work'))
    set

# Generated at 2022-06-23 02:38:02.635115
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(None)
    assert virt.platform == 'SunOS'

# Generated at 2022-06-23 02:38:05.558487
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

    assert x._platform == 'SunOS', "_platform not set to 'SunOS'"
    assert x._fact_class == SunOSVirtual, "_fact_class not set to 'SunOSVirtual'"

# Generated at 2022-06-23 02:38:09.202987
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mod = SunOSVirtualCollector()
    assert mod is not None, 'Failed in creating object for SunOSVirtualCollector class'
    assert mod.platform == 'SunOS'

# Generated at 2022-06-23 02:38:16.321210
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    # check type of returned object
    assert isinstance(virtual_facts, SunOSVirtual)
    # test attribute platform
    assert virtual_facts.platform == 'SunOS'
    # test method get_virtual_facts
    results = virtual_facts.get_virtual_facts()
    assert 'virtualization_role' in results
    assert 'virtualization_type' in results
    assert 'virtualization_tech_guest' in results
    assert 'virtualization_tech_host' in results

# Generated at 2022-06-23 02:38:22.094170
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test with an empty 'sysinfo'
    sunos_virtual = SunOSVirtual({})

    # Test with a 'sysinfo' dict with SunOS
    sunos_virtual = SunOSVirtual({'system_vendor': { 'manufacturer': 'Sun Microsystems' }})

# Generated at 2022-06-23 02:38:24.397141
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._fact_class == SunOSVirtual
    assert c._platform == 'SunOS'



# Generated at 2022-06-23 02:38:35.306904
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    data = {
        'kernel': 'SunOS',
    }

    vm = SunOSVirtual(Collector(basic.AnsibleModule(data=data)))
    vmfacts = vm.get_virtual_facts()

    assert 'virtualization_type' in vmfacts
    assert 'virtualization_role' in vmfacts
    assert 'virtualization_tech_guest' in vmfacts
    assert 'virtualization_tech_host' in vmfacts
    # TODO: check this test to be sure it is applicable to all the SunOS supported version
    assert vmfacts['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:38:44.431714
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test the virtual facts function
    """
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    def test_module(module):
        """
        Mock ansible module
        """
        class FoobarModule(object):
            def __init__(self):
                self.params = {}
            def fail_json(self, fail):
                pass
            def get_bin_path(self, foo):
                return True
            def run_command(self, cmd):
                return 0, "output", "error"
        return FoobarModule()

    sunos = SunOSVirtual(test_module(None))
    result = sunos.get_virtual_facts()
    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:38:50.358621
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    ''' This method will instantiate an instance of
    the SunOSVirtualCollector Class'''
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual._fact_class == SunOSVirtual
    assert sunos_virtual._platform == 'SunOS'

# Generated at 2022-06-23 02:38:54.022616
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj1 = SunOSVirtualCollector()
    obj2 = SunOSVirtualCollector()

    assert obj1._fact_class == SunOSVirtual
    assert obj1._platform == 'SunOS'
    assert obj1._fact_class is obj2._fact_class
    assert obj1._platform is obj2._platform

# Generated at 2022-06-23 02:38:55.081289
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:56.563278
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual._platform == 'SunOS'

# Generated at 2022-06-23 02:39:03.955554
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # FIXME: Do not use VirtualCollector._set_hard_facts()
    SunOSVirtualCollector._set_hard_facts()
    # FIXME: Do not rely on the fact manager
    SunOSVirtualCollector.set_module()
    facts = SunOSVirtualCollector(SunOSVirtualCollector.module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:39:04.565995
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    pass

# Generated at 2022-06-23 02:39:09.236450
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/sbin/zonename'
    module.run_command.return_value = (0, "global\n", '')
    resource = SunOSVirtual(module)
    facts = resource.get_virtual_facts()
    assert facts['container'] == 'zone'
    assert facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:39:10.391617
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.facts == {}

# Generated at 2022-06-23 02:39:19.501220
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('Module', (object,), {'params': {}, 'run_command': lambda self, *args, **kwargs: (0, "", "")})
    virtual = SunOSVirtual(module)

    # Check platform
    assert virtual.platform == 'SunOS'

    # Check get_virtual_facts with virtualbox guest
    module.params['gather_subset'] = ['!all', '!any']
    module.run_command = lambda self, *args, **kwargs: (0, "", "Vendor: Oracle Corporation\nProduct: VirtualBox\n")
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-23 02:39:21.921918
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    vc = SunOSVirtualCollector(facts, None)
    assert issubclass(vc._fact_class, Virtual)
    assert vc._platform == 'SunOS'

# Generated at 2022-06-23 02:39:24.669413
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:28.555506
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    The constructor of the class SunOSVirtualCollector does not take any argument
    and returns a SunOSVirtualCollector object.
    """
    sun = SunOSVirtualCollector()
    assert isinstance(sun, SunOSVirtualCollector)

# Generated at 2022-06-23 02:39:38.702806
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Initialize SunOSVirtual
    #   Input:    platform_virtual = SunOS, module = None
    #   Expect:   object of class SunOSVirtual, platform = SunOS
    test_virt = SunOSVirtual(platform_virtual='SunOS', module=None)

    # Check if initialized object is of class SunOSVirtual
    assert isinstance(test_virt, SunOSVirtual)

    # Check if initialized object has correct platform
    assert test_virt.platform == 'SunOS'

    # Check if initialized object has correct platform_virtual
    assert test_virt.platform_virtual == 'SunOS'

    # Check if initialized object has correct module
    assert test_virt.module == None

    # Check if initialized object has correct os_family
    assert test_virt.os_family == 'Solaris'

    # Check if initialized object has correct container
   

# Generated at 2022-06-23 02:39:43.842370
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """ This function tests the constructor of SunOSVirtualCollector. """
    my_obj = SunOSVirtualCollector()
    assert my_obj
    assert isinstance(my_obj, SunOSVirtualCollector)
    assert my_obj._fact_class is SunOSVirtual
    assert my_obj._platform == 'SunOS'

# Generated at 2022-06-23 02:39:55.634394
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand({'zonename': ['global'], '': ['', '', 0], 'modinfo': ['id: virtio', '', 0]})
    module.get_bin_path = lambda x: 'command'
    module.params = {}
    virtual = SunOSVirtual(module)
    output = virtual.get_virtual_facts()
    assert output == {'virtualization_role': 'host (control)', 'virtualization_type': 'zone',
                      'container': 'zone', 'virtualization_tech_host': set(['zone']),
                      'virtualization_tech_guest': set(['zone'])}


# Generated at 2022-06-23 02:39:57.421928
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, {})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-23 02:39:59.247318
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    The constructor of the class SunOSVirtualCollector
    """
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:13.418893
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    # Mock module
    module = VirtualCollector.get_module()

    # Facts
    module.run_command = lambda x: (0, "VMware\n", "")

    # Test
    vf = SunOSVirtual(module)
    res = vf.get_virtual_facts()
    assert 'virtualization_type' in res
    assert 'virtualization_role' in res

    # Facts
    module.run_command = lambda x: (0, "Xen\n", "")

    # Test
    vf = SunOSVirtual(module)
    res = vf.get_virtual_facts()
    assert 'virtualization_type' in res

# Generated at 2022-06-23 02:40:23.879962
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import FactCollector

    class Module:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/sbin/%s' % arg

        def run_command(self, arg, opt_dirs=[], data=None):
            if arg == "/usr/sbin/zonename":
                return 0, "global\n", ""
            if arg == "/usr/sbin/modinfo":
                return 0, "", ""

# Generated at 2022-06-23 02:40:33.973372
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    # Setup the class we are testing
    SunOSVirtualCollector.set_available()
    sv = SunOSVirtual(None)

    # Make test data available to the test
    test_data = {}
    testdata_dir = os.path.dirname(os.path.realpath(__file__)) + '/data/'
    test_data['zone_files'] = testdata_dir + 'zone_files/'
    test_data['zone_models'] = testdata_dir + 'zone_models/'

    # Fake the command 'zonename'
    sv.module.run_command = myRun_command_zonename

    # Fake the method 'is_

# Generated at 2022-06-23 02:40:40.349664
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Given a SunOSVirtual object
    fake_module = FakeModule(platform='SunOS')
    sun_virtual = SunOSVirtual(module=fake_module)

    # when executing the get_virtual_facts method
    virtual_facts = sun_virtual.get_virtual_facts()

    # then the result of the method is as expected
    assert virtual_facts == {'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['vmware'])}



# Generated at 2022-06-23 02:40:42.297960
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:47.863749
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector({}, None).collect()
    virtual_facts = facts['virtual']
    assert type(virtual_facts) is dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:40:51.806130
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.data.get('virtualization_type') is None
    assert virtual.data.get('virtualization_role') is None
    assert virtual.data.get('container') is None

# Generated at 2022-06-23 02:40:55.970289
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector().platform == 'SunOS'
    assert SunOSVirtualCollector()._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:58.407027
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:00.615627
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == 'SunOS'
    assert virtual_facts._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:03.053094
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts_collector = SunOSVirtualCollector()
    assert virtual_facts_collector._fact_class == SunOSVirtual
    assert virtual_facts_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:41:07.031209
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt.get_virtual_facts() == dict(
        virtualization_role = None,
        virtualization_type = None,
        container = None,
        virtualization_tech_guest = set(),
        virtualization_tech_host = set()
    )


# Generated at 2022-06-23 02:41:17.084664
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    facts_collector = SunOSVirtual(module)

    # Test on a host with sunos
    virtual_facts = facts_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'host (cpu,io,control)'
    assert 'container' not in virtual_facts

    # Test on a guest of a global zone
    facts_collector.run_command = run_command_globalzone_guest
    virtual_facts = facts_collector.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'

    # Test on a global zone itself
    facts_collector.run_command = run_command_globalzone_host

# Generated at 2022-06-23 02:41:23.575225
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
        Calling constructor of class SunOSVirtual
        with argument 'module' having its
        attribute 'get_bin_path' returning 'test'
        must return an instance of this class.
    '''
    class ModuleMock(object):
        def get_bin_path(self, path):
            return 'test'
    module = ModuleMock()
    virtual = SunOSVirtual(module)
    assert virtual.module == module

# Generated at 2022-06-23 02:41:26.044920
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual()
    assert isinstance(s.virtual_facts, dict)
    assert isinstance(s.platform, str)
    assert s.platform == "SunOS"


# Generated at 2022-06-23 02:41:36.048300
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Constructor for class SunOSVirtual
    SunOSVirtualObject = SunOSVirtual({})

    # Test for method _get_virtual_facts of class SunOSVirtual
    virtual_facts = {'virtualization_type': 'zone', 'container': 'zone', 'virtualization_role': 'guest'}
    SunOSVirtualObject.module.run_command = lambda args, kwargs: (0, 'global', '')
    assert SunOSVirtualObject.get_virtual_facts() == virtual_facts

    virtual_facts = {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_type': 'virtualbox'}
    SunOSVirtualObject.module.run_command = lambda args, kwargs: (0, 'global', '')

# Generated at 2022-06-23 02:41:42.963502
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    if (c.platform != c._platform):
        raise AssertionError("Did not properly set platform")
    if (c.fact_class != c._fact_class):
        raise AssertionError("Did not properly set fact_class")


# Generated at 2022-06-23 02:41:44.611296
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert SunOSVirtual(None).get_virtual_facts() is None

# Generated at 2022-06-23 02:41:54.664246
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, "test_output", ""))
    module.get_bin_path = Mock(return_value="/bin/test_bin")
    os.path.isdir = Mock(return_value=True)
    os.path.exists = Mock(return_value=True)
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'zone',
                                                 'container': 'zone', 'virtualization_tech_host': set(),
                                                 'virtualization_tech_guest': set(['zone'])}
    module.get_bin_path.return_value = None
    assert sunos_virtual.get_virtual

# Generated at 2022-06-23 02:41:57.029164
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    f = SunOSVirtualCollector()
    assert isinstance(f, VirtualCollector)

# Generated at 2022-06-23 02:41:59.499990
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    return_value = SunOSVirtual(dict())
    assert return_value is not None


# Generated at 2022-06-23 02:42:02.624872
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector
    """
    sunos_vc = SunOSVirtualCollector()
    assert sunos_vc


# Generated at 2022-06-23 02:42:12.034598
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # see https://github.com/ansible/ansible/issues/17376
    sunos_virtual_facts = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'container': 'zone'}
    module = FakeAnsibleModule()
    virtual_facts_collector = SunOSVirtualCollector(module)
    virtual_facts = virtual_facts_collector.collect(sunos_virtual_facts, False)
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'



# Generated at 2022-06-23 02:42:15.561271
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Checking if the VirtualCollector constructor for SunOS works"""
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:42:25.359182
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()

    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/usr/sbin/' + x

    vc = SunOSVirtual(module=module)
    facts = vc.get_virtual_facts()

    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['container'] == 'zone'



# Generated at 2022-06-23 02:42:34.345100
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Check that get_virtual_facts returns a dict for each virtualization technology found.
       The only available virtualization technologies are branded zones and zones. """
    from ansible.module_utils.facts import ModuleConfig
    fake_module = ModuleConfig()
    fake_module.run_command = lambda x: (0, '', '')
    fake_module.get_bin_path = lambda x: '/usr/sbin/zoneadm'
    fake_facts = SunOSVirtual(fake_module)
    virtual_facts = fake_facts.get_virtual_facts()
    assert set(virtual_facts['virtualization_tech_guest']) == set(['zone'])


# Generated at 2022-06-23 02:42:36.321010
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.get_virtual_facts() is False


# Generated at 2022-06-23 02:42:43.166116
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.module.get_bin_path('modinfo') == '/usr/sbin/modinfo'
    assert sunos_virtual.module.get_bin_path('virtinfo') == '/usr/sbin/virtinfo'
    assert sunos_virtual.module.get_bin_path('zonename') == '/usr/sbin/zonename'
    assert sunos_virtual.module.get_bin_path('smbios') == '/usr/sbin/smbios'

# Generated at 2022-06-23 02:42:44.903850
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hv_facts = SunOSVirtual({})
    assert hv_facts._platform == 'SunOS'

# Generated at 2022-06-23 02:42:57.230412
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test case: zone
    module = AnsibleModule(command_features={'check_invalid_arguments': False})
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_tech_guest' not in virtual_facts
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['container'] == 'zone'

    # Test case: BrandZ Solaris 8/9 zone
    module = AnsibleModule(command_features={'check_invalid_arguments': False})
    module.run_command = MagicMock

# Generated at 2022-06-23 02:43:09.454302
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt = SunOSVirtual(module)

    # Test ldoms
    ldoms_output = """
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
"""
    expected_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['ldom']),
        'virtualization_tech_host': set(),
    }
    module.run_command = Mock(return_value=(0, ldoms_output, ''))
    assert virt.get_virtual_facts() == expected_virtual_facts

    # Test ldoms with an error because the command is not executed in

# Generated at 2022-06-23 02:43:11.191230
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector().collect()
    assert 'virtualization_type' in facts


# Generated at 2022-06-23 02:43:21.569373
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class SunOSModule():

        def __init__(self):
            self.params = {}
            self.run_command_rc = {}
            self.run_command_out = {}
            self.run_command_err = {}
            self.run_command_rc['/usr/sbin/modinfo'] = 0

# Generated at 2022-06-23 02:43:23.822517
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Test constructor of class SunOSVirtual
    '''
    o = SunOSVirtual()
    assert o is not None


# Generated at 2022-06-23 02:43:25.890905
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    _SunOSVirtual = SunOSVirtual({})
    assert _SunOSVirtual.platform == 'SunOS'

# Generated at 2022-06-23 02:43:28.456906
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # No test is possible because SunOSVirtual class is an abstract class.
    # It will be tested indirectly via test_SunOSVirtualCollector whenever it is instantiated.
    pass


# Generated at 2022-06-23 02:43:38.501088
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    def get_bin_path_mock(*args):
        path = args[0] if args else ''
        if path in ['/usr/sbin/zoneadm', '/usr/sbin/zonename', '/usr/sbin/modinfo', '/usr/sbin/virtinfo', '/usr/sbin/smbios']:
            return path
        raise Exception('Path not found')

    module.get_bin_path = get_bin_path_mock

    def exists_mock(*args):
        path = args[0] if args else ''
        if path == '/.SUNWnative' or path == '/proc/vz':
            return True
        else:
            return False
    os.path.exists = exists

# Generated at 2022-06-23 02:43:48.523125
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = mock_run_command
    module.get_bin_path = mock_get_bin_path
    # No zone
    module.run_command.return_value = (0, 'global', '')
    obj = SunOSVirtual(module)
    obj._module.run_command.return_value = (1, '', '')
    assert obj.get_virtual_facts() == {}
    # Zone
    module.run_command.return_value = (0, '', '')
    obj = SunOSVirtual(module)
    assert obj.get_virtual_facts()['container'] == 'zone'
    # Branded zone
    obj = SunOSVirtual(module)
    assert obj.get_virtual_facts()['container'] == 'zone'
    # Solaris 8

# Generated at 2022-06-23 02:43:55.723610
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    data = {'default_facts': 'sunos',
            'virtualization_type': 'zone',
            'container': 'zone'}
    sunos_virtual = SunOSVirtual(data)
    assert sunos_virtual.get_virtual_facts()['virtualization_type'] == 'zone'
    assert sunos_virtual.get_virtual_facts()['container'] == 'zone'
    assert sunos_virtual.get_virtual_facts()['virtualization_tech_guest'] == set(['zone'])
    assert sunos_virtual.get_virtual_facts()['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-23 02:44:00.115218
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    This method returns the instance of the class SunOSVirtualCollector
    '''
    sunos_virtual_collector_obj = SunOSVirtualCollector()
    assert isinstance(sunos_virtual_collector_obj, SunOSVirtualCollector)



# Generated at 2022-06-23 02:44:10.771198
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    sun = SunOSVirtual(module=module)

    # SunOS virtual facts without zones
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.side_effect = lambda x: {'zonename': '/usr/bin/zonename'}.get(x)
    module.isdir.return_value = False
    virtual_facts = sun.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'sun_zone', 'virtualization_role': 'host', 'container': 'global'}

    # SunOS virtual facts without zones, without zonename
    module.run_command.return_value = (0, 'global', '')

# Generated at 2022-06-23 02:44:11.802523
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = Mock()
    SunOSVirtual(module)

# Generated at 2022-06-23 02:44:13.616223
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({})


# Generated at 2022-06-23 02:44:14.766963
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # given
    var = {}
    var['ansible_facts'] = {}
    # when
    results = SunOSVirtualCollector(var)
    # then
    assert results.platform == 'SunOS'

# Generated at 2022-06-23 02:44:16.868726
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector(dict(), True)

    # Test the _platform
    assert collector._platform == 'SunOS'

    # Test the _fact_class
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:44:20.607797
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sys_solaris = Virtual('SunOS')
    sys_solaris.get_virtual_facts()
    assert sys_solaris.facts['virtualization_role'] == 'guest'
    assert sys_solaris.facts['virtualization_type'] == 'zone'

# Generated at 2022-06-23 02:44:24.996182
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual

if __name__ == "__main__":
    print(SunOSVirtualCollector())

# Generated at 2022-06-23 02:44:27.572619
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:44:37.933129
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # pylint: disable=unused-argument
    def run_command(self, cmd, check_rc=True, close_fds=True):
        # Helper function to make sure we are using the module.run_command
        # function from the module import
        return self.run_command(cmd, check_rc, close_fds)

    # pylint: disable=unused-argument
    def get_bin_path(self, arg):
        if arg == 'zonename':
            return '/usr/bin/zonename'
        elif arg == 'modinfo':
            return '/usr/sbin/modinfo'
        elif arg == 'virtinfo':
            return '/usr/sbin/virtinfo'
        elif arg == 'smbios':
            return '/usr/sbin/smbios'