

# Generated at 2022-06-23 02:34:38.291336
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    SunOSVirtual(module)



# Generated at 2022-06-23 02:34:41.824242
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Act
    sunos_virtual = SunOSVirtual(dict())

    # Assert
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual._virtual_facts is None

# Generated at 2022-06-23 02:34:45.030276
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    sunosvirtual = SunOSVirtual(module)
    assert sunosvirtual.platform == 'SunOS'

# Generated at 2022-06-23 02:34:56.341731
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Arrange
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value=True)
    test_class = SunOSVirtual(module)
    test_class.module.run_command = Mock(return_value=(0, '', ''))
    test_class.module.get_bin_path = Mock(return_value=True)

    # Act
    virtual_facts = test_class.get_virtual_facts()

    # Assert
    assert 'container' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:34:57.411209
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})

# Generated at 2022-06-23 02:35:08.709147
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # These are the values we know about in the test data.
    # The request is for the all the values for 'virtualization_type'
    expected_keys = {'virtualization_type', 'virtualization_role', 'container',
                     'virtualization_tech_guest', 'virtualization_tech_host'}

    # The test data is a dict of dicts, where the key is the input (the value of /usr/sbin/virtinfo -p)
    # and the value is the expected output (dict). We emulate the output of /usr/sbin/virtinfo -p
    # and test the method with the given input. If the actual output
    # (virtual_facts) matches the expected output (expected_virt_facts) the test passes, otherwise it fails.

# Generated at 2022-06-23 02:35:19.830677
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def mock_run_command(self, args):
        if args == "zonename":
            return 0, "global", ""
        elif args == "modinfo":
            return 0, "V d1s1fr       VMware block disk driver", ""
        elif args == "virtinfo -p":
            return 0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", ""
        else:
            self.fail_json(msg='Unsupported command %s' % args)

    os.path.isdir = lambda x: x == "/.SUNWnative"
    os.path.exists = lambda x: x == "/proc/vz"
    SunOSVirtual.module.run_command = mock_run_command

# Generated at 2022-06-23 02:35:21.877623
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:35:26.324576
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """This function tests the constructor of the class."""
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual.facts["virtualization_type"] == "unknown"
    assert sunos_virtual.facts["virtualization_role"] == "unknown"
    assert sunos_virtual.facts["container"] == "unknown"

# Generated at 2022-06-23 02:35:31.881203
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert SunOSVirtualCollector._platform == x._platform
    assert SunOSVirtualCollector._fact_class == x._fact_class
    assert SunOSVirtualCollector._fact_class._platform == x._fact_class._platform


# Generated at 2022-06-23 02:35:36.421028
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test virtual info for SunOS"""
    virtual = SunOSVirtualCollector().collect()['ansible_facts']['ansible_virtualization_facts']
    assert virtual['virtualization_type'] == 'kvm'
    assert virtual['virtualization_role'] == 'guest'
    assert virtual['container'] == 'zone'
    assert 'zone' in virtual['virtualization_tech_guest']

# Generated at 2022-06-23 02:35:48.225529
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a fake AnsibleModule object
    module = AnsibleModuleMock()

    # Create an instance of SunOSVirtual on a system where virtinfo is available
    if virtinfo:
        sunosvirtual = SunOSVirtual(module)

        # Mock the module methods that detect the zone type
        sunosvirtual.check_name = MagicMock(return_value=('zone', 'global'))

        # Check that we are not in a virtualized guest
        facts = sunosvirtual.get_virtual_facts()
        assert facts['virtualization_type'] == 'zone'
        assert facts['virtualization_role'] == 'host'

        # Mock the module method that detects the zone type
        sunosvirtual.check_name = MagicMock(return_value=('zone', 'non-global'))

        # Check that we are in a virtualized guest


# Generated at 2022-06-23 02:35:49.910213
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    assert SunOSVirtualCollector

# Generated at 2022-06-23 02:35:51.444204
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'

# Generated at 2022-06-23 02:35:59.439281
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = {
        'run_command': lambda x: (0, '', '')
    }
    virtual_facts_object = Virtual(module)
    virtual_facts_object.get_virtual_facts()
    assert virtual_facts_object.virtual_facts == {
        'virtualization_type': '',
        'virtualization_role': '',
        'container': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:36:01.954240
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    v = SunOSVirtual(module)
    assert v.platform == v.platform

# Test for get_virtual_facts

# Generated at 2022-06-23 02:36:05.175324
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    obj = SunOSVirtualCollector()
    assert obj._fact_class is SunOSVirtual
    assert obj._platform == 'SunOS'



# Generated at 2022-06-23 02:36:06.520612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector('fake_module', 'fake_subset')

# Generated at 2022-06-23 02:36:14.863213
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = lambda x: (0, '', '')

    virtual = SunOSVirtual(module=module)
    facts = virtual.get_virtual_facts()

    assert 'zone' in facts['virtualization_tech_host']
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'container' in facts
    assert facts['container'] == 'zone'

    assert isinstance(facts['virtualization_tech_guest'], set)
    assert len(facts['virtualization_tech_guest']) == 2
    assert isinstance(facts['virtualization_tech_host'], set)
    assert len(facts['virtualization_tech_host']) == 1

# Generated at 2022-06-23 02:36:27.261408
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = lambda x: x
    module.run_command.side_effect = lambda x: (0, "", "")

    vc = SunOSVirtualCollector(module)

    # check that it is an instance of the right class and of the right type
    assert isinstance(vc, SunOSVirtualCollector)
    assert isinstance(vc, VirtualCollector)

    # check virtualization facts are empty at the beginning
    assert not vc.facts['virtualization']

    # check that the get_virtual_facts() method returns the correct dict
    assert vc.get_virtual_facts() == {
        'container': {},
        'type': {},
        'role': {}
    }
    # check that the virtualization dict has been updated

# Generated at 2022-06-23 02:36:28.900973
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:31.055043
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    This function unit tests the constructor of the class SunOSVirtual
    '''
    SunOSVirtual()


# Generated at 2022-06-23 02:36:32.951950
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({'module': False})
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:36:35.806678
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:36:37.714580
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == "SunOS"
    assert x._fact_class.platform == "SunOS"

# Generated at 2022-06-23 02:36:41.203234
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector()
    assert facts_collector._fact_class == SunOSVirtual
    assert facts_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:36:50.783224
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()

    # zone facts
    module.run_command.side_effect = [
        (0, 'global', ''),    # zonename
        (0, '', ''),          # modinfo
        (0, '', ''),          # smbios
    ]
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_host'] == {'zone'}
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['container'] == ''

    # global zone facts

# Generated at 2022-06-23 02:36:52.802918
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_virtual = SunOSVirtual({})
    assert test_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:36:55.595991
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    nv=SunOSVirtual()
    assert nv.platform == 'SunOS'
    assert nv.virtualization_type == ''
    assert nv.virtualization_role == ''

# Generated at 2022-06-23 02:36:59.149878
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert hasattr(facts, 'virtualization_type')
    assert hasattr(facts, 'virtualization_role')
    assert hasattr(facts, 'virtualization_tech_guest')
    assert hasattr(facts, 'virtualization_tech_host')

# Generated at 2022-06-23 02:37:08.757467
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test case of class SunOSVirtual.get_virtual_facts when it's a global zone
    module = MockAnsibleModule(zone_zone_name='global')
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert_equals(virtual_facts['virtualization_role'], None)
    assert_equals(virtual_facts['container'], None)
    assert_equals(virtual_facts['virtualization_type'], None)
    assert_equals(virtual_facts['virtualization_tech_host'], set(['zone']))
    assert_equals(virtual_facts['virtualization_tech_guest'], set())

    # Test case of class SunOSVirtual.get_virtual_facts when it's a global zone and a branded zone

# Generated at 2022-06-23 02:37:10.934113
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == "SunOS"
    assert isinstance(vc._fact_class, SunOSVirtual)

# Generated at 2022-06-23 02:37:14.601405
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Derived classes of VirtualCollector must have a constructor that takes no arguments
    VirtualCollector()

# Generated at 2022-06-23 02:37:23.762037
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_object = SunOSVirtual({})
    test_object.module.run_command = lambda x: (0, "", "")
    test_object.module.get_bin_path = lambda x: '/bin/' + x

    # Run with zone
    test_object.module.run_command = lambda x: (0, "global", "")
    virtual_facts = test_object.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])

    # Run without zone
    test_object.module.run_command = lambda x: (1, "", "")
    virtual_facts = test_object.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-23 02:37:24.964706
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual({})
    assert isinstance(virtual_obj, Virtual)

# Generated at 2022-06-23 02:37:31.743826
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    collect = SunOSVirtualCollector()
    virtual_facts = collect.collect()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_system' not in virtual_facts
    assert 'product_name' not in virtual_facts
    assert 'product_version' not in virtual_facts

# Generated at 2022-06-23 02:37:41.627820
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # NOTE: ideally this would be a real unit test
    module = MockModule()
    sunos_virtual = SunOSVirtual(module)
    # TODO: Create test environment and determine expected dict
    # TODO: What is an appropiate way to test this method?
    expected = {}
    actual = sunos_virtual.get_virtual_facts()
    assert compare_dict(expected, actual) == []


import pytest
from ansible.module_utils.facts.virtual.sunos import Virtual, VirtualCollector
from ansible.module_utils.facts.virtual.sunos import test_SunOSVirtual_get_virtual_facts
from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

# Generated at 2022-06-23 02:37:48.873739
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = lambda path: path
    module.run_command.side_effect = [('0', 'global\n', ''),
                                      ('0', "id   0x3         xxxxxxx VMware vmxnet3 Ethernet Controller\n", ''),
                                      ('0', 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false\n', ''),
                                      ('1', '', '')]
    test_obj = SunOSVirtual(module=module)
    assert test_obj.data['virtualization_type'] == 'vmware'
    assert test_obj.data['virtualization_role'] == 'guest'
    assert test_obj.data['container'] == 'zone'

# Generated at 2022-06-23 02:37:58.317456
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule({'command': 'test'})

    # zonename is lx
    # no guest tech detected
    # lx zone
    module.run_command = lambda x: (0, "global\n", '')
    module.get_bin_path = lambda x: 'testbin'
    module.run_command = lambda x: (0, '', '')
    v = SunOSVirtual(module)
    assert v.get_virtual_facts() == {"container": 'zone',
                                     "virtualization_tech_guest": set(),
                                     "virtualization_tech_host": set('zone'),
                                     "virtualization_type": None,
                                     "virtualization_role": None}

    # zonename is global
    # no guest tech detected
    # global zone

# Generated at 2022-06-23 02:38:05.088234
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    module.run_command = MagicMock(
        side_effect=[
            (0, 'global', '')
        ],
    )
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set([])}

# Generated at 2022-06-23 02:38:08.012058
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.virtual_collector_type() == 'SunOSVirtualCollector'

# Generated at 2022-06-23 02:38:17.655377
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Set up some input data
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()

    # Instantiate an object of class SunOSVirtual
    virtual = SunOSVirtual(module)

    # Call the get_virtual_facts method of the object virtual
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': set()
    }



# Generated at 2022-06-23 02:38:27.830709
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # This is the module we'll be testing
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Get the facts to test against
    sunos_virtual_facts_collector = SunOSVirtualCollector(module)
    sunos_virtual_facts = sunos_virtual_facts_collector.get_facts()

    # Test the custom constructed class
    sunos_virtual = SunOSVirtual()
    sunos_virtual_facts_from_class = sunos_virtual.populate()

    assert sunos_virtual_facts == sunos_virtual_facts_from_class

# Generated at 2022-06-23 02:38:31.255209
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({}, {})
    assert facts.platform == 'SunOS'


# Generated at 2022-06-23 02:38:33.602041
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    sunos = SunOSVirtual(module)
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-23 02:38:37.338521
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # "get_virtual_facts" is a method of VirtualCollector, the parent of SunOSVirtualCollector.
    # Thus, it should be available by the instance of SunOSVirtualCollector.
    SunOSVirtualCollector().get_virtual_facts()

# Generated at 2022-06-23 02:38:48.022973
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.module_utils.facts.virtual.test_sunos_virtual import (
        AnsibleExitJson, Command, Module
    )

    module = Module()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = AnsibleExitJson
    module.fail_json = MagicMock()
    module.get_bin_path = MagicMock(return_value='/usr/sbin/virtinfo')

    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual import SunOSVirtual
    instance = SunOSVirtual(module)

    # We construct the output we want from 'virtinfo' command
    # This output is for a SPARC T4-4 machine hosting a single LDOM
   

# Generated at 2022-06-23 02:38:57.945046
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Mock module
    module = AnsibleModule(argument_spec={})

    # Mock commands to be executed
    cmds = {
        'zonename': '',
        'smbios': '',
        'modinfo': None,
        'virtinfo': '',
    }

    # Create a SunOSVirtual instance and run the get_virtual_facts method using the mocked methods
    # for system calls
    ansible_obj = SunOSVirtual(module, cmds)
    ansible_obj.module.run_command = mock_run_command
    ansible_obj.module.get_bin_path = mock_get_bin_path
    ansible_obj.module.file_exists = mock_file_exists
    virtual_facts = ansible_obj.get_virtual_facts()

    # Check expected results
    assert virtual_

# Generated at 2022-06-23 02:39:01.414553
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert isinstance(x._fact_class, SunOSVirtual)
    assert x._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:39:13.381369
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
        )
    )
    module.params['gather_subset'].append('!all')
    module.params['gather_subset'].append('!any')

    obj = SunOSVirtual(module=module)
    fact_subset = obj.get_facts(module)
    assert fact_subset == obj.get_virtual_facts()

    # These tests check if a specific key is set in gathering all facts
    module.params['gather_subset'] = 'all'
    assert isinstance(obj.get_facts(module), dict) is True

# Generated at 2022-06-23 02:39:18.680830
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-23 02:39:22.171116
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._platform == 'SunOS'
    assert v._fact_class == SunOSVirtual
    assert isinstance(v._fact_class({}), SunOSVirtual)


# Generated at 2022-06-23 02:39:33.717156
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Create a SunOSVirtual object
    sunosvirtual = SunOSVirtual()

    # Create an AnsibleModule object and a SunOSVirtualCollector object. They will be passed to sunosvirtual
    # to be able to call its get_virtual_facts() method.
    module = AnsibleModule
    sunosvirtualcollector = SunOSVirtualCollector()
    sunosvirtual.module = module
    sunosvirtual._collector = sunosvirtualcollector

    # Mock 2 paths to the zone shell command
    zonepaths = ['/usr/bin/zonename', '/opt/bin/zonename']
    sunosvirtual.module.get_bin_path = MagicMock(side_effect=zonepaths)

    # Mock the run_command method which is called by get_virtual_facts()
    sunosvirtual.module.run_command = MagicMock

# Generated at 2022-06-23 02:39:34.926760
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    myTest = SunOSVirtual(None, None)
    assert myTest.platform == 'SunOS'

# Generated at 2022-06-23 02:39:38.939371
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector(None)
    assert x._platform == SunOSVirtualCollector._platform
    assert isinstance(x._collector, SunOSVirtual)

# Generated at 2022-06-23 02:39:48.715227
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Simulate a zone and a branded zone
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(side_effect=lambda x: x)
    os.path.isdir = MagicMock(return_value=True)

    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert 'virtualization_type' not in virtual_facts

    # Simulate a zone with a global zone using vmware
    os.path.isdir = MagicMock(return_value=False)
    module.run_command = MagicMock(return_value=(0, 'VMware', ''))
    virtual

# Generated at 2022-06-23 02:39:58.752260
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def get_bin_path(bin_path):
        return '/usr/bin/' + bin_path

    import os.path
    def isdir(path):
        if path == "/.SUNWnative":
            return True
        else:
            return os.path.isdir(path)

    module = AnsibleModuleMock(
        dict(
            run_command = run_command,
            get_bin_path = get_bin_path,
            isdir = isdir
        )
    )
    import sys
    sys.modules['ansible.module_utils.facts.virtual.base'] = AnsibleBaseMock
    import ansible.module_utils.facts.virtual.SunOS as module_under_test
    sunos_virtual = module_under_test.SunOSVirtual(module)
    virtual_facts = sun

# Generated at 2022-06-23 02:40:12.950894
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a dummy module with given state returned by functions
    class SunOSVirtual_test(SunOSVirtual):
        def __init__(self, module):
            SunOSVirtual.__init__(self, module)

        def get_bin_path(self, name):
            if name == 'zonename':
                return '/sbin/zonename'
            if name == 'modinfo':
                return '/usr/sbin/modinfo'
            if name == 'virtinfo':
                return '/usr/sbin/virtinfo'
            if name == 'smbios':
                return '/usr/sbin/smbios'

        def zone_command(self, name):
            return 'global'


# Generated at 2022-06-23 02:40:19.522518
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fake_module = type('', (), {})()
    fake_module.get_bin_path = lambda *args: '/bin/virtinfo'
    fake_module.run_command = lambda *args: (0, 'test line', '')
    fake_module.params = {}
    f = SunOSVirtual(fake_module)
    facts = f.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-23 02:40:21.385285
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test mostly to just see if a SunOSVirtual object is constructed
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:40:22.851593
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual({})
    assert m.get_virtual_facts() == {}

# Generated at 2022-06-23 02:40:25.003325
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  x = SunOSVirtualCollector()
  assert x._fact_class == SunOSVirtual
  assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:40:26.673911
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pprint
    m = SunOSVirtual({})
    pprint.pprint(m.get_virtual_facts())

# Generated at 2022-06-23 02:40:28.309642
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_platform = SunOSVirtualCollector()
    assert os_platform.platform == 'SunOS'


# Generated at 2022-06-23 02:40:33.320223
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual as Virtual

    # get_virtual_facts() won't return anything for facts for Virtual
    virtual = Virtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {}


# Generated at 2022-06-23 02:40:38.192824
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Unit test for constructor of class SunOSVirtual
    """
    # Test with missing module argument
    obj = SunOSVirtual()
    assert obj.platform == 'SunOS'
    assert obj._virtual_facts == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-23 02:40:42.333106
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual = SunOSVirtual(module)

    assert virtual.platform == 'SunOS'

    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:40:50.112932
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import os
    import shutil
    module = type('FakeModule', (object, ), dict(run_command=lambda *a, **kw: (0, '', ''), get_bin_path=lambda *a, **kw: '/bin/fakebin'))
    module.get_bin_path = lambda *a, **kw: '/bin/fakebin'
    m_open = type('FakeOpen', (object, ), dict(read=lambda *a, **kw: '', close=lambda *a, **kw: None))
    m_isfile = type('FakeIsFile', (object, ), dict(return_value=True))
    m_isdir = type('FakeIsDir', (object, ), dict(return_value=True))

# Generated at 2022-06-23 02:40:51.461929
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:52.857451
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'

# Generated at 2022-06-23 02:41:01.006446
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    mock_module = MockModule()

    # Create a mock facts class
    mock_facts_class = MockSunOSVirtualFactsClass()

    sunos_virtual = SunOSVirtual(mock_module)

    mock_facts_class.virtual_facts = sunos_virtual.get_virtual_facts()

    assert 'virtualization_type' in mock_facts_class.virtual_facts


# Class used to replace the get_bin_path method of the module

# Generated at 2022-06-23 02:41:02.361312
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:41:11.908345
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def get_bin_path(x):
        return x
    module = type('', (), {
        '_ansible_module_commands': {'smbios': 'smbios-output'},
        'run_command': lambda x: [0, 'smbios-output', ''],
        'get_bin_path': get_bin_path
    })()
    module.run_command = classmethod(lambda self, x: (0, 'smbios-output', ''))
    module.get_bin_path = classmethod(get_bin_path)
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:41:14.119916
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts import VirtualFactCollector

    collector = VirtualFactCollector()
    assert SunOSVirtual(collector) is not None

# Generated at 2022-06-23 02:41:18.484203
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # When list of supported platforms is set, it should be a class attribute of VirtualCollector
    # The value of the attribute is a list and contains SunOS.
    assert ('SunOS' in SunOSVirtualCollector.platforms), 'The value of the attribute platforms of class SunOSVirtualCollector should be a list and should contain SunOS.'

# Generated at 2022-06-23 02:41:19.868605
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 02:41:29.786405
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a fake module
    module = type('', (), {})()

    # Create a fake command to return a fake output
    def run_command_grep(command, check_rc=True, close_fds=True, data=None, binary_data=False, path_prefix=None, cwd=None,
                         use_unsafe_shell=False, prompt=None, newline=True, env=None):
        return (0, '', '')

    # Create a fake command to return a fake output

# Generated at 2022-06-23 02:41:31.924500
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)

# Generated at 2022-06-23 02:41:36.418753
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(None)
    for key in virt.data.keys():
        assert key in virt.platform_subclass.data, '%s not in %s' % (key, virt.platform_subclass.data)

# Generated at 2022-06-23 02:41:46.325208
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = lambda *args, **kwargs: (0, 'fake_output', '')
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:41:55.960025
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual import SunOSVirtual
    from ansible.module_utils import basic
    import os

    class AnsibleModule:

        def __init__(self, params={}):
            self.params = params

        def fail_json(self, msg={}):
            raise Exception(msg)

        def run_command(self, cmd):
            if cmd == "modinfo | grep VMware":
                return 0, "vmm, VMware Virtual CPU version 1.0\nvmm, VMware Virtual Machine Monitor", ""
            if cmd == "modinfo | grep VirtualBox":
                return 0, "vboxnetadp, VirtualBox Host-Only Ethernet Adapter Driver\nvboxnetflt, VirtualBox Network Filter Driver\nvboxdrv, VirtualBox Support Driver", ""

# Generated at 2022-06-23 02:41:58.272329
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # pylint: disable=E1001
    assert SunOSVirtual(dict(module=None)).platform == 'SunOS'

# Generated at 2022-06-23 02:42:02.624684
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj._fact_class._platform == 'SunOS'


# Generated at 2022-06-23 02:42:13.882640
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Mock(return_value=dict())
    SunOSVirtual.module = module
    SunOSVirtual.module.run_command = Mock(return_value=(0, '', ''))
    # On a SunOS global zone (no container)
    SunOSVirtual.get_bin_path = lambda s, path: path
    virtual = SunOSVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['container'] != 'zone'
    # On a SunOS local zone (container)
    SunOSVirtual.get_bin_path = lambda s, path: 'zone' if path == 'zonename' else path
    virtual = SunOSVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'

import ansible.module_utils.facts.virtual

# Generated at 2022-06-23 02:42:16.764753
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt.__class__.__name__ == 'SunOSVirtual'
    assert virt.platform == 'SunOS'


# Generated at 2022-06-23 02:42:21.282978
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    solaris_collector = SunOSVirtualCollector(None, None)

    sunos_guest = solaris_collector.get_virtual_facts()
    assert 'virtualization_type' in sunos_guest
    assert 'virtualization_role' in sunos_guest
    assert 'container' in sunos_guest

# Generated at 2022-06-23 02:42:25.706996
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:42:26.674095
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector

# Generated at 2022-06-23 02:42:36.294473
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create the class object to test
    vm_test = SunOSVirtualCollector()

    # Check our platform is 'SunOS'
    if not vm_test._platform == 'SunOS':
        raise Exception("Platform set to %s but should be SunOS" % vm_test._platform)

    # Check our fact_class is 'SunOSVirtual'
    if not vm_test._fact_class.__name__ == 'SunOSVirtual':
        raise Exception("Fact class set to %s but should be SunOSVirtual" % vm_test._fact_class.__name__)


# Generated at 2022-06-23 02:42:38.345938
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    sun_facts = SunOSVirtual(module)
    assert sun_facts.platform == "SunOS"



# Generated at 2022-06-23 02:42:49.020786
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    vir = SunOSVirtual(module)
    # so we don't have to depend on code in other files
    vir.os = SunOSVirtual(module)

    facts = vir.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'vmware' not in facts['virtualization_tech_guest']

    # A real life example of /usr/sbin/smbios output

# Generated at 2022-06-23 02:42:54.572530
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    o = SunOSVirtual(dict())
    assert o.platform == 'SunOS'
    assert 'container' in o.virtual_facts
    assert 'virtualization_type' in o.virtual_facts
    assert 'virtualization_role' in o.virtual_facts
    assert isinstance(o.virtual_facts['virtualization_tech_host'], set)
    assert isinstance(o.virtual_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:42:56.302704
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hypervisor = SunOSVirtual()
    assert hypervisor.platform == 'SunOS'



# Generated at 2022-06-23 02:43:00.413362
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._mandatory_facts_missing()

# Generated at 2022-06-23 02:43:03.841595
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Test to create an instance of the class SunOSVirtual
    sunos_virtual = SunOSVirtual()

    # Check that the class properly sets the platform variable
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:43:14.394060
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_obj = SunOSVirtual({})
    # Mock the module
    class ModuleMock(object):
        def get_bin_path(self, cmd):
            if cmd == 'zonename':
                return 'zonename'
            if cmd == 'smbios':
                return 'smbios'
            if cmd == 'virtinfo':
                return 'virtinfo'
            if cmd == 'modinfo':
                return 'modinfo'

        def run_command(self, cmd):
            if cmd == 'zonename':
                if os.path.isdir('/.SUNWnative'):
                    # Return global zone but with branded zone (i.e Solaris 8/9)
                    return 0, 'global', None
                return 0, 'global', None

# Generated at 2022-06-23 02:43:15.884887
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:43:18.940045
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = {}
    v = SunOSVirtual(facts, 'any_module')
    assert v.platform == 'SunOS'
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''
    assert v.container == ''

# Generated at 2022-06-23 02:43:28.446437
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class FakeAnsibleModule(object):

        def __init__(self, *args, **kwargs):
            self.called = []
            self.params = {}
            self.called.append('__init__')

        def fail_json(self, *args, **kwargs):
            self.called.append('fail_json')

        def get_bin_path(self, *args, **kwargs):
            self.called.append('get_bin_path ({})'.format(*args))
            return '/usr/bin/{}'.format(*args)

        def run_command(self, *args, **kwargs):
            self.called.append('run_command ({})'.format(args[0]))

# Generated at 2022-06-23 02:43:33.296489
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    SunOSVirtual(module)
    # Just check that it doesn't raise an exception


# Generated at 2022-06-23 02:43:35.062345
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos = SunOSVirtual({})
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-23 02:43:46.776320
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    class FakeModule:
        def get_bin_path(self, bin_path):
            paths = { 'zonename': '/usr/bin/zonename', 'smbios': '/usr/sbin/smbios', 'virtinfo': '/usr/sbin/virtinfo', 'modinfo': '/usr/sbin/modinfo' }
            return paths.get(bin_path, None)
        def run_command(self, arg):
            if arg == '/usr/bin/zonename':
                return (0, 'global\n', '')
            elif arg == 'smbios':
                return (0, 'VMware\n', '')

# Generated at 2022-06-23 02:43:48.871921
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    sunosvirtual = SunOSVirtual(module)
    assert sunosvirtual.platform == 'SunOS'

# Generated at 2022-06-23 02:43:51.220054
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:59.208446
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import facts_d
    test_virtual_facts_results = dict(
        virtualization_type='virtualbox',
        virtualization_role='guest',
        container='zone',
        virtualization_tech_guest={'zone', 'virtualbox'},
        virtualization_tech_host={'zone'}
    )
    test_virtual_facts = SunOSVirtual(facts_d)
    assert test_virtual_facts.get_virtual_facts() == test_virtual_facts_results

# Generated at 2022-06-23 02:44:09.904965
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    class MockSunOSVirtual(SunOSVirtual):

        @staticmethod
        def __init__(module):
            pass

        def get_virtual_facts(self):
            return super(MockSunOSVirtual, self).get_virtual_facts()

        def _detect_virt_what(self):
            class MockSubProcess(object):
                return_value = '''
                VMware
                VirtualBox
                '''

                @staticmethod
                def communicate():
                    return MockSubProcess.return_value

            class MockPopen(object):
                return_value = MockSubProcess

                @staticmethod
                def Popen(*args, **kwargs):
                    return MockSubProcess

            return MockPopen

    facts = MockSunOSVirtual(module).get_virtual_facts()

# Generated at 2022-06-23 02:44:13.686122
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import virtual

    assert issubclass(SunOSVirtualCollector, virtual.VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual

# Generated at 2022-06-23 02:44:16.678123
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    f = SunOSVirtual({})
    virtual_facts = f.get_virtual_facts()
    expected_virtual_facts = {}
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:44:28.866555
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Fake module
    class TestModule(object):
        def __init__(self, run_command_args_list, bin_path_value_list):
            self.run_command_args_list = run_command_args_list
            self.run_command_called_with = []
            self.bin_path_value_list = bin_path_value_list
            self.get_bin_path_called_with = []

        def get_bin_path(self, name, *args, **kwargs):
            self.get_bin_path_called_with.append(name)
            return self.bin_path_value_list[name]

        def run_command(self, cmd, *args, **kwargs):
            self.run_command_called_with.append(cmd)
            return self.run_command_

# Generated at 2022-06-23 02:44:38.727485
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = FakeModule()
    facts = {}

    # Let's pretend we are in a global zone
    module.run_command_value = [(0, "global", ""), (0, "", "")]
    SunOSVirtual.get_virtual_facts(facts, module)
    assert(facts['virtualization_tech_host'] == set(['zone']))
    assert('virtualization_tech_guest' not in facts)
    assert('virtualization_type' not in facts)
    assert('virtualization_role' not in facts)

    # Let's pretend we are in a branded zone
    module.run_command_value = [(0, "global", ""), (0, "", "")]
    facts['container'] = 'zone'