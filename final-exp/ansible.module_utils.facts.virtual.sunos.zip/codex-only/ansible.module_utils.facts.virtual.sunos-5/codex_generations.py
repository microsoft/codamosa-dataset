

# Generated at 2022-06-23 02:34:46.719619
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virt = SunOSVirtual(module=module)
    module.run_command.return_value = (0, 'global', '')  # zonename
    assert virt.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['zone'])}

    module.run_command.return_value = (0, '', '')  # zonename
    assert virt.get_virtual_facts() == {'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set()}

    module.run_command.return_value = (1, '', '')  # zonename

# Generated at 2022-06-23 02:34:48.966360
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(None)
    assert virtual_facts.virtual


# Unit tests for get_virtual_facts() of class SunOSVirtual

# Generated at 2022-06-23 02:34:56.940952
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Mock()
    module.run_command.return_value = (0, "  global", "")

    # Test if running in a real Solaris zone.
    facts = {
        'container': 'zone'
    }
    obj = SunOSVirtual(module)
    result = obj.get_virtual_facts()

    (rc, out, err) = module.run_command.call_args[0]
    assert rc == 0
    assert out == "zonename"
    assert err == ""
    assert result == facts



# Generated at 2022-06-23 02:35:00.518526
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 10
    SunOSVirtual(module=module).get_virtual_facts()

# Generated at 2022-06-23 02:35:05.101319
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector.collect()

    assert 'SunOS' in virtual_facts
    assert virtual_facts['SunOS']['virtualization_type'] != ''
    assert virtual_facts['SunOS']['virtualization_role'] != ''



# Generated at 2022-06-23 02:35:13.391145
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a Mock module with given facts
    zonename_path = '/usr/bin/zonename'
    modinfo_path = '/usr/sbin/modinfo'
    virtinfo_path = '/usr/sbin/virtinfo'
    class MockModule:
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.sysfs_path = '/sys'

# Generated at 2022-06-23 02:35:15.062071
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()

    assert facts is not None

# Generated at 2022-06-23 02:35:17.478471
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'


# Generated at 2022-06-23 02:35:24.359217
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleFakeModule()
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])



# Generated at 2022-06-23 02:35:26.232200
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = SunOSVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-23 02:35:34.135007
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Facts will be read from the virtual_facts_cache.yml file, we just need to specify the path to it.
    # This file is also used by the unit tests of the linux and freebsd platform modules.
    tmpdir = os.path.dirname(__file__)
    path = os.path.join(tmpdir, 'virtual_facts_cache.yml')

    m = SunOSVirtual(dict(), path)

    # Test virtualization_type detection
    assert m.get_virtual_facts()['virtualization_type'] == 'vbox'

    # Test virtualization_role detection
    assert m.get_virtual_facts()['virtualization_role'] == 'guest'

    # Test container detection
    assert m.get_virtual_facts()['container'] == 'zone'

    # Test virtualization_tech_guest detection

# Generated at 2022-06-23 02:35:40.615147
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    vfacts = SunOSVirtual(None)
    vfacts.get_virtual_facts()

    assert vfacts.facts == {'virtualization_type': 'virtuozzo',
                            'virtualization_role': 'guest',
                            'container': 'virtuozzo',
                            'virtualization_tech_guest': {'virtuozzo'},
                            'virtualization_tech_host': {}}

# Generated at 2022-06-23 02:35:42.128237
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_class = SunOSVirtual()
    assert virtual_class.platform == 'SunOS'

# Generated at 2022-06-23 02:35:51.578062
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Virtual machine
    module = FakeModule({
        'smbios': 'fake sbios output with line "VirtualBox" or whatever',
        'zonename': 'fake zonename output with line "global" or whatever',
        'virtinfo': '/usr/sbin/virtinfo',
    })

    params = {
        'module': module,
        'platform': 'SunOS',
    }

    virtual = SunOSVirtual(**params)
    facts = virtual.get_virtual_facts()

    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['virtualbox'])
    assert facts['virtualization_tech_host'] == set([])

    # Branded zone

# Generated at 2022-06-23 02:35:54.537756
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:36:01.438709
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    SunOSVirtual.get_virtual_facts(module)
    virtual_facts = module.ANSIBLE_MODULE_ARGS['virtual_facts']
    assert True == virtual_facts['virtualization_type'] in ['vmware', 'virtualbox', 'xen', 'kvm']
    assert True == virtual_facts['virtualization_role'] in ['host', 'guest']
    assert True == virtual_facts['virtualization_tech_guest'] in ['vmware', 'virtualbox', 'xen', 'kvm', '']


# Generated at 2022-06-23 02:36:05.591330
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos = SunOSVirtual(dict(), [])

    assert sunos.platform == 'SunOS'
    assert sunos.hwaddr_interfaces == sunos.get_hwaddr_interfaces()


# Generated at 2022-06-23 02:36:12.130009
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # check if 'system_profiler' is present on local machine
    sunos_virtual = SunOSVirtual()
    if not sunos_virtual.module.get_bin_path('smbios'):
        sunos_virtual = SunOSVirtual(module=MagicMock())
    else:
        sunos_virtual = SunOSVirtual()
    sunos_virtual.get_virtual_facts()
    virtual_facts = sunos_virtual.get_all_facts()
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:36:15.704035
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._fact_class is SunOSVirtual
    assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:36:24.381861
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # create a module
    module_args = {}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # init the sunos virtual class
    v = SunOSVirtual(module=module)

    # get the virtual facts
    facts = v.get_virtual_facts()

    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert 'container' in facts



# Generated at 2022-06-23 02:36:26.878176
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:36:27.879958
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()


# Generated at 2022-06-23 02:36:28.934430
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual({})
    assert m.platform == 'SunOS'

# Generated at 2022-06-23 02:36:35.503320
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    platform_collector = collector.get_platform_collector('SunOS')
    virtual_collector = platform_collector.get_virtual_collector()
    assert isinstance(virtual_collector, SunOSVirtual)
    assert virtual_collector.platform == "SunOS"

# Generated at 2022-06-23 02:36:44.440649
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = True

    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()

    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'zone'}
    assert facts['virtualization_tech_host'] == {'zone'}

    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.return_value = True

    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()


# Generated at 2022-06-23 02:36:56.127771
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    set_module_args({})
    virt_obj = SunOSVirtual(module)
    module.run_command = Mock(return_value=(0, 'a', 'b'))
    module.get_bin_path = Mock(return_value='/bin/awk')
    module.stat = Mock()

    # Set file existance
    file_exists = dict()
    file_exists["/.SUNWnative"] = False
    module.stat.side_effect = lambda filename: os.stat_result([0, 0, 0, 0, 0, 0, 0, 0] if filename in file_exists else [])

    # Run the code
    virtual_facts = virt_obj.get_virtual

# Generated at 2022-06-23 02:37:00.755134
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create an object of class 'SunOSVirtualCollector'
    sunos_virtual_collector_obj = SunOSVirtualCollector()
    assert isinstance(sunos_virtual_collector_obj, SunOSVirtualCollector)



# Generated at 2022-06-23 02:37:02.312744
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual({})
    assert virtual_obj._platform == "SunOS"

# Generated at 2022-06-23 02:37:03.576403
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:37:05.542775
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()


# Generated at 2022-06-23 02:37:09.539380
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import virtual
    c = virtual.collector.get('SunOS')
    assert isinstance(c, SunOSVirtualCollector)
    assert c._platform == 'SunOS'
    assert c.platform == 'SunOS'


# Generated at 2022-06-23 02:37:21.361662
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # For the unit test, we load all possible results into a dictionary
    import json
    with open(os.path.join(os.path.dirname(__file__), 'get_virtual_facts.json')) as facts_file:
        facts_data = json.load(facts_file)

    def zonename_mock_command(module):
        # In this unit test, we distinguish between zones and global zones by the path of the binary.
        # True means it's a zone, False means it's a global zone
        return ['zonename', False]

    def zonename_mock_stdout(module, command):
        if command[1]:
            # This means it's a zone and we return an output as if it was a zone
            return 'nonglobal'

# Generated at 2022-06-23 02:37:31.743817
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand({"/usr/sbin/zonename": (0, "global", None),
                                         "/usr/sbin/virtinfo -p": (0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", None),
                                         "/usr/sbin/smbios": (0, "Manufacturer: VMware\nVersion: Microsoft (R) Windows (R)", None)})
    module.get_bin_path = FakeGetBinPath({'zonename': '/usr/sbin/zonename',
                                          'virtinfo': '/usr/sbin/virtinfo',
                                          'smbios': '/usr/sbin/smbios'})
    virtual = SunOSVirtual(module=module)
    virtual

# Generated at 2022-06-23 02:37:33.518049
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fact_subclass = SunOSVirtualCollector()
    assert fact_subclass is not None

# Generated at 2022-06-23 02:37:42.856329
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test case with both host_tech and guest_tech set
    test_facts = {
        'os': 'SunOS',
        'virtualization_tech_guest': {'zone', 'vmware'},
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest'
    }
    test_obj = SunOSVirtual(test_facts)
    assert test_obj.guest_tech == test_facts['virtualization_tech_guest']
    assert test_obj.virtualization_type == test_facts['virtualization_type']
    assert test_obj.virtualization_role == test_facts['virtualization_role']


# Generated at 2022-06-23 02:37:44.151826
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector(None).platform == 'SunOS'


# Generated at 2022-06-23 02:37:47.496524
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)

    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None

# Generated at 2022-06-23 02:37:49.893147
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual


# Generated at 2022-06-23 02:37:54.107881
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})
    facts = v.get_virtual_facts()
    assert facts['virtual'] is True
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:37:58.220737
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt_sunos_collector = SunOSVirtual(module)

    assert virt_sunos_collector.platform == 'SunOS'


# Generated at 2022-06-23 02:38:07.200894
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # This hack imports module names not identical with file names.
    # pylint: disable=import-error
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    # pylint: enable=import-error
    module = AnsibleModule(
        argument_spec = dict()
    )

    NON_EXIST = "no such file or directory"

# Generated at 2022-06-23 02:38:18.130064
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import cache

    # Create a test class object with a mock module and test the get_cached_facts method
    test_instance = SunOSVirtual(basic.AnsibleModule(
        argument_spec=dict()
    ))

    # Get the facts
    facts = test_instance.get_virtual_facts()
    # Check the facts
    assert len(facts) > 0
    assert facts['virtualization_type'] == 'kvm'
    assert len(facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-23 02:38:23.169494
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Verify arguments are accepted without error
    m = SunOSVirtualCollector(module=None)

    # Verify that virtual machine facts are found for this platform
    v = SunOSVirtual(module=None)
    assert v.get_virtual_facts()



# Generated at 2022-06-23 02:38:34.088280
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.rc = 0
    module.run_command.out = ' \n'.join(['DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=true',
                                         'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false'])
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['ldom']),
        'virtualization_role': 'host (root)',
        'virtualization_type': 'ldom'
    }

from ansible.module_utils.facts.virtual.sunos import SunOS

# Generated at 2022-06-23 02:38:36.528859
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvirtual = SunOSVirtualCollector()
    assert sunosvirtual._platform == "SunOS"
    assert sunosvirtual._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:38:47.536720
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()

    # There are three main scenarios to cover
    # 1. We are running inside a global zone but there is no virtualization technology detected
    # 2. We are running inside a container
    # 3. We are running on a physical host

    # Scenario 1: We are running inside a global zone but there is no virtualization technology detected
    if module.get_bin_path('zonename'):
        module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.run_command = MagicMock(return_value=(1, '', ''))
    module.get_bin_path = MagicMock(side_effect=lambda s: s + '123')
    module.path_exists = MagicMock(return_value=False)

# Generated at 2022-06-23 02:38:49.515174
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual(None)
    assert sv.platform == 'SunOS'

# Generated at 2022-06-23 02:38:57.797787
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/sbin/zonename')
    module.run_command = Mock(return_value=[0, 'global\n', ''])
    sunos_virtual_obj = SunOSVirtual(module)
    zonename_data = sunos_virtual_obj.get_virtual_facts()
    assert zonename_data == {'virtualization_tech_guest': set(), 'virtualization_tech_host': {'zone'}}

# Generated at 2022-06-23 02:39:01.694591
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtualCollector().collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:39:04.720612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_vc = SunOSVirtualCollector()
    assert sunos_vc
    assert sunos_vc._platform == 'SunOS'
    assert sunos_vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:08.037819
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''Unit test for constructor of class SunOSVirtual'''
    module = AnsibleModule(argument_spec={})
    virt = SunOSVirtual(module)
    assert virt is not None
    assert virt.get_virtual_facts() == {}



# Generated at 2022-06-23 02:39:09.769959
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.facts['virtualization_type'] == 'physical'

# Generated at 2022-06-23 02:39:17.116192
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Prepare parameters
    module = namedtuple('Module', ['run_command', 'get_bin_path'])
    module.run_command = lambda cmd: (0, '', '') if cmd == '/usr/sbin/zoneadm list -i' else (1, '', '')
    module.get_bin_path = lambda cmd: '/usr/sbin/' + cmd if cmd in ['zonename', 'virtinfo', 'smbios'] else None

    # Instantiate class
    fact = SunOSVirtual(module)

    # Run method
    virtual_facts = fact.get_virtual_facts()

    # Check result
    assert virtual_facts == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['zone'])
    }

# Generated at 2022-06-23 02:39:28.331076
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    virtual_test = SunOSVirtual()

    # Test in a zone
    virtual_test.module.run_command = mock_run_command({
        'zonename': (0, 'a_zone', ''),
        'modinfo': (0, 'virtinfo 80062 0', ''),
        'virtinfo': (0, '/usr/sbin/virtinfo: virtinfo can only be run from the global zone\n', '', 0),
        'smbios': (0, '', '', 0)
    })
    virtual_facts = virtual_test.get_virtual_facts()
    assert sorted(virtual_facts) == ['container', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_type']
   

# Generated at 2022-06-23 02:39:35.923523
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    # SunOSVirtual class instantiation creates an instance of the module.
    sunos_virtual = SunOSVirtual(module)
    # test_facts dictionary is populated by a SunOSVirtual instance only
    # if the code of the get_virtual_facts method does not raise an exception.
    facts = sunos_virtual.get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    if 'container' in facts:
        assert 'guest_tech' in facts



# Generated at 2022-06-23 02:39:43.309482
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual('module')
    assert x.platform == 'SunOS'
    assert x.virtualization_type == 'xen'
    assert x.virtualization_role == 'guest'
    assert x.container == 'zone'
    assert x.virtualization_tech_host == {'zone'}
    assert x.virtualization_tech_guest == {'zone', 'xen'}


# Generated at 2022-06-23 02:39:48.867334
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.data['virtualization_tech_host'] == set()
    assert virtual.data['virtualization_tech_guest'] == set()
    assert virtual.data['container'] is None
    assert virtual.data['virtualization_type'] is None

# Generated at 2022-06-23 02:39:52.855825
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    fact_class = SunOSVirtual(module)
    assert fact_class.module == module
    assert fact_class.platform == 'SunOS'


# Generated at 2022-06-23 02:39:57.810321
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_type is None
    assert sunos_virtual.virtualization_role is None

# Generated at 2022-06-23 02:40:01.904848
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector('ansible.module_utils.sunos.virtual')
    assert vc.get_fact_class() == SunOSVirtual
    assert vc.platform == 'SunOS'
    assert vc.get_key_to_collect() == 'virtualization_type'

# Generated at 2022-06-23 02:40:07.275515
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """ Unit test for method 'get_virtual_facts' of class SunOSVirtual """
    # SunOS virtual facts
    sunos_vfacts = {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'container': 'zone'
    }

    # Create instance of SunOSVirtual and call get_virtual_facts method
    sunos_virtual = SunOSVirtual()
    sunos_virtual_facts = sunos_virtual.get_virtual_facts()

    # Check output
    assert sunos_vfacts == sunos_virtual_facts

# Generated at 2022-06-23 02:40:19.423209
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    virtual = SunOSVirtual(dict())
    virtual.module = DummyAnsibleModule()
    # First test - AnsibleModule raises an exception in the call to get_bin_path
    with pytest.raises(Exception):
        virtual.get_virtual_facts()
    # Let's fake the calls to get_bin_path to return the correct path to the binaries
    # Second test - The call to zonename succeeds but returns an empty string
    virtual.module.run_command = fake_run_command_empty
    assert virtual.get_virtual_facts() == {}
    # Third test - The call to zonename succeeds but returns a value indicating
    # we are not a zone
    virtual.module.run_command = fake_run_command_not

# Generated at 2022-06-23 02:40:23.575566
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    unit test for constructor of class SunOSVirtual

    This test is needed, because the class is used in another file and
    the autodiscovery of tests doesn't find the test otherwise.
    """
    require_module('ansible.module_utils.facts')
    module = AnsibleModuleMock()
    obj = SunOSVirtual(module)
    assert obj
    assert isinstance(obj, SunOSVirtual)

# Generated at 2022-06-23 02:40:32.464954
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virt = SunOSVirtual(module)

    # Test for a branded zone
    virt.zonename = '/bin/zonename'
    module.run_command.return_value = (0, 'global', '')
    module.isdir.return_value = True
    virtual_facts = virt.get_virtual_facts()
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert virtual_facts['container'] == 'zone'
    virtual_facts = virt.get_virtual_facts()
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert virtual_facts['container'] == 'zone'
    module.isdir.return_value = False

# Generated at 2022-06-23 02:40:37.132793
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual(dict())

    # test platform
    assert sunosvirtual.platform == 'SunOS'

    # test virtualization_type
    assert 'virtualization_type' not in sunosvirtual.data

    # test virtualization_role
    assert 'virtualization_role' not in sunosvirtual.data

    # test container
    assert 'container' not in sunosvirtual.data

# Generated at 2022-06-23 02:40:43.878667
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class TestModule:
        def __init__(self):
            self.facts = {}

        def get_bin_path(self, arg):
            return False

        def run_command(self, arg):
            return (0, '', '')

    collector = SunOSVirtualCollector(TestModule())
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:50.328430
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    v = SunOSVirtual(module)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['container'] == 'zone'


# Generated at 2022-06-23 02:40:52.288846
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'



# Generated at 2022-06-23 02:41:01.765205
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = SunOSVirtual(dict())

    class FakeModule:
        def get_bin_path(self, tool):
            if tool == 'zonename':
                return '/usr/sbin/zonename'
            if tool == 'virtinfo':
                return '/usr/sbin/virtinfo'
            if tool == 'smbios':
                return '/usr/sbin/smbios'
            return None

        def run_command(self, args):
            if args == '/usr/sbin/zonename':
                return 0, "global", ''
            if args == '/usr/sbin/virtinfo -p':
                return 0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false\n", ''

# Generated at 2022-06-23 02:41:11.381090
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.utils import FakeAnsibleModule
    module = FakeAnsibleModule()
    module.get_bin_path = lambda arg: arg
    v = SunOSVirtual(module)

    # Naming convention: 'expect_<virtualization_tech>_<container>'
    # where <virtualization_tech> is a comma-separated list of the software-based
    # virtualization technologies and <container> is 'zone', 'lxd', 'docker' or ''
    # (empty string).

# Generated at 2022-06-23 02:41:13.292332
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'



# Generated at 2022-06-23 02:41:16.173682
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == 'SunOS'
    assert isinstance(virtual_facts, Virtual)
    assert isinstance(virtual_facts, SunOSVirtual)

# Generated at 2022-06-23 02:41:19.211464
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class is SunOSVirtual

# Generated at 2022-06-23 02:41:29.071714
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import platform
    import ddt

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import processor
    from ansible.module_utils.facts.virtual.SunOS import SunOSVirtual, SunOSVirtualCollector

    @ddt.ddt
    class MockProcessor(processor.Processor):

        IS_WINDOWS = False

        @staticmethod
        def cpu_count():
            return 4

    class MockModule(object):

        def __init__(self):
            self.run_command_mock = None
            self.run_command_calls = 0

            class MockSideEffect(object):
                def __init__(self):
                    self.return_value = 0
                    self.out = b''

            self.run_command_exec_side_effect = MockSideEffect()

# Generated at 2022-06-23 02:41:30.565891
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # call the constructor
    obj = SunOSVirtual()
    assert isinstance(obj, SunOSVirtual)


# Generated at 2022-06-23 02:41:39.821054
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import sys
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils import basic
    from ansible.module_utils.facts import timeout

    # Test computation of the "virtualization_tech_host" and "virtualization_tech_guest" parameters
    # Test for case where the virtualization technology is "zone" and the global zone is virtualized
    virtual_module = basic.AnsibleModule(argument_spec={})
    virtual_module.get_bin_path = lambda x: x
    virtual_module.run_command = lambda x: (0, "", "")
    virtual_module.params = {}
    virtual_module.run_command = lambda x: (0, "global\n", "")
    parameters = SunOSVirtual(virtual_module).get_virtual_facts()

# Generated at 2022-06-23 02:41:45.506312
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virth = SunOSVirtual(module)
    virtual_facts = virth.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-23 02:41:49.760091
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = fake_ansible_module()
    v_facts = SunOSVirtual(module).get_virtual_facts()
    assert v_facts['virtualization_type'] == 'vmware'
    assert 'vmware' in v_facts['virtualization_tech_guest']


# Generated at 2022-06-23 02:41:51.128697
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector


# Generated at 2022-06-23 02:41:56.285848
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virt = SunOSVirtual(module)
    virtual_facts = virt.get_virtual_facts()
    # The unit test SunOSVirtual_get_virtual_facts_testdata covers the following line of code
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['container'] == 'zone'


#######################################################
# Fake ansible module class for unit test of SunOSVirtual.
# A lot of this is taken from the Ansible source code

# Generated at 2022-06-23 02:42:00.141261
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    my_SunOSVirtual = SunOSVirtual()

    assert my_SunOSVirtual.__class__.__name__ == 'SunOSVirtual'
    assert my_SunOSVirtual.platform == 'SunOS'

# Generated at 2022-06-23 02:42:02.779500
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert v.platform == 'SunOS'
    assert v.virtualization_type == "zone"

# Generated at 2022-06-23 02:42:06.471564
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Create an instance of SunOSVirtualCollector.
    """
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual


# Generated at 2022-06-23 02:42:08.715141
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert isinstance(virtual, SunOSVirtual)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:42:13.852006
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert facts.platform == 'SunOS'
    assert facts.virtualization_type is None
    assert facts.virtualization_role is None
    assert facts.container is None
    assert facts.virtualization_tech_guest is None
    assert facts.virtualization_tech_host is None

# Generated at 2022-06-23 02:42:17.128021
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    assert isinstance(x._fact_class, SunOSVirtual)
    assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:42:27.015079
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualFacts

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-23 02:42:38.195349
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    virt = SunOSVirtual(ModuleFacts)

    # Prepare virtualization facts for testing

    # Set virtualization_type and virtualization_role for testing
    #   * `virtualization_type` for testing logic 'virtualbox', 'zone', 'vmware'
    #   * `virtualization_role` for testing logic 'guest', 'host'
    virtualization_type = None
    virtualization_role = None

    # Set container for testing
    #   * `container` for testing logic 'zone'
    container = None

    # Set facts for testing

# Generated at 2022-06-23 02:42:43.241686
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class is not None
    assert issubclass(obj._fact_class, Virtual)

# Generated at 2022-06-23 02:42:45.689486
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict(module=None), platform=None)
    assert v.platform == 'SunOS'
    assert v.__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-23 02:42:49.679010
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''
    module = AnsibleModule(argument_spec={})
    SunOSVirtual.get_virtual_facts(module)

# Generated at 2022-06-23 02:42:50.869721
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:42:53.787530
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    klass = SunOSVirtualCollector
    mySunOSVirtualCollector = klass()
    assert mySunOSVirtualCollector.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-23 02:43:03.625903
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts.sunos.virtual import SunOSVirtual

    sys.modules['ansible'] = type('mod', (), {'__file__': '/dev/null'})()
    sys.modules['ansible.module_utils'] = type('mod', (), {'__file__': '/dev/null'})()
    sys.modules['ansible.module_utils.facts'] = type('mod', (), {'__file__': '/dev/null'})()
    sys.modules['ansible.module_utils.facts.virtual'] = type('mod', (), {'__file__': '/dev/null'})()
    sys.modules['ansible.module_utils.facts.virtual.base'] = type('mod', (), {'__file__': '/dev/null'})()

    sunos = SunOSVirtual

# Generated at 2022-06-23 02:43:14.167700
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts.
    # The module has been tested on Solaris 11.1, Solaris 11.2, OpenSolaris 11 and SmartOS.
    # The following tests have been performed on a SmartOS global zone:
    # - running KVM-based branded zones
    # - running LX-based zones
    # In order to run the tests, you'll need the following:
    # - a file named SMF_MANIFEST_PATH in /var/svc/manifest/site/
    # - a file named SMF_METHOD_PATH in /lib/svc/method/

    import copy
    import sys
    import unittest
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    class ModuleStub(object):
        def __init__(self, params):
            self

# Generated at 2022-06-23 02:43:15.640809
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    a = SunOSVirtualCollector()
    assert a._platform == a.platform

# Generated at 2022-06-23 02:43:16.496305
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:20.673913
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert callable(SunOSVirtualCollector), 'Class does not have a constructor'
    assert SunOSVirtualCollector._platform == 'SunOS', 'Platform should be SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual, 'Wrong fact class used'
    assert issubclass(SunOSVirtualCollector._fact_class, Virtual), 'Fact class should be a child of Virtual'



# Generated at 2022-06-23 02:43:23.271317
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.virtualization_type == 'SunOS'



# Generated at 2022-06-23 02:43:27.047208
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    if v.platform != "SunOS":
        raise AssertionError("Invalid value for SunOSVirtual.platform: %s" % v.platform)

# Generated at 2022-06-23 02:43:37.336359
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class Module:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, arg):
            if arg == 'zonename':
                return '/usr/bin/zonename'
            elif arg == 'modinfo':
                return '/usr/sbin/modinfo'
            elif arg == 'virtinfo':
                return '/usr/sbin/virtinfo'
            elif arg == 'smbios':
                return '/usr/sbin/smbios'
            else:
                return None

        def run_command(self, cmd):
            rc = None
            err = None
            out = None
            if cmd == '/usr/bin/zonename':
                rc = self.rc

# Generated at 2022-06-23 02:43:41.369834
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    v = SunOSVirtual('/bin/ls', {})
    assert v.platform == 'SunOS'
    assert v.module == '/bin/ls'
    assert v.params == {}

# Generated at 2022-06-23 02:43:50.938736
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts_instance = SunOSVirtual()
    virtual_facts_instance.module.run_command = fake_run_command
    virtual_facts_instance.module.get_bin_path = lambda x: '/bin/' + x
    virtual_facts_instance.module.sysctl = fake_sysctl
    virtual_facts_instance.module.get_file_content = fake_get_file_content
    virtual_facts = virtual_facts_instance.get_virtual_facts()
    print("Virtual facts is: " + str(virtual_facts))
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])

# Generated at 2022-06-23 02:44:00.543484
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import json
    virtual_facts = SunOSVirtual().get_virtual_facts()

    virtual_facts_json = json.dumps(virtual_facts)
    assert '"virtualization_type": "xen"' in virtual_facts_json
    assert '"virtualization_type": "vmware"' in virtual_facts_json
    assert '"virtualization_type": "Parallels"' in virtual_facts_json
    assert '"virtualization_type": "virtualbox"' in virtual_facts_json
    assert '"virtualization_role": "guest"' in virtual_facts_json
    assert '"virtualization_tech_guest": ' in virtual_facts_json
    assert '"virtualization_tech_host": ' in virtual_facts_json
    assert '"container": "zone"' in virtual_facts_json

# Generated at 2022-06-23 02:44:03.317129
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    pytest_assertion(SunOSVirtualCollector)

# Generated at 2022-06-23 02:44:08.536358
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ Test constructor of class SunOSVirtual """

    module = MockModule()

    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'
    assert 'virtualization_tech_guest' not in virt.facts
    assert 'virtualization_tech_host' not in virt.facts
    assert 'container' not in virt.facts

# Generated at 2022-06-23 02:44:10.429510
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test constructor of class SunOSVirtualCollector
    """
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:44:13.561395
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts_virtual = SunOSVirtual(dict())

    assert facts_virtual
    assert facts_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:44:14.766719
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual({}, {})
    assert virt.__class__ == SunOSVirtual

# Generated at 2022-06-23 02:44:16.197892
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'

# Unit tests for methods of class SunOSVirtual

# Generated at 2022-06-23 02:44:17.381579
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:44:22.980965
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ Unit test for constructor of class SunOSVirtual """

    # Construct SunOSVirtual object and check value of its inherited property:
    sunos = SunOSVirtual({})
    assert sunos.platform == 'SunOS'

# Generated at 2022-06-23 02:44:35.491481
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Since we can't easily mock the output of modinfo and the other commands
    # this test is currently a "best effort" test. It will check that the
    # different virtualization_type flags are correctly set.

    # This is the place where we will store the result of the get_virtual_facts()
    # method
    facts = dict()

    # We create a SunOSVirtual object (this object will call the get_virtual_facts()
    # method) with a fake module
    sunos = SunOSVirtual({})

    # Read the virtualization_type that was set by the get_virtual_facts()
    # method
    sunos._populate_virtual_facts(facts)

    # Check that virtualization_type is correctly set. We know it's a VMware
    # because we configured virtinfo to return the following output:
    #   virtinfo -

# Generated at 2022-06-23 02:44:36.004992
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass