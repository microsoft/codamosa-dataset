

# Generated at 2022-06-23 02:34:47.032022
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    This tests the constructor of the class SunOSVirtual
    """

    import sys
    from ansible.module_utils.facts.virtual import Virtual

    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

    builtins.module = MagicMock()
    virtual = Virtual()

# Generated at 2022-06-23 02:34:58.262137
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()

    # vmware guest
    module.run_command.side_effect = [
        (0, "", ""),
        (0, "", ""),
        (0, "", ""),
        (0, "", ""),
    ]
    SunOSVirtual(module).get_virtual_facts()
    assert module.run_command.call_count == 4
    assert module.run_command.call_args_list[0][0][0] == 'zonename'
    assert module.run_command.call_args_list[1][0][0] == 'smbios'
    assert module.run_command.call_args_list[2][0][0] == 'modinfo'
    assert module.run_command.call_args_list[3][0][0] == 'virtinfo -p'

# Generated at 2022-06-23 02:35:08.180228
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    ''' Test get_virtual_facts of SunOSVirtual class.
    '''
    module = AnsibleModule(
        argument_spec = dict()
    )

    virt = SunOSVirtual(module=module)
    facts = virt.get_virtual_facts()
    assert 'virtualization_tech_guest' in facts.keys()
    assert 'virtualization_tech_host' in facts.keys()
    assert 'virtualization_type' in facts.keys()
    assert 'virtualization_role' in facts.keys()
    assert 'container' in facts.keys()


''' Add unit tests for method get_virtual_facts of class SunOSVirtual here.
    The method is tested above.
'''

# Generated at 2022-06-23 02:35:09.039388
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    pass

# Generated at 2022-06-23 02:35:11.322983
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # The test requires input from a real environment, so it is skipped.
    # A method is available to factorize code and simplify if required.
    pass

# Generated at 2022-06-23 02:35:12.879639
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v is not None

# Generated at 2022-06-23 02:35:23.633033
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual import SunOSVirtual
    import os
    import sys

    # Mock the module
    module = type('ansible.module_utils.facts.virtual.SunOSVirtual.test1', (object,), {})()
    module.get_bin_path = lambda x: '/usr/sbin/' + x.replace("-", "")
    module.run_command = lambda cmd, check_rc=True: (0, [], [])
    module.get_bin_path.side_effect = lambda x: '/usr/sbin/' + x.replace("-", "")
    module.run_command.side_effect = lambda cmd, check_rc=True: (0, [], [])

    # Create the class object
    my_

# Generated at 2022-06-23 02:35:29.735971
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    if not isinstance(virtual_facts, SunOSVirtual):
        raise AssertionError("Class object is not class SunOSVirtual")

# Instantiate class object as a module variable so it can be imported by other code
FACT_SUBCLASS = SunOSVirtual

# Generated at 2022-06-23 02:35:31.106398
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:35:33.447231
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc
    assert vc._fact_class
    assert vc._platform == 'SunOS'

# Generated at 2022-06-23 02:35:35.423729
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    virtual.get_virtual_facts()

# Generated at 2022-06-23 02:35:41.572627
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.test_sunos_virtual import test_SunOSVirtual as test_module
    test_virtual_class = SunOSVirtual(test_module)
    assert test_virtual_class.platform == 'SunOS'


# Generated at 2022-06-23 02:35:44.906093
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.virtualization_tech_host == set()
    assert virtual.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:35:50.348632
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from unittest import TestCase
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    facts = SunOSVirtual(dict())
    expected_virtual_facts = dict(virtualization_type='kvm', virtualization_role='guest', container=None,
                                  virtualization_tech_guest=['kvm'], virtualization_tech_host=[])
    assert facts.get_virtual_facts() == expected_virtual_facts

# Generated at 2022-06-23 02:35:57.555348
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    class Fake_module:
        def __init__(self):
            self.params = {}
            self.exit_json = {}
            self.run_command = lambda x,  y: (0, '', '')

    class Fake_BaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.module = Fake_module()
            self.collect()

        def get_bin_path(self, name):
            return {}

    fake_base_fact_collector = Fake_BaseFactCollector()


# Generated at 2022-06-23 02:36:01.859929
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector.platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:09.023115
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    SunOSVirtual(module)
    module.exit_json.assert_called_with(
        changed=False,
        ansible_facts={
            'virtual_facts': {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()
            }
        }
    )


# Class importing the plugin and adding it to the global list of virtual collectors
from ansible.module_utils.facts.virtual import virtual_collector_plugin
virtual_collector_plugin.add_plugin(SunOSVirtualCollector)

# Generated at 2022-06-23 02:36:11.320912
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector(None)
    assert x.platform == 'SunOS'
    assert x.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:13.882919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    v = SunOSVirtual(module)
    assert v.platform == 'SunOS'
    assert v.virtualization_type == 'zone'


# Generated at 2022-06-23 02:36:26.794604
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.sunos_virtual import SunOSVirtual
    from ansible.module_utils._text import to_bytes

    # Get module for testing
    fp = os.path.dirname(__file__) + "/../unit/data/ansible_facts/SunOS_zone"
    f = open(fp, "rb")
    # Inject class methods
    SunOSVirtual.module = type('Module', (object,), {
        'exit_json': exit_json,
        'fail_json': fail_json,
        'run_command': run_command,
        'get_bin_path': get_bin_path
    })
    SunOSVirtual.module.params = {}
    SunOSVirtual.module.exit_json = exit_json
   

# Generated at 2022-06-23 02:36:28.638534
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:36:40.043432
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule(platform='SunOS', os_family='Solaris')
    # Setup a fake return code and output of /usr/sbin/virtinfo
    module.run_command.side_effect = [
        # virtinfo can only be run from the global zone
        (0, 'virtinfo can only be run from the global zone', ''),
        # Returns a fake output of smbios
        (0, 'Manufacturer: VirtualBox\nProduct: VirtualBox\n', ''),
        (0, 'global', '')]
    module.get_bin_path.side_effect = [
        '/usr/sbin/virtinfo',
        '/usr/sbin/smbios',
        '/usr/sbin/zonename']
    # Setup the virtual facts class
    virtual_facts = SunOSVirtual(module=module)

# Generated at 2022-06-23 02:36:49.813260
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test class SunOSVirtual on method get_virtual_facts
    """
    import platform
    import sys
    if sys.version_info.major < 3:
        import __builtin__ as builtins
    else:
        import builtins
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    class MockModule:
        class MockRunCommand:
            def __init__(self):
                self.rc = 0
                self.stdout = ""
                self.stderr = ""

# Generated at 2022-06-23 02:37:00.314364
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = {}
    virt = SunOSVirtual(facts=facts)
    assert virt.virtualization_type is None
    assert virt.virtualization_role is None
    assert virt.container is None
    assert virt.virtualization_tech_guest == set()
    assert virt.virtualization_tech_host == set()

    facts['virtualization_type'] = 'ldom'
    facts['virtualization_role'] = 'guest'
    facts['container'] = 'zone'
    virt = SunOSVirtual(facts=facts)
    assert virt.virtualization_type == 'ldom'
    assert virt.virtualization_role == 'guest'
    assert virt.container == 'zone'
    assert virt.virtualization_tech_guest == set()
    assert virt.virtualization_tech_host == set()


# Generated at 2022-06-23 02:37:02.899255
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock(params={})
    fact_class = SunOSVirtual(module)
    assert fact_class.platform == "SunOS"


# Generated at 2022-06-23 02:37:05.985230
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    facts = SunOSVirtual(module).collect()
    # check if facts contains expected values

    assert facts['virtualization_type'] is not None
    assert facts['virtualization_role'] is not None
    assert facts['virtualization_role'] == 'guest' or facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:37:12.866120
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    ifile = os.path.join(os.getcwd(), 'testfile')
    test_tuple = (ifile, SunOSVirtual)
    with open(ifile, 'w') as f:
        f.write('')

    provider = SunOSVirtualCollector.factory()
    if provider:
        object, err = provider.collect(test_tuple)
        assert object
        assert not err
    else:
        assert False

    try:
        os.unlink(ifile)
    except OSError:
        pass

# Generated at 2022-06-23 02:37:20.107566
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Initialize a module object and SunOSVirtual instance
    module = AnsibleModule({})
    v = SunOSVirtual(module)

    # Set up some test input variables

    # Create a test instance of a subclass of the _fact_class
    v = _fact_class(module)

    # Execute the constructor code
    c = VirtualCollector(module)

    # Check the result of the constructor
    assert c._fact_class._platform == 'SunOS'
    assert c._fact_class == SunOSVirtual
    assert c._platform == 'SunOS'

# Generated at 2022-06-23 02:37:29.539094
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleDataCollector

    # Define mock objects
    class MyModuleDataCollector(ModuleDataCollector):
        def __init__(self):
            self.module = None

    # Create instance of class SunOSVirtual
    # This class wraps ansible Module, which is not present,
    # so we pass a mock object instead
    sunosvirt = SunOSVirtual(MyModuleDataCollector())

    # TODO: For now this test only validates that the function does not fail,
    # there is no more validation as the underlying methods are mocked.
    # We should improve this test to actually mock the validation data.
    sunosvirt.get_virtual_facts()



# Generated at 2022-06-23 02:37:32.243456
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:37:41.888133
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    # Test for container type 'zone'
    context = {}
    context['module'] = FakeAnsibleModule([('zonename', 'test_zone')], 'test_zone')
    sunos = SunOSVirtual(context)
    facts = sunos.get_virtual_facts()
    assert facts['container'] == 'zone'
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_tech_host' not in facts
    # Test for container type 'zone' and virtualized globalzone (zone type xen)
    context = {}

# Generated at 2022-06-23 02:37:44.530228
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # check the type of the object is VirtualCollector
    obj = SunOSVirtualCollector()
    assert isinstance(obj, VirtualCollector)


# Generated at 2022-06-23 02:37:54.729727
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no parameter
    collector = SunOSVirtualCollector()
    assert collector.__class__ == SunOSVirtualCollector
    assert collector._UNAME_RELEASE_INFO.__class__ == list
    assert collector._UNAME_RELEASE_INFO[0].__class__ == list
    assert collector._UNAME_RELEASE_INFO[1].__class__ == list
    assert collector._UNAME_SYSNAME_MATCH.__class__ == list
    assert collector._fact_class.__class__ == SunOSVirtual
    assert collector._platform.__class__ == str
    assert collector._platform == 'SunOS'
    # Test with parameters
    collector = SunOSVirtualCollector('SunOSVirtual', 'SunOS')
    assert collector.__class__ == SunOSVirtualCollector
    assert collector._UNAME_RELEASE_INFO.__

# Generated at 2022-06-23 02:38:04.191914
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.params['gather_subset'] = ["virtual"]
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] is None
    assert facts['zone'] is None
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-23 02:38:05.606109
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual()
    assert sv.platform == 'SunOS'

# Generated at 2022-06-23 02:38:17.358349
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This is mostly a copy of the method get_virtual_facts of class SunOSVirtual
    with faked commands to test the parsing of the output.
    """
    import sys

    # python3 compat
    if sys.version_info[0] > 2:
        basestring = str

    import os

    class ModuleStub:

        def __init__(self, *args):
            self.args = args

        def get_bin_path(self, binary):
            print('get_bin_path: {}'.format(binary))
            return binary

        def run_command(self, command):
            print('run_command: {}'.format(command))
            if command == 'zonename':
                return (0, 'global', '')

# Generated at 2022-06-23 02:38:28.614949
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    d = {'ansible_facts': {}, 'changed': False, 'failed': False}
    # A zone
    zone_zonename = {'rc': 0, 'out': "global\n", 'err': ''}
    zone_modinfo = {'rc': 0, 'out': "", 'err': ''}
    zone_smbios = {'rc': 1, 'out': '', 'err': ''}
    module.run_command = lambda x: zone_zonename if x == 'zonename' else (
                                       zone_modinfo if x == 'modinfo' else zone_smbios)
    sunos = SunOSVirtual(module)
    virtual_facts = sunos.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'


# Generated at 2022-06-23 02:38:31.961764
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    import json
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create an instance of class SunOSVirtual
    obj = SunOSVirtual()

    # Run the method
    obj.get_virtual_facts()

# Generated at 2022-06-23 02:38:34.334631
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts._platform == 'SunOS'

# Generated at 2022-06-23 02:38:42.752991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Test SunOSVirtual.get_virtual_facts()
    """
    # Generate a fake module
    module = AnsibleModule(argument_spec={})

    class FakeModuleUtilBase:
        def get_bin_path(self, name):
            import sys
            if name == 'zonename' and sys.platform.startswith('sunos'):
                return '/usr/bin/zonename'

# Generated at 2022-06-23 02:38:51.160356
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor for class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector.platform == 'SunOS'
    assert sunos_virtual_collector._fact_class.platform == 'SunOS'
    assert sunos_virtual_collector._fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-23 02:38:53.212815
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:38:55.667591
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtobj = SunOSVirtual(module)
    assert virtobj



# Generated at 2022-06-23 02:38:59.545090
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('MockModule', (), {'run_command': run_command,
                                     'get_bin_path': get_bin_path})
    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    assert facts == {'virtualization_role': 'guest',
                     'virtualization_type': 'zone'}



# Generated at 2022-06-23 02:39:07.273220
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    facts = SunOSVirtual(module)
    facts.module.get_bin_path = fake_get_bin_path
    facts.module.run_command = fake_run_command
    test_facts = facts.get_virtual_facts()
    assert test_facts['virtualization_role'] == 'guest'
    assert test_facts['virtualization_type'] == 'zone'
    assert test_facts['virtualization_tech_guest'] == {'zone'}
    assert test_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:39:18.026992
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test for a global zone
    module = FakeAnsibleModule(dict(os={'family': 'SunOS', 'name': 'SunOS'}), 'SunOS')
    test_SunOSVirtual = SunOSVirtual(module)
    virtual_facts = test_SunOSVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == {'zone'}
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'container' not in virtual_facts

    # Test for a branded zone
    module = FakeAnsibleModule(dict(os={'family': 'SunOS', 'name': 'SunOS'}), 'SunOS')
    module.add_file

# Generated at 2022-06-23 02:39:19.002881
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:20.429402
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ Constructor: SunOSVirtual()
    """
    SunOSVirtual()

# Generated at 2022-06-23 02:39:24.175441
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    # Class created, but no attributes set
    assert isinstance(v, SunOSVirtual)
    assert hasattr(v, 'platform')
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:39:28.159292
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This test case is used for test the constructor of class SunOSVirtualCollector
    """
    result = SunOSVirtualCollector()
    assert result._fact_class == SunOSVirtual
    assert result._platform == 'SunOS'

# Generated at 2022-06-23 02:39:33.562629
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = 'ansible.module_utils.facts.virtual.sunos.SunOSVirtual'
    obj = SunOSVirtual({}, FakeModule)
    assert obj.platform == SunOSVirtual.platform
    assert obj.__class__.__name__ == 'SunOSVirtual'
    assert obj._platform == SunOSVirtualCollector._platform
    assert obj._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:34.776826
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual({})
    assert m.platform == 'SunOS'


# Generated at 2022-06-23 02:39:39.693601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mock_module = type('module', (object,), {})()
    mock_module.params = {
        # For VirtualCollector
        'gather_subset': [],
        'filter': [],
        # For SunOSVirtualCollector
        'gather_subset': [],
        'filter': [],
    }
    SunOSVirtualCollector(mock_module)

# Generated at 2022-06-23 02:39:41.743857
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == "SunOS"

# Generated at 2022-06-23 02:39:44.816807
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_class = SunOSVirtual({}, None)
    assert virtual_facts_class.platform == 'SunOS'
    assert virtual_facts_class.get_virtual_facts() == {}

# Generated at 2022-06-23 02:39:55.584609
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=[0, '', ''])
    module.get_bin_path = MagicMock(return_value='/usr/bin/')
    os.path.exists = MagicMock(return_value=False)
    os.path.isdir = MagicMock(return_value=False)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == host_tech
    assert virtual_facts['virtualization_tech_guest'] == guest_tech


# Generated at 2022-06-23 02:40:01.978106
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virt_facts = SunOSVirtual(module).get_virtual_facts()

    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'container' not in virt_facts
    assert isinstance(virt_facts['virtualization_tech_guest'], set)
    assert isinstance(virt_facts['virtualization_tech_host'], set)

# Note: this helper class is only used for unit testing

# Generated at 2022-06-23 02:40:08.664075
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:40:20.636007
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v=SunOSVirtual()
    # The SunOSVirtual object should have a platform attribute of 'SunOS'
    assert(v.platform=='SunOS')
    # The SunOSVirtual object should have a Virtualization facts attribute of 'SunOS_virtual'
    assert(v.facts=='SunOS_virtual')
    # The SunOSVirtual object should have a virtualization_type attribute of None
    assert(v.virtualization_type==None)
    # The SunOSVirtual object should have a virtualization_role attribute of None
    assert(v.virtualization_role==None)
    # The SunOSVirtual object should have a container attribute of None
    assert(v.container==None)
    # The SunOSVirtual object should have a virtualization_tech_guest attribute of None
    assert(v.virtualization_tech_guest==None)
   

# Generated at 2022-06-23 02:40:24.238522
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(module=None)
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:40:28.510316
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ Unit test for constructor of class SunOSVirtual """
    sunOSFacts = SunOSVirtual({'test1': 'test1', 'test2': 'test2'})
    assert isinstance(sunOSFacts, Virtual)
    assert isinstance(sunOSFacts, SunOSVirtual)



# Generated at 2022-06-23 02:40:31.170481
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    oSunOSVirtual = SunOSVirtual()
    assert oSunOSVirtual.platform == 'SunOS'

# Generated at 2022-06-23 02:40:40.100024
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test non-virtualized system
    os.environ['PATH'] = "/bin:/usr/bin:/sbin:/usr/sbin"
    module = AnsibleModuleMock({},
                               {},
                               [],
                               False,
                               '/tmp',
                               False,
                               False)
    sunos_virtual = SunOSVirtual(module=module)
    result = sunos_virtual.get_virtual_facts()
    assert 'virtualization_type' not in result
    assert 'virtualization_role' not in result
    assert 'container' not in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result
    assert len(result['virtualization_tech_guest']) == 0

# Generated at 2022-06-23 02:40:41.854016
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual(dict(), dict()).get_virtual_facts()

# Generated at 2022-06-23 02:40:43.522505
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, {})
    assert v is not None

# Generated at 2022-06-23 02:40:45.172468
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test the constructor for class SunOSVirtualCollector"""
    assert SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:47.053121
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:53.231360
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    SunOSVirtual_get_virtual_facts = SunOSVirtual(module)
    result = SunOSVirtual_get_virtual_facts.get_virtual_facts()
    assert result == {
        'container': 'zone',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': set([]),
        'virtualization_role': 'guest',
        'virtualization_type': 'zone'
    }


# Generated at 2022-06-23 02:40:56.691056
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:58.846246
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:02.893310
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == "SunOS"
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:04.644622
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.__name__ == "SunOSVirtualCollector"

# Test the SunOSVirtual class

# Generated at 2022-06-23 02:41:07.121235
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vCol = SunOSVirtualCollector()
    assert vCol._platform == 'SunOS'
    assert type(vCol._fact_class) == type(SunOSVirtual)


# Generated at 2022-06-23 02:41:17.211842
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import datetime
    systemdatetime = datetime.datetime.now()
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    c = Collector()
    a = SunOSVirtualCollector(c)
    def test_z() -> str:
        return 'test'
    def test_a() -> str:
        return 'test'
    def test_b() -> str:
        return 'test'
    def test_c() -> str:
        return 'test'
    def test_aa() -> int:
        return 1
    def test_ab() -> int:
        return 0
    def test_ac() -> int:
        return 0
    def test_ad() -> int:
        return 0

# Generated at 2022-06-23 02:41:18.241045
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:27.871459
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test that the class constructor returns a SunOSVirtual object
    """
    module = DummyModule()
    py_version = sys.version_info
    py3 = py_version[0] == 3
    if py3:
        from io import StringIO
    else:
        from StringIO import StringIO
    if py3:
        from unittest.mock import patch
    else:
        from mock import patch

# Generated at 2022-06-23 02:41:32.609626
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class.platform == 'SunOS'
    assert facts._collector_platforms == ('SunOS',)
    assert facts.platforms == ('SunOS',)
    assert facts._fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-23 02:41:34.661890
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:41:35.499010
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:39.796546
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class == SunOSVirtual
    assert c._platform == 'SunOS'

# Generated at 2022-06-23 02:41:43.957808
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector.__new__(SunOSVirtualCollector)
    assert x is not None
    assert x._fact_class == SunOSVirtual
    assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:41:46.934488
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virt = SunOSVirtual(module)
    assert virt.get_virtual_facts()['virtualization_tech_guest'] == set()


# Generated at 2022-06-23 02:41:48.409059
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = Mock(params={})
    SunOSVirtual(module_mock)

# Generated at 2022-06-23 02:41:51.411038
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual()
    assert virtual_obj.platform == 'SunOS'

# Unit tests for get_virtual_facts() of class SunOSVirtual

# Generated at 2022-06-23 02:41:53.903764
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc._fact_class == SunOSVirtual
    assert svc._platform == 'SunOS'

# Generated at 2022-06-23 02:41:55.082386
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x is not None

# Generated at 2022-06-23 02:42:07.005748
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import os
    import sys

    if sys.version_info[0] < 3:
        class _module:
            def __init__(self, params=None):
                self.params = params
            def get_bin_path(self, name, req_true=False, opt_true=None, opt_false=None):
                if opt_true:
                    return opt_true
                elif opt_false:
                    return opt_false
                else:
                    return "/bin/" + name
            def run_command(self, cmd):
                if cmd == "/bin/zonename":
                    return (0, "global", None)
                else:
                    return (0, None, None)

# Generated at 2022-06-23 02:42:14.572247
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual(dict())
    assert (m.platform == 'SunOS')
    assert (m.product_name is None)
    assert (m.virtualization_type is None)
    assert (m.virtualization_role is None)
    assert (m.container is None)
    assert (m.facts is None)
    assert (isinstance(m.virtualization_tech_guest, set))
    assert (isinstance(m.virtualization_tech_host, set))

# Generated at 2022-06-23 02:42:19.299763
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual(dict(module=None, facts=dict()))
    assert obj.platform == 'SunOS'


# Generated at 2022-06-23 02:42:26.689497
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule({})
    v = SunOSVirtual({}, module=module)

    facts = v.get_virtual_facts()

    assert facts['container'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_type'] == 'zone'


# Unit test loader
if __name__ == '__main__':
    run_unittests(globals())

# Generated at 2022-06-23 02:42:30.209907
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    x = SunOSVirtualCollector()
    assert isinstance(x, VirtualCollector)


# Generated at 2022-06-23 02:42:40.802767
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    
    # Check if the object correctly sets the virtualization_type and virtualization_role
    modinfo = module.get_bin_path('modinfo')
    if modinfo:
        rc, out, err = module.run_command(modinfo)
        if rc == 0:
            for line in out.splitlines():
                if 'VMware' in line:
                    assert virtual_facts['virtualization_type'] == 'vmware'
                    assert virtual_facts['virtualization_role'] == 'guest'
                if 'VirtualBox' in line:
                    assert virtual_facts['virtualization_type'] == 'virtualbox'
                    assert virtual_facts['virtualization_role'] == 'guest'

    # Check if the object correctly sets the container and virtualization_type

# Generated at 2022-06-23 02:42:43.292819
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Unit test for constructor of class SunOSVirtual
    '''
    obj = SunOSVirtual()
    assert obj


# Generated at 2022-06-23 02:42:44.677724
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = SunOSVirtual(dict())

    assert module._platform == 'SunOS'

# Generated at 2022-06-23 02:42:57.062649
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.virtual import SunOSVirtual

    c = SunOSVirtual()
    setattr(c, "module", MockModule())

    # Test zone with no guest tools
    c.module.run_command.expect_call(zonename).return_value = (0, 'a\n', '')

    # Test domaining
    c.module.get_bin_path.expect_call('virtinfo').return_value = "/usr/sbin/virtinfo"
    c.module.run_command.expect_call(virtinfo).return_value = (0, '', '')

    # Test virtualbox

# Generated at 2022-06-23 02:43:01.685645
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    ''' Constructor SunOSVirtual should return an object. '''
    module_mock = {}
    virtual_facts_obj = SunOSVirtual(module_mock)
    assert virtual_facts_obj is not None


# Generated at 2022-06-23 02:43:03.295125
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(), dict())
    assert virtual.data == dict()

# Generated at 2022-06-23 02:43:06.557633
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:43:09.067924
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:43:19.333934
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()

    facts = {'virtualization_type': None, 'virtualization_role': None, 'container': None, 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    # Test on ldom
    ldom = FakeSunOSVirtual('ldom', 'guest (control)', 'LDoms', 'Zone', 'LDoms', module, facts)
    ldom_facts = ldom.get_virtual_facts()
    assert ldom_facts['virtualization_type'] == 'ldom'
    assert ldom_facts['virtualization_role'] == 'guest (control)'
    assert 'ldom' in ldom_facts['virtualization_tech_guest']
    assert 'guest (zone)' in ldom_facts['virtualization_tech_guest']

    # Test on zone
   

# Generated at 2022-06-23 02:43:23.627288
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    setattr(module, 'run_command', lambda *args, **kwargs: ([0, '', ''], [0, '']))

    # A non-virtualized machine
    module.set_command_resu

# Generated at 2022-06-23 02:43:28.462027
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create empty object
    obj = SunOSVirtualCollector()
    # Is it the correct class?
    assert isinstance(obj, SunOSVirtualCollector)
    # Is it the correct platform?
    assert obj._platform == 'SunOS'
    # Is it the correct fact class?
    assert obj._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:43:33.296489
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:43:37.710094
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    # AnsibleModule object as module_utils.basic.AnsibleModule object
    sunos_virtual_collector = SunOSVirtualCollector(module)
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'



# Generated at 2022-06-23 02:43:39.595525
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:43:41.899583
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class is SunOSVirtual

# Generated at 2022-06-23 02:43:44.030382
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    result = SunOSVirtualCollector()
    assert result.platform == 'SunOS'
    assert result._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:51.807227
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual()

    # SunOS: zone: native zone
    v.module.run_command = mock_run_command(
        [(0, ZONENAME_OUTPUT, ''),
         (0, VMODINFO_OUTPUT_VMWARE, ''),
         (0, VMODINFO_OUTPUT_VMWARE, ''),
         (1, '', ''),
         (0, SMBIOS_OUTPUT_VMWARE, '')])
    virtual_facts = v.get_virtual_facts()
    assert sorted(virtual_facts['virtualization_tech_guest']) == sorted(['zone', 'vmware'])
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-23 02:44:03.825594
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test module shared/library/facts/sunos/virtual.py with:
    uname -s: SunOS
    """
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import os

    # If ansible is called via the python interpreter, ansible_module_runtime.SOFTWARE_VERSION will be set
    facts = Facts().populate()

# Generated at 2022-06-23 02:44:10.591925
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test 1: Successful initialization of collector with expected platform
    collector1 = SunOSVirtualCollector({})
    assert collector1._platform == 'SunOS', "Expected 'SunOS' as value of VirtualCollector._platform"

    # Test 2: Failed initialization of collector with strange platform
    collector2 = SunOSVirtualCollector({'ansible_facts': {'ansible_system': 'Linux'}})
    assert collector2._fact_class is None, "Expected VirtualCollector._fact_class to be None"



# Generated at 2022-06-23 02:44:21.904250
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.fact_class == SunOSVirtual
    assert vc.platform == 'SunOS'


if __name__ == '__main__':
    # Unit test for class SunOSVirtual
    module = AnsibleModule(argument_spec={})
    sos = SunOSVirtual(module)
    # result = sos.get_virtual_facts()
    # if result['container'] == 'zone':
    #     print(result['container'])
    #     if 'virtualization_type' in result:
    #         print(result['virtualization_type'])
    #         print(result['virtualization_role'])
    # else:
    #     if 'virtualization_type' in result:
    #         print(result['virtualization_type'])
    #         print(

# Generated at 2022-06-23 02:44:25.448690
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_sunos_virtual_collector = SunOSVirtualCollector()
    assert my_sunos_virtual_collector._fact_class == SunOSVirtual
    assert my_sunos_virtual_collector._platform == 'SunOS'


# Generated at 2022-06-23 02:44:27.913271
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'


# Generated at 2022-06-23 02:44:31.991060
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvirtualcollector = SunOSVirtualCollector()
    assert sunosvirtualcollector._platform == 'SunOS'
    assert sunosvirtualcollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:44:41.052096
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.SunOS import SunOSVirtual
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.virtual.SunOS import SunOSVirtualCollector
    test_object = SunOSVirtual()
    os = Collector()
    os.populate(['SunOS'])
    os.populate(['SunOS', 'SunOS_6'])
    virtual = SunOSVirtualCollector()
    fake_data = {
        'module': {
            'run_command': os.run_command,
            'get_bin_path': os.get_bin_path
        }
    }
    test_object.get_virtual_facts(fake_data)
    assert test_object.platform == 'SunOS'
    assert test_object.virtualization