

# Generated at 2022-06-23 02:34:45.961355
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual()._get_virtual_facts()
    if not 'virtualization_type' in virtual_facts:
        assert True
    elif virtual_facts['virtualization_type'] == 'virtualbox':
        assert virtual_facts['virtualization_role'] == 'guest'
    elif virtual_facts['virtualization_type'] == 'vmware':
        assert virtual_facts['virtualization_role'] == 'guest'
    elif virtual_facts['virtualization_type'] == 'parallels':
        assert virtual_facts['virtualization_role'] == 'guest'
    elif virtual_facts['virtualization_type'] == 'xen':
        assert virtual_facts['virtualization_role'] == 'guest'
    elif virtual_facts['virtualization_type'] == 'kvm':
        assert virtual_facts

# Generated at 2022-06-23 02:34:50.690791
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    SunOSVirtualCollector.fail_key = True
    virtual_facts = SunOSVirtualCollector.load_virtual_facts(module)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts



# Generated at 2022-06-23 02:34:57.379804
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Collector
    my_obj = SunOSVirtualCollector(basic.AnsibleModule(
    ))
    my_obj_2 = SunOSVirtualCollector(basic.AnsibleModule(
    ))
    assert my_obj is not None
    assert my_obj_2 is not None
    assert Collector._collectors[SunOSVirtualCollector._platform] is my_obj

# Generated at 2022-06-23 02:35:05.208324
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual({})
    facts = m.get_virtual_facts()
    assert isinstance(facts, dict)
    assert facts['container'] == 'zone'
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert 'vmware' in facts['virtualization_tech_guest']
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'zone' in facts['virtualization_tech_host']

# Generated at 2022-06-23 02:35:07.805486
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x is not None

# Generated at 2022-06-23 02:35:13.510007
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual object
    v = SunOSVirtual({}, {"module_setup": True})
    # Make sure that get_virtual_facts() returns None when it is called with
    # a mock of module_utils.facts.virtual.base.Virtual._get_platform() that
    # always return "SunOS"
    assert v.get_virtual_facts() == None

# Generated at 2022-06-23 02:35:16.095474
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:35:18.944298
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:35:20.939816
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()

    assert x.platform == 'SunOS'


# Generated at 2022-06-23 02:35:23.129023
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual



# Generated at 2022-06-23 02:35:25.658737
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector(None)
    assert hasattr(collector, 'platform')
    assert collector.platform == SunOSVirtualCollector._platform


# Generated at 2022-06-23 02:35:27.458775
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''Unit test for constructor of class SunOSVirtual'''
    # To do: Create unit test for constructor of class SunOSVirtual


# Generated at 2022-06-23 02:35:35.238597
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # load fixtures
    fixture_zone_global = load_fixture("SunOS/zone_global.txt")
    fixture_zone_zone01 = load_fixture("SunOS/zone_zone01.txt")
    fixture_zone_zone01_solaris9 = load_fixture("SunOS/zone_zone01_solaris9.txt")
    fixture_zone_zone01_vmware = load_fixture("SunOS/zone_zone01_vmware.txt")
    fixture_zone_zone01_virtualbox = load_fixture("SunOS/zone_zone01_virtualbox.txt")
    fixture_zone_zone01_zone_zone01 = load_fixture("SunOS/zone_zone01_zone_zone01.txt")

# Generated at 2022-06-23 02:35:37.053647
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class

# Generated at 2022-06-23 02:35:48.985135
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos.virtual import SunOSVirtual

    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    module.get_bin_path = fake_get_bin_path
    setattr(module, 'os_family', 'SunOS')

    os_release_content = """NAME=Oracle Solaris
    VERSION="11.4"
    ID=solaris
    ID_LIKE=solaris
    VARIANT="Server"
    VARIANT_ID=server
    VERSION_ID=11.4
    """

    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None
    assert virtual_facts

# Generated at 2022-06-23 02:35:50.407933
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:35:57.579625
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.exit_json = lambda x: x
    virtual = SunOSVirtual(module)
    host_tech = set()
    guest_tech = set()
    virtual_facts = virtual.get_virtual_facts()
    if 'virtualization_tech_guest' in virtual_facts:
        guest_tech.add(virtual_facts['virtualization_tech_guest'])
    if 'virtualization_tech_host' in virtual_facts:
        host_tech.add(virtual_facts['virtualization_tech_host'])

# Generated at 2022-06-23 02:36:01.089852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert(x._platform == 'SunOS')
    assert(x._fact_class == SunOSVirtual)

# Generated at 2022-06-23 02:36:10.881326
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    context = {}

    my_sunosvirtual = SunOSVirtual(context)

    # Test for LDoms
    context['module'] = DummyModule(
        command_outputs={
            '/usr/sbin/virtinfo -p': (
                0,
                'DOMAINROLE|impl=LDoms|control=true|io=true|service=true|root=true',
                ''
            )
        }
    )
    virtual_facts = my_sunosvirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'ldom'
    assert virtual_facts['virtualization_role'] == 'host (control,io,service,root)'
    assert 'container' not in virtual_facts

    # Test for LDoms as

# Generated at 2022-06-23 02:36:17.007364
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    expected_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'hyperv',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'hyperv'}
    }
    module = FakeModule({
        'zone': 'guest',
        'smbios': 'Hyper-V'
    })
    SunOSVirtualCollector(module).collect()
    assert module.exit_json.call_args[0][0]['ansible_facts']['virtualization'] == expected_virtual_facts

# Generated at 2022-06-23 02:36:21.373710
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''Test SunOSVirtual Class'''
    vtype = VirtualCollector._get_platform_virtual(SunOSVirtualCollector)
    vtype.get_all_facts()
    assert vtype is not None

# Generated at 2022-06-23 02:36:26.340451
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor test SunOSVirtualCollector class
    """
    module = FakeAnsibleModule()
    assert isinstance(SunOSVirtualCollector(module), SunOSVirtualCollector)


# Test class SunOSVirtualCollector

# Generated at 2022-06-23 02:36:28.383203
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector('module')
    assert isinstance(vc, SunOSVirtualCollector)
    assert vc._platform == 'SunOS'


# Generated at 2022-06-23 02:36:30.946451
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test constructor of class SunOSVirtual with empty parameter
    test_virtual = SunOSVirtual(None)
    assert test_virtual != None

    # Test constructor of class SunOSVirtual with module parameter
    test_virtual = SunOSVirtual(None)
    assert test_virtual != None

# Generated at 2022-06-23 02:36:33.427430
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.__dict__ == {'module': {}}



# Generated at 2022-06-23 02:36:37.595844
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    f = SunOSVirtualCollector()
    assert f._platform == "SunOS"
    assert f._fact_class.platform == "SunOS"
    assert f._fact_class.__name__ == "SunOSVirtual"
    assert f._fact_class.__module__ == "ansible.module_utils.facts.virtual.sunos"

# Generated at 2022-06-23 02:36:38.933495
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc is not None

# Generated at 2022-06-23 02:36:41.410017
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    virtual_collector = SunOSVirtualCollector(module)
    assert virtual_collector.platform == "SunOS"

# Generated at 2022-06-23 02:36:46.361667
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:36:50.709972
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test output of SunOSVirtual.get_virtual_facts()
    virtual_facts = SunOSVirtual().get_virtual_facts()
    if virtual_facts:
        assert virtual_facts['virtualization_role'] == 'guest'
        assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:36:53.556249
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual


# Generated at 2022-06-23 02:36:56.710495
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    This unit test verifies that the SunOSVirtual class is initialised
    correctly.
    """
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    assert SunOSVirtual is not None

# Generated at 2022-06-23 02:36:59.412679
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:37:02.743078
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type == 'zone'
    assert virtual.virtualization_type == 'zone'
    assert virtual.virtualization_type == 'zone'

# Generated at 2022-06-23 02:37:06.230813
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = {}
    module = MockModule()
    v = SunOSVirtual(module)
    facts = v.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech' in facts


# Generated at 2022-06-23 02:37:15.095208
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    #################################
    # UnitTest for method SunOSVirtual.get_virtual_facts:
    #
    # 1. This is not a Zoned system
    # 2. This is a Zoned system without guest tools
    # 3. This is a Zoned system as non-global zone but with Solaris 8/9
    # 4. This is an LDoms system
    # 5. This is an Oracle VM system
    # 6. This is an VMware system
    # 7. This is a Parallels system
    # 8. This is a VirtualBox system
    # 9. This is a Xen system
    # 10. This is a KVM system
    # 11. This is a Virtuozzo system
    #################################

    class MockModule(object):
        def __init__(self, params):
            self._params = params


# Generated at 2022-06-23 02:37:17.624153
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:37:19.043956
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({}, {}, [None, None])
    assert True



# Generated at 2022-06-23 02:37:20.707748
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  assert isinstance(SunOSVirtualCollector(), VirtualCollector)

# Unit tests for method get_virtual_facts() of class SunOSVirtual

# Generated at 2022-06-23 02:37:23.281190
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict(module=dict()))
    assert sunos_virtual.__class__.__name__ == 'SunOSVirtual'


# Generated at 2022-06-23 02:37:32.345273
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize a mocked object of class SunOSVirtual
    sunos_virtual = SunOSVirtual(dict())

    # Mock some attributes
    sunos_virtual.module = dict()
    sunos_virtual.module['get_bin_path'] = lambda x: '/usr/sbin/zonename'
    sunos_virtual.module['run_command'] = lambda x: (0, "global", "")

    # Call get_virtual_facts()
    sunos_virtual_facts = sunos_virtual.get_virtual_facts()

    # Verify the result
    assert sunos_virtual_facts == dict(
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['zone']),
    )

# Generated at 2022-06-23 02:37:34.195565
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(module=dict()))
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:37:37.814921
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    print(x)
    assert x.platform == 'SunOS'
    assert x.collector == SunOSVirtual
    assert x.used_sys_module == False

# Generated at 2022-06-23 02:37:45.226323
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    SunOSVirtualCollector(module).collect()
    assert module.virtual_facts['virtualization_type'] == 'zone'
    assert module.virtual_facts['virtualization_role'] == 'none'
    assert module.virtual_facts['container'] == 'zone'
    assert module.virtual_facts['virtualization_tech_host'] == {'zone'}
    assert module.virtual_facts['virtualization_tech_guest'] == set()
    assert module.warn.called



# Generated at 2022-06-23 02:37:51.700169
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    facts_module = SunOSVirtualCollector(module=module)
    result = facts_module.collect()
    assert result is not None
    assert to_bytes('SunOS') in result['ansible_facts']['virtual']['platform']

# Generated at 2022-06-23 02:38:00.462983
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin')

    # test no virtualization
    SunOSVirtual(module).get_virtual_facts()
    module.get_bin_path.assert_has_calls([call('zonename'), call('modinfo'), call('virtinfo'), call('smbios')])
    module.run_command.assert_has_calls([call('/usr/bin/zonename'), call('/usr/bin/modinfo'), call('/usr/bin/virtinfo -p'), call('/usr/bin/smbios')])

    # test zone

# Generated at 2022-06-23 02:38:04.103563
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    SunOSVirtual(module)
    assert module.exit_args['msg'] == 'Could not find virtualization facts'


# Generated at 2022-06-23 02:38:15.026144
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # We should be able to detect containerized guests
    module1 = FakeAnsibleModule(container='zone')
    SunOSVirtualCollector(module1).collect()
    assert module1.virtual_facts['container'] == 'zone'
    assert module1.virtual_facts['virtualization_type'] == 'zone'
    assert module1.virtual_facts['virtualization_role'] == 'guest'
    assert 'zone' in module1.virtual_facts['virtualization_tech_guest']
    assert len(module1.virtual_facts['virtualization_tech_host']) == 0

    # We should be able to detect branded zones
    module2 = FakeAnsibleModule(container='zone')
    SunOSVirtualCollector(module2).collect()
    assert module2.virtual_facts['container'] == 'zone'

# Generated at 2022-06-23 02:38:16.575734
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert type(virtual_facts) == dict

# Generated at 2022-06-23 02:38:24.867432
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # test zone case
    module = FakeModule({
        'zonename': 'global'
    })
    virt = SunOSVirtual(module)
    facts = virt.get_virtual_facts()
    assert 'virtualization_role' not in facts
    assert 'virtualization_type' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert facts['virtualization_tech_host'] == {'zone'}
    assert 'container' not in facts

    module = FakeModule({
        'zonename': 'zone0'
    })
    virt = SunOSVirtual(module)
    facts = virt.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'zone'

# Generated at 2022-06-23 02:38:28.558226
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()

    # Instantiate SunOSVirtual
    obj = SunOSVirtual(module)

    # Check that the class's platform is set and corresponds to what we expect
    assert obj.platform == "SunOS"


# Generated at 2022-06-23 02:38:32.102593
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector(None, None, None).collect()

    for key in facts.keys():
        assert isinstance(facts[key], (str, bool, list))

# Generated at 2022-06-23 02:38:37.145382
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Make sure we get new instances of SunOSVirtualCollector to be able to mock multiple platforms
    '''
    os_virtual_collector = SunOSVirtualCollector()
    assert isinstance(os_virtual_collector, SunOSVirtualCollector)
    assert os_virtual_collector._platform == 'SunOS'


# Generated at 2022-06-23 02:38:38.333367
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:38:40.613233
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:38:42.529277
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:38:43.402072
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:46.576228
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:56.356272
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.virtual

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # This vaguely resembles a zone
    class mock_os(object):
        class Popen(object):
            def __init__(self, cmd, *args, **kwargs):
                self.returncode = 0
                self.cmd = cmd

            def communicate(self):
                if 'zonename' in self.cmd:
                    if 'global' in self.cmd:
                        return 'global', ''
                    return 'zonename', ''
                elif 'smbios' in self.cmd:
                    if 'VMware' in self.cmd:
                        return 'VMware', ''

# Generated at 2022-06-23 02:38:57.360675
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector

# Generated at 2022-06-23 02:38:59.163109
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == "SunOS"
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:39:09.585317
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ExecModule:
        def __init__(self, params={}):
            self.params = params

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return "/usr/bin/"+name

        def run_command(self, name, args, check_rc=True, close_fds=True, executable=None, data=None):
            out = err = ''
            rc = 0
            if name == "zonename":
                out = 'global'
            elif name == "modinfo":
                out = 'modinfo: could not get driver name from modctl\nfmod: VMware Virtual SATA HBA Driver'
                rc = 1

# Generated at 2022-06-23 02:39:11.941329
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v=SunOSVirtual({})
    assert v.virtualization == {}


# Generated at 2022-06-23 02:39:16.036470
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(None)
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:39:19.497356
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector()
    assert virtual_facts._fact_class == SunOSVirtual
    assert virtual_facts._platform == 'SunOS'


# Generated at 2022-06-23 02:39:20.526615
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert isinstance(SunOSVirtual(), Virtual)

# Generated at 2022-06-23 02:39:25.431317
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Create object for class SunOSVirtual
    sunosvirtual = SunOSVirtual()

    # Tests for attributes of class SunOSVirtual
    assert sunosvirtual.platform == 'SunOS'

    # Tests for methods of class SunOSVirtual
    assert 'container' in sunosvirtual.get_virtual_facts()

# Generated at 2022-06-23 02:39:27.475801
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    fact_subclass = SunOSVirtual('some_module')
    assert fact_subclass.platform == 'SunOS'

# Generated at 2022-06-23 02:39:29.492644
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = { 'kernel': 'SunOS' }
    SunOSVirtual(True, facts, None)

# Generated at 2022-06-23 02:39:39.401172
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import json
    import copy

    # Create a test instance
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.MagicMock(return_value=(0, json.dumps({"zone.max-swap": "536870912","zone.max-shm-memory": "536870912","zone.max-locked-memory": "536870912","zone.cpu-shares": "100","zone.cpu-cap": "100","zone.max-lwps": "2000","zone.max-msg-ids": "2000","zone.max-sem-ids": "2000","zone.max-shm-ids": "2000"}), ""))

    test = SunOSVirtual(module=module)

    # Test on a global zone
    facts_global_zone = test.get_virtual_facts()

# Generated at 2022-06-23 02:39:41.820785
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.facts['virtualization_type'] == 'SunOS'

# Generated at 2022-06-23 02:39:50.670867
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('Module', (object,), dict())
    module.run_command = lambda cmd: (0, '', '')
    module.get_bin_path = lambda cmd: cmd

    loader = type('Loader', (object,), dict())
    module.loader = loader
    module.params = dict()

    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:39:52.621979
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict(module=None)).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:40:00.350321
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector

    module = VirtualCollector()._create_module()
    SunOSVirtual._platform = 'SunOS'
    SunOSVirtual._module = module
    SunOSVirtual._params = {}
    SunOSVirtual._collect_platform_subset_facts = Virtual._collect_platform_subset_facts
    SunOSVirtual._parse_sysctl_info = Virtual._parse_sysctl_info
    SunOSVirtual._get_platform_subset_facts = Virtual._get_platform_subset_facts
    SunOSVirtual._get_dmi_info = Virtual._get_dmi_info
    SunOSVirtual._get

# Generated at 2022-06-23 02:40:14.314714
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (object,), {'get_bin_path': lambda *args: '/bin/zonename'})()
    command = type('', (object,), {'run_command': lambda *args, **kwargs: (0, 'global\n', '')})()
    module.run_command = command.run_command
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'

    # Set up command return value to test assumption
    command.run_command = lambda *args, **kwargs: (0, 'test\n', '')
    sunos_virtual = SunOSVirtual(module)

# Generated at 2022-06-23 02:40:21.618463
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Called from the constructor. The initialization of the module variable is done in the constructor.
    module = AnsibleModule(argument_spec={})
    obj = SunOSVirtual(module)
    # According to the documentation of AnsibleModule the object should provide an ansible_facts dictionary
    # with the desired entries.
    assert hasattr(obj, 'ansible_facts')
    assert isinstance(obj.ansible_facts, dict)
    assert hasattr(obj, 'ansible_module')
    assert isinstance(obj.ansible_module, AnsibleModule)

# Generated at 2022-06-23 02:40:25.193855
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Checks if SunOSVirtual serves the correct platform
    '''
    assert SunOSVirtual(dict()).platform == 'SunOS'


# Generated at 2022-06-23 02:40:28.269193
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Constructor of class SunOSVirtual should assign the correct
    # value to platform
    sunosvirtual = SunOSVirtual(None)
    assert sunosvirtual.platform == 'SunOS'



# Generated at 2022-06-23 02:40:31.514042
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Create object of class SunOSVirtual
    obj = SunOSVirtual()

    # Check if class attributes are properly set
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:40:40.350941
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''
    # The purpose of this test is to ensure that the output of a call to
    # SunOSVirtual.get_virtual_facts() has the existence of certain keys
    # as expected (i.e 'virtualization_type', 'virtualization_role').
    # This test does not aim to cover every possible output of
    # SunOSVirtual.get_virtual_facts() since this is platform-specific
    # and may be changed in the future.
    from ansible.module_utils.facts import Virtual, SunOSVirtual

    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert 'container' in virtual_facts.keys()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()

# Generated at 2022-06-23 02:40:48.841405
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Check SunOSVirtual.get_virtual_facts() with a zone.
    module = FakeModule(params={})
    class MySunOSVirtual(SunOSVirtual):
        def __init__(self, *args, **kwargs):
            SunOSVirtual.__init__(self, module)
        def get_file_content(self, path):
            return None
    virtual = MySunOSVirtual()
    virtual._run_command = lambda x: (0, 'non-global', '')
    virtual._get_file_content = lambda x: None
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'host' not in virtual

# Generated at 2022-06-23 02:40:51.805138
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module=module)
    assert virtual._module == module



# Generated at 2022-06-23 02:40:52.806131
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:57.096451
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:59.220253
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Ensure we return the right Virtual class
    """
    v = SunOSVirtualCollector()
    assert v._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:00.664960
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:41:02.984718
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:41:04.090099
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:41:11.009191
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mock_module = AnsibleModule(
        argument_spec=dict()
    )

    mock_module.get_bin_path = MagicMock(return_value='/usr/bin/false')

    # Test 1
    # Test for non-supported Solaris zone
    mock_module.run_command = MagicMock(side_effect=[(0, 'global\n', ''), (0, '', '')])

    virtual_facts = SunOSVirtual(mock_module).get_virtual_facts()
    assert virtual_facts == {}

    # Test 2
    # Test for Solaris 8/9 branded zone
    mock_module.run_command = MagicMock(side_effect=[(0, 'global\n', ''), (0, '', '')])

# Generated at 2022-06-23 02:41:13.297614
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._fact_class == SunOSVirtual
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 02:41:23.413604
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    os.environ['PATH'] = '/usr/sbin:/sbin:/usr/bin:/bin'
    module = MockModule()
    virt = SunOSVirtual(module)

    # Expected values for vmware
    facts = {}
    facts['virtualization_type'] = 'vmware'
    facts['virtualization_role'] = 'guest'
    facts['virtualization_tech_guest'] = set(['vmware'])
    facts['virtualization_tech_host'] = set()
    facts[''] = 'guest'


# Generated at 2022-06-23 02:41:29.719786
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    facts = SunOSVirtual(None)
    facts = facts.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'zone' in facts['virtualization_tech_host']
    assert facts['virtualization_tech_host'] == {'zone'}
    assert facts['virtualization_tech_guest'] == {'zone', 'xen'}

# Generated at 2022-06-23 02:41:30.890794
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:35.415943
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual(): # pylint: disable=R0903
    module = None
    virtual_facts = SunOSVirtual(module)
    assert virtual_facts.platform == "SunOS"

# Generated at 2022-06-23 02:41:45.065844
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    sunos = SunOSVirtual(module)

    v = sunos.get_virtual_facts()
    assert v['virtualization_type'] == 'parallels'
    assert v['virtualization_role'] == 'guest'
    assert v['virtualization_tech_host'] == set()
    assert v['virtualization_tech_guest'] == set('parallels')
    assert v['container'] == 'zone'

# Class for mocking Ansible module

# Generated at 2022-06-23 02:41:46.171593
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector().collect() == None

# Generated at 2022-06-23 02:41:50.041756
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert hasattr(collector, '_collect_platform')
    assert hasattr(collector, '_platform')
    assert hasattr(collector, '_fact_class')


# Generated at 2022-06-23 02:41:52.072411
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.platform == SunOSVirtual.platform


# Generated at 2022-06-23 02:42:00.623041
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_data = {
        '/usr/bin/zonename': "global\n",
        '/usr/sbin/modinfo': "id: misc/vmware 31 8 9\n",
        '/usr/sbin/virtinfo': "/usr/sbin/virtinfo: can't read 'domain.name'\n" + \
                              "DOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=false\n"
    }

    test_module_args = dict()

    test_SunOSVirtual = SunOSVirtual(test_module_args, test_data)
    test_virtual_facts = test_SunOSVirtual.get_virtual_facts()

    assert test_virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-23 02:42:01.987110
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()



# Generated at 2022-06-23 02:42:13.198782
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class TestModule(object):
        def get_bin_path(self, arg):
            return True

        def run_command(self, arg):
            rc = -1
            if arg == 'zonename':
                rc = 0
                out = 'global'
            elif arg == '/usr/sbin/virtinfo -p':
                rc = 0
                out = ''
            elif arg == 'modinfo':
                rc = 0

# Generated at 2022-06-23 02:42:14.981665
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = {}
    virtual = SunOSVirtual(facts, None)
    assert (virtual._platform == 'SunOS')

# Generated at 2022-06-23 02:42:20.101699
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert hasattr(collector, '_fact_class')
    assert hasattr(collector, '_platform')

# Unit test function for constructor of class SunOSVirtual

# Generated at 2022-06-23 02:42:32.186766
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import Virtual, SunOSVirtual, SunOSVirtualCollector
    import stat

    # Define all the functions and their return values, which get_*_facts() functions call
    def os_walk(a):
        return [("/",("",".zone",".SUNWnative"),("zonename","virtinfo","smbios"))]
    def os_stat(a):
        # Assume that all the files are executable
        return os.stat_result((stat.S_IFREG | 0o755, 10, 1, 0, 0, 0, 0, 0, 0, 0))
    def os_is_file(a):
        return True


# Generated at 2022-06-23 02:42:34.968593
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._fact_class == SunOSVirtual
    assert c._platform == 'SunOS'

# Generated at 2022-06-23 02:42:39.803874
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    context = {'ansible_facts':{'module_setup': True}}
    collector = SunOSVirtualCollector(context, None)
    assert collector.__class__.__name__ == 'SunOSVirtualCollector'
    assert  collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:42:41.270671
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, {}, {})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:42:43.489472
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock({})
    obj = SunOSVirtual(module)
    assert(obj.platform == 'SunOS')


# Generated at 2022-06-23 02:42:49.629031
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no parameters passed into the class
    test_collector = SunOSVirtualCollector()
    assert test_collector.platform == 'SunOS'
    assert test_collector.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:00.379709
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:43:02.596517
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Very simple assert that the method collects some data
    # TODO: The method's output probably need to be checked against the reality of the fact
    virtual = SunOSVirtual()
    assert len(virtual.get_virtual_facts())

# Generated at 2022-06-23 02:43:04.741032
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class is SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:43:07.011817
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector('fake_module', 'fake_env')
    assert x
    assert x.platform == 'SunOS'
    assert x.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:16.455494
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    import os
    import shutil
    import tempfile
    import collections

    # Create a temporary directory to create files in it
    tempdir = tempfile.mkdtemp()
    virtual_tempdir = os.path.join(tempdir, 'virtual')
    os.mkdir(virtual_tempdir)

    # Create a module for testing
    module = collections.namedtuple('AnsibleModule', ['get_bin_path', 'run_command'])

    # Create a function for retrieving a binary path

# Generated at 2022-06-23 02:43:22.348164
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    fake_module = type('AnsibleModule', (object,), {'run_command': lambda *a, **kw: (0, '', '')})
    fake_module.get_bin_path = lambda *a, **kw: ''
    facts = SunOSVirtual(fake_module).collect()
    assert 'Virtualization' in facts
    assert 'virtualization_type' in facts['Virtualization']
    assert 'virtualization_role' in facts['Virtualization']
    assert 'host' in facts['Virtualization']
    assert 'guest' in facts['Virtualization']
    assert 'container' in facts['Virtualization']

# Generated at 2022-06-23 02:43:24.446233
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:27.316438
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc is not None
    assert vc._fact_class is not None
    assert vc._platform is not None

# Generated at 2022-06-23 02:43:29.001820
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v1 = SunOSVirtualCollector()
    assert v1.facts == {}

# Generated at 2022-06-23 02:43:32.505322
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    os_obj = SunOSVirtual(module)
    assert isinstance(os_obj, SunOSVirtual)
    assert isinstance(os_obj.get_virtual_facts(), dict)


# Generated at 2022-06-23 02:43:33.935377
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v._platform == 'SunOS'

# Generated at 2022-06-23 02:43:36.015000
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
   vc = SunOSVirtualCollector()
   assert vc.platform == 'SunOS'
   assert vc.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:47.340313
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:43:50.204353
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt = SunOSVirtual({'module': None})

    # get_virtual_facts() returns a dictionary of virtualization details
    #  or an empty dict if no virtualization was detected
    assert isinstance(virt.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:43:58.462496
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    fake_module = type('', (), {'run_command': (lambda self, cmd, check_rc=True, close_fds=True:
                                                (0, '', '')),
                                'get_bin_path': (lambda self, name: '/usr/bin/' + name),
                                'params': {'gather_subset': [''], 'gather_timeout': 10}})()
    virt_facts = SunOSVirtual(fake_module)
    assert 'virtualization_type' in virt_facts.get_virtual_facts()
    assert 'virtualization_role' in virt_facts.get_virtual_facts()
    assert 'virtualization_tech_host' in virt_facts.get_virtual_facts()
    assert 'virtualization_tech_guest' in virt_facts.get_virtual_facts()

# Generated at 2022-06-23 02:44:09.198145
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()

    # No virtualization
    module.run_command.commands = [('smbios', '', 1), ('virtinfo -p', "", 1)]
    collector = SunOSVirtualCollector(module=module)
    facts = collector.collect()
    assert facts == {}

    # VirtualBox running on OpenIndiana oi_151a8 (SunOS)
    module.run_command.commands = [
        ('smbios', 'VirtualBox\n', 0),
        ('virtinfo -p', '', 0),
    ]
    collector = SunOSVirtualCollector(module=module)
    facts = collector.collect()
    assert facts['virtualization_role'] == 'guest'
   

# Generated at 2022-06-23 02:44:15.884135
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a fake module and an instance of SunOSVirtual
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    # Assert that fields of the instance are set to appropriate values
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts.__doc__ == \
        'Get virtualization facts for SunOS'



# Generated at 2022-06-23 02:44:17.784517
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    os.unsetenv('VMWARE_INSTALL_DIR')

# Generated at 2022-06-23 02:44:19.999803
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # The module dir doesn't exist on the controller
    virtual = SunOSVirtual({})
    assert virtual.get_virtual_facts()

# Generated at 2022-06-23 02:44:21.009622
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:44:33.066301
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Patch module.run_command to return desired values

# Generated at 2022-06-23 02:44:35.775346
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Test the constructor of class SunOSVirtual
    '''
    # Test with no options
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual is not None