

# Generated at 2022-06-23 02:34:46.599497
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import ModuleStub
    import os

    module = ModuleStub(dict(), dict(), dict(), dict(), os.devnull, dict())
    sunos_virtual = SunOSVirtual(module)

    facts = dict()
    facts['virtualization_role'] = 'guest'
    facts['virtualization_type'] = 'vmware'
    facts['virtualization_tech_guest'] = ['zone', 'vmware']
    facts['virtualization_tech_host'] = ['zone']
    facts['container'] = 'zone'
    assert facts == sunos_virtual.get_virtual_facts(), "error getting virtual facts: %s" % sunos_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:34:53.121735
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    module = FakeAnsibleModule()
    virtual_instance = SunOSVirtual(module)

    # Fake call to run_command
    rc, out, err = 0, '', None
    module.run_command.side_effect = [
        # Fake call of zonename command
        (rc, 'global', err),
        # Fake call of modinfo command
        (rc, '', err),
    ]
    # Fake call of get_bin_path

# Generated at 2022-06-23 02:34:54.640563
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual()
    assert isinstance(obj, SunOSVirtual)

# Generated at 2022-06-23 02:34:56.791826
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.get_virtual_facts() is None

# Generated at 2022-06-23 02:35:04.782172
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """This unit test is intended to verify that the constructor of the
    class SunOSVirtualCollector is working properly
    """
    from ansible.module_utils.facts import virtual
    import sys
    import os

    argv = sys.argv
    if os.name == 'java':
        # Jython does not support sys.argv[0]
        argv = ['virtual.py']

    virtual_collector = virtual.VirtualCollector(argv, os.name)
    assert isinstance(virtual_collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:35:13.208515
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Constructor call with the following parameters:
    # module_name=None, module_args=None, module_kwargs=None
    # The module_name is passed from the class VirtualCollector in the method
    # get_virtual_facts().
    # As the class SunOSVirtual doesn't have a constructor which
    # accepts values for module_name, module_args and module_kwargs, it should work.
    sunosvirtual = SunOSVirtual(module_name=None, module_args=None, module_kwargs=None)

    if not isinstance(sunosvirtual, SunOSVirtual):
        raise AssertionError

    # If a constructor is added which accepts values for module_name, module_args or
    # module_kwargs, the following tests may be useful.
    # module_name = 'TestModuleName'
    # module_

# Generated at 2022-06-23 02:35:16.691841
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual()
    assert sv.platform == 'SunOS'
    assert sv.virtualization_type == ''
    assert sv.virtualization_role == ''
    assert sv.container == ''

# Generated at 2022-06-23 02:35:21.866366
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    FakeModule = type('FakeModule', (object,), {})
    fake_module = FakeModule()
    fake_module.get_bin_path = lambda x: x
    virtual_facts = SunOSVirtualCollector(fake_module).collect()
    assert virtual_facts['virtualization_type'] == 'zone'

# Generated at 2022-06-23 02:35:29.356230
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    test_module = type('module', (), {})()
    test_module.get_bin_path = lambda x: x
    test_module.run_command = lambda x: (0, '', '')
    test_facts = SunOSVirtual(test_module)
    assert test_facts.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'container': 'zone',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-23 02:35:30.770860
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:35:38.577363
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # These are the facts we want as result
    virtual_facts = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set(['zone']),
        'container': 'zone'
    }
    # Create a SunOSVirtual object
    mySunOSVirtual = SunOSVirtual({}, {}, {})
    # Patch the get_bin_path function
    mySunOSVirtual.module.get_bin_path = lambda _: True
    # Patch the run_command function
    # Return code is 0
    def run_command(command):
        return (0, "global", "")
    mySunOSVirtual.module.run_command = run_command

    # Assert the result


# Generated at 2022-06-23 02:35:46.117090
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = MockModule()
    module_mock.run_command = Mock(return_value=(0, 'global', 'err'))
    module_mock.get_bin_path = Mock(return_value='/usr/bin/zonename')
    sunos_virtual = SunOSVirtual(module_mock)
    assert sunos_virtual.get_virtual_facts()['virtualization_tech_host'] == set(['zone'])
    assert 'virtualization_tech_guest' not in sunos_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:35:48.368797
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:35:49.315009
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual

# Generated at 2022-06-23 02:35:51.210522
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    collector = SunOSVirtualCollector
    facts = collector()
    assert type(facts) == SunOSVirtualCollector
    assert facts._platform == 'SunOS'

# Generated at 2022-06-23 02:35:55.304952
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    sc = SunOSVirtualCollector(None, None)
    assert sc.platform == 'SunOS'

# Generated at 2022-06-23 02:35:58.845322
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Execute constructor of the class to be tested
    sunos_virtual = SunOSVirtual(None)

    # Assert that the attributes are initialised correctly
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:36:03.127425
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    from ansible.module_utils.facts import sunos_virtual

    vc = sunos_virtual.SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc._fact_class == sunos_virtual.SunOSVirtual


# Generated at 2022-06-23 02:36:07.838481
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    virtual = SunOSVirtualCollector(module).collect()['ansible_facts']['ansible_virtualization_facts']
    assert 'virtualization_type' in virtual
    assert 'virtualization_role' in virtual
    assert 'virtualization_tech_guest' in virtual
    assert 'virtualization_tech_host' in virtual


# Generated at 2022-06-23 02:36:10.578504
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    virtual = SunOSVirtual(module)

    assert virtual.platform == 'SunOS'
    assert virtual.module == module


# Generated at 2022-06-23 02:36:14.776130
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = VirtualCollector._create_mock_module()
    plugin = SunOSVirtual(module=module)

    assert plugin.platform == 'SunOS'
    assert plugin._platform == 'SunOS'
    assert isinstance(plugin, SunOSVirtual)
    assert isinstance(plugin, Virtual)
    assert not hasattr(plugin, 'distribution')


# Generated at 2022-06-23 02:36:17.032513
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual()
    assert not obj.get_virtual_facts()

# Generated at 2022-06-23 02:36:19.195498
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj


# Generated at 2022-06-23 02:36:22.634275
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = dict()
    SunOSVirtualCollector(os_facts)

    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:36:31.925271
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module_exec = VirtualCollector.module_exec
    module_exec['get_bin_path'] = lambda self, arg: '/usr/bin/' + arg
    module_exec['run_command'] = lambda self, args: (0, '', '')
    facts = SunOSVirtual(module_exec).get_virtual_facts()
    assert facts is not None
    assert type(facts) == dict
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:36:34.622824
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual


# Generated at 2022-06-23 02:36:43.134664
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import FactCollector
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {'gather_subset': "!all,virtual"}
            super(MockAnsibleModule, self).__init__(*args, **kwargs)

    class MockFactCollector(FactCollector):
        def __init__(self, *args, **kwargs):
            super(MockFactCollector, self).__init__(*args, **kwargs)
            self.collector = [SunOSVirtual]
            self.collector

# Generated at 2022-06-23 02:36:44.622353
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.system == 'SunOS'

# Generated at 2022-06-23 02:36:47.990102
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == "SunOS"
    assert obj._fact_class == SunOSVirtual
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 02:36:50.502645
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual({}, None)
    assert sv.name == 'virtual'
    assert sv.all_commands == ['/usr/sbin/virtinfo', '/usr/sbin/zoneadm', '/usr/sbin/zonename', 'smbios']
    assert sv.platform == 'SunOS'
    assert sv.required_facts == set()

# Generated at 2022-06-23 02:36:53.752039
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(
        argument_spec=dict()
    )
    virtual_platform = SunOSVirtual(module)
    assert virtual_platform.platform == 'SunOS'


# Generated at 2022-06-23 02:37:00.032580
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})
    v.module.run_command = lambda x: (0, '', '')
    v.module.get_bin_path = lambda x: None
    v.module.exit_json = lambda x: None
    v.get_virtual_facts()
    assert v.virtual_facts == {
        'virtualization_type': None,
        'virtualization_role': None,
        'container': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:37:01.037770
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})

# Generated at 2022-06-23 02:37:10.336357
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils import basic
    from ansible.module_utils.facts import timeout
    from ansible.module_utils._text import to_bytes

    class MockModule(basic.AnsibleModule):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if cmd == 'dminfo':
                return (0, b'', b'')
            return (0, to_bytes('Fake output'), to_bytes('Fake error'))


# Generated at 2022-06-23 02:37:22.148461
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # initialize a 'Module' object for unit testing
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # initialize SunOSVirtual object
    virtual = SunOSVirtual(module)

    # test on sun4v
    virtual._module.run_command = run_command_solaris_sparc_kvm
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set()}

    # test on sun4u
    virtual._module.run_command = run_command_solaris_x86_vbox
    virtual_facts = virtual.get_

# Generated at 2022-06-23 02:37:25.177312
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual({})
    facts = m.get_virtual_facts()

    # We would like to test different virtualization types (and their
    # related facts) here, but we need to find out how to simulate
    # different virtualization technologies on a single machine
    # without resorting to nested virtualization.

# Generated at 2022-06-23 02:37:34.834726
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule({})
    # Test an unvirtualized machine
    virtual_facts = SunOSVirtual({}, module).get_virtual_facts()
    assert virtual_facts == {}
    # Test a VMware-guest
    os.environ['PATH'] = os.environ['PATH'] + (':' if os.environ['PATH'] else '') + ':../../../test/data/sunos'  # pylint: disable=environment-marker
    virtual_facts = SunOSVirtual({}, module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_role'] == 'guest'
    # Test a zone

# Generated at 2022-06-23 02:37:36.991393
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    s = SunOSVirtualCollector()
    assert isinstance(s, SunOSVirtualCollector)


# Generated at 2022-06-23 02:37:39.037195
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virtual = SunOSVirtual(module=module)

    assert virtual
    assert virtual.module == module

# Generated at 2022-06-23 02:37:49.941452
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Tests the get_virtual_facts method of the SunOSVirtual.
    """
    # Sample output from the smbios command

# Generated at 2022-06-23 02:37:57.399219
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/usr/sbin/virtinfo')
    module.run_command = MagicMock(return_value=(0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=true", ""))
    collect_data = {'module': module}
    sunos_virtual_collector = SunOSVirtual(collect_data)
    result = sunos_virtual_collector.get_virtual_facts()
    assert result['virtualization_role'] == 'host (root)'

# Generated at 2022-06-23 02:38:03.529049
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    os.environ['PATH'] = '/usr/bin:/usr/sbin'
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'].pop() == 'zone'
    assert virtual_facts['virtualization_tech_host'].pop() == 'zone'



# Generated at 2022-06-23 02:38:15.723032
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command
    virtual = SunOSVirtual(module)

    # In a zone
    os.path.isdir = lambda s: True
    virtual_facts = virtual.get_virtual_facts()
    assert 'container' in virtual_facts
    assert virtual_facts['container'] == 'zone'
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'zone' in virtual_facts['virtualization_tech_guest']

    # In a dom0

# Generated at 2022-06-23 02:38:27.526531
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:38:36.869104
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'
    assert 'vmware' not in virt.virtual_facts.get('virtualization_tech_guest', set())
    assert 'zone' not in virt.virtual_facts.get('virtualization_tech_guest', set())
    assert virt.virtual_facts.get('container') is None
    assert virt.virtual_facts.get('virtualization_type') is None
    assert virt.virtual_facts.get('virtualization_role') is None

# Generated at 2022-06-23 02:38:41.086051
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Check if the constructor of SunOSVirtualCollector raises the appropriate exceptions
    """
    virtual_collector_object = SunOSVirtualCollector()
    assert isinstance(virtual_collector_object,SunOSVirtualCollector)

# Generated at 2022-06-23 02:38:42.960693
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.module == module

# Generated at 2022-06-23 02:38:47.470332
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:38:52.423543
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_dict = dict()
    collector = SunOSVirtualCollector(facts_dict)
    assert collector.platform == 'SunOS', 'Platform name is incorrect'
    assert collector._fact_class == SunOSVirtual, 'The class being used to get the facts is incorrect'
    assert collector._facts_dict == facts_dict, 'Facts dictionary is incorrect'

# Generated at 2022-06-23 02:39:03.620089
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    collector.collector._instance = SunOSVirtual(module)
    result = collector.collector._instance.get_virtual_facts()
    assert type(result) is dict
    assert 'container' in result
    assert type(result['container']) is str
    assert 'virtualization_type' in result
    assert type(result['virtualization_type']) is str
    assert 'virtualization_role' in result
    assert type(result['virtualization_role']) is str
    assert 'virtualization_tech_guest' in result
    assert type(result['virtualization_tech_guest']) is set


# Generated at 2022-06-23 02:39:05.319368
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual._platform == 'SunOS'


# Generated at 2022-06-23 02:39:08.625081
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''This test makes sure that the constructor of SunOSVirtualCollector works correctly'''
    os_virtual_col = SunOSVirtualCollector()
    assert os_virtual_col._fact_class == SunOSVirtual
    assert os_virtual_col._platform == 'SunOS'



# Generated at 2022-06-23 02:39:10.945085
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:11.517585
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual({}).platform == 'SunOS'

# Generated at 2022-06-23 02:39:16.915485
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    sunos_virtual = SunOSVirtual(module)

    assert sunos_virtual.platform == 'SunOS'



# Generated at 2022-06-23 02:39:18.437781
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:39:21.032962
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None

# Generated at 2022-06-23 02:39:26.059909
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert isinstance(facts, SunOSVirtualCollector)
    assert isinstance(facts.platform, str)
    assert isinstance(facts.virtual, SunOSVirtual)
    assert isinstance(facts._platform, str)
    assert isinstance(facts._fact_class, object)

# Generated at 2022-06-23 02:39:31.579688
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual()
    facts = {
        'virtualization_type': 'kvm',
        'virtualization_type_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['zone']),
        'container': 'zone'}
    assert facts == v.get_virtual_facts()

# Generated at 2022-06-23 02:39:33.433269
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'



# Generated at 2022-06-23 02:39:35.354455
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert isinstance(collector._fact_class, SunOSVirtual)
    assert collector._platform == "SunOS"

# Generated at 2022-06-23 02:39:43.359509
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    fake_module = type('module', (object,), dict(params=dict(), get_bin_path=lambda _: None))()
    fake_module.run_command = lambda _: (0, '', '')
    fake_module.exit_json = lambda a: a
    fake_module.fail_json = lambda a: a

    a = SunOSVirtual(fake_module)
    assert a.platform == 'SunOS'


# Generated at 2022-06-23 02:39:52.570261
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test constructor of class SunOSVirtualCollector. It's a unit test.
    """
    # Input parameters and expected result.
    platform = 'SunOS'
    fact_class = SunOSVirtual
    expected_platform = 'SunOS'
    expected_fact_class = SunOSVirtual

    # Act
    sunos_virtual_collector = SunOSVirtualCollector()

    # Assert
    assert sunos_virtual_collector._platform == expected_platform
    assert sunos_virtual_collector._fact_class == expected_fact_class


# Generated at 2022-06-23 02:39:54.241023
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create instance of class SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:58.313250
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class is not None
    assert virtual_collector._platform is not None

# Generated at 2022-06-23 02:40:00.408993
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert hasattr(virtual_collector, '_fact_class')

# Generated at 2022-06-23 02:40:11.739407
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fact_dummy_class = type('', (), {})
    fact_dummy_class.platform = 'SunOS'

    # dummy module object
    module_ = type('', (), {})()
    module_.exit_json = lambda **args: None
    module_.fail_json = lambda **args: None
    module_.get_bin_path = lambda s: s
    module_.run_command = lambda *args: (0, '', '')

    c = SunOSVirtualCollector(module=module_)
    assert c.platform == 'SunOS'

# Generated at 2022-06-23 02:40:13.718837
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'

# Generated at 2022-06-23 02:40:17.807008
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    # If not called with a SunOS-based platform (darwin)
    # the constructor should raise a NotImplementedError
    if 'SunOS' not in sys.platform:
        try:
            SunOSVirtualCollector()
        except NotImplementedError:
           pass
        else:
           raise AssertionError("SunOSVirtualCollector constructor: NotImplementedError not raised")

# Generated at 2022-06-23 02:40:24.906319
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    module = ModuleStub()

    collector = VirtualCollector(module)
    fact_class = SunOSVirtual(collector)

    # just a random example
    module.run_command = lambda x: (0, "VirtualBox", "")

    fact_class.get_virtual_facts()

    assert 'virtualization_type' in fact_class.facts
    assert 'virtualization_role' in fact_class.facts
    assert 'container' in fact_class.facts



# Generated at 2022-06-23 02:40:33.567844
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mod = VirtualCollector()

    mod.module.run_command = lambda *args, **kwargs: (0, '', '')
    mod.module.get_bin_path = lambda *args, **kwargs: None

    assert not SunOSVirtual(mod).get_virtual_facts()

    mod.module.run_command = lambda *args, **kwargs: (0, 'solaris', '')
    mod.module.get_bin_path = lambda *args, **kwargs: 'zonename'

    assert not SunOSVirtual(mod).get_virtual_facts()

    mod.module.run_command = lambda *args, **kwargs: (0, 'global', '')
    mod.module.get_bin_path = lambda *args, **kwargs: 'zonename'

# Generated at 2022-06-23 02:40:35.993055
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc.fact_class == 'SunOSVirtual'

# Generated at 2022-06-23 02:40:40.324194
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'
    assert x.virtualization_type == 'unknown'
    assert x.virtualization_role == 'unknown'
    assert x.container == 'unknown'

# Generated at 2022-06-23 02:40:47.003187
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import Collector

    module = AnsibleModuleMock()
    collector = SunOSVirtualCollector(module=module)
    assert collector.module == module
    assert isinstance(collector.fact_class, SunOSVirtual) is True
    assert collector.fact_class.platform == 'SunOS'
    # Test that Collector.collect() is inherited by SunOSVirtualCollector
    assert callable(collector.collect) is True

# Generated at 2022-06-23 02:40:56.037694
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Return a valid collection of virtual_facts for a virtual machine,
    or an empty dict for a bare metal host.
    '''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json
            self.tmpdir = '/tmp'

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            '''find the first executable in PATH'''
            print("arg", arg)
            print("required", required)
            print("opt_dirs", opt_dirs)

# Generated at 2022-06-23 02:40:57.674064
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector(None)
    assert collector.platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:40:59.349601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:41:02.279699
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    virtual_collector = SunOSVirtualCollector(facts)
    assert virtual_collector._fact_class == SunOSVirtual
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:41:04.024547
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert isinstance(instance, SunOSVirtualCollector)


# Generated at 2022-06-23 02:41:05.694662
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    collector = SunOSVirtualCollector(facts, None)
    assert collector.platform == 'SunOS'
    assert collector.fact_class

# Generated at 2022-06-23 02:41:08.633436
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS', "platform should be 'SunOS'"
    assert c.fact_class == SunOSVirtual, "fact_class should be SunOSVirtual"

# Generated at 2022-06-23 02:41:12.897540
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    res = SunOSVirtual(module)
    assert res.platform == 'SunOS'
    assert module.get_bin_path.call_count == 1


# Generated at 2022-06-23 02:41:16.476789
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    solv = SunOSVirtual()
    assert solv.data['virtualization_type'] == 'virtualbox'
    assert solv.data['virtualization_role'] == 'guest'
    assert solv.data['container'] == 'zone'


# Generated at 2022-06-23 02:41:26.778215
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class SunOSVirtual
    '''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    # Create a dummy module
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    # Create a dummy module
    SunOSVirtual._module = module

    # Create a dummy module
    SunOSVirtual._module = module
    SunOSVirtual._module.get_bin_path = _mock_module_run_command

    # SunOS is running natively

# Generated at 2022-06-23 02:41:28.396788
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict())
    assert virt.platform == "SunOS"

# Generated at 2022-06-23 02:41:31.083431
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {}


# Generated at 2022-06-23 02:41:33.774755
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({}, {})


# Generated at 2022-06-23 02:41:42.286376
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    module = None

    # Create an instance of class SunOSVirtual
    sunos_virtual = SunOSVirtual(module)

    # /usr/sbin/smbios is missing
    sunos_virtual.module.get_bin_path = lambda x: None
    result = sunos_virtual.get_virtual_facts()
    assert result == {}

    # virtinfo does not return with success
    def get_bin_path_side_effect(path):
        if path == 'smbios':
            return 'smbios'
        else:
            return None

    sunos_virtual.module.get_bin_path = lambda x: 'virtinfo'

# Generated at 2022-06-23 02:41:52.381621
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    testmodule = '''
'''
    test = type('ModuleTest', (object,), {})()
    test.params = {}
    test.run_command = lambda *args, **kwargs: ('0', '', '')
    test.get_bin_path = lambda *args, **kwargs: '/usr/bin/zonename'
    test.exit_json = lambda *args: None
    test.fail_json = lambda *args: None
    test.ansible = type('AnsibleModuleStub', (object,), {})()
    test.ansible.module_utils = type('ModuleUtilsStub', (object,), {})()
    test.ansible.module_utils.basic = type('BasicStub', (object,), {})()
    test.ansible.module_utils.basic.AnsibleModule

# Generated at 2022-06-23 02:41:54.804768
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    myfacts = SunOSVirtualCollector({})
    assert myfacts.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-23 02:42:07.008897
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command
    facts = SunOSVirtual(module).get_virtual_facts()

    # Check that zones are properly detected
    assert (facts['container'] == 'zone')

    # Check that global zones are properly detected
    assert ('zone' in facts['virtualization_tech_host'])

    # Check that branded zones are properly detected
    assert ('zone' in facts['virtualization_tech_guest'])

    # Check that virtualized zones are properly detected
    assert (facts['virtualization_role'] == 'guest')

    # Check that physical hosts are properly detected
    assert (not 'virtualization_tech_host' in facts)
    assert (not 'virtualization_tech_guest' in facts)


# Unit test helper methods

# Generated at 2022-06-23 02:42:09.654756
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj_collector = SunOSVirtualCollector()
    assert obj_collector.get_virtual_facts() == {}
    assert obj_collector.collect() == {}

# Generated at 2022-06-23 02:42:12.562598
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}

    # Should return an instance of SunOSVirtualCollector
    assert isinstance(SunOSVirtualCollector(facts, None), SunOSVirtualCollector)


# Generated at 2022-06-23 02:42:16.015128
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v._platform == 'SunOS'
    assert v._fact_class is SunOSVirtual
    assert v._fact_class.platform == 'SunOS'



# Generated at 2022-06-23 02:42:19.113162
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    sunos_virtual = SunOSVirtual({})

    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:42:21.234961
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class is SunOSVirtual
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 02:42:34.113418
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'vmware'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_host'] = set(['zone'])
    virtual_facts['virtualization_tech_guest'] = set(['zone', 'vmware'])
    virtual_facts['container'] = 'zone'
    v = SunOSVirtual(module=None)
    v.facts = virtual_facts
    assert v.virtualization_type == 'vmware'
    assert v.virtualization_role == 'guest'
    assert v.virtualization_tech_host == set(['zone'])
    assert v.virtualization_tech_guest == set(['zone', 'vmware'])
    assert v.container == 'zone'

# Unit

# Generated at 2022-06-23 02:42:37.018432
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    virt = SunOSVirtualCollector(module)
    assert isinstance(virt, SunOSVirtualCollector)
    assert virt.platform == 'SunOS'

# Generated at 2022-06-23 02:42:44.832651
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a minimal module
    params = dict(
        ansible_facts={},
        ansible_cmdline={},
        ansible_version={},
        ansible_env={},
    )
    module = AnsibleModule(params=params)

    # Create a SunOS Virtual object
    virtual = SunOSVirtual(module)

    # Create virtual facts
    virtual_facts = virtual.get_virtual_facts()

    # Assert the virtual facts dict is not empty
    assert virtual_facts is not None
    assert len(virtual_facts) > 0

    # Assert some expected keys
    expected_keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
        'container',
        ]

# Generated at 2022-06-23 02:42:52.345721
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test the constructor of SunOSVirtualCollector
    # Note, we are only testing the constructor and nothing else.  The rest
    # of the tests will be done in test_virtual.py.
    #
    # This test covers:
    #       - Tests the class is assigned correctly

    # Create the object
    sunos_virtual_collector = SunOSVirtualCollector()

    assert sunos_virtual_collector._platform == "SunOS"
    assert sunos_virtual_collector._fact_class.platform == "SunOS"
    assert sunos_virtual_collector.platform == "SunOS"

# Generated at 2022-06-23 02:42:53.665626
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    col = SunOSVirtualCollector()
    assert col is not None

# Generated at 2022-06-23 02:42:56.202803
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.collect() == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:42:58.590714
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    sut = SunOSVirtual(module)
    assert sut.platform == 'SunOS'


# Generated at 2022-06-23 02:43:10.157251
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()

    # Construct an instance of SunOSVirtual object
    sunos_virtual = SunOSVirtual({}, module)

    assert sunos_virtual.platform == 'SunOS'

    # Check for get_virtual_facts function
    assert sunos_virtual.get_virtual_facts() == None

    # Check for get_virtual_facts function when we have a valid zonename from non-global zone
    module.run_command = MagicMock(return_value=(0, "kzone\n", ""))
    assert sunos_virtual.get_virtual_facts() == {'container': 'zone', 'virtualization_type': 'zone', 'virtualization_role': 'guest',
                                                 'virtualization_tech_host': set([]), 'virtualization_tech_guest': {'zone'}}

    # Check for get

# Generated at 2022-06-23 02:43:12.653482
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector.collect()
    assert virtual_facts['virtualization_type'] == "zone"
    assert virtual_facts['virtualization_role'] == "guest"

# Generated at 2022-06-23 02:43:19.372875
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    # Change these values to match the output of # /usr/sbin/smbios -t SMB_TYPE_SYSTEM
    module.exit_json.return_value = {'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': ['zone']}
    assert virtual.get_virtual_facts() == {'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': ['zone']}

# Generated at 2022-06-23 02:43:22.048114
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == "SunOS"
    assert collector._fact_class.platform == "SunOS"

# Generated at 2022-06-23 02:43:32.744716
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # create a test_SunOSVirtual object
    test_SunOSVirtual_obj = SunOSVirtual({})

    # check the result of get_virtual_facts()
    assert isinstance(test_SunOSVirtual_obj.get_virtual_facts()['virtualization_tech_guest'], set)
    assert isinstance(test_SunOSVirtual_obj.get_virtual_facts()['virtualization_tech_host'], set)
    assert isinstance(test_SunOSVirtual_obj.get_virtual_facts()['virtualization_type'], str) or test_SunOSVirtual_obj.get_virtual_facts()['virtualization_type'] is None

# Generated at 2022-06-23 02:43:34.037533
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()

# Generated at 2022-06-23 02:43:35.427208
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({}, {})
    assert obj is not None


# Generated at 2022-06-23 02:43:39.393612
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    isinstance(SunOSVirtual(module), SunOSVirtual)

# Generated at 2022-06-23 02:43:45.974654
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['virtualbox'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert 'container' in virtual_facts


# Generated at 2022-06-23 02:43:48.203921
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:43:50.956558
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({})
    #assert s.virtualization_type == ''
    #assert s.virtualization_role == ''
    #assert s.virtualization_system == ''

# Generated at 2022-06-23 02:43:58.888418
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # This is just a sample, we don't actually test behavior of get_virtual_facts() here
    sunosvirtual = SunOSVirtual({})
    virtual_facts = sunosvirtual.get_virtual_facts()

# Generated at 2022-06-23 02:44:02.155505
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = {'kernel_name': 'SunOS'}
    virtual = SunOSVirtual(module=None, facts=facts)
    assert virtual
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:44:06.986839
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Return an instance of SunOSVirtualCollector
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    # Return an instance of VirtualCollector
    x = VirtualCollector()
    assert isinstance(x, VirtualCollector)

# Generated at 2022-06-23 02:44:08.442292
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:44:18.056750
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of class SunOSVirtual
    test_instance = SunOSVirtual()
    # Set the module variable of test_instance
    test_instance.module = AnsibleModule(argument_spec={})
    # Set the module.run_command variable
    test_instance.module.run_command = lambda x: (0, "", "")

    # Test 1: Container is zone
    test_instance.module.run_command = lambda x: (0, "foo", "")
    test_instance.container = lambda: True
    out = test_instance.get_virtual_facts()
    assert "zone" in out['container']
    assert out['virtualization_role'] == 'guest'
    assert out['virtualization_type'] is None
    assert 'zone' in out['virtualization_tech_guest']
    assert 'zone'

# Generated at 2022-06-23 02:44:21.420835
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert 'container' in sunos_virtual.data

# Generated at 2022-06-23 02:44:27.671495
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0)
    module.get_bin_path = FakeGetBinPath(fake_zonename="/usr/bin/zonename")
    v = SunOSVirtual(module=module)
    vf = v.get_virtual_facts()


# Generated at 2022-06-23 02:44:38.000231
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import json
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create a new instance of SunOSVirtual
    sunos_virtual = SunOSVirtual()

    # Check if the class is derived from the base class
    assert issubclass(sunos_virtual.__class__, SunOSVirtual)
    assert issubclass(sunos_virtual.__class__, Virtual)

    # Check if the specific member variables are set
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_type == 'Unknown'

    # Check if virtualization_type is set correctly
    virtual_facts = sunos_virtual.get_virtual_facts()