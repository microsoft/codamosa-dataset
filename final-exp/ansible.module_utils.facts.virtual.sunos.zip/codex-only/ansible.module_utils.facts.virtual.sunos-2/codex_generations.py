

# Generated at 2022-06-23 02:34:37.664322
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:34:40.408254
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._fact_class == SunOSVirtual
    assert v._platform == 'SunOS'

# Generated at 2022-06-23 02:34:52.743379
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = {}
    class FakeModule:
        def __init__(self, module):
            self.module = module
            self.run_command_returns = [(0, 'global', ''),
                                        (0, 'VMware', ''),
                                        (0, '', '')]
            self.run_command_counter = 0
            self.get_bin_path_returns = ['/usr/sbin/zonename',
                                         '/usr/sbin/modinfo',
                                         '/usr/sbin/virtinfo']
            self.get_bin_path_counter = 0

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')


# Generated at 2022-06-23 02:35:01.324670
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # SunOSVirtualCollector should not print out anything when called on non-SunOS platforms
    # To test this, I will create a mock module object, which has a valid method get_bin_path(),
    # and plug in an invalid value for _platform, so that the call to SunOSVirtualCollector()
    # should just print out a warning and return an empty array
    class MockModule():
        def get_bin_path(self, path):
            return path

    module = MockModule()
    module._platform = 'NotSunOS'

    # Run the test code
    virtual_facts_list = SunOSVirtualCollector.collect(module)
    if virtual_facts_list:
        assert False

# Generated at 2022-06-23 02:35:08.098495
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({}, {})
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.virtualization_role_host is None
    assert virtual.virtualization_role_guest is None
    assert virtual.virtualization_subtype is None
    assert virtual.vmware_subtype is None
    assert virtual.hyperv_subtype is None
    assert virtual.kvm_subtype is None
    assert not virtual.container

# Generated at 2022-06-23 02:35:11.482833
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(module=None, facts={})
    assert virtual.facts['virtualization_type'] == 'zone'
    assert virtual.facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:35:22.369612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    class MockModule(object):
        def __init__(self, name, bin_path=None, run_command_environ_update=dict()):
            self.name = name
            self.bin_path = bin_path
            self.run_command_environ_update = run_command_environ_update

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return self.bin_path

        def run_command(self, args, check_rc=True):
            if args == 'virtinfo -p':
                return (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', '')

# Generated at 2022-06-23 02:35:23.784034
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert instance.collect() is not None

# Generated at 2022-06-23 02:35:25.039936
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    f = SunOSVirtual({}, None)
    assert f.platform == 'SunOS'

# Generated at 2022-06-23 02:35:28.448122
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:35:36.056686
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    with open(os.path.join(os.path.dirname(__file__), 'unit/fixtures/smbios.out'), 'r') as f:
        smbios = f.read()
    with open(os.path.join(os.path.dirname(__file__), 'unit/fixtures/modinfo.out'), 'r') as f:
        modinfo = f.read()

    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.return_value = '/usr/sbin/zonename'
    module.is_directory.return_value = False

    # First test a global zone
    v = SunOSVirtual(module)
    virtual_facts = v.get_virtual_facts()
    assert virtual

# Generated at 2022-06-23 02:35:47.853322
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    MOCK_MODULES = {
        'platform': 'MockPlatform'
    }
    MOCK_GET_BIN_PATH = {
        'zonename': '/usr/sbin/zonename',
        'modinfo': '/usr/sbin/modinfo',
        'virtinfo': '/usr/sbin/virtinfo',
        'smbios': '/usr/sbin/smbios'
    }

# Generated at 2022-06-23 02:35:54.600684
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import FactManager

    SunOSVirtualFactManager = FactManager(SunOSVirtualCollector, 'SunOS')
    SunOSVirtualFactManager.populate()

    virtual_facts = SunOSVirtualFactManager.facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:35:55.508667
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    t = SunOSVirtualCollector()


# Generated at 2022-06-23 02:36:00.581782
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'kvm'},
    }
    test_SunOSVirtual = SunOSVirtual(dict())
    result = test_SunOSVirtual.get_virtual_facts()
    assert result == expected

# Generated at 2022-06-23 02:36:06.635948
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in facts, "Failed to get virtualization type"
    assert 'virtualization_role' in facts, "Failed to get virtualization role"


# Generated at 2022-06-23 02:36:07.881277
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)



# Generated at 2022-06-23 02:36:09.357671
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # SunOSVirtual(module)
    # Tested above
    pass

# Generated at 2022-06-23 02:36:16.937674
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec=dict())
    grep_mock = MagicMock()
    grep_mock.findall.return_value = []

# Generated at 2022-06-23 02:36:18.363918
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector

# Generated at 2022-06-23 02:36:23.699135
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector(None)
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector.platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:32.367335
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={
            'filter': {
                'required': False,
                'choices': ['*'],
            },
        },
    )
    SunOSVirtual(module=module).get_virtual_facts()


# AnsibleModule boilerplate

# Generated at 2022-06-23 02:36:34.015200
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:36:37.845095
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mySunOSVirtual = SunOSVirtual({})
    assert mySunOSVirtual.platform == 'SunOS'
    assert mySunOSVirtual.virtualization_type is None
    assert mySunOSVirtual.virtualization_role is None
    assert mySunOSVirtual.container is None

# Generated at 2022-06-23 02:36:40.582991
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts.get_virtual_facts() == {'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}



# Generated at 2022-06-23 02:36:42.895453
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts() is not None

# Generated at 2022-06-23 02:36:44.974742
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Constructor of SunOSVirtualCollector"""
    obj = SunOSVirtualCollector()
    assert isinstance(obj, SunOSVirtualCollector)
    # Above should not raise any exception

# Generated at 2022-06-23 02:36:47.223919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test invocation of class (should always pass)
    SunOSVirtual()


# Generated at 2022-06-23 02:36:50.438448
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos.sunos import SunOSVirtual
    sunos_virtual = SunOSVirtual()
    facts_dict = sunos_virtual.get_virtual_facts()
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-23 02:37:00.520165
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    v = SunOSVirtual(module)
    v.module.run_command = run_command
    v.module.get_bin_path = get_bin_path
    # Test 1: Zone
    v.module.run_command.results = [0, "global", ""]
    assert v.get_virtual_facts() == {
        'container': None,
        'virtualization_role': None,
        'virtualization_type': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    # Test 2: Global zone
    v.module.run_command.results = [0, "zone_name", ""]

# Generated at 2022-06-23 02:37:02.308566
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ unit test for constructor of class SunOSVirtual """

    # Create an instance of `SunOSVirtual`
    SunOSVirtual()

# Generated at 2022-06-23 02:37:03.659469
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert isinstance(collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:37:14.148464
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyModule()

    real_get_bin_path = module.get_bin_path
    module.get_bin_path = lambda arg: arg
    process_utils_execute_return_values = dict()

    def mocked_process_utils_execute(cmd, *args, **kwargs):
        if cmd == zonename:
            process_utils_execute_return_values["zonename"] = (0, "global", "")

        if cmd == modinfo:
            process_utils_execute_return_values["modinfo"] = (0,
                "83       1 0xc4000000 1176484   vmmon  (VMware Virtual Machine Monitor) INACTIVE\n"
                "1        0 0xc2000000  157512   random (Entropy device driver)", "")

        if cmd == smbios:
            process_

# Generated at 2022-06-23 02:37:21.106965
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_type'] == 'baremetal'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'container' not in virtual_facts

# Generated at 2022-06-23 02:37:31.505671
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector


# Generated at 2022-06-23 02:37:35.066651
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    sunos = SunOSVirtual(module)
    assert sunos.get_virtual_facts() == {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest'}

# Generated at 2022-06-23 02:37:46.408628
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import json
    import subprocess
    import os
    import sys

    # Mock the run_command method of the module we are testing
    def run_command_mock(self, params, check_rc=True):
        # Find the mock response file based on the command we are executing
        # cmd == "zonename"
        if params == "zonename":
            response_file = "tests/unit/module_utils/facts/virtual/sunos_zonename_response.txt"
        # cmd == "modinfo"
        elif params == "modinfo":
            response_file = "tests/unit/module_utils/facts/virtual/sunos_modinfo_response.txt"
        # cmd == "virtinfo -p"

# Generated at 2022-06-23 02:37:56.500133
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock('ISCSIInitiatorName')

    v = SunOSVirtual(module)

    assert v.get_virtual_facts() == {}

    v.module.run_command = lambda x: (0, 'test', '')
    assert v.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': {'zone'}}

    v.module.run_command = lambda x: (0, 'global', '')
    assert v.get_virtual_facts() == {'virtualization_tech_host': {'zone'}, 'virtualization_tech_guest': set()}

    v.module.run_command = lambda x: (0, 'VMware', '')

# Generated at 2022-06-23 02:38:06.472206
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    sun_virtual = SunOSVirtual(module)


# Generated at 2022-06-23 02:38:07.127827
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict(module=None), None)

# Generated at 2022-06-23 02:38:10.063548
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.module == module
    assert virtual.platform == "SunOS"


# Generated at 2022-06-23 02:38:12.895240
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Constructor for class SunOSVirtualCollector can be called with
    no arguments.
    '''
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:15.261125
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:38:17.007271
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:38:21.013180
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = VirtualCollector()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:38:23.981955
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:38:26.830894
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = SunOSVirtual({'module': FakeModule()}).get_all()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'



# Generated at 2022-06-23 02:38:31.309173
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtual

    virtual = SunOSVirtual(dict(module=None))
    assert virtual.get_virtual_facts() is None

# Generated at 2022-06-23 02:38:34.546265
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virt_obj = SunOSVirtual(module)
    assert isinstance(virt_obj, SunOSVirtual)


# Unit testing of class SunOSVirtual

# Generated at 2022-06-23 02:38:36.785222
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Not used, but tested through test_utils/module_utils/fact_collector/__init__.py
    pass

# Generated at 2022-06-23 02:38:42.331030
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.get_virtual_facts() == {'container': 'zone', 'virtualization_type': 'virtuozzo', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'zone', 'virtuozzo'}, 'virtualization_tech_host': {'zone'}}

# Generated at 2022-06-23 02:38:49.352829
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = MockRunCommand()

    virtvirtual = SunOSVirtual(module)

    facts = dict()
    # Can't detect the current zone when zonename is not available
    facts['virtualization_tech_guest'] = set()
    facts['virtualization_tech_host'] = set()
    facts['virtualization_type'] = ""
    facts['virtualization_role'] = ""
    assert virtvirtual.get_virtual_facts() == facts

    # It is a zone, but can't detect its type
    module.run_command.register_sub_command("zonename", 0, "global")
    facts['virtualization_tech_guest'] = set()
    facts['virtualization_tech_host'] = set()
    facts['virtualization_type'] = ""

# Generated at 2022-06-23 02:38:51.494684
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:02.614692
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virt = SunOSVirtual(module=module)

    # Test case: A domU machine
    module.run_command_values['zonename'] = (0, 'global', '')
    module.run_command_values['modinfo'] = (0, 'Type: 5       Kernel Modules', '')
    module.run_command_values['smbios'] = (0, 'HVM domU', '')
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts

# Generated at 2022-06-23 02:39:11.299964
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test get_virtual_facts function of class SunOSVirtual for different scenarios
    """
    class TestModule(object):
        def get_bin_path(self, args, opt_dirs=[]):
            """
            Mock get_bin_path function in order to test
                1. zone
                2. ldom/domaining
                3. VMware
                4. Solaris 8/9 zone
                5. Virtuozzo
            """
            if 'zonename' in args:
                return '/bin/zonename'
            if 'modinfo' in args:
                if 'vmxnet3' in opt_dirs:
                    return '/usr/kernel/drv/sparcv9/vmxnet3'

# Generated at 2022-06-23 02:39:16.532061
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_dict = dict()
    virtual_collector = SunOSVirtualCollector(facts_dict)
    assert virtual_collector._platform == 'SunOS'


# Generated at 2022-06-23 02:39:19.447329
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.platform == 'SunOS'


# test_SunOSVirtualCollector

# Generated at 2022-06-23 02:39:30.946871
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Sample input and output
    class Module:
        def __init__(self):
            self.params = {}

# Generated at 2022-06-23 02:39:32.869878
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:39:38.038377
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    SunOSVirtualCollector._collect_platform_facts(module)
    assert 'virtualization_type' in module.facts
    assert 'virtualization_role' in module.facts
    assert 'virtualization_tech_host' in module.facts
    assert 'virtualization_tech_guest' in module.facts
    assert 'container' in module.facts



# Generated at 2022-06-23 02:39:42.522094
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:39:53.707490
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    run_command = module.run_command
    module.get_bin_path = lambda s: "/usr/bin/" + s
    module.run_command = lambda *args, **kwargs: run_command(*args, **kwargs)
    sunos = SunOSVirtual(module)

    virtual_facts = sunos.get_virtual_facts()
    if len(virtual_facts) == 0:
        assert False, "There are no virtual_facts"

    if not "virtualization_type" in virtual_facts:
        assert False, "'virtualization_type' is not in virtual_facts"

    if not "virtualization_role" in virtual_facts:
        assert False, "'virtualization_role' is not in virtual_facts"


# Generated at 2022-06-23 02:39:57.190928
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector(None, None, None, None)

# Generated at 2022-06-23 02:39:58.817018
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = dict(distribution='SunOS')
    SunOSVirtualCollector(None, os_facts, None)

# Generated at 2022-06-23 02:40:07.166977
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize the class
    module = get_module_mock()
    sunos_virtual = SunOSVirtual(module)

    # Test when it's not a zone
    set_module_args(module, dict(container=dict(key='value')))
    sunos_virtual.module.run_command = run_command_mock
    facts = sunos_virtual.get_virtual_facts()
    assert facts == {}

    # Test when it's a zone
    set_module_args(module, dict(virtualization_type=dict(key='value')))
    sunos_virtual.module.run_command = run_command_mock
    sunos_virtual.module.get_bin_path = get_bin_path_mock

# Generated at 2022-06-23 02:40:19.316991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    module = Mock()
    set_module_args(dict())
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, x, '')

    # 1) Check if it is a zone
    module.get_bin_path.side_effect = lambda x: x if x == 'zonename' else None
    v = SunOSVirtual(module=module)

    # 1.1) Since we are not in a zone, it should return an empty dict
    assert v.get_virtual_facts() == {}

    # 1.2) Now we are in a zone
    module

# Generated at 2022-06-23 02:40:26.583383
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test get_virtual_facts
    """
    fact_virtual = SunOSVirtual()

    # Test a non-virtualized machine
    fact_virtual.module = DummyAnsibleModule({
                                            'smbios': '/bin/true',
                                            'zonename': '/bin/false',
                                            'modinfo': None,
                                            'virtinfo': None,
                                            'lsmod': None,
                                            'osx_say': None
                                            })
    assert fact_virtual.get_virtual_facts() == {}

    # Test a LDoms solaris machine in global zone

# Generated at 2022-06-23 02:40:31.533184
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    result = {'container': 'zone',
              'virtualization_role': 'guest',
              'virtualization_type': 'vmware',
              'virtualization_tech_guest': set(['zone', 'vmware']),
              'virtualization_tech_host': set(['zone'])}
    obj = SunOSVirtual(module)
    assert obj.get_virtual_facts() == result


# Generated at 2022-06-23 02:40:32.710944
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    a = SunOSVirtualCollector(None)
    assert a.platform == 'SunOS'

# Generated at 2022-06-23 02:40:35.553545
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_args = dict()
    v = SunOSVirtual(module_args)
    assert v is not None

# Generated at 2022-06-23 02:40:39.694537
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    facts = SunOSVirtual(module).collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts

# Generated at 2022-06-23 02:40:41.853936
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    nv = SunOSVirtual()
    assert nv._platform == 'SunOS'


# Generated at 2022-06-23 02:40:49.814120
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test the virtual fact collection code and make sure we get
    the correct values
    """
    # pylint: disable=protected-access
    # pylint: disable=attribute-defined-outside-init
    class Module(object):
        def __init__(self):
            self.run_command_environ_update = dict()

        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'zonename':
                return '/usr/sbin/zonename'
            else:
                return None


# Generated at 2022-06-23 02:40:50.865017
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt = SunOSVirtual(module)
    assert virt.platform == "SunOS"

# Generated at 2022-06-23 02:40:54.215429
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    if obj is not None:
        print("SunOSVirtualCollector object initialization, successful")
        return
    print("SunOSVirtualCollector object initialization, unsuccessful")
    return



# Generated at 2022-06-23 02:40:55.958490
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert v.platform == 'SunOS'



# Generated at 2022-06-23 02:41:04.696016
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Prepare the test environment
    if not os.path.exists('/etc/zones'):
        os.mkdir('/etc/zones')

    if not os.path.exists('/proc/vz'):
        os.mkdir('/proc/vz')

    # Run unit tests
    virt_facts = SunOSVirtual().get_virtual_facts()
    assert virt_facts == {}

    open('/etc/zones/sysidcfg', 'w').close()
    virt_facts = SunOSVirtual().get_virtual_facts()
    assert virt_facts == {'container': 'zone'}

    open('/etc/zones/testzone-sysidcfg', 'w').close()
    virt_facts = SunOSVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:41:07.754899
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:11.036024
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS',\
    "SunOSVirtualCollector._platform should be equal to SunOS."


# Generated at 2022-06-23 02:41:13.347461
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == SunOSVirtual._platform
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:19.066227
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert 'container' not in virtual.virtual_facts
    assert 'virtualization_type' not in virtual.virtual_facts
    assert 'virtualization_role' not in virtual.virtual_facts
    assert 'virtualization_tech_guest' not in virtual.virtual_facts
    assert 'virtualization_tech_host' not in virtual.virtual_facts



# Generated at 2022-06-23 02:41:20.513975
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:41:23.898820
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual
    assert hasattr(virtual, 'virtualization_type')
    assert hasattr(virtual, 'virtualization_role')
    assert hasattr(virtual, 'container')



# Generated at 2022-06-23 02:41:25.815585
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facter = SunOSVirtual()
    assert facter._platform == 'SunOS'
    assert facter.get_virtual_facts() == {}

# Generated at 2022-06-23 02:41:29.071119
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector('fact')
    assert hasattr(obj, '_fact_class')
    assert hasattr(obj, '_platform')
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 02:41:33.855628
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.facts['virtualization_type'] == ''
    assert virtual_facts.facts['virtualization_role'] == ''
    assert virtual_facts.facts['virtualization_tech_guest'] == set()
    assert virtual_facts.facts['virtualization_tech_host'] == set()
    assert virtual_facts.facts['container'] == ''

# Generated at 2022-06-23 02:41:36.794292
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:41:43.377340
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule({})
    sunos_virtual = SunOSVirtual(module)

    # test zone execution
    sunos_virtual.module.run_command = run_command_mock({
        'zonename': {
            0: (0, 'global', '')
        },
        'modinfo': {
            0: (0, '', ''),
        },
    })
    assert sunos_virtual.get_virtual_facts() == {
        'virtualization_type': 'zone',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': set(),
        'container': '',
    }
    assert sunos_virtual.module.run_command.call_count == 1
    assert sunos_virtual.module

# Generated at 2022-06-23 02:41:53.652318
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    obj = SunOSVirtual([], module=module)

    # Test in a zone
    module._command_results['zonename'] = (0, "zone_name", None)
    module._command_results['modinfo'] = (0, "name:  vmsync\ndescription: \"VMware synchronization driver\"\n", None)
    facts = obj.get_virtual_facts()
    assert 'zone' in facts['virtualization_tech_host']
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'vmware' in facts['virtualization_tech_guest']
    assert 'container' in facts
    assert facts['container'] == 'zone'
    assert 'virtualization_type' in facts
    assert facts['virtualization_role'] == 'guest'

   

# Generated at 2022-06-23 02:41:55.626160
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.fact_class == SunOSVirtual
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 02:41:59.440989
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Create an object of type SunOSVirtual, then use its properties.
    """
    sunosobj = SunOSVirtual(None)
    assert sunosobj
    assert sunosobj.platform == 'SunOS'

# Generated at 2022-06-23 02:42:04.253380
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    print('Start test')
    v = SunOSVirtual()
    # Make sure subclass is invoked correctly
    assert(isinstance(v, SunOSVirtual))
    # Make sure superclass is invoked correctly
    assert(isinstance(v, Virtual))
    assert(SunOSVirtual._platform == 'SunOS')
    print('End test')

# Generated at 2022-06-23 02:42:09.064307
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector(None)
    assert hasattr(obj, 'platform')
    assert obj.platform == 'SunOS'
    assert hasattr(obj, '_fact_class')
    assert obj._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:42:20.289177
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Unit tests for method get_virtual_facts of class SunOSVirtual.
    # Virtual facts are: container, virtualization_type, virtualization_role, virtualization_tech_guest, virtualization_tech_host
    #
    # Test for normal zone
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/zonename')
    module.os.path.isdir = MagicMock(return_value=False)
    module.os.path.exists = MagicMock(return_value=False)
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_

# Generated at 2022-06-23 02:42:31.415609
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    # Given the above mock arguments, the module should return the following facts
    module.run_command = MagicMock(return_value=(0, '/usr/lib/virtinfo', ""))
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert facts['virtualization_tech_host'] == set()
    assert facts['container'] == 'zone'

# Generated at 2022-06-23 02:42:32.750051
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:42:38.153052
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_virtual_obj = SunOSVirtual(dict(), dict(), '')
    assert test_virtual_obj.platform == 'SunOS'
    assert test_virtual_obj.guest_facts == dict()
    assert test_virtual_obj.module == dict()
    assert test_virtual_obj.virt_what == ''

# Generated at 2022-06-23 02:42:49.020419
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    os_virtual = SunOSVirtual(module=module)

    # Can't detect virtualization on SunOS with only the zonename(1) command
    os_virtual.module.run_command.return_value = (0, "global", "")
    facts = os_virtual.get_virtual_facts()
    assert facts == {}

    # Can't detect virtualization on SunOS with only the modinfo(1) command
    os_virtual.module.run_command.return_value = (0, "", "")
    os_virtual.module.get_bin_path.return_value = "/usr/sbin/modinfo"
    facts = os_virtual.get_virtual_facts()
    assert facts == {}

    # Can detect virtualization on SunOS with zonename(1) and modinfo(

# Generated at 2022-06-23 02:42:59.911343
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = type('AnsibleModule', (object,), dict(
        params=dict(),
        fail_json=lambda *a, **k: None,
        exit_json=lambda *a, **k: None,
        run_command=lambda *a, **k: (0, '', ''),
        get_bin_path=lambda *a, **k: None,
    ))

    test_instance = SunOSVirtual(test_module)

    # Testing in a zone
    test_module.run_command = lambda *a, **k: (0, 'global', '')
    virtual_facts = test_instance.get_virtual_facts()
    assert virtual_facts == {'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set([]), 'container': 'zone'}



# Generated at 2022-06-23 02:43:01.306314
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({'module_setup': False}, '/bin/foo')

    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:43:04.654201
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class is not None

# Unit test function for function get_virtual_facts of class SunOSVirtualCollector

# Generated at 2022-06-23 02:43:14.929194
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import tempfile
    handler, tmpfile = tempfile.mkstemp()
    os.close(handler)
    with open(tmpfile, 'w') as fp:
        pass

    as_dict = {
        'ansible_facts': {
            'ansible_virtualization_type': '',
            'ansible_virtualization_role': '',
            'ansible_container': '',
            'ansible_virtualization_trap': '',
            'ansible_virtualization_trap_ansible_facts': ''
        }
    }
    as_list = [
        'ansible_virtualization_type',
        'ansible_virtualization_role',
        'ansible_container',
        'ansible_virtualization_trap',
        'ansible_virtualization_trap_ansible_facts'
    ]

# Generated at 2022-06-23 02:43:19.993627
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Test with empty 'facts' dict
    virt = SunOSVirtual({})
    assert virt.data == {}

    # Test with facts dict with (some) SunOSVirtual keys
    facts = dict(a_fact='a_value', virtualization_type='zone', virtualization_role='guest', container='zone')
    virt = SunOSVirtual(facts)
    assert virt.data == facts

# Generated at 2022-06-23 02:43:23.820123
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
	assert hasattr(SunOSVirtualCollector, '_platform')
	assert hasattr(SunOSVirtualCollector, '_fact_class')
	assert SunOSVirtualCollector._platform == 'SunOS' 
	assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:27.466737
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with a dummy module.
    module = object()
    collector = SunOSVirtualCollector(module)
    assert isinstance(collector._fact_class(module), SunOSVirtual)
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:43:37.821632
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    virtual = SunOSVirtual(module)

    # Write the test results to test-results.json.
    # This file is used by CI.
    import json
    with open('test-results.json', 'w') as f:
        json.dump([
            {'input': {}, 'output': virtual.get_virtual_facts(), 'expected': {}, },
        ], f, indent=4, sort_keys=True)

# Run the unit test only if we're called directly
# This allows us to use the unit test when developing this plugin
# (by adding -m facts.virtual.sunos)
# and to avoid running the unit test if this plugin is called
# by the facts collection function of Ansible

# Generated at 2022-06-23 02:43:40.946146
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test = SunOSVirtual(dict())
    assert test.platform == 'SunOS'
    assert test.get_virtual_facts() == {}
    assert test.get_virtual_facts() == {}


# Generated at 2022-06-23 02:43:43.215998
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:43:51.370213
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Data for unit tests
    testdata = {}
    testdata['vmware'] = {}
    testdata['vmware']['modinfo'] = """modinfo: module vmmon: filename vmmon.o: \
description VMware Monitor Module: author VMware, Inc.: license GPL v2: \
modinfo: module vmblock: filename vmblock.o: description VMware Blocking \
Filesystem: author VMware, Inc.: license GPL v2: modinfo: module vmnet: filename \
vmnet.o: description VMware Networking Module: author VMware, Inc.: license \
GPL v2: modinfo: module vmci: filename vmci.o: description VMware Virtual \
Machine Communication Interface: author VMware, Inc.: license GPL v2"""
    testdata['vmware']['zonename'] = "global\n"

# Generated at 2022-06-23 02:43:59.316166
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    platform_virtual = SunOSVirtual(module)
    expected_virtual_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(['kvm']),
    }
    virtual_facts = platform_virtual.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts


# Generated at 2022-06-23 02:44:01.686241
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

    assert x._fact_class.platform == "SunOS"
    assert x._platform == "SunOS"

# Generated at 2022-06-23 02:44:04.223108
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  assert issubclass(SunOSVirtualCollector, VirtualCollector)


# Generated at 2022-06-23 02:44:13.602850
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Return a dictionary of facts regarding SunOS virtualization
    """
    module = FakeAnsibleModule()
    sunos_virtual_collector = SunOSVirtual(module)

    # mock return values from methods called from within get_virtual_facts

# Generated at 2022-06-23 02:44:15.152283
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, {})

    assert virtual_facts.platform == 'SunOS'



# Generated at 2022-06-23 02:44:21.267631
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_virtual_collector = SunOSVirtualCollector('SunOS', '5.11')
    assert os_virtual_collector._platform == 'SunOS'
    assert os_virtual_collector._sysname == '5.11'
    assert os_virtual_collector._facts['virtualization_type'] == 'xen'
    assert os_virtual_collector._facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' not in os_virtual_collector._facts
    assert 'virtualization_tech_host' not in os_virtual_collector._facts
    assert os_virtual_collector._facts['container'] == 'zone'

# Generated at 2022-06-23 02:44:31.869699
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    mock = {
        'module': {
            'run_command': [
                (0, 'zonea\n', ''),
                (0, 'virtio\n', ''),
                (0, 'VMware vmmemctl module\n', ''),
            ],
            'get_bin_path': [
                ('modinfo', True),
                ('zonename', True),
                ('virtinfo', True),
            ]
        },
        'os': {
            'path': {
                'isdir': [
                    ('/.SUNWnative', False),
                    ('/proc/vz', True),
                ],
                'exists': [
                    ('/proc/vz', False),
                ]
            }
        }
    }

    virtual = SunOSVirtual(mock)
    facts = virtual.get_virtual

# Generated at 2022-06-23 02:44:40.230636
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a minimal module to use when testing
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create an instance of the module to use when testing
    SunOSVirtual = SunOSVirtual(module)

    # Create a list of keys we expect to receive
    expected_keys = [
        'virtualization_role',
        'virtualization_type',
        'container',
        'virtualization_tech_host',
        'virtualization_tech_guest'
    ]

    # Make the test call
    virtual_facts = SunOSVirtual.get_virtual_facts()

    # Assert that the expected keys are in the returned dictionary
    for key in expected_keys:
        module.assertIn(key, virtual_facts)
