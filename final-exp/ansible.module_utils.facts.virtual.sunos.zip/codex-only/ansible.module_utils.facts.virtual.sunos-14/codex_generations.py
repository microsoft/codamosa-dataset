

# Generated at 2022-06-23 02:34:41.576696
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mc = SunOSVirtualCollector()
    assert mc.platform == 'SunOS'
    assert issubclass(mc.get_fact_class(), Virtual)

# Generated at 2022-06-23 02:34:46.478005
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.get_bin_path = Mock(return_value="bin_path")
    module.run_command = Mock(return_value=("return_value", "", ""))
    SunOSVirtualCollector.get_virtual_facts(module)


# Generated at 2022-06-23 02:34:49.537125
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:34:52.382709
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:34:55.737243
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:34:58.716165
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()

    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual



# Generated at 2022-06-23 02:35:02.238072
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual(dict())
    assert virtual_obj.module == dict()
    assert virtual_obj.platform == 'SunOS'

# Generated at 2022-06-23 02:35:11.612927
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ModuleMock(object):
        class RunCommandMock():
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, cmd):
                return self.rc, self.out, self.err

        def __init__(self):
            self.get_bin_path_rc = {
                "zonename": 0,
                "modinfo": 0,
                "virtinfo": 0,
                "smbios": 0}
            self.get_bin_path_out = {
                "zonename": "zone_name",
                "modinfo": "modinfo_output",
                "virtinfo": "virtinfo_output",
                "smbios": "smbios_output"}
            self.get

# Generated at 2022-06-23 02:35:22.511310
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_fixture = SunOSVirtual({})
    test_fixture.module.run_command = lambda x: (0, "global", "")
    test_fixture.module.get_bin_path = lambda x: "/usr/bin/zonename"
    assert test_fixture.get_virtual_facts() == {}

    test_fixture = SunOSVirtual({})
    test_fixture.module.run_command = lambda x: (0, "global", "")
    assert test_fixture.get_virtual_facts() == {}

    test_fixture = SunOSVirtual({})
    test_fixture.module.run_command = lambda x: (0, "myzone", "")

# Generated at 2022-06-23 02:35:25.879054
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_test_SunOSVirtualCollector = SunOSVirtualCollector()
    assert my_test_SunOSVirtualCollector.platform == 'SunOS'
    assert isinstance(my_test_SunOSVirtualCollector.get_virtual_facts(), SunOSVirtual)

# Generated at 2022-06-23 02:35:35.180917
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('obj', (object,), {
        'run_command': lambda self, *args: (0, '', ''),
        'get_bin_path': lambda self, *args: '/sbin/',
    })()
    module.virtual = SunOSVirtual(module)
    command = module.virtual.get_virtual_facts
    assert len(command) != 0
    assert 'virtualization_type' in command
    assert 'virtualization_role' in command
    assert 'virtualization_tech_host' in command
    assert 'container' in command or 'virtualization_tech_guest' in command

# Generated at 2022-06-23 02:35:47.173318
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initializing the test class
    SunOSVirtual_test = SunOSVirtual({'ansible_facts': {}})

    # Testing with an OS that is not supported by the module
    SunOSVirtual_test.module.params = { 'gather_subset': '!all,min' }
    SunOSVirtual_test.module.run_command = lambda x, check_rc=True: (0, '', '')
    result = SunOSVirtual_test.get_virtual_facts()
    assert result == {}

    # Testing with a zone that is not virtualized
    SunOSVirtual_test.module.run_command = lambda x, check_rc=True: (0, 'global', '')
    SunOSVirtual_test.module.get_bin_path = lambda x: '/usr/bin/' + x
    result = SunOSVirtual_

# Generated at 2022-06-23 02:35:51.649110
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual

    sunos = SunOSVirtual()
    result = sunos.get_virtual_facts()
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in result['virtualization_tech_guest']
    assert 'container' in result

# Generated at 2022-06-23 02:35:54.838224
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    theModule = mock.MagicMock()
    theModule.get_bin_path.return_value = '/usr/sbin/virtinfo'
    theModule.run_command.return_value = 0, '', ''
    sunosVirtual = SunOSVirtual(theModule)
    assert sunosVirtual is not None

# Generated at 2022-06-23 02:36:03.344108
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(module)

    # Default value for 'container' should be None
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts['container'] is None

    # Execute get_virtual_facts with a fake command to detect zones, then verify
    # that the 'zone' virtualization_type has been detected
    module.run_command = lambda cmd: (0, "global\n", '')
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert 'zone' in virtual_facts['virtualization_tech_host']

    # Execute get_virtual_facts with a fake command to detect zones, then verify
    # that the 'zone' virtualization_type has been detected

# Generated at 2022-06-23 02:36:12.974969
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Example from OpenIndiana Hipster
    zone_v = SunOSVirtual({'module_setup': dict(base_class_setup_defaults=dict(gather_subset=['all']))})
    zone_result = zone_v.get_virtual_facts()
    assert zone_result == {
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'container': 'zone',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(['zone'])
    }

    # Example from OpenIndiana Hipster
    vbox_v = SunOSVirtual({'module_setup': dict(base_class_setup_defaults=dict(gather_subset=['all']))})
    vbox_result = vbox_v.get_

# Generated at 2022-06-23 02:36:15.493607
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual({}).get_virtual_facts() == {}


# Generated at 2022-06-23 02:36:27.298636
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt_facts_sunos = SunOSVirtual({})
    facts = dict(virtual_facts=dict())

    # get_virtual_facts will set virtual_facts['virtualization_type'] to 'zone'
    facts['virtual_facts']['zone'] = 'global'
    assert virt_facts_sunos.get_virtual_facts(facts) == dict(virtualization_type='zone', virtualization_role='host')

    facts['virtual_facts']['zone'] = 'testzone'
    assert virt_facts_sunos.get_virtual_facts(facts) == dict(virtualization_type='zone', virtualization_role='guest', container='zone')
    assert virt_facts_sunos.get_virtual_facts(dict(virtual_facts=dict())) == dict()

# Generated at 2022-06-23 02:36:32.672901
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (object,), {})
    module.run_command = classmethod(lambda cls, cmd, check_rc=True: ('', '', '',
       'VMware|VirtualBox|Parallels|HVM domU|KVM|VMware'))
    module.get_bin_path = classmethod(lambda cls, cmd: '/usr/sbin/virtinfo')
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x
    module.params = {'command_timeout': 10}
    module.log = lambda x, y: x
    SunOSVirtual(module)

# Generated at 2022-06-23 02:36:35.031244
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()

# Generated at 2022-06-23 02:36:43.430294
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    sunos_virtual = SunOSVirtual(module)
    # To mock facts for the class SunOSVirtual, we define a dict 'virtual_facts_test'
    # and we'll test against it.
    virtual_facts_test = {}

    # zone facts
    zonename_test = []
    zonename_test.append(AnsibleCmdResult(rc=0, stdout="global\n", stderr=''))
    zonename_test.append(AnsibleCmdResult(rc=0, stdout="zone1\n", stderr=''))
    zonename_mock = MagicMock(side_effect=zonename_test)
    module.get_bin_path = MagicMock(return_value='/usr/bin/zonename')

# Generated at 2022-06-23 02:36:44.936535
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:36:47.990342
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """test_SunOSVirtualCollector"""
    facts = SunOSVirtualCollector()
    assert facts.virtual._platform == 'SunOS', 'test_SunOSVirtualCollector failed'

# Generated at 2022-06-23 02:36:58.477638
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    # Test when SunOSVirtual is not a subclass of Virtual
    if issubclass(SunOSVirtual, Virtual):
        del Virtual._platform_subclasses['SunOS']
        del Virtual.platform_subclasses['SunOS']
    # Create a SunOSVirtualCollector object
    sunos_virtual_collector = SunOSVirtualCollector(module=facts.AnsibleModuleMock())
    # Test that the get_virtual_facts method raises a NotImplementedError


# Generated at 2022-06-23 02:37:07.525426
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Unit test for constructor of class SunOSVirtual
    """
    print("Unit test for constructor of class SunOSVirtual")
    sunos_virtual = SunOSVirtual()
    print("platform = " + sunos_virtual.platform)
    print("virtualization_type = " + str(sunos_virtual.virtualization_type))
    print("virtualization_role = " + str(sunos_virtual.virtualization_role))
    print("container = " + str(sunos_virtual.container))
    print("virtualization_tech_host = " + str(sunos_virtual.virtualization_tech_host))
    print("virtualization_tech_guest = " + str(sunos_virtual.virtualization_tech_guest))


# Generated at 2022-06-23 02:37:15.816661
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    import mock
    import __builtin__

    with mock.patch.dict(sys.modules, {'ansible': mock.Mock(),
                                       'ansible.module_utils': mock.Mock(),
                                       'ansible.module_utils.facts': mock.Mock(),
                                       'ansible.module_utils.facts.virtual': mock.Mock(),
                                       'ansible.module_utils.facts.virtual.base': mock.Mock()}):
        sys.modules['ansible'].module_utils = mock.Mock()
        sys.modules['ansible'].module_utils.facts = mock.Mock()
        sys.modules['ansible'].module_utils.facts.virtual = mock.Mock()
        sys.modules['ansible'].module_utils.facts.virtual.base = mock

# Generated at 2022-06-23 02:37:27.014780
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    virtual_facts_helper = Virtual(module)
    virtual_facts = SunOSVirtual(module)

    facts = {
        'kernel': 'SunOS',
    }

    # Check all virtualization technology
    virtual_facts_helper.data = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'container': 'zone',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['zone']),
    }

    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(side_effect=lambda path: path)

# Generated at 2022-06-23 02:37:36.178838
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class M(object):
        def __init__(self, rc, out=None, err=None):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            if cmd == 'zonename':
                return (0, 'global', '')
            elif cmd == '/usr/sbin/memconf':
                # If memconf is missing then it means we are running on an older
                # system (i.e. pre Solaris 10)
                return (1, '', '')
            elif cmd == '/usr/sbin/virtinfo -P':
                return (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', '')

# Generated at 2022-06-23 02:37:41.149324
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    inst = SunOSVirtual(dict())
    # First ensure we have an instance of the class
    assert isinstance(inst, SunOSVirtual)
    # Then ensure that the platform is set correctly
    assert inst.platform == 'SunOS'
    # Then ensure that the _fact_class is set correctly
    assert inst._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:37:43.597916
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v1 = SunOSVirtual()
    assert v1.platform == 'SunOS'
    v2 = SunOSVirtual(dict(), dict())
    assert v2.platform == 'SunOS'

# Generated at 2022-06-23 02:37:46.562060
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:37:48.503695
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict(module=dict()))
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:37:49.893423
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual()
    assert obj.platform == 'SunOS'


# Generated at 2022-06-23 02:37:58.757565
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test typical zone
    module = type('TestModule', (object,), {
        'get_bin_path': lambda self, _: '/usr/sbin/zonename',
        'run_command': lambda self, cmd: (0, 'zone1\n', ''),
    })

    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'
    assert 'zone' in facts['virtualization_tech_guest']
    assert 'zone' not in facts['virtualization_tech_host']

    # Test global zone

# Generated at 2022-06-23 02:38:00.963002
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:38:03.129664
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert SunOSVirtual(dict()).get_virtual_facts() == dict()

# Generated at 2022-06-23 02:38:04.527759
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector().collect(), dict)

# Generated at 2022-06-23 02:38:15.449775
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Verify for zone
    zonename = "global\n"
    modinfo = []
    smbios = []
    virtinfo = []
    my_object = SunOSVirtual({}, zonename, modinfo, smbios, virtinfo)
    result = my_object.get_virtual_facts()
    assert sorted(result['virtualization_tech_host']) == sorted(['zone'])
    assert 'container' not in result
    assert 'virtualization_role' not in result
    assert 'virtualization_type' not in result

    # Verify for branded zone
    zonename = "zone0\n"
    modinfo = []
    smbios = []
    virtinfo = []
    my_object = SunOSVirtual({}, zonename, modinfo, smbios, virtinfo)
    result = my_object

# Generated at 2022-06-23 02:38:18.520506
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})
    if v.get_virtual_facts() is not None:
        raise AssertionError('SunOSVirtual.get_virtual_facts returns a value if a virtual platform is detected.')
    else:
        pass

# Generated at 2022-06-23 02:38:29.649442
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    # Set up
    fake_module = basic.AnsibleModule(
        argument_spec=dict()
    )
    fake_module.run_command = fake_run_command
    sunos_virtual = SunOSVirtual(fake_module)

    # Test a system with a zone
    res = sunos_virtual.get_virtual_facts()
    assert res['virtualization_role'] == 'guest'
    assert res['virtualization_type'] == 'zone'
    assert res['container'] == 'zone'

    # Test a system with a branded zone (i.e. Solaris 8/9 zone)
    sunos_virtual.module.run_command = fake_run_command_branded_zone
    res = sunos_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:38:33.712169
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert isinstance(c, SunOSVirtualCollector)
    assert issubclass(c._fact_class, SunOSVirtual)
    assert isinstance(c.platform, str)
    assert c.platform == 'SunOS'

# Generated at 2022-06-23 02:38:35.280278
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    l = SunOSVirtual()
    assert l.platform == 'SunOS'

# Generated at 2022-06-23 02:38:45.961706
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

    # Test the constructor
    virtual_facts = SunOSVirtual({'ansible_facts': {}, 'module': None})
    assert virtual_facts.module is None
    assert virtual_facts.platform == 'SunOS'

    # test some of the methods in the parent class
    assert virtual_facts._virtual_facts is None
    assert virtual_facts.has_been_collected is False
    virtual_facts.collect()
    assert virtual_facts._virtual_facts is not None
    assert virtual_facts.has_been_collected is True

    # Test some of the methods in the SunOSVirtual class
    assert virtual_facts.get_virtual_facts() is not None

# Generated at 2022-06-23 02:38:49.869927
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == 'SunOSVirtual'


# Generated at 2022-06-23 02:38:54.289232
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # create a class instance
    v = SunOSVirtual()

    # check class variable values
    assert v.virtualization_type == ()
    assert v.virtualization_role == ()
    assert v.container == ()
    assert v.platform == ('SunOS')

# Generated at 2022-06-23 02:38:56.197322
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, None)
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:38:58.337099
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Unit test - constructor
    v = SunOSVirtual({})
    assert v._platform == 'SunOS'



# Generated at 2022-06-23 02:39:08.134517
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Arrange
    module = None
    virtual_facts = {}
    # Act
    obj = SunOSVirtual(module, virtual_facts)
    obj._module.run_command = mock_run_command
    obj._module.get_bin_path = mock_get_bin_path
    facts = obj.get_virtual_facts()
    # Assert
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'vmware'}
    assert facts['virtualization_tech_host'] == {'zone'}
    assert facts['container'] == 'zone'

# Unit test helper methods and mock classes/methods

# Generated at 2022-06-23 02:39:15.719370
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Unit test for get_virtual_facts of class SunOSVirtual

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json
            self.params['gather_subset'] = ['all']

        def run_command(self, cmd):
            out = ''
            if cmd == '/usr/sbin/virtinfo -p':
                out = 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false'

# Generated at 2022-06-23 02:39:24.749152
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # For this test, we create a module object
    from ansible.module_utils.facts.virtual.test.test_sunos_module import FakeModule
    module = FakeModule()

    # We create an object of class SunOSVirtual and we check that
    # the method get_virtual_facts of this class returns the correct values
    sunos = SunOSVirtual(module)
    virtual_facts = sunos.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'kvm'}

# Generated at 2022-06-23 02:39:32.511981
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = MockModule()
    virtual_mock = SunOSVirtual({'module': module_mock})

    # If a zone, set out for zonename
    module_mock.run_command.side_effect = [
        (0, 'global', ''),
    ]

    assert virtual_mock.get_virtual_facts() == {
        'virtualization_tech_host': set(['zone']),
        'virtualization_tech_guest': set(),
        'virtualization_type': 'zone'
    }



# Generated at 2022-06-23 02:39:35.467779
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.virtualization_type == 'zone'
    assert virtual_facts.virtualization_role == 'guest'
    assert virtual_facts.container == 'zone'

# Generated at 2022-06-23 02:39:42.640629
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class TestModule:

        class TestCommand:

            def run_command(self, command):
                if command == 'zonename':
                    return (0, 'global', '')
                elif command == 'modinfo':
                    return (0, 'modinfo: module not found', '')
                else:
                    return (1, '', 'not found')

        def get_bin_path(self, path):
            return None

        def __init__(self):
            self.run_command = self.TestCommand().run_command
            self.get_bin_path = self.get_bin_path

    class TestSunOSVirtual:

        platform = 'undefined'
        module = TestModule()

        def get_virtual_facts(self):
            return self._SunOSVirtual__get_virtual_facts()

    # GIVEN

# Generated at 2022-06-23 02:39:44.010465
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = MagicMock()
    SunOSVirtualCollector(module)

# Generated at 2022-06-23 02:39:47.296341
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert isinstance(x, VirtualCollector)


# Generated at 2022-06-23 02:39:54.574236
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    import os
    import shutil
    try:
        with open("/tmp/test_facts", "w") as f:
            f.write("test")
        out = sys.stdout
        sys.stdout = open("/dev/null", "w")
        collector = SunOSVirtualCollector("/tmp/test_facts")
        sys.stdout.close()
        sys.stdout = out
    finally:
        sys.stdout = out
        shutil.rmtree("/tmp/test_facts")


# Generated at 2022-06-23 02:39:57.599155
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    a = SunOSVirtualCollector(dict())
    assert a

# Generated at 2022-06-23 02:40:00.721208
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_type == None
    assert sunos_virtual.virtualization_role == None

# Generated at 2022-06-23 02:40:09.764223
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # create a Virtual class object
    virtual_obj = SunOSVirtual()

    # create a FakeModule object
    fake_module_obj = FakeModule()

    # get the facts
    facts = virtual_obj.get_virtual_facts(fake_module_obj)

    # check if the facts are empty
    assert not facts

# Generated at 2022-06-23 02:40:15.191476
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._platform == 'SunOS'
    assert hasattr(x, '_fact_class')
    assert x._fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-23 02:40:19.292659
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Instantiate class SunOSVirtualCollector with no arguments
    sunosvirtualcollector = SunOSVirtualCollector()
    # Check that class SunOSVirtualCollector is a child class of class VirtualCollector
    assert isinstance(sunosvirtualcollector, VirtualCollector)

# Generated at 2022-06-23 02:40:22.337274
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Unit test for constructor of class SunOSVirtualCollector.
    """

    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:23.523988
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:24.690937
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:28.937050
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = FakeAnsibleModule()
    virtual = SunOSVirtual(module=test_module)
    facts = virtual.get_virtual_facts()
    assert facts == {}

test_module = FakeAnsibleModule()
virtual = SunOSVirtual(module=test_module)


# Generated at 2022-06-23 02:40:32.014873
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    "Test get_virtual_facts of SunOSVirtual class"
    facts = SunOSVirtual({})
    virtual_facts = facts.get_virtual_facts()
    print(virtual_facts)

# Generated at 2022-06-23 02:40:39.468053
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = dict()
    SunOSVirtualCollector(virtual_facts, dict())
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:40:50.616382
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class SunOSVirtualModule:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            return self.out

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    def test(out, err, rc):
        module = SunOSVirtualModule(rc, out, err)
        facts = SunOSVirtual(module).get_virtual_facts()
        return facts

    # Check if it's a zone
    zoneout = '/global'
    zoneerr = ''
    zonefacts = test(zoneout, zoneerr, 0)
    assert 'container' in zonefacts and zonefacts['container'] == 'zone'

# Generated at 2022-06-23 02:40:52.326125
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    o = SunOSVirtual(dict())
    assert o.platform == 'SunOS'

# Generated at 2022-06-23 02:41:00.462226
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    facts = SunOSVirtual(module, []).get_virtual_facts()

    # SunOSVirtual should always return a dictionary
    assert isinstance(facts, dict), "SunOSVirtual.get_virtual_facts() should return a dictionary." \
        "It returned %s instead" % repr(facts)

    # Check that the values that should be in the dictionary are there.
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_type'] is None
    assert facts['virtualization_role'] is None
    assert facts['container'] is None


# Generated at 2022-06-23 02:41:02.946243
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:41:12.504507
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import tempfile
    import shutil
    import os

    ldoms_out = """DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false"""
    smbios_out = """VMware Virtual Platform
Parallels Virtual Platform
Oracle VM VirtualBox
KVM
HVM domU
foo"""

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.params = {
                'run_command': {
                    'executable': None,
                },
            }
            self.tmpdir = tempfile.mkdtemp(prefix='ansible_test_ SunOSVirtual_get_virtual_facts_')



# Generated at 2022-06-23 02:41:22.760789
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test SunOSVirtual.get_virtual_facts()
    """
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import override_facts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create a facts object for testing
    module = Facts()
    module.params = {}

    # Add facts that would normally be collected from the system
    overrides = {}
    overrides['ansible_system'] = 'SunOS'
    overrides['ansible_machine'] = 'i86pc'
    overrides['ansible_domain'] = 'example.com'
    overrides['ansible_os_family'] = 'Solaris'
    overrides['ansible_pkg_mgr'] = 'pkgsrc'

# Generated at 2022-06-23 02:41:27.465688
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # If a single VM is detected, then virtualization_type is the name of the
    # detected VM, virtualization_role is guest, container is the name of the
    # detected VM.

    # If multiple VMs are detected, then virtualization_type is the name of
    # one of the detected VMs, virtualization_role is guest, container is the
    # name of one of the detected VMs.
    pass



# Generated at 2022-06-23 02:41:30.684414
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    v = SunOSVirtualCollector(module=module)
    assert v.platform == 'SunOS'
    assert v.virtual == 'zone'


# Generated at 2022-06-23 02:41:41.671722
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    # This is what a zone would return
    zone_get_bin_path_map = {'zonename': '/usr/bin/zonename'}
    zone_run_command_map = {'/usr/bin/zonename': (0, 'non-global', '')}
    module = basic.AnsibleModule(run_command_check=True,
                                 get_bin_path_check=True,
                                 argument_spec={})
    module.run_command = lambda x: zone_run_command_map[x]
    module.get_bin_path = lambda x: zone_get_bin_path_map[x]
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual

# Generated at 2022-06-23 02:41:45.295902
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a instance of SunOSVirtual class
    virtual_test = SunOSVirtual(None)
    # Call method get_virtual_facts
    ret = virtual_test.get_virtual_facts()
    print(ret)

# Generated at 2022-06-23 02:41:54.561360
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Import my test class
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Create my mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Get the test class
    sun = SunOSVirtual(module=module)

    # Test get_virtual_facts
    facts = sun.get_virtual_facts()

    assert facts == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(['zone']),
        'container': 'zone'
    }



# Generated at 2022-06-23 02:41:56.927239
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)


# Generated at 2022-06-23 02:42:07.844968
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_facts = {}
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    test_SunOSVirtual = SunOSVirtual(module=MockModule())
    VirtualCollector.add_virtual_collector(SunOSVirtualCollector)
    collector.get_virtual_facts(test_facts)
    assert "virtualization_type" in test_facts
    assert "virtualization_role" in test_facts
    assert "container" in test_facts
    assert "virtualization_tech_guest" in test_facts

# Generated at 2022-06-23 02:42:09.262039
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({})
    assert isinstance(obj, SunOSVirtual)

# Generated at 2022-06-23 02:42:20.055339
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = mock.Mock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = True

    fake_collect_facts = collect_facts.CollectFacts(module)
    virtual_facts = SunOSVirtual(fake_collect_facts).get_virtual_facts()

    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'container' not in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:42:21.801244
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # FIXME: add unit test for method get_virtual_facts of class SunOSVirtual
    pass


# Generated at 2022-06-23 02:42:26.540605
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    virtual_facts.populate()
    assert 'virtualization_type' in virtual_facts.facts
    assert 'virtualization_role' in virtual_facts.facts

# Generated at 2022-06-23 02:42:29.555949
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.data['virtualization_type'] == 'zone'
    assert v.data['virtualization_role'] == 'guest'
    assert v.data['container'] == 'zone'

# Generated at 2022-06-23 02:42:30.932661
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-23 02:42:32.635188
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:42:36.441166
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fake_module = FakeAnsibleModule()
    vc = SunOSVirtualCollector(fake_module)
    assert vc._platform == "SunOS"



# Generated at 2022-06-23 02:42:45.227181
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    m.run_command = MagicMock(return_value=(0, to_bytes("global\n"), ""))
    sv = SunOSVirtual(m)
    assert sv.get_virtual_facts() == {'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None}
    m.run_command = MagicMock(return_value=(0, to_bytes("zone\n"), ""))
    sv = SunOSVirtual(m)

# Generated at 2022-06-23 02:42:57.266975
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # mock module input data
    module_args = {}

    # initialize the module and get facts
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    virt = SunOSVirtual(module)

    # if not SunOS we skip the test
    if virt.platform != 'SunOS':
        module.exit_json(skipped=True)

    # set the path to the mocked binaries
    os.environ['PATH'] = os.path.dirname(os.path.abspath(__file__)) + '/../unit/binaries/'

    # set the mocked hostname
    os.environ['HOSTNAME'] = 'test1'
    virt.facts['hostname'] = 'test1'

    # set the mocked product name/version
    os.environ

# Generated at 2022-06-23 02:43:01.005166
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''Unit test for class SunOSVirtualCollector'''

    # Constructor test
    facts_collector = SunOSVirtualCollector(None)
    assert facts_collector is not None

# Generated at 2022-06-23 02:43:03.136711
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vm = SunOSVirtual({},{},{},[])
    assert vm.platform == 'SunOS'


# Generated at 2022-06-23 02:43:06.819024
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert isinstance(instance, SunOSVirtualCollector)
    assert isinstance(instance._fact_class, SunOSVirtual)
    assert instance._platform == 'SunOS'

# Generated at 2022-06-23 02:43:08.822530
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    myos = SunOSVirtual()
    assert type(myos) is SunOSVirtual


# Generated at 2022-06-23 02:43:11.337772
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector()
    assert virtual_facts._platform == 'SunOS'
    assert virtual_facts.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-23 02:43:20.677740
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
        'container': 'docker'
    }
    facts = {}
    module = AnsibleModuleMock()
    v = SunOSVirtual(module)
    assert v.get_virtual_facts() == {}
    module.run_command = lambda x: (0, 'HVM domU', '')
    assert v.get_virtual_facts() == virt_facts


# Generated at 2022-06-23 02:43:27.821797
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = object()
    # Initialize our class
    test_class = SunOSVirtual(module)

    # Catch the output of the function
    out = test_class.get_virtual_facts()

    # Print the output
    print("Virtual facts are: ")
    for key in out.keys():
        print("%s: %s" % (key, out[key]))


if __name__ == '__main__':
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:43:33.842940
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector()
    assert facts_collector._fact_class == SunOSVirtual, "_fact_class(%s) attribute of class SunOSVirtualCollector has incorrect value" % (facts_collector._fact_class)
    assert facts_collector._platform == 'SunOS', "_platform(%s) attribute of class SunOSVirtualCollector has incorrect value" % (facts_collector._platform)

# Generated at 2022-06-23 02:43:42.087259
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    commands = {
        'zonename': 'global',
        'virtinfo -p': (0, "LDoms", None),
        'modinfo': (0, "VMware", None),
        'smbios': (0, "VirtualBox", None)
    }
    module.run_command = FakeCommand(commands)
    module.get_bin_path = FakeGetbinPath()
    virtual = SunOSVirtual(module=module)
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'vmware'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == {'zone', 'vmware'}
    assert result['virtualization_tech_host'] == set()
    assert result['container']

# Generated at 2022-06-23 02:43:50.142270
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    
    # Create a module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a SunOSVirtual instance 
    sunOSVirtual = SunOSVirtual(module) 

    # Set a fake virtualization_type value
    sunOSVirtual.virtualization_type = 'fake'

    # Get virtualization facts
    virtualization_facts = sunOSVirtual.get_virtual_facts()

    # Assertions
    assert('virtualization_type' in virtualization_facts)
    assert(virtualization_facts['virtualization_type'] == 'fake' or virtualization_facts['virtualization_type'] == None)


# Generated at 2022-06-23 02:43:51.076035
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()



# Generated at 2022-06-23 02:43:51.999403
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:57.287191
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.facts == {
        'virtualization_role': None,
        'virtualization_type': None,
        'virtualized': False,
        'virtualization_tech_host': [],
        'virtualization_tech_guest': []
    }

# Generated at 2022-06-23 02:44:00.510104
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert isinstance(v, SunOSVirtual)
    assert isinstance(v, Virtual)
    assert v.platform == 'SunOS'
    assert v.container == ''

# Generated at 2022-06-23 02:44:05.548612
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule({}, {}, [], False, False, '/')

    solaris = SunOSVirtual(module)
    assert solaris.platform == 'SunOS'

    solaris = SunOSVirtual({})
    assert solaris.platform == 'SunOS'

    solaris = SunOSVirtual({}, {}, [], '', '')
    assert solaris.platform == 'SunOS'

# Generated at 2022-06-23 02:44:07.622035
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(None)
    assert virtual_facts.platform == 'SunOS'



# Generated at 2022-06-23 02:44:09.905178
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_plugin = SunOSVirtual()
    assert virtual_facts_plugin.platform == 'SunOS'


# Generated at 2022-06-23 02:44:21.711733
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.openvz import OpenVZVirtual
    from ansible.module_utils.facts.virtual.xen import XenVirtual
    from ansible.module_utils.facts.virtual.kvm import KVMVirtual
    from ansible.module_utils.facts.virtual.virtuozzo import VirtuozzoVirtual

    mock_module = MockModule()

    # If zonename returns nothing
    mock_module.run_command = Mock(return_value=(0, '', ''))
    virtual = SunOSVirtual(mock_module)
    virtual.get_virtual_facts()
    assert not 'container' in virtual.virtual_facts

    # If zonename returns 'global'

# Generated at 2022-06-23 02:44:24.197299
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual()
    assert sunosvirtual is not None
    assert sunosvirtual.platform == 'SunOS'


# Generated at 2022-06-23 02:44:33.215014
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    sunos_virtual = SunOSVirtual(module)
    ldom_facts = sunos_virtual.get_virtual_facts()
    module.fail_json.assert_not_called()
    assert ldom_facts['virtualization_type'] == 'ldom'
    assert ldom_facts['virtualization_role'] == 'guest'
    assert 'container' not in ldom_facts
    assert 'virtualization_tech_guest' not in ldom_facts
    assert 'virtualization_tech_host' not in ldom_facts

import unittest
from ansible.module_utils.facts import virtual



# Generated at 2022-06-23 02:44:41.074961
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Test the constructor of class SunOSVirtualCollector
    '''
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector.__class__.__name__ == 'SunOSVirtualCollector', \
        'The class name of SunOSVirtualCollector is %s. It should be SunOSVirtualCollector' % sunos_virtual_collector.__class__.__name__
    assert sunos_virtual_collector._platform == 'SunOS', \
        'The platform of SunOSVirtualCollector is %s. It should be SunOS' % sunos_virtual_collector._platform