

# Generated at 2022-06-23 02:34:38.550920
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual(None)
    assert isinstance(facts, Virtual)
    assert facts.platform == 'SunOS'

# Generated at 2022-06-23 02:34:42.962742
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.virtual import Virtual

    fact_class = SunOSVirtual()
    assert isinstance(fact_class, Virtual)
    assert fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:34:54.586144
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos.get_virtual_facts_sunos import test_cases
    import sys
    import os
    import tempfile
    import subprocess
    import json

    # Remove the module_utils directory from the path so that our test_cases
    #  modules get imported before the real module_utils modules
    module_utils_path_index = None
    for i, path in enumerate(sys.path):
        if path.endswith('module_utils'):
            module_utils_path_index = i
            break

    # Remove the path to the module_utils dir from sys.path
    if module_utils_path_index is not None:
        del sys.path[module_utils_path_index]

    # Add test cases to sys.modules
    test_cases_path = os

# Generated at 2022-06-23 02:34:56.695911
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_obj = SunOSVirtual('sunos')
    assert test_obj.platform == 'SunOS'

# Generated at 2022-06-23 02:34:59.185365
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector(None)
    assert virtual_collector
    assert virtual_collector._fact_class == SunOSVirtual
    assert virtual_collector._platform == "SunOS"

# Generated at 2022-06-23 02:35:02.837504
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:35:06.424302
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})

    assert virtual.__class__.__name__ == 'SunOSVirtual'
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts() == {}


# Generated at 2022-06-23 02:35:10.454744
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt_facts = SunOSVirtual(None).get_virtual_facts()
    assert virt_facts['virtualization_type'] == 'xen'
    assert virt_facts['virtualization_role'] == 'guest'
    assert virt_facts['virtualization_tech_guest'] == set(['xen'])


# Generated at 2022-06-23 02:35:13.350378
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    unit test for constructor of class SunOSVirtualCollector
    '''
    vc = SunOSVirtualCollector()
    assert isinstance(vc,SunOSVirtualCollector)

# Generated at 2022-06-23 02:35:20.065051
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    modinfo = MagicMock()
    module.get_bin_path = lambda x: modinfo
    modinfo.return_value = 0
    zonename = MagicMock()
    module.get_bin_path = lambda x: zonename
    zonename.return_value = 'global'
    module.run_command = MagicMock()
    module.run_command.return_value = 0
    module.run_command.communicate.return_value = ('', '')
    sunos_virtual = SunOSVirtual(module)

# Generated at 2022-06-23 02:35:29.396282
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Test data
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'global', None)
    mock_module.get_bin_path.return_value = 'zonename'

    # Test object
    virtual = SunOSVirtual(mock_module)

    # Test call
    result = virtual.get_virtual_facts()
    assert result == {}

    # Test data
    mock_module.run_command.return_value = (0, 'zone1', None)
    mock_module.get_bin_path.return_value = 'zonename'

    # Test object
    virtual = SunOSVirtual(mock_module)

    # Test call
    result = virtual.get_virtual_facts()

# Generated at 2022-06-23 02:35:32.492997
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import FactCollector
    c = FactCollector(namespace='ansible_facts', excluded_facts=[])
    s = SunOSVirtualCollector(c)

# Generated at 2022-06-23 02:35:34.732531
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()

# Generated at 2022-06-23 02:35:37.003308
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_instance = SunOSVirtual(module)
    assert virtual_instance.platform == 'SunOS'

# Generated at 2022-06-23 02:35:41.035379
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual_collector = SunOSVirtualCollector(module)
    virtual_fact = virtual_collector.collect()
    assert isinstance(virtual_fact, SunOSVirtual)
    assert virtual_fact.platform == 'SunOS'


# Generated at 2022-06-23 02:35:43.323465
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == "SunOS"
    assert obj._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:35:52.763428
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class SunOSVirtual"""
    # setup a testclass
    # mock processor.cpu_info and return empty dictionary
    # run get_virtual_facts of SunOSVirtual
    # check the result
    # mock processor.cpu_info and return data
    # run get_virtual_facts of SunOSVirtual
    # check the result
    failed = False
    error_msg = ""
    try:
        import mock
    except ImportError:
        failed = True
        error_msg = "mock python module is not installed"
    else:
        from ansible.module_utils.facts.virtual.sunos.sunos import SunOSVirtual

# Generated at 2022-06-23 02:36:02.336519
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class FakeModule:

        def __init__(self):
            self.params = {}
            self.run_command_called = False

        def run_command(self, cmd, *args, **kwargs):
            self.run_command_called = True

    # Test if running on a non-Solaris platform
    m = FakeModule()
    s = SunOSVirtual(m)

    virtual_facts = s.get_virtual_facts()
    assert virtual_facts == {}
    assert m.run_command_called == False

    # Test if running on a zone or a Solaris branded zone
    m = FakeModule()
    s = SunOSVirtual(m)
    s._platform = m.platform = 'SunOS'
    s.zonename = m.get_bin_path = lambda cmd: cmd

    virtual_facts = s.get

# Generated at 2022-06-23 02:36:06.978642
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = mock.Mock()
    virtual = SunOSVirtual(module)
    assert(virtual.platform == 'SunOS')
    assert(virtual.module == module)
    assert(virtual.zonename is None)
    assert(virtual.virtinfo is None)


# Generated at 2022-06-23 02:36:11.990858
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts import FactCollector

    fact_collector = FactCollector()
    facts = fact_collector.collect(['virtual'])
    virtual = SunOSVirtual(facts)
    keys = virtual.get_virtual_facts().keys()
    assert 'virtualization_type' in keys
    assert 'virtualization_role' in keys
    assert 'container' in keys

# Generated at 2022-06-23 02:36:14.325854
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == "SunOS"

# Generated at 2022-06-23 02:36:16.724230
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:36:19.604236
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual()
    assert (obj.platform == 'SunOS')


# Generated at 2022-06-23 02:36:29.237240
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a instance of class SunOSVirtual
    virtual = SunOSVirtual({}, {})
    virtual.module.run_command = lambda x, check_rc=True, close_fds=True, executable=None, data=None: (0, "VMware\n", "")
    virtual.module.get_bin_path = lambda x, opt_dirs=[] : '/usr/bin/' + x
    # Virtual zone
    virtual.module.get_bin_path = lambda x, opt_dirs=[] : '/bin/zonename'
    virtual.module.run_command = lambda x, check_rc=True, close_fds=True, executable=None, data=None: (0, "global", "")
    assert virtual.get_virtual_facts()['container'] == 'zone'

# Generated at 2022-06-23 02:36:32.207247
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    import os
    import pytest

# Generated at 2022-06-23 02:36:37.891635
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # @todo
    # test all results in "virtual_facts"
    # it would be great to run this test on different types of vm's
    # (e.g. virtualbox, vmware, zone, ...)
    # The test should also run on a Solaris host itself.
    module = None
    vm = SunOSVirtual(module)
    print(vm.get_virtual_facts())


# Generated at 2022-06-23 02:36:48.475048
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from . import utils
    from ansible.module_utils.facts.virtual.sunos_virtual import SunOSVirtual
    collect_subset = ['!all', 'virtual']
    utils.collect_subset = collect_subset
    utils.facts_module.params = { 'gather_subset': collect_subset }
    utils.facts_module.exit_json = utils.exit_json
    sunos_virtual = SunOSVirtual(utils.facts_module)

    # Test the case where this is a zone
    utils.is_zone = True
    utils.zonename = "/global"
    sunos_virtual_facts = sunos_virtual.get_virtual_facts()
    assert len(sunos_virtual_facts) == 3

# Generated at 2022-06-23 02:36:49.863486
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    result = SunOSVirtual(dict())
    assert result is not None



# Generated at 2022-06-23 02:36:55.989018
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Unit test to see if SunOSVirtualCollector can be created

# Generated at 2022-06-23 02:36:57.424471
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.vendor == 'SunOS'

# Generated at 2022-06-23 02:37:00.167247
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    sunos = SunOSVirtual(module)
    assert(isinstance(sunos.get_virtual_facts(), dict))


# Generated at 2022-06-23 02:37:01.185789
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # TODO: implement
    assert(True)

# Generated at 2022-06-23 02:37:04.101729
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict(), "")
    assert(virtual_facts.platform == 'SunOS')
    assert(virtual_facts.get_virtual_facts() is not None)


# Generated at 2022-06-23 02:37:14.182461
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    class MockModule:
        """ Class used to mock a module """

        def __init__(self):
            self._commands_results = {}
            self._bin_path = {}

        def get_bin_path(self, command):
            return self._bin_path[command]

        def fail_json(self, msg):
            pass

        def exit_json(self, changed=False, ansible_facts=None):
            """ Successfully exit the module """

            if ansible_facts is None:
                ansible_facts = {}

            self.exit_args = {'changed': changed, 'ansible_facts': ansible_facts}


# Generated at 2022-06-23 02:37:17.176386
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
	sv = SunOSVirtual({})
	assert sv.virtualization_type == 'zone'
	assert sv.virtualization_role == 'guest'
	assert sv.container == 'zone'


# Generated at 2022-06-23 02:37:19.036691
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:37:29.924464
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Run the constructor of class SunOSVirtual.  The constructor
    is responsible for setting the following attributes:

    - platform
    - virtualization_type
    - virtualization_role
    - container
    """
    # Run the SunOSVirtual constructor.  We are
    # not running on SunOS.  We must get back
    # the following answers:
    #
    #  platform = 'SunOS'
    #  virtualization_type = ('zone', 'global_zone')
    #  virtualization_role = 'unknown'
    #  container = 'unknown'
    #
    test_obj = SunOSVirtual(dict())
    assert test_obj.platform == 'SunOS'
    assert test_obj.virtualization_type == 'unknown'
    assert test_obj.virtualization_role == 'unknown'
    assert test_

# Generated at 2022-06-23 02:37:31.648918
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    l = SunOSVirtualCollector()
    assert isinstance(l, SunOSVirtualCollector)

# Generated at 2022-06-23 02:37:41.576982
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Return virtual facts (e.g. virtualization_type, virtualization_role and container) on SunOS.
    This test uses mocked ouput to unit test method get_virtual_facts.
    """
    # Fire a class
    sunos_virtual = SunOSVirtual()

    # Constant that contains the expected output
    EXPECTED_FACTS_VIRTUAL = dict(
        virtualization_type='kvm',
        virtualization_role='guest',
        virtualization_tech_guest=set(['kvm']),
        virtualization_tech_host=set(),
        container='zone'
    )
    # This dict contains all the mocked output of the commands that are executed by the method get_virtual_facts

# Generated at 2022-06-23 02:37:43.872264
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = dict()
    collector = SunOSVirtualCollector(None, facts, None)
    assert isinstance(collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:37:46.817873
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c
    assert isinstance(c._fact_class, SunOSVirtual)
    assert c._platform == 'SunOS'

# Generated at 2022-06-23 02:37:56.621134
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class MockModule(object):
        @staticmethod
        def get_bin_path(path):
            return path

        @staticmethod
        def run_command(command, check_rc=True):
            rc = 0
            out = ''
            err = ''
            if command == '/usr/sbin/smbios':
                rc = 0
                out = 'System Information\nManufacturer: VMware, Inc.\nProduct Name: VMware Virtual Platform\nVersion: None'
            elif command == 'zonename':
                rc = 0
                out = 'global'
            elif command == '/usr/sbin/virtinfo':
                rc = 0
                out = ''
            elif command == 'modinfo':
                rc = 0

# Generated at 2022-06-23 02:38:00.765454
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.params = {'gather_subset': '!all,!min'}

    obj = SunOSVirtual(module=module)
    assert isinstance(obj, SunOSVirtual)
    assert obj.module == module


# Generated at 2022-06-23 02:38:03.519001
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:38:04.527616
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector


# Generated at 2022-06-23 02:38:09.454529
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeModule({})
    facts = SunOSVirtualCollector(module).collect()
    assert facts['ansible_virtualization_type'] == 'zone'
    assert facts['ansible_virtualization_role'] == 'guest'
    assert facts['ansible_container'] == 'zone'

# Generated at 2022-06-23 02:38:14.894469
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = MagicMock()
    module.run_command.return_value = (0, 'Fake output', '')
    module.get_bin_path.return_value = True

    vc = SunOSVirtualCollector(module=module)
    assert vc.platform == 'SunOS'
    assert isinstance(vc.virtual, SunOSVirtual)


# Generated at 2022-06-23 02:38:23.748009
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test SunOSVirtual.get_virtual_facts on a global zone which is not virtualized
    # Test data is a class with attributes:
    #   - rc (return code of a command)
    #   - out (output of a command)
    #   - err (error output of a command)
    test_data = type('module', (object,), {})()
    test_data.get_bin_path = lambda *args, **kwargs : '/bin'
    test_data.run_command = lambda *args, **kwargs : (0, 'global\n', '')
    # fill in the test data for the required modules
    test_SunOSVirtual = SunOSVirtual(module=test_data)
    result = test_SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-23 02:38:25.199630
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:38:27.030351
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtualCollector = SunOSVirtualCollector()
    assert sunos_virtualCollector.platform == 'SunOS'

# Generated at 2022-06-23 02:38:39.114015
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = type('', (object,), {'get_bin_path': lambda self, arg: arg})
    test_module.run_command = lambda self, cmd: (0, 'line1\nline2\nline3', '')
    test_obj = SunOSVirtual(test_module)

    # Test with no output
    test_module.run_command = lambda self, cmd: (1, '', '')
    assert test_obj.get_virtual_facts() == {}

    # Test with an error in output
    test_module.run_command = lambda self, cmd: (0, 'Cannot run virtinfo', '')
    assert test_obj.get_virtual_facts() == {}

    # Test with different output

# Generated at 2022-06-23 02:38:43.554807
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector(None)
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class.platform == 'SunOS'
    assert virtual_collector._fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-23 02:38:51.572276
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    sunosv = SunOSVirtual(module)

    # When the system is not virtualized
    assert sunosv.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # When the system is a zone
    module.run_command_values['zonename'] = 0, 'non-global', ''
    assert sunosv.get_virtual_facts() == {
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set(),
        'container': 'zone'
    }

    # When the system is a branded zone
    module.run_command_values['zonename'] = 0,

# Generated at 2022-06-23 02:38:56.148558
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no arguments
    SunOSVirtualCollector()

    # Test with a custom fact class
    class TestVirtual(Virtual):
        pass
    SunOSVirtualCollector(fact_class=TestVirtual)

    # Test with a custom platform
    SunOSVirtualCollector(platform='custom_platform')

# Generated at 2022-06-23 02:38:58.045079
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert type(collector) is SunOSVirtualCollector

# Generated at 2022-06-23 02:39:08.609486
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def mock_run_command(module, command):
        # zone
        if command.endswith('zonename'):
            return 0, 'global', ''
        # branded zone
        if command.endswith('pkginfo'):
            return 0, '', ''
        # global zone
        if command.endswith('modinfo'):
            return 0, 'VirtualBox', ''
        # domaining
        if command.endswith('virtinfo'):
            return 0, 'DOMAINROLE|impl=LDoms|control=true|io=true|service=true|root=false', ''

    import ansible.module_utils.facts.virtual.sunos
    m = ansible.module_utils.facts.virtual.sunos.SunOSVirtual({})
    m.run_command = mock_run_command
   

# Generated at 2022-06-23 02:39:14.894204
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.utils.virtual import SunOSVirtual
    from ansible.module_utils.facts import ModuleArgsParser

    fake_module = ModuleArgsParser.parse_kv('foo=bar')
    fake_module.run_command = lambda *args, **kwargs: (0, "", "")
    fake_module.get_bin_path = lambda *args: True

    virt = SunOSVirtual(fake_module)
    facts = virt.get_virtual_facts()

    assert 'vmware' not in facts['virtualization_tech_guest']
    assert 'zone' not in facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:39:21.228656
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Create an empty module object
    module = AnsibleModuleMock()

    # Create an empty class object of class SunOSVirtual
    virtual = SunOSVirtual(module)

    assert virtual.possible_sources == ['/proc/vz', '/.SUNWnative']

    assert virtual.platform == 'SunOS'

    assert virtual.distribution == 'SunOS'

# Generated at 2022-06-23 02:39:32.411962
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    A unit test for the SunOSVirtual() class.
    """
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual

    # Initialize an object of class Virtual() using SunOSVirtual.
    obj = SunOSVirtual()

    # The name of the class should be equal to the argument passed.
    assert obj.__class__.__name__ == "SunOSVirtual"

    # All the attributes of the class should be present.
    assert set(obj.__class__.__dict__) == {'__init__', 'platform',
                                           'get_virtual_facts'}

    # The parent type of the derived class should be Virtual().
    assert type(obj) == Virtual

# Generated at 2022-06-23 02:39:34.614985
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual = SunOSVirtual(module)
    assert virtual.platform  == 'SunOS'



# Generated at 2022-06-23 02:39:43.297006
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create Virtual class object
    virtualObj = SunOSVirtual()
    virtualObj.module.run_command = Mock()

    # Test get_virtual_facts method of SunOSVirtual
    virtualObj.module.run_command.return_value = [0, "global", ""]
    virtual_facts = virtualObj.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert 'virtualization_tech_guest' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert 'container' not in virtual_facts

    # Test get_virtual_facts method of SunOSVirtual when get_virtual_facts method
    # of parent Virtual class fails to execute

# Generated at 2022-06-23 02:39:51.339859
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    collector = SunOSVirtual(module)
    facts = collector.get_virtual_facts()
    assert facts == {
        'container': 'global',
        'virtualization_role': 'guest',
        'virtualization_type': 'parallels',
        'virtualization_tech_guest': {'parallels'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:39:53.315228
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(), dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:39:57.191059
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:40:02.034874
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Create a SunOSVirtual object
    """
    # Create a Solaris-like object instance
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'
    # Solaris-like object has no subtype
    assert not hasattr(virtual, 'subtype')
    # Solaris-like object has no version
    assert not hasattr(virtual, 'version')

# Generated at 2022-06-23 02:40:03.590438
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(None)
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:40:07.840285
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts_dict = SunOSVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in facts_dict
    assert 'virtualization_role' in facts_dict
    assert 'virtualization_tech_guest' in facts_dict
    assert 'virtualization_tech_host' in facts_dict
    assert 'container' in facts_dict

# Generated at 2022-06-23 02:40:16.394056
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('module', (object,), {})()
    module.run_command = lambda *args, **kwargs: (0, "", "")
    module.get_bin_path = lambda *args, **kwargs: "/usr/sbin/"
    module.params = {}
    test = SunOSVirtual(module)

    # Test an empty list
    module.run_command = lambda *args, **kwargs: (1, "", "")
    assert test.get_virtual_facts() == {}

# Generated at 2022-06-23 02:40:19.671852
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock({})
    virt = SunOSVirtual(module)
    assert virt is not None
    assert virt.module is not None
    assert virt.platform == 'SunOS'



# Generated at 2022-06-23 02:40:20.718657
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector

# Generated at 2022-06-23 02:40:24.290032
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = SunOSVirtualCollector()
    assert isinstance(module, SunOSVirtualCollector)



# Generated at 2022-06-23 02:40:33.028318
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/zonename')
    os.path.isdir = MagicMock(side_effect=lambda x: x == '/.SUNWnative')
    module.path_exists = MagicMock(side_effect=lambda x: x == '/proc/vz')
    module.get_bin_path = MagicMock(return_value=None)

    sv = SunOSVirtual(module)


# Generated at 2022-06-23 02:40:35.062979
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:41.913055
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == "SunOS"
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert isinstance(sunos_virtual_collector._fact_class({}), SunOSVirtual)


# Generated at 2022-06-23 02:40:47.508196
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    virtual_fact_collector = SunOSVirtual(module)
    virtual_facts = virtual_fact_collector.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'xen'



# Generated at 2022-06-23 02:40:58.214298
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual


# Generated at 2022-06-23 02:41:00.153555
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj1 = SunOSVirtualCollector()
    assert obj1 is not None
    assert obj1._platform == 'SunOS'
    assert obj1._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:41:01.532006
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:41:04.013327
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc._platform == 'SunOS'
    assert svc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:06.852181
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # check only run on SunOS platforms
    try:
        module = AnsibleModuleMock()
        vg = SunOSVirtualCollector(module=module)
        assert vg
    except:
        pass

# Generated at 2022-06-23 02:41:08.580578
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test that the SunOSVirtualCollector class can be instantiated.
    """
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:15.491383
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('Module', (object,), dict())
    setattr(module, 'run_command', lambda x: (0, '0', ''))
    setattr(module, 'get_bin_path', lambda x: '/usr/sbin/' + x if x == 'smbios' else None)
    sunos = SunOSVirtual(module)
    assert sunos.platform == 'SunOS'
    assert sunos.get_virtual_facts() is None

# Generated at 2022-06-23 02:41:25.333828
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    class DummyModule(object):

        def __init__(self):
            self.params = {}
            self.exit_json = lambda x, **kw: None

        @staticmethod
        def run_command(arg):
            return 0, '', ''

    dummy_module = DummyModule()
    VirSunOS = SunOSVirtual(dummy_module)

    assert 'virtualization_type' not in VirSunOS.get_virtual_facts()
    assert 'virtualization_role' not in VirSunOS.get_virtual_facts()

    collector.add_collector(SunOSVirtualCollector)

# Generated at 2022-06-23 02:41:32.282010
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize the Data Retrieval classes
    module = get_module(dict())
    facts_collector = SunOSVirtualCollector(module=module)
    facts = facts_collector.collect()
    virtual_facts = facts['ansible_virtualization_facts']

    # Test method get_virtual_facts of class SunOSVirtual
    SunOSVirtual_get_virtual_facts = SunOSVirtual(module=module)
    virtual_facts_dict = SunOSVirtual_get_virtual_facts.get_virtual_facts()
    for item in virtual_facts_dict:
        if item in virtual_facts:
            assert virtual_facts[item] == virtual_facts_dict[item]
        else:
            assert item in virtual_facts_dict

# Generated at 2022-06-23 02:41:35.792352
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector is not None
    assert collector.platform == 'SunOS'
    assert collector._fact_class is SunOSVirtual


# Generated at 2022-06-23 02:41:49.589575
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts
    of class SunOSVirtual
    """
    import sys
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    if sys.version_info[0] < 3:
        from mock import Mock
    else:
        from unittest.mock import Mock

    # Test 1, global zone
    module = Mock()
    env = Mock()
    facts = Mock()
    virtual = SunOSVirtual(module=module, env=env, facts=facts)

    module.run_command.return_value = (0, "global", "")

    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:42:01.010984
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    with open('/proc/zoneinfo') as f:
        zoneinfo = f.read()

    zonename = '/bin/zonename'
    modinfo = '/sbin/modinfo'
    virtinfo = '/usr/sbin/virtinfo'
    smbios = '/usr/sbin/smbios'

    module = Mock()
    module.run_command = Mock()
    module.run_command.side_effect = side_effect
    module.get_bin_path = Mock()
    module.get_bin_path.return_value = True

    module.run_command.reset_mock()
    module.run_command.return_value = (0, 'global\n', '')
    module.get_bin_path.return_value = zonename
    virtual_facts = SunOSVirtual(module).get

# Generated at 2022-06-23 02:42:09.542438
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = MockModule()
    module.run_command = Mock(side_effect=run_command_side_effect)

    obj = SunOSVirtual(module)
    obj.get_virtual_facts()

    expected = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'container': 'zone'
    }
    assert obj.facts == expected

    module.run_command.assert_any_call('/usr/bin/zonename')
    module.run_command.assert_any_call('/usr/sbin/virtinfo -p')
    module.run_command.assert_any_call('/usr/sbin/smbios')
    module.run_command

# Generated at 2022-06-23 02:42:12.946691
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # No need to check if it successfully instantiates
    # since the VirtualCollector base class will raise an
    # exception if it can't.
    obj = SunOSVirtualCollector()



# Generated at 2022-06-23 02:42:17.178528
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={})).get_virtual_facts() == {'container': None, 'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': None}

# Generated at 2022-06-23 02:42:19.853421
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual(dict())

if __name__ == '__main__':
    # Unit test for constructor of class SunOSVirtualCollector
    test_SunOSVirtual()

# Generated at 2022-06-23 02:42:21.152792
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    SunOSVirtual(module)



# Generated at 2022-06-23 02:42:21.758188
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({})

# Generated at 2022-06-23 02:42:25.278749
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.__class__.__name__ == 'SunOSVirtualCollector'
    assert collector.fact_class.__name__ == 'SunOSVirtual'
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 02:42:36.441645
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # If a solaris zone is not virtualized, the output of 'modinfo' should be an empty string
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))

    # If it's a solaris zone, the output of 'zonename' should be not equal to "global"
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))

    # If a solaris zone is virtualized, the output of 'modinfo' should contain the words 'vmware' or 'virtualbox'
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-23 02:42:44.466683
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test cases are formed by a tuple of (<inputs>, <expected_results>)
    # Inputs is a dictionary of options to install as file in the expected
    # locations (e.g. /usr/sbin/vminfo)
    # Expected results is another dictionary of what is expected to be
    # present in the facts after running the get_virtual_facts method.

    # Test 1: we are in a Solaris 8 branded zone.
    test_case = ({
        "/usr/sbin/vminfo": "#!/usr/bin/env bash\necho \"VMware\"",
        "/.SUNWnative": ""
    }, {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'container': 'zone'
    })


# Generated at 2022-06-23 02:42:46.405259
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Verify that a new object can be constructed.
    try:
        SunOSVirtual(dict())
    except Exception:
        assert 0

# Generated at 2022-06-23 02:42:54.572091
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'global', ''))
    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    assert 'zone' in facts['virtualization_tech_host']
    assert 'zone' not in facts['virtualization_tech_guest']
    assert not 'virtualization_role' in facts
    assert not 'container' in facts
    module.run_command = Mock(return_value=(0, 'global', ''))


# Generated at 2022-06-23 02:42:57.274632
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:09.497734
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # VirtualBox
    module = get_module_mock(dict(
        command='/usr/sbin/smbios',
        rc=0,
        stdout='\n'
               'VirtualBox\n'
               'Manufacturer: innotek GmbH\n'
               'Product Name: VirtualBox\n'
               'Version: 1.2\n'
               'Serial Number: 0\n'
               'UUID: 44454c4c-5300-1063-8051-b3c04f443443\n'
               'Wake-up Type: 6\n'
               'SKU Number: Not Specified\n'
               'Family: Not Specified\n'
    ))
    SunOSVirtual(module).get_virtual_facts()
    module.exit_json.assert_called_with

# Generated at 2022-06-23 02:43:13.089290
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type == 'zone'
    assert virtual.virtualization_role == 'guest'
    assert virtual.virtualization_tech_guest == {'zone'}

# Generated at 2022-06-23 02:43:18.298400
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)

    # get_virtual_facts is a virtual method and cannot be tested directly
    # instead, check if the method is implemented in this class, to ensure
    # that the implementation was changed in the subclass.
    assert hasattr(virtual, 'get_virtual_facts')
    assert 'get_virtual_facts' in virtual.__class__.__dict__

# Generated at 2022-06-23 02:43:27.938703
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of SunOSVirtual
    """
    module = FakeModule()
    SunOS = SunOSVirtual(module=module)

    # 1st test: zone in global zone
    module.set_command_response('zonename', 'global', 0)
    # No modinfo command: no hypervisor detected
    assert SunOS.get_virtual_facts() == {
        'virtualization_role': 'host',
        'virtualization_type': 'zone',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['zone']),
    }

    # 2nd test: zone in non global zone
    module.set_command_response('zonename', 'test', 0)
    # No modinfo command: no hypervisor detected
    assert SunOS.get_virtual_facts

# Generated at 2022-06-23 02:43:31.413260
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunosVirtualCollector:
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector.platform == 'SunOS'

# Generated at 2022-06-23 02:43:40.007370
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructing a SunOSVirtualCollector() object does not raise any
    exception and returns a SunOSVirtualCollector object.
    """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    c = SunOSVirtualCollector()
    assert isinstance(c, SunOSVirtualCollector)
    assert isinstance(c, Collector)
    assert isinstance(c._fact_class, SunOSVirtual)
    assert c._platform == 'SunOS'


# Generated at 2022-06-23 02:43:42.689284
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.collector import VirtualCollector
    obj = SunOSVirtualCollector()
    assert isinstance(obj, VirtualCollector)

# Generated at 2022-06-23 02:43:44.465073
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_sunos = SunOSVirtual()
    assert virtual_facts_sunos is not None

# Generated at 2022-06-23 02:43:47.800988
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.guest_tech_facts == set()
    assert virtual_facts.host_tech_facts == set()


# Generated at 2022-06-23 02:43:48.896234
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:53.322481
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        ),
        supports_check_mode=True)
    result = {}
    result['get_virtual_facts'] = SunOSVirtual(module).get_virtual_facts()
    module.exit_json(ansible_facts=result)



# Generated at 2022-06-23 02:43:55.208767
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts._platform == 'SunOS'

# Generated at 2022-06-23 02:43:59.154108
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:44:00.672137
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)



# Generated at 2022-06-23 02:44:08.258095
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/tmp/zonename"

    SunOSVirtual(module).get_virtual_facts()

    module.run_command.called_once_with("/usr/sbin/virtinfo -p")

# Generated at 2022-06-23 02:44:09.479259
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vm = SunOSVirtual()
    assert vm.platform == 'SunOS'

# Generated at 2022-06-23 02:44:13.073886
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.virtualization_type is None
    assert virtual_facts.virtualization_role is None
    assert len(virtual_facts.virtualization_tech_host) == 0
    assert len(virtual_facts.virtualization_tech_guest) == 0
    assert virtual_facts.container is None

# Generated at 2022-06-23 02:44:15.617771
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual, "SunOSVirtual class should be used"

# Generated at 2022-06-23 02:44:16.677900
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MockModule()
    SunOSVirtual(module)

# Generated at 2022-06-23 02:44:25.466206
# Unit test for constructor of class SunOSVirtual

# Generated at 2022-06-23 02:44:36.109285
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    module.run_command = Mock(return_value=(0, "solaris-globalzone", ""))
    module.get_bin_path = Mock(side_effect=lambda x: "/usr/sbin/%s" % x)

    virtual_collector = SunOSVirtualCollector(module=module)
    facts = virtual_collector.collect()

    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'host'
    assert facts['container'] == 'zone'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:44:46.387189
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()

    module.run_command.commands_results = {
        '/usr/sbin/virtinfo -p': (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''),
        '/usr/sbin/zonename': (0, 'global', ''),
        '/usr/sbin/modinfo': (0, '', ''),
    }

    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'ldom'
    assert virtual_facts['virtualization_tech_host'] == set()