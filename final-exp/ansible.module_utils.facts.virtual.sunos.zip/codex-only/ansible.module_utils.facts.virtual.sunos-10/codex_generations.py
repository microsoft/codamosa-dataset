

# Generated at 2022-06-23 02:34:39.197668
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:34:41.574755
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_virtual = SunOSVirtual()

    assert sun_virtual.platform is 'SunOS'
    assert sun_virtual.get_virtual_facts() is not None

# Generated at 2022-06-23 02:34:53.533904
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pytest

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    # This is just a dummy object without any attributes. The SunOSVirtual class should use its own attributes.
    dummy_module = object()

    # Before we can create a SunOSVirtual object we must replace the import statement in the module
    # ansible.module_utils.facts.virtual.sunos.SunOSVirtual. The import statement is only allowed to run once
    # because the Python interpreter caches the imported module.
    # This test method is executed multiple times in the same interpreter context. The import of
    # ansible.module_utils.facts.virtual.base.Virtual would result in an AttributeError because the class Virtual
    # does not exist after the first run of

# Generated at 2022-06-23 02:34:57.668639
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type == 'xen'
    assert virtual.virtualization_role == 'guest'


# Generated at 2022-06-23 02:34:59.568942
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosv = SunOSVirtual(dict(module=dict()))
    assert sunosv.platform == 'SunOS'


# Generated at 2022-06-23 02:35:10.756357
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    facts_collector = SunOSVirtual(module=module)

    # Simulate a Solaris 8 zone
    facts_collector._facts['system'] = 'SunOS'
    facts_collector._facts['distribution'] = 'SunOS'
    facts_collector._facts['distribution_major_version'] = '8'
    facts_collector._module.get_bin_path = lambda x: x
    facts_collector._module.run_command = lambda x: (2, 'not-a-global-zone', '')
    facts_collector._SunOSVirtual__is_zone = lambda: True
    facts_collector._SunOSVirtual__is_brand_zone = lambda: True
    facts_collector.get_virtual_facts()
    assert facts_collector.virtual

# Generated at 2022-06-23 02:35:16.920638
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test = SunOSVirtual()
    test.module.run_command = lambda *_, **kwargs: [0, '', '']
    test.module.get_bin_path = lambda *_: '/bin/zonename'
    assert test.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': {'zone'}, 'container': 'zone'}

# Generated at 2022-06-23 02:35:26.931460
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import Virtual
    import ast

    # Create a fake module for the unit test
    fake_module = type('AnsibleModule', (object,), {
        'get_bin_path': SunOSVirtual.get_bin_path,
        'run_command': SunOSVirtual.run_command,
    })

    # Create a fake AnsibleModule object
    module = fake_module()

    # Create a SunOSVirtual object
    test_object = SunOSVirtual(module)

    # Unit test the get_virtual_facts() method
    fake_zonename_out = """global"""
    fake_zonename_rc = 0
    fake_zonename_err = ""

# Generated at 2022-06-23 02:35:28.132475
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyModule()
    SunOSVirtualCollector(module)



# Generated at 2022-06-23 02:35:29.630162
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v_collector = SunOSVirtualCollector()
    assert v_collector._platform ==  'SunOS'

# Generated at 2022-06-23 02:35:31.392460
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    virtual = SunOSVirtual(module=module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:35:38.315563
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = {
        'zonename': '/usr/bin/zonename',
        'virtinfo': '/usr/sbin/virtinfo',
        'smbios': '/usr/sbin/smbios',
    }.get
    module.run_command.side_effect = {
        '/usr/bin/zonename': (0, 'global', ''),
        '/usr/sbin/virtinfo': (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=true|root=false', ''),
        '/usr/sbin/smbios': (0, 'Sun Fire X4450, No VMware, BIOS 2008.02.20', '')
    }.get


# Generated at 2022-06-23 02:35:43.178714
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # instantiate Virtual class
    sun_virtual = SunOSVirtual(module=None)

    # check virtualization_type
    assert sun_virtual.virtualization_type == 'zone'

    # check virtualization_role
    assert sun_virtual.virtualization_role == 'guest'

    # check container
    assert sun_virtual.container == 'zone'

# Generated at 2022-06-23 02:35:49.473474
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Create a SunOSVirtual object and a module mock
    virtual_obj = SunOSVirtual(None)
    module_mock = MockSunOSModule()

    # Set module mock to the SunOSVirtual object
    virtual_obj.module = module_mock

    # Get the virtual facts
    virtual_facts_dict = virtual_obj.get_virtual_facts()

    # Check towards expected dictionary
    assert virtual_facts_dict == expected_virtual_facts

# A mock class for AnsibleModule

# Generated at 2022-06-23 02:35:57.018203
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = Mock()

    module_mock.run_command.return_value = (0, 'global', '')
    module_mock.get_bin_path.return_value = 'zonename'

    SunOSVirtual_obj = SunOSVirtual(module_mock)

    # Test get_virtual_facts method with a global zone
    assert SunOSVirtual_obj.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    module_mock.run_command.return_value = (0, 'zone_1', '')

    # Test get_virtual_facts method with a zone

# Generated at 2022-06-23 02:36:05.651252
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_section = {
        "container": None,
        "virtualization_role": None,
        "virtualization_type": None,
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set(),
    }
    module = type("AnsibleModule", (object,), {"run_command": run_command_mock})()
    sunosvirtual_obj = SunOSVirtual(module)
    assert sunosvirtual_obj.get_virtual_facts() == virtual_section


# Generated at 2022-06-23 02:36:12.225989
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    module.get_file_content = get_file_content
    module.fail_json = fail_json
    module.exit_json = exit_json
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict), "'virtual_facts' is not a dict"


# Generated at 2022-06-23 02:36:14.742839
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == "SunOS"

# Generated at 2022-06-23 02:36:19.687521
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    c = SunOSVirtualCollector(module)
    assert isinstance(c._fact_class, SunOSVirtual)
    assert c._platform == 'SunOS'


# Generated at 2022-06-23 02:36:26.037507
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    collector = SunOSVirtualCollector(module=module)
    virtual_facts = collector.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == 'SunOS')
    assert(virtual_facts['virtualization_role'] == 'baremetal')
    assert(virtual_facts['virtualization_tech_guest'] == set())
    assert(virtual_facts['virtualization_tech_host'] == set())

# Generated at 2022-06-23 02:36:40.000661
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of SunOSVirtual
    obj = SunOSVirtual({})

    # Test zone
    class ReturnValue:
        rc = 0
        out = "global"
        err = ""
    setattr(obj.module, 'run_command', lambda *args, **kwargs: ReturnValue)
    expected = {'container': 'zone', 'virtualization_role': 'host', 'virtualization_type': 'zone', 'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set([])}
    assert expected == obj.get_virtual_facts()

    # Test dom
    ReturnValue.out = "non-global"

# Generated at 2022-06-23 02:36:46.276339
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.supported() == True
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.container == None

    assert virtual_facts._platform is not None
    assert virtual_facts._fact_class is not None
    assert virtual_facts._fact_class.platform is not None


# Generated at 2022-06-23 02:36:57.455408
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.test.test_virtual import TestVirtual
    module = TestVirtual()
    module.command = 'test_cmd'
    module.get_bin_path = lambda x: 'path_' + x
    module.run_command = lambda x:['rc', 'out', 'err']
    module.params = {}
    os_virt = SunOSVirtual(module)
    assert os_virt.get_virtual_facts() == {}

    module.params['container'] = 'zone'
    os_virt = SunOSVirtual(module)

# Generated at 2022-06-23 02:37:02.126026
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    runner = SunOSVirtualCollector()
    assert runner is not None, "Failed to create SunOSVirtualCollector"
    assert runner._fact_class == SunOSVirtual, "Failed to set _fact_class on SunOSVirtualCollector"
    assert runner._platform == 'SunOS', "Failed to set _platform on SunOSVirtualCollector"

# Generated at 2022-06-23 02:37:04.571955
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual
    assert virtual._collector_class == SunOSVirtualCollector

# Generated at 2022-06-23 02:37:07.894083
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:37:16.005458
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import types
    module = types.ModuleType('ansible.module_utils.facts.virtual.sunos')
    module.run_command = lambda x: (0, 'global', '')
    module.get_bin_path = lambda x: x
    module.exit_json = lambda x: x
    module.params = {}
    module.fail_json = lambda x: x
    module.Virtual = SunOSVirtual
    module.VirtualCollector = SunOSVirtualCollector

    module.Virtual.module = module
    module.Virtual.container = 'testcontainer'
    module.Virtual.virtualization_type = 'testvirtualizationtype'
    module.Virtual.virtualization_role = 'testvirtualizationrole'

    mdict = SunOSVirtual.get_virtual_facts(module)


# Generated at 2022-06-23 02:37:18.641476
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == "SunOS"
    assert collector._fact_class.platform == "SunOS"

# Generated at 2022-06-23 02:37:29.589097
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class TestAnsibleModule:
        def __init__(self):
            self.params = {}
            self.run_command_calls = 0
            self.run_command_rcs = {}
            self.run_command_outputs = {}
            self.run_command_exceptions = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'modinfo':
                return '/usr/sbin/modinfo'
            if arg == 'zonename':
                return '/usr/bin/zonename'
            if arg == 'smbios':
                return '/usr/sbin/smbios'

        def fail_json(self, **args):
            raise Exception(args)


# Generated at 2022-06-23 02:37:34.730123
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Mocking module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Mocking methods
    module.run_command = MagicMock(return_value=(0, 'test\nsecond line', ''))
    module.get_bin_path = MagicMock(return_value='/bin/test')

    # Unit test
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-23 02:37:36.493744
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual is not None

# Generated at 2022-06-23 02:37:38.982732
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict())
    assert virt.platform == 'SunOS'
    assert virt.get_virtual_facts() == {}


# Generated at 2022-06-23 02:37:42.329923
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    print(x)
    assert x.platform == 'SunOS'

# get_virtual_facts unit test for class SunOSVirtual

# Generated at 2022-06-23 02:37:52.896807
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Set up necessary mocks
    module = AnsibleModuleMock({})

    # Return value of AnsibleModuleMock.run_command = (0, out, None)
    run_command_zonename = ("global", "", None)
    module.run_command = Mock(return_value=run_command_zonename)
    module.get_bin_path = Mock(return_value="/bin/zonename")
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_role'] == 'host'

    # Return value of AnsibleModuleMock.run_command = (1, out, err)
    run_command_zonename = (1, "", "")
    module.run_

# Generated at 2022-06-23 02:37:57.660965
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = {}
    setattr(module, 'run_command', lambda *args, **kwargs: (0, '', ''))
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/usr/bin/zonename')
    virtual_facts = SunOSVirtual(module)
    assert virtual_facts._platform == 'SunOS'
    assert virtual_facts.supported is True


# Generated at 2022-06-23 02:38:06.934076
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector works as expected.
    :return:
    """
    # The output of virtinfo is different whether we are on a machine with logical
    # domains ('LDoms') on a T-series or domains ('Domains') on a M-series. Try LDoms first.
    virtinfo_output = """
        DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
        DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
    """
    # The output may also be not formatted and the returncode is set to 0 regardless of the error condition:
    #   virtinfo can only be run from the global zone
    virtinfo_output_error = "virtinfo can only be run from the global zone"

   

# Generated at 2022-06-23 02:38:09.763312
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector(None)
    assert vc
    assert vc._fact_class == SunOSVirtual
    assert vc._platform == 'SunOS'

# Generated at 2022-06-23 02:38:20.219595
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # initialize module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.params = {}

    # initialize SunOSVirtual object
    # Testing "get_virtual_facts" method
    sunos = SunOSVirtual(module)
    module.run_command = MagicMock(return_value=(0, 'global\n', ''))
    facts = sunos.get_virtual_facts()
    assert facts['container'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone'])

# Generated at 2022-06-23 02:38:22.510654
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:38:26.885478
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # We require module_utils.basic for this test, mock it here to avoid unintentional dependency
    # This should probably be moved to the unit test which tests for the correct function calls of
    # the VirtualCollector class.
    from ansible.module_utils.facts import collector
    collector.module_utils = None

    SunOSVirtual()

# Generated at 2022-06-23 02:38:30.156880
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_instance = SunOSVirtual({}, {})
    assert isinstance(virtual_facts_instance, SunOSVirtual)

# Generated at 2022-06-23 02:38:35.150138
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    my_virt = SunOSVirtual({'platform': 'SunOS'})
    assert my_virt.platform == 'SunOS'
    assert my_virt.options is not None
    assert my_virt.add_cmd_output is not None
    assert my_virt.fail_json is not None
    assert my_virt.module is not None

# Generated at 2022-06-23 02:38:38.821353
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert isinstance(virtual_facts, SunOSVirtual)
    assert isinstance(virtual_facts, Virtual)
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:38:42.482519
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c.fact_class == SunOSVirtual
    assert c.fact_class({}).platform == 'SunOS'

# Generated at 2022-06-23 02:38:51.137447
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual

    # Check with a module that is not zoned
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/' + x
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert sorted(virtual_facts['virtualization_tech_host']) == []
    assert sorted(virtual_facts['virtualization_tech_guest']) == []
    assert sorted(virtual_facts.keys()) == ['virtualization_tech_guest', 'virtualization_tech_host']

    # Check with a module that is zoned
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/' + x

# Generated at 2022-06-23 02:38:59.480699
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_info = {'virtualization_type': 'kvm',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': {'kvm'}}

    sunos_virtual = SunOSVirtual(virtual_info)
    assert sunos_virtual.virtualization_type == 'kvm'
    assert sunos_virtual.virtualization_role == 'guest'
    assert sunos_virtual.virtualization_tech_guest == {'kvm'}
    assert sunos_virtual.virtualization_tech_host == set()


# Generated at 2022-06-23 02:39:09.862603
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyModule()

    # Define virtualization_type, virtualization_role and container for a zone
    module.run_command = Mock(side_effect=[(0, "global\n", ""),
                                           (0, "", ""),
                                           (0, "", "")])
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'zone'}

    # Define virtualization_type, virtualization_role and container for a non-global zone
    module

# Generated at 2022-06-23 02:39:13.585603
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class MockModule():
        def __init__(self):
            self.params = None
            self.exit_json = None
        def fail_json(self, msg, **kwargs):
            raise Exception('fail_json')

    facts = {
        'kernel': 'SunOS',
    }
    module = MockModule()
    collector = SunOSVirtualCollector(module=module, facts=facts)

    # Test constructor
    assert collector.platform == 'SunOS'
    assert collector.module == module
    assert collector.facts == facts
    assert collector._fact_class == SunOSVirtual
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:39:22.364653
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = get_module_mock()
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.return_value = None
    facts = SunOSVirtual(module).get_virtual_facts()
    assert not facts
    module.get_bin_path.return_value = 'zonename'
    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['container'] == 'zone'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:39:28.331601
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    ######################################################################
    # Constructor
    ######################################################################
    module = AnsibleModuleMock()
    ######################################################################
    # get_virtual_facts
    ######################################################################
    virtual = SunOSVirtual(module)
    result = virtual.get_virtual_facts()
    assert isinstance(result, (dict, type(None)))

# Generated at 2022-06-23 02:39:37.662848
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of SunOSVirtual for a xen domU.
    # The instance will load the "smbios" program output from a file
    from ansible.module_utils.facts.virtual import SunOSVirtual
    test_obj = SunOSVirtual({}, {}, 'SunOS')
    test_data = {}
    test_data['ansible_virtualization_type'] = 'xen'
    test_data['ansible_virtualization_role'] = 'guest'
    test_data['ansible_container'] = None
    test_data['ansible_virtualization_tech_guest'] = set(['xen'])
    test_data['ansible_virtualization_tech_host'] = set()

    assert test_obj.get_virtual_facts() == test_data


# Generated at 2022-06-23 02:39:38.828249
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:43.559203
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test for classes SunOSVirtualCollector, SunOSVirtual
    virtualCollector = SunOSVirtualCollector()
    virtual = virtualCollector.collect()
    assert virtual.get('virtualization_tech_host') or virtual.get('virtualization_tech_guest')

# Generated at 2022-06-23 02:39:46.999336
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:39:48.658269
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({},{},{})
    assert obj.virtualization is not None

# Generated at 2022-06-23 02:39:51.340381
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == "SunOS"
    assert c.fact_class.platform == "SunOS"


# Generated at 2022-06-23 02:39:55.981714
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'
    # No host or guest virtualization technology detected.
    assert 'virtualization_tech_guest' not in virtual_facts.get_virtual_facts()
    assert 'virtualization_tech_host' not in virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:39:59.002330
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    data = {}
    data['virtual'] = {}
    v = SunOSVirtual(data)
    assert v.data['virtual'] == {}
    assert v.platform == "SunOS"

# Generated at 2022-06-23 02:39:59.566433
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()

# Generated at 2022-06-23 02:40:01.684201
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    fact = SunOSVirtual(module=module)
    assert isinstance(fact, SunOSVirtual)


# Generated at 2022-06-23 02:40:08.650959
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    obj = SunOSVirtual(module=module)
    assert obj.platform == 'SunOS'
    assert obj.module == module

# Generated at 2022-06-23 02:40:20.635940
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """ Test the method get_virtual_facts of class SunOSVirtual """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    sunosvirtual = SunOSVirtual(module)

    # Test 1: zonename is available, zonename reveals that we are a non-global zone
    module.run_command = Mock(return_value=(0, "test", ""))
    assert sunosvirtual.get_virtual_facts() == {'container': 'zone', 'virtualization_type': 'zone',
                                                'virtualization_role': 'guest', 'virtualization_tech_guest': {'zone'},
                                                'virtualization_tech_host': set()}

    # Test 2: zonename is available, zonename reveals that we are a non-global zone,

# Generated at 2022-06-23 02:40:22.099504
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:40:23.473813
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
   vcc = SunOSVirtualCollector('module')

# Generated at 2022-06-23 02:40:27.469365
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts()['virtualization_role'] == 'guest', "get_virtual_facts did not return the expected virtualization_role"


# Generated at 2022-06-23 02:40:36.074061
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test for bad input to class (invalid platform)
    with pytest.raises(AssertionError) as err:
        SunOSVirtual(None, platform='notSunOS')
    assert 'platform can either be undefined (to use the current platform), ' \
           'or it must be SunOS.' in str(err)

    # Test empty constructor
    SunOSVirtual(None)

    # Test constructor with module parameter
    import ansible.module_utils.facts.virtual.sunos as virtual_sunos
    module = virtual_sunos.VirtualModule()
    SunOSVirtual(module)

# Generated at 2022-06-23 02:40:48.555681
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()

    def get_bin_path(self, name, *args, **kwargs):
        return {
            'modinfo': '/usr/sbin/modinfo',
            'smbios': '/usr/sbin/smbios',
            'virtinfo': '/usr/sbin/virtinfo',
            'zonename': '/usr/sbin/zonename',
        }.get(name)

    module.get_bin_path = get_bin_path.__get__(module)

    ldom_poutput = '''DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
'''

    def run_command(self, cmd, *args, **kwargs):
        rc = 0
        out = None
        err = None


# Generated at 2022-06-23 02:40:52.477511
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test class instantiation
    collector = SunOSVirtualCollector()

    # Test '_fact_class' is defined
    assert collector._fact_class is not None
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:55.006183
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}), dict())
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:40:57.136548
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:04.219438
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = {"run_command.return_value": "zone"}
    module_mock = MagicMock(**module)
    set_module_args({})
    with patch.multiple("ansible.module_utils.facts.virtual.sunos.SunOSVirtual",
                        module=module_mock) as mock_dict:
        assert mock_dict["module"].run_command.return_value == "zone"
        obj1 = mock_dict["SunOSVirtual"]
        assert obj1.platform == "SunOS"
        assert obj1.module == module_mock


# Generated at 2022-06-23 02:41:05.203787
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:07.686828
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    host_facts = SunOSVirtual(module)

    assert host_facts.platform == 'SunOS'


# Generated at 2022-06-23 02:41:09.405413
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts.data == {'virtualization_tech': set()}



# Generated at 2022-06-23 02:41:19.582635
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:41:21.270066
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict(module=dict()))

# Generated at 2022-06-23 02:41:22.688569
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule({})
    SunOSVirtual(module)

# Generated at 2022-06-23 02:41:24.386916
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    SunOSVirtual(module).get_virtual_facts()



# Generated at 2022-06-23 02:41:31.756867
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import ansible.module_utils.facts.virtual.base

    class AnsibleModuleMock:
        params = None

        def get_bin_path(self, arg):
            if arg == 'smbios':
                return 'smbios'

            if arg == 'zonename':
                return 'zonename'

            if arg == 'modinfo':
                return 'modinfo'

            if arg == 'virtinfo':
                return 'virtinfo'

            if arg == 'smbios':
                return 'smbios'

            raise Exception('unexpected arg: %s' % arg)

        def run_command(self, cmdargs):
            if cmdargs == 'zonename':
                return 0, 'global\n', ''


# Generated at 2022-06-23 02:41:37.009982
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert (virtual_facts['virtualization_type'] == 'virtualbox')
    assert (virtual_facts['virtualization_role'] == 'guest')
    assert (virtual_facts['container'] == 'zone')

# Test module that can be used in unit test
from ansible.module_utils.facts import ModuleFailException

# Generated at 2022-06-23 02:41:38.217291
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.get_facts() == {}

# Generated at 2022-06-23 02:41:42.686615
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    test_obj = SunOSVirtual()
    assert test_obj.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                            'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:41:45.009765
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.get_virtual_facts()['virtualization_tech_host'] == set()
    assert v.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert v.get_virtual_facts()['virtualization_type'] is None
    assert v.get_virtual_facts()['virtualization_role'] is None
    assert v.get_virtual_facts()['container'] is None

# Generated at 2022-06-23 02:41:54.883035
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Tests get_virtual_facts method of class SunOSVirtual"""

    # Test with a system that
    # - has a brand new branded zone (i.e. Solaris 8/9 zone) installed
    # - has a zone
    # - has a domaining kernel
    # - is running in a domaining environment on Sparc hardware
    mock_module = Mock()
    mocked_facts = {'system_vendor': 'Sun Microsystems'}
    mock_module.return_value = mocked_facts
    test_module = SunOSVirtual(mock_module)
    mocked_get_bin_path = Mock(return_value='/usr/sbin/zonename')
    mocked_run_command = Mock(return_value=(0, 'global', ''))
    test_module.get_bin_path = mocked_get_bin_path

# Generated at 2022-06-23 02:42:07.007898
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Define test data
    facts = {}
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    SunOSVirtual.module = module
    SunOSVirtual.distribution = ''
    SunOSVirtual.distribution_version = ''
    # Test with a guest
    set_module_args({})
    with patch('ansible.module_utils.facts.virtual.base.open', mock_open(read_data='VMware\nVirtualBox\n'), create=True) as mock_file:
        vmware_facts = SunOSVirtual().get_virtual_facts()
        assert vmware_facts['virtualization_type'] == 'vmware'
        assert vmware_facts['virtualization_role'] == 'guest'
    # Test with a host and a guest
    set_module

# Generated at 2022-06-23 02:42:10.751430
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructing VirtualCollector should be success
    :return:
    """
    virtual_collector = SunOSVirtualCollector()
    assert isinstance(virtual_collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:42:13.286565
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'
    assert x.get_virtual_facts() == {}


# Generated at 2022-06-23 02:42:15.732207
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = dict()
    sunos_virtual = SunOSVirtual(virtual_facts, dict())
    assert isinstance(sunos_virtual, SunOSVirtual)

# Generated at 2022-06-23 02:42:25.407776
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('AnsModule', (object,), dict(run_command=lambda *args, **kwargs: (0, '', '')))
    virt = SunOSVirtual({}, module=module)
    module.get_bin_path = lambda key: key
    # On a global zone
    facts = virt.get_virtual_facts()
    assert 'container' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_type' not in facts
    # On a non-global zone
    facts = virt.get_virtual_facts()
    assert 'container' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts

    module = type('AnsModule', (object,), dict(run_command=lambda *args, **kwargs: (0, '', '')))

# Generated at 2022-06-23 02:42:36.530533
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts import virtual

    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

    class TestModule(object):
        def __init__(self):
            self.run_command = builtins.__dict__['__import__']('ansible.module_utils.facts.virtual.sunos').run_command
            self.get_bin_path = builtins.__dict__['__import__']('ansible.module_utils.facts.virtual.sunos').get_bin_path
            self.fail_json = builtins.__dict__['__import__']('ansible.module_utils.facts.virtual.sunos').fail_json


# Generated at 2022-06-23 02:42:39.640665
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a unit test for constructor of class SunOSVirtualCollector
    """
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:42:43.967339
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sunos_virtual = SunOSVirtual()
    facts = sunos_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert 'virtualization_type' not in facts

# Generated at 2022-06-23 02:42:50.592578
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ModuleMock(object):
        def get_bin_path(self, path):
            return '/usr/bin/%s' % path

        def run_command(self, command):
            if command == '/usr/bin/zonename':
                return 0, 'global', ''
            elif command == '/usr/sbin/virtinfo -p':
                return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''
            elif command == '/usr/sbin/modinfo':
                return 0, 'VirtualBox', ''
            elif command == '/usr/sbin/smbios':
                return 0, 'VMware', ''
            elif command == '/usr/sbin/prtdiag':
                return 0, '', ''

# Generated at 2022-06-23 02:42:51.912648
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:42:52.940936
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:00.451536
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # dummy class variable __module__
    SunOSVirtual.__module__ = "ansible_facts.virtual.sunos"
    # dummy class variable platform
    SunOSVirtual.platform = "SunOS"
    # dummy class variable module
    SunOSVirtual.module = "ansible.module_utils.facts.virtual.sunos"
    # initialize the object
    obj = SunOSVirtual()

    # check if it has common attributes
    assert hasattr(obj, 'get_virtual_facts')
    assert hasattr(obj, 'platform')
    assert hasattr(obj, 'module')

# Generated at 2022-06-23 02:43:01.805917
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    Virt = SunOSVirtual(dict())
    assert Virt.platform == 'SunOS'


# Generated at 2022-06-23 02:43:03.410978
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:43:13.995426
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    v = SunOSVirtual(module)

    # Check global zone
    expected_facts_dict = {'virtualization_type': '', 'virtualization_role': '', 'container': '',
                           'virtualization_tech_host': {}, 'virtualization_tech_guest': {}}
    assert expected_facts_dict == v.get_virtual_facts()

    # Check zone with global zone not virtualized
    def run_command1(cmd, *args, **kwargs):
        if cmd == '/usr/sbin/zonename':
            return (0, "testzone\n", "")
        return (1, "", "")
    module.run_command = run_command1

# Generated at 2022-06-23 02:43:15.835601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test instantiation of class SunOSVirtualCollector"""
    x = SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:20.841809
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with empty argument
    virtual_collector = SunOSVirtualCollector({'ansible_facts': {}})
    # Verify that the module parameter is a instance of class SunOSVirtual
    assert isinstance(virtual_collector._SunOSVirtualCollector__module, Virtual)

if __name__ == '__main__':
    # Unit test
    test_SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:26.705939
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    sunos = SunOSVirtual(module)
    rc, out, err = sunos.run_command("/usr/sbin/virtinfo -p")
    if rc == 0:
        facts = sunos.get_virtual_facts()
        assert facts['virtualization_tech_guest'] == {'ldom'}
        assert facts['virtualization_tech_host'] == set()
        assert facts['virtualization_type'] == 'ldom'



# Generated at 2022-06-23 02:43:37.091105
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Set up mock AnsibleModule object
    module = MockAnsibleModule('dummy')

    # Set up a SunOSVirtual object for testing
    virtual = SunOSVirtual(module)

    # Set up mock subprocess objects for testing
    # global zone, non-virtual
    modinfo_global_zone = MockSubproc(rc=0, out='')
    zonename_global_zone = MockSubproc(rc=0, out='global\n')
    smbios_global_zone = MockSubproc(rc=0, out='')
    # global zone, vmware virtualized
    modinfo_global_zone_vmware = MockSubproc(rc=0, out='id: 20 0 0x1094a vmware\n')

# Generated at 2022-06-23 02:43:47.423554
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual instance
    m = SunOSVirtual({'path': '/usr/bin'})
    # Define 'zonename', 'modinfo' and 'smbios' to specific files.
    m.module.get_bin_path = lambda name: 'zonename' if name == 'zonename' else 'modinfo' if name == 'modinfo' else 'smbios'
    # Define some fake return codes and outputs for the calls to run_command() in method get_virtual_facts()
    # of the same instance
    m.module.run_command = lambda cmd: (0, 'global', '') if cmd == 'zonename' else (0, 'VMware', '') if cmd == 'modinfo' else (0, '', '')
    # Call the method to test
    ret = m.get_virtual_facts()

# Generated at 2022-06-23 02:43:50.538292
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.virtualization_type == None
    assert v.virtualization_role == None
    assert v.virtualization_tech_guest == set()
    assert v.virtualization_tech_host == set()

# Generated at 2022-06-23 02:43:57.918879
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    vm = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}, ANSIBLE_MODULE_CONSTANTS={}), basic.AnsibleModule(
    argument_spec=dict()))

    results = vm.get_virtual_facts()
    assert results['virtualization_type'] == 'parallels'
    assert results['virtualization_role'] == 'guest'
    assert 'parallels' in results['virtualization_tech_guest']
    assert not results['virtualization_tech_host']

# Generated at 2022-06-23 02:44:08.647964
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    import platform
    import json
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    virt_module = 'None'
    virt_class = SunOSVirtual(module=virt_module)

    virtual_facts = virt_class.get_virtual_facts()

    if platform.uname()[0] == 'SunOS':
        if virtual_facts['virtualization_type'] == 'xen':
            assert virtual_facts['virtualization_type'] == 'xen'
            assert virtual_facts['virtualization_role'] == 'guest'
            assert virtual_facts['virtualization_tech_host'] == set()
            assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
       

# Generated at 2022-06-23 02:44:10.889011
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no OS-specific data source
    collector = SunOSVirtualCollector(module=None, facts=None)
    assert collector is not None


# Generated at 2022-06-23 02:44:21.015688
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # GIVEN
    module = MockAnsibleModule()
    module.get_bin_path = MagicMock(return_value='/usr/bin/vmware')
    setattr(module.run_command, 'returncode', 0)
    setattr(module.run_command, 'out', 'modinfo: VMware: driver not loaded')
    facts = {}
    # WHEN
    SunOSVirtual().populate(module, facts)
    # THEN
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:44:31.751484
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SUT = SunOSVirtual({'module_setup': True})

    # Initialize facts
    facts = {}
    # Set the current OS platform and distribution
    facts['ansible_os_family'] = 'Solaris'
    facts['ansible_system'] = 'SunOS'

    # Test from_facts() without any facts
    virtual_facts = SUT.from_facts(facts)
    assert len(virtual_facts) == 0

    # Insert facts from a global zone
    facts['ansible_zone'] = 'global'
    virtual_facts = SUT.from_facts(facts)
    assert len(virtual_facts) == 3
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'zone' in virtual_facts['virtualization_tech_host']

    # Insert facts from a zone

# Generated at 2022-06-23 02:44:39.760572
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_LIBVIRT:
        module.fail_json(msg='libvirt is not importable. Check the requirements.')

    if not HAS_XENAPI:
        module.fail_json(msg='xenapi is not importable. Check the requirements.')

    if not HAS_PYVMOMI:
        module.fail_json(msg='pyvmomi is not importable. Check the requirements.')

    SunOSVirtual(module).get_virtual_facts()

