

# Generated at 2022-06-23 02:34:39.822445
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual1 = SunOSVirtualCollector()
    assert virtual1.platform == 'SunOS'

# Generated at 2022-06-23 02:34:48.988637
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class TestModule(object):
        def __init__(self, params={}):
            self.params = params

        def get_bin_path(self, arg):
            return "/usr/bin/%s" % arg

        def run_command(self, arg):
            return 1, '', ''

    module = TestModule({})
    sun = SunOSVirtual(module)

    class RunModuleFail(object):
        def __init__(self, params={}):
            self.params = params

        def get_bin_path(self, arg):
            return "/usr/bin/%s" % arg

        def run_command(self, arg):
            return 1, '', ''

    class RunModulePass(object):
        def __init__(self, params={}):
            self.params = params


# Generated at 2022-06-23 02:34:59.897609
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = lambda *args, **kwargs: (0, "test_output", "")
    module.get_bin_path = lambda *args, **kwargs: "/bin/" + args[0]

    collector = SunOSVirtualCollector(module=module)
    virtual_facts = collector.collect()

    assert virtual_facts is not None
    assert 'container' in virtual_facts
    assert virtual_facts['container'] == 'zone'
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'host (control,root)'
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'ldom'
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:35:02.889005
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    obj = SunOSVirtual(module)
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 02:35:03.670827
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:35:06.782729
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    _fact_class = SunOSVirtualCollector(None)
    assert _fact_class.platform == 'SunOS'
    assert _fact_class._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:35:14.343238
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import sys

    virtual = SunOSVirtual(None)

    class RunModuleMock(object):
        @staticmethod
        def run_command(self):
            return (0, "global", "")

    class ModuleMock(object):
        def __init__(self):
            self.run_command = RunModuleMock.run_command

    def get_bin_path_mock(filename):
        return filename

    # Test if we can detect a zone
    virtual.module = ModuleMock()
    virtual.module.get_bin_path = get_bin_path_mock
    virtual.module.run_command = RunModuleMock.run_command
    facts = virtual.get_virtual_facts()
    assert 'container' in facts


# Generated at 2022-06-23 02:35:16.017595
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert(SunOSVirtualCollector._platform == 'SunOS')
    assert(SunOSVirtualCollector._fact_class == SunOSVirtual)

# Generated at 2022-06-23 02:35:18.575432
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:35:19.531422
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector



# Generated at 2022-06-23 02:35:28.905234
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import json
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    loader = MockLoader(module)
    shared_loader_obj = None
    SunOSVirtual._loader = loader
    SunOSVirtual._shared_loader_obj = shared_loader_obj

    virt_fact = SunOSVirtual()
    result = virt_fact.get_virtual_facts()

    for key in ['virtualization_tech_host', 'virtualization_tech_guest', 'virtualization_role', 'virtualization_type', 'container']:
        assert key in result


# Generated at 2022-06-23 02:35:30.332596
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert hasattr(x, 'platform')

# Generated at 2022-06-23 02:35:31.825586
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:35:36.125166
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # No argument should make it fail
    try:
        v = SunOSVirtual(module=None)
        assert False
    except Exception:
        pass

    # An empty argument should be enough
    v = SunOSVirtual(module=dict())
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.container is None

# Generated at 2022-06-23 02:35:47.902846
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = SunOSVirtual({}, {})

    # Define some sample output for the fact gathering
    ZONENAME_OUT = """global
"""
    MODINFO_OUT = """    id: vmware
    description:    VMware virtual network driver
    class: driver
    module: drv/vmnet
    devclass:        vmmet
    devi:        vmmet
    type:        STREAMS DRIVER
    bus:        PRIVATE
    major:        101
    flags:        0
"""

# Generated at 2022-06-23 02:35:49.579491
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of SunOSVirtualCollector class can be called without arguments
    """
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:35:57.062614
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.params['gather_subset'] = []

    virt_obj = SunOSVirtual(module)

    # Module run_command for fake binary 'zonename'
    def fake_run_command_zonename(module, *args, **kwargs):
        return 0, 'global', None

    module.run_command = fake_run_command_zonename
    module.get_bin_path = lambda x: '/usr/bin/zonename'

    # We are in a zone
    assert virt_obj.get_virtual_facts() == {
        'virtualization_type': None,
        'virtualization_role': None,
        'container': 'zone',
    }

    # Module run_command for fake binary 'zonename'

# Generated at 2022-06-23 02:36:08.432313
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts.virtual.sunos.SunOSVirtual import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    class MockModule(object):
        def get_bin_path(self, binary):
            return '/sbin/' + binary

        def run_command(self, cmd):
            if binary == 'zonename':
                if cmd == zonename:
                    rc, out, err = 0, 'global', ''
                else:
                    rc, out, err = 0, 'solaris8', ''


# Generated at 2022-06-23 02:36:09.315698
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:36:10.578247
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:36:18.279228
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import json
    import tempfile
    module = AnsibleModuleMock()
    ld = tempfile.mkdtemp()
    module.run_command = Mock(side_effect=[(0, "/usr/sbin/init", ""), (0, "global", ""), \
                                           (0, """MODULE_NAME: vboxguest\nLICENSE: GPLv2\nPTYPE: SYS_UNKNOWN\n""", ""), \
                                           (0, "", "")])
    module.get_bin_path = Mock(side_effect=['/usr/sbin/zonename', '/usr/sbin/modinfo', None, None])
    os.mkdir("/proc/vz")
    v = SunOSVirtual(module)
    virtual_facts = v.get_virtual_facts()
   

# Generated at 2022-06-23 02:36:28.765696
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'global', None)
    zone_output = '/usr/sbin/zoneadm list -icv\n' \
                  '0:global:running:/::native:shared::::\n' \
                  '1:zone1:running:/zones/zone1:ipkg:excl::::\n' \
                  '2:zone2:installed:/zones/zone2:brand:excl::::\n' \
                  '4:zone4:installed:/zones/zone4:ipkg:excl::::\n'
    module.run_command.return_value = (0, zone_output, None)

# Generated at 2022-06-23 02:36:31.943053
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    result = (SunOSVirtual()).get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-23 02:36:34.675190
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v.platform is 'SunOS'
    assert v._fact_class is SunOSVirtual



# Generated at 2022-06-23 02:36:41.410100
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module=module, subprocess_obj=PopenMock).get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None

# Generated at 2022-06-23 02:36:45.976629
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # If platform is not SunOS, an empty collector object is returned
    collector = SunOSVirtualCollector()
    assert collector.get_virtual_facts() == dict()
    assert collector.collect() == dict()

    # If platform is SunOS, an object of the class SunOSVirtual should be returned
    collector = SunOSVirtualCollector(platform='SunOS')
    assert collector.get_virtual_facts() == dict()
    assert collector.collect() == dict()

# Generated at 2022-06-23 02:36:56.239821
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    input = {'ansible_facts': {'system': 'SunOS',
                               'virtualization_role': None,
                               'virtualization_type': None,
                               'virtualization_tech_guest': set(),
                               'virtualization_tech_host': set()}}
    sunos = SunOSVirtual(input)
    output = sunos.get_virtual_facts()

# Generated at 2022-06-23 02:36:57.302362
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class is SunOSVirtual

# Generated at 2022-06-23 02:36:59.965772
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c.fact_class.platform == 'SunOS'
    assert isinstance(c.fact_class, SunOSVirtual)

# Generated at 2022-06-23 02:37:02.174524
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})
    facts = v.get_virtual_facts()
    assert 'virtualization_type' in facts

# Generated at 2022-06-23 02:37:03.954700
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({}, {}, [])
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:37:10.141841
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # empty module
    module = FakeModule()
    collector = SunOSVirtualCollector(module=module)
    results = collector.collect()
    assert results['virtualization_type'] == 'zone'

    # module with facts
    module = FakeModule(container='zone')
    collector = SunOSVirtualCollector(module=module)
    results = collector.collect()
    assert results['virtualization_type'] == 'zone'

# Generated at 2022-06-23 02:37:22.032283
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Pretend to be SunOS.
    os.name = 'SunOS'

    # Pretend to be a zone
    module = type('', (), {})
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    setattr(module, '_sunos_zonename_out', 'global')
    setattr(module, '_sunos_zone_zone_name', 'testzone')
    setattr(module, '_sunos_zone_zone_brand', 'solaris')
    setattr(module, '_sunos_vmware_installed', True)
    setattr(module, '_sunos_virtualbox_installed', False)

# Generated at 2022-06-23 02:37:31.279639
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import types
    # Create class instance
    sv_inst = SunOSVirtual()

    sv_inst.module.run_command = types.MethodType(mock_run_command, sv_inst.module)
    sv_inst.module.get_bin_path = types.MethodType(mock_get_bin_path, sv_inst.module)

    # Create facts dictionary
    temp_facts = dict()

    # Call method
    sv_inst.get_virtual_facts(temp_facts)

    # Assertions to check if method returned expected results
    assert temp_facts['virtualization_type'] == 'virtuozzo'
    assert temp_facts['virtualization_role'] == 'guest'
    assert temp_facts['container'] == 'zone'
    assert 'zone' in temp_facts['virtualization_tech_host']
   

# Generated at 2022-06-23 02:37:41.367889
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.zone import ZoneVirtual
    from ansible.module_utils.facts.virtual.zone import ZoneVirtualCollector
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils.facts.virtual.vmware import VMwareVirtual
    from ansible.module_utils.facts.virtual.vmware import VMwareVirtualCollector
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBoxVirtual
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBoxVirtualCollector
    from ansible.module_utils.facts.virtual.vbox import VBoxVirtual
    from ansible.module_utils.facts.virtual.vbox import VBoxVirtualCollector
    from ansible.module_utils.facts.virtual.hybrid import HybridVirtual
   

# Generated at 2022-06-23 02:37:43.782859
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    facts = SunOSVirtual(module).collect()
    assert facts.get('virtualization_type') is not None


# Generated at 2022-06-23 02:37:54.166930
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a test instance of class DebianVirtual
    test_instance = SunOSVirtual()

    # Create a MockModule to get the return values for calls to module
    test_module = MockModule()

    # Set up the arguments as attributes of the test module.
    # This way every call to module.get_bin_path() in get_virtual_facts() will
    # return the desired value.

    # zonename is available
    test_module.bin_path = {
        'zonename': '/usr/bin/zonename',
        'modinfo': '/usr/sbin/modinfo',
        'virtinfo': '/usr/bin/virtinfo',
        'smbios': '/usr/sbin/smbios',
        'zoneadm': '/usr/sbin/zoneadm',
    }

    # Attach the test module as

# Generated at 2022-06-23 02:37:56.706017
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:38:05.787639
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''

    # Given: the SunOSVirtual class
    # When: I create an instance with the following output from
    #       the zonename command: zonename: global
    module = MockAnsibleModule(command_outputs=[['zonename', 'zonename: global', 0, '']])
    sunos_virtual = SunOSVirtual(module).get_virtual_facts()

    # Then: the virtualization_role should be "host" and the virtualization_type should be "zone"
    assert sunos_virtual['virtualization_role'] == 'host'
    assert sunos_virtual['virtualization_type'] == 'zone'



# Generated at 2022-06-23 02:38:06.711061
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._platform == 'SunOS'

# Generated at 2022-06-23 02:38:10.802598
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    facts_collector = FactCollector(module=module, collector_class=SunOSVirtualCollector)
    virtual_facts = facts_collector.collect(['virtual'])['ansible_virtualization_facts']
    assert 'container' in virtual_facts or 'virtualization_type' in virtual_facts or 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:38:12.254118
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:21.918007
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    virt = SunOSVirtual('/')

    # SunOS inside of a zone
    virt.module.run_command = lambda cmd: (0, '/global', None)
    virt.module.get_bin_path = lambda cmd: True
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'

    # SunOS baremetal
    virt.module.run_command = lambda cmd: (0, '/', None)
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'host'

    # SunOS branded zone
    virt.module.run_command = lambda cmd: (0, '/', None)

# Generated at 2022-06-23 02:38:24.021554
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test SunOSVirtual.
    """
    SunOSVirtual()

# Generated at 2022-06-23 02:38:25.378219
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mytest = SunOSVirtual()
    assert mytest.platform == 'SunOS'

# Generated at 2022-06-23 02:38:29.891550
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector
    collector = Collector(None)
    platform_virtual = SunOSVirtual(collector)
    facts = platform_virtual.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts

# Generated at 2022-06-23 02:38:38.845134
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    obj = SunOSVirtual(module)

    # No command on the system, this is not a virtual machine
    module.run_command.return_value = (1, '', '')
    module.run_command.reset_mock()

    obj.get_virtual_facts()
    assert not module.get_bin_path.called

    # Command on the system, it is a virtual machine
    module.run_command.return_value = (0, 'Global', '')
    module.run_command.reset_mock()

    obj.get_virtual_facts()
    module.get_bin_path.assert_called_with('zonename')



# Generated at 2022-06-23 02:38:41.651704
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    x = SunOSVirtual(module)
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:38:45.725649
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_virtual_facts = {'container': 'zone',
                          'virtualization_type': 'xen',
                          'virtualization_role': 'guest',
                          'virtualization_tech_guest': set(['xen']),
                          'virtualization_tech_host': set(['zone'])}
    assert SunOSVirtual(dict()).get_virtual_facts() == test_virtual_facts

# Generated at 2022-06-23 02:38:47.177197
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:56.625220
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    import os.path

    sunos = SunOSVirtual(None)
    # Virtual should be parent class of SunOSVirtual
    assert isinstance(sunos, Virtual)

    sunos.module = None
    # Virtualization type should be 'kvm' when smbios output contains the string 'KVM'
    sunos.module = MagicMock(return_value=True)
    sunos.module.get_bin_path = MagicMock(return_value='/usr/local/bin/smbios')
    sunos.module.run_command = MagicMock(return_value=(0, 'KVM', ''))
    virtual_facts = sunos.get_virtual_facts()

# Generated at 2022-06-23 02:38:58.386619
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:01.151789
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj_SunOSVirtualCollector = SunOSVirtualCollector()
    assert obj_SunOSVirtualCollector.platform == 'SunOS'

# Generated at 2022-06-23 02:39:04.622912
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    sunos = SunOSVirtual(module)
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-23 02:39:13.188937
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)

    # Don't test whether the virtualization is set correctly when
    # the tools are not installed.
    module.run_command.return_value = (1, '', '')
    assert virtual.get_virtual_facts() == {}

    module.run_command.return_value = (1, '', '')
    assert virtual.get_virtual_facts() == {}

    # Test that an empty dict is returned if the virtinfo return code is not 0.
    module.run_command.return_value = (1, '', '')
    assert virtual.get_virtual_facts() == {}

    # Test that the correct dict is returned if we are on a zone (global).

# Generated at 2022-06-23 02:39:25.121478
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import tempfile
    import json
    import shutil
    import os

    # create temp directory
    temp_dir = tempfile.mkdtemp()
    tmppath = os.path.join(temp_dir, 'smbios')

    # create temp smbios output
    smbios_file = open(tmppath, 'w')

# Generated at 2022-06-23 02:39:28.598143
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual
    assert x._fact_class().platform == 'SunOS'

# Generated at 2022-06-23 02:39:30.336818
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vm = SunOSVirtual()
    assert vm.platform == "SunOS"

# Generated at 2022-06-23 02:39:40.051431
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = get_module_mock()

    # Default test with no arguments.  For this test we assume that the host
    # has not been virtualized at all.  So we can test the results against
    # known values.

    # Set module standard output and standard error messages.  These are the
    # messages that the tested method would get if it were run on a real host
    module.set_stdout(
        """
        global
        """
    )
    module.set_stderr(
        """
        """
    )

    # Create a SunOSVirtual object and call its get_virtual_facts() method
    # with the mock object created above.
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()

    # Check if the result matches the expected result.


# Generated at 2022-06-23 02:39:42.121960
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:39:45.298298
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    assert isinstance(x, object)
    assert isinstance(x, VirtualCollector)
    assert not isinstance(x, list)


# Generated at 2022-06-23 02:39:48.655043
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sc = SunOSVirtualCollector()
    assert isinstance(sc._platform, str)
    assert isinstance(sc._fact_class, object)
    assert callable(sc._fact_class)

# Generated at 2022-06-23 02:39:58.394036
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    import tempfile
    import shutil

    def mock_run_command(self, binary):
        if binary == "/usr/sbin/zoneadm list":
            return 0, "global\trunning\t0\t0\ttestzone\tinstalled\t-", ""
        elif binary == "/usr/sbin/zoneadm list -cv":
            return 0, "zid: 0\nname: global\ncaps: \nlimitpriv: default,dtrace_kernel,dtrace_proc,dtrace_user\nscheduling-class: \nlcpu-cap: \nlcpu-ratio: \ncpu-shares: N/A\ncpu-cap: \n", ""
        elif binary == "/usr/sbin/zoneadm list -cp":
            return 1, "", ""

# Generated at 2022-06-23 02:40:02.180500
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v.platform == 'SunOS'
    assert v._platform == 'SunOS'
    assert v.fact_class._platform == 'SunOS'
    assert v.fact_class._platform == v._fact_class._platform


# Generated at 2022-06-23 02:40:08.759480
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class TestModule:
        def __init__(self, out, rc):
            self.out = out
            self.rc = rc
            self.run_command_called = 0
            self.get_bin_path_called = 0

        def run_command(self, *args, **kwargs):
            self.run_command_called += 1
            return self.rc, self.out, ''

        def get_bin_path(self, *args, **kwargs):
            self.get_bin_path_called += 1
            return '/usr/bin/zonename'

    v = SunOSVirtual(module=None)
    test_module = TestModule("global", rc=0)
    v.module = test_module

    # Test if it's a global zone only
    v.get_virtual_facts()
    assert test_

# Generated at 2022-06-23 02:40:11.100355
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert SunOSVirtual.platform == 'SunOS'

# Generated at 2022-06-23 02:40:22.383839
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test the get_virtual_facts method of SunOSVirtual.
    """
    SunOSVirtual._module = None
    SunOSVirtual._module = MockModule()

# Generated at 2022-06-23 02:40:26.719817
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Run constructor
    test_instance = SunOSVirtual({})

    # Check that instance is created
    assert isinstance(test_instance, SunOSVirtual)

    # Check that _platform is correctly set
    assert test_instance._platform == 'SunOS'

    # Check that _fact_class is correctly set
    assert test_instance._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:32.717904
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert SunOSVirtual().get_virtual_facts() == {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'container': 'zone',
        'virtualization_tech_guest': {'zone', 'vmware'},
        'virtualization_tech_host': {},
    }

# Generated at 2022-06-23 02:40:42.435476
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    import os
    from ansible.module_utils.facts.virtual.posix import PosixVirtual
    from ansible.module_utils.facts import FactCollector

    os.environ['VMWARE_PRODUCT_NAME'] = "VMware Fusion"
    # get_virtual_facts() should return a dictonary with the dictonary keys:
    # virtualization_type, virtualization_role, container, and virtualization_tech_*
    # The values are all sets
    # Create a subclass of Virtual whose get_virtual_facts() method is instrumented
    # so that it returns

# Generated at 2022-06-23 02:40:46.716060
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    vc = SunOSVirtualCollector(module=module)
    assert type(vc) == SunOSVirtualCollector
    assert vc.platform == 'SunOS'
    assert vc.module == module


# Generated at 2022-06-23 02:40:47.912073
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.get_virtual_facts() == {}

# Generated at 2022-06-23 02:40:50.504453
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt = SunOSVirtualCollector()
    assert virt._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:40:53.929366
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._limit_platforms == ['SunOS']
    assert obj._fact_class == SunOSVirtual
    assert obj.collect() == {}

# Generated at 2022-06-23 02:40:58.683972
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    fact_collector = FactCollector()
    sunos_virtual_fact_collector = SunOSVirtualCollector()
    fact_collector.add_collector(sunos_virtual_fact_collector)

# Generated at 2022-06-23 02:41:10.380336
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Set up our module object
    class Module:
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, name):
            if name == 'zonename':
                return '/usr/bin/zonename'
            elif name == 'virtinfo':
                return '/usr/sbin/virtinfo'
            else:
                return None

    class VM(object):
        def __init__(self, name, type):
            self.name = name
            self.type = type

    class Machine(object):
        def __init__(self, manufacturer, productname):
            self.manufacturer = manufacturer
            self.productname = productname


# Generated at 2022-06-23 02:41:12.230141
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:41:21.366268
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['!all']
    module.params['gather_timeout'] = 0
    obj = SunOSVirtual(module=module)
    facts = obj.get_facts()
    assert not 'virtualization_type' in facts
    assert not 'virtualization_role' in facts
    assert not 'container' in facts
    assert 'virtualization_tech_guest' in facts
    assert len(facts['virtualization_tech_guest']) == 0
    assert 'virtualization_tech_host' in facts
    assert len(facts['virtualization_tech_host']) == 0


# Generated at 2022-06-23 02:41:23.944465
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a test of the constructor of class SunOSVirtualCollector
    """
    collect = SunOSVirtualCollector()
    assert collect._platform == 'SunOS'

# Generated at 2022-06-23 02:41:31.472037
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = SunOSVirtual(module)

    zonename = module.get_bin_path.return_value
    rc, out, err = module.run_command.return_value
    out = 'global'
    module.run_command.return_value = rc, out, err

    facts = virtual.get_virtual_facts()
    assert facts == {'virtualization_role': 'host', 'virtualization_type': 'zone',
                        'virtualization_tech_guest': set([]), 'virtualization_tech_host': set(['zone']),
                        'container': None}

    zonename = module.get_bin_path.return_value
    rc, out, err = module.run_command.return_value
    out = 'myzone'
    module.run_command.return_value

# Generated at 2022-06-23 02:41:41.115614
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0)

    # Test a zone
    module.run_command = FakeRunCommand(out="global", rc=0)
    collector = SunOSVirtualCollector(module)
    facts = collector.collect(module)
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'container' not in facts
    assert 'virtualization_tech_host' in facts and facts['virtualization_tech_host'] == {'zone'}
    assert 'virtualization_tech_guest' in facts and facts['virtualization_tech_guest'] == set()

    # Test a non global zone
    module.run_command = FakeRunCommand(out="z1", rc=0)
    collector = SunOSVirtual

# Generated at 2022-06-23 02:41:45.447283
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos = SunOSVirtual(None)

    assert os.path.exists(sunos._zonename)
    assert os.path.exists(sunos._zonename)
    assert os.path.exists(sunos._zonename)

# Generated at 2022-06-23 02:41:55.134018
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()

    # test if it's a zone
    zonename_path = module.zonestate.get_zonename()
    module.exists_mock = MagicMock(return_value=False)
    module.isdir_mock = MagicMock(return_value=False)
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()
    module.isdir_mock.reset_mock()

    # if it's a zone and it contains a file named /proc/vz

# Generated at 2022-06-23 02:41:58.224580
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts.platform == 'SunOS'
    assert facts._size == 0



# Generated at 2022-06-23 02:42:02.981438
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = type('module', (object,), {'get_bin_path': lambda self, path: path})
    virt_module = SunOSVirtual(module_mock)
    assert virt_module.platform == 'SunOS'
    assert virt_module.module == module_mock

# Generated at 2022-06-23 02:42:04.878575
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})

    assert type(v) == SunOSVirtual

# Generated at 2022-06-23 02:42:07.194758
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-23 02:42:16.861291
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeCommand
    facts = SunOSVirtual(module).get_virtual_facts()
    correct_virtual_facts = {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set()
    }
    for key in correct_virtual_facts:
        assert key in facts and facts[key] == correct_virtual_facts[key]


# Fake AnsibleModule class to return values from get_bin_path method

# Generated at 2022-06-23 02:42:19.903283
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Unit test for constructor of class SunOSVirtual
    """
    module = AnsibleModule(argument_spec={})
    mock_virtual = SunOSVirtual(module)
    assert mock_virtual

# Generated at 2022-06-23 02:42:21.947550
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt_collector = SunOSVirtualCollector()
    assert virt_collector._platform == 'SunOS'
    assert virt_collector._fact_class is SunOSVirtual

# Generated at 2022-06-23 02:42:34.209900
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    from ansible.module_utils.facts.virtual import FakeModule
    module = FakeModule()
    sun_virtual = SunOSVirtual(module)
    result_expected = {
        'container': 'zone',
        'virtualization_tech_guest': set(['zone', 'vmware']),
        'virtualization_role': 'guest',
        'virtualization_tech_host': set([]),
        'virtualization_type': 'vmware',
    }

    def run_command_mock(module, command):
        if command == 'zonename':
            return (0, 'solaris11\n', '')

# Generated at 2022-06-23 02:42:35.621577
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()


# Generated at 2022-06-23 02:42:40.574805
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Mock()
    module.run_command = Mock(side_effect=lambda x, **kargs: (0, x[0], ''))
    module.get_bin_path = Mock(side_effect=lambda x: '/bin/' + x)
    virtual = SunOSVirtual(module)
    virtual.get_virtual_facts()
    assert module.run_command.call_count == 10

# Generated at 2022-06-23 02:42:42.066260
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()

# Generated at 2022-06-23 02:42:43.490043
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict()).platform == 'SunOS'



# Generated at 2022-06-23 02:42:47.763880
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:42:48.999779
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:42:51.740762
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = DummyAnsibleModule()
    obj = SunOSVirtualCollector(module)
    assert obj._fact_class is SunOSVirtual
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 02:43:02.250712
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test case 1: No vmware or virtualbox installed
    module = FakeAnsibleModule()
    module.run_command = lambda cmd: (0, "", "")
    module.get_bin_path = lambda cmd: cmd
    obj = SunOSVirtual(module=module)
    facts = obj.get_virtual_facts()
    assert facts == {}

    # Test case 2: VMware running in the global zones
    module = FakeAnsibleModule()
    module.run_command = lambda cmd: (0, "0 VMware foo", "")
    module.get_bin_path = lambda cmd: cmd
    obj = SunOSVirtual(module=module)
    facts = obj.get_virtual_facts()
    assert "virtualization_type" in facts
    assert facts["virtualization_type"] == "vmware"

# Generated at 2022-06-23 02:43:03.841343
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:43:05.846286
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    result = SunOSVirtualCollector()
    assert result.platform == 'SunOS'

# Generated at 2022-06-23 02:43:08.630824
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = _mock_module()
    v = SunOSVirtual(module)
    assert v.platform == 'SunOS'


# Generated at 2022-06-23 02:43:11.255984
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Returns an object of class SunOSVirtual
    """
    facts = SunOSVirtual({})
    assert facts.__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-23 02:43:13.457651
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({}, {}, 'redhat', 'x86_64')
    assert virtual.data == {}


# Generated at 2022-06-23 02:43:15.688413
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({}, {}, {}, [])
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:43:17.854400
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.platform == "SunOS"
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:43:21.294008
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    'Unit test for SunOSVirtualCollector'
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:32.313022
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:43:34.845856
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_test = SunOSVirtualCollector(None, None)
    assert virtual_test._platform == 'SunOS'
    assert virtual_test._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:35.318585
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()

# Generated at 2022-06-23 02:43:41.740360
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_type == None
    assert sunos_virtual.virtualization_role == None
    assert sunos_virtual.container == None

# Generated at 2022-06-23 02:43:50.074055
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class TestModule(object):

        def __init__(self):
            self.params = dict()

        def get_bin_path(self, name):
            return "/usr/bin/%s" % name

        def run_command(self, cmd):
            return 0, '', ''

    class Test(SunOSVirtual):

        def __init__(self):
            self.module = TestModule()

    virtual_facts = Test().get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'zone'



# Generated at 2022-06-23 02:43:51.694730
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts=SunOSVirtual({})
    assert facts.platform == 'SunOS'


# Generated at 2022-06-23 02:43:54.236118
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosv = SunOSVirtualCollector()
    assert isinstance(sunosv, VirtualCollector)

# Generated at 2022-06-23 02:44:05.251807
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyModule()
    virt = SunOSVirtual(module)

    # Test for container type
    #   - virtinfo returns the exit code 0 but the output indicates error
    module.run_command = MagicMock(return_value=(
        0,
        'virtinfo can only be run from the global zone\n',
        ''))
    res = virt.get_virtual_facts()
    assert 'container' in res and res['container'] == 'zone'

    # Test for virtualization_type
    #   - In the case of an LDOM guest, virtinfo returns the exit code 0
    #     and the output contains the "control" feature

# Generated at 2022-06-23 02:44:08.997375
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_instance = SunOSVirtual(dict(), None, 'guest')
    assert virtual_facts_instance.platform == 'SunOS'
    assert virtual_facts_instance.all_facts.keys() == []



# Generated at 2022-06-23 02:44:10.551762
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_test = SunOSVirtual({})
    assert hasattr(virtual_facts_test, 'platform')

# Generated at 2022-06-23 02:44:16.306579
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Unit test for constructor of class SunOSVirtualCollector.
    """
    # Initialize SunOSVirtualCollector and assert module is SunOS
    c = SunOSVirtualCollector()
    module = c._module
    assert module.__name__ == 'ansible_sunos_system'



# Generated at 2022-06-23 02:44:25.583577
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()

    expected_attr = '_fact_class'
    if not hasattr(obj, expected_attr):
        raise AttributeError("'%s' does not have '%s' attribute" % (type(obj), expected_attr))

    expected_attr = '_platform'
    if not hasattr(obj, expected_attr):
        raise AttributeError("'%s' does not have '%s' attribute" % (type(obj), expected_attr))

# Generated at 2022-06-23 02:44:28.152363
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule({})
    virtual = SunOSVirtual(module)
    assert virtual.get_virtual_facts() == {}


# Generated at 2022-06-23 02:44:32.221437
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Set up arguments used by AnsibleModule
    module_args = dict()

    # Construct an instance of the SunOSVirtual class
    test_virtual = SunOSVirtual(module_args, {})

    # Check if module_args was copied
    assert test_virtual.module_args == module_args

# Generated at 2022-06-23 02:44:35.110067
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sample_output = {'virtualization_type': 'zone', 'virtualization_role': 'guest'}
    virtual = SunOSVirtual(None, sample_output)
    assert virtual.virtualization_type == "zone"

# Generated at 2022-06-23 02:44:43.633335
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def _module_mock(module_args, check_invalid_arguments=None, **kwargs):
        class _Results(object):
            return_value = 0
            stdout_lines = []
            stderr_lines = []

            def __getitem__(self, key):
                if key == 'rc':
                    return self.return_value
                elif key == 'stdout':
                    return '\n'.join(self.stdout_lines)
                elif key == 'stderr':
                    return '\n'.join(self.stderr_lines)
                else:
                    raise IndexError

        class ModuleFailException(Exception):
            pass
