

# Generated at 2022-06-23 02:34:40.086858
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule({})
    test_obj = SunOSVirtual(module)
    assert test_obj
    assert test_obj.name == 'SunOS'


# Generated at 2022-06-23 02:34:46.776657
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virt_facts = SunOSVirtual(module)
    assert virt_facts.virtual == {'is_chroot': False, 'container': None, 'type': None, 'role': None,
                                  'tech_guest': set(), 'tech_host': set()}
    assert virt_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:34:54.393897
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    module = AnsibleModule(argument_spec=dict())

    # Patch module as this module depends on module_utils/facts/virtual/base.py
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_file_content = MagicMock(return_value=True)
    module.file_exists = MagicMock(return_value=True)
    module.get_platform = MagicMock(return_value='SunOS')
    module.is_rule_conditional = MagicMock(return_value=False)

    try:
        virt_module = SunOSVirtual(module)
        assert virt_module.get_virtual_facts() is not None
    except:
        pass


# Unit test

# Generated at 2022-06-23 02:34:56.113044
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert 'SunOS' == virtual.platform

# Generated at 2022-06-23 02:34:59.360282
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class._platform == 'SunOS'
    assert virtual_collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:35:02.628481
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.name == "sunos"
    assert virtual is not None

# Generated at 2022-06-23 02:35:08.359340
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import sys

    class TestModule(object):
        _ansible_module_commands = {
            'zonename': '/bin/zonename',
            'modinfo': '/bin/modinfo',
            'virtinfo': '/bin/virtinfo',
            'smbios': '/bin/smbios',
        }

        def get_bin_path(self, arg, required=False, opt_dirs=None):
            if arg in self._ansible_module_commands:
                return self._ansible_module_commands[arg]
            else:
                return None

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            rc = 0

# Generated at 2022-06-23 02:35:09.965167
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:35:21.000506
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # import the module
    module = AnsibleModule(argument_spec=dict())

    # create a dummy Virtual object
    virt_obj = SunOSVirtual(module)

    # create an empty dictionary to get filled
    virtual_facts = {}

    # create a dummy module
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.side_effect = lambda x: x

    # patch the module to get a working get_bin_path function
    with patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.side_effect = lambda x: x

        # patch the module to get a working run_command function

# Generated at 2022-06-23 02:35:30.292962
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.posix import BasePosixVirtual
    from ansible.module_utils.facts.virtual import BaseVirtual

    for s_class in [SunOSVirtual, BasePosixVirtual, BaseVirtual]:
        s_instance = s_class()

        # We can't really test that s_instance.module is an instance of
        # AnsibleModule since AnsibleModule is imported manually in the
        # class definition.
        assert isinstance(s_instance.module, object)

        def zonename_func(self, *args, **kwargs):
            if "global" in args:
                return (0, "global", "fake-stderr")

# Generated at 2022-06-23 02:35:34.234887
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Unit test for constructor of class SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == "SunOS"
    assert sunos_virtual_collector._fact_class._platform == "SunOS"

# Generated at 2022-06-23 02:35:44.749246
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'container': 'zone',
        'virtualization_tech_guest': set(['zone', 'virtualization_type']),
        'virtualization_tech_host': set(['zone'])
    }
    virtual_module = MagicMock()
    virtual_module.run_command.return_value = [0, "global\n", ""]
    virtual_module.get_bin_path.side_effect = lambda x: x
    virtual_module.os.path.isdir.return_value = False
    virtual_module.os.path.exists.return_value = False
    sunos_virtual = SunOSVirtual(virtual_module)

# Generated at 2022-06-23 02:35:50.785142
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_virtual_facts = SunOSVirtual(test_module)
    test_virtual_facts_dic = test_virtual_facts.get_virtual_facts()
    keys = ['virtualization_tech_host', 'virtualization_tech_guest', 'virtualization_role', 'virtualization_type', 'container']
    for key in keys:
        assert key in test_virtual_facts_dic.keys()

# Generated at 2022-06-23 02:35:53.502374
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    sunos = SunOSVirtual(module)
    if not isinstance(sunos, SunOSVirtual):
        raise Exception('Class constructor of SunOSVirtual failed')

# Generated at 2022-06-23 02:35:55.934413
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = {'ansible_system': 'SunOS'}
    test_object = SunOSVirtual(facts)
    # Check the class of test_object is SunOSVirtual
    assert type(test_object) == SunOSVirtual


# Generated at 2022-06-23 02:36:03.837272
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = []
    tmpdir.append(tempfile.mkdtemp())
    tmpdir.append(tempfile.mkdtemp())

    # Create files in temporary directory
    with open(os.path.join(tmpdir[0], '.SUNWnative'), 'a'):
        os.utime(os.path.join(tmpdir[0], '.SUNWnative'), None)

    with open(os.path.join(tmpdir[1], 'proc', 'vz'), 'a'):
        os.utime(os.path.join(tmpdir[1], 'proc', 'vz'), None)

    # Test get_virtual_facts
    virtual_facts = Sun

# Generated at 2022-06-23 02:36:11.156866
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.SunOS import SunOSVirtualCollector, SunOSVirtual

    test_data_dir = os.path.join(os.path.dirname(__file__), 'unittests', 'test_data')

    sunos_virtual_collector = SunOSVirtualCollector({}, {}, test_data_dir)
    sunos_virtual = sunos_virtual_collector.collect()
    assert isinstance(sunos_virtual, SunOSVirtual)

# Generated at 2022-06-23 02:36:19.289699
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = MockModule()
    module_mock.run_command = Mock(return_value=(0, "", ""))
    module_mock.get_bin_path = Mock(return_value="/bin")

    sunos_virtual = SunOSVirtual(module_mock)
    module_mock.run_command = Mock(return_value=(0, "global", ""))
    assert sunos_virtual.get_virtual_facts() == {'virtualization_tech_host': {'zone'}, 'virtualization_tech_guest': set()}
    module_mock.run_command = Mock(return_value=(1, "", ""))
    assert sunos_virtual.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    module_

# Generated at 2022-06-23 02:36:30.465665
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    from ansible.module_utils.facts.facts import Facts

    import sys

    m = SunOSVirtual()
    m.module = type("AnsibleModule", (), dict(run_command=lambda self, args, check_rc=False: (0, "", "")))

    m.module.get_bin_path = lambda arg: arg
    sys.modules['ansible.module_utils.facts.facts'] = Facts()

    # Verify that running on a global zone sets virtualization_type, virtualization_role and
    # virtualization_tech_guest to None
    m.module.run_command = lambda arg, check_rc=False: (0, "global", "")

# Generated at 2022-06-23 02:36:38.791680
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    # testing SunOSVirtual
    sunos_virtual = SunOSVirtual(None)
    assert sunos_virtual.get_virtual_facts() is None

    # testing SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector(None)
    assert sunos_virtual_collector.fetch_virtual_facts() is None

# Generated at 2022-06-23 02:36:40.492655
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt.platform == 'SunOS'

# Generated at 2022-06-23 02:36:42.340096
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x=SunOSVirtual(dict())
    assert x._platform == 'SunOS'
    assert x._fact_class == Virtual


# Generated at 2022-06-23 02:36:51.636898
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.system.system import FakeModule
    from ansible.module_utils.facts.system.distribution import FakeDistribution
    from ansible.module_utils.facts.system.platform import FakePlatform
    from ansible.module_utils.facts.other.custom.linux_gce import GCEFacts


# Generated at 2022-06-23 02:37:01.412738
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual(dict(module_setup=dict()), 'fake')
    module_main = os.path.realpath(os.path.dirname(__file__) + '/../../ansible/module_utils/facts/virtual/__init__.py')
    rc, out, err = m.module.run_command("%s get_virtual_facts | grep -v '^ python'" % module_main)
    if rc != 0:
        raise Exception("Unable to run ansible module")
    facts = eval(out)
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'container' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# vim: set sw=4:ts=4:

# Generated at 2022-06-23 02:37:03.797546
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Instantiate SunOSVirtual class.
    This does not require facter or ohai to be installed.
    """
    SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}), None)

# Generated at 2022-06-23 02:37:06.984413
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class is SunOSVirtual



# Generated at 2022-06-23 02:37:08.814009
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj_test = SunOSVirtual()
    assert virtual_obj_test.platform == 'SunOS'

# Generated at 2022-06-23 02:37:09.378504
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:37:12.799167
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(None)
    assert sunos_virtual.type == 'SunOS'

# Generated at 2022-06-23 02:37:14.496699
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vobj = SunOSVirtual()
    assert vobj.platform == 'SunOS'

# Generated at 2022-06-23 02:37:26.353027
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector

    def create_module(name):
        module = type(name, (object,),
                      {'run_command': lambda *args, **kwargs: (0, "", ""),
                       'get_bin_path': lambda *args, **kwargs: "/usr/local/bin/%s" % args[0] if args[0] == 'smbios' else None,
                       '_fact_cache': {},
                       'params': {'name': name, 'gather_subset': ['!all', 'virtual']}})
        return module

    collector = Collector(create_module('test'), '/tmp/ansible_facts')

    # Fake a zone
    os.makedirs('/etc/zones')

# Generated at 2022-06-23 02:37:33.163506
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Check that the constructor of class SunOSVirtualCollector
    """
    # Test with no argument
    no_argument_virtual_collector=SunOSVirtualCollector()
    # Test that the target platform is correctly set
    assert no_argument_virtual_collector.platform == 'SunOS'
    # Test that the fact class is correctly set
    assert no_argument_virtual_collector.fact_class == SunOSVirtual

if __name__ == '__main__':
    # Unit test
    test_SunOSVirtualCollector()

# Generated at 2022-06-23 02:37:44.173171
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class Module():
        def __init__(self, check_rc=True):
            self.check_rc = check_rc

# Generated at 2022-06-23 02:37:47.498134
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # This checks that SunOSVirtualCollector class can be instantiated.
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 02:37:57.190415
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:38:01.449987
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    collector = Collector()
    module = DummyModule(collector)
    fact_class = SunOSVirtual(module)
    assert fact_class.module == module


# Generated at 2022-06-23 02:38:08.984652
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import json
    import sys

    if sys.version_info.major < 3:
        from mock import Mock, patch
    else:
        from unittest.mock import Mock, patch

    FACT_LIST = [
        "virtual_facts.py",
        "virtual.py",
        "virtual/base.py",
        "virtual/sunos.py",
        "virtual/sunos/smbios.py",
        "virtual/sunos/virtinfo.py",
        "virtual/sunos/vmadm.py",
        "virtual/sunos/zoneadm.py",
        "virtual/sunos/zonename.py",
    ]


# Generated at 2022-06-23 02:38:16.525992
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = MockAnsibleModule()
    virtual = SunOSVirtual(module)

    facts = virtual.get_virtual_facts()

    module.fail_json.assert_not_called()
    assert facts == {'virtualization_type': 'xen',
                     'virtualization_role': 'guest',
                     'virtualization_tech_host': set(),
                     'virtualization_tech_guest': {'xen'}}


# Generated at 2022-06-23 02:38:22.547494
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module_mock = {
        'run_command': lambda x: (0, "some command output", None),
        'get_bin_path': lambda x: x if x in ('smbios', 'zonename', 'virtinfo') else None
    }
    virtual_collector = SunOSVirtualCollector(module=module_mock, platform='SunOS')
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual
    assert virtual_collector._module == module_mock


# Generated at 2022-06-23 02:38:33.534105
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mocked module, a mocked command, and mocked return values
    module = VirtualCollectorTestUtils.build_mock_module()

    VirtualCollectorTestUtils.mock_command(module, 'zonename', 0, 'global', '')
    VirtualCollectorTestUtils.mock_command(module, 'modinfo', 0, '', '')
    VirtualCollectorTestUtils.mock_command(module, 'virtinfo', 0, '', '')
    VirtualCollectorTestUtils.mock_command(module, 'smbios', 0, '', '')

    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    # Check that the command has been called once and also the module.exit_json

# Generated at 2022-06-23 02:38:34.652309
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:37.826105
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Testing SunOSVirtual()
    vc = Virtual()
    assert vc.virtualization_type is None
    assert vc.virtualization_role is None
    assert vc.container is None


# Generated at 2022-06-23 02:38:38.916885
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:38:42.131930
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    obj = SunOSVirtual(module)
    assert obj.platform == 'SunOS'
    assert obj.module == module


# Generated at 2022-06-23 02:38:50.983730
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ We expect an empty virtual_facts as we are mocking
    the output and return code of the run_command.
    """
    module_mock = MockModule()
    # Run the constructor
    sunos_facts = SunOSVirtual(module_mock)

    # Test that the class was instantiated as expected
    assert sunos_facts.platform == 'SunOS'

    # Test that the virtual_facts is empty
    assert not sunos_facts.virtual_facts

    # Test that the module_mock was called to execute the command
    assert module_mock.run_command.call_count == 1

    # Test that the run_command was called as expected

# Generated at 2022-06-23 02:38:57.620331
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    my_SunOSVirtual = SunOSVirtual()
    expected_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
        'container': 'zone'}
    assert my_SunOSVirtual.get_virtual_facts() == expected_virtual_facts

# Generated at 2022-06-23 02:39:02.312758
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    assert isinstance(x.facts, SunOSVirtual)
    assert x.platform == 'SunOS'
    assert x._platform == 'SunOS'
    assert x.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:11.031359
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    setattr(module, 'get_bin_path', get_bin_path)
    setattr(module, 'run_command', run_command)
    setattr(module, 'fail_json', fail_json)
    virtual = SunOSVirtual({}, module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {'container': 'zone',
                             'virtualization_role': 'guest',
                             'virtualization_tech_guest': set(['zone', 'vmware']),
                             'virtualization_tech_host': set(['zone']),
                             'virtualization_type': 'vmware'}



# Generated at 2022-06-23 02:39:13.684944
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:17.138942
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.__class__.__name__ == "SunOSVirtualCollector"


# Generated at 2022-06-23 02:39:18.203518
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no arguments
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:29.548365
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command.side_effect = [
        (0, 'global', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', '')
    ]
    virtual = SunOSVirtual(mock_module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_type'] == 'zone'
    assert 'container' not in facts


# Generated at 2022-06-23 02:39:39.443899
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # The following was taken from the output of modinfo | grep -i vm
    modinfo = """
    3093 fffffffff7d4a000 1f4e0 6c6f3f01 e3e9a          vmware_pvscsi (VMware PVSCSI)
    3094 fffffffff7f46000 e294 7cffa701 072d8          vmware_balloon (VMware Balloon)
    """
    virtinfo = """
    DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
    """
    class module:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_err = ''
            self.run_command_out = modinfo


# Generated at 2022-06-23 02:39:51.387802
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Tests for when running on a zone
    module = FakeANSIModule()
    module.get_bin_path_returns = {'zonename': '/usr/bin/zonename'}
    module.run_command_returns = [
        (0, 'global', ''),
        (0, 'zonename: kernel module not loaded', '')
    ]
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['container'] == 'zone'



# Generated at 2022-06-23 02:39:52.493706
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'
    assert virtual.virtual_subtype == 'zone'

# Generated at 2022-06-23 02:40:02.378863
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Uses the VirtualCollector to test method get_virtual_facts of class SunOSVirtual.
    """
    # Create a collector
    virtual_collector = SunOSVirtualCollector(None)

    # Get the correct fact class
    fact_class = virtual_collector.collect()['virtual']

    # Instanciate the fact class with the module
    fact = fact_class._create({'module': {
        'get_bin_path': lambda x: "/usr/bin/" + x,
        'run_command': lambda x: (1, '', '')
    }})

    # Try to get the virtual facts
    virtual_facts = fact.get_virtual_facts()

    # Assert that we have all we want
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role']

# Generated at 2022-06-23 02:40:07.950168
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fake_module = type('', (), dict(run_command=lambda cmd, check_rc=True: (0, '', ''), params={}, get_bin_path=lambda x: True))()
    virtual_instance = SunOSVirtual(fake_module)

    expected_virtual_facts = {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['zone', 'vmware'])
    }

    assert expected_virtual_facts == virtual_instance.get_virtual_facts()

# Generated at 2022-06-23 02:40:20.121454
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.sunos import SunOSVirtual

    mock_module = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}))

    # check for zonename
    zonename_available = {"rc": 0, "out": "global", "err": ""}
    zonename_unavailable = {"rc": 1, "out": "", "err": "zonename: not found"}


# Generated at 2022-06-23 02:40:26.558431
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule({})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    if isinstance(virtual_facts, dict):
        assert virtual_facts['virtualization_tech_host'] == {}
        assert virtual_facts['virtualization_tech_guest'] == {}

# Generated at 2022-06-23 02:40:29.092551
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """This will test the constructor of the class SunOSVirtualCollector"""
    obj = SunOSVirtualCollector()
    assert SunOSVirtualCollector == type(obj)

# Generated at 2022-06-23 02:40:34.289439
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Check if SunOSVirtual is a subclass of Virtual
    assert issubclass(SunOSVirtual, Virtual)

    # Create instance of class SunOSVirtual
    virtual = SunOSVirtual()
    # Check if virtual is an instance of SunOSVirtual
    assert isinstance(virtual, SunOSVirtual)
    # Check if virtual is an instance of Virtual
    assert isinstance(virtual, Virtual)

# Generated at 2022-06-23 02:40:37.648368
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert(vc._platform == 'SunOS')
    assert(isinstance(vc._fact_class, SunOSVirtual))

# Generated at 2022-06-23 02:40:42.746071
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvirtual_collector = SunOSVirtualCollector()
    assert isinstance(sunosvirtual_collector, SunOSVirtualCollector)
    assert isinstance(sunosvirtual_collector._fact_class, SunOSVirtual)
    assert sunosvirtual_collector._platform == 'SunOS'


# Generated at 2022-06-23 02:40:51.690265
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sample_zone_out = """
0:global                  ex:/::default
1:cloud-node0             ex:/zones/cloud-node0:running
2:cloud-node1             ex:/zones/cloud-node1:running
"""
    facts_module = 'ansible.module_utils.facts.virtual.sunos.SunOSVirtual'

# Generated at 2022-06-23 02:40:53.076867
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:41:02.389452
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    mock_get_bin_path = MagicMock(return_value='/bin/true')

    mock_run_command = MagicMock(side_effect=[
        (0, 'global\n', ''),  # zonename
        (0, 'modinfo: no module matches `vmware' + "'" + "'\n", ''),  # modinfo
        (0, '', ''),
        (1, '', ''),
    ])

    mock_isdir = MagicMock(side_effect=[
        False,
        True
    ])

    mock_exists = MagicMock(side_effect=[
        False,
        True
    ])


# Generated at 2022-06-23 02:41:07.860727
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of SunOSVirtualCollector should create an instance of
    SunOSVirtualCollector with _platform attribute equal to 'SunOS'
    """
    try:
        sunos_virtual_collector = SunOSVirtualCollector()
    except NameError:
        assert False, "Constructor of SunOSVirtualCollector failed"

    assert hasattr(sunos_virtual_collector, '_platform'), \
        "_platform attribute should be defined"

    assert sunos_virtual_collector._platform == 'SunOS', \
        "_platform attribute should be equal to 'SunOS'"

# Generated at 2022-06-23 02:41:14.023459
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector

    sv = Virtual()
    svc = VirtualCollector(sv)

    assert sv.platform == 'SunOS'
    assert svc._fact_class == Virtual
    assert svc._platform == 'SunOS'

# Generated at 2022-06-23 02:41:19.167721
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    m = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    os.environ['PATH'] = m + ':' + os.environ['PATH']
    c = SunOSVirtualCollector()
    assert type(c._fact_class) == SunOSVirtual
    assert c._platform == SunOSVirtual.platform

# Generated at 2022-06-23 02:41:29.021484
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils import facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.collectors.sunos import SunOSVirtual
    # Store current stdout to restore after test
    old_stdout = sys.stdout
    # Replace stdout with a buffer to capture output
    sys.stdout = to_bytes(u'buffer')

    # Create a AnsibleModule object
    ansible_module = facts.get_ansible_module()
    # Create a SunOSVirtualCollector object
    sunos_virtual_collector = SunOSVirtualCollector(ansible_module)

    # Check if SunOSVirtualConstructor is an instance of VirtualCollector
   

# Generated at 2022-06-23 02:41:38.338493
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import TestModule

    testmodule = TestModule()
    testmodule.add_command_output(('/usr/sbin/zonename', 0, 'global', ''))
    testmodule.add_command_output(('/usr/sbin/modinfo', 0, '', ''))
    testmodule.add_command_output(('/usr/sbin/virtinfo', 0, '', ''))
    testmodule.add_command_output(('/usr/sbin/smbios', 0, '', ''))
    virtual = SunOSVirtual(module=testmodule)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] is None
    assert facts['virtualization_role'] is None

# Generated at 2022-06-23 02:41:40.214540
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:41.766296
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    return SunOSVirtualCollector()


# Generated at 2022-06-23 02:41:45.345857
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj.fact_class == obj._fact_class

# Generated at 2022-06-23 02:41:57.881850
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value='/usr/sbin/virtinfo')

    cmd_output1 = '''DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false
DOMAIN|did=0|uuid=8c2e1d75-e5f5-4db5-9042-4d4d4c58a259|name=primary|role=root|control=true|io=true|service=true|root=true|status=active'''

# Generated at 2022-06-23 02:41:58.904675
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector


# Generated at 2022-06-23 02:42:01.471459
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virtual = SunOSVirtual(module)
    assert 'SunOS' == virtual.platform
    assert virtual.get_virtual_facts()

# Generated at 2022-06-23 02:42:03.388542
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert isinstance(v, SunOSVirtual)



# Generated at 2022-06-23 02:42:06.268919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert not v.get_virtual_facts()


# Generated at 2022-06-23 02:42:09.311954
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(dict())
    assert s.virtual.platform == 'SunOS'
    assert s.virtual.get_virtual_facts().get('virtualization_type') == 'xen'

# Generated at 2022-06-23 02:42:12.448646
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ Unit test for the constructor of class SunOSVirtual. """
    # empty class instantiation
    virtual_tech_data = SunOSVirtual()
    assert virtual_tech_data.platform == 'SunOS'

# Generated at 2022-06-23 02:42:16.318762
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj_SunOSVirtualCollector = SunOSVirtualCollector()
    assert isinstance(obj_SunOSVirtualCollector, SunOSVirtualCollector)
    assert obj_SunOSVirtualCollector._platform == 'SunOS'


# Generated at 2022-06-23 02:42:18.570713
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_collector = SunOSVirtualCollector()
    assert my_collector.platform == 'SunOS'
    assert my_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:42:27.796978
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    class TestModule(object):
        def __init__(self):
            self.fail_json = lambda *a, **k: None
            self.run_command = lambda *a, **k: (0, '', '')
            self.get_bin_path = lambda *a, **k: None
            self.log = lambda *a, **k: None

    class TestFacts(object):
        def __init__(self):
            self.module = TestModule()

    import platform
    platform_data = dict(
        machine='TestMachine',
        processor='TestProcessor',
        uname_result=('SunOS', 'SunOS machine', '5.11', '11.4', 'sun4v')
    )
    fake_platform

# Generated at 2022-06-23 02:42:28.444379
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-23 02:42:30.304230
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()      # Invokes __init__() of class SunOSVirtualCollector

# Generated at 2022-06-23 02:42:31.697541
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    t = SunOSVirtualCollector()
    assert t._platform == 'SunOS'

# Generated at 2022-06-23 02:42:34.615636
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = MockModule()
    sut = SunOSVirtual(module_mock)
    assert sut.platform == 'SunOS'


# Generated at 2022-06-23 02:42:35.723056
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()


# Generated at 2022-06-23 02:42:44.063632
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()

    # First test not in a zone nor a branded zone nor a container
    os.path.isdir = lambda x: False

    # Nothing found
    SunOSVirtual(module).get_virtual_facts()
    assert module.exit_args['failed'] is False
    assert module.exit_args['changed'] is False

    # Check if it's a zone
    os.path.isdir = lambda x: True
    setattr(module, 'run_command', FakeAnsibleModule.run_command)
    setattr(module.run_command, 'rc', 0)
    setattr(module.run_command, 'out', "global")
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

# Generated at 2022-06-23 02:42:46.405256
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector(None, None)
    assert vc.platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:42:49.836724
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    virtual = SunOSVirtual(None)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:42:52.384746
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:42:55.079332
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Validate the module constructor SunOSVirtual
    '''
    SunOSVirtual({})

# Generated at 2022-06-23 02:43:02.889234
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    instance = Virtual(module, "test")

    rct, out, err = instance.get_virtual_facts()
    assert rct == 0
    assert err == ""
    assert out['container'] == 'zone'
    assert out['virtualization_role'] == 'guest'
    assert out['virtualization_type'] == 'zone'
    assert out['virtualization_tech_guest'] == {'zone'}
    assert out['virtualization_tech_host'].isdisjoint(('zone', 'vmware', 'virtualbox', 'virtuozzo', 'domaining', 'domaining'))

# Mock AnsibleModule

# Generated at 2022-06-23 02:43:13.601401
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: "/sbin/" + x
    module.run_command = lambda x: (
        0,
        "global",
        ""
    )  # zonename returns global zone
    module.exists = lambda x: True

    sunosdata = SunOSVirtual(module)
    result = sunosdata.get_virtual_facts()
    assert result == {'virtualization_tech_host': set(['zone']),
                      'virtualization_tech_guest': set([]),
                      'virtualization_type': '',
                      'virtualization_role': ''}

    # Test `zonename` returns non-global zone
    module.run_command = lambda x: (
        0,
        "non-global",
        ""
    )
   

# Generated at 2022-06-23 02:43:15.443280
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_vc = SunOSVirtualCollector()
    assert sunos_vc.platform == 'SunOS'

# Generated at 2022-06-23 02:43:17.218618
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_collector = SunOSVirtualCollector()
    assert test_collector.fact_class is SunOSVirtual

# Generated at 2022-06-23 02:43:18.643103
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.virtualization_type == 'zone'

# Generated at 2022-06-23 02:43:22.121565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert isinstance(x, VirtualCollector)
    assert x.virtual.platform == 'SunOS'
    assert isinstance(x.virtual, Virtual)



# Generated at 2022-06-23 02:43:23.868978
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v is not None
    assert v._platform == 'SunOS'

# Generated at 2022-06-23 02:43:34.136229
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict())
    # test that the correct platform is set
    assert virt.platform == "SunOS"
    # test that the correct fields are set to None
    assert virt.virt_what is None
    assert virt.zone is None

    # test that the correct fields are set to empty sets
    assert virt.domaining_host == set()
    assert virt.domaining_guest == set()
    assert virt.zone_guest == set()
    assert virt.zone_host == set()

    # test that the correct fields are set to None
    assert virt.zonename is None

    # test that the correct fields are set to empty dicts
    assert virt.virtual_facts == {}
    assert virt.virtual_commands == {}



# Generated at 2022-06-23 02:43:42.286398
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of SunOSVirtual
    test_obj = SunOSVirtual()

    # Create mocks
    test_obj.module = Mock()
    test_obj.module.run_command.return_value = 0, "", ""
    test_obj.module.get_bin_path.return_value = False

# Generated at 2022-06-23 02:43:47.422823
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    facts = SunOSVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': 'None',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:43:55.305233
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts=SunOSVirtual()
    assert 'virtualization_type' in virtual_facts.get_virtual_facts().keys()
    assert 'virtualization_role' in virtual_facts.get_virtual_facts().keys()
    assert 'virtualization_tech_guest' in virtual_facts.get_virtual_facts().keys()
    assert 'virtualization_tech_host' in virtual_facts.get_virtual_facts().keys()
    assert 'container' in virtual_facts.get_virtual_facts().keys()
    assert 'zone' in virtual_facts.get_virtual_facts()['virtualization_tech_guest']

# Generated at 2022-06-23 02:43:57.966330
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Constructor of SunOSVirtualCollector does not have functions call
    # so it is enough for unit testing
    virtual_collector = SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:59.586671
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert isinstance(v, SunOSVirtualCollector)


# Generated at 2022-06-23 02:44:10.235663
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual

    Virtual.module = SunOSVirtual.module = FakeModule()

    def run_command(command):
        '''This method is used to mock out run_command'''
        return command_return[command]

    Virtual.module.run_command = run_command

    Virtual.module.get_bin_path = lambda x: x


# Generated at 2022-06-23 02:44:13.506347
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = Virtual(None)
    assert isinstance(virtual_facts, SunOSVirtual)

# Generated at 2022-06-23 02:44:16.884909
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert issubclass(collector._fact_class, Virtual)
    assert isinstance(collector._fact_class(), Virtual)

# Generated at 2022-06-23 02:44:20.165425
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector



# Generated at 2022-06-23 02:44:22.687312
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._fact_class is SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:44:25.702290
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvc = SunOSVirtualCollector()
    assert sunosvc._platform == 'SunOS'

# Generated at 2022-06-23 02:44:27.829747
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'



# Generated at 2022-06-23 02:44:31.923568
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    # Create an instance of Facts class
    facts = Facts()
    # create an instance of SunOSVirtual
    v = SunOSVirtual(facts)
    # Call get_virtual_facts
    v.get_virtual_facts()

# Generated at 2022-06-23 02:44:41.009039
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # tests for virtualization_type
    osname = 'SunOS'
    cls = SunOSVirtual(dict(module_utils=dict(basic=dict(_AnsibleModule=dict()))))
    cls.module.get_bin_path = Mock(return_value=None)
    assert cls.get_virtual_facts() == dict(virtualization_tech_host=set(), virtualization_tech_guest=set())

    cls.module.get_bin_path = Mock(return_value='/usr/sbin/smbios')
    cls.module.run_command = Mock(return_value=(0, '', ''))
    assert cls.get_virtual_facts() == dict(virtualization_tech_host=set(), virtualization_tech_guest=set())

    cls.module.run_command = Mock