

# Generated at 2022-06-23 02:34:47.627496
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.module_common import AnsibleModule

    """
    This test method tests the get_virtual_facts method of SunOSVirtual class using the mock_module
    It checks the output of the get_virtual_facts method for the SunOS platform
    """

    def run_mocked_module(module):
        attrs = {
            'get_bin_path.return_value': "/usr/bin/smbios",
            'run_command.return_value': (0, "VirtualBox", ""),
        }
        mock_module = type('AnsibleModule', (object,), attrs)
        return module.get_virtual_facts(mock_module)

    module = SunOSVirtual()

    result = run_

# Generated at 2022-06-23 02:34:54.164338
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    virt_facts_collector = SunOSVirtualCollector(module)
    virtual_facts = virt_facts_collector.collect()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:34:56.287695
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual(None)
    assert sunosvirtual is not None


# Generated at 2022-06-23 02:34:58.631903
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:35:04.676528
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts
    assert isinstance(virtual_facts, dict)
    assert virtual_facts.get('virtualization_type')
    assert virtual_facts.get('virtualization_role')
    assert virtual_facts.get('container')


# Generated at 2022-06-23 02:35:06.940147
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:35:10.284578
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_virtual_facts() is None

# Generated at 2022-06-23 02:35:17.636081
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not module.check_mode:
        module.run_command = MagicMock(return_value=(0, '', ''))
        module.get_bin_path = MagicMock(return_value=True)

    module.params = {'gather_subset': '!all'}
    fact_instance = SunOSVirtual(module)
    fact_instance.get_virtual_facts()

# Generated at 2022-06-23 02:35:19.939090
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({'PATH': '/bin'})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-23 02:35:29.274429
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class TestModule:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, args):
            return (self.rc, self.out, self.err)

        def get_bin_path(self, arg):
            if arg == 'zonename':
                return True
            elif arg == "modinfo":
                return True
            elif arg == "smbios":
                return True
            else:
                return None

    def test_get_virtual_facts_failed_rc(out, err):
        module = TestModule(1, out, err)
        sunos_virtual = SunOSVirtual(module)
        virtual_facts = sunos_virtual.get_virtual_facts()
        assert not virtual_

# Generated at 2022-06-23 02:35:31.450701
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize the class
    SunOSVirtual_obj = SunOSVirtual()
    # Run method
    SunOSVirtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:35:33.681532
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.get_virtual_facts().__class__.__name__ == "dict"

# Generated at 2022-06-23 02:35:35.590192
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._fact_class is SunOSVirtual
    assert x._platform is 'SunOS'

# Generated at 2022-06-23 02:35:38.701249
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert isinstance(x._fact_class, SunOSVirtual)
    assert x._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:35:39.775130
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create an instance of SunOSVirtual class
    # verbose is set to False to suppress verbose output
    sun_os_virtual = SunOSVirtual(False)
    return sun_os_virtual

# Generated at 2022-06-23 02:35:42.222645
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert isinstance(vc, SunOSVirtualCollector), "did not instantiate a SunOSVirtualCollector"

# Generated at 2022-06-23 02:35:44.069754
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual().get_virtual_facts() is not None

# Generated at 2022-06-23 02:35:48.203979
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.fact_class == SunOSVirtual
    assert vc.platform == 'SunOS'

# Generated at 2022-06-23 02:35:49.516882
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual({})
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:35:51.724783
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    f = SunOSVirtualCollector()
    assert isinstance(f, VirtualCollector)
    assert f._platform == 'SunOS'
    assert f._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:35:57.435693
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import platform

    platform_system = platform.system()
    if platform_system != 'SunOS':
        pytest.skip('requires SunOS')

    # Instantiate class SunOSVirtual
    obj = SunOSVirtual()

    # Verify _platform
    assert obj._platform == 'SunOS'


# Generated at 2022-06-23 02:36:01.478934
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector(None, None).collect()
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'zone'

# Generated at 2022-06-23 02:36:03.532994
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:07.754669
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(None)
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtual_facts['virtualization_tech_guest'] == set()
    assert sunos_virtual.virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:36:15.746766
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test method get_virtual_facts
    # arguments:
    # returns:
    # raises:
    print("Test method get_virtual_facts of class SunOSVirtual\n")
    # class DummyModule:
    #     def __init__(self):
    #         self.params = {}
    #     def get_bin_path(self, arg_1):
    #         return ""
    # class DummyVirtual:
    #     def __init__(self):
    #         self.module = DummyModule()
    # test_SunOSVirtual = SunOSVirtual()
    # test_SunOSVirtual.module = DummyModule()
    # assert test_SunOSVirtual.get_virtual_facts() == None

# Generated at 2022-06-23 02:36:19.402306
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Should have only 'virtualization_type', 'virtualization_role', and 'container' keys
    # in the dictionary returned by the SunOSVirtual.get_virtual_facts() method.
    virtual_facts = SunOSVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert len(virtual_facts) == 3

# Generated at 2022-06-23 02:36:26.886621
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import TestModule
    module = TestModule()
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': 'ldom',
        'virtualization_role': 'host (control)',
        'container': 'zone',
        'virtualization_tech_guest': {'zone', 'ldom'},
        'virtualization_tech_host': {'zone'}
    }


# Generated at 2022-06-23 02:36:29.131756
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual



# Generated at 2022-06-23 02:36:38.030079
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    fixture = { 'module': {'get_bin_path': lambda _: '/usr/sbin/zonename'},
            'run_command': lambda _: (0, 'global', '') }
    sunos_virtual = SunOSVirtual(fixture)
    assert sunos_virtual.platform == 'SunOS'
    sunos_virtual._virtual_facts = {}
    sunos_virtual.get_virtual_facts()
    assert sunos_virtual._virtual_facts['virtualization_tech_host'] == set()
    assert sunos_virtual._virtual_facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-23 02:36:44.830729
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    virtual_facts = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': 'zone',
        'virtualization_tech_host': None,
        'container': 'zone',
    }

    SunOSVirtual = SunOSVirtual()
    virtual_facts_get = SunOSVirtual.get_virtual_facts()

    assert virtual_facts == virtual_facts_get

# Generated at 2022-06-23 02:36:47.223663
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.__class__ is SunOSVirtual

# Generated at 2022-06-23 02:36:54.923382
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-23 02:36:59.027484
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:37:01.629421
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class == SunOSVirtual
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:37:03.422290
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert isinstance(c, SunOSVirtualCollector)


# Generated at 2022-06-23 02:37:06.699736
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    sv = SunOSVirtual(dict())

    assert sv.platform == 'SunOS'
    assert sv._virtual_facts == {}


# Generated at 2022-06-23 02:37:14.115348
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    SunOSVirtualCollector.collect(module)
    facts = module.exit_json['ansible_facts']
    assert 'virtualization_tech_guest' in facts['ansible_virtualization_facts']
    assert 'virtualization_tech_host' in facts['ansible_virtualization_facts']
    assert 'virtualization_type' in facts['ansible_virtualization_facts']
    assert 'virtualization_role' in facts['ansible_virtualization_facts']
    assert 'container' in facts['ansible_virtualization_facts']

# All classes below are used for unit testing only

# Generated at 2022-06-23 02:37:20.718679
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})

    keys = set(sunos_virtual.data.keys())
    assert 'virtualization_role' in keys
    assert 'virtualization_type' in keys
    assert 'virtualization_tech_host' in keys
    assert 'virtualization_tech_guest' in keys
    assert 'container' in keys
    assert 'system_id' not in keys

# Generated at 2022-06-23 02:37:27.204575
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module and instance of SunOSVirtual
    mock_module = Mock()
    mock_module.run_command.return_value = (0, "global", "")
    virtual = SunOSVirtual(mock_module)
    virtual_facts = virtual.get_virtual_facts()

    # Assert that the output of the get_virtual_facts method is correct
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert not virtual_facts['virtualization_tech_guest']

if __name__ == '__main__':
    # Unit test
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:37:29.249813
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({'module': True})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:37:34.760771
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.collect()

    assert isinstance(facts, dict)
    assert not facts['is_virtual']

# Generated at 2022-06-23 02:37:40.361125
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import datetime
    mock_time = datetime.datetime(2020, 1, 1)

    # Test with no arguments provided to constructor
    # Required arguments are (module, platform, time)
    sunos_virtual = SunOSVirtual(None, 'SunOS', mock_time)
    assert sunos_virtual.module is None
    assert sunos_virtual.time == mock_time

# Generated at 2022-06-23 02:37:48.915661
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'
    assert isinstance(x.virtualization_type_command(), str)
    assert isinstance(x.get_virtual_facts(), dict)
    assert isinstance(x.get_virtual_facts()['virtualization_type'], str)
    assert isinstance(x.get_virtual_facts()['virtualization_role'], str)
    assert isinstance(x.get_virtual_facts()['virtualization_role'], str)
    assert isinstance(x.get_virtual_facts()['container'], str)


# Generated at 2022-06-23 02:37:50.330431
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts.platform == 'SunOS'

# Generated at 2022-06-23 02:37:52.993978
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector(None)
    assert facts_collector._fact_class == SunOSVirtual
    assert facts_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:38:01.346972
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Construct a mock module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    # Construct a mock module class
    sunos_virtual = SunOSVirtual(module)

    # Set values to the mock module attributes
    sunos_virtual.module.get_bin_path = MagicMock(
        name='get_bin_path',
        return_value='/bin/echo')

    sunos_virtual.module.run_command = MagicMock(
        name='run_command',
        return_value=(0, 'test output', ''))

    # Construct virtual_facts
    virtual_facts = {}

    # Set values to the mock module attributes
    sunos_virtual.module.get_bin_path.return_value = '/bin/echo'
    sunos_virtual.module.run

# Generated at 2022-06-23 02:38:08.909505
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.sunos.facts import SunOSVirtual

    # Test zone detection
    with patch.object(SunOSVirtual, "_run_command", return_value=(0, "global", "")):
        assert SunOSVirtual().get_virtual_facts()['virtualization_tech_host'] == {'zone'}
    with patch.object(SunOSVirtual, "_run_command", return_value=(0, "not_global", "")):
        assert SunOSVirtual().get_virtual_facts()['virtualization_tech_guest'] == {'zone'}
        assert SunOSVirtual().get_virtual_facts()['container']

# Generated at 2022-06-23 02:38:10.819842
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:38:16.587944
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Create an instance of the SunOSVirtual class with
    all of it's arguments set to None and check that
    the instance was created as expected.
    :return: True
    """
    mod = None
    vc = SunOSVirtual(module=mod)
    assert vc is not None
    assert vc.module is mod
    assert vc.platform == 'SunOS'

# Generated at 2022-06-23 02:38:18.524703
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    coll = SunOSVirtualCollector()
    assert coll.platform == 'SunOS'
    assert coll.fact_class == SunOSVirtual


# Generated at 2022-06-23 02:38:22.248793
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
        vc = SunOSVirtualCollector()
        assert vc.platform == 'SunOS'
        assert vc._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:38:28.745215
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import pytest
    mock_module = pytest.Mock()
    mock_module.run_command = pytest.Mock(return_value=(0, 'global', ''))
    mock_module.get_bin_path = pytest.Mock(return_value=True)

    v = SunOSVirtual(mock_module)

    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.virtualization_tech_host == set(['zone'])
    assert v.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:38:38.520540
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a virtual class object
    SunOSVirtualObject = SunOSVirtual(module=None)

    # Create a dictionary which will be used as input for the virtual method
    # get_virtual_facts of class SunOSVirtual
    #
    # Expected module results for a global zone of a ZFS root with a ZFS pool called rpool
    # Solaris 11.x:
    # > zonename
    # global
    #
    # > modinfo | grep VMware
    # 32 28 0x8f7bc000 5b6f7 1 vmnet (VMware Virtual Ethernet Module)
    # 33 13 0x8f8bb000 801dc 1 vmmon (VMware Virtual Machine Monitor)
    #
    # > modinfo | grep VirtualBox
    # 46 78 0x6df7c000 1dfac6 1 vboxdrv (VirtualBox

# Generated at 2022-06-23 02:38:43.404164
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # A concrete instance of class SunOSVirtualCollector has to be created
    # in order to call the constructor of class VirtualCollector
    test_collector = SunOSVirtualCollector()
    assert test_collector.fact_class == SunOSVirtual
    assert test_collector.platform == 'SunOS'

# Generated at 2022-06-23 02:38:54.493236
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # fact_subclass is instantiated with module arg as test-module
    fact_subclass = SunOSVirtual({})
    # 'virtualization_type' and 'virtualization_role' are initialized with 'unknown'
    assert fact_subclass.data['virtualization_type'] == 'unknown'
    assert fact_subclass.data['virtualization_role'] == 'unknown'
    # 'virtualization_type' and 'virtualization_role' are converted to lower case
    assert fact_subclass.data['virtualization_type'].islower(), "virtualization_type is not in lower case"
    assert fact_subclass.data['virtualization_role'].islower(), "virtualization_role is not in lower case"

# Generated at 2022-06-23 02:39:02.569615
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, "global\n", ""))
    module.get_bin_path = Mock(return_value="")

    sunos_virtual = SunOSVirtual(module)
    result = sunos_virtual.get_virtual_facts()
    assert result['container'] == "zone"
    assert result['virtualization_role'] == 'host'
    assert result['virtualization_type'] == 'zone'
    assert 'virtualization_tech_guest' not in result
    assert 'virtualization_tech_host' not in result



# Generated at 2022-06-23 02:39:05.601633
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Unit test to test constructor of SunOSVirtualCollector."""
    result = SunOSVirtualCollector(None)
    assert result._platform == 'SunOS'
    assert result._fact_class._platform == 'SunOS'

# Generated at 2022-06-23 02:39:08.215433
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v._platform == 'SunOS'
    assert type(v._virtual_facts_class) == dict
    assert v._fact_class == SunOSVirtual


# Generated at 2022-06-23 02:39:09.076454
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:39:13.692200
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Define some variables to return by get_bin_path method
    modinfo = 'modinfo'
    zonename = 'zonename'
    virtinfo = 'virtinfo'
    smbios = 'smbios'

    # Define some variables to return by run_command method
    rc = 0
    out = ''
    err = ''

    # Define some variables used by the test
    virtual_type = 'none'
    virtual_role = 'guest'
    container = 'none'
    guest_tech = set()
    host_tech = set()
    virtual_facts = {}
    zone_type = 'global'

    # Define a dictionary of expected results

# Generated at 2022-06-23 02:39:23.425948
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.module == module
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtual_facts == {
        'container': 'zone',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': {},
        'virtualization_type': 'zone',
        'virtualization_role': 'guest'
    }

# Generated at 2022-06-23 02:39:25.718653
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector().collect()
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:39:28.661350
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:39:31.621750
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos
    assert isinstance(sunos, SunOSVirtualCollector)
    assert sunos._platform == 'SunOS'

# Generated at 2022-06-23 02:39:35.520220
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # create instance of class SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector()

    # Check instance
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)

    # Check type of instance
    assert isinstance(sunos_virtual_collector, VirtualCollector)

# Generated at 2022-06-23 02:39:38.497065
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual('module')
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-23 02:39:44.035513
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts_obj = SunOSVirtual()
    assert 'Facts' in facts_obj.__dict__
    assert 'System' in facts_obj.__dict__
    assert facts_obj.platform == 'SunOS'
    assert facts_obj.module == 'ansible.module_utils.facts.virtual.sunos'


# Generated at 2022-06-23 02:39:45.943827
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    cmd = SunOSVirtualCollector()

    assert cmd is not None
    assert cmd._platform == 'SunOS'
    return cmd

# Generated at 2022-06-23 02:39:49.997117
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This function tests the constructor of the class SunOSVirtualCollector.
    """
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'


# Generated at 2022-06-23 02:39:55.347447
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Some fake modules
    module = type('FakeModule', (object,), {
        'run_command': lambda self, args: (0, '', ''),
        'get_bin_path': lambda self, arg: arg,
    })

    # Ensure that the class is initialized
    SunOSVirtual(module)

    # Ensure that the all facts returned by get_virtual_facts,
    # are in the facts dictionary returned by the collect() method
    assert(all(fact in SunOSVirtual(module).get_virtual_facts() for fact in SunOSVirtual(module).collect().keys()))

# Generated at 2022-06-23 02:40:03.961308
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    unit test for making sure SunOSVirtual can be instantiated correctly
    :return:
    '''
    module = None
    virtual = SunOSVirtual(module)
    assert(virtual.get_virtual_facts().get('virtualization_type') is None)
    assert(virtual.get_virtual_facts().get('virtualization_role') is None)
    assert(virtual.get_virtual_facts().get('virtualization_tech_host') == set())
    assert(virtual.get_virtual_facts().get('virtualization_tech_guest') == set())
    assert(virtual.get_virtual_facts().get('container') is None)

# Generated at 2022-06-23 02:40:06.336137
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Construct and verify a SunOSVirtual object
    v = SunOSVirtual(dict())

    # Test the subclass platform with the base class method.
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:40:07.303229
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no args
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:09.334421
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt = SunOSVirtual()
    facts = virt.get_virtual_facts()
    assert facts == {}

# Generated at 2022-06-23 02:40:13.195446
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    with_virtual_facts = SunOSVirtual(dict())
    assert with_virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:40:23.699699
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import json

    # Invalid command
    v = SunOSVirtual(dict(module=dict(run_command=lambda x: (1, '', ''))))
    assert v.get_virtual_facts() == {}

    # Not a zone
    v = SunOSVirtual(dict(module=dict(run_command=lambda x: (0, 'global', ''))))
    assert v.get_virtual_facts() == {}

    # Zone
    v = SunOSVirtual(dict(module=dict(run_command=lambda x: (0, 'foo', ''))))

# Generated at 2022-06-23 02:40:25.549006
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:40:27.641323
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('Module', (object, ), {'get_bin_path': lambda *args: None})
    SunOSVirtualCollector(module).collect()

# Generated at 2022-06-23 02:40:32.562142
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test SunOSVirtualCollector has been initialized as expected
    collector = SunOSVirtualCollector()

    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual
    assert collector._fact_class.platform == collector.platform

# Generated at 2022-06-23 02:40:34.117398
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # create the class with a mocked module
    app = SunOSVirtual({})

    assert app.platform == 'SunOS'

# Generated at 2022-06-23 02:40:35.448474
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({}, {}, {})


# Generated at 2022-06-23 02:40:46.123724
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual(None)
    virtual._module = FakeAnsibleModule()
    virtual._module.run_command = lambda x: (0, "VMware\nVirtualBox\n", "")
    result = virtual.get_virtual_facts()
    assert result['container'] == 'zone'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] in ('vmware', 'virtualbox')
    assert 'zone' in result['virtualization_tech_guest']
    assert 'vmware' in result['virtualization_tech_guest']
    assert 'virtualbox' in result['virtualization_tech_guest']


# Generated at 2022-06-23 02:40:54.345297
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class SunOSVirtual
    """
    import os
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = os.path.dirname(__file__) + '/resources/mock_uname.py'
    os.environ['PATH'] = os.path.dirname(__file__) + '/resources/bin:' + os.environ['PATH']

    obj = SunOSVirtual(module)
    v = obj.get_virtual_facts()
    assert v['virtualization_type'] == 'zone'
    assert v['virtualization_role'] == 'guest'
    assert v['container'] == 'zone'

# Generated at 2022-06-23 02:41:03.401125
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class SunOSVirtual."""
    #
    # Create a module, and add some facts to get_virtual_facts
    #
    module = FakeModule(
        params={
            'ansible_facts': {
                'ansible_system': 'SunOS',
            }
        }
    )
    #
    # Create a object SunOSVirtual for testing its method get_virtual_facts
    sunos_virtual = SunOSVirtual(module)

    # Test get_virtual_facts
    sunos_virtual.get_virtual_facts()

    # Test that we get the expected virtual facts
    # Check the virtualization_type
    assert sunos_virtual.facts['virtualization_type'] == 'vmware'
    # Check the virtualization_role

# Generated at 2022-06-23 02:41:07.734094
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Constructor without arguments
    virtual = SunOSVirtual()

    # Check some members were initialized to an empty string
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_system == ''

    # Check the platform was detected correctly
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:41:09.096868
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == "SunOS"

# Generated at 2022-06-23 02:41:15.314471
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = mock.MagicMock()
    module.get_bin_path.side_effect = lambda x: '/usr/sbin/' + x
    sunos_virtual_cls = SunOSVirtual(module=module)
    assert '/usr/sbin/' == sunos_virtual_cls.module.get_bin_path('/usr/sbin/')

# Generated at 2022-06-23 02:41:25.162757
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test of method get_virtual_facts'''
    import os
    import tempfile
    test_file = tempfile.NamedTemporaryFile(
        delete=False, mode='wt', encoding='utf-8')
    test_file.write('/usr/sbin/zonename\n')
    test_file.write('/usr/sbin/virtinfo -p\n')
    test_file.write('/usr/sbin/smbios\n')
    test_file.write('/usr/sbin/modinfo\n')
    test_file.close()


# Generated at 2022-06-23 02:41:30.066325
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = MagicMock(name='module', spec=AnsibleModule)
    module.params = dict(
    )
    setattr(module, "run_command", MagicMock(return_value=(0, b"foo", b"bar")))
    setattr(module, "get_bin_path", MagicMock(return_value=True))
    sunos_virtual = SunOSVirtualCollector.fetch_virtual_facts(module)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:41:38.043853
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_virtuals = SunOSVirtualCollector(None, None, None)
    assert sun_virtuals.platform == 'SunOS'
    assert sun_virtuals.__class__.__bases__[0].__name__ == 'VirtualCollector'
    assert sun_virtuals.__class__.__bases__[0].__bases__[0].__name__ == 'object'



# Generated at 2022-06-23 02:41:40.420779
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:42.180770
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:53.000574
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()

    zonename = "/bin/zonename"
    module.run_command.return_value = (0, "global", "")
    module.get_bin_path.return_value = zonename
    module.isdir.return_value = False
    x = SunOSVirtual(module)
    result = x.get_virtual_facts()
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == {'zone'}

    modinfo = "/bin/modinfo"
    module.run_command.return_value = (0, "VMware", "")
    module.get_bin_path.return_value = modinfo
    x = SunOSVirtual(module)
    result = x.get_virtual_facts()

# Generated at 2022-06-23 02:41:57.066536
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector
    assert sunos_virtual_collector._fact_class
    assert sunos_virtual_collector._platform == 'SunOS'


# Unit test specific to SunOSVirtual Collector
# Include tests for all functions in class SunOSVirtual

# Generated at 2022-06-23 02:42:02.041140
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('DummyModule', (object,), dict(run_command=lambda x,y,z: (0, "", "")))()
    SunOSVirtual(module).populate()
    assert 'virtualization_role' in module.ansible_facts['virtualization']

# Generated at 2022-06-23 02:42:08.498698
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    collector = SunOSVirtualCollector(module=module)
    facts = collector.collect()['ansible_facts']
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:42:10.436364
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt.platform == 'SunOS'

# Generated at 2022-06-23 02:42:21.197001
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Success
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    mock_module = MockModule({'run_command': (0, '', '')})
    mock_module.run_command = Mock(return_value=(0, '', ''))
    virtual = SunOSVirtual(mock_module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == None
    assert virtual_facts['virtualization_role'] == None
    assert virtual_facts['container'] == None
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Failure
    mock_module = MockModule({'run_command': (1, '', 'error')})

# Generated at 2022-06-23 02:42:25.135237
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Constructor test of class SunOSVirtualCollector
    '''
    # Test with no args
    SunOSVirtualCollector()
    # Test with invalid argument
    try:
        SunOSVirtualCollector(None)
    except TypeError as err:
        assert "argument must be a string" in str(err)

# Generated at 2022-06-23 02:42:26.279521
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:42:29.657381
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock({})
    sunosvirtual_class = SunOSVirtual(module)
    assert sunosvirtual_class.platform == 'SunOS'
    assert sunosvirtual_class.module == module



# Generated at 2022-06-23 02:42:30.690909
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # use sunos_virtual_facts fixture
    pass

# Generated at 2022-06-23 02:42:31.349244
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Nothing to test
    return

# Generated at 2022-06-23 02:42:38.487639
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector()
    fact_collector.collect()
    facts = fact_collector.get_facts()
    virtual_facts = SunOSVirtual(facts).get_virtual_facts()
    print(virtual_facts)
    assert isinstance(virtual_facts, dict)


if __name__ == "__main__":
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:42:40.122553
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert isinstance(collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:42:48.955450
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This is a test function for method get_virtual_facts of class SunOSVirtual
    """
    #Test case 1: when test_module is None
    test_module = None

    #Test case 1.1: when /usr/sbin/virtinfo -p returns "virtinfo can only be run from the global zone"
    test_SunOSVirtual = SunOSVirtual(test_module)
    test_SunOSVirtual.module.run_command = lambda x: [0, """virtinfo can only be run from the global zone""", '']
    assert test_SunOSVirtual.get_virtual_facts() == {}

    #Test case 1.2: when /usr/sbin/virtinfo -p returns "Invalid argument" and virtualization_type is vmware
    test_SunOSVirtual = SunOSVirtual(test_module)
    test_Sun

# Generated at 2022-06-23 02:42:59.867003
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, SunOSVirtual
    from ansible.module_utils.facts import FactCollector
    import unittest

    class TestVirtual(Virtual):
        def __init__(self):
            self.module = AnsibleModule_get_bin_path()

        def _get_platform(self):
            return 'SunOS'

    class TestSunOSVirtual(SunOSVirtual):
        """
        This is a subclass of SunOSVirtual.

        It overrides the following methods:

        - get_virtual_facts
        - _get_platform
        """
        def get_virtual_facts(self):
            return SunOSVirtual.get_virtual_facts(self)

        def _get_platform(self):
            return 'SunOS'


# Generated at 2022-06-23 02:43:02.898624
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert issubclass(c._fact_class, Virtual)


# Generated at 2022-06-23 02:43:05.165808
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:43:16.625054
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Set up mock facts module
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    # Parse virtual facts from ldom output
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'ldom'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'zone', 'ldom'}
    assert virtual_facts['virtualization_tech_host'] == {'zone'}

# Generated at 2022-06-23 02:43:20.324013
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = Mock()
    module.get_bin_path.return_value = "foo/bar/baz"
    module.run_command.return_value = 0, "virtinfo can only be run from the global zone", ""

    sunos = SunOSVirtual(module)
    assert sunos.module == module
    assert sunos.platform == 'SunOS'

# Generated at 2022-06-23 02:43:32.215746
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Define a fake class for the virtual module
    class FakeModule():
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_failure = False

        def get_bin_path(self, bin):
            if bin == 'zonename':
                return bin

        def run_command(self, cmd):
            self.run_command_calls += 1
            if self.run_command_calls == 1:
                return (0, "global", "")
            elif self.run_command_calls == 2:
                return (0, "zonename: not found", "")
            elif self.run_command_calls == 3:
                return (0, "modinfo: not found", "")

# Generated at 2022-06-23 02:43:42.974323
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This returns virtual facts for a SunOS system.
    """
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import sys

    if sys.version_info[0:2] == (2, 6):
        class ModuleStub:
            @classmethod
            def run_command(cls, command):
                if command == "/usr/sbin/virtinfo -p":
                    return 0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", ""
                else:
                    return 0, "", ""
            @classmethod
            def get_bin_path(cls, command):
                if command == "zonename":
                    return "/usr/sbin/zonename"

# Generated at 2022-06-23 02:43:44.901187
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt_collector = SunOSVirtualCollector(None)
    assert isinstance(virt_collector, VirtualCollector)

# Generated at 2022-06-23 02:43:47.775628
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This function returns true when the constructor of the class SunOSVirtualCollector
    does not return a null object.
    """
    obj = SunOSVirtualCollector(None)
    if obj is None:
        return False
    else:
        return True

# Generated at 2022-06-23 02:43:57.989340
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()

    # SunOS zone - zonename: global
    module.run_command.return_value = 0, "global", ''
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'zone' not in virtual_facts['virtualization_tech_guest']
    module.run_command.assert_called_with('/bin/zonename')

    # SunOS branded zone - zonename: non global
    module.run_command.return_value = 0, "non global", ''
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'zone' not in virtual_facts['virtualization_tech_host']
   

# Generated at 2022-06-23 02:44:07.930251
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Tries a SunOS VM running in a VMware VM
    module = type('', (object,), {'params': {}, 'run_command': lambda *args, **kwargs: (0, "", "")})
    module.get_bin_path = lambda *args: "/usr/bin/vmware"
    facts = SunOSVirtual(module).collect()
    assert 'container' not in facts
    assert 'virtual' in facts
    assert facts['virtual'] == 'vmware'
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'vmware'}

# Generated at 2022-06-23 02:44:10.185374
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """SunOSVirtualCollector(): test the constructor and the name"""
    sunos_virtual_collector = SunOSVirtualCollector()
    assert(sunos_virtual_collector)

# Generated at 2022-06-23 02:44:19.958558
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fixture = """
[global]
zonename: global

[zone]
zonename: testzone1

[zone]
zonename: testzone2
"""
    results = {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set()
    }

    module = FakeModule(fixture)
    virtual = SunOSVirtual(module)
    assert virtual.get_virtual_facts() == results



# Generated at 2022-06-23 02:44:26.628001
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    instance = SunOSVirtualCollector()
    if instance.platform != 'SunOS':
        raise AssertionError("SunOSVirtualCollector has a wrong value")
    if instance._fact_class != SunOSVirtual:
        raise AssertionError("SunOSVirtualCollector has a wrong value")
    if instance._platform != 'SunOS':
        raise AssertionError("SunOSVirtualCollector has a wrong value")

# Generated at 2022-06-23 02:44:29.267086
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test = SunOSVirtual()
    assert test.platform == 'SunOS'

# Unit tests for constructor of class SunOSVirtualCollector

# Generated at 2022-06-23 02:44:31.522246
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.virtual is True

# Generated at 2022-06-23 02:44:40.579751
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, rc, out, err, path):
            self.run_command_rc = rc
            self.run_command_out = out
            self.run_command_err = err
            self.run_command_path = path
            self.run_command_called = False

        def get_bin_path(self, arg):
            return self.run_command_path

        def run_command(self, cmd):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_out, self.run_command_err

    # Case where module.get_bin_path returns None
    module = MockModule(None, None, None, None)
    virtual = SunOSVirtual(module)
    assert virtual.get_virtual_facts