

# Generated at 2022-06-23 02:34:38.551398
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector


# Generated at 2022-06-23 02:34:48.368456
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import ModuleStub
    import json
    from collections import namedtuple

    module = ModuleStub()

    ##########################################
    # zonename: global
    # modinfo: not run
    # virtinfo: not run
    # smbios: not run
    out = {
        'virtualization_role': 'host',
        'virtualization_type': 'zone',
        'virtualization_tech_host': set(['zone']),
        'virtualization_tech_guest': set()
    }
    # mock module.run_command to return global zone

# Generated at 2022-06-23 02:34:52.796130
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector.platform == 'SunOS'
    assert sunos_virtual_collector.fact_class == SunOSVirtual
    assert sunos_virtual_collector.fact_name == 'virtual'

# Generated at 2022-06-23 02:34:58.542234
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create the SunOSVirtual object
    sunos_virtual = SunOSVirtualCollector.fetch_virtual_facts(None, None)

    # Test is_virtual_facts() method
    assert sunos_virtual.is_virtual_facts()

    # Test get_virtual_facts() method
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert 'container' in virtual_facts

# Generated at 2022-06-23 02:35:09.833090
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    import os
    import os.path
    import shutil

    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual, SunOSVirtualCollector

    import ansible.module_utils.facts.virtual.sunos

    # Fake module
    class FakeModule:
        def __init__(self):
            self.run_command = FakeModule.run_command

        def get_bin_path(self, arg):
            if arg == 'zonename':
                return '/sbin/zonename'
            elif arg == 'modinfo':
                return '/sbin/modinfo'
            elif arg == 'virtinfo':
                return '/usr/sbin/virtinfo'

# Generated at 2022-06-23 02:35:12.647221
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    ''' Testing constructor of class SunOSVirtualCollector'''
    obj = SunOSVirtualCollector()
    assert obj != "", "Error creating SunOSVirtualCollector class"

# Generated at 2022-06-23 02:35:21.091327
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule({
        'smbios': 'bin/smbios',
        'zonename': 'bin/zonename',
        'virtinfo': 'bin/virtinfo',
    })
    sun_virtual = SunOSVirtual(module)
    virtual_facts = sun_virtual.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:35:22.091794
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({})


# Generated at 2022-06-23 02:35:24.320808
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    sunos = SunOSVirtual(module)
    assert sunos.platform == "SunOS"

# Generated at 2022-06-23 02:35:26.760321
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    host_facts = dict(machine='sparc64', virtualization_tech_guest=set(), virtualization_tech_host=set())
    SunOSVirtual(False, host_facts)

# Generated at 2022-06-23 02:35:28.294549
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == 'SunOS'



# Generated at 2022-06-23 02:35:35.923729
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module=module)

    zonename = module.get_bin_path('zonename')
    modinfo = module.get_bin_path('modinfo')
    virtinfo = module.get_bin_path('virtinfo')
    smbios = module.get_bin_path('smbios')

    test_cases = []
    # Test Case 1: We are in a non-global zone and our global zone is virtualized

# Generated at 2022-06-23 02:35:38.647334
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test that the class SunOSVirtualCollector can be instantiated. """
    facts = SunOSVirtualCollector()
    assert isinstance(facts, SunOSVirtualCollector)


# Generated at 2022-06-23 02:35:41.391755
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Check whether all attributes of SunOSVirtual class are initialized properly
    """
    sunos_virtual = SunOSVirtual(None)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:35:42.004708
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()

# Generated at 2022-06-23 02:35:52.088523
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_obj = SunOSVirtual()
    test_facts = {
        'kernel': 'SunOS',
        'kernel_version': '5.11'
    }
    zonename = test_obj.module.get_bin_path('zonename')
    if zonename:
        test_obj.module.run_command = lambda x: (0, 'global', '')
        assert test_obj.get_virtual_facts(test_facts) == {'virtualization_tech_host': set(['zone'])}

        test_obj.module.run_command = lambda x: (0, 'testzone', '')
        assert test_obj.get_virtual_facts(test_facts) == {
            'virtualization_tech_guest': set(['zone']),
            'container': 'zone'
        }

# Generated at 2022-06-23 02:36:01.979185
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule([])
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    # These facts should be present in every machine
    assert 'container' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'

    assert set(virtual_facts['virtualization_tech_host']) == set(['zone'])
    assert set(virtual_facts['virtualization_tech_guest']) == set(['zone', 'vmware'])


# Helper class for unit testing

# Generated at 2022-06-23 02:36:04.623942
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert isinstance(sunos_virtual_collector, VirtualCollector)


# Generated at 2022-06-23 02:36:05.640948
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual() is not None

# Generated at 2022-06-23 02:36:15.037727
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.fake_virtuals import FakeVirtuals

    # Create an instance of FakeModule which is a child class of AnsibleModule
    # and is used for unit test
    module = FakeVirtuals()

    # Create an instance of SunOSVirtual which is a child class of Virtual
    # and is used for unit test
    test_class = SunOSVirtual(module)

    # Set the attributes of module and test_class, which can be retrieved by
    # AnsibleModule()/FakeModule() and SunOSVirtual()
    module.params = {}
    test_class.module = module

    # Run the unit test
    test_class.get_virtual_facts()

    # Assert the values returned by get_virtual_facts()


# Generated at 2022-06-23 02:36:18.594762
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:21.166301
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mc = SunOSVirtualCollector()
    assert mc._platform == 'SunOS'

# Generated at 2022-06-23 02:36:32.670587
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Only run the unit tests if the platform is SunOS
    import sys
    if sys.platform == 'sunos' or sys.platform == 'sunos5':
        import os
        import pytest
        from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
        from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

        sunos_virtual = SunOSVirtual(dict(), platform='SunOS')
        # Create a directory structure to allow check for zone
        os.makedirs('/etc/zones/.SUNWnative')
        virtual_facts_zone = sunos_virtual.get_virtual_facts()
        assert virtual_facts_zone['container'] == 'zone'
        assert 'virtualization_type' not in virtual_facts_zone

# Generated at 2022-06-23 02:36:34.970405
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert instance.platform == 'SunOS'
    assert instance._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:36:37.258726
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    # For now this is a no-op, but verify it exists
    virtual.get_virtual_facts()

# Generated at 2022-06-23 02:36:45.757024
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Workarounds to run this test independently
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.virtual.sunos
    ansible.module_utils.facts.virtual.sunos.Virtual = SunOSVirtual
    ansible.module_utils.facts.virtual.sunos.VirtualCollector = SunOSVirtualCollector
    ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector._fact_class = SunOSVirtual
    ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector._platform = 'SunOS'

    from ansible.module_utils.facts import ModuleTestCase
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-23 02:36:48.306963
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('Module', (), {})
    mod = SunOSVirtual(module)
    assert mod is not None

# Generated at 2022-06-23 02:36:52.235696
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Check that when a SunOSVirtual class is created that
    - It has the correct platform (SunOS)
    - It has the correct modules
    """
    sunosvirtual = SunOSVirtual({})
    assert sunosvirtual.platform == 'SunOS'
    assert sunosvirtual.modules == 'zone virtinfo smbios'


# Generated at 2022-06-23 02:37:01.773640
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """ Test SunOSVirtual and methods in this class
    """
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import FactCollector

    mock_module = FactCollector._create_mock_module()
    mock_module.run_command.return_value = (0, 'global', '')

    vm = SunOSVirtual(mock_module)
    assert vm.platform == 'SunOS'

    # test get_virtual_facts
    # vmware
    mock_module.get_bin_path.side_effect = [
        '/sbin/zonename',
        '/usr/sbin/smbios'
    ]
    mock_module.run_command.side_effect

# Generated at 2022-06-23 02:37:05.010376
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:37:08.422445
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:37:13.680484
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    module = FakeAnsibleModule()
    facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'container' in facts



# Generated at 2022-06-23 02:37:15.231938
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:37:19.671392
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:37:24.752298
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # There are no known virtualization platforms for SunOS that can run on other virtualization platforms
    platform_map = {}
    v = SunOSVirtual(platform_map)

    assert v.platform == 'SunOS'
    assert v.get_virtual_facts() == {}
    assert not Virtual.is_platform_Darwin(platform_map)

# Generated at 2022-06-23 02:37:26.659154
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, None)
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:37:31.743930
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = ansible_fake_module_new()
    virt = SunOSVirtual(module)

    # Check the platform attribute
    assert virt.platform == 'SunOS'

    # Check the virtual_facts attribute
    assert virt.virtual_facts == {}

    # Check the get_virtual_facts() method
    assert virt.get_virtual_facts() == {}


# Generated at 2022-06-23 02:37:34.600443
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a SunOSVirtual object
    sunos_virtual_obj = SunOSVirtual(None)

    assert sunos_virtual_obj.platform == 'SunOS'

# Generated at 2022-06-23 02:37:36.007051
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:37:38.714392
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    This test ensures that the class SunOSVirtual is working as expected.
    """
    facts = SunOSVirtual()
    assert isinstance(facts, SunOSVirtual)
    assert not facts.collect()



# Generated at 2022-06-23 02:37:40.099709
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x=SunOSVirtualCollector()
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:37:41.773116
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'

# Generated at 2022-06-23 02:37:44.019250
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'


# Generated at 2022-06-23 02:37:47.737536
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(None)
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_tech_host == set()
    assert sunos_virtual.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:37:48.750980
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:37:57.559748
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test case 1: Unbranded non-global zone
    module_obj = FakeModule(platform='SunOS',
                            virtualization_type=None,
                            virtualization_role=None,
                            container=None,
                            virtualization_tech_host=set(),
                            virtualization_tech_guest=set())

    module_obj.run_command = Mock(return_value=(0, 'zone1', ''))
    module_obj.get_bin_path = Mock(return_value='/usr/bin/zonename')
    module_obj.os.path.isdir = Mock(return_value=False)

    fact_class_obj = SunOSVirtual(module_obj)
    fact_class_obj.get_virtual_facts()

    assert module_obj.container == 'zone'
    assert module_obj.virtual

# Generated at 2022-06-23 02:37:58.457748
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:04.904906
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()

    facts_module = Virtual(module)
    facts_module.module.run_command = Mock(return_value=(0, '', ''))
    facts_module.module.get_bin_path.side_effect = lambda _: '/usr/bin/somecommand'

    assert facts_module.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest'
    }



# Generated at 2022-06-23 02:38:07.754448
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:38:11.343517
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'
    assert x.get_virtual_facts() is not None
    assert x._virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:38:13.894745
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert isinstance(v, SunOSVirtual)
    assert isinstance(v, Virtual)


# Generated at 2022-06-23 02:38:16.627508
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Create an instance of SunOSVirtualCollector for testing it
    """
    my_obj = SunOSVirtualCollector()
    assert my_obj


# Generated at 2022-06-23 02:38:18.546624
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:29.860154
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    def run_facts(cmd_output):
        module = FakeModule(cmd_output=cmd_output)
        facts = SunOSVirtual({}, module=module).get_virtual_facts()
        # On SunOS systems, we have to have a virtualization_role key
        assert 'virtualization_role' in facts
        return facts

    cases = {
        # Xen zones
        "domain role: guest\n",
        # Solaris zones
        "global\n",
    }
    for output in cases:
        facts = run_facts({'zonename': output})
        assert 'zone' in facts['virtualization_tech_host']
        assert facts['virtualization_role'] == 'guest'
        assert facts['container'] == 'zone'

    # vmware branded zones are detected by module_utils.facts.virtual.zone.zone_brand

# Generated at 2022-06-23 02:38:32.639192
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert isinstance(vc, SunOSVirtualCollector)
    assert isinstance(vc._fact_class, SunOSVirtual)


# Generated at 2022-06-23 02:38:35.038471
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    assert(virtual.module == module)



# Generated at 2022-06-23 02:38:42.577488
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.collector import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.sunos_virtinfo import SunOSVirtual

    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert isinstance(SunOSVirtualCollector._fact_class, Virtual)
    assert SunOSVirtualCollector._fact_class.platform is 'SunOS'

# Generated at 2022-06-23 02:38:46.426614
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:38:50.166573
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(
        argument_spec=dict()
    )

    virtual_obj = SunOSVirtual(module)
    assert virtual_obj.platform == "SunOS"


# Generated at 2022-06-23 02:38:55.598376
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    os_facts = dict()
    os_facts['distribution'] = 'SunOS'
    sv = SunOSVirtual(dict(module=None, os_facts=os_facts))
    assert sv.platform == 'SunOS'
    assert sv.distribution == 'SunOS'
    assert sv.facts == dict()


# Generated at 2022-06-23 02:38:57.938520
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:00.502371
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    x = SunOSVirtualCollector(facts, None)
    assert x._platform == 'SunOS'

# Generated at 2022-06-23 02:39:10.547947
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class MockModule(object):
        def __init__(self):
            self.params = {
                'all_logs': False,
                'gather_subset': None,
                'gather_timeout': 10,
                'filter': None,
                'log_dir': None,
                'separator': None,
                'splunk_url': None,
                'suppress_keys': '',
                'unsafe_writes': False,
                'validate_certs': False
            }

        def get_bin_path(self, cmd):
            if cmd == 'zonename':
                return '/usr/bin/zonename'
            elif cmd in ['modinfo', 'virtinfo', 'smbios']:
                return '/bin/' + cmd
            else:
                return None


# Generated at 2022-06-23 02:39:12.916330
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert hasattr(virtual, 'get_virtual_facts')

# Generated at 2022-06-23 02:39:25.085657
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class SunOSVirtual
    '''
    # Unit test for method get_virtual_facts of class SunOSVirtual
    #
    # Build a mock module
    #
    # FIXME: At the moment, we don't test the return of method run_command,
    # so we don't test the impact of the use of the installed command.
    #
    # Note: The return of method run_command is a tuple of the form (rc, out, err).
    # If rc is not 0, out is the content of err.
    #

    class MockModule(object):
        '''
        Mock class for a module.
        '''

        def __init__(self):
            self.run_command_calls = 0
            self.run_command_args = []
            self

# Generated at 2022-06-23 02:39:34.091477
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    sunos_virtual = SunOSVirtual(module)

    # Neither a zone nor a branded zone
    module.run_command.side_effect = [
        # zonename
        (1, '', ''),
        # modinfo
        (0, 'modinfo: module not found', ''),
        # virtinfo
        (1, '', ''),
        # smbios
        (0, '', '')
    ]

    expected_facts = {}

    facts = sunos_virtual.get_virtual_facts()
    assert facts == expected_facts
    assert module.run_command.call_count == 4

    # zonename

# Generated at 2022-06-23 02:39:37.411118
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # class instance
    SunOSVirtual_instance = SunOSVirtual(dict(), dict())
    assert isinstance(SunOSVirtual_instance, SunOSVirtual)

# Generated at 2022-06-23 02:39:41.517950
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.__doc__ is not None
    assert hasattr(SunOSVirtualCollector, '_fact_class')
    assert SunOSVirtualCollector._fact_class == SunOSVirtual



# Generated at 2022-06-23 02:39:53.315620
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Mock()
    module.get_bin_path.side_effect = lambda path: path

# Generated at 2022-06-23 02:39:59.633344
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# When executed, this code will make sure the SunOSVirtualCollector class is tested
if __name__ == "__main__":
    test_SunOSVirtualCollector()

# Generated at 2022-06-23 02:40:03.174057
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)
    assert x.platform == 'SunOS'
    assert x.fact_class == x._fact_class
    assert x.fact_class == SunOSVirtual


# Generated at 2022-06-23 02:40:06.963595
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test constructor of class SunOSVirtualCollector"""

    sunosvirtual_collector_inst = SunOSVirtualCollector()
    assert sunosvirtual_collector_inst._platform == 'SunOS'
    assert sunosvirtual_collector_inst._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:40:13.752265
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = lambda x: (0, "", "")
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert "zone" in facts['virtualization_tech_guest']
    assert len(facts['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:40:17.926381
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_vc = SunOSVirtualCollector()
    assert isinstance(sunos_vc, SunOSVirtualCollector)
    assert sunos_vc._fact_class is SunOSVirtual
    assert sunos_vc._platform == 'SunOS'



# Generated at 2022-06-23 02:40:20.850554
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test constructor of class VirtualCollector"""
    module = MagicMock()
    SunOSVirtualCollector(module)
    module().add_default_facts = True
    module().fail_on_missing_facts = True

# Generated at 2022-06-23 02:40:25.497453
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Creating SunOSVirtual object
    sunos_virtual_object = SunOSVirtual(None)
    # Checking the result of get_virtual_facts
    sunos_virtual_object._get_virtual_facts()

# Generated at 2022-06-23 02:40:27.934724
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    _SunOSVirtualCollector = SunOSVirtualCollector()
    assert _SunOSVirtualCollector._fact_class is not None
    assert _SunOSVirtualCollector._platform is not None

# Generated at 2022-06-23 02:40:36.436181
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    The test_SunOSVirtualCollector function performs a unit test on the constructor of class SunOSVirtualCollector.
    :return:
    """
    my_io = {}
    my_ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    my_test_fact_class = SunOSVirtualCollector(my_ansible_module, "test_file", my_io)
    assert my_test_fact_class._platform == 'SunOS'
    assert my_test_fact_class._fact_class().platform == 'SunOS'

# Generated at 2022-06-23 02:40:48.852052
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts.virtual.sunos.facts import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import get_bin_path

    def run_command(self, command):
        retcode = 0
        out = ''
        err = ''
        if command == get_bin_path('zonename') and os.path.isdir('/usr/lib/brand'):
            out = 'global\n'
        elif command == get_bin_path('zonename'):
            out = 'test\n'
        elif command == get_bin_path('modinfo'):
            out = """
36 fb       misc/vmware      VMware vmmemctl driver
37 fb       misc/vmware      VMware vmmemctl driver
            """

# Generated at 2022-06-23 02:40:59.406716
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *cmd, **kwargs: (0, "", ""),
        'get_bin_path': lambda *cmd, **kwargs: cmd[0]
    })

    mock_facts = type('AnsibleModule', (object,), {
        'virtual_facts': {}
    })

    test_subject = SunOSVirtual(mock_module)

    # test with kvm
    mock_module.run_command = lambda *cmd, **kwargs: (0, "VirtualBox", "")

# Generated at 2022-06-23 02:41:03.327927
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.module is not None


# Generated at 2022-06-23 02:41:04.694040
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._fact_class is not None

# Generated at 2022-06-23 02:41:07.386509
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = FakeModule()
    SunOSVirtual(m).get_virtual_facts()



# Generated at 2022-06-23 02:41:17.505594
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    # Test virtualization_tech_guest
    assert 'solaris' in virtual_facts['virtualization_tech_guest']

    # Test virtualization_tech_host
    assert 'global' in virtual_facts['virtualization_tech_host']

    # Test virtualization_role
    assert virtual_facts['virtualization_role'] == 'guest'

    # Test virtualization_type
    assert virtual_facts['virtualization_type'] == 'solaris'

    # Test container
    assert virtual_facts['container'] == 'zone'

from ansible.module_utils.basic import *  # noqa

# Generated at 2022-06-23 02:41:21.162893
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mc = SunOSVirtualCollector()
    assert mc._platform == "SunOS"
    assert isinstance(mc._fact_class, type)
    assert issubclass(mc._fact_class, SunOSVirtual)

# Generated at 2022-06-23 02:41:22.135572
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:41:30.343906
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize the SunOSVirtual class
    virtual = SunOSVirtual(dict(module=None))

    # Add some fake data to the virtual.module.run_command method.
    # This data will be returned if the argument is 'zonename'. We test
    # the method in the case of a zone and not in a zone.
    # The virtual.module.run_command method is a function that takes
    # an argument (a string) and returns a tuple of three elements, 
    # a return code (0 for success, anything else for failure), 
    # the standard output and the standard error.
    # The method run_command is called by the method _run_check_output.
    def mock_run_command(arg):
        if arg == 'zonename':
            return 0, 'global', ''

# Generated at 2022-06-23 02:41:41.454834
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import Virtual
    module = Virtual()


# Generated at 2022-06-23 02:41:46.731763
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Create an instance of SunOSVirtualCollector with VirtualCollector as
    argument and verify that the object is an instance of SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector(collector_platform='SunOS')
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:41:48.607116
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual(module=None)
    assert sv.platform == 'SunOS'



# Generated at 2022-06-23 02:41:51.903393
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    my_SunOSVirtual = SunOSVirtual()
    virtual_facts = my_SunOSVirtual.get_virtual_facts()
    assert 'container' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:41:58.883565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a simple unit test to ensure the constructor of the
    VirtualCollector class is working correctly.
    """
    # Create an instance of the class
    collector = SunOSVirtualCollector()
    # Ordinarily this test won't run on a Windows host, so make sure
    # the module_name is correct for the platform
    if collector._platform == 'Windows':
        assert collector.module_name == 'ansible.module_utils.facts.virtual.windows'
    else:
        assert collector.module_name == 'ansible.module_utils.facts.virtual.sunos'

# Generated at 2022-06-23 02:42:00.776072
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    SunOSVirtual(module)


# Generated at 2022-06-23 02:42:09.318072
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value=True)
    module.params = {}
    module.check_mode = False
    module.debug = False
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    collector = SunOSVirtualCollector(module=module, facts={})
    facts = collector.collect(module=module, facts=dict())
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:42:15.664696
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    srv_virtual = SunOSVirtual({})
    assert srv_virtual.facts['virtualization_type'] is None
    assert srv_virtual.facts['virtualization_role'] is None
    assert srv_virtual.facts['container'] is None
    assert srv_virtual.facts['virtualization_tech_host'] == set()
    assert srv_virtual.facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:42:16.667257
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:42:26.978526
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    d = {}
    d['ansible_facts'] = {'hardwaremodel': 'x86_64'}
    d['ansible_facts']['virtualization_tech_guest'] = ''
    d['ansible_facts']['virtualization_tech_host'] = ''
    d['ansible_facts']['virtualization_role_guest'] = ''
    d['ansible_facts']['virtualization_role_host'] = ''

    solaris_virtual = SunOSVirtual(d)

    assert d['ansible_facts']['virtualization_tech_guest'] == solaris_virtual.virtualization_tech_guest
    assert d['ansible_facts']['virtualization_tech_host'] == solaris_virtual.virtualization_tech_host

# Generated at 2022-06-23 02:42:30.134740
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt_facts = SunOSVirtual(module).get_virtual_facts()
    # Test if returned dict has the expected keys
    assert all(k in virt_facts for k in ('virtualization_type', 'virtualization_role', 'container'))

# Generated at 2022-06-23 02:42:31.928693
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.virtualization_tech_guest is None
    assert virtual.virtualization_tech_host is None

# Generated at 2022-06-23 02:42:34.078020
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual({'module': True})
    assert isinstance(virtual_obj, SunOSVirtual)


# Generated at 2022-06-23 02:42:38.871475
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    testmodule = type('', (object,), {})()
    testmodule.run_command = lambda x, check_rc=True: (0, '', '')
    testmodule.get_bin_path = lambda x, opt_dirs=[] : ''
    testfacts = SunOSVirtual(testmodule)
    testfacts.get_virtual_facts()

# Generated at 2022-06-23 02:42:41.709546
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:42:43.872837
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:42:45.903842
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual('/bin/dummy', '/sbin/dummy')
    assert v.platform == 'SunOS'

# Generated at 2022-06-23 02:42:51.421991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    facts = SunOSVirtual(module=module)

    for result in facts.get_virtual_facts().items():
        key = result[0]
        value = result[1]
        print("%s: %s" % (key, value))

# Generated at 2022-06-23 02:42:53.174854
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert hasattr(SunOSVirtual, 'platform')
    assert SunOSVirtual.platform == 'SunOS'



# Generated at 2022-06-23 02:42:55.700753
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mock_module = Mock()
    collector = SunOSVirtualCollector(mock_module)
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:42:57.274857
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()


# Generated at 2022-06-23 02:43:09.502443
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos.test_virt_sunos import get_mock_config
    from ansible.module_utils.facts.virtual.sunos.test_virt_sunos import get_mock_module

    mock_config = get_mock_config()
    mock_module = get_mock_module(mock_config)

    # When testing on VirtualBox the return code will be non-zero if the command
    # smbios is called with the wrong argument. In this case we should get an
    # empty dictionary.
    virtual_facts = SunOSVirtual(mock_module).get_virtual_facts()
    assert not virtual_facts

    # Set the command smbios to return a valid result.
    mock_config['smbios']['rc'] = 0

    virtual_facts

# Generated at 2022-06-23 02:43:10.577479
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({})
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 02:43:12.753403
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 02:43:15.074320
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-23 02:43:21.730919
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec=dict())
    module.run_command = lambda cmd, check_rc=False: (0, '', '')
    module.get_bin_path = lambda name: {}
    module.params = {}
    collector = SunOSVirtualCollector(module=module)
    facts = collector.collect()
    assert facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:43:30.650388
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    ldoms = SunOSVirtual({})
    assert ldoms.get_virtual_facts() == {
        'virtualization_type': 'ldom',
        'container': None,
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['ldom']),
        'virtualization_tech_host': set([]),
    }

    zonename = SunOSVirtual({})
    zonename.module = FakeModuleShell(0, 'global', '')
    assert zonename.get_virtual_facts() == {
        'virtualization_type': None,
        'container': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set(['zone']),
    }


# Generated at 2022-06-23 02:43:42.277776
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Virtual

    # Create a dummy module and some inputs
    module = object()
    module.run_command = lambda x: x # return command itself
    module.get_bin_path = lambda x: x # assume all binaries are in PATH
    module.exit_json = lambda: exit() # do not exit on run_command

    # Check a guest inside a global zone
    module.run_command.__code__ = lambda x: (0, 'global', '')
    virtual = SunOSVirtual(module)
    assert virtual.get_virtual_facts() == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set()}

    # Check a host of branded zone
    module.run_command

# Generated at 2022-06-23 02:43:53.280122
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual object:
    sun_virtual = SunOSVirtual({})
    sun_virtual.module = MockModule()
    # Create a backup of the original command:
    backup_command = sun_virtual.module.run_command

    # Invoke method get_virtual_facts
    # With zonename command returning Not-global
    sun_virtual.module.run_command = lambda command: (0, 'not-global', '')
    assert sun_virtual.get_virtual_facts() == {'container': 'zone', 'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set()}
    # With zonename command returning Global
    sun_virtual.module.run_command = lambda command: (0, 'global', '')

# Generated at 2022-06-23 02:43:59.263249
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test it without an argument
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

    # Test it with an argument
    collector = SunOSVirtualCollector(cache={})
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:44:01.212393
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'

# Generated at 2022-06-23 02:44:09.059719
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    virt_facts = SunOSVirtual(None).get_virtual_facts()
    assert virt_facts['virtualization_type'] == 'zone'
    assert virt_facts['virtualization_role'] == 'guest'
    assert virt_facts['virtualization_tech_guest'] == set(['zone'])
    assert virt_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-23 02:44:17.257210
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    module.sysctl = {"hw.machine_arch": "i386"}
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:44:20.708235
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'

# Generated at 2022-06-23 02:44:32.571907
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    import os
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils import basic

    #############################################################################################
    # Prepare the tests for the get_virtual_facts method of class SunOSVirtual

    # We will stub out all of the methods of the module for which we don't care about responses
    # and set the expected value for get_bin_path('zonename') and get_bin_path('modinfo')
    # to the appropriate location so we can test the various responses.
    def test_ansibleModule(test):
        test.test_name = 'test_ansibleModule'


# Generated at 2022-06-23 02:44:41.633102
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = FakeModule()
    sunosvirtual = SunOSVirtual(module)

    # ldoms
    ldoms_out = 'DOMAINROLE|impl=LDoms|control=false|io=true|service=false|root=false'
    module.rc = 0
    module.run_command.return_value = (module.rc, ldoms_out, None)
    facts = sunosvirtual.get_virtual_facts()
    assert facts['virtualization_tech_host'] == {'ldom'}
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_type'] == 'ldom'
    assert facts['virtualization_role'] == 'host (io)'

    # vmware
    vmware_out = 'ID NAME            KV    MODULE                  STATE'