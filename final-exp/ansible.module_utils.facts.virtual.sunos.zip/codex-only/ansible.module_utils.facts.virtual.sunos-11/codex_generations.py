

# Generated at 2022-06-23 02:34:42.072870
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({'module': None})
    assert 'zone' not in virtual.virtualization_tech_host
    assert 'zone' not in virtual.virtualization_tech_guest
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None

# Generated at 2022-06-23 02:34:46.057584
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts


# Generated at 2022-06-23 02:34:48.403501
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    fact_class = SunOSVirtual(module)
    assert fact_class.platform == 'SunOS'
    assert fact_class._platform == 'SunOS'


# Generated at 2022-06-23 02:34:58.772113
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value="sunos_bin_path")
    module.params = {'gather_subset': '!all,!min'}
    virtual = SunOSVirtual(module=module)
    virtual.get_virtual_facts()
    # Check that all calls to get_bin_path have been made with the expected value
    module.get_bin_path.assert_called_with('zonename')
    # Check that all calls to run_command have been made with the expected value
    module.run_command.assert_called_with("sunos_bin_path")


# Generated at 2022-06-23 02:35:10.027724
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    import pytest

    # Load the virtual fact class
    virtual = SunOSVirtual()

    # Mock a module with run_command method
    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    module = Bunch()

    # Fake class encapsulating the running command
    class CommandResult(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    # Fake class encapsulating the ansible_module.run_command method
    class RunCommand(object):
        def __init__(self):
            self.commands = []
        def __call__(self, cmd):
            self

# Generated at 2022-06-23 02:35:12.395361
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:35:13.568505
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-23 02:35:17.426925
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    my_SunOSVirtual = SunOSVirtual()
    # Set mandatory attributes
    #
    #
    # Returned value
    ret = my_SunOSVirtual.get_virtual_facts()
    assert type(ret) is dict
    return ret

# Generated at 2022-06-23 02:35:27.299267
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class SunOSVirtual """
    testcmd = '/usr/sbin/smbios'

# Generated at 2022-06-23 02:35:28.822249
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, None, None)
    assert v.platform == 'SunOS'



# Generated at 2022-06-23 02:35:32.697048
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    vinfo = {'virtualization_type': 'virtuozzo', 'virtualization_role': 'guest', 'virtualization_tech_host': {'zone'}, 'container': 'zone', 'virtualization_tech_guest': {'zone', 'virtuozzo'}}
    sunosv = SunOSVirtual({}, vinfo)
    assert sunosv.data == vinfo

# Generated at 2022-06-23 02:35:35.211337
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v


# Generated at 2022-06-23 02:35:40.108833
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
     # Check if SunOSVirtualCollector class is instantiated:
    sunos_virtual_collector = SunOSVirtualCollector()

    # Here we check if the result is of the right type:
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)


# Generated at 2022-06-23 02:35:44.115058
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    my_object = SunOSVirtual()
    results = my_object.get_virtual_facts()
    assert type(results['virtualization_tech_guest']) is set
    assert type(results['virtualization_tech_host']) is set

# Generated at 2022-06-23 02:35:47.858834
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.get_virtual_facts() == None


# Generated at 2022-06-23 02:35:54.057074
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Unit test for method SunOSVirtual.get_virtual_facts
    """
    module = DummyModule()
    virtual = SunOSVirtual(module)
    virtual.module.run_command = lambda x: [0, '', '']
    virtual.module.get_bin_path = lambda x: x
    virtual.module.isdir = lambda x: True
    virtual.module.os.path.exists = lambda x: True
    virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual.facts
    assert 'virtualization_role' in virtual.facts
    assert 'virtualization_tech_guest' in virtual.facts
    assert isinstance(virtual.facts["virtualization_tech_guest"], set)
    assert 'virtualization_tech_host' in virtual.facts

# Generated at 2022-06-23 02:35:55.598896
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    fact_class = SunOSVirtual(module)
    assert fact_class.module == module



# Generated at 2022-06-23 02:35:57.204509
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    a = SunOSVirtual(dict(module=dict()))
    assert a.platform == 'SunOS'

# Generated at 2022-06-23 02:36:01.810529
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:36:12.760617
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sys0 = SunOSVirtual()
    # Constructor test: After instantiating the object we should have an object reference to a class instance
    assert isinstance(sys0, SunOSVirtual)
    # Constructor test: the object should have 'virtualization_type'
    assert hasattr(sys0, 'virtualization_type')
    # Constructor test: the object should have 'virtualization_type' as a string
    assert isinstance(sys0.virtualization_type, str)
    # Constructor test: the object should have 'virtualization_role'
    assert hasattr(sys0, 'virtualization_role')
    # Constructor test: the object should have 'virtualization_role' as a string
    assert isinstance(sys0.virtualization_role, str)
    # Constructor test: the object should have 'container'

# Generated at 2022-06-23 02:36:26.401789
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hypervisor_type_value1 = {'virtualization_type': 'vmware'}
    hypervisor_type_value2 = {'virtualization_type': 'virtualbox'}

    hypervisor_type_list = [hypervisor_type_value1, hypervisor_type_value2]

    hypervisor_role_value1 = {'virtualization_role': 'host'}
    hypervisor_role_value2 = {'virtualization_role': 'guest'}

    hypervisor_role_list = [hypervisor_role_value1, hypervisor_role_value2]

    hypervisor_container = {'container': 'zone'}

    hypervisor_set = {'virtualization_tech_guest': {'vmware'}, 'virtualization_tech_host': {'zone'}}


# Generated at 2022-06-23 02:36:36.213707
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='')
    SunOSVirtual.module = module
    SunOSVirtual._cache = {}
    SunOSVirtual.zfs = None
    # Testing case with a 'global' zone.
    # Testing case with a branded zone.
    # Testing case with a zone running VMware.
    # Testing case with a zone running VirtualBox.
    # Testing case with zones running on a VMware global zone.
    # Testing case with zones running on a VirtualBox global zone.
    # Testing case with a LDoms guest (T-series).
    # Testing case with a LDoms guest running a control domain (T-series

# Generated at 2022-06-23 02:36:45.012615
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import FactVirtualSunOS

    # Construct an instance of class SunOSVirtual
    v = Virtual()

    # Mock method get_bin_path
    def mock_get_bin_path(self, arg):
        path = {
            "zonename": "/usr/bin/zonename",
            "modinfo": "/usr/sbin/modinfo",
            "virtinfo": "/usr/sbin/virtinfo",
            "smbios": "/usr/sbin/smbios"
        }
        return path[arg]

    v.get_bin_path = mock_get_bin_path
    v.module = FactVirtualSunOS()

    # Mock method run_command

# Generated at 2022-06-23 02:36:56.127572
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import FakeModule
    import pytest

    def FakeRunCommand(self, zonename, check_rc=True):
        out = ""
        if zonename == "zonename":
            out = "global"
            rc = 0
        else:
            rc = 1
        return (rc, out, "")
    FakeModule.run_command = FakeRunCommand

    def FakeFindBin(self, zonename):
        if zonename == "modinfo" or zonename == "virtinfo" or zonename == "smbios":
            return os.path.join(self.get_bin_path('sh'), 'sh')
        return None
    FakeModule.get_bin_

# Generated at 2022-06-23 02:37:06.196453
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtSubclass
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module_mock = VirtSubclass(SunOSVirtual)

    module_mock.run_command = run_command_mock

    assert(module_mock.get_virtual_facts() == {'container': 'zone', 'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['zone', 'vmware']), 'virtualization_tech_host': set(['zone'])})
    global zonename_results
    zonename_results = [0, "global", ""]

# Generated at 2022-06-23 02:37:10.884952
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create an instance of class SunOSVirtualCollector
    svc = SunOSVirtualCollector()
    # Test that the class protected variable _fact_class points to SunOSVirtual
    assert svc._fact_class == SunOSVirtual
    # Test that the class protected variable _platform points to SunOS
    assert svc._platform == 'SunOS'

# Generated at 2022-06-23 02:37:15.030245
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    a = SunOSVirtual(dict())
    assert a.platform == 'SunOS'
    assert a.facts == {}
    assert a.module is None

# Generated at 2022-06-23 02:37:26.558567
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # This dictionary is a copy of the dictionary returned by the module "get_distribution()"
    # in the module fact
    distribution = dict(
        osfamily='SunOS',
        manufacturer='Oracle',
        major_release='5.11',
        os_name='SunOS'
    )

    # The module SunOSVirtual returns a dictionary of dictionaries
    # The main dictionary keys are: 'virtualization_role', 'container', 'virtualization_type',
    # 'virtualization_tech_guest' and 'virtualization_tech_host'
    virtual_facts = {
        "virtualization_role": "host (control)",
        "container": "",
        "virtualization_type": "ldom",
        "virtualization_tech_guest": {"ldom"},
        "virtualization_tech_host": {"zone"}
    }

   

# Generated at 2022-06-23 02:37:35.808034
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    facts = {'system': 'SunOS'}
    sunosvirtual = SunOSVirtual(module)

    # Check when it's not a zone
    sunosvirtual.module.run_command = Mock(return_value=(0, "global", ""))
    sunosvirtual.module.get_bin_path = Mock(return_value=True)
    sunosvirtual.module.run_command = Mock(return_value=(0, "modinfo", ""))
    sunosvirtual.module.get_bin_path = Mock(return_value=True)
    sunosvirtual.module.get_bin_path.side_effect = [False, False, False, False]

# Generated at 2022-06-23 02:37:42.501417
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    virtual = SunOSVirtual(dict())
    assert virtual is not None
    assert virtual.has_option('container')
    assert virtual.has_option('virtualization_type')
    assert virtual.has_option('virtualization_role')
    assert virtual.has_option('virtualization_tech_host')
    assert virtual.has_option('virtualization_tech_guest')


# Generated at 2022-06-23 02:37:46.092308
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual = ['zone', 'vmware', 'virtualbox', 'virtuozzo', 'ldom', 'parallels', 'xen', 'kvm']
    collector = SunOSVirtualCollector()
    assert collector.get_virtual_facts() is not None
    assert collector.get_virtual_facts() == {}

# Generated at 2022-06-23 02:37:48.106560
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_test = SunOSVirtualCollector()
    assert my_test.platform == 'SunOS'

# Generated at 2022-06-23 02:37:54.630108
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())
    assert v.__class__.__name__ == 'SunOSVirtual'
    assert v.platform == 'SunOS'
    assert SunOSVirtual.platform == 'SunOS'
    assert v.virtualization_type == 'unknown'
    assert v.virtualization_role == 'unknown'
    assert v.has_container == False
    assert v.virtualization_tech_guest == set()
    assert v.virtualization_tech_host == set()


# Generated at 2022-06-23 02:37:58.490397
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    virtual = SunOSVirtualCollector.collect(module, None)
    assert isinstance(virtual, SunOSVirtual)


# Generated at 2022-06-23 02:38:07.212116
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    SunOSVirtualCollector1 = SunOSVirtualCollector(module)
    virtual_facts_list = SunOSVirtualCollector1.get_virtual_facts()
    assert virtual_facts_list['virtualization_type'] == 'zone'
    assert virtual_facts_list['virtualization_role'] == 'guest'
    assert virtual_facts_list['virtualization_tech_host'] == {'zone'}
    assert virtual_facts_list['virtualization_tech_guest'] == {'zone'}
    assert virtual_facts_list['container'] == 'zone'


# Generated at 2022-06-23 02:38:11.153361
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_SunOSVirtual = SunOSVirtual()
    os_virtual_facts = test_SunOSVirtual.get_virtual_facts()
    assert 'virtualization_type' in os_virtual_facts
    assert 'virtualization_role' == os_virtual_facts['virtualization_role'] in ['guest', 'host', None]
    assert 'virtualization_tech_host' in os_virtual_facts
    assert 'virtualization_tech_guest' in os_virtual_facts
    assert 'container' == os_virtual_facts['container'] in ['zone', None]

# Generated at 2022-06-23 02:38:20.790247
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a dummy module object
    module = type('AnsModule', (object,), {'get_bin_path': lambda s, filename: None})
    module.run_command = lambda command: (1, '', '')

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set()
    }

    # Create a mocked SunOSVirtual object

# Generated at 2022-06-23 02:38:23.777613
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos
    assert sunos._platform == 'SunOS'
    assert sunos._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:38:28.608616
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Unit test for constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector is not None
    assert sunos_virtual_collector._fact_class is SunOSVirtual
    assert sunos_virtual_collector._platform is 'SunOS'

# Generated at 2022-06-23 02:38:32.532094
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'
    virtual_facts.get_all()
    assert 'virtualization_type' in virtual_facts.data


# Generated at 2022-06-23 02:38:35.890653
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunVirtualFactCollector = SunOSVirtualCollector()
    assert sunVirtualFactCollector._platform == 'SunOS'
    assert sunVirtualFactCollector._fact_class._platform == 'SunOS'

# Generated at 2022-06-23 02:38:37.067554
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector('/')

# Generated at 2022-06-23 02:38:38.229867
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict(module=None))

# Generated at 2022-06-23 02:38:39.293874
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-23 02:38:49.436137
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    import platform
    import pytest

    class CallModule(object):
        def __init__(self, params):
            self._bin_path = None
            self._params = params
            self._call_count = dict()

        @property
        def params(self):
            return self._params

        def get_bin_path(self, name):
            if self._bin_path is None:
                self._bin_path = dict()
                for bin_name in ('zonename', 'modinfo', 'virtinfo', 'smbios'):
                    try:
                        self._bin_path[bin_name] = self.module.get_bin_path(bin_name)
                    except Exception as e:
                        self._bin_path[bin_name] = None

# Generated at 2022-06-23 02:38:51.952536
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert 'SunOSVirtual' == repr(SunOSVirtualCollector())

# Generated at 2022-06-23 02:38:59.546240
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mySunOSVirtual = SunOSVirtual('')
    assert(mySunOSVirtual.platform == 'SunOS')
    assert(mySunOSVirtual.virtualization_type is None)
    assert(mySunOSVirtual.virtualization_role is None)
    assert(mySunOSVirtual.virtualization_subtype is None)
    assert(mySunOSVirtual.container is None)
    assert(mySunOSVirtual.virtualization_technologies['guest'] == set())
    assert(mySunOSVirtual.virtualization_technologies['host'] == set())

# Generated at 2022-06-23 02:39:08.995138
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    #
    # Create a valid Virtual module object
    #
    module = FakeModule(
        return_values={
            'get_bin_path': {
                'zonename': 'zonename',
                'modinfo': 'modinfo',
                'smbios': 'smbios'
            },
            'run_command': {
                'zonename': [
                    0,
                    'global',
                    []
                ],
                'modinfo': [
                    0,
                    'id\tVMXNET3\nname\tVMware VMXNET3 Ethernet NIC #1',
                    []
                ],
                'smbios': [
                    0,
                    'Vendor: VMware\nProduct: VMware Virtual Platform',
                    []
                ]
            }
        }
    )
    virtual = SunOSVirtual(module=module)

# Generated at 2022-06-23 02:39:10.119007
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:11.988878
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()
    assert facts.platform == 'SunOS'

# Generated at 2022-06-23 02:39:16.645869
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hv = SunOSVirtual()
    assert hv.platform == 'SunOS'
    assert hv.get_virtual_facts() is not None

# Generated at 2022-06-23 02:39:26.579848
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = lambda *args, **kw: ('', '', 0)
    # Zone tests
    module.run_command = lambda *args, **kw: ('global', '', 0)
    assert SunOSVirtual(module).get_virtual_facts() == {
        'container': 'zone',
        'virtualization_type': None,
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set([]),
    }
    module.run_command = lambda *args, **kw: ('nonglobal', '', 0)

# Generated at 2022-06-23 02:39:36.980078
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Test our SunOS specific subclass of Virtual.
    '''
    # Reference for what we should be getting after the scan
    sunos_virtual_expected_results = {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'container': 'zone',
        'virtualization_type': 'vmware',
        'virtualization_role': 'host (control,io,service,root)'
    }

    # Create a mock module object that has what we need for testing
    mock_module_obj = object()
    setattr(mock_module_obj, 'get_bin_path', lambda x: '/bin/' + x)
    setattr(mock_module_obj, 'run_command', lambda x: (0, '', ''))

    # Construct the SunOSVirtual

# Generated at 2022-06-23 02:39:38.661754
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:39:41.361825
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == "SunOS"

# Generated at 2022-06-23 02:39:45.608793
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create an instance of class SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector()
    # Check attributes of instance
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-23 02:39:56.561267
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector

    module = AnsibleModuleStub()

    # Fake the module and use it to instantiate the class SunOSVirtual
    sunosv = SunOSVirtual(module)

    # Fake the VirtualCollector and use it to fake the collect_platform_subset_facts and use it to set the virtual_facts
    vc = VirtualCollector(module, 'SunOS', SunOSVirtual)

# Generated at 2022-06-23 02:39:58.903323
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    info = {'ansible_facts': {}}
    virtual_facts = SunOSVirtual(info)
    assert isinstance(virtual_facts, SunOSVirtual)

# Generated at 2022-06-23 02:40:07.172443
# Unit test for constructor of class SunOSVirtual

# Generated at 2022-06-23 02:40:15.762478
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt_collector = SunOSVirtualCollector(module)

    results = virt_collector.collect()
    if 'virtualization_type' not in results:
        return False
    if 'virtualization_role' not in results:
        return False
    if 'virtualization_tech_guest' not in results:
        return False
    if 'virtualization_tech_host' not in results:
        return False
    if 'container' not in results:
        return False

    return True

# Generated at 2022-06-23 02:40:18.688616
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual
    c = SunOSVirtualCollector()



# Generated at 2022-06-23 02:40:21.666308
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    set_module_args({})
    from ansible.module_utils.facts import virtual
    s = SunOSVirtual(virtual)
    assert isinstance(s, SunOSVirtual)


# Generated at 2022-06-23 02:40:25.387801
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    vm = collector.get_platform_facts(SunOSVirtual)
    assert vm['virtualization_type'] == 'xen'
    assert vm['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:40:29.124550
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    import os

    sys.path.append(os.getcwd())

    m = SunOSVirtual({})
    assert m.get_virtual_facts() is not None
    m = SunOSVirtual({'module_setup': True})
    assert m.get_virtual_facts() is not None

# Generated at 2022-06-23 02:40:33.151335
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance_of_fact_class = SunOSVirtualCollector()
    assert isinstance(instance_of_fact_class, SunOSVirtualCollector)
    assert isinstance(instance_of_fact_class._fact_class, SunOSVirtual)
    assert instance_of_fact_class._platform == 'SunOS'


# Generated at 2022-06-23 02:40:35.084841
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector([])
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:40:38.009026
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt_storage = dict()
    virt_storage['mock'] = None
    virtual = SunOSVirtual(virt_storage)
    assert virtual

# Generated at 2022-06-23 02:40:44.593994
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeOsModule()
    facts = SunOSVirtual(module).populate_facts()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set()
    assert facts['container'] == 'zone'


# Generated at 2022-06-23 02:40:54.163986
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Method returns a dict.
    module = FakeAnsibleModule()
    obj = SunOSVirtual(module)
    facts = obj.get_virtual_facts()
    assert isinstance(facts, dict)

    # Host system
    obj.module.run_command = FakeRunCommand(rc=0, out='global\n', err='')
    obj.module.get_bin_path = FakeGetBinPath(exists=True)
    facts = obj.get_virtual_facts()
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_tech_host'] == {'zone'}
    assert facts['virtualization_tech_guest'] == set()

    # Zone system

# Generated at 2022-06-23 02:40:57.339295
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'



# Generated at 2022-06-23 02:41:03.528198
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('MockAnsibleModule', (object,), {})
    module.params = {}
    module.run_command = type('MockRunCommand', (object,), {})
    module.get_bin_path = type('MockGetBinPath', (object,), {})
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = ""
    fact = SunOSVirtual(module)
    assert fact.platform == "SunOS"

# Generated at 2022-06-23 02:41:04.882192
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Constructor should not fail
    sunos = SunOSVirtual(None)

# Generated at 2022-06-23 02:41:06.609067
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual()
    assert m.platform == 'SunOS'


# Generated at 2022-06-23 02:41:08.349882
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts is not None


# Generated at 2022-06-23 02:41:11.333136
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-23 02:41:13.659561
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v.platform == 'SunOS'
    assert v.fact_class == SunOSVirtual


# Generated at 2022-06-23 02:41:17.275386
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    os_obj = SunOSVirtual({})
    assert isinstance(os_obj, SunOSVirtual)
    os_obj = SunOSVirtual({}, {}, {}, {}, {})
    assert isinstance(os_obj, SunOSVirtual)


# Generated at 2022-06-23 02:41:27.353010
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class AnsibleModuleMock(object):
        def get_bin_path(self, path):
            return '/usr/bin/%s' % path

        def run_command(self, command):
            return 0, '', ''

    module = AnsibleModuleMock()
    virt = SunOSVirtual(module=module)
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert sorted(virtual_facts['virtualization_tech_guest']) == sorted([u'vmware', u'zone'])

# Generated at 2022-06-23 02:41:31.381716
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # We don't want to actually run the command
    module = type('module', (), {'run_command': lambda self, command: (0, '', '')})
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual._platform == 'SunOS'

# Generated at 2022-06-23 02:41:33.812142
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual

# Generated at 2022-06-23 02:41:36.064075
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    l = SunOSVirtual(module)
    assert 'SunOS' == l.platform


# Generated at 2022-06-23 02:41:49.932046
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Simulate module input parameters and facts
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create instance of SunOSVirtual
    sunos_virtual = SunOSVirtual(module)

    # Only test on SunOS platform
    if sunos_virtual.on_sunos:
        sunos_virtual._get_zone_name = MagicMock(return_value=("", 0, ""))
        sunos_virtual.module.run_command = MagicMock(side_effect=[("", 0, ""),
                                                                  ("", 0, "root true"),
                                                                  ("", 0, "")])

        # Test: Not a zone
        facts = {
            'virtual': sunos_virtual.get_virtual_facts()
        }

        print (facts)


# Generated at 2022-06-23 02:41:52.891316
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-23 02:42:02.653099
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class MockModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, path):
            if path == 'zonename':
                return '/usr/bin/zonename'
            if path == 'modinfo':
                return '/usr/sbin/modinfo'
            if path == 'virtinfo':
                return '/usr/sbin/virtinfo'
            if path == 'smbios':
                return '/usr/sbin/smbios'
            return None
        def run_command(self, cmd, check_rc=True):
            if cmd == '/usr/bin/zonename':
                return 0, 'global', ''

# Generated at 2022-06-23 02:42:07.194598
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    TestSunOSVirtualCollector = SunOSVirtualCollector()
    assert TestSunOSVirtualCollector._platform == 'SunOS'
    assert TestSunOSVirtualCollector._fact_class == SunOSVirtual
    assert TestSunOSVirtualCollector._options is None

# Generated at 2022-06-23 02:42:16.953980
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual import Virtual, SunOSVirtual
    import os

    class RunCommand:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, args, check_rc=True, close_fds=False, executable=None,
                     data=None, binary_data=False, path_prefix=None, cwd=None,
                     use_unsafe_shell=False, prompt_regex=None, environ_update=None,
                     umask=None, encoding=None, errors=None, text=None):
            return (self.rc, self.out, self.err)

    class Module:
        def __init__(self):
            self.run_command = RunCommand

# Generated at 2022-06-23 02:42:19.147767
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # TODO: This unit test is not implemented yet
    module = FakeAnsibleModule()
    obj = SunOSVirtual(module)
    obj.get_virtual_facts()
    pass

# Generated at 2022-06-23 02:42:20.553255
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, None, None)
    assert isinstance(v, SunOSVirtual)

# Generated at 2022-06-23 02:42:23.613692
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor for class SunOSVirtualCollector should set _platform to
    SunOS and _fact_class to SunOSVirtual.
    """
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:42:25.919930
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('module',(object,),dict(exit_json=dict(), fail_json=dict()))
    VirtualCollector(module)

# Generated at 2022-06-23 02:42:37.005551
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # TODO: this unit test should be moved to test/unit/module_utils/facts/virtual/sunos.py
    # but I don't understand how to do it.
    vm = SunOSVirtual({})
    assert isinstance(vm, SunOSVirtual)

    # Some arbitrary example data

# Generated at 2022-06-23 02:42:38.299161
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Constructor test
    e = SunOSVirtualCollector()
    assert e is not None

# Generated at 2022-06-23 02:42:42.067408
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-23 02:42:43.091165
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector



# Generated at 2022-06-23 02:42:46.834651
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    SunOSVirtualCollector(facts, None)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:42:52.016164
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    __test__ = {}
    assert SunOSVirtualCollector
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    exit(0)


if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-23 02:43:01.842576
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes

    client = SunOSVirtual()
    client.module = FakeAnsibleModule()
    client.module.run_command = FakeRunCommand()


# Generated at 2022-06-23 02:43:04.331439
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual

# Generated at 2022-06-23 02:43:14.718633
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''

    # Unit test parameters
    SunOSVirtual.module = AnsibleModuleMock()
    SunOSVirtual.module.run_command = AnsibleModuleMock.run_command_mock
    SunOSVirtual.module.run_command.side_effect = lambda command, use_unsafe_shell=False: run_command_mock(command)

    # Expected results
    expected_results = dict(
        virtualization_type='zone',
        virtualization_role='guest',
        virtualization_tech_host=set(['zone']),
        virtualization_tech_guest=set([])
    )

    # Actual results
    actual_results = SunOSVirtual().get_virtual_facts()


# Generated at 2022-06-23 02:43:23.375285
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Compute the path of the modules/module_utils/facts/virtual/zone.py module
    import os, sys
    import ansible.module_utils.facts.virtual.zone as testee

    # Check the virtual_facts dictionary returned by the method
    current_dir = os.path.dirname(__file__)
    testee.module.run_command = lambda _, environ_update=None, check_rc=True: (1, current_dir, '')
    virtual_facts = testee.get_virtual_facts()
    assert 'container' in virtual_facts
    assert len(virtual_facts['virtualization_tech_guest']) > 0


# Generated at 2022-06-23 02:43:26.159851
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual(dict())
    assert x.platform == 'SunOS'


# Generated at 2022-06-23 02:43:29.091765
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fact_subclass = SunOSVirtualCollector()
    assert fact_subclass._fact_class is SunOSVirtual
    assert fact_subclass._platform == 'SunOS'

# Generated at 2022-06-23 02:43:31.021436
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert isinstance(collector, SunOSVirtualCollector)

# Generated at 2022-06-23 02:43:35.046476
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    SunOSVirtualCollector(facts, None)
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_host'] == set(['zone'])

# Generated at 2022-06-23 02:43:46.732766
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    facts_obj = SunOSVirtual(module)
    # The methods is_zone, is_solaris_zone and is_solaris_logical_domain were called in yes condition
    facts_obj.is_zone = lambda: True
    facts_obj.is_solaris_zone = lambda: True
    facts_obj.is_solaris_logical_domain = lambda: True
    facts_obj.is_smartos = lambda: False
    facts_obj.is_virtuozzo = lambda: False
    facts_obj.is_xen = lambda: False
    facts_obj.is_kvm = lambda: False
    facts_obj.is_parallels = lambda: False
    facts_obj.is_vmware = lambda: False


# Generated at 2022-06-23 02:43:57.139535
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Call method get_virtual_facts of class SunOSVirtual on empty object
    # This should not return any value
    testSunOSVirtual = SunOSVirtual()
    testSunOSVirtual.module.run_command = lambda x: (0, '', '')
    assert testSunOSVirtual.get_virtual_facts() == {}

    # Populate module.run_command with valid/invalid output
    # Check if correct output is returned
    testSunOSVirtual.module.run_command = lambda x: (0, 'dom0', '')
    expected_result = {'container': 'zone',
                       'virtualization_tech_guest': {'xen'},
                       'virtualization_tech_host': set(),
                       'virtualization_role': 'guest',
                       'virtualization_type': 'xen'}
    assert testSunOS

# Generated at 2022-06-23 02:44:03.727718
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module_mock = basic.AnsibleModule(
        argument_spec=dict()
    )
    module_mock.run_command = lambda *cmd, **_: (0, '', '')
    module_mock.get_bin_path = lambda _: '/dev/null'
    virtual = SunOSVirtual(module=module_mock)
    facts = virtual.get_virtual_facts()
    assert facts == {}

# Generated at 2022-06-23 02:44:09.582605
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.sunos.sunos_virtual import SunOSVirtual
    module = FakeModule()
    test_object = SunOSVirtual(module)
    test_object.get_virtual_facts()
    assert module.params['gather_subset'] == ['!all', '!min']
    assert module.params['gather_timeout'] == 10

# Generated at 2022-06-23 02:44:13.242914
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = VirtualCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 02:44:23.010640
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # The test is done by trying to collect facts from a SunOS system
    # This system has been manually virtualized, i.e. no automated tests suite
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    v = SunOSVirtual(module=None)
    v._module = None
    v.module = v._module
    os.environ["VIRTINFO"] = "/usr/sbin/virtinfo"
    os.environ["ZONENAME"] = "/usr/sbin/zonename"

    # Check if it's a zone
    v.module.run_command = lambda x: (0, "global", "")
    virtual_facts = v.get_virtual_facts()
    v.module.run_command = lambda x: (0, "non-global", "")

# Generated at 2022-06-23 02:44:27.407721
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector._fact_class().platform == 'SunOS'


# Generated at 2022-06-23 02:44:37.885574
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Simple test of constructor of class VirtualCollector
    """
    import sys
    import os
    import platform
    import pkgutil
    from ansible.module_utils.facts import virtual

    finder = pkgutil.find_loader(virtual.__name__)
    if finder is not None:
        test_module = finder.load_module(virtual.__name__)
    else:
        test_module = __import__('ansible.module_utils.facts.virtual')

    test_instance = SunOSVirtualCollector(
        module=test_module,
        subc_path='ansible.module_utils.facts.virtual.collectors.SunOS')

    assert test_instance.platform == "SunOS"
    assert test_instance._fact_class.platform == "SunOS"
    assert test_instance