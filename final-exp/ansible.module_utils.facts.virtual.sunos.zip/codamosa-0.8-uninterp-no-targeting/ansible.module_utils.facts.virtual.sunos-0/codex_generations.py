

# Generated at 2022-06-20 20:48:32.841894
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    import os
    import tempfile
    import platform
    import subprocess
    import stat

    if platform.system() != "SunOS":
        return

    def copy_file(src, dest):
        dest_file = open(dest, 'w')
        try:
            src_file = open(src)
            try:
                for line in src_file:
                    dest_file.write(line)
            finally:
                src_file.close()
        finally:
            dest_file.close()

    def fake_module_run_command(self, cmd):
        if cmd == "zonename":
            return 0, "global\n", ""

# Generated at 2022-06-20 20:48:33.434964
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()

# Generated at 2022-06-20 20:48:44.366317
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test zonename
    zonename = SunOSVirtualCollector.get_bin_path('zonename')
    assert zonename == '/usr/bin/zonename'

    # Test modinfo
    modinfo = SunOSVirtualCollector.get_bin_path('modinfo')
    assert modinfo == '/usr/sbin/modinfo'

    # Test virtinfo
    virtinfo = SunOSVirtualCollector.get_bin_path('virtinfo')
    assert virtinfo == '/usr/sbin/virtinfo'

    # Test smbios
    smbios = SunOSVirtualCollector.get_bin_path('smbios')
    assert smbios == '/usr/sbin/smbios'

    # Check platform
    assert SunOSVirtualCollector._platform == 'SunOS'

    # Check fact_class
   

# Generated at 2022-06-20 20:48:47.844736
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    vm = SunOSVirtual(module=module)
    assert isinstance(vm, SunOSVirtual)

# Generated at 2022-06-20 20:48:51.532154
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual(None)
    assert sunosvirtual.platform == 'SunOS'
    assert sunosvirtual.guest_tech == set()
    assert sunosvirtual.host_tech == set()
    assert sunosvirtual.info == {}



# Generated at 2022-06-20 20:48:54.691354
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """This function is called by the py.test framework to test that the constructor
    for class SunOSVirtual works as advertised.
    """
    virtual = SunOSVirtual({})

# Generated at 2022-06-20 20:49:02.673105
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'virtualbox'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['container'] = 'zone'
    virtual_facts['virtualization_tech_guest'] = set(['zone', 'virtualbox'])
    virtual_facts['virtualization_tech_host'] = set(['zone', 'virtualbox'])
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-20 20:49:13.720830
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import tempfile
    from ansible.module_utils.facts.virtual.sunos.test_SunOSVirtual import test_SunOSVirtual
    import ansible.module_utils.facts.virtual.sunos.test_SunOSVirtual
    test_module = 'ansible.module_utils.facts.virtual.sunos.test_SunOSVirtual'
    test_SunOSVirtual.TEST_DATA = {}


# Generated at 2022-06-20 20:49:17.512081
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Note: we don't actually invoke the method here, just test that
    # the class is a subclass of the proper class and that it
    # has the correct platform attribute
    assert issubclass(SunOSVirtual, Virtual)
    assert SunOSVirtual.platform == 'SunOS'

# Generated at 2022-06-20 20:49:20.123558
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual = SunOSVirtualCollector()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:49:36.518006
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc._platform == 'SunOS'
    assert svc._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:49:44.987689
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import platform
    import sys
    import copy

    class FakeModule:

        global_zone = "zone1"
        zones = [global_zone]

        def __init__(self):
            self.sys_platform = platform.system()

        def get_bin_path(self, arg):
            global zonename
            zonename = arg
            return arg

        def run_command(self, arg):
            if arg == zonename:
                return 0, self.global_zone, None
            return 0, "", "Test_Exception"

    class FakeOS(object):

        def __init__(self):
            self.path = FakePath()

        def isdir(self, arg):
            # mock the /.SUNWnative directory for branded zones
            if arg == '/.SUNWnative':
                return True



# Generated at 2022-06-20 20:49:47.205618
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:49:48.232056
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    return

# ===============================================


# Generated at 2022-06-20 20:49:55.003370
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    import json
    import os

    MockedModule = basic.AnsibleModule

    class MockedModule2(MockedModule):
        def __init__(self):
            super(MockedModule2, self).__init__(argument_spec={},
                                                supports_check_mode=True)

        def get_bin_path(self, arg, required=False):
            return

    module = MockedModule2()

    def mocked_run_command(arg):
        if arg == 'zonename':
            return 0, 'global', ''

# Generated at 2022-06-20 20:49:58.625361
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # test for virtual class
    x = SunOSVirtualCollector()
    assert x
    assert isinstance(x, VirtualCollector)
    assert isinstance(x._fact_class, SunOSVirtual)

# Generated at 2022-06-20 20:50:00.354244
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector(None)

# Generated at 2022-06-20 20:50:07.186175
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual(): # pylint: disable=no-self-use
    """
    Unit test for constructor of class SunOSVirtual
    """
    custom_module_args = dict(
        _ansible_sys_module_store={
            'virtual_env': '/test/venv',
        }
    )
    sunos_virtual_obj = SunOSVirtual(dict(), custom_module_args)
    assert(sunos_virtual_obj)

# Generated at 2022-06-20 20:50:16.890634
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    ##################################
    # Case 1: Global zone
    ##################################
    # Create a SunOSVirtual object
    sunos_virtual_obj = SunOSVirtual()

    # Set up mock return values for get_bin_path() and run_command()
    sunos_virtual_obj.module.get_bin_path = mock.MagicMock(side_effect=['/usr/sbin/zonename', '/usr/sbin/modinfo'])
    sunos_virtual_obj.module.run_command = mock.MagicMock(side_effect=[(0, 'global\n', ''),
                                                                       (0, '81  ffffffffffbfe0a0  1  VM_PAGE_MODULE_OBJECT    [vmxnet3s]\n', '')])

    # Mocked return value for os listdir().

# Generated at 2022-06-20 20:50:18.008914
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'

# Generated at 2022-06-20 20:50:43.403677
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.system == "SunOS"

# Generated at 2022-06-20 20:50:55.549644
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # create instance of SunOSVirtual
    v = SunOSVirtual(dict(module=None))

    # get_virtual_facts
    f = v.get_virtual_facts()
    assert f['container'] in [None, 'zone']
    assert f['virtualization_type'] in [None, 'vmware', 'virtualbox', 'kvm', 'xen', 'parallels', 'virtuozzo']
    assert f['virtualization_role'] in [None, 'guest', 'host']
    assert f['virtualization_tech_host'] in [set(), set(['zone']), set(['zone', 'kvm', 'vmware', 'parallels', 'xen', 'virtualbox'])]

# Generated at 2022-06-20 20:50:58.453088
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:51:03.101820
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtualCollector
    virtual_collector = SunOSVirtualCollector()
    assert isinstance(virtual_collector, SunOSVirtualCollector)


# Generated at 2022-06-20 20:51:11.387441
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class TestSunOS():
        def __init__(self):
            # The module instance is needed as class attributes by the _execute method.
            self.module = self
            self.facts = {}

        def get_bin_path(self, path):
            if path == 'zonename':
                return '/usr/bin/zonename'
            if path == 'modinfo':
                return '/usr/sbin/modinfo'
            if path == 'virtinfo':
                return '/usr/bin/virtinfo'
            if path == 'smbios':
                return '/usr/sbin/smbios'

        def run_command(self, cmd):
            if cmd == '/usr/bin/zonename':
                return (0, 'global\n', '')


# Generated at 2022-06-20 20:51:12.376359
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is SunOSVirtual

# Generated at 2022-06-20 20:51:20.391257
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import mock
    import sys
    module = mock.Mock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/bin/true'
    sunosvirtual = SunOSVirtualCollector(module=module)
    assert sunosvirtual.platform == 'SunOS'
    if sys.version_info >= (2, 7):
        assert isinstance(sunosvirtual, SunOSVirtualCollector)
    else:
        assert isinstance(sunosvirtual, SunOSVirtualCollector)
        assert isinstance(sunosvirtual, SunOSVirtual)



# Generated at 2022-06-20 20:51:22.218217
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fake_module_loader = None
    assert SunOSVirtualCollector(fake_module_loader)._platform == 'SunOS'

# Generated at 2022-06-20 20:51:24.833655
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual is not None

# Generated at 2022-06-20 20:51:30.687258
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dut = SunOSVirtualCollector()
    dut.module = MagicMock()
    dut.module.get_bin_path.return_value = 'testbin'
    dut.module.run_command.return_value = (0, 'out', 'err')
    assert dut.get_virtual_facts() == {}

# Generated at 2022-06-20 20:52:21.354678
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert SunOSVirtual.platform == 'SunOS'
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:52:36.445638
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import basic

    module_mock = basic.AnsibleModule(argument_spec={})

    zonename_result = ('0', 'global', '')
    modinfo_result = ('0', 'id: vmware 1.0.0.1 class: misc compat: SVR4', '')
    virtinfo_result = ('0', 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', '')


# Generated at 2022-06-20 20:52:39.713554
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict(), dict())
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-20 20:52:44.707413
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    virt_obj = SunOSVirtual(module)
    assert virt_obj.facts['virtualization_type'] == 'xen'
    assert virt_obj.facts['virtualization_role'] == 'guest'
    assert virt_obj.facts['virtualization_tech_guest'] == set(['xen'])
    assert virt_obj.facts['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-20 20:52:53.777545
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'global', None)
    module.get_bin_path.return_value = '/usr/sbin/virtinfo'
    module.get_bin_path.return_value = '/usr/sbin/zonename'
    SunOSVirtual(module).get_virtual_facts()
    expected_calls = [('/usr/sbin/zonename', ), ('/usr/sbin/virtinfo -p', )]
    if module.run_command.call_args_list != expected_calls:
        raise Exception('Unexpected call order in SunOSVirtual.get_virtual_facts')

# Generated at 2022-06-20 20:52:55.313455
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.platform == 'SunOS'

# Generated at 2022-06-20 20:52:58.806388
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector is not None


# Generated at 2022-06-20 20:53:08.856760
# Unit test for constructor of class SunOSVirtual

# Generated at 2022-06-20 20:53:20.187084
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyModule()
    virtual = SunOSVirtual(module)

    # The unit test should try all the branches that are covered by
    # the implementation.  The code is quite difficult to follow
    # in a unit test but we try to do the best we can.

    # DummyModule.run_command will return different values for different
    # commands so the tests for different commands are mutually exclusive.
    zonename = '/bin/zonename'
    modinfo = '/sbin/modinfo'
    virtinfo = '/bin/virtinfo'
    smbios = '/usr/sbin/smbios'

    def run_command_mock(cmd, **kwargs):
        """
        This mock function can simulate the output of the run_command
        method.  It returns a dictionary instead of a three element tuple.
        """

# Generated at 2022-06-20 20:53:23.615692
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Verify SunOSVirtual class constructor
    """
    virt = SunOSVirtual(dict())
    assert virt.platform == 'SunOS'



# Generated at 2022-06-20 20:55:11.821557
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({'module': None})


# Generated at 2022-06-20 20:55:25.672575
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    #Setup test environment
    SunOSVirtual.platform = 'SunOS'

    testmodule = type('', (object,), {
        'params': type('', (object,), {
            'gather_subset': [],
            'gather_timeout': 1,
        }),
        'get_bin_path': lambda x: None,
        'run_command': lambda x: (0, '', ''),
        'fail_json': lambda **kwargs: None
    })

    #Note: _parameter_case is used to keep track of all required variables for this platform.
    #If you add any new variables for this platform to class SunOSVirtual, please add it to _parameter_case

# Generated at 2022-06-20 20:55:30.617238
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Constructor test:
    #   create object with dummy module object argument
    #   check if vmtype is detected and has proper value
    #   check if 'zone' virtualization_type is detected and has proper value
    #   check if 'xenu' virtualization_type is detected and has proper value
    dummy_module = type('', (), {
        'params': lambda self: None,
        'env_fallback': lambda self, *args: None,
        'run_command': lambda self, *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda self, *args, **kwargs: None,
    })()
    virt = SunOSVirtual(dummy_module)
    assert virt.vmtype == 'KVM'
    assert virt.container == 'zone'
    assert virt.virtualization

# Generated at 2022-06-20 20:55:44.187225
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = get_module_mock()
    set_module_args(dict(
        gather_subset='virtual'
    ))
    set_module_args(dict(
        gather_subset='virtual'
    ))
    sunos = SunOSVirtual(module)
    res = sunos.get_virtual_facts()
    assert res['virtualization_type'] == 'kvm'
    assert res['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' not in res
    assert 'virtualization_tech_host' not in res
    assert 'container' not in res
    assert res['virtual']
    assert 'virtual' not in res

# Generated at 2022-06-20 20:55:47.338998
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:55:50.455772
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert SunOSVirtual._platform == 'SunOS'
    assert v.get_virtual_facts() is None

# Generated at 2022-06-20 20:56:05.455824
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual, SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    import pytest

    # Test with a VMware
    module_mock = MagicMock()
    module_mock.run_command.return_value = [0, '', '']
    module_mock.get_bin_path.side_effect = ['/usr/sbin/virtinfo', '/usr/sbin/modinfo']
    module_mock.run_command.return_value = [0, 'driver: VMware vmxnet\n', '']

# Generated at 2022-06-20 20:56:15.187929
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    modinfo = '/opt/test/testbin/modinfo'
    module.run_command = run_command_mock

    # Test for solaris 8/9 branded zone
    module.run_command = run_command_mock
    module.run_command.side_effect = [
        (0, '{"id": "virtinfo-0.3", "name": "VMware", "description": "VMware Tools, driver"}', ''),
        (0, '{"id": "virtinfo-0.3", "name": "VirtualBox", "description": "VirtualBox Tools, driver"}', ''),
    ]
    module.get_bin_path.side_effect = [ modinfo, None, None ]
    virtual = SunOSVirtual(module)

# Generated at 2022-06-20 20:56:20.800590
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Instantiate SunOSVirtual
    assert SunOSVirtual(dict()) is not None
    # assert that the platform is set correctly
    assert SunOSVirtual(dict()).platform == 'SunOS'

# Generated at 2022-06-20 20:56:23.646604
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
