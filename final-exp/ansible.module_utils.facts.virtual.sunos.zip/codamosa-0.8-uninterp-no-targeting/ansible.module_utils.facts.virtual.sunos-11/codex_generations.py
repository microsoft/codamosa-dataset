

# Generated at 2022-06-20 20:48:22.180037
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc._platform == 'SunOS'
    assert isinstance(svc._fact_class(), SunOSVirtual)

# Generated at 2022-06-20 20:48:24.060042
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual({})
    # Return an empty dict if we cannot find the command
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:48:25.414823
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Check Virtual Constructor"""
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:48:37.913483
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Setup
    import os
    import sys
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils._text import to_bytes, to_text
    import yaml
    from ansible.module_utils.six import BytesIO

    # Run the code and check the output
    # Construct a module object
    set_module_args({})

# Generated at 2022-06-20 20:48:40.214429
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = MockAnsibleModule()
    virtual = SunOSVirtual(module_mock)
    virtual.get_virtual_facts()

# Generated at 2022-06-20 20:48:48.743516
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector().collect()

    assert len(facts) == 1
    fact_subset = dict((k, facts[k]) for k in ('virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'))
    assert fact_subset == {
        'virtualization_type' : None,
        'virtualization_role' : None,
        'virtualization_tech_host' : set(),
        'virtualization_tech_guest' : set()
    }

# Generated at 2022-06-20 20:48:51.712419
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Validate the constructor of SunOSVirtualCollector
    '''
    sunos_virtual = SunOSVirtualCollector()

    assert sunos_virtual.get_fact_class() == SunOSVirtual

# Generated at 2022-06-20 20:48:54.598777
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hostname = 'foo'
    facts_module = None
    v = SunOSVirtual(module=facts_module, hostname=hostname)
    assert v.hostname == hostname
    assert v.module == facts_module

# Generated at 2022-06-20 20:49:06.608940
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mod_args = dict(
        gather_subset=["!all", "!min"],
        filter=[
            "a",
            "b",
            "c"
        ]
    )
    vc = SunOSVirtualCollector(module=AnsibleModuleMock(params=mod_args))
    assert vc.get_gather_subset() == ['!all', '!min']
    assert vc.get_gather_network_resources() is True
    assert vc.get_gather_subset() == ['!all', '!min']
    assert vc.get_filter_string() == "a,b,c"
    assert vc.get_platform() == 'SunOS'
    assert vc.get_fact_class() is SunOSVirtual
    assert vc.get_fact_class()

# Generated at 2022-06-20 20:49:10.843240
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    result = SunOSVirtualCollector(module)
    assert result._fact_class is SunOSVirtual
    assert result._platform is 'SunOS'

# Testing the class SunOSVirtual

# Generated at 2022-06-20 20:49:25.765342
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    set_module_args({})
    obj = SunOSVirtual(module)
    assert obj.get_virtual_facts()

# Generated at 2022-06-20 20:49:28.325098
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-20 20:49:31.377555
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:49:38.490876
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = dict()
    facts['system'] = dict()
    facts['system']['SunOS'] = dict()
    module = FakeAnsibleModule(facts)
    sunos = SunOSVirtual(module)
    expected = dict(
        virtualization_type='vmware',
        virtualization_role='guest',
        virtualization_tech_guest={'vmware'},
        virtualization_tech_host={},
    )
    assert expected == sunos.get_virtual_facts()


# Generated at 2022-06-20 20:49:43.483410
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_sunos = SunOSVirtual()
    assert virtual_facts_sunos.platform == 'SunOS'


# Generated at 2022-06-20 20:49:44.333572
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:46.896196
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    v = SunOSVirtual(module)
    assert v.module == module
    assert not v._zone_name



# Generated at 2022-06-20 20:49:54.629321
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test the case no virtualization technologies are detected
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    def mock_module_get_bin_path(module, arg, opt_dirs=[]):
        if arg == 'zonename':
            return arg
        return None

    module.get_bin_path = mock_module_get_bin_path
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    # Test the case when it's a zone
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    def mock_module_get_bin_path(module, arg, opt_dirs=[]):
        if arg == 'zonename':
            return arg
        return None


# Generated at 2022-06-20 20:50:01.134141
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('module', (object,), {'params': {}, 'run_command': lambda x, check_rc=False: [0, '', '']})()
    obj = SunOSVirtual(module)
    assert obj._platform == 'SunOS'
    assert obj.virtualization_type == None
    assert obj.virtualization_role == None
    assert obj.container == None

# Generated at 2022-06-20 20:50:02.163151
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt_collector = SunOSVirtualCollector(None)

# Generated at 2022-06-20 20:50:25.619366
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Basic test with a Linux VM
    module = FakeModule(bin_path=dict(smbios='/usr/sbin/smbios'))
    module.run_command = FakeRunCommand(stdout="""ID                 NAME                DESCRIPTION
    0                   VMware, Inc.  Virtual SMP Cpu
    1                   VMware, Inc.  Virtual SMP Cpu
    2                   VMware, Inc.  Virtual SMP Cpu
    3                   VMware, Inc.  Virtual SMP Cpu
    4                   VMware, Inc.  Virtual SMP Cpu
    5                   VMware, Inc.  Virtual SMP Cpu
    6                   VMware, Inc.  Virtual SMP Cpu
    7                   VMware, Inc.  Virtual SMP Cpu""")

    v = SunOSVirtual(module)
    f = v.get_virtual_facts()

# Generated at 2022-06-20 20:50:30.132400
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('MockModule', (object,), dict())
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: 'path'
    s = SunOSVirtual(module)

# Generated at 2022-06-20 20:50:41.653831
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # create an instance of SunOSVirtual with mocked methods of class Virtual
    m_module = mock.MagicMock()
    m_get_bin_path = mock.PropertyMock(return_value='/usr/sbin/smbios')
    m_module.configure_mock(get_bin_path=m_get_bin_path)
    m_run_command = mock.PropertyMock(return_value=(0, '', ''))
    m_module.configure_mock(run_command=m_run_command)
    m_module.run_command = m_run_command
    m_SunOSVirtual = SunOSVirtual(m_module)

    # method get_virtual_facts with datacenter

# Generated at 2022-06-20 20:50:43.717432
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'



# Generated at 2022-06-20 20:50:46.822113
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.name == 'SunOS'
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-20 20:50:49.708983
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:52.621421
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtualCollector = SunOSVirtualCollector()
    assert virtualCollector._platform == 'SunOS'
    assert virtualCollector._fact_class.platform == 'SunOS'



# Generated at 2022-06-20 20:50:53.780161
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert isinstance(SunOSVirtual(dict()), dict)

# Generated at 2022-06-20 20:50:55.601554
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc is not None

# Generated at 2022-06-20 20:50:57.323265
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector != None

# Generated at 2022-06-20 20:51:23.786016
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-20 20:51:26.262992
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # test that the class can be instantiated
    assert SunOSVirtualCollector(dict())

# Generated at 2022-06-20 20:51:29.443731
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule({})
    fact_class = SunOSVirtual(module)
    fact_class.populate()
    assert(fact_class.module == module)

# Generated at 2022-06-20 20:51:41.567262
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ModuleMock:
        def get_bin_path(self, program):
            if program == 'zonename':
                return '/usr/bin/zonename'
            else:
                return None

        def run_command(self, command):
            if command == '/usr/bin/zonename':
                return (0, 'foo', '')
            else:
                return (0, '', '')
    module_mock = ModuleMock()

    virtual = SunOSVirtual(module_mock)
    result = virtual.get_virtual_facts()
    assert(len(result) == 3)
    assert(result['container'] == 'zone')
    assert(len(result['virtualization_tech_host']) == 1)
    assert(len(result['virtualization_tech_guest']) == 1)

# Generated at 2022-06-20 20:51:47.186375
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({}, {})

    assert sunos_virtual.virtual_facts['virtualization_type'] == "zone"
    assert sunos_virtual.virtual_facts['virtualization_role'] == "guest"
    assert sunos_virtual.virtual_facts['container'] == "zone"

# Generated at 2022-06-20 20:52:00.725651
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.sunos as sun
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    class MockModule(object):
        """MockModule for mocking a AnsibleModule"""
        def __init__(self, **kwargs):
            self.params = kwargs.get('params', {})
            self.exit_json = kwargs.get('exit_json', False)
            self.fail_json = kwargs.get('fail_json', False)
            self.exit_args = kwargs.get('exit_args', ())
            self.fail_args = kwargs.get('fail_args', ())

# Generated at 2022-06-20 20:52:03.174179
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_fact = SunOSVirtual(dict(), None)
    assert virtual_fact.platform == 'SunOS'

# Generated at 2022-06-20 20:52:05.237119
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({'module_setup': True}, {}, [])
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:52:14.510832
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.virtual.sunos.get_virtual_facts import FakePopen

    # Collected facts are stored in the 'ansible_facts' variable of the dummy module
    module = DummyModule(
        ansible_facts={},
        ansible_module_args={},
        # Trick the dummy module to use the FakePopen class instead of the real Popen class
        before_instance=lambda obj: setattr(obj, 'Popen', FakePopen)
    )

    # Setup required fixtures for the FakePopen class
    FakePopen.fixture_zonename_output = b"""global
    """

# Generated at 2022-06-20 20:52:20.893402
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    result = SunOSVirtual(module).get_virtual_facts()
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'host (control,io,service,root)'

# Generated at 2022-06-20 20:52:48.166910
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({})
    assert None is not obj

# Generated at 2022-06-20 20:52:50.956025
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor for class SunOSVirtual.
    """
    module = ansible.module_utils.fake_ansible_module.AnsibleModule()
    v = SunOSVirtual(module)
    assert v


# Generated at 2022-06-20 20:52:58.317054
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # pylint: disable=no-init

    class ModuleMock(object):

        def __init__(self):
            self.run_command_exit_code = 0
            self.run_command_output = ""

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return self.run_command_exit_code, self.run_command_output, ""

    class SunOSVirtualMock(SunOSVirtual):
        def __init__(self, module):
            SunOSVirtual._module = module

    module = ModuleMock()
    fact_module = SunOSVirtualMock(module)

    # Tests to detect a domaining (Sparc hardware)
    fact_module.get_virtual_facts()
   

# Generated at 2022-06-20 20:53:08.781397
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    vm = SunOSVirtual(module)
    # This is the output of smbios when running on Solaris 11 in a VirtualBox
    # guest.
    # VirtualBox is not detected by modinfo on Solaris 11.

# Generated at 2022-06-20 20:53:11.472987
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:53:25.660938
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    zonename = "/bin/zonename"
    modinfo = "/usr/sbin/modinfo"
    virtinfo = "/usr/sbin/virtinfo"
    smbios = "/usr/sbin/smbios"

    # Test constructor of class SunOSVirtual
    facts = SunOSVirtual({
        'module': {
            'run_command': lambda *_: (0, 'global', ''),
            'get_bin_path': lambda *_: zonename,
        },
        'path': {'stat': lambda _: {}},
    })
    assert facts.platform == 'SunOS'
    assert facts.data == {'virtualization_tech_host': {'zone'}, 'virtualization_tech_guest': set()}


# Generated at 2022-06-20 20:53:27.188843
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt_collector = SunOSVirtualCollector()
    assert virt_collector.platform == 'SunOS'

# Generated at 2022-06-20 20:53:30.278664
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Initialization is done by Ansible
    collector = SunOSVirtualCollector()
    assert collector
    assert collector._fact_class is SunOSVirtual
    assert collector._platform is 'SunOS'
    assert collector.virtual is None


# Generated at 2022-06-20 20:53:45.251373
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sun.sunos import SunOSVirtual
    ##
    ## Test virtualization of Solaris 11 zone
    ##
    #
    # Test a global zone
    test_module = MockAnsibleModule()
    test_module.run_command = Mock(return_value=(0, "global\n", ""))
    virtual = SunOSVirtual(test_module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'zone' in virtual_facts['virtualization_tech_host']
    #
    # Test a lx branded zone
    test_module = MockAnsibleModule()
    test_module.run_command = Mock(return_value=(0, "lx-zone\n", ""))
   

# Generated at 2022-06-20 20:54:00.158438
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeANSIModule()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/virtinfo'
    module.read_file = MagicMock()
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'zone' in virtual_facts['virtualization_type']
    assert 'guest' in virtual_facts['virtualization_role']

# Generated at 2022-06-20 20:55:00.644015
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts_d = {}
    facts = SunOSVirtual(facts_d, None)

    assert 'virtualization_type' in facts.virtual
    assert 'virtualization_role' in facts.virtual
    assert 'virtualization_tech_guest' in facts.virtual
    assert 'virtualization_tech_host' in facts.virtual

# Generated at 2022-06-20 20:55:02.302850
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v
    assert isinstance(v, SunOSVirtualCollector)
    assert v._platform == 'SunOS'

# Generated at 2022-06-20 20:55:08.106353
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test VM Ware
    module = FakeAnsibleModule()
    module.run_command = run_command_fakeoutput
    module.get_bin_path = lambda _: "/usr/sbin/virtinfo"
    virtual_sunos = SunOSVirtual(module)
    facts = virtual_sunos.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set(['ldom', 'vmware'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'


# Generated at 2022-06-20 20:55:10.436614
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual({}, {}, {})
    assert m.platform == "SunOS"

# Generated at 2022-06-20 20:55:16.747854
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'container': 'zone',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set(),
    }

    v = SunOSVirtual({})
    assert v.get_virtual_facts() == virtual_facts



# Generated at 2022-06-20 20:55:19.309037
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.data['virtualization_tech_guest'] == set()
    assert virtual.data['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:55:29.110866
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # create a mock module
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', 'virtual'], type='list')
        )
    )
    # create a mock module
    facts_collector = collector.FactsCollector(module=module)

    facts_collector.collect()

    # create a SunOSVirtual object
    virtual_info = SunOSVirtual(module=module, facts=facts_collector)

    # test get_virtual_facts
    virtual_facts = virtual_info.get_virtual_facts()
    assert virtual_facts is not None
    assert 'container' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-20 20:55:33.622872
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSVirtual
    assert not hasattr(c, '_types')


# Generated at 2022-06-20 20:55:38.573662
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x.platforms == ['SunOS']
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:55:44.660522
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert SunOSVirtual(None).get_virtual_facts() == {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'container': 'zone', 'virtualization_tech_guest': set(['xen']), 'virtualization_tech_host': set(['zone'])}

# Generated at 2022-06-20 20:57:54.059955
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = ansible_fake_module()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:58:01.371154
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Virtual
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, 'global', 'global'))
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert(virtual_facts['virtualization_role'] == 'host')
    assert(virtual_facts['virtualization_type'] == 'zone')
    assert(virtual_facts['virtualization_tech_guest'] == set())
    assert(virtual_facts['virtualization_tech_host'] == {'zone'})
    assert(not 'container' in virtual_facts)
    module.get_bin_path = MagicMock(return_value=False)
    module.run_command = MagicMock(return_value=(0, '', ''))
    virtual