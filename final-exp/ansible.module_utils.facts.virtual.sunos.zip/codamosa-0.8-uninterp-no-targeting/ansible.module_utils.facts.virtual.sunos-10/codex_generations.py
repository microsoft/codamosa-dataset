

# Generated at 2022-06-20 20:48:23.189851
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:48:24.616400
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual({'ansible_facts': {'kernel': 'SunOS'}})



# Generated at 2022-06-20 20:48:26.344221
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import FactCollector
    assert issubclass(SunOSVirtualCollector, FactCollector)

# Generated at 2022-06-20 20:48:31.984428
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({'ANSIBLE_MODULE_ARGS': {}})
    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual
    assert virtual._collector_class == SunOSVirtualCollector


# Generated at 2022-06-20 20:48:43.002541
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import sunos

    # create instance of class SunOSVirtual
    obj = sunos.SunOSVirtual()

    # create fake module object with parameters below
    # zone: zonename
    # branded zone: /.SUNWnative
    # container: modinfo
    # global zone vzone
    module = type('obj', (object,), {'run_command':zone_zone_zone_zone_zone_zone_zone_zone_zone_zone_zone_zone_zone_zone_zone_zone})

    obj.module = module
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'


# Generated at 2022-06-20 20:48:46.404393
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'



# Generated at 2022-06-20 20:48:53.263477
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    with open('tests/unit/module_utils/facts/virtual/SunOSVirtual/testdata.txt') as f:
        virtual_testdata = f.read()

    module = AnsibleModule(argument_spec={})

    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = Mock(side_effect=lambda arg: arg)
    module.params = {}

    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    assert facts == json.loads(virtual_testdata)

# Generated at 2022-06-20 20:49:01.201583
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class MockModule:
        def run_command(self, *args):
            output = "  400 0 0 s8e3b: awcs LSILOGIC     Fibre Channel Disk (000101)"
            return 0, output, ""

        def get_bin_path(self, *args):
            return '/sbin/' + args[0]

    module = MockModule()
    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == "vmware"
    assert facts['virtualization_role'] == "guest"

# Generated at 2022-06-20 20:49:05.273877
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  sunos_virtual_collector = SunOSVirtualCollector()
  assert sunos_virtual_collector._fact_class == SunOSVirtual
  assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:49:15.198582
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    assert virtual_facts == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    module = AnsibleModule(argument_spec={})
    module.params['ansible_facts'] = {'zonename': 'global'}
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    assert virtual_facts == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['zone']),
    }



# Generated at 2022-06-20 20:49:30.990904
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x
    assert x.platform == 'SunOS'

# Generated at 2022-06-20 20:49:33.079753
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._fact_class is not None
    assert c._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:49:42.915903
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Tests with facts from a zone
    zone_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': None,
        'container': 'zone'
    }
    zone_sys_info = """
systeminfo:systeminfo_1.1r
        Sun_Microsystems
        SunOS
        5.11
        11.4
        i86pc
    """
    zone_zone_info = """
brand:zoneinfo_1.0
        native
        branded
"""

    # Tests with facts from a branded zone
    branded_zone_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': None,
        'container': 'zone'
    }

# Generated at 2022-06-20 20:49:45.138167
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert issubclass(vc._fact_class, Virtual)

# Generated at 2022-06-20 20:49:53.571304
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    virt = SunOSVirtual(module)

    # Test with a Solaris Zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    os.path.isdir = MagicMock(return_value=True)
    result = virt.get_virtual_facts()
    assert('zone' in result['virtualization_tech_host'])
    assert('zone' in result['virtualization_tech_guest'])
    assert(result['container'] == 'zone')

    # Test with a Solaris Zone with VMware
    modinfo = []


# Generated at 2022-06-20 20:50:00.450373
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    result = {'virtualization_type': '',
              'virtualization_role': '',
              'container': '',
              'virtualization_tech_guest': set(),
              'virtualization_tech_host': set()}
    virt = SunOSVirtual(module)
    assert(virt.get_virtual_facts() == result)


# Generated at 2022-06-20 20:50:11.562309
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-20 20:50:16.087026
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    (is_class, obj) = Virtual.load_virtual_module("SunOS")
    assert is_class
    assert obj.__doc__ == '''
        This is a SunOS-specific subclass of Virtual.  It defines
        - virtualization_type
        - virtualization_role
        - container
        '''
    assert obj.platform == 'SunOS'


# Generated at 2022-06-20 20:50:20.695279
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = run_command
    v = SunOSVirtual(module)
    assert v.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
        'container': None
    }



# Generated at 2022-06-20 20:50:23.271892
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:47.067934
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Successfully return virtual facts for a solaris 11.2 zone
    module = FakeModule({'zonename': '/usr/bin/zonename'}, {},
                        module_args='',
                        bin_path=dict(zonename='/usr/bin/zonename'))
    set_module_args(module, dict(gather_subset='virtual'))
    module.execute_module()
    expected_facts = {
        'container': 'zone',
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'zone'},
    }
    assert_equal(module.exit_json['ansible_facts']['ansible_virtual'], expected_facts)

    # Successfully return virtual facts

# Generated at 2022-06-20 20:50:49.972132
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert isinstance(x.facts, SunOSVirtual)

# Generated at 2022-06-20 20:50:52.893379
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts_dict = SunOSVirtual().get_virtual_facts()
    assert virtual_facts_dict['virtualization_role'] == 'guest'



# Generated at 2022-06-20 20:51:06.290482
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec=dict()
    )
    m.get_bin_path = lambda _: 'foo'
    m.run_command = lambda _: (0, 'foo', '')
    sv = SunOSVirtual(module=m)

    facts = sv.get_virtual_facts()
    assert facts['container'] == 'zone'
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert facts['virtualization_tech_host'] == set(['zone'])


if __name__ == '__main__':
    testme()

# Generated at 2022-06-20 20:51:08.292771
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert isinstance(instance, SunOSVirtualCollector)

# Generated at 2022-06-20 20:51:14.340829
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Constructor of class SunOSVirtualCollector
    '''
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:51:17.483494
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    platform_virtual_facts = SunOSVirtualCollector().collect(None, None)
    sunos_virtual_facts = SunOSVirtual().get_all_facts()
    assert sunos_virtual_facts == platform_virtual_facts

# Generated at 2022-06-20 20:51:27.684991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fixture = {'module_name': 'test',
               'get_bin_path.return_value': None,
               'run_command.return_value': (0, '', ''),
               'zonename.return_value': (0, '', ''),
               'smbios.return_value': (0, '', ''),
               'virtinfo.return_value': (0, '', ''),
               'modinfo.return_value': (0, '', '')}
    mocked_module = type('MockedModule', (), fixture)

    virtual = SunOSVirtual(mocked_module)
    facts = virtual.get_all()

    assert 'virtualization_type' in facts
    assert 'virtualization_type_role' in facts
    assert 'container' in facts
    assert 'virtualization_tech_guest' in facts


# Generated at 2022-06-20 20:51:30.191912
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test class SunOSVirtualCollector constructor
    """

    from ansible.module_utils.facts import virtual
    facts_class = virtual.SunOSVirtualCollector()
    assert isinstance(facts_class, SunOSVirtualCollector)

# Generated at 2022-06-20 20:51:42.282518
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test on a non-virtualized machine
    module = FakeAnsibleModule(
        virtual=SunOSVirtual,
        zonename=False,
        smbios=False,
        virtinfo=False,
        modinfo=False
    )
    facts = dict()
    virtual = SunOSVirtual(module, facts)

    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts == dict()

    # Test on a zone
    module = FakeAnsibleModule(
        virtual=SunOSVirtual,
        zonename=True,
        smbios=False,
        virtinfo=False,
        modinfo=False
    )
    facts = dict()
    virtual = SunOSVirtual(module, facts)

    virtual_facts = virtual.get_virtual_facts()


# Generated at 2022-06-20 20:52:08.170458
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    res = SunOSVirtual({"module": "anymodule"})
    assert res.platform == 'SunOS'

# Generated at 2022-06-20 20:52:15.707140
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import tempfile
    import os
    from ansible.module_utils.facts import ansible_facts

    tmp_dir_path = tempfile.mkdtemp()
    zone_name_file_path = tmp_dir_path + '/.SUNWnative'
    open(zone_name_file_path, 'a').close()
    modinfo_file_path = tmp_dir_path + '/modinfo'
    modinfo_file = open(modinfo_file_path, 'w')
    print('Module: svm 86 3.2.1 (pseudo)\n', file=modinfo_file)
    modinfo_file.close()
    os.environ['PATH'] = tmp_dir_path

    virtual = SunOSVirtual(module=None, facts=ansible_facts)
    facts = virtual.get_virtual_facts()

# Generated at 2022-06-20 20:52:19.077878
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:52:25.593104
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({})

    v.module.run_command = lambda *args, **kwargs: (0, 'test', '')
    v.module.get_bin_path = lambda *args, **kwargs: '/bin/' + args[0]
    v.module.file_exists = lambda *args, **kwargs: True

    virtual_facts = v.get_virtual_facts()

    assert 'container' in virtual_facts
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-20 20:52:27.498919
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:52:38.976364
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    import os
    test_dir = os.path.dirname(os.path.realpath(__file__))
    fixture_path = os.path.join(test_dir, 'fixtures', 'SunOSVirtual_get_virtual_facts_output.txt')
    m = basic.AnsibleModule(argument_spec={})
    f = open(fixture_path)
    m.run_command = lambda args, check_rc=True: (0, f.read(), None)
    sunos_virtual = SunOSVirtual(m)
    facts = sunos_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:52:46.034749
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def sunos_virtinfo_format(line):
        return ' ' * 4 + line + '\n'

    fact_module = 'ansible.modules.system.sunos.virtual'
    c = FactCollector(fact_module)
    c.collect()
    assert c.facts['ansible_virtualization_type'] == 'parallels'
    assert c.facts['ansible_virtualization_role'] == 'guest'
    assert c.facts['ansible_virtualization_tech_guest'] == set(['parallels'])
    assert c.facts['ansible_virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:52:48.506147
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class.platform == "SunOS"

# Generated at 2022-06-20 20:52:54.961373
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    module.get_bin_path = fake_get_bin_path
    sunos = SunOSVirtual(module=module)
    expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'container': 'zone',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['zone'])
    }
    assert sunos.get_virtual_facts() == expected

# Simple unit test for class SunOSVirtualCollector

# Generated at 2022-06-20 20:52:56.394942
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'


# Generated at 2022-06-20 20:53:54.737275
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Test constructor of SunOSVirtual class."""
    # This will set up the module class and module_args dictionaries
    # which is what is used by the SunOSVirtual constructor:
    module_setup()
    # Do not include the constructor invocation in the coverage
    # measurement because it is implicitly invoked by the test
    # framework:
    sunos_virtual = SunOSVirtual(module=module)  # pragma: no cover
    # We are only testing the constructor here:
    assert sunos_virtual is not None  # pragma: no cover



# Generated at 2022-06-20 20:54:03.706591
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
  module = AnsibleModule(
    argument_spec=dict()
    )

  params = {
    'module': module,
    'path': os.path.dirname(__file__) + '/fixtures',
  }

  x = SunOSVirtual(**params)

  zonename_path = x.module.get_bin_path('zonename')
  modinfo_path = x.module.get_bin_path('modinfo')
  virtinfo_path = x.module.get_bin_path('virtinfo')

  module.run_command = MagicMock(return_value=(0, 'global', ''))
  module.get_bin_path = Mock(side_effect=[zonename_path, modinfo_path, virtinfo_path])
  virtual_facts = x.get_virtual_facts()

# Generated at 2022-06-20 20:54:04.782212
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert (vc._platform == 'SunOS')

# Generated at 2022-06-20 20:54:05.829793
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:54:09.173077
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.virtualization_type == 'zone'

# Generated at 2022-06-20 20:54:19.625177
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    virtual = Virtual(module)
    virtual.get_virtual_facts()
    assert module.exit_json.called
    # SunOS zone
    args, kwargs = module.exit_json.call_args
    assert 'virtualization_tech_host' in kwargs['ansible_facts']['virtualization']
    assert 'zone' in kwargs['ansible_facts']['virtualization']['virtualization_tech_host']
    assert 'virtualization_type' in kwargs['ansible_facts']['virtualization']
    assert 'virtualization_role' in kwargs['ansible_facts']['virtualization']
    # Solaris 8/9 zone
    args, kwargs = module.exit_

# Generated at 2022-06-20 20:54:22.755743
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual._platform == 'SunOS'
    assert sunos_virtual._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:54:26.774994
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual as test_SunOSVirtual
    from ansible.module_utils.facts import ModuleStub

    module = ModuleStub()
    test_virtual = test_SunOSVirtual(module)

    assert test_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:54:37.842075
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeAnsibleModuleRunCommand
    module.params = {}
    module.params['container'] = 'zone'
    module.get_bin_path = FakeAnsibleModuleBinPath
    module.get_file_content = FakeAnsibleModuleFileContent
    module.get_file_content_or_dict = FakeAnsibleModuleFileContentOrDict
    module.get_file_content_or_raise = FakeAnsibleModuleFileContentOrRaise
    module.get_mount_points = FakeAnsibleModuleMountPoints
    module.get_mount_size = FakeAnsibleModuleMountSize
    module.get_mount_status = FakeAnsibleModuleMountStatus
    module.get_mount_device = FakeAnsibleModuleMountDevice
    module.get

# Generated at 2022-06-20 20:54:41.492480
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual({})
    assert obj.platform == 'SunOS'
    assert obj.virtualization_type == {}
    assert obj.virtualization_role == {}
    assert obj.virtualization_tech_guest == set()
    assert obj.virtualization_tech_host == set()
    assert obj.container == {}

# Generated at 2022-06-20 20:57:04.605049
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()

    def mock_get_bin_path(name, opts=None):
        if name in ('zonename', 'virtinfo', 'smbios'):
            return name
        elif name == 'modinfo':
            return '/usr/sbin/modinfo'

    module.get_bin_path = mock_get_bin_path

    def mock_run_command(cmd):
        if cmd[-1] == 'zonename':
            return 0, 'non-global', ''
        elif cmd[-1] == 'modinfo':
            return 0, 'id: VMware VMX net driver\nid: VirtualBox', ''
        elif cmd[-1] == 'smbios':
            return 0, 'Manufacturer: VMware, Inc.\nManufacturer: VirtualBox', ''

# Generated at 2022-06-20 20:57:12.781518
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''Construct class SunOSVirtualCollector and print results'''
    # Create TestModule for testing
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    virt = SunOSVirtualCollector(module)

    # Print facts from SunOSVirtual class
    for fact in virt.fetch_all():
        print("%s: %s" % (fact, virt.get_facts()[fact]))

if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-20 20:57:15.173497
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    fact_subclass = SunOSVirtual(module)
    assert isinstance(fact_subclass._module, FakeAnsibleModule)

# Generated at 2022-06-20 20:57:18.384814
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector('/usr/bin/virtinfo')
    assert virtual_collector.platform == 'SunOS'

# Generated at 2022-06-20 20:57:32.273236
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    virt = SunOSVirtual(module)

# Generated at 2022-06-20 20:57:33.793776
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Test creation of SunOSVirtual class
    """

    SunOSVirtual()

# Generated at 2022-06-20 20:57:43.631032
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Given - an example of a zone
    module = MockModule({'command': '/usr/sbin/zonename'})
    module.run_command = Mock(return_value=(0, "foo\n", ""))
    module.get_bin_path = Mock(return_value='/usr/sbin/zonename')

    # When - I get the virtual facts
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()

    # Then
    # I expect that it has been identified as a zone
    assert 'container' in facts
    assert facts['container'] == 'zone'



# Generated at 2022-06-20 20:57:45.848557
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class is not None
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:57:53.222276
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.SunOS import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.VirtualCollector import VirtualCollector
    obj = SunOSVirtualCollector()
    assert isinstance(obj, VirtualCollector)

# Generated at 2022-06-20 20:58:03.494205
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Construct empty SunOSVirtual
    t = SunOSVirtual({})
    assert t
    assert isinstance(t, Virtual)
    assert t.platform == 'SunOS'
    assert t.facts == {}
    assert not t.collect()

    # Construct populated SunOSVirtual
    t = SunOSVirtual({'ansible_facts': {'foo': 'bar'}})
    assert t
    assert isinstance(t, Virtual)
    assert t.platform == 'SunOS'
    assert t.facts == {'foo': 'bar'}
    assert not t.collect()
