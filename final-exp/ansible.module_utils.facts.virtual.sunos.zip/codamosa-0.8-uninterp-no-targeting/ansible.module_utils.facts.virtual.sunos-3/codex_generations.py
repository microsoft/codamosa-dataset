

# Generated at 2022-06-20 20:48:23.544276
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == 'SunOS'

# Generated at 2022-06-20 20:48:35.211206
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = mock.Mock()

# Generated at 2022-06-20 20:48:37.209391
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.platform == 'SunOS'


# Generated at 2022-06-20 20:48:38.676325
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hv = SunOSVirtual()
    assert hv.platform == 'SunOS'

# Generated at 2022-06-20 20:48:50.475477
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = Virtual()
    assert not hasattr(v, 'virtualization_type')
    assert not hasattr(v, 'virtualization_role')
    assert not hasattr(v, 'container')

    v = SunOSVirtual()
    assert not hasattr(v, 'virtualization_type')
    assert not hasattr(v, 'virtualization_role')
    assert not hasattr(v, 'container')


# Test the output of SunOSVirtual().get_virtual_facts()
# The test will execute the method get_virtual_facts() but only with the __init__(self) part.
# I.e. the test will not execute the facts gathering from the subclasses of Virtual()
# because the inheritance of those classes has not yet been set up.
# So here the test is rather the coding style of the methods than the functionality.
# It will show

# Generated at 2022-06-20 20:48:53.265491
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector(None)
    assert collector.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-20 20:48:57.048384
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS', "value of variable should be SunOS"
    assert virtual_collector._fact_class == SunOSVirtual, "value of variable should be SunOSVirtual"

# Generated at 2022-06-20 20:48:58.936467
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos = SunOSVirtual({})
    assert sunos.platform == 'SunOS'



# Generated at 2022-06-20 20:49:03.605464
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_instance = SunOSVirtual()
    if virtual_instance.platform != 'SunOS':
        print("Test for SunOSVirtual: Failed")
    else:
        print("Test for SunOSVirtual: Success")

if __name__ == '__main__':
    test_SunOSVirtual()

# Generated at 2022-06-20 20:49:10.793011
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # The class instance
    sunos = SunOSVirtual(None)

    # Mock subprocess.Popen
    class popen_mock:
        def __init__(self, command, **kwargs):
            pass

        def communicate(self):
            return ('', '', 0)

    sunos.module.run_command = popen_mock

    assert sunos.get_virtual_facts() == {}



# Generated at 2022-06-20 20:49:31.674463
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    is_py2 = (sys.version_info[0] < 3)
    if is_py2:
        import imp
        import ansible.module_utils.facts.virtual.sunos
        imp.reload(ansible.module_utils.facts.virtual.sunos)
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    # Disable pylint message: "Access to a protected member _facts of a client class"
    # pylint: disable=W0212
    # Disable pylint message: "Access to a protected member OUTPUT_RETURNED of a client class"
    # pylint: disable=W0212


# Generated at 2022-06-20 20:49:33.788910
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert isinstance(instance, SunOSVirtualCollector)


# Generated at 2022-06-20 20:49:43.199212
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ModuleStub(object):
        def __init__(self, params=None):
            self.params = params or {}

        def get_bin_path(self, name, opts=None):
            if name == 'zonename':
                return '/bin/zonename'
            elif name == 'virtinfo':
                return '/usr/sbin/virtinfo'
            elif name == 'smbios':
                return '/usr/sbin/smbios'
            else:
                return None

        def run_command(self, params, check_rc=True):
            if params == '/bin/zonename':
                if os.path.isdir('/.SUNWnative'):
                    return 0, 'global', ''
                else:
                    return (0, 'zone1', '')

# Generated at 2022-06-20 20:49:51.514219
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test = SunOSVirtual({})

    # On a Sparc machine
    test.module.run_command = MagicMock(return_value=(0, "VMwareA\nVMwareB\n", ""))
    facts = test.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert facts['virtualization_tech_host'] == set()

    # On an X86 machine
    test.module.run_command = MagicMock(return_value=(0, "VMwareA\nVMwareB\n", ""))
    facts = test.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
   

# Generated at 2022-06-20 20:50:04.249164
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    for version in ['7', '8', '9', '10']:
        module.run_command = create_mock_command_run(version)
        virtual_facts = SunOSVirtual(module).get_virtual_facts()
        assert virtual_facts['virtualization_role'] == 'guest'
        assert 'zone' in virtual_facts['virtualization_tech_guest']
        assert 'zone' in virtual_facts['virtualization_tech_host']
        assert virtual_facts['container'] == 'zone'

    # Test 'domaining' on Sparc hardware
    module.run_command = create_mock_command_run('domaining')
    virtual_facts = SunOSVirtual(module).get_virtual_facts()

# Generated at 2022-06-20 20:50:15.128058
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={},
    )

    fake_facts = {}

    get_bin_path_mock = MagicMock(side_effect=lambda x: 'testbin/' + x)
    module.get_bin_path = get_bin_path_mock

    run_command_mock = MagicMock(return_value=(0, '', ''))
    module.run_command = run_command_mock

    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()

    # Check that the test returned result uses the generic virtual facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_type_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
   

# Generated at 2022-06-20 20:50:17.091971
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_fact_class = SunOSVirtual()
    assert virtual_fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:50:23.036875
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Make sure method get_virtual_facts of class SunOSVirtual returns expected results
    # for a global zone
    virtual = SunOSVirtual({})
    virtual['module'] = {'run_command': lambda cmd, check_rc=True: (0, 'global\n', '')}
    virtual['module']['get_bin_path'] = lambda cmd: '/usr/bin/' + cmd
    assert(virtual.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(['zone'])})

    # Make sure method get_virtual_facts of class SunOSVirtual returns expected results
    # for a zone if we can't detect the host virtualization
    virtual = SunOSVirtual({})

# Generated at 2022-06-20 20:50:31.868065
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.sunos.SunOSVirtual import \
        SunOSVirtualCollector
    for x in [SUNOS_virtual, SUNOS_global_zone_virtualized, SUNOS_zone_virtualized]:
        collector = SunOSVirtualCollector()
        facts = collector.collect(x['ansible_facts'], x['platform'])
        assert facts['virtualization_type'] == x['virtualization_type']
        assert facts['virtualization_role'] == x['virtualization_role']
        assert facts['container'] == x['container']

# Unit tests for SunOSVirtual

# Generated at 2022-06-20 20:50:39.500149
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from mock import Mock

    from module_utils.facts import Facts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from module_utils.facts import sunosp

    mock_module = Mock()
    mock_module.get_bin_path = sunosp.get_bin_path

    f = Facts(mock_module)
    f.populate_facts()

    c = SunOSVirtualCollector(f)
    f[c._platform] = {}
    c.collect()

# Generated at 2022-06-20 20:50:53.054477
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert isinstance(virtual, Virtual)

# Generated at 2022-06-20 20:50:54.944014
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual is not None

# Generated at 2022-06-20 20:51:07.427281
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual_obj = SunOSVirtual({})
    # Test for a zone
    SunOSVirtual_obj.module.run_command = lambda x, check_rc=True: (0, "test", None)
    SunOSVirtual_obj.isdir = lambda x: False
    facts = SunOSVirtual_obj.get_virtual_facts()
    assert facts == {
        'virtualization_role': 'guest',
        'virtualization_type': 'zone',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': set(),
        'container': 'zone',
    }

    # Test for a branded zone
    SunOSVirtual_obj.module.run_command = lambda x, check_rc=True: (0, "global", None)

# Generated at 2022-06-20 20:51:10.429950
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._fact_class is SunOSVirtual
    assert c._platform == 'SunOS'

# Generated at 2022-06-20 20:51:17.400635
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test on a guest
    module = AnsibleModule(argument_spec={})
    SunOSVirtual.get_virtual_facts(module)
    assert 'virtualization_type' in module.ansible_facts
    assert 'virtualization_role' in module.ansible_facts
    assert 'virtualizaton_tech_guest' in module.ansible_facts
    assert 'virtualizaton_tech_host' in module.ansible_facts
    assert 'container' in module.ansible_facts
    if module.ansible_facts['virtualization_type'] == 'parallels':
        assert module.ansible_facts['virtualization_role'] == 'guest'
    elif module.ansible_facts['virtualization_type'] == 'vmware':
        assert module.ansible_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:51:24.259782
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = type('AnsibleModule', (object,), {})
    module.get_bin_path = lambda x: "zonename"
    module.get_bin_path = lambda x: ("modinfo")
    module.run_command = lambda x: (0, "", "")

    v = SunOSVirtual(module)
    facts = v.get_virtual_facts()
    assert "container" in facts

# Generated at 2022-06-20 20:51:31.834446
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = {}
    facts['ansible_virtualization_type'] = 'VMware'
    facts['ansible_product_name'] = 'VMware Virtual Platform'
    module = FakeAnsibleModule(facts=facts)

    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:51:44.428160
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class SunOSVirtual """

    class MockZonenameModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            return '/usr/bin/zonename'

        def run_command(self, cmd, check_rc=True):
            return self.rc, self.out, self.err

    class MockSmbiosModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            if name == 'zonename':
                return None

# Generated at 2022-06-20 20:51:46.519630
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:51:47.793450
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector('testmodule')

# Generated at 2022-06-20 20:52:13.937453
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual
    assert vc._fact_class().platform == 'SunOS'

# Generated at 2022-06-20 20:52:19.369508
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_obj = SunOSVirtual()
    result = test_obj.get_virtual_facts()
    # Check that method returns a dictionary
    assert type(result) is dict

# Generated at 2022-06-20 20:52:30.124541
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This test checks that get_virtual_facts of class SunOSVirtual produces the expected output.
    """

    module = MockAnsibleModule()

    # If zone name is global, it's a host zone
    module.run_command.return_value = (0, 'global\n', '')
    module.get_bin_path.return_value = '/usr/sbin/zonename'
    module.exists.return_value = False

    sunos_virtual = SunOSVirtual(module)

    # Check the output
    expected_output = {
        'virtualization_role': 'host',
        'virtualization_type': None,
        'virtualization_tech_host': set(['zone']),
        'virtualization_tech_guest': set([]),
    }

    assert sunos_virtual.get_virtual

# Generated at 2022-06-20 20:52:33.447442
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:52:39.042008
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class.platform == 'SunOS'
    assert vc._fact_class.get_virtual_facts() == {}


# Generated at 2022-06-20 20:52:41.400928
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Create a SunOSVirtual object to test if it is constructed properly
    '''
    virtual = SunOSVirtual({})
    assert virtual._platform == 'SunOS'

# Generated at 2022-06-20 20:52:55.543910
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class Module:
        def __init__(self):
            self.params = None
            self.run_command_results = [(0, "global", None)]
            self.run_command_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_results.pop()

    class VirtualSunOS(SunOSVirtual):
        def __init__(self):
            pass

        def get_bin_path(self, cmd, required=False):
            return cmd

    module = Module()
    virtual = VirtualSunOS()
    virtual.module = module

    facts = virtual.get_virtual_facts()

    assert module.run_command_calls[0] == 'zonename'
    assert facts['container'] == 'zone'

# Generated at 2022-06-20 20:53:07.503719
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import unittest.mock
    # Mock module
    module = unittest.mock.Mock()
    module.run_command = unittest.mock.Mock(return_value=(0, 'global', ''))
    module.get_bin_path = unittest.mock.Mock(return_value='/usr/sbin/zonename')
    # Create SunOSVirtual instance
    sunos_virtual = SunOSVirtual(module)
    # Get virtual facts
    virtual_facts = sunos_virtual.get_virtual_facts()
    # Check virtual facts
    assert virtual_facts


if __name__ == '__main__':
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:53:11.891001
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual
    assert collector._fact_class().platform == 'SunOS'

# Generated at 2022-06-20 20:53:15.623951
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert(vc._platform == 'SunOS')
    assert(isinstance(vc._fact_class, SunOSVirtual))

# Generated at 2022-06-20 20:54:14.883609
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import re


# Generated at 2022-06-20 20:54:20.800256
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['container'], str) or virtual_facts['container'] is None
    assert isinstance(virtual_facts['virtualization_type'], str) or virtual_facts['virtualization_type'] is None
    assert isinstance(virtual_facts['virtualization_role'], str) or virtual_facts['virtualization_role'] is None

# Generated at 2022-06-20 20:54:24.493796
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert isinstance(obj, SunOSVirtualCollector)
    assert isinstance(obj._fact_class, SunOSVirtual)
    assert obj._platform == 'SunOS'


# Generated at 2022-06-20 20:54:36.637404
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create mocks
    module = MockModule()
    module.run_command = Mock(return_value=(0, "global\n", ""))
    module.get_bin_path = Mock(return_value="/bin/zonename")
    # Call the method
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    # Check the result
    assert virtual_facts == {'virtualization_role': 'guest', 'container': 'zone', 'virtualization_type': 'zone',
        'virtualization_tech_guest': set([u'zone']), 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:54:38.675853
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert(virtual)



# Generated at 2022-06-20 20:54:43.665769
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    result = SunOSVirtual(module).collect()
    assert result.get('virtualization_tech_guest') == 'unknown'
    assert result.get('virtualization_type') == 'unknown'
    assert result.get('virtualization_role') == 'unknown'
    assert result.get('container') == 'unknown'

# Generated at 2022-06-20 20:54:45.601014
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)


# Generated at 2022-06-20 20:54:47.685561
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fc = SunOSVirtualCollector()
    assert fc.platform == 'SunOS'

# Generated at 2022-06-20 20:54:53.431744
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda *args: '/bin/' + args[0],
        'run_command': lambda *args: (0, '', '')
    })()
    SunOSVirtual(module)

# Generated at 2022-06-20 20:54:56.013525
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:57:02.882128
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, {})
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 20:57:06.834423
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual({})
    assert x.data['virtualization_type'] == "zone"
    assert x.data['virtualization_role'] == "guest"
    assert x.data['container'] == "zone"

# Generated at 2022-06-20 20:57:09.970834
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert SunOSVirtual(None) in collector._collectors

# Generated at 2022-06-20 20:57:24.684501
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    collector = SunOSVirtualCollector(None)
    # Create fake facts from facts.d directory
    fact_content = {'facts': {'system': 'SunOS'}}
    fact_content['facts']['is_zone'] = 'true'
    fact_content['facts']['zone'] = 'global'
    # Set fake vitual facts to test get_virtual_facts method
    collector.virtual_facts = fact_content
    virtual_facts = collector.get_virtual_facts()
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['container'] == 'zone'

    # Create fake facts from facts.d directory

# Generated at 2022-06-20 20:57:28.151696
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # First test: if the SunOSVirtualCollector constructor without arguments
    # is not valid
    collector = SunOSVirtualCollector()
    # Second test: if the SunOSVirtualCollector constructor with a Module argument
    # is valid
    module = VirtualCollector.get_module()
    collector = SunOSVirtualCollector(module)
    return

# Generated at 2022-06-20 20:57:34.322472
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Mock module for SunOSVirtual
    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command

    # Init SunOSVirtual class and test get_virtual_facts method
    sunos = SunOSVirtual(module)
    virtual_facts = sunos.get_virtual_facts()
    assert virtual_facts is not None
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts


# Generated at 2022-06-20 20:57:39.165719
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual(dict())
    assert sunosvirtual.virtualization_type is None
    assert sunosvirtual.virtualization_role is None
    assert sunosvirtual.container is None

# Generated at 2022-06-20 20:57:43.188565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class is not None, 'Class definition is not None'
    assert vc._platform == 'SunOS', 'Platform is SunOS'

# Generated at 2022-06-20 20:57:46.284903
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:57:52.247207
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual().platform == 'SunOS'
    assert SunOSVirtual().get_virtual_facts() is None
