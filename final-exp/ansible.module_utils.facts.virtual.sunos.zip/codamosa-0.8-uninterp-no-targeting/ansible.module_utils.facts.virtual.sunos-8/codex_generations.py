

# Generated at 2022-06-20 20:48:26.453119
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    # Fake module
    module.run_command = lambda x: (0, '', '',)
    module.get_bin_path = lambda x: '__bin_path__'
    module.os_path_exists = lambda x: True

    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])

# Generated at 2022-06-20 20:48:31.639936
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module_mock = MockModule({})
    sunosvirtual = SunOSVirtual(module_mock)

    assert sunosvirtual.platform == 'SunOS'
    assert sunosvirtual.module == module_mock


# Generated at 2022-06-20 20:48:42.621937
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # This script return the path of a binary files that provides
    # information about the virtualisation. We create a mock object
    # to fake these commands return values.
    import mock
    import sys

    is_file = mock.Mock(side_effect=["False", "True", "True"])
    exists = mock.Mock(side_effect=["False", "True", "True"])

    with mock.patch('os.path.isfile', is_file):
        with mock.patch('os.path.exists', exists):
            c = SunOSVirtualCollector()
            assert c.facts == {'virtualization_role': 'guest', 'virtualization_type': 'zone', 'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:48:46.056065
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    l = SunOSVirtualCollector()
    assert l.platform == 'SunOS'
    assert l._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:48:47.590992
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    SunOSVirtualCollector(module)



# Generated at 2022-06-20 20:48:50.611526
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert isinstance(x, (SunOSVirtualCollector, VirtualCollector)) and x._platform == 'SunOS' and isinstance(x._fact_class, SunOSVirtual)

# Generated at 2022-06-20 20:48:52.811746
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:49:04.683537
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual(dict(module=dict(run_command=run_command)))
    virtual_facts = virtual.get_virtual_facts()
    assert('container' in virtual_facts)
    if 'container' in virtual_facts:
        assert(virtual_facts['container'] == 'zone')
    assert('virtualization_type' in virtual_facts)
    if 'virtualization_type' in virtual_facts:
        assert(virtual_facts['virtualization_type'] == 'vmware')
    assert('virtualization_role' in virtual_facts)
    if 'virtualization_role' in virtual_facts:
        assert(virtual_facts['virtualization_role'] == 'guest')
    assert('virtualization_tech_host' in virtual_facts)

# Generated at 2022-06-20 20:49:14.836751
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Prepare test data
    args = '{"module_utils.basic.AnsibleModule":{"_name":"setup",' \
           '"_aliases":[],"_module_shim_args":{"_ansible_version":"2.5.3",' \
           '"_ansible_module_name":"setup","_ansible_no_log":"false"},' \
           '"_ansible_module_shim":{"_name":"setup","_ansible_version":"2.5.3"},' \
           '"_ansible_module_shim_defaults":null}}'

    # Store original run_command
    original = SunOSVirtual._run_command

    # Prepare test run_command

# Generated at 2022-06-20 20:49:23.600363
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    input_data = """
    1.00 sun4u  (0x01) [IBM] [Sun] [SunBlade 2500] [1.0]

    """
    expected = {'virtualization_type': 'xen', 'virtualization_role': 'guest'}
    module = type('', (), {'get_bin_path': lambda t, x: '/usr/bin/smbios', 'run_command': lambda x, y, z: (0, input_data, None)})
    v = SunOSVirtual(module)
    assert v.get_virtual_facts() == expected


# Generated at 2022-06-20 20:49:36.947547
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    subject = SunOSVirtual(dict())
    assert isinstance(subject, Virtual)
    assert subject.platform == 'SunOS'

# Generated at 2022-06-20 20:49:40.272072
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual.platform == 'SunOS'
    assert SunOSVirtual.is_platform(dict())
    assert SunOSVirtual.is_platform(dict(ansible_os_family='SunOS'))
    assert not SunOSVirtual.is_platform(dict(ansible_os_family='Linux'))

# Generated at 2022-06-20 20:49:43.606738
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector.get_platforms(), list)
    assert SunOSVirtualCollector.is_platform('SunOS')

# Generated at 2022-06-20 20:49:51.803042
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.load_file_common_arguments = MagicMock(return_value={})
    module.is_executable = MagicMock(return_value=True)

    module.run_command = MagicMock(return_value=(0, 'VMware', ''))
    module.get_bin_path = MagicMock(return_value=True)
    sun_virtual = SunOSVirtual(module)
    virtual_facts = sun_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:49:54.810140
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert virtual.platform == 'SunOS'
    assert not hasattr(virtual, 'virtualization_type')
    assert not hasattr(virtual, 'virtualization_role')
    assert not hasattr(virtual, 'container')
    assert not hasattr(virtual, 'container_uuid')
    assert not hasattr(virtual, 'container_name')
    assert not hasattr(virtual, 'virtualization_tech_host')
    assert not hasattr(virtual, 'virtualization_tech_guest')

# Generated at 2022-06-20 20:49:55.942767
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:58.178599
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(None, dict(), dict())
    assert virt.platform == 'SunOS'


# Generated at 2022-06-20 20:50:01.640023
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-20 20:50:04.207369
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({'ANSIBLE_MODULE_ARGS':{'gather_subset':'all'}})
    assert s.platform == 'SunOS'

# Generated at 2022-06-20 20:50:06.278805
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Unit test for the constructor of class SunOSVirtualCollector."""
    instance = SunOSVirtualCollector()
    assert instance.platform == 'SunOS'
    assert instance.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:32.456964
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = MagicMock()
    module.get_bin_path.return_value = True
    module.run_command.return_value = (0, 'global', '')
    virtual = SunOSVirtual(module)
    assert virtual._platform == 'SunOS'

# Generated at 2022-06-20 20:50:34.360803
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    V = SunOSVirtual('/usr/bin/ansible')
    assert V.platform == 'SunOS'
    assert V.exists

# Generated at 2022-06-20 20:50:38.008445
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    # the following exception will raise if the unit test failed
    assert collector.platform == 'SunOS'

# Generated at 2022-06-20 20:50:39.110715
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})

# Generated at 2022-06-20 20:50:39.978600
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts is not None


# Generated at 2022-06-20 20:50:40.725355
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, {})
    assert v.platform == 'SunOS'


# Generated at 2022-06-20 20:50:42.729298
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({'module': None})
    assert facts.platform == "SunOS"

# Generated at 2022-06-20 20:50:48.781056
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    sunos_virtual = SunOSVirtual(module)
    # When virtinfo is not present, get_virtual_facts must not raise an exception
    sunos_virtual.get_virtual_facts()
    # When virtinfo is not present, get_virtual_facts must not raise an exception
    sunos_virtual.get_virtual_facts()


# Generated at 2022-06-20 20:51:01.840909
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys
    # Mock to return the output of the command.
    class MockModule(object):
        class FakeModuleExit(Exception):
            value = False

        def __init__(self):
            self.run_command_value = 0

        def run_command(self, cmd):
            if 'zonename' in cmd:
                return 0, 'global\n', ''

# Generated at 2022-06-20 20:51:03.369945
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    a = SunOSVirtual({})
    assert a.platform == 'SunOS'

# Generated at 2022-06-20 20:51:50.620879
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v is not None


# Generated at 2022-06-20 20:51:55.423691
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This function is a unit test that verifies that all class
    attributes have been properly set up.
    """
    test_object = SunOSVirtualCollector()
    assert test_object._fact_class is SunOSVirtual

# Generated at 2022-06-20 20:51:58.849911
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun = SunOSVirtualCollector()
    assert sun._fact_class == SunOSVirtual
    assert sun._platform == "SunOS"

# Generated at 2022-06-20 20:52:00.472749
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:52:11.460815
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''

    # Create a SunOSVirtual object from a mock module
    module = create_mock_module()
    virtual_facts_obj = SunOSVirtual(module)

    # Container test
    with patch('ansible.module_utils.facts.virtual.SunOSVirtual.get_virtual_facts', return_value={}):
        virtual_facts_obj.get_virtual_facts()
        assert module.params['container'] is None
    with patch('ansible.module_utils.facts.virtual.SunOSVirtual.get_virtual_facts', return_value={'container': 'zone'}):
        virtual_facts_obj.get_virtual_facts()
        assert module.params['container'] == 'zone'

    # Virtualization_type test

# Generated at 2022-06-20 20:52:15.143378
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert isinstance(collector.get_virtual_facts(), dict)
    assert isinstance(collector.get_virtual_facts()['virtualization_type'], str)
    assert isinstance(collector.get_virtual_facts()['virtualization_role'], str)
    assert isinstance(collector.get_virtual_facts()['container'], str)

# Generated at 2022-06-20 20:52:21.474537
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    collector = SunOSVirtualCollector(module)

    assert collector
    assert collector._platform == 'SunOS'
    assert collector._fact_class is SunOSVirtual

# Generated at 2022-06-20 20:52:25.549180
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hostname = 'foo'
    virtual_facts = SunOSVirtual(None, hostname)
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.hostname == hostname

# Generated at 2022-06-20 20:52:29.390751
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvirtual = SunOSVirtualCollector()
    assert sunosvirtual.fact_class == SunOSVirtual
    assert sunosvirtual.platform == 'SunOS'


# Generated at 2022-06-20 20:52:35.756926
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    sc = SunOSVirtualCollector()
    assert isinstance(sc, SunOSVirtualCollector)
    assert isinstance(sc, Virtual)

# Generated at 2022-06-20 20:54:13.436246
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == "SunOS"
    assert isinstance(obj._fact_class, SunOSVirtual)

# Unit test the method get_all_facts()

# Generated at 2022-06-20 20:54:15.525737
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:54:21.142980
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    c = SunOSVirtual()
    c.collect()
    facts = c.get_facts()

    # If you see this assert fail, either you just added a new platform to this
    # plugin or it is a bug in VirtualCollector.collect().
    assert c.platform == 'SunOS'
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert facts['virtualization_role'] in ['guest', 'host', 'zone', None]
    assert facts['virtualization_type'] in ['kvm', 'parallels', 'vmware', 'virtualbox', None]


# Generated at 2022-06-20 20:54:25.039297
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class.platform == 'SunOS'
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:54:25.835809
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v

# Generated at 2022-06-20 20:54:30.219847
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    keys = [ 'container', 'virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host' ]
    for key in keys:
        assert key in facts._virtual_facts_cache, "The cached value of %s is missing" % key

# Generated at 2022-06-20 20:54:43.306686
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    #
    # Exit code 0, multi-line output.
    #

# Generated at 2022-06-20 20:54:44.610576
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create test object
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:54:47.837366
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()

    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:54:51.455739
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    out = SunOSVirtual().get_virtual_facts()
    assert 'virtualization_type' in out.keys()
    assert 'virtualization_role' in out.keys()
    assert 'virtualization_tech_host' in out.keys()
    assert 'virtualization_tech_guest' in out.keys()