

# Generated at 2022-06-20 20:48:26.662803
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({'params': {'gather_subset': ["!all", "min"]}, 'ansible_facts': {}})
    assert virtual in SunOSVirtual.__mro__
    assert virtual.platform == "SunOS"
    assert virtual.gather_subset == ["!all", "min"]
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:48:30.437418
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert hasattr(v, 'platform')
    assert v.platform == 'SunOS'


# Generated at 2022-06-20 20:48:35.612779
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """ Test that objects of SunOSVirtualCollector can be created. """
    collector = SunOSVirtualCollector()
    assert isinstance(collector, SunOSVirtualCollector)
    assert isinstance(collector, VirtualCollector)
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual



# Generated at 2022-06-20 20:48:45.885546
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    host_facts = dict(
        module=dict(
            get_bin_path=lambda x: '/usr/sbin/' + x,
            run_command=lambda x: (0, '', ''),
        ),
    )
    host_facts['ansible_virtualization_type'] = 'vmware'
    host_facts['ansible_virtualization_role'] = 'host'

    sunosvirtual = SunOSVirtual(host_facts, dict())
    virtual_facts = sunosvirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'host'



# Generated at 2022-06-20 20:48:54.732913
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class TestModule:
        def __init__(self):
            self.virtual_facts = {}
            self.exit_json = {}
            self.fail_json = {}
        def run_command(self, args, check_rc=True):
            return (0, '', '')
        def get_bin_path(self, args, opts=None, required=False):
            return '/usr/sbin/virtinfo'
    mod = TestModule()
    x = SunOSVirtual(module=mod)
    x.get_virtual_facts()
    expected_keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_host',
        'virtualization_tech_guest',
        'container',
    ]

# Generated at 2022-06-20 20:48:57.994009
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    context = {}
    module = type('AnsibleModule', (object,), {})()
    module.params = {'gather_subset': 'all'}
    module.get_bin_path = lambda _: None
    module.run_command = lambda _: (0, '', '')
    module.exit_json = lambda **kwargs: None
    setattr(module, '_shared_loader_obj', None)
    SunOSVirtualCollector(module=module).populate()

# Generated at 2022-06-20 20:49:10.444498
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This unit test tests if by default (when the facts dict is empty) the
    method get_virtual_facts of class SunOSVirtual returns the right dict.

    It will be run by test/units/module_utils/facts/test_virtual.py
    """
    # This dict should be empty.
    facts = {}
    # Instantiate the module with dummy paramter module
    module = DummyModule
    module.get_bin_path = lambda x: '/bin/'+x
    module.run_command = lambda x: (0,'','error')
    # Instantiate the class
    sunosvirt = SunOSVirtualCollector(module).collect()[0]
    # Now let's run the method get_virtual_facts
    virtual_facts = sunosvirt.get_virtual_facts()
    # Which should return
    assert virtual_

# Generated at 2022-06-20 20:49:12.332531
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    my_sunos = SunOSVirtual('/usr/bin/python')
    assert my_sunos.platform == 'SunOS'


# Generated at 2022-06-20 20:49:15.454422
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual._platform == 'SunOS'
    assert virtual._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:49:19.212187
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}), dict())
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:49:51.185755
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path = MagicMock()
    sunos_get_virtual_facts = SunOSVirtual(module)

    virtual_facts = sunos_get_virtual_facts.get_virtual_facts()
    assert sunos_get_virtual_facts
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-20 20:49:53.345862
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj



# Generated at 2022-06-20 20:50:04.209336
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class args(object):
        def __init__(self, path=None, no_log=None):
            self.path = path
            self.no_log = no_log
    module = args()
    module.get_bin_path = lambda _: '/usr/sbin/virtinfo'
    module.run_command = lambda _: (0, '', '')
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:50:05.076102
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector is not None


# Generated at 2022-06-20 20:50:10.715562
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Run get_virtual_facts()
    virtual_facts = SunOSVirtual({'module': module}).get_virtual_facts()

    # Check the result
    module.exit_json(changed=False, ansible_facts=dict(virtual=virtual_facts))


# Generated at 2022-06-20 20:50:12.798169
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()
    assert svc.platform == 'SunOS'
    assert svc._fact_class is SunOSVirtual

# Generated at 2022-06-20 20:50:13.713248
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:50:15.081778
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    m = SunOSVirtual({}, None)
    assert isinstance(m, SunOSVirtual)

# Generated at 2022-06-20 20:50:16.732052
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    m = SunOSVirtualCollector()
    assert m != None

# Generated at 2022-06-20 20:50:27.773857
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test the get_virtual_facts() method of SunOSVirtual'''
    # Test 1: Check zone facts.
    module = get_module()
    module.get_bin_path.side_effect = lambda x: {
        'zonename': '/usr/bin/zonename',
        'modinfo': '/usr/sbin/modinfo'
    }.get(x)
    module.run_command = get_command_output(('/usr/bin/zonename', 0, 'global\n', ''), ('/usr/sbin/modinfo', 0, '', ''))
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['container'] == 'zone'
    assert 'zone' in facts['virtualization_tech_host']

# Generated at 2022-06-20 20:50:52.677314
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    obj = SunOSVirtual(None)
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 20:50:55.000010
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert isinstance(sunos_virtual, SunOSVirtualCollector)

# Generated at 2022-06-20 20:50:55.892549
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, {}, {})
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 20:51:08.165516
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    setattr(module, 'run_command', fake_run_command)
    setattr(module, 'get_bin_path', fake_get_bin_path)
    setattr(module, 'read_file', fake_read_file)

    sunos = SunOSVirtual(module=module)
    facts = sunos.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert 'kvm' in facts['virtualization_tech_guest']
    assert 'zone' in facts['virtualization_tech_host']
    assert 'container' in facts
    assert facts['container'] == 'zone'


# Generated at 2022-06-20 20:51:10.307272
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:51:20.011753
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    expected_virtual_facts = dict(
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
        virtualization_role='host (control)',
        virtualization_type='ldom'
    )
    module = MockModule()
    module.run_command.return_value = (0, '/usr/sbin/virtinfo -p\nDOMAINROLE|impl=LDoms|control=true|io=false|service=false|root=false', None)
    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts


# Generated at 2022-06-20 20:51:25.432853
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # This is the SunOSVirtual
    virtual = SunOSVirtual('module')

    virtualfacts = virtual.get_virtual_facts()
    # Check possible facts of the SunOSVirtual
    # We don't know what to expect but they should exist
    assert 'virtualization_type' in virtualfacts
    assert 'virtualization_role' in virtualfacts
    assert 'container' in virtualfacts
    assert 'virtualization_tech_host' in virtualfacts
    assert 'virtualization_tech_guest' in virtualfacts

# Generated at 2022-06-20 20:51:29.327943
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:51:31.328168
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert(virtual_facts.platform == 'SunOS')


# Generated at 2022-06-20 20:51:43.907156
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Tests using mocker fixtures
    def mocker_zone_zone_and_vmware_combo(mocker, module, rc, out, err, out1):

        mocker.patch('ansible.module_utils.facts.virtual.SunOSVirtual.get_virtual_facts')
        mocker.patch('os.path.isdir')
        mocker.patch('os.path.exists')
        mocker.patch('ansible.module_utils.facts.virtual.SunOSVirtual.module.run_command')
        os.path.isdir.return_value = True
        os.path.exists.return_value = False
        ansible.module_utils.facts.virtual.SunOSVirtual.module.run_command.return_value = rc, out, err
        ansible.module_utils.facts.virtual.SunOSVirtual

# Generated at 2022-06-20 20:52:35.071997
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test object creation
    virtual_facts = dict()
    SunOSVirtualCollector(virtual_facts=virtual_facts)
    virtual_facts = dict()
    SunOSVirtualCollector(module=dict(), virtual_facts=virtual_facts)

# Generated at 2022-06-20 20:52:38.805264
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual
    assert vc._platform == 'SunOS'

# Generated at 2022-06-20 20:52:40.100993
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual


# Generated at 2022-06-20 20:52:42.366686
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(None)
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.container == ''

# Generated at 2022-06-20 20:52:43.706316
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict())

# Generated at 2022-06-20 20:52:45.976835
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(None)
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:52:48.122965
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector(None, None)
    assert x.platform == 'SunOS'

# Generated at 2022-06-20 20:52:50.641950
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = MockAnsibleModule()
    x = SunOSVirtualCollector(module=module)
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:52:52.399288
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == 'SunOSVirtual'

# Generated at 2022-06-20 20:52:53.444912
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert Virtual


# Generated at 2022-06-20 20:54:37.127056
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    del VirtualCollector.virtual_facts_cache[:]

    v = SunOSVirtual(VirtualCollector)
    assert v.platform == 'SunOS'
    assert v.get_virtual_facts() == {'virtualization_tech_host':
                                         set(),
                                     'virtualization_tech_guest':
                                         set(),
                                     'virtualization_role':
                                         None,
                                     'virtualization_type':
                                         None}
    assert SunOSVirtualCollector._fact_

# Generated at 2022-06-20 20:54:45.488334
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock(platform='SunOS')

    # Mocking functions
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.side_effect = {'zonename': '/usr/bin/zonename', 'modinfo': '/usr/sbin/modinfo'}.get

    # Mocking file existence
    module.file_exists.side_effect = {'/.SUNWnative': True}.get

    # Mocking file reading
    module.read_file.side_effect = {'/proc/vz': '', '/etc/virtinfo': '', '/usr/sbin/smbios': ''}.get

    # Get a fake object of SunOSVirtual
    virtual = SunOSVirtual(module=module)
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-20 20:54:47.536970
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._fact_class is SunOSVirtual

# Generated at 2022-06-20 20:54:52.693117
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # The SunOSVirtualCollector class is instantiated, which also
    # calls get_virtual_facts() as a side effect, which does all the
    # actual collection.  So, no assertions here.
    SunOSVirtualCollector()


# Generated at 2022-06-20 20:54:55.947977
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    SunOSVirtualCollector(module)


# Class to fake a ansible module

# Generated at 2022-06-20 20:54:59.123059
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Only test the basic instantiation of the class. This is because
    # the VirtualCollector base class should already have been tested, so
    # all that basic functionality should be good.
    SunOSVirtualCollector('fake_module')

# Generated at 2022-06-20 20:55:00.216795
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:55:07.323360
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeCmd
    virtual = SunOSVirtual()
    virtual.module = module
    rc, out, err = module.run_command("/usr/sbin/virtinfo -p")

# Generated at 2022-06-20 20:55:07.956926
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtualCollector()
    SunOSVirtual()

# Generated at 2022-06-20 20:55:19.269602
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.platform == 'SunOS'

# Unit tests for method get_virtual_facts() of class SunOSVirtual
# Content of /proc/zoneinfo:
#          0       0    c00000        1  0   0   0   0  10     7     0     0     0
#  c8000000 c8000000  20000000        1  0   0   0   0  10     7     0     0     1
# c20000000 c20000000  38000000        1  0   0   0   0  10     7     0     0     2
# 1:global:c8000000:c20000000:a:306:0:1:0:1:0:0:0:0:0:0:0:0
# 2:zone1:c8400000:c2040000:a:306:1