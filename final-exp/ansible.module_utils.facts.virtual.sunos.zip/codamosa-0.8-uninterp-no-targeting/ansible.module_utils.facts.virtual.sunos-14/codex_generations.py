

# Generated at 2022-06-20 20:48:21.541591
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(None)

    # Check that platform is set to SunOS
    assert virt.platform == 'SunOS'

# Generated at 2022-06-20 20:48:22.485645
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

# Generated at 2022-06-20 20:48:28.357376
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.mock_command("zonename", rc=0, out="testzone")
    collector = SunOSVirtualCollector(module)
    virtual_facts = collector.collect()
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'


# Generated at 2022-06-20 20:48:36.043425
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual_facts = SunOSVirtual(module=module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-20 20:48:47.993915
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    ####
    # Global zone case
    ####

    # Case: No virtualization
    tested_virtual_facts = SunOSVirtual({'path': '/usr/sbin/dladm'}, {}).get_virtual_facts()
    assert tested_virtual_facts == {}

    # Case: VM using VMware tools
    tested_virtual_facts = SunOSVirtual({'path': '/usr/sbin/dladm', 'MODULES': [("VMware", "")]}, {}).get_virtual_facts()
    assert tested_virtual_facts == {'virtualization_type': 'vmware', 'virtualization_role': 'host'}

    # Case: VM using Virtualbox tools

# Generated at 2022-06-20 20:48:55.679272
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] <= 6:
        import unittest2 as unittest
    else:
        import unittest
    try:
        from mock import MagicMock
    except ImportError:
        from unittest.mock import MagicMock

    module = MagicMock()
    fact = SunOSVirtual(module)
    assert fact.platform == 'SunOS'
    # The following test would be better if fact.__dict__ was a MagicMock
    #assert fact.get_virtual_facts() == \
    #    {'container': 'zone',
    #     'virtualization_role': 'guest',
    #     'virtualization_type': 'vmware'}

# Generated at 2022-06-20 20:49:04.784810
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('Module', (object, ), {'get_bin_path': lambda x: '/bin/fake'})
    setattr(module, 'run_command', lambda x: (0, '', ''))
    sunos_virtual = SunOSVirtual(module)

    assert_equals(sunos_virtual.platform, 'SunOS')
    assert_equals(sunos_virtual.get_virtual_facts(), {'virtualization_role': 'guest', 'virtualization_type': 'vmware', 'virtualization_tech_guest': {'vmware'}, 'virtualization_tech_host': set()})

# Generated at 2022-06-20 20:49:09.244270
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    constructor of class SunOSVirtualCollector
    '''

    my_obj = VirtualCollector()
    sunos_obj = SunOSVirtualCollector()

    assert my_obj
    assert sunos_obj


# Generated at 2022-06-20 20:49:10.305527
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:17.214695
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    test_SunOSVirtual_get_virtual_facts: unit test for testing get_virtual_facts method of class SunOSVirtual
    '''
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.collection import BaseFactsCollection
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    import json
    import os

    class VirtualModule(object):
        def __init__(self):
            self.name = ''
            self.bin_path = {}

        def get_bin_path(self, name):
            if name in self.bin_path:
                return self.bin_path[name]
            else:
                return None


# Generated at 2022-06-20 20:49:46.541888
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virt = SunOSVirtual({'module_setup': True})
    assert virt.get_virtual_facts()['virtualization_type'] == 'zone'
    assert virt.get_virtual_facts()['virtualization_role'] == 'guest'
    assert virt.get_virtual_facts()['virtualization_tech_guest'] == set(['zone'])
    assert virt.get_virtual_facts()['virtualization_tech_host'] == set([])
    assert virt.get_virtual_facts()['container'] == 'zone'

# Generated at 2022-06-20 20:49:47.445235
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:54.674859
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class ModuleStub(object):

        def get_bin_path(self, name):
            filemap = {
                "zonename": "/usr/bin/zonename",
                "modinfo": "/usr/kernel/drv/sparcv9/sd@3,0:a",
                "virtinfo": "/usr/sbin/virtinfo",
                "smbios": "/usr/sbin/smbios"
            }
            return filemap.get(name)


# Generated at 2022-06-20 20:49:56.692750
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x
    assert x._platform == 'SunOS'

# Generated at 2022-06-20 20:50:01.766150
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Testing the instantiation of a SunOSVirtualCollector object:
    vc = SunOSVirtualCollector()
    assert isinstance(vc._fact_class, SunOSVirtual)
    assert vc._fact_class.platform == 'SunOS'
    assert vc._platform == 'SunOS'

# Generated at 2022-06-20 20:50:08.483625
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class MockModule:
        class FakeZoneRunner:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, module, command):
                return self.rc, self.out, self.err

        def __init__(self, zone_runner):
            self.zone_runner = zone_runner

        def get_bin_path(self, name):
            if name == 'zonename':
                return "/usr/bin/zonename"
            elif name == 'virtinfo':
                return "/usr/sbin/virtinfo"
            elif name == 'smbios':
                return "/usr/sbin/smbios"
            else:
                return None


# Generated at 2022-06-20 20:50:09.428703
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:50:13.581770
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Unit test for constructor of class SunOSVirtual"""
    sunos = SunOSVirtual(dict())
    assert sunos.platform == 'SunOS'
    assert sunos.virtualization_type is None
    assert sunos.virtualization_role is None
    assert sunos.virtualization_system is None
    assert sunos.container is None

# Generated at 2022-06-20 20:50:16.707780
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    This is a unit test method for SunOSVirtual class.
    """
    from ansible.module_utils.facts.virtual import SunOSVirtual
    virtual_obj = SunOSVirtual(None)
    assert virtual_obj.platform == "SunOS"

# Generated at 2022-06-20 20:50:18.460806
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a SunOSVirtual object
    x = SunOSVirtual(dict(), dict())
    # Check the default platform
    assert x.platform == 'SunOS'

# Generated at 2022-06-20 20:50:42.988133
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts
    assert virtual_facts._platform == 'SunOS'

# Generated at 2022-06-20 20:50:55.068415
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class SunOSVirtual'''

    # Create an instance of class SunOSVirtual
    sunos_virtual = SunOSVirtual()

    # Return value for when a binary does not exist
    bin_rc = 1, '', ''

    # Return value for when the output of a binary is empty
    empty_rc = 0, '', ''

    # Return value for when a binary exists (and virtinfo can be run from the global zone)
    global_rc = 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''

    # Return value for when a binary exists, but virtinfo can only be run from the global zone
    no_global_rc = 0, 'virtinfo can only be run from the global zone', ''

    # Return value for when

# Generated at 2022-06-20 20:50:57.682842
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyModule()
    collector = SunOSVirtual(module)
    assert collector.platform == 'SunOS'


# Generated at 2022-06-20 20:51:03.090802
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    # check subclass
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)
    # check superclass
    assert isinstance(sunos_virtual_collector, VirtualCollector)

# Generated at 2022-06-20 20:51:11.398124
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Unit test for get_virtual_facts of class SunOSVirtual"""

    # Run module_utils.facts.virtual.sunos.SunOSVirtual class through some
    # minimal tests
    #
    # Note that the SunOSVirtual class is a subclass of Virtual, which is a base
    # class of the VirtualCollector class.  For a better understanding of the
    # whole class hierarchy, see the docstring at the top of the files
    # module_utils/facts/virtual/base.py and module_utils/facts/virtual/linux.py.
    #
    # Since the tests are executed when the file is loaded by pytest, we've
    # used a Pythonic trick to prevent pytest from executing this code outside
    # of the testing environment.  It consists in using the __name__ variable,
    # which is automatically set to "__main__" when

# Generated at 2022-06-20 20:51:13.476366
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Create an object and make sure it is the right class
    '''

    x = SunOSVirtualCollector()
    assert isinstance(x, SunOSVirtualCollector)

    # Make sure it is a subclass of VirtualCollector
    assert isinstance(x, VirtualCollector)


# Generated at 2022-06-20 20:51:15.540830
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_obj = SunOSVirtualCollector()
    assert sunos_obj.platform == "SunOS"

# Generated at 2022-06-20 20:51:27.364164
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class RunCommandFake:
        def __init__(self):
            self.last_command = None

# Generated at 2022-06-20 20:51:29.154158
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_SunOSVirtual = SunOSVirtual({})
    assert test_SunOSVirtual

# Generated at 2022-06-20 20:51:41.319121
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    test_module.get_bin_path = Mock(return_value='/bin/zonename')
    test_module.run_command = Mock(return_value=(0, 'global', ''))
    test_module.fail_json = Mock()
    fact_module = SunOSVirtual(test_module)
    result = fact_module.get_virtual_facts()
    test_module.get_bin_path.assert_has_calls([call('zonename'), call('zonename')])
    test_module.run_command.assert_called_once_with('/bin/zonename')

# Generated at 2022-06-20 20:52:27.236193
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.virtual
    assert x.virtual.module

# Generated at 2022-06-20 20:52:31.203896
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    unit test for constructor of class SunOSVirtualCollector
    '''
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:52:37.890414
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    fact_class = SunOSVirtual
    virtual_collector = SunOSVirtualCollector(module)
    assert virtual_collector.__class__.__name__ == 'SunOSVirtualCollector'
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == fact_class
    assert virtual_collector.module == module


# Unit tests for SunOSVirtual class

# Generated at 2022-06-20 20:52:41.518190
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    module.structured = True

    sunos_virtual = SunOSVirtual(module)

    assert sunos_virtual.module == module
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:52:49.535536
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    try:
        fact_subclass = SunOSVirtualCollector()
        assert fact_subclass.__class__.__name__ == 'SunOSVirtualCollector'
        assert issubclass(fact_subclass.__class__, VirtualCollector)
        assert fact_subclass.platform == 'SunOS'
        assert fact_subclass._fact_class == SunOSVirtual
    except Exception:
        raise Exception("Unit test failed at line %s of %s" % (sys.exc_info()[2].tb_lineno, __file__))

# Generated at 2022-06-20 20:52:55.255496
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """This function is used to test if the
    SunOSVirtual.get_virtual_facts() returns a dictionary with the
    correct values of virtualization_type, virtualization_role
    and container.
    """
    module = MockModule()
    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == 'ldom'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['zone', 'ldom'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['container'] == 'zone'

# Mock class for ansible module

# Generated at 2022-06-20 20:53:00.460574
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-20 20:53:02.028066
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()

# Generated at 2022-06-20 20:53:04.330557
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    obj = SunOSVirtualCollector('foo')
    obj = SunOSVirtualCollector(platform='bar')
    obj.get_virtual_facts()

# Generated at 2022-06-20 20:53:15.833820
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "global", "")
    module.get_bin_path.side_effect = lambda x: x + "/bin"

    s = SunOSVirtual(module=module)
    facts = s.get_virtual_facts()

    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-20 20:54:54.774508
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    # Test if SunOSVirtualCollector is a VirtualCollector object
    assert isinstance(sunos_virtual_collector, VirtualCollector)
    # Test if SunOSVirtualCollector is an instance of class SunOSVirtual
    assert isinstance(sunos_virtual_collector._fact_class(), SunOSVirtual)


# Generated at 2022-06-20 20:55:03.118562
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual

    # The class VirtualCollector should be the parent class of SunOSVirtualCollector
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    # The class Virtual should be the parent class of SunOSVirtual
    assert issubclass(SunOSVirtual, Virtual)

    # Instantiate SunOSVirtualCollector()
    sys.modules['platform'] = sys.modules['ansible.module_utils.facts.virtual.base']
   

# Generated at 2022-06-20 20:55:08.954544
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert 'virtualization_type' in virtual.data
    assert 'virtualization_role' in virtual.data
    assert 'container' in virtual.data
    assert 'virtualization_tech_guest' in virtual.data
    assert 'virtualization_tech_host' in virtual.data

# Generated at 2022-06-20 20:55:12.276058
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class1 = SunOSVirtualCollector()
    assert class1.platform == 'SunOS'
    assert class1._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:17.665060
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:55:19.696176
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import subprocess
    module = subprocess
    v = SunOSVirtual(module)
    assert v.platform == 'SunOS'


# Generated at 2022-06-20 20:55:24.760081
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtual
    my_test_class=SunOSVirtual()
    my_test_class.module=MockModule()
    my_test_facts = my_test_class.get_virtual_facts()
    # Make sure something is returned
    assert my_test_facts



# Generated at 2022-06-20 20:55:25.661920
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # no error should be raised
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:55:29.324031
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosVirtualCollector = SunOSVirtualCollector()
    assert sunosVirtualCollector._platform == 'SunOS'
    assert sunosVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:44.790679
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_technologies_guest': ['zone', 'vmware'],
        'virtualization_technologies_host': ['zone']
    }

    # Test virtualized guest
    zonename = '/usr/bin/zonename'
    modinfo = '/usr/sbin/modinfo'
    virtinfo = '/usr/sbin/virtinfo'
    module = type('FakeModule', (object,), {'get_bin_path': lambda self, binary: binary if os.path.isfile(binary) else None})()
    module.run_command = lambda command: (0, 'VMwareVMware', '') if command == modinfo else (0, '', '')
    sunos_