

# Generated at 2022-06-20 20:48:22.618683
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector is not None

# Generated at 2022-06-20 20:48:32.293079
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = run_command
    v = SunOSVirtual(module)
    res = v.get_virtual_facts()
    assert res['virtualization_role'] == 'guest'
    assert res['virtualization_type'] == 'vmware'
    assert res['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert res['virtualization_tech_host'] == set(['zone'])
    assert res['container'] == 'zone'
    assert res['zone'] == 'global'



# Generated at 2022-06-20 20:48:33.707198
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_obj = SunOSVirtual()
    virtual_obj.get_all_facts()

# Generated at 2022-06-20 20:48:39.123306
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """ Unit test for constructor of class SunOSVirtualCollector """
    # Instantiate SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector()

    # Check if the class variables of SunOSVirtualCollector are correct.
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:48:43.622082
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mysys = {}
    mysys['platform'] = 'SunOS'
    mysys['distribution_version'] = '5.11'
    myvirt = SunOSVirtual(module=mysys)
    print(myvirt)
    print(myvirt.get_virtual_facts())



# Generated at 2022-06-20 20:48:46.614514
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_object = SunOSVirtual(None)
    assert virtual_object.platform == 'SunOS'

# Generated at 2022-06-20 20:48:51.906267
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor of class SunOSVirtual and
    all its subclassses must always pass.
    """
    print()
    virtual_class_list = Virtual.__subclasses__()
    for virtual_class in virtual_class_list:
        virtual_object = virtual_class()
        print(virtual_object)

if __name__ == '__main__':
    test_SunOSVirtual()

# Generated at 2022-06-20 20:48:54.430151
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    instance = SunOSVirtualCollector()
    assert isinstance(instance, VirtualCollector)
    assert isinstance(instance, SunOSVirtualCollector)


# Generated at 2022-06-20 20:48:58.936146
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector(None)

    # The class is in _fact_class
    assert vc._fact_class == SunOSVirtual

    # Override the _platform property of base class to the OS we are testing against
    assert vc._platform == "SunOS"



# Generated at 2022-06-20 20:49:00.429902
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual is not None

# Generated at 2022-06-20 20:49:14.819436
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'


# Generated at 2022-06-20 20:49:16.726126
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.virtualization_type == 'unknown'
    assert x.virtualization_role == 'unknown'

# Generated at 2022-06-20 20:49:27.662262
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # pylint: disable=protected-access

    module_mock = Mock(params={'gather_subset': ['!all', 'virtual']}, check_mode=False)
    module_mock.run_command = Mock(return_value=(0, 'out', 'err'))
    module_mock.get_bin_path = Mock(return_value=True)

    SunOSVirtual._platform_check = Mock(return_value=True)
    # Populate the cache
    SunOSVirtual.get_virtual_facts(module_mock)

    # Verify that the cache worked

# Generated at 2022-06-20 20:49:35.842151
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = SunOSVirtual({'module_setup': True}, {})
    f = m.get_virtual_facts()
    assert f['virtualization_type'] == 'vmware'
    assert f['virtualization_role'] == 'guest'
    assert 'container' in f.keys()
    assert f['virtualization_tech_guest'] == {'vmware'}
    assert f['virtualization_tech_host'] == {'zone'}

# Generated at 2022-06-20 20:49:39.322956
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

# Generated at 2022-06-20 20:49:42.778361
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert isinstance(SunOSVirtual({}), SunOSVirtual)

# Generated at 2022-06-20 20:49:48.408330
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    if 'container' in virtual_facts:
        assert virtual_facts['container'] in ('zone', 'unknown')

# Generated at 2022-06-20 20:49:52.355520
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual({})
    assert(s.system == "SunOS")


# Generated at 2022-06-20 20:49:55.997565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test VirtualCollector.__init__()
    """
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:49:58.294762
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Unit test for constructor of class SunOSVirtualCollector
    '''
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:50:30.482011
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_collector = SunOSVirtualCollector()
    test_object = SunOSVirtual(test_collector)
    test_facts = test_object.get_virtual_facts()
    assert test_facts['virtualization_type'] == 'xen'
    assert test_facts['virtualization_role'] == 'guest'
    assert test_facts['virtualization_tech_guest'] == {'kvm', 'virtualbox'}
    assert test_facts['virtualization_tech_host'] == {'zone'}
    assert test_facts['container'] == 'zone'

# Generated at 2022-06-20 20:50:31.868930
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual()
    assert s is not None


# Generated at 2022-06-20 20:50:38.697535
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    import os
    import mock

    SunOSVirtualCollector_instance = SunOSVirtualCollector()
    SunOSVirtual_instance = SunOSVirtual()
    with mock.patch.object(SunOSVirtualCollector, '_fact_class', SunOSVirtual_instance, create=False):
        with mock.patch.object(SunOSVirtualCollector, '_platform', 'SunOS', create=False):
            SunOSVirtualCollector_instance.load_platform_subclass()
            SunOSVirtual_instance.module = mock.Mock()
            SunOSVirtual_instance.module.run_command.return_

# Generated at 2022-06-20 20:50:43.632574
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeModule()
    sunos_virtual = SunOSVirtualCollector(module)
    assert isinstance(sunos_virtual, SunOSVirtualCollector)
    assert sunos_virtual._platform == "SunOS"
    assert sunos_virtual._fact_class == SunOSVirtual
    assert sunos_virtual._module == module


# Generated at 2022-06-20 20:50:54.945320
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MagicMock()
    test_object = SunOSVirtual(module)
    test_object.module.run_command = MagicMock(return_value=(0, '', ''))
    test_object.module.get_bin_path = MagicMock(return_value=True)
    test_object.module.os.path.exists = MagicMock(return_value=True)
    assert test_object.get_virtual_facts() == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_type': 'virtuozzo',
        'virtualization_tech_guest': set(['zone', 'virtuozzo']),
        'virtualization_tech_host': set(),
    }



# Generated at 2022-06-20 20:50:55.703174
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    Virt = SunOSVirtual({})
    print(Virt.get_virtual_facts())

# Generated at 2022-06-20 20:51:02.208710
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict(), dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-20 20:51:10.956784
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual()
    # The get_virtual_facts method of SunOSVirtual returns a dictionary
    # containing the following pairs:
    #   'virtualization_type' -> 'string'
    #   'virtualization_role' -> 'string'
    #   'virtualization_tech_guest' -> set(string, ...)
    #   'virtualization_tech_host' -> set(string, ...)
    #   'container' -> 'string'  (optional)
    facts = sv.get_virtual_facts()
    # The dictionary returned by get_virtual_facts should contain
    # following keys:
    #   'virtualization_type'
    #   'virtualization_role'
    #   'virtualization_tech_guest'
    #   'virtualization_tech_host'

# Generated at 2022-06-20 20:51:13.932937
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mySunOSVirtual = SunOSVirtual(None)
    assert mySunOSVirtual.facts['virtualization_type'] == 'Unknown'

# Generated at 2022-06-20 20:51:17.152071
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj._fact_class().platform == 'SunOS'

# Generated at 2022-06-20 20:52:13.815389
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.side_effect = [
        (0, 'global', ''),
        (0, 'VMware', ''),
        (0, 'VirtualBox', ''),
        (0, '', ''),  # make sure non-zero returncode is handled
        (0, '', ''),  # make sure non-zero returncode is handled
    ]

    test_collector = SunOSVirtual(module)

    virtual_facts = test_collector.get_virtual_facts()

    assert len(virtual_facts) == 5
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:52:21.147548
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test SunOSVirtual Collector class.
    """

    # Arrange
    SunOSVirtual.module = AnsibleModule(argument_spec=dict())

    # Action
    sunos_virtual = SunOSVirtual()

    # Assert
    assert sunos_virtual is not None
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:52:29.509022
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-20 20:52:33.447201
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert (virtual_collector.platform == 'SunOS' and virtual_collector.fact_class == SunOSVirtual)


# Generated at 2022-06-20 20:52:39.782674
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of SunOSVirtual and call the method get_virtual_facts
    vmobj = SunOSVirtual()
    virtual_facts = vmobj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])

# Generated at 2022-06-20 20:52:40.959432
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:52:42.366748
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert type(obj) == SunOSVirtualCollector


# Generated at 2022-06-20 20:52:52.951232
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Create an instance of SunOSVirtual
    virtual = SunOSVirtual(module=module)

    # Test with empty data (assuming not virtualized)
    rc, out, err = module.run_command("/usr/sbin/virtinfo -p")
    if rc == 0:
        virtual.out = out
        virtual.err = err
        virtual.rc = rc
        assert virtual.get_virtual_facts() == {}
    else:
        rc, out, err = module.run_command("/usr/sbin/smbios")
        if rc == 0:
            virtual.out = out
            virtual.err = err
            virtual.rc = rc
            assert virtual.get_virtual_facts() == {}

    # Test virtualization_type output

# Generated at 2022-06-20 20:52:59.689338
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    sunosvirtual = SunOSVirtual(module)

    # We mock the methods of class Virtual
    def get_bin_path(self, name, opt_dirs=[]):
        if name == 'zonename':
            return '/usr/bin/zonename'
        elif name == 'virtinfo':
            return '/usr/sbin/virtinfo'

    module.run_command = run_command_mock('d0cc9f839e3b4f4eb17bbce6d2daab09')
    sunosvirtual.module.get_bin_path = get_bin_path

    # Call method get_virtual_facts of class SunOSVirtual
    virtual_facts = sunosvirtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-20 20:53:04.568206
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.data['virtualization_type'] == 'vmware'
    assert virtual.data['virtualization_role'] == 'guest'
    assert virtual.data['container'] == 'zone'
    assert 'vmware' in virtual.data['virtualization_tech_guest']

# Generated at 2022-06-20 20:54:51.278811
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('Module', (object,), {'run_command': lambda x,y: (0, 'solaris', ''),
                                        'get_bin_path': lambda x,y: '/usr/sbin/virtinfo'})()
    collector = SunOSVirtualCollector(module)
    facts = collector.collect()
    assert 'virtual' in facts
    assert 'virtualization_tech_host' in facts['virtual']
    assert 'virtualization_tech_guest' in facts['virtual']
    assert 'virtualization_role' in facts['virtual']
    assert 'virtualization_type' in facts['virtual']
    assert 'container' in facts['virtual']

    assert 'ldom' in facts['virtual']['virtualization_tech_guest']

# Generated at 2022-06-20 20:54:54.095546
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual({})
    assert facts.platform == "SunOS"

# Generated at 2022-06-20 20:54:56.934022
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'


# Generated at 2022-06-20 20:55:04.187427
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class Module(object):
        def __init__(self, name, path, rc, out, err):
            self.name = name
            self.rc = rc
            self.out = out
            self.err = err
            self.path = path

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if self.name == name:
                return self.path
            return None

        def run_command(self, args):
            return self.rc, self.out, self.err

    class FakeVirtual(SunOSVirtual):
        def __init__(self, facts):
            self.facts = facts
            self.module = None

        def get_file_content(self, path):
            return self.facts.get(path, '')

    # Test case 1:
    #

# Generated at 2022-06-20 20:55:10.695005
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    This test creates an instance of class SunOSVirtual and returns it
    """
    module_args = {}
    module = FakeAnsibleModule(**{'params': module_args})
    facts = SunOSVirtual(module, "test_operating_system")
    assert isinstance(facts, SunOSVirtual)



# Generated at 2022-06-20 20:55:11.994794
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector("FakeModule")
    assert vc is not None


# Generated at 2022-06-20 20:55:25.720061
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    this_module = AnsibleModule(argument_spec={})

    this_module.run_command = MagicMock(return_value=(0, 'solaris\n', ''))
    this_virtual = SunOSVirtual(this_module)

    this_virtual.module.run_command = MagicMock(return_value=(0, '', ''))
    assert this_virtual.get_virtual_facts() == {'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None, 'container': 'zone'}

    this_virtual.module.run_command = MagicMock(return_value=(0, 'global\n', ''))

# Generated at 2022-06-20 20:55:30.569521
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    try:
        virtual_collector = SunOSVirtualCollector()
        assert virtual_collector
        assert virtual_collector._platform == 'SunOS'
        assert virtual_collector._fact_class == SunOSVirtual
    except:
        assert False

# Generated at 2022-06-20 20:55:36.908438
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # When
    sunos_virtual_collector = SunOSVirtualCollector()

    # Then
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._virtfacts == 'virtual'

# Generated at 2022-06-20 20:55:46.239086
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a MockModule object
    module = MockModule()

    # Instantiate the SunOSVirtual class
    inst_class = SunOSVirtual(module)

    # Get the facts from SunOSVirtual.get_virtual_facts()
    facts = inst_class.get_virtual_facts()

    # Assert that it returns the correct facts
    assert facts == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
        'container': 'lxc'
    }
