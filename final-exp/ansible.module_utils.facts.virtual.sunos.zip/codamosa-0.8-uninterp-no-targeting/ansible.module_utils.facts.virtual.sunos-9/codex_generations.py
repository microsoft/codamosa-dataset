

# Generated at 2022-06-20 20:48:24.770896
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual_facts = SunOSVirtual(module)
    virtual_facts.get_virtual_facts()
    assert module.params['gather_subset'] == ['!all', 'hardware', 'virtual']


# Generated at 2022-06-20 20:48:37.830770
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import os

    mock_module = type('TestAnsibleModule', (object,), {'get_bin_path': lambda *args: None, 'run_command': lambda *args: (1, '', '')})()
    vm = SunOSVirtual(mock_module)

    facts = vm.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'container' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_tech_host' not in facts

    os.environ['ANSIBLE_UNIT_TEST_VIRTUAL_TYPE'] = 'zone'

# Generated at 2022-06-20 20:48:43.013675
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    results = {
        'virtualization_tech_guest': set(['zone']),
        'container': 'zone'
    }
    SunOSVirtualModule = type('SunOSVirtualModule', (object,),
                            {'get_bin_path': lambda x,y: '/usr/bin/zonename',
                             'run_command': lambda x,y: (0, 'global', '')})
    assert SunOSVirtual(SunOSVirtualModule()).get_virtual_facts() == results

    results = {
        'virtualization_tech_guest': set(['zone', 'vmware', 'virtualbox']),
        'container': 'zone',
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest'
    }

# Generated at 2022-06-20 20:48:45.997153
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts._platform == 'SunOS'


# Generated at 2022-06-20 20:48:54.691594
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] in ['xen', 'kvm', 'parallels', 'vmware', 'virtualbox', 'virtuozzo', 'zone', '']
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] in ['guest', 'host', '']
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'container' in facts
    assert facts['container'] in ['zone', '']


# Generated at 2022-06-20 20:48:57.094800
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class is SunOSVirtual

# Generated at 2022-06-20 20:49:08.810988
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtualCollector

    mock_module = Mock()
    mock_module.get_bin_path = Mock()
    mock_module.run_command = Mock()

    mock_module.get_bin_path.return_value = '/usr/bin/zonename'
    mock_module.run_command.return_value = (0, '', '')

    vm = SunOSVirtualCollector(mock_module).collect()['ansible_facts']['ansible_virtualization_type']

    mock_module.run_command.assert_called_once_with('/usr/bin/zonename')
    assert vm == 'zone'

# Generated at 2022-06-20 20:49:16.555909
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class ModuleStub(object):
        def __init__(self):
            self.params = {'gather_subset': [], 'gather_timeout': 10, 'filter': '*'}
            self.fail_json = lambda **kwargs: exit(-1)
            self.run_command = lambda cmd, **kwargs: (0, '', '')

        def get_bin_path(self, cmd, required=True):
            if cmd == 'zonename':
                return '/bin/zonename'
            if cmd == 'virtinfo':
                return '/usr/sbin/virtinfo'
            return ''

    class AnsibleModuleStub(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: exit(-1)

# Generated at 2022-06-20 20:49:27.503003
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    virtual_facts = SunOSVirtual()
    #
    # test variable 'platform'
    #
    assert virtual_facts.platform == 'SunOS'
    #
    # test function 'get_virtual_facts'
    #
    virtual_facts.module.run_command = run_command
    virtual_facts.module.get_bin_path = get_bin_path
    #
    # test case 1: check if it's a zone
    #
    virtual_facts.cache = {}
    virtual_facts.cache_paths = []
    actual_result = virtual_facts.get_virtual_facts()

# Generated at 2022-06-20 20:49:29.695668
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_SunOSVirtualCollector = SunOSVirtualCollector()
    my_SunOSVirtualCollector.collect()
    assert True

# Generated at 2022-06-20 20:49:43.206866
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:45.070431
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts
    assert virtual_facts.os_name == 'SunOS'

# Generated at 2022-06-20 20:49:46.884550
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-20 20:49:53.553379
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.utils import AnsibleModuleMock
    from ansible.module_utils.facts.virtual.virt_what.virt_what import VirtWhat, VirtWhatError

    # Create mock class
    class ModuleMock(AnsibleModuleMock):
        # Define properties
        _ansible_module_name = 'test'
        _ansible_version = '2.1.1.0'


# Generated at 2022-06-20 20:49:55.421957
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:07.780600
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a dummy module to work with
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.check_mode = False
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Create an instance of the SunOSVirtual class with the module as argument
    my_SunOSVirtual_obj = SunOSVirtual(module)

    my_SunOSVirtual_obj.get_virtual_facts()

    module.exit_json.assert_called_with(
        changed=False,
        ansible_facts={
        'virtualization_tech_host': {'zone'},
        'virtualization_tech_guest': {},
        }
    )



# Generated at 2022-06-20 20:50:10.716083
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Constructor test
    module_args = dict()
    obj = SunOSVirtual(module_args, {})
    assert obj.platform == 'SunOS'
    assert obj.module == module_args
    assert obj.facts == {}

# Generated at 2022-06-20 20:50:12.485683
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector(None)
    assert isinstance(vc, SunOSVirtualCollector)

# Generated at 2022-06-20 20:50:20.695052
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtual

    fake_module = FakeModule({})
    sunos = SunOSVirtual(fake_module)

    # Check that facts are well returned by method get_virtual_facts when smbios
    # command is available and its output contains the string 'VMware'
    def fake_run_command(cmd, tmp_path, _daemonize):
        assert (cmd == 'smbios')

        return 0, 'VMware', ''

    fake_module.run_command = fake_run_command
    fake_module.get_bin_path = lambda cmd: '/usr/bin/%s' % cmd

    virtual_facts = sunos.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-20 20:50:24.132794
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_all_virtual_facts() == {}



# Generated at 2022-06-20 20:51:01.994874
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    class TestModule:
        @staticmethod
        def run_command(command):
            if command == "zonename":
                return (0, "global", None)
            elif command == "modinfo":
                return (0, "e1000g   9082  84  VMWare Net VirtualNIC Ethernet Driver", None)
            elif command == "virtinfo -p":
                return (0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", None)
            else:
                return (1, None, None)

        @staticmethod
        def get_bin_path(path):
            if path == "zonename":
                return "/usr/bin/zonename"
            elif path == "virtinfo":
                return "/usr/bin/virtinfo"
            el

# Generated at 2022-06-20 20:51:04.417549
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())
    assert sunos_virtual.platform == "SunOS"


# Generated at 2022-06-20 20:51:07.426449
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    fc = SunOSVirtual(module)
    assert fc.platform == 'SunOS'
    assert fc.module == module
    assert fc._virtual_facts is None


# Generated at 2022-06-20 20:51:19.624389
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        """ Fake class for module testing """
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd):
            """ Fake method for testing """
            cmd = to_bytes(cmd)
            self.run_command_calls.append(cmd)
            if cmd == '/bin/zonename':
                return 0, 'global\n', ''
            elif cmd == '/usr/sbin/virtinfo -p':
                return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=true\nSOMETHING|key=value\n',

# Generated at 2022-06-20 20:51:26.976049
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Run get_virtual_facts for a virtual machine
    module_mock = MockModule({
        "smbios" : "smbios",
        "run_command.return_value" : (0, 'HVM domU', ''),
    })
    virtual_facts = SunOSVirtual(module_mock).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()
    assert 'container' not in virtual_facts

# Generated at 2022-06-20 20:51:39.394518
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Testing with a VMware guest on Solaris 11
    module = FakeModule()
    v = SunOSVirtual(module)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert 'container' not in facts
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'vmware'}

    # Testing with a global zone of a Solaris 10 branded zone
    module = FakeModule({'zonename': (0, "global\n", '')})
    v = SunOSVirtual(module)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'

# Generated at 2022-06-20 20:51:42.281902
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._fact_class == SunOSVirtual
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:51:44.945985
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Test method for constructor of class SunOSVirtual
    '''
    module = None
    SunOSVirtualCollector(module)

# Generated at 2022-06-20 20:51:46.680983
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Testing if the class can be instanciated
    assert SunOSVirtual(dict())

# Generated at 2022-06-20 20:51:54.806813
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a fake module
    from ansible.module_utils.facts.virtual import SunOSVirtual
    def get_bin_path(name): return name
    def run_command(name):
        if name == 'zonename':
            return (0, "global", "")
        elif name == 'modinfo':
            return (0, "", "")
    module = type('FakeModule', (object,), {'get_bin_path': get_bin_path, 'run_command': run_command, 'params': {}})
    # Create a fake class
    virtual = SunOSVirtual(module)
    # Run method get_virtual_facts
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'zone'

# Generated at 2022-06-20 20:52:46.077940
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virtual_facts = SunOSVirtual(module)
    assert virtual_facts.platform == 'SunOS'

# Unit test of SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:52:50.285414
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('', (), {})()
    module.run_command = lambda x, check_rc=True: (0, '', '')
    module.get_bin_path = lambda x: None
    sunos = SunOSVirtual(module)
    result = sunos.get_virtual_facts()
    assert result is None

# Generated at 2022-06-20 20:52:52.232195
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    m = SunOSVirtualCollector()
    assert m.platform == 'SunOS'
    assert m._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:52:53.444791
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-20 20:52:56.114190
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:53:01.356284
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(None)
    assert not hasattr(virtual_facts, 'data')



# Generated at 2022-06-20 20:53:09.264965
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    test_module = SunOSVirtual(module=None)

    # an empty output for modinfo and zonename
    test_module.module.run_command = MagicMock(return_value=(0, '', ''))
    virtual_facts = test_module.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'

    # ldom guest

# Generated at 2022-06-20 20:53:20.255483
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    module.run_command = Mock(return_value=(0, '', ''))
    os.path.isdir = Mock(return_value='False')

    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.module == module
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.smbios is not None
    assert sunos_virtual.virtinfo is not None
    assert sunos_virtual.zonestat is not None
    assert sunos_virtual.zonename is not None
    assert sunos_virtual.zonename_exec is not None
    assert sunos_virtual.zoneadm is not None
    # Should return False for all other methods for now because
    # the mocks are not configured.

# Generated at 2022-06-20 20:53:32.117789
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This is a unit test for method get_virtual_facts of class Virtual
    """
    import mock
    import sys

    # Import this module so the module under test can be imported
    sys.modules["ansible.module_utils.facts.virtual.sunos"] = sys.modules[__name__]

    module = mock.MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/usr/bin/zonename'

    sunos_virtual = SunOSVirtual(module)
    result = sunos_virtual.get_virtual_facts()

    assert result['virtualization_type'] == 'zone'
    assert result['virtualization_role'] == 'guest'
    assert result['container'] == 'zone'



# Generated at 2022-06-20 20:53:45.879043
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyModule()
    module.run_command = Mock(return_value=(0, '', ''))
    sunos_virtual = SunOSVirtual(module=module)

    # zonename not available
    zonename_not_available = SunOSVirtual(module=module)
    zonename_not_available.module.run_command = Mock(side_effect=OSError)
    sunos_virtual_facts = zonename_not_available.get_virtual_facts()
    assert 'virtualization_tech_guest' not in sunos_virtual_facts
    assert 'virtualization_tech_host' not in sunos_virtual_facts
    assert 'virtualization_role' not in sunos_virtual_facts
    assert 'virtualization_type' not in sunos_virtual_facts
    assert 'container' not in sunos

# Generated at 2022-06-20 20:55:39.031595
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    SunOSVirtual(module)
    assert module.run_command.call_count > 0

# Generated at 2022-06-20 20:55:45.919470
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    module.exists.side_effect = [False, False, False, False]

    virtual = SunOSVirtual(module=module)

    expected_facts = {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    facts = virtual.get_virtual_facts()
    for key in expected_facts:
        assert key in facts
        assert facts[key] == expected_facts[key]


# Generated at 2022-06-20 20:55:56.605644
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual.module = FakeAnsibleModule()
    # No container and no hypervisor:
    SunOSVirtual.module.run_command = lambda command: (0, '', '')
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert len(virtual_facts) == 0

    # Container without hypervisor:
    SunOSVirtual.module.run_command = lambda command: (0, 'aContainer', '')
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert len(virtual_facts) == 1
    assert 'container' in virtual_facts
    assert virtual_facts['container'] == 'zone'

    # Container and hypervisor (we have only information about the guest)
    SunOSVirtual.module.run_command = lambda command: (0, 'something', '')

# Generated at 2022-06-20 20:56:06.589903
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-20 20:56:13.961835
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # A couple of things are known about SunOSVirtual
    # - it is a subclass of Virtual
    # - it is a instance of SunOSVirtual
    # - it is a instance of Virtual
    # - it is a instance of object
    fact = SunOSVirtual(None)
    assert isinstance(SunOSVirtual, type)
    assert isinstance(fact, SunOSVirtual)
    assert isinstance(fact, Virtual)
    assert isinstance(fact, object)
    # - that it has the right platform
    assert fact.platform == 'SunOS'

# Generated at 2022-06-20 20:56:15.531029
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:56:19.549678
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test the constructor of the SunOSVirtualCollector class"""

    SunOSVirtualCollector()


# Generated at 2022-06-20 20:56:24.297913
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual_facts = SunOSVirtualCollector().collect()
    assert('virtualization_type' in sunos_virtual_facts)
    assert('virtualization_role' in sunos_virtual_facts)
    assert('container' in sunos_virtual_facts)
    assert('virtualization_tech_guest' in sunos_virtual_facts)
    assert('virtualization_tech_host' in sunos_virtual_facts)

# Generated at 2022-06-20 20:56:27.514763
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == "SunOS"

# Generated at 2022-06-20 20:56:29.365637
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = object()
    SunOSVirtualCollector(module)