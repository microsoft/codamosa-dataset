

# Generated at 2022-06-20 20:48:21.031677
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos = SunOSVirtualCollector()
    assert sunos.platform == "SunOS"

# Generated at 2022-06-20 20:48:26.100490
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert(virtual_facts['virtualization_tech_host'] == set(['zone']))
    assert('virtualization_tech_guest' not in virtual_facts)
    assert('virtualization_role' not in virtual_facts)


# Generated at 2022-06-20 20:48:28.584738
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:48:34.895249
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = dict(virtual_facts=dict())
    virtual_facts = dict(virtualization_type=None, virtualization_role=None,
                         virtualization_tech_guest=None, virtualization_tech_host=None,
                         container=None)
    VirtualCollector._test_virtual_collector(SunOSVirtualCollector, virtual_facts, os_facts)

# Generated at 2022-06-20 20:48:37.308553
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class._platform == 'SunOS'

# Generated at 2022-06-20 20:48:43.870305
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(side_effect=run_command_mock)
    module.get_bin_path = Mock(return_value='/opt/bin/sbin/modinfo')

    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:48:52.573051
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sc = SunOSVirtual({})
    facts = sc.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['container'] == 'zone'
    assert set(facts.keys()) == set(['virtualization_role', 'virtualization_type', 'virtualization_tech_host', 'virtualization_tech_guest', 'container'])

# Generated at 2022-06-20 20:48:55.221612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._fact_class is not None
    assert facts._platform == 'SunOS'

# Generated at 2022-06-20 20:49:06.899233
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockLinuxModule()
    sunos_virtual = SunOSVirtual(module)

    # Test simple case: global zone
    module.run_command = Mock(return_value=(0, "global", ""))
    facts = sunos_virtual.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert 'container' not in facts

    # Test simple case: guest zone
    module.run_command = Mock(return_value=(0, "zone1", ""))
    facts = sunos_virtual.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role'

# Generated at 2022-06-20 20:49:09.055294
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert isinstance(SunOSVirtual(), SunOSVirtual)


# Generated at 2022-06-20 20:49:29.848001
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    # Call the constructor for the posix virtual fact collector
    fact_collector = SunOSVirtualCollector(basic.AnsibleModule(
    ))
    # assert that the collector is the correct class
    assert isinstance(fact_collector, collector.VirtualCollector)
    # assert that the object is the correct class
    assert isinstance(fact_collector._fact_class(fact_collector._module), SunOSVirtual)
    # assert that the platform is equal to the current platform
    assert fact_collector._platform == SunOSVirtualCollector._platform


# Generated at 2022-06-20 20:49:38.049919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    if os.path.exists('/proc/vz'):
        assert SunOSVirtual() is not None

    virtual = SunOSVirtual(module=FakeModule())

    # default values
    details = virtual.get_details()
    assert details.get('virtualization_type') is None
    assert details.get('virtualization_role') is None
    assert details.get('container') is None
    assert details.get('virtualization_tech') is None
    assert details.get('virtualization_tech_host') is None
    assert details.get('virtualization_tech_guest') is None


# Generated at 2022-06-20 20:49:44.073244
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunosvirtualcollector = SunOSVirtualCollector()
    assert sunosvirtualcollector._platform == 'SunOS'
    assert sunosvirtualcollector._fact_class.platform == 'SunOS'



# Generated at 2022-06-20 20:49:46.297161
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:48.916685
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor for class SunOSVirtualCollector
    :return:
    """
    # Check if the class name has been defined correctly
    assert SunOSVirtualCollector.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-20 20:49:52.924764
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Pass in an empty argument list
    r = SunOSVirtual({})
    assert isinstance(r, SunOSVirtual)


# Generated at 2022-06-20 20:50:03.851418
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    facts = {}
    module = FakeAnsibleModule(facts)
    module.exit_json = exit_json
    module.fail_json = fail_json
    setattr(module, 'run_command', run_command)

    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    # Check the virtual facts
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'domU' in virtual_facts['virtualization_tech_guest']
    assert not 'virtualbox' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-20 20:50:14.691456
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    # result for Solaris 11.4 on SPARC T4-4
    assert 'virtualization_role' in virtual_facts.get_virtual_facts()
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == 'guest'
    assert 'virtualization_type' in virtual_facts.get_virtual_facts()
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == 'ldom'
    assert 'container' in virtual_facts.get_virtual_facts()
    assert virtual_facts.get_virtual_facts()['container'] == 'zone'
    assert 'virtualization_tech_guest' in virtual_facts.get_virtual_facts()

# Generated at 2022-06-20 20:50:16.238054
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    o = SunOSVirtual(dict())
    assert o.platform == 'SunOS'


# Generated at 2022-06-20 20:50:18.682460
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    pc = SunOSVirtualCollector()
    assert pc.platform == 'SunOS'
    assert pc._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:44.314736
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:50:45.762816
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''SunOSVirtualCollector()'''
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:50:52.141189
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt_class = SunOSVirtual(None)
    assert virt_class.platform == 'SunOS'
    assert virt_class.virtualization_role == None
    assert virt_class.virtualization_type == None
    assert virt_class.container == None
    assert virt_class.virtualization_tech_guest == None
    assert virt_class.virtualization_tech_host == None

# Generated at 2022-06-20 20:50:53.727190
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual.platform == 'SunOS'
    virtual = SunOSVirtual()

# Generated at 2022-06-20 20:50:55.985068
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector


# Generated at 2022-06-20 20:50:59.774214
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Check SunOSVirtual
    # Set up class
    obj = SunOSVirtual()
    # Check if it is Virtual class
    assert(isinstance(obj, Virtual))

# Generated at 2022-06-20 20:51:03.593699
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector().collect()
    assert 'virtualization_tech_guest' in facts


if __name__ == '__main__':
    # Unit test
    test_SunOSVirtualCollector()

# Generated at 2022-06-20 20:51:05.678594
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt
    assert virt.get_virtual_facts()

# Generated at 2022-06-20 20:51:08.382242
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = 'ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector'
    obj = SunOSVirtualCollector(module=module)
    assert obj._fact_class == SunOSVirtual
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 20:51:09.820503
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert SunOSVirtual().get_virtual_facts() == {}

# Generated at 2022-06-20 20:51:46.562271
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Function to test the get_virtual_facts method of class SunOSVirtual
    """

    def _run_command(module, cmd, check_rc=True):
        return (0, "", "")

    def _get_bin_path(module, name):
        return name

    # Generate a class and instantiate an instance of this class
    class MyModule(object):
        def __init__(self, check_rc=True):
            self.run_command = _run_command
            self.get_bin_path = _get_bin_path
            self.params = {}

    my_module = MyModule()

    test_virtual = SunOSVirtual(my_module)

    # Call the get_virtual_facts method
    test_virtual.get_virtual_facts()

# Unit test to verify the virtualization_type

# Generated at 2022-06-20 20:51:54.712753
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual

    # We need to mock the module_utils functions we will use to gather the
    # data
    from ansible.module_utils.facts import virtual

    import ansible.module_utils.facts.virtual.solaris as solaris

    old_run_command = solaris.run_command
    old_get_bin_path = solaris.get_bin_path


# Generated at 2022-06-20 20:51:55.507583
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # This is a stub to prevent errors when testing with nosetests
    return

# Generated at 2022-06-20 20:52:00.636480
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class ModuleMock:
        def get_bin_path(self, executable):
            return executable

        def run_command(self, executable):
            returncode = 0
            if executable == 'smbios':
                return (returncode, "VMware", "")
            elif executable == 'zonename':
                return (returncode, "zone", "")
            elif executable == 'virtinfo -p':
                return (returncode, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", "")
            elif executable == 'modinfo':
                return (returncode, "", "")
            return (returncode, "", "")


    module = ModuleMock()
    facts = SunOSVirtual().get_virtual_facts(module=module)

# Generated at 2022-06-20 20:52:11.657031
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    facts_under_test = SunOSVirtual(module)

    # Populate facts_under_test.facts
    facts_under_test.facts = {'distribution': 'SunOS'}
    # Populate facts_under_test.module
    facts_under_test.module = module
    # Populate module.run_command return values
    module.run_command_values["zonename"] = (0, "global\n", "")

    module.run_command_values["modinfo"] = (0, "", "")

    module.run_command_values["virtinfo -p"] = (0, "", "")
    module.run_command_values["virtinfo -a"] = (0, "", "")
    rc, out, err = module.run_command("virtinfo -p")
   

# Generated at 2022-06-20 20:52:13.492471
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fc = SunOSVirtualCollector()
    assert fc.fact_class is SunOSVirtual
    assert fc.platform == 'SunOS'

# Generated at 2022-06-20 20:52:16.826211
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = None
    SunOSVirtualCollector(module)

# Generated at 2022-06-20 20:52:18.939760
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.__class__.__name__ == 'SunOSVirtualCollector'


# Generated at 2022-06-20 20:52:29.085647
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule({})
    fact_class_obj = SunOSVirtual(module)
    virtual_facts = fact_class_obj.get_virtual_facts()
    assert virtual_facts == {}
    module = FakeModule({'zonename': '/bin/zonename'})
    fact_class_obj = SunOSVirtual(module)
    virtual_facts = fact_class_obj.get_virtual_facts()
    assert virtual_facts == {'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set()}
    module = FakeModule({'zonename': '/bin/zonename', '_ansible_zone': 'global'})
    fact_class_obj = SunOSVirtual(module)
    virtual_facts = fact_class_obj.get_virtual_facts()

# Generated at 2022-06-20 20:52:33.600044
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    _fact_class = SunOSVirtual
    _platform = 'SunOS'
    collector = SunOSVirtualCollector()
    assert collector.platform == _platform
    assert collector._fact_class == _fact_class



# Generated at 2022-06-20 20:53:29.587993
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """This func exists just for py.test to recognize it as test.
       The test is all in VirtualCollector.test_VirtualCollector()
    """
    pass

# Generated at 2022-06-20 20:53:44.985973
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def mocked_module_run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        cmdlist = command.split(' ')

# Generated at 2022-06-20 20:53:48.006522
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:54:03.255398
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Create an instance of the SunOSVirtual class
    test_SunOSVirtual = SunOSVirtual()

    # Set some values for the module object
    test_SunOSVirtual.module = type('AnsibleModule', (object,), {})
    test_SunOSVirtual.module.get_bin_path = lambda x: '/usr/bin/{0}'.format(x)
    test_SunOSVirtual.module.run_command = lambda x: (0, '', '')

    # Test the get_virtual_facts method, nothing virtualized
    virtual_facts = test_SunOSVirtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Test the get_virtual_facts method, virtualized in zone
   

# Generated at 2022-06-20 20:54:05.445337
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = DummyAnsibleModule()
    virtual_facts_collector = SunOSVirtual(module)
    assert virtual_facts_collector.platform == 'SunOS'


# Generated at 2022-06-20 20:54:06.714593
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:54:12.865362
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Constructor of class VirtualCollector
    module = type('', (), {})
    module.debug = False
    virtual_collector = SunOSVirtualCollector(module)

    # class Virtual
    assert isinstance(virtual_collector.virtual, SunOSVirtual)
    assert virtual_collector.virtual._module == module

# Generated at 2022-06-20 20:54:14.315480
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj



# Generated at 2022-06-20 20:54:16.323151
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual._platform == 'SunOS'

# Generated at 2022-06-20 20:54:29.305077
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virt_inst = SunOSVirtual(module=module)

    assert(virt_inst.get_virtual_facts() == {'virtualization_type': 'vmware',
                                             'virtualization_role': 'guest',
                                             'container': 'zone',
                                             'virtualization_tech_guest': set(['zone', 'vmware']),
                                             'virtualization_tech_host': set(['zone'])})

# Generated at 2022-06-20 20:56:41.400273
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({})
    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:56:46.217193
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    # Constructor for class SunOSVirtualCollector
    obj = SunOSVirtualCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual
    assert obj._collectors == {}


# Generated at 2022-06-20 20:56:56.794335
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({}, {}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] in (None, 'vmware', 'virtualbox', 'vmware', 'parallels', 'xen', 'kvm', 'virtuozzo', 'ldom')
    assert virtual_facts['virtualization_role'] in (None, 'guest', 'host (control,io,service,root)')
    assert virtual_facts['virtualization_role'] in (None, 'guest', 'host')
    assert virtual_facts['container'] in (None, 'zone')

# Generated at 2022-06-20 20:57:02.118581
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Create an instance of the class SunOSVirtual to test the constructor.
    '''
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'
    assert SunOSVirtual.platform == 'SunOS'
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:57:03.529650
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual()
    assert s.platform == 'SunOS'


# Generated at 2022-06-20 20:57:07.441000
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    virtual_obj = SunOSVirtual(module)
    assert virtual_obj.virtualization_type is None
    assert virtual_obj.virtualization_role is None
    assert virtual_obj.container is None
    assert virtual_obj.platform == "SunOS"

# Generated at 2022-06-20 20:57:09.541306
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual



# Generated at 2022-06-20 20:57:24.210792
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class ModuleMock(object):
        def run_command(self, cmd):
            return 0, "", ""
        def get_bin_path(self, cmd, opts=None):
            if cmd == 'zonename':
                return '/sbin/zonename'
            elif cmd == 'modinfo':
                return '/sbin/modinfo'
            elif cmd == 'virtinfo':
                return '/usr/sbin/virtinfo'
            elif cmd == 'smbios':
                return '/usr/sbin/smbios'
            return None

    class FacterMock(object):
        def __init__(self, module):
            self.module = module
        def fact(self, fact):
            return "whatever"

    module = ModuleMock()
    facter = FacterMock(module)
   

# Generated at 2022-06-20 20:57:29.387991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({'module_setup': True})

    v.module.run_command = _run_command
    v.get_virtual_facts()



# Generated at 2022-06-20 20:57:33.800960
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Generate test data
    data = {}
    def mock_run_command(module, command):
        # Simulate virtualbox zonename returncode
        if command == 'zonename':
            rc, out, err = 0, 'zone_name', ''

        # Simulate vmware zonename returncode
        elif command == '/usr/sbin/virtinfo -p':
            rc, out, err = 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''
        elif command == 'smbios':
            rc, out, err = 0, 'VirtualBox', ''
        return rc, out, err

    # Init the object
    obj = SunOSVirtual()