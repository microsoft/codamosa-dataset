

# Generated at 2022-06-20 20:48:22.462990
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    os_facts = {}
    os_facts['kernel'] = "SunOS"

    virtual_facts = SunOSVirtual(os_facts)
    assert isinstance(virtual_facts, SunOSVirtual)


# Generated at 2022-06-20 20:48:24.770944
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    s = SunOSVirtualCollector()
    assert s._platform == 'SunOS'

# Generated at 2022-06-20 20:48:26.488099
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    if SunOSVirtual is not None:
        collector = SunOSVirtualCollector()
        assert isinstance(collector, SunOSVirtualCollector)

# Generated at 2022-06-20 20:48:29.804513
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:48:36.887911
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()

    module.run_command = run_command

    # Below test is based on the output of command /usr/sbin/virtinfo
    # -p on an OpenSolaris platform
    v = SunOSVirtual(module)
    f = v.get_virtual_facts()

    assert 'virtualization_type' in f
    assert 'virtualization_role' in f
    assert 'virtualization_tech_guest' in f
    assert 'virtualization_tech_host' in f
    assert 'container' not in f

    assert f['virtualization_type'] == 'ldom'
    assert f['virtualization_role'] == 'host (control,io,service)'
    assert f['virtualization_tech_host'] == set(['ldom'])
    assert f['virtualization_tech_guest'] == set

# Generated at 2022-06-20 20:48:45.799221
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (), {})()
    module.run_command = lambda *cmd: (0, "global\n", None)
    module.get_bin_path = lambda *cmd: "/bin/" + cmd[0]
    virtual = SunOSVirtual(module)

    # Checks that we set virtualization_type to zone
    assert virtual.virtualization_type == "zone"

    # Checks that we set virtualization_role to host
    assert virtual.virtualization_role == "host"

    # Checks that we set container to zone
    assert virtual.container == "zone"

# Generated at 2022-06-20 20:48:48.889543
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({'ansible_facts': {}})
    assert str(type(virtual)) == "<class 'ansible.module_utils.facts.virtual.sunos.SunOSVirtual'>"


# Generated at 2022-06-20 20:48:50.378843
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)

# Generated at 2022-06-20 20:48:52.128833
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 20:48:52.965023
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:08.706917
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test that the constructor of SunOSVirtual class works as expected
    """
    vm = SunOSVirtual()
    assert vm.platform == 'SunOS'

# Generated at 2022-06-20 20:49:09.662653
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:12.163244
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    o = SunOSVirtual([])
    assert o is not None
    assert o.platform == 'SunOS'
    assert o.get_virtual_facts() is not None

# Generated at 2022-06-20 20:49:25.088584
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts import FactCollector

    modules_path = os.path.join(os.path.dirname(__file__), '../../../../')
    stdout = [
      'VMware, Inc. VMware Virtual Platform, Xeon',
      'Parallels Software International Inc. Parallels Virtual Platform',
      'Oracle Corporation Sun Microsystems VirtualBox',
      'global',
      'global',
      'Xen (HVM domU)',
      'KVM']

    module = FactCollector('SunOS', modules_path)
    setattr(module, 'run_command', lambda *args, **kwargs: (0, '\n'.join(stdout), ''))
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/bin/' + args[0])

# Generated at 2022-06-20 20:49:28.169901
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts_collector = SunOSVirtualCollector()
    assert facts_collector._fact_class == SunOSVirtual
    assert facts_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:49:32.014075
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Returns 'SunOSVirtualCollector' object
    """
    svc = SunOSVirtualCollector()
    assert svc.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-20 20:49:33.788803
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos = SunOSVirtual()
    assert sunos.platform == 'SunOS'

# Generated at 2022-06-20 20:49:36.270169
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:49:40.321968
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    modules_mock = {
        'platform': 'SunOS',
        'get_bin_path': lambda x, *args, **kwargs: '/sbin/' + x
    }
    module_mock = type('module', (object,), modules_mock)()

    module = module_mock

    sunos_virtual = SunOSVirtual(module)
    assert isinstance(sunos_virtual, SunOSVirtual)

# Generated at 2022-06-20 20:49:46.140356
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('', (object,), dict(run_command=lambda x: ('', '', '')))
    module.get_bin_path = lambda x: x
    facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'container' in facts

# Generated at 2022-06-20 20:50:01.589178
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual({}, {})

    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:50:03.041740
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual()
    assert virt._platform == 'SunOS'

# Generated at 2022-06-20 20:50:07.015727
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.fact_class == SunOSVirtual


# Generated at 2022-06-20 20:50:08.651968
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:17.701542
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import Virtual
    import os
    import shutil
    import tempfile

    # Store current working directory and change to a system with a zone named zone1
    tmp_path = tempfile.mkdtemp()
    tmp_path_system = tmp_path + '/' + "test"
    os.makedirs(tmp_path_system)
    os.chdir(tmp_path_system)

    # Create file tree in tmp_path
    os.makedirs('/proc/vz')
    os.makedirs('/.SUNWnative/usr/sbin')
    os.makedirs('/usr/sbin')

# Generated at 2022-06-20 20:50:23.330712
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Sample virtualization_tech_host output: set(['zone'])
    # Sample virtualization_tech_guest output: set(['zone'])
    # Sample container output: 'zone'
    # Sample virtualization_type output: 'vmware'
    # Sample virtualization_role output: 'guest'
    facts = dict(
        virtualization_tech_guest=set(['zone']),
        virtualization_tech_host=set(['zone']),
        container='zone',
        virtualization_type='vmware',
        virtualization_role='guest')
    assert isinstance(SunOSVirtualCollector(None).collect(facts), SunOSVirtual)

# Generated at 2022-06-20 20:50:33.893285
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Mock the method get_bin_path
    def get_bin_path(bin_name):
        if bin_name == 'zonename':
            return '/usr/bin/zonename'
        elif bin_name == 'modinfo':
            return '/usr/sbin/modinfo'
        elif bin_name == 'smbios':
            return '/usr/sbin/smbios'
        elif bin_name == 'virtinfo':
            return '/usr/sbin/virtinfo'
        else:
            return None

    module.get_bin_path = get_bin_path

    # Mock the method run_command

# Generated at 2022-06-20 20:50:45.553760
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    import os
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=False
    )


# Generated at 2022-06-20 20:50:47.767663
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-20 20:50:49.789975
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    try:
        assert obj.__class__.__name__ == 'SunOSVirtualCollector'
        assert obj._platform == 'SunOS'
    except:
        'Test Failed'


# Generated at 2022-06-20 20:51:08.125188
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    mock_module = patch.object(SunOSVirtualCollector, '_platform', 'SunOS')
    assert mock_module is not None

# Generated at 2022-06-20 20:51:13.205073
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_collector = SunOSVirtualCollector()
    assert sunos_collector._platform == 'SunOS'
    assert sunos_collector._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:51:16.911138
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    m = FakeModule()
    v = SunOSVirtual(m)
    assert v.get_virtual_facts()['virtualization_role'] == 'guest'
    assert v.get_virtual_facts()['container'] == 'zone'

# Generated at 2022-06-20 20:51:20.591310
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector()
    assert virtual_facts.platform == "SunOS"
    assert virtual_facts._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:51:29.597917
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = ""
    virt = SunOSVirtual(module)
    rc = 0
    out = 'SunOS Release 10 Version Generic_147147-26 2015/08/03\n'
    err = ''
    virt.module.run_command = lambda x: (rc, out, err)

    rc = 1
    out = ''
    err = ''
    virt.module.get_bin_path = lambda x: '/bin/' + x
    virt.module.run_command = lambda x: (rc, out, err)
    assert {} == virt.get_virtual_facts()

    rc = 0
    out = 'global'
    err = ''
    virt.module.run_command = lambda x: (rc, out, err)

# Generated at 2022-06-20 20:51:34.758473
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    facter = SunOSVirtualCollector(module)
    assert facter.module == module
    assert facter.platform == 'SunOS'
    assert isinstance(facter._fact_class(module), SunOSVirtual)



# Generated at 2022-06-20 20:51:46.479478
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of SunOSVirtual.
    """
    from ansible.module_utils.facts.collector.cloud.sunos import SunOSCloud
    from ansible.module_utils.facts.collector.system.sunos import SunOSSystem
    from ansible.module_utils.facts.collector import VirtualCollector, CloudCollector, SystemCollector

    # Setup
    module = FakeAnsibleModule(
        params={
            'gather_subset': ['all'],
            'filter': '*'
        },
        ansible_facts={
            'ansible_facts': {
                'system': {},
                'virtual': {},
                'cloud': {}
            }
        }
    )

    # Test 1 - AnsibleModule.run_command (called in get_virtual_facts

# Generated at 2022-06-20 20:52:00.415876
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    module_mock = Mock()
    module_mock.run_command.return_value = (0, 'global', '')
    module_mock.get_bin_path.return_value = True
    sunos = SunOSVirtual(module_mock)
    assert sunos.get_virtual_facts() == {
        'container': 'zone',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': {'zone'},
    }
    # Test on a branded zone (i.e. Solaris 8/9 zone)
    sunos.module.run_command.return_value = (0, '', '')
    os.path.exists = Mock(return_value=True)


# Generated at 2022-06-20 20:52:03.124477
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:52:09.933974
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    sunos_virtual_collector = SunOSVirtualCollector(None)
    assert isinstance(sunos_virtual_collector, SunOSVirtualCollector)
    assert isinstance(sunos_virtual_collector._fact_class, SunOSVirtual)
    assert isinstance(sunos_virtual_collector._platform, str)

# Generated at 2022-06-20 20:52:38.165347
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:52:39.606718
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc_test = SunOSVirtualCollector()
    assert vc_test._platform == 'SunOS'



# Generated at 2022-06-20 20:52:41.934087
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:52:45.592864
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:52:48.422941
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(dict(), "fake_path")
    assert v.platform == 'SunOS'
    assert v.get_virtual_facts() == {}



# Generated at 2022-06-20 20:52:55.381382
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual()
    virtual_facts.module = FakeAnsibleModule()
    virtual_facts.module.run_command = MockRunCommand()

    # zonename not installed
    virtual_facts.module.run_command.set_command("which zonename", 1, "")
    virtual_facts.module.run_command.set_command("zonename", 1, "")
    assert virtual_facts.get_virtual_facts() == {}

    # zonename installed, but not a zone
    virtual_facts.module.run_command.set_command("which zonename", 0, "")
    virtual_facts.module.run_command.set_command("zonename", 0, "")
    assert virtual_facts.get_virtual_facts() == {}

    # zonename installed, in a zone
    virtual

# Generated at 2022-06-20 20:53:01.863388
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    x = SunOSVirtual()
    assert x.virtualization_type == 'unknown'
    assert x.virtualization_role == 'unknown'
    assert x.container == 'unknown'

# Generated at 2022-06-20 20:53:02.872527
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Insert your unit test here.
    assert True == True

# Generated at 2022-06-20 20:53:04.688623
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:53:15.481963
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    FakeModule = type('FakeModule', (object,), {})
    FakeModule.get_bin_path = lambda x, y: y

    FakeModule.run_command = lambda x, y: (0, '', '')

    sunos_virtual = SunOSVirtual(FakeModule)
    results = sunos_virtual.get_virtual_facts()
    assert results["virtualization_type"] is None
    assert results["virtualization_role"] is None
    assert results["virtualization_tech_guest"] == set()
    assert results["virtualization_tech_host"] == set()

# Generated at 2022-06-20 20:54:09.540106
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = dict()
    module = dict()
    virtual = SunOSVirtual(module, facts)
    virtual.collect()

# Generated at 2022-06-20 20:54:24.030513
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import sys
    import io
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.join(test_dir, '../../../../plugins/modules'))
    sys.path.insert(0, os.path.join(test_dir, '../../../../plugins/module_utils/basic'))
    sys.path.insert(0, os.path.join(test_dir, '../../../../plugins/module_utils/common'))
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts import BasicModuleUtils


# Generated at 2022-06-20 20:54:25.915983
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.data['virtualization_type'] == 'parallels'

# Generated at 2022-06-20 20:54:27.788258
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert SunOSVirtual.platform == 'SunOS'


# Generated at 2022-06-20 20:54:32.159402
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    module = type('AnsibleModule', (object,), {'run_command': run_command})()

    # Create a instance of SunOSVirtual
    c = SunOSVirtual(module)

    # Check virtualization_type and virtualization_role are correctly set.
    # This is a kvm guest
    assert c.get_virtual_facts()['virtualization_type'] == 'kvm'
    assert c.get_virtual_facts()['virtualization_role'] == 'guest'
    assert c.get_virtual_facts()['virtualization_tech_guest'] == {'kvm'}
    assert c.get_virtual_facts()['virtualization_tech_host'] == set()
    assert c.get_virtual_facts()['container'] is None

    # This is a zone host
    assert c.get_virtual_facts()

# Generated at 2022-06-20 20:54:35.734503
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict(module=None))
    assert virt.get_virtual_facts() == dict()

# Generated at 2022-06-20 20:54:38.279100
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector is not None

# Generated at 2022-06-20 20:54:43.618201
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    assert virtual != None
    assert virtual.virtualization_type == 'kvm'
    assert virtual.virtualization_role == 'guest'
    assert virtual.virtualization_tech_host == None
    assert virtual.virtualization_tech_guest == None


# Generated at 2022-06-20 20:54:44.951002
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:54:48.829546
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule({})
    sut = SunOSVirtual(module)
    assert sut.platform == 'SunOS'
    assert sut.module == module


# Generated at 2022-06-20 20:57:05.683251
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.has_key('virtualization_type') is False
    assert virtual_facts.has_key('virtualization_role') is False
    assert virtual_facts.has_key('virtualization_tech_guest') is False
    assert virtual_facts.has_key('virtualization_tech_host') is False
    assert virtual_facts.has_key('container') is False

# Generated at 2022-06-20 20:57:08.102612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == 'SunOSVirtual'

# Generated at 2022-06-20 20:57:13.439013
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    fake_module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(fake_module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-20 20:57:15.245865
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual = SunOSVirtualCollector()
    assert sunos_virtual._platform == "SunOS"

# Generated at 2022-06-20 20:57:27.027029
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    import os
    import sys
    import unittest

    class ModuleStub:
        def get_bin_path(self, bin):
            return bin

        def run_command(self, bin):
            return 0, '', ''

    virtual_facts = SunOSVirtual(ModuleStub()).get_virtual_facts()

    if 'virtualization_type' in virtual_facts:
        del virtual_facts['virtualization_type']

    if 'virtualization_role' in virtual_facts:
        del virtual_facts['virtualization_role']

    if 'virtualization_tech_guest' in virtual_facts:
        del virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-20 20:57:30.604760
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Test return values of method get_virtual_facts of SunOSVirtual class."""
    facts = SunOSVirtual({})
    assert facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:57:38.285941
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock(return_value='/bin/true')
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.lsmod = MagicMock(return_value={'vboxdrv': 'vboxdrv 16753 12'})

    # test case 1:
    # a) no bins available:
    # b) isdir(/.SUNWnative) == False
    # c) os.path.isdir('/proc/vz') == False
    # d) rc = 0 and output contains the string 'vmware'
    # expected:
    # a) virtualization_type == 'vmware'
    # b) virtualization_role == 'guest'
    # c) virtualization_tech_guest

# Generated at 2022-06-20 20:57:41.240749
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    "Test the constructor of the class SunOSVirtualCollector"
    x = SunOSVirtualCollector()
    assert x


# Generated at 2022-06-20 20:57:44.219733
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._platform == 'SunOS'
    assert v._fact_class == SunOSVirtual



# Generated at 2022-06-20 20:57:47.100003
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual()
    assert SunOSVirtual().platform == 'SunOS'
