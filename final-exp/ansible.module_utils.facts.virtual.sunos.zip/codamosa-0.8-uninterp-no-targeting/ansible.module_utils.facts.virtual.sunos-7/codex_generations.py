

# Generated at 2022-06-20 20:48:23.704656
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # init and read
    if SunOSVirtual().read_facts() is not None:
        assert False # fail test
    # init and read
    if SunOSVirtual().get_virtual_facts() is not None:
        assert False # fail test

# Generated at 2022-06-20 20:48:31.043132
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual(dict()).get_virtual_facts()
    if 'virtualization_type' in virtual_facts:
        if virtual_facts['virtualization_type'] != 'zone' and virtual_facts['virtualization_type'] != 'hvm':
            assert virtual_facts['virtualization_type'] in ['vmware', 'virtualbox', 'parallels', 'xen', 'kvm']
    else:
        assert virtual_facts['virtualization_type'] == None

# Generated at 2022-06-20 20:48:32.642499
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert 'SunOS' == x._platform

# Generated at 2022-06-20 20:48:34.585982
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:48:37.411879
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector()
    assert virtual_facts.virtualfacts.platform == 'SunOS'
    assert isinstance(virtual_facts.virtualfacts, SunOSVirtual)

# Generated at 2022-06-20 20:48:39.282651
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    virt_facts = SunOSVirtual(module)
    assert virt_facts.platform == 'SunOS'

# Generated at 2022-06-20 20:48:41.168477
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    SunOSVirtualCollector(facts, None)
    assert 'virtual' in facts

# Generated at 2022-06-20 20:48:53.265717
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Unit test'''
    # Create test class
    module = AnsibleModule(argument_spec={})
    module.params = {}
    test_instance = SunOSVirtual(module=module)
    assert type(test_instance) is SunOSVirtual
    # Create test cases

# Generated at 2022-06-20 20:48:58.281755
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector

    testdata = FactCollector.collect(SunOSVirtualCollector)
    for key in testdata:
        print("%s: %s" % (key, testdata[key]))


if __name__ == '__main__':
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:49:01.010715
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # pylint: disable=protected-access
    x = SunOSVirtual({})
    assert x._platform == 'SunOS'
    assert isinstance(x, Virtual)

# Generated at 2022-06-20 20:49:25.089017
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual = SunOSVirtual(None)
    virtual_facts = virtual.get_virtual_facts()

    # The dict of the return value should contain the following keys:
    assert sorted(virtual_facts.keys()) == ["container", "virtualization_role", "virtualization_tech_guest", "virtualization_tech_host", "virtualization_type"]

    # The dict should contain "empty" values
    assert virtual_facts["container"] is None
    assert virtual_facts["virtualization_role"] is None
    assert virtual_facts["virtualization_tech_guest"] == set()
    assert virtual_facts["virtualization_tech_host"] == set()
    assert virtual_facts["virtualization_type"] is None

# Generated at 2022-06-20 20:49:33.430153
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Method get_virtual_facts return a dict of facts regarding
    virtualization tech used on the SunOS platform.
    """
    def run_solaris_command(self, cmd):
        """
        Fake method of module_utils.basic.AnsibleModule that
        simulate the command 'zonename' for the test.
        """
        class FakeResp:
            def __init__(self, out):
                self.rc = 0
                self.stdout = out

        global zonename_status
        if cmd == 'zonename':
            if zonename_status == 'global':
                zonename_status = 'not_global'
            elif zonename_status == 'not_global':
                zonename_status = 'global'
            else:
                zonename_status = 'not_global'


# Generated at 2022-06-20 20:49:36.745801
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    my_virtual = VirtualCollector().collector[0]
    assert my_virtual._platform == 'SunOS', \
        "Expected 'SunOS' but found {0} in {1}".format(my_virtual._platform, my_virtual)

# Generated at 2022-06-20 20:49:37.961898
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual._platform == 'SunOS'

# Generated at 2022-06-20 20:49:43.398251
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert type(vc) == SunOSVirtualCollector

# Generated at 2022-06-20 20:49:51.183167
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # The directory /proc/vz is usually only present on Virtuozzo systems
    if os.path.exists('/proc/vz'):
        expected = {'virtualization_type': 'virtuozzo',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': set(['virtuozzo']),
                    'virtualization_tech_host': set(),
                    'container': 'zone'}
    else:
        expected = {'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set(),
                    'virtualization_role': 'guest'}
    collector = SunOSVirtualCollector()
    facts = collector.collect(None, None)
    assert facts == expected


# Generated at 2022-06-20 20:49:56.361711
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    # Test with empty params
    SunOSVirtual({}, {})
    # Test with params
    SunOSVirtual({}, {"ANSIBLE_MODULE_ARGS": {}})


# Generated at 2022-06-20 20:49:59.748391
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    sunos = SunOSVirtual(module)
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-20 20:50:02.907922
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Constructor of class SunOSVirtual should set value of variables _platform, _fact_class
    obj = SunOSVirtual(None)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:08.346252
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    results = SunOSVirtual().get_virtual_facts()
    assert isinstance(results, dict)
    assert 'virtualization_type' in results
    assert 'virtualization_role' in results
    assert 'virtualization_tech_host' in results
    assert 'virtualization_tech_guest' in results

# Generated at 2022-06-20 20:50:38.049535
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    facts_collector = SunOSVirtualCollector()
    assert facts_collector._platform == 'SunOS'
    assert facts_collector._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:50:49.657710
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module.
    class MockModule:
        def __init__(self):
            self.run_command_results = [
                (0, 'global', ''),  # zonename
                (0, '', ''),  # modinfo
                (0, '', ''),  # modinfo
                (0, '', ''),  # modinfo
                (0, '', ''),  # modinfo
                (0, 'virtinfo: Error: A valid parameter must be specified.\n', ''),  # virtinfo
                (0, '', ''),  # smbios
                (0, '', ''),  # smbios
                (0, '', ''),  # smbios
                (0, '', ''),  # smbios
            ]


# Generated at 2022-06-20 20:51:02.696973
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = Fake_module()
    obj = SunOSVirtual(module)
    obj.virtual_sys_modules = {'zonename': '/usr/sbin/zonename',
                               'modinfo': '/usr/sbin/modinfo',
                               'virtinfo': '/usr/sbin/virtinfo',
                               'smbios': '/usr/sbin/smbios',
                               'zoneadm': '/usr/sbin/zoneadm'}

    obj.module.run_command = fake_run_command
    obj.module.get_bin_path = fake_get_bin_path
    obj.os_is_solaris = True
    obj.os_is_solaris10 = True
    obj.os_is_global_zone = True
    obj.os_is_windows = False

# Generated at 2022-06-20 20:51:06.964716
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    assert virtual.module == module
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None

# Generated at 2022-06-20 20:51:15.434683
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    facts = SunOSVirtual()

    # Set the virtual platform to SunOS
    facts.platform = 'SunOS'

    # The platform should be SunOS
    assert(facts.platform == 'SunOS')

    # Set the virtual platform to Linux
    facts.platform = 'Linux'

    # The virtual platform should be SunOS
    assert(facts.platform == 'SunOS')

    # Set the virtual platform to SunOS
    facts.platform = 'SunOS'

# Generated at 2022-06-20 20:51:19.979985
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:51:25.395939
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    '''
    Make sure we correctly populate the SunOSVirtual class instance
    '''
    obj = SunOSVirtual()
    assert obj.platform == 'SunOS'
    assert obj.virtualization_type == 'kvm'
    assert obj.virtualization_role == 'guest'
    assert obj.container == 'zone'
    #assert obj.virtualization_tech_guest == set(['kvm','zone'])
    assert obj.virtualization_tech_host == set(['zone'])

# Generated at 2022-06-20 20:51:29.794360
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.__name__ == 'SunOSVirtualCollector'
    assert SunOSVirtualCollector.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:51:31.702367
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    os = SunOSVirtual(module)
    os.get_virtual_facts()

# Generated at 2022-06-20 20:51:35.514101
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a minimal unit test to ensure the constructor of the class
    SunOSVirtualCollector works.
    """
    my_SunOSVirtualCollector = SunOSVirtualCollector()

# Generated at 2022-06-20 20:52:27.369674
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test the constructor directly
    SunOSVirtualCollector()


# Generated at 2022-06-20 20:52:30.587364
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:52:40.149372
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    # Create a Module Facts object
    module_facts = ModuleFacts(module_args="", persist_files=False)

    # Create a SunOSVirtual object
    #   read_file_generic is selected to return a fixed value
    sunos_virtual = SunOSVirtual(module_facts, 'test_file_path', Virtual.read_file_generic)

    # Create a VirtualCollector object
    #   read_file_generic is selected to return a

# Generated at 2022-06-20 20:52:41.517672
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)


# Generated at 2022-06-20 20:52:44.078274
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Unit test for constructor of class SunOSVirtualCollector
    '''
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:52:45.891904
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:52:54.961386
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def run_command(*args, **kwargs):
        return 0, '', ''
    module = type(str('FakeModule'), (object,), {
        'get_bin_path': lambda *args, **kwargs: '/path/to/binary',
        'run_command': lambda *args, **kwargs: run_command(*args, **kwargs)
    })
    sunos = SunOSVirtual(module)

    # With no virtualization tech detected at all
    facts = sunos.get_virtual_facts()
    assert facts['virtualization_type'] is None
    assert facts['virtualization_role'] is None
    assert facts['container'] is None
    assert not facts['virtualization_tech_host']
    assert not facts['virtualization_tech_guest']

    # With only a host virtualization technology installed

# Generated at 2022-06-20 20:52:56.639932
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """Test SunOSVirtual
    """

    linux_virtual = SunOSVirtual({}, None)

    assert linux_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:53:03.246199
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.legacy_facts is None
    assert vc._fact_class.platform == 'SunOS'
    assert vc._platform == 'SunOS'


# Generated at 2022-06-20 20:53:05.433303
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:54:47.686322
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:54:49.879242
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:02.408876
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual

    module = AnsibleModule(
        argument_spec = dict()
    )

    def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None):
        """Return (rc, out, err)"""
        if command[0] == 'zonename':
            if command[-1] == 'global':
                return 0, 'global\n', ''
            else:
                return 0, 'non-global\n', ''

# Generated at 2022-06-20 20:55:03.895883
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector can be called.
    """
    SunOSVirtualCollector(None)


# Generated at 2022-06-20 20:55:08.063956
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:15.024372
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('ansible_module', (object,), {})
    module.get_bin_path = lambda _: None
    collector = SunOSVirtualCollector(module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual
    assert collector.fact_class.platform == 'SunOS'
    assert collector.fact_class.get_virtual_facts.__module__ == 'ansible.module_utils.facts.virtual.sunos'

# Generated at 2022-06-20 20:55:18.201762
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virt = SunOSVirtual(dict())
    assert virt.facts == {}
    assert virt.platform == 'SunOS'



# Generated at 2022-06-20 20:55:26.098021
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    import os

    module = os.path.dirname(os.path.realpath(__file__)) + '/../../../lib/ansible/module_utils/facts/virtual/sunos.py'
    module = __import__(module.split('.')[0])
    module = getattr(module, module.split('.')[1])
    module = getattr(module, module.split('.')[2])
    module = getattr(module, module.split('.')[3])
    module = getattr(module, module.split('.')[4])
    fact = getattr(module, 'SunOSVirtualCollector')

    # Test from a regular global zone running on bare metal
    test_virtual_facts = dict()

# Generated at 2022-06-20 20:55:37.069739
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # The returned object must be a dictionary with the same keys as the virtual_facts
    # ansible variable defined in ansible.cfg
    virtual_facts_keys = {'virtualization_type', 'virtualization_role', 'container',
                          'virtualization_tech_host', 'virtualization_tech_guest'}
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert isinstance(virtual_facts, dict) and virtual_facts_keys == set(virtual_facts.keys())

# Generated at 2022-06-20 20:55:47.043182
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_module = AnsibleModule(
        argument_spec={}
    )

    obj_temp = SunOSVirtual(module=test_module)
    if obj_temp.module.get_bin_path('zonename'):
        assert obj_temp.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                                'virtualization_tech_host': set()}

    os.environ['PATH'] = ''
    obj_temp2 = SunOSVirtual(module=test_module)
    if obj_temp2.module.get_bin_path('zonename'):
        assert obj_temp2.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                                 'virtualization_tech_host': set()}
