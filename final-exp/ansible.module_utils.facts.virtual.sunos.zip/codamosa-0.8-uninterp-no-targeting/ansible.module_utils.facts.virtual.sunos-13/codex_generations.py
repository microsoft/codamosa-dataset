

# Generated at 2022-06-20 20:48:21.139665
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual=SunOSVirtual()
    # Test for class creation
  

# Generated at 2022-06-20 20:48:22.794256
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'

# Generated at 2022-06-20 20:48:24.841434
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._fact_class.platform == 'SunOS'
    assert x._platform == 'SunOS'

# Generated at 2022-06-20 20:48:31.176398
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock({'get_bin_path': lambda x: None})
    virt = SunOSVirtual(module)

    # Test virtualization_tech_guest
    assert virt.get_virtual_facts()['virtualization_tech_guest'] == set()
    module = AnsibleModuleMock({'get_bin_path': lambda x: 'zonename'})
    virt = SunOSVirtual(module)
    assert virt.get_virtual_facts()['virtualization_tech_guest'] == set()
    module = AnsibleModuleMock({'get_bin_path': lambda x: 'zonename', 'run_command': lambda x: (0, 'global\n', '')})
    virt = SunOSVirtual(module)
    assert virt.get_virtual_facts()['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:48:42.267896
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    facts_module = SunOSVirtual(module)

    # VirtualBox should be detected
    module.run_command = FakeRunCommand(rc=0, stdout='VirtualBox')
    facts = facts_module.get_virtual_facts()
    assert 'virtualbox' in facts['virtualization_tech_guest']
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'

    # VMware should be detected
    module.run_command = FakeRunCommand(rc=0, stdout='VMware')
    facts = facts_module.get_virtual_facts()
    assert 'vmware' in facts['virtualization_tech_guest']
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role']

# Generated at 2022-06-20 20:48:50.095886
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    """Test the constructor of SunOSVirtual"""

    # Setup
    sunos_virtual = SunOSVirtual()

    # Exercise
    # Verify
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_type is None
    assert sunos_virtual.virtualization_role is None
    assert sunos_virtual.container is None
    assert sunos_virtual.virtualization_tech_guest == set()
    assert sunos_virtual.virtualization_tech_host == set()


# Generated at 2022-06-20 20:49:01.113727
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.SunOS import SunOSVirtual

    class ModuleMock:
        def get_bin_path(self, p):
            if p == "modinfo":
                return "/usr/sbin/modinfo"
            elif p == "virtinfo":
                return "/usr/sbin/virtinfo"
            elif p == "zonename":
                return "/usr/sbin/zonename"
            else:
                return None
        def run_command(self, cmd):
            if cmd == "/usr/sbin/modinfo":
                # We assume that the hypervisor has the guest tools installed
                modinfo_output = """
18 2 0:0 SUNWvboxdrv - Filler
19 1 84 0:1 SUNWvboxguest - VirtualBox Guest Additions for Solaris
"""


# Generated at 2022-06-20 20:49:04.442029
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:49:06.898472
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector
    assert collector.__class__.__name__ == 'SunOSVirtualCollector'

# Generated at 2022-06-20 20:49:15.946352
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import sys

    if sys.hexversion < 0x02070000:
        raise SkipTest("Python 2.7 or higher needed")

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.lxd import LXD
    from ansible.module_utils.facts.virtual.zone import Zone
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    class MockFactCollector:
        def __init__(self, *args, **kwargs):
            pass

        def get_all_facts(self):
            return dict()


# Generated at 2022-06-20 20:49:31.028074
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'

# Generated at 2022-06-20 20:49:31.824403
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()


# Generated at 2022-06-20 20:49:36.269697
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    SunOSVirtual(module).get_virtual_facts()
    assert module.run_command_called_count == 1
    assert "zonename" in module.run_command_called_with


# Generated at 2022-06-20 20:49:39.177105
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    o = SunOSVirtualCollector()
    assert o.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class is not None
    assert issubclass(SunOSVirtualCollector._fact_class, Virtual)

# Generated at 2022-06-20 20:49:51.114332
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Create a mock module to get virtualization facts
    import sys
    import imp
    import subprocess

    sys.modules['ansible'] = imp.new_module('ansible')
    sys.modules['ansible.module_utils'] = imp.new_module('ansible.module_utils')
    sys.modules['ansible.module_utils.facts'] = imp.new_module('ansible.module_utils.facts')
    sys.modules['ansible.module_utils.facts.virtual'] = imp.new_module('ansible.module_utils.facts.virtual')
    sys.modules['ansible.module_utils.facts.virtual.base'] = imp.new_module('ansible.module_utils.facts.virtual.base')


# Generated at 2022-06-20 20:50:03.991188
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mod = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!any'], type='list')
        ),
        support_check_mode=True
    )
    inst = SunOSVirtual(module=mod)

    # Change the behaviour of the module functions to be able to test the result
    def get_bin_path_mock(name, opts=None, required=False):
        if name == 'zonename':
            return 'zonename'
        if name == 'modinfo':
            return 'modinfo'
        if name == 'virtinfo':
            return 'virtinfo'
        if name == 'smbios':
            return 'smbios'
        return None
    mod.get_bin_path = get_bin_path_mock

    # Run tests

# Generated at 2022-06-20 20:50:05.425635
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual({})

# Generated at 2022-06-20 20:50:07.094415
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()

# Generated at 2022-06-20 20:50:13.408927
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = Mock(return_value=(0, "global", ""))
    module.get_bin_path = Mock(return_value="/usr/sbin/zonename")
    virtual = SunOSVirtual(module)
    assert {'virtualization_type': None,
            'virtualization_role': 'host',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': {'zone'},
            'container': None} == virtual.get_virtual_facts()


# Generated at 2022-06-20 20:50:21.248736
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    def run_module(*args, **kwargs):
        for name, v in kwargs.items():
            setattr(mod, name, v)
        mod.run_command = lambda *a, **kw: (0, '', '')
        mod.exit_json = lambda **kw: None
        virtual = SunOSVirtual(mod)
        returned_facts = virtual.get_virtual_facts()
        return returned_facts

    mod = MockModule({})
    mod.module.get_bin_path = Mock(return_value=True)

    # Test for a zone
    run_module.run_command = lambda *a, **kw: (0, '/global', '')
    run_module.isdir = lambda *p: False

# Generated at 2022-06-20 20:50:49.111015
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:52.032466
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:55.219787
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:51:07.601523
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    module.read_file = read_file
    module.os_path_isdir = os_path_isdir
    module.os_path_exists = os_path_exists

    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware', 'zone'])
    assert virtual_facts['container'] == 'zone'



# Generated at 2022-06-20 20:51:13.428537
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mod_attrs = dict(module=dict(fail_json=dict(msg='test')), which_binary=lambda x: x)
    obj = SunOSVirtualCollector(module_attrs=mod_attrs)
    assert obj._platform == 'SunOS'


# Generated at 2022-06-20 20:51:23.269769
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtual
    from ansible.module_utils.facts.virtual.solaris import SunOSVirtualCollector
    from ansible.module_utils.facts import ansible_virtual_facts
    from ansible.module_utils.facts.virtual.solaris import test_solaris_virtual_zonename
    from ansible.module_utils.facts.virtual.solaris import test_solaris_virtual_modinfo
    from ansible.module_utils.facts.virtual.solaris import test_solaris_virtual_smbios
    from ansible.module_utils.facts.virtual.solaris import test_solaris_virtual_proc_vz
    from ansible.module_utils.facts.virtual.solaris import test_solaris

# Generated at 2022-06-20 20:51:28.762978
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    class MockModule(object):
        def __init__(self):
            self.params = None

        def run_command(self, cmd):
            return 1, '', ''

        def get_bin_path(self, cmd):
            return None


# Generated at 2022-06-20 20:51:36.796255
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    mocked_module = Mock(run_command=Mock(return_value=(0, "global\n", "")))
    virtual = SunOSVirtual(mocked_module)

    virtual_facts_0 = {}
    virtual_facts_0["virtual"] = {
        "container": 'zone',
        "virtualization_tech_host": set(['zone']),
        "virtualization_tech_guest": set(['zone'])
    }

    assert virtual.get_virtual_facts() == virtual_facts_0

# Generated at 2022-06-20 20:51:38.786108
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({}, load_on_init=False)
    assert v.platform == 'SunOS'


# Generated at 2022-06-20 20:51:49.808807
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.test_get_virtual_facts import MockModule, MockCommand

    # test on a non-global zone
    mock_module = MockModule(
        dict(run_command=MockCommand(
            return_value=(0, 'non-global', '')
        ))
    )
    virtual = SunOSVirtual(mock_module)
    ret = virtual.get_virtual_facts()

    assert ret['virtualization_type'] == 'zone'
    assert 'hypervisor' not in ret
    assert ret['container'] == 'zone'

    # test on a non-global zone, running on a vmware technology

# Generated at 2022-06-20 20:52:40.064202
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = {}
    virtual_collector = SunOSVirtualCollector(facts, None)
    assert virtual_collector._fact_class == SunOSVirtual



# Generated at 2022-06-20 20:52:41.120025
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()


# Generated at 2022-06-20 20:52:42.586664
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.virtual

# Generated at 2022-06-20 20:52:47.164521
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_sv = SunOSVirtual()
    assert test_sv.platform == 'SunOS'
    assert test_sv.get_virtual_facts() == {}
    assert test_sv.concatenate_facts() == {}


# Generated at 2022-06-20 20:52:53.020663
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_dict = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'container': 'zone'
    }
    sunosvirtual = SunOSVirtual(module=None)
    result_dict = sunosvirtual.get_virtual_facts()
    assert result_dict == test_dict, \
        "SunOSVirtual constructor output %s does not match expected output %s" \
        % (result_dict, test_dict)


# Generated at 2022-06-20 20:52:57.036444
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    # TODO: mock virtinfo, smbios, zone, etc.
    v = SunOSVirtual(module)
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:53:00.648251
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()


# Generated at 2022-06-20 20:53:08.006754
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.exists = exists_mock

    virtual_collector = SunOSVirtualCollector(module)
    virtual_facts = virtual_collector.collect()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'container' in virtual_facts


# Mock module for unit testing

# Generated at 2022-06-20 20:53:12.648903
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert len(SunOSVirtual().get_virtual_facts()) >= 1
    assert len(SunOSVirtual().get_virtual_facts()) == len(SunOSVirtual().get_virtual_facts())


# Generated at 2022-06-20 20:53:26.357226
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """Test get_virtual_facts of SunOSVirtual class"""

    # Create an instance of class SunOSVirtual
    test_instance = SunOSVirtual()

    # Mock module.run_command
    test_instance.module.run_command = lambda *args, **kw: (0, '', '')

    # Mock module.get_bin_path
    test_instance.module.get_bin_path = lambda *args, **kw: 'zone'
    result = test_instance.get_virtual_facts()
    assert result == {'virtualization_type': 'zone', 'virtualization_role': 'guest', 'container': 'zone', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'zone'}}

    test_instance.module.get_bin_path = lambda *args, **kw: 'modinfo'

# Generated at 2022-06-20 20:55:15.799336
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Check if it is an instance of VirtualCollector
    virtual_collector = SunOSVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector), \
    "Not an instance of VirtualCollector"
    # Check if it is the sub-class of VirtualCollector
    assert isinstance(virtual_collector, SunOSVirtualCollector), \
    "Not a subclass of SunOSVirtualCollector"
    # Check if the fact_class is set to SunOSVirtual
    assert virtual_collector.fact_class._platform == 'SunOS', \
    "fact_class._platform should be set to 'SunOS'"

# Generated at 2022-06-20 20:55:17.266482
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:55:19.580415
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = SunOSVirtual(dict(module=dict()))
    assert module is not None
    assert SunOSVirtual.platform == 'SunOS'


# Generated at 2022-06-20 20:55:24.186979
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_platform = SunOSVirtual(dict())
    assert "SunOS" in virtual_platform.platform

if __name__ == '__main__':
    test_SunOSVirtual()

# Generated at 2022-06-20 20:55:26.273051
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Create instance of class SunOSVirtualCollector
    sunos_virtual_collector = SunOSVirtualCollector()

    # Assert the instance is not None
    assert(sunos_virtual_collector is not None)


# Generated at 2022-06-20 20:55:30.964213
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import os
    import tempfile
    my_env = os.environ.copy()
    my_env['PATH'] = '/bin'
    module = type('AnsibleModule', (object,), {
        'fail_json': lambda self, *args, **kwargs: None,
        'get_bin_path': lambda self, *args, **kwargs: None,
        'run_command': lambda self, *args, **kwargs: (1, None, None),
        'env': my_env,
    })
    facts = SunOSVirtual(module)
    facts.collect()
    assert 'virtualization_role' not in facts.facts
    assert 'virtualization_type' not in facts.facts
    assert 'container' not in facts.facts

    # inject default values
    zonename = tempfile.NamedTemporary

# Generated at 2022-06-20 20:55:34.296470
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert issubclass(SunOSVirtualCollector._fact_class, Virtual)


# Generated at 2022-06-20 20:55:36.907747
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert isinstance(v, SunOSVirtualCollector)


# Generated at 2022-06-20 20:55:39.230572
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:41.867863
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
