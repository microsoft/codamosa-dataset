

# Generated at 2022-06-20 20:48:27.041685
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Setup class for testing, this will automatically use module_utils/facts/virtual/sunos.py
    test_class = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}), ansible_facts={})

    # Define expected results
    result_zone = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'container': 'zone'
    }
    result_brandedzone = {
        'container': 'zone',
        'virtualization_role': 'guest'
    }
    result_globalzone_vmware_tools_installed = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'container': 'zone'
    }

# Generated at 2022-06-20 20:48:30.698119
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    testargs = ['', '/dev/null']
    with mock.patch.object(sys, 'argv', testargs):
        SunOSVirtual()

# Generated at 2022-06-20 20:48:31.913788
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:48:42.875988
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    mymodule = AnsibleModule(argument_spec=dict())
    result = {
        'ansible_facts': {'virtualization_tech_guest': set(),
                          'virtualization_tech_host': set()
        },
        'changed': False
    }

    # Run get_virtual_facts with no hypervisor in output of modinfo
    def run_command(self):
        return 0, "", ""

    mymodule.run_command = run_command.__get__(mymodule)
    SunOSVirtual = SunOSVirtual(mymodule)

    result['ansible_facts']['virtualization_tech_guest'] = set(['zone'])
    mymodule.exit_json(**result)


# Generated at 2022-06-20 20:48:51.783350
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
   FACT_LIST = [
      'virtualization_tech_guest',
      'virtualization_tech_host',
      'virtualization_type',
      'virtualization_role',
      'container',
   ]
   ALL_FACTS = set(FACT_LIST)
   facts = SunOSVirtual({}).get_virtual_facts()
   test_facts = set()
   test_facts.update(facts.keys())

   # Test that all collected facts are in the expected list of facts
   assert test_facts == ALL_FACTS,\
           "Not all facts collected"



# Generated at 2022-06-20 20:48:52.579039
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    svc = SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:04.396529
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.virtual.Solaris import SunOSVirtualCollector

    fake_module = Facts(
        dict(
            ANSIBLE_MODULE_ARGS = dict(gather_subset = 'virtual')
        )
    )
    virtualCollector = SunOSVirtualCollector(fake_module)
    # Run the collector
    virtualCollector.collect()

    # Check the result

# Generated at 2022-06-20 20:49:06.065855
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual({}, None).platform == 'SunOS'

# Generated at 2022-06-20 20:49:08.208782
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virt = SunOSVirtualCollector()
    assert isinstance(virt, SunOSVirtualCollector)

# Generated at 2022-06-20 20:49:09.739125
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor for class SunOSVirtual returns an instance of that class
    """
    sunos_virtual = SunOSVirtual({})
    assert isinstance(sunos_virtual, SunOSVirtual)

# Generated at 2022-06-20 20:49:31.381076
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual_class = SunOSVirtual(module)

    # This is the well-formatted output of virtinfo:
    #   DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false

    # virtinfo is in the PATH, running it with '-p' option will return the formatted output
    module.run_command_fun = lambda x: (0, "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false", "")
    virtual_facts = virtual_class.get_virtual_facts()

# Generated at 2022-06-20 20:49:41.066851
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize class
    SunOSVirtual = SunOSVirtual()

    # Check if it's a zone
    zonename = SunOSVirtual.module.get_bin_path('zonename')
    if zonename:
        rc, out, err = SunOSVirtual.module.run_command(zonename)
        if rc == 0:
            assert out.rstrip() in ["global", "non-global"]

    # Check if it's a branded zone (i.e. Solaris 8/9 zone)
    if os.path.isdir('/.SUNWnative'):
        assert os.path.isdir('/.SUNWnative') is True

    # Check virtualization type
    modinfo = SunOSVirtual.module.get_bin_path('modinfo')

# Generated at 2022-06-20 20:49:42.444240
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 20:49:51.752961
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-20 20:49:55.260954
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS={}), None)
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:49:56.857911
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(None)


# Generated at 2022-06-20 20:50:01.488966
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    test constructor of class SunOSVirtualCollector
    '''
    dummy_obj = SunOSVirtualCollector()
    assert dummy_obj._fact_class is not None
    assert dummy_obj._platform == 'SunOS'

# Generated at 2022-06-20 20:50:02.953114
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual()
    return v.get_virtual_facts()

# Generated at 2022-06-20 20:50:05.884747
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()

    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'



# Generated at 2022-06-20 20:50:15.858625
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    try:
        from ansible.module_utils.facts.virtual.sunos.virtual import SunOSVirtual
    except ImportError:
        return

    ldom = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset="!all,!min")))
    ldom.module.run_command = lambda *args, **kwargs: (0, '', '')
    virtual_facts = ldom.get_virtual_facts()
    assert virtual_facts == dict(virtualization_type="ldom", virtualization_role="guest", container="zone")

    ldom = SunOSVirtual(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset="!all,!min")))
    ldom.module.get_bin_path = lambda *args, **kwargs: "/bin/true"

# Generated at 2022-06-20 20:50:36.696653
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def get_bin_path(name):
        return (name)

    def run_command(name):
        return (0, '', '')

    def get_file_content(name):
        return ''

    module = type('FakeModule', (object,), {'get_bin_path': get_bin_path,
        'run_command': run_command, 'get_file_content': get_file_content})

    sunos = SunOSVirtual(module)
    assert sunos.get_virtual_facts() == {}

    # Testing:
    # - If it's a zone then virtualization_role must be "guest"
    # - If it's global zone then it may be "host or guest"
    def run_command1(name):
        if name == 'zonename':
            return (0, 'global', '')

# Generated at 2022-06-20 20:50:39.675399
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of SunOSVirtualCollector can be called.
    """
    module = FakeModule()
    SunOSVirtualCollector(module)

# Generated at 2022-06-20 20:50:42.844624
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'zone'

# Generated at 2022-06-20 20:50:44.676536
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(dict(module=None))

    assert s.platform == 'SunOS'

# Generated at 2022-06-20 20:50:51.270041
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert(virtual_facts.get_virtual_facts() == {'virtualization_type': 'solaris-zone',
                                                 'container': 'zone',
                                                 'virtualization_role': 'guest',
                                                 'virtualization_tech_guest': set(['zone']),
                                                 'virtualization_tech_host': set([])})

# Generated at 2022-06-20 20:50:54.940595
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert isinstance(v, SunOSVirtual)
    assert isinstance(v.facts, dict)
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 20:50:58.327363
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    facts = SunOSVirtual(module).get_virtual_facts()

    assert facts['virtualization_tech_host'] == set([])
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['container'] == 'zone'
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'


if __name__ == '__main__':
    # Unit test for method get_virtual_facts of class SunOSVirtual
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:51:03.037092
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor creates SunOSVirtualCollector object
    """
    result = SunOSVirtualCollector()
    assert result is not None

if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-20 20:51:06.290181
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:51:18.829392
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Construct an argument spec
    argument_spec = VirtualCollector._get_argument_spec_for_system_platform(template=Virtual.argument_spec_template)
    del argument_spec['gather_subset']
    del argument_spec['filter']

    # Construct virtual fact collector for System sub class
    # this will load all virtual fact classes for System sub class
    sunos_virtual_collector = SunOSVirtualCollector(argument_spec, {})

    class ModuleStub:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/usr/sbin/zlogin'

        def run_command(self, arg):
            return 0, 'global', ''

    # Construct a ansible module
    module = ModuleStub()

    # Construct a ansible module

# Generated at 2022-06-20 20:51:34.945361
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()

    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.zones == 'zone'

# Generated at 2022-06-20 20:51:46.603547
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual({}, {})

    # Test with a zone
    zonename_path = os.path.join(os.getenv('UNIT_TEST_DATA_DIR'), 'zonename')
    v.module.get_bin_path = lambda x: zonename_path
    modinfo_path = os.path.join(os.getenv('UNIT_TEST_DATA_DIR'), 'modinfo')
    v.module.get_bin_path = lambda x: modinfo_path if x == 'modinfo' else None
    v.container = 'zone'
    v.module.run_command = lambda x: (0, 'solaris-nonglobal', '')
    ret = v._get_virtual_facts()
    assert 'zone' in ret['virtualization_tech_host']

# Generated at 2022-06-20 20:51:48.573676
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.virtualization_type is None

# Generated at 2022-06-20 20:51:49.278565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:51:49.804275
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:52:00.444072
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, 'global', '')
    module_mock.get_bin_path.return_value = False

    fact_ins = SunOSVirtual(module_mock)

    virtual_facts = {'containers': set(), 'virtualization_role': 'host', 'virtualization_type': 'zone',
                     'virtualization_role_guest': set(), 'virtualization_role_host': set(['zone'])}
    assert fact_ins.get_virtual_facts() == virtual_facts



# Generated at 2022-06-20 20:52:11.460127
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    This is a test method for get_virtual_facts of class SunOSVirtual.
    It contains several different cases to test if the method
    correctly identifies the SunOS virtualization technology.
    """
    import sys
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from distutils.version import LooseVersion

    # SunOSVirtual.platform: 'SunOS'
    # SunOSVirtual.get_virtual_facts: return a dictionary of virtualization facts
    test_sunos_virtual = SunOSVirtual(sys.modules[__name__])
    test_sunos_virtual.module.run_command = function_mock_run_command

# Generated at 2022-06-20 20:52:13.937176
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()
    if facts:
        assert facts is not None
    else:
        assert facts is None

# Generated at 2022-06-20 20:52:18.800039
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector(None, None, None).collect()
    assert facts['virtualization_type'] == 'zone'

# Generated at 2022-06-20 20:52:28.846729
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    def run(input_str):
        SunOSVirtualModule = SunOSVirtual(dict(module=object()))
        SunOSVirtualModule.module.run_command = lambda cmd: ('', input_str.splitlines(), '')
        facts = SunOSVirtualModule.get_virtual_facts()
        return facts
    assert run('zonename: global') == {'virtualization_role': 'host', 'virtualization_type': 'zone'}
    assert run('zonename: foo') == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_type': 'zone'}
    assert run('modinfo: vnet: VMware Virtual Ethernet') == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_type': 'vmware'}

# Generated at 2022-06-20 20:52:55.381082
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtualCollector.collect()

    # Test in global zone
    module = Mock()
    virtual = SunOSVirtual(module)
    module.get_bin_path.side_effect = lambda x: '/usr/sbin/virtinfo'
    module.run_command.return_value = (0, '', '')
    virtual_facts = virtual.get_virtual_facts()
    # virtual_facts == {'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set([])}
    assert 'virtualization_tech_host' in virtual_facts and virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert 'virtualization_tech_guest' in virtual_facts and virtual_facts['virtualization_tech_guest'] == set()

    # Test in zone


# Generated at 2022-06-20 20:53:04.049405
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = {}
    virtual_facts = SunOSVirtual(None, 'sunos').get_virtual_facts()
    if virtual_facts is None:
        assert virtual_facts == {}, "Failed to create SunOSVirtual instance."
    else:
        assert 'virtualization_type' in virtual_facts, "Failed to create SunOSVirtual instance."

# Generated at 2022-06-20 20:53:07.606925
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    objtest = SunOSVirtual(None)
    assert objtest.platform == 'SunOS'
    assert objtest.get_virtual_facts() == {}

# Generated at 2022-06-20 20:53:22.722111
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create an instance of SunOSVirtual class
    module = FakeModule()
    virtual_facts = SunOSVirtual(module)

    class Test:
        def test(self, guest_tech, host_tech, container, virtualization_type, virtualization_role):
            self.guest_tech = guest_tech
            self.host_tech = host_tech
            self.container = container
            self.virtualization_type = virtualization_type
            self.virtualization_role = virtualization_role

    # Test zone
    zones = SunOSVirtualCollector.load_json_file('tests/unit/modules/extras/test_facts/virtual/fs/zones.json')

    t = Test()
    t.test(set(['zone']), set([]), 'zone', None, None)
    SunOSVirtualCollector.walk_

# Generated at 2022-06-20 20:53:23.758394
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:53:24.639341
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # run constructor test
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:53:28.805377
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict(module=None,))
    assert virtual_facts.platform == 'SunOS'

# Test for facts of SunOSVirtualCollector

# Generated at 2022-06-20 20:53:44.643051
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    my_module = basic.AnsibleModule(
        argument_spec={'get_type_facts': dict(required=False, type='bool', default=True)}
    )
    my_module.params['get_type_facts'] = True

    # set up my own SunOS virtual class...
    class TestSunOSVirtual(SunOSVirtual):
        platform = 'SunOS'
        # pretend we have a zonename command...
        def get_bin_path(self, arg1, opt_dirs=[]):
            return '/path/for/zonename'
        # ...and a modinfo as well

# Generated at 2022-06-20 20:53:45.890070
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    o = SunOSVirtual()
    assert o.platform == 'SunOS'

# Generated at 2022-06-20 20:54:00.794080
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # pylint: disable=unused-argument
    def run_command(module, command):
        """
        Placeholder function for run_command
        :param module:
        :param command:
        :return:
        """
        if module == 'zonename':
            return 0, 'global', ''
        elif module == 'modinfo':
            return 0, 'filename:     /kernel/misc/vmware.ko', ''
        elif module == 'virtinfo':
            return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''
        else:
            return 1, '', ''

    def get_bin_path(module):
        """
        Placeholder function for get_bin_path
        :param module:
        :return:
        """
       

# Generated at 2022-06-20 20:54:18.184185
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = None
    if os.path.isdir('/.SUNWnative'):
        testobj = SunOSVirtual(module)
        assert testobj.system == 'SunOS'
        assert testobj.virtual == testobj.VIRTUAL_TYPE_CONTAINER

# Generated at 2022-06-20 20:54:28.719227
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.utils.hashs import md5s
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.six import PY3, b
    from ansible.module_utils._text import to_bytes

    import os
    import tempfile

    module = Virtual.get_platform_module('SunOS')()
    module.run_command = run_command_mock

    if PY3:
        v = SunOSVirtual(module, run_command_mock)
    else:
        v = SunOSVirtual(module)

    v.get_virtual_facts()


# Generated at 2022-06-20 20:54:33.609806
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_SunOSVirtual = SunOSVirtual()
    test_virtual_facts = test_SunOSVirtual.get_virtual_facts()
    assert 'vmware' in test_virtual_facts['virtualization_tech_guest']
    assert 'zone' in test_virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:54:38.351179
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    os_version = 'SunOS 5'
    module = FakeAnsibleModule(os_version=os_version)
    fact_instance = SunOSVirtual(module)
    fact_instance.get_virtual_facts()
    assert fact_instance.module == module
    assert fact_instance.platform == 'SunOS'
    assert fact_instance.os_version == os_version


# Generated at 2022-06-20 20:54:39.205110
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-20 20:54:40.555408
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:54:41.109906
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
  pass

# Generated at 2022-06-20 20:54:50.457812
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    virtual_collector = SunOSVirtualCollector(module=module)

    virtual_facts = virtual_collector.collect()
    # Test if the instance has been changed to an instance of SunOSVirtual
    assert(isinstance(virtual_collector._fact_instance, SunOSVirtual))
    # Test virtual_facts
    assert(virtual_facts['virtualization_type'] == 'domaining')
    assert(virtual_facts['virtualization_role'] == 'guest')
    assert(virtual_facts['virtualization_tech_guest'] == set(['domaining']))

# Generated at 2022-06-20 20:54:53.319366
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert v.data is not None



# Generated at 2022-06-20 20:54:55.948228
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-20 20:55:38.072020
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    virtual = SunOSVirtualCollector.fetch_virtual_facts()  # noqa

# Generated at 2022-06-20 20:55:42.674205
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_facts = SunOSVirtualCollector().collect()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:55:47.123071
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (), dict(run_command=lambda *args, **kwargs: [0, '', ''],
                               get_bin_path=lambda *args: '/bin/somepath'))
    fixture = SunOSVirtual(module)
    assert fixture.virtualization_type is None
    assert fixture.virtualization_role is None
    assert fixture.virtualization_tech_host == set()
    assert fixture.virtualization_tech_guest == set()
    assert fixture.container is None

# Generated at 2022-06-20 20:55:57.611140
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    import unittest

    class ModuleMock():
        def __init__(self, params={}, exit_json=None, fail_json=None):
            self.params = params
            self.exit_json = exit_json
            self.fail_json = fail_json

        def run_command(self, command, check_rc=True):
            return (0, '', '')

    sunos_virtual = SunOSVirtual(ModuleMock())
    assert sunos_virtual.platform == 'SunOS'

if __name__ == '__main__':
    test_SunOSVirtual()

# Generated at 2022-06-20 20:56:10.832671
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sysv_ipc import SysVIPCModule
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.zfs import ZFSModule
    import os
    import sys

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'zonename':
                x = os.path.join(os.sep, 'usr', 'bin', 'zonename')
                if os.path.isfile(x):
                    return x
                else:
                    return None

# Generated at 2022-06-20 20:56:13.476595
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    ''' SunOSVirtual is returning an instance of class SunOSVirtual
    '''
    sunos_virtual = SunOSVirtual(dict(module=dict()))
    assert isinstance(sunos_virtual, SunOSVirtual)

# Generated at 2022-06-20 20:56:15.607682
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({'module': None}, {}, {}, [])

    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_virtual_facts() is None


# Generated at 2022-06-20 20:56:18.013059
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 20:56:22.863221
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:56:30.308063
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('', (object,), {'run_command': run_command, 'get_bin_path': get_bin_path})
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert "virtualization_type" in facts
    assert "virtualization_role" in facts
    assert "container" in facts

    assert facts["virtualization_type"] == "vmware"
    assert facts["virtualization_role"] == "guest"
    assert facts["container"] == "zone"

    assert facts["virtualization_tech_guest"] == {'zone', 'vmware'}
    assert facts["virtualization_tech_host"] == {'zone'}



# Generated at 2022-06-20 20:57:26.955984
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeModule()
    SunOSVirtualCollector(module=module)

# Generated at 2022-06-20 20:57:29.309461
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: [0, 'VMware\n', '']

    facts = SunOSVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'


# Unit test class

# Generated at 2022-06-20 20:57:36.969024
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    v = SunOSVirtual(module=module)

    # Check IPMI
    module.run_command.return_value = 127, '', ''
    v.get_virtual_facts()
    module.fail_json.assert_called_with(msg="ipmi_bmc fact cannot be collected")

    # Check ldom
    module.run_command.return_value = 0, '', ''
    v.get_virtual_facts()
    module.fail_json.assert_called_with(msg="virtinfo fact cannot be collected")

    module.run_command.return_value = 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''
    facts = v.get_virtual_facts()

# Generated at 2022-06-20 20:57:40.145544
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.virtualization_type is None
    assert virtual_facts.virtualization_role is None
    assert virtual_facts.container is None



# Generated at 2022-06-20 20:57:44.512157
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor of SunOSVirtual can be instantiated with no arguments
    and values are set to None by default.
    """
    sun_os_virtual = SunOSVirtual()
    assert sun_os_virtual.module is None
    assert sun_os_virtual.platform == 'SunOS'
    assert sun_os_virtual.virtual_facts == {}

# Generated at 2022-06-20 20:57:45.365360
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()


# Generated at 2022-06-20 20:57:51.111035
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual
    assert virtual.platform == "SunOS"


# Generated at 2022-06-20 20:57:53.638146
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunosvirtual = SunOSVirtual('ansible.module_utils.facts.virtual.sunos')
    assert sunosvirtual.platform == 'SunOS'

# Generated at 2022-06-20 20:57:57.433645
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    sunos = SunOSVirtual(module)

    # GIVEN a SunOS machine
    # WHEN get_virtual_facts is called
    facts = sunos.get_virtual_facts()
    # THEN our facts should be correct
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'


# ----------------- Helper classes for unit test ------------------ #
