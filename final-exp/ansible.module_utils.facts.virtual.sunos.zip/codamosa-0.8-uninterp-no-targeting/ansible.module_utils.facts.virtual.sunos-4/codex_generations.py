

# Generated at 2022-06-20 20:48:30.760801
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Tests a SunOS Zones and LDoms scenarios with or without the "guest tools"
    """
    os_virtual = SunOSVirtual()

    os_virtual.module.run_command = lambda x: (0, "global", "")
    os_virtual.get_virtual_facts()

    os_virtual.module.run_command = lambda x: (0, "non-global", "")
    os_virtual.get_virtual_facts()

    os_virtual.module.run_command = lambda x: (0, "", "")
    os_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:48:41.912717
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    class Object:
        args = False
        return_value = False
    module = Object()
    module.run_command = Object()

    # Check the return value of get_virtual_facts method with a global zone
    module.get_bin_path = Object()
    module.get_bin_path.return_value = '/usr/sbin/zonename'
    module.run_command.return_value = 0, "global\n", None
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get_virtual_facts()
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_tech_host' == {'zone'}
    assert 'virtualization_role' not in facts
    assert 'virtualization_type' not in facts
    assert 'container' not in facts



# Generated at 2022-06-20 20:48:53.265764
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    class ModuleMock(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path):
            return '/usr/bin/' + path

        def run_command(self, cmd):
            if cmd == '/usr/bin/zonename':
                return (0, 'global', None)
            if cmd == 'virtinfo -p':
                return (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', None)
            if cmd == '/usr/sbin/modinfo':
                return (0, 'Type: VMware vmm\n', None)
            if cmd == '/usr/sbin/virtinfo':
                return (0, 'not supported', None)

# Generated at 2022-06-20 20:49:05.048471
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    def mock_run_command(args):
        if args == ['zonename']:
            return (0, 'global', '')
        elif args == ['modinfo']:
            return (0, '', '')
        elif args == ['/usr/sbin/virtinfo', '-p']:
            return (0, '', '')
        elif args == ['/usr/sbin/virtinfo', '-l']:
            return (0, '', '')
        elif args == ['/usr/sbin/smbios']:
            return (0, 'System Information\nManufacturer: VMware, Inc.\nProduct Name: VMware Virtual Platform\n', '')
        else:
            return (0, '', '')


# Generated at 2022-06-20 20:49:06.411668
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:09.709209
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Default constructor
    module = FakeModule()
    sunos = SunOSVirtualCollector(module=module)
    assert sunos
    assert sunos.module == module

# Generated at 2022-06-20 20:49:10.845084
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual({})


# Generated at 2022-06-20 20:49:14.609373
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test class SunOSVirtualCollector"""
    os_obj = SunOSVirtualCollector()
    assert os_obj._platform == 'SunOS'
    assert os_obj._fact_class == 'SunOSVirtual'

# Generated at 2022-06-20 20:49:15.856933
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 20:49:20.123371
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = type('', (object,), {'get_bin_path': lambda x, y: False})
    module.run_command = lambda x: (1, '', '')
    SunOSVirtual(module)

# Generated at 2022-06-20 20:49:33.402449
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:38.208973
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()
    assert virtual.container is None

# Generated at 2022-06-20 20:49:42.113339
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:49:51.623350
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import mock
    module = mock.Mock()
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, "global", "")
    module.get_bin_path = mock.Mock()
    module.get_bin_path.return_value = '/usr/bin/zonename'

    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {'virtualization_tech_host': {'zone'}, 'virtualization_tech_guest': set(), 'virtualization_role': 'host', 'virtualization_type': 'zone'}
    assert module.run_command.call_args_list == [mock.call('/usr/bin/zonename')]
    assert module.get_bin_path.call_args_

# Generated at 2022-06-20 20:49:56.200780
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = {}
    candidate = SunOSVirtual(module)
    assert candidate.platform == 'SunOS'
    assert candidate.module == module
    assert candidate.module_utils == 'ansible.module_utils.facts.virtual'


# Generated at 2022-06-20 20:50:06.025343
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    testmodule = FakeAnsibleModule()
    testmodule.run_command = MagicMock(return_value=(0, '', ''))
    testmodule.get_bin_path = MagicMock(side_effect=lambda *args: '/usr/bin/' + args[0])
    testmodule.get_file_content = MagicMock(return_value='')

    testclass = SunOSVirtual(module=testmodule)
    result = testclass.get_virtual_facts()
    assert result == {'virtualization_role': 'guest', 'virtualization_type': 'zone'}



# Generated at 2022-06-20 20:50:11.630232
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import sunos

    # Create a temp module for testing get_virtual_facts()
    module = basic.AnsibleModule(
        argument_spec=collector.get_virtual_facts_argument_spec(),
        supports_check_mode=False
    )
    # Parse the arguments - we don't actually use this in the test.
    collector.add_virtual_facts_options(module)

    # Create a temp instance of the SunOSVirtual class to test virtual_facts()
    fact_class_instance = sunos.SunOSVirtual(module=module)
    fact_class_instance.module.run_command = test_SunOSVirtual_get_virtual_facts_run_command
    # Run

# Generated at 2022-06-20 20:50:12.574219
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:50:15.032143
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector.platforms == ['SunOS']

# Generated at 2022-06-20 20:50:15.899997
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-20 20:50:50.904070
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a fictive module object
    class ModuleMock(object):
        def __init__(self):
            return

        def get_bin_path(self, arg):
            if arg in ['zonename', 'smbios']:
                # we return a binary that does not exist
                return os.path.join(os.sep, 'bin', 'does_not_exist')
            return

        def run_command(self, arg):
            if arg == '/usr/sbin/virtinfo -p':
                if os.path.isdir('/.SUNWnative'):
                    # ldoms: global zone
                    return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''

# Generated at 2022-06-20 20:50:52.893473
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # unit test; we cannot create a class instance for this platform
    # SunOSVirtual(module)
    pass

# Generated at 2022-06-20 20:51:06.290370
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # pylint: disable=no-member
    module = MockModule()

# Generated at 2022-06-20 20:51:15.433301
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Construct an empty instance of the SunOSVirtualCollector class
    std_vc = SunOSVirtualCollector()

    # Assert that the name of the class is set correctly
    assert std_vc.__class__.__name__ == 'SunOSVirtualCollector'

    # Assert that the value of '_fact_class' is set correctly
    assert std_vc._fact_class == SunOSVirtual

    # Assert that the value of '_platform' is set correctly
    assert std_vc._platform == 'SunOS'

# Generated at 2022-06-20 20:51:19.652893
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This test verifies that SunOSVirtualCollector is constructed properly by
    verifying that the only collector added is SunOSVirtualCollector
    """
    collector = SunOSVirtualCollector()
    assert len(collector.collectors) == 1
    assert collector.collectors[0].__class__.__name__ == 'SunOSVirtual'

# Generated at 2022-06-20 20:51:23.088027
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Constructor of class SunOSVirtual should return an instance
    """
    module = AnsibleModule(
        argument_spec={},
    )
    result = SunOSVirtual(module)
    assert isinstance(result, SunOSVirtual)

# Generated at 2022-06-20 20:51:29.958777
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    provider = SunOSVirtual(module=module)
    facts = provider.get_virtual_facts()
    assert facts == dict()



# Generated at 2022-06-20 20:51:42.111943
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module_mock = Mock()
    module_mock.get_bin_path.side_effect = lambda x: '%s_bin_path' % x

    # Test on VMware Guest
    v = SunOSVirtual(module_mock)
    module_mock.run_command.side_effect = lambda x: ('', 'VMware', '')
    response = v.get_virtual_facts()
    assert response == {'virtualization_type': 'vmware', 'virtualization_role': 'guest'}

    # Test on VirtualBox Guest
    v = SunOSVirtual(module_mock)
    module_mock.run_command.side_effect = lambda x: ('', 'VirtualBox', '')
    response = v.get_virtual_facts()

# Generated at 2022-06-20 20:51:42.897920
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()

# Generated at 2022-06-20 20:51:44.186191
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:52:40.149498
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''Unit test for constructor of class SunOSVirtualCollector.'''

    # Create a new object of class SunOSVirtualCollector
    sunos_virtual_collector_object = SunOSVirtualCollector()

    # Check _fact_class
    expected_value = SunOSVirtual
    observed_value = sunos_virtual_collector_object._fact_class
    assert observed_value == expected_value, \
        'Expected and observed values for _fact_class mismatch. Expected: %s, but observed: %s.' % (
            expected_value, observed_value)

    # Check _platform
    expected_value = 'SunOS'
    observed_value = sunos_virtual_collector_object._platform

# Generated at 2022-06-20 20:52:43.695325
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = {}
    os_facts['distribution'] = 'SunOS'
    os_facts['distribution_version'] = '11'

    os_collector = SunOSVirtualCollector(os_facts)
    assert os_collector.get_virtual_facts() == {}



# Generated at 2022-06-20 20:52:48.280620
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-20 20:52:51.336993
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fact_class = SunOSVirtual
    virtual_collector = SunOSVirtualCollector(fact_class)
    assert virtual_collector is not None
    assert virtual_collector.fact_class == fact_class
    assert virtual_collector.platform == 'SunOS'

# Generated at 2022-06-20 20:52:52.138421
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test object construction
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:52:59.511571
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a test fixture for class SunOSVirtual
    virtual_facts_obj = SunOSVirtual()

    # Set is_zone to True
    virtual_facts_obj.is_zone = True
    # Set is_brandZ to True
    virtual_facts_obj.is_brandZ = True
    # Set is_vserver to True
    virtual_facts_obj.is_vserver = True
    # Set is_ldom to True
    virtual_facts_obj.is_ldom = True
    # Set is_domU to True
    virtual_facts_obj.is_domU = True
    # Set is_kvm to True
    virtual_facts_obj.is_kvm = True

    # Call method get_virtual_facts
    virtual_facts = virtual_facts_obj.get_virtual_facts()

    # Check that virtual_

# Generated at 2022-06-20 20:53:02.918515
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    facts_obj = SunOSVirtualCollector(module)
    assert facts_obj


# Generated at 2022-06-20 20:53:06.354493
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()

    # SunOSVirtual.get_virtual_facts() without any detected virtualization
    virtual = SunOSVirtual(module)
    if 'virtualization_type' in virtual.get_virtual_facts():
        raise AssertionError("empty virtual() dict should be returned")

# Generated at 2022-06-20 20:53:07.898333
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual is not None

# Generated at 2022-06-20 20:53:11.174032
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector.virtual == SunOSVirtual

# Generated at 2022-06-20 20:54:51.874569
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    '''
    Test the constructor of class SunOSVirtualCollector.
    '''
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class.__class__.__name__ == 'SunOSVirtual'
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:54:55.844606
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test the constructor of SunOSVirtual
    """
    assert SunOSVirtual(dict()) is not None



# Generated at 2022-06-20 20:54:57.392247
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    v = SunOSVirtualCollector()
    assert v._platform == 'SunOS'

# Generated at 2022-06-20 20:54:58.939262
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:55:00.670076
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sv = SunOSVirtual()
    assert sv.platform == 'SunOS'


# Generated at 2022-06-20 20:55:02.064347
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:04.058725
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class._platform == 'SunOS'
    assert obj.fact_class.__name__ == 'SunOSVirtual'

# Generated at 2022-06-20 20:55:18.826169
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts import facts

    # Set up our module, with some dummy args
    module = facts.AnsibleModule(
        argument_spec={'gather_subset': dict(default=['!all', 'virtual'], type='list')},
        supports_check_mode=True)

    # We create a test class to return fixed value
    # for the methods 'is_zone' and 'is_branded_zone'
    class TestSunOSVirtual(SunOSVirtual):
        def is_zone(self):
            return True
        def is_branded_zone(self):
            return True
        def get_bin_path(self, binary):
            return '/usr/sbin/' + binary

    # Set up a test object
    virtual_facts = TestSunOSVirtual(module)

    # Test get_virtual

# Generated at 2022-06-20 20:55:21.193186
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = AnsibleModuleMock()
    virtual_collector = SunOSVirtualCollector(module)
    assert virtual_collector.facts is None


# Generated at 2022-06-20 20:55:29.217935
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos.facts import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector

    # Mock the AnsibleModule class
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.params = {}

        def get_bin_path(self, arg):
            if arg == "zonename":
                return "/usr/bin/zonename"