

# Generated at 2022-06-20 20:48:25.083481
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec = dict())
    virt = SunOSVirtual(module)
    # Run the constructor of Virtual()
    virtual_facts = virt.populate()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-20 20:48:37.514396
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import os
    module = os.path.join(os.path.dirname(__file__), 'ansible_module_get_virtual_facts.py')
    module = os.path.abspath(module)

    v = SunOSVirtual(module)
    virtual_facts = v.get_virtual_facts()

    # Test virtualization_type
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] in ('vbox', 'kvm', 'parallels', 'zone', 'vmware', 'xen', None)

    if virtual_facts['virtualization_type'] is not None:
        # Test virtualization_role
        assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:48:49.314256
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Initialize the class SunOSVirtual
    virtual_module = SunOSVirtual()

    # Make a subprocess with command "zonename"
    def subprocess(command):
        class subprocess:
            def __init__(self, command):
                self.command = command
            def run_command(self, command):
                if command == "zonename":
                    if self.command == "zone_name=global":
                        return (0, "global", "")
                    elif self.command == "zone_name=something":
                        return (0, "something", "")
                    else:
                        return (1, None, None)
                elif command == "modinfo":
                    return (0, "Some text with name of a hypervisor", "")

# Generated at 2022-06-20 20:48:52.759196
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_facts = SunOSVirtualCollector()
    assert isinstance(sunos_facts, SunOSVirtualCollector)
    assert sunos_facts._platform == 'SunOS'
    assert sunos_facts._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:48:55.780105
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    v = SunOSVirtual(module)
    facts = v.get_virtual_facts()
    assert isinstance(facts, dict)


# Generated at 2022-06-20 20:49:07.552410
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''
    Tests for method get_virtual_facts of class SunOSVirtual
    '''
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.system.system import SunOSPlatform
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts import assemble_facts

    # Test: SunOS system running in a zone
    # Expected result:
    #   virtualization_type:
    #   virtualization_role: guest
    #   container: zone
    virtfacts = assemble_facts(SunOSPlatform, SunOSVirtual)
    assert virtfacts['virtualization_type'] == 'zone'
    assert virtfacts['virtualization_role'] == 'guest'
    assert virtfacts['container'] == 'zone'


# Generated at 2022-06-20 20:49:16.327814
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mod_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    sys.path.append(mod_path)
    module_args = dict(gather_subset='!all,!any,minimal')
    col = SunOSVirtualCollector(module=AnsibleModule(argument_spec=module_args))
    assert col.platform == 'SunOS'
    assert len(col.subsets) == 3
    assert '!all' in col.subsets
    assert '!any' in col.subsets
    assert 'minimal' in col.subsets
    assert col.fact_class == SunOSVirtual
    assert col.ignore_subset_all is False
    assert col.ignore_subset_any is False

# Generated at 2022-06-20 20:49:27.342918
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, x: x,
        'run_command': lambda self, args: (0, '', '')
    })()
    sunos_virtual_obj = SunOSVirtual(module)
    assert sunos_virtual_obj.get_virtual_facts()['container'] == 'zone'
    assert sunos_virtual_obj.get_virtual_facts()['virtualization_type'] == 'vmware'
    assert sunos_virtual_obj.get_virtual_facts()['virtualization_role'] == 'guest'
    assert sunos_virtual_obj.get_virtual_facts()['virtualization_tech_guest'] == {'zone', 'vmware'}

# Generated at 2022-06-20 20:49:29.885787
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.collector._platform == 'SunOS'


# Generated at 2022-06-20 20:49:34.886690
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    hypervisor_type = 'hypervisor_type'
    virtual_facts = 'virtual_facts'
    module = 'module'
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.hypervisor_type == hypervisor_type
    assert sunos_virtual.virtual_facts == virtual_facts
    assert sunos_virtual.module == module

# Generated at 2022-06-20 20:49:54.632687
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt_obj = SunOSVirtual(module)

    def run_bin_return_out(binpath):
        binpath = os.path.expanduser(binpath)
        (rc, out, err) = module.run_command(binpath)
        return (rc, out)

    def run_bin_return_err(binpath):
        binpath = os.path.expanduser(binpath)
        (rc, out, err) = module.run_command(binpath)
        return (rc, err)

    # Set up mocks
    class AnsibleModule_mock:
        def __init__(self):
            self.params = {'gather_subset': '!all', 'gather_timeout': 10, 'filter': '*'}

       

# Generated at 2022-06-20 20:50:05.885541
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    with open('/tmp/test_SunOSVirtual_module.stdout', 'w') as out:
        with open('/tmp/test_SunOSVirtual_module.stderr', 'w') as err:
            with open('/tmp/test_SunOSVirtual_module.stdin', 'w') as ins:
                module = AnsibleModule(
                    argument_spec = dict(),
                    stdin=ins, stdout=out, stderr=err
                )
                v = SunOSVirtual(module)
                v.collect()
                j = v.get_facts()
                assert 'virtualization_type' in j
                assert 'virtualization_role' in j
                assert 'container' in j


# Generated at 2022-06-20 20:50:09.820438
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = "/bin"
    sunos_virtual = SunOSVirtual(mock_module)
    assert isinstance(sunos_virtual, SunOSVirtual)

# Update the Virtual class dictionary of platform specific subclasses
Virtual.collectors.update({SunOSVirtualCollector._platform: SunOSVirtualCollector})

# Generated at 2022-06-20 20:50:18.755715
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    import tempfile

    facts = dict()
    facts['system'] = dict()
    facts['system']['manufacturer'] = 'Microsoft Corporation'
    facts['system']['product'] = 'Virtual Machine'

    module = type('MockedModule', (object,), {})
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/sbin/%s' % x
    module.params = {'gather_subset': 'all'}
    module.fail_json = lambda *args, **kwargs: None

    os_virtual = SunOSVirtual(module)
    virtual_facts = os_virtual.get_virtual_facts()

    assert isinstance(virtual_facts.get('virtualization_type'), str)

# Generated at 2022-06-20 20:50:21.400526
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    c = SunOSVirtualCollector()
    assert c._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 20:50:24.581934
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts._platform == "SunOS"
    assert virtual_facts._fact_class == SunOSVirtual


# Generated at 2022-06-20 20:50:26.381465
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-20 20:50:28.531967
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual
    assert virtual.module == {}

# Generated at 2022-06-20 20:50:33.237725
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    # Check instance
    if not isinstance(virtual_collector, SunOSVirtualCollector):
        raise AssertionError("Not instance of SunOSVirtualCollector")
    # Check parent class
    if not isinstance(virtual_collector, VirtualCollector):
        raise AssertionError("Not instance of VirtualCollector")


# Generated at 2022-06-20 20:50:35.208380
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Constructor of class SunOSVirtualCollector"""
    obj = SunOSVirtualCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 20:50:50.535155
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:50:53.499620
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:51:06.672414
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module._module.get_bin_path = MagicMock(side_effect=lambda x: x)
    module._module.run_command = MagicMock(side_effect=lambda x: (0, '', ''))
    loader = module._module._loader
    module._module._loader = MagicMock(side_effect=lambda x: {
        'smbios': loader(x),
        'zonename': loader(x),
        'modinfo': loader(x)
    }[x])
    module._module.get_bin_path = MagicMock(side_effect=lambda x: x)
    module._module.run_command_environ_update = MagicMock(return_value=module._module.run_command)

# Generated at 2022-06-20 20:51:19.163188
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    vm = SunOSVirtual(module)

    # Simulate platform is SunOS
    vm.platform = 'SunOS'
    facts = vm.get_virtual_facts()

    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    # Simulate platform is Solaris 10 and we are in a global zone
    vm.platform = 'Solaris'
    vm.module.run_command = Mock(return_value=(0, "/usr/sbin/zonename: global", ''))
    facts = vm.get_virtual_facts()

    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set

# Generated at 2022-06-20 20:51:28.868682
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'global', ''))
    module.get_bin_path = Mock(return_value='/usr/sbin/zonename')
    SunOSVirtual.module = module

    SunOSVirtual.is_file = Mock(side_effect=lambda x: x == '/.SUNWnative')
    SunOSVirtual.is_directory = Mock(side_effect=lambda x: x == '/proc/vz')
    SunOSVirtual.virtual_facts = {'some_fact': 'some_value'}
    SunOSVirtual.get_virtual_facts()
    assert(SunOSVirtual.virtual_facts == {'some_fact': 'some_value'})
    assert(SunOSVirtual.virtual_facts['virtualization_role'] == 'host')

# Generated at 2022-06-20 20:51:41.122908
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = 'usr/bin/'
    os.path.isdir.return_value = False
    os.path.exists.return_value = False

    sunos = SunOSVirtual(module)
    facts = sunos.get_virtual_facts()

    assert facts['container'] == 'zone'
    assert facts['virtualization_type'] == 'virtuozzo'
    assert facts['virtualization_role'] == 'guest'
    assert set(facts['virtualization_tech_guest']) == set(['virtuozzo', 'zone'])
    assert len(set(facts['virtualization_tech_host'])) == 1

# Generated at 2022-06-20 20:51:44.670396
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector('SunOSVirtualCollector', {}, {}, [], [])
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:51:46.502914
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """Test SunOSVirtualCollector constructor"""
    SunOSVirtualCollector()

# Generated at 2022-06-20 20:51:49.438508
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual
    assert x.platform == SunOSVirtual._platform

# Generated at 2022-06-20 20:51:56.500787
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    facts = {}

    # Test a standard zone
    SunOSVirtual(module, facts, None).get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_guest' == set(['zone'])
    assert 'virtualization_tech_host' == set()
    assert 'container' == 'zone'

    # Test a branded zone
    os.makedirs('/.SUNWnative')
    SunOSVirtual(module, facts, None).get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_guest' == set(['zone'])
    assert 'virtualization_tech_host' == set()

# Generated at 2022-06-20 20:52:26.213054
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    for key in ['virtualization_type', 'virtualization_role', 'virtualization_tech_host', 'virtualization_tech_guest']:
        assert key in virtual_facts

# Generated at 2022-06-20 20:52:27.655208
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.name == "SunOS"

# Generated at 2022-06-20 20:52:30.612099
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Pre-existing unit test for the constructor of class
    SunOSVirtual.
    """
    SunOSVirtual({})

# Generated at 2022-06-20 20:52:43.342977
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a fixture for the module_utils.facts.virtual.sunos.SunOSVirtual class
    class FixtureSunOSVirtual:
        _module = None
        facts = dict()

        def __init__(self, *args, **kwargs):
            # Do not instantiate module as it requires unittest.mock.MagicMock
            self._module = type('', (), {'get_bin_path': self._get_bin_path, 'run_command': self._run_command})()

        def _get_bin_path(self, path):
            if path == 'zonename' and 'zone' in self.facts['virtualization_tech_guest']:
                return '/usr/sbin/zonename'

# Generated at 2022-06-20 20:52:49.063012
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Test constructor without argument
    sunos_virtual = SunOSVirtual()
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.virtualization_type == 'SunOS'
    assert sunos_virtual.virtualization_role == 'SunOS'
    assert sunos_virtual.container is None

# Generated at 2022-06-20 20:52:50.175840
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:52:55.001886
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_dev = SunOSVirtual()
    assert sunos_dev.platform == 'SunOS'
    assert sunos_dev.virtualization_type is None
    assert sunos_dev.virtualization_role is None
    assert sunos_dev.virtualization_tech_guest is None
    assert sunos_dev.virtualization_tech_host is None
    assert sunos_dev.container is None

# Generated at 2022-06-20 20:52:56.900140
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual
    assert x._platform == 'SunOS'

# Generated at 2022-06-20 20:53:08.549215
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value='/bin/zonename')
    module.get_bin_path.side_effect = [
        '/bin/zonename', '/bin/zonename', None, '/bin/modinfo', '/bin/virtinfo', '/bin/smbios']

# Generated at 2022-06-20 20:53:14.190426
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = 'ansible_facts.solaris.virtual.py'
    m = __import__(module, fromlist=[''])
    s = SunOSVirtual(m)
    assert (s.get_platform() == 'SunOS')

# Generated at 2022-06-20 20:54:15.687931
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import BaseVirtual
    from ansible.module_utils.facts import FactCollector

    # Create mock module
    module = MockModule()

    # Create fact collector for mock module
    fact_collector = FactCollector(module=module)

    # Create a test class, using our mocked module
    virtual_testclass = SunOSVirtual(module=module, fact_collector=fact_collector)

    # In the following we are testing the output of the get_virtual_facts method
    # of the test class.
    # To test this we need to create the virtual_facts dictionary with the expected
    # values of the tests.

    # Test machine with global zone and no guest tools installed
    assert virtual_testclass

# Generated at 2022-06-20 20:54:23.511021
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    os_facts = {}
    os_facts['distribution'] = 'SunOS'
    os_facts['distribution_version'] = ''
    SunOSVirtualCollector(None, os_facts, None)

# Generated at 2022-06-20 20:54:25.231450
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert obj._platform == "SunOS"

# Generated at 2022-06-20 20:54:27.782249
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sunos_virtual = SunOSVirtual(dict())

    assert sunos_virtual.platform == 'SunOS'

# Generated at 2022-06-20 20:54:29.817872
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # For coverage.
    module = None
    SunOSVirtual(module)

# Generated at 2022-06-20 20:54:39.563940
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeCommand({
        'zonename': (0, 'global', ''),
        'modinfo': (0, 'vmware1 vmware2', ''),
        'smbios': (0, 'smbios_return', ''),
        '/usr/sbin/virtinfo -p': (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', '')
    })
    module.read_file = FakeReadFile({
        '/proc/vz': (0, '', ''),
    })
    module.stat = FakeStat({
        '/.SUNWnative': (0, '', ''),
    })

# Generated at 2022-06-20 20:54:49.267853
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()

    # Test case 1: zonename returns "global"
    zonename = module.mock_get_bin_path.return_value = True
    module.run_command.return_value = (0, 'global', '')
    module.path_exists.return_value = False

    # Expected facts
    virtual_facts = {
        'virtualization_tech_host': {'zone'},
        'virtualization_tech_guest': set()
    }

    sun = SunOSVirtual(module)
    results = sun.get_virtual_facts()

    module.mock_get_bin_path.assert_called_with('zonename')
    module.run_command.assert_called_with(zonename)
    module.path_exists.assert_not_called()

# Generated at 2022-06-20 20:54:52.616301
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual()
    assert v.platform == 'SunOS'
    assert not v.get_virtual_facts()


# Generated at 2022-06-20 20:54:55.874319
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector(None, SunOSVirtual)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSVirtual

# Generated at 2022-06-20 20:55:01.821061
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from collections import defaultdict
    from ansible.module_utils.facts import FactCollector

    fact_collector = FactCollector(None, None, None)
    SunOSVirtualCollector(fact_collector)
    assert isinstance(fact_collector.facts['virtualization'], defaultdict), 'The virtualization fact should be of type defaultdict'

# Generated at 2022-06-20 20:56:18.831537
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    f = SunOSVirtual({})
    assert f.platform == 'SunOS'

# Generated at 2022-06-20 20:56:22.362295
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual(dict())
    assert s.platform == 'SunOS'
    assert s.get_virtual_facts() is None


# Generated at 2022-06-20 20:56:30.673609
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-20 20:56:33.293321
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sc = SunOSVirtualCollector
    assert sc._platform == 'SunOS'
    assert sc._fact_class.platform == 'SunOS'
    assert sc._fact_class.get_virtual_facts() == {}

# Generated at 2022-06-20 20:56:35.223533
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert isinstance(virtual_collector._fact_class, SunOSVirtual)
    assert virtual_collector._platform == 'SunOS'

# Generated at 2022-06-20 20:56:42.667588
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    Test the module constructor
    """

    sunos_virtual = SunOSVirtual()

    # At the moment there is just one instance of Virtual, so we can test things
    # on sunos_virtual.
    assert sunos_virtual.platform == "SunOS"

# Generated at 2022-06-20 20:56:44.387471
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s = SunOSVirtual()
    assert s.platform == "SunOS"


# Generated at 2022-06-20 20:56:46.627413
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual(None)
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 20:56:47.405417
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-20 20:56:49.570894
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual(None)