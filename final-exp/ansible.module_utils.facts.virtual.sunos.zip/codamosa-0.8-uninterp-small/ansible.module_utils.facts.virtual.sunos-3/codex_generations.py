

# Generated at 2022-06-25 01:28:45.598407
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # No exception is thrown
    test_case_0()



# Generated at 2022-06-25 01:28:53.575013
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = '!I9XPf)~tN\x0c'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    sun_o_s_virtual_0.module = MockModule()
    sun_o_s_virtual_0.module.get_bin_path = Mock(return_value='\x04\x0f\r')
    sun_o_s_virtual_0.module.run_command = Mock(return_value=('\x06', 'U6\n', '\n\x1a+\x12\x11\x19\x1b\x12\x01\r'))
    sun_o_s_virtual_0.module.params = {}
    sun_o_s_virtual_0.module.fail_json = Mock()
    sun

# Generated at 2022-06-25 01:29:00.211792
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    str_0 = '7=uD\x04'
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(str_0)
    str_0 = '7=uD\x04'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(str_0)

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 01:29:03.351433
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = '!I9XPf)~tN\x0c'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)


# Generated at 2022-06-25 01:29:14.220419
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_1 = SunOSVirtual()
    assert isinstance(sun_o_s_virtual_1._platform, str) == True
    assert sun_o_s_virtual_1._platform == 'SunOS'
    assert isinstance(sun_o_s_virtual_1._module, object) == True
    assert isinstance(sun_o_s_virtual_1._facts, dict) == True
    assert isinstance(sun_o_s_virtual_1.platform, str) == True
    assert sun_o_s_virtual_1.platform == 'SunOS'
    assert isinstance(sun_o_s_virtual_1.virtualization_type, str) == True
    assert sun_o_s_virtual_1.virtualization_type == ''

# Generated at 2022-06-25 01:29:18.167490
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = '!I9XPf)~tN\x0c'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)



# Generated at 2022-06-25 01:29:20.819245
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = 'A(@.&Zqa'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:24.969519
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

if __name__ == "__main__":
    test_case_0()
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:31.992007
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = '@Rm\x1d4\x1f'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_virtual_0.module.get_bin_path = MagicMock(return_value='')
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:41.710267
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = 'B\x15.'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    if sun_o_s_virtual_0.module.get_bin_path('zonename') is not None:
        str_1 = 'global'
    else:
        str_1 = os.path.isdir('/.SUNWnative')
    dict_0 = sun_o_s_virtual_0.get_virtual_facts()
    if 'container' not in dict_0.keys():
        sun_o_s_virtual_0.module.get_bin_path('modinfo')
    dict_1 = sun_o_s_virtual_0.get_virtual_facts()
    str_2 = 'vmware'
    str_3 = 'virtualbox'

# Generated at 2022-06-25 01:29:54.680200
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:56.997219
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_1 is not None


# Generated at 2022-06-25 01:29:59.897544
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    print(sun_o_s_virtual_0.get_virtual_facts())

if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:30:01.580024
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    assert sun_o_s_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:30:07.636505
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual({})
    sun_o_s_virtual.module.run_command = MagicMock(return_value=[0, '', ''])
    sun_o_s_virtual.module.get_bin_path = MagicMock(side_effect=[
        '/bin/zonename',
        None,
        '/bin/modinfo',
        '/bin/virtinfo',
        '/bin/smbios'])
    os.path.isdir = MagicMock(return_value=True)
    os.path.exists = MagicMock(side_effect=[True, False])


# Generated at 2022-06-25 01:30:18.253710
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test case for testing get_virtual_facts with various inputs
    """
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, 'output of lsb_release command', ''))
    sun_o_s_virtual_0.module.get_bin_path = MagicMock(return_value='/usr/bin')
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-25 01:30:19.945834
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual_0 = SunOSVirtual()
    result = SunOSVirtual_0.get_virtual_facts()
    assert (result is None)


# Generated at 2022-06-25 01:30:30.019056
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual({})
    sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_1 = SunOSVirtual({'ANSIBLE_MODULE_ARGS': {'gather_subset': '!all'}})
    sun_o_s_virtual_1.get_virtual_facts()
    sun_o_s_virtual_2 = SunOSVirtual({'ANSIBLE_MODULE_ARGS': {'gather_subset': '!all,!min'}})
    sun_o_s_virtual_2.get_virtual_facts()
    sun_o_s_virtual_3 = SunOSVirtual({'ANSIBLE_MODULE_ARGS': {'gather_subset': 'all'}})
    sun_o_s

# Generated at 2022-06-25 01:30:34.214501
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    output = sun_o_s_virtual_0.get_virtual_facts()
    assert output == {}


# Generated at 2022-06-25 01:30:34.935888
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:30:49.466272
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:50.618305
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:53.255372
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    s0 = SunOSVirtual()
    if isinstance(s0, SunOSVirtual):
        print("SunOSVirtual object is successfully created")
    else:
        raise Exception("Failed to create SunOSVirtual object")


# Generated at 2022-06-25 01:30:58.822833
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    sun_o_s_virtual = SunOSVirtual()
    sun_o_s_virtual.module = MagicMock()
    sun_o_s_virtual.module.get_bin_path.return_value = True

    virtual_facts = sun_o_s_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

    virtual_facts = sun_o_s_virtual.get_virtual_facts()
    assert virtual_facts.has_key('container')
    assert virtual_facts['container'] == 'zone'

from ansible.module_utils.facts.virtual.sun_o_s.test_case_sun_o_s_virtual import *

# Generated at 2022-06-25 01:31:00.760352
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
  sun_o_s_virtual_0 = SunOSVirtual()
  
if __name__ == '__main__':
    test_SunOSVirtual()

# Generated at 2022-06-25 01:31:01.899971
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:04.027318
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0 is not None


# Generated at 2022-06-25 01:31:11.034326
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    if os.path.isdir('/tmp/test_SunOSVirtual'):
        shutil.rmtree('/tmp/test_SunOSVirtual')
    os.makedirs('/tmp/test_SunOSVirtual')
    module = AnsibleModule(argument_spec={})

    sun_o_s_virtual = SunOSVirtual(module, "some_path", "some_command")
    assert sun_o_s_virtual.platform == 'SunOS'


# Generated at 2022-06-25 01:31:11.849170
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:31:12.714915
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:31:51.780002
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    output = sun_o_s_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in output
    assert 'virtualization_type' in output
    assert 'container' in output
    assert 'virtualization_tech_guest' in output
    assert 'virtualization_tech_host' in output

# Generated at 2022-06-25 01:31:55.867491
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:32:00.988065
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_virtual_0.module.get_bin_path.return_value = '/usr/sbin/zonename'
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set([]),
                                                                                           'virtualization_tech_host': set([]),
                                                                                           'virtualization_role': None,
                                                                                           'virtualization_type': None,
                                                                                           'container': None}


# Generated at 2022-06-25 01:32:06.211608
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    with open('test_SunOSVirtual.out', 'r') as f:
        sun_o_s_virtual_0 = SunOSVirtual()
        data = f.read()
        virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
        assert virtual_facts == {'virtualization_type': 'parallels', 'virtualization_role': 'guest'}



# Generated at 2022-06-25 01:32:08.238819
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()


if __name__ == '__main__':
    print(SunOSVirtual.get_virtual_facts())

# Generated at 2022-06-25 01:32:10.066939
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual(module=None)
    assert sun_o_s_virtual
    assert sun_o_s_virtual.platform == 'SunOS'

# Generated at 2022-06-25 01:32:18.871789
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Definition of:
    # - config_file
    # - root_dir
    # - module_name
    # - module_path
    # - module_args
    config_file = None
    root_dir = None
    module_name = 'ansible_collections.not.a.real.collection.plugins.modules.test_facts_module'
    module_path = 'plugins/modules/test_facts_module.py'
    module_args = None

    # Create a module with the ansible definition and call the
    # constructor of SunOSVirtual class
    module = AnsibleModule(
        config_file=config_file,
        root_dir=root_dir,
        module_name=module_name,
        module_path=module_path,
        module_args=module_args
    )
    sun_o

# Generated at 2022-06-25 01:32:22.263272
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 01:32:26.987885
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:32:32.204605
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    """
    This is a test for the constructor of the class SunOSVirtual.
    It checks if the created object is an instance of the correct class.
    """
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    if not isinstance(sun_o_s_virtual_collector_0,SunOSVirtualCollector):
        raise AssertionError()


# Generated at 2022-06-25 01:33:44.175472
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
	sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
	sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
	sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:33:46.291296
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_instance_0 = SunOSVirtual()
    assert isinstance(sun_o_s_virtual_instance_0.get_virtual_facts(), dict)

# Generated at 2022-06-25 01:33:46.901551
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert True == True 


# Generated at 2022-06-25 01:33:52.011159
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    # We aren't testing the returned values, just that they don't error out
    assert sun_o_s_virtual_collector is not None

# Generated at 2022-06-25 01:33:53.133279
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:33:54.880564
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:33:57.510635
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:33:58.282582
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:34:01.481049
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_1._platform == 'SunOS'
    assert sun_o_s_virtual_collector_1._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_1._filename_pattern == 'virtual_sunos.fact'
    assert sun_o_s_virtual_collector_1._cache_file == 'virtual_sunos.fact'

# Generated at 2022-06-25 01:34:09.201236
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
# Check instance of class SunOSVirtualCollector
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
# Check instance of class VirtualCollector
    assert isinstance(sun_o_s_virtual_collector_0, VirtualCollector)
# Check attribure _fact_class of class SunOSVirtualCollector
    assert sun_o_s_virtual_collector_0._fact_class is SunOSVirtual
# Check attribure _platform of class SunOSVirtualCollector
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:35:30.466691
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    float_0 = -806.0402
    dict_0 = {float_0: sun_o_s_virtual_collector_0, float_0: sun_o_s_virtual_collector_0, float_0: float_0}
    str_0 = '|7A@D(\tW'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    bytes_0 = b'\xe2\xf03'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(bytes_0)

# Generated at 2022-06-25 01:35:41.491428
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    float_0 = -806.0402
    dict_0 = {float_0: sun_o_s_virtual_collector_0, float_0: sun_o_s_virtual_collector_0, float_0: float_0}
    str_0 = '|7A@D(\tW'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    bytes_0 = b'\xe2\xf03'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(bytes_0)

# Generated at 2022-06-25 01:35:46.723746
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class() == SunOSVirtual
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    str_0 = 'XO^CK\x1c'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(str_0)
    assert sun_o_s_virtual_collector_1._fact_class() == SunOSVirtual
    assert sun_o_s_virtual_collector_1._platform == 'SunOS'


# Generated at 2022-06-25 01:35:50.765763
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:55.400375
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    float_0 = 36.0916
    sun_o_s_virtual_1 = SunOSVirtual(float_0)
    dict_1 = {float_0: float_0}
    sun_o_s_virtual_2 = SunOSVirtual(dict_1)
    str_0 = '9aT~s'
    sun_o_s_virtual_3 = SunOSVirtual(str_0, dict_1)
    str_1 = 'E-r?r'
    sun_o_s_virtual_4 = SunOSVirtual(str_1)
    dict_2 = {float_0: sun_o_s_virtual_4}

# Generated at 2022-06-25 01:36:03.381196
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    float_0 = -806.0402
    dict_0 = {float_0: sun_o_s_virtual_collector_0, float_0: sun_o_s_virtual_collector_0, float_0: float_0}
    str_0 = '|7A@D(\tW'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    bytes_0 = b'\xe2\xf03'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(bytes_0)

# Generated at 2022-06-25 01:36:10.503927
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    float_0 = -806.0402
    dict_0 = {float_0: sun_o_s_virtual_collector_0, float_0: sun_o_s_virtual_collector_0, float_0: float_0}
    str_0 = '|7A@D(\tW'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    bytes_0 = b'\xe2\xf03'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(bytes_0)

# Generated at 2022-06-25 01:36:15.713231
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual('X')
    str_0 = 'v\xf5\xc1\xb5\xcc\x0b\x1f\x9a\x17'
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert (var_0 == {}), "Failed: expected var_0 to be {}."


# Generated at 2022-06-25 01:36:26.247553
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    float_0 = -806.0402
    dict_0 = {float_0: sun_o_s_virtual_collector_0, float_0: sun_o_s_virtual_collector_0, float_0: float_0}
    str_0 = '|7A@D(\tW'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    bytes_0 = b'\xe2\xf03'
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(bytes_0)

# Generated at 2022-06-25 01:36:32.299960
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    float_0 = -806.0402
    dict_0 = {float_0: sun_o_s_virtual_collector_0, float_0: sun_o_s_virtual_collector_0, float_0: float_0}
    str_0 = '|7A@D(\tW'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()