

# Generated at 2022-06-25 01:28:46.002795
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    sun_o_s_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:28:49.812310
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(dict(), dict())
    assert sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:50.790425
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:28:53.561931
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_virtual_collector_0, SunOSVirtualCollector)


# Generated at 2022-06-25 01:28:55.452648
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:28:58.722955
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(virtual_collector_0)


# Generated at 2022-06-25 01:29:00.610218
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()
    assert sun_o_s_virtual.platform == 'SunOS'

# Generated at 2022-06-25 01:29:01.899390
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert sun_o_s_virtual_collector_0


# Generated at 2022-06-25 01:29:04.561489
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:06.807007
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_0 = SunOSVirtual({}, {}, {}, [], None)
    assert virtual_0


# Generated at 2022-06-25 01:29:22.448612
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:23.493665
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:26.737042
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\xae0'
    list_0 = [bytes_0]
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(bytes_0)
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(bytes_0, list_0)


# Generated at 2022-06-25 01:29:28.006217
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:34.809860
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:35.642907
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:29:41.600686
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\xae0'
    list_0 = [bytes_0, bytes_0, bytes_0]
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(bytes_0, list_0)
    assert sun_o_s_virtual_collector_0._fact_class._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:29:45.492128
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:49.808094
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == dict(
        container=None,
        virtualization_role=None,
        virtualization_type=None,
        virtualization_tech_guest=set(),
        virtualization_tech_host=set())

# Generated at 2022-06-25 01:29:55.969304
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:23.648726
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)

# Generated at 2022-06-25 01:30:24.987542
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
  # TODO: Hard to test because of protected method.
  pass


# Generated at 2022-06-25 01:30:29.530223
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)


# Generated at 2022-06-25 01:30:36.253096
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:30:44.233912
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    print("test_SunOSVirtual")
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    print(sun_o_s_virtual_0)
    print(sun_o_s_virtual_0.arg)
    print(sun_o_s_virtual_0.module)
    print(SunOSVirtual)


# Generated at 2022-06-25 01:30:51.863991
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:55.666290
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  bytes_0 = b'\xae0'
  list_0 = [None, bytes_0, None]
  sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
  var_0 = sun_o_s_virtual_0.get_virtual_facts()
  sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:31:03.573457
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:31:10.305094
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:15.170785
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    pass


# Generated at 2022-06-25 01:32:09.580131
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector();
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector();



test_case_0()

# Generated at 2022-06-25 01:32:16.174198
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    sun_o_s_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:32:17.731600
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    try:
       sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    except Exception as e:
       print(e)



# Generated at 2022-06-25 01:32:25.802686
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b''
    list_0 = [bytes_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # sun_o_s_virtual_collector_0._fact_class = sun_o_s_virtual_0
    # sun_o_s_virtual_collector_0._platform = bytes_0
    var_0 = sun_o_s_virtual_collector_0._get_platform()
    # var_1 = sun_o_s_virtual_collector_0._get_fact_class()
    # sun_o_s_virtual_collector_0._platform = bytes_0
    # var_2 = sun_o_s_virtual_collect

# Generated at 2022-06-25 01:32:29.606053
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:33.484972
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:37.146950
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:32:42.196762
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    assert sun_o_s_virtual_0._platform == 'SunOS'
    assert sun_o_s_virtual_0._module == bytes_0
    assert sun_o_s_virtual_0._facts == list_0
    assert sun_o_s_virtual_0._system == 'SunOS'



# Generated at 2022-06-25 01:32:42.896973
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    pass


# Generated at 2022-06-25 01:32:46.027215
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    assert sun_o_s_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:35:06.818658
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert test_case_0() == None


# Generated at 2022-06-25 01:35:10.548986
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_os_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_os_virtual_0.get_virtual_facts()
    assert not var_0
    assert len(var_0) == 0
    assert sun_os_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:35:14.374207
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    assert isinstance(sun_o_s_virtual_0, SunOSVirtual)


# Generated at 2022-06-25 01:35:25.090367
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'test-value'
    list_0 = [b'long', b'longer']
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_0._fact_class = sun_o_s_virtual_0
    sun_o_s_virtual_collector_0._platform = 'SunOS'
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'

if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:35:28.013343
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0 is not None


# Generated at 2022-06-25 01:35:31.851067
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    str_0 = sun_o_s_virtual_0.__doc__
    str_1 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:34.421864
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(argument_0)


# Generated at 2022-06-25 01:35:37.660839
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:35:41.706211
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xae0'
    int_0 = None
    list_0 = [int_0, bytes_0, int_0]
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0, list_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:42.504684
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()