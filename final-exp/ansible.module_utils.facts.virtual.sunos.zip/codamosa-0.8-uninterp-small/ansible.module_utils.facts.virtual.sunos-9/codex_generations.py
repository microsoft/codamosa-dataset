

# Generated at 2022-06-25 01:28:47.989919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:28:54.127795
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None
    assert len(sun_o_s_virtual_collector._fact_class) > 0
    assert sun_o_s_virtual_collector._fact_class._platform == 'SunOS'

# Generated at 2022-06-25 01:29:04.970246
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.get_bin_path = lambda x: x
    sun_o_s_virtual_0.module.run_command = lambda x: (0, '', '')
    sun_o_s_virtual_0.module.get_bin_path = lambda x: x
    sun_o_s_virtual_0.module.run_command = lambda x: (0, '', '')
    sun_o_s_virtual_0.module.get_bin_path = lambda x: x
    sun_o_s_virtual_0.module.run_command = lambda x: (0, '', '')
    sun_o_s_virtual_0.module.get_bin_path = lambda x: x
    sun_

# Generated at 2022-06-25 01:29:06.849946
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()



# Generated at 2022-06-25 01:29:08.585046
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:10.805151
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector, SunOSVirtualCollector)


# Generated at 2022-06-25 01:29:12.446901
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:18.240928
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual


# Generated at 2022-06-25 01:29:19.690299
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:20.796271
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:29:35.417321
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_1.facts == {}


# Generated at 2022-06-25 01:29:36.538918
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(dict())


# Generated at 2022-06-25 01:29:44.315590
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    os = SunOSVirtual()
    facts = os.get_virtual_facts()
    assert(facts['virtualization_type'] == expected_type)
    assert(facts['virtualization_role'] == expected_role)
    assert(facts['container'] == expected_container)
    assert('virtualization_tech_guest' in facts)
    assert('virtualization_tech_host' in facts)

test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:29:49.754966
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)



# Generated at 2022-06-25 01:29:55.606513
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert str(type(sun_o_s_virtual_collector_1)) == "<class 'ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector'>"


# Generated at 2022-06-25 01:30:00.006410
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual)
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:30:03.174662
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0


# Generated at 2022-06-25 01:30:04.827222
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0_obj = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0_obj, SunOSVirtualCollector)

# Generated at 2022-06-25 01:30:05.780881
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:30:07.418757
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

    assert sun_o_s_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:30:34.332796
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector._platform == 'SunOS'


# Generated at 2022-06-25 01:30:37.552402
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:30:42.496250
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  virtual_collector = SunOSVirtualCollector()
  assert virtual_collector._platform == 'SunOS'
  assert isinstance(virtual_collector._fact_class(), SunOSVirtual)

# Generated at 2022-06-25 01:30:44.447551
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.facts is None


# Generated at 2022-06-25 01:30:49.258085
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:30:50.696438
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:51.787998
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:52.923591
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    

# Generated at 2022-06-25 01:30:54.010660
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:56.547264
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual)


# Generated at 2022-06-25 01:31:55.697837
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:59.334243
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert type(sun_o_s_virtual_collector_0) == SunOSVirtualCollector
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:32:03.554011
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


if __name__ == '__main__':
    test_SunOSVirtual()
    test_case_0()

# Generated at 2022-06-25 01:32:12.780259
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual('module')
    sun_o_s_virtual_0.module.params = dict()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, "", ""))
    os.path.isdir = MagicMock(return_value=True)
    os.path.exists = MagicMock(return_value=False)

    sun_o_s_virtual_0.get_virtual_facts()
    if os.path.exists.call_count == 2:
        print("True")
    else:
        print("False")


# Generated at 2022-06-25 01:32:16.611596
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    assert virtual_facts != None
    assert virtual_facts == {}



# Generated at 2022-06-25 01:32:26.938256
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    '''Test the get_virtual_facts method of SunOSVirtual class'''

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = sun_o_s_virtual_collector_0.collect()

    # Assert of the values of the virtual facts dictionary returned by
    # the get_virtual_facts method
    # assert method _get_virtual_facts() == {}
    # assert method _get_virtual_facts() == {u'container': u'zone', u'virtualization_type': u'kvm', u'virtualization_role': u'guest', u'virtualization_tech_host': set([]), u'virtualization_tech_guest': set([u'kvm'])}
    # assert method _get_virtual_facts() == {}
   

# Generated at 2022-06-25 01:32:29.737752
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:32:31.477832
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:32:32.571751
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()



# Generated at 2022-06-25 01:32:37.857329
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:08.471732
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0._module = MagicMock()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    sun_o_s_virtual_0.module.get_bin_path = MagicMock(return_value='/bin/zonename')
    sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_0.module.get_bin_path.assert_any_call('zonename')


# Generated at 2022-06-25 01:35:10.285887
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = None
    sun_o_s_virtual_0.get_virtual_facts()

test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:35:17.118379
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Test basic case
   """
        Basic case 1:
    """

# Generated at 2022-06-25 01:35:19.815955
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    fact_result = sun_o_s_virtual_0.get_virtual_facts()
    assert fact_result is not None

# Generated at 2022-06-25 01:35:25.347151
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    # Tests if the member variable _fact_class is set to the correct value
    assert sun_o_s_virtual_collector._fact_class == SunOSVirtual
    # Tests if the member variable _platform is set to the correct value
    assert sun_o_s_virtual_collector._platform == 'SunOS'


# Generated at 2022-06-25 01:35:28.556463
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(dict())
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:34.687179
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = ansible_module_mock
    # We expect that the method get_virtual_facts of class SunOSVirtual will return a dictionary.
    assert isinstance(sun_o_s_virtual_0.get_virtual_facts(), dict)


# Generated at 2022-06-25 01:35:36.509068
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.get_virtual_facts() == {}
    assert sun_o_s_virtual_collector_0._platform == "SunOS"



# Generated at 2022-06-25 01:35:42.506724
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # Test if instance SunOSVirtualCollector was created successfully
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
    # Test if value of attribute _platform of instance sun_o_s_virtual_collector_0 is equal to 'SunOS'
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'

if __name__ == '__main__':
    test_case_0()

    print('All test cases for class SunOSVirtualCollector completed')

# Generated at 2022-06-25 01:35:48.148113
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    with open(u'./ansible/modules/facts/virtual/SunOSVirtual.get_virtual_facts.pkl', 'rb') as f:  pkl_data = f.read()
    sun_o_s_virtual_obj_0 = SunOSVirtual()
    sun_o_s_virtual_dict_0 = {}
    sun_o_s_virtual_dict_0['virtualization_tech_guest'] = set(['zone'])
    sun_o_s_virtual_dict_0['virtualization_tech_host'] = set()
    sun_o_s_virtual_dict_0['container'] = 'zone'
    sun_o_s_virtual_dict_0['virtualization_type'] = 'zone'
    sun_o_s_virtual_dict_0['virtualization_role'] = 'guest'
