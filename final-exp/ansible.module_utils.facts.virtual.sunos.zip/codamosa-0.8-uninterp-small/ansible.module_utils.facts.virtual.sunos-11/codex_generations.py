

# Generated at 2022-06-25 01:28:49.426419
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:28:52.229638
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual()
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    sun_o_s_virtual_0.module = module_0
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:28:57.175538
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_get_virtual_facts_0 = sun_o_s_virtual_0.get_virtual_facts()
    test=False
    if 'virtualization_type' in sun_o_s_virtual_get_virtual_facts_0:
        test=True
    assert test


# Generated at 2022-06-25 01:29:01.591934
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


if __name__ == '__main__':
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:29:03.628926
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:29:06.383964
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:07.910616
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Unit test class SunOSVirtual

# Generated at 2022-06-25 01:29:10.019856
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None

# Generated at 2022-06-25 01:29:11.303267
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:29:14.063550
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_2 = SunOSVirtual()
    sun_o_s_virtual_2.module = object()
    sun_o_s_virtual_2.get_virtual_facts()

# Generated at 2022-06-25 01:29:36.719670
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()
    guest_tech.add('zone')
    guest_tech.add('zone')
    guest_tech.add('zone')
    guest_tech.add('zone')
    guest_tech.add('zone')
    guest_tech.add('zone')
    guest_tech.add('zone')
    expected_virtual_facts = {'container': 'zone',
                              'virtualization_tech_guest': guest_tech,
                              'virtualization_tech_host': host_tech}
    module = {'run_command': fake_run_command}
    sun_o_s_virtual_0 = SunOSVirtual(module=module)
    assert sun_o_s_virtual_0.get_virtual_facts() == expected_virtual_facts


# Generated at 2022-06-25 01:29:45.358984
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({},{},{},{})
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    if len(virtual_facts) != 0 and len(virtual_facts['virtualization_tech_guest']) != 0 and len(virtual_facts['virtualization_tech_host']) != 0 and virtual_facts['virtualization_tech_guest'][0] == 'zone' and virtual_facts['virtualization_tech_host'][0] == 'zone':
        sun_o_s_virtual_0 = SunOSVirtual({},{},{},{})

# Generated at 2022-06-25 01:29:49.177270
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sunos_virtual = SunOSVirtual()
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts


# Generated at 2022-06-25 01:29:55.244574
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == "SunOS"
    assert virtual_collector._fact_class != "SunOSVirtual"
    assert virtual_collector._fact_class == sun_o_s_virtual_collector_0._fact_class



# Generated at 2022-06-25 01:29:57.584934
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None


# Generated at 2022-06-25 01:30:06.781866
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = mock_module_0()
    sun_o_s_virtual_0.zone = mock_zone_0()

    value = sun_o_s_virtual_0.get_virtual_facts()
    assert value == {'virtualization_role': 'guest', 'virtualization_type': 'vmware', 'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set(['zone'])}



# Generated at 2022-06-25 01:30:10.649781
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    setattr(sun_o_s_virtual_0, 'module', True)
    print(sun_o_s_virtual_0.get_virtual_facts())


# Generated at 2022-06-25 01:30:16.195197
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0._platform, str)
    assert isinstance(sun_o_s_virtual_collector_0.facts, dict)
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual)


# Generated at 2022-06-25 01:30:16.994271
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:30:21.190379
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:30:51.223082
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_get_virtual_facts_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert (sun_o_s_virtual_get_virtual_facts_0 is None)


# Generated at 2022-06-25 01:30:54.128081
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:30:55.156607
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()



# Generated at 2022-06-25 01:30:59.809713
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:31:04.376961
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._fact_class._platform == 'SunOS'


# Generated at 2022-06-25 01:31:06.207724
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    sun_o_s_virtual_0 = SunOSVirtual()

    sun_o_s_virtual_0.module = MockModule()

    # Attempt to return a dictionary of facts
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:31:06.960857
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Unit test

# Generated at 2022-06-25 01:31:08.637145
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_os_virtual_collector = SunOSVirtualCollector()
    assert sun_os_virtual_collector

# Generated at 2022-06-25 01:31:10.823818
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None
    assert sun_o_s_virtual_collector._platform == 'SunOS'


# Generated at 2022-06-25 01:31:15.473412
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual({})


# Generated at 2022-06-25 01:32:18.106544
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    expected_virtual_facts = {
        "container": "zone",
        "virtualization_type": "vmware",
        "virtualization_role": "guest",
        "virtualization_tech_guest": set(["vmware", "zone"]),
        "virtualization_tech_host": set(["zone"])
    }
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-25 01:32:19.379273
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0


# Generated at 2022-06-25 01:32:23.708336
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-25 01:32:26.296452
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:32:27.369951
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    a = SunOSVirtual()
    a.get_virtual_facts()


# Generated at 2022-06-25 01:32:30.603858
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual({})
    assert sun_o_s_virtual.get_virtual_facts() is not None



# Generated at 2022-06-25 01:32:31.346548
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:32:32.429585
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:32:37.410241
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    return sun_o_s_virtual_0


# Generated at 2022-06-25 01:32:40.361621
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # unit test for method get_virtual_facts of class SunOSVirtual
    sun_o_s_virtual_0 = SunOSVirtual()

    # virtual_facts = get_virtual_facts()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()


# Test module SunOSVirtual

# Generated at 2022-06-25 01:35:01.499677
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector, VirtualCollector)


# Generated at 2022-06-25 01:35:07.718732
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual

# Generated at 2022-06-25 01:35:12.112056
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sunos_virtual = SunOSVirtual()
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-25 01:35:13.465761
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:35:17.877155
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:35:23.234986
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Init the instance of class SunOSVirtual
    sun_o_s_virtual_0 = SunOSVirtual({})
    # Call the method get_virtual_facts of class SunOSVirtual with param sun_o_s_virtual_0
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:35:27.900110
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    if not isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual):
        raise Exception('Failed to create SunOSVirtualCollector object, _fact_class not set to SunOSVirtual')


# Generated at 2022-06-25 01:35:28.609403
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:35:29.897193
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:36.110543
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
    assert isinstance(sun_o_s_virtual_collector_0.fact_class, SunOSVirtual)
