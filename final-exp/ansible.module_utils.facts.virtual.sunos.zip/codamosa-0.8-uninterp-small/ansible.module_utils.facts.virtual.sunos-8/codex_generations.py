

# Generated at 2022-06-25 01:28:46.260219
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:28:49.275873
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:28:50.988842
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:28:55.975890
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # Tests if _fact_class is set to SunOSVirtual
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    # Tests if _platform is set to SunOS
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:28:56.862635
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:28:58.956759
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_0 = SunOSVirtual({})


# Generated at 2022-06-25 01:29:01.196918
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    assert isinstance(sun_o_s_virtual.get_virtual_facts(), dict)

# Generated at 2022-06-25 01:29:03.582843
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_os_virtual = SunOSVirtual()
    assert sun_os_virtual != None


# Generated at 2022-06-25 01:29:08.033009
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    dict_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert dict_0 == {'virtualization_type': 'zone'}


# Generated at 2022-06-25 01:29:10.028190
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector), "Constructor of class SunOSVirtualCollector did not return an instance."


# Generated at 2022-06-25 01:29:24.210192
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

    return

# Generated at 2022-06-25 01:29:25.813476
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    assert sun_o_s_virtual.get_virtual_facts() == {}

# Generated at 2022-06-25 01:29:28.884960
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # AssertionError: {} != {'virtualization_type': 'vmware', 'virtualization_role': 'guest'}
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_type': 'vmware', 'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:29:34.067319
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    sun_o_s_virtual_collector.populate()
    assert(sun_o_s_virtual_collector.platform == 'SunOS')
    assert('virtualization_type' in sun_o_s_virtual_collector.virtual)


# Generated at 2022-06-25 01:29:35.184770
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:40.747437
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual(module=None)
    sun_o_s_virtual_get_virtual_facts = sun_o_s_virtual.get_virtual_facts()
    assert sun_o_s_virtual_get_virtual_facts['virtualization_tech_host'] == set()
    assert sun_o_s_virtual_get_virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-25 01:29:41.870645
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_0 = SunOSVirtual()
    virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:44.133524
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_fact_0 = SunOSVirtual()

if __name__ == '__main__':
    test_SunOSVirtual()

# Generated at 2022-06-25 01:29:53.238189
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
    assert isinstance(sun_o_s_virtual_collector_0._platform, str)
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._fallback_finder_class == None


# Generated at 2022-06-25 01:29:54.822341
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:30:22.385694
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(arg_0)

# test_SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:23.420470
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:30:24.993197
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:30:28.699580
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:30:35.014732
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(
        module=AnsibleModuleFake(
            dict(), dict()
        )
    )
    virtual_facts_expected = dict()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    assertEquals(virtual_facts, virtual_facts_expected)


# Generated at 2022-06-25 01:30:39.303628
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Instantiate a instance of class SunOSVirtual
    sun_o_s_virtual_0 = SunOSVirtual()

    # Test member variable virtualization_type:
    sun_o_s_virtual_0.virtualization_type
    # Test member variable virtualization_role:
    sun_o_s_virtual_0.virtualization_role
    # Test member variable container:
    sun_o_s_virtual_0.container
    # Test member variable virtualization_tech_guest:
    sun_o_s_virtual_0.virtualization_tech_guest
    # Test member variable virtualization_tech_host:
    sun_o_s_virtual_0.virtualization_tech_host
    # Test member method get_virtual_facts:
    sun_o_s_virtual_0.get_virtual_facts()

#

# Generated at 2022-06-25 01:30:40.346605
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:41.768483
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    print(SunOSVirtual.get_virtual_facts(SunOSVirtual()))

# Generated at 2022-06-25 01:30:43.976470
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    sun_o_s_virtual_0 = SunOSVirtual(
        module='module_0'
    )

    assert sun_o_s_virtual_0.platform == 'SunOS'



# Generated at 2022-06-25 01:30:49.465892
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    virtual_facts = sun_o_s_virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)


# Generated at 2022-06-25 01:31:48.953994
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:31:50.821529
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == virtual_facts


# Generated at 2022-06-25 01:31:52.790655
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    result = sun_o_s_virtual_0.get_virtual_facts()
    assert (result is None)


# Generated at 2022-06-25 01:31:58.189187
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector, SunOSVirtualCollector) and (sun_o_s_virtual_collector.__class__ is SunOSVirtualCollector)


# Generated at 2022-06-25 01:32:06.249194
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    print('Testing method get_virtual_facts of class SunOSVirtual')
    sun_o_s_virtual_0 = SunOSVirtual()
    dict_of_output_4 = sun_o_s_virtual_0.get_virtual_facts()
    assert isinstance(dict_of_output_4, dict)

if __name__ == "__main__":
    test_case_0()
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:32:07.359615
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_os_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:32:09.042721
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Make an instance of class SunOSVirtualCollector
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:32:12.882320
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Define a test case mapping of inputs to expected outputs
    sun_o_s_virtual_0 = SunOSVirtual()
    # Run the method against the test data
    assert 'virtualization_role' in sun_o_s_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:14.391627
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:32:17.414207
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector();
    assert sun_o_s_virtual_collector._fact_class == SunOSVirtual, 'AssertionError: 1'
    assert sun_o_s_virtual_collector._platform == 'SunOS', 'AssertionError: 2'


# Generated at 2022-06-25 01:34:38.040239
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0, {})
    data = {'kvm': set(['kvm']), 'xen': set(['xen']), 'container': 'zone', 'vmware': set(['vmware']), 'virtualization_type': 'vmware', 'virtualization_role': 'guest'}
    assert sun_o_s_virtual_0.get_virtual_facts() == data

# POC

# Generated at 2022-06-25 01:34:39.215159
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:34:44.535917
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Case 0
    try:
        test_case_0()
    except:
        # This case failed!
        pass
    else:
        # This case passed!
        pass

# Generated at 2022-06-25 01:34:47.795610
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'container': 'zone', 'virtualization_type': 'vmware', 'virtualization_tech_guest': {'zone', 'vmware'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:34:48.758613
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:34:50.795070
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test class constructor:
    def test_SunOSVirtualCollector():
        sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:34:51.807907
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:34:56.549311
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    os_virtual = SunOSVirtual()
    os_virtual_facts = os_virtual.get_virtual_facts()
    if "virtualization_type" in os_virtual_facts:
        if os_virtual_facts["virtualization_type"] != "":
            print("method get_virtual_facts of class SunOSVirtual ran sucessfully")

# Generated at 2022-06-25 01:34:58.034544
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

    assert sun_o_s_virtual_0.get_virtual_facts() == {}



# Generated at 2022-06-25 01:35:00.563987
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
