

# Generated at 2022-06-25 01:28:49.308273
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:28:56.836796
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=("0", "global", ""))
    sun_o_s_virtual_0.module.get_bin_path = MagicMock(return_value="/usr/bin/zonename")
    sun_o_s_virtual_0.module.params = {'gather_subset': '!all,!min'}
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:01.634163
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_1)
    assert sun_o_s_virtual_0.platform == 'SunOS'



# Generated at 2022-06-25 01:29:10.715498
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-25 01:29:13.222925
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    try:
        test_case_0()
    except Exception as err:
        print("Test case 0 failed - exception: %s" % err)


# Generated at 2022-06-25 01:29:17.243219
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_collector_0._fact_class == sun_o_s_virtual_0
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:29:24.657363
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    if sun_o_s_virtual_collector_0.platform != 'SunOS':
        raise Exception('setting of "platform" property of class "SunOSVirtualCollector" failed')
    if sun_o_s_virtual_collector_0._fact_class.platform != 'SunOS':
        raise Exception('setting of "_fact_class" property of class "SunOSVirtualCollector" failed')
    if sun_o_s_virtual_collector_0._collect_facter_facts() != 1:
        raise Exception('return value of "_collect_facter_facts" function of class "SunOSVirtualCollector" failed')

# Generated at 2022-06-25 01:29:32.186647
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_instance = SunOSVirtual()
    if not sun_o_s_virtual_instance._platform == 'SunOS':
        raise Exception("Expected platform name %s, got %s" % (sun_o_s_virtual_instance._platform, 'SunOS'))
    virtual_facts_dictionary = sun_o_s_virtual_instance.get_virtual_facts();
    # TODO - Assert actual value to expected value
    assert True, "No assertion"
# End of unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-25 01:29:35.642373
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() is None

if __name__ == "__main__":
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:29:36.463291
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert True



# Generated at 2022-06-25 01:29:52.120596
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:52.975102
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert False



# Generated at 2022-06-25 01:29:56.971182
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict())
    var_0 = sun_o_s_virtual_collector_0.platform
    var_1 = sun_o_s_virtual_collector_0._fact_class
    var_2 = sun_o_s_virtual_collector_0.collect()


# Generated at 2022-06-25 01:30:01.512557
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'container': None, 'virtualization_type': None, 'vitualization_role': None}


# Generated at 2022-06-25 01:30:04.642869
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 is None


# Generated at 2022-06-25 01:30:11.723740
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # assert that the SunOSVirtualCollector object sun_o_s_virtual_collector_0 is not None
    assert sun_o_s_virtual_collector_0 is not None
    # assert that the SunOSVirtualCollector object sun_o_s_virtual_collector_0 is an instance of SunOSVirtualCollector
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)


# Generated at 2022-06-25 01:30:16.063071
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:21.221193
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    var_1 = sun_o_s_virtual_collector_0.platform()
    var_2 = sun_o_s_virtual_collector_0.get_all()
    sun_o_s_virtual_0 = SunOSVirtual(b'')
    var_3 = sun_o_s_virtual_collector_0.collect(sun_o_s_virtual_0)

if __name__ == '__main__':
    test_SunOSVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:30:24.268414
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\xe4\xcd\xef\xc1'
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(bytes_0)
    var_0 = sun_o_s_virtual_collector_0.is_it_virtual()
    assert var_0 == True


# Generated at 2022-06-25 01:30:28.632432
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)


# Generated at 2022-06-25 01:30:55.868202
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:31:02.361034
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\x1c\xbe\x01'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    assert sun_o_s_virtual_0._platform == 'SunOS'
    assert sun_o_s_virtual_0._fact_class == SunOSVirtual



# Generated at 2022-06-25 01:31:10.723701
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xca\x89\xec\x9e\xf1\x92\xbd\xb3\xfb\x08\xab\xe9\xe9R'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    assert sun_o_s_virtual_0._res == {}
    assert sun_o_s_virtual_0._module == None


# Generated at 2022-06-25 01:31:17.039706
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import module_utils.facts.virtual
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:31:19.832357
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9b\x9c\xb1'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == dict()


# Generated at 2022-06-25 01:31:21.391836
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_SunOSVirtualCollector_0()


# Generated at 2022-06-25 01:31:23.834699
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 is True



# Generated at 2022-06-25 01:31:29.572459
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:31:31.923203
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xe6\xab\xd1\xc7'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:41.888943
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    list_0 = ['zone']
    set_0 = set(list_0)
    set_1 = frozenset(['vmware'])
    dict_0 = {'virtualization_role': 'guest', 'virtualization_type': 'vmware', 'virtualization_tech_host': set_0, 'container': 'zone', 'virtualization_tech_guest': set_1}
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == dict_0

# Generated at 2022-06-25 01:32:32.756830
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = str(sun_o_s_virtual_0)
    assert var_0 == 'SunOSVirtual(None)'


# Generated at 2022-06-25 01:32:37.819733
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    var_0 = SunOSVirtual()
    var_1 = var_0.get_virtual_facts()
    assert var_1 == None

# --------------------------------------------------------------------------------

# Generated at 2022-06-25 01:32:44.555937
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xbc\x98\xdd\x1a'
    bytes_1 = b'\x9f8\xdb\x89'
    bytes_2 = b'@\x8a\x18\x9c\xb9\xe6R\x1e\x0e\xd6\x8f\x0e\xa1{'
    bytes_3 = b'\xab\xe6\x11\x17\x95\xff\xa7+\xee\x9b\xb2\x0f'
    bytes_4 = b'B\x8f\x0e\xa1{'

# Generated at 2022-06-25 01:32:52.660029
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    arg_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(arg_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    var_1 = {'virtualization_role': 'guest', 'virtualization_type': 'virtualbox'}
    assert var_0 == var_1

# Generated at 2022-06-25 01:32:53.236682
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Run test case
    test_case_0()

# Generated at 2022-06-25 01:33:02.795226
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x80\xec\xf1\xaf\xe2\xb2\xa8\x81\x16\x0c\x8f\xdd\xa4\xe1\xbb'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    var_1 = sun_o_s_virtual_0.get_virtual_facts()
    var_2 = sun_o_s_virtual_0.get_virtual_facts()
    var_3 = sun_o_s_virtual_0.get_virtual_facts()
    var_4 = sun_o_s_virtual_0.get_virtual_facts()
    var_5 = sun_o_s_virtual_

# Generated at 2022-06-25 01:33:07.346838
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    result_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert dict == type(result_0)

# Generated at 2022-06-25 01:33:09.965898
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    var_1 = SunOSVirtualCollector()
    return var_1

if __name__ == "__main__":
    test_case_0()
    obj = test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:33:14.207920
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Given
    pass

    # When
    bytes_0 = b'\xf9\xb9U\x12'
    sun_os_virtual_collector_0 = SunOSVirtualCollector(bytes_0)

    # Then
    assert sun_os_virtual_collector_0, "Argument \"sun_os_virtual_collector_0\" was not defined, but a class instance was expected."


# Generated at 2022-06-25 01:33:14.992411
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 01:35:30.698516
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    assert sun_o_s_virtual_0 is not None
    assert sun_o_s_virtual_0.module is bytes_0
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:35:36.725896
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert (var_0 == None)

# Generated at 2022-06-25 01:35:38.651896
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # No error expected
    try:
        SunOSVirtual("bytes_0")
    except Exception:
        assert False, "Unexpected error raised"


# Generated at 2022-06-25 01:35:40.039480
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_SunOSVirtualCollector_0()


# Generated at 2022-06-25 01:35:41.751240
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\xf9\xb9U\x12'
    SunOSVirtual(bytes_0)


# Generated at 2022-06-25 01:35:51.644406
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x93\x0b\x89\x8d\x9b\xb3\x1b\x80'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, b'\xb9\x1b\x1e\xae\xea\x97\xfa\xc7\x8b\x9b\xed\x0b\x1d', b''))
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:35:56.309002
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x05\x10\x9a\x1c'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    assert sun_o_s_virtual_0.get_virtual_facts() == None #


# Generated at 2022-06-25 01:36:00.377550
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\x99\xf2\x1c\xfc'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:36:02.055673
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:36:03.791434
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\xf9\xb9U\x12'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()