

# Generated at 2022-06-25 01:28:48.910244
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)


# Generated at 2022-06-25 01:28:51.889954
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)


# Generated at 2022-06-25 01:28:54.821010
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'

# Generated at 2022-06-25 01:29:00.507321
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    sun_o_s_virtual_0.get_virtual_facts()
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:01.460675
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:29:05.374931
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    assert sun_o_s_virtual_0
    assert isinstance(sun_o_s_virtual_0, SunOSVirtual)


# Generated at 2022-06-25 01:29:07.317053
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual({})
    assert sun_o_s_virtual_0.data == {}


# Generated at 2022-06-25 01:29:10.078410
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    assert sun_o_s_virtual_0.get_virtual_facts() == None


# Generated at 2022-06-25 01:29:10.998059
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
   test_case_0()

# Generated at 2022-06-25 01:29:12.322758
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:25.494383
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:27.029981
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    print(obj)

# Generated at 2022-06-25 01:29:27.483715
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert False



# Generated at 2022-06-25 01:29:31.215802
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:34.419430
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.collect() is None, "Fail"


# Generated at 2022-06-25 01:29:41.092976
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = sun_o_s_virtual_collector_0.collect()
    var_0 = {}
    if var_0 != dict_0:
        print('result = {}'.format(dict_0))
        raise AssertionError('test_SunOSVirtualCollector: result = {}'.format(dict_0))

if __name__ == "__main__":
    test_case_0()
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:44.017215
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:29:48.407920
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)

# Generated at 2022-06-25 01:29:52.453144
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fact_class = SunOSVirtual
    platform = 'SunOS'
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(fact_class, platform)

# vim: set et:
# vi: set sts=4:
# vi: set ts=4:

# Generated at 2022-06-25 01:29:53.142090
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_case_0()


# Generated at 2022-06-25 01:30:18.325607
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:30:21.824713
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    if is_SunOSVirtual() == True:
        test_case_0()



# Generated at 2022-06-25 01:30:24.380641
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Test with a dict
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == {}



# Generated at 2022-06-25 01:30:27.953652
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:29.824601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)

# Generated at 2022-06-25 01:30:35.498924
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert(var_0 == {})


# Generated at 2022-06-25 01:30:39.662758
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)
    var_0 = sun_o_s_virtual_collector_0._platform
    var_1 = sun_o_s_virtual_collector_0._fact_class

# Generated at 2022-06-25 01:30:42.293176
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'container' in var_0

# Generated at 2022-06-25 01:30:45.269045
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    var_1 = SunOSVirtualCollector()
    assert isinstance(var_1, VirtualCollector)
    assert isinstance(var_1, SunOSVirtualCollector)
    assert var_1._fact_class is SunOSVirtual

# Generated at 2022-06-25 01:30:48.625715
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert type(SunOSVirtualCollector) == type

# Generated at 2022-06-25 01:31:52.904800
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:31:58.521579
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_0.module.run_command("/usr/sbin/virtinfo -p")
    sun_o_s_virtual_0.module.run_command("/usr/sbin/virtinfo -p")
    sun_o_s_virtual_0.module.run_command("/usr/sbin/virtinfo -p")
    sun_o_s_virtual_0.module.run_command("/usr/sbin/virtinfo -p")
    sun_o_s_virtual_0.module.run_command("/usr/sbin/virtinfo -p")
    sun_o_

# Generated at 2022-06-25 01:32:00.376284
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == None


# Generated at 2022-06-25 01:32:02.982668
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:32:05.724208
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_1 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:32:08.052942
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:32:08.950292
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:32:12.807307
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS', "there is some error in SunOSVirtualCollector class constructor"
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual, "there is some error in SunOSVirtualCollector class constructor"


# Generated at 2022-06-25 01:32:17.441284
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:32:22.155915
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:34:55.728940
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_1 = {}
    sun_o_s_virtual_1 = SunOSVirtual(dict_1)
    sun_o_s_virtual_1.module.run_command = MagicMock(return_value=(0, 'global', ''))
    sun_o_s_virtual_1.module.get_bin_path = MagicMock(return_value='/usr/bin/zonename')
    sun_o_s_virtual_1.os.path.isdir = MagicMock(return_value=False)
    sun_o_s_virtual_1.os.path.exists = MagicMock(return_value=True)
    sun_o_s_virtual_1.module.get_bin_path = Mock(side_effect=['/usr/bin/modinfo', '/usr/bin/virtinfo', None])


# Generated at 2022-06-25 01:34:57.178263
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    test_case_0()

test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:35:00.564113
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)

# Generated at 2022-06-25 01:35:02.456773
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == {}


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:35:06.993719
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0)

# Generated at 2022-06-25 01:35:09.094109
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == None

# Generated at 2022-06-25 01:35:13.372435
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert True


# Generated at 2022-06-25 01:35:19.449292
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    sun_o_s_virtual_0 = SunOSVirtual(dict_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:35:22.614795
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor test
    """
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()



# Generated at 2022-06-25 01:35:23.962754
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
