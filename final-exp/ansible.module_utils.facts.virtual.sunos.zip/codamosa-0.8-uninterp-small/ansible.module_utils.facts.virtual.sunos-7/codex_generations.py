

# Generated at 2022-06-25 01:28:51.049629
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    test_SunOSVirtual = SunOSVirtual(None)

# Generated at 2022-06-25 01:28:52.535181
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_o_s_sun = SunOSVirtual()
    assert virtual_o_s_sun

# Generated at 2022-06-25 01:28:54.127871
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:28:56.234312
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtual()

# Generated at 2022-06-25 01:29:01.809345
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Test with no facts present
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.exit_json(changed=False)

    # Test with facts present
    sun_o_s_virtual_1 = SunOSVirtual()
    sun_o_s_virtual_1.module.exit_json(changed=False)

# Generated at 2022-06-25 01:29:03.852298
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:06.459326
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:15.324429
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    test_value_0 = sun_o_s_virtual_0.get_virtual_facts()
    del sun_o_s_virtual_0
    sun_o_s_virtual_0 = SunOSVirtual()
    test_value_1 = sun_o_s_virtual_0.get_virtual_facts()
    del sun_o_s_virtual_0
    sun_o_s_virtual_0 = SunOSVirtual()
    test_value_2 = sun_o_s_virtual_0.get_virtual_facts()
    del sun_o_s_virtual_0
    sun_o_s_virtual_0 = SunOSVirtual()
    test_value_3 = sun_o_s_virtual_0.get_virtual_facts()
    del sun

# Generated at 2022-06-25 01:29:18.932478
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

    assert(not hasattr(sun_o_s_virtual_collector_0, '_fact_class'))
    assert(not hasattr(sun_o_s_virtual_collector_0, '_platform'))


# Generated at 2022-06-25 01:29:23.319251
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.virtualization_type == 'zone'
    assert sun_o_s_virtual_0.virtualization_role == 'guest'
    assert sun_o_s_virtual_0.get_virtual_facts() == {'container': 'zone',
                                                     'virtualization_role': 'guest',
                                                     'virtualization_tech_host': set(),
                                                     'virtualization_tech_guest': {'zone'},
                                                     'virtualization_type': 'zone'}
    assert sun_o_s_virtual_0.platform == 'SunOS'
    assert sun_o_s_virtual_0.is_sun_solaris



# Generated at 2022-06-25 01:29:42.450411
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_os_virtual_0 = SunOSVirtual()
    virtual_facts = sun_os_virtual_0.get_virtual_facts()
    print("virtual_facts\n")
    print(virtual_facts)


# Generated at 2022-06-25 01:29:46.754499
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
# Instantiation of class SunOSVirtual using default arguments
sun_o_s_virtual_0 = SunOSVirtual()
# Assignment of attribute "platform" of object "sun_o_s_virtual_0"
sun_o_s_virtual_0.platform = 'SunOS'
# Instantiation of class SunOSVirtual using default arguments
sun_o_s_virtual_1 = SunOSVirtual()


# Generated at 2022-06-25 01:29:47.521012
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:54.361323
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    sun_o_s_virtual._module = FakeAnsibleModule()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual._module.run_command = FakeRunCommand(sun_o_s_virtual_collector_0)
    sun_o_s_virtual_collector_0.module.get_bin_path = FakeGetBinPath(sun_o_s_virtual_collector_0)
    sun_o_s_virtual_collector_0.os.path.isdir = FakeOsPathIsdir(sun_o_s_virtual_collector_0)

# Generated at 2022-06-25 01:29:56.314783
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:30:00.239086
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None


# Generated at 2022-06-25 01:30:01.502960
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:02.404103
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:05.794138
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:07.133793
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()



# Generated at 2022-06-25 01:30:33.753164
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:36.096942
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    sun_o_s_virtual_collector.get_all_facts()

# Generated at 2022-06-25 01:30:38.124719
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:30:40.007674
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    result = sun_o_s_virtual_0.get_virtual_facts()
    assert result is None


# Generated at 2022-06-25 01:30:42.037254
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:43.115408
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:52.244649
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_1 = SunOSVirtual()
    assert sun_o_s_virtual_1.platform == 'SunOS'

# verifies that container value is set to zone when the host is a solaris 10 branded zone
# verifies that the virtualization_role is set to guest when the host is a solaris 10 branded zone
# verifies that the virtualization_type is set to zone when the host is a solaris 10 branded zone
# verifies that the zonename returns "global" for the global zone
# verifies that the zonename returns a non-global zone name for non-global zones

# Generated at 2022-06-25 01:30:54.499690
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()


if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:30:59.370331
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:31:01.016049
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_os_virtual_0 = SunOSVirtual()
    sun_os_virtual_0._module

# Generated at 2022-06-25 01:32:06.579897
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.virtualization_type == None
    assert sun_o_s_virtual_0.virtualization_role == None
    assert sun_o_s_virtual_0.container == None
    assert sun_o_s_virtual_0.virtualization_tech_guest == None
    assert sun_o_s_virtual_0.virtualization_tech_host == None

# Generated at 2022-06-25 01:32:09.381009
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert (isinstance(sun_o_s_virtual_collector, SunOSVirtualCollector))
    assert (isinstance(sun_o_s_virtual_collector, VirtualCollector))


# Generated at 2022-06-25 01:32:14.495267
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = {}
    sun_o_s_virtual_0 = SunOSVirtual(module)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:16.328923
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    # sun_o_s_virtual_collector.get_all()


# Generated at 2022-06-25 01:32:21.658237
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
	if SunOSVirtualCollector.__name__ == 'SunOSVirtualCollector':
		test_case_0()
		assert True
	else:
		assert False


# Generated at 2022-06-25 01:32:25.015052
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_mock = SunOSVirtual()
    # In case of "getting" the value of a variable that doesn't exist, the function should return False.
    assert sun_o_s_virtual_mock.get_virtual_facts() == {}


# Generated at 2022-06-25 01:32:26.359316
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()



# Generated at 2022-06-25 01:32:28.037205
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_1 = SunOSVirtual()


# Generated at 2022-06-25 01:32:32.087853
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class is SunOSVirtual


# Generated at 2022-06-25 01:32:42.357169
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    sun_o_s_virtual_0.module = MagicMock()
    sun_o_s_virtual_0.module.run_command = MagicMock()
    sun_o_s_virtual_0.module.get_bin_path = MagicMock()
    sun_o_s_virtual_0.module.get_bin_path.return_value = '/usr/sbin/virtinfo'
    sun_o_s_virtual_0.module.run_command.return_value = (0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false\n', '')

# Generated at 2022-06-25 01:35:12.017437
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    result = sun_o_s_virtual_0.get_virtual_facts()
    assert result is None


# Generated at 2022-06-25 01:35:14.085581
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:35:20.071102
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = lambda *_, **__: (1, 'out', 'err')
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:35:29.305548
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = run_command
    sun_o_s_virtual_0.module.get_bin_path = get_bin_path
    sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_0.module.run_command = run_command_DOMAINROLE
    sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_0.module.run_command = run_command_DOMAINROLE_error
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:29.952306
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 01:35:30.897245
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:35:35.773956
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0 is not None


# Generated at 2022-06-25 01:35:41.823353
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = type('',(),{})()
    sun_o_s_virtual_0.module.run_command = type('',(),{'__call__': lambda self, arg1: (0,'','',)})()
    sun_o_s_virtual_0.module.get_bin_path = type('',(),{'__call__': lambda self, arg1: (0,'','',)})()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:35:44.373653
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual


# Generated at 2022-06-25 01:35:50.460472
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # VirtualCollector.__init__(self, fail_on_missing_platform=True)
    sun_o_s_virtual_collector_0.get_virtual_facts()