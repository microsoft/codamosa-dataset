

# Generated at 2022-06-25 01:28:45.331731
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:28:46.401002
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:28:49.781140
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert True

test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:28:51.925337
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:28:59.951810
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = MagicMock()
    sun_o_s_virtual_0.module.run_command = MagicMock()
    sun_o_s_virtual_0.module.run_command.return_value = (0, 'test', '')
    sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_virtual_0.module.run_command.assert_called_with('/usr/sbin/virtinfo', check_rc=False)

# Generated at 2022-06-25 01:29:03.810653
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'
    assert sun_o_s_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:29:14.257873
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    data = {
        'path_exists_glob': ['/usr/sbin/virtinfo', '/.SUNWnative/usr/sbin/virtinfo'],
        'command_exists': ['smbios', 'zonename', 'modinfo', 'virtinfo'],
        'run_command': [
            ('smbios', 0, 'VMware', ''),
            ('zonename', 0, 'global', ''),
            ('modinfo', 0, 'VirtualBox', ''),
            ('virtinfo -p', 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', '')
        ]
    }

    sun_o_s_virtual = SunOSVirtual(data)
    result = sun_o_s_virtual.get_virtual_facts()

    expected

# Generated at 2022-06-25 01:29:17.359773
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'
    assert sun_o_s_virtual_collector_0.fact_class == SunOSVirtual


# Generated at 2022-06-25 01:29:19.680103
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'


# Generated at 2022-06-25 01:29:24.251274
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(dict())


# Generated at 2022-06-25 01:29:42.890334
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert(sun_o_s_virtual_collector_0._platform == "SunOS")
    assert(sun_o_s_virtual_collector_0._fact_class._platform == "SunOS")


# Generated at 2022-06-25 01:29:45.101209
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:29:46.415872
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_os_virtual_0 = SunOSVirtual()
    assert sun_os_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:29:52.423681
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_type': 'virtualbox', 'virtualization_tech_guest': {'virtualbox', 'zone'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:30:00.149427
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = MockModule()
    sun_o_s_virtual_0.module.run_command = Mock(return_value=(0, '', ''))

    sun_o_s_virtual_0._get_virtual_facts()

    sun_o_s_virtual_0.module.run_command.assert_any_call('zonename')
    sun_o_s_virtual_0.module.run_command.assert_any_call('modinfo')
    sun_o_s_virtual_0.module.run_command.assert_any_call('virtinfo')
    sun_o_s_virtual_0.module.run_command.assert_any_call('smbios')


# Generated at 2022-06-25 01:30:01.441852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:08.880799
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'zone'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'virtualbox'
    }

# Generated at 2022-06-25 01:30:12.169341
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:14.263856
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0 is not None

# Generated at 2022-06-25 01:30:16.356809
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:41.968236
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(None)


# Generated at 2022-06-25 01:30:43.940478
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    result = sun_o_s_virtual_0.get_virtual_facts()
    assert result is None


# Generated at 2022-06-25 01:30:46.740904
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector() is not None


# Generated at 2022-06-25 01:30:50.703525
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'


# Generated at 2022-06-25 01:30:52.169433
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:54.686799
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(dict(module=None))
    sun_o_s_virtual_0.get_virtual_facts()

test_SunOSVirtual_get_virtual_facts()


# Generated at 2022-06-25 01:31:00.759910
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = sun_o_s_virtual_collector_0.collector()

# Generated at 2022-06-25 01:31:03.093914
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual_0 = SunOSVirtual()
    assert SunOSVirtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:31:04.746162
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:08.406148
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sunos_virtual_0 = SunOSVirtual()
    assert sunos_virtual_0.get_virtual_facts() is None

# Generated at 2022-06-25 01:32:08.595291
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    import sys
    import inspect
    from ansible.module_utils.facts.virtual.sunos.facts import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos.facts import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual



# Generated at 2022-06-25 01:32:10.155904
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None


# Generated at 2022-06-25 01:32:14.712878
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:20.432942
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_obj_0 = SunOSVirtual()
    # 
    # Build mocked module representing the current process
    module_obj_0 = MockModule()
    module_obj_0.params = dict()
    module_obj_0.run_command = MagicMock()

    # Create an instance of MagicMock to represent the return value
    # of get_bin_path().
    basic_0 = MagicMock()
    # Define the return value of get_bin_path().
    basic_0.return_value = '/usr/sbin/zonename'
    module_obj_0.get_bin_path = basic_0
    # Create an instance of MagicMock to represent the return value
    # of run_command().
    command_0 = MagicMock()
    # Define the return value of run

# Generated at 2022-06-25 01:32:24.684972
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:32:28.401874
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({}, None, None)
    setattr(sun_o_s_virtual_0, 'module', None)
    setattr(sun_o_s_virtual_0, 'facts', None)
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:32:30.763158
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:32:31.134540
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    pass

# Generated at 2022-06-25 01:32:31.957130
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:32:33.084420
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:46.790890
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = 3901
    float_0 = -5355.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:33:47.791380
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:56.206737
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = 1
    float_0 = 1.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    assert sun_o_s_virtual_0._name == 'SunOSVirtual'
    assert sun_o_s_virtual_0._platform == 'SunOS'
    assert sun_o_s_virtual_0.type is None
    assert sun_o_s_virtual_0.role is None


# Generated at 2022-06-25 01:34:01.152309
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = -1013
    float_0 = 1.26
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    assert sun_o_s_virtual_0 is not None
    int_0 = -1013
    float_0 = -1.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    assert sun_o_s_virtual_0 is not None
    int_0 = 3840
    float_0 = -1.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    assert sun_o_s_virtual_0 is not None
    int_0 = 3840
    float_0 = 12.0
    sun_o_s_virtual_0

# Generated at 2022-06-25 01:34:05.294381
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = 5986
    float_0 = -1013.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
# AssertionError: TypeError not raised


# Generated at 2022-06-25 01:34:14.141449
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    float_0 = float()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(float_0)
    sun_o_s_virtual_collector_0.collect()
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_1.collect()
    var_0 = sun_o_s_virtual_collector_0.get_all()
    sun_o_s_virtual_collector_1.populate()
    sun_o_s_virtual_collector_0.populate()
    sun_o_s_virtual_collector_0.populate()
    var_1 = sun_o_s_virtual_collector_0.get_all()

# Generated at 2022-06-25 01:34:15.966037
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = -131
    float_0 = -1219.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    assert sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:34:20.968182
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    mock_module_0 = magic_mock()
    mock_module_0._name = 'ansible_facts.hardware.virtual'
    mock_module_1 = magic_mock()
    mock_module_1._name = 'ansible_facts.system.virtual'
    mock_module_2 = magic_mock()
    mock_module_2._name = 'ansible_facts.virtualization'
    mock_module_2.run_command = mock_run_command
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(mock_module_0, mock_module_1, mock_module_2)
    sun_o_s_virtual_collector_0.collect()
#     sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
#     sun_

# Generated at 2022-06-25 01:34:22.686318
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = 5986
    float_0 = -1013.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    sun_o_s_virtual_1 = SunOSVirtual(float_0)


# Generated at 2022-06-25 01:34:28.572613
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 24406
    float_0 = 0.441722
    sun_o_s_virtual_0 = SunOSVirtual(int_0)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:36:42.634111
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    int_0 = 12063
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(int_0)
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'

# Generated at 2022-06-25 01:36:44.622308
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 9965
    float_0 = -27.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:36:47.532428
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_case_0()


# Generated at 2022-06-25 01:36:54.629634
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    print("")
    print("****************** Unit test method get_virtual_facts ******************")
    int_0 = 923
    float_0 = 98.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    sun_o_s_virtual_1 = SunOSVirtual(float_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    return

# Generated at 2022-06-25 01:36:55.964268
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    test_case_0()


# Generated at 2022-06-25 01:37:02.257454
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  int_0 = 226
  float_0 = -2.0
  sun_o_s_virtual_collector_0 = SunOSVirtualCollector(int_0, float_0)
  sun_o_s_virtual_collector_0.collect()

test_SunOSVirtualCollector()
test_case_0()

# Generated at 2022-06-25 01:37:04.138868
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = -849
    float_0 = -584.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    int_1 = -2896
    sun_o_s_virtual_1 = SunOSVirtual(int_1)


# Generated at 2022-06-25 01:37:12.185852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos.SunOSVirtualCollector import SunOSVirtualCollector
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(1, 1.0)

if __name__ == '__main__':
    test_SunOSVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:37:19.738624
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 5986
    float_0 = -1013.0
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)
    sun_o_s_virtual_1 = SunOSVirtual(float_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    # Get the module to test method
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    var_1 = sun_o_s_virtual_collector_0.collect()

# Generated at 2022-06-25 01:37:22.540913
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 7124
    float_0 = -3177.0
    sun_o_s_virtual_1 = SunOSVirtual(int_0, float_0)
    var_0 = sun_o_s_virtual_1.get_virtual_facts()
    assert var_0 == 'virtualization_tech_host'
