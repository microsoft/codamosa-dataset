

# Generated at 2022-06-25 01:28:51.863628
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:54.139912
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0._get_virtual_facts()

# Generated at 2022-06-25 01:28:58.247968
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert not sun_o_s_virtual_collector_1.__dict__
    assert sun_o_s_virtual_collector_1.__dict__.keys() == []
    assert sun_o_s_virtual_collector_1._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_1._platform == 'SunOS'
    assert not sun_o_s_virtual_collector_1.name

test_case_0()
test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:00.879027
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.virtualization_type == 'vmware'


# Generated at 2022-06-25 01:29:10.248908
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-25 01:29:12.222618
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0 is not None


# Generated at 2022-06-25 01:29:20.463883
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # Check if __init__ of class ModuleStore was called
    var_sun_o_s_virtual_collector_0_obj_ref = sun_o_s_virtual_collector_0.get_module_store()
    var_module_store_0 = ModuleStore()
    assert var_sun_o_s_virtual_collector_0_obj_ref == var_module_store_0, \
        'Expected equality but got:' + var_sun_o_s_virtual_collector_0_obj_ref.__repr__() + ' ' + \
        var_module_store_0.__repr__()

    # Check if __init__ of class SunOSVirtualCollector was called
    var_sun_o_s_

# Generated at 2022-06-25 01:29:22.893541
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(['test'])
    # Check that SunOSVirtual._platform was set
    assert sun_o_s_virtual_0._platform == 'SunOS'



# Generated at 2022-06-25 01:29:29.405005
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Test for 'SunOS' platform
    sun_os_virtual_0 = SunOSVirtual()
    sun_os_virtual_1 = SunOSVirtual()
    sun_os_virtual_2 = SunOSVirtual()
    sun_os_virtual_3 = SunOSVirtual()
    sun_os_virtual_4 = SunOSVirtual()
    sun_os_virtual_5 = SunOSVirtual()
    sun_os_virtual_6 = SunOSVirtual()
    sun_os_virtual_7 = SunOSVirtual()
    sun_os_virtual_8 = SunOSVirtual()
    sun_os_virtual_9 = SunOSVirtual()
    sun_os_virtual_10 = SunOSVirtual()
    sun_os_virtual_11 = SunOSVirtual()
    sun_os_virtual_12 = SunOSVirtual()
    sun_os_virtual_

# Generated at 2022-06-25 01:29:31.259887
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(0)


# Generated at 2022-06-25 01:29:48.963724
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:51.871481
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector, SunOSVirtualCollector)


# Generated at 2022-06-25 01:29:55.345150
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_get_virtual_facts_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:57.081732
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(module=0)


# Generated at 2022-06-25 01:29:58.510279
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:59.897968
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
	sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:03.692947
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = MockModule()
    sun_o_s_virtual_0.module.run_command = Mock(return_value=(0, '', ''))

    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()

    assert virtual_facts == {'container': 'zone', 'virtualization_type': 'zone'}


# Generated at 2022-06-25 01:30:06.461319
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:08.707406
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)
    assert sun_o_s_virtual_0.get_virtual_facts() == None

# Generated at 2022-06-25 01:30:12.435578
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:41.914135
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)

# Generated at 2022-06-25 01:30:43.866593
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:46.133172
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    print("Constructor")
    assert SunOSVirtualCollector()



# Generated at 2022-06-25 01:30:55.499788
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    ins = SunOSVirtual()

# Generated at 2022-06-25 01:30:59.853005
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()



# Generated at 2022-06-25 01:31:01.360503
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:31:03.093192
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:05.835120
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=AnsibleModuleMock())
    assert sun_o_s_virtual_0.get_virtual_facts() == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_type': 'vmware', 'virtualization_tech_guest': set(['zone', 'vmware']), 'virtualization_tech_host': set(['zone'])}


# Generated at 2022-06-25 01:31:11.594664
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # setup dummy data
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.myfact = MagicMock()
    sun_o_s_virtual_0.module = MagicMock()
    results = {}
    sun_o_s_virtual_0.module.run_command.return_value = [
        0, '', '']
    # execute test case
    sun_o_s_virtual_0.get_virtual_facts()
    # assert results


# Generated at 2022-06-25 01:31:15.529153
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:32:14.630791
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    result = isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)
    assert result is True


# Generated at 2022-06-25 01:32:15.677073
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:32:21.580692
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0 is not None

# Generated at 2022-06-25 01:32:23.563943
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:32:33.411729
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    c = SunOSVirtualCollector()
    s = c._fact_class()

    # xenfullvirt
    os.environ['PATH'] = os.path.join(os.path.dirname(__file__), '../../unittests/data/:/sbin:/usr/sbin')
    # zonename
    os.environ['PATH'] = os.path.join(os.path.dirname(__file__), '../../unittests/data/:/bin:/usr/bin')
    s.module.run_command = Fake_run_command

    # Testing with a xen full virtualization
    facts = s.get_virtual_facts()

# Generated at 2022-06-25 01:32:41.916722
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class.platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class.__class__.__name__ == 'SunOSVirtual'
    assert sun_o_s_virtual_collector_0._fact_class.__class__.__bases__[0].__name__ == 'Virtual'


# Generated at 2022-06-25 01:32:48.014958
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    os.environ['PATH'] = '/tmp'
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = MagicMock()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_virtual_0.get_virtual_facts()
    # Test command
    sun_o_s_virtual_0.module.run_command.assert_called_once_with(sun_o_s_virtual_0.module.get_bin_path('smbios'), run_in_check_mode=True)
    del os.environ['PATH']

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule

    module

# Generated at 2022-06-25 01:32:51.072086
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    res = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:54.661396
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_os_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:32:57.548337
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    try:
        sun_o_s_virtual_0.get_virtual_facts()
    except NameError:
        print("Exception")


# Generated at 2022-06-25 01:35:20.385820
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS', 'Expected SunOS'



# Generated at 2022-06-25 01:35:21.661420
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  try:
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
  except Exception as e:
    print('test_SunOSVirtualCollector() failed: ' + str(e))


# Generated at 2022-06-25 01:35:25.744538
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    #
    # Initiate SunOSVirtual object
    #
    sun_o_s_virtual = SunOSVirtual({"PATH": "/sbin:/bin:/usr/sbin:/usr/bin:/opt/sbin:/opt/bin"}, None)
    #
    # Get virtual facts
    #
    sun_o_s_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:35:27.199884
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    sun_o_s_virtual_0.container = 'zone'

    sun_o_s_virtual_0.get_virtual_facts()
# Unit test end


# Generated at 2022-06-25 01:35:34.792189
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()

# /**
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_test_test_test
#  * @testname test_test_test_

# Generated at 2022-06-25 01:35:38.287483
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_collector_0.parse(sun_o_s_virtual_0.get_virtual_facts())
    return sun_o_s_virtual_collector_0.data

# Generated at 2022-06-25 01:35:40.566030
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0 is not None


# Generated at 2022-06-25 01:35:43.914672
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.get_virtual_facts() == {
        'container': 'zone',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'zone'}}


# Generated at 2022-06-25 01:35:44.802002
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  assert isinstance(SunOSVirtualCollector, VirtualCollector)


# Generated at 2022-06-25 01:35:45.650635
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
