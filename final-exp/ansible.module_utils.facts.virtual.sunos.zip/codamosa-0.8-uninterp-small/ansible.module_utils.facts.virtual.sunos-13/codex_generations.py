

# Generated at 2022-06-25 01:28:56.251289
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 2800
    sun_o_s_virtual_0 = SunOSVirtual(int_0)
    sun_o_s_virtual_0.module = mock_module_0()
    sun_o_s_virtual_0._get_dmi_data = mock_get_dmi_data_0
    sun_o_s_virtual_0.module.run_command = mock_run_command_0
    dict_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:57.280427
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:04.219261
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 2800
    sun_o_s_virtual_0 = SunOSVirtual(int_0)
    sun_o_s_virtual_0.module.get_bin_path = lambda s0: ''
    sun_o_s_virtual_0.module.run_command = lambda s0: ['', '', 0]
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:12.091895
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector = SunOSVirtualCollector(check_sysfs=False)
    sun_o_s_virtual_collector.collect()
    facts = sun_o_s_virtual_collector.get_facts()
    v_facts = facts['ansible_facts']['ansible_virtualization_facts']
    v_facts_keys = v_facts.keys()

    for key in ('virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host'):
        assert key in v_facts_keys


# Generated at 2022-06-25 01:29:14.142998
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    int_0 = 2800
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(int_0)

# Generated at 2022-06-25 01:29:18.407492
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 2800
    sun_o_s_virtual_0 = SunOSVirtual(int_0)
    map_0 = sun_o_s_virtual_0.get_virtual_facts()
    set_0 = frozenset(['virtualbox'])
    str_0 = 'virtualization_tech_guest'
    assert map_0[str_0] == set_0


# Generated at 2022-06-25 01:29:21.309319
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    int_0 = 2800

    sun_o_s_virtual_0 = SunOSVirtual(int_0)
    str_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert str_0 == 'dummy_result'


# Generated at 2022-06-25 01:29:28.179921
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    print('Test constructor')
    sun_o_s_virtual = SunOSVirtual()
    assert sun_o_s_virtual is not None, 'Object is None'
    print('Test get_virtual_facts')
    assert sun_o_s_virtual.get_virtual_facts() is None, 'get_virtual_facts returns None'
    print('Test __str__')
    assert str(sun_o_s_virtual) is not None, 'String representation is None'
    print('Test __repr__')
    assert repr(sun_o_s_virtual) is not None, 'Repr is None'
    print('Test get_virtual_facts')
    assert sun_o_s_virtual.get_virtual_facts() is None, 'get_virtual_facts returns None'
    print('Test get_virtual_facts')
    assert sun

# Generated at 2022-06-25 01:29:30.611035
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = 2800
    sun_o_s_virtual_0 = SunOSVirtual(int_0)
    assert sun_o_s_virtual_0._module.check_mode is False
    assert sun_o_s_virtual_0._module.no_log is False
    assert sun_o_s_virtual_0._module.diff is False
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:29:33.516673
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 01:29:48.141652
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'
    assert sun_o_s_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:29:53.201772
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'zone' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-25 01:29:54.787574
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:58.632827
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, 'global', ''))
    assert sun_o_s_virtual_0.get_virtual_facts()['container'] == 'zone'


# Generated at 2022-06-25 01:29:59.748992
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:01.096483
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:06.731134
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_1 = SunOSVirtual()
    sun_o_s_virtual_1.module = "AnsibleModule"
    sun_o_s_virtual_2 = SunOSVirtual()
    sun_o_s_virtual_2.module = "AnsibleModule"
    sun_o_s_virtual_2.module.run_command = "run_command"
    sun_o_s_virtual_3 = SunOSVirtual()
    sun_o_s_virtual_3.module = "AnsibleModule"
    sun_o_s_virtual_3.module.run_command = "run_command"
    sun_o_s_virtual_3.module.run_command = "run_command"
    sun_o_s

# Generated at 2022-06-25 01:30:09.436658
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    facts = sun_o_s_virtual_0.get_virtual_facts()
    print(facts)

test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:30:12.979105
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'


# Generated at 2022-06-25 01:30:14.084227
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:39.387488
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # If a module is not available, ignore complain that the module is not available on SunOS
    # and check if we get None as return value
    sun_o_s_virtual_0.module.get_bin_path = lambda x: None
    assert sun_o_s_virtual_0.get_virtual_facts() is None
    sun_o_s_virtual_0.module.get_bin_path = lambda x: '/usr/sbin/prtconf'
    assert sun_o_s_virtual_0.get_virtual_facts() is None
    sun_o_s_virtual_0.module.get_bin_path = lambda x: '/usr/sbin/zoneadm'
    assert sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:40.866941
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:43.332358
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual({})
    assert sun_o_s_virtual_0.data['virtualization_tech_guest'] == set()
    assert sun_o_s_virtual_0.data['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:30:47.109743
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert isinstance(sun_o_s_virtual_0.get_virtual_facts(), dict)

# Generated at 2022-06-25 01:30:49.505718
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:30:51.202185
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'
    assert sun_o_s_virtual_0.container == 'zone'


# Generated at 2022-06-25 01:30:56.447903
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = MagicMock()
    sun_o_s_virtual_0.module.run_command.return_value = (0, '', '')
    sun_o_s_virtual_0.module.get_bin_path.return_value = '/usr/sbin/modinfo'
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:30:59.570483
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:31:06.812633
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_os_virtual_0 = SunOSVirtual()
    sun_os_virtual_0.supported_facts = ['virtualization_role', 'virtualization_type', 'virtualization_tech_host', 'virtualization_tech_guest', 'container']
    sun_os_virtual_0.module = MockModule()
    sun_os_virtual_0.module.run_command = Mock(return_value=(0, "", ""))
    sun_os_virtual_0._get_vmware_facts = Mock(return_value={'virtualization_type': 'vmware', 'virtualization_role': 'guest'})
    sun_os_virtual_0._get_parallels_facts = Mock(return_value={'virtualization_type': 'parallels', 'virtualization_role': 'guest'})
    sun_os_virtual_0

# Generated at 2022-06-25 01:31:11.439774
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)
    sun_o_s_virtual_0.facts = dict()
    sun_o_s_virtual_0._module = MagicMock(name='module')
    sun_o_s_virtual_0._module.get_bin_path.return_value = '/usr/foo/zonename'
    sun_o_s_virtual_0._module.run_command.return_value = 0, """zonename: global""", ''
    sun_o_s_virtual_0.get_virtual_facts()

    assert sun_o_s_virtual_0.facts['virtualization_tech_host'] == set(['zone'])
    assert sun_o_s_virtual_0.facts['virtualization_tech_guest'] == set([])
    assert sun

# Generated at 2022-06-25 01:31:50.365218
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector._platform == SunOS


# Generated at 2022-06-25 01:31:52.411343
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert virtual_facts_0 == {}


# Generated at 2022-06-25 01:31:53.939568
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0 != ''

# test get_virtual_facts method

# Generated at 2022-06-25 01:31:55.781611
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    s_u_n_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:31:56.843260
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:31:59.043688
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Setup
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = None
    # Exercise
    sun_o_s_virtual_0.get_virtual_facts()
    # Verify
    pass


# Generated at 2022-06-25 01:32:01.173512
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, type)

# Generated at 2022-06-25 01:32:02.287484
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:32:04.650744
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:32:13.915156
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    import platform
    sun_o_s_virtual_0.module.params = {u'gather_subset': ['all']}
    sun_o_s_virtual_0.module.run_command = lambda x: (0, u'SunOS', u'')
    sun_o_s_virtual_0.module.get_bin_path = lambda x: u'/usr/sbin/virtinfo'

# Generated at 2022-06-25 01:33:22.190495
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:22.954310
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual()


# Generated at 2022-06-25 01:33:24.469076
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # Try to collect some facts with SunOSVirtual.get_virtual_facts()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:33:33.003339
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    ansible_facts = {}
    ansible_facts['ansible_facts'] = {}
    ansible_facts['ansible_facts']['module_utils'] = {}
    ansible_facts['ansible_facts']['module_utils']['virtual'] = {}
    ansible_facts['ansible_facts']['module_utils']['virtual']['_module'] = {}
    ansible_facts['ansible_facts']['module_utils']['virtual']['_module']['get_bin_path'] = {}
    ansible_facts['ansible_facts']['module_utils']['virtual']['_module']['get_bin_path']['rc'] = 0

# Generated at 2022-06-25 01:33:38.186905
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = AnsibleModuleStub()

    name = 'get_virtual_facts'
    with pytest.raises(NotImplementedError) as error_info:
        sun_o_s_virtual_0.get_virtual_facts(name)

    assert name in str(error_info.value)



# Generated at 2022-06-25 01:33:39.335660
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:44.764745
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    if sun_o_s_virtual_0.get_virtual_facts() != {'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([]), 'virtualization_type': None, 'virtualization_role': None, 'container': None}:
        assert False


# Generated at 2022-06-25 01:33:45.749800
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:33:49.687741
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector) is True
    assert sun_o_s_virtual_collector_0._fact_class == sun_o_s_virtual_0.__class__
    assert sun_o_s_virtual_collector_0._platform == sun_o_s_virtual_0.platform

# Generated at 2022-06-25 01:33:52.160451
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:36:06.961306
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Check if the constructor of class SunOSVirtualCollector is created
    assert SunOSVirtualCollector()


# Generated at 2022-06-25 01:36:07.855303
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:36:14.373800
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = {}

    # Test for zonename
    zonename = "/usr/bin/zonename"
    rc = 0
    out = "global\n"
    err = ""
    virtual_facts = {}
    sun_o_s_virtual = SunOSVirtual(module=None)
    virtual_facts = sun_o_s_virtual.get_virtual_facts()
    assert virtual_facts == {}



# Generated at 2022-06-25 01:36:15.259553
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:36:19.938893
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = FakeAnsibleModule
    sun_o_s_virtual_0.module.get_bin_path = FakeGetBinPath
    sun_o_s_virtual_0.module.run_command = FakeRunCommand
    sun_o_s_virtual_0.module.params = {}

    # Test with a host on VMware
    with open('/proc/cpuinfo', 'w') as cpuinfo_file:
        cpuinfo_file.write('vendor_id	: GenuineIntel')

# Generated at 2022-06-25 01:36:22.212972
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    obj = SunOSVirtualCollector()
    assert isinstance(obj, SunOSVirtualCollector)


# Generated at 2022-06-25 01:36:23.222603
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:36:25.362944
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual_0 = SunOSVirtual()
    # Testing for exceptions raised in SunOSVirtual.get_virtual_facts
    # Pass
    SunOSVirtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:36:27.640017
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    pass

# Generated at 2022-06-25 01:36:29.635982
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual_get_virtual_facts_0 = SunOSVirtual()
    SunOSVirtual_get_virtual_facts_0.get_virtual_facts()
