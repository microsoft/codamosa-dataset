

# Generated at 2022-06-25 01:28:47.251683
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:28:54.658803
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = sun_o_s_virtual_collector_0.collect()
    if not sun_o_s_virtual_0:
        result = True
    else:
        result = False
    return result

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:28:58.280770
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = None
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:00.166968
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    SunOSVirtual_0 = SunOSVirtual(None)
    # No assert for the constructor.


# Generated at 2022-06-25 01:29:09.793989
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = None
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    sun_o_s_virtual_0.module = (test_SunOSVirtual_get_virtual_facts.__module__)
    sun_o_s_virtual_0.platform = ('SunOS')
    sun_o_s_virtual_0.module.run_command = (lambda *args, **kwargs: (0, '', ''))
    sun_o_s_virtual_0.module.get_bin_path = (lambda *args, **kwargs: '/usr/bin/zonename')
    sun_o_s_virtual_0.module.run_command = (lambda *args, **kwargs: (0, 'global\n', ''))

# Generated at 2022-06-25 01:29:11.780229
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = None
    sun_o_s_virtual_0 = SunOSVirtual(str_0)


# Generated at 2022-06-25 01:29:15.357994
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    str_0 = None
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(str_0)
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual

# Generated at 2022-06-25 01:29:17.433458
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
  str = None
  sun_o_s_virtual_0 = SunOSVirtual(str)
  sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:21.206143
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    str_0 = None
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(str_0)
    print(sun_o_s_virtual_collector_0)
    sun_o_s_virtual_0 = sun_o_s_virtual_collector_0.collect()
    print(sun_o_s_virtual_0)

# Generated at 2022-06-25 01:29:25.848911
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = ansible_module_create()
    sun_o_s_virtual = SunOSVirtual(module)
    # Setup test data.
    str_1 = None
    sun_o_s_virtual_0 = SunOSVirtual(str_1)
    str_2 = None
    sun_o_s_virtual_0.module = str_2
    # Call method get_virtual_facts of class SunOSVirtual
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:41.910267
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    print(sun_o_s_virtual_collector)

# Generated at 2022-06-25 01:29:44.193286
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:29:46.444137
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    facts_dict = sun_o_s_virtual_0.get_virtual_facts()
    assert (facts_dict.get('virtualization_role') == 'guest') or 'virtualization_role' not in facts_dict

# Generated at 2022-06-25 01:29:47.541852
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:51.708502
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    assert virtual_facts == {}

# Generated at 2022-06-25 01:29:54.497968
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(dict())

# Generated at 2022-06-25 01:30:02.174128
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    collector = SunOSVirtualCollector()
    collector.platform = 'SunOS'
    setattr(collector, '_current_line', {'module': 'qemu', 'module_args': '{"path": "/proc/cpuinfo"}'})

# Generated at 2022-06-25 01:30:03.829264
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:07.967040
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = {'container': 'zone',
                     'virtualization_role': 'guest',
                     'virtualization_type': 'zone'}
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0._get_virtualization_type = lambda: 'zone'
    sun_o_s_virtual_0._get_virtualization_role = lambda: 'guest'
    sun_o_s_virtual_0._get_container = lambda: 'zone'
    assert sun_o_s_virtual_0.get_virtual_facts() == virtual_facts



# Generated at 2022-06-25 01:30:12.110456
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector()._platform == "SunOS"

# Generated at 2022-06-25 01:30:28.329935
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()  # noqa


# Generated at 2022-06-25 01:30:32.919362
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    print(sun_o_s_virtual.get_virtual_facts())


if __name__ == '__main__':
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:30:33.940433
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)


# Generated at 2022-06-25 01:30:41.504349
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual({
        "distribution": "Solaris 11.3",
        "distribution_version": "11.3",
        "module_setup": True,
        "module_utils": "/usr/share/ansible/module_utils/basic/complex_args.py"})

    rc, out, err = sun_o_s_virtual.get_virtual_facts()
    assert rc == 0
    assert out == {'virtualization_role': 'guest', 'virtualization_tech_guest': set(['zone']), 'container': 'zone', 'virtualization_tech_host': set([]), 'virtualization_type': None}


# Generated at 2022-06-25 01:30:43.644781
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # Place your code below this line
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:30:44.783957
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:50.805102
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_0.platform
    # assert sun_o_s_virtual_collector_0.platform == 'SunOS'

###

# Generated at 2022-06-25 01:30:54.289658
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == None, 'Expected None, got %s for SunOSVirtual.get_virtual_facts()' % (sun_o_s_virtual_0.get_virtual_facts())


# Generated at 2022-06-25 01:31:00.077705
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # check if SunOSVirtual is_platform_supported equal to True
    assert SunOSVirtual().is_platform_supported() == True


# Generated at 2022-06-25 01:31:02.788529
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:31:41.100612
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    sun_o_s_virtual_get_virtual_facts_0 = sun_o_s_virtual.get_virtual_facts()
    pass


# ===========================
# ==== SunOSVirtual
# ===========================

# Generated at 2022-06-25 01:31:42.734000
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    # Calling get_virtual_facts
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:44.539553
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:47.663581
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:31:48.950416
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_os_virtual = SunOSVirtual()


# Generated at 2022-06-25 01:31:50.348397
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert isinstance(sun_o_s_virtual_0, SunOSVirtual)


# Generated at 2022-06-25 01:31:51.364912
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtualCollector.get_virtual_facts()

# Generated at 2022-06-25 01:31:55.592324
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:56.369024
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:31:57.013715
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  test_case_0()


# Generated at 2022-06-25 01:32:57.705268
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    if not SunOSVirtualCollector():
        raise Exception('Unit testSunOSVirtualCollector for class SunOSVirtualCollector failed')


# Generated at 2022-06-25 01:32:59.887187
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    my_SunOSVirtual = SunOSVirtual(dict())


# Generated at 2022-06-25 01:33:02.328601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert (sun_o_s_virtual_collector.platform == 'SunOS')



# Generated at 2022-06-25 01:33:05.704972
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    virtual_facts = SunOSVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-25 01:33:06.952303
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:33:09.369174
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


if __name__ == '__main__':
    test_SunOSVirtual()
    test_case_0()

# Generated at 2022-06-25 01:33:10.025720
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    sun_o_s_virtual = SunOSVirtual()

# Generated at 2022-06-25 01:33:11.942842
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_SunOSVirtual()

# Generated at 2022-06-25 01:33:14.529438
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)
    assert sun_o_s_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:33:17.050386
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.platform == 'SunOS'
    assert sun_o_s_virtual_0.virtual == None


# Generated at 2022-06-25 01:35:45.522829
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    # Check if class SunOSVirtual is created successfully
    assert sun_o_s_virtual_0.__class__.__name__ == 'SunOSVirtual'

    # Check if class SunOSVirtual contains 'virtualization_type' attribute
    assert hasattr(sun_o_s_virtual_0, 'virtualization_type')

    # Check if class SunOSVirtual contains 'virtualization_role' attribute
    assert hasattr(sun_o_s_virtual_0, 'virtualization_role')

    # Check if class SunOSVirtual contains 'virtualization_tech_host' attribute
    assert hasattr(sun_o_s_virtual_0, 'virtualization_tech_host')

    # Check if class SunOSVirtual contains 'virtualization_tech_guest' attribute
    assert hasattr

# Generated at 2022-06-25 01:35:50.643608
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_2 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:35:52.000819
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:35:56.743094
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    sun_o_s_virtual_get_virtual_facts_result = sun_o_s_virtual.get_virtual_facts()
    assert (sun_o_s_virtual_get_virtual_facts_result == None)

# Generated at 2022-06-25 01:36:00.469052
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    if os.path.isdir('/.SUNWnative'):
        sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, "global\n", ""))
    else:
        sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(1, "", ""))
    sun_o_s_virtual_0.module.get_bin_path = MagicMock(return_value=True)

    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:36:03.974178
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'
    assert sun_o_s_virtual_collector_0.fact_class == SunOSVirtual
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(fact_class='sun_o_s_virtual_collector_1', platform='sun_o_s_virtual_collector_1')
    assert sun_o_s_virtual_collector_1.platform == 'sun_o_s_virtual_collector_1'
    assert sun_o_s_virtual_collector_1.fact_class == 'sun_o_s_virtual_collector_1'


# Generated at 2022-06-25 01:36:07.882601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert hasattr(sun_o_s_virtual_collector_0, "get_virtual_facts")
    assert not hasattr(sun_o_s_virtual_collector_0, "__init__")


# Generated at 2022-06-25 01:36:08.754543
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.__init__()



# Generated at 2022-06-25 01:36:17.627628
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = FakeAnsibleModule()

    sun_o_s_virtual_0.module.run_command = run_command_mock

    # Test case with value 0
    sun_o_s_virtual_0.module.run_command.return_value = 0
    # Test case with value 1
    sun_o_s_virtual_0.module.run_command.return_value = 1
    # Test case with value 2
    sun_o_s_virtual_0.module.run_command.return_value = 2
    # Test case with value 3
    sun_o_s_virtual_0.module.run_command.return_value = 3
    # Test case with value 4
    sun_o_s_

# Generated at 2022-06-25 01:36:25.015874
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    sun_o_s_virtual_0.module.run_command = lambda x: (0, '', '')

    # This test does not apply to the current system. See
    # https://github.com/ansible/ansible/issues/60804 for details.
    sun_o_s_virtual_0.module.fail_json = lambda x: False

    assert sun_o_s_virtual_0.get_virtual_facts() == {}
