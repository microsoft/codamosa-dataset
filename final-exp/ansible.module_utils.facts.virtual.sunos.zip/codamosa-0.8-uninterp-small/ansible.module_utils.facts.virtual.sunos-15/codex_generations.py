

# Generated at 2022-06-25 01:28:51.242827
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_virtual_0.module.get_bin_path = MagicMock(return_value='')
    sun_o_s_virtual_0.module.params = { 'name': 'test_name_0' }
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:55.880194
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = { 'run_command': lambda *args, **kwargs: (0, '', ''), 'get_bin_path': lambda *args, **kwargs: ''}
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:59.133781
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert(sun_o_s_virtual_0.platform == 'SunOS')


# Generated at 2022-06-25 01:29:00.642720
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:29:01.944940
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:04.896927
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:05.992799
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(dict())


# Generated at 2022-06-25 01:29:07.871282
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:09.270972
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:14.102180
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of class SunOSVirtual
    """
    arg0 = None
    arg1 = None
    arg2 = None
    sun_o_s_virtual_0 = SunOSVirtual(arg0, arg1, arg2)
    sun_o_s_virtual_0.module = None
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:29:31.226867
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    v = SunOSVirtual()
    # Test no result is returned if /usr/sbin/zoneadm does not exist
    v.module.get_bin_path = lambda _: None
    assert v.get_virtual_facts() == {}
    # Test no result is returned if /usr/sbin/zoneadm returns a non-zero value
    v.module.get_bin_path = lambda _: "/usr/sbin/zoneadm"
    v.module.run_command = lambda _: (1, None, None)
    assert v.get_virtual_facts() == {}
    # Test no result is returned if the output of /usr/sbin/zoneadm has an unexpected format
    v.module.run_command = lambda _: (0, "", None)
    assert v.get_virtual_facts() == {}
   

# Generated at 2022-06-25 01:29:34.151918
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert type(sun_o_s_virtual_0).__name__ == 'SunOSVirtual' 


# Generated at 2022-06-25 01:29:35.565055
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:36.685995
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:41.996949
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None


# Generated at 2022-06-25 01:29:44.987110
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    fake_module = type('module')()
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(fake_module)
    assert sun_o_s_virtual_collector_1.module == fake_module



# Generated at 2022-06-25 01:29:46.538068
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    res = sun_o_s_virtual_0.get_virtual_facts()
    assert res is None


# Generated at 2022-06-25 01:29:47.328884
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:50.979370
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    facts_dict = sun_o_s_virtual_0.get_virtual_facts()
    assert facts_dict == {}


# Generated at 2022-06-25 01:29:55.088967
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0 is not None


# Generated at 2022-06-25 01:30:17.822743
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert isinstance(SunOSVirtual(), SunOSVirtual)

# Generated at 2022-06-25 01:30:23.945289
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == "SunOS"
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 01:30:28.023154
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:30:35.661349
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual, 'incorrect value for sun_o_s_virtual_collector_0._fact_class'
    assert sun_o_s_virtual_collector_0._platform == 'SunOS', 'incorrect value for sun_o_s_virtual_collector_0._platform'



# Generated at 2022-06-25 01:30:42.065343
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({})
    sun_o_s_virtual_0.module = type('', (object,), dict(get_bin_path=lambda _, x: x))
    sun_o_s_virtual_0.module.run_command=lambda _: (0, "", "")
    assert sun_o_s_virtual_0.get_virtual_facts() == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_type': 'zone', 'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 01:30:52.960524
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = run_command
    sun_o_s_virtual_0.module.get_bin_path = get_bin_path
    sun_o_s_virtual_0.module.path_exists = path_exists

    # On a global zone
    set_module_args({'gather_subset': 'all'})
    with pytest.raises(AnsibleExitJson) as exec_info:
        sun_o_s_virtual_0.get_virtual_facts()
    assert exec_info.value.args[0]['ansible_facts']['virtualization_role'] == 'host'

# Generated at 2022-06-25 01:30:54.486227
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual({}, {})
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:04.204298
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    virtual_facts_dict = {'container': 'zone', 'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['zone', 'vmware']), 'virtualization_tech_host': set(['zone'])}
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts_dict_1 = sun_o_s_virtual_0.get_virtual_facts()
    assert virtual_facts_dict_1 == virtual_facts_dict


# Generated at 2022-06-25 01:31:07.735310
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:31:09.340986
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    pass


# Generated at 2022-06-25 01:32:02.840167
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """ Check the constructor of SunOSVirtualCollector """
    try:
        sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    except:
        print('Constructor of class SunOSVirtualCollector has exception')



# Generated at 2022-06-25 01:32:04.419191
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()



# Generated at 2022-06-25 01:32:08.400168
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:32:09.533289
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    return sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:16.867716
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual( {} )
    assert type(sun_o_s_virtual_0._platform) is str
    assert sun_o_s_virtual_0._platform == 'SunOS'
    assert type(sun_o_s_virtual_0._virtual_facts_class) is dict
    assert sun_o_s_virtual_0._virtual_facts_class == {}


# Generated at 2022-06-25 01:32:20.367429
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:32:25.279406
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    if sun_o_s_virtual_collector_0 is not sun_o_s_virtual_collector_1:
        print("TestCase 0: Constructor of class SunOSVirtualCollector")


# Generated at 2022-06-25 01:32:27.866919
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.__init__()
    assert sun_o_s_virtual_0._platform == 'SunOS'


# Generated at 2022-06-25 01:32:36.042252
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    rc, out, err = sun_o_s_virtual_0.module.run_command("/bin/echo -e 'LDoms/VM#status=disabled\\nLDoms/Control#status=enabled\\nLDoms/IO#status=enabled\\nLDoms/Service#status=enabled'")
    sun_o_s_virtual_0.module.get_bin_path = lambda x: '/usr/sbin/virtinfo'
    sun_o_s_virtual_0.module.run_command = lambda *args, **kwargs: (rc, out, err)
    sun_o_s_virtual_0.module.path_exists = lambda path: True
    sun_o_s_virtual_0.module.is_executable = lambda path: True
   

# Generated at 2022-06-25 01:32:43.127995
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    # AssertionError: Expected "host" to be "host"
    assert sun_o_s_virtual_0.virtualization_role == 'host'
    # AssertionError: Expected "solaris" to be "solaris"
    assert sun_o_s_virtual_0.virtualization_type == 'solaris'
    # AssertionError: Expected 'NoneType' to be 'NoneType'
    assert sun_o_s_virtual_0.container is None


# Generated at 2022-06-25 01:34:57.295394
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_1 = SunOSVirtual()
    sun_o_s_virtual_1.module = MagicMock()
    sun_o_s_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:35:05.038002
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = sun_o_s_virtual_collector_0.collect()
    assert sun_o_s_virtual_0.virtualization_type == 'parallels'
    assert sun_o_s_virtual_0.virtualization_role == 'guest' or sun_o_s_virtual_0.virtualization_role == 'host (control,io,service,root)'
    assert sun_o_s_virtual_0.container is None or sun_o_s_virtual_0.container == 'zone'
    assert sun_o_s_virtual_0.virtualization_tech_guest == {'zone'} or sun_o_s_virtual_0.virtualization_tech_guest == set()
   

# Generated at 2022-06-25 01:35:06.728984
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert isinstance(SunOSVirtualCollector(), SunOSVirtualCollector)


# Generated at 2022-06-25 01:35:08.442995
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)
    assert sun_o_s_virtual_0.get_virtual_facts() is None

# Generated at 2022-06-25 01:35:12.436725
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=None)
    assert not sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:20.178519
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)

# Unit testing SunOSVirtualCollector
if __name__ == '__main__':
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:35:28.126752
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    if os.path.isdir('/.SUNWnative'):
        sun_o_s_virtual = SunOSVirtual()
        result = sun_o_s_virtual.get_virtual_facts()
        assert result['virtualization_role'] == 'guest'
        assert result['virtualization_type'] == 'zone'
        assert result['virtualization_tech_guest'] == set(['zone'])
        assert result['virtualization_tech_host'] == set([])
        assert result['container'] == 'zone'
    else:
        assert True

# Generated at 2022-06-25 01:35:30.448608
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()

    # REQ-TEST-0001
    # test for get_virtual_facts()
    # test if return value from a SunOSVirtual class is instance of dict
    assert isinstance(sun_o_s_virtual_0.get_virtual_facts(), dict)

# Generated at 2022-06-25 01:35:37.359974
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0.fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'
    assert sun_o_s_virtual_collector_0.fallback_collector is None


# Generated at 2022-06-25 01:35:38.433306
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()