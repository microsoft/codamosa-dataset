

# Generated at 2022-06-25 01:28:47.252281
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    try:
        assert isinstance(SunOSVirtual, type)
    except AssertionError:
        raise AssertionError('SunOSVirtual is not a class')

# Generated at 2022-06-25 01:28:50.157234
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = ''
    sun_o_s_virtual_0 = SunOSVirtual(str_0)

    sun_o_s_virtual_0.module.run_command = MagicMock(return_value=(0, 'global\n', ''))

    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:28:51.129635
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Runs above tests
    test_case_0()

# Generated at 2022-06-25 01:28:52.992590
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    output = SunOSVirtual(None)
    assert output.module == None
    assert output.platform == 'SunOS'


# Generated at 2022-06-25 01:28:59.861237
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = ''
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    # TODO: remove the following lines
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'virtualbox', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['virtualbox']), 'container': 'zone'}



# Generated at 2022-06-25 01:29:04.675462
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  with mock.patch('ansible_facts.virtual.sun_os.SunOSVirtualCollector._get_platform') as _get_platform:
    _get_platform.return_value = None
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector('/usr/sbin/virtinfo')


# Generated at 2022-06-25 01:29:08.987356
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # str_data - String data
    # obj_sun_o_s_virtual_collector_instance - Instance of object SunOSVirtualCollector
    str_data = ''
    obj_sun_o_s_virtual_collector_instance = SunOSVirtualCollector(str_data)    
    


# Generated at 2022-06-25 01:29:16.088182
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    str_0 = ''
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(str_0)
    assert sun_o_s_virtual_collector_0.__class__.__name__ == 'SunOSVirtualCollector'
    assert sun_o_s_virtual_collector_0.__class__.__doc__ == 'Platform-specific subclass of VirtualCollector. Provides virtualization facts'
    assert sun_o_s_virtual_collector_0.__class__.__module__ == 'ansible_collections.ansible.community.plugins.module_utils.facts.virtual.sunos'


# Generated at 2022-06-25 01:29:18.454313
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = ''
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    assert sun_o_s_virtual_0._platform == 'SunOS'


# Generated at 2022-06-25 01:29:20.206640
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = ''
    sun_o_s_virtual_0 = SunOSVirtual(str_0)


# Generated at 2022-06-25 01:29:35.717340
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(module=AnsibleModule(argument_spec={}))
    assert sun_o_s_virtual_0 != None


# Generated at 2022-06-25 01:29:37.020390
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:41.483192
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = Virtual()


# Generated at 2022-06-25 01:29:46.052409
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    #my_dict = {'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'vmware'}}
    #assert sun_o_s_virtual.get_virtual_facts() == my_dict
    return True

if __name__ == "__main__":
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:29:48.256329
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert isinstance(SunOSVirtual(), SunOSVirtual)


# Generated at 2022-06-25 01:29:49.770601
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:54.797678
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert test_case_0() is None, "constructor for class SunOSVirtualCollector is failing"

#######################################################################################


# Generated at 2022-06-25 01:30:02.404026
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    SunOSVirtual_get_virtual_facts_raw = {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['zone'])
    }
    SunOSVirtual_get_virtual_facts_out = {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['zone'])
    }
    SunOSVirtual_get_virtual_facts_obj = SunOSVirtual()
    SunOSVirtual_get_virtual_facts_obj.module.get_bin_path = lambda x: '/bin/zonename' if x == 'zonename' else None
    SunOSVirtual_get_

# Generated at 2022-06-25 01:30:04.051011
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Check if virtual_facts is equal to None
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.virtual_facts == None


# Generated at 2022-06-25 01:30:08.811416
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(None)

if __name__ == '__main__':
    test_case_0()
    sun_o_s_virtual_0 = SunOSVirtual(None)
    print("sun_o_s_virtual_0.virtual_facts=", sun_o_s_virtual_0.virtual_facts)

# Generated at 2022-06-25 01:30:27.472423
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

    # Test with scope 'global'
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

    # Test with scope 'global'
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

    # Test with scope 'global'
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

    # Test with scope 'global'
    sun_o_s_virtual_0 = SunOSVirtual()

# Generated at 2022-06-25 01:30:29.658638
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
  virtual_collector_0 = SunOSVirtualCollector()
  assert isinstance(virtual_collector_0, SunOSVirtualCollector)


# Generated at 2022-06-25 01:30:35.620059
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    assert sun_o_s_virtual_0.platform == 'SunOS'

# Generated at 2022-06-25 01:30:38.646173
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == None


# Generated at 2022-06-25 01:30:40.248446
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:49.425813
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_0.__init__()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual)
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class._platform == 'SunOS'
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual)


# Generated at 2022-06-25 01:30:50.705319
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:53.631096
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test case 0
    test_case_0()

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-25 01:30:55.491631
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    # AssertionError: isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)


# Generated at 2022-06-25 01:31:00.194851
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    my_SunOSVirtual_obj_0 = SunOSVirtual()
    my_SunOSVirtual_obj_0.get_virtual_facts()

# Generated at 2022-06-25 01:31:36.388444
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # Print the dictionary for information about virtualization technologies
    sun_o_s_virtual_0.get_virtual_facts()
    assert True is True

# Generated at 2022-06-25 01:31:40.182212
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

test_case_0()
test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:31:48.362332
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    module = os.path.join(os.path.dirname(__file__), '../../library/command.py')

    module_mocker = AnsibleModuleMock(module)
    module_mocker.params = { 'warn': False }
    sun_o_s_virtual_0 = SunOSVirtual(module_mocker)

    zonename = os.path.join(os.path.dirname(__file__), '../../../zonename')
    if os.path.exists(zonename):
        module_mocker.run_command.return_value = (0, "global", '')
    else:
        module_mocker.run_command.return_value = (1, "", "")

    module_mocker.get_bin_path.side_effect = [ zonename, zonename ]


# Generated at 2022-06-25 01:31:50.786206
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    if sun_o_s_virtual_collector_1._platform != 'SunOS':
        print('Failed to initialize data')


# Generated at 2022-06-25 01:31:55.526813
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual({})


# Generated at 2022-06-25 01:31:58.489753
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.exit_json = lambda v: None
    sun_o_s_virtual_0.module.run_command = lambda *args, **kw: (0, 'global', '')
    sun_o_s_virtual_0.module.get_bin_path = lambda *args, **kw: "/usr/sbin/zonename"
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:32:03.476357
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:32:10.812882
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-25 01:32:15.848867
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos.collector import SunOSVirtualCollector
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0 is not None


# Generated at 2022-06-25 01:32:23.778854
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()
    # Testing if sun_o_s_virtual is an instance of class Virtual
    if not isinstance(sun_o_s_virtual, Virtual):
        raise AssertionError('sun_o_s_virtual is not an instance of class Virtual')


# Generated at 2022-06-25 01:33:36.377546
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector._platform == 'SunOS'
    assert sun_o_s_virtual_collector._fact_class == SunOSVirtual


# Generated at 2022-06-25 01:33:41.307175
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual()
    assert sun_o_s_virtual.platform == 'SunOS'
    assert sun_o_s_virtual.virtualization_type == 'SunOS'
    assert sun_o_s_virtual.virtualization_role == 'guest'
    assert sun_o_s_virtual.container == None
    assert sun_o_s_virtual.virtualization_tech_guest == set()
    assert sun_o_s_virtual.virtualization_tech_host == set()


# Generated at 2022-06-25 01:33:43.730404
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:33:46.456874
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class._platform == 'SunOS'


# Generated at 2022-06-25 01:33:47.479615
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:33:49.046138
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:52.136154
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:33:56.537867
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = MockModule()
    sun_o_s_virtual_0.module.run_command.side_effect = [
        (0, 'global', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
    ]
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:33:58.431322
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual


# Generated at 2022-06-25 01:33:59.420121
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:36:14.949269
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:36:17.506841
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == dict(virtualization_role='guest', virtualization_type='zone', virtualization_tech_guest={'zone'}, virtualization_tech_host={'zone'}, container='zone')

# Generated at 2022-06-25 01:36:21.852072
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'

# Generated at 2022-06-25 01:36:22.380118
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:36:23.251984
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual(connection=None, module=None)


# Generated at 2022-06-25 01:36:27.234634
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual(module=AnsibleModule)
    sun_o_s_virtual_0.module.run_command = mock.Mock()

# Generated at 2022-06-25 01:36:28.402752
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert True

# Generated at 2022-06-25 01:36:30.155054
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    results = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:36:35.241982
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'

# Unit test to check method get_virtual_facts

# Generated at 2022-06-25 01:36:38.394540
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
  sun_o_s_virtual_0 = SunOSVirtual(module=None)
  assert sun_o_s_virtual_0
