

# Generated at 2022-06-25 01:28:48.870698
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:28:53.562444
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    assert (sun_o_s_virtual_0.platform == 'SunOS')


# Generated at 2022-06-25 01:28:56.734981
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)

    field_value_dict_0 = sun_o_s_virtual_0.get_virtual_facts()

    assert field_value_dict_0 == {}

# Generated at 2022-06-25 01:29:07.835485
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    sun_o_s_virtual_0.module = MockModule()
    sun_o_s_virtual_0.module.get_bin_path.side_effect = lambda x: "/usr/sbin/%s" % x
    sun_o_s_virtual_0.module.run_command.side_effect = lambda x: (0, '', '')

    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'hvm'

# Generated at 2022-06-25 01:29:14.484460
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    bytes_1 = b' \xba\xc4\xec\xe9\x80\x0c\x8f\xcd\x91\x0c\xb0\xc1\x07\xcc\xf2'
    result_0 = SunOSVirtual(bytes_0)
    result_1 = SunOSVirtual(bytes_1)
    assert result_0.platform == "SunOS"
    assert result_1.platform == "SunOS"


# Generated at 2022-06-25 01:29:20.333428
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    sun_o_s_fact_subclass_0 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_fact_subclass_1 = sun_o_s_virtual_0.get_virtual_facts()
    sun_o_s_fact_subclass_2 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:22.471709
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)


# Generated at 2022-06-25 01:29:25.459467
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)

    assert(sun_o_s_virtual_0.get_virtual_facts() == {})

# Generated at 2022-06-25 01:29:27.715116
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(bytes_0)



# Generated at 2022-06-25 01:29:34.226754
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    bytes_0 = b'\x94\xfc\x00@\x88\x7f'
    sun_o_s_virtual_0 = SunOSVirtual(bytes_0)
    bytes_1 = b'\x90\xfe\x00@\x88\x7f'
    sun_o_s_virtual_1 = SunOSVirtual(bytes_1)


# Generated at 2022-06-25 01:29:47.060098
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:48.581581
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert not SunOSVirtualCollector(
    )._fact_class.platform != 'SunOS', 'The platform of the result should equal SunOS.'


# Generated at 2022-06-25 01:29:49.779308
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:00.068759
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # Set up the method input parameters
    # Method Module mock
    mock_module_0 = mock_module_factory()
    # Set up the method execution attributes
    sun_o_s_virtual_0.module = mock_module_0
    # Set up the method mock object
    sun_o_s_virtual_0.get_virtual_facts = MagicMock(name='SunOSVirtual.get_virtual_facts')
    set_module_args({})

    with pytest.raises(AnsibleExitJson) as context:
        sun_o_s_virtual_0.get_virtual_facts()

    _exit_json = context.value.args[0]
    assert not _exit_json.get('changed')
    sun_o_s_virtual

# Generated at 2022-06-25 01:30:09.253891
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module.run_command = MagicMock()

    # Return value of run_command (mocked function)
    sun_o_s_virtual_0.module.run_command.return_value = ( 0, 'global', '' )

    assert isinstance(sun_o_s_virtual_0.module.run_command(), tuple)
    assert sun_o_s_virtual_0.get_virtual_facts() == {}
    sun_o_s_virtual_0.module.run_command.assert_called_with('zonename')


# Generated at 2022-06-25 01:30:11.932032
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:30:16.499456
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    result_sun_o_s_virtual_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert result_sun_o_s_virtual_0 == None


# Generated at 2022-06-25 01:30:18.134604
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:22.093901
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:30:32.017313
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    # AssertionError: assert {'virtualization_type': None, 'virtualization_role': None, 'container': None} == {'virtualization_type': 'parallels', 'virtualization_role': 'guest', 'container': None}
    # assert {'virtualization_type': None, 'virtualization_role': None, 'container': None} == {'virtualization_type': 'parallels', 'virtualization_role': 'guest', 'container': None}
    assert sun_o_s_virtual_0.get_virtual_facts() == {'virtualization_type': 'parallels', 'virtualization_role': 'guest', 'container': None}


# Generated at 2022-06-25 01:30:47.110439
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:30:55.806346
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert not sun_o_s_virtual_0.platform
    assert not sun_o_s_virtual_0.distribution
    assert not sun_o_s_virtual_0.get_virtual_facts()
    assert not sun_o_s_virtual_0.get_sysctl()
    assert sun_o_s_virtual_0.platform == 'SunOS'
    assert not sun_o_s_virtual_0.distribution
    assert not sun_o_s_virtual_0.get_virtual_facts()
    assert not sun_o_s_virtual_0.get_sysctl()


# Generated at 2022-06-25 01:31:06.167577
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtual()
    output_0 = str(sun_o_s_virtual_collector_0.platform)
    output_1 = str(sun_o_s_virtual_collector_0.get_virtual_facts())
    output_2 = str(sun_o_s_virtual_collector_0.virtualization_type)
    output_3 = str(sun_o_s_virtual_collector_0.virtualization_role)
    output_4 = str(sun_o_s_virtual_collector_0.virtualization_tech_host)
    output_5 = str(sun_o_s_virtual_collector_0.virtualization_tech_guest)

# Generated at 2022-06-25 01:31:06.913364
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:08.249206
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:31:09.745416
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:12.483961
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() is not None
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:31:19.290822
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Case 0:
    virtual_0 = SunOSVirtual()
    assert virtual_0.get_virtual_facts() == None
    # Case 1:
    virtual_1 = SunOSVirtual({'container': 'zone'})
    assert 'virtualization_type' not in virtual_1.get_virtual_facts()
    assert virtual_1.get_virtual_facts() == {'virtualization_role': 'guest', 'container': 'zone', 'virtualization_tech_guest': set(['zone']), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:31:21.297204
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    try:
        virtual_facts = sun_o_s_virtual_0.get_virtual_facts()
    except:
        failed = True
    else:
        failed = False
    assert not failed



# Generated at 2022-06-25 01:31:24.346188
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    try:
        sun_o_s_virtual_0 = SunOSVirtual()
        print('sun_o_s_virtual_0 = ' + repr(sun_o_s_virtual_0))
    except Exception as err:
        print('Constructor of SunOSVirtual failed!\n' + repr(err))
    else:
        print('Constructor of SunOSVirtual works!')


# Generated at 2022-06-25 01:31:53.912528
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:31:58.707032
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    # Reading data from sample output file
    cur_dir = dir_path.split("/")
    file_path = "/".join(cur_dir[:cur_dir.index("test")+1]) + "/sample_outputs/solaris_virtual.out"
    with open(file_path, "r") as f:
        data = f.read()
    sun_o_s_virtual_0 = SunOSVirtual(module_name=None)
    sun_o_s_virtual_0.get_virtual_facts(data=data)


# Generated at 2022-06-25 01:32:00.150668
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    assert sun_o_s_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:32:02.482440
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class.__class__.__name__ == 'SunOSVirtual'
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:32:04.805873
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    virtual_facts = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:32:08.343568
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_1 = SunOSVirtual()
    sun_o_s_virtual_2 = SunOSVirtual()
    sun_o_s_virtual_3 = SunOSVirtual()
    sun_o_s_virtual_4 = SunOSVirtual()
    sun_o_s_virtual_5 = SunOSVirtual()
    sun_o_s_virtual_6 = SunOSVirtual()
    sun_o_s_virtual_7 = SunOSVirtual()
    sun_o_s_virtual_8 = SunOSVirtual()
    sun_o_s_virtual_9 = SunOSVirtual()


# Generated at 2022-06-25 01:32:11.866260
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None
    assert sun_o_s_virtual_collector._platform == "SunOS"
    assert sun_o_s_virtual_collector._fact_class is SunOSVirtual


# Generated at 2022-06-25 01:32:14.286282
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()

# Generated at 2022-06-25 01:32:15.606172
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:32:21.579468
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None


# Generated at 2022-06-25 01:33:25.131636
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    sun_o_s_virtual_0.module = AnsibleModule(argument_spec={})
    sun_o_s_virtual_0.module.run_command = mock_run_command

    assert sun_o_s_virtual_0.get_virtual_facts() == {'container': 'zone', 'virtualization_role': 'guest', 'virtualization_tech_host': set(['zone']), 'virtualization_tech_guest': set(['zone']), 'virtualization_type': 'zone'}

# Generated at 2022-06-25 01:33:31.341427
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(module_0)
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:33:40.260937
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    sun_o_s_virtual.module = MockModule()
    module_get_bin_path_mock = Mock()
    sun_o_s_virtual.module.get_bin_path = module_get_bin_path_mock
    module_get_bin_path_mock.side_effect = [None, None, None, None, None, None, None, None]
    sun_o_s_virtual.module.run_command = Mock()

# Generated at 2022-06-25 01:33:41.772394
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:43.759737
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:33:46.071532
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual = SunOSVirtual({})
    assert sun_o_s_virtual.platform == 'SunOS'


# Generated at 2022-06-25 01:33:47.109803
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert sun_o_s_virtual_0._platform == 'SunOS'


# Generated at 2022-06-25 01:33:52.070868
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0 != None


# Generated at 2022-06-25 01:33:53.016587
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:33:54.218253
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_os_virtual = SunOSVirtual()
    result = sun_os_virtual.get_virtual_facts()
    assert result == {}


# Generated at 2022-06-25 01:35:17.005078
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test

# Generated at 2022-06-25 01:35:23.578591
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    float_0 = 2846.838
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(float_0)
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)
    assert isinstance(sun_o_s_virtual_collector_0._fact_class, SunOSVirtual)
    assert isinstance(sun_o_s_virtual_collector_0._platform, str)

# Generated at 2022-06-25 01:35:25.262222
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    float_0 = 2846.838
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(float_0)

# Generated at 2022-06-25 01:35:29.216868
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    float_0 = 16.738
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(float_0)

if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:35:32.144468
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:35:42.254523
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    str_0 = sun_o_s_virtual_0.get_virtual_facts()
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    str_1 = sun_o_s_virtual_0.get_virtual_facts()
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    str_2 = sun_o_s_virtual_0.get_virtual_facts()
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    str_3 = sun_o_

# Generated at 2022-06-25 01:35:45.035979
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    
    # Call method to test
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:35:45.473406
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    assert1 = False

# Generated at 2022-06-25 01:35:46.845855
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    int_0 = 2018
    float_0 = 4010.873
    sun_o_s_virtual_0 = SunOSVirtual(int_0, float_0)


# Generated at 2022-06-25 01:35:48.541054
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    float_0 = 2846.838
    sun_o_s_virtual_0 = SunOSVirtual(float_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert True