

# Generated at 2022-06-25 01:28:47.991488
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = 'g&u9-%;~gX'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)

# Function to test whether the output of function get_virtual_facts of method SunOSVirtual
# is not empty

# Generated at 2022-06-25 01:28:52.373162
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:28:55.281689
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(None)

if __name__ == '__main__':
    test_case_0()
    test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:28:57.464695
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_module = SunOSVirtualCollector(module=None)
    test_module.collect()
    assert test_module.failed is False

# Generated at 2022-06-25 01:29:01.060295
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = 'g&u9-%;~gX'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:04.141290
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    str_0 = '@1w2e`[o6"'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)


# Generated at 2022-06-25 01:29:07.144733
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    str_0 = 'z'
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(str_0)

# Generated at 2022-06-25 01:29:09.510867
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    str_0 = '+6Ck>6U_'

    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(str_0)


# Generated at 2022-06-25 01:29:13.051304
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    str_0 = 'g&u9-%;~gX'
    sun_o_s_virtual_0 = SunOSVirtual(str_0)
    # Call method get_virtual_facts() of class SunOSVirtual
    sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:29:17.488990
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()


test_SunOSVirtualCollector()

# Generated at 2022-06-25 01:29:31.457450
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert(isinstance(SunOSVirtualCollector(),object))


# Generated at 2022-06-25 01:29:33.730925
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:35.790847
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_1 is not None


# Generated at 2022-06-25 01:29:39.470867
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()


# Generated at 2022-06-25 01:29:41.511630
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:42.651922
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:29:46.697195
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():

    # Create an instance of SunOSVirtual
    sun_o_s_virtual_0 = SunOSVirtual()

    # Check SunOSVirtual.platform
    assert sun_o_s_virtual_0.platform == 'SunOS'

    # Check SunOSVirtual.get_virtual_facts()
    virtual_facts_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert virtual_facts_0 == {}


# Generated at 2022-06-25 01:29:53.332149
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():

    # Constructing a mock for the class SunOSVirtual
    class SunOSVirtualInstance:
        def __init__(self, module):
            self.module = module

        def get_virtual_facts(self):
            # Returns a string "Some return value"
            return "Some return value"

    # Constructing a mock for the class Module
    class ModuleInstance:
        def __init__(self):
            pass


# Generated at 2022-06-25 01:29:55.538044
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    facts_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert facts_0


# Generated at 2022-06-25 01:29:57.863172
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector is not None


# Generated at 2022-06-25 01:30:13.449637
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    var_1 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:18.707663
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_2 = SunOSVirtualCollector()
    sun_o_s_virtual_1 = SunOSVirtual(sun_o_s_virtual_collector_2)
    var_1 = sun_o_s_virtual_1.get_virtual_facts()
    var_2 = sun_o_s_virtual_1._platform
    var_3 = sun_o_s_virtual_1._fact_class

# Generated at 2022-06-25 01:30:23.525294
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)


# Generated at 2022-06-25 01:30:25.702728
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)


# Generated at 2022-06-25 01:30:28.665724
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:30:29.503545
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 01:30:34.872330
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual
    assert sun_o_s_virtual_collector_0._platform == 'SunOS'


# Generated at 2022-06-25 01:30:41.990565
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
#    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    print('var_0: ' + str(var_0))
    assert var_0 == 'vmware' or var_0 == 'parallels' or var_0 == 'virtualbox' or var_0 == 'xen' or var_0 == 'kvm' or var_0 == 'zone' or var_0 == 'ldom'

# Generated at 2022-06-25 01:30:51.372870
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    assert not hasattr(sun_o_s_virtual_0, 'virtualization_role')
    assert not hasattr(sun_o_s_virtual_0, 'virtualization_type')
    assert not hasattr(sun_o_s_virtual_0, 'virtualization_tech_guest')
    assert not hasattr(sun_o_s_virtual_0, 'virtualization_tech_host')



# Generated at 2022-06-25 01:30:54.230837
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)

# Generated at 2022-06-25 01:31:30.023196
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_1)

# Generated at 2022-06-25 01:31:32.626287
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    try:
        sun_o_s_virtual_0.get_virtual_facts()
    except:
        pass

# Generated at 2022-06-25 01:31:33.402776
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()


# Generated at 2022-06-25 01:31:35.992565
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)



# Generated at 2022-06-25 01:31:36.701266
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert True


# Generated at 2022-06-25 01:31:40.523224
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:31:45.019694
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    sun_o_s_virtual_1 = SunOSVirtual(sun_o_s_virtual_collector_1)


# Generated at 2022-06-25 01:31:49.376636
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert sun_o_s_virtual_collector_0
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)
    assert sun_o_s_virtual_collector_1


# Generated at 2022-06-25 01:31:52.062193
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)


# Generated at 2022-06-25 01:31:56.123404
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # This test doesn't actually run anything so we can call it
    # during actual tests, e.g. for mocking purposes
    pass



# Generated at 2022-06-25 01:32:46.810277
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0, int_0)
    assert sun_o_s_virtual_collector_0.platform == 'SunOS'
    assert sun_o_s_virtual_collector_0._fact_class == SunOSVirtual

# Generated at 2022-06-25 01:32:51.146045
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    var_1 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_1 is None



# Generated at 2022-06-25 01:33:00.954928
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    var_1 = sun_o_s_virtual_0.get_virtual_facts()
    var_2 = sun_o_s_virtual_0.get_virtual_facts()
    var_3 = sun_o_s_virtual_0.get_virtual_facts()
    var_4 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 is not None
    assert var_1 is not None
    assert var_2 is not None
    assert var_3 is not None
    assert var

# Generated at 2022-06-25 01:33:06.326957
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 01:33:09.557921
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)


# Generated at 2022-06-25 01:33:13.968402
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:33:18.408785
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:33:20.411682
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)



# Generated at 2022-06-25 01:33:23.259048
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class SunOSVirtual
    sun_o_s_virtual_0 = SunOSVirtual(SunOSVirtualCollector())
    # test for command zonename
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
    assert var_0 is None

# Generated at 2022-06-25 01:33:28.041689
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)
    sun_o_s_virtual_1 = SunOSVirtual(sun_o_s_virtual_collector_1)
    sun_o_s_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:35:40.013310
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    assert sun_o_s_virtual_0.get_virtual_facts() == {}
    # Assert
    assert sun_o_s_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:35:42.849543
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)


# Generated at 2022-06-25 01:35:47.653108
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = {}
    int_0 = 5436
    sun_o_s_virtual_collector_1 = SunOSVirtualCollector(dict_0, int_0)


# Generated at 2022-06-25 01:35:53.130009
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    dict_0 = sun_o_s_virtual_collector_0.__dict__
    assert isinstance(dict_0, dict)
    sun_o_s_virtual_collector_2 = SunOSVirtualCollector(dict_0, 5436)
    assert isinstance(sun_o_s_virtual_collector_2, SunOSVirtualCollector)
    assert isinstance(sun_o_s_virtual_collector_2._fact_class, SunOSVirtual)


# Generated at 2022-06-25 01:35:57.545181
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:36:03.684221
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    int_0 = 5436
    sun_o_s_virtual_0 = test_case_0()
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector(dict_0, int_0)
    sun_o_s_virtual_0 = SunOSVirtual(sun_o_s_virtual_collector_0)
    var_0 = sun_o_s_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:36:07.483241
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sun_o_s_virtual_collector_0 = SunOSVirtualCollector()
    assert isinstance(sun_o_s_virtual_collector_0, SunOSVirtualCollector)

# Generated at 2022-06-25 01:36:08.808887
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual = SunOSVirtual()
    assert sun_o_s_virtual.get_virtual_facts() == dict()


# Generated at 2022-06-25 01:36:12.872485
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    sun_o_s_virtual_0 = SunOSVirtual()
    var_0 = sun_o_s_virtual_0.get_virtual_facts()

test_case_0()
test_SunOSVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:36:16.488652
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    sun_o_s_virtual_0 = SunOSVirtual()
    var_0 = sun_o_s_virtual_0.get_virtual_facts()
