

# Generated at 2022-06-17 03:29:11.869179
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:14.033261
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:17.232041
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:29:24.441931
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual({})

    # Create a mock module
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/virtinfo'
    sunos_virtual.module = module

    # Create a mock module
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/virtinfo'
    sunos_virtual.module = module

    # Test the get_virtual_facts method
    assert sunos_virtual.get_virtual_

# Generated at 2022-06-17 03:29:27.154836
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:29:32.777783
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:29:43.022618
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)

    # Test on a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/zonename')
    module.get_file_content = MagicMock(return_value=None)
    module.get_file_size = MagicMock(return_value=None)
    module.get_file_type = MagicMock(return_value=None)
    module.get_file_uid = MagicMock(return_value=None)
    module.get_file_gid = MagicMock(return_value=None)
    module.get_file_mode = MagicMock(return_value=None)
   

# Generated at 2022-06-17 03:29:52.055771
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(module)
    module.get_bin_path = FakeGetBinPath(module)
    module.params = {}
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_host']


# Generated at 2022-06-17 03:29:59.303912
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a dummy class with a dummy method run_command
    class Dummy(object):
        def run_command(self, args):
            if args == 'zonename':
                return 0, 'global', ''
            elif args == 'modinfo':
                return 0, '', ''
            elif args == 'virtinfo -p':
                return 0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''
            elif args == 'smbios':
                return 0, '', ''
            else:
                return 1, '', ''

    # Create a dummy module object
    dummy = Dummy()

    # Create a SunOSVirtual object
    sun

# Generated at 2022-06-17 03:30:06.126267
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:30:24.900875
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:30:29.948067
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:33.473257
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:30:35.536574
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:30:43.763123
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value=True)
    module.stat = MagicMock(return_value=True)
    module.os_path_exists = MagicMock(return_value=True)
    module.os_path_isfile = MagicMock(return_value=True)
    module.os_path_isdir = MagicMock(return_value=True)
    module.os_path_islink = MagicMock(return_value=True)
    module.os_path_ismount = Magic

# Generated at 2022-06-17 03:30:45.113905
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:47.069849
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:30:48.624058
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:52.615888
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:03.014512
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:31:29.043724
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:40.540831
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value=True)
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    module.params['gather_network_resources'] = 'no'
    module.params['gather_device_size'] = 'no'
    module.params['gather_mount_size'] = 'no'

# Generated at 2022-06-17 03:31:43.750105
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:45.548381
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:55.236372
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/zonename')
    module.get_bin_path = MagicMock(return_value='/usr/sbin/modinfo')
    module.get_bin_path = MagicMock(return_value='/usr/sbin/virtinfo')
    module.get_bin_path = MagicMock(return_value='/usr/sbin/smbios')
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'

# Generated at 2022-06-17 03:31:58.170875
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    v = SunOSVirtual(module)
    assert v.platform == 'SunOS'
    assert v.module == module


# Generated at 2022-06-17 03:32:09.414193
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.os_path = os.path
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:32:11.969193
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:32:15.700170
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:32:20.631600
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:28.537936
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert 'kvm' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-17 03:33:29.519674
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:33:31.603388
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector.platform == 'SunOS'
    assert virtual_collector.fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:35.462615
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:33:37.217141
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:38.112111
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:33:46.289281
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector

    # Create a mock module
    module = MockModule()

    # Create a mock class
    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

    # Create a mock class
    class MockSunOSVirtualCollector(SunOSVirtualCollector):
        def __init__(self, module):
            self.module = module

    # Create a mock class

# Generated at 2022-06-17 03:33:48.795366
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:55.982298
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:33:58.275719
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:18.911621
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd: (0, '', ''),
        'get_bin_path': lambda self, cmd: cmd,
    })

    # Create a mock ansible module

# Generated at 2022-06-17 03:36:19.677295
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:28.997391
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='global')
    module.get_bin_path = FakeGetBinPath(path='/usr/bin/zonename')
    module.os.path.isdir = FakeOsPathIsDir(isdir=False)
    module.os.path.exists = FakeOsPathExists(exists=False)
    module.get_file_content = FakeGetFileContent(content='')
    module.get_mount_size = FakeGetMountSize(size=0)
    module.get_mount_device = FakeGetMountDevice(device='')
    module.get_mount_point = FakeGetMountPoint(point='')
    module.get_mount_options = FakeGetMountOptions(options='')
    module.get

# Generated at 2022-06-17 03:36:30.344205
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:32.266291
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:34.103208
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:35.758388
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:40.886842
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    # Test with no input
    v = SunOSVirtual({})
    assert v.data == {}

    # Test with input
    args = {
        'ansible_facts': {
            'ansible_virtualization_type': 'kvm',
            'ansible_virtualization_role': 'guest',
            'ansible_container': 'zone',
            'ansible_virtualization_tech_guest': ['zone'],
            'ansible_virtualization_tech_host': ['zone']
        }
    }
    v = SunOSVirtual(args)
    assert v.data == args['ansible_facts']

# Generated at 2022-06-17 03:36:43.574404
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:36:46.278352
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
