

# Generated at 2022-06-17 03:29:09.347295
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:29:10.171592
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:29:12.981390
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:14.507142
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:15.324148
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:29:17.528717
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:29:18.845485
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:29:23.917151
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:25.441270
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:36.685680
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')

# Generated at 2022-06-17 03:29:58.872544
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # Test with no virtualization
    set_module_args({})
    SunOSVirtualCollector.collect(module=module)
    facts = module.exit_json['ansible_facts']
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'container' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_tech_host' not in facts

    # Test with zone
    set_module_args({})
    run_command_values['rc'] = 0
    run_

# Generated at 2022-06-17 03:30:01.618070
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:30:09.950762
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:30:13.434841
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:30:16.787206
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:18.284381
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:19.938948
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:30:24.060236
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:36.541494
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        rc=0,
        out="global",
        err=""
    )
    module.get_bin_path = FakeGetBinPath(
        bin_path="/usr/sbin/virtinfo"
    )
    module.get_file_content = FakeGetFileContent(
        content=""
    )
    module.file_exists = FakeFileExists(
        exists=False
    )
    module.stat = FakeStat(
        st_mode=0o777
    )
    module.is_executable = FakeIsExecutable(
        executable=True
    )
    module.is_directory = FakeIsDirectory(
        directory=False
    )

# Generated at 2022-06-17 03:30:40.431222
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual()
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()


# Generated at 2022-06-17 03:31:14.751309
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'


# Generated at 2022-06-17 03:31:22.398240
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:31:23.931102
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:31:29.140244
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:31:31.419553
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:31:42.183171
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeOsPathIsDir()
    module.os.path.exists = FakeOsPathExists()
    module.os.path.isfile = FakeOsPathIsFile()
    module.os.stat = FakeOsStat()
    module.os.access = FakeOsAccess()
    module.os.getuid = FakeOsGetuid()
    module.os.getgid = FakeOsGetgid()
    module.os.geteuid = FakeOsGeteuid()
    module.os.getegid = FakeOsGetegid()
    module.os.getgroups = FakeOsGetgroups()
    module.os.getenv = FakeOs

# Generated at 2022-06-17 03:31:44.749128
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:51.946621
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'container' in virtual_facts

# Generated at 2022-06-17 03:31:53.696492
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:31:56.338599
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:48.618561
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:32:56.739588
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command = AnsibleRunCommandMock
    module.get_bin_path = AnsibleGetBinPathMock
    module.params = {}
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.module == module


# Generated at 2022-06-17 03:33:00.139669
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:01.542822
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:12.863012
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock class
    class MockFile(object):
        def __init__(self, path, content):
            self.path = path
            self.content = content

        def read(self):
            return self.content

        def close(self):
            pass

    class MockOs(object):
        def __init__(self, files):
            self.files = files

        def listdir(self, path):
            return []

        def path(self, path):
            return path

        def isdir(self, path):
            return False

        def isfile(self, path):
            return True


# Generated at 2022-06-17 03:33:13.616917
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:33:14.911946
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:22.549715
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value='')
    module.is_file = MagicMock(return_value=True)
    module.is_directory = MagicMock(return_value=True)
    module.is_executable = MagicMock(return_value=True)
    module.is_readable = MagicMock(return_value=True)
    module.is_symlink = Magic

# Generated at 2022-06-17 03:33:30.532261
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:33:42.299693
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.warn = MagicMock()
    module.deprecate = MagicMock()
    module.add_path_info = MagicMock()
    module.get_platform = MagicMock(return_value='SunOS')
    module.get_distribution = MagicMock(return_value='SunOS')
    module.get

# Generated at 2022-06-17 03:35:49.222551
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:00.739247
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        rc=0,
        out="global",
        err=""
    )
    module.get_bin_path = FakeGetBinPath(
        bin_path="/usr/sbin/virtinfo"
    )
    module.get_file_content = FakeGetFileContent(
        content=""
    )
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['container']

# Generated at 2022-06-17 03:36:02.436043
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:36:09.931584
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    module.params['fact_path'] = '/etc/ansible/facts.d'
    module.params['fact_basename'] = 'virtual_facts'
    module.params['_ansible_check_mode'] = False
    module.params['_ansible_debug'] = False
    module.params['_ansible_diff'] = False
    module.params['_ansible_verbosity'] = 0

# Generated at 2022-06-17 03:36:21.795969
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # Create a facts dictionary
    facts = dict()

    # Get virtual facts
    facts.update(sunos_virtual.get_virtual_facts())

    # Assert that virtualization_type is set to 'zone'
    assert facts['virtualization_type'] == 'zone'

    # Assert that virtualization_role is set to 'guest'
    assert facts['virtualization_role'] == 'guest'

    # Assert that container is set to 'zone'
    assert facts['container'] == 'zone'

    # Assert that virtualization_tech_guest is set to 'zone'

# Generated at 2022-06-17 03:36:24.443678
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:36:28.628787
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-17 03:36:32.986597
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-17 03:36:40.569640
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value=True)
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-17 03:36:45.638686
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual