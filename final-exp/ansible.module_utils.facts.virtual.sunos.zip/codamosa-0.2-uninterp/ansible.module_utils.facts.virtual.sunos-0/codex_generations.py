

# Generated at 2022-06-17 03:29:16.052543
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:29:17.601270
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:29:26.544040
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # Create a facts dictionary
    facts = dict()

    # Get virtual facts
    sunos_virtual.get_virtual_facts(facts)

    # Assert that virtualization_type is set to 'zone'
    assert facts['virtualization_type'] == 'zone'

    # Assert that virtualization_role is set to 'guest'
    assert facts['virtualization_role'] == 'guest'

    # Assert that container is set to 'zone'
    assert facts['container'] == 'zone'

    # Assert that virtualization_tech_guest is set to 'zone'

# Generated at 2022-06-17 03:29:37.065155
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value=True)
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-17 03:29:46.187350
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:29:57.350273
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:30:00.494538
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.get_virtual_facts() is None

# Generated at 2022-06-17 03:30:04.474529
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no args
    SunOSVirtualCollector()

    # Test with args
    SunOSVirtualCollector(
        module=dict(
            get_bin_path=lambda x: None,
            run_command=lambda x: (0, '', '')
        )
    )

# Generated at 2022-06-17 03:30:08.834658
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:30:12.961716
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_virtual_facts() is None


# Generated at 2022-06-17 03:30:36.609723
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='global')
    module.get_bin_path = FakeGetBinPath(path=True)
    module.path_exists = FakePathExists(exists=False)
    module.file_exists = FakeFileExists(exists=False)
    module.stat = FakeStat(st_mode=0o644)
    module.read_file = FakeReadFile(data='VMware')
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:30:38.853983
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.module == module


# Generated at 2022-06-17 03:30:40.349944
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:30:47.510293
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None


# Generated at 2022-06-17 03:30:58.502379
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:31:03.761677
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:31:05.335811
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:31:09.488612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:13.220553
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.module == module


# Generated at 2022-06-17 03:31:15.681531
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:31:52.948501
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='global')
    module.get_bin_path = FakeGetBinPath(path='/usr/sbin/zonename')
    module.path_exists = FakePathExists(exists=False)
    module.file_exists = FakeFileExists(exists=False)
    module.stat = FakeStat(st_mode=0o755)
    module.is_executable = FakeIsExecutable(executable=True)
    module.is_directory = FakeIsDirectory(directory=True)
    module.is_file = FakeIsFile(file=True)
    module.is_symlink = FakeIsSymlink(symlink=True)

# Generated at 2022-06-17 03:31:56.950931
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeAnsibleModule()
    SunOSVirtualCollector(module)
    assert module.exit_args == {'failed': False}
    assert module.exit_msg == ''


# Generated at 2022-06-17 03:31:59.647779
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:01.758019
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:32:03.799055
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:16.960132
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        rc=0,
        out='global',
        err=''
    )
    module.get_bin_path = FakeGetBinPath(
        bin_path='/usr/sbin/zonename'
    )
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None
    assert virtual_facts['container'] is None


# Generated at 2022-06-17 03:32:18.094426
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:19.918443
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:32:21.190265
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:32:25.451184
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:33:34.597116
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.is_file = MagicMock(return_value=True)
    module.is_executable = MagicMock(return_value=True)
    module.is_directory = MagicMock(return_value=True)
    module.is_block_device = MagicMock(return_value=True)
   

# Generated at 2022-06-17 03:33:42.995162
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock class
    sunos_virtual = SunOSVirtual(module)

    # Create a mock facts
    facts = dict()

    # Create a mock command
    command = dict(rc=0, out='', err='')

    # Mock method run_command
    def run_command(self, cmd, check_rc=True):
        return command['rc'], command['out'], command['err']

    # Mock method get_bin_path
    def get_bin_path(self, arg):
        return '/bin/' + arg

    # Mock method exists
    def exists(self, arg):
        if arg == '/proc/vz':
            return True

# Generated at 2022-06-17 03:33:44.442910
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:52.700173
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'global', ''))
    module.get_bin_path = Mock(return_value='/usr/sbin/zonename')
    module.params = {'gather_subset': ['!all', 'virtual']}
    module.exit_json = Mock()
    module.fail_json = Mock()

    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['container'] == 'zone'

#

# Generated at 2022-06-17 03:33:54.178467
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:33:55.969152
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:34:02.922409
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:34:05.086492
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-17 03:34:11.550655
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector should set
    _fact_class to SunOSVirtual and _platform to 'SunOS'
    """
    collector = SunOSVirtualCollector()
    assert collector._fact_class == SunOSVirtual
    assert collector._platform == 'SunOS'

# Generated at 2022-06-17 03:34:20.751195
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['container'] == 'zone'


# Generated at 2022-06-17 03:36:37.329552
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock of class SunOSVirtual
    mock_SunOSVirtual = MagicMock(spec=SunOSVirtual)
    mock_SunOSVirtual.module = module

    # Create a mock of method get_virtual_facts of class SunOSVirtual
    def mock_get_virtual_facts():
        return {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'container': 'zone'}

    mock_SunOSVirtual.get_virtual_facts = mock_get_virtual_facts

    # Create a mock of class SunOSVirtualCollector
    mock_SunOSVirtualCollector = MagicMock(spec=SunOSVirtualCollector)

# Generated at 2022-06-17 03:36:39.234365
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:51.495037
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-17 03:36:55.753415
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:59.727123
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:37:00.725844
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:37:05.071352
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen', 'zone'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-17 03:37:08.542205
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:37:11.849171
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:37:13.852892
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with empty argument
    x = SunOSVirtualCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSVirtual
    assert x._fact_class._platform == 'SunOS'