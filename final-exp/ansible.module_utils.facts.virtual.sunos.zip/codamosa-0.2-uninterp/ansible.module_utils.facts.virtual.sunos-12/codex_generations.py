

# Generated at 2022-06-17 03:29:17.958813
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:29:24.893384
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual
    assert SunOSVirtualCollector._platform == 'SunOS'

# Generated at 2022-06-17 03:29:27.689607
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:31.932699
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:36.755804
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:29:43.764350
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock of class SunOSVirtual
    mock_SunOSVirtual = MagicMock(spec=SunOSVirtual)
    mock_SunOSVirtual.module = module
    mock_SunOSVirtual.get_virtual_facts.return_value = {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'container': 'zone',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set(['zone'])
    }

    # Create a mock of class SunOSVirtualCollector
    mock_SunOSVirtualCollector = MagicMock(spec=SunOSVirtualCollector)
    mock_SunOSVirtualCollector._fact

# Generated at 2022-06-17 03:29:50.467911
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:29:59.417154
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False
    module.no_log = False
    module.debug = False
    module.verbosity = 0
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock

# Generated at 2022-06-17 03:30:09.073752
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock class
    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'zonename':
                return '/usr/bin/zonename'
            elif name == 'modinfo':
                return '/usr/sbin/modinfo'
            elif name == 'virtinfo':
                return '/usr/sbin/virtinfo'
            elif name == 'smbios':
                return '/usr/sbin/smbios'
            else:
                return None


# Generated at 2022-06-17 03:30:10.201675
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:23.711370
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:27.129947
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:30:28.311512
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    assert SunOSVirtual(dict()).platform == 'SunOS'

# Generated at 2022-06-17 03:30:34.061056
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}

    sunos_virtual = SunOSVirtual(module)
    sunos_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:30:40.721532
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_host']


# Generated at 2022-06-17 03:30:50.740152
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(module)
    module.get_bin_path = FakeGetBinPath(module)
    module.params = {}
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'


# Generated at 2022-06-17 03:30:59.414183
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    module.params['ansible_facts'] = {}
    module.params['ansible_facts']['ansible_virtualization_type'] = None
    module.params['ansible_facts']['ansible_virtualization_role'] = None

# Generated at 2022-06-17 03:31:09.553208
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.os_path = os.path
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:31:11.100301
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:31:13.658037
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:41.614370
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:53.390629
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

# Generated at 2022-06-17 03:31:55.010079
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:31:57.101341
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:59.355812
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:32:09.806424
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with a class that inherits from SunOSVirtualCollector
    class TestSunOSVirtualCollector(SunOSVirtualCollector):
        pass

    # Test with a class that does not inherit from SunOSVirtualCollector
    class TestVirtualCollector(VirtualCollector):
        pass

    # Test with a class that does not exist
    try:
        class TestVirtualCollector2(VirtualCollector2):
            pass
    except NameError:
        pass

    # Test with a class that is not a class
    try:
        class TestVirtualCollector3(object):
            pass
    except TypeError:
        pass

    # Test with a class that is not a class
    try:
        class TestVirtualCollector4(1):
            pass
    except TypeError:
        pass

    # Test with a class that is not a class
   

# Generated at 2022-06-17 03:32:15.280480
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:25.797486
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')

# Generated at 2022-06-17 03:32:32.537521
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

# Generated at 2022-06-17 03:32:34.193638
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:35.461435
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:38.854892
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:40.577432
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:42.930606
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:33:44.473994
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:33:46.326785
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:33:48.832391
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:33:57.121791
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert facts['virtualization_tech_host'] == set(['zone'])
    assert facts['container'] == 'zone'


# Generated at 2022-06-17 03:33:58.929924
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual
    assert vc._platform == 'SunOS'

# Generated at 2022-06-17 03:34:03.740782
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    module.exit_json = exit_json_mock
    module.fail_json = fail_json_mock
    module.warn = warn_mock
    module.deprecate = deprecate_mock
    SunOSVirtual(module)


# Generated at 2022-06-17 03:36:14.751459
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:21.287729
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.os_path = os.path
    module.os_path.isdir = MagicMock(return_value=True)
    module.os_path.exists = MagicMock(return_value=True)
    module.os_path.isfile = MagicMock(return_value=True)
    module.os_path.islink = MagicMock(return_value=True)

# Generated at 2022-06-17 03:36:23.568594
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:36:30.462414
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out="global")
    module.get_bin_path = FakeGetBinPath(path="/usr/sbin/zonename")
    module.get_bin_path = FakeGetBinPath(path="/usr/sbin/virtinfo")
    module.get_bin_path = FakeGetBinPath(path="/usr/sbin/smbios")
    module.get_bin_path = FakeGetBinPath(path="/usr/sbin/modinfo")
    module.run_command = FakeRunCommand(rc=0, out="modinfo: module not found")
    module.run_command = FakeRunCommand(rc=0, out="modinfo: module not found")

# Generated at 2022-06-17 03:36:35.970113
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()

    # Test a global zone
    module.run_command.set_command('zonename', 'global')
    module.os.path.isdir.set_isdir('/.SUNWnative', False)
    module.os.path.exists.set_exists('/proc/vz', False)
    module.get_bin_path.set_path('virtinfo', None)
    module.get_bin_path.set_path('smbios', None)
    module.get_bin_path.set_path('modinfo', None)


# Generated at 2022-06-17 03:36:40.200645
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:36:42.035522
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:43.928301
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:50.352002
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type == 'zone'
    assert virtual.virtualization_role == 'guest'
    assert virtual.container == 'zone'
    assert virtual.virtualization_tech_guest == set(['zone'])
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-17 03:36:55.449616
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with a class that has no _platform attribute
    class TestClass1():
        pass
    try:
        SunOSVirtualCollector(TestClass1)
    except TypeError:
        pass
    else:
        raise AssertionError("SunOSVirtualCollector should raise TypeError if the class does not have a _platform attribute")

    # Test with a class that has a _platform attribute
    class TestClass2():
        _platform = 'SunOS'
    try:
        SunOSVirtualCollector(TestClass2)
    except TypeError:
        raise AssertionError("SunOSVirtualCollector should not raise TypeError if the class has a _platform attribute")