

# Generated at 2022-06-17 03:29:19.109683
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.run_command.set_commands({
        'zonename': (0, 'global', ''),
        'modinfo': (0, '', ''),
        'virtinfo -p': (0, '', ''),
        'smbios': (0, '', ''),
    })
    module.get_bin_path = FakeGetBinPath()
    module.get_bin_path.set_paths({
        'zonename': '/usr/bin/zonename',
        'modinfo': '/usr/sbin/modinfo',
        'virtinfo': '/usr/sbin/virtinfo',
        'smbios': '/usr/sbin/smbios',
    })
    sunos_virtual = SunOSVirtual(module)


# Generated at 2022-06-17 03:29:20.328063
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:29:23.654640
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:29:30.353386
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a mock class
    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

    # Create a instance of MockSunOSVirtual
    mock_SunOSVirtual_instance = MockSunOSVirtual(module)

    # Set virtualization_type and virtualization_role to None
    mock_SunOSVirtual_instance.virtualization_type = None
    mock_SunOSVirtual_instance.virtualization_role = None

    # Set module.run_command to a mock function
    def mock_run_command(cmd, check_rc=True):
        if cmd == "zonename":
            return 0, "global", ""

# Generated at 2022-06-17 03:29:31.917724
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:36.756805
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:29:38.948667
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:29:42.216123
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:29:44.253969
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'
    assert virtual_facts.get_virtual_facts() is None

# Generated at 2022-06-17 03:29:45.995732
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:08.447490
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-17 03:30:11.863006
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:30:22.153821
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=False)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])

# Generated at 2022-06-17 03:30:27.939717
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(module)
    module.get_bin_path = FakeGetBinPath(module)
    module.os_path_exists = FakeOsPathExists(module)
    module.os_path_isdir = FakeOsPathIsDir(module)
    module.os_path_isfile = FakeOsPathIsFile(module)
    module.os_path_islink = FakeOsPathIsLink(module)
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:30:29.895711
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:38.361592
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:30:40.157112
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._fact_class == SunOSVirtual
    assert vc._platform == 'SunOS'

# Generated at 2022-06-17 03:30:48.840981
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'container' in virtual_facts

# Generated at 2022-06-17 03:30:57.250872
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)

    sunos_virtual = SunOSVirtual(module)
    sunos_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:30:58.595041
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:31.165202
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:31:39.383563
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:31:51.984410
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a mock class
    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'smbios':
                return '/usr/sbin/smbios'
            elif name == 'zonename':
                return '/usr/bin/zonename'
            elif name == 'modinfo':
                return '/usr/sbin/modinfo'
            elif name == 'virtinfo':
                return '/usr/sbin/virtinfo'
            else:
                return None


# Generated at 2022-06-17 03:31:57.872932
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:32:09.257586
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='global')
    module.get_bin_path = FakeGetBinPath(path='/usr/sbin/zonename')
    module.path_exists = FakePathExists(exists=False)
    module.isdir = FakeIsDir(isdir=False)
    module.get_file_content = FakeGetFileContent(content='')
    module.get_mount_size = FakeGetMountSize(size=0)
    module.get_mount_device = FakeGetMountDevice(device='')
    module.get_mount_point = FakeGetMountPoint(point='')
    module.get_mount_options = FakeGetMountOptions(options='')
    module.get_mount_uuid = FakeGet

# Generated at 2022-06-17 03:32:15.009365
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This is a test for the constructor of the class SunOSVirtualCollector.
    It checks that the class could be instantiated.
    """
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:32:17.008330
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.module == module


# Generated at 2022-06-17 03:32:18.358985
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:32:20.824430
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:25.899801
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:33:30.712784
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = type('', (), {})()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: x
    module.params = {}
    SunOSVirtualCollector(module)

# Generated at 2022-06-17 03:33:38.236878
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'container' in virtual_facts

# Generated at 2022-06-17 03:33:42.885477
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value='VMware')
    module.get_file_content = MagicMock(return_value='VMware')
    module.get_file_content = MagicMock(return_value='VMware')
    module.get_file_content = MagicMock

# Generated at 2022-06-17 03:33:44.681054
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:56.055212
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollectorException
    from ansible.module_utils.facts.virtual.base import VirtualException
    from ansible.module_utils.facts.virtual.base import VirtualFacts
    from ansible.module_utils.facts.virtual.base import VirtualParserException
    from ansible.module_utils.facts.virtual.base import VirtualPlatformException
    from ansible.module_utils.facts.virtual.base import VirtualUnsupportedException
    from ansible.module_utils.facts.virtual.base import VirtualUnsupportedPlatformException

# Generated at 2022-06-17 03:34:04.674526
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None
    assert virtual_facts['container'] is None

    # Test for a branded zone
    module.run

# Generated at 2022-06-17 03:34:05.657565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:34:16.013713
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:34:17.240655
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:34:18.523154
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:20.608836
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:23.004829
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:34.756432
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:36:40.228585
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:36:43.695167
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.virtualization_type is None
    assert virtual_facts.virtualization_role is None
    assert virtual_facts.container is None

# Generated at 2022-06-17 03:36:44.833697
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:46.119182
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:48.891782
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:36:55.649516
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()

    # Test case 1:
    #   - zonename command returns "global"
    #   - modinfo command returns "VMware"
    #   - /proc/vz does not exist
    #   - virtinfo command returns "DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false"
    #   - smbios command returns "VMware"
    #   - /.SUNWnative does not exist
    # Expected result:
    #   - virtualization_type: vmware
    #

# Generated at 2022-06-17 03:37:02.401444
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeOsPathIsDir()
    module.os.path.exists = FakeOsPathExists()
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
