

# Generated at 2022-06-17 03:29:10.618734
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:29:12.155073
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module)
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:29:21.679920
# Unit test for method get_virtual_facts of class SunOSVirtual

# Generated at 2022-06-17 03:29:30.043573
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual
    from ansible.module_utils.facts.virtual.sunos import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

# Generated at 2022-06-17 03:29:41.745247
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command

    # Test on a zone
    run_command_results = [
        (0, "global", ""),
        (0, "VMware", ""),
        (0, "VirtualBox", ""),
    ]
    run_command_calls = [
        call("zonename"),
        call("modinfo"),
        call("modinfo"),
    ]
    module.run_command.side_effect = lambda x: run_command_results.pop(0)

    virtual_facts = SunOSVirtual(module).get_virtual_facts()

    assert module.run_command.call_args_list == run_command_calls
    assert virtual_

# Generated at 2022-06-17 03:29:43.799457
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:55.875352
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.run_command.commands = {
        'zonename': (0, 'global', ''),
        'modinfo': (0, '', ''),
        'virtinfo': (0, '', ''),
        'smbios': (0, '', ''),
    }
    module.get_bin_path = FakeGetBinPath()
    module.get_bin_path.paths = {
        'zonename': '/usr/bin/zonename',
        'modinfo': '/usr/sbin/modinfo',
        'virtinfo': '/usr/sbin/virtinfo',
        'smbios': '/usr/sbin/smbios',
    }
    virtual = SunOSVirtual(module)
    virtual_facts

# Generated at 2022-06-17 03:30:00.046546
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:30:01.848358
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:10.046911
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual({})

    # Create a facts object
    facts = {'ansible_facts': {}}

    # Create a module object
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Set the module object as the module attribute of the SunOSVirtual object
    sunos_virtual.module = module

    # Set the facts object as the ansible_facts attribute of the module object
    module.ansible_facts = facts

    # Call the get_virtual_facts method of the SunOSVirtual object
    sunos_virtual.get_virtual_facts()

    # Assert that the ansible_facts attribute of the module object contains the virtualization_type key
    assert 'virtualization_type' in module.ansible_facts

# Generated at 2022-06-17 03:30:23.982736
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:30:32.878112
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a mock class
    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def run_command(self, cmd):
            if cmd == '/usr/bin/zonename':
                return (0, 'global', '')
            elif cmd == '/usr/bin/modinfo':
                return (0, '', '')
            elif cmd == '/usr/bin/virtinfo -p':
                return (0, '', '')
            elif cmd == '/usr/sbin/smbios':
                return

# Generated at 2022-06-17 03:30:41.674364
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:30:47.073378
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:52.399955
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc.platform == 'SunOS'
    assert vc.fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:53.786285
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:58.376739
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:02.478798
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:31:03.574726
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:31:05.058572
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:31:33.755019
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:31:39.578097
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:31:40.931123
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:43.898808
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:54.366046
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 1
    module.params['filter'] = '*'
    module.params['gather_network_resources'] = False
    module.params['gather_device_size'] = False
    module.params['gather_mount_size'] = False
    module.params['gather_package_facts'] = False
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 1
    module.params['filter'] = '*'
    module.params['gather_network_resources'] = False
    module.params['gather_device_size'] = False

# Generated at 2022-06-17 03:31:56.494919
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:58.072835
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:32:04.866505
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type == 'zone'
    assert virtual.virtualization_role == 'guest'
    assert virtual.container == 'zone'
    assert virtual.virtualization_tech_guest == set(['zone'])
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-17 03:32:09.348634
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:17.882415
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual

    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert issubclass(SunOSVirtual, Virtual)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:33:25.090090
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:33:27.287506
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:33:29.886423
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:37.865802
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    module.run_command.set_command('zonename', 'global', 0, 'global')
    module.run_command.set_command('modinfo', '', 0, 'modinfo: could not load module vmware: No such file or directory')
    module.run_command.set_command('virtinfo', '', 0, 'virtinfo: can only be run from the global zone')
    module.get_bin_path.set_path('zonename', '/usr/bin/zonename')

# Generated at 2022-06-17 03:33:39.363629
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:42.156181
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:33:43.683056
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:33:46.204319
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)

    # Test if the method returns a dictionary
    assert isinstance(virtual.get_virtual_facts(), dict)


# Generated at 2022-06-17 03:33:50.946706
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:33:55.977205
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:36:07.624501
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector.platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:36:16.017237
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert 'container' in virtual_facts
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:36:22.927555
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()


# Generated at 2022-06-17 03:36:25.516600
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:36:36.262357
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    # Test case 1:
    #   - SunOSVirtual.get_virtual_facts() returns a dict
    #   - SunOSVirtual.get_virtual_facts() returns a dict with keys:
    #       - virtualization_type
    #       - virtualization_role
    #       - container
    #       - virtualization_tech_guest
    #       - virtualization_tech_host
    #   - SunOSVirtual.get_virtual_facts() returns a dict with values:
    #       - virtualization_

# Generated at 2022-06-17 03:36:48.687211
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()

    sunos_virtual = SunOSVirtual(module)
    sunos_virtual.get_virtual_facts()

    module.run_command.assert_any_call('zonename')
    module.run_command.assert_any_call('modinfo')
    module.run_command.assert_any_call('smbios')

# Generated at 2022-06-17 03:36:50.477335
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector
    """
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:51.943362
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:37:01.727945
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import BaseVirtual
    from ansible.module_utils.facts.virtual.base import BaseVirtualCollector
    from ansible.module_utils.facts.virtual.base import BaseVirtualPlatform
    from ansible.module_utils.facts.virtual.base import BaseVirtualPlatformCollector

    assert issubclass(SunOSVirtual, Virtual)
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

# Generated at 2022-06-17 03:37:02.756506
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual