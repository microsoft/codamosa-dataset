

# Generated at 2022-06-17 03:29:13.430693
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:14.984742
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:17.776766
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:29:19.089199
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:29:29.449868
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()

    # Test a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=False)
    module.read_file = MagicMock(return_value='VMware')
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual

# Generated at 2022-06-17 03:29:31.765441
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None


# Generated at 2022-06-17 03:29:42.876936
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # Set the module.run_command mock
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Set the module.get_bin_path mock
    module.get_bin_path = MagicMock(return_value=True)

    # Set the os.path.isdir mock
    os.path.isdir = MagicMock(return_value=True)

    # Set the os.path.exists mock
    os.path.exists = MagicMock(return_value=True)

    # Get virtual facts
    virtual_facts = sunos_virtual.get_virtual_facts

# Generated at 2022-06-17 03:29:55.087471
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-17 03:29:57.454222
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:00.494711
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no args
    SunOSVirtualCollector()
    # Test with args
    SunOSVirtualCollector(None, None, None, None, None, None)

# Generated at 2022-06-17 03:30:15.018686
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:23.055034
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=(0, 0, 0, 0, 0, 0))
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value='VMware')
    module.get_file_content = MagicMock(return_value='VMware')
    module.get_file_content = MagicMock(return_value='VMware')
    module

# Generated at 2022-06-17 03:30:24.251455
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:36.541690
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)

    # Test a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/zonename')
    module.isdir = MagicMock(return_value=False)
    module.exists = MagicMock(return_value=False)
    module.get_bin_path = MagicMock(return_value=None)
    module.run_command = MagicMock(return_value=(0, '', ''))
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'

# Generated at 2022-06-17 03:30:38.476520
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    vc = SunOSVirtualCollector()
    assert vc._platform == 'SunOS'
    assert vc._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:44.613041
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/sbin/virtinfo')
    module.run_command = Mock(return_value=(0, 'DOMAINROLE|impl=LDoms|control=false|io=false|service=false|root=false', ''))
    virtual = SunOSVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'ldom'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['ldom'])
    assert facts['virtualization_tech_host'] == set()
    assert 'container' not in facts

# Generated at 2022-06-17 03:30:55.510729
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        rc=0,
        out='global',
        err=''
    )
    module.get_bin_path = FakeGetBinPath(
        bin_path='/usr/sbin/zonename'
    )
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'container' not in virtual_facts

    module = FakeAnsibleModule()

# Generated at 2022-06-17 03:30:56.858120
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:30:58.217238
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual({})
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:30:59.471228
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:31:27.447415
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    module.os.uname = FakeUname()
    module.os.path.isfile = FakeIsFile()

    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'zone' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-17 03:31:29.442403
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:30.545279
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:31:32.255137
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:31:35.953538
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:38.166421
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virt = SunOSVirtual(module)
    assert virt.platform == 'SunOS'


# Generated at 2022-06-17 03:31:49.767011
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:31:53.696122
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:31:56.338181
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:58.320370
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:32:52.996849
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:54.261713
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:32:57.048173
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:32:59.137876
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:33:00.640867
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:03.265703
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:33:11.210190
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()
    assert virtual.container == ''

# Generated at 2022-06-17 03:33:12.493813
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:18.450195
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeOsPathIsDir()
    module.os.path.exists = FakeOsPathExists()

    # Test case 1: zonename is not installed
    module.get_bin_path.return_value = None
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {}

    # Test case 2: zonename is installed, but not in a zone
    module.get_bin_path.return_value = '/usr/bin/zonename'
    module.run_command.return_value = (0, 'global', '')
    virtual = SunOSVirtual(module)


# Generated at 2022-06-17 03:33:19.741448
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:35:03.308499
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:35:07.742330
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    virtual_collector = SunOSVirtualCollector()
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:35:13.512724
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value=True)
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=False)

# Generated at 2022-06-17 03:35:15.091565
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:35:17.634560
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'

# Generated at 2022-06-17 03:35:19.393119
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:35:26.918613
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False

    # Test with a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=False)
    module.read_file = MagicMock(return_value='VMware')
    virtual = SunOS

# Generated at 2022-06-17 03:35:31.555660
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:35:39.736463
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_guest']
    assert 'zone' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-17 03:35:43.208006
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'