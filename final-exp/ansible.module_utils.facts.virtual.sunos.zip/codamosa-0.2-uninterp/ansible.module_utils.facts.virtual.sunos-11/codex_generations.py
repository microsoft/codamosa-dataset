

# Generated at 2022-06-17 03:29:19.387357
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:29:28.953871
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    sunos_virtual = SunOSVirtual(module)
    sunos_virtual.get_virtual_facts()
    assert sunos_virtual.facts['virtualization_type'] == 'vmware'
    assert sunos_virtual.facts['virtualization_role'] == 'guest'
    assert sunos_virtual.facts['virtualization_tech_guest'] == set(['vmware'])

# Generated at 2022-06-17 03:29:30.043492
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:41.744873
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'testzone', ''))
    module.stat = MagicMock(side_effect=OSError)
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get

# Generated at 2022-06-17 03:29:45.767792
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:29:47.507219
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:52.007479
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-17 03:29:59.303425
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value=True)
    module.run_command = Mock(return_value=(0, '', ''))
    module.params = {}
    module.exit_json = Mock()
    module.fail_json = Mock()
    module.check_mode = False

    # Test for a zone
    module.run_command = Mock(return_value=(0, 'global', ''))
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['container'] == 'zone'
    assert 'zone' in virtual_facts['virtualization_tech_host']
    assert 'zone' not in virtual_facts['virtualization_tech_guest']

    # Test for a branded zone
   

# Generated at 2022-06-17 03:30:06.123686
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt_facts = SunOSVirtual(module).get_virtual_facts()
    assert virt_facts['virtualization_type'] == 'kvm'
    assert virt_facts['virtualization_role'] == 'guest'
    assert virt_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virt_facts['virtualization_tech_host'] == set()
    assert virt_facts['container'] == 'zone'

# Generated at 2022-06-17 03:30:08.760289
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:30:26.976313
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    This function is used to test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._fact_class == SunOSVirtual
    assert sunos_virtual_collector._platform == 'SunOS'

# Generated at 2022-06-17 03:30:34.233041
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:30:43.437457
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # Create a facts dictionary
    facts = dict()

    # Get virtualization facts
    virtual_facts = sunos_virtual.get_virtual_facts()

    # Assert that the virtualization facts are correct
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:30:53.980485
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:30:54.994687
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:58.323058
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.container is None
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-17 03:31:04.404647
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone', 'vmware'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])


# Generated at 2022-06-17 03:31:15.044412
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen', 'zone'])
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])

# Generated at 2022-06-17 03:31:20.253063
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:22.668947
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:51.725924
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Test the constructor of class SunOSVirtualCollector
    """
    sunos_virtual_collector = SunOSVirtualCollector()
    assert sunos_virtual_collector._platform == 'SunOS'
    assert sunos_virtual_collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:53.567168
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:56.815988
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    facts = SunOSVirtualCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:58.748257
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:32:09.068895
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(module)
    module.get_bin_path = FakeGetBinPath(module)
    module.params = {}
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm', 'zone'])
    assert virtual_facts['container'] == 'zone'


# Generated at 2022-06-17 03:32:11.674926
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:32:15.427779
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:25.597500
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.run_command.set_command('zonename', 'global', 0, 'global\n')
    module.run_command.set_command('modinfo', '', 0, 'modinfo: VMware\n')
    module.run_command.set_command('smbios', '', 0, 'smbios: VMware\n')
    module.get_bin_path = FakeGetBinPath()
    module.get_bin_path.set_command('zonename', '/usr/bin/zonename')
    module.get_bin_path.set_command('modinfo', '/usr/bin/modinfo')
    module.get_bin_path.set_command('smbios', '/usr/bin/smbios')
    virtual = SunOSVirtual

# Generated at 2022-06-17 03:32:27.354679
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:32:37.804600
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock(return_value=True)
    module.fail_json = MagicMock(return_value=True)
    module.check_mode = False

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=False)

# Generated at 2022-06-17 03:33:39.168589
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:33:42.807586
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    """
    Constructor of SunOSVirtualCollector can be invoked.
    """
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:33:44.353074
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:45.907867
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:47.738397
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:49.279504
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual = SunOSVirtual(dict())
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:33:51.652153
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = FakeAnsibleModule()
    sunos_virtual = SunOSVirtual(module)
    assert sunos_virtual.platform == 'SunOS'
    assert sunos_virtual.module == module


# Generated at 2022-06-17 03:33:59.152187
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:34:09.622425
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.os_path = os.path
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:34:18.377400
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.sunos import VirtualMetaClass
    from ansible.module_utils.facts.virtual.sunos import VirtualFactCollector
    from ansible.module_utils.facts.virtual.sunos import VirtualFactCollectorMetaClass
    from ansible.module_utils.facts.virtual.sunos import VirtualFactCache
    from ansible.module_utils.facts.virtual.sunos import VirtualFactCacheMetaClass

# Generated at 2022-06-17 03:36:24.377367
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual({})

    # Create a fake module
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/bin/' + args[0]
    sunos_virtual.module = module

    # Test get_virtual_facts
    assert sunos_virtual.get_virtual_facts() == {
        'virtualization_type': 'zone',
        'virtualization_role': 'guest',
        'container': 'zone',
        'virtualization_tech_guest': set(['zone']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-17 03:36:35.814081
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt = SunOSVirtual(module)

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, "global", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/zonename")
    module.isdir = MagicMock(return_value=False)
    module.exists = MagicMock(return_value=False)
    module.get_bin_path = MagicMock(return_value=None)
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'host'
    assert facts['container'] == 'zone'
    assert facts['virtualization_tech_guest'] == set()


# Generated at 2022-06-17 03:36:36.551934
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:49.044702
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModuleMock()
    module.run_command = AnsibleRunCommandMock(0, "global", "")
    module.get_bin_path = AnsibleGetBinPathMock(True)
    module.get_bin_path.side_effect = ["/usr/sbin/zonename", "/usr/sbin/modinfo", "/usr/sbin/virtinfo", "/usr/sbin/smbios"]
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])

# Generated at 2022-06-17 03:36:49.911743
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:36:55.566885
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    assert virtual.platform == 'SunOS'


# Generated at 2022-06-17 03:37:02.539281
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeOsPathIsDir()
    module.os.path.exists = FakeOsPathExists()
    module.os.path.isfile = FakeOsPathIsFile()
    module.os.stat = FakeOsStat()

    # Test case 1:
    #   - global zone
    #   - no virtualization

# Generated at 2022-06-17 03:37:16.396637
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with a class that has no _platform attribute
    class TestClass1:
        pass
    try:
        SunOSVirtualCollector(TestClass1)
    except TypeError as e:
        assert 'does not appear to be a subclass of Virtual' in str(e)

    # Test with a class that has a _platform attribute but it's not SunOS
    class TestClass2:
        _platform = 'Linux'
    try:
        SunOSVirtualCollector(TestClass2)
    except TypeError as e:
        assert 'does not appear to be a subclass of SunOSVirtual' in str(e)

    # Test with a class that has a _platform attribute and it's SunOS
    class TestClass3:
        _platform = 'SunOS'

# Generated at 2022-06-17 03:37:27.458590
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    module.os.path.isfile = FakeIsFile()
    module.os.stat = FakeStat()
    module.os.access = FakeAccess()
    module.os.getuid = FakeGetUid()
    module.os.getgid = FakeGetGid()
    module.os.geteuid = FakeGetEuid()
    module.os.getegid = FakeGetEgid()
    module.os.getgroups = FakeGetGroups()
    module.os.getenv = FakeGetEnv()

# Generated at 2022-06-17 03:37:38.113415
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # Create a facts object
    facts = dict()

    # Get virtualization facts
    sunos_virtual.get_virtual_facts(facts)

    # Assert that the virtualization_type is set to 'zone'
    assert facts['virtualization_type'] == 'zone'

    # Assert that the virtualization_role is set to 'guest'
    assert facts['virtualization_role'] == 'guest'

    # Assert that the container is set to 'zone'
    assert facts['container'] == 'zone'

    # Assert that the virtualization_tech_guest is set to 'zone'