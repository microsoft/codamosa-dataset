

# Generated at 2022-06-17 03:29:10.384373
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:29:11.019263
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no params
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:29:20.153232
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a fake module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    # Create a SunOSVirtual object
    sunos_virtual = SunOSVirtual(module)

    # Test get_virtual_facts
    sunos_virtual.get_virtual_facts()
    assert sunos_virtual.facts['virtualization_type'] == 'vmware'
    assert sunos_virtual.facts['virtualization_role'] == 'guest'
    assert sunos_virtual.facts['virtualization_tech_guest'] == set(['vmware'])
    assert sunos_virtual.facts['virtualization_tech_host'] == set(['zone'])
    assert sun

# Generated at 2022-06-17 03:29:29.384307
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeOsPathIsDir()
    module.os.path.exists = FakeOsPathExists()
    module.os.path.isfile = FakeOsPathIsFile()
    module.os.stat = FakeOsStat()
    module.os.access = FakeOsAccess()
    module.os.getuid = FakeOsGetuid()
    module.os.getgid = FakeOsGetgid()
    module.os.geteuid = FakeOsGeteuid()
    module.os.getegid = FakeOsGetegid()
    module.os.getgroups = FakeOsGetgroups()
    module.os.getenv = FakeOs

# Generated at 2022-06-17 03:29:30.848343
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:29:34.492279
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:36.086423
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:29:43.448716
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:29:55.623735
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')

# Generated at 2022-06-17 03:29:57.244947
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:30:21.210006
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='VMware')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.os_path = os.path

    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:30:27.594598
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value=True)
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False
    module.run_command.return_value = (0, 'global', '')
    module.get_bin_path.return_value = '/usr/sbin/virtinfo'
    module.read_file.return_value = 'VMware'
    module.stat.return_value = True


# Generated at 2022-06-17 03:30:37.749921
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    module.get_bin_path.side_effect = FakeGetBinPathSideEffect()
    module.run_command.side_effect = FakeRunCommandSideEffect()
    module.os.path.isdir.side_effect = FakeIsDirSideEffect()
    module.os.path.exists.side_effect = FakeExistsSideEffect()
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-17 03:30:40.157135
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    v = SunOSVirtual({})
    assert v.platform == 'SunOS'
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.container is None


# Generated at 2022-06-17 03:30:51.578452
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()

    # Test for a zone
    module.run_command.set_output('zonename', 0, 'global')
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['container'] == ''

    # Test for a branded zone
    module.run_command.set_output('zonename', 0, 'global')

# Generated at 2022-06-17 03:30:53.534392
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual({})
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:30:55.754550
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert issubclass(SunOSVirtualCollector, VirtualCollector)
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:30:57.106724
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:31:02.889281
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.isdir = MagicMock(return_value=True)
    module.exists = MagicMock(return_value=True)
    module.get_platform = MagicMock(return_value='SunOS')
    module.get_distribution = MagicMock(return_value='SunOS')
    module.get_distribution_version = MagicMock(return_value='5.11')

# Generated at 2022-06-17 03:31:06.376993
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    sunos_virtual = SunOSVirtual(module)
    facts = sunos_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set()
    assert facts['container'] == 'zone'


# Generated at 2022-06-17 03:31:36.718928
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['container'] == 'zone'

# Generated at 2022-06-17 03:31:45.265990
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual

    # Test that SunOSVirtualCollector is a subclass of VirtualCollector
    assert issubclass(SunOSVirtualCollector, VirtualCollector)

    # Test that SunOSVirtualCollector is a subclass of FactCollector
    assert issubclass(SunOSVirtualCollector, FactCollector)

    # Test that SunOSVirtualCollector is a subclass of object
    assert issubclass(SunOSVirtualCollector, object)

    # Test that SunOSVirtual is

# Generated at 2022-06-17 03:31:55.088879
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # Test for a zone
    set_module_args(dict(
        gather_subset='!all',
        gather_timeout=10,
    ))

# Generated at 2022-06-17 03:32:07.597044
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()

    # Test on a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=False)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-17 03:32:10.241120
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:20.012924
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    module.stat = MagicMock(return_value=True)
    module.os.path.isdir = MagicMock(return_value=False)
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-17 03:32:25.411592
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    x = SunOSVirtualCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:31.453096
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/sbin/zonename')
    module.run_command = Mock(return_value=(0, 'global', ''))
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['container'] == ''


# Generated at 2022-06-17 03:32:36.599497
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:32:38.512410
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:33:39.643712
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = SunOSVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:33:49.796940
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.stat = MagicMock(return_value=True)
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False

    # Test for a zone
    module.run_command = MagicMock(return_value=(0, 'global', ''))
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-17 03:33:51.226077
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:33:58.101696
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a SunOSVirtual object
    virtual_facts = SunOSVirtual(module)

    # Test get_virtual_facts
    facts = virtual_facts.get_virtual_facts()
    assert facts['virtualization_type'] == 'zone'
    assert facts['virtualization_role'] == 'guest'
    assert facts['container'] == 'zone'
    assert facts['virtualization_tech_guest'] == set(['zone'])
    assert facts['virtualization_tech_host'] == set(['zone'])

# Generated at 2022-06-17 03:34:03.894365
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'container' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:34:07.413745
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'


# Generated at 2022-06-17 03:34:10.223709
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual(dict())
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:34:20.892937
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class
    class MockSunOSVirtual(SunOSVirtual):
        def __init__(self, module):
            self.module = module

    # Create a mock class
    class MockFile(object):
        def __init__(self, path, content):
            self.path = path
            self.content = content

        def read(self):
            return self.content

    # Create a mock class
    class MockOs(object):
        def __init__(self, path, content):
            self.path = path
            self.content = content

        def path(self):
            return self.path

    # Create a mock class
    class MockModule(object):
        def __init__(self, path, content):
            self.path

# Generated at 2022-06-17 03:34:22.200612
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:34:30.942248
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(module)
    module.get_bin_path = FakeGetBinPath(module)
    module.params = {}
    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'zone'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['container'] == 'zone'
    assert virtual_facts['virtualization_tech_guest'] == set(['zone'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:36:37.844011
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    module.params['fact_path'] = '/etc/ansible/facts.d'
    module.params['fact_basename'] = 'virtual_facts'
    module.params['module_setup'] = False
    module.params['module_setup_show_complex_facts'] = False
    module.params['module_setup_show_legacy_facts'] = False
    module.params['module_setup_list_facts'] = False
    module

# Generated at 2022-06-17 03:36:50.395273
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeOsPathIsDir()
    module.os.path.exists = FakeOsPathExists()

    # Test case 1: zone
    module.run_command.set_command('zonename', 0, 'global', '')
    module.os.path.isdir.set_isdir('/.SUNWnative', False)
    module.os.path.exists.set_exists('/proc/vz', False)
    module.get_bin_path.set_path('modinfo', True)
    module.run_command.set_command('modinfo', 0, '', '')

# Generated at 2022-06-17 03:36:51.256347
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    # Test with no args
    SunOSVirtualCollector()

# Generated at 2022-06-17 03:36:55.421890
# Unit test for constructor of class SunOSVirtual
def test_SunOSVirtual():
    virtual_facts = SunOSVirtual()
    assert virtual_facts.platform == 'SunOS'

# Generated at 2022-06-17 03:36:56.855299
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    assert SunOSVirtualCollector._platform == 'SunOS'
    assert SunOSVirtualCollector._fact_class == SunOSVirtual

# Generated at 2022-06-17 03:37:01.168658
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    module = FakeModule()
    virtual_collector = SunOSVirtualCollector(module)
    assert virtual_collector._platform == 'SunOS'
    assert virtual_collector._fact_class == SunOSVirtual


# Generated at 2022-06-17 03:37:10.003131
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.os.path.isdir = FakeIsDir()
    module.os.path.exists = FakeExists()
    module.os.access = FakeAccess()
    module.get_file_content = FakeGetFileContent()

    virtual = SunOSVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:37:18.727403
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualOptions

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, arg):
            if arg == 'zonename':
                return '/usr/bin/zonename'
            elif arg == 'modinfo':
                return '/usr/sbin/modinfo'
            elif arg == 'virtinfo':
                return '/usr/sbin/virtinfo'

# Generated at 2022-06-17 03:37:28.713206
# Unit test for method get_virtual_facts of class SunOSVirtual
def test_SunOSVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='global')
    module.get_bin_path = FakeGetBinPath(path='/usr/sbin/zonename')
    module.os.path.isdir = FakeOsPathIsDir(isdir=False)
    module.os.path.exists = FakeOsPathExists(exists=False)

    sunos_virtual = SunOSVirtual(module)
    virtual_facts = sunos_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['zone'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
   

# Generated at 2022-06-17 03:37:32.116992
# Unit test for constructor of class SunOSVirtualCollector
def test_SunOSVirtualCollector():
    collector = SunOSVirtualCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSVirtual