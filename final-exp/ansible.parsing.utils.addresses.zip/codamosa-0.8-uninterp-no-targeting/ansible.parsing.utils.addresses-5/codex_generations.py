

# Generated at 2022-06-20 23:30:00.168182
# Unit test for function parse_address
def test_parse_address():
    # A trivial case with a hostname, a port, and no ranges.
    assert parse_address('www.example.com:80') == ('www.example.com', 80)

    # Note that www.example.com is a valid hostname in Ansible's universe, but
    # not necessarily in DNS (for example, it is not less than 64 characters).
    # And [www.example.com]:80 is valid, but not [www.example.com:80].
    assert parse_address('[www.example.com]:80') == ('www.example.com', 80)
    with pytest.raises(AnsibleParserError):
        parse_address('[www.example.com:80]')

    assert parse_address('127.0.0.1:80') == ('127.0.0.1', 80)
    assert parse

# Generated at 2022-06-20 23:30:11.045302
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:21.946306
# Unit test for function parse_address
def test_parse_address():
    def c(addr, host, port, allow_ranges=False):
        (h, p) = parse_address(addr, allow_ranges)
        assert(h == host)
        assert(p == port)

    c('example.com', 'example.com', None, True)
    c('example.com', 'example.com', None)
    c('example.com[1:2]', 'example.com[1:2]', None, True)
    with pytest.raises(AnsibleParserError):
        c('example.com[1:2]', 'example.com[1:2]', None, False)

    c('[::1]', '::1', None, True)
    c('[::1]', '::1', None)

# Generated at 2022-06-20 23:30:35.837134
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('10.0.2.3') == ('10.0.2.3', None)
    assert parse_address('10.0.2.3:22') == ('10.0.2.3', 22)
    assert parse_address('host.example.com') == ('host.example.com', None)
    assert parse_address('host.example.com:22') == ('host.example.com', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)

# Generated at 2022-06-20 23:30:48.183029
# Unit test for function parse_address
def test_parse_address():
    x = parse_address("foo:99")
    assert (x == ("foo", 99))

    x = parse_address("127.0.0.1:99")
    assert (x == ("127.0.0.1", 99))

    x = parse_address("127.0.0.1:99", allow_ranges=True)
    assert (x == ("127.0.0.1", 99))

    x = parse_address("[::1]:99")
    assert (x == ("::1", 99))

    x = parse_address("[::1]:99", allow_ranges=True)
    assert (x == ("::1", 99))

    x = parse_address("foo[1:3]")
    assert (x[0] == "foo")


# Generated at 2022-06-20 23:31:01.209748
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:5353') == ('localhost', 5353)
    assert parse_address('[localhost]') == ('localhost', None)
    assert parse_address('[localhost]:5353') == ('localhost', 5353)
    assert parse_address('localhost[1:2]') == ('localhost[1:2]', None)
    assert parse_address('localhost[1:2]:5353') == ('localhost[1:2]', 5353)
    assert parse_address('localhost[x-z]') == ('localhost[x-z]', None)
    assert parse_address('localhost[x-z]:5353') == ('localhost[x-z]', 5353)

# Generated at 2022-06-20 23:31:15.296353
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('machine') == ('machine', None)
    assert parse_address('machine:80') == ('machine', 80)

    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:80') == ('1.2.3.4', 80)

    assert parse_address('1.2.3[0:3].4') == ('1.2.3[0:3].4', None)
    assert parse_address('1.2.3[0:3].4:80') == ('1.2.3[0:3].4', 80)
    assert parse_address('[1.2.3[0:3].4]:80') == ('1.2.3[0:3].4', 80)

   

# Generated at 2022-06-20 23:31:26.960213
# Unit test for function parse_address
def test_parse_address():
    def check(host, port, expected):
        (got_host, got_port) = parse_address(host, port)
        assert got_host == expected[0]
        assert got_port == expected[1]

    # Class of address       Host             Port      Expected Result
    # -----------------------------------------------------------------------
    check("192.0.2.3:21",   None,            (None,    None))
    check("192.0.2.3",      None,            ("192.0.2.3", None))
    check("192.0.2.3",      True,            ("192.0.2.3", None))
    check("192.0.2.3:21",   None,            ("192.0.2.3", 21))

# Generated at 2022-06-20 23:31:41.454698
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:53.505291
# Unit test for function parse_address
def test_parse_address():
    host = '[::1]:22'
    assert parse_address(host) == ('[::1]', 22)
    try:
        parse_address(host, allow_ranges=False)
        assert False
    except AnsibleParserError:
        pass

    host = '::1'
    assert parse_address(host) == (host, None)
    try:
        parse_address(host, allow_ranges=False)
        assert False
    except AnsibleParserError:
        pass

    host = '::1'
    assert parse_address(host, allow_ranges=True) == (host, None)

    host = '127.0.0.1:22'
    assert parse_address(host) == ('127.0.0.1', 22)