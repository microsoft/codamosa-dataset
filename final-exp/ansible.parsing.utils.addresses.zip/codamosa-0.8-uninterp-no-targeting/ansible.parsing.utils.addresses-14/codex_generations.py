

# Generated at 2022-06-20 23:30:05.104696
# Unit test for function parse_address
def test_parse_address():
    def should_fail(a):
        try:
            parse_address(a)
            raise Exception("Test failed: should have failed but didn't: %s" % a)
        except AnsibleError:
            return True

    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:1234') == ('example.com', 1234)
    assert parse_address('example.com:65535') == ('example.com', 65535)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:1234') == ('127.0.0.1', 1234)

# Generated at 2022-06-20 23:30:13.509730
# Unit test for function parse_address
def test_parse_address():
    from ansible import constants as C
    from ansible.compat.tests import unittest


# Generated at 2022-06-20 23:30:24.907778
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:38.452387
# Unit test for function parse_address
def test_parse_address():
    def check(address, host, port):
        test_host, test_port = parse_address(address)
        assert test_host == host and test_port == port, "%r -> %r, %r" % (address, test_host, test_port)

    def check_error(address):
        try:
            parse_address(address)
            assert False, "Expected an error for %r" % (address,)
        except (AnsibleError, AnsibleParserError):
            pass

    # Various valid addresses.

    for host in [ "foo", "www.example.com", "192.0.2.254", "::1",
                  "dead:beef:cafe:babe:dead:beef:cafe:babe" ]:
        check(host, host, None)


# Generated at 2022-06-20 23:30:52.839084
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('1.2.3.4:5678') == ('1.2.3.4', 5678)
    assert parse_address('1.2.3.4:5678', True) == ('1.2.3.4', 5678)

    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4', True) == ('1.2.3.4', None)

    assert parse_address('[1.2.3.4]:5678') == ('1.2.3.4', 5678)
    assert parse_address('[1.2.3.4]:5678', True) == ('1.2.3.4', 5678)


# Generated at 2022-06-20 23:31:07.142097
# Unit test for function parse_address
def test_parse_address():
    # Test basic hostname parsing
    assert parse_address('host') == ('host', None)
    assert parse_address('host.example.com') == ('host.example.com', None)
    # Test with hexadecimal ranges in the hostname
    assert parse_address('[a-z]') == ('[a-z]', None)
    assert parse_address('f[a-z]o') == ('f[a-z]o', None)
    assert parse_address('f[a-z]o.example.com') == ('f[a-z]o.example.com', None)
    assert parse_address('f[0-9]o.example.com') == ('f[0-9]o.example.com', None)

# Generated at 2022-06-20 23:31:13.028911
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:1234') == ('foo.example.com', 1234)
    assert parse_address('foo[1:3].example.com:1234') == ('foo[1:3].example.com', 1234)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]-bar[a-z]:1234') == ('foo[1:3]-bar[a-z]', 1234)
    assert parse_address('[127.0.0.1]:1234') == ('127.0.0.1', 1234)

# Generated at 2022-06-20 23:31:25.814186
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('host:42') == ('host', 42)
    assert parse_address('host') == ('host', None)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:42') == ('1.2.3.4', 42)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)
    assert parse_address('[::ffff:192.0.2.3]:42') == ('::ffff:192.0.2.3', 42)
    assert parse_address('[::]:42') == ('::', 42)

# Generated at 2022-06-20 23:31:36.096631
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('foobar:22') == ('foobar', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[foo.example.com]') == ('foo.example.com', None)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)

# Generated at 2022-06-20 23:31:41.262911
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None)
    assert parse_address('[2001:db8::1]') == ('[2001:db8::1]', None)
    assert parse_address('[::1]') == ('[::1]', None)
    assert parse_address('[::1]') == ('[::1]', None)
    assert parse_address('[::1]') == ('[::1]', None)
    assert parse_address('[::1]') == ('[::1]', None)
    assert parse_address('[::1]:123') == ('[::1]', 123)
    assert parse_address('[fe80::1%lo0]:123') == ('[fe80::1%lo0]', 123)