

# Generated at 2022-06-20 23:30:08.757946
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:19.418992
# Unit test for function parse_address
def test_parse_address():
    # Test valid IPv4 patterns
    assert parse_address('1:2:3:4:5:6:7:8') == ('1:2:3:4:5:6:7:8', None)
    assert parse_address('[1:2:3:4:5:6:7:8]') == ('1:2:3:4:5:6:7:8', None)
    assert parse_address('[1:2:3:4:5:6:7:8]:1234') == ('1:2:3:4:5:6:7:8', 1234)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)

# Generated at 2022-06-20 23:30:34.034131
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:44.200055
# Unit test for function parse_address
def test_parse_address():
    for address in [
        'foo.example.com',
        'foo.example.com:22',
        'foo.example.com:22',
        'foo[1:3].example.com',
        'foo[1:3].example.com:22',
        '192.0.2.3',
        '192.0.2.3:22',
        '[192.0.2.3]',
        '[192.0.2.3]:22',
        '2001:db8::1',
        '[2001:db8::1]',
        '[2001:db8::1]:22',
        '10.0.0.0/8',
    ]:
        (host, port) = parse_address(address)
        assert host is not None, address
        assert port is not None, address

# Generated at 2022-06-20 23:30:56.599370
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:11.330499
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:80') == ('foo.example.com', 80)
    assert parse_address('foo.example.com:8080') == ('foo.example.com', 8080)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:8080') == ('example.com', 8080)
    assert parse_address('192.168.11.12') == ('192.168.11.12', None)
    assert parse_address('192.168.11.12:8080') == ('192.168.11.12', 8080)

# Generated at 2022-06-20 23:31:24.548223
# Unit test for function parse_address
def test_parse_address():
    # Some corner cases we need to check for

    # No host given
    result = parse_address('')
    assert result == (None, None), \
        '''parse_address() failed to fail when parsing the empty string'''

    # No port given
    result = parse_address('somehost')
    assert result == ('somehost', None), \
        '''parse_address() failed to parse 'somehost' without a port'''

    # No host given when port is specified
    result = parse_address(':22')
    assert result == (None, None), \
        '''parse_address() failed to fail when parsing ':22' for a host'''

    # Parse success for various different forms of host address

# Generated at 2022-06-20 23:31:38.950075
# Unit test for function parse_address
def test_parse_address():
    # Test with no port specified
    assert parse_address('[::1]') == (':1', None)
    assert parse_address('[::1]', allow_ranges=True) == (':1', None)
    assert parse_address('foo[1:2].example.com') == ('foo[1:2].example.com', None)
    assert parse_address('foo[1:2].example.com', allow_ranges=True) == ('foo[1:2].example.com', None)
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1', allow_ranges=True) == ('192.168.1.1', None)

    # Test with port specified

# Generated at 2022-06-20 23:31:51.260138
# Unit test for function parse_address
def test_parse_address():
    """
    Structure: (test_input, expected_result)
    """

# Generated at 2022-06-20 23:32:04.150089
# Unit test for function parse_address
def test_parse_address():
    def _test(inp, expected_host, expected_port):
        if expected_host is None:
            expected = None
        else:
            expected = (expected_host, expected_port)
        actual = parse_address(inp)
        assert actual == expected, "'%s' -> '%s' != '%s'" % (inp, actual, expected)

    _test(None, None, None)
    _test('', None, None)
    _test(' ', None, None)
    _test('127.0.0.1', '127.0.0.1', None)
    _test('localhost', 'localhost', None)
    _test('localhost:22', 'localhost', 22)
    _test('[127.0.0.1]', '127.0.0.1', None)
    _test

# Generated at 2022-06-20 23:32:15.701346
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:5') == ('foo', 5)
    assert parse_address('foo:0015') == ('foo', 15)
    assert parse_address('foo:100', allow_ranges=True) == ('foo:100', None)
    assert parse_address('foo[1:4]') == ('foo[1:4]', None)
    assert parse_address('foo[1:4]:5') == ('foo[1:4]', 5)
    assert parse_address('foo[1:4]:005', allow_ranges=True) == ('foo[1:4]:005', None)
    assert parse_address('foo[1-4]') == ('foo[1-4]', None)

# Generated at 2022-06-20 23:32:28.249257
# Unit test for function parse_address
def test_parse_address():
    # Test simple expressions
    assert parse_address("[192.168.1.1]:5678") == ('192.168.1.1', 5678)
    assert parse_address("[192.168.1.1]") == ('192.168.1.1', None)
    assert parse_address("192.168.1.1") == ('192.168.1.1', None)
    assert parse_address("server1") == ('server1', None)
    assert parse_address("server1:22") == ('server1', 22)
    assert parse_address("[server1:22]") == ('server1:22', None)
    assert parse_address("server1[1:3]:22") == ('server1[1:3]', 22)

    # Test range expressions

# Generated at 2022-06-20 23:32:38.386757
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('[::1]:22') == ('[::1]', 22)
    assert parse_address('[::ffff:1.2.3.4]') == ('[::ffff:1.2.3.4]', None)
    assert parse_address('server.example.com') == ('server.example.com', None)

    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('[::ffff:1.2.3.4]:22') == ('[::ffff:1.2.3.4]', 22)

# Generated at 2022-06-20 23:32:50.629395
# Unit test for function parse_address

# Generated at 2022-06-20 23:33:01.280691
# Unit test for function parse_address

# Generated at 2022-06-20 23:33:13.456706
# Unit test for function parse_address
def test_parse_address():
    for string in ('foo', 'foo.example.com', '127.0.0.1', 'fe80::1', 'fe80::1:2',
                   '[fe80::1]', '[fe80::1]:22', '[fe80::1]:2222',
                   '[fe80::1:2]:23', 'fe80::1:2:3', '[fe80::1:2:3]:24',
                   '[fe80::1:2:3]', '[fe80::1:2:3]',
                   '192.0.2.1', '[192.0.2.1]', '[192.0.2.1]:25',
                   '192.0.2.1:26', '[192.0.2.1]:27'):
        assert parse_address(string)

# Generated at 2022-06-20 23:33:20.044433
# Unit test for function parse_address
def test_parse_address():
    import pytest

    def check(input, result):
        p = parse_address(input)
        assert p == result

    check('foo', ('foo', None))
    with pytest.raises(AnsibleError) as excinfo:
        check('[', ('[', None))
    check('[foo]', ('foo', None))
    check('[foo]:2222', ('foo', 2222))
    check('[1.2.3.4]:2222', ('1.2.3.4', 2222))
    check('1.2.3.4:2222', ('1.2.3.4', 2222))

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-20 23:33:30.779731
# Unit test for function parse_address

# Generated at 2022-06-20 23:33:42.844253
# Unit test for function parse_address
def test_parse_address():
    """
    Test function parse_address() in the module.
    """

    # Test cases:
    #  (address string, host result, port result)

# Generated at 2022-06-20 23:33:55.034818
# Unit test for function parse_address
def test_parse_address():
    """
    This is a hack for unit testing. It won't work when imported.
    """

    def check_address(address, result):
        (host, port) = parse_address(address)
        print("Parsed %s as %s:%s" % (address, host, port))
        assert (host, port) == result

    # Test with and without ranges.

    test_host = 'hostname'
    test_port = 42

    check_address(test_host, (test_host, None))
    check_address('%s:%d' % (test_host, test_port), (test_host, test_port))
    check_address('[%s]:%d' % (test_host, test_port), (test_host, test_port))
