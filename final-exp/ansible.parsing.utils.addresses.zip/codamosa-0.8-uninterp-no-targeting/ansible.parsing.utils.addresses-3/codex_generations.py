

# Generated at 2022-06-20 23:29:58.456351
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == (None, None)
    assert parse_address('[]:22') == (None, None)
    assert parse_address('[::1]:') == (None, None)
    assert parse_address('::1:22') == (None, None)
    assert parse_address('::1') == (None, None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo') == ('foo', None)
    assert parse_

# Generated at 2022-06-20 23:30:10.583012
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:21.496237
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:35.441234
# Unit test for function parse_address
def test_parse_address():
    def parse(address, host, port=None, allow_ranges=False):
        result = parse_address(address, allow_ranges)
        if result != (host, port):
            print("parse_address(%s): got %s, expected %s, port=%s" % (address, repr(result), repr((host, port)), repr(port)))
        else:
            print("parse_address(%s): got %s, good" % (address, repr(result)))


# Generated at 2022-06-20 23:30:44.979110
# Unit test for function parse_address
def test_parse_address():
    import random
    import socket
    import string

    # Try parsing various hostnames, IPv4 addresses, IPv6 addresses, and ports

    for char in string.lowercase + string.digits + '-_':
        # Simple hostnames
        assert parse_address(char) == (char, None)
        assert parse_address(char + '.' + char) == (char + '.' + char, None)
        assert parse_address(char + '.' + char + '.' + char + '.' + char) == (char + '.' + char + '.' + char + '.' + char, None)

        # Simple IPv4 addresses

# Generated at 2022-06-20 23:30:57.846373
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:04.354355
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)

    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)

    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)

    assert parse_address('[::ffff:127.0.0.1]') == ('::ffff:127.0.0.1', None)
    assert parse_address('[::ffff:127.0.0.1]:22') == ('::ffff:127.0.0.1', 22)

   

# Generated at 2022-06-20 23:31:18.846283
# Unit test for function parse_address
def test_parse_address():
    def assert_parsed(raw, expected):
        parsed = parse_address(raw)
        assert parsed == expected, '%r parsed as %r' % (raw, parsed)

    assert_parsed('localhost', (u'localhost', None))
    assert_parsed('localhost:22', (u'localhost', 22))
    assert_parsed('[::1]', (u'::1', None))
    assert_parsed('[::1]:22', (u'::1', 22))
    assert_parsed('192.168.0.1', (u'192.168.0.1', None))
    assert_parsed('192.168.0.1:22', (u'192.168.0.1', 22))

# Generated at 2022-06-20 23:31:28.193504
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:42.812023
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:54.776362
# Unit test for function parse_address
def test_parse_address():
    # valid (but unusual) IPv4 addresses
    assert parse_address('0.0.0.0', allow_ranges=True) == ('0.0.0.0', None)
    assert parse_address('127.0.0.1', allow_ranges=True) == ('127.0.0.1', None)
    assert parse_address('10.8.0.0', allow_ranges=True) == ('10.8.0.0', None)
    assert parse_address('10.8.0.255', allow_ranges=True) == ('10.8.0.255', None)
    assert parse_address('192.0.2.255', allow_ranges=True) == ('192.0.2.255', None)

    # valid IPv6 addresses

# Generated at 2022-06-20 23:32:07.740227
# Unit test for function parse_address

# Generated at 2022-06-20 23:32:16.413730
# Unit test for function parse_address
def test_parse_address():
    # The following should all be successful
    assert ('www.example.com', None) == parse_address('www.example.com')
    assert ('192.0.2.1', None) == parse_address('192.0.2.1')
    assert ('192.0.2.1', None) == parse_address('192.0.2.1:')
    assert ('192.0.2.1', 22) == parse_address('192.0.2.1:22')
    assert ('192.0.2.1', 22) == parse_address('[192.0.2.1]:22')
    assert ('2001:db8:dead:beef::1', None) == parse_address('2001:db8:dead:beef::1')

# Generated at 2022-06-20 23:32:28.720020
# Unit test for function parse_address

# Generated at 2022-06-20 23:32:38.625099
# Unit test for function parse_address
def test_parse_address():
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    # Bracketed expressions
    (host, port) = parse_address(address='[example.com]')
    assert host == 'example.com'
    assert port is None

    (host, port) = parse_address(address='[example.com]:22')
    assert host == 'example.com'
    assert port == 22

    (host, port) = parse_address(address='[192.0.2.1]:22')
    assert host == '192.0.2.1'
    assert port == 22

    (host, port) = parse_address(address='[2001:db8::1]:22')
    assert host == '2001:db8::1'
    assert port == 22

    #

# Generated at 2022-06-20 23:32:50.746952
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import pytest

    if not isinstance("foo.example.com", AnsibleUnsafeText):
        pytest.skip("Skipping due to python2 unicode issues")

    assert parse_address("foo.example.com:123") == (u'foo.example.com', 123)
    assert parse_address("foo.example.com") == (u'foo.example.com', None)

    assert parse_address("[abcd:ef::123]:456") == (u'abcd:ef::123', 456)
    with pytest.raises(AnsibleParserError):
        parse_address("abcd:ef::123[:456]")

# Generated at 2022-06-20 23:33:01.416095
# Unit test for function parse_address
def test_parse_address():
    def t(address, fail=False, port=None, host=None, allow_ranges=False):
        if fail:
            try:
                parse_address(address, allow_ranges)
            except AnsibleError:
                pass
            else:
                assert False, '%s was not rejected' % address
        else:
            (h,p) = parse_address(address, allow_ranges)
            assert h == host, '%s does not match %s' % (h, host)
            assert p == port, '%s does not match %s' % (p, port)

    # Simple IPv4 address with a port
    t('127.0.0.1:22',             host='127.0.0.1', port=22)

# Generated at 2022-06-20 23:33:08.503405
# Unit test for function parse_address
def test_parse_address():
    import nose.tools as nt


# Generated at 2022-06-20 23:33:17.578499
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:77') == ('foo', 77)
    assert parse_address('foo[0:5]:77') == ('foo[0:5]', 77)
    assert parse_address('[foo[0:5]]:77') == ('foo[0:5]', 77)
    assert parse_address('[]:77') == ('', 77)
    assert parse_address('127.0.0.1:77') == ('127.0.0.1', 77)
    assert parse_address('127.0.0.1[1:3].20:77') == ('127.0.0.1[1:3].20', 77)

# Generated at 2022-06-20 23:33:24.714199
# Unit test for function parse_address
def test_parse_address():
    # Should parse IPv4 and IPv6 addresses with or without square brackets
    parse_address('192.0.2.3:123')
    parse_address('[192.0.2.3]:123')
    parse_address('[2001:db8::12]:123')
    parse_address('2001:db8::12:123')

    # Should parse hostnames with or without square brackets and with or without
    # a port specification. Also, the caller can choose to ignore host patterns
    # containing [x:y(:z)] ranges.
    parse_address('example.com:80')
    parse_address('[example.com]:80')
    parse_address('example.com')
    parse_address('[example.com]')
    parse_address('example[1:2].com')