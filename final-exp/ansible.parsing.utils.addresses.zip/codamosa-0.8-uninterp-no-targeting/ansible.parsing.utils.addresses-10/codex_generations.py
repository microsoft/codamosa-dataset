

# Generated at 2022-06-20 23:29:58.638196
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:22") == ("192.0.2.1", 22)
    assert parse_address("[192.0.2.1]") == ("192.0.2.1", None)
    assert parse_address("[192.0.2.1]:22") == ("192.0.2.1", 22)
    assert parse_address("::") == ("::", None)
    assert parse_address("[::]") == ("::", None)
    assert parse_address("[::]:22") == ("::", 22)
    assert parse_address("[::1]") == ("::1", None)

# Generated at 2022-06-20 23:30:10.616573
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com[0:4]:22') == ('foo.example.com[0:4]', 22)
    assert parse_address('foo.example.com[b-d]:22') == ('foo.example.com[b-d]', 22)
    assert parse_address('foo.example.com[x-z]:22') == ('foo.example.com[x-z]', 22)

# Generated at 2022-06-20 23:30:21.536380
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:80') == ('192.0.2.1', 80)
   

# Generated at 2022-06-20 23:30:35.484474
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:45.008825
# Unit test for function parse_address
def test_parse_address():

    # Basic host names
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo') == ('foo', None)

    # Host names with ranges
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[a:c]') == ('foo[a:c]', None)
    assert parse_address('foo[a:z:2]') == ('foo[a:z:2]', None)

    # IP addresses of all sorts
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:123') == ('192.0.2.1', 123)

# Generated at 2022-06-20 23:30:57.841753
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:12.118967
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:18.082805
# Unit test for function parse_address
def test_parse_address():
    assert ('foo', 22) == parse_address('foo:22')
    assert ('foo.example.com', 22) == parse_address('foo.example.com:22')
    assert ('foo-01.example.com', 22) == parse_address('foo-01.example.com:22')
    assert ('foo_01.example.com', 22) == parse_address('foo_01.example.com:22')
    assert ('foo.example.com', 22) == parse_address('[foo.example.com]:22')
    assert ('192.0.2.1', 22) == parse_address('192.0.2.1:22')
    assert ('192.0.2.1', 22) == parse_address('[192.0.2.1]:22')

# Generated at 2022-06-20 23:31:27.977380
# Unit test for function parse_address
def test_parse_address():
    (h, p) = parse_address("192.168.0.1:2222")
    assert h == '192.168.0.1'
    assert p == 2222

    (h, p) = parse_address("[2001:db8::1]:22")
    assert h == '2001:db8::1'
    assert p == 22

    (h, p) = parse_address("host:22")
    assert h == 'host'
    assert p == 22

    (h, p) = parse_address("[192.168.0.1]")
    assert h == '192.168.0.1'
    assert p is None

    (h, p) = parse_address("foo[a-z].example.com:22")
    assert h == 'foo[a-z].example.com'

# Generated at 2022-06-20 23:31:42.388568
# Unit test for function parse_address