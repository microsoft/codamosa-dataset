

# Generated at 2022-06-20 23:30:01.302033
# Unit test for function parse_address
def test_parse_address():
    import json
    import fnmatch

# Generated at 2022-06-20 23:30:11.607350
# Unit test for function parse_address
def test_parse_address():
    """
    Tests that the given addresses are parsed as expected.
    """

    # These are valid addresses:

# Generated at 2022-06-20 23:30:24.908483
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:5432') == ('192.0.2.1', 5432)
    assert parse_address('192.0.2.1:5432') == ('192.0.2.1', 5432)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:5432') == ('2001:db8::1', 5432)
    assert parse_address('example.invalid') == ('example.invalid', None)
    assert parse_address('example.invalid:5432') == ('example.invalid', 5432)

# Generated at 2022-06-20 23:30:38.452519
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:53.693984
# Unit test for function parse_address
def test_parse_address():
    """
    >>> test_parse_address()
    """

    # Host without port
    (host, port) = parse_address('foo')
    assert host == 'foo'
    assert port is None

    (host, port) = parse_address('foo.example.com')
    assert host == 'foo.example.com'
    assert port is None

    (host, port) = parse_address('foo-bar[1:3]')
    assert host == 'foo-bar[1:3]'
    assert port is None

    (host, port) = parse_address('192.0.2.3')
    assert host == '192.0.2.3'
    assert port is None

    (host, port) = parse_address('192.0.2[3:6]')

# Generated at 2022-06-20 23:31:08.473552
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:23.426668
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:37.299969
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:43.074525
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:52.789584
# Unit test for function parse_address
def test_parse_address():
    assert (None, None) == parse_address(None)
    assert (None, None) == parse_address('nil:0')
    assert (None, None) == parse_address('nil')
    assert ('nil', None) == parse_address('nil', allow_ranges=True)
    assert (None, None) == parse_address('nil:nil', allow_ranges=True)
    assert ('localhost', 22) == parse_address('localhost:22')
    assert ('10.1.1.1', 22) == parse_address('10.1.1.1:22')
    assert ('10.1.1.1', 22) == parse_address('10.1.1.1[1-2]:22')

# Generated at 2022-06-20 23:32:06.834861
# Unit test for function parse_address

# Generated at 2022-06-20 23:32:15.966606
# Unit test for function parse_address
def test_parse_address():
    print("Checking parse_address")
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:3') == ('127.0.0.1', 3)
    assert parse_address('127.0.0.1:0') == ('127.0.0.1', 0)
    assert parse_address('127.0.0.1:65535') == ('127.0.0.1', 65535)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('::1:3') == ('::1', 3)
    assert parse_address('::1:0') == ('::1', 0)

# Generated at 2022-06-20 23:32:28.452545
# Unit test for function parse_address

# Generated at 2022-06-20 23:32:38.480694
# Unit test for function parse_address
def test_parse_address():

    # Exercise the code to get the branch coverage we need
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:0') == ('1.2.3.4', 0)
    assert parse_address('1.2.3.4:65535') == ('1.2.3.4', 65535)
    assert parse_address('1.2.3.4:65536') == ('1.2.3.4', 65536)

    # ipv4 ranges
    assert parse_address('1.2.3.[4:8]') == ('1.2.3.[4:8]', None)

# Generated at 2022-06-20 23:32:50.683124
# Unit test for function parse_address
def test_parse_address():
    # Simple cases
    assert parse_address("example.com:22") == ("example.com", 22)
    assert parse_address("example.com")    == ("example.com", None)
    assert parse_address("192.0.2.1:22")   == ("192.0.2.1", 22)
    assert parse_address("192.0.2.1")      == ("192.0.2.1", None)
    assert parse_address("2001:db8::1")    == ("2001:db8::1", None)
    assert parse_address("2001:db8::1:22") == ("2001:db8::1", 22)

    # Bracketed IPv6 address with a port
    assert parse_address("[2001:db8::1]:22") == ("2001:db8::1", 22)

    #

# Generated at 2022-06-20 23:33:01.351753
# Unit test for function parse_address

# Generated at 2022-06-20 23:33:03.918243
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == (':1', 22)
    assert parse_address('127.0.0.1', allow_ranges=True) == ('127.0.0.1', None)

# This is a stricter variant of parse_address that only accepts a simple IPv4
# or IPv6 address.


# Generated at 2022-06-20 23:33:13.194544
# Unit test for function parse_address
def test_parse_address():

    import pytest

    def assert_parse_address_raises(input, error_pattern):
        with pytest.raises(AnsibleParserError, match=error_pattern):
            parse_address(input)
        with pytest.raises(AnsibleError, match=error_pattern):
            parse_address(input, allow_ranges=True)

    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]', allow_ranges=True) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)

# Generated at 2022-06-20 23:33:20.630116
# Unit test for function parse_address
def test_parse_address():
    """ Return a list of test cases and their expected results """
    tests = []

    # Test cases:
    #
    #  0. test, expected
    #  1. test, expected
    #  2. test, expected
    #

    # Hostname with port
    tests.append(['foo.example.com:80', ('foo.example.com', 80)])
    tests.append(['foo[1:3].example.com:80', ('foo[1:3].example.com', 80)])
    tests.append(['foo[0:5][a:z]', None])
    tests.append(['foo[:5][a:z]', None])
    tests.append(['foo[a:z]', None])
    tests.append(['foo[:z]', None])

# Generated at 2022-06-20 23:33:30.956899
# Unit test for function parse_address
def test_parse_address():
    def test(host, port, allow_ranges):
        assert parse_address(host, allow_ranges) == (host, port)

    # Without ranges, this is a complete failure.
    test('foo', None, False)

    # These should all work, with or without ranges.
    for allow_ranges in (True, False):
        test('foo[1:3]', None, allow_ranges)
        test('foo[1:3]-bar[x-z]', None, allow_ranges)
        test('foo[1:3]-bar[x-z]:22', 22, allow_ranges)
        test('[::1]:22', 22, allow_ranges)
        test('[::1]:22', 22, allow_ranges)