

# Generated at 2022-06-20 23:30:01.262378
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('example.com:65535') == ('example.com', 65535)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:65535') == ('192.0.2.1', 65535)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)

# Generated at 2022-06-20 23:30:11.608824
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-20 23:30:23.422194
# Unit test for function parse_address
def test_parse_address():
    # Test function parse_address

    import sys

    def xeq(a, b, msg):
        """
        Raises an error on inequality, which is what we want to
        happen when there's a test failure.
        """
        a = tuple(a)
        b = tuple(b)

        print(a, b)
        if a != b:
            raise AssertionError(msg)

    # Basic cases

    xeq(parse_address('foo.example.com'), ('foo.example.com', None),
        "foo.example.com")

    xeq(parse_address('foo.example.com:1234'),
        ('foo.example.com', 1234),
        "foo.example.com:1234")


# Generated at 2022-06-20 23:30:36.738681
# Unit test for function parse_address
def test_parse_address():
    # Parse IPv4 addresses, with and without port numbers
    (address, port) = parse_address('127.0.0.1')
    assert address == '127.0.0.1'
    assert port is None
    (address, port) = parse_address('127.0.0.1:7777')
    assert address == '127.0.0.1'
    assert port == 7777
    (address, port) = parse_address('127.0.0.1:7777s')
    assert address == '127.0.0.1'
    assert port == 7777

    # Parse IPv6 addresses, with and without port numbers
    (address, port) = parse_address('::1')
    assert address == '::1'
    assert port is None

# Generated at 2022-06-20 23:30:45.470554
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:') == ('127.0.0.1', None)
    assert parse_address('udp://[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('udp://[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('udp://[2001:db8::1]:') == ('2001:db8::1', None)

# Generated at 2022-06-20 23:30:58.265442
# Unit test for function parse_address
def test_parse_address():
    # make sure we can parse host with spaces in them
    assert parse_address("10.2.2.3:20") == ('10.2.2.3', 20)
    assert parse_address("[10.2.2.3]:20") == ('10.2.2.3', 20)
    assert parse_address("[10.2.2.3]") == ('10.2.2.3', None)

    assert parse_address("10.2.2.3") == ('10.2.2.3', None)
    assert parse_address("foo:22") == ('foo', 22)
    assert parse_address("foo") == ('foo', None)
    assert parse_address("[foo]") == ('foo', None)
    assert parse_address("foo:22", True) == ('foo', 22)
    assert parse

# Generated at 2022-06-20 23:31:12.447064
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo:10") == ("foo", 10)
    assert parse_address("foo.bar.example.com") == ("foo.bar.example.com", None)
    assert parse_address("foo[1:5]") == ("foo[1:5]", None)
    assert parse_address("[0:5:2]") == ("[0:5:2]", None)
    assert parse_address("[aa:bb:cc]") == ("[aa:bb:cc]", None)
    assert parse_address("bar[1:3].example.com") == ("bar[1:3].example.com", None)
    assert parse_address("[::1234]:10") == ("::1234", 10)

# Generated at 2022-06-20 23:31:25.346520
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]', True) == (u'[::1]', None)
    assert parse_address('[::1]:0') == (u'[::1]', 0)
    assert parse_address('[::1]:100') == (u'[::1]', 100)
    assert parse_address('[::1:3:4:5:6:7]', True) == (u'[::1:3:4:5:6:7]', None)
    assert parse_address('[::1:3:4:5:6:7]:101', True) == (u'[::1:3:4:5:6:7]', 101)

    assert parse_address('1.2.3.4', True) == (u'1.2.3.4', None)
    assert parse_

# Generated at 2022-06-20 23:31:39.514820
# Unit test for function parse_address
def test_parse_address():
    expected = ('host.example.com', 1234)
    assert expected == parse_address(expected[0] + ':' + str(expected[1]))

    expected = ('127.0.0.1', 1234)
    assert expected == parse_address('[%s]:%d' % expected)

    assert ('192.0.2.1', None) == parse_address('192.0.2.1')

    assert ('2001:db8::1', None) == parse_address('2001:db8::1')
    assert ('2001:db8::1', 1234) == parse_address('[2001:db8::1]:1234')
    assert ('2001:db8::1', 1234) == parse_address('[2001:db8::1%lo0]:1234')

# Generated at 2022-06-20 23:31:44.965027
# Unit test for function parse_address