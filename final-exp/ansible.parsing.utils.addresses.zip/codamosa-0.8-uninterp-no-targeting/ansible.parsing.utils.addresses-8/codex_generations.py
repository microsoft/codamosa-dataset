

# Generated at 2022-06-20 23:29:57.412762
# Unit test for function parse_address
def test_parse_address():
    try:
        (host, port) = parse_address("[2001:db8::1]:5555", allow_ranges=False)
    except Exception as e:
        assert False, str(e)
    else:
        assert host == "2001:db8::1"
        assert port == 5555

# Generated at 2022-06-20 23:30:10.217952
# Unit test for function parse_address
def test_parse_address():
    # pylint: disable=unused-argument
    def test(input, result, allow_ranges):
        actual = parse_address(input, allow_ranges)
        if actual != result:
            print("FAIL: parse_address(%s, %s) expected %s, got %s" % (input, allow_ranges, result, actual))

    test("peter.example.com:8000", ("peter.example.com", 8000), False)
    test("[peter.example.com]:8000", ("peter.example.com", 8000), False)
    test("peter.example.com[x:y]:8000", ("peter.example.com[x:y]", 8000), False)

# Generated at 2022-06-20 23:30:21.094735
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com')              == ('example.com', None)
    assert parse_address('[example.com]')            == ('example.com', None)
    assert parse_address('example.com:22')           == ('example.com', 22)
    assert parse_address('[example.com]:22')         == ('example.com', 22)
    assert parse_address('192.168.1.1')              == ('192.168.1.1', None)
    assert parse_address('[192.168.1.1]')            == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:22')           == ('192.168.1.1', 22)

# Generated at 2022-06-20 23:30:35.304846
# Unit test for function parse_address
def test_parse_address():
    #
    # Verify that currently failing combinations fail.
    def parse_fail(desc, addr, allow_ranges=False):
        try:
            parse_address(addr, allow_ranges)
        except AnsibleError as e:
            #print("PASS: %s failed as expected: %s" % (desc, addr))
            pass
        else:
            print("FAIL: %s did not fail as expected: %s" % (desc, addr))

    parse_fail("Unparseable address", "_")
    parse_fail("Square brackets without port", "[::]")
    parse_fail("Bad IPv4 address (out of range)", "999.999.999.999")
    parse_fail("Bad IPv4 address (missing component)", "1.1")

# Generated at 2022-06-20 23:30:44.889515
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 address
    (address, port) = parse_address('1.2.3.4:22')
    assert address == '1.2.3.4'
    assert port == 22
    # Test IPv6 address
    (address, port) = parse_address('[2001:db8::1]:22')
    assert address == '2001:db8::1'
    assert port == 22
    # Test hostname
    (address, port) = parse_address('[example.com]:22')
    assert address == 'example.com'
    assert port == 22
    # Test bad address
    try:
        parse_address('[example.com')
        assert False
    except AnsibleError:
        pass
    # Test address with range

# Generated at 2022-06-20 23:30:57.749593
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:11.850677
# Unit test for function parse_address
def test_parse_address():
    import unittest
    import pytest

    class TestParseAddress(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-20 23:31:17.991854
# Unit test for function parse_address
def test_parse_address():
    # ideal-format IPv4 addresses
    assert parse_address('1.1.1.1', allow_ranges=False) == ('1.1.1.1', None)
    assert parse_address('1.1.1.1:22', allow_ranges=False) == ('1.1.1.1', 22)
    assert parse_address('1.1.1.1:22', allow_ranges=True) == ('1.1.1.1', 22)
    assert parse_address('[1.1.1.1]:22', allow_ranges=False) == ('1.1.1.1', 22)
    assert parse_address('[1.1.1.1]:22', allow_ranges=True) == ('1.1.1.1', 22)
    # numeric-range IPv4 addresses
   

# Generated at 2022-06-20 23:31:27.946862
# Unit test for function parse_address
def test_parse_address():
    """
    Tests the parse_address function.
    """

    assert parse_address("[1::2]:3") == ("[1::2]", 3)
    assert parse_address("[1::2]3") == ("[1::2]3", None)

    assert parse_address("1::2:3") == ("1::2:3", None)
    assert parse_address("[1::2:3]") == ("1::2:3", None)
    assert parse_address("[1::2:3]:4") == ("[1::2:3]", 4)

    assert parse_address("1::2") == ("1::2", None)
    assert parse_address("[1::2]") == ("1::2", None)

# Generated at 2022-06-20 23:31:42.388761
# Unit test for function parse_address
def test_parse_address():
    def fail(msg):
        raise Exception(msg)

    def test(address, expected_host, expected_port, allow_ranges=False):
        result = parse_address(address, allow_ranges)
        if result != (expected_host, expected_port):
            fail("parse_address(%s, %s) = %s, expected %s" %
                 (address, allow_ranges, result, (expected_host, expected_port)))

    test("localhost", "localhost", None)
    test("localhost:22", "localhost", 22)
    test("[localhost]", "localhost", None)
    test("[::1]", "::1", None)
    test("[::1]:22", "::1", 22)
    test("10.1.2.3", "10.1.2.3", None)