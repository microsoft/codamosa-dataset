

# Generated at 2022-06-20 23:30:06.859091
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo:22") == ('foo', 22)
    assert parse_address("foo:1:22") == ('foo:1', 22)
    assert parse_address("foo:1:22:44") == ('foo:1', 22)
    assert parse_address("a[1:3]") == ('a[1:3]', None)
    assert parse_address("a[1:3]:22") == ('a[1:3]', 22)
    assert parse_address("a[1:3:4]") == ('a[1:3:4]', None)
    assert parse_address("a[1:3:4]:22") == ('a[1:3:4]', 22)
    assert parse_address("a[1-3]")

# Generated at 2022-06-20 23:30:14.755871
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:5656') == ('example.com', 5656)
    assert parse_address('example.com:5656', True) == ('example.com', 5656)
    assert parse_address('[2001:db8::a00:20ff:fefa:db40]:5656') == ('2001:db8::a00:20ff:fefa:db40', 5656)
    assert parse_address('[example.com]:5656') == ('example.com', 5656)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]', True) == ('example.com', None)

# Generated at 2022-06-20 23:30:25.532957
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo[0:4]') == ('foo[0:4]', None)
    assert parse_address('foo[0:4]:22') == ('foo[0:4]', 22)
    assert parse_address('[1.2.3.4]:22') == ('1.2.3.4', 22)
    assert parse_address('[1:2::3:4]') == ('1:2::3:4', None)
    assert parse_address('[1:2::3:4]:22') == ('1:2::3:4', 22)
    assert parse_address('foo[1,2]') == ('foo[1,2]', None)
    assert parse_address('foo[1,2]:22') == ('foo[1,2]', 22)

# Generated at 2022-06-20 23:30:39.340067
# Unit test for function parse_address
def test_parse_address():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text

    # address, port, error_regex

# Generated at 2022-06-20 23:30:53.694212
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('host1')
    assert host == 'host1'
    assert port is None
    host, port = parse_address('host1:22')
    assert host == 'host1'
    assert port == 22
    host, port = parse_address('192.168.1.10:22')
    assert host == '192.168.1.10'
    assert port == 22
    host, port = parse_address('[192.168.1.10]:22')
    assert host == '192.168.1.10'
    assert port == 22
    host, port = parse_address('host42[4:7]')
    assert host == 'host42[4:7]'
    assert port is None
    host, port = parse_address('[host42[4:7]]:22')

# Generated at 2022-06-20 23:31:08.473653
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-20 23:31:15.242838
# Unit test for function parse_address
def test_parse_address():

    def check(address, host, port):
        (h, p) = parse_address(address)
        assert h == host and p == port, "failed to parse '%s' as (%s, %d)" % (address, host, port)

    check('127.0.0.1', '127.0.0.1', None)
    check('2001:db8::1', '2001:db8::1', None)
    check('example.com', 'example.com', None)
    check('[example.com]', 'example.com', None)
    check('example.com:22', 'example.com', 22)
    check('10.0.0.1:22', '10.0.0.1', 22)

# Generated at 2022-06-20 23:31:26.714021
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:40.997620
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:52.043699
# Unit test for function parse_address
def test_parse_address():
    import ansible.utils
    test_string = []
    expect = []
    test_string.append('localhost')
    expect.append((u'localhost', None))
    test_string.append('localhost:2222')
    expect.append((u'localhost', 2222))
    test_string.append('[::1]:2222')
    expect.append((u'::1', 2222))
    test_string.append('[::1%eth0]')
    expect.append((u'::1%eth0', None))
    test_string.append('[::1%eth0]:2222')
    expect.append((u'::1%eth0', 2222))
    test_string.append('::1')
    expect.append((u'::1', None))