

# Generated at 2022-06-20 23:30:05.766933
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:14.011498
# Unit test for function parse_address
def test_parse_address():
    # Checks for the presence of the final host or port in the returned
    # tuple.
    def check_host(expected, *args, **kwargs):
        assert expected in parse_address(*args, **kwargs)

    # Basic cases
    check_host('local', 'local')
    check_host('local', 'local:2022')
    check_host('local', '[local]')
    check_host(2022, '[local]:2022')
    check_host('local', 'local:foo')
    check_host('0.0.0.0', '0.0.0.0')
    check_host('0.0.0.0', '[0.0.0.0]')
    check_host(2022, '[0.0.0.0]:2022')

# Generated at 2022-06-20 23:30:24.561350
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:37.975527
# Unit test for function parse_address
def test_parse_address():
    import unittest
    class TestParseAddress(unittest.TestCase):

        def test_IPv4_address(self):
            self.assertEqual(("192.0.2.1", None), parse_address("192.0.2.1"))
            self.assertEqual(("192.0.2.1", None), parse_address("192.0.2.1[1:3]"))
            self.assertEqual(("192.0.2.1", None), parse_address("[192.0.2.1]"))
            self.assertEqual(("192.0.2.1", 8000), parse_address("[192.0.2.1]:8000"))

# Generated at 2022-06-20 23:30:51.995736
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:05.885924
# Unit test for function parse_address
def test_parse_address():
    """
    The below test cases cover the various combinations of
    hostname and ports
    """

# Generated at 2022-06-20 23:31:20.676446
# Unit test for function parse_address
def test_parse_address():
    """
    The purpose of this test is to show that all of the following functions
    work as expected. This allows to test new functions easily.

    The functions tested are:

    * parse_address
    """

    # Tests for parse_address
    print("Test parse_address")
    print("------------------")

    def print_address(address, port, parsed_address, parsed_port):
        msg = "Failed to parse '{0}' (port: {1}), got '{2}' (port '{3}')"
        print(msg.format(address, port, parsed_address, parsed_port))
        if address != parsed_address or port != parsed_port:
            raise Exception("Test failed.")

    cases = []

    # [<addr>]:<port>

# Generated at 2022-06-20 23:31:28.884601
# Unit test for function parse_address
def test_parse_address():
    assert(parse_address('127.0.0.1'))
    assert(parse_address('[::1]'))
    assert(parse_address('[::1]:22'))
    assert(parse_address('[::1]:22', allow_ranges=True))
    assert(parse_address('[::1]', allow_ranges=True))
    assert(parse_address('host[1:3]:22'))
    assert(parse_address('host[1:3]:22', allow_ranges=True))
    assert(parse_address('host[1:3]', allow_ranges=True))
    assert(parse_address('host[1:3]', allow_ranges=True))
    assert(parse_address('host[a-z][1:3]:22', allow_ranges=True))

# Generated at 2022-06-20 23:31:43.572215
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:54.776041
# Unit test for function parse_address