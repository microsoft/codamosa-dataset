

# Generated at 2022-06-20 23:29:58.800710
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("192.168.5.5:8888") == ('192.168.5.5', 8888)
    assert parse_address("192.168.5.5") == ('192.168.5.5', None)
    assert parse_address("192.168.5.5:0") == ('192.168.5.5', 0)
    assert parse_address("192.168.5.5:65535") == ('192.168.5.5', 65535)
    assert parse_address("192.168.5.5:65536") == ('192.168.5.5', 65536)
    assert parse_address("192.168.5.5:65537") == ('192.168.5.5', 65537)

# Generated at 2022-06-20 23:30:10.849682
# Unit test for function parse_address
def test_parse_address():
    def assert_parse_address(host, port, input):
        assert (host, port) == parse_address(input)

    assert_parse_address(None, None, "")
    assert_parse_address(None, None, ":")
    assert_parse_address(None, None, "1.2")
    assert_parse_address(None, None, "1.2:")
    assert_parse_address(None, None, "1.2:3f")
    assert_parse_address("1::", None, "1::")
    assert_parse_address("1::", None, "1:::")
    assert_parse_address("1::", None, "1:::3")
    assert_parse_address("1::", None, "1:::3f")

# Generated at 2022-06-20 23:30:21.782062
# Unit test for function parse_address
def test_parse_address():
    """
    Run unit tests against the parse_address function
    """

    import sys
    import pytest


# Generated at 2022-06-20 23:30:35.753782
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com:9999') == ('foo.example.com', 9999)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com', allow_ranges=True) == ('foo.example.com', None)
    assert parse_address('foo[0:99].example.com', allow_ranges=True) == ('foo[0:99].example.com', None)

    # good IPv4, port is optional
    assert parse_address('1.2.3.4:9999') == ('1.2.3.4', 9999)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)

    # good IPv4, port is optional, numeric ranges allowed
   

# Generated at 2022-06-20 23:30:42.784599
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.py23 import StringIO
    import glob

    import pytest

    test_cases = glob.glob('./test/units/utils/test_network/parse_address/*')
    for test_case in test_cases:
        with open(test_case) as f:
            test_data = StringIO(f.read())

        pytest.raises(
            ValueError,
            parse_address,
            test_data.getvalue().splitlines()[0]
        )

# Generated at 2022-06-20 23:30:55.527375
# Unit test for function parse_address
def test_parse_address():
    import pytest
    from ansible import constants as C
    from ansible.utils.boolean import parse_boolean

# Generated at 2022-06-20 23:31:09.945991
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('example.org:22') == ('example.org', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:1234') == ('192.0.2.1', 1234)
    assert parse_address('1.2.3.4:5678') == ('1.2.3.4', 5678)
    assert parse_address('192.0.2.1:65536') == ('192.0.2.1', 65536)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)

# Generated at 2022-06-20 23:31:23.754632
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:38.140985
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:50.881488
# Unit test for function parse_address
def test_parse_address():

    # Examples from ansible-doc inventory_hostname
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:23') == ('example.com', 23)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:23') == ('example.com', 23)
    assert parse_address('[2001:db8::4]:23') == ('2001:db8::4', 23)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:23') == ('192.0.2.3', 23)

# Generated at 2022-06-20 23:32:05.102576
# Unit test for function parse_address

# Generated at 2022-06-20 23:32:14.953834
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[::ffff:192.0.2.1]") == ("::ffff:192.0.2.1", None)
    assert parse_address("[::ffff:192.0.2.3]:80") == ("::ffff:192.0.2.3", 80)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:80") == ("192.0.2.1", 80)
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:80") == ("foo.example.com", 80)

# Generated at 2022-06-20 23:32:28.163931
# Unit test for function parse_address
def test_parse_address():
    """
    Since there are many possible combinations, we have to test every
    case separately.  For example, foo.example.com:22, 192.168.0.1:5555,
    [abcd:ef01:2345:6789:abcd:ef01:2345:6789]:22, and
    [192.168.0.1]:22 are all valid host/port combinations, but not
    valid IPv4/IPv6 addresses.
    """
    failures = []

# Generated at 2022-06-20 23:32:38.358454
# Unit test for function parse_address

# Generated at 2022-06-20 23:32:50.584286
# Unit test for function parse_address
def test_parse_address():
    assert ('192.0.2.1', 80) == parse_address('192.0.2.1:80')
    assert ('192.0.2.1', None) == parse_address('192.0.2.1')
    assert (None, None) == parse_address(':80')
    assert ('1234:5678:9abc:def0::', None) == parse_address('1234:5678:9abc:def0::')
    assert ('1234:5678:9abc:def0::', 80) == parse_address('[1234:5678:9abc:def0::]:80')
    assert ('::ffff:192.0.2.3', 80) == parse_address('[::ffff:192.0.2.3]:80')

# Generated at 2022-06-20 23:33:01.257625
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest


# Generated at 2022-06-20 23:33:13.304378
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 address with port
    (host, port) = parse_address("10.42.0.1:8001")
    assert host == "10.42.0.1"
    assert port == 8001

    # Test IPv4 address with no port
    (host, port) = parse_address("10.42.0.2")
    assert host == "10.42.0.2"
    assert port == None

    # Test IPv4-like range address with port
    (host, port) = parse_address("10.1[0:2].0.2:8001")
    assert host == "10.1[0:2].0.2"
    assert port == 8001

    # Test IPv4-like range address with port

# Generated at 2022-06-20 23:33:20.644178
# Unit test for function parse_address

# Generated at 2022-06-20 23:33:30.996634
# Unit test for function parse_address

# Generated at 2022-06-20 23:33:42.899063
# Unit test for function parse_address
def test_parse_address():
    def ok(address, host, port=None, allow_ranges=False):
        (parsed_host, parsed_port) = parse_address(address, allow_ranges=allow_ranges)
        assert host == parsed_host
        assert port == parsed_port

    def fail(address, msg, allow_ranges=False):
        try:
            parse_address(address, allow_ranges=allow_ranges)
        except Exception as e:
            assert msg == str(e)

    ok("www.google.com", "www.google.com")
    ok("www.google.com:23", "www.google.com", 23)
    ok("[::1]", "::1")
    ok("[::1]:23", "::1", 23)

# Generated at 2022-06-20 23:33:56.107920
# Unit test for function parse_address
def test_parse_address():
    # Port only
    assert parse_address(":123")[0] is None
    # Hostname with port
    assert parse_address("localhost:22") == ("localhost", 22)
    # IPv4 with port
    assert parse_address("127.0.0.1:53") == ("127.0.0.1", 53)
    # IPv4 with port
    assert parse_address("127.0.0.1:53") == ("127.0.0.1", 53)
    # IPv6 with port
    assert parse_address("[2001:db8::1]:888") == ("2001:db8::1", 888)
    # IPv6 with port
    assert parse_address("[2001:db8::1]:888") == ("2001:db8::1", 888)
    # IPv6 with no port
    assert parse

# Generated at 2022-06-20 23:34:07.966609
# Unit test for function parse_address

# Generated at 2022-06-20 23:34:19.268772
# Unit test for function parse_address
def test_parse_address():
    # The following should succeed
    # Examples from https://docs.ansible.com/ansible/latest/user_guide/intro_patterns.html
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('example.org:22') == ('example.org', 22)
    assert parse_address('example.org:443') == ('example.org', 443)
    assert parse_address('www[001:003].example.org') == ('www[001:003].example.org', None)
    assert parse_address('www[001:003].example.org:22') == ('www[001:003].example.org', 22)
    assert parse_address('www[001:003].example.org:443') == ('www[001:003].example.org', 443)
    assert parse_

# Generated at 2022-06-20 23:34:30.440793
# Unit test for function parse_address
def test_parse_address():
    import pytest

    assert parse_address("localhost:22") == ("localhost", 22)
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:") == ("localhost", None)
    with pytest.raises(AnsibleParserError):
        parse_address("localhost:a")

    assert parse_address("127.0.0.1:22") == ("127.0.0.1", 22)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:") == ("127.0.0.1", None)
    with pytest.raises(AnsibleParserError):
        parse_address("127.0.0.1:a")


# Generated at 2022-06-20 23:34:38.360568
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:4321') == ('foo', 4321)
    assert parse_address('foo[1:]') == ('foo[1:]', None)
    assert parse_address('foo[1:]:4321') == ('foo[1:]', 4321)
    assert parse_address('[foo]:4321') == ('[foo]', 4321)
    assert parse_address('[foo[1:]]:4321') == ('[foo[1:]]', 4321)
    assert parse_address('[foo]') == ('[foo]', None)
    assert parse_address('[foo[1:]]') == ('[foo[1:]]', None)

# Generated at 2022-06-20 23:34:48.795492
# Unit test for function parse_address
def test_parse_address():
    """
    A simple unit test for the parse_address() function.
    """
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_basic_server_spec(self):
            self.assertEqual(
                parse_address('www.example.com'),
                ('www.example.com', None),
            )
            self.assertEqual(
                parse_address('www.example.com:123'),
                ('www.example.com', 123),
            )
            self.assertEqual(
                parse_address('[::1]'),
                ('::1', None),
            )
            self.assertEqual(
                parse_address('[::1]:123'),
                ('::1', 123),
            )

# Generated at 2022-06-20 23:35:01.687753
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:2222') == ('foo.example.com', 2222)
    assert parse_address('foo.example.com:2222', True) == ('foo.example.com', 2222)
    assert parse_address('<foo.example.com>') == ('foo.example.com', None)
    assert parse_address('[foo.example.com]:2222') == ('foo.example.com', 2222)
    assert parse_address('[foo.example.com]') == ('foo.example.com', None)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('10.2.3.4') == ('10.2.3.4', None)


# Generated at 2022-06-20 23:35:10.906622
# Unit test for function parse_address
def test_parse_address():
    address = '192.0.2.3:20'
    assert parse_address(address) == ('192.0.2.3', 20)
    address = '192.0.2.3'
    a, b = parse_address(address)
    assert a == ('192.0.2.3', None)
    assert b is None
    address = '192.0.2.3:20'
    assert parse_address(address) == ('192.0.2.3', 20)
    address = '192.0.2.3:20'
    assert parse_address(address) == ('192.0.2.3', 20)
    address = '::ffff:192.0.2.3:20'
    assert parse_address(address) == ('::ffff:192.0.2.3', 20)
    address

# Generated at 2022-06-20 23:35:24.810805
# Unit test for function parse_address

# Generated at 2022-06-20 23:35:38.179588
# Unit test for function parse_address