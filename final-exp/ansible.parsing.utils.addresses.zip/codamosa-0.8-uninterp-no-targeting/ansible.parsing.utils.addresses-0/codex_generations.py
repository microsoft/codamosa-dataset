

# Generated at 2022-06-20 23:30:07.181065
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('[foo]') == ('foo', None)
    assert parse_address('foo:1234') == ('foo', 1234)
    assert parse_address('foo[1:3]:1234') == ('foo[1:3]', 1234)
    assert parse_address('foo[0:5]-bar[x-z]:1234') == ('foo[0:5]-bar[x-z]', 1234)
    assert parse_address('192.0.2.1:456') == ('192.0.2.1', 456)
    assert parse_address('192.0.2.1[0:10]:456') == ('192.0.2.1[0:10]', 456)

# Generated at 2022-06-20 23:30:15.445729
# Unit test for function parse_address
def test_parse_address():
    # Unit test with just IPv4
    assert parse_address("1.2.3.4:5") == ("1.2.3.4", 5)
    assert parse_address("1.2.3.4:5", allow_ranges=True) == ("1.2.3.4", 5)
    assert parse_address("1.2.3.4") == ("1.2.3.4", None)
    assert parse_address("1.2.3.4", allow_ranges=True) == ("1.2.3.4", None)
    assert parse_address("[1.2.3.4]") == ("1.2.3.4", None)
    assert parse_address("[1.2.3.4]", allow_ranges=True) == ("1.2.3.4", None)

# Generated at 2022-06-20 23:30:25.690111
# Unit test for function parse_address
def test_parse_address():
    from ansible.module_utils import basic
    from ansible.utils.debug import debug

    basic._ANSIBLE_ARGS = None
    host, port = parse_address('rest.example.com:8080')
    assert host == 'rest.example.com' and port == '8080', 'parse_address failed on rest.example.com:8080'

    host, port = parse_address('[0001:0002:0003:0004:0005:0006:0007:0008]', allow_ranges=True)
    assert host == '0001:0002:0003:0004:0005:0006:0007:0008' and port == None, 'parse_address failed on [0001:0002:0003:0004:0005:0006:0007:0008]'

# Generated at 2022-06-20 23:30:39.339772
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo]') == ('foo', None)
    assert parse_address('[foo:bar:baz]:22') == ('foo:bar:baz', 22)

    assert parse_address('foo[1-2]') == (None, None)
    assert parse_address('foo[1-2]', allow_ranges=True) == ('foo[1-2]', None)

    assert parse_address('[1.2.3.4]:22') == ('1.2.3.4', 22)

# Generated at 2022-06-20 23:30:55.102237
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('test')         == ('test', None)
    assert parse_address('test:22')      == ('test', 22)
    assert parse_address('test[x:y]:22') == ('test[x:y]', 22)
    assert parse_address('[test[x:y]]:22') == ('test[x:y]', 22)
    assert parse_address('[1.1.1.1]:22')  == ('1.1.1.1', 22)
    assert parse_address('1.1.1.1', True) == ('1.1.1.1', None)
    assert parse_address('1.1.1.1:22', True) == ('1.1.1.1', 22)

# Generated at 2022-06-20 23:31:09.554026
# Unit test for function parse_address
def test_parse_address():
    # Check a few simple cases.
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo[1:5]") == ("foo[1:5]", None)
    assert parse_address("[1:5]:23") == ("[1:5]", 23)
    assert parse_address("x:23") == ("x:23", None)
    assert parse_address("foo:23") == ("foo", 23)

    assert parse_address("foo[1:5]:23") == ("foo[1:5]", 23)

    # As long as the ranges are syntactically correct, we'll parse it.
    assert parse_address("foo[1:52:3]") == ("foo[1:52:3]", None)
    assert parse_address("foo[1:52:3]:23")

# Generated at 2022-06-20 23:31:24.946509
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('www.example.com') == ('www.example.com', None)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('192.168.0.100:22') == ('192.168.0.100', 22)
    assert parse_address('2001:0db8:85a3:08d3:1319:8a2e:0370:7334') == ('2001:0db8:85a3:08d3:1319:8a2e:0370:7334', None)

# Generated at 2022-06-20 23:31:39.377906
# Unit test for function parse_address
def test_parse_address():
    """
    Unit tests for parse_address()
    """

    def assert_parse(hostport, expected_host, expected_port=None):
        actual_host, actual_port = parse_address(hostport)
        if expected_host != actual_host:
            raise AssertionError("For hostport='%s': expected host=%s, got %s" % (hostport, expected_host, actual_host))
        if expected_port != actual_port:
            raise AssertionError("For hostport='%s': expected port=%s, got %s" % (hostport, expected_port, actual_port))


# Generated at 2022-06-20 23:31:51.472919
# Unit test for function parse_address
def test_parse_address():
    import sys
    import warnings

    def describe(a, p=None, h=None, x=False):
        return (
            '%s -> (%s,%s) [%s]' % (
                a, repr(h), repr(p),
                'expected' if (p == parse_address(a)[1] and h == parse_address(a)[0]) else 'unexpected'
            )
        )


# Generated at 2022-06-20 23:32:04.151334
# Unit test for function parse_address
def test_parse_address():
    def test(input, host, port, allow_ranges=False):
        (h, p) = parse_address(input, allow_ranges)
        assert (h, p) == (host, port), \
            "parse_address(%s, %s): expected %s, got %s" % (input, allow_ranges, (host, port), (h, p))

    test('[fe80::1]', 'fe80::1', None, allow_ranges=True)
    test('[::ffff:192.0.2.3]', '::ffff:192.0.2.3', None, allow_ranges=True)
    test('foo[1:3].example.com', 'foo[1:3].example.com', None, allow_ranges=True)