

# Generated at 2022-06-20 23:29:59.764972
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[0:2].example.com') == ('foo[0:2].example.com', None)
    assert parse_address('foo[0:2].example.com:22') == ('foo[0:2].example.com', 22)
    assert parse_address('foo:example:com:22') == ('foo:example:com', 22)
    assert parse_address('foo.example.com:22:33') == ('foo.example.com:22', 33)

# Generated at 2022-06-20 23:30:10.899346
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:21.835590
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("example.com:8080") == ("example.com", 8080)
    assert parse_address("example.com:80:8080") == ("example.com", 80)
    assert parse_address("example[1:3].com") == ("example[1:3].com", None)
    assert parse_address("example[1:3].com:8080") == ("example[1:3].com", 8080)
    assert parse_address("example[1:3]com:8080") == ("example[1:3]com", 8080)
    assert parse_address("example[1-3]com:8080") == ("example[1-3]com", 8080)

# Generated at 2022-06-20 23:30:35.793919
# Unit test for function parse_address
def test_parse_address():
    def add_unittest(address, host, port):
        import ansible.constants as C
        (h, p) = parse_address(address, allow_ranges=C.DEFAULT_HOST_LIST_INTERNAL)
        msg = "Parse of %s gives %s,%s expected %s,%s" % (address, h, p, host, port)
        assert (h, p) == (host, port), msg
    add_unittest("foo:80", "foo", 80)
    add_unittest("foo", "foo", None)
    add_unittest("192.168.0.1", "192.168.0.1", None)
    add_unittest("192.168.0.1:1", "192.168.0.1", 1)
    add_

# Generated at 2022-06-20 23:30:45.183589
# Unit test for function parse_address
def test_parse_address():

    def t(s, explicit_port, host=None, port=None, allow_ranges=False):
        result = parse_address(s, allow_ranges)
        if host is not None or port is not None:
            assert result == (host, port)
        elif explicit_port:
            assert result == (None, explicit_port)
        else:
            assert result == (None, None)

    # IPv4 address with implicit or explicit port
    t('1.2.3.4', None, '1.2.3.4', None)
    t('1.2.3.4:1234', 123)              # implicit port
    t('1.2.3.4:1234', 1234, None, 1234) # explicit port

    # IPv6 address with optional port (must be bracketed)

# Generated at 2022-06-20 23:30:58.083388
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.123') == ('192.0.2.123', None)
    assert parse_address('192.0.2.123:9999') == ('192.0.2.123', 9999)
    assert parse_address('[192.0.2.123]:9999') == ('192.0.2.123', 9999)

    assert parse_address('vpn.example.com') == ('vpn.example.com', None)
    assert parse_address('vpn.example.com:9999') == ('vpn.example.com', 9999)
    assert parse_address('[vpn.example.com]:9999') == ('vpn.example.com', 9999)


# Generated at 2022-06-20 23:31:12.372112
# Unit test for function parse_address
def test_parse_address():
    # Valid hostnames
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo-bar.example.com') == ('foo-bar.example.com', None)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)

    # Valid hostnames with port specification
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)

    # Invalid hostnames because of missing labels
    assert parse_address('.foo') == (None, None)
    assert parse_

# Generated at 2022-06-20 23:31:25.231608
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:39.470080
# Unit test for function parse_address
def test_parse_address():
    def assert_parse(x, host=None, port=None):
        result = parse_address(x)
        msg = "Expected %s, got %s" % ((host, port), result)
        assert host == result[0], msg
        assert port == result[1], msg

    assert_parse('[foo]', 'foo')
    assert_parse('[foo]:1234', 'foo', 1234)
    assert_parse('foo', 'foo')
    assert_parse('foo:1234', 'foo', 1234)
    assert_parse('0.0.0.0', '0.0.0.0')
    assert_parse('0.0.0.0:1234', '0.0.0.0', 1234)
    assert_parse('[::1]', '::1')
    assert_parse

# Generated at 2022-06-20 23:31:51.506786
# Unit test for function parse_address