

# Generated at 2022-06-20 23:30:06.357596
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:14.427932
# Unit test for function parse_address
def test_parse_address():

    def test(address, expect_host, expect_port=None):
        host, port = parse_address(address)
        print("address: %s host: %s port: %s" % (address, host, port))
        if expect_host is None:
            if host:
                return False
        elif host != expect_host:
            return False

        if expect_port is not None and port != expect_port:
            return False

        return True

    if not test("host.example.com:1000", "host.example.com", 1000):
            raise AssertionError("host.example.com:1000 failed")

    if not test("host.example.com", "host.example.com", None):
            raise AssertionError("host.example.com failed")


# Generated at 2022-06-20 23:30:25.026183
# Unit test for function parse_address

# Generated at 2022-06-20 23:30:38.730678
# Unit test for function parse_address
def test_parse_address():
    import nose
    import tempfile
    import sys

    test_data = tempfile.NamedTemporaryFile(mode='w+b', prefix='ansible_test_parse_address_', suffix='.json')
    test_data.write('[\n'.encode('utf-8'))
    test_data.write('    {\n'.encode('utf-8'))
    test_data.write('        "address": "192.0.2.1",\n'.encode('utf-8'))
    test_data.write('        "host": "192.0.2.1",\n'.encode('utf-8'))
    test_data.write('        "port": null\n'.encode('utf-8'))
    test_data.write('    },\n'.encode('utf-8'))

# Generated at 2022-06-20 23:30:53.309678
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:08.350484
# Unit test for function parse_address
def test_parse_address():
    # Set up
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False) as fd:
        fd.write("")
    fd.close()
    global connection_loader
    import ansible.plugins.connection.local
    load_path = ansible.plugins.connection.local.load_path
    connection_loader = ansible.plugins.loader.connection_loader

    # Tests
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.plugin_docs import read_docstring

    group = Group("group1")
    group.vars['ansible_ssh_host'] = "127.0.0.1"

# Generated at 2022-06-20 23:31:23.426803
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address("127.0.0.1")
    assert (host, port) == ("127.0.0.1", None), "Simple IPv4 address"

    host, port = parse_address("[::1]")
    assert (host, port) == ("[::1]", None), "Simple IPv6 address"

    host, port = parse_address("host1.example.com")
    assert (host, port) == ("host1.example.com", None), "Simple host name"

    host, port = parse_address("127.0.0.1:5900")
    assert (host, port) == ("127.0.0.1", 5900), "IPv4 address and port"

    host, port = parse_address("host1.example.com:5900")

# Generated at 2022-06-20 23:31:37.250071
# Unit test for function parse_address

# Generated at 2022-06-20 23:31:50.353487
# Unit test for function parse_address
def test_parse_address():

    from collections import namedtuple
    from nose.tools import ok_, eq_

    Class = namedtuple("Class", ["method", "address", "want", "error"])


# Generated at 2022-06-20 23:32:03.319431
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address('[::1]:22') == ("::1", 22))
    assert (parse_address('[::1]', allow_ranges=False) == ("::1", None))
    assert (parse_address('[::1]:22', allow_ranges=False) == ("::1", 22))
    assert (parse_address('[::a:b:c:d:e:f:0:1]:22') == ("::a:b:c:d:e:f:0:1", 22))
    assert (parse_address('[::ffff:192.0.2.3]:22') == ("::ffff:192.0.2.3", 22))

# Generated at 2022-06-20 23:32:14.846991
# Unit test for function parse_address
def test_parse_address():
    """
    ansible.utils.network.parse_address unit tests
    """
    import pytest


# Generated at 2022-06-20 23:32:28.073574
# Unit test for function parse_address
def test_parse_address():

    # These should be successful.
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=False) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22', allow_ranges=False) == ('foo[1:3]', 22)

    assert parse_address('[foo[1:3]]', allow_ranges=True) == ('foo[1:3]', None)

# Generated at 2022-06-20 23:32:38.329170
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == (u'example.com', None)
    assert parse_address('example.com:22') == (u'example.com', 22)
    assert parse_address('192.0.2.1') == (u'192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == (u'192.0.2.1', 22)
    assert parse_address('[2001:db8::1]') == (u'2001:db8::1', None)
    assert parse_address('[2001:db8::1]:22') == (u'2001:db8::1', 22)
    assert parse_address('[192.0.2.1]:22') == (u'192.0.2.1', 22)
    assert parse_

# Generated at 2022-06-20 23:32:50.594649
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('centos1') == ('centos1', None)
    assert parse_address('centos1.example.com') == ('centos1.example.com', None)
    assert parse_address('centos1.example.com:22') == ('centos1.example.com', 22)
    assert parse_address('devel.example.com:22') == ('devel.example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)

# Generated at 2022-06-20 23:33:01.246904
# Unit test for function parse_address
def test_parse_address():
    """Test that function parse_address returns the expected tuple.
    """
    # Input(address, allow_ranges), expected output(host, port).

    # IPv4 address with no port specified.
    inputs = [('192.0.2.3', False), ('192.0.2.3', True)]
    exp_outputs = [('192.0.2.3', None), ('192.0.2.3', None)]

    # IPv4 address with port specified.
    inputs += [('192.0.2.3:4', False), ('192.0.2.3:4', True),
               ('[192.0.2.3]:4', False), ('[192.0.2.3]:4', True)]

# Generated at 2022-06-20 23:33:13.304402
# Unit test for function parse_address
def test_parse_address():
    """
    Returns a list of test cases for the function parse_address.
    """

# Generated at 2022-06-20 23:33:20.644682
# Unit test for function parse_address
def test_parse_address():

    import unittest2

    class ParseAddressTest(unittest2.TestCase):
        """
        Test cases for function parse_address.
        """
        def test_hostnames(self):
            self.assertEqual(parse_address('foo'), ('foo', None))
            self.assertEqual(parse_address('f.o.o'), ('f.o.o', None))
            self.assertEqual(parse_address('foo:123'), ('foo', 123))
            self.assertEqual(parse_address('[foo]:123'), ('foo', 123))
            self.assertEqual(parse_address('[f.o.o]:123'), ('f.o.o', 123))
            self.assertEqual(parse_address('[foo.example.com]'), ('foo.example.com', None))
            self

# Generated at 2022-06-20 23:33:25.048395
# Unit test for function parse_address
def test_parse_address():
    address = '192.0.2.0:9090'
    (host, port) = parse_address(address)
    print(host)
    print(port)

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-20 23:33:32.710435
# Unit test for function parse_address
def test_parse_address():

    # Valid hostnames and IP addresses with optional ports

    for address in [
        'foobar',
        'foo.bar',
        'foo_bar.123',
        'foo-bar',
        'a.b.c.d.e.f.g',
        '192.0.2.3',
        '192.0.2.3:100',
        '2001:db8::1:2:3:4:5:6:7:8',
        '2001:db8::1:2:3:4:5:6:7:8:100',
        '::ffff:192.0.2.3',
        '::ffff:192.0.2.3:100',
    ]:
        (host, port) = parse_address(address, True)

# Generated at 2022-06-20 23:33:43.662416
# Unit test for function parse_address
def test_parse_address():
    # test the parsing of ipv6
    assert parse_address('[::1]:123') == ('::1', 123)
    assert parse_address('[::1:2:3:4:5:6:7]:123') == ('::1:2:3:4:5:6:7', 123)
    assert parse_address('[::]:123') == ('::', 123)
    assert parse_address('[a1:a2::a3]:123') == ('a1:a2::a3', 123)
    assert parse_address('[1:2:3:4:5:6:7:a1]:123') == ('1:2:3:4:5:6:7:a1', 123)