

# Generated at 2022-06-23 05:11:18.281531
# Unit test for function parse_address
def test_parse_address():
    """
    Test that parse_address() returns the right tuples for a bunch of input
    strings.
    """

    # Some basic checks.
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('example.org:80') == ('example.org', 80)
    assert parse_address('[::1]:443') == ('::1', 443)

    # If a bare IPv4 address is specified, we accept it but don't allow ranges.
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    with open('test_parse_address.err', 'w') as err:
        assert parse_address('192.0.2.3[0:4]', err) == ('192.0.2.3', None)
        assert err

# Generated at 2022-06-23 05:11:25.684836
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:36.141380
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:47.254106
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('host1', allow_ranges=True) == ('host1', None)
    assert parse_address('host1:22', allow_ranges=True) == ('host1', 22)
    assert parse_address('host1[1:4]', allow_ranges=True) == ('host1[1:4]', None)
    assert parse_address('host1[1:4]', allow_ranges=False) == ('host1', None)
    assert parse_address('host1[1:4]:22', allow_ranges=True) == ('host1[1:4]', 22)
    assert parse_address('host1[x:y]:22', allow_ranges=True) == ('host1[x:y]', 22)


# Generated at 2022-06-23 05:11:56.236355
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:06.053305
# Unit test for function parse_address
def test_parse_address():
    # Check that port-only inputs are rejected.
    for addr in [':22', '::22', '[::22]', '[::ffff:a00:2]', '127.0.0.1:22']:
        try:
            parse_address(addr)
            assert False, 'Expected a parse failure'
        except AnsibleError:
            pass

    # Check that IPv4 addresses parse correctly.

# Generated at 2022-06-23 05:12:16.035543
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:25.483948
# Unit test for function parse_address
def test_parse_address():
    """
    This unit test validates the function parse_address using a series of test
    cases.
    """

    # We assume, but don't explicitly test, that the regexes all work as
    # intended, and that the functions in this module are only used by this
    # module. If a test fails, it's hard to tell whether the problem is in the
    # test case or the code.


# Generated at 2022-06-23 05:12:32.232390
# Unit test for function parse_address
def test_parse_address():
    # Tests for a few special cases in the handling of IPv6 addresses.
    #
    # We do not want to regress this functionality.
    #
    # In addition, we want to make sure that the IPv6 address is being
    # canonicalized.

    assert parse_address('[::1:2:3:4:5:6:7]:123') == ('::1:2:3:4:5:6:7', 123)
    assert parse_address('[::1:2:3:4:5:6:7]:123', allow_ranges=True) == ('::1:2:3:4:5:6:7', 123)

    assert parse_address('[1:2:3:4:5:6:7::]:123') == ('1:2:3:4:5:6:7::', 123)
   

# Generated at 2022-06-23 05:12:37.602024
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("host") == ("host", None)
    assert parse_address("host:") == ("host", None)
    assert parse_address("host:5") == ("host", 5)
    assert parse_address("[host]") == ("host", None)
    assert parse_address("[host]:") == ("host", None)
    assert parse_address("[host]:5") == ("host", 5)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:") == ("::1", None)
    assert parse_address("[::1]:5") == ("::1", 5)
    assert parse_address("[::1][::2]:5") == ("::1[::2]", 5)

# Generated at 2022-06-23 05:12:47.796206
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com")                   == ("example.com", None)
    assert parse_address("[2001:db8::1]")                 == ("[2001:db8::1]", None)
    assert parse_address("localhost:11211")               == ("localhost", 11211)
    assert parse_address("[127.0.0.1]:11211")             == ("[127.0.0.1]", 11211)
    assert parse_address("[127.0.0.1]")                   == ("[127.0.0.1]", None)
    assert parse_address("example.com:11")                == ("example.com", 11)
    assert parse_address("example.com[1:3]")              == ("example.com[1:3]", None)

# Generated at 2022-06-23 05:12:56.928276
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:07.722689
# Unit test for function parse_address
def test_parse_address():
    assert ('a', None) == parse_address('a')
    assert ('foo', None) == parse_address('foo')
    assert ('foo.example.com.', None) == parse_address('foo.example.com.')
    assert ('10', None) == parse_address('10')
    assert ('10.20', None) == parse_address('10.20')
    assert ('10.20.30', None) == parse_address('10.20.30')
    assert ('10.20.30.40', None) == parse_address('10.20.30.40')
    assert ('10', 1234) == parse_address('10:1234')
    assert ('10.20', 5678) == parse_address('10.20:5678')

# Generated at 2022-06-23 05:13:17.210271
# Unit test for function parse_address
def test_parse_address():

    # Test all the combinations of IPv4 addresses and port specifications that
    # may be accepted: IP:port, IP/port, [IP], [IP]/port.
    for address in [
        '192.0.2.1:123',
        '192.0.2.1/124',
        '[192.0.2.1]:125',
        '[192.0.2.1]/126',
        '[192.0.2.1]',
        '192.0.2.1',
        '192.0.2.1:65535',
        '192.0.2.1/65535',
        '192.0.2.1:0',
        '192.0.2.1/0',
    ]:
        (h, p) = parse_address(address)

# Generated at 2022-06-23 05:13:24.693022
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:35.239871
# Unit test for function parse_address
def test_parse_address():
    from nose import tools as nt

    # Examples from the IPv4 and IPv6 addres space.
    for ipv4s in [
        '192.0.2.1',
        '192.0.2.1:123',
        '[192.0.2.1]:123',
        '[192.0.2.1]:',
        '[192.0.2.1]',
    ]:
        nt.assert_equal(parse_address(ipv4s, allow_ranges=True), (ipv4s, None))
        nt.assert_equal(parse_address(ipv4s, allow_ranges=False), (ipv4s, None))


# Generated at 2022-06-23 05:13:46.785985
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo.example.com:123') == ('foo.example.com', 123)
    assert parse_address('foo[0:3]:123') == ('foo[0:3]', 123)
    assert parse_address('[::1]:123') == ('[::1]', 123)
    assert parse_address('192.0.2.1:123') == ('192.0.2.1', 123)
    assert parse_address('[192.0.2.1]:123') == ('[192.0.2.1]', 123)

# Generated at 2022-06-23 05:13:58.373803
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:80') == ('2001:db8::1', 80)
    assert parse_address('foo[0:9]') == ('foo[0:9]', None)
    assert parse_address('[example.com]') == ('example.com', None)

# Generated at 2022-06-23 05:14:09.533892
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:21.367223
# Unit test for function parse_address
def test_parse_address():
    # Invalid addresses
    assert parse_address('a,[192.0.2.1]') == (None, None)
    assert parse_address('a, [192.0.2.1]') == (None, None)
    assert parse_address('a, [192.0.2.1]:123') == (None, None)
    assert parse_address('[192.0.2.1]a') == (None, None)
    assert parse_address('[192.0.2.1]:1:2') == (None, None)
    assert parse_address('foo.example.com:') == (None, None)
    assert parse_address('[192.0.2.1]:65536') == (None, None)
    assert parse_address('[192.0.2.1]:100000') == (None, None)

# Generated at 2022-06-23 05:14:31.711560
# Unit test for function parse_address
def test_parse_address():
    # IPv4 with port
    assert parse_address('127.0.0.1:22') == ("127.0.0.1", 22)
    # IPv4 with IPv4 ranges and port
    assert parse_address('192.0.2.[1:5]:22', allow_ranges=True) == ("192.0.2.[1:5]", 22)
    # IPv4 with IPv4 ranges, no port
    assert parse_address('192.0.2.[1:5]', allow_ranges=True) == ("192.0.2.[1:5]", None)
    # IPv4 with IPv4 ranges and port, inside brackets
    assert parse_address('[192.0.2.[1:5]]:22', allow_ranges=True) == ("192.0.2.[1:5]", 22)
    #

# Generated at 2022-06-23 05:14:41.893533
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('::1]') == (None, None)
    assert parse_address('[::1') == (None, None)
    assert parse_address('[::1') == (None, None)
    assert parse_address('bracketsarevalidhere') == ('bracketsarevalidhere', None)
    assert parse_address('brackets[are]validhere') == ('brackets[are]validhere', None)
    assert parse_address('brackets[are]validhere', allow_ranges=True) == ('brackets[are]validhere', None)
    assert parse_address('name:port') == ('name', None)

# Generated at 2022-06-23 05:14:53.144957
# Unit test for function parse_address
def test_parse_address():
    '''
    >>> test_parse_address()
    >>>
    '''

    _test_parse_address('foo', 'foo', None)
    _test_parse_address('foo:42', 'foo', 42)
    _test_parse_address('foo:42:99', 'foo', 42)
    _test_parse_address('foo[1:3]:42', 'foo[1:3]', 42)
    _test_parse_address('foo[0:5]:42', 'foo[0:5]', 42)
    _test_parse_address('foo[0:5]-bar[x-z]:42', 'foo[0:5]-bar[x-z]', 42)

# Generated at 2022-06-23 05:14:59.438194
# Unit test for function parse_address
def test_parse_address():
    # Tests for IPv4 address parsing
    assert parse_address('192.0.2.10:100') == ('192.0.2.10', 100)
    assert parse_address('192.0.2.10:100', allow_ranges=True) == ('192.0.2.10', 100)
    assert parse_address('192.0.2.10') == ('192.0.2.10', None)
    assert parse_address('192.0.2.10', allow_ranges=True) == ('192.0.2.10', None)
    assert parse_address('[192.0.2.10]') == ('192.0.2.10', None)
    assert parse_address('[192.0.2.10]', allow_ranges=True) == ('192.0.2.10', None)

# Generated at 2022-06-23 05:15:10.710107
# Unit test for function parse_address
def test_parse_address():
    import json, pprint


# Generated at 2022-06-23 05:15:22.366997
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:28.166127
# Unit test for function parse_address
def test_parse_address():
    assert None == parse_address(None)
    assert (None, None) == parse_address('')

    # Test IPv4 addresses
    assert ('1.2.3.4', 22) == parse_address('1.2.3.4:22')
    assert ('1.2.3.4', None) == parse_address('1.2.3.4')

    # Test IPv6 addresses
    assert ('::1', 22) == parse_address('[::1]:22')
    assert ('::1', None) == parse_address('[::1]')
    assert ('::1', None) == parse_address('[::1]:')
    assert ('1:2:3:4:5:6:7:8', 22) == parse_address('[1:2:3:4:5:6:7:8]:22')

# Generated at 2022-06-23 05:15:38.909874
# Unit test for function parse_address
def test_parse_address():
    # hostname tests
    (host, port) = parse_address("example.com")
    assert host == "example.com" and port is None

    (host, port) = parse_address("example.com:22")
    assert host == "example.com" and port == 22

    (host, port) = parse_address("[example.com]:22")
    assert host == "example.com" and port == 22

    # IPv4 tests
    (host, port) = parse_address("192.0.2.1")
    assert host == "192.0.2.1" and port is None

    (host, port) = parse_address("192.0.2.1:22")
    assert host == "192.0.2.1" and port == 22


# Generated at 2022-06-23 05:15:48.641218
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('host:22') == ('host', 22)
    assert parse_address('host') == ('host', None)
    assert parse_address('hostname.com') == ('hostname.com', None)
    assert parse_address('hostname.com:2222') == ('hostname.com', 2222)
    assert parse_address('hostname[1:2]') == ('hostname[1:2]', None)
    assert parse_address('hostname[1:2]', True) == ('hostname[1:2]', None)
    assert parse_address('hostname[1:2]:2222') == ('hostname[1:2]', 2222)

# Generated at 2022-06-23 05:16:00.247885
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:09.267238
# Unit test for function parse_address
def test_parse_address():
    import unittest
    import textwrap

    class TestParseAddress(unittest.TestCase):
        def check_address(self, address, host=None, port=None, allow_ranges=False):
            r = parse_address(address, allow_ranges)
            self.assertEqual(r, (host, port))


# Generated at 2022-06-23 05:16:18.232633
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:29.014574
# Unit test for function parse_address
def test_parse_address():
    import pytest

    host = 'bracketed_hostport'
    port = 'bracketed_port'
    assert (host, port) == parse_address('[%s]:%s' % (host, port))

    host = 'hostport'
    port = 'hostport_port'
    assert (host, port) == parse_address('%s:%s' % (host, port))

    host = '192.168.1.1'
    port = 'ipv4_port'
    assert (host, port) == parse_address('%s:%s' % (host, port))

    host = '::ffff:192.168.1.1'
    port = 'ipv6_port'
    assert (host, port) == parse_address('[%s]:%s' % (host, port))



# Generated at 2022-06-23 05:16:40.506155
# Unit test for function parse_address
def test_parse_address():
    def e(m, a, p=None):
        (h, p2) = parse_address(a)
        if p is None:
            if h == a and p2 is None:
                pass
            else:
                print("%s FAILED: expected (%s, None) or (%s, None), got (%s, %s)" % (m, a, a, h, p2))
        else:
            if h == a and p == p2:
                pass
            else:
                print("%s FAILED: expected (%s, %s), got (%s, %s)" % (m, a, p, h, p2))


# Generated at 2022-06-23 05:16:52.965277
# Unit test for function parse_address
def test_parse_address():

    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo.example.com") == ("foo.example.com", None)

    assert parse_address("foo:1234") == ("foo", 1234)
    assert parse_address("foo.example.com:1234") == ("foo.example.com", 1234)

    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:1234") == ("192.0.2.1", 1234)

    assert parse_address("[::1]") == ("[::1]", None)
    assert parse_address("[::1]:1234") == ("[::1]", 1234)


# Generated at 2022-06-23 05:17:05.065836
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:16.445260
# Unit test for function parse_address
def test_parse_address():
    # Test hostnames
    assert parse_address('[::1]', False) == (u'::1', None)
    assert parse_address('[::1]:1234', False) == (u'::1', 1234)
    assert parse_address('gw-1', False) == ('gw-1', None)
    assert parse_address('node-01', False) == ('node-01', None)
    assert parse_address('host.example.org', False) == ('host.example.org', None)
    assert parse_address('host:1234', False) == ('host', 1234)
    assert parse_address('host.example.org:1234', False) == ('host.example.org', 1234)

    # Test IPv4

# Generated at 2022-06-23 05:17:23.904538
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:65432') == ('localhost', 65432)
    assert parse_address('localhost:45678') == ('localhost', 45678)
    assert parse_address('foo.example.com:65432') == ('foo.example.com', 65432)
    assert parse_address('foo.example.com:65432') == ('foo.example.com', 65432)
    assert parse_address('[127.0.0.1]:65432') == ('127.0.0.1', 65432)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)

# Generated at 2022-06-23 05:17:29.258803
# Unit test for function parse_address
def test_parse_address():
    """
    Test the parsing of addresses
    """
    # Tests for function parse_address
    # Parse an IP address with a port suffix
    assert parse_address('192.168.1.1:80', allow_ranges=False) == ('192.168.1.1', 80)
    assert parse_address('192.168.1.1:80', allow_ranges=True) == ('192.168.1.1', 80)

    # Parse an IPv4 address with numeric ranges and a port suffix
    assert parse_address('192.168.1[1:3].1:80', allow_ranges=False) == ('192.168.1[1:3].1', 80)

# Generated at 2022-06-23 05:17:41.661903
# Unit test for function parse_address
def test_parse_address():
    # A bunch of tests to verify that the above regexps are correct.
    # Sadly, it's not really possible to do this automatically.

    # For comparison, the set of valid hostnames according to RFC 1034.
    valid_rfc1034_hostnames = [
        'example.com',
        'www.example.com',
        'example',
        '3com',
        '3.com',
        '3-com',
        '3.2.1.com',
        'xn--0zwm56d.',
    ]

    # For comparison, the set of valid IPv4 addresses according to RFC 2373.

# Generated at 2022-06-23 05:17:54.464530
# Unit test for function parse_address
def test_parse_address():
    ipv4 = '192.0.2.42:80'
    ipv4_ranges = '192.0.2.[1:3]:80'
    ipv6 = '[1080::8:800:200C:417A]:80'
    ipv6_ranges = '[1080::8:800:[1:3]:417A]:80'
    hostname = 'example.com:80'
    hostname_ranges = 'example[0:1].com:80'
    barehostname = 'example.com'
    barehostname_ranges = 'example[0:1].com'

    assert parse_address(ipv4) == ('192.0.2.42', 80)
    assert parse_address(ipv4_ranges) == ('192.0.2.[1:3]', 80)

# Generated at 2022-06-23 05:18:05.717536
# Unit test for function parse_address
def test_parse_address():

    # Simple hostname, no port
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('foo.bar') == ('foo.bar', None)

    # IPv4 address, no port
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('172.16.254.1') == ('172.16.254.1', None)

    # IPv6 address, no port
    assert parse_address('::') == ('::', None)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('2001:db8::') == ('2001:db8::', None)
    assert parse_address('c000:00ff::') == ('c000:00ff::', None)



# Generated at 2022-06-23 05:18:16.896846
# Unit test for function parse_address
def test_parse_address():
    # Simple cases
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:23') == ('1.2.3.4', 23)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:23') == ('foo', 23)
    assert parse_address('foo:23:42') == ('foo:23:42', None)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:23') == ('1.2.3.4', 23)
    assert parse_address('[foo]') == ('foo', None)

# Generated at 2022-06-23 05:18:27.422530
# Unit test for function parse_address
def test_parse_address():
    import nose.tools
    nose.tools.assert_equal((None, None), parse_address(''))
    nose.tools.assert_equal(('foo', 22), parse_address('foo:22'))
    nose.tools.assert_equal(('abc-123', 22), parse_address('abc-123:22'))
    nose.tools.assert_equal(('abc_123.example.com', 22), parse_address('abc_123.example.com:22'))
    nose.tools.assert_equal(('[::1]', 22), parse_address('[::1]:22'))
    nose.tools.assert_equal(('1::1', 22), parse_address('[1::1]:22'))

# Generated at 2022-06-23 05:18:39.896097
# Unit test for function parse_address
def test_parse_address():
    # Defensive test for an empty string.
    (host, port) = parse_address('')
    assert host == None
    assert port == None

    # A valid host name with no port specification.
    (host, port) = parse_address('foo')
    assert host == 'foo'
    assert port == None

    # This is even a valid host pattern.
    (host, port) = parse_address('foo[1-3]')
    assert host == 'foo[1-3]'
    assert port == None

    # An IPv4 address with no port specification.
    (host, port) = parse_address('192.0.2.1')
    assert host == '192.0.2.1'
    assert port == None

    # An IPv6 address with no port specification.

# Generated at 2022-06-23 05:18:50.726273
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:58.167411
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com[0:5]') == ('foo.example.com[0:5]', None)
    assert parse_address('foo.example.com[0:5]:22') == ('foo.example.com[0:5]', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com[0:5]]:22') == ('foo.example.com[0:5]', 22)


# Generated at 2022-06-23 05:19:08.365318
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[2001:db8::]', allow_ranges=True) == (u'2001:db8::', None)
    assert parse_address('[2001:db8::]:22', allow_ranges=True) == (u'2001:db8::', 22)
    assert parse_address('2001:db8::', allow_ranges=True) == (u'2001:db8::', None)
    assert parse_address('2001:db8::1', allow_ranges=True) == (u'2001:db8::1', None)
    assert parse_address('192.0.2.1', allow_ranges=True)

# Generated at 2022-06-23 05:19:19.544865
# Unit test for function parse_address
def test_parse_address():
    '''Test parsing of network hostnames with and without ports.'''

    # 'invalid' is not a valid hostname and will not parse.

# Generated at 2022-06-23 05:19:28.377784
# Unit test for function parse_address
def test_parse_address():
    # Test valid addresses
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22:33') == ('foo', 22)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('1.2.3.4:22:3') == ('1.2.3.4', 22)
    assert parse_address('[1.2.3.4]:22') == ('1.2.3.4', 22)

# Generated at 2022-06-23 05:19:39.040781
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 with and without port
    assert parse_address('10.0.0.1') == ('10.0.0.1', None)
    assert parse_address('10.0.0.1:22') == ('10.0.0.1', 22)
    # Test IPv4 with and without port, and ranges
    assert parse_address('10.0.0.[1:2]') == ('10.0.0.[1:2]', None)
    assert parse_address('10.0.0.[1:2]:22') == ('10.0.0.[1:2]', 22)
    # Test IPv6 with and without port, and ranges
    assert parse_address('[fe80::1]') == ('[fe80::1]', None)

# Generated at 2022-06-23 05:19:48.121484
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo', False) == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:2]', False) == ('foo[1:2]', None)
    assert parse_address('foo[1:2]:22') == ('foo[1:2]', 22)
    assert parse_address('foo[1:2]-bar[3-4]', False) == ('foo[1:2]-bar[3-4]', None)
    assert parse_address('foo[1:2]-bar[3-4]:22') == ('foo[1:2]-bar[3-4]', 22)

    assert parse_address('foo', True) == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
   

# Generated at 2022-06-23 05:19:57.933261
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('bar[1:2]') == ('bar[1:2]', None)
    assert parse_address('bar[1:2]:22') == ('bar[1:2]', 22)

    # IPv4 addresses, supporting ranges
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('192.168.1.1:22') == ('192.168.1.1', 22)
    assert parse_address('10.0.0.1[1:2]') == ('10.0.0.1[1:2]', None)

# Generated at 2022-06-23 05:20:08.181933
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:19.113533
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:30.191008
# Unit test for function parse_address
def test_parse_address():
    # check for IPv4 address
    host, port = parse_address("192.168.0.1:22")
    assert host == "192.168.0.1"
    assert port == 22
    # check for IPv6 address
    host, port = parse_address("[2001:db8:85a3::8a2e:370:7334]:22")
    assert host == "2001:db8:85a3::8a2e:370:7334"
    assert port == 22
    # check for IPv4 address with range
    host, port = parse_address("192.168.0.[1:5]:22", allow_ranges=True)
    assert host == "192.168.0.[1:5]"
    assert port == 22
    # check for IPv6 address with range

# Generated at 2022-06-23 05:20:41.590483
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:48.086794
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo:123") == ("foo", 123)
    assert parse_address("foo.example.com:123") == ("foo.example.com", 123)
    assert parse_address("[foo.example.com]:123") == ("foo.example.com", 123)
    assert parse_address("192.0.2.254") == ("192.0.2.254", None)
    assert parse_address("192.0.2.254:123") == ("192.0.2.254", 123)
    assert parse_address("[192.0.2.254]") == ("192.0.2.254", None)
    assert parse_address("[192.0.2.254]:123") == ("192.0.2.254", 123)
   

# Generated at 2022-06-23 05:20:58.406136
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:05.595214
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:14.115727
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address("foo")
    assert host == "foo"
    assert port is None

    host, port = parse_address("foo:")
    assert host is None
    assert port is None

    host, port = parse_address("foo:1")
    assert host == "foo"
    assert port == 1

    host, port = parse_address("foo:65535")
    assert host == "foo"
    assert port == 65535

    host, port = parse_address("foo:65536")
    assert host is None
    assert port is None

    host, port = parse_address("1.2.3.4")
    assert host == "1.2.3.4"
    assert port is None

    host, port = parse_address("1.2.3.4:")
    assert host is None
