

# Generated at 2022-06-23 05:11:18.170994
# Unit test for function parse_address
def test_parse_address():
    test_cases = [
        ('192.0.2.1', ('192.0.2.1', None)),
        ('2001:db8::', ('2001:db8::', None)),
        ('www.example.com', ('www.example.com', None)),
        ('[::1]:80', ('::1', 80)),
        ('[::ffff:192.0.2.3]:80', ('::ffff:192.0.2.3', 80)),
        ('192.0.2.1:80', ('192.0.2.1', 80)),
        ('[192.0.2.1]:80', ('192.0.2.1', 80)),
    ]

    for (host, expected) in test_cases:
        result = parse_address(host)
        assert result == expected


# Generated at 2022-06-23 05:11:29.018343
# Unit test for function parse_address
def test_parse_address():
    """
    These examples come from the docstring above, to check that the examples
    there work.
    """

# Generated at 2022-06-23 05:11:37.901764
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:45.104688
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:53.406918
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:04.763262
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)

    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)


# Generated at 2022-06-23 05:12:14.709839
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address(' 1.2.3.4 ') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)
    assert parse_address(' [1.2.3.4] ') == ('1.2.3.4', None)
    assert parse_address(' [1.2.3.4]:5 ') == ('1.2.3.4', 5)
    assert parse_address(' 1.2.3.4:5 ') == ('1.2.3.4', 5)

# Generated at 2022-06-23 05:12:25.596539
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:1234') == ('foo', 1234)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:1234') == ('foo[1:3]', 1234)
    assert parse_address('[1.2.3.4]:1234') == ('1.2.3.4', 1234)
    assert parse_address('[1.2.3.4.5]:1234') == ('[1.2.3.4.5]:1234', None)
    assert parse_address('[1.2.3.4]:[1234]') == ('[1.2.3.4]:[1234]', None)

# Generated at 2022-06-23 05:12:33.259357
# Unit test for function parse_address
def test_parse_address():
    if not patterns:
        # If patterns are undefined, we're probably running in an environment
        # where regular expressions haven't been loaded. Because this is just
        # a test, skip all the tests.
        return

    # Tests for ipv4 parsing
    assert parse_address("10.20.30.40") == ("10.20.30.40", None)
    assert parse_address("10.20.30.40:22") == ("10.20.30.40", 22)
    assert parse_address("10.20.30.40:22") == ("10.20.30.40", 22)
    assert parse_address("[10.20.30.40:22]") == ("10.20.30.40", 22)

# Generated at 2022-06-23 05:12:41.756064
# Unit test for function parse_address
def test_parse_address():
    FAIL = "Parsing expected to fail"


# Generated at 2022-06-23 05:12:51.045323
# Unit test for function parse_address
def test_parse_address():

    with open('test/utils/parse_address.json', 'r') as f:
        test_data = json.load(f)

    for test in test_data:
        if test['allow_ranges']:
            address = parse_address(test['address'], True)
        else:
            address = parse_address(test['address'])
        assert address == (test['host'], test['port']), \
            "Comparing {0} with {1} (expected {2})".format(address, test['address'], (test['host'], test['port']))

if __name__ == "__main__":
    import sys
    import json
    from random import randint
    
    argv = sys.argv[1:]

# Generated at 2022-06-23 05:12:58.258111
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:08.768722
# Unit test for function parse_address
def test_parse_address():
    """
    Test that parse_address provides the expected value.
    """
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:80') == ('foo', 80)
    assert parse_address('foo[0:4]') == ('foo', None)
    assert parse_address('foo[0:4]:80') == ('foo[0:4]', 80)
    assert parse_address('[foo[0:4]]:80') == ('foo[0:4]', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)

# Generated at 2022-06-23 05:13:18.185036
# Unit test for function parse_address
def test_parse_address():
    t = parse_address
    assert t('foo.example.com')  == ('foo.example.com', None)
    assert t('[::]')             == ('::', None)
    assert t('[::]:5')           == ('::', 5)
    assert t('[::]:-1')          == ('::', -1)
    assert t('192.0.2.1')        == ('192.0.2.1', None)
    assert t('192.0.2.1:5')      == ('192.0.2.1', 5)
    assert t('192.0.2.1:-1')     == ('192.0.2.1', -1)
    assert t('foo.example.com:5') == ('foo.example.com', 5)

# Generated at 2022-06-23 05:13:29.418828
# Unit test for function parse_address
def test_parse_address():
    # Simple hostnames
    assert parse_address("localhost")                       == (u"localhost", None)
    assert parse_address("localhost:22")                    == (u"localhost", 22)
    assert parse_address("foo.example.com")                 == (u"foo.example.com", None)
    assert parse_address("foo.example.com:22")              == (u"foo.example.com", 22)

    # Illegal hostnames (trailing dot, underscore, hyphen)
    for s in [".", "_.", "-.", "_.example.com", "-.example.com"]:
        try:
            parse_address(s)
            assert False, "Did not raise exception"
        except AnsibleParserError:
            pass

    # Hostnames with square brackets (just one)

# Generated at 2022-06-23 05:13:40.187261
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:22') == ('1.2.3.4', 22)
    assert parse_address('[1.2.3.4]:0') == ('1.2.3.4', 0)
    assert parse_address('foo.example.com[bar]:22') == ('foo.example.com[bar]', 22)
    assert parse_address('foo.example.com[bar[x:y]]:22') == ('foo.example.com[bar[x:y]]', 22)
   

# Generated at 2022-06-23 05:13:48.507492
# Unit test for function parse_address
def test_parse_address():
    def test(c):
        return parse_address(c[0], allow_ranges=c[1])


# Generated at 2022-06-23 05:13:57.507682
# Unit test for function parse_address
def test_parse_address():
    def assert_parse(string, host, port):
        (h, p) = parse_address(string)
        assert (h, p) == (host, port), \
            "{0} should parse to {1} but got {2}".format(string, (host, port), (h, p))

    # host:port
    assert_parse('example.com', 'example.com', None)
    assert_parse('example.com:22', 'example.com', 22)
    # IPv4
    assert_parse('192.0.2.3', '192.0.2.3', None)
    assert_parse('192.0.2.3:22', '192.0.2.3', 22)
    assert_parse('127.0.0.1', '127.0.0.1', None)

# Generated at 2022-06-23 05:14:06.736909
# Unit test for function parse_address
def test_parse_address():
    # test with hostname
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)

    # test with IPv6 address
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:80') == ('::1', 80)

    # test with IPv4 address
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:80') == ('127.0.0.1', 80)

    # hostname, IPv6 address and IPv4 address should all work with ranges,
    # if we allow them.

# Generated at 2022-06-23 05:14:17.510559
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1', allow_ranges=True) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=True) == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]:22', allow_ranges=True) == ('127.0.0.1', 22)
    assert parse_address('foo', allow_ranges=True) == ('foo', None)

# Generated at 2022-06-23 05:14:29.232598
# Unit test for function parse_address
def test_parse_address():
    """
    We should parse a variety of valid host identifiers, with and without
    port specifications. We should not parse invalid ones.
    """

    import pytest


# Generated at 2022-06-23 05:14:37.156041
# Unit test for function parse_address
def test_parse_address():
    def test_it(a, *expect):
        result = parse_address(a)
        print("parse_address(%r) returned %r" % (a, result))
        assert result == expect

    # Simple IPv4
    test_it("192.0.2.1", "192.0.2.1", None)
    test_it("192.0.2.1:22", "192.0.2.1", 22)
    test_it("192.0.2.1:65535", "192.0.2.1", 65535)

    # Simple IPv6
    test_it("[2001:db8::1]", "2001:db8::1", None)
    test_it("[2001:db8::1]:22", "2001:db8::1", 22)

# Generated at 2022-06-23 05:14:50.201094
# Unit test for function parse_address
def test_parse_address():
    def testcase(address, expected):
        (host, port) = parse_address(address)
        assert (host, port) == expected
        r = "Host: %r Port: %r" % (host, port)
        if expected == (None, None):
            assert False, "parsed bad address %r as %s" % (address, r)
        else:
            assert True, "parsed address %r as %s" % (address, r)


# Generated at 2022-06-23 05:14:58.447902
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-23 05:15:08.808838
# Unit test for function parse_address
def test_parse_address():
    """
    Since this function is used as a context manager in Ansible, it needs
    to be fully exercised.
    """

# Generated at 2022-06-23 05:15:19.222132
# Unit test for function parse_address
def test_parse_address():
    # Test the failure cases first.
    for address in [
        'foo',                 # Not a valid hostname
        '9.9.-9.9',            # Not a valid IPv4 address
        '::ffff:g.g.g.g',      # Not a valid IPv6 address
        'gopher://[::1]:70',   # Not a valid range
        ':::',                 # Also not a valid range (no [0:0] in IPv6)
        'foo.example.com:',    # Missing port number
        '[::1]:',              # Missing port number
    ]:
        try:
            parse_address(address)
            assert False
        except AnsibleError:
            pass

    # Now the success cases.

# Generated at 2022-06-23 05:15:27.249976
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:37.747017
# Unit test for function parse_address
def test_parse_address():
    # Note that these tests do not try to exercise all the parsing logic. That
    # happens in the unit tests for ansible.inventory.host, which is where the
    # logic originated. These tests focus on the range handling aspects only.

    try:
        assert('host.example.com', None) == parse_address('host.example.com')
        assert('host.example.com', None) == parse_address('host.example.com:')
        assert('host', None) == parse_address('host')
        assert('host', None) == parse_address('host:')
    except AssertionError:
        return False

    # With ranges, a hostname must have a port number.


# Generated at 2022-06-23 05:15:48.007173
# Unit test for function parse_address
def test_parse_address():
    # TODO: this should be a unittest
    # TODO: we should create a fixture for each error and write
    #       a loop that calls parse_address with different values
    #       and checks whether the result is correct, or a specific
    #       error is raised
    try:
        parse_address('foo-bar')
        assert False, "Must not accept hostnames with dashes"
    except AnsibleError:
        pass

    try:
        parse_address('[192.0.2.3:-1]')
        assert False, "Must not accept ports with negative values"
    except AnsibleError:
        pass

    try:
        parse_address('192.0.2.3:65536')
        assert False, "Must not accept ports with values above 65535"
    except AnsibleError:
        pass


# Generated at 2022-06-23 05:15:59.696061
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:08.843953
# Unit test for function parse_address
def test_parse_address():
    import re

# Generated at 2022-06-23 05:16:17.940849
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:28.729282
# Unit test for function parse_address
def test_parse_address():

    def assert_parsed_address(address, expected_host, expected_port=None):
        (host, port) = parse_address(address)
        assert host == expected_host
        assert port == expected_port

    # These should all be legal.

    assert_parsed_address('foo', 'foo')                                        # plain hostname
    assert_parsed_address('f.com', 'f.com')                                    # qualified hostname
    assert_parsed_address('192.0.2.1', '192.0.2.1')                            # IPv4 address
    assert_parsed_address('[::1]', '::1', port=None)                           # IPv6 address
    assert_parsed_address('[::1]:22', '::1', port=22)                          # IPv6 address

# Generated at 2022-06-23 05:16:40.349173
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:52.808811
# Unit test for function parse_address
def test_parse_address():
    """
    These unit tests are constructed a little differently from the rest of
    Ansible. They're bundled here and only run as part of this module, because
    they depend on the patterns defined in patterns[] above, which in turn
    depend on the regex module which we don't want to load if we're never
    going to run these tests anyway.
    """

    # pylint: disable=unused-argument
    import ansible.module_utils.network as network

    def run_tests(tests, allow_ranges):

        for address, expected in tests:
            result = network.parse_address(address, allow_ranges)
            assert result == expected, "parsing '%s' => %s but expected %s" % (address, result, expected)


# Generated at 2022-06-23 05:17:04.904216
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:16.393082
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:28.680466
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:40.874145
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:1', True) == ('foo', 1)
    assert parse_address('foo[0:3]:22') == ('foo[0:3]', 22)
    assert parse_address('foo[0:3]:22', True) == ('foo[0:3]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[192.0.2.4]:22') == ('192.0.2.4', 22)
    assert parse_address('[192.0.2.4:5:7]:22') == ('192.0.2.4:5:7', 22)

# Generated at 2022-06-23 05:17:52.340105
# Unit test for function parse_address
def test_parse_address():
    from nose.tools import assert_equal

    assert_equal(parse_address("localhost"), ("localhost", None))
    assert_equal(parse_address("localhost:5999"), ("localhost", 5999))
    assert_equal(parse_address("localhost:5999"), ("localhost", 5999))
    assert_equal(parse_address("[localhost]:5999"), ("localhost", 5999))
    assert_equal(parse_address("127.0.0.1"), ("127.0.0.1", None))
    assert_equal(parse_address("127.0.0.1:5999"), ("127.0.0.1", 5999))
    assert_equal(parse_address("127[0.0.1]:5999"), ("127[0.0.1]", 5999))

# Generated at 2022-06-23 05:18:04.086429
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[2002:c000:0204::1]:22') == ('2002:c000:0204::1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('[::ffff:c000:2ff]:22') == ('::ffff:c000:2ff', 22)

# Generated at 2022-06-23 05:18:16.360993
# Unit test for function parse_address
def test_parse_address():
    import pytest
    with pytest.raises(AnsibleError) as excinfo:
        parse_address('[foo]')  # Malformed IPv6
    assert 'not a valid network hostname' in str(excinfo.value)

    # Valid IPv4 address with a port spec
    assert parse_address('192.0.2.3:3') == ('192.0.2.3', 3)

    # Valid IPv4 address with a range spec
    assert parse_address('192.0.2[1:2].3') == ('192.0.2[1:2].3', None)

    # Valid IPv4 range and port
    assert parse_address('192.0.2[1:2].3:3') == ('192.0.2[1:2].3', 3)

    # Valid IPv6 address with a port

# Generated at 2022-06-23 05:18:27.278841
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4', allow_ranges=True) == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:5678') == ('1.2.3.4', 5678)
    assert parse_address('1.2.3.4', allow_ranges=False) == ('1.2.3.4', None)
    assert parse_address('1.2.3.4[80:82]', allow_ranges=True) == ('1.2.3.4[80:82]', None)
    assert parse_address('1.2.3.4[80:82]') == ('1.2.3.4[80:82]', None)

# Generated at 2022-06-23 05:18:39.729310
# Unit test for function parse_address
def test_parse_address():
    # This is a test because parse_address() is used in two places for
    # different purposes (connection_plugins/paramiko_ssh.py and
    # lib/ansible/inventory/host.py), and the obvious way to test it
    # (override it in the relevant classes) didn't work.

    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)

    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)

   

# Generated at 2022-06-23 05:18:50.572702
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:23') == ('foo.example.com', 23)
    assert parse_address('192.0.2.50') == ('192.0.2.50', None)
    assert parse_address('192.0.2.50:23') == ('192.0.2.50', 23)
    assert parse_address('[2001:db8::1]') == ('[2001:db8::1]', None)
    assert parse_address('[2001:db8::1]:23') == ('[2001:db8::1]', 23)
    assert parse_address('[192.0.2.50]') == ('[192.0.2.50]', None)
    assert parse_address

# Generated at 2022-06-23 05:18:59.919103
# Unit test for function parse_address
def test_parse_address():
    """
    Call playbooks with a bunch of hostnames that may or may not be valid,
    and make sure they do what they're supposed to do.
    """

    import os
    import ansible.playbook
    from ansible.module_utils._text import to_text


# Generated at 2022-06-23 05:19:09.391453
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]/64') == ('::1/64', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('[2001:db8::1]/64') == ('2001:db8::1/64', None)

    assert parse_address('[2001:db8::1]:22', allow_ranges=True)

# Generated at 2022-06-23 05:19:20.172009
# Unit test for function parse_address
def test_parse_address():
    # Bracketed address with port
    (host, port) = parse_address('[127.0.0.1]:123')
    assert host == '127.0.0.1'
    assert port == 123

    # Unbracketed address with port
    (host, port) = parse_address('127.0.0.1:123')
    assert host == '127.0.0.1'
    assert port == 123

    # IPv6 address with port
    (host, port) = parse_address('[::1]:123')
    assert host == '::1'
    assert port == 123

    # Bracketed address without port
    (host, port) = parse_address('[127.0.0.1]')
    assert host == '127.0.0.1'
    assert port is None

    # Un

# Generated at 2022-06-23 05:19:31.919534
# Unit test for function parse_address
def test_parse_address():
    '''
    Test the function parse_address.

    :return: If parse_address returns the correct result.
    :rtype: bool
    '''
    from ansible.utils.network import parse_address


# Generated at 2022-06-23 05:19:43.954503
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:56.296726
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:123') == ('192.0.2.3', 123)
    assert parse_address('[192.0.2.3]:123') == ('192.0.2.3', 123)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com.au', allow_ranges=True) == ('foo.example.com.au', None)
    assert parse_address('foo[a].example.com', allow_ranges=True) == ('foo[a].example.com', None)

# Generated at 2022-06-23 05:20:06.427266
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:18.185184
# Unit test for function parse_address
def test_parse_address():
    import types
    assert isinstance(parse_address, types.FunctionType)
    # with port specification
    (host, port) = parse_address('example.com:1234')
    assert host == 'example.com'
    assert port == 1234
    (host, port) = parse_address('foo.example.com:1234')
    assert host == 'foo.example.com'
    assert port == 1234
    (host, port) = parse_address('192.168.0.1:1234')
    assert host == '192.168.0.1'
    assert port == 1234
    (host, port) = parse_address('2001:0db8:85a3:0042:1000:8a2e:1310:7334:1234')

# Generated at 2022-06-23 05:20:29.354357
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('example.com[1:3]') == ('example.com[1:3]', None)
    assert parse_address('example.com[1:3]:22') == ('example.com[1:3]', 22)
    assert parse_address('foo[1:3]-bar') == ('foo[1:3]-bar', None)
    assert parse_address('foo[1:3]-bar:22') == ('foo[1:3]-bar', 22)

    assert parse_address('192.168.1.1') == ('192.168.1.1', None)

# Generated at 2022-06-23 05:20:37.700028
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1', 22) == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]', 22) == ('127.0.0.1', 22)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[bar:baz]:22') == ('foo[bar:baz]', 22)
    assert parse_address('foo[0:5]:22') == ('foo[0:5]', 22)


# Generated at 2022-06-23 05:20:45.692126
# Unit test for function parse_address
def test_parse_address():
    import unittest
    class TestParseAddress(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_ipv4(self):
            self.assertEqual((None, None), parse_address(""))
            self.assertEqual(("a", None), parse_address("a"))
            self.assertEqual(("1.2.3.4", None), parse_address("1.2.3.4"))
            self.assertEqual(("1.2.3.4", 2000), parse_address("1.2.3.4:2000"))
            self.assertEqual(("[1.2.3.4]", None), parse_address("[1.2.3.4]"))

# Generated at 2022-06-23 05:20:56.308191
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22', True) == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo]:22', True) == ('foo', 22)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', True) == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22', True) == ('192.0.2.1', 22)
    assert parse

# Generated at 2022-06-23 05:21:07.303888
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:80") == ("foo.example.com", 80)
    assert parse_address("foo.example.com:443") == ("foo.example.com", 443)
    assert parse_address("[fd1d:2ceb:a906:d868:82e:f75f:52f6:b8a3]") ==("fd1d:2ceb:a906:d868:82e:f75f:52f6:b8a3", None)

# Generated at 2022-06-23 05:21:18.376077
# Unit test for function parse_address
def test_parse_address():
    assert (None, None) == parse_address('')
    assert (None, 1) == parse_address(':1')
    assert (None, 1) == parse_address('[]:1')
    assert (None, 1) == parse_address('foo:1')
    assert (None, 1) == parse_address('foo[1:5]:1')
    assert (None, 1) == parse_address('[foo]:1')
    assert (None, 1) == parse_address('[foo[1:5]]:1')
    assert (None, 1) == parse_address('[foo[1:5]]:1', allow_ranges=True)

    assert ('foo', None) == parse_address('foo')
    assert ('foo', None) == parse_address('foo[1:5]')
    assert ('foo', 1)