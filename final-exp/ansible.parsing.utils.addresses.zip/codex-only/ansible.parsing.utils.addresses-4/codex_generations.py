

# Generated at 2022-06-23 05:11:19.379729
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('[::1]') == ('::1', None)


# Generated at 2022-06-23 05:11:30.146182
# Unit test for function parse_address
def test_parse_address():
    import pytest
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_parse_address()
#
# Copyright 2017, Ansible Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# Following code is

# Generated at 2022-06-23 05:11:38.466496
# Unit test for function parse_address
def test_parse_address():
    """
    A few test cases, to demonstrate what the function accepts
    """

# Generated at 2022-06-23 05:11:49.159494
# Unit test for function parse_address
def test_parse_address():
    # Parse errors
    for address in ['example.com', '10.20.30.40', '[fd00::a]']:
        try:
            parse_address(address, allow_ranges=False)
            raise AssertionError("Expected an AnsibleParserError for '%s' but got no exception" % address)
        except AnsibleParserError:
            pass

    # Valid inputs

# Generated at 2022-06-23 05:12:01.356755
# Unit test for function parse_address
def test_parse_address():
    # Simple hostname, no port
    print(parse_address("host.example.com"))
    # Hostname with a port
    print(parse_address("host.example.com:80"))
    # IPV4 with a port
    print(parse_address("192.0.2.42:42"))
    # IPV6 with a port
    print(parse_address("[2001:db8::42]:42"))
    # IPV4 with a port in square brackets
    print(parse_address("[192.0.2.42]:42"))
    # IPV6 with a port in square brackets
    print(parse_address("[2001:db8::42]:42"))
    # IPV6 with a port in square brackets, and a range

# Generated at 2022-06-23 05:12:10.645008
# Unit test for function parse_address
def test_parse_address():
    # Test valid IPv4 addresses with and without port numbers
    data = [
        ("192.0.2.3", (None, None)),
        ("192.0.2.3:22", ("192.0.2.3", 22)),
        ("192.0.2.3:65535", ("192.0.2.3", 65535)),
        ("192.0.2.3:0", ("192.0.2.3", 0)),
    ]
    for string, result in data:
        assert parse_address(string) == result
        assert parse_address(string) == result

    # Test invalid IPv4 addresses

# Generated at 2022-06-23 05:12:20.159361
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:28.579561
# Unit test for function parse_address
def test_parse_address():
    """ this is a basic unit test for the parse_address method """
    import sys

    # Python 2.6 doesn't have assertItemsEqual, so we work around it via set
    # coercion. It's not perfect, but it's good enough.
    if sys.version_info[1] <= 6:
        def assertItemsEqual(a, b):
            assert set(a) == set(b)
    else:
        from unittest import TestCase
        assertItemsEqual = TestCase.assertItemsEqual

    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('EXAMPLE.com:22') == ('example.com', 22)
    assert parse

# Generated at 2022-06-23 05:12:40.655395
# Unit test for function parse_address
def test_parse_address():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary source file
    source = """
from ansible.errors import AnsibleParserError
from ansible.module_utils.parsing.convert_bool import boolean
from ansible.module_utils.parsing.splitter import parse_address
from ansible.module_utils.six import string_types
"""
    source += "print parse_address.parse_address('1.2.3.4:1234')"
    source += "print parse_address.parse_address('1.2.3.4', allow_ranges=True)"

# Generated at 2022-06-23 05:12:50.244510
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:1234') == ('example.com', 1234)
    assert parse_address('example[a:c].com:1234') == ('example[a:c].com', 1234)
    assert parse_address('192.0.2.1:1234') == ('192.0.2.1', 1234)
    assert parse_address('192[1:3].0.2.1:1234') == ('192[1:3].0.2.1', 1234)
    assert parse_address('[192.0.2.1]:1234') == ('192.0.2.1', 1234)

# Generated at 2022-06-23 05:12:57.821404
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('localhost')
    assert host == 'localhost'
    assert port is None

    (host, port) = parse_address('localhost:22')
    assert host == 'localhost'
    assert port == 22

    (host, port) = parse_address('127.0.0.1')
    assert host == '127.0.0.1'
    assert port is None

    (host, port) = parse_address('127.0.0.1:22')
    assert host == '127.0.0.1'
    assert port == 22

    (host, port) = parse_address('[::1]')
    assert host == '[::1]'
    assert port is None

    (host, port) = parse_address('[::1]:22')
    assert host == '[::1]'


# Generated at 2022-06-23 05:13:08.465795
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22:33') == None
    assert parse_address('127.0.0.1:22:33', allow_ranges=True) == ('127.0.0.1', 22)

# Generated at 2022-06-23 05:13:17.964220
# Unit test for function parse_address
def test_parse_address():
    disabled_tests = {
        'test_id': None,
        'test_description': 'test disabled',
        'test_address': None,
        'expected_host': None,
        'expected_port': None,
        'expect_pass': False,
        'expect_exception': True,
        'expect_exception_class': AnsibleParserError
    }


# Generated at 2022-06-23 05:13:29.419440
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:40.136340
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost', False) == ('localhost', None)
    assert parse_address('localhost:1234', True) == ('localhost', 1234)
    assert parse_address('[1.2.3.4]', True) == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:2', True) == ('1.2.3.4', 2)
    assert parse_address('[1.2.3.4]:2', False) == ('1.2.3.4', 2)
    assert parse_address('[1.2.3.4]:[1:4]', True) == ('1.2.3.4', None)

# Generated at 2022-06-23 05:13:48.477354
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)

# Generated at 2022-06-23 05:13:58.659784
# Unit test for function parse_address
def test_parse_address():
    import pytest

    correct = ('localhost', 256)
    assert correct == parse_address('localhost:256')
    assert correct == parse_address('[localhost]:256')
    assert correct == parse_address('[127.0.0.1]:256')
    assert correct == parse_address('[::1]:256')

    correct = ('localhost', None)
    assert correct == parse_address('localhost')
    assert correct == parse_address('[localhost]')
    assert correct == parse_address('[127.0.0.1]')
    assert correct == parse_address('[::1]')

    correct = ('192.0.2.42', None)
    assert correct == parse_address('192.0.2.42')
    assert correct == parse_address('[192.0.2.42]')


# Generated at 2022-06-23 05:14:09.871183
# Unit test for function parse_address
def test_parse_address():
    ipv4_test1 = ['192.0.2.1', '192.0.2.1:22', '192.0.2.1:22-23']
    ipv4_test2 = ['[192.0.2.1]', '[192.0.2.1]:22', '[192.0.2.1]:22-23']
    ipv4_test3 = ['192.0.2.0/24', '192.0.2.0/24:22', '[192.0.2.0/24]:22-24']
    ipv4_test4 = ['192.0.2.1/6']
    ipv4_test5 = ['192.0.2.1[0:255]', '192.0.2.1[0:255]:22']

    ipv6_test1

# Generated at 2022-06-23 05:14:21.587241
# Unit test for function parse_address
def test_parse_address():
    class Unexpected:
        pass

    class Issue(object):
        # An expected result.
        # Either "pass" or "fail"
        expect = None

        # An optional error message to display when the test fails
        msg = None

        def __init__(self, expect, msg=None):
            self.expect = expect
            self.msg = msg

    # Key is the test string, value is an Issue object

# Generated at 2022-06-23 05:14:31.869164
# Unit test for function parse_address
def test_parse_address():
    # IPv4 addresses
    assert parse_address("192.168.100.100:4444") == ("192.168.100.100", 4444)
    assert parse_address("192.168.100.100") == ("192.168.100.100", None)
    assert parse_address("192.168.1[1:3]0.1[2:3]0:444") == ("192.168.1[1:3]0.1[2:3]0", 444)
    assert parse_address("192.168.1[1:3]0.1[2:3]0") == ("192.168.1[1:3]0.1[2:3]0", None)
    # IPv6 addresses
    assert parse_address("[::1]:4444") == ("::1", 4444)

# Generated at 2022-06-23 05:14:43.386961
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:23') == ('example.com', 23)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:8080') == ('127.0.0.1', 8080)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('fe80::1') == ('fe80::1', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:42') == ('::1', 42)

# Generated at 2022-06-23 05:14:51.027832
# Unit test for function parse_address
def test_parse_address():
    # valid hostname or IP address with or without port
    for address in ['example.com', 'example.com:22', '127.0.0.1', '192.0.2.1:22', '1.2.3.4:1']:
        host,port = parse_address(address)
        assert host == address.split(':')[0]
        assert int(port) == int(address.split(':')[1]) if len(address.split(':')) > 1 else port == None
    # hostname or IP address with IPv6 as host
    for address in ['[::1]', '[2001:db8::1]']:
        host, port = parse_address(address)
        assert host == address
    # invalid hostname or IP address

# Generated at 2022-06-23 05:14:59.065940
# Unit test for function parse_address
def test_parse_address():
    for (s, h, p) in [
        ('localhost', 'localhost', None),
        ('localhost:22', 'localhost', 22),
        ('[::1]', '::1', None),
        ('[::1]:22', '::1', 22),
        ('192.0.2.3', '192.0.2.3', None),
        ('192.0.2.3:22', '192.0.2.3', 22),
    ]:
        assert parse_address(s) == (h, p)

if __name__ == "__main__":
    test_parse_address()

# Generated at 2022-06-23 05:15:10.651380
# Unit test for function parse_address
def test_parse_address():
    # Matches hostname with dashes and ranges.
    assert parse_address("example-[a:z]-[0:9].com:42") == ("example-[a:z]-[0:9].com", 42)
    assert parse_address("example-[a:z]-[0:9].com") == ("example-[a:z]-[0:9].com", None)

    # Matches IPv4 address with port.
    assert parse_address("192.0.2.1:42") == ("192.0.2.1", 42)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)

    # Matches IPv6 address with port.
    assert parse_address("[2001:db8::1]:42") == ("2001:db8::1", 42)
    assert parse_

# Generated at 2022-06-23 05:15:20.257700
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:28.053622
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('test01.example.com') == ('test01.example.com', None)
    assert parse_address('[test01.example.com]') == ('test01.example.com', None)
    assert parse_address('test01.example.com:80') == ('test01.example.com', 80)
    assert parse_address('[test01.example.com]:80') == ('test01.example.com', 80)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('192.0.2.1:80:80') == ('192.0.2.1:80:80', None)

# Generated at 2022-06-23 05:15:38.776521
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:45.763057
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[fe80::23:31ff:fe7c:8339]:22") == ("fe80::23:31ff:fe7c:8339", 22)
    assert parse_address("[192.0.2.3]:22") == ("192.0.2.3", 22)
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)
    assert parse_address("foo[1:3].example.com:22") == ("foo[1:3].example.com", 22)
    assert parse_address("[192.0.2.1:192.0.2.2]:22") == ("192.0.2.1:192.0.2.2", 22)

# Generated at 2022-06-23 05:15:57.507604
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foobar') == ('foobar', None)
    assert parse_address('[foobar]') == ('foobar', None)
    assert parse_address('foobar:5000') == ('foobar', 5000)
    assert parse_address('[foobar]:5000') == ('foobar', 5000)

    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:5000') == ('192.0.2.1', 5000)

    assert parse_address('2001:db8::2:1') == ('2001:db8::2:1', None)
    assert parse_address('[2001:db8::2:1]') == ('2001:db8::2:1', None)

# Generated at 2022-06-23 05:16:05.159528
# Unit test for function parse_address
def test_parse_address():
    (h, p) = parse_address('[::1]:123')
    assert h == '::1'
    assert p == 123

    (h, p) = parse_address('foo[1:3]')
    assert h == 'foo[1:3]'
    assert p is None

    (h, p) = parse_address('foo[1:3]:123')
    assert h == 'foo[1:3]'
    assert p == 123

    (h, p) = parse_address('[::1]')
    assert h == '::1'
    assert p is None

    (h, p) = parse_address('[::1]:')
    assert h == '::1'
    assert p is None

    (h, p) = parse_address('127.0.0.1:123')

# Generated at 2022-06-23 05:16:16.046317
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('exampl[1:3]e.com') == ('exampl[1:3]e.com', None)
    assert parse_address('localhost[1:3]') == ('localhost[1:3]', None)
    assert parse_address('[::1]:22') == ('[::1]', 22)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[2001:db8::1]:22') == ('[2001:db8::1]', 22)
    assert parse_address('f[2:5]o.bar') == ('f[2:5]o.bar', None)

# Generated at 2022-06-23 05:16:27.098817
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:38.550261
# Unit test for function parse_address
def test_parse_address():
    # IPv4 host
    test_address = "a.b.com"
    result = parse_address(test_address)
    assert result[0] == "a.b.com" and result[1] is None

    # IPv4 host and port
    test_address = "a.b.com:53"
    result = parse_address(test_address)
    assert result[0] == "a.b.com" and result[1] == 53

    # IPv4 address
    test_address = "192.168.1.1"
    result = parse_address(test_address)
    assert result[0] == "192.168.1.1" and result[1] is None

    # IPv4 address and port
    test_address = "192.168.1.1:53"

# Generated at 2022-06-23 05:16:50.411037
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)

    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.[1:3]') == ('192.0.2.[1:3]', None)
    assert parse_address('192.0.2.[1:3]:22') == ('192.0.2.[1:3]', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)


# Generated at 2022-06-23 05:17:00.025148
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:05.628950
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:16.284187
# Unit test for function parse_address
def test_parse_address():
    # Empty input
    assert(parse_address('') == (None, None))

    # Port-only input
    assert(parse_address(':22') == (None, None))

    # Port as suffix
    assert(parse_address('1.2.3.4:22') == ('1.2.3.4', 22))
    assert(parse_address('1.2.3:22') == (None, None))
    assert(parse_address(':22') == (None, None))
    assert(parse_address('example.com:22') == ('example.com', 22))
    assert(parse_address('[::1]:22') == ('::1', 22))

    # Port as suffix with [x:y] ranges

# Generated at 2022-06-23 05:17:28.681497
# Unit test for function parse_address
def test_parse_address():
    import unittest
    import functools
    class TestParseAddress(unittest.TestCase):
        def test_port(self):
            expected = 'localhost', 12345

# Generated at 2022-06-23 05:17:36.475320
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:47.027152
# Unit test for function parse_address
def test_parse_address():
    def t(expected, address, allow_ranges=False):
        assert expected == parse_address(address, allow_ranges)

    t((None, None), '', True)
    t((None, None), '', False)

    t((None, None), ':', True)
    t((None, None), ':', False)

    t((None, None), '[:]', True)
    t((None, None), '[:]', False)

    t((None, None), '[', True)
    t((None, None), '[', False)

    t((None, None), 'foo]', True)
    t((None, None), 'foo]', False)

    t((None, None), 'foo:bar', True)
    t((None, None), 'foo:bar', False)


# Generated at 2022-06-23 05:17:58.678646
# Unit test for function parse_address
def test_parse_address():
    assert(parse_address('foo') == ('foo', None))
    assert(parse_address('foo:22') == ('foo', 22))
    assert(parse_address('foo:22:') == ('foo:22', None))
    assert(parse_address('foo[1:2]:22') == ('foo[1:2]', 22))
    assert(parse_address('foo[1-5]:22') == ('foo[1-5]', 22))
    assert(parse_address('foo[1:2]-bar:22') == ('foo[1:2]-bar', 22))
    assert(parse_address('1.2.3.4') == ('1.2.3.4', None))
    assert(parse_address('1.2.3.4:22') == ('1.2.3.4', 22))

# Generated at 2022-06-23 05:18:07.990060
# Unit test for function parse_address
def test_parse_address():
    g = globals()
    def assert_parsed(inp, out):
        g['got'] = parse_address(inp)
        assert g['got'] == out, g['err']

    # plain hostnames, bare or with a port number
    assert_parsed('localhost', ('localhost', None))
    assert_parsed('localhost:1234', ('localhost', 1234))
    assert_parsed('1.2.3.4', ('1.2.3.4', None))
    assert_parsed('1.2.3.4:1234', ('1.2.3.4', 1234))
    assert_parsed('::1', ('::1', None))
    assert_parsed('[::1]:1234', ('::1', 1234))
    assert_parsed

# Generated at 2022-06-23 05:18:19.048684
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.pycompat import assertDictEqual

    assertDictEqual(parse_address('192.0.2.1/32'), ('192.0.2.1', None))
    assertDictEqual(parse_address('2001:db8::1/32'), ('2001:db8::1', None))
    assertDictEqual(parse_address('www.example.com'), ('www.example.com', None))

    assertDictEqual(parse_address('192.0.2.1:80'), ('192.0.2.1', 80))
    assertDictEqual(parse_address('example.com:80'), ('example.com', 80))

# Generated at 2022-06-23 05:18:29.321308
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:40.437492
# Unit test for function parse_address
def test_parse_address():
    # Simple valid addresses
    for a in ['192.0.2.1', '[2001:db8::1]', 'foo.example.com', '[2001:db8::1]:22']:
        h, p = parse_address(a)
        assert h == a.split(':')[0]
        if '[' in h:
            assert p is None
        else:
            assert p == int(a.split(':')[-1])

    # Port appears before the address
    assert parse_address('1:2:3:4:5:6:7:8:9') == (None, None)
    assert parse_address('1:2:3:4:5:6:7:8:9:65535') == (None, None)

    # Ports may be missing or out of range

# Generated at 2022-06-23 05:18:51.230088
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:03.487042
# Unit test for function parse_address
def test_parse_address():
    class TestCase:
        def __init__(self, input, expected_host, expected_port, allow_ranges):
            self.input = input
            self.expected_host = expected_host
            self.expected_port = expected_port
            self.allow_ranges = allow_ranges


# Generated at 2022-06-23 05:19:13.750947
# Unit test for function parse_address
def test_parse_address():
    """
    This is a simple unit test for function parse_address.
    It is not a complete test and should not be used as such.
    """
    host, port = parse_address("1.2.3.4")
    assert (host == "1.2.3.4")
    assert (port == None)
    host, port = parse_address("1.2.3.4:5678")
    assert (host == "1.2.3.4")
    assert (port == 5678)
    host, port = parse_address("1.2.3.4[33:44]")
    assert (host == "1.2.3.4[33:44]")
    assert (port == None)
    host, port = parse_address("1.2.3.4[33:44]:5678")
   

# Generated at 2022-06-23 05:19:23.468326
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:33.915034
# Unit test for function parse_address
def test_parse_address():

    # Valid IPv4 addresses, with and without port specification.
    assert parse_address("1.2.3.4") == ("1.2.3.4", None)
    assert parse_address("1.2.3.4:5") == ("1.2.3.4", 5)
    assert parse_address("1.2.3.4:5") == ("1.2.3.4", 5)
    assert parse_address("1.2.3.4:65535") == ("1.2.3.4", 65535)
    assert parse_address("1.2.3.4:0") == ("1.2.3.4", 0)

    # Valid IPv4 addresses with range specifications, with and without ports.

# Generated at 2022-06-23 05:19:43.954750
# Unit test for function parse_address
def test_parse_address():

    def check(addr, allow_ranges=False):
        host, port = parse_address(addr, allow_ranges)
        print("parse_address(%s, allow_ranges=%s) -> (%s, %s)" % (addr, allow_ranges, host, port))
        return host, port

    # Test with various hostnames and IPv4 addresses.
    check('[1.2.3.4]:22')
    check('1.2.3.4:22')
    check('1.2.3.4', True)
    check('[a.b.c.d]:22')
    check('[a.b.c.d]', True)
    check('[1.2.3.4.5]:22')
    check('[a.b.c.d.e]', True)
   

# Generated at 2022-06-23 05:19:56.296699
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[dead:beef::]') == ('dead:beef::', None)
    assert parse_address('[dead:beef::]:123') == ('dead:beef::', 123)
    assert parse_address('dead:beef::') == ('dead:beef::', None)
    assert parse_address('dead:beef:::123') == ('dead:beef:::123', None)
    assert parse_address('dead:beef::1') == ('dead:beef::1', None)
    assert parse_address('[dead:beef::1]:123') == ('dead:beef::1', 123)
    assert parse_address('dead:beef:1::') == ('dead:beef:1::', None)

# Generated at 2022-06-23 05:20:06.716770
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:18.460248
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:30.119585
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com[1:3]:22') == ('foo.example.com[1:3]', 22)
    assert parse_address('10.1.2.3') == ('10.1.2.3', None)
    assert parse_address('10.1.2.3:22') == ('10.1.2.3', 22)
    assert parse_address('10.1.2.3[1:3]') == ('10.1.2.3[1:3]', None)

# Generated at 2022-06-23 05:20:41.516695
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:50022') == ('::1', 50022)
    assert parse_address('[1:2:3:4:5:6:7:8]:50022') == ('1:2:3:4:5:6:7:8', 50022)
    assert parse_address('[1::8]:50022') == ('1::8', 50022)
    assert parse_address('1:2:3:4:5:6:7:8', allow_ranges=True) == ('1:2:3:4:5:6:7:8', None)
    assert parse_address('1:2:3:4:5:6:7:8:9') == (None, None)
    assert parse_address('::ffff:192.0.2.3', allow_ranges=True)

# Generated at 2022-06-23 05:20:51.879770
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('bar') == ('bar', None)
    for a in ['foo:123', 'foo.example.com:123', '[foo.example.com]:123']:
        assert parse_address(a) == ('foo.example.com', 123)
    for a in ['127.0.0.1:123', '[::1]:123', '[::ffff:192.0.2.1]:123']:
        assert parse_address(a) == (a, 123)
    for a in ['127.0.0.1', '[::1]', '[::ffff:192.0.2.1]']:
        assert parse_address(a) == (a, None)

# Generated at 2022-06-23 05:21:01.318667
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:10.976404
# Unit test for function parse_address
def test_parse_address():
    def test_ok(string, host, port=None):
        (h, p) = parse_address(string)
        assert h == host and p == port

    def test_fail(string):
        try:
            parse_address(string)
            assert False
        except Exception:
            pass

    test_ok('foo', 'foo')
    test_ok('foo.example.com', 'foo.example.com')
    test_ok('example.com', 'example.com')
    test_ok('192.0.2.1', '192.0.2.1')
    test_ok('192.0.2.1:22', '192.0.2.1', 22)
    test_ok('192.0.2.1[2:10]', '192.0.2.1[2:10]')

# Generated at 2022-06-23 05:21:20.808852
# Unit test for function parse_address
def test_parse_address():
    import warnings
    warnings.filterwarnings("ignore",category=DeprecationWarning)

    PORT_NUM = 42
    PORT_SPEC = u':{0}'.format(PORT_NUM)
    PORT_SPEC_BRACKETED = u'[{0}]'.format(PORT_SPEC)

    # Test an IPv4 address.
    x = parse_address(u'192.0.2.3{0}'.format(PORT_SPEC))
    assert x[0] == '192.0.2.3'
    assert x[1] == PORT_NUM
    x = parse_address(u'192.0.2.3')
    assert x[0] == '192.0.2.3'
    assert x[1] == None

    # Test an IPv4 address with ranges.
    x = parse_