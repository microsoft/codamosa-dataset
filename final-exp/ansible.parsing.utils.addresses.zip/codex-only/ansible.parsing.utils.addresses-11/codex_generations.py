

# Generated at 2022-06-23 05:11:23.588160
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address(':22', allow_ranges=True) == ('[:22]', None)

    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost[1:2]') == ('localhost', None)
    assert parse_address('localhost[1:2]:22') == ('localhost[1:2]', 22)

    assert parse_address('example') == ('example', None)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
   

# Generated at 2022-06-23 05:11:35.536145
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:46.790802
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:55.783513
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:06.173508
# Unit test for function parse_address
def test_parse_address():
    # valid examples
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('example.com[0:1]:1234') == ('example.com[0:1]', 1234)
    assert parse_address('example.com[a:b]:1234') == ('example.com[a:b]', 1234)
    assert parse_address('example.com[a-b]:1234') == ('example.com[a-b]', 1234)
    assert parse_address('example.com[a-]:1234') == ('example.com[a-]', 1234)

# Generated at 2022-06-23 05:12:16.128968
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:25.569662
# Unit test for function parse_address
def test_parse_address():
    # These are valid IPv4 addresses and hostnames.
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:80') == ('1.2.3.4', 80)
    assert parse_address('foo.bar') == ('foo.bar', None)
    assert parse_address('foo.bar:443') == ('foo.bar', 443)

    # If the address is enclosed in square brackets, it is treated as an
    # IPv6 address or hostname, and the port is mandatory.
    assert parse_address('[fe80:1:2:3:4:5]:443') == ('fe80:1:2:3:4:5', 443)

# Generated at 2022-06-23 05:12:33.233748
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:45.167244
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:55.285582
# Unit test for function parse_address
def test_parse_address():
    import pytest

# Generated at 2022-06-23 05:13:06.723431
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:16.358874
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:24.246834
# Unit test for function parse_address
def test_parse_address():
    def check(address, result, port=None):
        actual = parse_address(address, allow_ranges=True)
        if actual != result:
            raise Exception("parse_address('%s', allow_ranges=True) -> %s != %s"
                    % (address, actual, result))
        if port is not None:
            if actual[1] != port:
                raise Exception("parse_address('%s', allow_ranges=True) -> port %d != %d"
                        % (address, actual[1], port))

    # IPv4 addresses
    check('192.168.1.1', ('192.168.1.1', None))
    check('192.168.1.1:2222', ('192.168.1.1', 2222))

# Generated at 2022-06-23 05:13:35.011536
# Unit test for function parse_address
def test_parse_address():
    """
    AnsibleModuleTestCase
    """


# Generated at 2022-06-23 05:13:44.064747
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:52.903518
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1][2:5]') == ('2001:db8::1[2:5]', None)
    assert parse_address('[2001:db8::[1:2]]:22') == ('2001:db8::[1:2]', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)

# Generated at 2022-06-23 05:14:00.829968
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class TestAddrParse(unittest.TestCase):
        def test_basics(self):
            self.assertTupleEqual(parse_address('foo'), ('foo', None))
            self.assertTupleEqual(parse_address('foo:1234'), ('foo', 1234))
            self.assertTupleEqual(parse_address('1.2.3.4'), ('1.2.3.4', None))
            self.assertTupleEqual(parse_address('1.2.3.4:1234'), ('1.2.3.4', 1234))

# Generated at 2022-06-23 05:14:11.944946
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.[1:5]:22') == ('127.0.0.[1:5]', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.[1:5]]:22') == ('127.0.0.[1:5]', 22)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('[2001:db8::[1:5]]:22') == ('2001:db8::[1:5]', 22)

# Generated at 2022-06-23 05:14:21.975107
# Unit test for function parse_address
def test_parse_address():

    import ansible.inventory.vars
    import ansible.inventory.host
    import ansible.inventory.group


# Generated at 2022-06-23 05:14:32.536352
# Unit test for function parse_address
def test_parse_address():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # The hosts_list we will use to create the inventory
    hosts_list = [ "alpha", "beta", "gamma", "delta:2222", "epsilon[1:3]", "zeta[x:z]-omega", "ipsilon:25", "[2001:db8::1]:22", "[2001:db8::2]", "[192.0.2.1]:22" ]
    hosts_list.reverse()

    # Initialize a new inventory
    i = Inventory(host_list=hosts_list)

    # Check that we have the right number of hosts
    assert len(i.get_hosts()) == 10, "Did not create the expected 10 hosts"
    assert len(i.get_groups_dict()) == 2

# Generated at 2022-06-23 05:14:43.641551
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address("example.com:99")
    assert(host == "example.com" and port == 99)

    # This was caught by a bug and needs to be tested to make sure it doesn't
    # happen again.
    (host, port) = parse_address("example.com:bogusport")
    assert(host == "example.com" and port is None)

    (host, port) = parse_address("0.0.0.0:0")
    assert(host == "0.0.0.0" and port == 0)

    (host, port) = parse_address("192.0.2.1:65535")
    assert(host == "192.0.2.1" and port == 65535)


# Generated at 2022-06-23 05:14:51.288997
# Unit test for function parse_address
def test_parse_address():
    def parse_ok(host, port, s):
        h, p = parse_address(s)
        assert h == host
        assert p == port
        h, p = parse_address(s, allow_ranges=True)
        assert h == host
        assert p == port
        h, p = parse_address(s, allow_ranges=False)
        assert h == host
        assert p == port

    def parse_fail(s):
        try:
            h, p = parse_address(s)
            assert False
        except:
            pass
        try:
            h, p = parse_address(s, allow_ranges=True)
            assert False
        except:
            pass

# Generated at 2022-06-23 05:15:01.151371
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:10.754627
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:23') == ('localhost', 23)
    assert parse_address('localhost:65535') == ('localhost', 65535)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:23') == ('127.0.0.1', 23)
    assert parse_address('127.0.0.1:65535') == ('127.0.0.1', 65535)
    assert parse_address('127.0.0.1[0:2]') == ('127.0.0.1[0:2]', None)

# Generated at 2022-06-23 05:15:22.367045
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:33.737045
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:37.120422
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:47.752391
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('foo')
    assert(host == 'foo' and port is None)

    host, port = parse_address('::1')
    assert(host == '::1' and port is None)

    host, port = parse_address('127.0.0.1')
    assert(host == '127.0.0.1' and port is None)

    host, port = parse_address('127.0.0.1:444')
    assert(host == '127.0.0.1' and port == 444)

    host, port = parse_address('foo.example.com')
    assert(host == 'foo.example.com' and port is None)

    host, port = parse_address('foo.example.com:444')

# Generated at 2022-06-23 05:15:59.441932
# Unit test for function parse_address
def test_parse_address():
    # This function is used in unit tests only
    # pylint: disable=unused-argument
    def assert_parses(address, host, port=None):
        """
        Checks that parse_address(address) == (host, port)

        Note that host may be None if parse_address() fails.
        """
        (p_host, p_port) = parse_address(address)
        assert p_host == host
        assert p_port == port

    # Without a port

# Generated at 2022-06-23 05:16:08.665021
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("test.example.com:22") == ("test.example.com", 22)
    assert parse_address("test.example.com") == ("test.example.com", None)
    assert parse_address("test.example.com:") == ("test.example.com", None)
    assert parse_address("test.example.com:[2001:db8::1]") == ("test.example.com:[2001:db8::1]", None)
    assert parse_address("[test.example.com]:22") == ("test.example.com", 22)
    assert parse_address("[test.example.com]") == ("test.example.com", None)
    assert parse_address("192.0.2.42:22") == ("192.0.2.42", 22)

# Generated at 2022-06-23 05:16:17.836330
# Unit test for function parse_address
def test_parse_address():

    # Make sure the function raises an exception for invalid inputs.
    def check_invalid(address):
        try:
            parse_address(address)
        except AnsibleParserError:
            pass
        else:
            raise AssertionError('expected exception for {!r}'.format(address))

    yield check_invalid, '192.0.2.1 : 80'
    yield check_invalid, '192.0.2.1:65536'
    yield check_invalid, '192.0.2.1:666'
    yield check_invalid, '192.0.2.1:0'
    yield check_invalid, '[192.0.2.1]'
    yield check_invalid, '[192.0.2.1'
    yield check_invalid, '192.0.2.1]'


# Generated at 2022-06-23 05:16:28.586330
# Unit test for function parse_address
def test_parse_address():
    test_result = parse_address('[2001:db8::1]:22')
    assert test_result == ('2001:db8::1', 22), test_result

    test_result = parse_address('[2001:db8::1]')
    assert test_result == ('2001:db8::1', None), test_result

    test_result = parse_address('[192.0.2.1]')
    assert test_result == ('192.0.2.1', None), test_result

    test_result = parse_address('192.0.2.1')
    assert test_result == ('192.0.2.1', None), test_result

    test_result = parse_address('[192.0.2.1]:22')
    assert test_result == ('192.0.2.1', 22), test_

# Generated at 2022-06-23 05:16:37.337907
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=True) == ('127.0.0.1', 22)
    assert parse_address('127.1.1.[1:4]', allow_ranges=True) == ('127.1.1.[1:4]', None)

# Generated at 2022-06-23 05:16:49.004844
# Unit test for function parse_address
def test_parse_address():
    """
    Test cases for function parse_address
    """
    # Simple hostname
    assert parse_address('localhost') == ('localhost', None)
    # Simple domain name
    assert parse_address('example.com') == ('example.com', None)
    # Hostname with port specification
    assert parse_address('localhost:1234') == ('localhost', 1234)
    # Domain name with port specification
    assert parse_address('example.com:1234') == ('example.com', 1234)
    # IPv4 address
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    # IPv6 address
    assert parse_address('::1') == ('::1', None)
    # IPv4 address with port specification

# Generated at 2022-06-23 05:16:59.048787
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:08.686454
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:18.466433
# Unit test for function parse_address
def test_parse_address():

    f = parse_address

    assert f('localhost') == ('localhost', None)
    assert f('localhost:23') == ('localhost', 23)

    # Bracketed IPv4 and port
    assert f('[::ffff:192.0.2.123]:1234') == ('::ffff:192.0.2.123', 1234)
    assert f('[192.0.2.123]:1234') == ('192.0.2.123', 1234)

    # Bracketed hostname and port
    assert f('[foo]:1234') == ('foo', 1234)
    assert f('[foo][bar]:1234') == ('foo[bar]', 1234)

    # Bracketed IPv6
    assert f('[::1]') == ('::1', None)

# Generated at 2022-06-23 05:17:29.596654
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[::1]:22", True) == (["::1"], 22)
    assert parse_address("[::1]:22", False) == (["::1"], 22)
    assert parse_address("localhost:22", True) == ("localhost", 22)
    assert parse_address("localhost:22", False) == ("localhost", 22)
    assert parse_address("[127.0.0.1]", True) == (["127.0.0.1"], None)
    assert parse_address("[127.0.0.1]", False) == (["127.0.0.1"], None)
    assert parse_address("[127.0.0.1]:22", True) == (["127.0.0.1"], 22)

# Generated at 2022-06-23 05:17:42.046285
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo:42') == ('foo', 42)
    assert parse_address('foo[1-2].example.com:42') == ('foo[1-2].example.com', 42)
    assert parse_address('[[::1]]:42') == ('[::1]', 42)
    assert parse_address('[[::1]].example.com:42') == ('[::1].example.com', 42)
    assert parse_address('192.0.2.1:42') == ('192.0.2.1', 42)
    assert parse_address('192.0.2.1[1:2]:42') == ('192.0.2.1[1:2]', 42)

# Generated at 2022-06-23 05:17:49.017172
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('[1.2.3.4]:22') == ('1.2.3.4', 22)
    assert parse_address('hostname') == ('hostname', None)
    assert parse_address('hostname:23') == ('hostname', 23)
    assert parse_address('[hostname]:23') == ('hostname', 23)

# Generated at 2022-06-23 05:18:01.191251
# Unit test for function parse_address
def test_parse_address():
    assert(parse_address(':1234') == (None, 1234))
    assert(parse_address('[::1]') == ('::1', None))
    assert(parse_address('[::1]:1234') == ('::1', 1234))
    assert(parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None))
    assert(parse_address('[::ffff:192.0.2.3]:1234') == ('::ffff:192.0.2.3', 1234))
    assert(parse_address('[::192.0.2.3]') == ('::192.0.2.3', None))

# Generated at 2022-06-23 05:18:12.911300
# Unit test for function parse_address
def test_parse_address():
    def test(address, host, port, allow_ranges=False):
        h, p = parse_address(address, allow_ranges)
        assert h == host, ("%s: expected host %s, got %s" % (address, host, h))
        assert p == port, ("%s: expected port %s, got %s" % (address, port, p))

    # Test the many ways in which the host can be specified with port
    test('[::1]:22', '::1', 22, True)
    test('[::1]', '::1', None, True)
    test('[::fff:1.2.3.4]:22', '::fff:1.2.3.4', 22, True)

# Generated at 2022-06-23 05:18:21.005422
# Unit test for function parse_address
def test_parse_address():

    assert parse_address("192.0.2.2") == ("192.0.2.2", None)
    assert parse_address("2001:db8::1") == ("2001:db8::1", None)
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("192.0.2.2:9876") == ("192.0.2.2", 9876)
    assert parse_address("2001:db8::888:9999") == ("2001:db8::888:9999", None)
    assert parse_address("::ffff:192.0.2.2") == ("::ffff:192.0.2.2", None)

# Generated at 2022-06-23 05:18:31.491209
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:42.743894
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[2001:db8:a0b:12f0::1]') == ('2001:db8:a0b:12f0::1', None)
    assert parse_address('[2001:db8:a0b:12f0::1]:22') == ('2001:db8:a0b:12f0::1', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)

# Generated at 2022-06-23 05:18:50.638905
# Unit test for function parse_address
def test_parse_address():
    """
    Tests the parsing of address (host and port)
    """


# Generated at 2022-06-23 05:18:57.821282
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:80") == ("192.0.2.1", 80)

    assert parse_address("[2001:db8::1]") == ("2001:db8::1", None)
    assert parse_address("[2001:db8::1]:80") == ("2001:db8::1", 80)

    assert parse_address("hostname") == ("hostname", None)
    assert parse_address("hostname:port") == ("hostname", 100)
    assert parse_address("hostname[1:3].example.com") == ("hostname[1:3].example.com", None)
    assert parse_address("hostname[1:3].example.com:80")

# Generated at 2022-06-23 05:19:08.140919
# Unit test for function parse_address
def test_parse_address():
    import random
    import string

    def gen_domain(length=8):
        random_chars = [random.choice(string.ascii_lowercase) for _ in range(length)]
        return "".join(random_chars) + ".com"

    def gen_host(length=8):
        random_chars = [random.choice(string.ascii_lowercase) for _ in range(length)]
        return "".join(random_chars)

    def gen_port():
        return random.randint(1001, 60000)

    def gen_ipv4():
        return ".".join([str(random.randint(1, 255)) for _ in range(4)])


# Generated at 2022-06-23 05:19:19.304626
# Unit test for function parse_address
def test_parse_address():

    import pytest

    def assert_parse(address, host, port=None):
        assert parse_address(address) == (host, port)

    def assert_parse_failure(address):
        with pytest.raises(AnsibleError) as exc:
            parse_address(address)
        assert "Not a valid network hostname" in "%s" % exc.value

    assert_parse("[::1]", "::1")
    assert_parse("[::1]", "::1", port=5)
    assert_parse("[2001:db8::a]", "2001:db8::a")
    assert_parse("[2001:db8::a]", "2001:db8::a", port=5)

# Generated at 2022-06-23 05:19:26.817891
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::]') == ('::', None)
    assert parse_address(':::') == (None, None)
    assert parse_address('::') == (None, None)
    assert parse_address('[::]:80') == ('::', 80)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:80') == ('1.2.3.4', 80)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:80') == ('foo.example.com', 80)
    assert parse_address('foo.example.com:8080') == ('foo.example.com', 8080)

# Generated at 2022-06-23 05:19:36.265958
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('192.0.2.3:1234') == ('192.0.2.3', 1234)
    assert parse_address('foo[1:3]:1234') == ('foo[1:3]', 1234)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)

    # Precedence for multiple patterns
    assert parse_address("[192.0.2.3]:1234") == ('192.0.2.3', 1234)
    assert parse_address("[::ffff:192.0.2.3]:1234") == ('::ffff:192.0.2.3', 1234)

# Generated at 2022-06-23 05:19:44.795129
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('www.example.com:80') == ('www.example.com', 80)
    assert parse_address('www.example.com:8080') == ('www.example.com', 8080)
    assert parse_address('www.example.com') == ('www.example.com', None)
    assert parse_address('192.168.0.1:8000') == ('192.168.0.1', 8000)
    assert parse_address('192.168.0.1') == ('192.168.0.1', None)
    assert parse_address('[2001:db8::1]:80') == ('[2001:db8::1]', 80)
    assert parse_address('[2001:db8::1]') == ('[2001:db8::1]', None)

# Generated at 2022-06-23 05:19:56.664187
# Unit test for function parse_address
def test_parse_address():
    "Parse addresses with optional ports."

# Generated at 2022-06-23 05:20:06.581593
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('[example.com%eth0]:80') == ('example.com%eth0', 80)
    assert parse_address('192.0.2.51') == ('192.0.2.51', None)
    assert parse_address('192.0.2.51:80') == ('192.0.2.51', 80)
    assert parse_address('[192.0.2.51]:80') == ('192.0.2.51', 80)

# Generated at 2022-06-23 05:20:18.393046
# Unit test for function parse_address
def test_parse_address():
    def assert_address(address, host=None, port=None):
        (got_host, got_port) = parse_address(address)
        assert host == got_host
        assert port == got_port

    assert_address('foo.example.com', 'foo.example.com')
    assert_address('1.2.3.4', '1.2.3.4')
    assert_address('1.2.3.4:5', '1.2.3.4', 5)
    assert_address('[foo.example.com]', 'foo.example.com')
    assert_address('[2001:0db8:85a3:0000:0000:8a2e:0370:7334]', '2001:0db8:85a3:0000:0000:8a2e:0370:7334')

# Generated at 2022-06-23 05:20:30.068975
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils import test as utils

    # This test data is a list of tuples: (input, expected output, 'success' or 'error', allow_ranges)


# Generated at 2022-06-23 05:20:38.373278
# Unit test for function parse_address
def test_parse_address():
    import pytest
    import sys

    # Python 2 raises a DeprecationWarning when running this test. I
    # can't find a way to silence it without also hiding real
    # DeprecationWarnings, so we temporarily squelch them.
    if sys.version_info[0] == 2:
        import warnings
        warnings.filterwarnings('ignore', category=DeprecationWarning)

    # Hostname with numeric ranges, port specified
    (host,port) = parse_address("foo[3:6]:10")
    assert host == "foo[3:6]"
    assert port == 10

    # Hostname with numeric ranges, no port specified
    (host,port) = parse_address("foo[3:6]")
    assert host == "foo[3:6]"
    assert port == None

    # IPv4 address with numeric

# Generated at 2022-06-23 05:20:50.015803
# Unit test for function parse_address
def test_parse_address():
    # ensure the patterns match what we expect
    assert patterns['bracketed_hostport'].match("[10.1.1.1]:22")
    assert patterns['bracketed_hostport'].match("[10.1.1.1]:65535")
    assert not patterns['bracketed_hostport'].match("[10.1.1.1]")
    assert not patterns['bracketed_hostport'].match("10.1.1.1]")
    assert not patterns['bracketed_hostport'].match("[10.1.1.1")
    assert not patterns['bracketed_hostport'].match("10.1.1.1:22")

    assert patterns['hostport'].match("10.1.1.1:22")

# Generated at 2022-06-23 05:20:59.967670
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 address
    test_inputs = [
        '127.0.0.1',
        '127.0.0.1:2022',
        '192.168.2.1',
        '192.168.2.1:22',
    ]

    for test_input in test_inputs:
        (host, port) = parse_address(test_input)
        assert host is not None
        assert port is None or port > 0

    # Test IPv4 range
    test_inputs = [
        '192.0.2.[1:3]',
        '192.0.2.[1:3]:22',
    ]

    for test_input in test_inputs:
        (host, port) = parse_address(test_input, True)
        assert host is not None
        assert port

# Generated at 2022-06-23 05:21:06.925006
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("192.0.2.5") == ("192.0.2.5", None)
    assert parse_address("192.0.2.5:43") == ("192.0.2.5", 43)
    assert parse_address("foo.example.com:43") == ("foo.example.com", 43)
    assert parse_address("[::ffff:192.0.2.5]") == ("::ffff:192.0.2.5", None)
    assert parse_address("[::ffff:192.0.2.5]:43") == ("::ffff:192.0.2.5", 43)
    assert parse_address("[foo.example.com]") == ("foo.example.com", None)
   

# Generated at 2022-06-23 05:21:17.943252
# Unit test for function parse_address