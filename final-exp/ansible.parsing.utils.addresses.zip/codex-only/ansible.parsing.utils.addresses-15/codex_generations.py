

# Generated at 2022-06-23 05:11:18.008656
# Unit test for function parse_address
def test_parse_address():
    import subprocess
    try:
        output = subprocess.check_output("python -m ansible.utils.network_modules", shell=True)
    except:
        print("FAILED: %s function" % __name__)
        return

    if b'OK' not in output:
        print("FAILED: %s function" % __name__)
        print(output)

# Generated at 2022-06-23 05:11:28.868684
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:37.851915
# Unit test for function parse_address
def test_parse_address():
    address = 'foo:80'
    host, port = parse_address(address)
    assert host == 'foo'
    assert port == 80

    address = '[foo]:80'
    host, port = parse_address(address)
    assert host == 'foo'
    assert port == 80

    address = '[192.168.1.1]:80'
    host, port = parse_address(address)
    assert host == '192.168.1.1'
    assert port == 80

    address = '192.168.1.1:80'
    host, port = parse_address(address)
    assert host == '192.168.1.1'
    assert port == 80

    address = '1:2:3:4:5:6:7:8'
    host, port = parse_address(address)

# Generated at 2022-06-23 05:11:45.078996
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:54.539311
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:05.277782
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost:5555') == ('localhost', 5555)
    assert parse_address('localhost') == ('localhost', 22)
    assert parse_address('123.123.123.123:5555') == ('123.123.123.123', 5555)
    assert parse_address('123.123.123.123') == ('123.123.123.123', 22)
    assert parse_address('[::1]:5555') == ('::1', 5555)
    assert parse_address('::1') == ('::1', 22)
    assert parse_address('[123:123:123:123:123:123:123:123]:5555') == \
        ('123:123:123:123:123:123:123:123', 5555)

# Generated at 2022-06-23 05:12:15.302502
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils import pycompat
    from ansible.errors import AnsibleError
    from ansible.compat.tests import unittest
    import sys
    import random

    if pycompat.PY2:
        strtype = basestring
    else:
        strtype = str

    class TestParseAddress(unittest.TestCase):

        def test_hostname(self):
            reference_hostname = u'localhost'
            self.assertEqual(parse_address(reference_hostname), (reference_hostname, None))
            reference_hostname = u'localhost.'
            self.assertEqual(parse_address(reference_hostname), (reference_hostname, None))
            reference_hostname = u'127.0.0.1'

# Generated at 2022-06-23 05:12:26.090507
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:34.686807
# Unit test for function parse_address
def test_parse_address():
    # Tests with port specifications
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]', allow_ranges=True) == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)

    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:[22]', allow_ranges=True) == (u'::1', 22)

# Generated at 2022-06-23 05:12:46.206600
# Unit test for function parse_address
def test_parse_address():
    """
    (Basic) unit test for function parse_address
    """

# Generated at 2022-06-23 05:12:56.059257
# Unit test for function parse_address
def test_parse_address():
    '''Unit test for function parse_address'''

    def test_netloc(netloc, host, port):
        (h, p) = parse_address(netloc)
        assert h == host
        assert p == port

    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('22:192.0.2.1', allow_ranges=True) == ('22:192.0.2.1', None)

# Generated at 2022-06-23 05:13:07.123775
# Unit test for function parse_address
def test_parse_address():
    # Test parsing IPv4 address without a port
    assert parse_address('192.168.1.2') == ('192.168.1.2', None)

    # Test parsing IPv4 address with a port
    assert parse_address('192.168.1.2:23') == ('192.168.1.2', 23)

    # Test parsing IPv6 address in brackets, with a port
    assert parse_address('[::1]:23') == ('::1', 23)

    # Test parsing IPv6 address in brackets, without a port
    assert parse_address('[::1]') == ('::1', None)

    # Test parsing IPv6 address, with a port - should raise an error

# Generated at 2022-06-23 05:13:16.830317
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:26.562414
# Unit test for function parse_address
def test_parse_address():
    """
    This function is used to make sure that parse_address works.
    Returns a tuple of (successes, failures)
    """

# Generated at 2022-06-23 05:13:36.005688
# Unit test for function parse_address
def test_parse_address():

    # Test basic host:port parsing
    assert parse_address('foo.example.com:1234') == ('foo.example.com', 1234)
    assert parse_address('[2001:db8::1]:1234') == ('[2001:db8::1]', 1234)
    assert parse_address('192.0.2.1:1234') == ('192.0.2.1', 1234)

    # Test that non-numeric ports are rejected
    try:
        parse_address('192.0.2.1:abc')
        assert False
    except:
        pass

    # Test that malformed IPv4 addresses are rejected
    try:
        parse_address('192.0.2.256')
        assert False
    except:
        pass

    # Test that malformed IPv6 addresses are rejected

# Generated at 2022-06-23 05:13:46.856651
# Unit test for function parse_address
def test_parse_address():

    # host without a port
    (host, port) = parse_address('localhost')
    assert host == 'localhost'
    assert port is None

    # IPv4 address without a port
    (host, port) = parse_address('192.0.2.1')
    assert host == '192.0.2.1'
    assert port is None

    # IPv6 address without a port
    (host, port) = parse_address('[::ffff:192.0.2.1]')
    assert host == '[::ffff:192.0.2.1]'
    assert port is None

    # host with a port
    (host, port) = parse_address('localhost:1234')
    assert host == 'localhost'
    assert port == 1234

    # IPv4 address with a port
    (host, port) = parse_address

# Generated at 2022-06-23 05:13:58.406792
# Unit test for function parse_address
def test_parse_address():
    """
    This is a minimal test for parse_address. It doesn't check that
    the port numbers are actually valid, but it does check that
    non-numeric ports cause a parse error.
    """
    pass

    # Single-digit port numbers
    for i in range(0, 10):
        assert parse_address("foo.example.com:%d" % i) == ("foo.example.com", i)
        assert parse_address("192.0.2.%d:%d" % (i, i)) == ("192.0.2.%d" % i, i)
        assert parse_address("[192.0.2.%d]:%d" % (i, i)) == ("192.0.2.%d" % i, i)

# Generated at 2022-06-23 05:14:09.584835
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:21.403925
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost[1:3]:22') == ('localhost[1:3]', 22)
    assert parse_address('localhost:22[1:3]') == ('localhost', 22)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4[1:3]') == ('1.2.3.4[1:3]', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)

# Generated at 2022-06-23 05:14:29.845587
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:80') == ('::1', 80)
    assert parse_address('10.0.0.1[2:4]') == ('10.0.0.1[2:4]', None)
    assert parse_address('10.0.0.1[2:4]', allow_ranges=True) == ('10.0.0.1[2:4]', None)
    assert parse_address('10.0.0.1[2:4]:80') == ('10.0.0.1[2:4]', 80)
   

# Generated at 2022-06-23 05:14:38.960756
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("") == (None, None)
    assert parse_address(":") == (None, None)
    assert parse_address("hostname") == ('hostname', None)
    assert parse_address("hostname:123") == ('hostname', 123)
    assert parse_address("10.0.0.1") == ('10.0.0.1', None)
    assert parse_address("10.0.0.1:123") == ('10.0.0.1', 123)
    assert parse_address("10.0.0.1[1:10]") == ('10.0.0.1[1:10]', None)
    assert parse_address("10.0.0.1[1:10]:123") == ('10.0.0.1[1:10]', 123)
    assert parse

# Generated at 2022-06-23 05:14:51.619609
# Unit test for function parse_address
def test_parse_address():
    # basic tests with hostnames first
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:5986') == ('localhost', 5986)
    assert parse_address('localhost:22') == ('localhost', 22)

    # bracketed
    assert parse_address('[localhost]:5986') == ('localhost', 5986)

    # IP addresses with port
    assert parse_address('127.0.0.1:5986') == ('127.0.0.1', 5986)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)

    # IP addresses without port
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)

# Generated at 2022-06-23 05:15:01.527933
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:23') == ('localhost', 23)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:23') == ('127.0.0.1', 23)
    assert parse_address('127.0.0.1[2:4]') == ('127.0.0.1[2:4]', None)
    assert parse_address('127.0.0.1[2:4]:23') == ('127.0.0.1[2:4]', 23)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('[::1]:23') == ('::1', 23)

# Generated at 2022-06-23 05:15:10.884352
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22:33') == ('foo:22:33', None)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_

# Generated at 2022-06-23 05:15:22.396064
# Unit test for function parse_address
def test_parse_address():
    # Test all valid forms
    address = ('[::1]:22', ('::1', 22))
    assert(parse_address(address[0]) == address[1])
    address = ('[failed.example.com]:22', ('failed.example.com', 22))
    assert(parse_address(address[0]) == address[1])
    address = ('[192.168.1.1]:22', ('192.168.1.1', 22))
    assert(parse_address(address[0]) == address[1])
    address = ('[192.168.1.0-1]:22', ('192.168.1.0-1', 22))
    assert(parse_address(address[0], True) == address[1])
    address = ('failed.example.com:22', ('failed.example.com', 22))

# Generated at 2022-06-23 05:15:33.793916
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:46.320823
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::ffff:192.0.2.3]') == (u'[::ffff:192.0.2.3]', None)
    assert parse_address('[::ffff:192.0.2.3]:123') == (u'[::ffff:192.0.2.3]', 123)
    assert parse_address('localhost') == (u'localhost', None)
    assert parse_address('localhost:1234') == (u'localhost', 1234)
    assert parse_address('192.0.2.3') == (u'192.0.2.3', None)
    assert parse_address('192.0.2.3:1234') == (u'192.0.2.3', 1234)

# Generated at 2022-06-23 05:15:58.227813
# Unit test for function parse_address
def test_parse_address():
    assert ('127.0.0.1', 22) == parse_address('127.0.0.1:22')
    assert ('127.0.0.1', None) == parse_address('127.0.0.1')
    assert ('::1', 22) == parse_address('[::1]:22')
    assert ('::1', None) == parse_address('[::1]')
    assert ('::1', None) == parse_address('::1')
    assert ('::1', 22) == parse_address('[::1]:22')
    assert ('::', None) == parse_address('::')
    assert (':', None) == parse_address(':')
    assert ('foo', None) == parse_address('foo')
    assert ('foo', 22) == parse_address('foo:22')

# Generated at 2022-06-23 05:16:07.713173
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:123') == (':1', 123)
    assert parse_address('192.0.2.2:123') == ('192.0.2.2', 123)
    assert parse_address('foo[0:2]') == ('foo', None)
    assert parse_address('foo[0:2]:123') == ('foo', 123)
    assert parse_address('foo[0:2]') == ('foo', None)
    assert parse_address('foo[0:2]:123') == ('foo', 123)
    assert parse_address('foo[0:2]-bar[x-z]:123') == ('foo[0:2]-bar[x-z]', 123)

# Generated at 2022-06-23 05:16:16.732336
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:5555') == ('localhost', 5555)
    assert parse_address('127.0.0.1:5555') == ('127.0.0.1', 5555)
    assert parse_address('127.0.0.1:5555', True) == ('127.0.0.1', 5555)
    assert parse_address('127.0.0.1', True) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1[1:3]', True) == ('127.0.0.1[1:3]', None)

# Generated at 2022-06-23 05:16:27.957234
# Unit test for function parse_address
def test_parse_address():

    class ParseError(Exception):
        pass

    def expect(address, host, port):
        (h, p) = parse_address(address)
        if h != host:
            raise ParseError("%s returned host %s instead of %s" % (address, h, host))
        if p != port:
            raise ParseError("%s returned port %d instead of %d" % (address, p, port))

    expect("[::1]:22", "::1", 22)
    expect("[::1]", "::1", None)
    expect("[::1]", "::1", None)
    expect("[::1:2:3:4:5:6:7]", "::1:2:3:4:5:6:7", None)

# Generated at 2022-06-23 05:16:36.867031
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:48.451900
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost:65535') == ('localhost', 65535)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:65535') == ('192.0.2.3', 65535)

    with pytest.raises(AnsibleError):
        parse_address('foo[bar')

    with pytest.raises(AnsibleError):
        parse_address('foo[1:2')


# Generated at 2022-06-23 05:16:58.670207
# Unit test for function parse_address
def test_parse_address():
    import sys
    import pytest
    from ansible.module_utils.six import PY3


# Generated at 2022-06-23 05:17:08.575283
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:2222') == ('foo', 2222)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)

# Generated at 2022-06-23 05:17:18.466789
# Unit test for function parse_address
def test_parse_address():
    try:
        parse_address(None)
        assert False, "Expected a ValueError"
    except AnsibleError:
        pass

    assert parse_address("[::1]") == ("[::1]", None)
    assert parse_address("[::1]:22") == ("[::1]", 22)
    assert parse_address("[::ffff:192.0.2.3]:22") == ("[::ffff:192.0.2.3]", 22)

    assert parse_address("hostname:1234") == ("hostname", 1234)
    assert parse_address("hostname") == ("hostname", None)

    assert parse_address("192.0.2.3:1234") == ("192.0.2.3", 1234)

# Generated at 2022-06-23 05:17:29.596766
# Unit test for function parse_address
def test_parse_address():

    assert (parse_address('[::1]') == ('::1', None))
    assert (parse_address('[::1]:22') == ('::1', 22))
    assert (parse_address('bad-hostname-with-port:22') == ('bad-hostname-with-port', 22))
    assert (parse_address('bad-hostname-with-port') == ('bad-hostname-with-port', None))
    assert (parse_address('bad_hostname_with_port:22') == ('bad_hostname_with_port', 22))
    assert (parse_address('bad_hostname_with_port') == ('bad_hostname_with_port', None))

    assert (parse_address('127.0.0.1') == ('127.0.0.1', None))

# Generated at 2022-06-23 05:17:42.045399
# Unit test for function parse_address
def test_parse_address():
    # IPv4
    assert parse_address("1.2.3.4") == ('1.2.3.4', None)
    assert parse_address("1.2.3.4:50") == ('1.2.3.4', 50)
    assert parse_address("1.2.3.4[1]:50") == ('1.2.3.4[1]', 50)
    assert parse_address("[1.2.3.4]:50") == ('1.2.3.4', 50)
    assert parse_address("1.2.3.4[0:2]:50") == ('1.2.3.4[0:2]', 50)
    # IPv6
    assert parse_address("2001:0db8:85a3:0000:0000:8a2e:0370:7334")

# Generated at 2022-06-23 05:17:50.538414
# Unit test for function parse_address
def test_parse_address():
    # Basic tests
    assert parse_address('localhost')      == ('localhost', None)
    assert parse_address('localhost:1234') == ('localhost', 1234)
    assert parse_address('127.0.0.1')      == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:1234') == ('127.0.0.1', 1234)
    assert parse_address('::1')            == ('::1', None)
    assert parse_address('[::1]:1234')     == ('::1', 1234)

    # Identifiers with ranges
    assert parse_address('localhost[1]:1234') == ('localhost[1]', 1234)
    assert parse_address('localhost[1-3]:1234') == ('localhost[1-3]', 1234)


# Generated at 2022-06-23 05:18:02.409722
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:11.189256
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:20.795752
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:31.454380
# Unit test for function parse_address
def test_parse_address():
    """
    Unit test for module function parse_address.
    """
    import pytest

    # Tests for IPv4 addresses with port numbers.
    assert parse_address('12.34.56.78:3306') == ('12.34.56.78', 3306)
    assert parse_address('192.168.0.255:22') == ('192.168.0.255', 22)
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)

    # Failures for IPv4 addresses with bad port numbers.
    with pytest.raises(AnsibleError):
        parse_address('12.34.56.78:65536')
    with pytest.raises(AnsibleError):
        parse_address('255.255.255.255:')

# Generated at 2022-06-23 05:18:41.576613
# Unit test for function parse_address
def test_parse_address():
    def test_case(input_value, expected_result):
        result = parse_address(input_value, True)
        assert result == expected_result

    test_case('1.2.3.4', ("1.2.3.4", None))
    test_case('1.2.3.4:80', ("1.2.3.4", 80))
    test_case('[1.2.3.4]:80', ("1.2.3.4", 80))
    test_case('foo', ("foo", None))
    test_case('foo.bar', ("foo.bar", None))
    test_case('foo[0:5]', ("foo[0:5]", None))
    test_case('foo[0:5]-bar', ("foo[0:5]-bar", None))
    test_case

# Generated at 2022-06-23 05:18:52.395321
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:04.662524
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:15.810028
# Unit test for function parse_address
def test_parse_address():

    def test(address, host=None, port=None):
        assert parse_address(address) == (host, port)

    test('[2001:db8::1]')
    test('[2001:db8::1]:5432')
    test('[2001:db8:0:1:1:1:1:1]')
    test('[2001:db8:0:1:1:1:1:1]:5432')
    test('[2001:db8::1]:5432', host='[2001:db8::1]', port=5432)
    test('[2001:db8:0:1::1]:5432', host='[2001:db8:0:1::1]', port=5432)
    test('[2001:db8::1.2.3.4]')

# Generated at 2022-06-23 05:19:27.948837
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:1234') == ('localhost', 1234)

    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:1234') == ('127.0.0.1', 1234)

    assert parse_address('127.0.0.1[3-5]') == ('127.0.0.1[3-5]', None)
    assert parse_address('127.0.0.1[3-5]', allow_ranges=True) == ('127.0.0.1', None)

# Generated at 2022-06-23 05:19:39.000653
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:49.136692
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:58.273592
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('example.org:80') == ('example.org', 80)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:80') == ('::1', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:80') == ('192.0.2.1', 80)
    assert parse_address

# Generated at 2022-06-23 05:20:07.386356
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:18.724736
# Unit test for function parse_address
def test_parse_address():

    if not hasattr(test_parse_address, 'errors'):
        test_parse_address.errors = 0

    def check(case, host, port, ranges_work=True):
        (h, p) = parse_address(case)
        if ((h, p) == (host, port)) != ranges_work:
            print("FAIL: parse_address('%s') = (%s, %s) but expected (%s, %s)" % (case, h, p, host, port))
            test_parse_address.errors += 1

    check('foo', 'foo', None)


# Generated at 2022-06-23 05:20:30.412598
# Unit test for function parse_address
def test_parse_address():

    # test case
    # input: address:port
    # expected: (address, port)

    # ranges are not accepted unless specified
    assert parse_address("192.0.2.1:9001") == ('192.0.2.1', 9001)
    assert parse_address("192.0.2.1:9001", False) == ('192.0.2.1', 9001)
    try:
        parse_address("192.0.2.1:9001", True)
        assert False
    except AnsibleParserError:
        pass

    # port is required for ipv6 addresses
    assert parse_address("[2001:db8::1]:9001") == ('2001:db8::1', 9001)

# Generated at 2022-06-23 05:20:41.924723
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:48.303164
# Unit test for function parse_address
def test_parse_address():
    from nose.tools import assert_equal

    assert_equal(parse_address('192.168.222.1:443'), ('192.168.222.1', 443))
    assert_equal(parse_address('192.168.222.1'), ('192.168.222.1', None))
    assert_equal(parse_address('192.168.222.1:nope'), ('192.168.222.1', None))

    assert_equal(parse_address('[2001:db8::1]:443'), ('2001:db8::1', 443))
    assert_equal(parse_address('[2001:db8::1]'), ('2001:db8::1', None))
    assert_equal(parse_address('[2001:db8::1:443'), ('2001:db8::1', 443))

# Generated at 2022-06-23 05:20:58.619892
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:10.315717
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("example.com[1:3]") == ("example.com[1:3]", None)
    assert parse_address("example.com[1:3]:22") == ("example.com[1:3]", 22)
    assert parse_address("example.com:22") == ("example.com", 22)
    assert parse_address("[example.com]:22") == ("example.com", 22)
    assert parse_address("[example.com[1:3]]:22") == ("example.com[1:3]", 22)
    assert parse_address("192.168.1.1") == ("192.168.1.1", None)
    assert parse_address("192.168.1.1[1:3]")

# Generated at 2022-06-23 05:21:20.174495
# Unit test for function parse_address