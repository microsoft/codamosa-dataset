

# Generated at 2022-06-23 05:11:21.631340
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com:80") == ("example.com", 80)
    assert parse_address("example.com") == ("example.com", None)

    assert parse_address("[example.com]:80") == ("example.com", 80)
    assert parse_address("[example.com]") == ("example.com", None)

    assert parse_address("192.0.2.0:80") == ("192.0.2.0", 80)
    assert parse_address("192.0.2.0") == ("192.0.2.0", None)

    assert parse_address("[192.0.2.0]:80") == ("192.0.2.0", 80)
    assert parse_address("[192.0.2.0]") == ("192.0.2.0", None)

   

# Generated at 2022-06-23 05:11:28.933900
# Unit test for function parse_address
def test_parse_address():
    import pytest

    def test(address,
             allows_ranges=False,
             host=None,
             port=None):
        (rhost, rport) = parse_address(address, allows_ranges)
        assert rhost == host
        assert rport == port

    test(address='example.com', host='example.com', port=None)
    test(address='example.com:22', host='example.com', port=22)
    test(address='example.com:22', host='example.com', port=22)
    test(address='example.com[1:3]', host='example.com[1:3]', port=None)
    test(address='example.com[1:3]:22', host='example.com[1:3]', port=22)

# Generated at 2022-06-23 05:11:38.617917
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.network import parse_address

    def _test(address, allow_ranges=False):
        (host, port) = parse_address(address, allow_ranges)
        print(address, '=', host, port)

    print('valid')
    _test('example.com')
    _test('example.com:123')
    _test('example.com:123', allow_ranges=True)
    _test('192.0.2.1')
    _test('192.0.2.1:123')
    _test('192.0.2.1', allow_ranges=True)
    _test('192.0.2.1:123', allow_ranges=True)
    _test('192.0.2.1/24')

# Generated at 2022-06-23 05:11:49.204650
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('[localhost]') == ('localhost', None)
    assert parse_address('[localhost]:22') == ('localhost', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)

    # ranges are not supported

# Generated at 2022-06-23 05:12:01.401452
# Unit test for function parse_address
def test_parse_address():
    assert ('foo.example.com', None) == parse_address('foo.example.com')
    assert ('foo.example.com', None) == parse_address('foo.example.com:')
    assert ('foo.example.com', 22) == parse_address('foo.example.com:22')
    assert ('192.0.2.3', None) == parse_address('192.0.2.3')
    assert ('192.0.2.3', None) == parse_address('192.0.2.3:')
    assert ('192.0.2.3', 22) == parse_address('192.0.2.3:22')
    assert ('::ffff:192.0.2.3', None) == parse_address('::ffff:192.0.2.3')

# Generated at 2022-06-23 05:12:10.684476
# Unit test for function parse_address
def test_parse_address():
    """
    We treat a number of variants in a number of different contexts as
    equivalent, and therefore test them all against the same expected result.

    The result is a (host, port) tuple, where either or both may be None.
    """


# Generated at 2022-06-23 05:12:23.289065
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:31.044286
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:80') == ('foo', 80)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:23') == ('foo.example.com', 23)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:23') == ('192.0.2.3', 23)
    assert parse_address('[2001:db8::]') == ('2001:db8::', None)
    assert parse_address('[2001:db8::]:23') == ('2001:db8::', 23)

# Generated at 2022-06-23 05:12:36.636403
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:47.397846
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:56.383562
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:07.953306
# Unit test for function parse_address
def test_parse_address():
    import pytest

    def assert_parse_address(input, expected):
        assert parse_address(input) == expected

    def assert_parse_error(input):
        with pytest.raises(AnsibleParserError):
            parse_address(input)

    assert_parse_address("foo.example.com", ("foo.example.com", None))
    assert_parse_address("foo.example.com:1234", ("foo.example.com", 1234))
    assert_parse_address("foo.example.com:1234", ("foo.example.com", 1234))
    assert_parse_address("foo.example.com:1234", ("foo.example.com", 1234))
    assert_parse_address("192.0.2.1", ("192.0.2.1", None))
    assert_parse_

# Generated at 2022-06-23 05:13:16.216931
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1[1:3]') == ('127.0.0.1[1:3]', None)
    assert parse_address('127.0.0.1[1:3]:22') == ('127.0.0.1[1:3]', 22)
    assert parse_address('www.example.com') == ('www.example.com', None)

# Generated at 2022-06-23 05:13:24.079059
# Unit test for function parse_address
def test_parse_address():
    assert(parse_address("hostname", True) == ("hostname", None))
    assert(parse_address("hostname:") == ("hostname", None))
    assert(parse_address("hostname:42") == ("hostname", 42))
    assert(parse_address("[hostname]") == ("hostname", None))
    assert(parse_address("[hostname]:") == ("hostname", None))
    assert(parse_address("[hostname]:42") == ("hostname", 42))
    assert(parse_address("[ipv6.address]") == ("ipv6.address", None))
    assert(parse_address("[ipv6.address]:") == ("ipv6.address", None))
    assert(parse_address("[ipv6.address]:42") == ("ipv6.address", 42))


# Generated at 2022-06-23 05:13:34.891865
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('foo[1:2]') == ('foo[1:2]', None)
    assert parse_address('foo[1:2]:22') == ('foo[1:2]', 22)

    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)


# Generated at 2022-06-23 05:13:46.503785
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:55.149006
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest

    class TestAddr(unittest.TestCase):
        def test_hostname(self):
            for address in ["foo.example.com:22", "foo.example.com:22/foo"]:
                (host, port) = parse_address(address)
                self.assertEqual(host, "foo.example.com")
                self.assertEqual(port, 22)

            for address in ["foo.example.com", "foo.example.com/foo"]:
                (host, port) = parse_address(address)
                self.assertEqual(host, "foo.example.com")
                self.assertIsNone(port)


# Generated at 2022-06-23 05:14:04.870130
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:15.572193
# Unit test for function parse_address
def test_parse_address():
    # Tests on valid IPv4 addresses
    assert parse_address("192.0.2.3:66") == ("192.0.2.3", 66)
    assert parse_address("192.0.2.3") == ("192.0.2.3", None)
    assert parse_address("[192.0.2.3]:77") == ("192.0.2.3", 77)
    assert parse_address("[192.0.2.3]") == ("192.0.2.3", None)
    assert parse_address("[192.0.2.3]:88", allow_ranges=True) == ("192.0.2.3", 88)
    assert parse_address("[192.0.2.3]", allow_ranges=True) == ("192.0.2.3", None)

    #

# Generated at 2022-06-23 05:14:24.621717
# Unit test for function parse_address
def test_parse_address():
    def test(description, address, host, port):
        (h, p) = parse_address(address)
        # print("host: %s, port: %s" % (h, p))
        if (host is None or h == host) and (port is None or p == port):
            print("test_parse_address %s passed" % description)
        else:
            print("test_parse_address %s FAILED" % description)
            print("  expected (host=%s, port=%s)" % (host, port))
            print("  got      (host=%s, port=%s)" % (h, p))

    test("invalid address", "unrecognised--address", None, None)
    test("simple address", "example.com", "example.com", None)

# Generated at 2022-06-23 05:14:33.329103
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:44.238869
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest
    class TestParseAddress(unittest.TestCase):

        def assert_hostport(self, expected, host, port=None):
            (h, p) = parse_address(host)
            self.assertEqual(expected, h)
            if port is None:
                self.assertIsNone(p)
            else:
                self.assertEqual(port, p)

        def assert_port_only(self, host, port):
            self.assertRaises(AnsibleError, parse_address, host)
            (h, p) = parse_address("[%s]" % host)
            self.assertIsNone(h)
            self.assertEqual(port, p)


# Generated at 2022-06-23 05:14:51.832123
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:01.749745
# Unit test for function parse_address
def test_parse_address():
    """ Unit tests for function parse_address """

    def test(host, port, ranges=False):
        """
        Tests whether host, port pairs are correctly parsed. The host may be
        None to indicate that host/port cannot be parsed. A port of None
        indicates that no port was specified.
        """
        s = None
        if port is not None:
            s = host + ':' + str(port)
        else:
            s = host
        (got_host, got_port) = parse_address(s, ranges)
        if host is None:
            assert (got_host, got_port) == (None, None)
        else:
            assert (got_host, got_port) == (host, port)

    # Test IPv4 address parsing.


# Generated at 2022-06-23 05:15:11.040880
# Unit test for function parse_address
def test_parse_address():
    from ansible.module_utils.six import assertRegexpMatches
    import pytest
    from ansible.module_utils._text import to_native

    try:
        from ipaddress import IPv4Address
        NET_HAS_IP = True
    except ImportError:
        NET_HAS_IP = False

    # Test suite, each entry consists of a string, a list of two elements,
    # for host and port, and if None, then ignore the value.

# Generated at 2022-06-23 05:15:22.367466
# Unit test for function parse_address
def test_parse_address():
    # If a hostname or IPv4 address has a port specification (:NN), it must be
    # a suffix.
    assert parse_address('foo:88') == ('foo', 88)
    assert parse_address('192.168.1.1:88') == ('192.168.1.1', 88)
    assert parse_address('192.168.1.1/32:88') == ('192.168.1.1/32', 88)
    assert parse_address('192.168.1.1/32 :88') == ('192.168.1.1/32 ', 88)

    # If a hostname or IPv4 address is enclosed in square brackets, a port
    # specification (:NN) is mandatory.
    assert parse_address('[foo]:88') == ('foo', 88)

# Generated at 2022-06-23 05:15:29.607102
# Unit test for function parse_address
def test_parse_address():
    '''Tests the parse_address function and its regexes'''

    assert parse_address('[::]:0') == ('::', 0)
    assert parse_address('[::1]:0') == ('::1', 0)
    assert parse_address('[::1]:65535') == ('::1', 65535)
    assert parse_address('[2001:db8::1]:0') == ('2001:db8::1', 0)
    assert parse_address('[2001:db8::1]:65535') == ('2001:db8::1', 65535)
    assert parse_address('[2001:db8::1]:65536') == ('2001:db8::1', 65536)

# Generated at 2022-06-23 05:15:39.727658
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)

# Generated at 2022-06-23 05:15:49.056257
# Unit test for function parse_address
def test_parse_address():
    import random

    # A list of valid, invalid, and stupid addresses.

# Generated at 2022-06-23 05:16:00.676479
# Unit test for function parse_address
def test_parse_address():

    # [x:y(:z)] range specifications
    # =============================

    # Numeric ranges
    print(parse_address('foo[1:3]', allow_ranges=True))
    print(parse_address('foo[0:5]:443', allow_ranges=True))
    print(parse_address('[127.0.0.1:127.0.0.5]:22', allow_ranges=True))
    print(parse_address('foo[1:3:2]', allow_ranges=True))
    print(parse_address('foo[1:3:2]:443', allow_ranges=True))
    print(parse_address('[127.0.0.1:127.0.0.5:2]:22', allow_ranges=True))

    # Hexadecimal ranges

# Generated at 2022-06-23 05:16:10.760712
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('1:2:3:4:5:6:7:8:22') == ('1:2:3:4:5:6:7:8', 22)
    assert parse_address('1:2:3:4:5:6:7:8') == ('1:2:3:4:5:6:7:8', None)
    assert parse_address('::1:2:3:4:5:6:7:8:22') == ('::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-23 05:16:23.224848
# Unit test for function parse_address
def test_parse_address():
    failed = False
    failed_tests = []

# Generated at 2022-06-23 05:16:32.956469
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:40.098576
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.168.0.1') == ('192.168.0.1', None)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[example.com]:22') == ('example.com', 22)
    assert parse_address('[192.168.0.1]:22') == ('192.168.0.1', 22)
    assert parse_address('[172.16.100.1]:22') == ('172.16.100.1', 22)
    assert parse_address('[172.16.100.1]') == ('172.16.100.1', None)

# Generated at 2022-06-23 05:16:43.210000
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:54.983328
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:06.253160
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo', allow_ranges=False) == ('foo', None)
    assert parse_address('foo:123', allow_ranges=False) == ('foo', 123)
    assert parse_address('foo[1:3]', allow_ranges=False) == ('foo[1:3]', None)
    assert parse_address('foo[1:3:2]', allow_ranges=False) == ('foo[1:3:2]', None)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3:2]', allow_ranges=True) == ('foo[1:3:2]', None)

# Generated at 2022-06-23 05:17:16.823408
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('2001:db8::1:22') == (None, None)
    assert parse_address('[2001:db8::1') == (None, None)

# Generated at 2022-06-23 05:17:28.821181
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.pycompat import byte_to_text

    # Known-good address:port combinations.

# Generated at 2022-06-23 05:17:39.410485
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:51.117356
# Unit test for function parse_address
def test_parse_address():
    # These are hostnames with no port.
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    # These are IPv4 addresses with no port.
    assert parse_address('192.0.2.123') == ('192.0.2.123', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1/24') == ('127.0.0.1/24', None)
    # These are IPv6 addresses with no port.
    assert parse_address('::1') == ('::1', None)
    assert parse_address('::2') == ('::2', None)
    # These are hostnames with

# Generated at 2022-06-23 05:18:02.836401
# Unit test for function parse_address
def test_parse_address():

    ipv4_patterns = {
        'host':     '192.168.1.1',
        'hostport': '192.168.1.1:80',
        'range':    '192.168.1[0-1]:80',
    }

    for pattern in ipv4_patterns:
        (host, port) = parse_address(ipv4_patterns[pattern])
        assert host == '192.168.1.1', pattern
        assert port == (pattern == 'hostport') * 80, pattern

    ipv6_patterns = {
        'host':     '::1',
        'hostport': '[::1]:80',
        'range':    '[1:ffff:1:ffff:1:ffff:1:ffff]:80',
    }


# Generated at 2022-06-23 05:18:11.562448
# Unit test for function parse_address
def test_parse_address():
    # Test for correct results for valid strings
    valid_strings = ["1.2.3.4:23","foo:65535","[1:2:3:4:5:6:7:8]:5987","[1.2.3.4]:14"]
    for valid_string in valid_strings:
        (host, port) = parse_address(valid_string, True)
        if valid_string.startswith('['):
            # this is an ipv6 address
            assert host == valid_string[1:-1]
        else:
            # ipv4 or hostname
            assert host == valid_string.split(':')[0]
        assert port == int(valid_string.split(':')[1])

    # Test for correct results when ranges are not allowed

# Generated at 2022-06-23 05:18:20.953075
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:31.490925
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:42.743127
# Unit test for function parse_address
def test_parse_address():
    from ansible.inventory.host import Host
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.six import string_types

    def _resolve(host):
        host = Host(name=host)
        vars = VariableManager()
        blocks = load_list_of_blocks([dict(hosts=host.name)], play=play, variable_manager=vars, loader=variable_manager.loader)
        block = blocks[0]
        block

# Generated at 2022-06-23 05:18:50.671155
# Unit test for function parse_address
def test_parse_address():
    # Valid host names, with and without ranges.
    assert parse_address(u'target') == ('target', None)
    assert parse_address(u'target:2222') == ('target', 2222)
    assert parse_address(u'foo[0:3].example.com') == ('foo[0:3].example.com', None)
    assert parse_address(u'foo[0:3].example.com:2222') == ('foo[0:3].example.com', 2222)

    # Valid IPv4 addresses, with and without ranges.
    assert parse_address(u'192.0.2.1') == ('192.0.2.1', None)
    assert parse_address(u'192.0.2.1:2222') == ('192.0.2.1', 2222)
    assert parse_

# Generated at 2022-06-23 05:18:57.853256
# Unit test for function parse_address
def test_parse_address():
    import unittest
    from ansible.utils.unicode import to_bytes

    address = "example.org"
    expected = ("example.org", None)
    result = parse_address(address)
    assert result == expected

    host, port = result
    assert host is not None
    assert port is None

    address = "localhost"
    expected = ("localhost", None)
    result = parse_address(address)
    assert result == expected

    address = "localhost:22"
    expected = ("localhost", 22)
    result = parse_address(address)
    assert result == expected

    address = "localhost.localdomain"
    expected = ("localhost.localdomain", None)
    result = parse_address(address)
    assert result == expected

    address = "foo[0:4].example.com"


# Generated at 2022-06-23 05:19:08.140640
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest

    class TestParseAddress(unittest.TestCase):

        def test_ipv4(self):
            address = '127.0.0.1'
            self.assertEqual(parse_address(address), (address, None))
            address = '[127.0.0.1]:5000'
            self.assertEqual(parse_address(address), (address, 5000))
        def test_ipv6(self):
            address = '::1'
            self.assertEqual(parse_address(address), ('[%s]' % address, None))
            address = '[::1]:5000'
            self.assertEqual(parse_address(address), (address, 5000))
            address = '2001:db8::8:800:200c:417a'
           

# Generated at 2022-06-23 05:19:19.304637
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo:123', allow_ranges=True) == ('foo', 123)
    assert parse_address('[foo]:123') == ('foo', 123)
    assert parse_address('[foo]:123', allow_ranges=True) == ('foo', 123)
    assert parse_address('192.0.2.1:123') == ('192.0.2.1', 123)
    assert parse_address('192.0.2.1:123', allow_ranges=True) == ('192.0.2.1', 123)
    assert parse_address('192.0.2.1:123:456:789') == ('192.0.2.1:123:456:789', None)

# Generated at 2022-06-23 05:19:28.221131
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('example.com[1-5]:22') == ('example.com[1-5]', 22)
    assert parse_address('[fe80::5]:22') == ('[fe80::5]', 22)
    assert parse_address('[10.0.0.1]:22') == ('[10.0.0.1]', 22)
    assert parse_address('[www.example.com]:22') == ('[www.example.com]', 22)
    assert parse_address('[::ffff:192.0.2.1]:22') == ('[::ffff:192.0.2.1]', 22)

# Generated at 2022-06-23 05:19:39.000929
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:48.086002
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[2001:db8::1]') == ('[2001:db8::1]', None)
    assert parse_address('[2001:db8::1]:22') == ('[2001:db8::1]', 22)
    assert parse_address('[::ffff:192.0.2.3]:22') == ('[::ffff:192.0.2.3]', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)

# Generated at 2022-06-23 05:19:57.904242
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:07.146939
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[1:2::1]', allow_ranges=False) == ('[1:2::1]', None)
    assert parse_address('[1:2::1]', allow_ranges=True) == ('[1:2::1]', None)

    assert parse_address('[::ffff:192.0.2.128]:1024') == ('::ffff:192.0.2.128', 1024)
    assert parse_address('[::ffff:192.0.2.128]', allow_ranges=False) == ('[::ffff:192.0.2.128]', None)
    assert parse_address('[::ffff:192.0.2.128]', allow_ranges=True) == ('::ffff:192.0.2.128', None)


# Generated at 2022-06-23 05:20:18.695037
# Unit test for function parse_address
def test_parse_address():
    """
    Tests for parse_address
    """
    assert parse_address('[::1]:5') == ('::1', 5)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::ffff:192.0.2.3]:5') == ('::ffff:192.0.2.3', 5)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:4]:58') == ('foo[1:4]', 58)

# Generated at 2022-06-23 05:20:29.817492
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(":123") == (None, 123)
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)
    assert parse_address("[foo.example.com]") == ("foo.example.com", None)
    assert parse_address("[foo.example.com]:22") == ("foo.example.com", 22)
    assert parse_address("192.0.2.222") == ("192.0.2.222", None)
    assert parse_address("192.0.2.222:22") == ("192.0.2.222", 22)
    assert parse_address("[192.0.2.222]") == ("192.0.2.222", None)

# Generated at 2022-06-23 05:20:38.141428
# Unit test for function parse_address
def test_parse_address():
    # allow_ranges = False, default
    assert parse_address("192.168.0.1") == ("192.168.0.1", None)
    assert parse_address("192.168.0.1:1234") == ("192.168.0.1", 1234)
    assert parse_address("[192.168.0.1]") == ("192.168.0.1", None)
    assert parse_address("[192.168.0.1]:1234") == ("192.168.0.1", 1234)
    assert parse_address("localhost:1234") == ("localhost", 1234)
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("192-168-0-1") == ("192-168-0-1", None)

# Generated at 2022-06-23 05:20:49.693448
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('') == (None, None)

    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:[::1]:22') == ('foo.example.com:[::1]', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:22')

# Generated at 2022-06-23 05:20:59.770431
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:10.583467
# Unit test for function parse_address
def test_parse_address():
    # Check success cases.
    assert parse_address('hostname') == (u'hostname', None)
    assert parse_address('host-name') == (u'host-name', None)
    assert parse_address('host_name') == (u'host_name', None)
    assert parse_address('host[1:3]') == (u'host[1:3]', None)
    assert parse_address('host[1-3]') == (u'host[1-3]', None)
    assert parse_address('host[1-3]-name') == (u'host[1-3]-name', None)
    assert parse_address('host[ab-cd]') == (u'host[ab-cd]', None)

# Generated at 2022-06-23 05:21:20.402866
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:123') == ('localhost', 123)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:123') == ('127.0.0.1', 123)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:123') == ('::1', 123)
    assert parse_address('[dead:beef::1]') == ('dead:beef::1', None)
    assert parse_address('[dead:beef::1]:123') == ('dead:beef::1', 123)