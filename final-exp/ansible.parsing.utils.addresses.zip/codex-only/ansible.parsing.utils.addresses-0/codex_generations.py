

# Generated at 2022-06-23 05:11:20.615191
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-23 05:11:27.565614
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:1234") == ("127.0.0.1", 1234)
    assert parse_address("127.0.0[1:2].1:1234") == ("127.0.0[1:2].1", 1234)
    assert parse_address("127.0.0[1:2].1") == ("127.0.0[1:2].1", None)
    assert parse_address("127.0.0[1:2].1:1234") == ("127.0.0[1:2].1", 1234)

    assert parse_address("[::1]") == ("::1", None)

# Generated at 2022-06-23 05:11:37.431881
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:48.194610
# Unit test for function parse_address
def test_parse_address():
    print("Testing parse_address")

    def test(address, expected, **kwargs):
        """
        Test that parse_address() works as expected on the given arguments.
        """
        if 'expect_error' in kwargs:
            expect_error = kwargs['expect_error']
        else:
            expect_error = False
        try:
            result = parse_address(address, **kwargs)
        except AnsibleError:
            if expect_error:
                print("Works as expected: %r" % address)
            else:
                print("Oops: unexpected error with %r" % address)
            return
        if expect_error:
            print("Oops: expected an error but got %r" % result)
            return

# Generated at 2022-06-23 05:11:57.485577
# Unit test for function parse_address
def test_parse_address():
    """
    Test cases for function parse_address
    """

    assert parse_address('localhost', True) == ('localhost', None)
    assert parse_address('[::1]', True) == ('::1', None)
    assert parse_address('[::1]:22', True) == ('::1', 22)
    assert parse_address('[::1]:22', False) == ('::1', 22)
    assert parse_address('127.0.0.1', True) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22', True) == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', False) == ('127.0.0.1', 22)


# Generated at 2022-06-23 05:12:01.762357
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:1234') == ('example.com', 1234)
    assert parse_address('example.com [abc:def]', allow_ranges=True) == ('example.com [abc:def]', None)
    assert parse_address('example.com:1234 [abc:def]', allow_ranges=True) == ('example.com:1234 [abc:def]', None)
    assert parse_address('example.com [abc:def]:1234', allow_ranges=True) == ('example.com [abc:def]', 1234)
    assert parse_address('[example.com]') == ('example.com', None)

# Generated at 2022-06-23 05:12:10.968459
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest


# Generated at 2022-06-23 05:12:20.445999
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com', allow_ranges=True) == ('example.com', None)
    assert parse_address('example.com:1234', allow_ranges=True) == ('example.com', 1234)
    assert parse_address('foo[0:2].example.com', allow_ranges=True) == ('foo[0:2].example.com', None)
    assert parse_address('foo[0:2].example.com:1234', allow_ranges=True) == ('foo[0:2].example.com', 1234)
    assert parse_address('[foo[0:2].example.com]:1234', allow_ranges=True) == ('foo[0:2].example.com', 1234)

# Generated at 2022-06-23 05:12:28.839618
# Unit test for function parse_address
def test_parse_address():
    def t(s, h=None, p=None):
        (host, port) = parse_address(s)
        assert host == h and port == p, "input %s gave host=%s port=%s" % (s, host, port)

    t("localhost[1]", "localhost[1]")
    t("localhost[1:5]", "localhost[1:5]")
    t("localhost[1:5:4]", "localhost[1:5:4]")
    t("localhost[x:y]", "localhost[x:y]")
    t("localhost[x:y:z]", "localhost[x:y:z]")
    t("localhost[ab:ef]", "localhost[ab:ef]")

# Generated at 2022-06-23 05:12:40.889922
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:50.440424
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('[1:2:3:4:5:6:7:8]') == ('1:2:3:4:5:6:7:8', None)

    assert parse_address('[::ffff:192.0.2.3]:23') == ('::ffff:192.0.2.3', 23)
    assert parse_address('[abcd::1]:23') == ('abcd::1', 23)

# Generated at 2022-06-23 05:12:59.248498
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils import unit
    from ansible.compat.tests import unittest


# Generated at 2022-06-23 05:13:10.517823
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:18.410819
# Unit test for function parse_address
def test_parse_address():

    # Success:
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:1234') == ('example.com', 1234)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:1234') == ('192.0.2.3', 1234)
    assert parse_address('[192.0.2.3]:1234') == ('192.0.2.3', 1234)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:1234') == ('2001:db8::1', 1234)

    assert parse_address

# Generated at 2022-06-23 05:13:29.489930
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('[::1]') == ('[::1]', None)

# Generated at 2022-06-23 05:13:40.235381
# Unit test for function parse_address
def test_parse_address():
    results = {}

    results['invalid'] = (None, None)
    assert parse_address("x y") == results['invalid']

    results['hostport'] = ('hostname', 42)
    assert parse_address("[hostname]:42") == results['hostport']

    results['hostport'] = ('hostname', 42)
    assert parse_address("hostname:42") == results['hostport']

    results['hostport'] = ('host[1:3]name', 42)
    assert parse_address("[host[1:3]name]:42") == results['hostport']

    results['hostport'] = ('host[1:3]name', 42)
    assert parse_address("host[1:3]name:42") == results['hostport']


# Generated at 2022-06-23 05:13:48.167693
# Unit test for function parse_address
def test_parse_address():
    import pytest

    # valid addresses
    assert parse_address("abc", True) == ("abc", None)
    assert parse_address("abc:1", True) == ("abc", 1)
    assert parse_address("1.2.3.4", True) == ("1.2.3.4", None)
    assert parse_address("1.2.3.4:1", True) == ("1.2.3.4", 1)
    assert parse_address("1.2.3.4:1-2", True) == ("1.2.3.4", 1)
    assert parse_address("1.2.3.4-5:1-2", True) == ("1.2.3.4-5", 1)

# Generated at 2022-06-23 05:13:58.565647
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('1.2.3.4:123') == ('1.2.3.4', 123)
    with raises(AnsibleParserError, match=r'Detected range in host but was asked to ignore ranges'):
        parse_address('1.2.3.4:123', allow_ranges=False)
    assert parse

# Generated at 2022-06-23 05:14:09.726665
# Unit test for function parse_address
def test_parse_address():
    def _test(address, host, port):
        h, p = parse_address(address)
        assert h == host and p == port, "parse_address(%s) returned %s, %d != %s, %d" % (address, h, p, host, port)

    _test("example.com", "example.com", None)
    _test("example.com:22", "example.com", 22)
    _test("[::1]", "::1", None)
    _test("[::1]:22", "::1", 22)
    _test("[::ffff:192.0.2.3]", "::ffff:192.0.2.3", None)
    _test("[::ffff:192.0.2.3]:22", "::ffff:192.0.2.3", 22)

# Generated at 2022-06-23 05:14:21.550593
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address('[::]:22') == ("::", 22))
    assert (parse_address('[::1]:22') == ("::1", 22))
    assert (parse_address('[2001:db8::1]:22') == ("2001:db8::1", 22))
    assert (parse_address('foo[1:3]-bar[x-z].example.com:22') == ("foo[1:3]-bar[x-z].example.com", 22))
    assert (parse_address('foo[1:3]-bar[x-z].example.com') == ("foo[1:3]-bar[x-z].example.com", None))

# Generated at 2022-06-23 05:14:31.869397
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', True) == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', False) == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:22', True) == ('192.0.2.3', 22)

# Generated at 2022-06-23 05:14:43.386111
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('::1') == (u'::1', None)
    assert parse_address('::1:22') == (u'::1', 22)
    assert parse_address('::1:22', allow_ranges=True) == (u'::1:22', None)

    assert parse_address('[192.168.0.1]:22') == (u'192.168.0.1', 22)
    assert parse_address('192.168.0.1') == (u'192.168.0.1', None)

# Generated at 2022-06-23 05:14:53.981921
# Unit test for function parse_address
def test_parse_address():

    # Test coverage of IPv4 and IPv6 addresses.
    #
    # We assume that the rules for IPv6 addresses are covered by the tests for
    # host names because we just allow the same characters in each. So we only
    # need to test the IPv4 and IPv6 components above.
    #
    # Basic numeric ranges.
    assert parse_address('[1:4]') == (None, 0)
    assert parse_address('[1:4]:80') == ('[1:4]', 80)
    assert parse_address('[000:008]') == (None, 0)
    assert parse_address('[000:008]:80') == ('[000:008]', 80)
    # Negative numbers are invalid.
    try:
        parse_address('[1:-4]')
    except AnsibleError:
        pass

# Generated at 2022-06-23 05:15:05.312489
# Unit test for function parse_address
def test_parse_address():
    import sys
    # sys.stderr.write is just to keep ansible-test from thinking this is a test case
    sys.stderr.write('Testing host identifiers (parse_address)')

    # hostname, port
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:1234') == ('foo.example.com', 1234)
    assert parse_address('foo[1:2].example.com') == ('foo[1:2].example.com', None)
    assert parse_address('foo[1:2].example.com:1234') == ('foo[1:2].example.com', 1234)

# Generated at 2022-06-23 05:15:16.800820
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)

    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:80') == ('1.2.3.4', 80)
    assert parse_address('1.2.3.4:80', allow_ranges=True) == ('1.2.3.4', 80)

    assert parse_address('::1') == ('::1', None)
    assert parse_address('::1:80', allow_ranges=True) == ('::1', 80)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address

# Generated at 2022-06-23 05:15:26.054664
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:38.074044
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:48.143871
# Unit test for function parse_address
def test_parse_address():
    """
    The function parse_address should return a (host, port) tuple, where
    host can be either:
    * an IPv4 address
    * an IPv6 address (if IPv6 is enabled)
    * a hostname

    The host may contain numbers joined by ':' to indicate range (or in the
    case of IPv6, ':').

    The port is optional. It may be appended to the hostname or address.
    It may also be specified in an explicit hostname:port format.

    The port must be numeric, but may be of arbitrary length.
    """


# Generated at 2022-06-23 05:15:59.800904
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com.') == ('foo.example.com', None)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address(':22') == (None, 22)
    assert parse_address('[foo]:22') == ('foo', 22)

# Generated at 2022-06-23 05:16:08.922322
# Unit test for function parse_address
def test_parse_address():
    def cases(f, ca):
        """
        Takes a function and a list of (input, expected output) cases. Raises
        an assertion error if the actual output doesn't match the expected
        output.
        """
        for case in ca:
            res = f(*case[0])
            if res != case[1]:
                raise AssertionError("Expected %r, got %r" % (case[1], res))

    assert 'bracketed_hostport' in patterns
    assert 'hostport' in patterns
    assert 'ipv4' in patterns
    assert 'ipv6' in patterns
    assert 'hostname' in patterns

    # IPv4 address followed by a colon, with no port number.

# Generated at 2022-06-23 05:16:18.008082
# Unit test for function parse_address
def test_parse_address():
    assert (None, None) == parse_address("")
    assert (None, None) == parse_address("a:")

    assert ("127.0.0.1", None) == parse_address("127.0.0.1")
    assert ("127.0.0.1", 22) == parse_address("127.0.0.1:22")
    assert ("127.0.0.1", 22) == parse_address("[127.0.0.1]:22")
    assert ("[127.0.0.1]", 22) == parse_address("[[127.0.0.1]]:22")

    assert ("localhost", None) == parse_address("localhost")
    assert ("localhost", 22) == parse_address("localhost:22")
    assert ("localhost", 22) == parse_address("[localhost]:22")


# Generated at 2022-06-23 05:16:28.829541
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('192.0.2.10') == ('192.0.2.10', None)
    assert parse_address('2001:db8::') == ('2001:db8::', None)
    assert parse_address('192.0.2.10:2030') == ('192.0.2.10', 2030)
    assert parse_address('[2001:db8::]:42') == ('2001:db8::', 42)
    assert parse_address('foo[x:y].example.com', allow_ranges=True) == ('foo[x:y].example.com', None)

# Generated at 2022-06-23 05:16:40.427701
# Unit test for function parse_address
def test_parse_address():
    """ Test the parse_address() function by trying a bunch of valid and
    invalid addresses and comparing the expected result with the actual one.
    """

    # The test suite is a list of tuples:
    # (address, a tuple of expected_results, allow_ranges)
    #
    # expected_results is a tuple of expected output, which is allowed
    # to be None to indicate a parse error.
    #
    # Note that this is a series of positive tests; the only explicitly
    # expected error is host pattern expressions with numeric ranges.


# Generated at 2022-06-23 05:16:52.856739
# Unit test for function parse_address
def test_parse_address():
    # Walk through all possible addresses specified in the patterns and confirm
    # that they all give valid results.
    #
    # This is done in a very simplistic way and assumes that all patterns match
    # exactly one of the patterns in the dictionary.

    for address in patterns:
        print("Testing %s with all patterns" % address)
        for pattern_name, pattern in patterns.items():
            print("  trying %s" % pattern_name)
            result = parse_address(address)
            assert result[0] == address

    # Test individual cases that are likely to cause trouble and that are not
    # covered by the patterns
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)

# Generated at 2022-06-23 05:17:04.904852
# Unit test for function parse_address
def test_parse_address():

    class CASES:
        """
        The input variables are a single string and a flag that determines
        whether [x:y] range expressions are allowed. The output variables are
        a host/IP identifier and a port number, both of which may be None.
        """


# Generated at 2022-06-23 05:17:16.392683
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com:1234') == ('foo.example.com', 1234)
    assert parse_address('foo.example.com:1234', allow_ranges=True) == ('foo.example.com', 1234)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('192.0.2.3:1234') == ('192.0.2.3', 1234)
    assert parse_address('192.0.2.3:1234', allow_ranges=True) == ('192.0.2.3', 1234)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)

# Generated at 2022-06-23 05:17:28.680543
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest

    class TestParseAddress(unittest.TestCase):

        def test_hostnames(self):
            self.assertRejects("foo:bar",
                               "Not a valid network hostname: foo:bar")
            self.assertRejects("foo[1:2]:bar",
                               "Not a valid network hostname: foo[1:2]:bar")
            self.assertAccepts("foo", "foo", None)
            self.assertAccepts("foo.example.com", "foo.example.com", None)
            self.assertAccepts("foo[1:2]", "foo[1:2]", None)
            self.assertAccepts("foo[1:2].example.com", "foo[1:2].example.com", None)
            self

# Generated at 2022-06-23 05:17:39.231213
# Unit test for function parse_address
def test_parse_address():
    # These should all succeed.
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo.example.com:123') == ('foo.example.com', 123)
    assert parse_address('192.168.0.1:123') == ('192.168.0.1', 123)
    assert parse_address('2001:db8::1:123') == ('2001:db8::1', 123)
    assert parse_address('[2001:db8::1]:123') == ('2001:db8::1', 123)
    assert parse_address('[2001:db8::1]:123', allow_ranges=True) == ('2001:db8::1', 123)

# Generated at 2022-06-23 05:17:48.896752
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('somehost.example.com') == ('somehost.example.com', None)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('2001:db8::1:22') == ('2001:db8::1:22', None)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)

# Generated at 2022-06-23 05:18:01.091131
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:09.525841
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('foo[1:3].example.com:80') == ('foo[1:3].example.com', 80)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[0:5]-bar[x-z].example.com') == ('foo[0:5]-bar[x-z].example.com', None)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('[example.com]') == ('example.com', None)

# Generated at 2022-06-23 05:18:19.849035
# Unit test for function parse_address
def test_parse_address():
    from nose.tools import assert_raises
    from ansible.errors import AnsibleError, AnsibleParserError

    assert parse_address("myhostname") == ("myhostname", None)
    assert parse_address("myhostname.com") == ("myhostname.com", None)
    assert parse_address("myhostname.com:22") == ("myhostname.com", 22)
    assert parse_address("192.0.2.3") == ("192.0.2.3", None)
    assert parse_address("192.0.2.3:22") == ("192.0.2.3", 22)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:22") == ("::1", 22)

# Generated at 2022-06-23 05:18:29.696689
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:40.587759
# Unit test for function parse_address
def test_parse_address():
    '''
    Network address parsing
    '''
    import unittest
    test = unittest.TestCase()

    # We do not support IPv4 shorthand notation.

# Generated at 2022-06-23 05:18:49.678166
# Unit test for function parse_address
def test_parse_address():
    # missing brackets for IPv6
    assert parse_address("fe80::a00:27ff:fe19:69e7") == (None, None)

    # missing brackets for IPv6 with port specified
    assert parse_address("fe80::a00:27ff:fe19:69e7:22") == (None, None)

    # valid IPv6 with port
    assert parse_address("[fe80::a00:27ff:fe19:69e7]:22") == ("fe80::a00:27ff:fe19:69e7", 22)

    # valid IPv6
    assert parse_address("[fe80::a00:27ff:fe19:69e7]") == ("fe80::a00:27ff:fe19:69e7", None)

    # valid IPv6

# Generated at 2022-06-23 05:18:59.216973
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('a') == ('a', None)
    assert parse_address('a:1') == ('a', 1)
    assert parse_address('[a]:1') == ('[a]', 1)
    assert parse_address('[a:1]:1') == ('[a:1]', 1)
    assert parse_address('[a:1:1]:1') == ('[a:1:1]', 1)
    assert parse_address('[a-c]:1') == ('[a-c]', 1)
    assert parse_address('[a-c:1]:1') == ('[a-c:1]', 1)
    assert parse_address('[a-c:1:1]:1') == ('[a-c:1:1]', 1)


# Generated at 2022-06-23 05:19:08.952356
# Unit test for function parse_address
def test_parse_address():
    import pytest
    from ansible.module_utils.connection import Connection
    from ansible.parsing.splitter import parse_address

    def test_parse_address(address, host, port, allow_ranges=False):
        assert (host, port) == parse_address(address, allow_ranges)

    def test_parse_address_range_error(address, host, port, allow_ranges=False):
        with pytest.raises(AnsibleParserError):
            parse_address(address, allow_ranges)

    def test_parse_address_error(address, host, port, allow_ranges=False):
        with pytest.raises(AnsibleError):
            parse_address(address, allow_ranges)

    # Addresses without ports

# Generated at 2022-06-23 05:19:19.840345
# Unit test for function parse_address
def test_parse_address():
    # Simple tests for IPv4 and IPv6 addresses.
    assert parse_address('192.0.2.1', False) == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:1234', False) == ('192.0.2.1', 1234)
    assert parse_address('[2001:db8::1]:1234', False) == ('2001:db8::1', 1234)
    assert parse_address('2001:db8::1', False) == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]', False) == ('2001:db8::1', None)

    # Example IPv4 host-with-port from the documentation.

# Generated at 2022-06-23 05:19:31.267181
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:41.401405
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest

    class TestParseAddress(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None


# Generated at 2022-06-23 05:19:48.407495
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:58.769682
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:08.725410
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("127.0.0.1", allow_ranges=False) == ('127.0.0.1', None)
    assert parse_address("127.0.0.1", allow_ranges=True) == ('127.0.0.1', None)
    assert parse_address("127.0.0.1:80", allow_ranges=False) == ('127.0.0.1', 80)
    assert parse_address("127.0.0.1:80", allow_ranges=True) == ('127.0.0.1', 80)
    assert parse_address("[::1]", allow_ranges=False) == ('::1', None)
    assert parse_address("[::1]", allow_ranges=True) == ('::1', None)

# Generated at 2022-06-23 05:20:19.349612
# Unit test for function parse_address
def test_parse_address():
    for host, port in ['localhost:5984', '127.0.0.1:5984', '::1:5984', '[::1]:5984']:
        (h, p) = parse_address(host, True)
        assert h == host, "expected %s, got %s\n" % (host, h)
        assert p == port, "expected %s, got %s\n" % (port, p)

    for host, port in ['localhost', '127.0.0.1', '::1', '[::1]']:
        (h, p) = parse_address(host, True)
        assert h == host, "expected %s, got %s\n" % (host, h)
        assert p == None, "expected %s, got %s\n" % (None, p)


# Generated at 2022-06-23 05:20:30.395823
# Unit test for function parse_address
def test_parse_address():
    """Test function parse_address."""

    # Test the port-extraction logic
    assert parse_address('example.com:10') == ('example.com', 10)
    assert parse_address('[dead::beef]:22') == ('[dead::beef]', 22)
    assert parse_address('192.0.2.1:33') == ('192.0.2.1', 33)
    assert parse_address('[192.0.2.1]:22') == ('[192.0.2.1]', 22)
    assert parse_address('[::192.0.2.1]:22') == ('[::192.0.2.1]', 22)

# Generated at 2022-06-23 05:20:41.930206
# Unit test for function parse_address
def test_parse_address():
    # Note: When testing, don't trust the function to validate input.

    # Valid hosts and IP addresses, with and without port numbers
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address('foo:12') == ('foo', 12)
    assert parse_address('foo:1.2') == ('foo', 1)
    assert parse_address('foo:bar') == ('foo:bar', None)

    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:') == ('192.0.2.3', None)

# Generated at 2022-06-23 05:20:46.200253
# Unit test for function parse_address
def test_parse_address():
    for host in (
            'bar.baz.com', 'foo', '[1:2:3::4]', '1:2:3::4',
            '192.168.1.1', '192.168.1.1[1:3]', '192.168.1.1[1:3]:22'):
        assert(parse_address(host) == (host, None))

    with open('tests/units/parsing/host_resolve/ipv6_hosts', 'r') as ipv6_hosts:
        for host in ipv6_hosts.read().split():
            assert(parse_address(host) == (host, None))


# Generated at 2022-06-23 05:20:56.587695
# Unit test for function parse_address
def test_parse_address():
    """
    Test drive the parse_address function.

    :return: None
    """
    # should parse ipv4 address with and without port
    assert parse_address("127.0.0.1") == ('127.0.0.1', None)
    assert parse_address("127.0.0.1:22") == ('127.0.0.1', 22)

    # should parse ipv6 address with and without port
    assert parse_address("[::1]") == ('::1', None)
    assert parse_address("[::1]:22") == ('::1', 22)

    # should parse hostname with and without port
    assert parse_address("example.org") == ("example.org", None)
    assert parse_address("example.org:22") == ("example.org", 22)

    # should raise an

# Generated at 2022-06-23 05:21:07.706559
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('hostname.example') == ('hostname.example', None)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('1.2.3.4:5678') == ('1.2.3.4', 5678)
    assert parse_address('[::1]:5678') == ('::1', 5678)
    assert parse_address('[1.2.3.4]:5678') == ('1.2.3.4', 5678)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)

# Generated at 2022-06-23 05:21:19.179924
# Unit test for function parse_address
def test_parse_address():
    from nose.tools import assert_equals, assert_true

    # IPv4 (dot-separated decimals + optional port)
    assert_equals(parse_address('192.0.2.1'), ('192.0.2.1', None))
    # ...with a port
    assert_equals(parse_address('192.0.2.1:65535'), ('192.0.2.1', 65535))
    # ...with a port and bracketed IPv4
    assert_equals(parse_address('192.0.2.1:65535'), ('192.0.2.1', 65535))
    # ...with a port and bracketed IPv4, optionally omitting the brackets