

# Generated at 2022-06-23 05:11:22.177710
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:20000') == ('127.0.0.1', 20000)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:') == (None, None)
    assert parse_address('127.0.0.1:10') == ('127.0.0.1', 10)
    assert parse_address('[::1]:20') == ('::1', 20)
    assert parse_address('[::1]:20', True) == ('::1', 20)
    assert parse_address('[::1]:') == (None, None)
    assert parse_address('[::1]') == (None, None)

# Generated at 2022-06-23 05:11:29.424133
# Unit test for function parse_address
def test_parse_address():
    def validate_parse(address, host, port):
        (h, p) = parse_address(address, allow_ranges=False)
        assert h == host, "address %s: host %s != %s" % (address, h, host)
        assert p == port, "address %s: port %s != %s" % (address, p, port)

    # An IPv4 address with no port
    validate_parse("1.2.3.4", "1.2.3.4", None)

    # An IPv4 address with a port
    validate_parse("1.2.3.4:5678", "1.2.3.4", 5678)

    # An IPv6 address
    validate_parse("[2001:db8::5678]", "2001:db8::5678", None)

    # An

# Generated at 2022-06-23 05:11:38.082699
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:48.844458
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:00.871058
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:10.257678
# Unit test for function parse_address
def test_parse_address():

    # IPv4 without port
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)

    # IPv6 literal without port
    assert parse_address('2001:db8::') == ('2001:db8::', None)

    # IPv4 with port
    assert parse_address('192.168.1.1:22') == ('192.168.1.1', 22)

    # IPv6 literal with port
    assert parse_address('[2001:db8::]:22') == ('2001:db8::', 22)

    # IPv6 literal in brackets with port
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)

    # IPv6 literal with numeric range

# Generated at 2022-06-23 05:12:19.826643
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:29.356962
# Unit test for function parse_address
def test_parse_address():
    assert (('foo', None) == parse_address('foo'))
    assert (('foo', None) == parse_address('foo', allow_ranges=True))
    assert (('foo.example.com', None) == parse_address('foo.example.com'))
    assert (('[::1]', 6379) == parse_address('[::1]:6379'))
    assert (('127.0.0.1', 6379) == parse_address('127.0.0.1:6379'))
    assert (('127.0.0.1', 6379) == parse_address('[127.0.0.1]:6379'))
    assert (('foo[0:7]-bar', 6379) == parse_address('foo[0:7]-bar:6379'))

# Generated at 2022-06-23 05:12:41.560331
# Unit test for function parse_address
def test_parse_address():
    from ansible.plugins.inventory.ini import InventoryModule

    # For each test case, we expect the function to return a 2-tuple: the
    # expected host specification, and the expected port number. The latter
    # will be None if no port was specified, or if the host could not be parsed
    # at all.


# Generated at 2022-06-23 05:12:50.527189
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:59.397031
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:10.633248
# Unit test for function parse_address
def test_parse_address():
    """
    Test the parser for host and port strings.
    """

    #
    # Test cases:
    #
    # Format:
    # ( in, (host, port), is_range )
    #
    # The first component is the input string.
    # The second component is the expected (host, port) tuple.
    # The third component is a flag whether a range has been detected.
    #


# Generated at 2022-06-23 05:13:21.654986
# Unit test for function parse_address
def test_parse_address():
    def do_test(address, port, host):
        assert parse_address(address) == (host, port)

    do_test('foo', None, 'foo')
    do_test('foo:bar', None, 'foo')
    do_test('foo:123', 123, 'foo')
    do_test('foo:', None, 'foo')
    do_test('foo:0', 0, 'foo')
    do_test('foo:65535', 65535, 'foo')
    do_test('foo:65536', None, 'foo')
    do_test('foo:bar:123', None, 'foo')

    do_test('1.2.3.4', None, '1.2.3.4')

# Generated at 2022-06-23 05:13:33.349676
# Unit test for function parse_address
def test_parse_address():
    def test(s, allow_ranges, exp_address, exp_port):
        got_address, got_port = parse_address(s, allow_ranges=allow_ranges)
        assert got_address == exp_address and got_port == exp_port, \
            "parse_address(%s, allow_ranges=%s) got (%s, %s) instead of (%s, %s)" % \
            (s, allow_ranges, got_address, got_port, exp_address, exp_port)

    # Failure cases
    # The following should raise an exception (not match).

# Generated at 2022-06-23 05:13:45.104420
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:53.813559
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.network import is_valid_ipv6

# Generated at 2022-06-23 05:14:03.811793
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:512') == ('::1', 512)
    assert parse_address('[::1]:0') == ('::1', 0)
    assert parse_address('[::1]:65535') == ('::1', 65535)
    assert parse_address('[::1]:65536') == (None, None)
    assert parse_address('[::1]:abc') == (None, None)
    assert parse_address('[::1]:') == (None, None)
    assert parse_address('[1::1]') == (None, None)
    assert parse_address('[1::1]:512') == (None, None)


# Generated at 2022-06-23 05:14:14.682320
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:23.857263
# Unit test for function parse_address
def test_parse_address():
    # expected valid input
    assert parse_address('[::1]:1') == (u'::1', 1)
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1:65535]') == (u'::1:65535', None)
    assert parse_address('[::1:65535:255]') == (u'::1:65535:255', None)
    assert parse_address('[::1:65535:255]', allow_ranges=True) == (u'::1:65535:255', None)
    assert parse_address('[::1:65535:255]', allow_ranges=False) == (u'::1:65535:255', None)

# Generated at 2022-06-23 05:14:35.262077
# Unit test for function parse_address
def test_parse_address():
    # Valid addresses
    assert parse_address('[::1]')            == (':1', None)
    assert parse_address('[::1]:80')         == (':1', 80)
    assert parse_address('127.0.0.1')        == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:80')     == ('127.0.0.1', 80)
    assert parse_address('localhost')        == ('localhost', None)
    assert parse_address('localhost:80')     == ('localhost', 80)
    assert parse_address('foo[1:2]')         == ('foo1', None)
    assert parse_address('foo[2:3]:80')      == ('foo2', 80)

# Generated at 2022-06-23 05:14:45.834533
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.15:80') == ('192.0.2.15', 80)
    assert parse_address('[2001:db8::ff00:42]:80') == ('2001:db8::ff00:42', 80)
    assert parse_address('[192.0.2.15:80]') == ('192.0.2.15:80', None)
    assert parse_address('foo.example.com:80') == ('foo.example.com', 80)
    assert parse_address('[foo.example.com:80]') == ('foo.example.com', 80)
    assert parse_address('[2001:db8::ff00:42]') == ('2001:db8::ff00:42', None)

# Generated at 2022-06-23 05:14:55.688775
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:80') == ('foo.example.com', 80)
    assert parse_address('foo[0:2].example.com:80') == ('foo[0:2].example.com', 80)
    assert parse_address('foo:bar[0:2].example.com:80') == ('foo:bar[0:2].example.com', 80)
    assert parse_address('[foo.example.com]') == ('foo.example.com', None)
    assert parse_address('[foo.example.com]:80') == ('foo.example.com', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse

# Generated at 2022-06-23 05:15:05.889369
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:17.127238
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:27.351827
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:39.123382
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:46.017081
# Unit test for function parse_address
def test_parse_address():
    def test(address, host, port):
        h, p = parse_address(address)
        assert p == port, "%s: port %d != parsed %d" % (address, port, p)
        assert h == host, "%s: host %s != parsed %s" % (address, host, h)

    test('localhost', 'localhost', None)
    test('localhost:22', 'localhost', 22)
    test('[::1]', '::1', None)
    test('[::1]:22', '::1', 22)
    test('192.0.2.1', '192.0.2.1', None)
    test('192.0.2.1:22', '192.0.2.1', 22)

# Generated at 2022-06-23 05:15:57.879618
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(':') == (None, None)
    assert parse_address('[1.2.3.4]:5') == ('1.2.3.4', 5)
    assert parse_address('a[0:1]:2') == ('a[0:1]', 2)
    assert parse_address('a1.b2.c3.d4') == ('a1.b2.c3.d4', None)
    assert parse_address('a1.b2.c3.d4:5') == ('a1.b2.c3.d4', 5)
    assert parse_address('a1-b2-c3-d4-e5-f6-abcd:1234') == ('a1-b2-c3-d4-e5-f6-abcd', 1234)

# Generated at 2022-06-23 05:16:07.409771
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('') == (None, None)
    assert parse_address(None) == (None, None)
    assert parse_address('::1') == (None, None)
    assert parse_address('::1', True) == ("::1", None)
    assert parse_address('[::1]') == ("::1", None)
    assert parse_address('[::1]:2') == ("::1", 2)
    assert parse_address('[::1]:2', True) == ("::1", 2)
    assert parse_address(':') == (None, None)
    assert parse_address('[]:') == (None, None)
    assert parse_address('[:]:2') == (None, 2)
    assert parse_address('[::1[') == (None, None)

# Generated at 2022-06-23 05:16:13.631413
# Unit test for function parse_address
def test_parse_address():
    from pprint import pprint

    def check(address, host, port):
        (h, p) = parse_address(address)
        assert h == host
        assert p == port, (address, port, p)

    foo123 = 'foo123'
    foo099 = 'foo099'
    foo099port = 'foo099:22'
    foo123noport = 'foo123'
    foo123port = 'foo123:22'
    foo123ipv4 = 'foo123.example.com'
    foo123ipv4noport = 'foo123.example.com'
    foo123ipv4port = 'foo123.example.com:22'
    foo123pattern = 'foo1[0:2]3'
    foo123patternnoport = 'foo1[0:2]3'

# Generated at 2022-06-23 05:16:21.748061
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("192.168.1.2") == ('192.168.1.2', None)
    assert parse_address("192.168.1.2:80") == ('192.168.1.2', 80)
    assert parse_address("[192.168.1.2]") == ('192.168.1.2', None)
    assert parse_address("[192.168.1.2]:80") == ('192.168.1.2', 80)
    assert parse_address("[01:23::45]") == ('01:23::45', None)
    assert parse_address("[01:23::45]:80") == ('01:23::45', 80)
    assert parse_address("foo.example.com") == ('foo.example.com', None)

# Generated at 2022-06-23 05:16:31.726220
# Unit test for function parse_address
def test_parse_address():
    try:
        assert parse_address('')
    except:
        pass
    else:
        raise AssertionError('Empty string should not be a valid network address')

    try:
        assert parse_address('foo') == ('foo', None)
    except:
        raise AssertionError('foo should be a valid network address')

    try:
        assert parse_address('foo:22') == ('foo', 22)
    except:
        raise AssertionError('foo:22 should be a valid network address')

    try:
        assert parse_address('foo:22:bar:33')
    except:
        pass
    else:
        raise AssertionError('foo:22:bar:33 should not be a valid network address')


# Generated at 2022-06-23 05:16:39.420233
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:51.723004
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:03.779695
# Unit test for function parse_address
def test_parse_address():

    # Some host-only examples.
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('[::1]') == ('[::1]', None)
    assert parse_address('foo[0:2]') == ('foo[0:2]', None)
    assert parse_address('foo[xyz]') == ('foo[xyz]', None)

    # Some host:port examples.
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:2222') == ('127.0.0.1', 2222)

# Generated at 2022-06-23 05:17:11.952214
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:20.672783
# Unit test for function parse_address
def test_parse_address():
    """
    parse_address() unit tests
    """

# Generated at 2022-06-23 05:17:26.899573
# Unit test for function parse_address
def test_parse_address():

    # host, port
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)
    assert parse_address('2001:db8::1:22') == ('2001:db8::1', 22)

    # host, port (

# Generated at 2022-06-23 05:17:36.131268
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:46.777990
# Unit test for function parse_address
def test_parse_address():
    # Basic host:port and [host]:port examples
    assert ('foo.example.com', 1234) == parse_address('foo.example.com:1234')
    assert ('1.2.3.4', 1234) == parse_address('[1.2.3.4]:1234')
    assert ('::dead:beef', 1234) == parse_address('[::dead:beef]:1234')

    # Simple bracket-enclosed IPv4 and IPv6 addresses
    assert ('[1.2.3.4]', 5678) == parse_address('[1.2.3.4]:5678')
    assert ('[::dead:beef]', 5678) == parse_address('[::dead:beef]:5678')

    # Bracket-enclosed IPv4 addresses and IPv6 addresses with port numbers

# Generated at 2022-06-23 05:17:56.722408
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost:1234') == ('localhost', 1234)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost[0-9]') == ('localhost[0-9]', None)
    assert parse_address('[::1]:1234') == ('::1', 1234)
    assert parse_address('192.168.11.0:1234') == ('192.168.11.0', 1234)
    assert parse_address('[192.168.11.0]:1234') == ('192.168.11.0', 1234)
    assert parse_address('192.168.11.0[1-2]:1234') == ('192.168.11.0[1-2]', 1234)

# Generated at 2022-06-23 05:18:07.063804
# Unit test for function parse_address
def test_parse_address():

    def check_success(s, host, port=None):
        assert parse_address(s) == (host, port)

    def check_failure(s):
        try:
            parse_address(s)
            assert False
        except AnsibleError:
            pass

    check_success('example.com', 'example.com')
    check_success('example.com:443', 'example.com', 443)
    check_success('example.com:443', 'example.com', 443)
    check_success('example.com:0', 'example.com', 0)
    check_success('example.com:65535', 'example.com', 65535)
    check_failure('example.com:65536')
    check_failure('example.com:x')
    check_failure('example.com:')
   

# Generated at 2022-06-23 05:18:17.860748
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:26.765800
# Unit test for function parse_address
def test_parse_address():
    import pytest

    a = pytest.raises(AnsibleError, parse_address, "not_a_valid_hostname")
    assert str(a.value) == "Not a valid network hostname: not_a_valid_hostname"

    assert parse_address("foo:80") == ("foo", 80)
    assert parse_address("[::ffff:192.0.2.3]:80") == ("::ffff:192.0.2.3", 80)
    assert parse_address("[1ab:2cd::1]:80") == ("1ab:2cd::1", 80)
    assert parse_address("[1.2.3.4]:80") == ("1.2.3.4", 80)

# Generated at 2022-06-23 05:18:34.709525
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:44.281859
# Unit test for function parse_address
def test_parse_address():
    # Parse IPv4 addresses
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)

    # Parse IPv6 addresses
    assert parse_address('1:2:3:4:5:6:7:8') == ('1:2:3:4:5:6:7:8', None)
    assert parse_address('[1:2:3:4:5:6:7:8]:22') == ('1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-23 05:18:54.334605
# Unit test for function parse_address
def test_parse_address():
    "Parse host:port strings"

    def assert_parse_address(text, expected, allow_ranges=False):
        result = parse_address(text, allow_ranges)
        if result != expected:
            raise AssertionError("%s != %s" % (result, expected))

    # A valid, bracketed IPv6 address.
    assert_parse_address(
        '[fe80::1%lo0]:2222',
        ('fe80::1%lo0', 2222),
    )

    # A valid IPv4 address with a port number.
    assert_parse_address(
        '192.0.2.1:2222',
        ('192.0.2.1', 2222),
    )

    # A valid, bracketed IPv4 address with a port number.

# Generated at 2022-06-23 05:19:05.544168
# Unit test for function parse_address
def test_parse_address():
    #
    # Examples of valid hostname patterns
    #
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:9999") == ("localhost", 9999)
    assert parse_address("foo[1:20]") == ("foo[1:20]", None)
    assert parse_address("[2001::]:22") == ("[2001::]", 22)
    assert parse_address("foo[1:20]:9999") == ("foo[1:20]", 9999)
    assert parse_address("[2001::]:22:22") == ("[2001::]:22", None)
    assert parse_address("192.0.2.0:22:22:22:22:22:22:22") == ("192.0.2.0", 22)

    #
    # Examples of invalid hostname patterns

# Generated at 2022-06-23 05:19:15.083577
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:23') == ('192.0.2.3', 23)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:23') == ('192.0.2.3', 23)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:23') == ('example.com', 23)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:23') == ('example.com', 23)

# Generated at 2022-06-23 05:19:27.949306
# Unit test for function parse_address
def test_parse_address():
    print("Testing function parse_address:")

# Generated at 2022-06-23 05:19:36.140013
# Unit test for function parse_address
def test_parse_address():
    def _test(s, expected_host, expected_port=None, allow_ranges=False):
        host, port = parse_address(s, allow_ranges=allow_ranges)
        assert host == expected_host
        assert port == expected_port
        return host, port

    # make sure we can parse with a unix style socket file
    _test('/foo/bar:123', '/foo/bar', 123)
    _test('/foo/bar', '/foo/bar', None)

    # simple hostnames with ports
    _test('localhost:22', 'localhost', 22)
    _test('ansible.com:80', 'ansible.com', 80)

    # hostnames with '-' in them
    _test('web-001.example.com:80', 'web-001.example.com', 80)
   

# Generated at 2022-06-23 05:19:44.695676
# Unit test for function parse_address
def test_parse_address():
    pa = parse_address
    pae = AnsibleError

    assert pa('1.2.3.4') == ('1.2.3.4', None)
    assert pa('1.2.3.4:5') == ('1.2.3.4', 5)
    assert pa('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)
    assert pa('[::ffff:192.0.2.3]:5') == ('::ffff:192.0.2.3', 5)
    assert pa('[::ffff:192.0.2.3]:05') == ('::ffff:192.0.2.3', 5)
    assert pa('foo.example.com') == ('foo.example.com', None)

# Generated at 2022-06-23 05:19:56.664789
# Unit test for function parse_address
def test_parse_address():
    # Some examples from the Ansible documentation
    test_address = [
        ('example.com', None),
        ('example.com:80', 80),
        ('[1:2:3:4:5:6:7:8]:53', 53),
        ('[1:2:3:4:5:6:7:8]', None),
        ('1:2:3:4:5:6:7:8', None),
        ('192.168.1.1', None),
        ('192.168.1.1:25', 25),
        ('[2001:db8:a0b:12f0::1]', None),
        ('[2001:db8:a0b:12f0::1]:80', 80),
    ]

# Generated at 2022-06-23 05:20:07.094212
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_unparseables(self):
            inputs = [
                '', '99.99.99.99.99', '55:66', 'xyz', '1.2.3.4.5',
                'foo.example.com:999999999', '2001:db8::1:-1',
                'localhost:abc', '[localhost:0]', '[localhost:65536]',
                '[127.0.0.1]:65536', '[2001:db8::1]:65536',
                '[::1]:65536', '[::ffff:192.0.2.1]:65536',
                '[::ffff:ffff:192.0.2.1]:65536'
            ]

# Generated at 2022-06-23 05:20:18.695892
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:5309') == ('192.0.2.1', 5309)
    assert parse_address('[2001:db8::192.0.2.42]') == ('[2001:db8::192.0.2.42]', None)
    assert parse_address('[2001:db8::192.0.2.42]:5309') == ('[2001:db8::192.0.2.42]', 5309)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:5309') == ('example.com', 5309)

# Generated at 2022-06-23 05:20:30.362392
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:38.645755
# Unit test for function parse_address
def test_parse_address():
    import nose

    def assertParseAddressReturns(input, expected):
        actual = parse_address(input)
        nose.tools.eq_(actual, expected)

    assertParseAddressReturns("localhost", ("localhost", None))
    assertParseAddressReturns("localhost:123", ("localhost", 123))
    assertParseAddressReturns("localhost[0:6]", ("localhost[0:6]", None))
    assertParseAddressReturns("localhost[0:6]:123", ("localhost[0:6]", 123))
    assertParseAddressReturns("[::]", ("[::]", None))
    assertParseAddressReturns("[::]:123", ("[::]", 123))
    assertParseAddressReturns("[::]:123", ("[::]", 123))

# Generated at 2022-06-23 05:20:50.666710
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:00.554972
# Unit test for function parse_address
def test_parse_address():
    # Note that the test suite will only run if you have pytest installed:
    #   http://pytest.org/latest/getting-started.html#installation
    #
    # To run the unit tests, then:
    #  $ py.test test_ansible_inventory.py

    def assert_address(address, host, port):
        assert parse_address(address) == (host, port)

    def assert_failure(address):
        try:
            parse_address(address)
        except Exception as e:
            return e.args[0]
        else:
            assert False, "Should have failed"

    def assert_allow_range(address, host, port):
        assert parse_address(address, allow_ranges=True) == (host, port)


# Generated at 2022-06-23 05:21:07.301472
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:23') == ('foo', 23)
    assert parse_address('foo:23:a') == ('foo:23:a', None)
    assert parse_address('127.0.0.1:23') == ('127.0.0.1', 23)
    assert parse_address('127.0.0.1:23:a') == ('127.0.0.1:23:a', None)
    assert parse_address('[fe80::ce4b:c4ff:fe4d:4b4a]:23') == ('fe80::ce4b:c4ff:fe4d:4b4a', 23)

# Generated at 2022-06-23 05:21:18.349023
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:1234") == ("foo.example.com", 1234)
    assert parse_address("foo.example.com[x:z]") == ("foo.example.com[x:z]", None)
    assert parse_address("foo.example.com[x:z]:1234") == ("foo.example.com[x:z]", 1234)
    assert parse_address("192.168.1.1") == ("192.168.1.1", None)
    assert parse_address("192.168.1.1:1234") == ("192.168.1.1", 1234)