

# Generated at 2022-06-23 05:11:23.680626
# Unit test for function parse_address
def test_parse_address():

    # basic/well-formed IP and IPv6 addresses
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:22') == ('192.168.1.1', 22)
    assert parse_address('[192.168.1.1]:22') == ('192.168.1.1', 22)
    assert parse_address('[::1]:22') == ('::1', 22)

    # IPv6 addresses with ranges
    assert parse_address('[1::1][2]:22', allow_ranges=True) == ('1::1[2]', 22)
    assert parse_address('[1::1[0:4]]:22', allow_ranges=True) == ('1::1[0:4]', 22)

# Generated at 2022-06-23 05:11:35.605166
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:46.842164
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:55.844485
# Unit test for function parse_address
def test_parse_address():
    def t(allowed, expected_host, expected_port, address, expected_error=None):
        print(address)
        if allowed:
            try:
                host, port = parse_address(address, allow_ranges=True)
                assert host == expected_host and port == expected_port
            except AnsibleParserError as e:
                    assert "Detected range in host but was asked to ignore ranges" == str(e)
        else:
            try:
                host, port = parse_address(address, allow_ranges=False)
                assert False
            except AnsibleParserError as e:
                assert "Detected range in host but was asked to ignore ranges" == str(e)

    t(True, '[localhost]', 22, "[localhost]:22")
    t(True, 'localhost', None, "localhost")

# Generated at 2022-06-23 05:12:00.621475
# Unit test for function parse_address
def test_parse_address():
    import sys
    import doctest

    failures, tests = doctest.testmod(sys.modules[__name__])
    if failures:
        raise AnsibleParserError("Doctest failures: %d" % failures)

    return failures, tests

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-23 05:12:09.389210
# Unit test for function parse_address
def test_parse_address():
    '''Test helper function parse_address()'''
    # Test with 'allow_ranges' False
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127[0:1].0[0:1].0[0:1].1:22') == ('127[0:1].0[0:1].0[0:1].1', 22)
    assert parse_address('localhost:65535') == ('localhost', 65535)
    assert parse_address('127.0.0.1:65535') == ('127.0.0.1', 65535)
    assert parse_address('::1:22') == ('::1', 22)

# Generated at 2022-06-23 05:12:13.660423
# Unit test for function parse_address
def test_parse_address():
    """
    Validate that we can parse the various forms of host:port, IPv4, IPv6, and
    hostname that we expect to see in a standard inventory file. We can't assert
    the expected results in a portable manner, so we just call and make sure we
    don't get an exception.
    """

    # Some basic host:port tests
    assert parse_address('host:22')
    assert parse_address('host:22')[1] == 22
    assert parse_address('host:222')[1] == 222
    assert parse_address('host:2')[1] == 2

    # Test IPv4 addresses and ranges
    assert parse_address('192.0.2.3')
    assert parse_address('192.0.2.3', allow_ranges=True)

# Generated at 2022-06-23 05:12:25.106346
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:33.757077
# Unit test for function parse_address
def test_parse_address():
    # = regular cases =
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('host[1:3]') == ('host[1:3]', None)
    assert parse_address('host[1:3]:22') == ('host[1:3]', 22)
    assert parse_address('host[0:5]-bar[x-z]:22') == ('host[0:5]-bar[x-z]', 22)
    assert parse_address('[localhost]:22') == ('localhost', 22)
    assert parse_address('[localhost]') == ('localhost', None)
    # = IPv4 regular ranges =

# Generated at 2022-06-23 05:12:45.656892
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:55.642743
# Unit test for function parse_address
def test_parse_address():
    """
    This function returns True if parse_address() passes its unit tests,
    False otherwise.
    """

    # Function to call parse_address() and check what it returns
    def check(address, host, port):
        (h, p) = parse_address(address)
        return h == host and p == port

    # The tests
    if not check("localhost", "localhost", None):
        return False

    if not check("localhost:80", "localhost", 80):
        return False

    if not check("[fec0::1]", "fec0::1", None):
        return False

    if not check("[fec0::1]:80", "fec0::1", 80):
        return False

    if not check("foo.example.com", "foo.example.com", None):
        return False

   

# Generated at 2022-06-23 05:13:06.769623
# Unit test for function parse_address
def test_parse_address():
    # no host
    (host, port) = parse_address('[::1]:2222')
    assert host == '[::1]'
    assert port == 2222

    # ipv4
    (host, port) = parse_address('192.168.1.1')
    assert host == '192.168.1.1'
    assert port == None
    (host, port) = parse_address('192.168.1.1:2222')
    assert host == '192.168.1.1'
    assert port == 2222

    # ipv4 ranges
    (host, port) = parse_address('[192.168.1.1:192.168.1.4]:2222', allow_ranges=True)
    assert host == '[192.168.1.1:192.168.1.4]'
   

# Generated at 2022-06-23 05:13:16.404716
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:24.174192
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('::1:22') == ('::1', 22)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == (None, None)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.bar:22') == ('foo.bar', 22)
    assert parse_address('[foo.bar]:22') == ('foo.bar', 22)
    assert parse_address('[foo.bar][0:3]:22') == ('foo.bar[0:3]', 22)

# Generated at 2022-06-23 05:13:34.972109
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address("foo.example.com:22")
    assert host == "foo.example.com"
    assert port == 22

    (host, port) = parse_address("192.168.1.1")
    assert host == "192.168.1.1"
    assert port is None

    (host, port) = parse_address("192.168.1.1:22")
    assert host == "192.168.1.1"
    assert port == 22

    (host, port) = parse_address("192.168.1.1:22", allow_ranges=True)
    assert host == "192.168.1.1"
    assert port == 22

    (host, port) = parse_address("192.168.1.1:22", allow_ranges=False)
   

# Generated at 2022-06-23 05:13:46.541291
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('foo.example.com')
    assert (host, port) == ('foo.example.com', None)

    (host, port) = parse_address('foo.example.com:10022')
    assert (host, port) == ('foo.example.com', 10022)

    (host, port) = parse_address('example.com')
    assert (host, port) == ('example.com', None)

    (host, port) = parse_address('example.com:10022')
    assert (host, port) == ('example.com', 10022)

    (host, port) = parse_address('192.0.2.3')
    assert (host, port) == ('192.0.2.3', None)


# Generated at 2022-06-23 05:13:52.898570
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:03.262186
# Unit test for function parse_address
def test_parse_address():
    assert ('10.2.3.4', None) == parse_address('10.2.3.4')
    assert ('10.2.3.4', 5678) == parse_address('10.2.3.4:5678')
    assert ('[10.2.3.4]', 5678) == parse_address('[10.2.3.4]:5678')
    assert ('[fc00:babe::4]', 5678) == parse_address('[fc00:babe::4]:5678')
    assert ('foo.example.com', None) == parse_address('foo.example.com')
    assert ('foo.example.com', 5678) == parse_address('foo.example.com:5678')

# Generated at 2022-06-23 05:14:10.938748
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('')
    assert host is None
    assert port is None

    (host, port) = parse_address('foo')
    assert host == 'foo'
    assert port is None

    (host, port) = parse_address('foo:1234')
    assert host == 'foo'
    assert port == 1234

    (host, port) = parse_address('[foo:1234]')
    assert host == 'foo:1234'
    assert port is None

    (host, port) = parse_address('[foo:1234]:4321')
    assert host == 'foo:1234'
    assert port == 4321

    (host, port) = parse_address('192.0.2.1')
    assert host == '192.0.2.1'

# Generated at 2022-06-23 05:14:20.453492
# Unit test for function parse_address
def test_parse_address():
    # This is a rather stupid and simplistic test.
    # We never expect this to fail, so we only test that no exception is thrown.
    # (This can be improved.)
    parse_address('hostname:22')
    parse_address('hostname.example.com:22')
    parse_address('192.0.2.3:22')
    parse_address('192.0.2.3:22')
    parse_address('[2001:db8::1]:22')
    parse_address('[2001:db8::1]')
    parse_address('[192.0.2.3]:22')
    parse_address('[192.0.2.3]')



# Generated at 2022-06-23 05:14:31.307337
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:43.260442
# Unit test for function parse_address
def test_parse_address():
    from nose.plugins.skip import SkipTest
    raise SkipTest("This test fails")

    from unittest import TestCase
    from collections import namedtuple
    from nose.plugins.attrib import attr
    from nose.tools import raises

    # Simple parsing tests

# Generated at 2022-06-23 05:14:53.894371
# Unit test for function parse_address
def test_parse_address():
    # Basic hostname
    speclist = ['foo', 'foo.example.com']
    for spec in speclist:
        (host, port) = parse_address(spec)
        assert host == spec
        assert port is None

    # Basic IPv4 address
    speclist = ['192.0.2.3', '192.0.2.3:42', '192.0.2[1:5].3:42']
    for spec in speclist:
        (host, port) = parse_address(spec)
        assert host == spec.split(':')[0]
        assert port == 42

    # Bare IPv4 address with port specification
    speclist = ['192.0.2.3:42', '[192.0.2.3]:42']

# Generated at 2022-06-23 05:15:05.194480
# Unit test for function parse_address
def test_parse_address():
    import pytest
    host = None
    port = None

    pytest.raises(AnsibleParserError, parse_address, 'foo[bar', False)
    pytest.raises(AnsibleError, parse_address, 'foo[bar]', False)
    pytest.raises(AnsibleError, parse_address, '[foo]', False)
    pytest.raises(AnsibleError, parse_address, 'example.com:', False)

    host, port = parse_address("localhost", False)
    assert host == 'localhost' and port is None
    host, port = parse_address("nohost", False)
    assert host == 'nohost' and port is None
    host, port = parse_address("localhost:22", False)
    assert host == 'localhost' and port == 22
    host

# Generated at 2022-06-23 05:15:16.790296
# Unit test for function parse_address
def test_parse_address():
    # no trailing colon
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)

    # IPv6 address
    assert parse_address("fe80::1") == ("fe80::1", None)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:22") == ("::1", 22)
    assert parse_address("[fe80::1]:22") == ("fe80::1", 22)

    # IPv4 address
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:22") == ("192.0.2.1", 22)

# Generated at 2022-06-23 05:15:27.289400
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:37.571802
# Unit test for function parse_address
def test_parse_address():

    assert (None, None) == parse_address('x')
    assert ('[x]', 22) == parse_address('[x]:22')
    assert ('x', 22) == parse_address('x:22')
    assert ('x', None) == parse_address('x')
    assert ('x', 22) == parse_address('x:22')
    assert (None, None) == parse_address('x[y]')
    assert (None, None) == parse_address('x[1.2.3.4]')
    assert ('x[1.2.3.4]', 22) == parse_address('x[1.2.3.4]:22')

# Generated at 2022-06-23 05:15:47.899486
# Unit test for function parse_address
def test_parse_address():
    """
    >>> test_parse_address()
    """

# Generated at 2022-06-23 05:15:57.506298
# Unit test for function parse_address
def test_parse_address():
    """
    >>> parse_address("foo[0:1]-bar[0-]")
    ('foo[0:1]-bar[0-]', None)
    >>> parse_address("foo[0:1]-bar[0-]:22")
    ('foo[0:1]-bar[0-]', 22)
    >>> parse_address("foo[0:1]-bar[0-]:22", allow_ranges=True)
    ('foo0-foo1-bar0-bar1-bar2-bar3-bar4-bar5-bar6-bar7-bar8-bar9', 22)
    """
    pass



# Generated at 2022-06-23 05:16:07.055629
# Unit test for function parse_address
def test_parse_address():
    # Tests for bracketed identifiers
    assert parse_address('[::1]') == ("::1", None)
    assert parse_address('[::1]:22') == ("::1", 22)
    assert parse_address('[foo[1:2].example.com]') == ("foo[1:2].example.com", None)
    assert parse_address('[foo[1:2].example.com]:22') == ("foo[1:2].example.com", 22)
    assert parse_address('[2001:db8::9]') == ("2001:db8::9", None)
    assert parse_address('[2001:db8::9]:22') == ("2001:db8::9", 22)
    assert parse_address('[12.34.56.78]') == ("12.34.56.78", None)

# Generated at 2022-06-23 05:16:16.850912
# Unit test for function parse_address
def test_parse_address():
    # pylint: disable=too-many-branches
    answer = (('localhost', None))
    result = parse_address('localhost')
    assert result == answer

    answer = (('localhost', 22))
    result = parse_address('localhost:22')
    assert result == answer

    answer = (('localhost', 22))
    result = parse_address('[localhost]:22')
    assert result == answer

    answer = (('192.0.2.3', 22))
    result = parse_address('192.0.2.3:22')
    assert result == answer

    answer = (('192.0.2.3', None))
    result = parse_address('192.0.2.3')
    assert result == answer

    answer = (('192.0.2.3', 22))

# Generated at 2022-06-23 05:16:27.956754
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)
   

# Generated at 2022-06-23 05:16:39.755231
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('ansible.com') == ('ansible.com', None)
    assert parse_address('ansible.com:22') == ('ansible.com', 22)
    assert parse_address('[ansible.com]') == ('ansible.com', None)
    assert parse_address('[ansible.com]:22') == ('ansible.com', 22)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('1.2.3.4:22', allow_ranges=True) == ('1.2.3.4', 22)
    assert parse_address('[1.2.3.4]')

# Generated at 2022-06-23 05:16:52.195237
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:04.327560
# Unit test for function parse_address
def test_parse_address():

    def check(address, host, port, allow_ranges, error=None):
        if error:
            try:
                parse_address(address, allow_ranges)
                raise AssertionError(
                    "Did not get the expected error: %s" % error
                )
            except AnsibleError as e:
                if error not in str(e):
                    raise AssertionError(
                        "Expected error to contain %s, but got: %s" % (
                            error, e.message
                        )
                    )
        else:
            (actual_host, actual_port) = parse_address(address, allow_ranges)
            assert (actual_host, actual_port) == (host, port)

    check('thisisafakehostname:123', None, None, True, 'Not a valid network hostname')

# Generated at 2022-06-23 05:17:15.014828
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:23.289677
# Unit test for function parse_address
def test_parse_address():

    import ansible.utils.network as network


# Generated at 2022-06-23 05:17:33.125490
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com')                 == ('foo.example.com', None)
    assert parse_address('192.0.2.3:123')                   == ('192.0.2.3', 123)
    assert parse_address('[2001:db8::7]:123')               == ('2001:db8::7', 123)
    assert parse_address('[2001:db8::7]')                   == ('2001:db8::7', None)
    assert parse_address('foo[0:2].example.com[1:3]')       == ('foo[0:2].example.com[1:3]', None)

    # This is a valid IPv6 address, but we don't accept it without square
    # brackets.
    assert parse_address('2001:db8::1')                     == (None, None)

   

# Generated at 2022-06-23 05:17:44.321533
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:51.676973
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ("::1", 22)
    assert parse_address('[::1]') == ("::1", None)
    assert parse_address('10.0.0.1:22') == ("10.0.0.1", 22)
    assert parse_address('10.0.0.1') == ("10.0.0.1", None)
    assert parse_address('host:22') == ("host", 22)
    assert parse_address('host') == ("host", None)
    assert parse_address('[localhost]:22') == ("localhost", 22)
    assert parse_address('[localhost]') == ("localhost", None)
    assert parse_address('[local:hos.t]:22') == ('local:hos.t', 22)

# Generated at 2022-06-23 05:18:01.114412
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('example.com')
    assert host == 'example.com'
    assert port is None

    host, port = parse_address('example.com:5556')
    assert host == 'example.com'
    assert port == 5556

    host, port = parse_address('[2001:db8::]')
    assert host == '2001:db8::'
    assert port is None

    host, port = parse_address('[2001:db8::]:5556')
    assert host == '2001:db8::'
    assert port == 5556


# Generated at 2022-06-23 05:18:09.556052
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:19.878775
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo', False) == ('foo', None)
    assert parse_address('foo:5986', False) == ('foo', 5986)
    assert parse_address('foo:5986', True) == ('foo', 5986)
    assert parse_address('[foo]:5986', True) == ('foo', 5986)
    assert parse_address('[foo]:5986', False) == ('foo', 5986)
    assert parse_address('192.0.2.1', True) == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:5986', True) == ('192.0.2.1', 5986)
    assert parse_address('2001:db8:85a3:8d3:1319:8a2e:370:7348', True)

# Generated at 2022-06-23 05:18:28.215402
# Unit test for function parse_address
def test_parse_address():
    # FIXME: test all valid address types, the error-raising cases, etc.
    assert parse_address('host-name') == ('host-name', None)
    assert parse_address('hostname') == ('hostname', None)
    assert parse_address('hostname:22') == ('hostname', 22)
    assert parse_address('host-name:22') == ('host-name', 22)
    assert parse_address('[host1-10]') == ('host1-10', None)
    assert parse_address('[host1-10]:22') == ('host1-10', 22)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)

# Generated at 2022-06-23 05:18:39.937573
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:50.781056
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:57.944571
# Unit test for function parse_address
def test_parse_address():
    import pytest

    with pytest.raises(AnsibleError):
        assert(parse_address('foo:0/0')) is None

    with pytest.raises(AnsibleError):
        assert(parse_address('192.168.0.10:0/0')) is None

    with pytest.raises(AnsibleError):
        assert(parse_address('192.168.0.10:0/0', True)) is None

    with pytest.raises(AnsibleError):
        assert(parse_address('192.168.0.10', True)) is None

    with pytest.raises(AnsibleParserError):
        assert(parse_address('192.168.0.0-192.168.0.1')) is None


# Generated at 2022-06-23 05:19:08.215455
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:19.400690
# Unit test for function parse_address
def test_parse_address():
    """
    Tests if parse_address behaves as expected with different input.
    """
    # Test cases:
    # First item in tuple is input given to parse_address
    # Second item is expected result in the form (host, port)
    # Third item indicates if ranges are allowed


# Generated at 2022-06-23 05:19:28.301171
# Unit test for function parse_address
def test_parse_address():
    def test(spec, expected_host, expected_port, allow_ranges):
        (host, port) = parse_address(spec, allow_ranges)
        print("%s: host=%s port=%s" % (spec, host, port))
        assert host == expected_host
        assert port == expected_port

    test("foo.example.com", "foo.example.com", None, False)
    test("foo[1:3].example.com", None, None, False)
    test("foo[1:3].example.com", "foo[1:3].example.com", None, True)
    test("1.2.3.4", "1.2.3.4", None, False)

# Generated at 2022-06-23 05:19:37.369459
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:48.229783
# Unit test for function parse_address
def test_parse_address():
    """Check that parse_address returns the expected values."""

    from nose.tools import assert_equal
    import pytest

    # Verify that the regexps match the expected values.
    # We use the function itself to do this, so we can be sure that something
    # is actually parsing them, and we don't have to invent our own parser.

    def validate(r, i, m):
        """
        Given a regexp, a string to match against it, and a dictionary of named
        groups to expected matches, this raises an exception if the match
        doesn't succeed or the named groups don't match the expected values.
        """
        m = re.match(patterns[r], i)
        if not m:
            raise Exception("Regexp %s doesn't match string %s" % (r, i))

# Generated at 2022-06-23 05:19:58.256417
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:08.371836
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:19.188538
# Unit test for function parse_address
def test_parse_address():

    # Hostname with port
    assert parse_address("localhost:22") == ("localhost", 22)

    # IPv4 address with port
    assert parse_address("192.0.2.22:22") == ("192.0.2.22", 22)

    # IPv6 address with port
    assert parse_address("[::1]:22") == ("::1", 22)

    # Deprecated IPv6 address with port
    assert parse_address("::1:22") == ("::1:22", None)

    # Hostname with brackets and port
    assert parse_address("[[[host]host]]host:22") == ("[[[host]host]]host", 22)

    # IPv4 address with brackets and port

# Generated at 2022-06-23 05:20:30.272191
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:41.701817
# Unit test for function parse_address
def test_parse_address():
    def test(s, expected_host, expected_port, allow_ranges=False):
        result_host, result_port = parse_address(s, allow_ranges=allow_ranges)
        assert expected_host == result_host
        assert expected_port == result_port

    # Hosts without port numbers
    test("www.ansible.com", "www.ansible.com", None)
    test("www.ansible.com.", "www.ansible.com", None)
    test("www.ansible.com:", "www.ansible.com", None)
    test("192.0.2.34", "192.0.2.34", None)
    test("192.0.2.34.", "192.0.2.34", None)

# Generated at 2022-06-23 05:20:48.178361
# Unit test for function parse_address
def test_parse_address():
    """
    parse_address should parse the given address into a tuple of host, port.
    """
    assert parse_address('a.example.com') == ('a.example.com', None)
    assert parse_address('a.example.com:22') == ('a.example.com', 22)
    assert parse_address('a.example.com:0') == ('a.example.com', 0)
    assert parse_address('[a.example.com]:22') == ('a.example.com', 22)
    assert parse_address('[a.example.com]:0') == ('a.example.com', 0)

    assert parse_address('1.2.3.4') == ('1.2.3.4', None)

# Generated at 2022-06-23 05:20:58.500978
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('nonvalididentifier') == (None, None)
    assert parse_address('nonvalididentifier:80') == (None, None)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:16384') == ('192.0.2.3', 16384)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:16384') == ('2001:db8::1', 16384)
    assert parse_address('[192.0.2.3]:16384') == ('192.0.2.3', 16384)

# Generated at 2022-06-23 05:21:10.315932
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:20.841316
# Unit test for function parse_address
def test_parse_address():
    # simple cases
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:42") == ("localhost", 42)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:42") == ("192.0.2.1", 42)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:42") == ("::1", 42)

    # range expressions
    assert parse_address("localhost[2:5]") == ("localhost[2:5]", None)
    assert parse_address("localhost[2:5]:42") == ("localhost[2:5]", 42)