

# Generated at 2022-06-23 05:11:21.176551
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:123') == ('::1', 123)
    assert parse_address('foo[1:2]:123') == ('foo[1:2]', 123)
    assert parse_address('192.0.2.3:123') == ('192.0.2.3', 123)
    assert parse_address('foo[0:5]:123') == ('foo[0:5]', 123)
    assert parse_address('foo[0:5]-bar[x-z]:123') == ('foo[0:5]-bar[x-z]', 123)
    assert parse_address('foo[x-z]:123') == ('foo[x-z]', 123)

# Generated at 2022-06-23 05:11:31.888898
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('foo')
    assert host == 'foo'
    assert port is None

    (host, port) = parse_address('foo:23')
    assert host == 'foo'
    assert port == 23

    (host, port) = parse_address('192.0.2.3:23')
    assert host == '192.0.2.3'
    assert port == 23

    (host, port) = parse_address('::1:23')
    assert host == '::1'
    assert port == 23

    (host, port) = parse_address('[::ffff:192.0.2.3]:23')
    assert host == '::ffff:192.0.2.3'
    assert port == 23


# Generated at 2022-06-23 05:11:41.088840
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:45.595190
# Unit test for function parse_address
def test_parse_address():
    import random

    # Test special cases
    assert parse_address('') == (None, None)
    assert parse_address(':') == (None, None)
    assert parse_address('::') == (None, None)
    assert parse_address('abc:') == (None, None)
    assert parse_address('[]:') == (None, None)
    assert parse_address('[::]:') == (None, None)

    # Test numeric ranges
    assert parse_address('[10:20:5]', True) == (None, None)
    assert parse_address('[10:20:5]') == ('[10:20:5]', None)
    assert parse_address('[10:20:5]:22') == ('[10:20:5]', 22)

# Generated at 2022-06-23 05:11:54.929259
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:05.571199
# Unit test for function parse_address
def test_parse_address():
    import pytest

    def assert_host_equal(host, expected):
        (host_name, port) = parse_address(host, allow_ranges=True)
        if port is not None:
            host_name += ':'+str(port)
        assert host_name == expected

    with pytest.raises(AnsibleError):
        assert_host_equal('127.0.0.1:port', '127.0.0.1')

    assert_host_equal('foo.example.com', 'foo.example.com')
    assert_host_equal('[foo.example.com]', 'foo.example.com')
    assert_host_equal('[foo.example.com]:22', 'foo.example.com:22')

# Generated at 2022-06-23 05:12:15.635463
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:25.114649
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:33.171628
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:38.572615
# Unit test for function parse_address
def test_parse_address():
    import sys
    import pytest

    # test different valid IPv4 addresses
    test_case = ['10.0.0.2', '192.0.2.1:1234', '[10.0.0.1]:1234']
    expected_results = [('10.0.0.2',None), ('192.0.2.1', 1234), ('10.0.0.1', 1234)]
    for i in range(0, 3):
        assert parse_address(test_case[i]) == expected_results[i]

    # test different valid IPv6 addresses
    test_case = ['::1', '1:2:3:4:5:6:7:8', '[::1]:1234']

# Generated at 2022-06-23 05:12:48.263701
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('host[1:3].example.com:33') == ('host[1:3].example.com', 33)
    assert parse_address('[::1][1:2]:44') == ('[::1][1:2]', 44)

    assert parse_address('bracketed_hostport') is None
    assert parse_address('hostport:55') is None

    assert parse_address('host') == ('host', None)
    assert parse_address('host:66') == ('host', 66)
    assert parse_address('host[1:3].example.com') == ('host[1:3].example.com', None)
    assert parse_

# Generated at 2022-06-23 05:12:57.379614
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address('example.com') == ('example.com', None))
    assert (parse_address('example.com:1234') == ('example.com', 1234))
    assert (parse_address('[example.com]') == ('example.com', None))
    assert (parse_address('[example.com]:1234') == ('example.com', 1234))
    assert (parse_address('192.0.2.3') == ('192.0.2.3', None))
    assert (parse_address('192.0.2.3:1234') == ('192.0.2.3', 1234))
    assert (parse_address('[192.0.2.3]') == ('192.0.2.3', None))

# Generated at 2022-06-23 05:13:08.103436
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests import unittest

    class TestParseAddress(unittest.TestCase):

        def test_host_port(self):
            self.assertEqual((u'example.com', 256), parse_address('example.com:256'))

        def test_fqdn_port(self):
            self.assertEqual((u'test.example.com', 256), parse_address('test.example.com:256'))

        def test_ipv4_port(self):
            self.assertEqual((u'10.0.0.0', 256), parse_address('10.0.0.0:256'))


# Generated at 2022-06-23 05:13:16.321328
# Unit test for function parse_address
def test_parse_address():
    """
    Verify operation of parse_address()
    """
    from types import TupleType

    f = parse_address
    assert f('foo.example.com') == ('foo.example.com', None)
    assert f('foo.example.com:80') == ('foo.example.com', 80)
    assert f('[foo.example.com]') == ('foo.example.com', None)
    assert f('[foo.example.com]:80') == ('foo.example.com', 80)
    assert f('192.0.2.3') == ('192.0.2.3', None)
    assert f('192.0.2.3:80') == ('192.0.2.3', 80)

# Generated at 2022-06-23 05:13:24.109325
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:34.931487
# Unit test for function parse_address
def test_parse_address():
    def assert_parse_address(address, host, port, allow_ranges=False):
        assert host is not None and 0 <= port <= 65535
        if not allow_ranges:
            assert host == address
        (h, p) = parse_address(address, allow_ranges)
        assert (h, p) == (host, port)

    # Basic tests of the various forms
    assert_parse_address('foo', 'foo', None)
    assert_parse_address('foo.example.com', 'foo.example.com', None)
    assert_parse_address('foo:8888', 'foo', 8888)
    assert_parse_address('foo.example.com:8888', 'foo.example.com', 8888)

# Generated at 2022-06-23 05:13:46.541761
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:80") == ("localhost", 80)
    assert parse_address("localhost:65535") == ("localhost", 65535)

    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:80") == ("192.0.2.1", 80)
    assert parse_address("192.0.2.1:65535") == ("192.0.2.1", 65535)

    assert parse_address("[192.0.2.1]") == ("192.0.2.1", None)
    assert parse_address("[192.0.2.1]:80") == ("192.0.2.1", 80)

# Generated at 2022-06-23 05:13:52.313350
# Unit test for function parse_address
def test_parse_address():
    """
    Parse a set of addresses and verify the output.
    """

# Generated at 2022-06-23 05:14:03.176630
# Unit test for function parse_address
def test_parse_address():

    def eq(s, h, p=None):
        (host, port) = parse_address(s)
        assert host == h and port == p, "parse_address(%s) = (%s, %s), want (%s, %s)" % (repr(s), host, port, h, p)

    def ne(s, h, p=None):
        try:
            eq(s, h, p)
        except AssertionError:
            return
        raise AssertionError("expected parse_address(%s) to fail, got %s" % (s, repr((h, p))))

    # Empty string
    eq('', None, None)

    # Hostname with no port
    eq('foo', 'foo')
    eq('foo.bar.baz', 'foo.bar.baz')

# Generated at 2022-06-23 05:14:14.184078
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:23.383178
# Unit test for function parse_address
def test_parse_address():
    address = 'myhost'
    host = 'myhost'
    port = 22
    assert (host, port) == parse_address(address)

    address = 'myhost[0:3]'
    host = 'myhost[0:3]'
    port = 22
    assert (host, port) == parse_address(address, allow_ranges=True)

    address = 'myhost[0:3]'
    host = 'myhost[0:3]'
    port = 22
    assert (host, port) == parse_address(address)

    address = 'myhost[0:3]'
    host = 'myhost[0:3]'
    port = 2222
    assert (host, port) == parse_address(address)

    address = 'myhost[0:3]:2222'

# Generated at 2022-06-23 05:14:33.508674
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('example.com')
    assert host == 'example.com'
    assert not port
    (host, port) = parse_address('example.com:22')
    assert host == 'example.com'
    assert port == 22

    (host, port) = parse_address('192.0.2.1')
    assert host == '192.0.2.1'
    assert not port
    (host, port) = parse_address('192.0.2.1:22')
    assert host == '192.0.2.1'
    assert port == 22

    (host, port) = parse_address('fe80::a00:27ff:fe1b:a110')
    assert host == 'fe80::a00:27ff:fe1b:a110'

# Generated at 2022-06-23 05:14:44.507494
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestParseAddress(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        @patch('ansible.inventory.host.parse_address')
        def test__address_contains_range(self, mock_parse_address):
            mock_parse_address.return_value = ('hostname', 22)

            self.assertEqual(parse_address('[hostname]', allow_ranges=True), ('hostname', 22))
            mock_parse_address.assert_called_with('[hostname]', allow_ranges=True)

            mock_parse_address.return_value = ('hostname', None)
            self.assertE

# Generated at 2022-06-23 05:14:52.111012
# Unit test for function parse_address
def test_parse_address():

    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)
    assert parse_address("foo.example.com[1:5]:22") == ("foo.example.com[1:5]", 22)
    assert parse_address("foo[1:5].example.com[1:5]:22") == ("foo[1:5].example.com[1:5]", 22)
    assert parse_address("foo[1:5].example[1:5].com[1:5]:22") == ("foo[1:5].example[1:5].com[1:5]", 22)

# Generated at 2022-06-23 05:15:01.928472
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:11.070717
# Unit test for function parse_address
def test_parse_address():
    print("Testing parse_address with empty input")
    assert parse_address('') == (None, None)

    print("Testing parse_address with IPv4 address")
    assert parse_address('10.20.30.40:443') == ('10.20.30.40', 443)

    print("Testing parse_address with IPv6 address")
    assert parse_address('[::1]:80') == ('::1', 80)

    print("Testing parse_address with IPv4 address and port in brackets")
    assert parse_address('[192.0.2.3]:443') == ('192.0.2.3', 443)

    print("Testing parse_address with IPv6 address and port in brackets")
    assert parse_address('[::1]:80') == ('::1', 80)


# Generated at 2022-06-23 05:15:16.202307
# Unit test for function parse_address
def test_parse_address():
    # pylint: disable=missing-docstring
    assert (None, None) == parse_address('a')
    assert ('a', 22) == parse_address('a:22')
    assert ('192.0.2.3', 22) == parse_address('192.0.2.3:22')
    assert ('[::fffe]', 22) == parse_address('[::fffe]:22')

    assert ('[2001:db8::a:b:c:d:e]', None) == parse_address('2001:db8::a:b:c:d:e')
    assert ('[::ffff:127.0.0.1]', None) == parse_address('[::ffff:127.0.0.1]')
    assert ('[::ffff:127.0.0.1]', 9999) == parse

# Generated at 2022-06-23 05:15:25.619581
# Unit test for function parse_address
def test_parse_address():
    """Unit test for function parse_address"""
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=False) == ('127.0.0.1', 22)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost:22', allow_ranges=False) == ('localhost', 22)

# Generated at 2022-06-23 05:15:37.689192
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4', True) == ('1.2.3.4', None)
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('example.org', True) == ('example.org', None)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)
    assert parse_address('2001:db8::1', True) == ('2001:db8::1', None)
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)

# Generated at 2022-06-23 05:15:47.971888
# Unit test for function parse_address
def test_parse_address():
    import pytest
    # valid hostname, no port
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    # valid hostname, port
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    # valid IPv4 without port
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    # valid IPv4 with port
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    # valid IPv4 in square brackets, no port

# Generated at 2022-06-23 05:15:59.699844
# Unit test for function parse_address
def test_parse_address():

    # Test IPv4 addresses with and without port specifications.
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=True) == ('127.0.0.1', 22)

    # Test IPv6 addresses (which require square brackets to specify a port).
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == ('::1', 22)

    # Test hostnames with and without port specifications.

# Generated at 2022-06-23 05:16:06.750312
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:13.321728
# Unit test for function parse_address
def test_parse_address():
    import unittest
    import ansible.playbook.play_context as pc

    class TestParseAddress(unittest.TestCase):
        hostname = "foobar.example.com"
        ipv4host = "192.0.2.10"
        ipv4hostport = "192.0.2.10:20"
        ipv4range = "192.0.2.[1:10]"
        ipv4range2 = "192.0.2.[0:10:2]"              # 0:10 stepping by 2
        ipv4range3 = "192.0.2.[0:10:2]-192.1.2.[1:3]" # 0:10 stepping by 2
        ipv6host = "2001:db8::1"

# Generated at 2022-06-23 05:16:25.155817
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo[1:2]') == ('foo[1:2]', None)
    assert parse_address('foo.example.com[1:2]') == ('foo.example.com[1:2]', None)
    assert parse_address('foo.example.com[1:2]:50051') == ('foo.example.com[1:2]', 50051)
    assert parse_address('10.20.30.40:50051') == ('10.20.30.40', 50051)
    assert parse_address('[10.20.30.40]:50051') == ('10.20.30.40', 50051)
    assert parse_

# Generated at 2022-06-23 05:16:34.487381
# Unit test for function parse_address
def test_parse_address():
    def test(host, port, validates):
        assert parse_address(host, "foo") == (host, "foo")
        assert parse_address(host, None) == (host, None)

        actual = parse_address(":%s" % port)
        assert actual == (None, port)

        actual = parse_address(":%s" % port, "foo")
        assert actual == (None, port)

        actual = parse_address("%s:%s" % (host, port))
        assert actual == (host, port)

        actual = parse_address("%s:%s" % (host, port), "foo")
        assert actual == (host, port)

        actual = parse_address("[%s]:%s" % (host, port))
        assert actual == (host, port)

        actual = parse

# Generated at 2022-06-23 05:16:43.307292
# Unit test for function parse_address
def test_parse_address():
    from collections import namedtuple


# Generated at 2022-06-23 05:16:55.064123
# Unit test for function parse_address
def test_parse_address():

    # These are all OK.
    assert parse_address("foo", allow_ranges=True) == ("foo", None)
    assert parse_address("foo[1:3]", allow_ranges=True) == ("foo[1:3]", None)
    assert parse_address("foo[0:5]:22", allow_ranges=True) == ("foo[0:5]", 22)
    assert parse_address("foo[0:5]-bar[1:3]:22", allow_ranges=True) == ("foo[0:5]-bar[1:3]", 22)
    assert parse_address("192.168.1.1", allow_ranges=True) == ("192.168.1.1", None)

# Generated at 2022-06-23 05:17:02.745362
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-23 05:17:13.875439
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.168.0.1') == ('192.168.0.1', None)
    assert parse_address('192.168.0.1:22') == ('192.168.0.1', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]') == ('foo.example.com', None)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('[192.168.0.1]:22') == ('192.168.0.1', 22)

# Generated at 2022-06-23 05:17:25.741059
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:35.367928
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("host") == ("host", None)
    assert parse_address("host:port") == ("host", port)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:9999") == ("127.0.0.1", 9999)
    assert parse_address("[127.0.0.1]:9999") == ("127.0.0.1", 9999)
    assert parse_address("[127.0.0.1]") == ("127.0.0.1", None)
    assert parse_address("::1") == ("::1", None)
    assert parse_address("[::1]") == ("::1", None)

# Generated at 2022-06-23 05:17:46.102809
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo-bar.example.com') == ('foo-bar.example.com', None)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('192.0.2.8') == ('192.0.2.8', None)
    assert parse_address('192.0.2.8:') == ('192.0.2.8', None)

# Generated at 2022-06-23 05:17:56.261583
# Unit test for function parse_address
def test_parse_address():
    try:
        import pytest
    except ImportError:
        pytest = None


# Generated at 2022-06-23 05:18:06.844343
# Unit test for function parse_address
def test_parse_address():
    # From _ssh_hosts.py
    add_host('foo:22')
    add_host('[1.2.3.4]:22')
    add_host('[1.2.3.4]:2222')
    add_host('[1.2.3.4]')
    add_host('[1:2:3:4:5:6:7:8]')
    add_host('[1:2:3:4:5:6:7:8]:22')
    add_host('[1:2:3:4:5:6:127.0.0.1]')
    add_host('[1:2:3:4:5:6:127.0.0.1]:22')

# Generated at 2022-06-23 05:18:17.694387
# Unit test for function parse_address
def test_parse_address():
    from ansible.parsing import vault

    def test_host_port(host, port):
        if host is None and port is None:
            print('?')
        elif host is None and port is not None:
            print('? :%d' % port)
        elif host is not None and port is None:
            print(host)
        else:
            print('%s:%d' % (host, port))

    def test(s, expected_host, expected_port, allow_ranges):
        output = parse_address(s, allow_ranges=allow_ranges)
        print('%-40s -->' % s, end=' ')
        host, port = output

        if host == expected_host and port == expected_port:
            print('OK:', end=' ')

# Generated at 2022-06-23 05:18:27.883719
# Unit test for function parse_address
def test_parse_address():
    def check(s, wanted):
        got = parse_address(s)
        if got != wanted:
            raise Exception("FAIL: '%s' -> '%s' (wanted '%s')" % (s, got, wanted))

    for s in [
        'localhost',
        'localhost:22',
        '[localhost]',
        '[localhost]:22',
        '127.0.0.1',
        '127.0.0.1:22',
        '::1',
        '[::1]',
        '[::1]:22',
    ]:
        check(s, (s, None))


# Generated at 2022-06-23 05:18:39.937285
# Unit test for function parse_address
def test_parse_address():
    import sys
    import pytest

    if sys.version_info < (2, 7):
        pytest.skip("In order to run the tests for this module we need Python 2.7 or later")

    # Basic tests.

    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('::1', allow_ranges=True) == ('::1', None)
    assert parse_address('::1:22', allow_ranges=True) == ('::1:22', None)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse

# Generated at 2022-06-23 05:18:48.789782
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:58.622402
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:08.656024
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None)
    assert parse_address('a') == ('a', None)
    assert parse_address('a.b.c') == ('a.b.c', None)
    assert parse_address('a-b-c') == ('a-b-c', None)
    assert parse_address('a[1:2]-b') == ('a[1:2]-b', None)
    assert parse_address('a:80') == ('a', 80)
    assert parse_address('a.b:80') == ('a.b', 80)
    assert parse_address('a-b-c:80') == ('a-b-c', 80)
    assert parse_address('a[1:2]-b:80') == ('a[1:2]-b', 80)
    assert parse_

# Generated at 2022-06-23 05:19:19.587826
# Unit test for function parse_address
def test_parse_address():

    def test(address, expect=None, allow_ranges=False):
        (host, port) = parse_address(address, allow_ranges)
        if expect is not None:
            assert (host, port) == expect
        else:
            assert (host, port)

    test('foo', expect=(None, None))
    test('foo:123', expect=('foo', 123))
    test('1.2.3.4', expect=('1.2.3.4', None))
    test('1.2.3.4:123', expect=('1.2.3.4', 123))
    test('[1.2.3.4]', expect=('1.2.3.4', None))

# Generated at 2022-06-23 05:19:31.182142
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:41.308445
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address("foo"))                == ('foo', None)
    assert (parse_address("foo:"))               == ('foo', None)
    assert (parse_address("foo:1"))              == ('foo', 1)
    assert (parse_address(":1"))                 == (None, 1)
    assert (parse_address(":65535"))             == (None, 65535)
    assert (parse_address(":99999"))             == (None, None)
    assert (parse_address("10.1.1.1"))           == ('10.1.1.1', None)
    assert (parse_address("10.1.1.1:"))          == ('10.1.1.1', None)

# Generated at 2022-06-23 05:19:48.348373
# Unit test for function parse_address
def test_parse_address():
    # Pass
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:22') == ('example.com', 22)
    assert parse_address('[2001:db8::7]') == ('2001:db8::7', None)
    assert parse_address('[2001:db8::7]:22') == ('2001:db8::7', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
   

# Generated at 2022-06-23 05:19:58.667288
# Unit test for function parse_address
def test_parse_address():
    def assert_parse(text, expect_host, expect_port):
        (host, port) = parse_address(text)
        assert host == expect_host, "%s: expected host %s, got %s" % (text, expect_host, host)
        assert port == expect_port, "%s: expected port %s, got %s" % (text, expect_port, port)

    def assert_parse_fail(text):
        try:
            parse_address(text)
            assert False, "expected %s to fail" % text
        except:
            pass

    assert_parse("hostname", "hostname", None)
    assert_parse("hostname:1234", "hostname", 1234)
    assert_parse("hostname:port", "hostname:port", None)

# Generated at 2022-06-23 05:20:08.647477
# Unit test for function parse_address
def test_parse_address():
    def check(input, expect):
        host, port = parse_address(input)
        if (host, port) != expect:
            print("FAIL %s -> %s != %s" % (input, (host, port), expect))
        else:
            print("OK   %s" % (input))

    check("example.com", ("example.com", None))
    check("example.com:80", ("example.com", 80))
    check("https://example.com:80/", ("example.com", 80))
    check("example.com[1:3]", ("example.com[1:3]", None))
    check("example.com[1:3]:80", ("example.com[1:3]", 80))

# Generated at 2022-06-23 05:20:19.304875
# Unit test for function parse_address
def test_parse_address():

    def assert_parses_to(address, host, port):
        (parsed_host, parsed_port) = parse_address(address)
        assert parsed_host == host, \
            "parse_address(%r) should return host %r (got %r)" % (address, host, parsed_host)
        assert parsed_port == port, \
            "parse_address(%r) should return port %r (got %r)" % (address, port, parsed_port)

    def assert_fails(address, message):
        try:
            parse_address(address)
        except Exception as e:
            assert e.message == message, \
                "parse_address(%r) should throw %r (got %r)" % (address, message, e.message)

# Generated at 2022-06-23 05:20:30.404257
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:41.921690
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:46.162806
# Unit test for function parse_address
def test_parse_address():
    # Test normal cases
    (host, port) = parse_address('host')
    assert host == 'host'
    assert port is None
    (host, port) = parse_address('host:1234')
    assert host == 'host'
    assert port == 1234
    (host, port) = parse_address('[host]')
    assert host == 'host'
    assert port is None
    (host, port) = parse_address('[host]:1234')
    assert host == 'host'
    assert port == 1234
    (host, port) = parse_address('[::1]')
    assert host == '[::1]'
    assert port is None
    (host, port) = parse_address('[::1]:1234')
    assert host == '[::1]'
    assert port == 1234

    # Test

# Generated at 2022-06-23 05:20:56.539279
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1', True) == ('127.0.0.1', None)
    assert parse_address('localhost', True) == ('localhost', None)
    assert parse_address('http://localhost', True) == ('http://localhost', None)
    assert parse_address('http://[::1]', True) == ('http://[::1]', None)
    assert parse_address('http://[::1]:8080', True) == ('http://[::1]', 8080)
    assert parse_address('http://127.0.0.1:8080', True) == ('http://127.0.0.1', 8080)
    assert parse_address('http://localhost:8080', True) == ('http://localhost', 8080)

# Generated at 2022-06-23 05:21:07.668960
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('foo.example.com:2002')
    assert host == 'foo.example.com'
    assert port == 2002

    (host, port) = parse_address('192.0.2.56:2002')
    assert host == '192.0.2.56'
    assert port == 2002

    (host, port) = parse_address('[1:2]:2002')
    assert host == '[1:2]'
    assert port == 2002

    (host, port) = parse_address('::1')
    assert host == '::1'
    assert port is None

    (host, port) = parse_address('[2001:db8::1]:2002')
    assert host == '[2001:db8::1]'
    assert port == 2002


# Generated at 2022-06-23 05:21:18.622670
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo[1:3]:22")             == ("foo[1:3]", 22)
    assert parse_address("foo[1:3]")                == ("foo[1:3]", None)
    assert parse_address("foo:22")                  == ("foo", 22)
    assert parse_address("[x:y(:z)]")               == ("[x:y(:z)]", None)
    assert parse_address("192.0.2.3:22")            == ("192.0.2.3", 22)
    assert parse_address("192.0.2.3")               == ("192.0.2.3", None)