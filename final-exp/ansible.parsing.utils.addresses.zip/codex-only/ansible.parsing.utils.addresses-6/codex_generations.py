

# Generated at 2022-06-23 05:11:18.134095
# Unit test for function parse_address
def test_parse_address():
    addrs = {
        'example.com'        : ('example.com', None),
        'example.com:80'     : ('example.com', 80),
        '10.1.1.1'           : ('10.1.1.1', None),
        '10.1.1.1:80'        : ('10.1.1.1', 80),
        '[10.1.1.1]'         : ('10.1.1.1', None),
        '[10.1.1.1]:80'      : ('10.1.1.1', 80),
        '[2001:db8::1]'      : ('2001:db8::1', None),
        '[2001:db8::1]:80'   : ('2001:db8::1', 80),
    }

# Generated at 2022-06-23 05:11:28.968020
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:37.876537
# Unit test for function parse_address
def test_parse_address():
    ###########################################################################
    # Port specification tests
    ###########################################################################

    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[2001:db8::f00]') == ('2001:db8::f00', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('[2001:db8::f00]:22') == ('2001:db8::f00', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)

    ###########################################################################
    # IPv6 tests


# Generated at 2022-06-23 05:11:48.642118
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:00.570585
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:09.358651
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:13.623698
# Unit test for function parse_address
def test_parse_address():
    def test(address, expected, allow_ranges):
        actual = parse_address(address, allow_ranges)
        if actual != expected:
            raise AssertionError("test failed: parse_address(%r) expected %r but returned %r" % (address, expected, actual))

    test("foo.example.com", ("foo.example.com", None),             False)
    test("foo.example.com:22", ("foo.example.com", 22),            False)
    test("[foo.example.com]", ("foo.example.com", None),           False)
    test("[foo.example.com]:22", ("foo.example.com", 22),          False)
    test("foo.example.com", ("foo.example.com", None),             True)

# Generated at 2022-06-23 05:12:25.106616
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("example.com:80") == ("example.com", 80)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:80") == ("192.0.2.1", 80)
    assert parse_address("[2001:db8::1]") == ("2001:db8::1", None)
    assert parse_address("[2001:db8::1]:80") == ("2001:db8::1", 80)
    assert parse_address("example[1].com") == ("example[1].com", None)
    assert parse_address("example[1].com:80") == ("example[1].com", 80)


# Generated at 2022-06-23 05:12:31.998613
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:37.419896
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:47.862972
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:1234') == ('localhost', 1234)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:1234') == ('1.2.3.4', 1234)
    assert parse_address('1.2.3.4:1234', allow_ranges=True) == ('1.2.3.4', 1234)
    assert parse_address('[1:2:3:4::5]') == ('1:2:3:4::5', None)
    assert parse_address('[1:2:3:4::5]:1234') == ('1:2:3:4::5', 1234)


# Generated at 2022-06-23 05:12:56.991519
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:07.765380
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:17.257891
# Unit test for function parse_address
def test_parse_address():
    def assert_hostport(host, port, input, allow_ranges=False):
        assert parse_address(input, allow_ranges=allow_ranges) == (host, port)

    def assert_host(host, input, allow_ranges=False):
        assert parse_address(input, allow_ranges=allow_ranges) == (host, None)

    def assert_bad(input, allow_ranges=False):
        try:
            parse_address(input, allow_ranges=allow_ranges)
        except AnsibleError:
            pass
        else:
            assert False, "Expected parse of %s to fail" % input

    # Numeric ranges are not allowed by default.
    assert_bad('[1:5]')
    assert_bad('foo[1:5]')
    assert_bad

# Generated at 2022-06-23 05:13:29.266852
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:39.979908
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost:8080") == ("localhost", 8080)
    assert parse_address("[localhost]:8080") == ("localhost", 8080)
    assert parse_address("127.0.0.1:8080") == ("127.0.0.1", 8080)
    assert parse_address("[127.0.0.1]:8080") == ("127.0.0.1", 8080)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("[127.0.0.1]") == ("127.0.0.1", None)
    assert parse_address("[127.0.0.1]:") == ("127.0.0.1", None)

# Generated at 2022-06-23 05:13:48.352295
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:3') == ('foo', 3)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address('foo:bar') == ('foo:bar', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:3') == ('::1', 3)
    assert parse_address('[::1]:') == ('::1', None)
    assert parse_address('[::1]:bar') == ('::1', None)
    assert parse_address('[::1]:3:4') == ('::1:3:4', None)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
   

# Generated at 2022-06-23 05:13:58.596991
# Unit test for function parse_address
def test_parse_address():
    assertions = dict(
        simple_host='server.example.com',
        ipv4_host='127.0.0.1',
        ipv6_host='::1',
        ipv6_host_with_port='[::1]:22',
        bracketed_host='[server.example.com]',
        bracketed_host_with_port='[server.example.com]:22',
        range_host='server[1:3].example.com',
        bracketed_range_host='[server[1:3]].example.com',
        bracketed_range_host_with_port='[server[1:3]].example.com:22',
    )

    for host, address in assertions.items():
        assert host == parse_address(address, allow_ranges=True)[0]


# Generated at 2022-06-23 05:14:07.474671
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.bar.example.com') == ('foo.bar.example.com', None)
    assert parse_address('foo.bar.example.com:22') == ('foo.bar.example.com', 22)
    assert parse_address('foo[0:3].bar.example.com:22') == ('foo[0:3].bar.example.com', 22)
    assert parse_address('foo[0:3].example.com:22') == ('foo[0:3].example.com', 22)
    assert parse_address('example.com:22') == ('example.com', 22)

# Generated at 2022-06-23 05:14:19.812318
# Unit test for function parse_address
def test_parse_address():
    """ Returns true if the function works as advertised. """

    import ansible.utils.network

# Generated at 2022-06-23 05:14:31.070169
# Unit test for function parse_address
def test_parse_address():
    def test_address(address, port, host, msg=None):
        try:
            (parsed_host, parsed_port) = parse_address(address)
        except Exception as e:
            assert port is None, "%s: failed to parse '%s' with error: %s" % (msg, address, e)
            return

        assert parsed_host == host, "%s: parsed host '%s' != '%s' for address '%s'" % (msg, parsed_host, host, address)
        assert parsed_port == port, "%s: parsed port '%s' != '%s' for address '%s'" % (msg, parsed_port, port, address)

    # Host names, IPv4 addresses and IPv6 addresses without a port.


# Generated at 2022-06-23 05:14:43.087956
# Unit test for function parse_address
def test_parse_address():
    """ Unit test for function parse_address """
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('[3ffe:2a00:100:7031::1]') == ('3ffe:2a00:100:7031::1', None)
    assert parse_address('[::192.0.2.3]') == ('::192.0.2.3', None)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)
    assert parse_address('localhost:9999') == ('localhost', 9999)

# Generated at 2022-06-23 05:14:53.807924
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-23 05:15:02.809631
# Unit test for function parse_address
def test_parse_address():
    assert ('undef', None) == parse_address('undef')
    assert ('localhost', None) == parse_address('localhost')
    assert ('host', None) == parse_address('host:')
    assert ('host', 1) == parse_address('host:1')
    assert ('host', 1) == parse_address('[host]:1')
    assert ('0.0.0.0', None) == parse_address('0.0.0.0')
    assert ('0.0.0.0', 1) == parse_address('0.0.0.0:1')
    assert ('0.0.0.0', 1) == parse_address('[0.0.0.0]:1')
    assert (None, None) == parse_address('[anon@localhost]')

# Generated at 2022-06-23 05:15:11.557085
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:22.478382
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('db1[1:3]:22') == ('db1[1:3]', 22)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('1.2.3.4[1:3]') == ('1.2.3.4[1:3]', None)
    assert parse_address('1.2.3.4[1:3]:22') == ('1.2.3.4[1:3]', 22)

# Generated at 2022-06-23 05:15:33.832527
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)

    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::ffff:192.0.2.1]:22') == ('::ffff:192.0.2.1', 22)
    assert parse_address('[::ffff:127.0.0.1]:22') == ('::ffff:127.0.0.1', 22)
    assert parse_address('[::ffff:127.0.0.1]') == ('::ffff:127.0.0.1', None)


# Generated at 2022-06-23 05:15:46.321389
# Unit test for function parse_address
def test_parse_address():
    # Function returns a tuple of host and port.
    # It then passes them to double check the data types are
    # being returned as expected.
    def test_return_type(address):
        val = parse_address(address)
        assert len(val) == 2
        assert isinstance(val[0], (type(None), str))
        assert isinstance(val[1], (type(None), int))
        return True
    # The tests for the parse_address funciton.
    # We are checking for IPv4, IPv6, and hostnames.
    # The function should return a tuple with an IP and a Port number.
    # The function will return None if it is unable to process the input.
    # Note that the IPv6 address will likely require
    #   a system level setting of EnableIPv6 to be set to true.

# Generated at 2022-06-23 05:15:58.279506
# Unit test for function parse_address
def test_parse_address():
    """
    Test suite for parse_address()

    Our test cases are:
        (address, expected_host, expected_port)

    For example:
        ('localhost:22', 'localhost', 22)
    """

# Generated at 2022-06-23 05:16:06.498684
# Unit test for function parse_address
def test_parse_address():
    # Normal hostnames, IPv4 addresses, and IPv6 addresses with ports
    assert parse_address("host.name:123") == ('host.name', 123)
    assert parse_address("1.2.3.4:123") == ('1.2.3.4', 123)
    assert parse_address("[1234::5678]:123") == ('1234::5678', 123)

    # FQDNs and addresses with ports in square brackets
    assert parse_address("host.name.com:123") == ('host.name.com', 123)
    assert parse_address("[1.2.3.4]:123") == ('1.2.3.4', 123)
    assert parse_address("[1234::5678]:123") == ('1234::5678', 123)

    # Unqualified hostnames, localhost, the

# Generated at 2022-06-23 05:16:16.413403
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:27.416013
# Unit test for function parse_address
def test_parse_address():
    """
    Test case for function parse_address
    """

    try:
        parse_address(None)
        assert False, "Should not have been able to parse None"
    except AnsibleError:
        pass

    try:
        parse_address("")
        assert False, "Should not have been able to parse empty string"
    except AnsibleError:
        pass

    h, p = parse_address("localhost")
    assert h == "localhost", "Did not parse localhost correctly"
    assert p is None, "Should not have a port"

    h, p = parse_address("localhost:22")
    assert h == "localhost", "Did not parse localhost:22 correctly"
    assert p == 22, "port should be 22"

    h, p = parse_address("localhost:foo")

# Generated at 2022-06-23 05:16:39.621753
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:52.035232
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:04.105345
# Unit test for function parse_address
def test_parse_address():
    test_func = parse_address
    # no port
    host, port = test_func("host.name")
    assert host == "host.name"
    assert port == None
    # no port
    host, port = test_func("1.2.3.4")
    assert host == "1.2.3.4"
    assert port == None
    # port in IPv4 address
    host, port = test_func("1.2.3.4:5")
    assert host == "1.2.3.4"
    assert port == 5
    # no port
    host, port = test_func("2001:db8::1")
    assert host == "2001:db8::1"
    assert port == None
    # no port
    host, port = test_func("[2001:db8::1]")

# Generated at 2022-06-23 05:17:15.346324
# Unit test for function parse_address
def test_parse_address():
    # Test for proper detection of addresses w/ no ports
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)

    # Test that we can parse an IPv6 address w/ a port
    assert parse_address('[::1]:65432') == ('::1', 65432)

    # Test that we

# Generated at 2022-06-23 05:17:23.218003
# Unit test for function parse_address
def test_parse_address():
    assert None == parse_address('[','True')
    assert None == parse_address('[','False')
    assert None == parse_address('[','')
    assert None == parse_address('ThiIsNotAHost','False')
    assert None == parse_address('[ThiIsNotAHost]','False')
    assert None == parse_address('a[b]:u','False')
    assert None == parse_address('[a[b]]:u','False')
    assert ('[a[b]]', 'u') == parse_address('[a[b]]:u','True')
    assert ('a[b]', None) == parse_address('a[b]','True')
    assert ('a[b]', None) == parse_address('a[b]','False')

# Generated at 2022-06-23 05:17:32.433129
# Unit test for function parse_address
def test_parse_address():
    def validate_address(address, host, port):
        if port is not None:
            port = int(port)
        (h, p) = parse_address(address)
        assert h == host
        assert p == port

    validate_address('foo', 'foo', None)
    validate_address('1.2.3.4', '1.2.3.4', None)
    validate_address('1.2.3.4:5', '1.2.3.4', 5)
    validate_address('[1.2.3.4]', '1.2.3.4', None)
    validate_address('[1.2.3.4]:5', '1.2.3.4', 5)


# Generated at 2022-06-23 05:17:43.669323
# Unit test for function parse_address
def test_parse_address():
    # Some easy cases
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("example.com:123") == ("example.com", 123)
    assert parse_address("example.com:99") == ("example.com", 99)

    # IPv4
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:123") == ("192.0.2.1", 123)
    assert parse_address("192.0.2.1:99") == ("192.0.2.1", 99)
    assert parse_address("[192.0.2.1]") == ("192.0.2.1", None)

# Generated at 2022-06-23 05:17:54.243412
# Unit test for function parse_address
def test_parse_address():
    """These should all succeed"""

# Generated at 2022-06-23 05:18:05.526444
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-23 05:18:16.711435
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('[::ffff:192.0.2.3]:22') == ('::ffff:192.0.2.3', 22)

# Generated at 2022-06-23 05:18:25.794701
# Unit test for function parse_address
def test_parse_address():
    ipv4_addresses = [
        ('127.0.0.1', None),
        ('127.0.0.1:1234', 1234),
        ('127.0.0.1:1234', 1234),
        ('127[0:255].0.0[0:1]', None),
        ('127[0:255].0.0[0:1]:1234', 1234),
    ]

    for test in ipv4_addresses:
        assert parse_address(test[0]) == (test[0], test[1])

    ipv6_addresses = [
        ('fe80::1', None),
        ('[fe80::1]:1234', 1234),
    ]


# Generated at 2022-06-23 05:18:33.737453
# Unit test for function parse_address
def test_parse_address():
    # basic formats
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost:0') == ('localhost', 0)
    assert parse_address('localhost:[::]:0') == ('localhost:[::]', 0)
    assert parse_address('localhost:1:2:3') == ('localhost', 0)
    assert parse_address('localhost[1:2:3]') == ('localhost[1:2:3]', None)
    assert parse_address('localhost[1:2:3]:0') == ('localhost[1:2:3]', 0)
    assert parse_address('putty') == ('putty', None)
    assert parse_address('putty:0') == ('putty', 0)

# Generated at 2022-06-23 05:18:42.728777
# Unit test for function parse_address
def test_parse_address():
    print("Testing function parse_address()")

# Generated at 2022-06-23 05:18:53.462110
# Unit test for function parse_address
def test_parse_address():
    def assert_equal(address, host, port=None, allow_ranges=False):
        (h, p) = parse_address(address, allow_ranges)
        assert h == host, 'Failed to parse {} as {}'.format(address, host)
        assert p == port, 'Failed to parse {} as a port number'.format(address)

    assert_equal('foo', 'foo')
    assert_equal('foo.example.com', 'foo.example.com')
    assert_equal('foo[1:3]', 'foo[1:3]')
    assert_equal('foo[1:3]', 'foo[1:3]', allow_ranges=True)
    assert_equal('foo[x:z]', 'foo[x:z]')

# Generated at 2022-06-23 05:19:05.087199
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:16.273511
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:27.944131
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:32.293016
# Unit test for function parse_address
def test_parse_address():
    # The "host" part of a given string is returned by the first match.
    # The "port" part is returned by the second match. If the host is None
    # then the string could not be parsed as a host identifier with an optional
    # port specification. If the port is None, then no port was specified.

    # The host identifier may be a hostname (qualified or not), an IPv4 address,
    # or an IPv6 address. If allow_ranges is True, then any of those may contain
    # [x:y] range specifications, e.g. foo[1:3] or foo[0:5]-bar[x-z].

    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)


# Generated at 2022-06-23 05:19:43.954632
# Unit test for function parse_address
def test_parse_address():
    # Identify a range in host and deny it if we don't allow ranges
    try:
        (host, port) = parse_address('foo[1:3]')
        if host != 'foo[1:3]':
            raise AnsibleError('Fail')
        if port:
            raise AnsibleError('Fail')
        (host, port) = parse_address('foo[1:3]', True)
        if host != 'foo[1:3]':
            raise AnsibleError('Fail')
        if port:
            raise AnsibleError('Fail')
        (host, port) = parse_address('foo[1:3]', False)
        raise AnsibleError('Fail')
    except AnsibleError:
        pass
    except AnsibleParserError:
        pass
    except:
        raise AnsibleError('Fail')

   

# Generated at 2022-06-23 05:19:56.296569
# Unit test for function parse_address
def test_parse_address():
    """
    Shared unit test for parse_address().
    """


# Generated at 2022-06-23 05:20:06.427558
# Unit test for function parse_address
def test_parse_address():
    for test in [
        ('::1', ('::1', None)),
        ('2001:db8::1', ('2001:db8::1', None)),
        ('host.example.org', ('host.example.org', None)),
        ('[::1]:100', ('::1', 100)),
        ('[2001:db8::1]:100', ('2001:db8::1', 100)),
        ('[127.0.0.1]:100', ('127.0.0.1', 100)),
        ('[host.example.org]:100', ('host.example.org', 100)),
        ('a[b:c]d.example.org', ('a[b:c]d.example.org', None)),
    ]:
        (host, port) = parse_address(test[0])
        assert (host, port) == test

# Generated at 2022-06-23 05:20:18.185621
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:29.869996
# Unit test for function parse_address
def test_parse_address():
    for hostname in ['test01', 'test01.localdomain', 'test01.local', 'test01.localdomain.local', 'test01.localdomain.foo.bar', 'test01.localdomain.foo.bar.localdomain', 'test01.localdomain.foo.bar.localdomain', 'test01.localdomain.foo.bar.localdomain.tld', 'test01.localdomain.foo.bar.àéè.localdomain.tld', 'test01.localdomain.foo.bar.localdomain.local.tld.tld', 'test01.localdomain.foo.bar.localdomain.local.local']:
        assert parse_address(hostname) == (hostname, None)


# Generated at 2022-06-23 05:20:38.179336
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("10.0.0.1:111") == ('10.0.0.1', 111)
    assert parse_address("foo[1:3].example.com:222") == ('foo[1:3].example.com', 222)
    assert parse_address("foo[1:3:100].example.com:222") == ('foo[1:3:100].example.com', 222)
    assert parse_address("[::1]:333") == ('[::1]', 333)
    assert parse_address("example.com") == ('example.com', None)
    assert parse_address("foo.bar[01:07].example.com") == ('foo.bar[01:07].example.com', None)

# Generated at 2022-06-23 05:20:49.760246
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:59.803844
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:06.611281
# Unit test for function parse_address
def test_parse_address():
    """Test parse_address() function."""
    def assert_host_port(host, port, expected_host, expected_port):
        _host, _port = parse_address(host + ":" + port)
        assert _host == expected_host, "Host mismatch - got %s, expected %s" % (_host, expected_host)
        assert _port == expected_port, "Port mismatch - got %s, expected %s" % (_port, expected_port)

    # IPv4 address
    assert_host_port("0.0.0.0", "42", "0.0.0.0", 42)
    assert_host_port("127.0.0.1", "42", "127.0.0.1", 42)

# Generated at 2022-06-23 05:21:17.632156
# Unit test for function parse_address
def test_parse_address():
    import pytest

    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six import PY3

    parsed = parse_address('example.com')
    assert parsed == ('example.com', None)

    parsed = parse_address('example.com:80')
    assert parsed == ('example.com', 80)

    parsed = parse_address('192.0.2.1')
    assert parsed == ('192.0.2.1', None)

    parsed = parse_address('192.0.2.1:80')
    assert parsed == ('192.0.2.1', 80)

    parsed = parse_address('[2001:db8::1]')
    assert parsed == ('2001:db8::1', None)

    parsed = parse_address('[2001:db8::1]:80')
   