

# Generated at 2022-06-23 05:11:21.215259
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:28.533044
# Unit test for function parse_address
def test_parse_address():
    import textwrap
    import unittest

    class TestCases(unittest.TestCase):

        def assertParse(self, address, host, port=None):
            """Assert that the given address parses to the given host/port pair."""
            self.assertEqual(parse_address(address), (host, port))

        def assertRangeError(self, address):
            """Assert that the given address is not a valid hostname."""
            self.assertRaises(AnsibleParserError, parse_address, address, False)


# Generated at 2022-06-23 05:11:38.273548
# Unit test for function parse_address
def test_parse_address():
    addr_port_tuple = parse_address('a.b.c.d', False)
    assert addr_port_tuple == ('a.b.c.d', None)

    addr_port_tuple = parse_address('a.b.c.d:123', False)
    assert addr_port_tuple == ('a.b.c.d', 123)

    addr_port_tuple = parse_address('[a.b.c.d]:123', False)
    assert addr_port_tuple == ('a.b.c.d', 123)

    addr_port_tuple = parse_address('[f.g.h.i]:123', False)
    assert addr_port_tuple == ('f.g.h.i', 123)


# Generated at 2022-06-23 05:11:48.971912
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:01.074541
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(':123') == (None, 123)
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo[1:3]:123') == ('foo[1:3]', 123)
    assert parse_address('foo[x-y].example.com:123') == ('foo[x-y].example.com', 123)
    assert parse_address('192.0.2.1:123') == ('192.0.2.1', 123)
    assert parse_address('[192.0.2.1]:123') == ('192.0.2.1', 123)
    assert parse_address('[2001:db8::1]:123') == ('2001:db8::1', 123)

# Generated at 2022-06-23 05:12:10.430474
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost',             False) == ('localhost', None)
    assert parse_address('localhost:22',          False) == ('localhost', 22)
    assert parse_address('localhost:22',          True)  == ('localhost', 22)
    assert parse_address('[::1]',                 False) == ('::1',       None)
    assert parse_address('[::1]:22',              False) == ('::1',       22)
    assert parse_address('[::1]:22',              True)  == ('::1',       22)
    assert parse_address('[::1][:22]',            False) == ('[::1]',     22)
    assert parse_address('[::1][:22]',            True)  == ('[::1]',     22)

# Generated at 2022-06-23 05:12:22.705142
# Unit test for function parse_address
def test_parse_address():
    import unittest


# Generated at 2022-06-23 05:12:30.781109
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4
    assert parse_address("localhost:22222") == ('localhost', 22222)
    assert parse_address("192.0.2.1:22") == ('192.0.2.1', 22)
    assert parse_address("192.0.2.1:22:33") == ('192.0.2.1:22:33', None)
    assert parse_address("192.0.2.1:22:33", allow_ranges=True) == ('192.0.2.1', 22)
    assert parse_address("192.0.2.1[0:2]:22", allow_ranges=True) == ('192.0.2.1[0:2]', 22)

# Generated at 2022-06-23 05:12:40.810730
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)
    assert parse_address('1.2.3.4.5') == (None, None)
    assert parse_address('-1.2.3.4') == (None, None)
    assert parse_address('1.2.3.4-') == ('1.2.3.4-', None)
    assert parse_address('server') == ('server', None)
    assert parse_address('Server') == ('Server', None)
    assert parse_address('server.example.com') == ('server.example.com', None)

# Generated at 2022-06-23 05:12:50.361050
# Unit test for function parse_address
def test_parse_address():
    """Unit test for function parse_address"""
    import sys
    import socket


# Generated at 2022-06-23 05:12:59.156982
# Unit test for function parse_address
def test_parse_address():
    # Test simple and bracketed IP addresses and host names with and without
    # port specifications.
    addresses = [
        'www.example.com',
        'foo.example.com:8080',
        '10.0.0.1',
        '10.0.0.1:123',
        '[2001:db8::1]',
        '[f0:de:f1:ec:a::1]:1234',
        '[f0:de:f1:ec:a:0:1:2]:1234',
    ]
    for address in addresses:
        host, port = parse_address(address)
        print("%s -> %s, %s" % (address, host, port))

    # An IPv4 range.
    host, port = parse_address('10.0.0.[1:3]:123')

# Generated at 2022-06-23 05:13:10.436970
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:19.520524
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None), "host name with no port failed"
    assert parse_address('example.com:1234') == ('example.com', 1234), "host name with port failed"
    assert parse_address('192.0.2.3') == ('192.0.2.3', None), "IPv4 address with no port failed"
    assert parse_address('192.0.2.3:1234') == ('192.0.2.3', 1234), "IPv4 address with port failed"
    assert parse_address('[2001:db8::42]') == ('2001:db8::42', None), "IPv6 address with no port failed"

# Generated at 2022-06-23 05:13:29.774097
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4:5678') == ('1.2.3.4', 5678)
    assert parse_address('1.2.3.4[1:3]:5678') == ('1.2.3.4[1:3]', 5678)
    assert parse_address('[1:3]:5678') == ('[1:3]', 5678)
    assert parse_address('foo.example.com:5678') == ('foo.example.com', 5678)
    assert parse_address('foo.example.com[1:3]:5678') == ('foo.example.com[1:3]', 5678)
    assert parse_address('foo.example.com[1:3]') == ('foo.example.com[1:3]', None)

# Generated at 2022-06-23 05:13:40.517853
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class ParseAddressTest(unittest.TestCase):
        def test_parse_address(self):
            self.assertEqual((None, None), parse_address('::2:'))
            self.assertEqual((None, None), parse_address('::2_:'))
            self.assertEqual((None, None), parse_address('::2['))
            self.assertEqual((None, None), parse_address('::2:_'))
            self.assertEqual((None, None), parse_address('::[1:2:'))
            self.assertEqual((None, None), parse_address('::[1:2:3'))
            self.assertEqual((None, None), parse_address('::[1:2:3]'))

# Generated at 2022-06-23 05:13:48.711719
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:57.689185
# Unit test for function parse_address
def test_parse_address():
    # happy path
    address = "localhost:5432"
    host, port = parse_address(address)
    assert host == address.split(':')[0]
    assert port == int(address.split(':')[-1])

    # happy path
    address = "localhost"
    host, port = parse_address(address)
    assert host == address
    assert port is None

    # happy path
    address = "[127.0.0.1]:5432"
    host, port = parse_address(address)
    assert host == address.split(':')[0].strip('[]')
    assert port == int(address.split(':')[-1])

    # happy path
    address = "[::1]:5432"
    host, port = parse_address(address)

# Generated at 2022-06-23 05:14:08.803593
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:22") == ("192.0.2.1", 22)
    assert parse_address("[192.0.2.1]:22") == ("192.0.2.1", 22)

    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)
    assert parse_address("[foo.example.com]:22") == ("foo.example.com", 22)

    assert parse_address("2001:db8::1") == ("2001:db8::1", None)

# Generated at 2022-06-23 05:14:20.941969
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:31.349404
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:43.315100
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1:23') == ('127.0.0.1', 23)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1]') == (None, None)
    assert parse_address('[::1') == (None, None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:23') == ('::1', 23)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:23') == ('localhost', 23)
    assert parse_address('localhost[01:03]') == ('localhost[01:03]', None)

# Generated at 2022-06-23 05:14:50.400486
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("www.example.com:8080") == ("www.example.com", 8080)
    assert parse_address("[www.example.com]:8080") == ("www.example.com", 8080)
    assert parse_address("192.0.2.1:8080") == ("192.0.2.1", 8080)
    assert parse_address("[192.0.2.1]:8080") == ("192.0.2.1", 8080)



# Generated at 2022-06-23 05:14:58.520458
# Unit test for function parse_address
def test_parse_address():
    def _test_parse_address(s, host, port):
        result = parse_address(s)
        if (host, port) != result:
            raise AssertionError("string %r failed: expected %r, got %r" % (s, (host, port), result))
    _test_parse_address("192.168.1.1", "192.168.1.1", None)
    _test_parse_address("192.168.1.1:49152", "192.168.1.1", 49152)
    _test_parse_address("foo[1:2].example.com", "foo[1:2].example.com", None)
    _test_parse_address("foo[1:2].example.com:49152", "foo[1:2].example.com", 49152)
    _

# Generated at 2022-06-23 05:15:08.848681
# Unit test for function parse_address
def test_parse_address():
    import sys

    def test(s, a=(None, None), allow_ranges=False):
        v = parse_address(s, allow_ranges=allow_ranges)
        if v != a:
            sys.stderr.write("test_parse_address failed for %s, "
                             "expected %s but got %s\n" % (s, a, v))

    test("", allow_ranges=True)
    test("foo", allow_ranges=True)
    test("foo:123", allow_ranges=True)
    test("192.0.2.4", allow_ranges=True)
    test("[::1]")
    test("[::1]:123")
    test("[::ffff:192.0.2.4]")

# Generated at 2022-06-23 05:15:19.253591
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0[0:5]:22') == ('127.0.0[0:5]', 22)
    assert parse_address('127.0.0[00:05]:22') == ('127.0.0[00:05]', 22)
    assert parse_address('127.0.0[0:5]:22') == ('127.0.0[0:5]', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)

# Generated at 2022-06-23 05:15:27.284855
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:39.094683
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:48.770519
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[1:2::1]:22') == ('1:2::1', 22)

# Generated at 2022-06-23 05:16:00.422395
# Unit test for function parse_address
def test_parse_address():
    """
    Test parse_address() with various inputs.
    """
    from ansible.compat.tests import unittest

    class TestParseAddress(unittest.TestCase):

        def test_inputs(self):

            self.assertEqual(parse_address("example.com"), (u"example.com", None))
            self.assertEqual(parse_address("192.0.2.1"), (u"192.0.2.1", None))
            self.assertEqual(parse_address("2001:db8::1"), (u"2001:db8::1", None))

            self.assertEqual(parse_address("example.com:22"), (u"example.com", 22))

# Generated at 2022-06-23 05:16:10.551611
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:23.066765
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:32.837550
# Unit test for function parse_address
def test_parse_address():
    """
    Simple unit test for parse_address()
    """

    import types

    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:123') == ('foo.example.com', 123)
    assert parse_address('foo.example.com:xyz') == (None, None)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:123') == ('192.0.2.3', 123)
    assert parse_address('192.0.2.3:xyz') == (None, None)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('[::1]:123')

# Generated at 2022-06-23 05:16:42.215758
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:54.233715
# Unit test for function parse_address
def test_parse_address():
    def _test_parse(address, host, port, allow_ranges):
        error = None
        try:
            result = parse_address(address, allow_ranges)
        except Exception as err:
            result = None
            error = repr(err)[1:]
        assert (result, error) == (
            ((host, port) if host is not None else None, None) if error is None else error)

    # basic parse.
    yield (_test_parse, 'foo', 'foo', None, False)
    yield (_test_parse, 'foo:22', 'foo', 22, False)
    yield (_test_parse, '[foo]:22', 'foo', 22, False)
    yield (_test_parse, '192.168.1.1', '192.168.1.1', None, False)

# Generated at 2022-06-23 05:17:05.767806
# Unit test for function parse_address
def test_parse_address():
    """
    This is a unit test for the functions in this file.

    It doesn't need to live in the test/ directory, since it doesn't test
    anything Ansible related.
    """
    from collections import namedtuple

    HostPort = namedtuple('HostPort', ('host', 'port'))

    def assert_equals(a, b, msg=None):
        assert a == b, "%r != %r: %s" % (a, b, msg)

    def test_parse(address, host_port, is_valid=True, allow_ranges=False):
        try:
            h = parse_address(address, allow_ranges=allow_ranges)
        except AnsibleParserError as e:
            if is_valid:
                raise

# Generated at 2022-06-23 05:17:16.408345
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:23.876413
# Unit test for function parse_address
def test_parse_address():
    # Basic hostname
    assert parse_address("foo") == ('foo', None)

    # Hostname with port
    assert parse_address("foo:42") == ('foo', 42)

    # IPv4 address
    assert parse_address("192.0.2.1") == ('192.0.2.1', None)

    # IPv4 address with port
    assert parse_address("192.0.2.1:42") == ('192.0.2.1', 42)

    # IPv6 address
    assert parse_address("2001:db8::1") == ('2001:db8::1', None)

    # IPv6 address with port
    assert parse_address("[2001:db8::1]:42") == ('2001:db8::1', 42)

    # IPv4 address with port as IPv6 address
    assert parse_address

# Generated at 2022-06-23 05:17:29.236894
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:41.661795
# Unit test for function parse_address
def test_parse_address():
    print("Testing parse_address")
    assert parse_address('foobar') == ('foobar', None)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)

# Generated at 2022-06-23 05:17:50.351683
# Unit test for function parse_address
def test_parse_address():
    print('Testing function parse_address()')

    def test_parse_address_return(expression, expected):
        result = parse_address(expression)
        if result == expected:
            print('\tpassed: %s ==> %s' % (expression, expected))
        else:
            print('\tfailed: %s ==> %s  (expected: %s)' % (expression, result, expected))

    test_parse_address_return('127.0.0.1:1234', ('127.0.0.1', 1234))
    test_parse_address_return('127.0.0.1', ('127.0.0.1', None))
    test_parse_address_return('127.0.0.1:abc', ('127.0.0.1', None))
    test_parse_address_return

# Generated at 2022-06-23 05:18:02.282774
# Unit test for function parse_address
def test_parse_address():
    import os

    # Before running this unit test, verify the path.
    # pylint: disable=line-too-long
    expected_path = '/opt/ansible-test/ansible/test/lib/ansible/module_utils/network/common/utils.py'
    if not os.path.isfile(expected_path):
        print('Unit test error: Not in Ansible Git repository. Please run from ./hacking/test-module')
        exit(1)

    # Arrays used for test cases
    # Each test case is a tuple of input host, expected return host, expected return port

# Generated at 2022-06-23 05:18:10.281891
# Unit test for function parse_address
def test_parse_address():

    # good ipv4
    assert parse_address('192.0.2.3') == (u'192.0.2.3', None)
    # good ipv6, no port
    assert parse_address('2001:db8::1') == (u'2001:db8::1', None)
    # good ipv4 with port
    assert parse_address('192.0.2.3:1234') == (u'192.0.2.3', 1234)
    # good ipv6 with port
    assert parse_address('[2001:db8::1]:1234') == (u'2001:db8::1', 1234)
    # good ipv4 with range
    assert parse_address('192.0.2.[1:5]') == (u'192.0.2.[1:5]', None)

# Generated at 2022-06-23 05:18:20.870558
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)

    assert parse_address('foo.example.com') == ('foo.example.com', None)

    assert parse_address('192.168.2.5') == ('192.168.2.5', None)

    assert parse_address('192.168.2.5:80') == ('192.168.2.5', 80)

    assert parse_address('[192.168.2.5]') == ('192.168.2.5', None)

    assert parse_address('[192.168.2.5]:80') == ('192.168.2.5', 80)

    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)


# Generated at 2022-06-23 05:18:31.491185
# Unit test for function parse_address
def test_parse_address():
    def t(s, host=None, port=None):
        assert parse_address(s) == (host, port)

    # TODO: test IPv6 with ranges
    # TODO: test host patterns with ranges

    t('foo', 'foo', None)
    t('foo.example.com', 'foo.example.com', None)
    t('foo.example.com:123', 'foo.example.com', 123)
    t('[foo.example.com]:123', 'foo.example.com', 123)
    t('192.168.1.1', '192.168.1.1', None)
    t('192.168.1.1:123', '192.168.1.1', 123)
    t('[192.168.1.1]:123', '192.168.1.1', 123)


# Generated at 2022-06-23 05:18:42.782808
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:53.515354
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('localhost')
    assert host == 'localhost' and port is None
    assert parse_address('localhost:2200') == ('localhost', 2200)
    assert parse_address('localhost', allow_ranges=True) == ('localhost', None)
    assert parse_address('example.com:2200', allow_ranges=True) == ('example.com', 2200)
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:2200') == ('192.168.1.1', 2200)
    assert parse_address('192.168.1.1', allow_ranges=True) == ('192.168.1.1', None)

# Generated at 2022-06-23 05:19:05.089004
# Unit test for function parse_address
def test_parse_address():
    """Unit test for function parse_address"""

    # Verify that we get the same answers as Ansible prior to 2.5.
    old_targets = [
        '',
        'foobar',
        '1.2.3.4',
        'a::b',
        'a[1:3]',
        '1.2.3.4:5',
        'a::b:6',
        '[a::b]:7',
        '[1.2.3.4]:8',
        '[a[1:3]]:9',
        '[1.2.3.4:5]',
        '[a::b:6]',
        '[a[1:3]:7]',
    ]


# Generated at 2022-06-23 05:19:16.273977
# Unit test for function parse_address
def test_parse_address():

    def check(addr, expect_host, expect_port):
        (host, port) = parse_address(addr)
        assert host == expect_host
        assert port == expect_port, "%s: got port %d, expected %d" % (addr, port, expect_port)

    # Portless IPv4, IPv6, and hostnames.
    check('1.2.3.4', '1.2.3.4', None)
    check('2001:0db8:85a3:0000:0000:8a2e:0370:7334', '2001:0db8:85a3:0000:0000:8a2e:0370:7334', None)
    check('localhost', 'localhost', None)
    check('example.com', 'example.com', None)

    # IPv4 addresses, IPv6 addresses,

# Generated at 2022-06-23 05:19:27.944131
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('foo.example.com')
    assert host == 'foo.example.com' and port is None
    host, port = parse_address('foo.example.com:8080')
    assert host == 'foo.example.com' and port == 8080
    host, port = parse_address('192.0.2.1')
    assert host == '192.0.2.1' and port is None
    host, port = parse_address('192.0.2.1:80')
    assert host == '192.0.2.1' and port == 80
    host, port = parse_address('[192.0.2.1]:80')
    assert host == '192.0.2.1' and port == 80
    host, port = parse_address('2001:db8::1')
   

# Generated at 2022-06-23 05:19:37.105158
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('localhost:5555')
    assert host == 'localhost' and port == 5555

    (host, port) = parse_address('foo[bar]:5555')
    assert host == 'foo[bar]' and port == 5555

    (host, port) = parse_address('foo[0:3].example.com:5555')
    assert host == 'foo[0:3].example.com' and port == 5555

    (host, port) = parse_address('foo[0-3].example.com:5555')
    assert host == 'foo[0-3].example.com' and port == 5555

    (host, port) = parse_address('foo[0:3].example.com[1:2]')

# Generated at 2022-06-23 05:19:47.975295
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:57.726242
# Unit test for function parse_address
def test_parse_address():
    # Matches
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:23') == ('localhost', 23)
    assert parse_address('localhost:23', allow_ranges=True) == ('localhost', 23)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:23') == ('foo.example.com', 23)
    assert parse_address('foo.example.com:23', allow_ranges=True) == ('foo.example.com', 23)
    assert parse_address('[foo.example.com]') == ('foo.example.com', None)
    assert parse_address('[foo.example.com]:23') == ('foo.example.com', 23)

# Generated at 2022-06-23 05:20:08.006372
# Unit test for function parse_address
def test_parse_address():
    def test_one(address, expect_host, expect_port, want_range=False, want_exception=None):
        try:
            host, port = parse_address(address, allow_ranges=want_range)
            if expect_host is not None:
                assert host == expect_host
            if expect_port is not None:
                assert port == expect_port
        except AnsibleError as err:
            if want_exception is None:
                assert False
            else:
                assert type(err) == want_exception

    test_one('foo', 'foo', None)
    test_one('foo:12', 'foo', 12)
    test_one('foo[1:2]', 'foo[1:2]', None, want_range=True)

# Generated at 2022-06-23 05:20:19.015621
# Unit test for function parse_address
def test_parse_address():
    """
    Test the parse_address method

    Note: this test is specific to python 3 and
    should not be run for python 2:
      https://github.com/ansible/ansible/issues/22693
    """

    import sys
    if sys.version_info[0] == 2:
        return

    # Test IP ranges
    # IPv6, including ipv4-in-ipv6
    assert parse_address("[1:2:3:4:5:6:7:8]", allow_ranges=True) == ('[1:2:3:4:5:6:7:8]', None)

# Generated at 2022-06-23 05:20:30.108554
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:38.410165
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[example.com]:22') == ('example.com', 22)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('2001:db8::1:2:3:4:5') == ('2001:db8::1:2:3:4:5', None)

# Generated at 2022-06-23 05:20:50.068326
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:00.305385
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('foo.example.com')
    assert host == 'foo.example.com'
    assert port is None

    host, port = parse_address('127.0.0.1')
    assert host == '127.0.0.1'
    assert port is None

    host, port = parse_address('[::1]')
    assert host == '::1'
    assert port is None

    host, port = parse_address('127.0.0.1:22')
    assert host == '127.0.0.1'
    assert port == 22

    host, port = parse_address('foo.example.com:22')
    assert host == 'foo.example.com'
    assert port == 22

    host, port = parse_address('[::1]:22')

# Generated at 2022-06-23 05:21:10.618969
# Unit test for function parse_address
def test_parse_address():
    foo = parse_address
    assert foo('foo[1:3]') == ('foo[1:3]', None)
    assert foo('foo[1:3]:10') == ('foo[1:3]', 10)
    assert foo('[foo[1:3]]:10') == ('foo[1:3]', 10)
    assert foo('[foo[1:3]]:010') == ('foo[1:3]', 10)
    assert foo('foo:10') == ('foo', 10)
    assert foo('foo:[10:11]') == ('foo:[10:11]', None)
    assert foo('[1.2.3.4]:010') == ('1.2.3.4', 10)
    assert foo('1.2.3.4') == ('1.2.3.4', None)

# Generated at 2022-06-23 05:21:20.439971
# Unit test for function parse_address
def test_parse_address():
    # Tests for IPv4 address
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:123') == ('192.0.2.3', 123)
    assert parse_address('[192.0.2.3]:123') == ('192.0.2.3', 123)
    assert parse_address('[192.0.2.3:123]') == ('192.0.2.3:123', None)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3/29]') == ('192.0.2.3/29', None)