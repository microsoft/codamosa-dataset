

# Generated at 2022-06-23 05:11:24.574894
# Unit test for function parse_address
def test_parse_address():
    # Test string not containing a valid ip or hostname
    try:
        assert parse_address('localhost:8080') == (None, None)
    except AssertionError:
        pass

    # Test connected host containing a valid address or hostname and port number
    try:
        assert parse_address('localhost:8080') == ('localhost', 8080)
    except AssertionError:
        pass

    # Test connected host containing a valid address or hostname without port number
    try:
        assert parse_address('localhost') == ('localhost', None)
    except AssertionError:
        pass

    # Test connected host containing a valid ipv4 address with port number

# Generated at 2022-06-23 05:11:36.135711
# Unit test for function parse_address
def test_parse_address():
    from nose.tools import assert_equal, raises

    assert_equal(parse_address(':2022'), (None, 2022))
    assert_equal(parse_address('[::1]:2222'), ('::1', 2222))
    assert_equal(parse_address('2001:db8::1'), ('2001:db8::1', None))
    assert_equal(parse_address('192.168.1.2'), ('192.168.1.2', None))
    assert_equal(parse_address('example.com'), ('example.com', None))
    assert_equal(parse_address('foo[1:3].example.com:2222'), ('foo[1:3].example.com', 2222))

# Generated at 2022-06-23 05:11:47.255602
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:22") == ("localhost", 22)
    assert parse_address("localhost:65535") == ("localhost", 65535)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:22") == ("127.0.0.1", 22)
    assert parse_address("127.0.0.1:65535") == ("127.0.0.1", 65535)
    assert parse_address("127.0.0.1:65536") == (None, None)  # Invalid port
    assert parse_address("::1") == ("::1", None)

# Generated at 2022-06-23 05:11:58.290164
# Unit test for function parse_address
def test_parse_address():
    # Test without ranges
    assert ('foo', None) == parse_address('foo')
    assert ('foo', 2222) == parse_address('foo:2222')
    assert ('192.0.2.3', None) == parse_address('192.0.2.3')
    assert ('192.0.2.3', 2222) == parse_address('192.0.2.3:2222')
    assert (None, None) == parse_address('192.0.2.3:')
    assert ('0::0', None) == parse_address('0::0')
    assert ('0::0', 2222) == parse_address('0::0:2222')
    assert (None, None) == parse_address('0::0:')
    assert ('[192.0.2.3]', 2222) == parse_

# Generated at 2022-06-23 05:12:07.974288
# Unit test for function parse_address
def test_parse_address():
    # Test valid IPv4 addresses
    assert parse_address("192.0.2.3") == ("192.0.2.3", None)
    assert parse_address("[192.0.2.3]") == ("192.0.2.3", None)
    assert parse_address("192.0.2.3:1") == ("192.0.2.3", 1)
    assert parse_address("[192.0.2.3]:1") == ("192.0.2.3", 1)

    # Test valid IPv6 addresses
    assert parse_address("0:0:0:0:0:0:0:1") == ("0:0:0:0:0:0:0:1", None)

# Generated at 2022-06-23 05:12:16.375382
# Unit test for function parse_address
def test_parse_address():
    import sys
    import pytest
    from ansible.compat.tests import unittest

    # pylint: disable=missing-docstring

    # The unittest module was only introduced in 2.7, which is when we
    # started requiring it, so this is fine.
    class TestParseAddress(unittest.TestCase):
        def assertParse(self, address, expected, *args, **kwargs):
            actual = parse_address(address, *args, **kwargs)
            self.assertEqual(actual, expected)

        def assertParseError(self, address, *args, **kwargs):
            with self.assertRaises(AnsibleParserError):
                parse_address(address, *args, **kwargs)


# Generated at 2022-06-23 05:12:26.698460
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:38.933929
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:48.385480
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[3ffe:2a00:100:7031::1]:80', True) == ('3ffe:2a00:100:7031::1', 80)
    assert parse_address('3ffe:2a00:100:7031::1:80', True) == ('3ffe:2a00:100:7031::1', 80)
    assert parse_address('[3ffe:2a00:100:7031::1]', True) == ('3ffe:2a00:100:7031::1', None)
    assert parse_address('3ffe:2a00:100:7031::1', True) == ('3ffe:2a00:100:7031::1', None)

# Generated at 2022-06-23 05:12:57.483877
# Unit test for function parse_address
def test_parse_address():
    failed = []


# Generated at 2022-06-23 05:13:08.225791
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:16.391234
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com:5432") == ('foo.example.com', 5432)
    assert parse_address("foo.example.com") == ('foo.example.com', None)
    assert parse_address("foo.example.com:") == ('foo.example.com', None)
    assert parse_address("192.168.1.1:5432") == ('192.168.1.1', 5432)
    assert parse_address("192.168.1.1") == ('192.168.1.1', None)
    assert parse_address("192.168.1.1:") == ('192.168.1.1', None)
    assert parse_address("[foo.example.com]:5432") == ('foo.example.com', 5432)

# Generated at 2022-06-23 05:13:24.281565
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:35.049706
# Unit test for function parse_address
def test_parse_address():
    from collections import namedtuple

    HostPort = namedtuple('HostPort', ['host', 'port'])
    IP = namedtuple('IP', ['ip', 'port'])


# Generated at 2022-06-23 05:13:46.611032
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:55.256452
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:80") == ("foo.example.com", 80)
    assert parse_address("foo.example.com:443") == ("foo.example.com", 443)
    assert parse_address("foo.example.com:23") == ("foo.example.com", 23)
    assert parse_address("foo.example.com:65535") == ("foo.example.com", 65535)
    assert parse_address("foo.example.com:1") == ("foo.example.com", 1)
    assert parse_address("[foo.example.com]") == ("foo.example.com", None)

# Generated at 2022-06-23 05:14:04.950581
# Unit test for function parse_address
def test_parse_address():
    # Test with alphanumeric range
    assert parse_address("foo", allow_ranges=True) == ("foo", None)
    assert parse_address("f[a:b]", allow_ranges=True) == ("f[a:b]", None)
    assert parse_address("f[0:5]-[x:z]", allow_ranges=True) == ("f[0:5]-[x:z]", None)
    assert parse_address("f[a:b]:9", allow_ranges=True) == ("f[a:b]", 9)
    assert parse_address("f[0:5]-[x:z]:9", allow_ranges=True) == ("f[0:5]-[x:z]", 9)

    # Test with numeric ranges

# Generated at 2022-06-23 05:14:15.606398
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address(':') == (None, None)
    assert parse_address('foo:bar') == (None, None)
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo[1:3]:123') == ('foo[1:3]', 123)
    assert parse_address('10.0.0.1:123') == ('10.0.0.1', 123)
    assert parse_address('::1:123') == ('::1', 123)
    assert parse_address('[::1]:123') == ('[::1]', 123)

# Generated at 2022-06-23 05:14:24.658926
# Unit test for function parse_address
def test_parse_address():
    # IPv4
    assert parse_address("192.0.2.1:1234") == ("192.0.2.1", 1234)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("[192.0.2.1]:1234") == ("192.0.2.1", 1234)

    # IPv6
    assert parse_address("[::1]:1234") == (u"::1", 1234)
    assert parse_address("[::1]") == (u"::1", None)
    assert parse_address("[fffe::1]:1234") == (u"fffe::1", 1234)

    # Hostname

# Generated at 2022-06-23 05:14:36.696518
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:46.794909
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:57.586115
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('') == (None, None)
    assert parse_address('[192.0.2.0]') == ('192.0.2.0', None)
    assert parse_address(':9876') == (None, 9876)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:9876') == ('2001:db8::1', 9876)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('[foo.example.com]:9876') == ('foo.example.com', 9876)

# Generated at 2022-06-23 05:15:08.146247
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('[::1]', 22)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('10.0.0.1:22') == ('10.0.0.1', 22)
    assert parse_address('10.0.0.1[0:4]') == ('10.0.0.1[0:4]', None)
    assert parse_address('10.0.0.1[0:4]:22') == ('10.0.0.1[0:4]', 22)
    assert parse_address('foo[0:4]') == ('foo[0:4]', None)
    assert parse_address('foo[0:4]:22') == ('foo[0:4]', 22)
   

# Generated at 2022-06-23 05:15:18.688489
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:30.363853
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.network import valid_ipv4, valid_ipv6
    from ansible.utils.network import parse_address as _parse_addr

    # Make sure that empty addresses are handled correctly.
    (host, port) = _parse_addr("")
    assert host is None
    assert port is None

    # Make sure that short IPv4 addresses are handled correctly.
    for addr in ["10.0.1.2", "10.1.2"]:
        (host, port) = _parse_addr(addr)
        assert host is None
        assert port is None

    # Make sure that valid hostnames without port numbers are handled correctly.
    for addr in ["www.example.com", "foo-bar-baz_9"]:
        (host, port) = _parse_addr(addr)
        assert host == addr

# Generated at 2022-06-23 05:15:39.943957
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("127.0.0.1") == ('127.0.0.1', None)
    assert parse_address("127.0.0.1:22") == ('127.0.0.1', 22)
    assert parse_address("127[0.0.1]") == ('127[0.0.1]', None)
    assert parse_address("127[0.0.1]:22") == ('127[0.0.1]', 22)
    assert parse_address("[127.0.0.1]") == ('[127.0.0.1]', None)
    assert parse_address("[127.0.0.1]:22") == ('[127.0.0.1]', 22)

# Generated at 2022-06-23 05:15:51.776696
# Unit test for function parse_address
def test_parse_address():
    import pytest

    def test_valid(address, expect_host, expect_port):
        (host, port) = parse_address(address)
        assert host == expect_host
        assert port == expect_port

    def test_invalid(address):
        with pytest.raises(AnsibleError):
            parse_address(address)

    test_valid('localhost', 'localhost', None)
    test_valid('127.0.0.1', '127.0.0.1', None)
    test_valid('127.0.0.1:80', '127.0.0.1', 80)
    test_invalid('[127.0.0.1]')
    test_valid('[127.0.0.1]:80', '127.0.0.1', 80)

# Generated at 2022-06-23 05:16:02.283413
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:10.823204
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:23.276370
# Unit test for function parse_address
def test_parse_address():

    def test(addr, allow_ranges=False, host=None, port=None):
        h, p = parse_address(addr, allow_ranges=allow_ranges)
        if (host, port) != (h, p):
            raise AssertionError(addr, (host, port), (h, p))
    test('example.com', host='example.com')
    test('example.com:22', host='example.com', port=22)
    test('example.com:00', host='example.com', port=0)
    test('example.com:65535', host='example.com', port=65535)
    test('example.com:65536', host='example.com', port=65536)

# Generated at 2022-06-23 05:16:32.852399
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo:22") == ("foo", 22)
    assert parse_address("[foo]:22") == ("foo", 22)
    assert parse_address("foo[a:z]:22") == ("foo[a:z]", 22)
    assert parse_address("[foo]:22") == ("foo", 22)
    assert parse_address("[foo[a:z]]:22") == ("foo[a:z]", 22)
    assert parse_address("[foo[a:z]]:22") == ("foo[a:z]", 22)

    assert parse_address("192.168.0.1") == ("192.168.0.1", None)

# Generated at 2022-06-23 05:16:40.055863
# Unit test for function parse_address
def test_parse_address():
    import pytest
    from collections import namedtuple


# Generated at 2022-06-23 05:16:52.511049
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("127.0.0.1:22") == ('127.0.0.1', 22)
    assert parse_address("127.0.0.1") == ('127.0.0.1', None)
    assert parse_address("[127.0.0.1]") == ('127.0.0.1', None)
    assert parse_address("[127.0.0.1]:22") == ('127.0.0.1', 22)
    assert parse_address("foo[0:2].example.com") == ('foo[0:2].example.com', None)
    assert parse_address("foo[0:2].example.com", allow_ranges=True) == ('foo[0:2].example.com', None)

# Generated at 2022-06-23 05:17:04.731203
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost", True) == ("localhost", None)
    assert parse_address("localhost", False) == ("localhost", None)
    assert parse_address("localhost:100", True) == ("localhost", 100)
    assert parse_address("localhost:100", False) == ("localhost", 100)
    assert parse_address("192.0.2.0", True) == ("192.0.2.0", None)
    assert parse_address("192.0.2.0", False) == ("192.0.2.0", None)
    assert parse_address("192.0.2.0:100", True) == ("192.0.2.0", 100)
    assert parse_address("192.0.2.0:100", False) == ("192.0.2.0", 100)

# Generated at 2022-06-23 05:17:16.007478
# Unit test for function parse_address
def test_parse_address():
    from ansible import constants as C
    host, port = parse_address('172.18.0.1:624')
    assert (host, port) == ('172.18.0.1', 624)
    host, port = parse_address('172.18.0.1')
    assert (host, port) == ('172.18.0.1', None)
    host, port = parse_address('[::1]:624')
    assert (host, port) == ('::1', 624)
    host, port = parse_address('[::1]')
    assert (host, port) == ('::1', None)
    host, port = parse_address('[1:2::]')
    assert (host, port) == ('1:2::', None)

# Generated at 2022-06-23 05:17:28.583608
# Unit test for function parse_address
def test_parse_address():
    def test(address, host, port, allow_ranges):
        actual = parse_address(address, allow_ranges=allow_ranges)
        expected = host, port
        if actual != expected:
            import pprint
            print("Input: %s (allow_ranges=%s)" % (address, allow_ranges))
            print("Expected: %s" % pprint.pformat(expected))
            print("Actual:   %s" % pprint.pformat(actual))
        else:
            print("Input: %s (allow_ranges=%s) - Expected and Actual matches" % (address, allow_ranges))
    test('foo[1:3]:22', 'foo[1:3]', 22, True)

# Generated at 2022-06-23 05:17:39.112431
# Unit test for function parse_address
def test_parse_address():

    def assert_parse(address, host, port, allow_ranges=False):
        (actual_host, actual_port) = parse_address(address, allow_ranges)
        assert actual_host == host
        assert actual_port == port

    # Tests for function parse_address in its basic form
    assert_parse('172.16.0.0',     '172.16.0.0', None)
    assert_parse('172.16.0.0:80',  '172.16.0.0', 80)
    assert_parse('172.16.0.0:443', '172.16.0.0', 443)
    assert_parse('foo.com',        'foo.com', None)
    assert_parse('foo.com:22',     'foo.com', 22)

# Generated at 2022-06-23 05:17:48.818779
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:01.047131
# Unit test for function parse_address
def test_parse_address():
    """
    Makes sure that the parse_address function behaves as expected.
    """

# Generated at 2022-06-23 05:18:09.493578
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:1234') == ('foo.example.com', 1234)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:1234') == ('foo[1:3].example.com', 1234)
    assert parse_address('foo[1:3].example.com:1234', allow_ranges=True) == ('foo[1:3].example.com', 1234)
    assert parse_address('192.0.2.42:1234') == ('192.0.2.42', 1234)

# Generated at 2022-06-23 05:18:20.210848
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:28.503142
# Unit test for function parse_address
def test_parse_address():
    # pylint: disable=missing-docstring
    def test(address, expected):
        parsed = parse_address(address)
        if parsed != expected:
            print("expecting %s from %s, got %s" % (expected, address, parsed))
            exit(1)

    test("[fe80::1%en0]:22", ("fe80::1%en0", 22))
    test("[fe80::1%en0]", ("fe80::1%en0", None))
    test("fe80::1%en0:22", ("fe80::1%en0", 22))
    test("fe80::1%en0", ("fe80::1%en0", None))
    test("[127.0.0.1]:22", ("127.0.0.1",  22))

# Generated at 2022-06-23 05:18:40.016459
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('[2001:db8::1]:80') == ('2001:db8::1', 80)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:80') == ('2001:db8::1', 80)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('[example.com]:80') == ('example.com', 80)


# Generated at 2022-06-23 05:18:50.830999
# Unit test for function parse_address
def test_parse_address():  # noqa: N802
    """
    A host port is optional and can be an integer or integer expression.
    """


# Generated at 2022-06-23 05:19:02.911912
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('[2001:db8::1]:22') == (u'2001:db8::1', 22)
    assert parse_address('2001:db8::1:22') == (None, None)
    assert parse_address('2001:db8::1') == (u'2001:db8::1', None)

    assert parse_address('[192.0.2.1]:22') == (u'192.0.2.1', 22)
    assert parse_address('192.0.2.1:22') == (u'192.0.2.1', 22)
    assert parse_address('192.0.2.1') == (u'192.0.2.1', None)

    assert parse_address('[host.example.com]:22') == (u'host.example.com', 22)


# Generated at 2022-06-23 05:19:11.562127
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:21.889481
# Unit test for function parse_address
def test_parse_address():
    hostname_full = 'foo.example.com'
    hostname_short = 'foo'
    ipv4_full = '10.0.0.1'
    ipv4_short = '10.0'
    ipv6_full = '2001:0db8:85a3:08d3:1319:8a2e:0370:7344'
    ipv6_short = '2001:0db8:85a3:08d3:1319:8a2e:0370'
    ipv6_shortest = '2001:0db8:85a3:08d3:1319:8a2e'
    ipv6_full_with_port = '[2001:0db8:85a3:08d3:1319:8a2e:0370:7344]:80'

# Generated at 2022-06-23 05:19:33.252963
# Unit test for function parse_address
def test_parse_address():
    """
    Unit test for function parse_address()
    """


# Generated at 2022-06-23 05:19:43.233606
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:53.038753
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.network import parse_address
    from ansible.compat.tests.mock import patch

# Generated at 2022-06-23 05:20:03.447474
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address("[1.2.3.4]:5678")) == ('1.2.3.4', 5678)  # noqa
    assert (parse_address("example.com:5678")) == ('example.com', 5678)  # noqa
    assert (parse_address("example.com")) == ('example.com', None)  # noqa
    assert (parse_address("[1.2.3.4]")) == ('1.2.3.4', None)  # noqa
    assert (parse_address("1.2.3.4")) == ('1.2.3.4', None)  # noqa
    assert (parse_address("host-1")) == ('host-1', None)  # noqa
    assert (parse_address("host_1")) == ('host_1', None) 

# Generated at 2022-06-23 05:20:12.254784
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:21.270400
# Unit test for function parse_address
def test_parse_address():
    """
    This isn't really a unit test in the usual sense. It just runs a set of
    pre-defined test cases.
    """
    # (input, (expected host, expected port))

# Generated at 2022-06-23 05:20:32.869122
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:43.965353
# Unit test for function parse_address
def test_parse_address():
    """
    Ensure that the parse_address function can parse all valid addresses,
    and fails on all invalid addresses.
    """


# Generated at 2022-06-23 05:20:55.143380
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("") == (None, None)
    assert parse_address("a.b.c") == ("a.b.c", None)
    assert parse_address("a.b.c:5") == ("a.b.c", 5)
    assert parse_address("192.168.1.1") == ("192.168.1.1", None)
    assert parse_address("192.168.1.1:5") == ("192.168.1.1", 5)
    assert parse_address("[1.2.3.4]") == ("1.2.3.4", None)
    assert parse_address("[1.2.3.4]:5") == ("1.2.3.4", 5)

# Generated at 2022-06-23 05:21:03.544502
# Unit test for function parse_address
def test_parse_address():
    # Positive cases
    assert parse_address('[::1:2:3:4:5:6:7:8]:42') == ("::1:2:3:4:5:6:7:8", 42)
    assert parse_address('[::ffff:192.0.2.3]:42') == ("::ffff:192.0.2.3", 42)
    assert parse_address('[::ffff:c000:203]:42') == ("::ffff:c000:203", 42)
    assert parse_address('foo.example.com:42') == ("foo.example.com", 42)
    assert parse_address('[foo.example.com]:42') == ("foo.example.com", 42)

# Generated at 2022-06-23 05:21:12.298408
# Unit test for function parse_address
def test_parse_address():
    import pytest

    # Failing cases

# Generated at 2022-06-23 05:21:22.518484
# Unit test for function parse_address