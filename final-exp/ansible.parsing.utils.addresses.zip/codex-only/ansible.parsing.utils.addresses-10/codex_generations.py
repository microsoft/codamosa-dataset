

# Generated at 2022-06-23 05:11:22.552206
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class ParseAddressTests(unittest.TestCase):

        def test_ipv4(self):
            self.assertEqual(parse_address('127.0.0.1'), ('127.0.0.1', None))
            self.assertEqual(parse_address('127.0.0.1:80'), ('127.0.0.1', 80))
            self.assertEqual(parse_address('127.0.0.1[1:2]'), ('127.0.0.1[1:2]', None))
            self.assertEqual(parse_address('127.0.0.1[1:2]:80'), ('127.0.0.1[1:2]', 80))

# Generated at 2022-06-23 05:11:35.393210
# Unit test for function parse_address
def test_parse_address():
    # Port in square brackets
    assert parse_address("[1:3:4]:1234") == ("[1:3:4]", 1234)
    assert parse_address("[1:3:4]", allow_ranges=False) == ("[1:3:4]", None)

    # Port in non-bracketed host identifier
    assert parse_address("1:3:4:1234") == ("1:3:4", None)
    assert parse_address("example.com:1234") == ("example.com", 1234)
    assert parse_address("[::ffff:c000:203]:1234") == ("[::ffff:c000:203]", 1234)

# Generated at 2022-06-23 05:11:46.586174
# Unit test for function parse_address
def test_parse_address():
    def test(host, port=None):
        if port is not None:
            test_string = "{0}:{1}".format(host, port)
        else:
            test_string = host

        result = parse_address(test_string)
        assert result[0] == host
        assert result[1] == port

    # IPv4 tests
    test('192.0.2.3', 80)
    test('192.0.2.3', 0)
    test('192.0.2.3')
    test('[192.0.2.3]:80')
    test('192.0.2.3[0:2]', 80)
    test('192.0.2.3[0:2]')

    # IPv6 tests

# Generated at 2022-06-23 05:11:55.660773
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:06.094641
# Unit test for function parse_address
def test_parse_address():
    from ansible.module_utils._text import to_text


# Generated at 2022-06-23 05:12:16.083307
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:26.498710
# Unit test for function parse_address
def test_parse_address():
    def assert_host_port(address, host, port):
        assert parse_address(address) == (host, port)

    # Make sure we can parse all valid strings and extract the right information
    assert_host_port('localhost', 'localhost', None)
    assert_host_port('localhost:22', 'localhost', 22)
    assert_host_port('[::1]', '::1', None)
    assert_host_port('[::1]:22', '::1', 22)
    assert_host_port('[::1]:22', '::1', 22)
    assert_host_port('foo[1:2].example.com', 'foo[1:2].example.com', None)

# Generated at 2022-06-23 05:12:35.106733
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:2222') == ('localhost', 2222)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:2222') == ('::1', 2222)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:2222') == ('192.0.2.1', 2222)
    assert parse_address('[fe80::1]') == ('fe80::1', None)
    assert parse_address('[fe80::1]:2222') == ('fe80::1', 2222)

# Generated at 2022-06-23 05:12:46.484714
# Unit test for function parse_address
def test_parse_address():
    import pytest

    # Test that we can parse a range expression even if we don't want them
    assert parse_address("foo[0:5]") == ("foo[0:5]", None)
    assert parse_address("[192.168.1.1]") == ("[192.168.1.1]", None)
    assert parse_address("[192.168.1:1:2]") == ("[192.168.1:1:2]", None)
    assert parse_address("[192.168.1:1:2]:8080") == ("[192.168.1:1:2]", 8080)
    assert parse_address("foo[0:5]:8080") == ("foo[0:5]", 8080)

    # Test that we can parse a range expression if we want to
    assert parse_

# Generated at 2022-06-23 05:12:56.223239
# Unit test for function parse_address
def test_parse_address():
    """
    Test that parse_address correctly parses IPv4 and IPv6 addresses.
    The basic format is allowed or not, with or without ranges.
    Ranges or not are allowed or not.
    """

# Generated at 2022-06-23 05:13:07.166212
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:16.829977
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)

    assert parse_address('www.example.com') == ('www.example.com', None)
    assert parse_address('www.example.com:80') == ('www.example.com', 80)

    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:80') == ('192.0.2.3', 80)

    assert parse_address('[2001:db8::1]', allow_ranges=True) == ('2001:db8::1', None)

# Generated at 2022-06-23 05:13:24.449461
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:35.165478
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:46.715762
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:1') == ('foo', 1)
    assert parse_address('foo:bar:1') == ('foo:bar', 1)
    assert parse_address('foo:1:bar') == ('foo', 1)
    assert parse_address('[foo:bar]:1') == ('[foo:bar]', 1)

    # Test various IPv4 addresses (all valid)
    assert parse_address('0') == ('0', None)
    assert parse_address('0.1') == ('0.1', None)
    assert parse_address('0.0.0.0') == ('0.0.0.0', None)
    assert parse_address('255.255.255.255') == ('255.255.255.255', None)
    assert parse

# Generated at 2022-06-23 05:13:55.327250
# Unit test for function parse_address
def test_parse_address():
    import pytest
    host, port = parse_address('[2001::1]:12345')
    assert host == '2001::1'
    assert port == 12345

    # hostname with alphanumeric-only ranges
    host, port = parse_address('[a:z]:12345')
    assert host == 'a:z'
    assert port == 12345

    # numeric range with step
    host, port = parse_address('[1:3:2]')
    assert host == '1:3:2'
    assert port == None

    # alphanumeric range with step
    host, port = parse_address('[a:z:3]')
    assert host == 'a:z:3'
    assert port == None

    # hostname with numeric ranges:

# Generated at 2022-06-23 05:14:05.029399
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:15.684436
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address('foo:0') == ('foo', 0)
    assert parse_address('foo:1') == ('foo', 1)
    assert parse_address('foo:2') == ('foo', 2)
    assert parse_address('foo:13') == ('foo', 13)
    assert parse_address('foo:21') == ('foo', 21)
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo:1123') == ('foo', 1123)
    assert parse_address('foo:2113') == ('foo', 2113)

    assert parse_address('[foo]') == ('foo', None)

# Generated at 2022-06-23 05:14:24.733117
# Unit test for function parse_address

# Generated at 2022-06-23 05:14:34.498618
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_basic_hostname(self):
            """
            hostname without port
            """

            s = 'foo.example.com'
            self.assertEqual(parse_address(s), ('foo.example.com', None))

        def test_hostname_with_port(self):
            """
            hostname with port
            """

            s = 'foo.example.com:22'
            self.assertEqual(parse_address(s), ('foo.example.com', 22))

        def test_hostname_with_port_in_brackets(self):
            """
            hostname with port in brackets
            """

            s = '[foo.example.com]:22'

# Generated at 2022-06-23 05:14:45.107376
# Unit test for function parse_address
def test_parse_address():
    """
    Unit test for function parse_address()
    """
    print("Testing function utils.parse_address")
    # Test if true host and port return
    assert parse_address("foo:1") == ('foo', 1)
    assert parse_address("foo.example.com:65537") == ("foo.example.com", 65537)
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:65537") == ("192.0.2.1", 65537)
    assert parse_address("[192.0.2.1]") == ("192.0.2.1", None)

# Generated at 2022-06-23 05:14:53.433133
# Unit test for function parse_address
def test_parse_address():
    def _check_parse(input, host, port):
        h, p = parse_address(input)
        assert h == host, 'expected "%s", got "%s"' % (host, h)
        assert p == port, 'expected "%s", got "%s"' % (port, p)


# Generated at 2022-06-23 05:14:59.540839
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)
    assert parse_address('1.2.3.4[1:3]') == ('1.2.3.4[1:3]', None)
    assert parse_address('1.2.3.4[1:3]:5') == ('1.2.3.4[1:3]', 5)
    assert parse_address(':90') == (':90', None)
    assert parse_address('[1:2:3:4:5:6:7:8]:90') == ('1:2:3:4:5:6:7:8', 90)
    assert parse_address

# Generated at 2022-06-23 05:15:10.685431
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:20.295439
# Unit test for function parse_address
def test_parse_address():
    # Explain what's going on
    print("parse_address():")

    # Tests

# Generated at 2022-06-23 05:15:24.206368
# Unit test for function parse_address
def test_parse_address():

    # Valid IPv4 address with a port specification
    assert parse_address("192.0.2.1:22") == ("192.0.2.1", 22)

    # Invalid IPv4 address, but a valid hostname with a port specification
    assert parse_address("192.0.256.1:22") == ("192.0.256.1", 22)

    # Valid IPv4 address with a port specification
    assert parse_address("192.168.2.1:22") == ("192.168.2.1", 22)

    # Valid IPv4 address without a port specification
    assert parse_address("10.1.1.1") == ("10.1.1.1", None)

    # Valid IPv6 address with a port specification

# Generated at 2022-06-23 05:15:35.187965
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:46.639119
# Unit test for function parse_address
def test_parse_address():
    #
    # Test for function parse_address
    #
    # Simple plain host

    # Test basic host
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    # Test basic host with port
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)

    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:5') == ('foo', 5)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:5') == ('foo.example.com', 5)


# Generated at 2022-06-23 05:15:58.644350
# Unit test for function parse_address
def test_parse_address():
    # host, port
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('example.com:80', allow_ranges=True) == ('example.com', 80)
    assert parse_address('[example.com]:80', allow_ranges=True) == ('example.com', 80)

    # idna: host, port
    assert parse_address('xn--d1abbgf6aiiy.xn--p1ai:80') == ('xn--d1abbgf6aiiy.xn--p1ai', 80)

    # ipv4: host, port

# Generated at 2022-06-23 05:16:08.064652
# Unit test for function parse_address
def test_parse_address():
    def generate_test_range(test_type, test_pattern, expected_host, expected_port):
        def test(self):
            (host, port) = parse_address(test_pattern, allow_ranges=True)
            self.assertEqual(host, expected_host)
            self.assertEqual(port, expected_port)
        return test


# Generated at 2022-06-23 05:16:16.972293
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:22') == ('example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
   

# Generated at 2022-06-23 05:16:27.957397
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:38.569442
# Unit test for function parse_address
def test_parse_address():
    ########################################################################
    # test IPv4 addresses
    ########################################################################
    # basic host with IPv4 address
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    # host with IPv4 address and non-standard port
    assert parse_address('1.2.3.4:5678') == ('1.2.3.4', 5678)

    # host with IPv4 address and non-standard port in brackets (should be ignored)
    assert parse_address('[1.2.3.4]:5678') == ('1.2.3.4', None)

    # host with IPv4 address and fqdn

# Generated at 2022-06-23 05:16:49.345684
# Unit test for function parse_address

# Generated at 2022-06-23 05:16:53.284717
# Unit test for function parse_address

# Generated at 2022-06-23 05:17:00.913356
# Unit test for function parse_address
def test_parse_address():

    # test basic hostnames (unqualified, qualified, with underscore)
    assert "foo" == parse_address("foo")[0]
    assert "foo.example.com" == parse_address("foo.example.com")[0]
    assert "foo_bar" == parse_address("foo_bar")[0]

    # test ipv4
    assert "192.0.2.3" == parse_address("192.0.2.3")[0]
    assert "192.0.2.3" == parse_address("192.0.2.3:1234")[0]

    # test ipv4 with ranges
    assert "192.0.2[0:1].3" == parse_address("192.0.2[0:1].3")[0]

# Generated at 2022-06-23 05:17:09.914812
# Unit test for function parse_address
def test_parse_address():
    p = parse_address

    assert p('foo.bar') == ('foo.bar', None)
    assert p('foo.bar:42') == ('foo.bar', 42)
    assert p('foo[1:3].bar') == ('foo[1:3].bar', None)
    assert p('foo[1:3].bar:42') == ('foo[1:3].bar', 42)
    assert p('[wxyz]') == ('[wxyz]', None)
    assert p('[wxyz]:42') == ('[wxyz]', 42)
    assert p('[0:9]') == ('[0:9]', None)
    assert p('[0:9]:42') == ('[0:9]', 42)

# Generated at 2022-06-23 05:17:19.251897
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("a.example.com", False) == ("a.example.com", None)
    assert parse_address("a.example.com", True) == ("a.example.com", None)

    assert parse_address("a.example.com:1234", False) == ("a.example.com", 1234)
    assert parse_address("a.example.com:1234", True) == ("a.example.com", 1234)

    assert parse_address("[a.example.com]:1234", False) == ("a.example.com", 1234)
    assert parse_address("[a.example.com]:1234", True) == ("a.example.com", 1234)

    assert parse_address("192.0.2.1", False) == ("192.0.2.1", None)

# Generated at 2022-06-23 05:17:30.166907
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ('foo.example.com', None)
    assert parse_address("192.0.2.1") == ('192.0.2.1', None)
    assert parse_address("192.0.2.1:4000") == ('192.0.2.1', 4000)
    assert parse_address("[192.0.2.1]:4000") == ('192.0.2.1', 4000)
    assert parse_address("2001:db8::1") == ('2001:db8::1', None)
    assert parse_address("2001:db8::1:80") == ('2001:db8::1:80', None)
    assert parse_address("[2001:db8::1:80]:80") == ('2001:db8::1:80', 80)

    assert parse_

# Generated at 2022-06-23 05:17:42.501710
# Unit test for function parse_address
def test_parse_address():
    # Test valid addresses
    test_address = "localhost:65535"
    (host, port) = parse_address(test_address)
    assert(host == "localhost")
    assert(port == 65535)

    test_address = "[127.0.0.1]:65535"
    (host, port) = parse_address(test_address)
    assert(host == "127.0.0.1")
    assert(port == 65535)

    test_address = "[::1]:65535"
    (host, port) = parse_address(test_address)
    assert(host == "::1")
    assert(port == 65535)

    test_address = "[::1]"
    (host, port) = parse_address(test_address)
    assert(host == "::1")

# Generated at 2022-06-23 05:17:53.190437
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('') == (None, None)
    assert parse_address(':') == (None, None)
    assert parse_address('[::]') == (None, None)
    assert parse_address('[::]') == (None, None)
    assert parse_address('[::]:') == (None, None)
    assert parse_address('[::]:443') == (None, None)
    assert parse_address('[::]443') == (None, None)
    assert parse_address('[::]443') == (None, None)

    assert parse_address('[::]:443') == ('::', 443)
    assert parse_address('[::1]:443') == ('::1', 443)
    assert parse_address('[::1]') == ('::1', None)


# Generated at 2022-06-23 05:18:04.840722
# Unit test for function parse_address
def test_parse_address():
    # port number parsing
    assert parse_address('123.123.123.123:564') == ('123.123.123.123', 564)
    assert parse_address('[foo.example.com]:564') == ('foo.example.com', 564)
    assert parse_address('foo[20:30].example.com:564') == ('foo[20:30].example.com', 564)

    # IPv4 address parsing
    assert parse_address('123.123.123.123') == ('123.123.123.123', None)
    assert parse_address('123.123.123.[55:66]') == ('123.123.123.[55:66]', None)
    assert parse_address('123.123.[33:44].123') == ('123.123.[33:44].123', None)
   

# Generated at 2022-06-23 05:18:05.397623
# Unit test for function parse_address
def test_parse_address():
    pass

# Generated at 2022-06-23 05:18:16.598558
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:27.322100
# Unit test for function parse_address
def test_parse_address():
    t = parse_address
    assert t("foo:123") == ("foo", 123)
    assert t("foo[0:5]:123") == ("foo[0:5]", 123)
    assert t("[2001:db8:85a3:0:0:8a2e:370:7334]:123") == ("[2001:db8:85a3:0:0:8a2e:370:7334]", 123)
    assert t("[::ffff:192.0.2.3]:123") == ("[::ffff:192.0.2.3]", 123)
    assert t("192.0.2.3") == ("192.0.2.3", None)
    assert t("192.0.2.[5]") == ("192.0.2.[5]", None)

# Generated at 2022-06-23 05:18:39.855523
# Unit test for function parse_address
def test_parse_address():
    # Tests for hostnames
    assert parse_address('foobar') == ('foobar', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:25') == ('::1', 25)
    assert parse_address('[192.0.2.1]:25') == ('192.0.2.1', 25)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:25') == ('192.0.2.1', 25)
    assert parse_address('foo[1:3].example.com:25') == ('foo[1:3].example.com', 25)
    # Test for IPv6

# Generated at 2022-06-23 05:18:50.676427
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.0:22') == ('127.0.0.0', 22)
    assert parse_address('127.0.0.255:22') == ('127.0.0.255', 22)

    # IPv6

# Generated at 2022-06-23 05:19:02.570510
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:11.401469
# Unit test for function parse_address
def test_parse_address():
    # These are valid
    assert parse_address("hostname") == ('hostname', None)
    assert parse_address("hostname:1234") == ('hostname', 1234)
    assert parse_address("hostname1.example.com:1234") == ('hostname1.example.com', 1234)
    assert parse_address("123.123.123.123") == ('123.123.123.123', None)
    assert parse_address("123.123.123.123:1234") == ('123.123.123.123', 1234)
    assert parse_address("[2001:db8::1]") == ('2001:db8::1', None)
    assert parse_address("[2001:db8::1]:1234") == ('2001:db8::1', 1234)

# Generated at 2022-06-23 05:19:21.729390
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None)
    assert parse_address('') == (None, None)
    assert parse_address('123') == (None, None)

    assert parse_address('[::]') == (None, None)
    assert parse_address(':::') == (None, None)
    assert parse_address('[aff::]') == (None, None)
    assert parse_address('[::aff]') == (None, None)
    assert parse_address('[::aff', True) == ('[::aff', None)

    assert parse_address('foo[bar') == (None, None)
    assert parse_address('foo[bar]') == ('foo[bar]', None)

# Generated at 2022-06-23 05:19:33.132207
# Unit test for function parse_address
def test_parse_address():
    good_hosts = [
        'foo.example.com',
        'bar',
        'localhost',
        '127.0.0.1',
        '192.0.2.1',
        '192.168.1.3:99',
        '[192.0.2.3]',
        '[192.0.2.4]:99',
        '2001:db8::1',
        '[2001:db8::1]',
        '[2001:db8::1]:99',
        'foo-[1:3].bar',
        'foo-[x:y].bar',
        'foo-bar.example[x:y:z].com[1:3]',
    ]


# Generated at 2022-06-23 05:19:43.956540
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests.mock import patch

    # Check that we can handle all the variations of IPv4 and IPv6 addresses.
    assert parse_address("192.0.2.3") == ('192.0.2.3', None)
    assert parse_address("2001:db8::1") == ('2001:db8::1', None)
    assert parse_address("2001:db8:0:0:1:0:0:1") == ('2001:db8:0:0:1:0:0:1', None)
    assert parse_address("192.168.1.1:1024") == ('192.168.1.1', 1024)

# Generated at 2022-06-23 05:19:56.329807
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)

    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)

    assert parse_address('foo[1:2].example.com') == ('foo[1:2].example.com', None)

    assert parse_address

# Generated at 2022-06-23 05:20:06.762363
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:18.496966
# Unit test for function parse_address
def test_parse_address():

    # Simple IPv4 addresses with and without a port
    assert parse_address('192.168.0.42')      == ('192.168.0.42', None)
    assert parse_address('192.168.0.42:123')  == ('192.168.0.42', 123)

    # Simple IPv6 addresses with and without a port
    assert parse_address('::1')               == ('::1', None)
    assert parse_address('::1:123')           == ('::1', 123)

    # IPv6 addresses with a scope specifier.
    assert parse_address('fe80::1%eth0')      == ('fe80::1%eth0', None)
    assert parse_address('fe80::1%eth0:123')  == ('fe80::1%eth0', 123)

    # IPv6 addresses in square brackets


# Generated at 2022-06-23 05:20:30.169622
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address('host')) == ('host', None)
    assert (parse_address('host:22')) == ('host', 22)
    assert (parse_address('[::1]:22')) == ('::1', 22)
    assert (parse_address('[::1]')) == ('::1', None)
    assert (parse_address('[::1%eth0]')) == ('::1%eth0', None)
    assert (parse_address('[::1%eth0]:22')) == ('::1%eth0', 22)
    assert (parse_address('::1', allow_ranges=True)) == ('::1', None)
    with raises(AnsibleParserError) as excinfo:
        parse_address('::1')
    assert 'Detected range in host' in str(excinfo.value)


# Generated at 2022-06-23 05:20:38.486832
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:50.486414
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:00.400863
# Unit test for function parse_address
def test_parse_address():
    """ This function unit tests the `parse_address` function. """

    address = "example.com"
    (host, port) = parse_address(address)
    assert host == address
    assert port == None

    address = "http://example.com"
    (host, port) = parse_address(address)
    assert host == address
    assert port == None

    address = "http://[::1]"
    (host, port) = parse_address(address)
    assert host == address
    assert port == None

    address = "http://example.com:8080"
    (host, port) = parse_address(address)
    assert host == 'example.com'
    assert port == 8080

    address = "[::1]:8080"
    (host, port) = parse_address(address)

# Generated at 2022-06-23 05:21:07.191758
# Unit test for function parse_address
def test_parse_address():
    """This is a basic unit test for the parse_address method."""
    import pytest
    from ansible.module_utils.common._parse_address import parse_address

    # Test IPv4 address without a port number
    valid_host_ipv4 = "192.168.1.1"
    assert parse_address(valid_host_ipv4) == ("192.168.1.1", None)

    # Test IPv4 address with a port number
    valid_host_port_ipv4 = "192.168.1.1:22"
    assert parse_address(valid_host_port_ipv4) == ("192.168.1.1", 22)

    # Test IPv6 address without a port number

# Generated at 2022-06-23 05:21:18.247183
# Unit test for function parse_address