

# Generated at 2022-06-23 05:11:19.957720
# Unit test for function parse_address

# Generated at 2022-06-23 05:11:30.637375
# Unit test for function parse_address
def test_parse_address():

    test_cases = list()

    # Valid IPv4 tests
    test_cases.append(('192.0.2.1', ('192.0.2.1', None)))
    test_cases.append(('192.0.2.1:22', ('192.0.2.1', 22)))
    test_cases.append(('192.0.2.1[2:4]', ('192.0.2.1[2:4]', None)))
    test_cases.append(('192.0.2.1[2:4]:22', ('192.0.2.1[2:4]', 22)))
    test_cases.append(('[192.0.2.1]:22', ('192.0.2.1', 22)))

# Generated at 2022-06-23 05:11:38.724421
# Unit test for function parse_address
def test_parse_address():
    # Test RFC 4291 section 2.2 examples
    assert parse_address('[2001:db8:85a3::8a2e:370:7334]') == ('2001:db8:85a3::8a2e:370:7334', None)
    assert parse_address('[2001:db8:85a3::8a2e:370:7334]:80') == ('2001:db8:85a3::8a2e:370:7334', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[2001:db8:85a3::8a2e:0:7334]:80')

# Generated at 2022-06-23 05:11:49.248942
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None), 'Invalid result: parse_address() returned %s' % parse_address('[1.2.3.4]')
    assert parse_address('1.2.3.4') == ('1.2.3.4', None), 'Invalid result: parse_address() returned %s' % parse_address('1.2.3.4')
    assert parse_address('[1.2.3.4]:5678') == ('1.2.3.4', 5678), 'Invalid result: parse_address() returned %s' % parse_address('[1.2.3.4]:5678')

# Generated at 2022-06-23 05:12:01.447612
# Unit test for function parse_address
def test_parse_address():
    def test(address, allow_ranges, expected):
        result = parse_address(address, allow_ranges=allow_ranges)
        head = "%s => " % address
        if result != expected:
            print("%sFAIL %s != %s" % (head, result, expected))
        else:
            print("%sPASS" % head)

    test('[::ffff:192.0.2.3]', False, (None, None))
    test('[::ffff:192.0.2.3]:1234', False, ('::ffff:192.0.2.3', 1234))
    test('[::ffff:192.0.2.3]:1234', True, ('::ffff:192.0.2.3', 1234))

# Generated at 2022-06-23 05:12:10.723605
# Unit test for function parse_address
def test_parse_address():
    # Simple hostnames
    host, port = parse_address('myhost.example.com', allow_ranges=True)
    assert host == 'myhost.example.com'
    assert port == None

    host, port = parse_address('myhost.example.com:3306', allow_ranges=True)
    assert host == 'myhost.example.com'
    assert port == 3306

    # Simple hostnames with numeric ranges
    host, port = parse_address('myhost[0:3].example.com', allow_ranges=True)
    assert host == 'myhost[0:3].example.com'
    assert port == None

    host, port = parse_address('myhost[0:3].example.com:3306', allow_ranges=True)

# Generated at 2022-06-23 05:12:20.250942
# Unit test for function parse_address
def test_parse_address():
    failed = False


# Generated at 2022-06-23 05:12:24.604784
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:33.246746
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_ipv4_with_no_port_should_have_host_and_none_port(self):
            expected_host = '192.0.2.17'
            (host, port) = parse_address(expected_host)
            self.assertEqual(expected_host, host)
            self.assertIsNone(port)

        def test_ipv4_with_port_should_have_both_host_and_port(self):
            expected_host = '192.0.2.17'
            expected_port = 65000
            (host, port) = parse_address(expected_host + ":" + str(expected_port))
            self.assertEqual(expected_host, host)
            self.assertE

# Generated at 2022-06-23 05:12:38.609374
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:48.300458
# Unit test for function parse_address

# Generated at 2022-06-23 05:12:57.415026
# Unit test for function parse_address
def test_parse_address():
    from nose.tools import assert_equal


# Generated at 2022-06-23 05:13:08.144198
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost', allow_ranges=True) == ('localhost', None)
    assert parse_address('foo[0:3]', allow_ranges=True) == ('foo[0:3]', None)
    assert parse_address('[::1]', allow_ranges=True) == ('[::1]', None)
    assert parse_address('[::1]:22', allow_ranges=True) == ('[::1]', 22)
    assert parse_address('[::1:2:3:4:5:6:7]:22', allow_ranges=True) == ('[::1:2:3:4:5:6:7]', 22)

# Generated at 2022-06-23 05:13:16.356846
# Unit test for function parse_address

# Generated at 2022-06-23 05:13:24.141392
# Unit test for function parse_address
def test_parse_address():

    '''
    This test is run for Ansible versions equal to and later than 2.0.1.
    For Ansible 2.0.0 the backport of https://github.com/ansible/ansible/pull/17395
    is not applicable because it's not possible to backport a function that
    modifies the regex to take ranges into consideration.
    This test is mainly to ensure that parse_address works with IPv6 addresses,
    but it also tests IPv4 and hostnames with ranges.
    '''


# Generated at 2022-06-23 05:13:34.117288
# Unit test for function parse_address
def test_parse_address():
    from ansible.module_utils.network.common.utils import conditional

    # Valid IP addresses and legal variants

# Generated at 2022-06-23 05:13:43.425354
# Unit test for function parse_address
def test_parse_address():
    """
    Test function parse_address
    """

    def test(s, h, p, allow_ranges=False):
        (host, port) = parse_address(s, allow_ranges)
        if (host != h) or (port != p):
            raise AssertionError(
                "parse_address('%s') returned ('%s', %s), expected ('%s', %s)"
                % (s, host, port, h, p)
            )


# Generated at 2022-06-23 05:13:52.797079
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_ipv4_address_with_port(self):
            (host, port) = parse_address('192.0.2.1:22')
            self.assertEqual(host, '192.0.2.1')
            self.assertEqual(port, 22)

        def test_ipv4_address_with_range(self):
            (host, port) = parse_address('192.0.2[1:3]:22')
            self.assertEqual(host, '192.0.2[1:3]')
            self.assertEqual(port, 22)


# Generated at 2022-06-23 05:14:03.219249
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:1') == (u'::1', 1)
    assert parse_address('::1') == (u'::1', None)
    assert parse_address('0::1') == (u'0::1', None)
    assert parse_address('0:0:0:0:0:0:0:1') == (u'0:0:0:0:0:0:0:1', None)
    assert parse_address('::ffff:192.0.2.3') == (u'::ffff:192.0.2.3', None)

# Generated at 2022-06-23 05:14:14.183345
# Unit test for function parse_address
def test_parse_address():
    """test parse_address"""
    assert ('[2001:0db8:85a3:0000:0000:8a2e:0370:7334]', 22) == parse_address('[2001:0db8:85a3:0000:0000:8a2e:0370:7334]:22')
    assert ('[127.0.0.1]', 22) == parse_address('[127.0.0.1]:22')
    assert ('127.0.0.1', 22) == parse_address('127.0.0.1:22')
    assert ('127.0.0.1', 22) == parse_address('127.0.0.1:22', allow_ranges=True)
    assert ('foo.example.com', 22) == parse_address('foo.example.com:22')

# Generated at 2022-06-23 05:14:23.438151
# Unit test for function parse_address
def test_parse_address():

    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo.bar") == ("foo.bar", None)
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("example.com:80") == ("example.com", 80)
    assert parse_address("foo:80") == ("foo", 80)
    assert parse_address("foo.bar:80") == ("foo.bar", 80)
    assert parse_address("foo bar") == ("foo bar", None)
    assert parse_address("foo[1:10]") == ("foo[1:10]", None)
    assert parse_address("foo[a:z]") == ("foo[a:z]", None)

# Generated at 2022-06-23 05:14:33.544993
# Unit test for function parse_address
def test_parse_address():
    test_list = (
        ('py.test[1:3]', ('py.test[1:3]', None)),
        ('py.test[1:3]:2222', ('py.test[1:3]', 2222)),
        ('foo.example.com:2500', ('foo.example.com', 2500)),
        ('[2001:cdba::3257:9652]:25', ('2001:cdba::3257:9652', 25)),
        ('192.0.2.1:25', ('192.0.2.1', 25)),
        ('192.0.2.1[2:4]:25', ('192.0.2.1[2:4]', 25)),
    )
    for address, expected in test_list:
        check = parse_address(address)

# Generated at 2022-06-23 05:14:43.623841
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1', False) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22', False) == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', True) == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1[2:3]', False) == ('127.0.0.1[2:3]', None)
    assert parse_address('127.0.0.1[2:3]', True) == ('127.0.0.1[2:3]', None)

# Generated at 2022-06-23 05:14:54.149750
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == (u'example.com', None)
    assert parse_address('example.com:9876') == (u'example.com', 9876)
    assert parse_address('[example.com]') == (u'example.com', None)
    assert parse_address('[example.com]:9876') == (u'example.com', 9876)
    assert parse_address('[ipv6::]') == (u'ipv6::', None)
    assert parse_address('[ipv6::]:9876') == (u'ipv6::', 9876)
    assert parse_address('192.0.2.3') == (u'192.0.2.3', None)

# Generated at 2022-06-23 05:15:05.398068
# Unit test for function parse_address
def test_parse_address():
    p = parse_address


# Generated at 2022-06-23 05:15:16.888055
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:22") == ("localhost", 22)
    assert parse_address("localhost:22", allow_ranges=True) == ("localhost", 22)
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)
    assert parse_address("[localhost]:22") == ("localhost", 22)
    assert parse_address("[fe80::1]:22") == ("fe80::1", 22)
    assert parse_address("192.0.2.9") == ("192.0.2.9", None)
    assert parse_address("192.0.2.9:22") == ("192.0.2.9", 22)

# Generated at 2022-06-23 05:15:26.091317
# Unit test for function parse_address
def test_parse_address():
    ''' validate parse_address() produces the expected results '''

    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo:bar:22]') == ('foo:bar:22', None)
    assert parse_address('[foo:bar:22]:33') == ('foo:bar:22', 33)
    assert parse_address('[foo:bar:22]baz') == ('foo:bar:22baz', None)
    assert parse_address('[foo:bar:22baz]:33') == ('foo:bar:22baz', 33)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)

# Generated at 2022-06-23 05:15:38.073985
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[2001:db8::1]:5678') == ('[2001:db8::1]', 5678)

    # The only way to specify a port for an IPv6 address is to use square brackets.
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]') == ('[2001:db8::1]', None)
    assert parse_address('[2001:db8::1]:5678') == ('[2001:db8::1]', 5678)

    # IPv4 addresses can be specified with or without square brackets.
    assert parse_address('192.168.1.1:5678') == ('192.168.1.1', 5678)

# Generated at 2022-06-23 05:15:45.410010
# Unit test for function parse_address

# Generated at 2022-06-23 05:15:57.128895
# Unit test for function parse_address
def test_parse_address():
    # Valid addresses with port number
    assert parse_address('localhost:20') == ('localhost', 20)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[::1]:21') == ('::1', 21)
    assert parse_address('[::ffff:2a02:a448]:22') == ('::ffff:2a02:a448', 22)

    # Valid addresses without port number
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('[::1]') == ('::1', None)

# Generated at 2022-06-23 05:16:06.792775
# Unit test for function parse_address
def test_parse_address():
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_invalid(self):
            for a in ['localhost:65536', 'localhost:', ':1234', 'localhost:1234[1:2]']:
                self.assertRaises(AnsibleError, parse_address, a)
            self.assertEqual((None, 1234), parse_address(':1234', allow_ranges=True))
            self.assertRaises(AnsibleParserError, parse_address, 'localhost:1234[1:2]', allow_ranges=True)

        def test_valid_hostport(self):
            self.assertEqual((None, 1234), parse_address('localhost:1234', allow_ranges=False))

# Generated at 2022-06-23 05:16:13.363553
# Unit test for function parse_address
def test_parse_address():
    import sys


# Generated at 2022-06-23 05:16:21.511326
# Unit test for function parse_address
def test_parse_address():
    # Valid inputs
    # IPv4
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:22') == ('192.168.1.1', 22)
    assert parse_address('192.168.1.1[2:3]') == ('192.168.1.1[2:3]', None)
    assert parse_address('192.168.1.1[2:3]:22') == ('192.168.1.1[2:3]', 22)
    assert parse_address('192.168.1.1[2:3:4]') == ('192.168.1.1[2:3:4]', None)

# Generated at 2022-06-23 05:16:31.554057
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[::1]:22") == ("::1", 22)
    assert parse_address("127.0.0.1:22") == ("127.0.0.1", 22)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:") == ("127.0.0.1", None)
    assert parse_address("[127.0.0.1]:22") == ("127.0.0.1", 22)
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo[1:3]") == ("foo[1:3]", None)

# Generated at 2022-06-23 05:16:41.473835
# Unit test for function parse_address
def test_parse_address():
    # Test None return value
    try:
        parse_address(None)
        assert False
    except AnsibleError as e:
        assert str(e).find("Not a valid network hostname") >= 0

    # Test IPv4 address
    host, port = parse_address(address='192.168.0.1')
    assert host == '192.168.0.1' and port is None
    host, port = parse_address(address='192.168.0.1:')
    assert host == '192.168.0.1' and port is None
    host, port = parse_address(address='192.168.0.1:50')
    assert host == '192.168.0.1' and port == 50

    # Test IPv4 with ranges

# Generated at 2022-06-23 05:16:53.289412
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)

# Generated at 2022-06-23 05:17:05.353198
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("127.0.0.1")[0] == "127.0.0.1"
    assert parse_address("127.0.0.1")[1] is None
    assert parse_address("::1")[0] == "::1"
    assert parse_address("::1")[1] is None
    assert parse_address("foo")[0] == "foo"
    assert parse_address("foo")[1] is None
    assert parse_address("[2001:db8::1]")[0] == "2001:db8::1"
    assert parse_address("[2001:db8::1]")[1] is None
    assert parse_address("[2001:db8::1]:123")[0] == "2001:db8::1"

# Generated at 2022-06-23 05:17:16.071056
# Unit test for function parse_address
def test_parse_address():
   expected = ('127.0.0.1', 80)
   assert parse_address('127.0.0.1', True) == expected
   assert parse_address('127.0.0.1:80', True) == expected
   expected = ('127.0.0.1', None)
   assert parse_address('127.0.0.1', False) == expected
   assert parse_address('127.0.0.1:80', False) == expected
   expected = ('[::1]', 80)
   assert parse_address('[::1]', True) == expected
   assert parse_address('[::1]:80', True) == expected
   expected = ('::1', None)
   assert parse_address('[::1]', False) == expected
   assert parse_address('[::1]:80', False) == expected
  

# Generated at 2022-06-23 05:17:28.631410
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:22") == ("localhost", 22)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:2222") == ("127.0.0.1", 2222)
    assert parse_address("[127.0.0.1]") == ("127.0.0.1", None)
    assert parse_address("[127.0.0.1]:2222") == ("127.0.0.1", 2222)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:2222") == ("::1", 2222)

# Generated at 2022-06-23 05:17:29.253613
# Unit test for function parse_address
def test_parse_address():
    pass

# Generated at 2022-06-23 05:17:41.661770
# Unit test for function parse_address
def test_parse_address():
    def test(address, expected_host=None, expected_port=None):
        (host, port) = parse_address(address)
        assert(host == expected_host)
        assert(port == expected_port)

    # Basic cases
    test(address='foo', expected_host='foo')
    test(address='foo:42', expected_host='foo', expected_port=42)
    test(address='[::1]', expected_host='::1')
    test(address='[::1]:42', expected_host='::1', expected_port=42)
    test(address='192.0.2.3', expected_host='192.0.2.3')
    test(address='192.0.2.3:42', expected_host='192.0.2.3', expected_port=42)
    test

# Generated at 2022-06-23 05:17:53.208842
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:22") == ("localhost", 22)
    assert parse_address("localhost:22")[0] == "localhost"
    assert parse_address("localhost:22")[1] == 22
    assert parse_address("[2001:ffff:ffff::]:22") == ("[2001:ffff:ffff::]", 22)
    assert parse_address("[2001:ffff:ffff::]") == ("[2001:ffff:ffff::]", None)
    assert parse_address("[2001:ffff:ffff::]")[0] == "[2001:ffff:ffff::]"
    print("FUNCTION parse_address PASSED")


# Generated at 2022-06-23 05:18:04.841049
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:16.403026
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:80') == ('192.0.2.1', 80)
   

# Generated at 2022-06-23 05:18:26.669342
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::ffff:192.0.2.3]') == (u'[::ffff:192.0.2.3]', None)
    assert parse_address('[::ffff:192.0.2.3]:80') == (u'[::ffff:192.0.2.3]', 80)
    assert parse_address('example.com:22') == (u'example.com', 22)
    assert parse_address('192.0.2.3:22') == (u'192.0.2.3', 22)
    assert parse_address(u'2001:db8:a0b:12f0::1') == (u'2001:db8:a0b:12f0::1', None)

# Generated at 2022-06-23 05:18:34.616660
# Unit test for function parse_address

# Generated at 2022-06-23 05:18:35.226281
# Unit test for function parse_address
def test_parse_address():
    pass

# Generated at 2022-06-23 05:18:44.705955
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:1234') == ('foo[1:3].example.com', 1234)
    assert parse_address('foo[1-3].example.com:1234') == ('foo[1-3].example.com', 1234)
    assert parse_address('[::1]') == ('[::1]', None)
    assert parse_address('[::1]:1234') == ('[::1]', 1234)

# Generated at 2022-06-23 05:18:54.369910
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.168.1.1:80') == ('192.168.1.1', 80)
    assert parse_address('myhost.example.com') == ('myhost.example.com', None)
    assert parse_address('[::1]:80') == ('::1', 80)
    assert parse_address('localhost') == ('localhost', None)

    assert parse_address('[192.168.1.1-3]:80') == ('192.168.1.1-3', 80)
    assert parse_address('[192.168.1.0:2:2]:80', allow_ranges=True) == ('192.168.1.0:2:2', 80)

# Generated at 2022-06-23 05:19:05.588955
# Unit test for function parse_address
def test_parse_address():
    """
    This unit test is a copy of the test_address_parsing function written in
    the ansible-2.2.0.0/test/units/module_utils/network/common/utils.py file
    """
    # test_parse_address is a list of tuples, each of which is a test
    # case for the parse_address function in this module.
    #
    # The test format is:
    #
    # ( test_case_name,
    #   expected_result,
    #   args )
    #
    # Thus each test case consists of a test case name, the expected result,
    # which is a two-tuple '(host, port)', and the arguments to parse_address,
    # which is a two-tuple '(address, allow_ranges)'.
    #
    # The

# Generated at 2022-06-23 05:19:15.119337
# Unit test for function parse_address

# Generated at 2022-06-23 05:19:27.943316
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost:p22', allow_ranges=True) == ('localhost', None)
    assert parse_address('localhost:p22') == ('localhost', None)
    assert parse_address('192.168.0.1') == ('192.168.0.1', None)
    assert parse_address('192.168.0.1:22') == ('192.168.0.1', 22)
    assert parse_address('192.168.0.1:p22', allow_ranges=True) == ('192.168.0.1', None)
    assert parse_address('192.168.0.1:p22') == ('192.168.0.1', None)
   

# Generated at 2022-06-23 05:19:37.140317
# Unit test for function parse_address
def test_parse_address():
    ''' parser.host_pattern.test_parse_address() '''
    host_ipv4, port_ipv4 = parse_address('192.0.2.1:23')
    assert host_ipv4 == '192.0.2.1'
    assert port_ipv4 == 23
    host_bracketed_ipv4, port_bracketed_ipv4 = parse_address('[192.0.2.1]:23')
    assert host_bracketed_ipv4 == '192.0.2.1'
    assert port_bracketed_ipv4 == 23
    host_ipv6, port_ipv6 = parse_address('[2001:db8:85a3:8d3:1319:8a2e:370:7348]:23')
    assert host_ip

# Generated at 2022-06-23 05:19:47.976535
# Unit test for function parse_address
def test_parse_address():
    assert (None, None) == parse_address("")
    assert (None, None) == parse_address("]")
    assert (None, None) == parse_address("[")
    assert (None, None) == parse_address("[1]")
    assert (None, None) == parse_address("[1:1]")
    assert (None, None) == parse_address("[1:-1]")
    assert (None, None) == parse_address("[1:1:1:1]")
    assert ('a[b]', None) == parse_address("a[b]")
    assert ('a[b]', None) == parse_address("a[b]:")
    assert ('a[b', None) == parse_address("a[b")
    assert ('a', None) == parse_address("a")
   

# Generated at 2022-06-23 05:19:57.842415
# Unit test for function parse_address
def test_parse_address():
    '''
    Test cases for the parse_address function
    '''


# Generated at 2022-06-23 05:20:08.088399
# Unit test for function parse_address
def test_parse_address():
    x = parse_address("foo.example.com")
    assert(x == ('foo.example.com', None))

    x = parse_address("[foo.example.com]")
    assert(x == ('foo.example.com', None))

    x = parse_address("foo.example.com:1234")
    assert(x == ('foo.example.com', 1234))

    x = parse_address("[foo.example.com]:1234")
    assert(x == ('foo.example.com', 1234))

    x = parse_address("1.2.3.4")
    assert(x == ('1.2.3.4', None))

    x = parse_address("1.2.3.4:1234")
    assert(x == ('1.2.3.4', 1234))

    x

# Generated at 2022-06-23 05:20:19.059824
# Unit test for function parse_address
def test_parse_address():
    # test basic
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1', allow_ranges=True) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22', allow_ranges=True) == ('127.0.0.1', 22)

    # test IPv6
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)

# Generated at 2022-06-23 05:20:30.150240
# Unit test for function parse_address
def test_parse_address():
    """ Unit test for function parse_address """
    import platform

    # all tests expect to be run in utf-8 and not a unicode locale.
    # if the test detects a unicode locale then it fails.
    if platform.system() != 'Windows':
        if not sys.stdin.encoding.lower().startswith('utf-8'):
            print("test_parse_address requires utf-8 locale, not %s" % sys.stdin.encoding)
            return
    else:
        # check for utf-8 chars in code_page
        code_page = locale.getpreferredencoding()
        try:
            code_page.decode('utf-8')
        except UnicodeDecodeError:
            print("test_parse_address requires utf-8 locale, not %s" % code_page)


# Generated at 2022-06-23 05:20:41.590688
# Unit test for function parse_address

# Generated at 2022-06-23 05:20:51.979835
# Unit test for function parse_address

# Generated at 2022-06-23 05:21:01.393585
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestCases(unittest.TestCase):
        def test_parse_address(self):
            with self.assertRaises(AnsibleError):
                parse_address("not a valid hostname")

            # IPv4 address with no port
            self.assertEqual(parse_address("192.0.2.5"), ("192.0.2.5", None))

            # IPv6 address with no port
            self.assertEqual(parse_address("2001:db8::1"), ("2001:db8::1", None))

            # IPv4 address with port
            self.assertEqual(parse_address("192.0.2.5:22"), ("192.0.2.5", 22))



# Generated at 2022-06-23 05:21:11.009569
# Unit test for function parse_address
def test_parse_address():
    # Valid IPv4 and IPv6 addresses without port
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('10.20.30.40') == ('10.20.30.40', None)
    assert parse_address('1:2:3:4:5:6:7:8') == ('1:2:3:4:5:6:7:8', None)
    assert parse_address('1:2:3:4:5:6:7::') == ('1:2:3:4:5:6:7::', None)
    assert parse_address('1:2:3:4:5::') == ('1:2:3:4:5::', None)

# Generated at 2022-06-23 05:21:21.407614
# Unit test for function parse_address