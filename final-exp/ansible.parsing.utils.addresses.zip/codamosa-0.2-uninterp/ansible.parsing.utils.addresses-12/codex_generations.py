

# Generated at 2022-06-17 06:12:37.872853
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]', allow_ranges=True) == (u'::1', None)
    assert parse_address('[::1:2:3:4:5:6:7]:22') == (u'::1:2:3:4:5:6:7', 22)
    assert parse_address('[::1:2:3:4:5:6:7]') == (u'::1:2:3:4:5:6:7', None)

# Generated at 2022-06-17 06:12:46.842083
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com:22', allow_ranges=True) == ('foo[1:3].example.com', 22)

# Generated at 2022-06-17 06:13:01.066142
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo]') == ('foo', None)
    assert parse_address('[foo]bar') == ('foobar', None)
    assert parse_address('[foo]bar:22') == ('foobar', 22)
    assert parse_address('[foo]bar[1:3]') == ('foobar[1:3]', None)
    assert parse_address('[foo]bar[1:3]:22') == ('foobar[1:3]', 22)

# Generated at 2022-06-17 06:13:13.471423
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 addresses
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:22', allow_ranges=True) == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:22', allow_ranges=False) == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)

# Generated at 2022-06-17 06:13:25.436209
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 addresses
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:22', allow_ranges=True) == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:22', allow_ranges=False) == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)

# Generated at 2022-06-17 06:13:39.719533
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)

# Generated at 2022-06-17 06:13:49.048953
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address

# Generated at 2022-06-17 06:14:02.891505
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:14:11.949375
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo.example.com[1:3]') == ('foo.example.com[1:3]', None)
    assert parse_address('foo.example.com[1:3]:22') == ('foo.example.com[1:3]', 22)
    assert parse_address('foo.example.com[1:3]:22', allow_ranges=True) == ('foo.example.com[1:3]', 22)

# Generated at 2022-06-17 06:14:20.902563
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == (u'::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)