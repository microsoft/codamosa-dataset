

# Generated at 2022-06-17 06:12:44.322846
# Unit test for function parse_address
def test_parse_address():
    # Test cases for IPv4 addresses
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:65535') == ('127.0.0.1', 65535)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]:65535') == ('127.0.0.1', 65535)

# Generated at 2022-06-17 06:12:54.980057
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)

# Generated at 2022-06-17 06:12:59.692571
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == (u'::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:13:07.550447
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:13:22.176872
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)

# Generated at 2022-06-17 06:13:30.882045
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:80') == ('192.0.2.1', 80)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)

# Generated at 2022-06-17 06:13:44.709847
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo]:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22')

# Generated at 2022-06-17 06:13:55.035682
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address('foo:1') == ('foo', 1)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo:1234') == ('foo', 1234)
    assert parse_address('foo:12345') == ('foo', 12345)
    assert parse_address('foo:123456') == ('foo', 123456)
    assert parse_address('foo:1234567') == ('foo', 1234567)
    assert parse_address('foo:12345678') == ('foo', 12345678)

# Generated at 2022-06-17 06:14:06.712592
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo.example.com[1:3]') == ('foo.example.com[1:3]', None)
    assert parse_address('foo.example.com[1:3]:22') == ('foo.example.com[1:3]', 22)
    assert parse_address('foo.example.com[1:3]:22', allow_ranges=True) == ('foo.example.com[1:3]', 22)

# Generated at 2022-06-17 06:14:13.724538
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_