

# Generated at 2022-06-17 06:12:43.160537
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com:22')

# Generated at 2022-06-17 06:12:50.902842
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:22]') == (u'::1:22', None)
    assert parse_address('[::1:22]:22') == (u'::1:22', 22)
    assert parse_address('[::1:22]:22', allow_ranges=True) == (u'::1:22', 22)

# Generated at 2022-06-17 06:13:02.766307
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)


# Generated at 2022-06-17 06:13:10.611167
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == ('::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == ('::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == ('::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:13:23.519248
# Unit test for function parse_address
def test_parse_address():
    # Test cases for IPv4 addresses
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=True) == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=False) == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse

# Generated at 2022-06-17 06:13:38.692219
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)

# Generated at 2022-06-17 06:13:48.775783
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)
    assert parse_address('foo[1:3]-bar[x-z]:22') == ('foo[1:3]-bar[x-z]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)

# Generated at 2022-06-17 06:14:02.598644
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)
    assert parse_address('foo[1:3]-bar[x-z]:22') == ('foo[1:3]-bar[x-z]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)

# Generated at 2022-06-17 06:14:10.552824
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)

# Generated at 2022-06-17 06:14:20.409171
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo.example.com[1:3]') == ('foo.example.com[1:3]', None)
    assert parse_address('foo.example.com[1:3]:22') == ('foo.example.com[1:3]', 22)
    assert parse_address('foo.example.com[1:3]:22', allow_ranges=True) == ('foo.example.com[1:3]', 22)