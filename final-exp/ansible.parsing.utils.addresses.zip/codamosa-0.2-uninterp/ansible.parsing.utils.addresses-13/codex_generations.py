

# Generated at 2022-06-17 06:12:44.209841
# Unit test for function parse_address

# Generated at 2022-06-17 06:12:52.425381
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22', allow_ranges=False) == ('foo[1:3]', 22)


# Generated at 2022-06-17 06:13:03.927817
# Unit test for function parse_address
def test_parse_address():
    # Test cases for IPv4 addresses
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1:22]') == ('127.0.0.1:22', None)
    assert parse_address('[127.0.0.1:22]:22') == ('127.0.0.1:22', 22)
    assert parse_address('[127.0.0.1:22:2]') == ('127.0.0.1:22:2', None)


# Generated at 2022-06-17 06:13:10.832198
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:13:23.605572
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)

# Generated at 2022-06-17 06:13:38.682885
# Unit test for function parse_address
def test_parse_address():
    # Test cases for IPv4 addresses
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=True) == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=False) == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)

# Generated at 2022-06-17 06:13:48.774742
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:2:3]:22', allow_ranges=True) == (u'::1:2:3', 22)
    assert parse_address('[::1:2:3]:22', allow_ranges=False) == (u'::1:2:3', 22)

# Generated at 2022-06-17 06:13:58.688920
# Unit test for function parse_address

# Generated at 2022-06-17 06:14:09.470820
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == (u'::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:14:21.271785
# Unit test for function parse_address