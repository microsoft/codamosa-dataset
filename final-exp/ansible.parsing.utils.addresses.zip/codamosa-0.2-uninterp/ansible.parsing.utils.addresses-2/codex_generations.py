

# Generated at 2022-06-17 06:12:43.576208
# Unit test for function parse_address

# Generated at 2022-06-17 06:12:50.928188
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost:2222') == ('localhost', 2222)
    assert parse_address('localhost:22222') == ('localhost', 22222)
    assert parse_address('localhost:222222') == ('localhost', 222222)
    assert parse_address('localhost:2222222') == ('localhost', 2222222)
    assert parse_address('localhost:22222222') == ('localhost', 22222222)
    assert parse_address('localhost:222222222') == ('localhost', 222222222)
    assert parse_address('localhost:2222222222') == ('localhost', 2222222222)

# Generated at 2022-06-17 06:12:57.340741
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == ('::1:2:3:4:5:6:7:8', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == ('::1:2:3:4:5:6:7:8', None)

# Generated at 2022-06-17 06:13:06.860925
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost:2222') == ('localhost', 2222)
    assert parse_address('localhost:22222') == ('localhost', 22222)
    assert parse_address('localhost:222222') == ('localhost', 222222)
    assert parse_address('localhost:2222222') == ('localhost', 2222222)
    assert parse_address('localhost:22222222') == ('localhost', 22222222)
    assert parse_address('localhost:222222222') == ('localhost', 222222222)
    assert parse_address('localhost:2222222222') == ('localhost', 2222222222)

# Generated at 2022-06-17 06:13:21.614960
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address

# Generated at 2022-06-17 06:13:30.488670
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address

# Generated at 2022-06-17 06:13:36.139350
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)

# Generated at 2022-06-17 06:13:47.023317
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:') == ('::1', None)
    assert parse_address('[::1]:-1') == ('::1', None)
    assert parse_address('[::1]:65536') == ('::1', None)
    assert parse_address('[::1]:0') == ('::1', 0)
    assert parse_address('[::1]:65535') == ('::1', 65535)
    assert parse_address('[::1]:65535', allow_ranges=True) == ('::1', 65535)

# Generated at 2022-06-17 06:13:59.898015
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)

# Generated at 2022-06-17 06:14:10.067825
# Unit test for function parse_address
def test_parse_address():
    # Test cases for IPv4 addresses
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=True) == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=False) == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)