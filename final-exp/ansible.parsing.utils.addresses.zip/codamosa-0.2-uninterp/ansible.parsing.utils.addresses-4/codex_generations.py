

# Generated at 2022-06-17 06:12:33.425930
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:') == (u'::1', None)
    assert parse_address('[::1]:-1') == (u'::1', None)
    assert parse_address('[::1]:65536') == (u'::1', None)
    assert parse_address('[::1]:0') == (u'::1', 0)
    assert parse_address('[::1]:65535') == (u'::1', 65535)
    assert parse_address('[::1]:65535', allow_ranges=True) == (u'::1', 65535)

# Generated at 2022-06-17 06:12:45.689258
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1:2]') == (u'::1:2', None)
    assert parse_address('[::1:2]:22') == (u'::1:2', 22)
    assert parse_address('[::1:2]:22', allow_ranges=True) == (u'::1:2', 22)
    assert parse_address('[::1:2:3]') == (u'::1:2:3', None)

# Generated at 2022-06-17 06:13:00.759401
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3:22]') == ('192.0.2.3:22', None)
    assert parse_address('[192.0.2.3:22]:22') == ('192.0.2.3:22', 22)

# Generated at 2022-06-17 06:13:08.222115
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:22]') == (u'::1:22', None)
    assert parse_address('[::1:22]:22') == (u'::1:22', 22)
    assert parse_address('[::1:22]:22', allow_ranges=True) == (u'::1:22', 22)

# Generated at 2022-06-17 06:13:22.693692
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('[::1:2:3]:22') == ('::1:2:3', 22)
    assert parse_address('[::1:2:3]') == ('::1:2:3', None)
    assert parse_address('[::1:2:3]', allow_ranges=True) == ('::1:2:3', None)

# Generated at 2022-06-17 06:13:31.500317
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:13:41.864319
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)

# Generated at 2022-06-17 06:13:49.834218
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)

# Generated at 2022-06-17 06:14:03.504267
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com[1:3]:22') == ('foo[1:3].example.com[1:3]', 22)

# Generated at 2022-06-17 06:14:12.347492
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3][4:6]') == ('foo[1:3][4:6]', None)
    assert parse_address('foo[1:3][4:6]:22')