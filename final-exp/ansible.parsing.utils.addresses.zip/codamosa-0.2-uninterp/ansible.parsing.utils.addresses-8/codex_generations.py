

# Generated at 2022-06-17 06:12:43.871415
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=False) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=False)

# Generated at 2022-06-17 06:12:51.045986
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address

# Generated at 2022-06-17 06:13:02.878824
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo]') == ('foo', None)
    assert parse_address('[foo]bar') == ('foobar', None)
    assert parse_address('[foo]bar:22') == ('foobar', 22)
    assert parse_address('[foo]bar:22') == ('foobar', 22)
    assert parse_address('[foo]bar[1:3]:22') == ('foobar[1:3]', 22)
    assert parse_address('[foo]bar[1:3]') == ('foobar[1:3]', None)

# Generated at 2022-06-17 06:13:10.634262
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address

# Generated at 2022-06-17 06:13:23.549357
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=False) == ('foo[1:3]', None)

# Generated at 2022-06-17 06:13:38.682110
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)

# Generated at 2022-06-17 06:13:48.783746
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:13:56.124159
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]', allow_ranges=True) == (u'::1', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)
    assert parse_address('[::ffff:192.0.2.3]:22') == (u'::ffff:192.0.2.3', 22)
    assert parse_address('[::ffff:192.0.2.3]') == (u'::ffff:192.0.2.3', None)
    assert parse

# Generated at 2022-06-17 06:14:08.140574
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == ('::1:2:3:4:5:6:7:8', 22)
    assert parse_address('[::ffff:192.0.2.3]:22') == ('::ffff:192.0.2.3', 22)
    assert parse_address('[::ffff:192.0.2.3]') == ('::ffff:192.0.2.3', None)

# Generated at 2022-06-17 06:14:20.397370
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)