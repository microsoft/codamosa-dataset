

# Generated at 2022-06-17 06:12:33.527824
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == ('::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == ('::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == ('::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:12:45.736605
# Unit test for function parse_address

# Generated at 2022-06-17 06:13:00.759831
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1:2]') == (u'::1:2', None)
    assert parse_address('[::1:2]:22') == (u'::1:2', 22)
    assert parse_address('[::1:2]:22', allow_ranges=True) == (u'::1:2', 22)
    assert parse_address('[::1:2:3]') == (u'::1:2:3', None)

# Generated at 2022-06-17 06:13:13.134064
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('foo[1:3].example.com[1:3]:22') == ('foo[1:3].example.com[1:3]', 22)

# Generated at 2022-06-17 06:13:24.537616
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)

# Generated at 2022-06-17 06:13:39.136779
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == (u'::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:13:48.929459
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:80') == ('192.0.2.1', 80)
    assert parse_address('[2001:db8::1]') == ('2001:db8::1', None)

# Generated at 2022-06-17 06:14:02.776744
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ("::1", 22)
    assert parse_address('[::1]') == ("::1", None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == ("::1:2:3:4:5:6:7:8", 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == ("::1:2:3:4:5:6:7:8", None)
    assert parse_address('[::ffff:192.0.2.3]:22') == ("::ffff:192.0.2.3", 22)

# Generated at 2022-06-17 06:14:11.883437
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_

# Generated at 2022-06-17 06:14:20.865123
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)