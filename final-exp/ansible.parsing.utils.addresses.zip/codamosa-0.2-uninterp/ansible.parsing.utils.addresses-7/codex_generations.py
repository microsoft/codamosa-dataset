

# Generated at 2022-06-17 06:12:33.070086
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_

# Generated at 2022-06-17 06:12:45.561316
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('[::1:2:3:4:5:6:7]:22') == ('::1:2:3:4:5:6:7', 22)
    assert parse_address('[::1:2:3:4:5:6:7]') == ('::1:2:3:4:5:6:7', None)

# Generated at 2022-06-17 06:12:55.876443
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:') == ('foo', None)
    assert parse_address('foo:1') == ('foo', 1)
    assert parse_address('foo:1:2') == ('foo', 1)
    assert parse_address('foo:1:2:3') == ('foo', 1)
    assert parse_address('foo:1:2:3:4') == ('foo', 1)
    assert parse_address('foo:1:2:3:4:5') == ('foo', 1)
    assert parse_address('foo:1:2:3:4:5:6') == ('foo', 1)
    assert parse_address('foo:1:2:3:4:5:6:7') == ('foo', 1)

# Generated at 2022-06-17 06:13:06.690910
# Unit test for function parse_address
def test_parse_address():
    import pytest

    # Test cases for IPv4 addresses
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3:22]') == ('192.0.2.3:22', None)
    assert parse_address('[192.0.2.3:22]:22') == ('192.0.2.3:22', 22)
    assert parse

# Generated at 2022-06-17 06:13:21.416412
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('[::1:2:3:4:5:6:7]:22') == ('::1:2:3:4:5:6:7', 22)
    assert parse_address('[::1:2:3:4:5:6:7]') == ('::1:2:3:4:5:6:7', None)

# Generated at 2022-06-17 06:13:30.405916
# Unit test for function parse_address
def test_parse_address():
    """
    >>> test_parse_address()
    True
    """
    # Test IPv4 addresses
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=True) == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=False) == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1:22', allow_ranges=True) == ('192.0.2.1', 22)

# Generated at 2022-06-17 06:13:44.466122
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)

# Generated at 2022-06-17 06:13:54.781902
# Unit test for function parse_address

# Generated at 2022-06-17 06:14:06.387507
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=False) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)

# Generated at 2022-06-17 06:14:19.579237
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)