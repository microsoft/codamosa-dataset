

# Generated at 2022-06-17 06:12:43.218977
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)
    assert parse_address('[foo.example.com]:22') == ('foo.example.com', 22)

# Generated at 2022-06-17 06:12:50.929194
# Unit test for function parse_address

# Generated at 2022-06-17 06:12:58.135269
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_

# Generated at 2022-06-17 06:13:06.948740
# Unit test for function parse_address

# Generated at 2022-06-17 06:13:21.684291
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:80') == ('192.0.2.1', 80)
   

# Generated at 2022-06-17 06:13:30.520502
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo.example.com[1:3]') == ('foo.example.com[1:3]', None)
    assert parse_address('foo.example.com[1:3]:22') == ('foo.example.com[1:3]', 22)
    assert parse_address('foo.example.com[1:3]:22', allow_ranges=True) == ('foo.example.com[1:3]', 22)

# Generated at 2022-06-17 06:13:39.422733
# Unit test for function parse_address

# Generated at 2022-06-17 06:13:49.019264
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_

# Generated at 2022-06-17 06:14:02.838241
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 addresses
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=True) == ('127.0.0.1', 22)
    assert parse_address('127.0.0.1:22', allow_ranges=False) == ('127.0.0.1', 22)
    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:22') == ('127.0.0.1', 22)
    assert parse_address

# Generated at 2022-06-17 06:14:08.759598
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)
    assert parse_address('foo[1:3]-bar[x-z]:22') == ('foo[1:3]-bar[x-z]', 22)