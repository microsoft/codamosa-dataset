

# Generated at 2022-06-17 06:12:33.016558
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22', allow_ranges=False) == ('foo[1:3]', 22)


# Generated at 2022-06-17 06:12:45.534534
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3,5]', allow_ranges=True) == ('foo[1:3,5]', None)

# Generated at 2022-06-17 06:12:55.852005
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]:22]') == ('foo[1:3]:22', None)
    assert parse_address('[foo[1:3]:22]:22') == ('foo[1:3]:22', 22)

# Generated at 2022-06-17 06:13:06.816216
# Unit test for function parse_address
def test_parse_address():
    # Test IPv4 addresses
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('192.0.2.3:22', allow_ranges=True) == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]:22', allow_ranges=True) == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:13:21.547557
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == (u'::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:13:30.462740
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)

# Generated at 2022-06-17 06:13:44.496564
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7]') == (u'::1:2:3:4:5:6:7', None)
    assert parse_address('[::1:2:3:4:5:6:7]:22') == (u'::1:2:3:4:5:6:7', 22)

# Generated at 2022-06-17 06:13:59.521523
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('[foo]:22') == ('foo', 22)
    assert parse_address('[foo]:22', allow_ranges=True) == ('foo', 22)
    assert parse_address('[foo[1:3]]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('[foo[1:3]]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_

# Generated at 2022-06-17 06:14:09.801601
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)
    assert parse_

# Generated at 2022-06-17 06:14:16.658333
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)
    assert parse_address("foo.example.com:22", allow_ranges=True) == ("foo.example.com", 22)
    assert parse_address("foo.example.com[1:3]") == ("foo.example.com[1:3]", None)
    assert parse_address("foo.example.com[1:3]:22") == ("foo.example.com[1:3]", 22)
    assert parse_address("foo.example.com[1:3]:22", allow_ranges=True) == ("foo.example.com[1:3]", 22)