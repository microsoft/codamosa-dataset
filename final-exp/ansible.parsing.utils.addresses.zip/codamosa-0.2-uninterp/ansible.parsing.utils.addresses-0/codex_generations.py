

# Generated at 2022-06-17 06:12:43.219938
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('[localhost]:22') == ('localhost', 22)
    assert parse_address('[localhost]') == ('localhost', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == ('::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == ('::1:2:3:4:5:6:7:8', None)

# Generated at 2022-06-17 06:12:53.999274
# Unit test for function parse_address

# Generated at 2022-06-17 06:12:58.949454
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:22') == ('192.0.2.1', 22)
    assert parse_

# Generated at 2022-06-17 06:13:07.173207
# Unit test for function parse_address
def test_parse_address():
    # Test cases for IPv4 addresses.
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:123') == ('192.0.2.3', 123)
    assert parse_address('[192.0.2.3]:123') == ('192.0.2.3', 123)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3:123]') == ('192.0.2.3:123', None)
    assert parse_address('[192.0.2.3:123]:456') == ('192.0.2.3:123', 456)

# Generated at 2022-06-17 06:13:21.739417
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)

# Generated at 2022-06-17 06:13:30.540433
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_

# Generated at 2022-06-17 06:13:44.532396
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1:2:3:4:5:6:7:8]') == (u'::1:2:3:4:5:6:7:8', None)
    assert parse_address('[::1:2:3:4:5:6:7:8]:22') == (u'::1:2:3:4:5:6:7:8', 22)

# Generated at 2022-06-17 06:13:54.854943
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', True) == ('foo.example.com', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)

# Generated at 2022-06-17 06:14:06.521825
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:22') == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]:22', allow_ranges=True) == ('foo[1:3]', 22)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]-bar[x-z]') == ('foo[1:3]-bar[x-z]', None)

# Generated at 2022-06-17 06:14:19.637201
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:22') == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=True) == (u'::1', 22)
    assert parse_address('[::1]:22', allow_ranges=False) == (u'::1', 22)
    assert parse_address('[::1:2]') == (u'::1:2', None)
    assert parse_address('[::1:2]:22') == (u'::1:2', 22)
    assert parse_address('[::1:2]:22', allow_ranges=True) == (u'::1:2', 22)