

# Generated at 2022-06-25 04:11:32.146261
# Unit test for function parse_address
def test_parse_address():
    '''
    Test case for function parse_address
    '''

    print("Testing function parse_address")

    try:
        test_case_0()
        print("Test case 0 passed.")

    except Exception as e:
        print("Exception raised")
        print(e)
        print("Test case 0 failed.")


if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:11:35.128673
# Unit test for function parse_address
def test_parse_address():
    print("Testing function parse_address")

    test_case_0()

# Generated at 2022-06-25 04:11:42.600769
# Unit test for function parse_address
def test_parse_address():
    from collections import namedtuple
    HostPort = namedtuple('HostPort', ['host', 'port'])

    assert parse_address('1.2.3.4') == HostPort('1.2.3.4', None)
    assert parse_address('1.2.3.4') == HostPort('1.2.3.4', None)
    assert parse_address('domain.example.com') == HostPort('domain.example.com', None)
    assert parse_address('1.2.3.4:5') == HostPort('1.2.3.4', 5)
    assert parse_address('1.2.3.4:5') == HostPort('1.2.3.4', 5)
    assert parse_address('domain.example.com:5') == HostPort('domain.example.com', 5)


# Generated at 2022-06-25 04:11:52.263175
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:02.297403
# Unit test for function parse_address
def test_parse_address():
    int_0 = "205"
    var_0 = parse_address(int_0)
    assert len(var_0) == 2, "Invalid return value from parse_address"
    assert isinstance(var_0[0], basestring), "Invalid return value from parse_address"
    assert isinstance(var_0[1], int), "Invalid return value from parse_address"

    int_0 = "205"
    var_0 = parse_address(int_0)
    assert var_0[0] == "205", "Invalid return value from parse_address"
    assert var_0[1] == None, "Invalid return value from parse_address"

    int_0 = "205:22"
    var_0 = parse_address(int_0)

# Generated at 2022-06-25 04:12:11.162872
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('0:a:b:c:d:e:f:0', allow_ranges=False) == ('0:a:b:c:d:e:f:0', None)
    assert parse_address('0:a:b:c:d:e:f:0', allow_ranges=True) == ('0:a:b:c:d:e:f:0', None)
    assert parse_address('[0:a:b:c:d:e:f:0]', allow_ranges=False) == ('0:a:b:c:d:e:f:0', None)

# Generated at 2022-06-25 04:12:14.504999
# Unit test for function parse_address
def test_parse_address():
    int_0 = "1"
    var_0 = parse_address(int_0)

# Generated at 2022-06-25 04:12:15.324170
# Unit test for function parse_address
def test_parse_address():
    assert 1 == 1

# Generated at 2022-06-25 04:12:18.441508
# Unit test for function parse_address
def test_parse_address():
    for test_case in range(0):
        test_case_0()


# Main program

# Generated at 2022-06-25 04:12:25.669871
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:30.035483
# Unit test for function parse_address
def test_parse_address():
    int_2 = ''
    int_1 = 205
    var_0 = parse_address(int_1, True)
    var_1 = parse_address(int_2)



# Generated at 2022-06-25 04:12:39.606943
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:50.907006
# Unit test for function parse_address
def test_parse_address():
    (host, port) = parse_address('[2001:db8:85a3:0:0:8a2e:370:7334]:443')
    assert host == '2001:db8:85a3:0:0:8a2e:370:7334'
    assert port == 443

    (host, port) = parse_address('example.com:443')
    assert host == 'example.com'
    assert port == 443

    (host, port) = parse_address('192.168.1.3:443')
    assert host == '192.168.1.3'
    assert port == 443

    (host, port) = parse_address('[192.168.1.3]:443')
    assert host == '192.168.1.3'
    assert port == 443


# Generated at 2022-06-25 04:12:57.753665
# Unit test for function parse_address
def test_parse_address():
    with pytest.raises(AnsibleError):
        assert parse_address(1) == ('foo.example.com', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:1337') == ('foo.example.com', 1337)
    assert parse_address('foo[1:5].example.com:1337') == ('foo[1:5].example.com', 1337)
    assert parse_address('foo-bar[1:5].example.com:1337') == ('foo-bar[1:5].example.com', 1337)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)

# Generated at 2022-06-25 04:13:02.041789
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost") == ('localhost', None)
    assert parse_address("localhost:22") == ('localhost', 22)
    assert parse_address("example.com:111") == ('example.com', 111)
    assert parse_address("localhost:22:333") == ('localhost:22:333', None)
    assert parse_address("[127.0.0.1]") == ('127.0.0.1', None)
    assert parse_address("[127.0.0.1]:22") == ('127.0.0.1', 22)
    assert parse_address("example.com[1:3].example.com[3:5]") == ('example.com[1:3].example.com[3:5]', None)

# Generated at 2022-06-25 04:13:11.889235
# Unit test for function parse_address
def test_parse_address():
    in_0 = "[127.0.0.1]:9000"
    in_1 = None
    out_1 = ('127.0.0.1', 9000)
    assert parse_address(in_0, in_1) == out_1
    in_0 = "[2001:db8::1]:9000"
    in_1 = None
    out_1 = ('2001:db8::1', 9000)
    assert parse_address(in_0, in_1) == out_1
    in_0 = "127.0.0.1:9000"
    in_1 = None
    out_1 = ('127.0.0.1', 9000)
    assert parse_address(in_0, in_1) == out_1
    in_0 = "2001:db8::1:9000"
   

# Generated at 2022-06-25 04:13:16.423738
# Unit test for function parse_address
def test_parse_address():
    int_0 = 205
    var_0 = parse_address(int_0)
    assert var_0[0] == int_0 and var_0[1] is None
    int_1 = '205'
    var_1 = parse_address(int_1)
    assert var_1[0] == int_1 and var_1[1] is None
    int_2 = '205:22'
    var_2 = parse_address(int_2)
    assert var_2[0] == int_2 and var_2[1] == 22
    int_3 = '[205:22]'
    var_3 = parse_address(int_3)
    assert var_3[0] == int_3 and var_3[1] == 22
    int_4 = '[192.168.0.3]:22'


# Generated at 2022-06-25 04:13:29.377185
# Unit test for function parse_address
def test_parse_address():
    int_0 = 205
    int_1 = 205
    int_2 = 205
    int_3 = 205
    int_4 = 205
    int_5 = 205
    int_6 = 205
    int_7 = 205
    int_8 = 205
    int_9 = 205
    int_10 = 205
    int_11 = 205
    int_12 = 205
    var_0 = parse_address(int_0)
    var_1 = parse_address(int_1, allow_ranges=True)
    var_2 = parse_address(int_2)
    var_3 = parse_address(int_3, allow_ranges=True)
    var_4 = parse_address(int_4)
    var_5 = parse_address(int_5, allow_ranges=True)
    var_

# Generated at 2022-06-25 04:13:36.440087
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('192.168.1.1[1:3]:22')
    assert host == '192.168.1.1[1:3]'
    assert port == 22

    host, port = parse_address('192.168.2.2')
    assert host == '192.168.2.2'
    assert port is None

    host, port = parse_address('192.168.3.3:22')
    assert host == '192.168.3.3'
    assert port == 22

    host, port = parse_address('[192.168.4.4]:22')
    assert host == '192.168.4.4'
    assert port == 22

    host, port = parse_address('host[1:3]:22')
    assert host == 'host[1:3]'

# Generated at 2022-06-25 04:13:42.868377
# Unit test for function parse_address
def test_parse_address():
    int_0 = "a"
    var_0 = parse_address(int_0)
    assert var_0 == ('a', None)

    int_1 = "a[1:2]:32"
    var_0 = parse_address(int_1)
    assert var_0 == ('a[1:2]', 32)

    int_2 = "a["
    var_0 = parse_address(int_2)
    try:
        var_0 == ('a[', None)
    except AnsibleParserError:
        print("AnsibleParserError is raised")

    int_3 = "a:"
    var_0 = parse_address(int_3)
    assert var_0 == ('a', None)

    int_4 = "1.2.3.4:1"
    var_0 = parse_