

# Generated at 2022-06-25 04:11:37.065834
# Unit test for function parse_address
def test_parse_address():

    # Basic test: valid IPv4 address with port
    (host, port) = parse_address('192.0.2.1:55')
    assert host == '192.0.2.1' and port == 55

    # Basic test: valid IPv4 address without port
    (host, port) = parse_address('192.0.2.1')
    assert host == '192.0.2.1' and port is None

    # Basic test: valid IPv6 address with port
    (host, port) = parse_address('[2001:db8::1]:55')
    assert host == '2001:db8::1' and port == 55

    # Basic test: valid IPv6 address without port
    (host, port) = parse_address('[2001:db8::1]')

# Generated at 2022-06-25 04:11:40.968087
# Unit test for function parse_address
def test_parse_address():
    print('Testing parse_address')
    int_0 = -8191
    var_0 = parse_address(int_0)
    print(var_0)
    print('Test complete')


# Generated at 2022-06-25 04:11:50.349559
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("192.168.0.1:22") == ("192.168.0.1", 22)
    assert parse_address("192.168.0.1") == ("192.168.0.1", None)
    assert parse_address("192.168.0.1", allow_ranges=True) == ("192.168.0.1", None)
    assert parse_address("192.168.0.1:22", allow_ranges=True) == ("192.168.0.1", 22)
    assert parse_address("192.168.0.1[1:5]:22", allow_ranges=True) == ("192.168.0.1[1:5]", 22)

# Generated at 2022-06-25 04:11:52.616993
# Unit test for function parse_address
def test_parse_address():
    for int_0 in range(0, 5):
        var_0 = parse_address(int_0)

# Function to be tested.
# It must be named Main

# Generated at 2022-06-25 04:11:58.049359
# Unit test for function parse_address
def test_parse_address():
    # Generate a test case from the following inputs:
    #   int_0 = -2216

    # Invoke the parse_address function with argument int_0
    (host, port) = parse_address(int_0)

    # Verify the assertion host is None
    assert host is None


# Generated at 2022-06-25 04:12:02.986784
# Unit test for function parse_address
def test_parse_address():
    # Unit test function parse_address
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 04:12:11.468962
# Unit test for function parse_address
def test_parse_address():
    int_0 = -2216
    var_0 = parse_address(int_0)
    assert var_0[0] == -2216
    if var_0[0] == -2216:
        assert var_0[1] == None
    int_1 = -612231644
    var_1 = parse_address(int_1)
    assert var_1[0] == -612231644
    if var_1[0] == -612231644:
        assert var_1[1] == None
    int_2 = -527262414
    var_2 = parse_address(int_2)
    assert var_2[0] == -527262414
    if var_2[0] == -527262414:
        assert var_2[1] == None
   

# Generated at 2022-06-25 04:12:20.657649
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:23.901461
# Unit test for function parse_address
def test_parse_address():
    # Prevent the unit tests from being executed by the pyinstaller.
    # See https://github.com/pyinstaller/pyinstaller/issues/1699
    pass

# Used when generating the executable
if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:12:34.210858
# Unit test for function parse_address