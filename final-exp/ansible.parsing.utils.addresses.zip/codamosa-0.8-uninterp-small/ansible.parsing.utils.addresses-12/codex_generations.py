

# Generated at 2022-06-25 04:11:36.415846
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('S@7!NL') == ('S@7!NL', None)
    assert parse_address('S@7!NL:5000') == ('S@7!NL', 5000)
    assert parse_address('[S@7!NL]:5000') == ('S@7!NL', 5000)
    assert parse_address('[127.0.0.1]:5000') == ('127.0.0.1', 5000)
    assert parse_address('127.0.0.1:5000') == ('127.0.0.1', 5000)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:5000') == ('::1', 5000)


# Generated at 2022-06-25 04:11:44.407538
# Unit test for function parse_address
def test_parse_address():
    pattern = r'''
        (?:[\w]|
        \[(?:\d+:\d+(?::\d+)?|[0-9a-f]+:[0-9a-f]+(?::\d+)?|[a-z]:[a-z]|\d+
        :\d+)(?::\d+)?\])
        (?:[\w_-]|
        \[(?:\d+:\d+(?::\d+)?|[0-9a-f]+:[0-9a-f]+(?::\d+)?|[a-z]:[a-z]|\d+
        :\d+)(?::\d+)?\])*
        (?<![_-])$
    '''
    actual = re.compile(pattern, re.X)

# Generated at 2022-06-25 04:11:52.082395
# Unit test for function parse_address
def test_parse_address():
    for _ in range(10):
        # str_0 = 'c0b6637c9e914dd07d3f3e1e2a0d08a8'
        str_0 = '1.2.3.4'
        var_0 = parse_address(str_0)

        # Equivalent to the C version above
        # import random, string
        # str_0 = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(8))
        # var_0 = parse_address(str_0)

# Equivalent to the C version above

# Generated at 2022-06-25 04:12:01.143791
# Unit test for function parse_address
def test_parse_address():
    print("Test: parse_address")

    # Should find host and port
    str_0 = '192.0.2.1:22'
    (host, port) = parse_address(str_0)
    assert host == '192.0.2.1'
    assert port == 22
    print("Host test 1 pass")

    # Should parse IPv6 address without port
    str_1 = '2001:DB8::8a2e:370:7334'
    (host, port) = parse_address(str_1)
    assert host == '2001:DB8::8a2e:370:7334'
    assert port is None
    print("IPv6 test 1 pass")

    # Should parse IPv6 address with port
    str_2 = '[2001:DB8::8a2e:370:7334]:443'

# Generated at 2022-06-25 04:12:10.731198
# Unit test for function parse_address
def test_parse_address():
    str_0 = "abcd:[::ffff]:255"
    var_0 = parse_address(str_0, True)
    if var_0[0] != "abcd:[::ffff]:255" and var_0[1] is not None:
        raise AssertionError("test_parse_address 1")

    str_1 = 'S@7!NL'
    var_1 = parse_address(str_1)
    if var_1[0] != "S@7!NL" and var_1[1] is None:
        raise AssertionError("test_parse_address 2")

    str_2 = "1-255"
    var_2 = parse_address(str_2)
    if var_2[0] != "1-255" and var_2[1] is None:
        raise Assert

# Generated at 2022-06-25 04:12:18.389220
# Unit test for function parse_address
def test_parse_address():
    assert str(type(parse_address('[::1]:1', allow_ranges=False))) == "<type 'tuple'>"
    assert str(type(parse_address('[::1]:1', allow_ranges=True))) == "<type 'tuple'>"
    assert str(type(parse_address('[::1]', allow_ranges=False))) == "<type 'tuple'>"
    assert str(type(parse_address('[::1]', allow_ranges=True))) == "<type 'tuple'>"
    assert str(type(parse_address('hostname:1', allow_ranges=False))) == "<type 'tuple'>"
    assert str(type(parse_address('hostname:1', allow_ranges=True))) == "<type 'tuple'>"

# Generated at 2022-06-25 04:12:18.989260
# Unit test for function parse_address
def test_parse_address():
    assert True == True

# Generated at 2022-06-25 04:12:21.385177
# Unit test for function parse_address
def test_parse_address():
    str_0 = 'S@7!NL'
    var_1 = parse_address(str_0)
    assert var_1 == (u'S@7!NL', None)


# Generated at 2022-06-25 04:12:27.760520
# Unit test for function parse_address
def test_parse_address():
    # the proper answer is ('foo.example.com', 22)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    # the proper answer is ('foo.example.com', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)

    # the proper answer is ('foo.example.com', 22)
    assert parse_address('foo.example.com:22', allow_ranges=True) == ('foo.example.com', 22)
    # the proper answer is ('foo.example.com', None)
    assert parse_address('foo.example.com', allow_ranges=True) == ('foo.example.com', None)

    # the proper answer is ('foo[1:2]+bar', None)

# Generated at 2022-06-25 04:12:35.745132
# Unit test for function parse_address
def test_parse_address():
    assert (parse_address('S@7!NL') == (None, None))
    assert (parse_address('S@7!NL:22') == (None, None))
    assert (parse_address('S@7!NL', allow_ranges=True) == (None, None))
    assert (parse_address('S@7!NL:22', allow_ranges=True) == (None, None))
    assert (parse_address('10.10.10.10') == ('10.10.10.10', None))
    assert (parse_address('10.10.10.10', allow_ranges=True) == ('10.10.10.10', None))
    assert (parse_address('10.10.10.10', allow_ranges=True) == ('10.10.10.10', None))

# Generated at 2022-06-25 04:12:47.166060
# Unit test for function parse_address
def test_parse_address():
    assert 'foo.example.com' == parse_address('foo.example.com:123')[0]
    assert 123 == parse_address('foo.example.com:123')[1]
    assert 'foo.example.com' == parse_address('foo.example.com')[0]
    assert None == parse_address('foo.example.com')[1]
    assert 'foo[1:3].example.com' == parse_address('foo[1:3].example.com')[0]
    assert None == parse_address('foo[1:3].example.com')[1]
    assert 'foo[1:3].example.com' == parse_address('foo[1:3].example.com:123')[0]
    assert 123 == parse_address('foo[1:3].example.com:123')[1]

# Generated at 2022-06-25 04:12:51.702142
# Unit test for function parse_address
def test_parse_address():
    print("Function: parse_address")
    test_case_0()


# Generated at 2022-06-25 04:12:58.317007
# Unit test for function parse_address
def test_parse_address():
    t_0 = 'example.com'
    t_1 = 'example.com:1234'
    t_2 = '192.0.2.1:1234'
    t_3 = '[192.0.2.1]:1234'
    t_4 = '192.0.2.1[2:3]:1234'
    t_5 = '[2001:db8::1]:1234'
    t_6 = '[2001:db8::1][2:3]:1234'
    t_7 = '2001:db8::1:1234'
    t_8 = 'localhost'
    t_9 = 'test.example.com'
    t_10 = 'test.example.com:1234'
    t_11 = '192.0.2.1'

# Generated at 2022-06-25 04:13:02.621677
# Unit test for function parse_address
def test_parse_address():
    assert isinstance(parse_address('S@7!NL'), tuple)


# Generated at 2022-06-25 04:13:04.714951
# Unit test for function parse_address
def test_parse_address():
    assert 0 == parse_address('foo', True)


# Generated at 2022-06-25 04:13:15.491732
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('pass@ssh://my.server.com:2222/') == ('my.server.com', 2222)
    assert parse_address('server.com') == ('server.com', None)
    assert parse_address('server.com:22') == ('server.com', 22)
    assert parse_address('server.com:22') == ('server.com', 22)
    assert parse_address('[server.com:22]') == ('server.com:22', None)
    assert parse_address('[server.com:22]') == ('server.com:22', None)
    assert parse_address('[ server.com:22 ]') == (' server.com:22 ', None)
    assert parse_address('[ server.com:22 ]') == (' server.com:22 ', None)

# Generated at 2022-06-25 04:13:20.812870
# Unit test for function parse_address
def test_parse_address():
    str_0 = 'S@7!NL'
    var_0 = parse_address(str_0)
    result = (var_0, 2)

    assert result == (('S@7!NL', None), 2)


# Generated at 2022-06-25 04:13:26.655567
# Unit test for function parse_address
def test_parse_address():
    # Example to demonstrate how to use this function
    assert parse_address('S@7!NL') == ('S@7!NL', None)

    # For a full list of tests, see the test suite in test/unit/utils/test_ipaddr.py.

# ----------------------------------------------------------------------
# M A I N
# ----------------------------------------------------------------------

test_case_0()
test_parse_address()

# Generated at 2022-06-25 04:13:34.127762
# Unit test for function parse_address
def test_parse_address():
    print('Testing parse_address()')

    # Setup

# Generated at 2022-06-25 04:13:34.855592
# Unit test for function parse_address
def test_parse_address():
    assert False, "Unit test not implemented"

# Generated at 2022-06-25 04:13:40.881550
# Unit test for function parse_address
def test_parse_address():
    print("Unit test for function parse_address")
    test_case_0()

if __name__== "__main__":
    test_parse_address()

# Generated at 2022-06-25 04:13:43.569831
# Unit test for function parse_address
def test_parse_address():
    test_case_0()


if __name__ == "__main__":
    test_parse_address()

# Generated at 2022-06-25 04:13:50.924223
# Unit test for function parse_address
def test_parse_address():
    print("STARTING UNIT TEST: *****  parse_address  *****")
    # TEST 0
    print("TEST 0: (Test host verification)")
    str_0 = 'S@7!NL'
    try:
        var_0 = parse_address(str_0)
        print("Test case 0: test_parse_address: BAD: did not throw an exception")
    except AnsibleError:
        print("Test case 0: test_parse_address: GOOD: correctly threw an exception")
    # TEST 1
    print("TEST 1: (Test IPv4 address without port)")
    str_1 = '192.0.2.55'
    var_1 = parse_address(str_1)

# Generated at 2022-06-25 04:14:01.768476
# Unit test for function parse_address
def test_parse_address():
    # Testing if the function can accept an empty string
    try:
        parse_address("")
        # We should not reach this line
        assert False
    except AnsibleError as e:
        pass
    except:
        # We should not reach this line
        assert False

    # Testing if the function can parse a string with a correct port number
    assert parse_address("192.168.0.1:80") == (u'192.168.0.1', 80)
    assert parse_address("[192.168.0.1]:80") == (u'[192.168.0.1]', 80)
    assert parse_address("localhost:22") == (u'localhost', 22)
    assert parse_address("[localhost]:22") == (u'[localhost]', 22)

# Generated at 2022-06-25 04:14:05.964497
# Unit test for function parse_address
def test_parse_address():
    test_case_0()

# Generated at 2022-06-25 04:14:14.658373
# Unit test for function parse_address

# Generated at 2022-06-25 04:14:20.192161
# Unit test for function parse_address
def test_parse_address():
    for case in range(4):
        if case == 0:
            str_0 = 'S@7!NL'
            var_0 = parse_address(str_0)
        if case == 1:
            str_0 = 'S@7!NL'
            var_0 = parse_address(str_0, allow_ranges=False)
        if case == 2:
            str_0 = 'S@7!NL'
            var_0 = parse_address(str_0, allow_ranges=True)
        if case == 3:
            str_0 = 'S@7!NL'
            var_0 = parse_address(str_0, allow_ranges=False)

# Generated at 2022-06-25 04:14:25.096170
# Unit test for function parse_address
def test_parse_address():
    # This test case doesn't currently exist in Ansible.
    # It is generated for analysis test.
    # It evaluates the correctness of the function parse_address.
    test_case_0()

# Analysis test for function parse_address

# Generated at 2022-06-25 04:14:33.167712
# Unit test for function parse_address
def test_parse_address():

    # Everything is a valid hostname

    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:42') == ('foo.example.com', 42)

    # IPv4 addresses

    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('0.0.0.0') == ('0.0.0.0', None)

# Generated at 2022-06-25 04:14:43.856507
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:5') == ('1.2.3.4', 5)
    assert parse_address('[1.2.3.4]', True) == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]', False) == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:5', True) == ('1.2.3.4', 5)
    assert parse_address('[1.2.3.4]:5', False) == ('1.2.3.4', 5)
    assert parse_address('1.2.3.4')

# Generated at 2022-06-25 04:15:00.065678
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('S@7!NL') == (u'S@7!NL', None)
    assert parse_address('S@7!NL:123') == (u'S@7!NL', 123)
    assert parse_address('1.2.3.4') == (u'1.2.3.4', None)
    assert parse_address('1.2.3.4:123') == (u'1.2.3.4', 123)
    assert parse_address('[1.2.3.4]:123') == (u'1.2.3.4', 123)
    assert parse_address(u'[::1]:123') == (u'::1', 123)
    assert parse_address(u'[::1]') == (u'::1', None)

# Generated at 2022-06-25 04:15:00.775086
# Unit test for function parse_address
def test_parse_address():
    test_case_0()



# Generated at 2022-06-25 04:15:06.297673
# Unit test for function parse_address
def test_parse_address():
    # Test case 0
    str_0 = 'S@7!NL'
    var_0 = parse_address(str_0)
    print('Result: ' + str(var_0))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:15:08.452126
# Unit test for function parse_address
def test_parse_address():
    assert callable(parse_address)

# Testing the Python Standard Library
import unittest


# Generated at 2022-06-25 04:15:16.442395
# Unit test for function parse_address
def test_parse_address():
    def test_assertion(address, expected_host, expected_port):
        (actual_host, actual_port) = parse_address(address)
        assert actual_host == expected_host and actual_port == expected_port

    test_assertion('localhost', 'localhost', None)
    test_assertion('localhost:42', 'localhost', 42)
    test_assertion('example.com:42', 'example.com', 42)
    test_assertion('[2001:db8::1]:42', '2001:db8::1', 42)
    test_assertion('[192.0.2.1]:42', '192.0.2.1', 42)
    test_assertion('foo[1:3]', 'foo[1:3]', None)

# Generated at 2022-06-25 04:15:22.675204
# Unit test for function parse_address
def test_parse_address():
    with pytest.raises(AnsibleError):
        str_0 = 'S@7!NL'
        var_0 = parse_address(str_0)
    with pytest.raises(AnsibleError):
        str_0 = '128.66.68.nme'
        var_0 = parse_address(str_0)
    with pytest.raises(AnsibleParserError):
        str_0 = '128.66.68.18[0:5]:77'
        var_0 = parse_address(str_0)
    with pytest.raises(AnsibleParserError):
        str_0 = '[f:g:h]::78'
        var_0 = parse_address(str_0)
    with pytest.raises(AnsibleParserError):
        str_0

# Generated at 2022-06-25 04:15:33.321795
# Unit test for function parse_address
def test_parse_address():

    str_0 = '[192.0.2.3]'
    str_1 = '[C0::2:3]'
    str_2 = '192.0.2.3'
    str_3 = 'C0::2:3'
    str_4 = 'localhost'
    str_5 = 'myname[1:3]'
    str_6 = 'myname[0:5]-othername[a-c]'
    str_7 = 'myname[1:3]:80'
    str_8 = 'myname[0:5]-othername[a-c]:80'
    str_9 = '[192.0.2.3]:80'
    str_10 = '[myname[1:3]]:80'
    str_11 = '[192.0.2.3]:80'

# Generated at 2022-06-25 04:15:37.189758
# Unit test for function parse_address
def test_parse_address():
    try:
        test_case_0()
    except Exception as e:
        print('FAIL: test_parse_address: ' + str(e))
        assert False

    print('PASS')

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:15:44.752736
# Unit test for function parse_address
def test_parse_address():

    # Unit test for AnsibleError exception with parameter 'Detected range in host but was asked to ignore ranges'
    try:
        str_0 = 'S@7!NL'
        parse_address(str_0)
    except AnsibleError as e:
        assert e.message == 'Detected range in host but was asked to ignore ranges'

    # Unit test for AnsibleError exception with parameter 'Not a valid network hostname: S@7!NL'
    try:
        str_0 = 'S@7!NL'
        parse_address(str_0, True)
    except AnsibleError as e:
        assert e.message == 'Not a valid network hostname: S@7!NL'

    # Unit test for AnsibleError exception with parameter "Not a valid network hostname: [S@7!NL]:10"

# Generated at 2022-06-25 04:15:53.193973
# Unit test for function parse_address
def test_parse_address():

    # test_0
    str_0 = '172.16.0.0'
    str_1 = None
    port_0 = None
    port_1 = 1234
    str_2 = None
    str_3 = '172.16.0.0:1234'
    str_4 = '172.16.0.0:1234'
    str_5 = '[172.16.0.0]'
    str_6 = '[172.16.0.0]:1234'
    var_0 = parse_address(str_0)
    var_1 = parse_address(str_1)
    var_2 = parse_address(str_2)
    var_3 = parse_address(str_3)
    var_4 = parse_address(str_4)

# Generated at 2022-06-25 04:16:03.792587
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('S@7!NL')


# Generated at 2022-06-25 04:16:04.261451
# Unit test for function parse_address
def test_parse_address():
  pass


# Generated at 2022-06-25 04:16:12.725960
# Unit test for function parse_address
def test_parse_address():
    host, port = parse_address('1.2.3.4')
    if host != '1.2.3.4' or port != None:
        print('parse_address test failed')
    else:
        print('parse_address test passed')
    print(host)
    print(port)
    host, port = parse_address('1.2.3.4:22')
    if host != '1.2.3.4' or port != 22:
        print('parse_address test failed')
    else:
        print('parse_address test passed')
    print(host)
    print(port)
    host, port = parse_address('ipv6::22')
    if host != 'ipv6::' or port != 22:
        print('parse_address test failed')

# Generated at 2022-06-25 04:16:21.566576
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('10.15.2.3:21') == ('10.15.2.3', 21)
    assert parse_address('[10.15.2.3]:22') == ('10.15.2.3', 22)
    assert parse_address('[10.15.2.3]') == ('10.15.2.3', None)
    assert parse_address('10.15.2.3') == ('10.15.2.3', None)
    assert parse_address('example.com:33') == ('example.com', 33)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:44') == ('example.com', 44)
   

# Generated at 2022-06-25 04:16:24.434038
# Unit test for function parse_address
def test_parse_address():
    print("test parse_address")
    result = parse_address('S@7!NL')
    print("result %s" % result)
    assert result == ('S@7!NL', None)


if __name__ == "__main__":
    # test_case_0()
    test_parse_address()

# Generated at 2022-06-25 04:16:35.135849
# Unit test for function parse_address
def test_parse_address():
    str_0 = '123'
    str_1 = '123.123'
    str_2 = '123.123.[1:6]'
    str_3 = '123.123.123.[1:6]'
    str_4 = '123.123.123.123'
    str_5 = 'foo.[1:5]-bar'
    str_6 = 'foo[1:5]-bar.[1:5]'
    str_7 = 'foo[1:5]-bar.fizz[1:5]'
    str_8 = 'foo[1:5]-bar.fizz.buzz[1:5]'
    str_9 = 'foo[1:5]-bar.[1:5].bazz'
    str_10 = 'foo.bar-[1:5]-baz.fizz'

# Generated at 2022-06-25 04:16:43.908291
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('S@7!NL') == (None, None)
    assert parse_address('S@7!NL') == (None, None)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.1.1:22') == ('127.0.1.1', 22)
    assert parse_address('127.0.1.1:[0:1000]:22') == ('127.0.1.1:[0:1000]', 22)
    assert parse_address('[127.0.1.1]:22') == ('127.0.1.1', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse

# Generated at 2022-06-25 04:16:51.219159
# Unit test for function parse_address
def test_parse_address():
    # Test case 0
    str_0 = 'S@7!NL'
    var_0 = parse_address(str_0)

    if var_0[0] == 'S@7!NL':
        print("SUCCESS: test_parse_address:case_0")
    else:
        print("FAIL: test_parse_address:case_0")


# Generated at 2022-06-25 04:16:52.497961
# Unit test for function parse_address
def test_parse_address():
    assert test_case_0() == ('S@7!NL', None)



# Generated at 2022-06-25 04:16:54.854450
# Unit test for function parse_address
def test_parse_address():
    # TODO: make this unit test passable
    # str_3 = 'S@7!NL'
    # var_3 = parse_address(str_3)
    assert False == False



# Generated at 2022-06-25 04:17:16.398924
# Unit test for function parse_address
def test_parse_address():
    assert isinstance(parse_address(str_0), tuple)



# Generated at 2022-06-25 04:17:26.221405
# Unit test for function parse_address
def test_parse_address():
    input = 'google.com'
    result = parse_address(input)
    print("-------------------------------------------------------------------------------------")
    expected = ['google.com', None]
    print("Result : " + str(result) + " -- Expected : " + str(expected))
    assert result == expected
    print("------------------------------------------------------")
    input = '192.168.0.1'
    result = parse_address(input)
    expected = ['192.168.0.1', None]
    print("Result : " + str(result) + " -- Expected : " + str(expected))
    assert result == expected
    print("------------------------------------------------------")
    input = '192.168.0.1:80'
    result = parse_address(input, allow_ranges=True)
    expected = ['192.168.0.1', 80]


# Generated at 2022-06-25 04:17:33.690731
# Unit test for function parse_address
def test_parse_address():
    # These tests correspond to the example patterns in the docstring.
    assert parse_address('192.0.2.1:80') == ('192.0.2.1', 80)
    assert parse_address('foo[1:3].example.net') == ('foo[1:3].example.net', None)
    assert parse_address('[::ffff:192.0.2.33]:80') == ('[::ffff:192.0.2.33]', 80)
    assert parse_address('[fe80::1d5:82ff:fefa:39b]:8080') == ('[fe80::1d5:82ff:fefa:39b]', 8080)

# Generated at 2022-06-25 04:17:42.355624
# Unit test for function parse_address
def test_parse_address():
    str_0 = 'S@7!NL'
    var_0 = parse_address(str_0)
    str_1 = '127.0.0.1:222'
    var_1 = parse_address(str_1)
    str_2 = 's7nl.net:443'
    var_2 = parse_address(str_2)
    str_3 = '::ffff:192.0.2.3'
    var_3 = parse_address(str_3)
    str_4 = '2001:db8::'
    var_4 = parse_address(str_4)



# Generated at 2022-06-25 04:17:46.222446
# Unit test for function parse_address
def test_parse_address():
    try:
        str_0 = 'S@7!NL'
        var_0 = parse_address(str_0)
    except AnsibleError as e:
        pass
    else:
        raise AssertionError("should not get here")


if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:17:54.013662
# Unit test for function parse_address
def test_parse_address():
    str_0 = 'S@7!NL'
    var_0 = parse_address(str_0)
    assert var_0 is not None, 'AnsibleError "1" not raised when expected'
    assert 'Not a valid network hostname' in str(var_0), 'AnsibleError not raised when expected'

    str_1 = 'a'
    var_1 = parse_address(str_1)
    assert var_1 is not None, 'AnsibleError "2" not raised when expected'
    assert 'Not a valid network hostname' in str(var_1), 'AnsibleError not raised when expected'

    str_2 = 'foo'
    var_2 = parse_address(str_2)
    assert var_2 is not None, 'AnsibleError "3" not raised when expected'
   

# Generated at 2022-06-25 04:18:00.292041
# Unit test for function parse_address
def test_parse_address():
    # Test with correct inputs
    str_7 = 'S@7!NL'
    res_2 = ('S@7!NL', None)
    assert res_2 == parse_address(str_7)

    # Test with incorrect inputs
    str_0 = ''
    assert (None, None) == parse_address(str_0)



# Generated at 2022-06-25 04:18:06.858458
# Unit test for function parse_address
def test_parse_address():

    # Arguments
    #  address = 'S@7!NL'
    #  allow_ranges = False
    #
    # Return:
    #  (None, None)
    print(test_case_0())


if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:18:11.487908
# Unit test for function parse_address
def test_parse_address():
    try:
        test_case_0()
    except Exception:
        pass

if __name__ == '__main__':
    test_parse_address()
    # Run tests with 'python -m ansible.utils.network_parser'
    import unittest

    class TestParseAddress(unittest.TestCase):
        def test_parse_address(self):
            str_0 = 'S@7!NL'
            regex_0 = re.compile(r'[A-Za-z0-9_]')

# Generated at 2022-06-25 04:18:12.803817
# Unit test for function parse_address
def test_parse_address():
    str_0 = 'S@7!NL'
    var_1 = parse_address(str_0)


if __name__ == '__main__':
    test_parse_address()
    test_case_0()