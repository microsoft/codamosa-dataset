

# Generated at 2022-06-25 04:11:29.332092
# Unit test for function parse_address
def test_parse_address():
    int_0 = '12'
    var_0 = parse_address(int_0)
    int_1 = '192.168.1.1'
    var_1 = parse_address(int_1)


# Generated at 2022-06-25 04:11:38.635956
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.bar/baz') == ('foo.bar', None)
    assert parse_address('foo.bar[1:3]') == ('foo.bar[1:3]', None)
    assert parse_address('foo[1:3].bar') == ('foo[1:3].bar', None)
    assert parse_address('foo[a:c].bar') == ('foo[a:c].bar', None)
    assert parse_address('foo:bar:baz') == ('foo:bar:baz', None)
    assert parse_address('foo:bar:baz[1:3]') == ('foo:bar:baz[1:3]', None)
    assert parse_address('192.168.1.1:abc') == ('192.168.1.1', None)
    assert parse_address

# Generated at 2022-06-25 04:11:47.509778
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("8.8.8.8:80") == ("8.8.8.8", 80)
    assert parse_address("a[1:2]b:80") == ("a[1:2]b", 80)
    assert parse_address("a[1:2]b:80:80") == ("a[1:2]b", 80)
    assert parse_address("a[1:2]b:80:80:80") == ("a[1:2]b", 80)
    assert parse_address("a[2:2]b:80:80:80") == ("a[2:2]b", 80)
    assert parse_address("a[1:1]b:80:80:80") == ("a[1:1]b", 80)

# Generated at 2022-06-25 04:11:58.364939
# Unit test for function parse_address
def test_parse_address():
    int_0 = 'myhost:80'
    var_0 = parse_address(int_0)
    assert var_0 == ('myhost', 80), 'The result should be "myhost:80"'
    int_1 = 'example.com'
    var_1 = parse_address(int_1)
    assert var_1 == ('example.com', None), 'The result should be "example.com"'
    int_2 = 'example.com[1:2]'
    var_2 = parse_address(int_2)
    assert var_2 == ('example.com[1:2]', None), 'The result should be "example.com[1:2]"'
    int_3 = 'example.com[1:2]'
    var_3 = parse_address(int_3, True)

# Generated at 2022-06-25 04:12:03.709250
# Unit test for function parse_address
def test_parse_address():
    int_0 = '10.10.10.10'
    var_0 = parse_address(int_0)
    assert var_0 == ('10.10.10.10', None)
    int_1 = '10.10.10.10:22'
    var_1 = parse_address(int_1)
    assert var_1 == ('10.10.10.10', 22)
    int_2 = 'example.com'
    var_2 = parse_address(int_2)
    assert var_2 == ('example.com', None)
    int_3 = 'example.com:22'
    var_3 = parse_address(int_3)
    assert var_3 == ('example.com', 22)
    int_4 = 'example.com:22:33'
    var_4 = parse_address

# Generated at 2022-06-25 04:12:06.369152
# Unit test for function parse_address
def test_parse_address():
    with pytest.raises(AnsibleError) as excinfo:
        parse_address(568)
    assert 'Invalid network address' in str(excinfo.value)


# Generated at 2022-06-25 04:12:15.304998
# Unit test for function parse_address
def test_parse_address():
    int_0 = 'foo[1-3]:22'
    var_0 = parse_address(int_0)
    assert var_0 == ('foo[1-3]', 22)
    int_0 = 'foo[1-3]'
    var_0 = parse_address(int_0)
    assert var_0 == ('foo[1-3]', None)
    int_0 = 'foo:22'
    var_0 = parse_address(int_0)
    assert var_0 == ('foo', 22)
    int_0 = 'foo'
    var_0 = parse_address(int_0)
    assert var_0 == ('foo', None)
    int_0 = '1.2.3.4:22'
    var_0 = parse_address(int_0)

# Generated at 2022-06-25 04:12:18.366990
# Unit test for function parse_address
def test_parse_address():
    int_0 = 568
    var_0 = parse_address(int_0)


# Generated at 2022-06-25 04:12:25.612526
# Unit test for function parse_address
def test_parse_address():
    int_0 = 568
    var_0 = parse_address(int_0)
    assert (var_0 == (568, None))
    int_1 = "foo.example.com"
    var_1 = parse_address(int_1)
    assert (var_1 == (int_1, None))
    int_2 = "192.0.2.3:100"
    var_2 = parse_address(int_2)
    assert (var_2 == ("192.0.2.3", 100))
    int_3 = "192.0.2.3:65536"
    var_3 = parse_address(int_3)
    assert (var_3 == ("192.0.2.3", 65536))
    int_4 = "::1:65536"
    var_4 = parse_

# Generated at 2022-06-25 04:12:29.344649
# Unit test for function parse_address
def test_parse_address():

    # Characteristics:
    # num = 0, len = 1
    int_0 = 15
    int_1 = 25
    int_2 = 35

    # Characteristics:
    # num = 4, len = 2
    var_0 = parse_address(int_0)
    var_1 = parse_address(int_1)
    var_2 = parse_address(int_2)

    assert (var_0 == var_1)
    assert (var_1 == var_2)

if __name__ == "__main__":
    test_parse_address()