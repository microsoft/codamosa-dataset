

# Generated at 2022-06-25 04:11:26.220670
# Unit test for function parse_address
def test_parse_address():
    assert True

# Generated at 2022-06-25 04:11:27.208494
# Unit test for function parse_address
def test_parse_address():
    test_case_0()

# Utility function used to locate a module in the context of a playbook.

# Generated at 2022-06-25 04:11:37.367111
# Unit test for function parse_address
def test_parse_address():
    str_a = '\r"rY)F'
    var_a = parse_address(str_a)
    str_b = '30.159.152.29:1234'
    var_b = parse_address(str_b)
    str_c = '30.159.152.29'
    var_c = parse_address(str_c)
    str_d = '[30.159.152.29]:1234'
    var_d = parse_address(str_d)
    str_e = '2001:db8::1:0'
    var_e = parse_address(str_e)
    str_f = '[2001:db8::1:0]:1234'
    var_f = parse_address(str_f)

# Generated at 2022-06-25 04:11:43.428381
# Unit test for function parse_address
def test_parse_address():
    str_0 = '[2001:db8::1]:50'
    str_1 = '[2001:db8:1234::1]:50'
    str_2 = '127.0.0.1'
    str_3 = '127.0.0.1:50'
    str_4 = 'localhost'
    str_5 = 'localhost:50'
    str_6 = '127.0.0.1[10:20]'
    str_7 = '127.0.0.1[10:20]:50'
    str_8 = 'localhost[10:20]'
    str_9 = 'localhost[10:20]:50'
    str_10 = '127.0.0.1[10:20]'
    str_11 = '127.0.0.1[10:20]:50'
    str_12

# Generated at 2022-06-25 04:11:49.923603
# Unit test for function parse_address
def test_parse_address():
    str_0 = '[::1]:22'
    var_0 = parse_address(str_0)
    print(var_0)

    str_0 = 'localhost:22'
    var_0 = parse_address(str_0)
    print(var_0)

    str_0 = 'tbs-test-host:22'
    var_0 = parse_address(str_0)
    print(var_0)

if __name__ == "__main__":
    test_parse_address()

# Generated at 2022-06-25 04:12:01.744750
# Unit test for function parse_address
def test_parse_address():
    str_0 = '\r"rY)F'
    var_0 = parse_address(str_0)

    str_1 = '\t'
    var_1 = parse_address(str_1)

    str_2 = '\r"rY)F'
    var_2 = parse_address(str_2)

    str_3 = 'jg>_P'
    var_3 = parse_address(str_3)

    str_4 = 'szs#F'
    var_4 = parse_address(str_4)

    str_5 = 'T]_M\x0c'
    var_5 = parse_address(str_5)

    str_6 = '\x0f\x15'
    var_6 = parse_address(str_6)

    str_7

# Generated at 2022-06-25 04:12:11.479330
# Unit test for function parse_address
def test_parse_address():
    assert(parse_address('localhost') == ('localhost', None))
    assert(parse_address('localhost:22') == ('localhost', 22))
    assert(parse_address('[::1]') == ('::1', None))
    assert(parse_address('[::1]:22') == ('::1', 22))
    assert(parse_address('[::ffff:192.0.2.5]') == ('::ffff:192.0.2.5', None))
    assert(parse_address('[::ffff:192.0.2.5]:22') == ('::ffff:192.0.2.5', 22))
    assert(parse_address('192.0.2.5') == ('192.0.2.5', None))

# Generated at 2022-06-25 04:12:19.042774
# Unit test for function parse_address
def test_parse_address():
    # From pytest_ansible.pytest_ansible_make_inventory
    groups = {'all': {'hosts': ['1.1.1.1', '2.2.2.2', '3.3.3.3'], 'vars': None}, 'build': {'hosts': ['1.1.1.1', '3.3.3.3'], 'vars': None}}
    # From pytest_ansible.pytest_ansible_make_inventory

    str_0 = '\r"rY)F'
    var_0 = parse_address(str_0)



# Generated at 2022-06-25 04:12:26.167549
# Unit test for function parse_address
def test_parse_address():
    str_0 = ''
    str_1 = 'F@@DP'
    str_2 = ''
    str_3 = '\r"rY)F'
    str_4 = '\r'
    str_5 = '\r'
    str_6 = 'N'

# Generated at 2022-06-25 04:12:28.282309
# Unit test for function parse_address
def test_parse_address():

    assert True == test_case_0()


# Valid

# Generated at 2022-06-25 04:12:39.626879
# Unit test for function parse_address
def test_parse_address():
    # First test case
    str_0 = '\r"rY)F'
    var_0 = parse_address(str_0)
    assert var_0 == (None, None)

    # Second test case
    str_1 = "''"
    var_1 = parse_address(str_1)
    assert var_1 == (None, None)

    # Third test case
    str_2 = 'K,h&'
    var_2 = parse_address(str_2)
    assert var_2 == (None, None)

    # Fourth test case
    str_3 = 'aGp9'
    var_3 = parse_address(str_3)
    assert var_3 == (None, None)

    # Fifth test case
    str_4 = 'x0z'
    var_4 = parse

# Generated at 2022-06-25 04:12:45.508382
# Unit test for function parse_address
def test_parse_address():
    try:
        assert(False)
        test_case_0()
        assert(True)
    except:
        print("Ansible Failed to run")
        assert(False)
    return


if __name__ == '__main__':
    test_parse_address()
    print('OK')

# Generated at 2022-06-25 04:12:54.588706
# Unit test for function parse_address
def test_parse_address():
    str_0 = '\r"rY)F'
    str_1 = '\r"rY)F'
    str_2 = '\r"rY)F'
    str_3 = '\r"rY)F'
    var_0 = parse_address(str_0)
    var_1 = parse_address(str_1)
    var_2 = parse_address(str_2)
    var_3 = parse_address(str_3)
    assert var_0 == var_1
    assert var_2 == var_3

# if __name__ == "__main__":
#     test_case_0()
#     test_case_1()
#     test_case_2()
#     test_case_3()
#     test_case_4()
#     test_case

# Generated at 2022-06-25 04:13:04.053474
# Unit test for function parse_address
def test_parse_address():
    assert 'a[0:1].b.c:1' == parse_address('a[0:1].b.c:1')
    assert 'a[0:1].b.c:1' == parse_address('a[0:1].b.c:1', True)
    assert 'a[0:1].b.c:1' == parse_address('a[0:1].b.c:1', False)
    assert 'a[0:1].b.c' == parse_address('a[0:1].b.c')
    assert 'a[0:1].b.c' == parse_address('a[0:1].b.c', True)
    assert 'a[0:1].b.c' == parse_address('a[0:1].b.c', False)

# Generated at 2022-06-25 04:13:05.049216
# Unit test for function parse_address
def test_parse_address():
    test_case_0()



# Generated at 2022-06-25 04:13:13.068961
# Unit test for function parse_address
def test_parse_address():
    # Function parse_address must be called with 1 argument
    try:
        assert len(sys.argv) == 2
    except AssertionError as e:
        print("Error: Function parse_address must be called with 1 argument")
        print("Exception thrown:", e, file=sys.stderr)


if __name__ == '__main__':
    # test case 0
    test_case_0()
    # unit test for function parse_address
    test_parse_address()

# Generated at 2022-06-25 04:13:14.632586
# Unit test for function parse_address
def test_parse_address():
    assert 'Unit test not implemented' == 'This test needs an implementation'


# Generated at 2022-06-25 04:13:16.828250
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('\r"rY)F') == (None, None)



# Generated at 2022-06-25 04:13:17.945925
# Unit test for function parse_address
def test_parse_address():
    assert True



# Generated at 2022-06-25 04:13:23.833305
# Unit test for function parse_address
def test_parse_address():
    print("Input: %s" % (str_0))
    print("Output: %s" % (var_0))


if __name__ == '__main__':
    test_case_0()