

# Generated at 2022-06-25 04:11:30.153287
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[192.0.2.1]:2', True) == ('192.0.2.1', 2)
    assert parse_address('[192.0.2.1:1:2]:2', True) == ('192.0.2.1:1:2', 2)
    assert parse_address('[2001:db8::1]', True) == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1:2:3:4:5:6:7:8]', True) == ('2001:db8::1:2:3:4:5:6:7:8', None)
    assert parse_address('hostname.example.org:2', True) == ('hostname.example.org', 2)

# Generated at 2022-06-25 04:11:33.985375
# Unit test for function parse_address
def test_parse_address():
    # Test case for parse_address.
    str_0 = ',y\\|HM\x0bYC'
    var_0 = parse_address(str_0)
    assert var_0 == ('y\\|HM\x0bYC', None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:11:35.041466
# Unit test for function parse_address
def test_parse_address():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 04:11:37.567529
# Unit test for function parse_address
def test_parse_address():
    str_0 = '\x19\x14\x10\x7f\r\n^M=\x1c4'
    val_0 = parse_address(str_0)


# Generated at 2022-06-25 04:11:42.930642
# Unit test for function parse_address
def test_parse_address():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        # Convert to failure message
        assert False, "Failure in test_case_0"
        # Unreachable code
        assert False
    # Unit test successful
    assert True


if __name__ == "__main__":
    # Run unit tests
    test_parse_address()

# Generated at 2022-06-25 04:11:52.486830
# Unit test for function parse_address
def test_parse_address():
    # This test makes sure that range patterns are rejected.
    with pytest.raises(AnsibleParserError):
        parse_address('host[1:2]', allow_ranges=False)

    # This test makes sure that range patterns are rejected.
    with pytest.raises(AnsibleParserError):
        parse_address('host[1:2]', allow_ranges=False)

    # This test makes sure that IPv4 addresses are accepted.
    result = parse_address('192.168.0.1')
    assert result == ('192.168.0.1', None)

    # This test makes sure that IPv6 addresses and hostnames without ranges are
    # accepted.
    result = parse_address('[::1]')
    assert result == ('[::1]', None)

# Generated at 2022-06-25 04:12:02.391389
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:03.088970
# Unit test for function parse_address
def test_parse_address():
    pass

# Generated at 2022-06-25 04:12:11.510262
# Unit test for function parse_address
def test_parse_address():

    # Test case 0
    str_0 = ',y\\|HM\x0bYC'
    var_0 = parse_address(str_0)

    # Test case 1
    str_1 = '\r%\r'
    var_1 = parse_address(str_1)

    # Test case 2
    str_2 = '+\x7fU6'
    var_2 = parse_address(str_2)

    # Test case 3
    str_3 = 'Yq\x1d\x18<'
    var_3 = parse_address(str_3)

    # Test case 4
    str_4 = 'p\x16\x7f\x1a'
    var_4 = parse_address(str_4)

    # Test case 5

# Generated at 2022-06-25 04:12:18.741894
# Unit test for function parse_address
def test_parse_address():
    str_0 = ',y\\|HM\x0bYC'
    var_0 = parse_address(str_0)
    assert (var_0 == (None, None))

    str_0 = '\x05\x16\x0b\x17\x05\x07\n\r\r\r\r\r\r\r\r\r\r'
    var_0 = parse_address(str_0)
    assert (var_0 == (None, None))

    str_0 = '\x19\x1e\x1b\x1b\x1e\x19\x1a\x1b\x1d\x19\x1c\x19\x1e\x1d'
    var_0 = parse_address(str_0)