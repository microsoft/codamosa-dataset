

# Generated at 2022-06-25 04:11:28.154859
# Unit test for function parse_address
def test_parse_address():
    assert test_case_0() == True

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:11:31.004937
# Unit test for function parse_address
def test_parse_address():
    print('Running tests for function parse_address...')
    test_case_0()


# Generated at 2022-06-25 04:11:39.216547
# Unit test for function parse_address
def test_parse_address():
    return

    # Test case 1
    # Test with default parameter values.
    bool_1 = True
    var_0 = parse_address(bool_1)
    assert var_0 is None

    # Test case 2
    # Test with default parameter values.
    bool_2 = False
    var_1 = parse_address(bool_2)
    assert var_1 is None

    # Test case 3
    # Test with default parameter values.
    bool_3 = False
    var_2 = parse_address(bool_3)
    assert var_2 is None

    # Test case 4
    # Test with default parameter values.
    bool_4 = False
    var_3 = parse_address(bool_4)
    assert var_3 is None



# Generated at 2022-06-25 04:11:48.131742
# Unit test for function parse_address
def test_parse_address():
    assert '10.2.1.1' == parse_address('10.2.1.1')[0]
    assert '10.2.1.1' == parse_address('10.2.1.1:22')[0]
    assert '10.2.1.1' == parse_address('10.2.1.1:22', allow_ranges=True)[0]
    assert '10.2.1.1' == parse_address('10.2.1.1', allow_ranges=True)[0]
    assert '10.2.1.1' == parse_address('10.2.1.1:22', allow_ranges=False)[0]
    assert '10.2.1.1' == parse_address('10.2.1.1:22', allow_ranges=True)[0]

# Generated at 2022-06-25 04:11:54.855807
# Unit test for function parse_address
def test_parse_address():
    # Test cases for function parse_address

    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print("Exception: {}".format(e))


if __name__ == "__main__":
    test_parse_address()

# Generated at 2022-06-25 04:11:59.796015
# Unit test for function parse_address
def test_parse_address():

    # Replace this with your real tests.
    assert parse_address_full('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address_full('foo.example.com[a:c]:22') == ('foo.example.com[a:c]', 22)
    assert parse_address_full('[::1]') == ('::1', None)
    assert parse_address_full('foo[1:2].example.com') == ('foo[1:2].example.com', None)
    assert parse_address_full('foo[a:b].example.com') == ('foo[a:b].example.com', None)
    assert parse_address_full('foo.example.com[1:3]') == ('foo.example.com[1:3]', None)
    assert parse_

# Generated at 2022-06-25 04:12:10.353907
# Unit test for function parse_address
def test_parse_address():
    #
    #    Test1:
    #        input: (host, port) = ('a.b.com', None)
    #    Expected result:
    #        (host, port) = ('a.b.com', None)
    #
    host, port = ('a.b.com', None)
    result = parse_address(host,False)
    assert (result == (host, port))

    #
    #    Test2:
    #        input: (host, port) = ('a.b.com', '1')
    #    Expected result:
    #        (host, port) = ('a.b.com', 1)
    #
    host, port = ('a.b.com', '1')
    expected = ('a.b.com', int(port))

# Generated at 2022-06-25 04:12:18.058461
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:28.924787
# Unit test for function parse_address
def test_parse_address():
    # Test Cases

    print(parse_address('foo'))
    print(parse_address('foo:'))
    print(parse_address('foo:80'))
    print(parse_address('foo[1:3]', allow_ranges=True))
    print(parse_address('foo[1:3]-bar[x-z]', allow_ranges=True))
    print(parse_address('10.0.0.1'))
    print(parse_address('10.0.0.1:'))
    print(parse_address('10.0.0.1:80'))
    print(parse_address('10.0.0.1[1:3]', allow_ranges=True))
    print(parse_address('[10.0.0.1]'))

# Generated at 2022-06-25 04:12:36.578303
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo[2:4]") == ('foo[2:4]', None)
    assert parse_address("foo[2:4]:22") == ('foo[2:4]', 22)
    assert parse_address("[fec0:0:0:2::2]:22") == ('[fec0:0:0:2::2]', 22)
    assert parse_address("[fec0:0:0:2::2]", allow_ranges=True) == ('fec0:0:0:2::2', None)
    assert parse_address("[fec0:0:0:2::2]", allow_ranges=False) == ('[fec0:0:0:2::2]', None)