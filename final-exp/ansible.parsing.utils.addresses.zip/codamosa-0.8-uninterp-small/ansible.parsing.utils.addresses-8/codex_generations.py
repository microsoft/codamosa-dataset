

# Generated at 2022-06-25 04:11:37.142195
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::]') == ("::", None), "expected (\"::\", None), got %s" % repr(parse_address('[::]'))
    assert parse_address('foo') == ("foo", None), "expected (\"foo\", None), got %s" % repr(parse_address('foo'))
    assert parse_address('[::]:443') == ("::", 443), "expected (\"::\", 443), got %s" % repr(parse_address('[::]:443'))
    assert parse_address('foo:443') == ("foo", 443), "expected (\"foo\", 443), got %s" % repr(parse_address('foo:443'))

# Generated at 2022-06-25 04:11:43.295350
# Unit test for function parse_address
def test_parse_address():
    #
    # This function unit tests function parse_address
    #
    # Steps:
    # - Create test data
    # - Run function under test
    # - Verify function result
    #
    # Tests:
    # - Parse IPv4 address
    # - Parse IPv4 address with port
    # - Parse Hostname with port
    # - Parse IPv6 address
    # - Parse IPv6 address with port
    # - Parse Hostname with port
    # - Parse Hostname with range
    # - Parse Hostname with ranges
    # - Parse Hostname with compound range
    # - Parse Hostname with compound ranges
    # - Parse IPv6 address with range
    #
    res_0 = { 'host': '192.0.2.0', 'port': 42 }

# Generated at 2022-06-25 04:11:50.431985
# Unit test for function parse_address
def test_parse_address():
    bytes_0 = b''
    var_0 = parse_address(bytes_0)
    bytes_1 = b'[127.0.0.1]'
    var_1 = parse_address(bytes_1)
    bytes_2 = b'[127.0.0.1]:2222'
    var_2 = parse_address(bytes_2)
    assert var_0 == (None, None)
    assert var_1 == ('127.0.0.1', None)
    assert var_2 == ('127.0.0.1', 2222)



# Generated at 2022-06-25 04:11:51.425961
# Unit test for function parse_address
def test_parse_address():
    assert True


# Generated at 2022-06-25 04:12:01.964816
# Unit test for function parse_address
def test_parse_address():
    """
    Test function.
    """

# Generated at 2022-06-25 04:12:03.080588
# Unit test for function parse_address
def test_parse_address():
    # No tests
    pass



# Generated at 2022-06-25 04:12:09.786966
# Unit test for function parse_address
def test_parse_address():
    # Need to fix the code, but it's unclear how to do that
    # assert parse_address == 'unittest_0'
    # assert parse_address == 'unittest_1'

    test_case_0()
    test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()


# Local Variables:
# indent-tabs-mode: nil
# tab-width: 4
# python-indent: 4
# End:

# Generated at 2022-06-25 04:12:17.644474
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("test") == ('test', None)
    assert parse_address("test.example.com") == ('test.example.com', None)
    assert parse_address("test.example.com:22") == ('test.example.com', 22)
    assert parse_address("[test.example.com]:22") == ('test.example.com', 22)
    assert parse_address("[2001:db8::1]:22") == ('2001:db8::1', 22)
    assert parse_address("192.0.2.1:22") == ('192.0.2.1', 22)
    assert parse_address("192.0.2.1") == ('192.0.2.1', None)

# Generated at 2022-06-25 04:12:28.822327
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("0") == ('0', None)
    assert parse_address("0:22") == ('0', 22)
    assert parse_address("127.0.0.1") == ('127.0.0.1', None)
    assert parse_address("127.0.0.1:22") == ('127.0.0.1', 22)
    assert parse_address("127.0.0.1[22]") == ('127.0.0.1[22]', None)
    assert parse_address("127.0.0.1[22]:22") == ('127.0.0.1[22]', 22)
    assert parse_address("fe80::3%en0") == ('fe80::3%en0', None)

# Generated at 2022-06-25 04:12:36.450445
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[target]:22') == ('target', 22)
    assert parse_address('target:22') == ('target', 22)
    assert parse_address('target') == ('target', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('2001:db8::1:22') == ('2001:db8::1', 22)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)

# Generated at 2022-06-25 04:12:47.588380
# Unit test for function parse_address
def test_parse_address():
    address = '192.168.0.1'
    var_0 = parse_address(address)
    address = '192.168.0.1:80'
    var_1 = parse_address(address)
    address = '[2001:db8::1]'
    var_2 = parse_address(address)
    address = '[2001:db8::1]:80'
    var_3 = parse_address(address)
    address = 'foo'
    var_4 = parse_address(address)
    address = 'foo.example.com'
    var_5 = parse_address(address)
    address = '[192.168.0.1]'
    var_6 = parse_address(address)
    address = '[192.168.0.1]:80'
    var_7 = parse_address(address)

# Generated at 2022-06-25 04:12:57.900040
# Unit test for function parse_address
def test_parse_address():
    host = 'host'
    port = 22
    address = host + ':' + str(port)
    
    # Normal case
    res = parse_address(address)
    assert res[0] == host and res[1] == port

    # IPV4 with bracket case
    address = '[' + address + ']'
    res = parse_address(address)
    assert res[0] == host and res[1] == port

    # IPV6 case
    address = '2002:4559:1FE2::4559:1FE2'
    res = parse_address(address)
    assert res[0] == address
    assert res[1] == None

    address = '[' + address + ']'
    res = parse_address(address)
    assert res[0] == address
    assert res[1] == None



# Generated at 2022-06-25 04:13:01.117619
# Unit test for function parse_address
def test_parse_address():
    var_1 = parse_address('127.0.0.1')
    if var_1 != ('127.0.0.1', None):
        raise ValueError('parse_address output {0} does not match expectation {1}'.format(var_1, ('127.0.0.1', None)))



# Generated at 2022-06-25 04:13:11.864263
# Unit test for function parse_address
def test_parse_address():
    print("Function test_parse_address started")

    # Example 1:
    # An IPv4 address with port number.
    assert (
        parse_address("192.0.2.3:0")
        == ("192.0.2.3", 0)
    )

    # Example 2:
    # An IPv6 address with port number.
    assert (
        parse_address("[2001:db8::1]:0")
        == ("[2001:db8::1]", 0)
    )

    # Example 3:
    # An IPv4 address range with port number.
    assert (
        parse_address("192.0.2.[2:4]:0")
        == ("192.0.2.[2:4]", 0)
    )

    # Example 4:
    # An IPv4 address range with port number, but

# Generated at 2022-06-25 04:13:15.617380
# Unit test for function parse_address
def test_parse_address():
    with pytest.raises(AnsibleParserError) as excinfo:
        assert parse_address('')
    assert 'Detected range in host but was asked to ignore ranges' in str(excinfo.value)



# Generated at 2022-06-25 04:13:25.449550
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo[0:5]') == ('foo[0:5]', None)
    assert parse_address('foo[0:5]:22') == ('foo[0:5]', 22)
    assert parse_address('[2a00:1450:4001:805::200e]:22') == ('[2a00:1450:4001:805::200e]', 22)
    assert parse_address('[2a00:1450:4001:805::200e]') == ('[2a00:1450:4001:805::200e]', None)

# Generated at 2022-06-25 04:13:32.887523
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(b'foo') == (b'foo', None)
    assert parse_address(b'foo:22') == (b'foo', 22)
    assert parse_address(b'[foo]:22') == (b'foo', 22)
    assert parse_address(b'[foo]') == (b'foo', None)
    assert parse_address(b'foo[1:3]:22') == (b'foo[1:3]', 22)
    assert parse_address(b'foo[1:3]') == (b'foo[1:3]', None)
    assert parse_address(b'192.168.1.1') == (b'192.168.1.1', None)

# Generated at 2022-06-25 04:13:39.800845
# Unit test for function parse_address
def test_parse_address():
    print("Testing function parse_address")

    # Test case 0
    try:
        test_case_0()
    except Exception:
        print("Failed test case 0")
        raise

    # Test case 1
    try:
        var_1 = b'localhost:22'
        var_2 = parse_address(var_1)
        assert ('localhost', 22) == var_2, "var_2 did not equal expected value"
    except Exception:
        print("Failed test case 1")
        raise

    # Test case 2

# Generated at 2022-06-25 04:13:44.036329
# Unit test for function parse_address
def test_parse_address():
    print("idlelib.run.parse_address()")
    test_case_0()


if __name__ == "__main__":
    test_parse_address()

# Generated at 2022-06-25 04:13:45.392091
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)