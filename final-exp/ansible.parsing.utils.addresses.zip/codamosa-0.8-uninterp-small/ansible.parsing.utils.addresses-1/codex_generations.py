

# Generated at 2022-06-25 04:11:26.483988
# Unit test for function parse_address
def test_parse_address():
    # This should pass
    try:
        int_0 = 82
        var_0 = parse_address(int_0)
    except NameError:
        # This should not happen
        assert False
    except Exception:
        assert True
        # This should happen

    # This should fail
    try:
        int_0 = 82
        var_0 = parse_address(int_0)
    except NameError:
        assert False
        # This should not happen
    except Exception:
        assert True
        # This should happen

# Generated at 2022-06-25 04:11:30.596197
# Unit test for function parse_address
def test_parse_address():
    print('>>> test_parse_address <<<')
    print(parse_address('[2001:db8::1]:80'))
    print(parse_address('[2001:db8::1]'))
    print(parse_address('192.168.0.1:80'))
    print(parse_address('www.example.com:80'))
    print(parse_address('www.example.com'))
    print(parse_address('192.168.0.1'))
    print(parse_address('2001:db8::1'))
    print(parse_address('2001:db8::1:80'))


if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:11:39.152201
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('2001:db8::1', allow_ranges=False) == ('2001:db8::1', None)
    assert parse_address('2001:db8::1', allow_ranges=True) == ('2001:db8::1', None)
    assert parse_address('2001:db8::1:23', allow_ranges=False) == ('2001:db8::1', 23)
    assert parse_address('2001:db8::1:23', allow_ranges=True) == ('2001:db8::1', 23)
    assert parse_address('[2001:db8::1]', allow_ranges=False) == ('2001:db8::1', None)
    assert parse_address('[2001:db8::1]', allow_ranges=True) == ('2001:db8::1', None)

# Generated at 2022-06-25 04:11:46.711479
# Unit test for function parse_address
def test_parse_address():
    test_cases = [
        'foo.example.com',
        '10.1.1.1:3306',
        '192.168.0.1',
        '192.168.0.1:443',
        '192.168.0.1:443',
        '192.168.0.1:443[1-5]',
        '192.168.0.1[1-5]:443',
        '192.168.0.1[1-5]:443',
        '192.168.1[1-5].0[2-7]:443'
    ]
    for int_0 in test_cases:
        parse_address(int_0)

# Generated at 2022-06-25 04:11:47.235120
# Unit test for function parse_address
def test_parse_address():
    assert False, "Unimplemented"

# Generated at 2022-06-25 04:11:52.057458
# Unit test for function parse_address
def test_parse_address():
    assert_true(parse_address)



# Generated at 2022-06-25 04:12:02.223925
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.168.1.1', False) == ('192.168.1.1', None)
    assert parse_address('192.168.1.1', True) == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:2222', False) == ('192.168.1.1', 2222)
    assert parse_address('192.168.1.1:2222', True) == ('192.168.1.1', 2222)
    assert parse_address('[192.168.1.1]', False) == ('192.168.1.1', None)
    assert parse_address('[192.168.1.1]', True) == ('192.168.1.1', None)

# Generated at 2022-06-25 04:12:11.137575
# Unit test for function parse_address
def test_parse_address():
    # If a string can't be parsed, then the port value is None, since the
    # whole string was not valid.
    (host, port) = parse_address('foo.bar.baz')
    assert (host is None)
    assert (port is None)

    # If a string is an IPv4 address, then we return IPAddress.
    (host, port) = parse_address('10.11.12.13')
    assert host == '10.11.12.13'
    assert (port is None)

    # If a string is an IPv6 address, then we return IPAddress.
    (host, port) = parse_address('fe80::abcd')
    assert host == 'fe80::abcd'
    assert (port is None)

    # If a string is a hostname, then we return the host value.

# Generated at 2022-06-25 04:12:18.552988
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("[::1]:22") == ("::1", 22)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("123.4.5.6:22") == ("123.4.5.6", 22)
    assert parse_address("host.example.com:100") == ("host.example.com", 100)
    assert parse_address("host.example.com:65535") == ("host.example.com", 65535)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:65535") == ("127.0.0.1", 65535)


# Generated at 2022-06-25 04:12:25.793366
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('0.0.0.1:123') == ('0.0.0.1', 123)
    assert parse_address('1.2.3.0') == ('1.2.3.0', None)
    assert parse_address('1.2.3.0:') == ('1.2.3.0', None)  # Trailing : is not a port
    assert parse_address('foo:123') == ('foo', 123)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:') == ('foo', None)  # Trailing : is not a port
    assert parse_address('bar.baz') == ('bar.baz', None)  # No dots are invalid
    assert parse_address('[::1]:123') == ('::1', 123)

# Generated at 2022-06-25 04:12:29.479306
# Unit test for function parse_address
def test_parse_address():
    
    from ansible.utils.network_common import parse_address
    assert parse_address("192.0.2.3") == ('192.0.2.3', None)


# Generated at 2022-06-25 04:12:39.582064
# Unit test for function parse_address
def test_parse_address():

    # noinspection PyShadowingNames,PyUnusedLocal
    def assert_eq(host, port):
        assert host == ref_host and port == ref_port, "({h}, {p}) != ({rh}, {rp})".format(
            h=host, p=port, rh=ref_host, rp=ref_port
        )

    # Host identifier:           plain       IPv4 addr    IPv6 addr    IPv6-in-IPv4
    #                          -----------  -----------  -----------  -----------
    # Valid w/port:             example.com  127.0.0.1    ::1          ::ffff:127.0.0.1
    # Valid w/bracketed port:   [example.com]
    # Valid w/o port:           127.0.0.1    ::1          ::ffff:

# Generated at 2022-06-25 04:12:50.907379
# Unit test for function parse_address
def test_parse_address():
    # Tests for function 'parse_address'
    assert parse_address("192.0.2.2:22") == ('192.0.2.2', 22), 'test_parse_address #0'
    assert parse_address("192.0.2.2") == ('192.0.2.2', None), 'test_parse_address #1'
    assert parse_address("192.0.2.2:", allow_ranges=True) == ('192.0.2.2:', None), 'test_parse_address #2'
    assert parse_address("[::ffff:192.0.2.2]:22") == ('::ffff:192.0.2.2', 22), 'test_parse_address #3'

# Generated at 2022-06-25 04:12:52.429013
# Unit test for function parse_address
def test_parse_address():
    # match case_0
    int_0 = 82
    var_0 = parse_address(int_0)
    assert var_0 is None


# Generated at 2022-06-25 04:12:54.569091
# Unit test for function parse_address
def test_parse_address():
    var_0 = parse_address('')
    int_0 = 82
    assert var_0[0] == int_0, "parse_address() is not returning the expected value."


# Generated at 2022-06-25 04:12:57.040070
# Unit test for function parse_address
def test_parse_address():

    # FIXME: This test stub will pass, but it doesn't test anything

    str_0 = "foo[1:3] bar[x-z]"
    int_0 = 81
    var_0 = parse_address(str_0, int_0)



# Generated at 2022-06-25 04:13:02.900474
# Unit test for function parse_address
def test_parse_address():
    # Test cases for parse_address
    test_cases = [(0, 82)]
    for test in test_cases:
        int_0 = test[0]
        int_1 = test[1]
        var_0 = parse_address(int_0)
        print("Test case: %d," % int_1, "Expected result: %s," % int_0, "Actual result: %s" % var_0)
        assert var_0 == int_0


if __name__ == '__main__':
    test_case_0()
    test_parse_address()
    print("All tests passed")

# Generated at 2022-06-25 04:13:11.937172
# Unit test for function parse_address
def test_parse_address():
    assert(parse_address('foo.example.com') == ('foo.example.com', None))
    assert(parse_address('foo.example.com:8888') == ('foo.example.com', 8888))
    assert(parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None))
    assert(parse_address('foo[1:3].example.com:8888') == ('foo[1:3].example.com', 8888))
    assert(parse_address('[192.0.2.3]') == ('192.0.2.3', None))
    assert(parse_address('[192.0.2.3]:8888') == ('192.0.2.3', 8888))

# Generated at 2022-06-25 04:13:14.267422
# Unit test for function parse_address
def test_parse_address():
    int_0 = 'test_value'
    var_0 = parse_address(int_0)
    assert var_0 == None

    int_0 = 'test_value'
    var_0 = parse_address(int_0, True)
    assert var_0 == None


# Unit test to check for function parse_address

# Generated at 2022-06-25 04:13:24.155343
# Unit test for function parse_address