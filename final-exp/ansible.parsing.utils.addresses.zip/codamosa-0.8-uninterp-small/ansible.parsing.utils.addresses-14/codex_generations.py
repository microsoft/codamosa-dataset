

# Generated at 2022-06-25 04:11:27.690823
# Unit test for function parse_address
def test_parse_address():
    if False:  # just for some breakpoint
        bool_0 = True
        var_0 = parse_address(bool_0)
    assert True


# Generated at 2022-06-25 04:11:37.822665
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)
    assert parse_address('foo:5') == ('foo', 5)
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:5') == ('foo[1:3]', 5)

# Generated at 2022-06-25 04:11:45.638298
# Unit test for function parse_address
def test_parse_address():

    # Normal, valid host:port pairs
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:42') == ('foo', 42)
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:42') == ('1.2.3.4', 42)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:42') == ('::1', 42)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:42') == ('1.2.3.4', 42)
    assert parse

# Generated at 2022-06-25 04:11:54.647683
# Unit test for function parse_address
def test_parse_address():
    input_0 = '127.0.0.1'
    input_1 = '127.0.0.1:12345'
    input_2 = '127.0.0.1[1:4]:12345'
    input_3 = '::1'
    input_4 = '::1:12345'
    input_5 = '[::1]:12345'
    input_6 = '[127.0.0.1]:12345'
    input_7 = 'localhost[1:3]:12345'
    input_8 = 'localhost:12345'
    input_9 = 'localhost'
    input_10 = 'localhost:foo'
    input_11 = 'localhost[1:2]:foo'
    input_12 = 'localhost:12345[1:4:2]'

# Generated at 2022-06-25 04:12:02.772914
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(b'127.0.0.1') == ('127.0.0.1', None)
    assert parse_address(b'127.0.0.1:2222') == ('127.0.0.1', 2222)
    assert parse_address(b'[2001:db8::1]') == ('2001:db8::1', None)
    assert parse_address(b'[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address(b'foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address(b'foo[1:3].example.com:5555') == ('foo[1:3].example.com', 5555)

# Generated at 2022-06-25 04:12:11.359358
# Unit test for function parse_address
def test_parse_address():

    # Test for correct argument types
    assert_raises(AnsibleError, parse_address, 'foo')
    assert_raises(AnsibleError, parse_address, 'foo', 'bar')

    assert parse_address("foo") == ('foo', None)
    assert parse_address("foo:22") == ('foo', 22)
    assert parse_address("[foo]:22") == ('foo', 22)
    assert parse_address("foo[1:3]") == ('foo[1:3]', None)
    assert parse_address("foo[1:3:2]") == ('foo[1:3:2]', None)
    assert parse_address("foo[1:3:2]:22") == ('foo[1:3:2]', 22)

# Generated at 2022-06-25 04:12:20.658190
# Unit test for function parse_address
def test_parse_address():
    var_0 = '1:2:3:4:5:6:7:8'
    assert parse_address(var_0)
    var_1 = '1:2:3:4:5:6:7'
    assert parse_address(var_1)
    var_2 = '1:2:3:4:5:6:7'
    assert parse_address(var_2)
    var_3 = '1:2:3:4:5:6'
    assert parse_address(var_3)
    var_4 = '1:2:3:4:5:6:7:8'
    assert parse_address(var_4)
    var_5 = '1:2:3:4:5:6:7'
    assert parse_address(var_5)

# Generated at 2022-06-25 04:12:27.267101
# Unit test for function parse_address
def test_parse_address():
    s = "host1:443"
    assert parse_address(s) == ('host1', 443)
    s = "[host1]:443"
    assert parse_address(s) == ('host1', 443)
    s = "[host1]"
    assert parse_address(s) == ('host1', None)
    s = "host2"
    assert parse_address(s) == ('host2', None)
    s = "host3[0:5].example.com:443"
    assert parse_address(s, allow_ranges=True) == ('host3[0:5].example.com', 443)
    s = "host3[0:5].example.com:443"
    assert parse_address(s) == ('host3[0:5].example.com', 443)
    s = "localhost"
   

# Generated at 2022-06-25 04:12:30.941248
# Unit test for function parse_address
def test_parse_address():
    pattern = re.compile("^[0-9]+:[0-9]+:[0-9]+$")
    if pattern.match("1:3:3"):
        print("true")
    else:
        print("false")

# Test function parse_address with a host with a port

# Generated at 2022-06-25 04:12:39.648470
# Unit test for function parse_address