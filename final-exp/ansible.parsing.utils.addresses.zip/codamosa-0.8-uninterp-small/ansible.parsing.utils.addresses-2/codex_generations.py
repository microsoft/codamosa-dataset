

# Generated at 2022-06-25 04:11:37.028211
# Unit test for function parse_address
def test_parse_address():
    print("testing: ", parse_address(''))
    print("testing: ", parse_address('192.168.1.1'))
    print("testing: ", parse_address('192.168.1.1[1:5]'))
    print("testing: ", parse_address('192.168.1.1[1:5]:42'))
    print("testing: ", parse_address('[192.168.1.1:42]'))
    print("testing: ", parse_address('[192.168.1.1:42]', allow_ranges=True))
    print("testing: ", parse_address('foo.example.com'))
    print("testing: ", parse_address('foo-bar.example.com:42'))

# Generated at 2022-06-25 04:11:44.991493
# Unit test for function parse_address
def test_parse_address():
    str_1 = '[L?G~>]'
    str_2 = 'L?G~>'
    str_3 = 'L?G~>:22'
    str_4 = '[L?G~>]:22'
    str_5 = '192.168.1.1'
    str_6 = '192.168.1.1:22'
    str_7 = '[192.168.1.1]'
    str_8 = '[192.168.1.1]:22'
    str_9 = '192.168.1.1[1:2]'

    # Try non-square brackets, no port
    var_1 = parse_address(str_2)
    assert var_1[0] == str_2
    assert var_1[1] == None

    # Try non-square brackets, with port
   

# Generated at 2022-06-25 04:11:50.270018
# Unit test for function parse_address
def test_parse_address():
    str_0 = 'L?G~>'
    var_0 = parse_address(str_0)
    str_1 = '[a:z]'
    var_1 = parse_address(str_1)
    str_2 = '[A:(ffff:)]'
    var_2 = parse_address(str_2)
    str_3 = '_'
    var_3 = parse_address(str_3)
    str_4 = '::'
    var_4 = parse_address(str_4)
    str_5 = ':;'
    var_5 = parse_address(str_5)
    str_6 = '1:2:3:4:5:6:7:8'
    var_6 = parse_address(str_6)

# Generated at 2022-06-25 04:12:00.019693
# Unit test for function parse_address
def test_parse_address():
    str_0 = '[L?G~>]:22'
    var_0 = parse_address(str_0)
    print(var_0)
    # (None, None)

    str_0 = 'gw1.example.com'
    var_0 = parse_address(str_0)
    print(var_0)
    # ('gw1.example.com', None)

    str_0 = 'gw1.example.com:22'
    var_0 = parse_address(str_0)
    print(var_0)
    # ('gw1.example.com', 22)

    str_0 = '192.168.1.2:22'
    var_0 = parse_address(str_0)
    print(var_0)
    # ('192.168.1.2',

# Generated at 2022-06-25 04:12:00.751264
# Unit test for function parse_address
def test_parse_address():
    test_case_0()

# Generated at 2022-06-25 04:12:01.172187
# Unit test for function parse_address
def test_parse_address():
    assert True


# Generated at 2022-06-25 04:12:01.886341
# Unit test for function parse_address
def test_parse_address():
    assert 1



# Generated at 2022-06-25 04:12:07.037360
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(str) == (var, None)
    assert parse_address(str) == (var, int)
    assert parse_address(str) == (None, None)
    assert parse_address(str) == (var, int)
    assert parse_address(str) == (var, int)

# Generated at 2022-06-25 04:12:15.394202
# Unit test for function parse_address
def test_parse_address():
    print("TESTING PARSE_ADDRESS")

    try:
        str_0 = 'L?G~>'
        var_0 = parse_address(str_0)
        print("parse_address('L?G~>') RETURNED ", var_0)
        print("parse_address('L?G~>') FAILED")
    except AnsibleError:
        print("parse_address('L?G~>') FAILED")


# Generated at 2022-06-25 04:12:22.463523
# Unit test for function parse_address
def test_parse_address():
    str1 = '192.168.1.10'
    str2 = '192.168.1.10:22'
    host1, port1 = parse_address(str1)
    h, p = parse_address(str2)
#    print(host1, port1, h, p)

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:12:28.622501
# Unit test for function parse_address

# Generated at 2022-06-25 04:12:36.290275
# Unit test for function parse_address
def test_parse_address():
    str_0 = '10.0.2.15:33'
    var_0 = parse_address(str_0)
    assert var_0 == ('10.0.2.15', 33)
    str_1 = '10.0.2.15'
    var_1 = parse_address(str_1)
    assert var_1 == ('10.0.2.15', None)
    str_2 = '::1:22'
    var_2 = parse_address(str_2)
    assert var_2 == ('::1', 22)
    str_3 = '::1'
    var_3 = parse_address(str_3)
    assert var_3 == ('::1', None)
    str_4 = 'localhost'
    var_4 = parse_address(str_4)
    assert var_

# Generated at 2022-06-25 04:12:46.542618
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]:22', True) == ("::1", 22) , "Invalid result for 'parse_address': %s" % parse_address('[::1]:22', True)
    assert parse_address('foobar', True) == ("foobar", None) , "Invalid result for 'parse_address': %s" % parse_address('foobar', True)
    assert parse_address('example.com:22', True) == ("example.com", 22) , "Invalid result for 'parse_address': %s" % parse_address('example.com:22', True)
    assert parse_address('[::1]', True) == ("::1", None) , "Invalid result for 'parse_address': %s" % parse_address('[::1]', True)
    assert parse_address('localhost:22', True)

# Generated at 2022-06-25 04:12:53.795629
# Unit test for function parse_address
def test_parse_address():
    # When there is an exception, it can be caused by instances of the
    # exception being raised outside the function being tested
    try:
        test_case_0()
    except AnsibleError as exc:
        # If the exception is raised outside the function,
        # test should pass, but the exception is still printed
        print(exc)


if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-25 04:12:59.648777
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ("::1", None)
    assert parse_address('[::1]:22') == ("::1", 22)
    assert parse_address('127.0.0.1') == ("127.0.0.1", None)
    assert parse_address('127.0.0.1:22') == ("127.0.0.1", 22)
    assert parse_address('127.0.0[1:2]') == ("127.0.0[1:2]", None)
    assert parse_address('127.0[0:2].3') == ("127.0[0:2].3", None)
    assert parse_address('127.0[0:2].3:22') == ("127.0[0:2].3", 22)
    assert parse_address

# Generated at 2022-06-25 04:13:08.600633
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None)
    assert parse_address('', False) == (None, None)
    assert parse_address('', True) == (None, None)

    assert parse_address('1', False) == (None, None)
    assert parse_address('1', True) == (None, None)

    assert parse_address('foo[x:y]', False) == (None, None)
    assert parse_address('foo[x:y]', True) == ('foo[x:y]', None)

    assert parse_address('foo1:2:3:4:5:6:7:8', False) == (None, None)

# Generated at 2022-06-25 04:13:10.069814
# Unit test for function parse_address
def test_parse_address():
    assert True


# Generated at 2022-06-25 04:13:12.582956
# Unit test for function parse_address
def test_parse_address():
    # Test case 0
    str_0 = 'L?G~>'
    var_0 = parse_address(str_0)
    assert var_0 == ('L?G~>', None)


# Generated at 2022-06-25 04:13:15.470434
# Unit test for function parse_address
def test_parse_address():
    with pytest.raises(AnsibleError):
        parse_address(str_0)

    with pytest.raises(AnsibleParserError):
        parse_address(str_1)



# Generated at 2022-06-25 04:13:25.420849
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[2001:db8:85a3::8a2e:370:7334]") == ('2001:db8:85a3::8a2e:370:7334', None)
    assert parse_address("foo.example.com") == ('foo.example.com', None)
    assert parse_address("example.com:80") == ('example.com', 80)
    assert parse_address("[example.com]:80") == ('example.com', 80)
    assert parse_address("192.168.1.1") == ('192.168.1.1', None)
    assert parse_address("192.168.1.1:80") == ('192.168.1.1', 80)