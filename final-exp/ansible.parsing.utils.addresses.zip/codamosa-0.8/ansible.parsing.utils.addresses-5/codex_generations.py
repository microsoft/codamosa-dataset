

# Generated at 2022-06-11 08:54:15.156340
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:23') == ('localhost', 23)
    assert parse_address('localhost:1234') == ('localhost', 1234)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]', allow_ranges=True) == ('::1', None)
    assert parse_address('[::1]:23') == ('::1', 23)
    assert parse_address('[::1]:23', allow_ranges=True) == ('::1', 23)


# Generated at 2022-06-11 08:54:25.318409
# Unit test for function parse_address
def test_parse_address():
    """
    Test cases for function parse_address()
    """
    assert(parse_address("foo.example.com:22") == ("foo.example.com", 22))
    assert(parse_address("foo.example.com") == ("foo.example.com", None))
    assert(parse_address("foo[1:3].example.com:22") == ("foo[1:3].example.com", 22))
    assert(parse_address("foo[1:3].example.com") == ("foo[1:3].example.com", None))
    assert(parse_address("192.0.2.1:22") == ("192.0.2.1", 22))
    assert(parse_address("192.0.2.1") == ("192.0.2.1", None))

# Generated at 2022-06-11 08:54:34.566585
# Unit test for function parse_address
def test_parse_address():
    def test(s, allow_ranges=False, h=None, p=None):
        r = parse_address(s, allow_ranges=allow_ranges)
        assert h == r[0], "expected {} but got {} for string '{}'".format(h, r[0], s)
        assert p == r[1], "expected {} but got {} for string '{}'".format(p, r[1], s)

    test("foo:13", h="foo", p=13)
    test("foo", h="foo", p=None)
    test("foo[1:3]:13", h="foo[1:3]", p=13)
    test("foo[1:3]", h="foo[1:3]", p=None)

# Generated at 2022-06-11 08:54:45.975913
# Unit test for function parse_address
def test_parse_address():
    h1 = 'foo.example.com:1234'
    h2 = 'foo.example.com'
    h3 = 'localhost'
    h4 = '192.0.2.3:1234'
    h5 = '192.0.2.3'
    h6 = '2001:db8::1:1234'
    h7 = '2001:db8::1'
    h8 = '::ffff:192.0.2.3'
    h9 = '::ffff:192.0.2.3:1234'
    h10 = '[::ffff:192.0.2.3]:1234'
    h11 = '[::ffff:192.0.2.3]'

    # Check the port number parsing.
    assert parse_address(h8) == (h8, None)
    assert parse_

# Generated at 2022-06-11 08:54:52.827176
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('example.com:8080') == ('example.com', 8080)
    assert parse_address('example.com:65535') == ('example.com', 65535)
    assert parse_address('example.com:65536') == ('example.com', None)
    assert parse_address('example.com:80', allow_ranges=True) == ('example.com', 80)
    assert parse_address('example.com[1:3]') == ('example.com[1:3]', None)
    assert parse_address('example.com[1:3]:80') == ('example.com[1:3]', 80)
    assert parse_

# Generated at 2022-06-11 08:55:05.536065
# Unit test for function parse_address
def test_parse_address():
    res = parse_address("example.com")
    assert res == ("example.com", None)

    res = parse_address("example.com:22")
    assert res == ("example.com", 22)

    res = parse_address("example.com:2")
    assert res == ("example.com", 2)

    res = parse_address("example.com[1]")
    assert res == ("example.com[1]", None)

    res = parse_address("example.com[1]:22")
    assert res == ("example.com[1]", 22)

    res = parse_address("192.168.1.1")
    assert res == ("192.168.1.1", None)

    res = parse_address("192.168.1.1:22")

# Generated at 2022-06-11 08:55:14.812913
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[foo_bar]:123") == ("foo_bar", 123)
    assert parse_address("[fe80::1%lo0]:123") == ("fe80::1%lo0", 123)
    assert parse_address("fe80::1%lo0:123") == ("fe80::1%lo0", 123)
    assert parse_address("[10.0.0.1]:123") == ("10.0.0.1", 123)
    assert parse_address("foo.com:123") == ("foo.com", 123)
    assert parse_address("foo.com") == ("foo.com", None)
    assert parse_address("10.0.0.1") == ("10.0.0.1", None)

# Generated at 2022-06-11 08:55:26.426598
# Unit test for function parse_address
def test_parse_address():
    """Test parsing of IPv4, IPv6, hostname and bracketed IPv4 addresses
    with and without port specification. Test function parse_address.
    Specifying port is mandatory for IPv6 addresses."""

# Generated at 2022-06-11 08:55:38.485542
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('a') == ('a', None)
    assert parse_address('a:10') == ('a', 10)
    assert parse_address('a.b') == ('a.b', None)
    assert parse_address('a.b.c') == ('a.b.c', None)
    assert parse_address('a.b.c:10') == ('a.b.c', 10)
    assert parse_address('a.b.c.d:10') == ('a.b.c.d', 10)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)
    assert parse_address('[1.2.3.4]:10') == ('1.2.3.4', 10)

# Generated at 2022-06-11 08:55:44.970276
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[192.0.2.1]') == ('192.0.2.1', None)
    assert parse_address('[192.0.2.1]:53') == ('192.0.2.1', 53)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:53') == ('192.0.2.1', 53)
    assert parse_address('bar[1:4].example.com') == ('bar[1:4].example.com', None)
    assert parse_address('bar[1:4].example.com:53') == ('bar[1:4].example.com', 53)