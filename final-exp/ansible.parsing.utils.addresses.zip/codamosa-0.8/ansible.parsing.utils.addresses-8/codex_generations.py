

# Generated at 2022-06-11 08:54:09.116540
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:19.935783
# Unit test for function parse_address
def test_parse_address():
    all_valid = ['example.com', 'example.com:1234', '[192.0.2.1]', '[2001:db8::1]', '[2001:db8::1]:1234',
                 '[::ffff:192.0.2.1]', '[::ffff:192.0.2.1]:1234', '[example.com]', '[example.com]:1234',
                 '[example.com[1:3]]:1234']

    invalid = ['example', '[192.0.2.1[]]', '[2001:db8::1[]]', '[2001:db8::1:1]:1234', '[example.com][]', 'example.com[1:3]']


# Generated at 2022-06-11 08:54:28.530052
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:38.451511
# Unit test for function parse_address
def test_parse_address():
    _parse_address_test(None, None)
    _parse_address_test('foo', 'foo')
    _parse_address_test('foo.example.com', 'foo.example.com')
    _parse_address_test('192.0.2.5', '192.0.2.5')
    _parse_address_test('192.0.2.5:1234', '192.0.2.5', 1234)
    _parse_address_test('[2001:db8::2]:9876', '2001:db8::2', 9876)
    _parse_address_test('[2001:db8::2]', '2001:db8::2', None)
    _parse_address_test('192.0.2.0[1:3]:9876', None, None)
    _parse_address

# Generated at 2022-06-11 08:54:49.468330
# Unit test for function parse_address
def test_parse_address():

    # From Ansible documentation
    assert parse_address('server1') == ('server1', None)
    assert parse_address('server1:2222') == ('server1', 2222)
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:2222') == ('192.168.1.1', 2222)
    assert parse_address('192.168.1.1[10:20]') == ('192.168.1.1[10:20]', None)
    assert parse_address('192.168.1.1[10:20]:2222') == ('192.168.1.1[10:20]', 2222)

# Generated at 2022-06-11 08:55:01.574052
# Unit test for function parse_address
def test_parse_address():
    # IP addresses
    assert parse_address("1.2.3.4") == ("1.2.3.4", None)
    assert parse_address("1.2.3.4:5678") == ("1.2.3.4", 5678)

    assert parse_address("[1.2.3.4]") == ("1.2.3.4", None)
    assert parse_address("[1.2.3.4]:5678") == ("1.2.3.4", 5678)

    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:5678") == ("::1", 5678)

    # IP address ranges

    # This looks like an IPv4 address but will actually be parsed as an
    # alphanumeric hostname pattern


# Generated at 2022-06-11 08:55:12.428700
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:24.153832
# Unit test for function parse_address
def test_parse_address():
    import sys
    if sys.version_info < (2, 7):
        print("Skipping test_parse_address due to incompatibility with Python 2.6")
        return

    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("[example.com]") == ("example.com", None)
    assert parse_address("example.com:42") == ("example.com", 42)
    assert parse_address("[example.com]:42") == ("example.com", 42)

    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("[192.0.2.1]") == ("192.0.2.1", None)

# Generated at 2022-06-11 08:55:36.339166
# Unit test for function parse_address
def test_parse_address():
    import sys

    # Test cases based on examples from RFC 2732, sections 2, 4, and 5.


# Generated at 2022-06-11 08:55:44.151085
# Unit test for function parse_address