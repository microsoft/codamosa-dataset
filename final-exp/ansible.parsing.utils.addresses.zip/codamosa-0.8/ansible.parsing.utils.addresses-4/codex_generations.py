

# Generated at 2022-06-11 08:54:14.058362
# Unit test for function parse_address
def test_parse_address():

    def p(s, expect=None, allow_ranges=False):
        host, port = parse_address(s, allow_ranges)
        print("%s -> %s:%s" % (s, host, port))
        if expect:
            assert (host, port) == expect

    p("myhost:1234", ('myhost', 1234))
    p("myhost", ('myhost', None))
    p("myhost.mydomain:1234", ('myhost.mydomain', 1234))
    p('[foo]:22', ('foo', 22))
    p('[foo]', None)
    p('[::1]:22', ("::1", 22))
    p('[::1]:22', ("::1", 22))
    p('[::1]', None)

# Generated at 2022-06-11 08:54:24.562409
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:9999') == ('192.0.2.1', 9999)
    assert parse_address('[192.0.2.1]:9999') == ('192.0.2.1', 9999)
    assert parse_address('192.0.2.1[1:3]') == ('192.0.2.1[1:3]', None)
    assert parse_address('192.0.2.1[1:3]:9999') == ('192.0.2.1[1:3]', 9999)

# Generated at 2022-06-11 08:54:33.828689
# Unit test for function parse_address
def test_parse_address():
    #
    # Invalid addresses
    #

    # No port number
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("localhost") == ("localhost", None)

    # Bad port number
    for bad in ["foo", "[::1]:bar", "[1:2:3:4:5:6:7:8]:bar"]:
        try:
            parse_address(bad)
            assert False
        except (AnsibleError, AnsibleParserError):
            assert True

    # Bad bracketing

# Generated at 2022-06-11 08:54:45.120485
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:52.500348
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:05.104254
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:11.986780
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:23.503889
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:35.756147
# Unit test for function parse_address
def test_parse_address():
    '''Test parse_address'''
    failed = True
    msg = ''

# Generated at 2022-06-11 08:55:43.836624
# Unit test for function parse_address
def test_parse_address():
    def test(host, port, message):
        (got_host, got_port) = parse_address(host)
        failed = False
        if got_host != host:
            failed = True
            print("want host %s got host %s" % (host, got_host))
        if got_port != port:
            failed = True
            print("want port %s got port %s" % (port, got_port))
        if failed:
            print("FAILED TEST: %s" % message)
            raise Exception(message)

    test('a1.example.com', None, 'plain hostname')
    test('a1.example.com:22', 22, 'plain hostname with port')
    test('[a1.example.com]', None, 'square brackets around hostname')