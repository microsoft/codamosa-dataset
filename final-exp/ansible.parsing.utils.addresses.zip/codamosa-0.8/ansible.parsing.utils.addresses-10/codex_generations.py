

# Generated at 2022-06-11 08:54:12.515794
# Unit test for function parse_address
def test_parse_address():
    def test(address, expect):
        result = parse_address(address)
        if result != expect:
            raise Exception("Input '%s' expected %s, got %s" % (address, expect, result))

    test("localhost",                  ("localhost", None))
    test("localhost:22",               ("localhost", 22))
    test("192.0.2.1",                  ("192.0.2.1", None))
    test("192.0.2.1:22",               ("192.0.2.1", 22))
    test("[::1]",                      ("::1", None))
    test("[::1]:22",                   ("::1", 22))
    test("[2001:db8:2:1::1]",          ("2001:db8:2:1::1", None))

# Generated at 2022-06-11 08:54:23.385553
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:32.571320
# Unit test for function parse_address
def test_parse_address():
    test_host = '10.2.3.[1:3]/16'
    (host, port) = parse_address(test_host)
    assert host == '10.2.3.[1:3]', '%s result: %s' % (test_host, host)

    test_host = '10.2.3.[1:3]'
    (host, port) = parse_address(test_host)
    assert host == '10.2.3.[1:3]', '%s result: %s' % (test_host, host)

    test_host = '10.2.3.1'
    (host, port) = parse_address(test_host)
    assert host == '10.2.3.1', '%s result: %s' % (test_host, host)

    test_

# Generated at 2022-06-11 08:54:43.670672
# Unit test for function parse_address
def test_parse_address():
    """
    IPv4/host:port
    IPv6/[IPv6]:port
    IPv4/IPv6:port
    """

    # valid IPv4
    assert parse_address("192.168.1.1:65530") == ('192.168.1.1', 65530)
    assert parse_address("192.168.1.1") == ('192.168.1.1', None)

    # valid IPv6
    assert parse_address("[::1]:65530") == ('::1', 65530)
    assert parse_address("[::1]") == ('::1', None)

    # invalid IPv4 with port
    assert parse_address("192.168.1:65530") == (None, None)
    assert parse_address("192.168.1.") == (None, None)
    assert parse_

# Generated at 2022-06-11 08:54:51.848246
# Unit test for function parse_address
def test_parse_address():
    failures = 0
    def check(allow_ranges, address, host, port):
        global failures
        try:
            actual = parse_address(address, allow_ranges)
            actual_host, actual_port = actual

            if actual_host != host:
                print("Host mismatch: expected %s, got %s" % (host, actual_host))
                failures += 1
            if actual_port != port:
                print("Port mismatch: expected %s, got %s" % (port, actual_port))
                failures += 1
        except Exception as e:
            print("Unexpected exception: %s expected %s" % (e, (host, port)))
            failures += 1

    # These should all parse with no errors.
    check(False, "[8::2]:80", "8::2", 80)

# Generated at 2022-06-11 08:55:04.485268
# Unit test for function parse_address
def test_parse_address():
    base_address = '172.20.30.40'
    port_address = '172.20.30.40:81'
    bracketed_port_address = '[172.20.30.40]:81'
    bracketed_address = '[172.20.30.40]'
    bracketed_dns_address = '[172.20.30.40.example.com]'
    bracketed_dns_port_address = '[172.20.30.40.example.com]:81'

    fqdn_address = 'server.example.com'
    fqdn_port_address = 'server.example.com:81'
    bracketed_fqdn_address = '[server.example.com]'
    bracketed_fqdn_port_address = '[server.example.com]:81'


# Generated at 2022-06-11 08:55:14.179334
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:25.821325
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('[localhost]') == ('localhost', None)
    assert parse_address('[localhost]:22') == ('localhost', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)
    assert parse_address('[192.0.2.3]:22') == ('192.0.2.3', 22)

# Generated at 2022-06-11 08:55:38.087941
# Unit test for function parse_address
def test_parse_address():
    """
    This is not a true unit test, because we don't want to enforce the 63-char
    length limit on hostnames. This tests each of the valid cases and a few
    invalid ones.

    `invalid' means not a valid host/port specification, while `unparsed' means
    that although the host was parsed, the port wasn't.
    """


# Generated at 2022-06-11 08:55:47.010472
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == ("::1", None)
    assert parse_address('[::1]:65536') == ("::1", 65536)
    assert parse_address('[::1]', allow_ranges=True) == ("::1", None)
    assert parse_address('[::1]:65536', allow_ranges=True) == ("::1", 65536)

    assert parse_address('[::1][::2]:65536') == ("::1[::2]", 65536)
    assert parse_address('[::1][::2]:65536', allow_ranges=True) == ("::1[::2]", 65536)

    assert parse_address('[::1:2:3:4:5:6:7:8]', allow_ranges=True)

# Generated at 2022-06-11 08:55:58.957760
# Unit test for function parse_address
def test_parse_address():
    assert('a' == 'a')
    # Check that we parse the following formats as expected
    assert(parse_address('foo.example.com') == ('foo.example.com', None))
    assert(parse_address('foo.example.com:42') == ('foo.example.com', 42))
    assert(parse_address('[1.2.3.4]:42') == ('1.2.3.4', 42))
    assert(parse_address('1.2.3.4:42') == ('1.2.3.4', 42))
    assert(parse_address('[::ffff:0:1]:42') == ('::ffff:0:1', 42))
    assert(parse_address('::ffff:0:1:42') == ('::ffff:0:1', 42))

# Generated at 2022-06-11 08:56:09.429269
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:19.797454
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:30.887407
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:42.179888
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:51.161129
# Unit test for function parse_address

# Generated at 2022-06-11 08:57:00.101170
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('192.0.2.0') == ('192.0.2.0', None)
    assert parse_address('192.0.2.0:22') == ('192.0.2.0', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('[fd00::1]') == ('fd00::1', None)
    assert parse_address('[fd00::1]:22') == ('fd00::1', 22)
    assert parse_address('[192.0.2.0]') == ('192.0.2.0', None)

# Generated at 2022-06-11 08:57:09.818193
# Unit test for function parse_address
def test_parse_address():
    address = 'localhost'
    assert parse_address(address) == ('localhost', None)

    address = 'localhost:22'
    assert parse_address(address) == ('localhost', 22)

    address = 'localhost:22:22'
    try:
        parse_address(address)
    except AnsibleError:
        pass
    else:
        assert False

    address = '[localhost]:22'
    assert parse_address(address) == ('localhost', 22)

    address = 'localhost[0::10]'
    try:
        parse_address(address)
    except AnsibleParserError:
        pass
    else:
        # ranges are not allowed in hostnames
        assert False

    address = 'localhost[0::10]'

# Generated at 2022-06-11 08:57:11.960562
# Unit test for function parse_address
def test_parse_address():
    import doctest
    doctest.testmod(verbose=False)

if __name__ == '__main__':
    test_parse_address()

# Generated at 2022-06-11 08:57:21.639369
# Unit test for function parse_address
def test_parse_address():

    # IPv4 addresses, with and without port number
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:42') == ('192.0.2.3', 42)
    assert parse_address('192.0.2.3:0') == ('192.0.2.3', 0)
    # IPv4 address ranges
    assert parse_address('1.2.3.4[8:12]') == ('1.2.3.4[8:12]', None)
    assert parse_address('1.2.3.4[8:12]:42') == ('1.2.3.4[8:12]', 42)
    assert parse_address('1.2.3.4[0:7]:42')