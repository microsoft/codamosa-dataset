

# Generated at 2022-06-11 08:54:09.199995
# Unit test for function parse_address
def test_parse_address():

    import pytest

    def check(host, port, expected_host, expected_port):
        (actual_host, actual_port) = parse_address(host, allow_ranges=True)
        assert actual_host == expected_host
        assert actual_port == expected_port

    # (input, expected host, expected port)
    check('foo.example.com', None, 'foo.example.com', None)
    check('foo.example.com:1234', None, 'foo.example.com', 1234)
    check('foo.example.com:1234', 4321, 'foo.example.com', 1234)
    check('foo[bar]', None, 'foo[bar]', None)
    check('foo[bar]:1234', None, 'foo[bar]', 1234)

# Generated at 2022-06-11 08:54:20.034841
# Unit test for function parse_address
def test_parse_address():
    # hostname & port parsing
    assert parse_address('hostname1:1234') == ('hostname1', 1234)
    assert parse_address('hostname:1234') == ('hostname', 1234)
    assert parse_address('hostname') == ('hostname', None)
    assert parse_address('hostname.subdomain.domain.com') == ('hostname.subdomain.domain.com', None)
    assert parse_address('hostname.subdomain.domain.com:1234') == ('hostname.subdomain.domain.com', 1234)

    # IPv4 & port parsing
    assert parse_address('10.10.10.1') == ('10.10.10.1', None)

# Generated at 2022-06-11 08:54:27.307159
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("foo.example.com:123") == ("foo.example.com", 123)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:123") == ("::1", 123)
    assert parse_address("[2001:db8::ff00:42:8329]:123") == ("2001:db8::ff00:42:8329", 123)
    assert parse_address("127.0.0.1") == ("127.0.0.1", None)
    assert parse_address("127.0.0.1:123") == ("127.0.0.1", 123)
    assert parse_address("192.0.2.3")

# Generated at 2022-06-11 08:54:37.081952
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:48.515077
# Unit test for function parse_address
def test_parse_address():

    def test(address, expected_host, expected_port, allow_ranges=False):
        actual_host, actual_port = parse_address(address, allow_ranges=allow_ranges)
        assert actual_host == expected_host, "host in (%s) expected %s but got %s" % (address, expected_host, actual_host)
        assert actual_port == expected_port, "port in (%s) expected %s but got %s" % (address, expected_port, actual_port)

    # Examples from Ansible docs.

    test("foo.example.com", "foo.example.com", None)
    test("foo.example.com:22", "foo.example.com", 22)
    test("192.168.1.23:22", "192.168.1.23", 22)

# Generated at 2022-06-11 08:55:00.773322
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:11.867076
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:23.252907
# Unit test for function parse_address
def test_parse_address():
    import unittest
    class Test(unittest.TestCase):
        """
        Tests for function AnsibleModule.parse_address()
        """

        def test_simple(self):
            """parse_address() should succeed with simple IPv4 or IPv6.
            """
            parse_address('[::1]')
            parse_address('127.0.0.1')

        def test_port(self):
            """parse_address() should succeed with ports.
            """
            self.assertEqual(('127.0.0.1', 42), parse_address('127.0.0.1:42'))
            self.assertEqual(('::1', 42), parse_address('[::1]:42'))

# Generated at 2022-06-11 08:55:35.450046
# Unit test for function parse_address
def test_parse_address():
    import pytest
    assert parse_address('foo.example.com:22')  == ('foo.example.com', 22)
    assert parse_address('foo.example.com')  == ('foo.example.com', None)
    assert parse_address('foo[a-z]')  == ('foo[a-z]', None)
    assert parse_address('foo[1:3]')  == ('foo[1:3]', None)
    assert parse_address('foo[0:5]-bar[a-c]')  == ('foo[0:5]-bar[a-c]', None)
    assert parse_address('[foo.example.com]:22')  == ('foo.example.com', 22)

# Generated at 2022-06-11 08:55:43.693376
# Unit test for function parse_address
def test_parse_address():
    # Tests for function parse_address

    # Valid inputs that do not specify a port
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1/29') == ('127.0.0.1/29', None)
    assert parse_address('127.0.0.1/255.255.255.248') == ('127.0.0.1/255.255.255.248', None)
    assert parse_address('::1') == ('::1', None)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('example.com') == ('example.com', None)