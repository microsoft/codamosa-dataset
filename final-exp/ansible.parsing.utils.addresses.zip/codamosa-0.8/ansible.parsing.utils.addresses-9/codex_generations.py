

# Generated at 2022-06-11 08:54:08.000547
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo.example.com") == ("foo.example.com", None)
    assert parse_address("192.0.2.3") == ("192.0.2.3", None)
    assert parse_address("192.0.2.3:80") == ("192.0.2.3", 80)
    assert parse_addres

# Generated at 2022-06-11 08:54:18.348460
# Unit test for function parse_address
def test_parse_address():
    # Test some aliases from the deprecated DEFAULT_REMOTE_PORT and
    # DEFAULT_REMOTE_PORT_ANY
    for port in ('22', '2222', '222222', '22222222'):
        assert parse_address(port)[0] == port

    # Test a few typical 'host' and 'host:port' combinations
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[foo:12:baz]') == ('[foo:12:baz]', None)
    assert parse_address('[foo:12:baz]:22') == ('[foo:12:baz]', 22)

# Generated at 2022-06-11 08:54:26.668349
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22', allow_ranges=True) == ('localhost', 22)
    assert parse_address('localhost', allow_ranges=True) == ('localhost', None)

    assert parse_address('192.168.1.1:2345') == ('192.168.1.1', 2345)
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)
    assert parse_address('192.168.1.1:2345', allow_ranges=True) == ('192.168.1.1', 2345)

# Generated at 2022-06-11 08:54:36.357829
# Unit test for function parse_address
def test_parse_address():
    from collections import namedtuple
    HostPort = namedtuple('HostPort', ['host', 'port'])

    def test_match(address, expected_host, expected_port):
        result = parse_address(address)
        if not (result == (expected_host, expected_port)
                or (result == (expected_host, None) and expected_port is None)):
            print("%(address)r: "
                  "Expected %(eh)r %(ep)r"
                  " but got %(rh)r %(rp)r" %
                  {'address': address, 'eh': expected_host, 'ep': expected_port,
                   'rh': result[0], 'rp': result[1]})

    test_match('example.com:22', 'example.com', 22)
    test_match

# Generated at 2022-06-11 08:54:47.722271
# Unit test for function parse_address
def test_parse_address():
    address = '1.2.3.4'
    (host, port) = parse_address(address, allow_ranges=False)
    assert (host, port) == ('1.2.3.4', None)

    address = '::ffff:192.0.2.3'
    (host, port) = parse_address(address, allow_ranges=False)
    assert (host, port) == ('::ffff:192.0.2.3', None)

    address = 'foo.example.com'
    (host, port) = parse_address(address, allow_ranges=False)
    assert (host, port) == ('foo.example.com', None)

    # with explicit port and host with range
    address = '1.2.3.4:5'
    (host, port) = parse_address

# Generated at 2022-06-11 08:54:53.490604
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:06.139891
# Unit test for function parse_address
def test_parse_address():
    #
    # Tests with port specifications
    #

    # Square brackets are mandatory for IPv6 addresses.

    assert('1:2:3:4:5:6:7:8', None) == parse_address('[1:2:3:4:5:6:7:8]')
    assert('1:2:3:4:5:6:7:8', 123) == parse_address('[1:2:3:4:5:6:7:8]:123')
    assert('1:2:3:4:5:6:7:8', 123) == parse_address('[1:2:3:4:5:6:7:8]:123')

    # ...same as above, using an IPv4 address specifier instead.


# Generated at 2022-06-11 08:55:15.185115
# Unit test for function parse_address
def test_parse_address():
    def assertParseAddress(expected, address, allow_ranges=False):
        (host, port) = parse_address(address, allow_ranges)
        assert (host, port) == expected, 'unexpected parse_address result for %s' % address

    assertParseAddress(('example.com', 53), 'example.com:53')
    assertParseAddress(('example.com', 53), 'example.com[1:2]:53')
    assertParseAddress(('example.com', 53), '[example.com]:53')
    assertParseAddress(('example.com', 53), '[example.com[1:2]]:53')

    assertParseAddress(('192.0.2.1', 53), '192.0.2.1:53')

# Generated at 2022-06-11 08:55:26.791529
# Unit test for function parse_address
def test_parse_address():
    addr = "192.1.1.1:22"
    host, port = parse_address(addr)
    assert(host == "192.1.1.1")
    assert(port == 22)
    addr = "[192.1.1.1]:22"
    host, port = parse_address(addr)
    assert(host == "192.1.1.1")
    assert(port == 22)
    addr = "somename.somedomain.com:22"
    host, port = parse_address(addr)
    assert(host == "somename.somedomain.com")
    assert(port == 22)
    addr = "[somename.somedomain.com]:22"
    host, port = parse_address(addr)

# Generated at 2022-06-11 08:55:38.787527
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:50.354442
# Unit test for function parse_address
def test_parse_address():

    def parse_fails(s):
        try:
            parse_address(s)
            return True
        except:
            return False

    def parse_succeeds(s):
        return parse_address(s)

    assert parse_fails('[21:34') == True
    assert parse_fails('21:34') == True
    assert parse_fails('[21:34]') == True
    assert parse_fails('[21:34]x') == True
    assert parse_fails('[21:34]10') == True
    assert parse_fails('[21:34.10]10') == True
    assert parse_fails('[21:34:10]10') == True
    assert parse_fails('[21:34]10') == True

# Generated at 2022-06-11 08:56:00.356719
# Unit test for function parse_address
def test_parse_address():
    def assertAddress(expr, host=None, port=None):
        (h, p) = parse_address(expr)
        assert h == host, 'expected %s, got %s' % (host, h)
        assert p == port, 'expected %s, got %s' % (port, p)

    assertAddress('::1', '::1')

    assertAddress('::1', '::1')
    assertAddress('[::1]', '::1')

    assertAddress('[::1]:123', '::1', 123)
    assertAddress('[::1]:123', '::1', 123)
    assertAddress('[::1]:45', '::1', 45)
    assertAddress('[::1]:0', '::1', 0)
    assertAddress('[::1]:1', '::1', 1)


# Generated at 2022-06-11 08:56:10.464252
# Unit test for function parse_address
def test_parse_address():
    import unittest
    import sys

    class TestNetworkHostname(unittest.TestCase):
        def test_basic_hostnames(self):
            self.assertEqual(parse_address('hostname'), ('hostname', None))
            self.assertEqual(parse_address('hostname.example.com'), ('hostname.example.com', None))
            self.assertEqual(parse_address('hostname.with.lots.of.labels.example.com'), ('hostname.with.lots.of.labels.example.com', None))
            self.assertEqual(parse_address('foo.example.com:1234'), ('foo.example.com', 1234))
            self.assertEqual(parse_address('foo.example.com:[x:y]'), ('foo.example.com', None))


# Generated at 2022-06-11 08:56:21.317078
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('10.0.0.1') == ('10.0.0.1', None)
    assert parse_address('10.0.0.1:22') == ('10.0.0.1', 22)
    assert parse_address('0:0:0:0:0:0:0:1') == ('0:0:0:0:0:0:0:1', None)

# Generated at 2022-06-11 08:56:31.943884
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:42.950320
# Unit test for function parse_address
def test_parse_address():
    # any of these should give us back ('foo',12)
    for input_value in ["foo:12", "foo:12:", "foo:12:", "foo:[12]:"]:
        assert parse_address(input_value) == ('foo', 12)

    # any of these should give us back ('foo',None)
    for input_value in ["foo", "foo:", "foo:"]:
        assert parse_address(input_value) == ('foo', None)

    # any of these should give us back ('foo',1)
    for input_value in ["[foo]:1", "[foo]:1:", "[foo]:1:"]:
        assert parse_address(input_value) == ('foo', 1)

    # any of these should give us back ('foo',None)

# Generated at 2022-06-11 08:56:52.345539
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("localhost:123") == ("localhost", 123)
    assert parse_address("example.com:123") == ("example.com", 123)
    assert parse_address("[::1]:123") == ("::1", 123)
    assert parse_address("[0:0:0:0:0:0:0:1]:123") == ("::1", 123)
    assert parse_address("192.0.2.3:123") == ("192.0.2.3", 123)
    assert parse_address("[192.0.2.3]:123") == ("192.0.2.3", 123)
    assert parse_address("[192.0.2.3]:123", allow_ranges=True) == ("192.0.2.3", 123)

# Generated at 2022-06-11 08:57:01.031532
# Unit test for function parse_address
def test_parse_address():
    from ansible.utils.network import is_ipv4, is_ipv6
    for a in ['a', 'a:b']:
        try:
            parse_address(a)
            raise Exception("Did not detect invalid IPv4 address")
        except AnsibleError:
            pass

    for a in ['a', 'a:b']:
        try:
            parse_address(a, allow_ranges=True)
            raise Exception("Did not detect invalid IPv4 address")
        except AnsibleError:
            pass

    for a in ['::1:b', '[::1]:b']:
        try:
            parse_address(a)
            raise Exception("Did not detect invalid IPv6 address")
        except AnsibleError:
            pass


# Generated at 2022-06-11 08:57:10.717676
# Unit test for function parse_address
def test_parse_address():
    # Valid inputs
    assert parse_address("localhost") == ("localhost", None)
    assert parse_address("localhost:22") == ("localhost", 22)
    assert parse_address("localhost:2222") == ("localhost", 2222)
    assert parse_address("google.com:22") == ("google.com", 22)
    assert parse_address("google.com:2222") == ("google.com", 2222)
    assert parse_address("10.10.10.1") == ("10.10.10.1", None)
    assert parse_address("10.10.10.1:22") == ("10.10.10.1", 22)
    assert parse_address("10.10.10.1:2222") == ("10.10.10.1", 2222)

# Generated at 2022-06-11 08:57:20.664297
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:80') == ('foo', 80)

    assert parse_address('foo[1:3]') == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:80') == ('foo[1:3]', 80)

    assert parse_address('foo[a:c]') == ('foo[a:c]', None)
    assert parse_address('foo[a:c]:80') == ('foo[a:c]', 80)

    assert parse_address('foo[a:c:2]') == ('foo[a:c:2]', None)
    assert parse_address('foo[a:c:2]:80') == ('foo[a:c:2]', 80)
