

# Generated at 2022-06-11 08:54:10.169355
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:21.138522
# Unit test for function parse_address
def test_parse_address():
    def compare(result, expected):
        if result != expected:
            print("%s failed: expected %s but got %s" % (address, expected, result))
            return False
        else:
            print("%s passed: %s" % (address, result))
            return True

    # Should match an IPv4 address with an optional port number
    passed = True
    address = '192.0.2.3:123'
    if not compare(parse_address(address), ('192.0.2.3', 123)):
        passed = False

    # Should match a bracketed IPv4 address with a mandatory port number
    address = '[192.0.2.3]:123'
    if not compare(parse_address(address), ('192.0.2.3', 123)):
        passed = False

    # Should match an IPv6

# Generated at 2022-06-11 08:54:27.648325
# Unit test for function parse_address
def test_parse_address():

    # IPv4
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:1234') == ('127.0.0.1', 1234)
    assert parse_address('127.0.0.1[0:3]') == ('127.0.0.1[0:3]', None)
    assert parse_address('127.0.0.1[0:3]:1234') == ('127.0.0.1[0:3]', 1234)
    assert parse_address('[127.0.0.1]:1234') == ('127.0.0.1', 1234)

# Generated at 2022-06-11 08:54:37.393375
# Unit test for function parse_address
def test_parse_address():
    ipv4_port_tests = {
        '127.0.0.1': ('127.0.0.1', None),
        '127.0.0.1:22': ('127.0.0.1', 22),
    }
    ipv4_range_tests = {
        '127.0.1[0:2].1': ('127.0.1[0:2].1', None),
        '127.0.1[0:2].1:22': ('127.0.1[0:2].1', 22),
    }
    host_port_tests = {
        'local.host': ('local.host', None),
        'local.host:22': ('local.host', 22),
    }

# Generated at 2022-06-11 08:54:48.777509
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:bar:22') == ('foo:bar', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:4') == ('192.0.2.3', 4)
    assert parse_address('192.0.2.3:65535') == ('192.0.2.3', 65535)
    assert parse_address('7ffe:10:20:abc:9e9e:ffff:ffff:ffff') == ('7ffe:10:20:abc:9e9e:ffff:ffff:ffff', None)

# Generated at 2022-06-11 08:55:01.000499
# Unit test for function parse_address
def test_parse_address():
    def test_address(address, host_expected, port_expected, allow_ranges=False):
        (host, port) = parse_address(address, allow_ranges)
        assert host == host_expected
        assert port == port_expected
    # No spec in IPv4 or IPv6
    test_address('127.0.0.1', '127.0.0.1', None)
    test_address('[::1]', '::1', None)
    # With port
    test_address('127.0.0.1:1234', '127.0.0.1', 1234)
    test_address('[::1]:1234', '::1', 1234)
    # Bracketed IPv4

# Generated at 2022-06-11 08:55:07.443383
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo.example.com', allow_ranges=True) == ('foo.example.com', None)
    assert parse_address('foo.example.com:443', allow_ranges=True) == ('foo.example.com', 443)
    assert parse_address('foo[1:3].example.com', allow_ranges=True) == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:443', allow_ranges=True) == ('foo[1:3].example.com', 443)
    assert parse_address('foo[1:3].example.com', allow_ranges=False) == ('foo[1:3].example.com', None)

# Generated at 2022-06-11 08:55:15.861907
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:27.490820
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:39.328879
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('0:0:0:0:0:ffff:192.0.2.3') == ('0:0:0:0:0:ffff:192.0.2.3', None)
    assert parse_address('0:0:0:0:0:ffff:192.0.2.3:65535') == ('0:0:0:0:0:ffff:192.0.2.3', 65535)
    assert parse_address('[0:0:0:0:0:ffff:192.0.2.3]:65535') == ('0:0:0:0:0:ffff:192.0.2.3', 65535)