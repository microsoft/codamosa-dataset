

# Generated at 2022-06-11 08:54:11.533031
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:22.609713
# Unit test for function parse_address
def test_parse_address():
    """
    Tests the parse_address function.
    """

# Generated at 2022-06-11 08:54:32.072450
# Unit test for function parse_address
def test_parse_address():
    import sys
    if sys.version_info[0] == 2:
        from mock import patch
    else:
        from unittest.mock import patch

    with patch.object(AnsibleError, "__str__") as mock_str:
        try:
            parse_address("foozle")
        except AnsibleError as e:
            assert e.__str__() == "Not a valid network hostname: foozle"

    (host, port) = parse_address("foo.example.com")
    assert host == "foo.example.com"
    assert port is None

    (host, port) = parse_address("foo.example.com:10022")
    assert host == "foo.example.com"
    assert port == 10022


# Generated at 2022-06-11 08:54:35.722793
# Unit test for function parse_address
def test_parse_address():
    """
    Module func: ansible.module_utils.network.common.parse_address
    Unit test for function parse_address
    """
    parsers = (parse_address,)
    for parser in parsers:
        yield ut1_parse_address, parser


# Generated at 2022-06-11 08:54:47.028974
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:58.378615
# Unit test for function parse_address
def test_parse_address():
    """Unit test: ansible.utils.parse_address()"""

    def test(address, allow_ranges=False, exp_host=None, exp_port=None):
        ans = parse_address(address, allow_ranges)
        assert ans == (exp_host, exp_port), "%s -> %s!=%s" % (address, ans, (exp_host, exp_port))

    # test() runs a single test case and tests for correct host and port.
    # If either is None, then the expression is invalid.

    # Bracketed hosts, with and without ports.

    test('[2001:db8::a:b:c]',
        exp_host='2001:db8::a:b:c')

# Generated at 2022-06-11 08:55:10.119360
# Unit test for function parse_address
def test_parse_address():

    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo.example.com:[1:3]') == ('foo.example.com:[1:3]', None)
    assert parse_address('foo.example.com:[1:3]:22') == ('foo.example.com:[1:3]', 22)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:22') == ('192.0.2.3', 22)

# Generated at 2022-06-11 08:55:17.385195
# Unit test for function parse_address
def test_parse_address():

    def check(string, expected_host, expected_port, allow_ranges=False):
        """
        Check that the function correctly parses the given string. If
        the string cannot be parsed, then the host must be None.
        """
        (host, port) = parse_address(string, allow_ranges)
        if host:
            assert host == expected_host
            assert port == expected_port
        else:
            assert expected_host is None

    # Test IPv4 addresses with and without port specifications
    check('10.0.0.0:22', '10.0.0.0', 22)
    check('10.0.0.0', '10.0.0.0', None)

    # Test IPv4 address patterns with and without port specifications

# Generated at 2022-06-11 08:55:29.329339
# Unit test for function parse_address
def test_parse_address():
    def test_valid(s, want_host, want_port):
        host, port = parse_address(s)
        assert host == want_host
        assert port == want_port

    def test_invalid(s):
        try:
            parse_address(s)
            assert False, "expected AnsibleError"
        except AnsibleError:
            pass

    # Test cases for parse_address

    # Valid IPv4 addresses:
    test_valid('192.0.2.3', '192.0.2.3', None)
    test_valid('192.0.2.3:22', '192.0.2.3', 22)
    test_valid('127.0.0.1:65535', '127.0.0.1', 65535)

    # Invalid IPv4 addresses:
    test_invalid

# Generated at 2022-06-11 08:55:40.507634
# Unit test for function parse_address
def test_parse_address():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    invm = InventoryManager(['/dev/null'])
    play_context = PlayContext(remote_addr='localhost', new_stdin=None)
    play_context.set_inventory(invm)


# Generated at 2022-06-11 08:55:51.709296
# Unit test for function parse_address
def test_parse_address():
    _host, _port = parse_address(None)
    assert (_host, _port) == (None, None)

    _host, _port = parse_address('', True)
    assert (_host, _port) == (None, None)

    _host, _port = parse_address('192.168.1.1', True)
    assert (_host, _port) == ('192.168.1.1', None)

    _host, _port = parse_address('192.168.1.1', False)
    assert (_host, _port) == ('192.168.1.1', None)

    _host, _port = parse_address('example.com', True)
    assert (_host, _port) == ('example.com', None)

    _host, _port = parse_address('example.com', False)
   

# Generated at 2022-06-11 08:56:01.740238
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo") == ("foo", None)
    assert parse_address("foo:22") == ("foo", 22)
    assert parse_address("foo:0") == ("foo", 0)
    assert parse_address("foo[0:2]:22") == ("foo[0:2]", 22)
    assert parse_address("foo:0:22") == ("foo:0", 22)
    assert parse_address("foo:22:0") == ("foo:22", 0)
    assert parse_address("[foo:0:22]:22") == ("[foo:0:22]", 22)

    assert parse_address("foo", allow_ranges=True) == ("foo", None)

# Generated at 2022-06-11 08:56:11.766368
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:22.657463
# Unit test for function parse_address
def test_parse_address():
    assert ('example.com', None) == parse_address('example.com')
    assert ('example[0:3].com', None) == parse_address('example[0:3].com')
    assert ('example.com', 22) == parse_address('example.com:22')
    assert ('example[0:3].com', 22) == parse_address('example[0:3].com:22')
    assert ('example[0:3].com', 22) == parse_address('[example[0:3].com]:22')
    assert ('1.2.3.4', None) == parse_address('1.2.3.4')
    assert ('1.2.3.4', 22) == parse_address('1.2.3.4:22')
    assert ('1.2.3.4', 22) == parse_address

# Generated at 2022-06-11 08:56:32.897694
# Unit test for function parse_address
def test_parse_address():
    """
    Compares output of parse_address() against a set of expected output
    """
    from nose.tools import assert_equal

    # A list of tuples (Input string, expected output)

# Generated at 2022-06-11 08:56:43.749807
# Unit test for function parse_address
def test_parse_address():
    def test(input, expected):
        if expected:
            assert parse_address(input) == expected, "parse_address(%s) == %s (expected %s)" % (input, parse_address(input), expected)
        else:
            try:
                parse_address(input)
                assert False, "parse_address(%s) == %s (expected exception)" % (input, parse_address(input))
            except Exception:
                # expected
                pass

    test("192.168.1.1", ("192.168.1.1", None))
    test("192.168.1.1:22", ("192.168.1.1", 22))
    test("[192.168.1.1]", ("192.168.1.1", None))

# Generated at 2022-06-11 08:56:53.455747
# Unit test for function parse_address

# Generated at 2022-06-11 08:57:01.858654
# Unit test for function parse_address

# Generated at 2022-06-11 08:57:11.759589
# Unit test for function parse_address
def test_parse_address():
    '''Unit test for function parse_address'''

    # IPv4 address with no port
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1', allow_ranges=True) == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:', allow_ranges=True) == ('127.0.0.1', None)

    # IPv4 address with a port
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)

# Generated at 2022-06-11 08:57:21.468206
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[2001:db8:85a3::8a2e:370:7334]') == (
        '2001:db8:85a3::8a2e:370:7334',
        None)
    assert parse_address('2001:db8:85a3::8a2e:370:7334') == (
        '2001:db8:85a3::8a2e:370:7334',
        None)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('192.168.1.1') == ('192.168.1.1', None)