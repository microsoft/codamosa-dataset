

# Generated at 2022-06-11 08:54:14.025462
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("example.com") == ("example.com", None)
    assert parse_address("example.com:80") == ("example.com", 80)
    assert parse_address("example.com:x", True) == ("example.com", None)
    assert parse_address("192.0.2.1") == ("192.0.2.1", None)
    assert parse_address("192.0.2.1:80") == ("192.0.2.1", 80)
    assert parse_address("192.0.2.1:x", True) == ("192.0.2.1", None)
    assert parse_address("[192.0.2.1]") == ("192.0.2.1", None)

# Generated at 2022-06-11 08:54:24.494771
# Unit test for function parse_address
def test_parse_address():

    assert parse_address("foo") == ('foo', None)
    assert parse_address("foo.example.com") == ('foo.example.com', None)
    assert parse_address("foo.example.com.invalid") == ('foo.example.com.invalid', None)

    assert parse_address("foo:1234") == ('foo', 1234)
    assert parse_address("foo.example.com:1234") == ('foo.example.com', 1234)
    assert parse_address("foo.example.com.invalid:1234") == ('foo.example.com.invalid', 1234)
    assert parse_address("[foo]:1234") == ('foo', 1234)
    assert parse_address("[foo.example.com]:1234") == ('foo.example.com', 1234)
    assert parse_address

# Generated at 2022-06-11 08:54:33.741609
# Unit test for function parse_address
def test_parse_address():
    def test(s, allow_ranges=False):
        h, p = parse_address(s, allow_ranges)
        print("%s -> %s:%s" % (s, h, p))

    assert(parse_address("foo") == ("foo", None))
    assert(parse_address("foo:22") == ("foo", 22))
    assert(parse_address("[foo]:22") == ("foo", 22))
    assert(parse_address(":22") == (None, 22))
    assert(parse_address("[::]:22") == ("::", 22))
    assert(parse_address("1.2.3.4") == ("1.2.3.4", None))
    assert(parse_address("1.2.3.4:22") == ("1.2.3.4", 22))

# Generated at 2022-06-11 08:54:45.022844
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    assert parse_address('localhost.localdomain') == ('localhost.localdomain', None)
    assert parse_address('localhost.localdomain:22') == ('localhost.localdomain', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)

# Generated at 2022-06-11 08:54:52.454144
# Unit test for function parse_address
def test_parse_address():
    # port number parsing
    assert parse_address("10.0.1.2:2022") == ('10.0.1.2', 2022)
    assert parse_address("[172.0.1.2]:2022") == ('172.0.1.2', 2022)
    assert parse_address("foo:22") == ('foo', 22)
    assert parse_address("foo:22", allow_ranges=True) == ('foo', 22)

    # IPv4 parsing
    assert parse_address("10.0.1.2") == ('10.0.1.2', None)
    assert parse_address("10.0.1.2", allow_ranges=True) == ('10.0.1.2', None)

# Generated at 2022-06-11 08:55:05.043221
# Unit test for function parse_address
def test_parse_address():
    """
    Tests for some examples of network hostname patterns that are and are not
    accepted. (This does not test all patterns.)
    """

    def test(address, expect, allow_ranges=False):
        """
        Tests whether the specified address string produces the expected result
        when parsed, and complains if it doesn't.
        """
        try:
            result = parse_address(address, allow_ranges)
            assert result == expect, '%s != %s (parsed correctly)' % (
                result, expect
            )
        except AnsibleParserError:
            assert expect is None, '%s should be accepted' % address
        except AnsibleError:
            assert expect is None, '%s should be accepted' % address

    test('example.com', ('example.com', None))                         # FQDN

# Generated at 2022-06-11 08:55:14.573677
# Unit test for function parse_address
def test_parse_address():
    # Test valid IPv4 addresses
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    # Test valid IPv6 addresses
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    # Test valid hostnames
    assert parse_address('localhost') == ('localhost', None)
    assert parse_address('localhost:22') == ('localhost', 22)
    # Test invalid IP addresses

# Generated at 2022-06-11 08:55:26.133999
# Unit test for function parse_address
def test_parse_address():
    ''' parse_address() form Ansible
    '''
    import sys
    import ipaddress


# Generated at 2022-06-11 08:55:38.352928
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4') == ('1.2.3.4', None)
    assert parse_address('1.2.3.4:22') == ('1.2.3.4', 22)
    assert parse_address('[::1]') == ('::1', None)
    assert parse_address('[::1]:22') == ('::1', 22)
    assert parse_address('foo.bar') == ('foo.bar', None)
    assert parse_address('foo.bar:22') == ('foo.bar', 22)
    assert parse_address('[foo.bar]:22') == ('foo.bar', 22)
    assert parse_address('1.2.3.4', True) == ('1.2.3.4', None)

# Generated at 2022-06-11 08:55:47.401871
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:59.428573
# Unit test for function parse_address
def test_parse_address():
    def t(address, host, port):
        (h, p) = parse_address(address)
        if host:
            assert h == host, '%s != %s' % (h, host)
        else:
            assert h is None, h
        if port:
            assert p == port, '%s != %s' % (p, port)
        else:
            assert p is None, p

    # bracket hostport
    t('[foo.example.com]', 'foo.example.com', None)
    t('[foo.example.com]:22', 'foo.example.com', 22)
    t('[192.0.2.3]', '192.0.2.3', None)
    t('[192.0.2.3]:22', '192.0.2.3', 22)


# Generated at 2022-06-11 08:56:09.820557
# Unit test for function parse_address
def test_parse_address():
    import pytest


# Generated at 2022-06-11 08:56:20.341794
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("foo:47") == ("foo", 47)
    assert parse_address("foo:aaa") == ("foo", "aaa")
    assert parse_address("foo[1:3]:aaa") == ("foo[1:3]", "aaa")
    assert parse_address("foo[01:3]:aaa") == ("foo[01:3]", "aaa")
    assert parse_address("foo[001:3]:aaa") == ("foo[001:3]", "aaa")
    assert parse_address("foo[a:c]:aaa") == ("foo[a:c]", "aaa")
    assert parse_address("foo[a:c:b]:aaa") == ("foo[a:c:b]", "aaa")

# Generated at 2022-06-11 08:56:29.968880
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('example.org:53') == ('example.org', 53)
    assert parse_address('[example][.:org]:53') == ('[example][.:org]', 53)
    assert parse_address('[127.0.0.1]:53') == ('127.0.0.1', 53)
    assert parse_address('127.0.0.1:53') == ('127.0.0.1', 53)
    assert parse_address('::1:53') == ('::1', 53)
    assert parse_address('[::1]:53') == ('::1', 53)

# Generated at 2022-06-11 08:56:41.578435
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('1.2.3.4:5') == ('1.2.3.4', 5)
    assert parse_address('example.org:80') == ('example.org', 80)
    assert parse_address('example.org') == ('example.org', None)
    assert parse_address('EXAMPLE.ORG') == ('example.org', None)

    assert parse_address('example[0:2].org') == ('example0.org', None)
    assert parse_address('example[0:2].org:80') == ('example0.org', 80)

    assert parse_address('[1.2.3.4]:5') == ('1.2.3.4', 5)
    assert parse_address('[1.2.3.4]') == ('1.2.3.4', None)

# Generated at 2022-06-11 08:56:50.196030
# Unit test for function parse_address

# Generated at 2022-06-11 08:56:59.280221
# Unit test for function parse_address
def test_parse_address():
    # Valid addresses (host or host:port)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:1234') == ('example.com', 1234)
    assert parse_address('foo[1].example.com') == ('foo[1].example.com', None)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:1234') == ('192.0.2.1', 1234)
    assert parse_address('[2001:db8::1]:1234') == ('[2001:db8::1]', 1234)

# Generated at 2022-06-11 08:57:08.895963
# Unit test for function parse_address
def test_parse_address():
    # Note that this test suite does not exhaustively test the four regular
    # expressions defined above (ipv4, ipv6, hostname). The intent is only to
    # cover cases that are actually used by the parse_address() function above.

    # Some of these tests use a dummy port number that ends in 6. This is just
    # to make it obvious that the port number is coming from the test string
    # rather than from the default port number.

    assert parse_address('[127.0.0.1]') == ('127.0.0.1', None)
    assert parse_address('[127.0.0.1]:26') == ('127.0.0.1', 26)

    assert parse_address('127.0.0.1:26') == ('127.0.0.1', 26)

# Generated at 2022-06-11 08:57:18.740297
# Unit test for function parse_address
def test_parse_address():
    import sys
    if sys.version_info < (2, 7, 0):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-11 08:57:27.663744
# Unit test for function parse_address
def test_parse_address():
    def test(address, allow_ranges):
        if allow_ranges:
            try:
                host, port = parse_address(address, True)
            except AnsibleError as e:
                host, port = e, None
        else:
            host, port = parse_address(address, False)
        if host is None:
            print("FAILED: %s, allow_ranges=%s: %s" % (address, allow_ranges, port))
        else:
            print("PASSED: %s, allow_ranges=%s -> %s:%s" % (address, allow_ranges, host, port))
