

# Generated at 2022-06-11 08:54:08.209371
# Unit test for function parse_address
def test_parse_address():

    # This is a simple hostname with an IPv4 address and a port
    assert parse_address("foo.example.com:22") == ("foo.example.com", 22)

    # This is the same hostname, with a numeric range in place of the IPv4 address
    assert parse_address("foo[0:5].example.com:22") == ("foo[0:5].example.com", 22)

    # These are IPv4 addresses with ports
    assert parse_address("192.0.2.3:22") == ("192.0.2.3", 22)
    assert parse_address("192.0.2.3:65535") == ("192.0.2.3", 65535)

    # These are IPv4 addresses with several parts replaced by ranges

# Generated at 2022-06-11 08:54:18.585361
# Unit test for function parse_address
def test_parse_address():

    assert(parse_address('foo') == ('foo', None))
    assert(parse_address('foo[0:3]') == ('foo[0:3]', None))
    assert(parse_address('foo[0:3]:42') == ('foo[0:3]', 42))

    assert(parse_address('foo.example.com') == ('foo.example.com', None))
    assert(parse_address('foo.example.com:42') == ('foo.example.com', 42))

    assert(parse_address('1.2.3.4') == ('1.2.3.4', None))
    assert(parse_address('1.2.3.4[0:2]:42') == ('1.2.3.4[0:2]', 42))

# Generated at 2022-06-11 08:54:26.768297
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:36.454754
# Unit test for function parse_address
def test_parse_address():
    assert parse_address(None) == (None, None), "Failed test for None input"
    assert parse_address("") == (None, None), "Failed test for empty input"

    assert parse_address("foo.example.com") == ("foo.example.com", None), "Failed test for hostname"

    assert parse_address("[2001:0db8:85a3:08d3:1319:8a2e:0370:7344]") == ("2001:0db8:85a3:08d3:1319:8a2e:0370:7344", None), "Failed test for IPv6 address"

    assert parse_address("[") == (None, None), "Failed test for improperly bracketed IPv6 address"

# Generated at 2022-06-11 08:54:47.823632
# Unit test for function parse_address
def test_parse_address():
    # basic cases
    assert parse_address('1.1.1.1:1234', allow_ranges=False) \
            == ('1.1.1.1', 1234)
    assert parse_address('[::1]:1234', allow_ranges=False) \
            == ('::1', 1234)
    assert parse_address('hostname:1234', allow_ranges=False) \
            == ('hostname', 1234)
    assert parse_address('1.1.1.1', allow_ranges=False) \
            == ('1.1.1.1', None)
    assert parse_address('[::1]', allow_ranges=False) \
            == ('::1', None)

# Generated at 2022-06-11 08:55:00.012960
# Unit test for function parse_address
def test_parse_address():
    try:
        import pytest
    except ImportError:
        return


# Generated at 2022-06-11 08:55:11.251383
# Unit test for function parse_address
def test_parse_address():

    result = parse_address("[::1]:6379")
    assert result == ("[::1]", 6379)

    result = parse_address("[::1]")
    assert result == ("[::1]", None)

    result = parse_address("[::1]", True)
    assert result == ("[::1]", None)

    result = parse_address("[::1]:1001", True)
    assert result == ("[::1]", 1001)

    result = parse_address("localhost:2222")
    assert result == ("localhost", 2222)

    result = parse_address("localhost")
    assert result == ("localhost", None)

    result = parse_address("localhost", True)
    assert result == ("localhost", None)

    result = parse_address("example.com:2222", True)
    assert result

# Generated at 2022-06-11 08:55:17.929688
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest

    class TestParseAddress(unittest.TestCase):

        def test_ipv4(self):
            self.assertTupleEqual(
                parse_address('192.0.2.1:123'),
                ('192.0.2.1', 123)
            )

        def test_ipv6(self):
            self.assertTupleEqual(
                parse_address('[2001:db8::1]:123'),
                ('2001:db8::1', 123)
            )

        def test_hostname(self):
            self.assertTupleEqual(
                parse_address('example.com:123'),
                ('example.com', 123)
            )


# Generated at 2022-06-11 08:55:29.793047
# Unit test for function parse_address
def test_parse_address():

    def test(inp, exp):
        if exp:
            host, port = exp
            exp = (host, port)
        res = parse_address(inp)
        if exp and res != exp:
            raise AssertionError("expected %s, got %s" % (exp, res))
        if not exp and res:
            raise AssertionError("expected %s, got %s" % (exp, res))

    test('[::1]', (u'::1', None))
    test('[::1]:22', (u'::1', 22))
    test('192.0.2.34', (u'192.0.2.34', None))
    test('192.0.2.34:22', (u'192.0.2.34', 22))

# Generated at 2022-06-11 08:55:40.802860
# Unit test for function parse_address
def test_parse_address():
    """
    >>> test_parse_address()
    passing
    """

    # We must have well-formed IP addresses and hostnames, and the port
    # specification must be optional.
    #
    # We test the IPv6 and IPv4 address patterns separately, because the IPv6
    # pattern is too complex to expect to be able to debug it.

    assert parse_address("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == \
        ("2001:0db8:85a3:0000:0000:8a2e:0370:7334", None)
    assert parse_address("2001:db8:85a3::8a2e:370:7334") == \
        ("2001:db8:85a3::8a2e:370:7334", None)
   