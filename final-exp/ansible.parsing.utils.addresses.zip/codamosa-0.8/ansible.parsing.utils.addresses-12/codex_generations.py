

# Generated at 2022-06-11 08:54:08.126533
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('foo') == ('foo', None)
    assert parse_address('foo:22') == ('foo', 22)
    assert parse_address('foo:1-65535') == ('foo', 1) # no-op for ports=0..65535
    assert parse_address('foo:65536') == ('foo', 65536) # no range checking
    assert parse_address('foo[0:11]:22') == ('foo[0:11]', 22)
    assert parse_address('[foo]:22') == ('foo', 22) # non-ambiguous address
    assert parse_address('127.0.0.1') == ('127.0.0.1', None)
    assert parse_address('127.0.0.1:22') == ('127.0.0.1', 22)

# Generated at 2022-06-11 08:54:18.474848
# Unit test for function parse_address
def test_parse_address():
  # Some simple error checking
  print (parse_address (None))
  print (parse_address (""))
  print (parse_address ("[]"))
  print (parse_address ("[127.0.0.1"))
  print (parse_address ("127.0.0.1]"))
  print (parse_address ("[127.0.0.1]:8000:"))
  print (parse_address ("[127.0.0.1]:8000::"))
  print (parse_address ("[::ffff:127.0.0.1]:8000"))

  # Valid addresses and range semantics
  print (parse_address ("127.0.0.1"))
  print (parse_address ("127.0.0.1:8000"))
  print (parse_address ("127.0.0.1[1:3]"))

# Generated at 2022-06-11 08:54:26.720478
# Unit test for function parse_address
def test_parse_address():
    from ansible.compat.tests import unittest
    class TestParseAddress(unittest.TestCase):

        def test_parse_address_with_no_port(self):
            """Parse a host identifier with no port specified."""

            (host, port) = parse_address('x')
            self.assertEqual(host, 'x')
            self.assertEqual(port, None)

            (host, port) = parse_address('x.y')
            self.assertEqual(host, 'x.y')
            self.assertEqual(port, None)

            (host, port) = parse_address('x:y')
            self.assertEqual(host, 'x:y')
            self.assertEqual(port, None)


# Generated at 2022-06-11 08:54:36.407448
# Unit test for function parse_address
def test_parse_address():
    import pytest
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:80') == ('example.com', 80)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('[example.com]:80') == ('example.com', 80)
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:80') == ('192.0.2.3', 80)
    assert parse_address('[192.0.2.3]') == ('192.0.2.3', None)

# Generated at 2022-06-11 08:54:47.772852
# Unit test for function parse_address
def test_parse_address():
    """ Test the correct operation of the function parse_address
    """

    assert parse_address('foo.example.com') == ('foo.example.com', None)
    assert parse_address('foo.example.com:22') == ('foo.example.com', 22)
    assert parse_address('foo[1:3].example.com') == ('foo[1:3].example.com', None)
    assert parse_address('foo[1:3].example.com:22') == ('foo[1:3].example.com', 22)
    assert parse_address('192.0.2.1') == ('192.0.2.1', None)
    assert parse_address('192.0.2.1:22') == ('192.0.2.1', 22)

# Generated at 2022-06-11 08:54:59.945131
# Unit test for function parse_address
def test_parse_address():
    result = parse_address('foo[1:3]')
    assert result == ('foo[1:3]', None)
    result = parse_address('foo[1:3]-bar[x-z]')
    assert result == ('foo[1:3]-bar[x-z]', None)
    result = parse_address('foo[1:3]:10')
    assert result == ('foo[1:3]', 10)
    result = parse_address('[::ffff:192.0.2.3]:10')
    assert result == ('[::ffff:192.0.2.3]', 10)
    with pytest.raises(AnsibleError):
        parse_address('[ff:ffff:192.0.2.3]:10')
    with pytest.raises(AnsibleError):
        parse_address

# Generated at 2022-06-11 08:55:11.209500
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('example.com:22') == ('example.com', 22)
    assert parse_address('[localhost]:8080') == ('localhost', 8080)
    assert parse_address('192.0.2.3:9000') == ('192.0.2.3', 9000)
    assert parse_address('[2001:db8::1]:22') == ('2001:db8::1', 22)
    assert parse_address('2001:db8::1:22') is None
    assert parse_address('192.0.2.3') == ('192.0.2.3', None)
    assert parse_address('2001:db8::1') == ('2001:db8::1', None)

# Generated at 2022-06-11 08:55:17.911332
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[::ffff:192.0.2.3]:123") == ("::ffff:192.0.2.3", 123)
    assert parse_address("[::192.0.2.3]:123") == ("::192.0.2.3", 123)
    assert parse_address("[foo:bar:baz]:123") == ("foo:bar:baz", 123)
    assert parse_address("[foo:baz:bar]:123") == ("foo:baz:bar", 123)

    assert parse_address("[::192.0.2.3]") == (None, None)
    assert parse_address("foo:1234") == (None, None)

    assert parse_address("192.0.2.3") == ("192.0.2.3", None)
    assert parse_

# Generated at 2022-06-11 08:55:29.734475
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:40.769874
# Unit test for function parse_address
def test_parse_address():
    def _assert(string, expect):
        actual = parse_address(string)
        assert expect == actual, "%s => %s != %s" % (string, expect, actual)

    _assert('localhost', ('localhost', None))
    _assert('localhost:22', ('localhost', 22))
    _assert('localhost:[1:3]', ('localhost', None))
    _assert('localhost[1:3]', ('localhost[1:3]', None))
    _assert('[localhost]:22', ('localhost', 22))
    _assert('[localhost]:[1:3]', ('localhost', None))
    _assert('[localhost[1:3]]:22', ('localhost[1:3]', 22))
    _assert('192.0.2.3', ('192.0.2.3', None))