

# Generated at 2022-06-11 08:54:09.116795
# Unit test for function parse_address
def test_parse_address():
    assert parse_address("[::]") == ("::", None)
    assert parse_address("[::1]") == ("::1", None)
    assert parse_address("[::1]:22") == ("::1", 22)
    assert parse_address("[2001:db8::1]") == ("2001:db8::1", None)
    assert parse_address("[2001:db8::1]:22") == ("2001:db8::1", 22)
    assert parse_address("[2001:db8::1%eth0]") == ("2001:db8::1%eth0", None)
    assert parse_address("[2001:db8::1%eth0]:22") == ("2001:db8::1%eth0", 22)

# Generated at 2022-06-11 08:54:19.926885
# Unit test for function parse_address

# Generated at 2022-06-11 08:54:28.471745
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::1]') == (u'::1', None)
    assert parse_address('[::1]:123') == (u'::1', 123)
    assert parse_address('[::192.0.2.3]') == (u'::192.0.2.3', None)
    assert parse_address('[::192.0.2.3]:123') == (u'::192.0.2.3', 123)
    assert parse_address('[::ffff:192.0.2.3]') == (u'::ffff:192.0.2.3', None)
    assert parse_address('[::ffff:192.0.2.3]:123') == (u'::ffff:192.0.2.3', 123)

# Generated at 2022-06-11 08:54:38.462419
# Unit test for function parse_address
def test_parse_address():
    """ Test parse_address function """

    a = parse_address("myhost")
    assert a == ('myhost', None)

    a = parse_address("myhost:")
    assert a == ('myhost', None)

    a = parse_address("myhost:22")
    assert a == ('myhost', 22)

    a = parse_address("my[0:9]host")
    assert a == ('my[0:9]host', None)

    a = parse_address("my[0:9]host:")
    assert a == ('my[0:9]host', None)

    a = parse_address("my[0:9]host:22")
    assert a == ('my[0:9]host', 22)

    # IPV4
    a = parse_address("192.0.2.3")


# Generated at 2022-06-11 08:54:49.467807
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:01.573156
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:12.424186
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:24.153853
# Unit test for function parse_address

# Generated at 2022-06-11 08:55:36.338872
# Unit test for function parse_address
def test_parse_address():
    assert parse_address('[::ffff:192.0.2.3]:27017') == ('::ffff:192.0.2.3', 27017)
    assert parse_address('example.com:27017') == ('example.com', 27017)
    assert parse_address('[example.com]:27017') == ('example.com', 27017)
    assert parse_address('[example.com]') == ('example.com', None)
    assert parse_address('example.com') == ('example.com', None)
    assert parse_address('one.two.three.four:27017') == ('one.two.three.four', 27017)
    assert parse_address('[one.two.three.four]:27017') == ('one.two.three.four', 27017)

# Generated at 2022-06-11 08:55:44.131434
# Unit test for function parse_address
def test_parse_address():
    """
    Test the parse_address function.
    """

    assert parse_address('foo', allow_ranges=True) == ('foo', None)
    assert parse_address('foo:42', allow_ranges=True) == ('foo', 42)
    assert parse_address('foo[1:3]', allow_ranges=True) == ('foo[1:3]', None)
    assert parse_address('foo[1:3]:42', allow_ranges=True) == ('foo[1:3]', 42)

    assert parse_address('192.0.2.3', allow_ranges=True) == ('192.0.2.3', None)
    assert parse_address('192.0.2.3:42', allow_ranges=True) == ('192.0.2.3', 42)
    assert parse