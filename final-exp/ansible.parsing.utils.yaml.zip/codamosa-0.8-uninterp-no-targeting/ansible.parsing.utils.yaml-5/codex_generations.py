

# Generated at 2022-06-20 23:40:28.510403
# Unit test for function from_yaml
def test_from_yaml(): # pylint:disable=unused-variable, redefined-outer-name
    '''
    test_from_yaml
    '''
    def _test_multiline_text(test_data):
        '''
        test_multiline_text
        '''
        # yaml.safe_load does not handle multiline text correctly
        test_data['multiline_text'] = '''
first line
second line
last line
'''
        test_data['true'] = True
        test_data['null'] = None
        test_data['int'] = 1
        test_data['float'] = 1.1
        test_data['tuple'] = (1, 2)
        test_data['list'] = ['1', '2']

# Generated at 2022-06-20 23:40:36.522183
# Unit test for function from_yaml
def test_from_yaml():
    src = """
    {
        "foo": "bar",
        "baz": "foobar",
        "foobar": "barfoo"
    }
    """
    try:
        result = from_yaml(src)
    except:
        print (AnsibleParserError.__doc__)
        raise
    else:
        assert result == {"baz": "foobar", "foo": "bar", "foobar": "barfoo"}

# Generated at 2022-06-20 23:40:43.886328
# Unit test for function from_yaml
def test_from_yaml():
    new_data = from_yaml("""
- hosts: localhost
  tasks:
  - name: Fetching the list of databases
    mysql_db:
      login_user: root
      login_password: {{ password }}
      state: list
    register: list_of_databases
""")
    assert new_data is not None

# Generated at 2022-06-20 23:40:56.507072
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    class Test_from_yaml(unittest.TestCase):

        def test_from_yaml(self):

            # No exception is expected
            self.assertIsNotNone(from_yaml('\n'.join([
                '---',
                '- hosts: all',
                '  tasks:',
                '  - ping:',
                '      data: "pong"',
                '      data: "2"',
                '      data',
                '      - "pong"',
                '      - "2"',
            ]), json_only=False))

            # In case of JSON decoding error only a JSON parser exception should be raised

# Generated at 2022-06-20 23:41:09.682912
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    class MockAnsibleBaseYAMLObject:
        ansible_pos = None
        show_content = False

    class MockAnsibleParserError:
        problem = u''
        def __init__(self, message, obj, show_content, orig_exc):
            self.message = message
            self.obj = obj
            self.show_content = show_content
            self.orig_exc = orig_exc

    class YamlMockAnsibleJSONDecoder:
        secrets = None
        def __init__(self, secrets):
            pass

        def loads(self, str, cls):
            return '{}'

        def set_secrets(secrets):
            YamlMockAnsibleJSONDecoder.secrets = secrets


# Generated at 2022-06-20 23:41:22.540493
# Unit test for function from_yaml
def test_from_yaml():
    # We need to import this here so the unused import will not be flagged.
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert from_yaml(None) is None
    assert from_yaml('') == ''

    # JSON
    assert from_yaml('{}') == {}
    assert from_yaml('{"a": 1}') == {'a': 1}
    assert from_yaml('{"a": {"b": [1, 2]}}') == {'a': {'b': [1, 2]}}
    assert from_yaml('"a"') == 'a'
    assert from_yaml('true') is True
    assert from_yaml('false') is False
    assert from_yaml('null') is None

# Generated at 2022-06-20 23:41:28.233471
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"test": 1}') == {u'test': 1}
    assert from_yaml('{"test": 1}', json_only=True) == {u'test': 1}
    assert from_yaml('{test: 1}', json_only=True) == u'{test: 1}'

# Generated at 2022-06-20 23:41:36.613561
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Function to test the from_yaml function
    '''
    import os
    import sys
    sys.path.append(os.path.join(os.path.join(os.path.dirname(__file__), os.path.pardir), 'test'))

    from test_from_yaml import TestFromYaml

# Generated at 2022-06-20 23:41:39.940015
# Unit test for function from_yaml
def test_from_yaml():

    try:
        from_yaml("{{{", json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, "Expecting an exception here"

# Generated at 2022-06-20 23:41:51.382208
# Unit test for function from_yaml
def test_from_yaml():
    # This is a list, which should be returned as a list
    test_data_1 = '''
    ---
    - foo
    - bar
    '''
    assert isinstance(from_yaml(test_data_1), list)

    # This is a dict, which should be returned as a dict
    test_data_2 = '''
    ---
    foo: bar
    baz: biz
    '''
    assert isinstance(from_yaml(test_data_2), dict)

    # This is an invalid yaml file
    test_data_3 = '''
    ---
    a: 1
    b:
      c: 3
      d: 4
    '''

# Generated at 2022-06-20 23:42:02.638497
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    assert from_yaml('{"a": 1, "b": 2, "c": [3, 4, 5], "d": {"e": 6, "f": 7}}', '<string>') == \
        {'a': 1, 'b': 2, 'c': [3, 4, 5], 'd': {'e': 6, 'f': 7}}
    assert isinstance(from_yaml('{"a": 1, "b": 2, "c": [3, 4, 5], "d": {"e": 6, "f": 7}}', '<string>'), Mapping)

# Generated at 2022-06-20 23:42:15.279082
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys

    this_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(this_dir, '..'))
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()

    try:
        from_yaml("foo: bar: baz", '<string>', show_content=True, vault_secrets=None, json_only=False)
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError should be raised if the content is not a valid YAML/JSON"


# Generated at 2022-06-20 23:42:26.354131
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Ensure that a pure 'null' string parses as empty
    x = from_yaml('null')
    assert x == None

    # Ensure that we can mix quoted ansible vars and unquoted
    x = from_yaml('{"a": "{{ foo }}", "b": $foo}')
    assert x['a'] == "{{ foo }}"
    assert x['b'] == "$foo"

    # Ensure that we can parse a vault string

# Generated at 2022-06-20 23:42:31.567260
# Unit test for function from_yaml
def test_from_yaml():
    with open('../../apb.yml') as stream:
        import debugs
        debugs.print_info(from_yaml(stream), 'from_yaml')


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:42:41.476025
# Unit test for function from_yaml
def test_from_yaml():
    json_str = '{"test": {"value": "test", "array": ["test0", "test1"]}}'
    json_data = {"test": {"value": "test", "array": ["test0", "test1"]}}

    yaml_str = 'test:\n  value: test\n  array:\n    - test0\n    - test1\n'
    yaml_data = {"test": {"value": "test", "array": ["test0", "test1"]}}

    assert from_yaml(json_str) == json_data
    assert from_yaml(yaml_str) == yaml_data

# Generated at 2022-06-20 23:42:48.783672
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"hello": "world"}'
    result = from_yaml(test_data, json_only=True)
    assert result == {'hello': 'world'}
    test_data = '''
        data: {
            "hello": "world"
        }
    '''
    result = from_yaml(test_data, json_only=True)
    assert result == {'data': {'hello': 'world'}}

# Generated at 2022-06-20 23:42:56.004292
# Unit test for function from_yaml
def test_from_yaml():
    var = { 'a': 'b', 'c': 123 }
    var_yaml = 'a: b\nc: 123\n'
    var_json = '{ "a": "b", "c": 123 }'
    assert var == from_yaml(var_yaml)
    assert var == from_yaml(var_json)
    assert var == from_yaml(var_json, json_only=True)

# Generated at 2022-06-20 23:43:01.606274
# Unit test for function from_yaml
def test_from_yaml():
    data='{"a": "example"}'

    # assert valid JSON data
    assert from_yaml(data) == {"a": "example"}

    # assert bad JSON raises an exception
    try:
        from_yaml('{a: example}')
        assert False, 'should have thrown exception'
    except Exception as e:
        assert 'not JSON' in to_native(e), e

    # assert bad YAML raises an exception
    try:
        from_yaml('a: example')
        assert False, 'should have thrown exception'
    except Exception as e:
        assert 'not YAML' in to_native(e), e

    # assert that we ignore non-JSON strings in the YAML output
    assert from_yaml('{a: example}') == {}

# Generated at 2022-06-20 23:43:12.669082
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.module_utils._text import to_bytes

    assert from_yaml(to_bytes("---\n- test1\n- test2\n")) == ['test1', 'test2']
    assert from_yaml(to_bytes("---\n- test1\n- test2\n"), json_only=False) == ['test1', 'test2']
    assert from_yaml(to_bytes("---\n- test1\n- test2\n"), json_only=True) == ['test1', 'test2']

    # FIXME (incomplete test)
    # try:
    #    from_yaml("---\n- test1\n- test2")
    #    raise AssertionError()
    # except Value

# Generated at 2022-06-20 23:43:19.498013
# Unit test for function from_yaml
def test_from_yaml():
    data = """---
        {
          "minimal_principal": "minimal",
          "role": ["Admin", "User"]
        }
    """
    res = from_yaml(data)
    assert 'minimal_principal' in res
    assert 'role' in res

# Generated at 2022-06-20 23:43:25.000076
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    foobar:
      nsh:
      - test
      - test2
    baz: "{{ foobar.nsh }}"
    '''
    data = from_yaml(yaml_str)
    assert isinstance(data, dict)
    assert data['baz'] == data['foobar']['nsh']

# Generated at 2022-06-20 23:43:34.595084
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': '{{bar}}'}",
                     "{'foo': '{{bar}}'}")
    assert from_yaml("'" + chr(10) + "'",
                     '\n')
    assert from_yaml(chr(10),
                     None)
    assert from_yaml("{'foo': '{{bar}}'}",
                     "{'foo': '{{bar}}'}")
    assert from_yaml("{'foo': '{{bar}}'}",
                     "{'foo': '{{bar}}'}")
    assert from_yaml("DATA",
                     "DATA")

# Generated at 2022-06-20 23:43:41.417501
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('"hello"') == "hello"
    assert from_yaml('["hello"]') == ["hello"]
    assert from_yaml('{"hello":"world"}') == {"hello": "world"}
    assert from_yaml('hello: world') == {"hello": "world"}
    assert from_yaml('1') == 1
    assert from_yaml('1.1') == 1.1
    assert from_yaml('1.1', json_only=True) == 1.1

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:43:44.287980
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}



# Generated at 2022-06-20 23:43:56.294959
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""{
            "json_only": false,
            "array": [
                "json",
                "yaml"
            ],
            "none": null,
            "boolean": true,
            "integer": 1,
            "float": 0.1,
            "string": "text"
    }""") == {
        'array': ['json', 'yaml'],
        'boolean': True,
        'float': 0.1,
        'integer': 1,
        'json_only': False,
        'none': None,
        'string': 'text',
    }


# Generated at 2022-06-20 23:44:03.756099
# Unit test for function from_yaml
def test_from_yaml():
    data = u'{ "foo": "bar" }'
    file_name = 'playbook'
    show_content = True
    vault_secrets = None
    json_only = False

    new_data = None

    try:
        # in case we have to deal with vaults
        AnsibleJSONDecoder.set_secrets(vault_secrets)

        # we first try to load this data as JSON.
        # Fixes issues with extra vars json strings not being parsed correctly by the yaml parser
        new_data = json.loads(data, cls=AnsibleJSONDecoder)
        print("This is loaded as JSON ", new_data)
    except Exception as json_exc:

        if json_only:
            raise AnsibleParserError(to_native(json_exc), orig_exc=json_exc)

       

# Generated at 2022-06-20 23:44:15.812458
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert from_yaml('{"foo": "1"}') == {'foo': '1'}
    assert from_yaml('{"foo": 1}') == {'foo': 1}
    assert from_yaml('{"foo": [1, 2]}') == {'foo': [1, 2]}
    assert from_yaml('{"foo": [1, 2], "bar": true}') == {'foo': [1, 2], 'bar': True}

    # test yaml
    assert from_yaml('foo: "bar"', json_only=True) == {'foo': 'bar'}
    assert from_yaml('foo: 1', json_only=True) == {'foo': 1}
    assert from_yaml

# Generated at 2022-06-20 23:44:24.024383
# Unit test for function from_yaml
def test_from_yaml():
    # Test AnsibleParserError is raised when unable to parse either JSON or YAML.
    try:
        from_yaml("{{warble")
    except AnsibleParserError as e:
        assert e.message == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n' \
                            'JSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)\n\n' \
                            "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" \
                            "YAML: Could not find expected ':' while scanning a simple key at line 1 column 3 (char 2)\n" \
                            'Details: {}'.format(getattr(e, 'details', 'N/A'))
    else:
        raise Assert

# Generated at 2022-06-20 23:44:36.214705
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit tests for function from_yaml
    '''
    # 1
    src = '''
    - name: "{{ remote_user }}"
      sudo: yes
      sudo_user: "{{ sudo_user }}"
      hosts: ci
      gather_facts: False
      tasks:
      - name: echo hello world
        shell: echo hello world
    '''
    result = from_yaml(src, json_only=False)
    assert result[0]['name'] == '{{ remote_user }}'

    # 2

# Generated at 2022-06-20 23:44:44.670471
# Unit test for function from_yaml
def test_from_yaml():

    # This should pass with no exception
    yaml_string = """
    -
        ansible_become: yes
        ansible_become_user: root
        ansible_become_method: sudo
        ansible_become_exe: /usr/bin/sudo
        ansible_host: localhost
        ansible_connection: docker
        ansible_user: root
        ansible_ssh_private_key_file: /Users/jtanner/.ssh/id_rsa
        ansible_python_interpreter: /usr/bin/python3.5

    """
    from_yaml(yaml_string)

# Generated at 2022-06-20 23:44:53.712435
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo":"bar"}') == {u'foo': u'bar'}
    assert from_yaml('foo: bar') == {u'foo': u'bar'}
    assert from_yaml('foo: bar', file_name='/tmp/foo', show_content=False) == {u'foo': u'bar'}
    with pytest.raises(AnsibleParserError):
        from_yaml('[')

# Generated at 2022-06-20 23:44:57.630694
# Unit test for function from_yaml
def test_from_yaml():
    test_data = "hostname: testhost\n"
    expected_result = {'hostname': 'testhost'}
    actual_result = from_yaml(test_data)
    assert actual_result == expected_result



# Generated at 2022-06-20 23:45:05.711257
# Unit test for function from_yaml
def test_from_yaml():
    # Test a valid yaml file
    valid_yaml = "hello:\n  var: 2"
    valid_yaml_data = from_yaml(valid_yaml, file_name='/etc/ansible/test_valid.yaml')
    assert valid_yaml_data == {'hello': {'var': 2}}

    # Test invalid yaml file
    invalid_yaml = "hello:\n  var: 2\n: hello"
    try:
        from_yaml(invalid_yaml, file_name='/etc/ansible/test_invalid.yaml')
        assert False, "Invalid yaml file did not raise an AnsibleParserError"
    except AnsibleParserError:
        pass

    # Test a valid json file
    json_string = "{\"hello\": {\"var\": 2}}"


# Generated at 2022-06-20 23:45:17.443712
# Unit test for function from_yaml
def test_from_yaml():
    '''
    from_yaml function test
    '''

    tests = [
        {"input":"{\"key\":42}", "output": {"key": 42}},
        {"input":"key: 42", "output": {"key": 42}},
        {"input":"key: [\"value1\", \"value2\"]", "output": {"key": ["value1", "value2"]}},
    ]

    wrong_syntax_inputs = [
        "key 42",
        """
        key:
            - subkey1 42
        """,
        """
        key:
            - subkey1: 42
            - subkey2 42
        """,
    ]

    for test in tests:
        print("input:\n%s" % test["input"])
        data = from_yaml(test["input"])
       

# Generated at 2022-06-20 23:45:25.137144
# Unit test for function from_yaml
def test_from_yaml():
    # Testing json only
    assert from_yaml("{'test_key': 'test_value'}", json_only=True) == {"test_key": "test_value"}
    # Testing json only with try_literal_eval
    assert from_yaml("'test_value'", json_only=True) == "test_value"
    # Testing json only with try_literal_eval and string value
    assert from_yaml("\"test_value\"", json_only=True) == "test_value"

# Generated at 2022-06-20 23:45:32.805292
# Unit test for function from_yaml
def test_from_yaml():
    ansible_ansible_playbook = {
        'name': 'ansible-playbook',
        'version': '1.0',
        'summary': 'Run Ansible playbooks',
        'description': 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.',
        'author': 'Ansible, Inc.',
        'homepage': 'http://ansible.com/',
        'license': 'GNU General Public License v3 or later (GPLv3+)',
        'keywords': [
            'ansible',
            'playbook'
        ],
        'requires': [
            'ansible'
        ]
    }


# Generated at 2022-06-20 23:45:44.714901
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml('---\n- a\n- b') == ["a", "b"]
    assert from_yaml('[ 1, 2, "a" ]') == [1, 2, "a"]
    assert from_yaml('{ "a": 1, "b": "c" }') == {"a": 1, "b": "c"}
    assert from_yaml('"string"') == "string"

    # strings
    assert from_yaml('"1"') == "1"
    assert from_yaml('"1.0"') == "1.0"
    assert from_yaml('"1.2e3"') == "1.2e3"
    assert from_yaml('"1.2E+3"') == "1.2E+3"

# Generated at 2022-06-20 23:45:54.688853
# Unit test for function from_yaml
def test_from_yaml():
    # Create and write test data
    data = {'test': 'data'}
    yaml_data = to_native(
        '---\n'
        'test: data\n'
    )
    json_data = to_native('{"test": "data"}')

    # Test from_yaml with yaml data
    with open('/tmp/test_from_yaml.yaml', 'w') as f:
        f.write(yaml_data)
    assert from_yaml(yaml_data, file_name='/tmp/test_from_yaml.yaml') == data
    assert from_yaml(yaml_data, file_name='/tmp/test_from_yaml.yaml', json_only=True) != data

    # Test from_yaml with json data

# Generated at 2022-06-20 23:46:06.227621
# Unit test for function from_yaml
def test_from_yaml():

    try:
        from_json = from_yaml('{}')
    except AnsibleParserError:
        pass

    try:
        from_json = from_yaml('{}', json_only=True)
    except AnsibleParserError:
        pass

    try:
        from_json = from_yaml('{}', json_only=True)
    except AnsibleParserError:
        pass

    try:
        from_yaml('[', json_only=True)
    except AnsibleParserError:
        pass

    try:
        from_yaml('[', json_only=False)
    except AnsibleParserError:
        pass

    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('[]', json_only=True)

# Generated at 2022-06-20 23:46:16.579842
# Unit test for function from_yaml
def test_from_yaml():
    '''Validate the from_yaml function.'''
    json_str = '{"foo": "bar"}'
    yaml_str = 'foo: bar\n'

    assert from_yaml(json_str) == json.loads(json_str)
    assert from_yaml(yaml_str) == yaml.load(yaml_str)

    json_broken_str = '{"foo": "bar"}'
    yaml_broken_str = 'foo: bar\nanother: line\n'

    try:
        from_yaml(json_broken_str, json_only=True)
        assert False
    except AnsibleParserError as e:
        assert 'JSON' in to_native(e)


# Generated at 2022-06-20 23:46:24.968928
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'foo': 42}"
    try:
        output = from_yaml(json.loads(data), file_name='<string>')
    except AnsibleParserError as e:
        output = e.message

    assert output == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n' \
                     'JSON: missing , in object key:value pair\n\nFailed to parse the JSON data: missing , in object key:value pair\n' \
                     'The error appears to be in \'<string>\': line 1, column 12'


# Generated at 2022-06-20 23:46:30.119386
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    # json
    json_str = '{"a": "b", "c": "d"}'
    data = from_yaml(json_str)
    assert isinstance(data, dict)
    assert data == DataLoader().load_from_file(json_str)

    # yaml
    yaml_str = 'a: b\nc: d'
    data = from_yaml(yaml_str)
    assert isinstance(data, dict)
    assert data == DataLoader().load_from_file(yaml_str)

    # ansible vars
    ansible_var_str = 'a: b: c'
    data = from_yaml(ansible_var_str)
    assert isinstance(data, dict)

# Generated at 2022-06-20 23:46:34.550654
# Unit test for function from_yaml
def test_from_yaml():
    # This is just a basic test to ensure a valid JSON string is handled as JSON.
    # There are other tests in parsing/test/test_ajson.py to test the JSON encoding/decoding.
    assert from_yaml("{\"foo\": \"bar\"}") == {'foo': 'bar'}

# Generated at 2022-06-20 23:46:44.534554
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This is not a real unit test. It just demonstrates how to use the from_yaml()
    function to parse data.
    '''
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    ---
    a: 1
    b: 2
    '''
    obj = from_yaml(data)
    assert obj['a'] == 1
    assert obj['b'] == 2

    data = '''
    ---
    a: 1
    b: 2.0
    '''
    obj = from_yaml(data)
    assert obj['a'] == 1
    assert obj['b'] == 2.0


# Generated at 2022-06-20 23:46:47.786303
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "foo": "bar" }'
    result = from_yaml(data)
    assert result == {u'foo': u'bar'}



# Generated at 2022-06-20 23:47:00.348093
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    ---
    foo:
      - name: test_key
        test_value: "key1: {{ var1 }}"
    '''

    print("Input:")
    print("-----")
    print(yaml_str)

    data = from_yaml(yaml_str)
    print("-----")
    print("Output (data):")
    print("-----")
    print(data)
    print("-----")
    print("Output (data[\"foo\"][0][\"name\"]):")
    print("-----")
    print(data["foo"][0]["name"])
    print("")

# This import allows from_yaml function to get loaded and exposed when
# the module is used as an external plugin via the ansible-galaxy command

# Generated at 2022-06-20 23:47:07.134072
# Unit test for function from_yaml
def test_from_yaml():
    import os
    ansible_yaml_test = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ansible_yaml_test.yml')
    with open(ansible_yaml_test) as f:
        ansible_yaml_data = f.read()
    test_data = from_yaml(ansible_yaml_data)
    assert(test_data['blocks'][0]['argument1'] == '3')

# Generated at 2022-06-20 23:47:13.100998
# Unit test for function from_yaml
def test_from_yaml():
    test_data = [{'foo': 'bar'}]

    result = from_yaml(json.dumps(test_data), json_only=True)
    assert result == test_data

    result = from_yaml(json.dumps(test_data))
    assert result == test_data

    result = from_yaml(json.dumps(test_data), json_only=False)
    assert result == test_data

# Generated at 2022-06-20 23:47:15.222710
# Unit test for function from_yaml
def test_from_yaml():
    '''Test for function from_yaml'''
    # TODO: Create unitest
    pass

# Generated at 2022-06-20 23:47:21.701689
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Make sure from_yaml load valid yaml data from a string
    '''
    from_yaml_result = from_yaml("""
    -
      name: test
      version: 1.0
    """)
    assert from_yaml_result == [
        {
            'name': 'test',
            'version': '1.0'
        }
    ]

# Generated at 2022-06-20 23:47:31.579235
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = 'foo: bar\n'
    data = from_yaml(yaml_str)
    assert data == {u'foo': u'bar'}

    json_str = '{"foo": "bar"}'
    data = from_yaml(json_str)
    assert data == {"foo": "bar"}

    json_str_with_secrets = '{"foo": "bar", "ansible_become_pass": "vault"}'
    data = from_yaml(json_str_with_secrets)
    assert data == {"foo": "bar", "ansible_become_pass": "vault"}


# Generated at 2022-06-20 23:47:37.344678
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # load simple YAML
    yaml_simple = """
        ---
        key1: value1
        key2: value2
    """

    data = from_yaml(yaml_simple)
    assert isinstance(data, dict)
    assert len(data) == 2

    # load simple JSON
    json_simple = """
        {
            "key1": "value1",
            "key2": "value2"
        }
    """
    data_json = from_yaml(json_simple)
    assert isinstance(data_json, dict)
    assert len(data_json) == 2

# Generated at 2022-06-20 23:47:48.422472
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u"{\"foo\": \"{{bar}}\"}", json_only=True) == {u'foo': u'{{bar}}'}
    assert from_yaml(u"{\"foo\": \"{{bar}}\"}") == {u'foo': u'{{bar}}'}
    assert from_yaml(u"{\"foo\": \"{{bar}}\"}", vault_secrets=[]) == {u'foo': u'{{bar}}'}
    assert from_yaml(u"{\"foo\": \"{{bar}}\"}", vault_secrets=[{'vault_id': 'vault_id'}]) == {u'foo': u'{bar}'}

# Generated at 2022-06-20 23:47:51.978424
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(from_yaml('{ "a": "b" }'), dict)
    assert isinstance(from_yaml('{"a": "b"}'), dict)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:47:58.615626
# Unit test for function from_yaml
def test_from_yaml():
    # Test JSON
    j = """
  ##############
  #
  {
    "top": {
        "middle": {
            "dict": "in dict",
            "string": "in string"
        }
    }
  }
  #
  ##############
  """

    # Test YAML
    y = """
  ##############
  #
  ---
  top:
    middle:
      dict: in dict
      string: in string
  #
  ##############
  """

    data1 = from_yaml(j)
    data2 = from_yaml(y)
    assert data1 == data2

    assert from_yaml(data1, '<string>', False) == data1

# Generated at 2022-06-20 23:48:11.581885
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import unittest
    import StringIO

    class TestAnsibleModuleUtils(unittest.TestCase):
        ''' Testing function from_yaml '''

        def test_basic_load(self):
            ''' Basic test for function from_yaml '''
            test_str = "{'key1': 'value1'}"
            exp_dict = {'key1': 'value1'}

            new_data = from_yaml(test_str)

            self.assertEqual(new_data, exp_dict)
        # End of test_basic_load

        def test_yaml_load(self):
            ''' Test for function from_yaml for YAML input '''
            test_str = """
                    ---
                    key1: value1
                    key2: value2
                    """

# Generated at 2022-06-20 23:48:18.462863
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"key": "value"}') == dict(key="value")
    assert from_yaml(u'{"key": "value"}') == dict(key="value")
    assert from_yaml('["one", "two"]') == ["one", "two"]
    assert from_yaml('["one", "two"]') == ["one", "two"]
    assert from_yaml('[one, two]') == ["one", "two"]
    assert from_yaml('[one, two]') == ["one", "two"]
    assert from_yaml('{"key": ["one", "two"]}') == dict(key=["one", "two"])
    assert from_yaml(u'{"key": ["one", "two"]}') == dict(key=["one", "two"])

# Generated at 2022-06-20 23:48:30.527981
# Unit test for function from_yaml
def test_from_yaml():
    # Test to ensure we raise an error when there is a syntax error
    def _test(s):
        try:
            from_yaml(s)
            raise Exception("should have failed!")
        except AnsibleParserError as e:
            print(e)
        # Ensure we see the content in the error message
        try:
            from_yaml(s, show_content=False)
            raise Exception("should have failed!")
        except AnsibleParserError as e:
            assert 'content' not in str(e)

    _test('"key" : "value"')
    _test('"key" : "value"')
    _test('"key" : value')
    _test('key: value: value')


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:48:35.350385
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"key": "value"}'
    assert from_yaml(data, file_name='<string>', show_content=False, vault_secrets=None) is not None
    assert from_yaml(data, file_name='<string>', show_content=False, vault_secrets=None) == {"key": "value"}

# Generated at 2022-06-20 23:48:38.165345
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'test': 1}") == {'test': 1}
    assert from_yaml("---\n- name: foo\n") == [{'name': 'foo'}]



# Generated at 2022-06-20 23:48:57.139297
# Unit test for function from_yaml
def test_from_yaml():
    # Test basic usage
    assert from_yaml('{"test": [1, 2, 3]}\n') == {'test': [1, 2, 3]}
    assert from_yaml('test: [1, 2, 3]\n') == {'test': [1, 2, 3]}

    # Test JSON error
    try:
        from_yaml('{test: 3, invalid_key}\n')
        assert False, "from_yaml() did not raise an exception"
    except AnsibleParserError:
        pass

    # Test YAML error
    try:
        from_yaml('{invalid_key}')
        assert False, "from_yaml() did not raise an exception"
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:49:04.219629
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 1
    data = '{"a": "foo", "b": "bar"}'
    new_data = from_yaml(data)
    assert new_data == {"a": "foo", "b": "bar"}

    # Test case 2
    data = '["a", "b", "c"]'
    new_data = from_yaml(data)
    assert new_data == ["a", "b", "c"]

    # Test case 3
    data = '{"a": {"b": "foo", "c": "bar"}}'
    new_data = from_yaml(data)
    assert new_data == {"a": {"b": "foo", "c": "bar"}}

    # Test case 4
    data = '{"a": ["b", "c"]}'
    new_data = from_

# Generated at 2022-06-20 23:49:15.467179
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.common._collections_compat import OrderedDict

    vault_secrets = dict(vault_identity='foo', vault_password='bar')


# Generated at 2022-06-20 23:49:25.113960
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('{ "a": 42 }')
    assert result == {"a": 42}
    result = from_yaml('{ a : 42 }')
    assert result == {"a": 42}

    result = from_yaml('{ "a": 42 }', json_only=True)
    assert result == {"a": 42}
    try:
        result = from_yaml('{ a : 42 }', json_only=True)
    except AnsibleParserError:
        pass
    else:
        # I don't know if this test is useful?
        assert False

    result = from_yaml('{ "a": 42 }', show_content=False)
    assert result == {"a": 42}

# Generated at 2022-06-20 23:49:29.494251
# Unit test for function from_yaml
def test_from_yaml():
    # Check that from_yaml returns a dictionary when it's a dictionary.
    data = {'hello': 'world'}
    expected_result = {"hello": "world"}
    assert from_yaml(data) == expected_result

    # Check that from_yaml returns a list when it's a list
    data = ['hello', 'world']
    expected_result = ['hello', 'world']
    assert from_yaml(data) == expected_result

    # Check that from_yaml returns the same integer
    data = 23
    expected_result = 23
    assert from_yaml(data) == expected_result

# Generated at 2022-06-20 23:49:40.155357
# Unit test for function from_yaml
def test_from_yaml():

    # Testing exception returns
    try:
        data = "{name: test}"
        file_name = 'file.yml'
        new_data = from_yaml(data, file_name)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Expected AnsibleParserError")

    try:
        data = None
        file_name = 'file.yml'
        new_data = from_yaml(data, file_name)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Expected AnsibleParserError")

    # Testing valid returns
    # We need to ensure that the return is a valid data structure
    # since we can't reliably know what data was passed in
    data = "{name: test}"

# Generated at 2022-06-20 23:49:41.291016
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1') == 1

# Generated at 2022-06-20 23:49:46.922494
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test function from_yaml
    '''
    from collections import OrderedDict

    data = '''\
    - a:
          1: foo
          2: bar
        b:
          1: baz
          2: qux
    - a:
          1: foo
          2: bar
        b:
          1: baz
          2: qux
    '''

    result = from_yaml(data)

    assert isinstance(result, list)

# Generated at 2022-06-20 23:49:56.027833
# Unit test for function from_yaml
def test_from_yaml():
    # Test yaml file
    import os
    test_yaml_file = os.path.join(os.path.dirname(__file__), 'data', 'from_yaml_test.yml')

    # Load from yaml string
    from_yaml_str = from_yaml('''
    ---
    # YAML comment
    hello: world
    foo:
        bar: baz
    ''')
    assert from_yaml_str is not None
    assert from_yaml_str['hello'] == 'world'
    assert from_yaml_str['foo']['bar'] == 'baz'

    # Load from json string
    from_yaml_json_str = from_yaml('{"hello": "world"}')
    assert from_yaml_json_str is not None
   

# Generated at 2022-06-20 23:49:59.910907
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = open('/Users/fsun/Downloads/test.yml', 'r').read()
    from_yaml(yaml_str)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:50:16.460089
# Unit test for function from_yaml
def test_from_yaml():
    data = u'{ "some_data": "test" }'
    assert from_yaml(data) == {'some_data': u'test'}

    data = u'{ "some_data": -100.5 }'
    assert from_yaml(data) == {'some_data': -100.5}

    data = u'{ "some_data": "test" }'
    assert from_yaml(data, json_only=True) == {'some_data': u'test'}

    data = u'{ "some_data": -100.5 }'
    assert from_yaml(data, json_only=True) == {'some_data': -100.5}

    data = u'{ "some_data": -100.5 }'