

# Generated at 2022-06-20 23:40:28.763447
# Unit test for function from_yaml
def test_from_yaml():
    '''Test to ensure yaml file is parsed as expected'''
    imp_string = u"{a: 1, b: 2}"
    ansible_string = "a: 1\nb: 2"
    assert from_yaml(imp_string) == {'a': 1, 'b': 2}
    assert from_yaml(ansible_string) == {'a': 1, 'b': 2}
    assert from_yaml(ansible_string, file_name="test.yml", show_content=True) == {'a': 1, 'b': 2}
    assert from_yaml(ansible_string, file_name="test.yml", show_content=False) == {'a': 1, 'b': 2}

# Generated at 2022-06-20 23:40:37.178038
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = [{u'a': u'b', u'c': u'd'}, {u'a': u'e', u'c': u'f'}]
    yaml_str = u'''---
- a: b
  c: d
- a: e
  c: f
    '''
    json_str = u'[{"a":"b","c":"d"},{"a":"e","c":"f"}]'
    assert from_yaml(json_str) == data
    assert from_yaml(yaml_str) == data

    assert isinstance(from_yaml(json_str), list)
    assert isinstance(from_yaml(yaml_str), list)

# Generated at 2022-06-20 23:40:43.492835
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    key1: value1
    key2: value2
    '''
    assert from_yaml(data) == {u'key1': u'value1', u'key2': u'value2'}

# Generated at 2022-06-20 23:40:53.510086
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.dataloader
    try:
        old_from_yaml = ansible.parsing.dataloader.from_yaml
    except:
        # The function is not there, so nothing to do.
        pass
    else:
        # Replace the function to be tested with the old one.
        ansible.parsing.dataloader.from_yaml = old_from_yaml

    # Get the function under test.
    from ansible.parsing.dataloader import from_yaml

    # Replace it again.
    ansible.parsing.dataloader.from_yaml = from_yaml

    # Check it.
    assert from_yaml("{}") == {}
    import os
    import tempfile

# Generated at 2022-06-20 23:41:00.202186
# Unit test for function from_yaml
def test_from_yaml():
    '''Test to ensure that a string containing a JSON structure is returned
    with a dict as its top-level object.
    '''
    test_data = "{\n  \"foo\": \"bar\",\n  \"baz\": [\n    1,\n    2,\n    3\n  ]\n}"
    test_data_result = {u'foo': u'bar', u'baz': [1, 2, 3]}
    assert from_yaml(test_data) == test_data_result

# Generated at 2022-06-20 23:41:06.499112
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{"bool": false, "int": 1, "list": [1, 2, 3], "string": "Hello World"}')
    from_yaml('{"bool": False}')
    from_yaml('null')
    from_yaml('[1, 2, 3]')
    from_yaml('123')
    from_yaml('123.456')

# Generated at 2022-06-20 23:41:10.740381
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_file = open('from_yaml.yml', 'r')
    yaml_content = from_yaml_file.read()
    from_yaml_file.close()

    try:
        from_yaml(yaml_content)
    except AnsibleParserError:
        raise AssertionError

# Generated at 2022-06-20 23:41:16.416811
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("""
- name: playbook
  hosts: localhost
  tasks:
  - name: ping test
    ping:
    register: result
    failed_when: result.rc != 0

    """)
    assert result is not None

# Generated at 2022-06-20 23:41:21.926014
# Unit test for function from_yaml
def test_from_yaml():
    ansible_vars = """
---
- name: "{{ inventory_hostname }}"
  iniset:
    section: DEFAULT
    option: verbose
    value: True
    config: "/etc/neutron/plugins/ml2/linuxbridge_agent.ini"
"""
    assert from_yaml(ansible_vars) is not None

# Generated at 2022-06-20 23:41:33.900372
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    if not PY3:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
        import sys
        import types
        # must get the original str type
        str_type = types.StringType
        # but if we're on python 2.6 or later, we need to make sure to use
        # the unicode type from python 3.x, as the one from 2.x will not work
        # with the json module.
        if sys.version_info[:2] > (2, 5):
            str_type = types.UnicodeType

        # make sure we can handle a leading @
        assert type(from_yaml('@test/foo.yml')) == AnsibleUnsafeText
        # make sure we can handle a unicode string


# Generated at 2022-06-20 23:41:43.509808
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    with open('../../lib/ansible/modules/web_infrastructure/scenario/scenario_requirements.yml') as f:
        data = from_yaml(f.read())
        assert isinstance(data, dict)
        assert isinstance(data["ceph"], (dict, AnsibleUnsafeText))

# Generated at 2022-06-20 23:41:47.460913
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("{\"a\": 1, \"b\": 2}") == {"a": 1, "b": 2}
    assert from_yaml("a: 1") == {"a": 1}
    assert from_yaml("a: 1\nb: 2") == {"a": 1, "b": 2}

# Generated at 2022-06-20 23:41:59.216461
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo':'bar'}") == {'foo':'bar'}
    assert from_yaml("{'foo':'bar', 'baz':'bam'}") == {'foo':'bar', 'baz':'bam'}
    assert from_yaml("{\"foo\":\"bar\"}") == {u"foo":u"bar"};
    assert from_yaml("{\"foo\":\"bar\", \"baz\":\"bam\"}") == {u"foo":u"bar", "baz":u"bam"};
    assert from_yaml("{\"foo\":\"bar\", \"baz\":\"bam\"}") == {u"foo":u"bar", "baz":u"bam"};

# Generated at 2022-06-20 23:42:12.588735
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    import tempfile

    def _load(data, **kwargs):
        with tempfile.NamedTemporaryFile() as f:
            f.write(data.encode('utf-8'))
            f.flush()
            return from_yaml(data, file_name=f.name, **kwargs)

    vault_secrets = [ VaultLib.DecryptionKey(None, 'passphrase', 'sha256:c4b2a4f6b3d1a3ea6a9e6e943a6e0014') ]

    # Test VaultLib
    data = '''
this:
  is:
    - a
    - test
'''
    value = None

# Generated at 2022-06-20 23:42:21.762659
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    # YAML Syntax
    - 1_item
    - 2_item
    - 3_item
    '''
    assert from_yaml(yaml_str) == [
        '1_item',
        '2_item',
        '3_item'
    ]
    json_str = '''
    {
        "key_1": "value_1",
        "key_2": "value_2"
    }
    '''
    assert from_yaml(json_str) == json.loads(json_str)


# Generated at 2022-06-20 23:42:30.404966
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Simple unit tests for function from_yaml
    '''
    import pytest

    def test_nonjson_yaml():
        yaml_strings = [
            "foo: bar",
            "list_var: [one, two, three]",
            "dict_var: {foo: bar}",
            "dict_var: { one: bar, two: three}",
            "{ one: bar, two: three}",
            "one: bar",
        ]
        for yaml_str in yaml_strings:
            result = from_yaml(yaml_str, show_content=False, vault_secrets=None, json_only=False)
            assert isinstance(result, dict)


# Generated at 2022-06-20 23:42:33.618109
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"some_data": "This is some data"}'
    parsed_data = from_yaml(data)
    assert parsed_data == {"some_data": "This is some data"}

# Generated at 2022-06-20 23:42:46.636001
# Unit test for function from_yaml
def test_from_yaml():
    json_valid = '{"a": 1}'
    json_invalid = '{"a": 1'
    yaml_valid = 'a: 1'
    yaml_invalid = 'a: 1\nb: 2'

    new_data = from_yaml(json_valid, json_only=True)
    assert new_data == json.loads(json_valid)
    try:
        new_data = from_yaml(json_invalid)
        assert False
    except AnsibleParserError:
        pass

    new_data = from_yaml(yaml_valid)
    assert new_data == json.loads(json_valid)
    try:
        new_data = from_yaml(yaml_invalid)
        assert False
    except AnsibleParserError:
        pass


# Generated at 2022-06-20 23:42:58.203022
# Unit test for function from_yaml
def test_from_yaml():
    def _check_from_yaml(data):
        assert from_yaml(data) == json.loads(data)
    yield _check_from_yaml, '{"a": 1, "b": 2}'
    yield _check_from_yaml, '---\na: 1\nb: 2\n'
    yield _check_from_yaml, '---\na: 1\nb: 2\n...\n'
    yield _check_from_yaml, '''\
---
a: 1
b: 2
...
'''
    yield _check_from_yaml, '''\
---
a: 1
b: 2
'''


# Generated at 2022-06-20 23:43:08.256516
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test for function from_yaml
    '''
    data = '{"key1":"value1", "key2":"value2"}'
    data = from_yaml(data)
    assert 'value1' == data['key1']
    assert 'value2' == data['key2']

    data = '''
    - 1
    - 2
    - 3
    '''
    data = from_yaml(data)
    assert [1, 2, 3] == data

    data = '''
    - { key: value }
    '''
    data = from_yaml(data)
    assert 'value' == data[0]['key']

# Generated at 2022-06-20 23:43:17.867116
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import OrderedDict
    try:
        import __builtin__ as builtins
        builtins_name = '__builtin__'
    except ImportError:
        import builtins
        builtins_name = 'builtins'

# Generated at 2022-06-20 23:43:32.361692
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.constructor import AnsibleConstructorError
    json_only = False
    # Test success
    assert from_yaml('[{ "item_1": 1, "item_2": ["a", "b"] }]', 'string', False, None, json_only)
    assert from_yaml('[item_1, item_2]', 'string', False, None, json_only)
    assert from_yaml('{ "item_1": 1, "item_2": ["a", "b"] }', 'string', False, None, json_only)
    assert from_yaml('{ "item_1": 1, "item_2": ["a", "b"] }\n', 'string', False, None, json_only)

# Generated at 2022-06-20 23:43:42.431201
# Unit test for function from_yaml
def test_from_yaml():
    class FakeSecrets(object):
        def __init__(self, secrets):
            self.secrets = secrets

        def get_text(self, token, allow_blank=False):
            return self.secrets.get(token)

    # Test with valid json string
    data = '{"key": "value"}'
    expected = {'key': 'value'}
    datastructure = from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None)
    assert datastructure == expected
    datastructure = from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=True)
    assert datastructure == expected

    # Test with valid yaml string
    data = 'key: value'
    expected

# Generated at 2022-06-20 23:43:44.817327
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('''"{"a": [1,3,4]}", key: value''')

# Generated at 2022-06-20 23:43:56.346671
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{foo: bar}') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('foo: [bar, baz]') == {'foo': ['bar', 'baz']}
    assert from_yaml('foo: bar', json_only=True) is None
    assert from_yaml('{foo: bar}', json_only=True) is None
    assert from_yaml('{foo: bar,}', json_only=True) is None
    assert from_yaml('{foo: bar', json_only=True) is None

# Generated at 2022-06-20 23:44:02.567147
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    data = """
    foo: bar
    baz:
      - one
      - two
    """
    ret = from_yaml(data)
    assert isinstance(ret, AnsibleMapping)
    assert ret == {'foo': 'bar', 'baz': ['one', 'two']}

    data = "['one', 'two']"

    ret = from_yaml(data)
    assert isinstance(ret, AnsibleSequence)
    assert ret == ['one', 'two']


# Generated at 2022-06-20 23:44:15.298883
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from lib.constants import DEFAULT_VAULT_ID_MATCH
    from test.support.helpers import TemplateVars

    class AnsibleFromYamlTestCase(unittest.TestCase):
        def setUp(self):
            ''' unit test for function from_yaml. '''

            self.template_vars = TemplateVars(vault_pass='secret password')

        def tearDown(self):
            pass

        def test_from_yaml_list_string(self):
            ''' test from_yaml with a list of strings. '''
            data = "['a', 'b', 'c']"
           

# Generated at 2022-06-20 23:44:19.264808
# Unit test for function from_yaml
def test_from_yaml():    
    try:
        data = """
- name: india
  age: 20
  location: bengaluru
- name: usa
  age: 30
  location: texas
        """
        from_yaml(data)
    except Exception as e:
        print(e)

# Generated at 2022-06-20 23:44:30.283971
# Unit test for function from_yaml
def test_from_yaml():

    # Test JSON strings
    data = '{"hello": "world"}'
    result = from_yaml(data)
    assert result == {"hello": "world"}

    # Test normal YAML
    data = 'hello: world'
    result = from_yaml(data)
    assert result == {"hello": "world"}

    # Test multiline YAML with embedded newlines
    data = '''welcome: "hello,
    my friend"'''
    result = from_yaml(data)
    assert result == {"welcome": "hello,\n    my friend"}

    # Test YAML lists
    data = '''welcome:
    - hello
    - my friend
    '''
    result = from_yaml(data)
    assert result == {"welcome": ["hello", "my friend"]}

# Generated at 2022-06-20 23:44:42.278204
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    class MyDict(AnsibleMapping):
        pass

    yaml.add_representer(MyDict, yaml.dumper.SafeRepresenter.represent_dict)
    yaml.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                         lambda loader, node: loader.construct_pairs(node))
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.vault import VaultEditor

    vault_password = '123'
    vault_id = 'test-vault'

# Generated at 2022-06-20 23:44:50.965301
# Unit test for function from_yaml
def test_from_yaml():
    json_data = [{"foo": "bar"}]
    yaml_data = """[
    {
        foo: bar
    }
]"""
    decoded_data = AnsibleJSONDecoder().decode(json_data)
    decoded_data == from_yaml(yaml_data, json_only=False)


# Unit test to ensure that when correct YAML is supplied, the parser does not fail

# Generated at 2022-06-20 23:44:57.678454
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = ('# Here is a comment\n\n'
                 '- hosts: localhost\n'
                 '  tasks:\n'
                 '  - debug: msg="ok"\n')

    test_json = ('{"hosts": "localhost", "tasks": ['
                 '{"debug": {"msg": "ok"}}]}')

    assert from_yaml(test_yaml) == from_yaml(test_json)

# Generated at 2022-06-20 23:45:06.551716
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.six.moves.configparser

    data = '{test_key1: "test1", test_key2: "test2", test_key3: "test3"}'
    data1 = 'test_key1: test1\n_test_key2: test2\ntest_key3:\n- test3\n- test3\n'

    yaml_data = from_yaml(data, '<string>')
    assert yaml_data["test_key1"] == "test1"
    assert yaml_data["test_key2"] == "test2"
    assert yaml_data["test_key3"] == "test3"

    yaml_

# Generated at 2022-06-20 23:45:18.211352
# Unit test for function from_yaml
def test_from_yaml():
    # test for yaml and json
    data_dict = {u'k1': u'v1', u'k2': u'v2'}
    data_json = '{"k1": "v1", "k2": "v2"}'
    data_yaml = 'k1: v1\nk2: v2\n'

    j1 = from_yaml(data_dict)
    assert(j1 == data_dict)
    j2 = from_yaml(data_json)
    assert(j2 == data_dict)
    j3 = from_yaml(data_yaml)
    assert(j3 == data_dict)

    # test for yaml syntax error
    data_yaml = 'k1: v1\nk2: v2'

# Generated at 2022-06-20 23:45:28.642332
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("") == None
    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []
    assert from_yaml("2") == 2
    assert from_yaml("2.2") == 2.2
    assert from_yaml("\"abc\"") == "abc"
    assert from_yaml("true") == True
    assert from_yaml("false") == False
    assert from_yaml("null") == None
    assert from_yaml("a: b") == {"a": "b"}
    assert from_yaml("a: b\nc: d") == {"a": "b", "c": "d"}

# Generated at 2022-06-20 23:45:39.702440
# Unit test for function from_yaml
def test_from_yaml():
    #basic usage
    json_string = '{"key":"value"}'
    json_dict = {"key":"value"}
    assert isinstance(from_yaml(json_string), dict) == True
    assert from_yaml(json_string) == json_dict
    #basic usage
    yaml_string = 'key: value'
    yaml_dict = {"key":"value"}
    assert isinstance(from_yaml(yaml_string), dict) == True
    assert from_yaml(yaml_string) == yaml_dict
    #from_yaml can handle json and yaml input, parse dicts and lists, and handle nested dicts and lists
    smol_string = '''
    [{"key1":"value1"}, {"key2":"value2"}]
    '''

# Generated at 2022-06-20 23:45:50.843019
# Unit test for function from_yaml
def test_from_yaml():
    import json
    import sys
    import yaml

    # JSON only
    test_json = '''{
        "test_json": "value"
    }'''
    test_result = {'test_json': 'value'}

    if sys.version_info[0] == 2:
        result = from_yaml(test_json, show_content=False, json_only=True)
        assert isinstance(result, dict)
        assert result == test_result

    # YAML only
    test_yaml = '''
    test_yaml: value
    '''
    test_result = {'test_yaml': 'value'}

    result = from_yaml(test_yaml, show_content=False, json_only=False)
    assert isinstance(result, dict)
    assert result

# Generated at 2022-06-20 23:45:54.650399
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    ---
    meta:
      protocol: http
      port: 8000
    '''
    result = from_yaml(data)
    expected_result = {'meta' : {'protocol' : 'http', 'port' : 8000 }}
    assert result == expected_result

# Generated at 2022-06-20 23:46:02.313922
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import files
    for file, expected in [
            ('./test/units/parsing/yaml/yaml_data_good.txt', [{'some': 'test_data'}, None, 'test', True, False]),
            ('./test/units/parsing/yaml/yaml_data_bad.txt', 'Invalid Vault encrypted data')
    ]:
        assert from_yaml(files.read_file(file)) == expected, "Unable to parse valid YAML in file %s." % file



# Generated at 2022-06-20 23:46:08.839852
# Unit test for function from_yaml
def test_from_yaml():
    # Test parse of yaml string containing '- !vault |\n          $ANSIBLE_VAULT;'
    from_yaml('---\n- hosts: all\n  gather_facts: false\n  vars:\n    no_log: false\n  tasks:\n  - name: "Test role"\n    include_role:\n      name: test.role\n    vars:')

# Generated at 2022-06-20 23:46:16.744941
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = """
    test_yaml:
      - name: item 1
        value: foo
      - name: item 2
        value: bar
    """


# Generated at 2022-06-20 23:46:28.060728
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    import os
    import stat

    def _rand_vault_id():
        import random
        import string
        chars = string.ascii_letters + string.digits
        size = random.randint(1, 32)
        return ''.join(random.choice(chars) for _ in range(size))

    def _make_tempfile():
        (fd, path) = tempfile.mkstemp()
        os.close(fd)
        return path

    def _rm_if_exists(path):
        if os.path.exists(path):
            os.unlink(path)


# Generated at 2022-06-20 23:46:39.383714
# Unit test for function from_yaml
def test_from_yaml():

    from sys import version_info
    if version_info < (2, 7):
        return

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    if hasattr(loader, 'set_vault_secrets'):
        loader.set_vault_secrets([])

    ret = from_yaml('{ "var": "value" }', file_name='<string>', show_content=True,
                    vault_secrets=None, json_only=False)
    assert ret == {'var': 'value'}

    ret = from_yaml('{ "var": "value" }', file_name='<string>', show_content=True,
                    vault_secrets=None, json_only=True)
    assert ret == {'var': 'value'}

   

# Generated at 2022-06-20 23:46:46.596116
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("---\n- {}") == [{}]
    assert from_yaml("{}", json_only=True) == {}
    #FIXME: https://github.com/ansible/ansible/issues/39565
    #assert from_yaml("{}", json_only=True) == {'json_only': True}
    assert from_yaml("---\n- {}", json_only=True) == [{}]

if __name__ == "__main__":
    import nose
    import sys
    sys.argv.append('--verbose')
    sys.argv.append('--nocapture')
    nose.runmodule()

# Generated at 2022-06-20 23:46:59.337657
# Unit test for function from_yaml
def test_from_yaml():
    
    # 1. Positive test case
    yaml_string = "this_is_a_key: this_is_a_value"
    yaml_dict = from_yaml(yaml_string)
    assert yaml_dict["this_is_a_key"] == "this_is_a_value"
    
    # 2. Negative test case
    yaml_string = "this_is_a_key: this_is_a_value {"
    try:
        from_yaml(yaml_string)
        assert False, "Expected ParseError"
    except YAMLError as e:
        pass

    # 3. Negative test case for json input
    json_string = '{"this_is_a_key": "this_is_a_value"'

# Generated at 2022-06-20 23:47:08.479351
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic sanity check to ensure from_yaml() works with both JSON
    and YAML strings.
    '''
    simple_json = '{"foo": [0.1, false]}'
    simple_yaml = '''
      foo:
        - 0.1
        - false
    '''

    # test JSON
    data = from_yaml(simple_json)
    assert data == {'foo': [0.1, False]}

    # test YAML
    data = from_yaml(simple_yaml)
    assert data == {'foo': [0.1, False]}


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:47:10.229135
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "foo": "bar" }'
    d = from_yaml(data)
    assert d['foo'] == 'bar'

# Generated at 2022-06-20 23:47:22.539545
# Unit test for function from_yaml
def test_from_yaml():
    # Test data 1
    data = '''
    ---
    - name: "{{ inventory_hostname }}"
      python:
        version: 2.7
      keys:
        - ssh-rsa XYZABC
      something: "{{ var1 }}"
      somethingelse: "{{ other_variable }}"
      flags:
        - key1=val1
        - key2=val2
    '''

    # Expected data 1
    expected = [{"name": "{{ inventory_hostname }}",
                 "python": {"version": 2.7},
                 "keys": ["ssh-rsa XYZABC"],
                 "something": "{{ var1 }}",
                 "somethingelse": "{{ other_variable }}",
                 "flags": ["key1=val1", "key2=val2"]}]

    # Test data 2


# Generated at 2022-06-20 23:47:26.717398
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1,2,3]") == [1,2,3]
    assert from_yaml("[1,2,3]", show_content=False) == [1,2,3]
    assert from_yaml("[1,2,3]", json_only=True) == [1,2,3]
    assert from_yaml("[1,2,3]", json_only=True, show_content=False) == [1,2,3]
    assert from_yaml("{'a':1}", json_only=True) == {"a": 1}
    assert from_yaml("{'a':1}", json_only=True, show_content=False) == {"a": 1}

# Generated at 2022-06-20 23:47:35.180813
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": 1, "b": 2}'
    assert from_yaml(data) == {"a": 1, "b": 2}
    assert from_yaml(data, json_only=True) == {"a": 1, "b": 2}

    data = '"foo"'
    is_equal = True
    try:
        from_yaml(data)
        is_equal = False
    except:
        pass
    assert is_equal is True

    data = '"foo"'
    assert from_yaml(data, json_only=True) == "foo"

    data = '{"a": 1, "b": 2}'
    assert from_yaml(data) == {"a": 1, "b": 2}

    data = '{"a": 1, "b": 2}'
    assert from_

# Generated at 2022-06-20 23:47:48.150474
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    key: "value"
    num: 50
    """
    d = from_yaml(data, file_name="test")
    assert isinstance(d, dict)
    assert d == {u"key": u"value", u"num": 50}

    try:
        from_yaml("fail", json_only=True)
        assert False
    except AnsibleParserError:
        pass

    try:
        from_yaml("fail")
        assert False
    except AnsibleParserError:
        pass

    try:
        from_yaml("[1,2")
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:47:54.159782
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml as test_from_yaml
    data = '''
- foo: bar
  bam: |
    one
    two
- bar: baz
  zoo: true
    '''

    expected = [
        {'foo': 'bar', 'bam': 'one\ntwo\n'},
        {'bar': 'baz', 'zoo': True},
    ]

    assert expected == test_from_yaml(data)

# Generated at 2022-06-20 23:47:54.895891
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("1") == 1

# Generated at 2022-06-20 23:48:00.532679
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.vars import merge_hash

    orig_dict = dict(
        a='test 1',
        b='test 2',
        c=dict(
            d='test 3',
            e=dict(
                h=dict(
                    i='test 4',
                    j='test 5',
                ),
                f=dict(
                    k=dict(
                        l='test 6',
                    ),
                    m=dict(
                        n='test 7',
                    ),
                ),
            ),
        ),
    )


# Generated at 2022-06-20 23:48:13.101560
# Unit test for function from_yaml
def test_from_yaml():
    ''' test_from_yaml
    Unit test for function from_yaml.
    '''

    assert from_yaml('{ "test": "data" }') == from_yaml('{ "test": "data" }', json_only=True)


# Generated at 2022-06-20 23:48:24.829901
# Unit test for function from_yaml
def test_from_yaml():

    json_input = u'{"name": "value", "name2": 2, "name3": true, "name4": null}'
    json_expected_data = {'name': 'value', 'name2': 2, 'name3': True, 'name4': None}
    json_data = from_yaml(json_input, json_only=True)
    assert json_data == json_expected_data

    yaml_input = u'name: value\nname2: 2\nname3: true\nname4: null'
    yaml_expected_data = {'name': 'value', 'name2': 2, 'name3': True, 'name4': None}
    yaml_data = from_yaml(yaml_input)
    assert yaml_data == yaml_expected_data

# Generated at 2022-06-20 23:48:26.876603
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''{"test":"test"}''') == {"test":"test"}



# Generated at 2022-06-20 23:48:31.959833
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{"a": "1"}')
    from_yaml('{"a": "1"}', file_name='test', show_content=True, vault_secrets=None, json_only=False)
    from_yaml('{"a": "1"}', json_only=True)

# Generated at 2022-06-20 23:48:40.358632
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader

    data = '{"test": "1"}'
    data_nojson = 'test: 1'
    data_invalidjson = '{"test": "1}'

    assert from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=True) == {"test": "1"}
    assert from_yaml(data_nojson, file_name='<string>', show_content=True, vault_secrets=None, json_only=True) is None

    # NOTE: ansible.parsing.ajson.AnsibleJSONDecoder() call json.loads(data_invalidjson,

# Generated at 2022-06-20 23:48:52.267727
# Unit test for function from_yaml
def test_from_yaml():
    # negative
    try:
        from_yaml('{"one":"two"')
    except AnsibleParserError as e:
        pass
    else:
        raise AssertionError('AnsibleParserError has not been raised')
    # positive
    assert from_yaml('{"one":"two"}') == {"one": "two"}
    assert from_yaml('{"one": "two"}') == {"one": "two"}
    assert from_yaml('{"one": "two"}', json_only=True) == {"one": "two"}
    assert from_yaml('one: two') == {"one": "two"}
    assert from_yaml('one: [two]') == {"one": ["two"]}
    assert from_yaml('one: {two:three}') == {"one": {"two": "three"}}


# Generated at 2022-06-20 23:48:59.412040
# Unit test for function from_yaml
def test_from_yaml():
    test_string = "test:test"
    test_dict = from_yaml(test_string)
    assert test_dict == {'test':'test'}, "yaml string not parsed correctly in from_yaml"

# Generated at 2022-06-20 23:49:10.252640
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test simple YAML parsing
    yaml_data = """
    foo: bar
    baz:
      - 1
      - 2
      - 3
    """
    parsed_data = from_yaml(yaml_data)

    assert parsed_data['foo'] == 'bar'
    assert parsed_data['baz'] == [1, 2, 3]

    # Test basic vault parsing

# Generated at 2022-06-20 23:49:21.045804
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = """
    - hosts: all
      remote_user: foo
      tasks:
      - name: bar
        debug: msg="hello world"
    """
    json_str = """
    {
      "hosts": "all", 
      "remote_user": "foo", 
      "tasks": [
        {
          "debug": "msg=\"hello world\"", 
          "name": "bar"
        }
      ]
    }
    """

    # Test that from_yaml can load yaml
    yaml_data = from_yaml(yaml_str)
    assert 'hosts' in yaml_data
    assert 'all' == yaml_data['hosts']
    assert 'remote_user' in yaml_data

# Generated at 2022-06-20 23:49:28.295752
# Unit test for function from_yaml
def test_from_yaml():
    # Tests that a JSON input is parsed correctly
    json_data = '''
    {
        "foo": "bar",
        "baz": [ "a", "b", "c" ]
    }
    '''
    assert from_yaml(json_data)["foo"] == "bar"
    assert from_yaml(json_data)["baz"] == [ "a", "b", "c" ]

    # Tests that a YAML input is parsed correctly
    yaml_data = '''
    ---
    foo: "bar"
    baz: [ "a", "b", "c" ]
    '''
    assert from_yaml(yaml_data)["foo"] == "bar"

# Generated at 2022-06-20 23:49:36.437301
# Unit test for function from_yaml
def test_from_yaml():

    json_string = '''
        {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        }
        '''

    yaml_string = '''
        key1: value1
        key2: value2
        key3: value3
        '''

    assert from_yaml(json_string) == json.loads(json_string)
    assert from_yaml(yaml_string) == yaml.load(yaml_string)



# Generated at 2022-06-20 23:49:45.717176
# Unit test for function from_yaml
def test_from_yaml():

    from .yamlcase import YamlTestCase
    from .yamlcase import get_str_from_file
    from .vault_helper import VaultHelper

    from ansible.utils.vars import combine_vars


# Generated at 2022-06-20 23:49:53.876397
# Unit test for function from_yaml
def test_from_yaml():
    str_yaml='[{ "name" : "first", "type" : "task" }]'
    str_json='[{ "name" : "first", "type" : "task" }]'
    str_json_with_bad='[{ "name" : "first", "type" : "task" }'
    str_yaml_with_bad='{ "name" "first" "type" "task" }'
    # Test that yaml is converted to dictionary
    assert type(from_yaml(str_yaml)) == list
    assert type(from_yaml(str_json)) == list
    # Test that the right ansibleparser error is being throw when wrong syntax
    # is used

# Generated at 2022-06-20 23:50:04.510467
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence
    # Test JSON
    data = '["foo","bar"]'
    results = from_yaml(data)
    assert type(results) == list
    assert results[0] == 'foo'
    assert results[1] == 'bar'

    # Test YAML
    data = "- foo\n- bar\n"
    results = from_yaml(data)
    assert type(results) == list
    assert results[0] == 'foo'
    assert results[1] == 'bar'

    # Test a few edge cases
    data = "foo"
    results = from_yaml(data)
    assert type(results) == str
    assert results == 'foo'

    data = "--- foo"

# Generated at 2022-06-20 23:50:13.554603
# Unit test for function from_yaml
def test_from_yaml():
    test_1 = '{"this is a json string": "this is a string"}'
    result1 = from_yaml(test_1)
    assert result1['this is a json string'] == 'this is a string'

    test_2 = '{"this is a json string": "this is a string"}'
    result2 = from_yaml(test_2, json_only=True)
    assert result2['this is a json string'] == 'this is a string'

    test_3 = '{"this is a json string": "this is a string"}'
    result3 = from_yaml(test_3, json_only=False)
    assert result3['this is a json string'] == 'this is a string'

    test_4 = 'this is not a json string'

# Generated at 2022-06-20 23:50:22.642074
# Unit test for function from_yaml
def test_from_yaml():
    '''
    In this function, we test the function from_yaml.
    '''
    from_yaml("{}")
    from_yaml("{}", json_only=True)
    from_yaml("{", json_only=True)
    from_yaml("[]")
    from_yaml("[]", json_only=True)
    from_yaml("[", json_only=True)
    from_yaml("foo")
    from_yaml("foo", json_only=True)
    from_yaml("- foo")
    from_yaml("- foo", json_only=True)

