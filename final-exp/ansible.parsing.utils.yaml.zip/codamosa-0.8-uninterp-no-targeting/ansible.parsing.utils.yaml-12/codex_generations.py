

# Generated at 2022-06-20 23:40:23.458343
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
    {
        "key": "value"
    }
    """, json_only=True) == {"key": "value"}

    assert from_yaml("""
    key: value
    """, json_only=True, show_content=False) == {"key": "value"}

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:40:29.210111
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    - foo: bar
      baz: qux
    - foo: bar
      baz: qux
    '''
    assert from_yaml(test_data) == [{'foo': 'bar', 'baz': 'qux'}, {'foo': 'bar', 'baz': 'qux'}]



# Generated at 2022-06-20 23:40:39.263614
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils import basic

    data = """
     {
        "default": {
            "a": "b"
        },
        "one": {
            "a": "b",
            "c": "d"
        }
     }
    """
    result = from_yaml(data, json_only=True)
    assert type(result) == dict
    assert len(result) == 3
    with basic.qunit.test("json_only gives back JSON"):
        assert type(result.get("default")) == dict
        assert len(result.get("default")) == 1
        assert result.get("default").get("a") == "b"

    data = """
    ["a", "{{ b }}", "c", "d"]
    """

# Generated at 2022-06-20 23:40:50.419457
# Unit test for function from_yaml
def test_from_yaml():

    data = '''
    # this is a yaml file with some # comments
    first:
        - 1
        - 2
        - 3
        - 4
    second:
        - 5
        - 6
        - 7
        - 8
    '''
    r1 = from_yaml(data)
    r2 = {'first': [1, 2, 3, 4], 'second': [5, 6, 7, 8]}
    assert r1 == r2, "Expected: %s\nGot: %s" % (r2, r1)

    data = '{"key1": "value1", "key2": "value2"}'
    r1 = from_yaml(data)
    r2 = {"key1": "value1", "key2": "value2"}

# Generated at 2022-06-20 23:41:01.276463
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test valid JSON and YAML as well as invalid JSON, invalid YAML and nonsensical input.
    '''

    # Valid JSON:
    result = from_yaml(data='{"key1":"value1", "key2":42, "key3":true, "key4":false, "key5":null}')
    assert(isinstance(result, dict))
    assert(result == {'key1': 'value1', 'key2': 42, 'key3': True, 'key4': False, 'key5': None})

    # Valid YAML:
    result = from_yaml(data='key1: value\nkey2:\n- item1\n- item2\nkey3:\n  subkey1: value1\n')
    assert(isinstance(result, dict))

# Generated at 2022-06-20 23:41:07.101793
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # AnsibleDumper is needed for testing as AnsibleLoader enforces vault-secrets
    # to be a dict, while the yaml parser may have other data types.

    vault_secrets = vault.VaultSecretParser(dict())
    vault_secrets.update_secrets('1', dict())
    vault_secrets.update_secrets('2', dict())
    vault_secrets.update_secrets('3', dict())
    vault_secrets.update_secrets('4', dict())


# Generated at 2022-06-20 23:41:19.947808
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils._text import to_native
    from ansible.parsing.ajson import AnsibleJSONDecoder

    # setting up vault
    class AnsibleVaultSecret(dict):
        def __init__(self, *args, **kwargs):
            super(AnsibleVaultSecret, self).__init__(*args, **kwargs)
            self.__dict__ = self

    secret = AnsibleVaultSecret()
    secret.data = "encryptedPassword"
    secret.rc = {}
    vault_secret = [secret]

    # Testing valid json
    assert from_yaml("{\"valid\":\"json\"}", vault_secrets=vault_secret) == {"valid": "json"}

    # Testing valid yaml

# Generated at 2022-06-20 23:41:23.346926
# Unit test for function from_yaml
def test_from_yaml():
    """
    >>> test_from_yaml()
    [u'foo']
    """

    data = '''
    ---
    - "foo"
    '''

    print(from_yaml(data))

# Generated at 2022-06-20 23:41:34.660537
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test - will test with valid and invalid YAML
    '''
    data = '''
name: test_hoge
version: 1.0
'''
    try:
        yml = from_yaml(data)
        # pylint: disable=unused-variable
        # Test passes if from_yaml() doesn't raise an exception
        test_passed = True

    except Exception as e:  # pylint: disable=broad-except
        assert False, 'from_yaml() raised an exception: {}'.format(str(e))

    data = '''
name: test_hoge
version: 1.0:
'''

# Generated at 2022-06-20 23:41:46.406130
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    assert sys.version_info >= (2, 7)
    assert from_yaml("{}", json_only=True) == {}
    assert from_yaml("{}") == {}
    assert from_yaml("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert from_yaml("{'a': 1, 'b': 2}", json_only=True) == {'a': 1, 'b': 2}
    assert from_yaml("{'a': 1, 'b': 2}", json_only=True) == {'a': 1, 'b': 2}

# Generated at 2022-06-20 23:41:59.131635
# Unit test for function from_yaml
def test_from_yaml():
    import os.path
    import inspect
    test_dir = os.path.dirname(inspect.getfile(inspect.currentframe()))
    test_file = os.path.join(test_dir, 'parse_yaml.yml')
    expected = {
        'foo': 'bar',
        'baz': {
            'a': 'b',
            'c': ['d', 'e', 'f'],
        },
        'dashes-in-key': True,
        'dashes-in-value': 'a-b-c',
        'hash': {
            '1': 'one',
            '2': 'two',
            '3': 'three',
        }
    }

    assert from_yaml(open(test_file).read()) == expected

# Generated at 2022-06-20 23:42:12.485251
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'{"a": 1}') == {u'a': 1}
    assert from_yaml(u'["a", "b"]') == [u'a', u'b']
    assert from_yaml(u'"a"') == u'a'
    assert from_yaml(u"---\n[a]\n") == [u'a']

    # This is a valid JSON string. yaml.safe_load() would see this as a Python
    # list, but we use JSON to determine the type and return a Python list.
    assert from_yaml(u'["a"]') == [u'a']

    assert from_yaml(u'["a"') == u'["a"'  # Invalid JSON

    # This is valid YAML, but not JSON.
    assert from_y

# Generated at 2022-06-20 23:42:23.840244
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible.parsing.yaml.dumper
    d = {
        'foo': 'bar',
        'bam': {
            'boo': ['a', 'b', 'c']
        }
    }
    d_as_string = ansible.parsing.yaml.dumper.AnsibleDumper().dump(d)
    assert to_native(from_yaml(d_as_string)) == d, \
        "from_yaml cannot successfully parse output from AnsibleDumper.dump"


# Generated at 2022-06-20 23:42:35.813790
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    stream = StringIO('foo')
    assert _safe_load(stream) == 'foo'
    stream.close()

    assert from_yaml('{}') == {}
    if PY3:
        assert from_yaml('\xef\xbb\xbf{}') == {}
    else:
        assert from_yaml(unicode('\xef\xbb\xbf{}', 'utf-8')) == {}

    assert from_yaml('---\nfoo\n...\n') == 'foo'
    assert from_yaml('foo:bar') == {'foo': 'bar'}


# Generated at 2022-06-20 23:42:41.153204
# Unit test for function from_yaml
def test_from_yaml():
    sample_dict = from_yaml("""
- hosts: localhost
  tasks:
    - debug:
        msg: 'Hello World!'
""")
    assert isinstance(sample_dict, list)
    assert isinstance(sample_dict[0], dict)

# Generated at 2022-06-20 23:42:42.890025
# Unit test for function from_yaml
def test_from_yaml():
    '''Test the from_yaml function'''
    pass

# Generated at 2022-06-20 23:42:49.303779
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing from_yaml")
    data = """
    - hosts: localhost
      tasks:
        - name: test
          debug: msg={{ variable }}
    """
    parsed_data = from_yaml(data)
    assert len(parsed_data) == 1
    assert parsed_data[0]['hosts'] == 'localhost'
    print("PASSED")

test_from_yaml()

# Generated at 2022-06-20 23:42:55.044410
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") is not None
    assert from_yaml("{}", vault_secrets=[{'data': 'foo', 'key': 'bar'}]) is not None
    assert from_yaml("{}", json_only=True) is not None



# Generated at 2022-06-20 23:43:07.966014
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import unquote
    if PY3:
        unicode_string = str
        byte_string = bytes
    else:
        unicode_string = unicode
        byte_string = str

    if sys.version_info[0] == 2:
        def b(x):
            return x
    else:
        import codecs

        def b(x):
            return codecs.latin_1_encode(x)[0]

    # Test that the string is not unicode
    assert isinstance(from_yaml("{}"), dict)

    # Test that the string is not unicode in Python

# Generated at 2022-06-20 23:43:16.138298
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    s = "string"
    u = AnsibleVaultEncryptedUnicode(s)
    # string
    assert from_yaml(s) == "string"
    # unicode
    assert from_yaml(u) == s
    # dict
    assert from_yaml("{'a':1}") == {'a': 1}
    # list
    assert from_yaml("['a']") == ['a']
    # none
    assert from_yaml("null") is None
    # empty string
    assert from_yaml("") == ""
    # integer
    assert from_yaml("1") == 1
    # float

# Generated at 2022-06-20 23:43:27.442475
# Unit test for function from_yaml
def test_from_yaml():
    string = "---\n- hosts: localhost\n  tasks:\n  - name: foo"
    data = from_yaml(string, '/fake/file/path.yaml')
    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert isinstance(data[0]['tasks'], list)
    assert isinstance(data[0]['tasks'][0], dict)
    assert data[0]['tasks'][0]['name'] == 'foo'

# Generated at 2022-06-20 23:43:37.505813
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
a: 1
b:
  - 2
  - 3
c:
  d: 4
'''
    file_name = '<test_file>'
    show_content = True
    vault_secrets = None
    json_only = False
    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert(new_data == {'a': 1, 'b': [2, 3], 'c': {'d': 4}})
    data = '{"a": 1, "b": ["2", "3"], "c": {"d": "4"}}'
    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)

# Generated at 2022-06-20 23:43:42.659269
# Unit test for function from_yaml

# Generated at 2022-06-20 23:43:49.222344
# Unit test for function from_yaml
def test_from_yaml():

    # create a YAML string
    yaml_string = '''
    ---
    foo: bar
    baz:
       - 1
       - 2
       - 3
    '''

    # try to load the string and check the results
    assert from_yaml(yaml_string) == {'foo': 'bar', 'baz': [1, 2, 3]}



# Generated at 2022-06-20 23:43:56.146624
# Unit test for function from_yaml
def test_from_yaml():
    key_value = {"foo": "bar"}
    assert(from_yaml(json.dumps(key_value)) == key_value)
    list_data = ["foo", "bar"]
    assert(from_yaml(json.dumps(list_data)) == list_data)
    str_data = "foobar"
    assert(from_yaml(str_data) == str_data)

# Test for missing variable

# Generated at 2022-06-20 23:44:03.715232
# Unit test for function from_yaml
def test_from_yaml():
  import os
  import sys
  import ansible.playbook.play_context


# Generated at 2022-06-20 23:44:15.809615
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, iteritems

    # Test for issues common to both JSON and YAML
    # NOTE: The test_from_yaml_* test functions below should be sufficient to
    #       cover these cases.

    # Test for YAML multiline
    yaml_data = """
- name: test1
  hash: '''
    - key1:  value1
    - key2:  value2
    '''
- name: test2
  hash:
    key1:  value1
    key2:  value2
    """

# Generated at 2022-06-20 23:44:24.024722
# Unit test for function from_yaml
def test_from_yaml():
    import datetime
    base_str = 'hello'
    assert from_yaml(base_str) == 'hello'
    double_str = '"hello"'
    assert from_yaml(double_str) == 'hello'
    triple_str = '""hello""'
    assert from_yaml(triple_str) == '"hello"'
    int_str = '42'
    assert from_yaml(int_str) == 42
    tuple_str = '[{"banana": 6, "apple": 1}]'
    assert from_yaml(tuple_str) == [{'banana': 6, 'apple': 1}]
    datetime_str = '2013-08-25 00:00:00'

# Generated at 2022-06-20 23:44:28.463139
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing from_yaml")
    from_yaml("lol: cat")
    from_yaml('{"foo": "bar"}')

# Run unit test for function from_yaml
if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:44:40.386664
# Unit test for function from_yaml
def test_from_yaml():
    data1='{"foo": "bar"}'
    data2="""
a: 1
b:
  c: 3
  d: 4
"""
    data3='{"a": "1", "b": ["c", "d"], "e": {"f": "g"}'
    data4='{ a : "1", b : [ "c", "d"], e : { f : "g"}'

    vault_secrets = ['AES', 'my secret']

    assert from_yaml(data1, vault_secrets=vault_secrets) == json.loads(data1)
    assert from_yaml(data2, vault_secrets=vault_secrets) == json.loads(data2)


# Generated at 2022-06-20 23:44:49.882636
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import yaml
        has_yaml = True
    except ImportError:
        has_yaml = False

    try:
        import json
        has_json = True
    except ImportError:
        has_json = False

    if not has_yaml:
        print("The yaml Python module is not installed. Skipping from_yaml tests.")
        return

    if not has_json:
        print("The json Python module is not installed. Skipping from_yaml tests.")
        return

    # Test successful JSON and YAML loads
    assert not from_yaml('[]')
    assert from_yaml('[]', json_only=True) == []
    assert from_yaml('[1,2,3]') == [1,2,3]

# Generated at 2022-06-20 23:44:59.693975
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts: all
      tasks:
      - debug: var=ansible_all_ipv4_addresses
    '''
    parsed_data = from_yaml(data.encode('utf-8'), file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    assert isinstance(parsed_data, list)
    assert parsed_data[0]['hosts'] == 'all'
    assert isinstance(parsed_data, list)
    assert parsed_data[0]['tasks'][0]['debug']['var'] == 'ansible_all_ipv4_addresses'


# Generated at 2022-06-20 23:45:06.606822
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')
    from_yaml('{ "foo": "bar" }')

# Generated at 2022-06-20 23:45:18.309734
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == json.loads('{}')
    assert from_yaml('{"foo": "bar"}') == json.loads('{"foo": "bar"}')
    assert from_yaml('[]') == json.loads('[]')
    assert from_yaml('{"foo": [1, 2, 3]}') == json.loads('{"foo": [1, 2, 3]}')
    assert from_yaml('[1, 2, 3]') == json.loads('[1, 2, 3]')
    assert from_yaml('[1, 2, 3]', json_only=True) == json.loads('[1, 2, 3]')
    assert from_yaml('foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-20 23:45:23.792946
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"key1":"value1", "key2": "value2"}'
    assert from_yaml(data) == {"key1": "value1", "key2": "value2"}
    data = '{"key1": "value1"}'
    assert from_yaml(data, json_only=True) == {"key1": "value1"}

# Generated at 2022-06-20 23:45:32.072053
# Unit test for function from_yaml
def test_from_yaml():
    # Older versions of PyYAML do not have the FullLoader, which means we have to make do with the base class.
    yaml_loader = getattr(yaml, 'FullLoader', yaml.BaseLoader)

# Generated at 2022-06-20 23:45:35.519026
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'b': ['c','d']}"
    try:
        new_data = from_yaml(data)
    except Exception as e:
        print(e)



# Generated at 2022-06-20 23:45:44.303324
# Unit test for function from_yaml
def test_from_yaml():
    import os

    current_dir = os.path.dirname(os.path.abspath(__file__))
    path_to_data = os.path.join(current_dir, "test_data/test_data.json")
    with open(path_to_data) as f:
        new_data = from_yaml(f, file_name=path_to_data, show_content=True)
        data_to_compare = {'hello': 'world', 'bye': 'world'}
        assert new_data == data_to_compare

# Generated at 2022-06-20 23:45:54.383199
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.display import Display
    class Options:
        def __init__(self, host_key_checking=False, verbosity=0):
            self.verbosity = verbosity
            self.host_key_checking = host_key_checking
    # Set up display
    display = Display()
    display.verbosity = 1
    # Set up options
    options = Options(verbosity=1)
    # Set up vault secrets
    vault_secrets = []
    # Set up result
    result = dict(data=None, err=None)

# Generated at 2022-06-20 23:46:02.204565
# Unit test for function from_yaml
def test_from_yaml():
    json_data = r'{"foo": "bar"}'
    yaml_data = "foo: bar"
    new_data = from_yaml(json_data)
    assert new_data["foo"] == "bar"
    new_data = from_yaml(yaml_data)
    assert new_data["foo"] == "bar"
    new_data = from_yaml(yaml_data, json_only=True)
    assert new_data is None

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:46:16.785638
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    class TestYAML(unittest.TestCase):
        def test_from_yaml(self):
            import tempfile
            file_handle, path = tempfile.mkstemp()
            try:
                os.write(file_handle, "--- { 'a': 'b' }\n".encode("utf-8"))
                os.close(file_handle)
                assert from_yaml("{ 'a': 'b' }", file_name=path) == {"a": "b"}
                assert from_yaml("- { 'a': 'b' }", file_name=path) == [{"a": "b"}]
            finally:
                os.remove(path)

    loader = unittest.TestLoader()

# Generated at 2022-06-20 23:46:28.108975
# Unit test for function from_yaml
def test_from_yaml():
    # Test various data types
    value = from_yaml("1001")
    assert value == 1001
    value = from_yaml("3.14")
    assert value == 3.14

    # Test string
    value = from_yaml("foobar")
    assert value == "foobar"

    # Test list
    value = from_yaml("[1,2,3,4,5]")
    assert value == [1,2,3,4,5]

    # Test dict
    value = from_yaml("foo: bar")
    assert value == dict(foo='bar')
    value = from_yaml("{'foo': 'bar', 'foo1': [1,2,3]}")
    assert value == dict(foo='bar', foo1=[1,2,3])

# Generated at 2022-06-20 23:46:39.684355
# Unit test for function from_yaml
def test_from_yaml():
    import collections
    import re
    import tempfile
    import shutil
    import pprint
    import os

    def _write_temp_file(content):
        f = tempfile.NamedTemporaryFile(mode='w', delete=False)
        f.write(content)
        f.close()
        return f.name

    def _read_temp_file(filename):
        with open(filename, 'r') as f:
            attributes = f.read()
        return attributes

    def _test_from_yaml(name, input_data, expected_data):
        tmp_file = _write_temp_file(input_data)

# Generated at 2022-06-20 23:46:41.302619
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []

# Generated at 2022-06-20 23:46:47.802219
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.parsing.yaml import objects
    from ansible.parsing.ajson import AnsibleJSONDecoder

    test_file = 'test/test_from_yaml.yaml'

    test_data = {'a': 1, 'b': 2, 'c': 'a'}
    test_string = """---
# this is a comment
a: 1
b: 2
c: 'a'
"""
    # The representation of OrderedDict is a bit unpredictable
    # this test was designed to fail without the correct patch
    # the empty space before 'a' is significant
    # if it breaks in the future, please replace by any other
    # unordered string representation
    # Python 3.5.4 (default, Nov 14 2017, 07

# Generated at 2022-06-20 23:47:00.400348
# Unit test for function from_yaml
def test_from_yaml():
    """
    This is a simple unit test for the from_yaml function.

    We use it to make sure the YAML and JSON parsers are both working.
    """
    data1 = """[1, 2, 3, 4]"""
    data2 = """- 1\n- 2\n- 3\n- 4"""
    assert(from_yaml(data1) == [1, 2, 3, 4])
    assert(from_yaml(data2) == [1, 2, 3, 4])
    assert(from_yaml(data1, json_only=True) == [1, 2, 3, 4])
    assert(from_yaml(data2, json_only=True) == [1, 2, 3, 4])

# Generated at 2022-06-20 23:47:10.159494
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    import pytest
    data = '''
 - a
 - b
'''
    assert isinstance(from_yaml(data), AnsibleSequence)

    data = '''
a: 1
b: 2
'''
    assert isinstance(from_yaml(data), AnsibleMapping)

    data = '''
a:
  - 1
  - 2
'''
    assert isinstance(from_yaml(data), AnsibleMapping)

    data = '''
a:
  - 1
  - 2
'''
    assert isinstance(from_yaml(data), AnsibleMapping)

    data = '''
- a
- b: 1
'''

# Generated at 2022-06-20 23:47:20.578652
# Unit test for function from_yaml
def test_from_yaml():
    # JSON parser error only
    result = from_yaml("{'test': 'json'}")
    assert result is None

    # YAML parser error only
    result = from_yaml("{test: 'yaml'}")
    assert result is None

    # Both parser errors
    result = from_yaml("{test: 'yaml'}")
    assert result is None

    # Valid JSON file
    result = from_yaml("{\"test\": \"json\"}")
    assert result == {"test": "json"}

    # Valid YAML file
    result = from_yaml("{test: 'yaml'}")
    assert result == {"test": "yaml"}

# Generated at 2022-06-20 23:47:30.725519
# Unit test for function from_yaml
def test_from_yaml():
    # Should not raise exception
    from_yaml(json.dumps(dict(a="a", b=dict(c="c"), d=[1,2,3])))

    # Should raise exception for invalid JSON
    try:
        from_yaml("{a='a', b={c='c'}, d=[1,2,3]}", json_only=True)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Should have raised AnsibleParserError")

    # Should not raise exception for valid YAML

# Generated at 2022-06-20 23:47:31.556573
# Unit test for function from_yaml
def test_from_yaml():
    ''' test_from_yaml '''
    pass

# Generated at 2022-06-20 23:47:52.264656
# Unit test for function from_yaml
def test_from_yaml():
    # From https://github.com/ansible/ansible/blob/devel/test/units/parsing/test_ajson.py
    assert from_yaml("['foo', 'bar']", json_only=True) == ['foo', 'bar']
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}

    # from https://github.com/cyberark/summon-aws-secrets/blob/develop/summon_aws_secrets/conjur.py
    vault_secrets = {'vault_password': 's3kr1t'}

# Generated at 2022-06-20 23:47:58.201390
# Unit test for function from_yaml
def test_from_yaml():
    import os

    basedir = os.getcwd()
    os.chdir("../../ansible/test/unit/parsing/")
    for yaml_file in filter(lambda f: f.endswith('yaml'), os.listdir(".")):
        with open(yaml_file, 'r') as f:
            yaml_str = f.read()
        python_obj = from_yaml(yaml_str)
        assert python_obj is not None, "%s conversion failed" % yaml_file
    os.chdir(basedir)
    print("Successfully parse all YAML files in ansible/test/unit/parsing/.")

# test_from_yaml()

# Generated at 2022-06-20 23:48:11.153054
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.ajson import AnsibleVaultEncryptedString

    import os
    import sys
    import io

    data = '''vars:
      var_name: 'myvar1:myvar1'
    hosts:
      "{{ var_name }}":
    '''

    data_json = '''{
      "vars": {
        "var_name": "myvar2:myvar2"
      },
      "hosts": {
        "{{ var_name }}": {}
      }
    }
    '''


# Generated at 2022-06-20 23:48:17.906336
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = '''
foo:
  - bar
  - baz
'''

    test_json = '''
{
  "foo": [
    "bar",
    "baz"
  ]
}
'''

    # Perform the test
    assert from_yaml(test_yaml) == from_yaml(test_json)

    # Perform the test
    test_yaml = '''
foo:
  - bar
  - baz
'''

    test_json = '''
{
  "foo": [
    "bar",
    "baz"
  ]
}
'''

    # Perform the test
    assert from_yaml(test_yaml) == from_yaml(test_json)

# Generated at 2022-06-20 23:48:25.494616
# Unit test for function from_yaml
def test_from_yaml():
    '''
    For the moment, just test if from_yaml() raises an AnsibleParserError
    when trying to load bad JSON and bad YAML.
    '''

    from ansible.errors import AnsibleParserError

    with pytest.raises(AnsibleParserError):
        from_yaml('{')

    with pytest.raises(AnsibleParserError):
        from_yaml('[')

    with pytest.raises(AnsibleParserError):
        from_yaml('')

# Generated at 2022-06-20 23:48:36.577722
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import ansible.constants
    from ansible.parsing.vault import VaultLib

    from_file = from_yaml

    test_utils_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'test_utils')
    if test_utils_dir not in sys.path:
        sys.path.insert(0, test_utils_dir)

    from unit.compat import unittest

    vault_stub = VaultLib([])

    def encrypt(var):
        return vault_stub.encrypt(var)


# Generated at 2022-06-20 23:48:49.024935
# Unit test for function from_yaml
def test_from_yaml():
    # !ansible_vault
    json_vault = '{"!vault": {"vault_secret": "Vault-token"}}'

    # !ansible_vault_string
    json_vault_string = '{"!vault |": "Vault-token"}'

    # !vault

# Generated at 2022-06-20 23:48:59.788562
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import unittest

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from _text import to_bytes

    FIXTURES_DIR = os.path.join(os.path.dirname(__file__), '..', 'fixtures')

    class TestFromYaml(unittest.TestCase):

        def _assert_encoded(self, data, encoding='utf-8'):
            if type(data) is dict:
                for k, v in data.items():
                    if isinstance(k, (str, bytes)):
                        self._assert_encoded(k, encoding)
                    if isinstance(v, (str, bytes)):
                        self._assert_encoded(v, encoding)

# Generated at 2022-06-20 23:49:08.647891
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    root_attr: 2
    - name: test1
      elem_attr: 3
    - name: test2
    '''

    data1 = '''
    - name: test1
      elem_attr: 3
    - name: test2
    '''

    result = [
        {'name': 'test1', 'elem_attr': 3},
        {'name': 'test2'}
    ]

    assert from_yaml(data)['root_attr'] == 2
    assert from_yaml(data)[0]['name'] == 'test1'
    assert from_yaml(data1) == result

# Generated at 2022-06-20 23:49:11.567579
# Unit test for function from_yaml
def test_from_yaml():
    yaml.load("""{
        'a':[1,2,3],
        'b':{'x':'y','z':[1,2,3]}
    }""")

# Generated at 2022-06-20 23:49:40.068854
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a JSON string
    result = from_yaml(u'{"a": {"b": {"c": "world"}}}')
    assert isinstance(result, dict)
    assert result['a']['b']['c'] == 'world'

    # Test with a YAML string
    result = from_yaml(u'a: {b: {c: world}}')
    assert isinstance(result, dict)
    assert result['a']['b']['c'] == 'world'

    # Test with a mixed JSON/YAML string
    result = from_yaml(u'{"a": {"b": {"c": "world"}}}', json_only=True)
    assert isinstance(result, dict)
    assert result['a']['b']['c'] == 'world'

    # Now

# Generated at 2022-06-20 23:49:48.881405
# Unit test for function from_yaml
def test_from_yaml():
    # Test 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n' \
    # Test 'JSON: %s\n\n%s' % (to_native(json_exc), n_yaml_syntax_error)
    yaml_data = "{'1': 2}"
    try:
        from_yaml(yaml_data)
    except AnsibleParserError as err:
        assert str(err).startswith('We were unable to read either as JSON nor YAML, these are the errors we got from each:')
        assert str(err).endswith('JSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)\n\nSyntax Error while loading YAML.\n  The error appears to have been in ')

    # Test 'Syntax

# Generated at 2022-06-20 23:49:59.160855
# Unit test for function from_yaml

# Generated at 2022-06-20 23:50:00.916595
# Unit test for function from_yaml
def test_from_yaml():
    assert "foo" in from_yaml("---\nfoo: bar")


# Generated at 2022-06-20 23:50:10.833830
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = """
    - hosts: localhost
      vars:
        var1: foo
      tasks:
      - name: test
        debug:
          msg: var1 is {{ var1 }}
    """

    json_data = """
    [
        {
            "hosts": "localhost",
            "vars": {
                "var1": "foo"
            },
            "tasks": [
                {
                    "debug": {
                        "msg": "var1 is {{ var1 }}"
                    },
                    "name": "test"
                }
            ]
        }
    ]
    """

    playbook_data = from_yaml(yaml_data)
    playbook_data_json = from_yaml(json_data)
    assert(playbook_data == playbook_data_json)

# Generated at 2022-06-20 23:50:17.647944
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml('asdf') == 'asdf')
    assert(from_yaml('4') == 4)
    assert(from_yaml('4.2') == 4.2)
    assert(from_yaml('{"a":"b"}') == {"a":"b"})