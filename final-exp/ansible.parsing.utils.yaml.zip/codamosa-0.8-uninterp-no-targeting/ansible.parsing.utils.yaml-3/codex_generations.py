

# Generated at 2022-06-20 23:40:25.812691
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test of from_yaml.
    '''
    data = '''
- hosts: localhost
  tasks:
  - name: "Check that pluto is NOT in the 'planets' list"
    assert:
      that:
        - "pluto" not in planets

    '''

    result = from_yaml(data)
    expected = [{'tasks': [{'assert': {'that': ['pluto not in planets']}, 'name': "Check that pluto is NOT in the 'planets' list"}], 'hosts': 'localhost'}]

    # Data must have the same structure of expected data
    assert(result[0]['hosts'] == expected[0]['hosts'])

# Generated at 2022-06-20 23:40:27.529667
# Unit test for function from_yaml
def test_from_yaml():
    pass

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:40:35.831481
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Testing if the json and yaml code work
    '''


# Generated at 2022-06-20 23:40:41.225043
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    ---
    a: 1
    b:
      - foo
      - bar
      - baz
    bla:
      - hello
      - world
    """

    answer = {
        'a': 1,
        'b': ['foo', 'bar', 'baz'],
        'bla': ['hello', 'world']
    }
    assert answer == from_yaml(test_data)
    print("OK!")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:40:44.356649
# Unit test for function from_yaml
def test_from_yaml():
    # testing with a dictionary
    data = '{"name": "value", "name2": "value2"}'
    new_data = from_yaml(data)
    assert type(new_data) is dict



# Generated at 2022-06-20 23:40:53.718326
# Unit test for function from_yaml
def test_from_yaml():
    # Test data with a few examples of direct container mapping and mapping
    # to a list
    data = '''
    # This is a comment and should be ignored
    key1: value1
    key2: value2
    key3:
    - value3.1
    - value3.2
    key4:
    - value4.1
    - key5: value5
      key6:
      - value6
    key7:
    - key8: value8
    key9:
      key10: value10
      key11: value11
    '''

    data = from_yaml(data)

    assert data
    assert type(data) == dict
    assert data.get('key1') == 'value1'
    assert data.get('key2') == 'value2'

# Generated at 2022-06-20 23:41:02.923867
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Normal text
    data = 'host: 10.1.1.1'
    data_dict = from_yaml(data)
    assert isinstance(data_dict, dict)
    assert 'host' in data_dict

    # Quoted text
    data = 'host: "10.1.1.1"'
    data_dict = from_yaml(data)
    assert isinstance(data_dict, dict)
    assert 'host' in data_dict
    assert isinstance(data_dict['host'], str)

    # Single quoted text
    data = "host: '10.1.1.1'"
    data_dict = from_yaml

# Generated at 2022-06-20 23:41:15.855417
# Unit test for function from_yaml
def test_from_yaml():
    # valid json string
    print(from_yaml('{"foo": "bar"}'))
    # valid yaml string
    print(from_yaml('foo: bar'))
    # valid json string without "
    print(from_yaml("{foo: 'bar'}"))
    # valid json string with ,
    print(from_yaml('{"foo": "bar", "hello": "world"}'))
    # valid yaml string with ,
    print(from_yaml('foo: bar, hello: world'))
    # valid sample
    print(from_yaml('{"foo": "bar", "grok": {"hello": ["world", "test"], "poppi": [1,2,3]}}'))
    # invalid json string
    print(from_yaml('{"foo: "bar"}'))
   

# Generated at 2022-06-20 23:41:24.125586
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a valid YAML string
    yaml_str = """
    foo: bar
    """
    data = from_yaml(yaml_str)
    assert isinstance(data, dict)
    assert data == {'foo': 'bar'}

    # Test with a valid JSON string
    json_str = '{"1": "one", "2": "two"}'
    data = from_yaml(json_str)
    assert isinstance(data, dict)
    assert data == {'1': 'one', '2': 'two'}

    # Test with an invalid string
    invalid_str = "foo: bar"
    raised = False
    try: from_yaml(invalid_str)
    except AnsibleParserError:
        raised = True
    assert raised is True

# Generated at 2022-06-20 23:41:31.682941
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml("{}") == {}
    assert from_yaml("{some: stuff}") == {'some': 'stuff'}
    assert from_yaml("stuff") == 'stuff'

    # FIXME: not sure why this doesn't work with assertRaises
    try:
        from_yaml("!stuff")
        assert False
    except AnsibleParserError as exc:
        assert 'AnsibleBaseYAMLObject' in str(exc)

# Generated at 2022-06-20 23:41:39.253486
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(from_yaml('{ "foo": "bar" }'), dict)
    try:
        from_yaml('{ "foo": "bar"')
    except AnsibleParserError:
        pass
    else:
        assert False, "Exception not raised"



# Generated at 2022-06-20 23:41:50.849800
# Unit test for function from_yaml
def test_from_yaml():
    # Test without passing file_name.
    my_list = from_yaml("[10, 20, 30]")
    assert my_list == [10, 20, 30]

    # Test passing file_name
    my_dict =  from_yaml("{\"a\": 10, \"b\": 20, \"c\": 30}", file_name="test.yml")
    assert my_dict == {"a": 10, "b": 20, "c": 30}

    # Test passing show_content as False
    my_dict = from_yaml("{\"a\": 10, \"b\": 20, \"c\": 30}", show_content=False)
    assert my_dict == {"a": 10, "b": 20, "c": 30}


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:42:00.737967
# Unit test for function from_yaml
def test_from_yaml():

    # Test that from_yaml method returns dictionary from YAML string
    import sys
    sys.modules['_ansible_test_failure'] = type('_ansible_test_failure', (Exception,), {})
    d = from_yaml('''
        some_key:
          - some_value
          - some_other_value
      ''')
    assert(d == {'some_key':['some_value', 'some_other_value']})

    # Test that from_yaml method returns dictionary from JSON string
    d = from_yaml('{"some_key":["some_value", "some_other_value"]}')
    assert(d == {'some_key':['some_value', 'some_other_value']})

    # Test that from_yaml method returns dictionary from JSON string
    #

# Generated at 2022-06-20 23:42:13.456430
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import unittest
    from ansible.module_utils._text import to_bytes

    class TestFromYaml(unittest.TestCase):
        def test_from_yaml_json(self):
            data = "{\"a\": [1,2,3], \"b\": 2, \"c\": 3}"
            output = from_yaml(data=to_bytes(data))
            self.assertIsNotNone(output)
            self.assertDictEqual(output, {"a": [1, 2, 3], "b": 2, "c": 3})

        def test_from_yaml(self):
            data = "{\"a\": [1,2,3], \"b\": 2, \"c\": 3}"
            output = from_yaml(data=to_bytes(data))
            self.assertIsNot

# Generated at 2022-06-20 23:42:24.619055
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {'foo': "bar"}
    assert from_yaml('["foo", "bar"]') == ['foo', "bar"]
    assert from_yaml('{"foo": 1}') == {'foo': 1}
    assert from_yaml('{"foo": 1.0}') == {'foo': 1.0}
    assert from_yaml('{"foo": true}') == {'foo': True}
    assert from_yaml('{"foo": false}') == {'foo': False}
    assert from_yaml('{"foo": [null]}') == {'foo': [None]}
    assert from_yaml('{"foo": ["bar", 42]}') == {'foo': ["bar", 42]}

# Generated at 2022-06-20 23:42:36.366052
# Unit test for function from_yaml
def test_from_yaml():
    # this is invalid YAML
    yaml_invalid = '''
        foo:
          bar: 1
          - baz
        '''
    try:
        from_yaml(yaml_invalid)
    except AnsibleParserError:
        pass

    # this is valid JSON.  Originally this was printed as 'null' due to
    # a bug in the old yaml parser, as it did not support multiple documents
    # in a single file
    json_valid = '{"foo":"bar"}\n---\n{"baz": "quox"}'
    new_data = from_yaml(json_valid)
    assert(new_data == [{'foo': 'bar'}, {'baz': 'quox'}])

    # test the json_only flag

# Generated at 2022-06-20 23:42:49.391077
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-20 23:43:03.377850
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-20 23:43:07.966012
# Unit test for function from_yaml
def test_from_yaml():
    s = """
a: 1
b:
- 2
- 3
"""
    exp_data = {u'a': 1, u'b': [2, 3]}
    act_data = from_yaml(s)

    assert act_data == exp_data


# Generated at 2022-06-20 23:43:13.231948
# Unit test for function from_yaml
def test_from_yaml():
    # Test passing a string
    result = from_yaml("{'first':'second'}")

    assert result.get('first') == 'second', "Did not get expected first value back"

    # Test passing a dictionary
    result = from_yaml({'first':'second'})

    assert result.get('first') == 'second', "Did not get expected first value back"


# Generated at 2022-06-20 23:43:30.527885
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader

    # Sample JSON string
    data = '{"SDK_VERSION": "1.0.0", "SDK_VERSION_IN_CONFIG": "{#SDK_VERSION#}", "ENVIRONMENT": "development"}'

    # Sample Vault encrypted string
    vault_secrets = {'vault_password_file': 'test'}

# Generated at 2022-06-20 23:43:35.561079
# Unit test for function from_yaml
def test_from_yaml():
    yamlstring = """
        # This is a YAML dictionary containing a string
        hello: world
    """
    assert (from_yaml(yamlstring) == {'hello': 'world'})

    jsonstring = """
        {
            "hello": "world"
        }
    """
    assert (from_yaml(jsonstring) == {'hello': 'world'})

# Generated at 2022-06-20 23:43:43.984341
# Unit test for function from_yaml
def test_from_yaml():
    data1 = "this is an invalid json"
    data2 = "{\"json_key\": \"json_value\"} this is invalid yaml"
    data3 = "this is also invalid yaml"
    data4 = "{\"json_key\": \"json_value\"}"

    try:
        from_yaml(data1)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("expected AnsibleParserError with invalid json")

    try:
        from_yaml(data2)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("expected AnsibleParserError with invalid yaml")

    try:
        from_yaml(data3, json_only=True)
    except AnsibleParserError:
        pass
    else:
        raise Assertion

# Generated at 2022-06-20 23:43:48.700998
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a json string
    data = '{"name": "John", "age": 30, "car": null}'
    expect_data = {"name": "John", "age": 30, "car": None}
    assert from_yaml(data) == expect_data

    # Test with a yaml string
    data = '''
    name: John
    age: 30
    car: null
    '''
    expect_data = {"name": "John", "age": 30, "car": None}
    assert from_yaml(data) == expect_data

    # Test with an invalid yaml string(remove the space between ': null')
    data = '''
    name: John
    age: 30
    car: null
    '''

# Generated at 2022-06-20 23:43:51.192136
# Unit test for function from_yaml
def test_from_yaml():
    assert {} == from_yaml('{}')
    assert {'foo': 'bar'} == from_yaml('{foo: bar}')

# Generated at 2022-06-20 23:44:01.148222
# Unit test for function from_yaml
def test_from_yaml():

    #from ansible.compat.tests import mock
    #with mock.patch.object(AnsibleJSONDecoder, 'set_secrets', return_value=None) as mock_set_secrets:
    #    mock_set_secrets.return_value = None

    #from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject as yamlobj
    yamlobj = AnsibleBaseYAMLObject

    try:
        #value = from_yaml(mock_set_secrets)
        value = from_yaml(yamlobj)
        #self.assertIsInstance(value, type(mock_set_secrets))
        #self.assertEqual(value.return_value, None)
    except (ImportError, AssertionError):
        from yaml import YAMLE

# Generated at 2022-06-20 23:44:06.158969
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    try:
        from_yaml("{'foo': 'bar'}", json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, "Expected AnsibleParserError"



# Generated at 2022-06-20 23:44:15.298494
# Unit test for function from_yaml
def test_from_yaml():
    #Negative case which throws an assert error
    try:
        from_yaml("{some: 'thing'}")
        assert False
    except AssertionError:
        assert True

    #Positive case
    assert from_yaml("{'some': 'thing'}") == {'some': 'thing'}
    assert from_yaml("{\"some\": \"thing\"}") == {'some': 'thing'}
    assert from_yaml("{\"some\": \"thing\"}", json_only=True) == {'some': 'thing'}

# Generated at 2022-06-20 23:44:21.455122
# Unit test for function from_yaml
def test_from_yaml():
    ret = from_yaml('', '<string>', True)
    assert ret is None, 'from_yaml returned incorrect value for empty string'

    ret = from_yaml('{}', '<string>', True)
    assert isinstance(ret, dict), 'from_yaml returned incorrect value for simple json'

    ret = from_yaml('---', '<string>', True)
    assert len(ret) == 0, 'from_yaml returned incorrect value for simple yaml'


# Generated at 2022-06-20 23:44:29.278533
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("{'foo': 'bar'}")
    assert result == {'foo': 'bar'}

    result = from_yaml("{'foo': 'bar'}", json_only=True)
    assert result == {'foo': 'bar'}

    try:
        from_yaml("{'foo': 'bar'}", '/tmp/foo.yml', False, None, True)
    except AnsibleParserError:
        pass

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:44:47.078459
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = "test.yaml"
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("[1, 2, 3]", test_yaml) == [1, 2, 3]

    json_yaml = "test.json"
    assert from_yaml("{\"a\":1}", json_yaml, json_only=True) == {"a": 1}
    try:
        assert from_yaml("{\"a\":1}", json_yaml, json_only=False) == {"a": 1}
    except AnsibleParserError as e:
        # Expect an error when we don't specify json_only
        pass


# Generated at 2022-06-20 23:44:54.526127
# Unit test for function from_yaml
def test_from_yaml():
    ajson = '{"key1": "val1", "key2": [0, 1, 2], "key3": {"key4": false, "key5": null}}'
    import yaml
    y = yaml.safe_dump(ajson)
    data = from_yaml(data=y)
    assert data == {"key1": "val1", "key2": [0, 1, 2], "key3": {"key4": False, "key5": None}}

# Generated at 2022-06-20 23:45:03.853022
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultSecret

    if PY2:
        test_string = StringIO("""---
a: 1
b:
- 2
- 3
""")
    else:
        test_string = StringIO("""---
a: 1
b:
- 2
- 3
""".encode('utf-8'))

    # FIXME: Ideally we'd use a mock class here, but this is better than nothing
    vault_secret = VaultSecret('secret', 'cipher', 'password')

    results = from_yaml(test_string, vault_secrets=vault_secret)

# Generated at 2022-06-20 23:45:08.290840
# Unit test for function from_yaml
def test_from_yaml():
    data = '''\
    {
        "a": "b",
        "c": "d"
    }'''

    out = from_yaml(data)

    assert out == {
        "a": "b",
        "c": "d"
    }

# Generated at 2022-06-20 23:45:14.895827
# Unit test for function from_yaml
def test_from_yaml():
    # No exceptions
    from_yaml("{}")
    from_yaml("[]")
    from_yaml("")

    # Quote exceptions

# Generated at 2022-06-20 23:45:24.439306
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml(r'["one", "two", "three"]'))
    print(from_yaml(r'{"one": 1, "two": 2, "three": 3}'))
    try:
        print(from_yaml(r'["one", "two", "three}'))
    except Exception as e:
        print(e)
    try:
        print(from_yaml(r'["one", "two", "three"]', json_only=True))
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:45:31.769782
# Unit test for function from_yaml
def test_from_yaml():
    data = '''\
    ---
    one:
        name: one
    two:
        name: two
        three:
            name: three
        four:
            - name: one
            - name: two
    '''

    result = from_yaml(data)

    assert result['one']['name'] == 'one'
    assert result['two']['name'] == 'two'
    assert result['two']['three']['name'] == 'three'
    assert result['two']['four'][0]['name'] == 'one'
    assert result['two']['four'][1]['name'] == 'two'

# vim: set expandtab ts=4 sw=4 ai

# Generated at 2022-06-20 23:45:42.381084
# Unit test for function from_yaml
def test_from_yaml():

    goodyaml = '''{"key":"value"}'''
    assert from_yaml(goodyaml) == {"key":"value"}

    goodyaml = '''{"key":"value"}
'''
    assert from_yaml(goodyaml) == {"key":"value"}

    goodyaml = '''
{"key":"value"}
'''
    assert from_yaml(goodyaml) == {"key":"value"}

    goodyaml = '''
{"key":"value"}
'''
    assert from_yaml(goodyaml) == {"key":"value"}

    goodyaml = '''
{"key":"value"}
'''
    assert from_yaml(goodyaml) == {"key":"value"}

# Generated at 2022-06-20 23:45:50.146984
# Unit test for function from_yaml
def test_from_yaml():

    # Test with different types of input data
    data = '{"a": "xxx"}'
    results = from_yaml(data)
    assert results == {"a": "xxx"}, "Test with JSON data"

    data = '{a: xxx}'
    results = from_yaml(data)
    assert results == {"a": "xxx"}, "Test with YAML data"

    data = '{a: xxx'
    try:
        from_yaml(data)
        assert False, "Test with YAML syntax error"
    except AnsibleParserError:
        assert True

# Generated at 2022-06-20 23:45:57.937585
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    if not hasattr(AnsibleUnicode, '__unicode__'):
        raise AssertionError("AnsibleUnicode needs to implement __unicode__")
    retval = from_yaml("foo: bar")
    assert type(retval) is dict
    assert retval.get('foo') == "bar"
    retval = from_yaml("foo:\n - bar")
    assert type(retval) is dict
    assert retval.get('foo') == ["bar"]
    retval = from_yaml("foo: bar", 'test data', False)
    assert type(retval) is dict
    assert retval.get('foo') == "bar"

# Generated at 2022-06-20 23:46:09.311337
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing from_yaml")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:46:18.428712
# Unit test for function from_yaml
def test_from_yaml():
    import sys

    # a simple test to ensure we can load YAML
    data = '''
    foo:
      - name: one
        val: 1
      - name: two
        val: 2
      - name: three
        val: 3
    '''

    # test with json only
    try:
        x = from_yaml(data, file_name='<string>', show_content=True, json_only=True)
        sys.exit("Should have thrown an exception")
    except AnsibleParserError:
        pass
    except Exception as e:
        sys.exit("wrong exception thrown:" + str(e))

    x = from_yaml(data, file_name='<string>', show_content=True)

# Generated at 2022-06-20 23:46:25.133172
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('[1,')
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not thrown"

    try:
        from_yaml('[1]', json_only=True)
    except AnsibleParserError:
        assert False, "Unexpected error"

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-20 23:46:35.777335
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret('secret')

    def test_func(data):
        return from_yaml(data, vault_secrets=secret)

    assert test_func("1") == 1
    assert test_func("{}") == {}
    assert test_func("{'foo': 'bar'}") == {'foo': 'bar'}
    assert test_func("{'foo': 'bar', 'baz': 'boo'}") == {'foo': 'bar', 'baz': 'boo'}
    assert test_func("{'foo': [1, 2, 3]}") == {'foo': [1, 2, 3]}
    assert test_func

# Generated at 2022-06-20 23:46:45.376354
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'{}') == {}
    assert from_yaml(u'{ "foo": "bar" }') == { 'foo': 'bar' }
    assert from_yaml(u'{ "foo": "bar" }') == json.loads(u'{ "foo": "bar" }')
    assert from_yaml(u'{ "foo": "baz" }', json_only=True) == { 'foo': 'baz' }
    assert from_yaml(u'foo: bar', json_only=True) is None
    assert from_yaml(u'{ "foo": "baz" }') == { 'foo': 'baz' }

    # Test exception

# Generated at 2022-06-20 23:46:58.274266
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import ast

    here = os.path.abspath(os.path.dirname(__file__))
    yaml1 = open(here + "/from_yaml1.yml")
    yaml2 = open(here + "/from_yaml2.yml")
    yaml3 = open(here + "/from_yaml3.yml")
    yaml4 = open(here + "/from_yaml4.yml")
    yaml5 = open(here + "/from_yaml5.yml")

    # Test .yml file where we can decode successfully as JSON or YAML
    assert ast.literal_eval(str(from_yaml(yaml1))) == {u'foo': u'bar'}

    # Test .yml file where we can decode successfully only as YAML

# Generated at 2022-06-20 23:47:06.545835
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    - name: server-one
      ip: 172.16.0.10
    - name: server-two
      ip: 172.16.0.20
    - name: server-three
      ip: 172.16.0.30
    - name: server-four
      ip: 172.16.0.40
    """

# Generated at 2022-06-20 23:47:15.023478
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    ---
    # this is a comment
    - one
    - two
    - {a: 1, b: 2}
    - [  1, 'string']
    - |
      multi-line
      YAML string
    '''
    result = from_yaml(data, 'test.yaml')
    assert result == [
        u'one',
        u'two',
        {u'a': 1, u'b': 2},
        [1, u'string'],
        u'multi-line\nYAML string\n'
    ]

# Generated at 2022-06-20 23:47:17.884964
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''
        # yaml doc
        - first
        - second''') == [ "first", "second" ]


# Generated at 2022-06-20 23:47:28.433507
# Unit test for function from_yaml
def test_from_yaml():
    # test regular yaml
    data = from_yaml("""
    - hosts: all
      roles:
        - conf.name
    """)
    assert data['roles'][0] == 'conf.name'

    # test a yaml list
    data = from_yaml("""
    - hosts: all
      roles:
        - conf.name
    - hosts: else
      roles:
        - else.roles
    """)
    assert data[0]['roles'][0] == 'conf.name'
    assert data[1]['roles'][0] == 'else.roles'
    data = from_yaml("""
    - tasks:
      - debug: msg='Hello World'
    - tasks:
      - debug: msg='Hello World2'
    """)

# Generated at 2022-06-20 23:47:55.413027
# Unit test for function from_yaml
def test_from_yaml():
    import types
    # Test 1, read valid json and yaml
    data1 = {'a': False, 'c': range(5), 'd': range(1,4)}
    assert(from_yaml(json.dumps(data1)) == data1)
    assert(from_yaml(data1) == data1)
    data2 = {'a': False, 'b': False, 'd': 'a string', 'e': ['a', 'string', 'list']}
    assert(from_yaml(json.dumps(data2)) == data2)
    assert(from_yaml(data2) == data2)
    data3 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 5: 2}

# Generated at 2022-06-20 23:48:07.907937
# Unit test for function from_yaml
def test_from_yaml():
    # Check handling of a YAML file with syntax error
    data = '{ a: 1 }'
    file_name = 'test.yaml'
    try:
        new_data = from_yaml(data, file_name)
    except AnsibleParserError as e:
        assert str(e).startswith('We were unable to read either as JSON nor YAML, these are the errors we got from each:')
        assert 'test.yaml:1,1' in str(e)
    else:
        raise Exception('AnsibleParserError not raised on a file with syntax error')

    # Check handling of a JSON file with syntax error
    data = '{ a: 1 }'
    file_name = 'test.json'

# Generated at 2022-06-20 23:48:16.865378
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with empty string
    result = from_yaml("")
    assert result is None

    # Test with YAML string
    yaml_string = '''
        ansible:
            host: localhost
        '''
    result = from_yaml(yaml_string)
    assert result == {u'ansible': {u'host': u'localhost'}}

    # Test with JSON string
    json_string = '''
        {
            "ansible": {
                "host": "localhost"
            }
        }
        '''
    result = from_yaml(json_string, "my_file")
    assert result == {u'ansible': {u'host': u'localhost'}}

# Generated at 2022-06-20 23:48:28.725767
# Unit test for function from_yaml
def test_from_yaml():
    import datetime

    # TODO: most of the following is probably not needed, so don't run these tests

    data = dict(
        test=dict(
            name='foo',
            version=dict(
                major=0,
                minor=12,
                patch=7,
            ),
            date=datetime.date(2014, 2, 22),
            features=dict(
                baz=False,
                qux=dict(
                    nested=True,
                ),
            ),
            extra=dict(
                list=[1, 2, True, 'foo', dict(bar=123, baz='hello world!')],
                dict=dict(foo='hello world!', bar=123),
            ),
        ),
    )

    # FIXME: this test needs to be adapted to fit new functionality
    #assert data == load('

# Generated at 2022-06-20 23:48:38.720526
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml '''

    # Note: the following test strings were chosen to test the parser code,
    #       not to test yaml or json compliance.  For example, there are
    #       some strings that are considered valid json, but are not useful
    #       as ansible strings, so we should probably not be parsing them
    #       ever.


# Generated at 2022-06-20 23:48:39.751259
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}

# Generated at 2022-06-20 23:48:51.942895
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == {}
    assert from_yaml('[]', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == []
    assert from_yaml('', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == {}
    assert from_yaml('{"a": 1}', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == {'a': 1}

# Generated at 2022-06-20 23:49:01.777423
# Unit test for function from_yaml
def test_from_yaml():
    # We check if the YAML parser correctly parses a dictionary, a list and a string.
    # For each of them, we check for a correct content and type.
    # Each test is also done with a faulty YAML syntax to check if we raise an exception

    assert from_yaml('d: 1') == {'d': 1}
    assert from_yaml('d: 1', json_only=True) == {'d': 1}
    assert from_yaml('\'') == '\''
    assert from_yaml('\'') == '\''
    assert from_yaml('{a: 1}') == {u'a': 1}
    assert from_yaml('[a, b]') == [u'a', u'b']

# Generated at 2022-06-20 23:49:13.060453
# Unit test for function from_yaml
def test_from_yaml():
    data = {'a': 'b'}
    # Convert to json
    data = json.dumps(data)
    # Convert back to dict
    data = from_yaml(data)
    assert data['a'] == 'b'
    data = '---\na: b\n'
    # Convert back to dict
    data = from_yaml(data)
    assert data['a'] == 'b'
    # Ensure we have error when we have invalid json
    data = '{"a: b}'
    try:
        from_yaml(data, json_only=True)
    except AnsibleParserError:
        pass
    else:
        raise('We should have failed here but did not')
    # Ensure we have error when we have invalid yaml
    data = '---\na: b\n}'

# Generated at 2022-06-20 23:49:19.148195
# Unit test for function from_yaml
def test_from_yaml():

    # Test JSON loading
    try:
        data = from_yaml('{"foo": "bar"}')
        assert data.get('foo') == 'bar'
    except:
        raise AssertionError('JSON failed to load')

    # Test YAML loading
    try:
        data = from_yaml('foo: bar')
        assert data.get('foo') == 'bar'
    except:
        raise AssertionError('YAML failed to load')

    # Test mixed
    try:
        data = from_yaml('{"foo": "bar"}\n---\nfoo: bar')
        assert data.get('foo') == 'bar'
    except:
        raise AssertionError('mixed failed to load')

    # Test failure

# Generated at 2022-06-20 23:50:06.167471
# Unit test for function from_yaml
def test_from_yaml():
    '''test_from_yaml'''
    assert from_yaml("hello world", "test") == "hello world"
    assert from_yaml("1", "test") == 1
    assert from_yaml("[1,2]", "test") == [1,2]
    assert from_yaml("{1:2}", "test") == {1:2}
    assert from_yaml("- hello world", "test") == ["hello world"]

    assert from_yaml("{'a':1, 'b':2}", "test") == {'a':1, 'b':2}
    assert from_yaml("{'a':1, 'b':'c:d'}", "test") == {'a':1, 'b':'c:d'}

# Generated at 2022-06-20 23:50:14.633411
# Unit test for function from_yaml
def test_from_yaml():

    from_yaml_data = from_yaml('{}')
    assert isinstance(from_yaml_data, dict) and not from_yaml_data

    from_yaml_data = from_yaml('[]')
    assert isinstance(from_yaml_data, list) and not from_yaml_data

    from_yaml_data = from_yaml('[ "a" ]')
    assert isinstance(from_yaml_data, list) and len(from_yaml_data) == 1

    try:
        from_yaml_data = from_yaml('foobar')
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    from_yaml_data = from_yaml('{ "a": "b" }')