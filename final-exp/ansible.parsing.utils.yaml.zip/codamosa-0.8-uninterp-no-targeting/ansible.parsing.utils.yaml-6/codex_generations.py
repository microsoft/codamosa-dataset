

# Generated at 2022-06-20 23:40:29.529653
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import os

    yaml_files = (
        "./test/module_utils/json_lookup_common.yml",
        "./test/module_utils/ec2_vault_credentials/ec2_vault_credentials.yml",
        "./test/module_utils/test_validate_modules.py",
        "./test/module_utils/validate_modules/test_accelerate.yml",
    )

    for yaml_file in yaml_files:
        with open(yaml_file) as f:
            yaml_content = f.read()
        print(f"Testing {yaml_file}")

# Generated at 2022-06-20 23:40:32.434464
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"hello": "world"}') == {'hello': 'world'}
    assert from_yaml('hello: world') == {'hello': 'world'}
    assert from_yaml('{hello: world') == {'hello': 'world'}

# Generated at 2022-06-20 23:40:41.286097
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    data = loader.load_from_file('test_file', 'tests/test_json_yaml_loader.data.yaml')
    assert len(data) == 3
    assert data[1]['var2'] == 22
    assert data[2]['var3'] == 333
    data = loader.load_from_file('test_file', 'tests/test_json_yaml_loader.data.json')
    assert len(data) == 3
    assert data[1]['var2'] == 22
    assert data[2]['var3'] == 333
    assert loader.load_from_file(None, None) == {}

# Generated at 2022-06-20 23:40:52.931816
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Ansible utils module tests.
    '''

    assert from_yaml(to_native({'some': 'json'})) == {'some': 'json'}

    assert from_yaml(to_native('{some: json}'), json_only=True) == {'some': 'json'}

    assert from_yaml(to_native('{some: json}'), json_only=True) == {'some': 'json'}

    assert from_yaml(to_native('---\n')) == u''

    assert from_yaml(to_native('{a: 1}'), json_only=True) == {'a': 1}

    assert from_yaml(to_native('{a: 1}')) == {'a': 1}


# Generated at 2022-06-20 23:40:56.935321
# Unit test for function from_yaml
def test_from_yaml():

    try:
        from_yaml('foo')
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML, these are the errors we got from each:" in e.message

# Generated at 2022-06-20 23:41:09.286688
# Unit test for function from_yaml
def test_from_yaml():
    # When JSON is passed, it should return data as JSON
    assert from_yaml('{"a": "b"}') == {"a": "b"}
    # When YAML is passed, it should return data as JSON
    assert from_yaml('a: b\nb: c') == {'a': 'b', 'b': 'c'}
    # When incorrect JSON is passed, it should raise AnsibleParserError
    try:
        from_yaml('a: b\nb: c', json_only=True)
        assert False, 'Expected AnsibleParserError'
    except AnsibleParserError:
        assert True
    finally:
        # Reset vault_secrets
        AnsibleJSONDecoder.set_secrets({})


# Generated at 2022-06-20 23:41:12.385314
# Unit test for function from_yaml
def test_from_yaml():
    ''' Test if it works with json and yaml '''
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:41:25.911503
# Unit test for function from_yaml
def test_from_yaml():

    def _test(data, expected, json_only=False):
        output = from_yaml(data, json_only=json_only)
        assert output == expected

    # Test that from_yaml correctly decodes JSON
    _test(
        data='''
{
    "foo": ["bar", "baz"],
    "xyzzy": {},
    "xyzzy2": {
        "xyzzy3": "xyzzy4"
    }
}
        ''',
        expected={
            'foo': ['bar', 'baz'],
            'xyzzy': {},
            'xyzzy2': {
                'xyzzy3': 'xyzzy4'
            }
        },
        json_only=False
    )

    # Test that from_yaml correctly decodes YAML

# Generated at 2022-06-20 23:41:35.807417
# Unit test for function from_yaml
def test_from_yaml():
    """ Unit test for function from_yaml()
    """
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.dataloader import DataLoader

    data = to_bytes("""---
    foo: bar
    baz:
        - my
        - list
        - of
        - data
    """)

    loader = DataLoader()


# Generated at 2022-06-20 23:41:46.886314
# Unit test for function from_yaml
def test_from_yaml():
    # Initialize AnsibleJSONDecoder
    AnsibleJSONDecoder.set_secrets(None)

    # Test Case 1: Good YAML data
    try:
        from_yaml(
            '---\n'
            '{}\n'
            '',
            file_name='<string>',
            show_content=True,
            vault_secrets=None,
        )
    except Exception as e:
        print('FAILED: test_from_yaml(): expected: no exception; actual: exception %s' % e)
        return False

    # Test Case 2: Bad YAML data

# Generated at 2022-06-20 23:41:53.432279
# Unit test for function from_yaml
def test_from_yaml():
    results = from_yaml('{"var1": [1, 2, true, false, null]}')
    assert results == {"var1": [1, 2, True, False, None]}

# Generated at 2022-06-20 23:42:01.941105
# Unit test for function from_yaml
def test_from_yaml():
    # As YAML is a superset of JSON, we test JSON parsing first.
    # The following JSON strings should be parsed correctly:
    # empty string
    assert from_yaml('') == None
    # empty dictionary
    assert from_yaml('{}') == {}
    # empty list
    assert from_yaml('[]') == []
    # one integer
    assert from_yaml('42') == 42
    # one boolean
    assert from_yaml('true') == True
    assert from_yaml('false') == False
    # one string
    assert from_yaml('"one string"') == 'one string'
    # one list of one string
    assert from_yaml('["one string"]') == ['one string']
    # one list of one integer

# Generated at 2022-06-20 23:42:04.752000
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('''
key1: "value1"
key2: "value2"
key3:
    - 1
    - 2
    - 3
''')

# Generated at 2022-06-20 23:42:11.995428
# Unit test for function from_yaml
def test_from_yaml():

    teststring = """
    ---
    - hosts: all
      gather_facts: no

      tasks:
      - name: this is a task
        debug:
            msg: I am  a task
    """

    data = from_yaml(teststring, show_content=False)

    if data['tasks'][0]['name'] != 'this is a task':
        raise Exception("Unable to parse the given string")

# Generated at 2022-06-20 23:42:14.502794
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\nfalse: false\nstring: bar\n") == {'false': False, 'string': 'bar'}

# Generated at 2022-06-20 23:42:18.722951
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('["a", "b", "c"]') == ["a", "b", "c"]
    assert from_yaml('{ "a": 1, "b": 2 }') == {'a': 1, 'b': 2}

# Generated at 2022-06-20 23:42:28.672321
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Simple test
    d1 = '{"foo":"bar"}'
    res = from_yaml(d1, file_name='<string>')
    assert isinstance(res, dict)

    # Simple test with a string that looks like JSON but isn't
    d1 = '{"foo":"bar":}'
    try:
        from_yaml(d1, file_name='<string>')
        assert False, "from_yaml() should have failed, but didn't"
    except AnsibleParserError as e:
        pass

    # Test with a string that looks like YAML without a blank line but isn't
    d1 = '- foo: bar\n  x: y\n'

# Generated at 2022-06-20 23:42:41.160269
# Unit test for function from_yaml

# Generated at 2022-06-20 23:42:47.659787
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''{
      "name": "Web server",
      "image": "nginx",
      "ports": {
        "80": "8000"
      }
    }'''
    assert from_yaml(test_data, json_only=True)['name'] == 'Web server'
    assert from_yaml(test_data)['name'] == 'Web server'

# Generated at 2022-06-20 23:43:01.393530
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Validate the output of from_yaml matches the yaml,json input
    '''

# Generated at 2022-06-20 23:43:09.513003
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("{\"key\":\"value\"}", json_only=True)
    assert result == {"key": "value"}

    result = from_yaml("{\"key\":\"value\"}", json_only=False)
    assert result == {"key": "value"}

    result = from_yaml("key: value", json_only=False)
    assert result == {"key": "value"}

# Generated at 2022-06-20 23:43:12.665941
# Unit test for function from_yaml
def test_from_yaml():
    test_obj = from_yaml("""
        {
            'foo': 'bar'
        }
    """)

    result = json.loads(json.dumps(test_obj))

    assert result['foo'] == 'bar'

# Generated at 2022-06-20 23:43:19.456022
# Unit test for function from_yaml
def test_from_yaml():

    import os

    # Ensure we have a dummy file to parse
    assert os.path.exists("test/utils/parsing/dummy_yaml.yml")
    assert os.path.isfile("test/utils/parsing/dummy_yaml.yml")

    with open("test/utils/parsing/dummy_yaml.yml", "r") as yaml_file:

        # Testing for AnsibleBaseYAMLObject.
        yaml_string = yaml_file.read()
        assert not yaml_string.startswith("#")

        # Do a dry run of from_yaml, without showing content.
        data = from_yaml(yaml_string, show_content=False)

        # Assert that the data is what we expect.

# Generated at 2022-06-20 23:43:23.033584
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('')
    from_yaml('{}')
    from_yaml('[]')
    from_yaml('["foo"]')
    from_yaml('{"foo": "bar"}')
    from_yaml('{"a": "b", "c": "d"}')
    from_yaml('[{"a": "b"}, {"c": "d"}]')
    from_yaml('{"a": [["b", "d"]], "c": "d"}')
    from_yaml('{"a": [{"b": "c"}, "d"], "c": "d"}')



# Generated at 2022-06-20 23:43:35.523084
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": "b"}') == {"a": "b"}
    assert from_yaml("""
    this:
      - is a json list:
        - with a string
    """) == {
        "this": [
            "is a json list",
            ["with a string"]
        ]
    }
    assert from_yaml("""
    this:
      - is a json list:
        - with a string
    """, json_only=True) == {
        "this": [
            "is a json list",
            ["with a string"]
        ]
    }

# Generated at 2022-06-20 23:43:43.969039
# Unit test for function from_yaml
def test_from_yaml():
    def check(data, exc=None):
        try:
            res = from_yaml(data)
            assert exc is None, res
            return res
        except Exception as e:
            assert exc is not None
            assert exc in to_native(e)

    check('{"foo": "bar", "baz": [1, "bax", {"key": "value"}]}')
    check('foo: bar\n')
    check('foo: bar\nbaz:\n  - 1\n  - bax\n  - key: value\n', exc='mapping values are not allowed here')
    check('foo: bar\nbaz:\n  - [1, 2]\n  - bax\n  - key: value\n', exc='mapping values are not allowed here')

# Generated at 2022-06-20 23:43:48.097417
# Unit test for function from_yaml
def test_from_yaml():
    data = {'a': 1, 'b': 2}
    json_data = json.dumps(data)
    assert from_yaml(json_data, json_only=True) == data
    assert from_yaml(json_data) == data

# Generated at 2022-06-20 23:43:58.958367
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u"abc") == "abc"
    assert from_yaml(u'["abc", "def", "ghi"]') == ["abc", "def", "ghi"]
    assert from_yaml(u"{'a': 'b'}") == {"a": "b"}
    assert from_yaml(u"{'a': 'b', 'c': {'d': 'e'}}") == {"a": "b", "c": {"d": "e"}}
    assert from_yaml(u"{'a': ['b', 'c']}") == {"a": ["b", "c"]}
    assert from_yaml(u"a: b\nc: d") == {"a": "b", "c": "d"}

# Generated at 2022-06-20 23:44:05.347948
# Unit test for function from_yaml
def test_from_yaml():
    test_input = r'{"ansible_facts": {"ansible_local": {"activated_modules": {"apt": True, "ignore_errors": True}}}}'
    output = from_yaml(test_input)

    assert isinstance(output, dict)
    assert 'ansible_facts' in output
    assert 'ansible_local' in output['ansible_facts']
    assert 'activated_modules' in output['ansible_facts']['ansible_local']

# Generated at 2022-06-20 23:44:17.438780
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    - hosts: localhost
      connection: local
      tasks:
        - name: Testing connection
          ping:
    '''

    json_str = '''
    [{"hosts": "localhost", "connection": "local", "tasks": [{"name": "Testing connection", "ping"}]}]
    '''

    # Test that yaml_str can be parsed correctly
    assert from_yaml(yaml_str) == from_yaml(json_str)

    # Test expected failure for bad JSON
    json_str = '{"hosts": "localhost", "connection": "local", "tasks": [{"name": "Testing connection", "ping"}]}'

# Generated at 2022-06-20 23:44:30.679117
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import types
    # Test for function _safe_load in AnsibleLoader
    #str = '{"a": "test"}'
    #assert(from_yaml(str) == {"a": "test"})

    # Test cases copied from test_yaml.py in ansible project
    #yaml_string = '''
    #---
    #- hosts: localhost
    #  roles:
    #    - role: test
    #'''
    #assert(from_yaml(yaml_string) == [{u'hosts': u'localhost', u'roles': [{u'role': u'test'}]}])

    #yaml_string = '''
    #---
    #- hosts: localhost
    # 

# Generated at 2022-06-20 23:44:38.189183
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile

    data = '''
---
foo: bar
'''
    path = os.path.join(tempfile.mkdtemp(), 'test.yml')
    with open(path, 'w') as f:
        f.write(data)

    yaml = from_yaml(data)

    assert yaml['foo'] == 'bar'

    yaml = from_yaml(path)

    assert yaml['foo'] == 'bar'

# Generated at 2022-06-20 23:44:47.637371
# Unit test for function from_yaml
def test_from_yaml():
    # Test with json
    s = """
    {
        "foo": "bar"
    }
    """
    data = from_yaml(s)
    assert data.get('foo') == 'bar'

    # Test with yaml
    s = """
    ---
    foo: bar
    """
    data = from_yaml(s)
    assert data.get('foo') == 'bar'

    # Test with yaml with $
    s = """
    ---
    foo: $
    """
    data = from_yaml(s)
    assert data.get('foo') == '$'

    # Test with error yaml
    s = """
    %YAML 1.2
    foo: $
    """

# Generated at 2022-06-20 23:44:56.650661
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("a: 1\nb: 2") == {"a": 1, "b": 2}
    assert from_yaml("{\"a\": 1, \"b\": 2}") == {"a": 1, "b": 2}
    assert from_yaml("{\"a\": [1, 2], \"b\": true}") == {"a": [1, 2], "b": True}
    assert from_yaml("{\"a\": {\"b\": 1, \"c\": 2}, \"d\": 3}") == {"a": {"b": 1, "c": 2}, "d": 3}

# Generated at 2022-06-20 23:45:04.669028
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test ansible.parsing.yaml.objects.from_yaml
    '''
    import ansible.parsing.yaml.objects
    from ansible.module_utils._text import to_text
    from io import StringIO
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    test_data = """
---
foo: bar
"""
    assert ansible.parsing.yaml.objects.from_yaml(test_data) == {'foo' : 'bar'}, 'failed to parse yaml'

    test_data = u"""
---
foo: bar
"""

# Generated at 2022-06-20 23:45:16.700989
# Unit test for function from_yaml
def test_from_yaml():
    # Test for vault in data
    data = {'vaulted_var': '$ANSIBLE_VAULT;1.1;AES256\n393037373638323831333233333839346638623333397337...'}
    new_data = from_yaml(data)
    assert new_data == {u'vaulted_var': u'VaultedVariablePlaceholder'}

    # Test for vault in data with json_only
    data = '{"vaulted_var": "$ANSIBLE_VAULT;1.1;AES256\n393037373638323831333233333839346638623333397337..."}'
    new_data = from_yaml(data, json_only=True)

# Generated at 2022-06-20 23:45:27.576504
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.error_strategy import ENCODED_VAULT
    import ansible.parsing.vault as vault

    assert(from_yaml("{}") == dict())
    assert(from_yaml("[]") == list())

    def d(**kv):
        return kv

    assert(from_yaml("{'key': 'val'}") == d(key="val"))
    assert(from_yaml("{'key': 'val'}", json_only=True) == dict(key='val'))

    assert(from_yaml("{'key': 'val', 'key2': 'val2'}") == d(key="val", key2="val2"))

# Generated at 2022-06-20 23:45:36.626524
# Unit test for function from_yaml
def test_from_yaml():
  data = "Hi"
  file_name = "test"
  show_content = True
  vault_secrets = None
  json_only = False
  assert from_yaml(data, file_name, show_content, vault_secrets, json_only) == "Hi"

  data='{"foo":"bar"}'
  file_name = "test"
  show_content = True
  vault_secrets = None
  json_only = False
  assert from_yaml(data, file_name, show_content, vault_secrets, json_only) == {"foo":"bar"}

if __name__ == '__main__':
  test_from_yaml()

# Generated at 2022-06-20 23:45:45.024963
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = "foo: [1,2,3]"
    print(from_yaml(yaml_str))
    assert from_yaml(yaml_str) == {"foo": [1, 2, 3]}
    json_str = '{"foo": [1,2,3]}'
    print(from_yaml(json_str, json_only=True))
    assert from_yaml(json_str, json_only=True) == {"foo": [1, 2, 3]}


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:45:50.194917
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u"{}") == {}
    assert from_yaml(u"{'foo': 'bar'}", json_only=True) == {u'foo': 'bar'}
    assert from_yaml(u"{'foo': 'bar'}", json_only=True) == {u'foo': 'bar'}



# Generated at 2022-06-20 23:45:58.003209
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
%YAML 1.2
---
---
foo:
  - name: Ansible
    type: {type: str}
  - name: ZStack
    type: {type: int}'''
    try:
        print(from_yaml(data))
    except AnsibleParserError as e:
        print(e.message)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:46:10.276219
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This unit test will fail without the fix for bug #35304 as the JSON
    parser won't be called.
    '''
    data = "{'json_only': 'won't work as yaml'}"
    try:
        from_yaml(data, json_only=True)
    except AnsibleParserError as e:
        assert str(e).startswith("We were unable to read either as JSON nor YAML, these are the errors we got from each:")
    else:
        assert False, "expected AnsibleParserError"

    data = "{'json_only': 'should work as both'}"
    try:
        from_yaml(data, json_only=True)
    except AnsibleParserError:
        assert False, "didn't expect AnsibleParserError"


# Generated at 2022-06-20 23:46:14.172657
# Unit test for function from_yaml
def test_from_yaml():
    data = "---\n" \
           "foo:\n" \
           "    - bar\n" \
           "    - baz:\n" \
           "        - asdf\n" \
           "        - qwer\n"

    ret = from_yaml(data)
    assert ret == {'foo': ['bar', {'baz': ['asdf', 'qwer']}]}

# Generated at 2022-06-20 23:46:19.099502
# Unit test for function from_yaml
def test_from_yaml():

    data = '{"test": "123"}'

    new_data = from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)

    assert new_data['test'] == '123'

# Generated at 2022-06-20 23:46:30.088805
# Unit test for function from_yaml
def test_from_yaml():
  string1 = '{ "string1": "string2" }'
  data = from_yaml(string1)
  assert data['string1'] == 'string2'

  string2 = "{ 'string1': 'string2' }"
  data = from_yaml(string2)
  assert data['string1'] == 'string2'

  string3 = '{ string1: "string2" }'
  data = from_yaml(string3)
  assert data['string1'] == 'string2'

  string4 = "{ string1: 'string2' }"
  data = from_yaml(string4)
  assert data['string1'] == 'string2'

  string5 = "{ string1: 'string2', string3: 'string4' }"
  data = from_yaml(string5)
 

# Generated at 2022-06-20 23:46:39.681304
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": 1}'
    result = from_yaml(data)
    assert result == {'foo': 1}

    data = 'foo: 1\nbar: 2\n'
    result = from_yaml(data)
    assert result == {'foo': 1, 'bar': 2}

    data = '''
foo: &foo
   name: "foobar"
   val: 123

bar: *foo
'''
    result = from_yaml(data)
    assert result == {'foo': {'name': 'foobar', 'val': 123}, 'bar': {'name': 'foobar', 'val': 123}}



# Generated at 2022-06-20 23:46:48.388415
# Unit test for function from_yaml
def test_from_yaml():
    import os, sys
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils._text import to_native

# Generated at 2022-06-20 23:46:55.306728
# Unit test for function from_yaml
def test_from_yaml():
    data = '''{
        "foo": "bar",
        "baz": [1,2,3],
        "bam": {
            "user": "name"
        }
    }'''
    assert from_yaml(data) == {'foo': 'bar', 'baz': [1,2,3], 'bam': {'user': 'name'}}

# Generated at 2022-06-20 23:47:06.536516
# Unit test for function from_yaml

# Generated at 2022-06-20 23:47:09.221329
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = AnsibleUnicode(u'test')
    assert from_yaml(data) == 'test'



# Generated at 2022-06-20 23:47:15.169275
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('{')
    except AnsibleParserError as e:
        assert e.message.find('We were unable') == 0
    else:
        assert False, "Expected AnsibleParserError"

# Generated at 2022-06-20 23:47:26.370001
# Unit test for function from_yaml
def test_from_yaml():
    data = "{ name: geoff }"
    file_name = "<string>"
    new_data = from_yaml(data, file_name)
    assert new_data["name"] == "geoff"

    data = "[ { name: geoff } ]"
    new_data = from_yaml(data, file_name)
    assert new_data[0]["name"] == "geoff"

    data = "---\n- { name: geoff }"
    new_data = from_yaml(data, file_name)
    assert new_data[0]["name"] == "geoff"

    data = "---\n- { name: geoff }"
    new_data = from_yaml(data, file_name)
    assert new_data[0]["name"] == "geoff"

   

# Generated at 2022-06-20 23:47:34.917760
# Unit test for function from_yaml
def test_from_yaml():

    # Test that we can parse a json
    data = json.dumps({'foo' : 'bar'})
    parsed = from_yaml(data, file_name=u'sting', show_content=False, vault_secrets=None,json_only=False)
    assert parsed == {'foo' : 'bar'}

    # Test that we can parse a yaml
    data = "---\nfoo: bar\n"
    parsed = from_yaml(data, file_name=u'sting', show_content=False, vault_secrets=None,json_only=False)
    assert parsed == {'foo' : 'bar'}

    # Test that with json_only we can only parse json
    data = "---\nfoo: bar\n"

# Generated at 2022-06-20 23:47:38.497102
# Unit test for function from_yaml
def test_from_yaml():
    # Test should return a list with one dict with key name and value test
    test_string = '---\n- name: test\n'
    assert from_yaml(test_string) == [{u'name': u'test'}]

# Generated at 2022-06-20 23:47:41.830391
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": "b" }') == {'a': 'b'}
    assert from_yaml('---\na: b') == {'a': 'b'}

# Generated at 2022-06-20 23:47:53.355884
# Unit test for function from_yaml
def test_from_yaml():

    # Generate data for test for function from_yaml
    test_data = '''
        - name: playbook.yaml
          description: playbook for test
          hosts: all
          vars:
            - testsrc: /tmp/src
            - testdst: /tmp/dst
          tasks:
            - name: create a new directory
              file:
                path: "{{testdst}}"
                state: directory
    '''
    # Convert yaml format to json format
    test_data_json = json.dumps(from_yaml(test_data), indent=4)
    # Write data to a json file
    with open("test_output.json", "w") as output_file:
        output_file.write(test_data_json)


# Generated at 2022-06-20 23:48:04.579742
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
- name: test
  hosts: localhost
  gather_facts: no
  tasks:
    - name: copy
      copy: src=somefile dest=/some/other/file
'''
    expected_data = [{"hosts": "localhost", "gather_facts": "no", "name": "test", "tasks": [{"name": "copy", "copy": "src=somefile dest=/some/other/file"}]}]

    assert from_yaml(yaml_data, file_name='test_from_yaml.yml') == expected_data

    # ANSIBLE_LIBRARY=. ./hacking/test-module-mocks.sh ./test/units/parsing/yaml/test_from_yaml.py -v



# Generated at 2022-06-20 23:48:12.803505
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a" : "b" }') == { u'a': u'b' }
    assert from_yaml('{ "a" : "b" }', json_only=True) == { u'a': u'b' }
    assert from_yaml('not json') == 'not json'
    assert from_yaml('not json', json_only=True) == 'not json'

    try:
        from_yaml('not json', json_only=True)
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:48:24.448137
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import simplejson as json

    # Simple test
    test_dict = {
        'test': {
            'test': True,
        }
    }
    test_yaml = yaml.dump(test_dict, Dumper=AnsibleDumper)
    new_data = from_yaml(test_yaml)

    assert new_data == test_dict
    assert json.dumps(new_data) == json.dumps(test_dict)

    # Test that we can serialize a yaml "document" stream
    test_yaml = '---\n'
    test_yaml += yaml.dump(test_dict, Dumper=AnsibleDumper)
    test_yaml

# Generated at 2022-06-20 23:48:35.721406
# Unit test for function from_yaml
def test_from_yaml():
    from os.path import basename
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test that from_yaml returns either a dict (JSON input) or a list (YAML input)
    input_yaml = """\
        - name: '{{ inventory_hostname }}'
          ipv4: ipaddress
        - name: '{{ inventory_hostname }}'
          ipv6: ipaddress6
    """
    data_yaml = from_yaml(input_yaml, file_name='/dev/null')
    assert len(data_yaml) == 2, 'Returned data should have length of 2, not %d.' % len(data_yaml)

    input_json = '{ "name": "{{ inventory_hostname }}" }'
    data_json = from_yaml

# Generated at 2022-06-20 23:48:50.262306
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None

    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('{ "foo": true}') == {"foo": True}
    assert from_yaml('{ "foo": true}', json_only=True) == {"foo": True}
    assert from_yaml('[1,2,3]') == [1, 2, 3]

    assert from_yaml('--- {}') == {}
    assert from_yaml('--- []') == []
    assert from_yaml('--- { "foo": true}') == {"foo": True}
    assert from_yaml('--- [1,2,3]') == [1, 2, 3]

    import sys

# Generated at 2022-06-20 23:49:00.547898
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import ansible
    class TestFromYAML(unittest.TestCase):
        def test_from_yaml(self):
            with self.assertRaises(AnsibleParserError):
                from_yaml("123")
            with self.assertRaises(AnsibleParserError):
                from_yaml("{a:b}")
            self.assertEqual({}, from_yaml("{}"))
            self.assertEqual({"a":1}, from_yaml("a: 1"))
            self.assertEqual({"a":1}, from_yaml("{a: 1}"))
            self.assertEqual([], from_yaml("[]"))
            self.assertEqual(["a"], from_yaml("[a]"))

# Generated at 2022-06-20 23:49:08.015211
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    data = '''
    {
      "pgsql_host": "{{ pgsql_host_for_opendj }}"
    }
    '''
    obj = from_yaml(data)
    assert obj == {'pgsql_host': '{{ pgsql_host_for_opendj }}'}
    assert isinstance(obj, dict)
    assert isinstance(obj, AnsibleMapping)


# Generated at 2022-06-20 23:49:16.880410
# Unit test for function from_yaml
def test_from_yaml():
    test_data = [
        "foobar",
        "1.1",
        "true",
        "false",
        "null",
        "{ foo: bar }",
        "{ foo: { bar: baz } }"
    ]

    for item in test_data:
        print("testing with %s"% (item,))
        try:
            result = from_yaml(item)
            print("result is %s"% (result,))
            print("success", end="\n\n")
        except AnsibleParserError as e:
            print(e)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:49:20.778387
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing function from_yaml")
    assert from_yaml('{ foo bar }', 'test_from_yaml.yaml.test') == { "foo" : "bar" }

test_from_yaml()

# Generated at 2022-06-20 23:49:28.135589
# Unit test for function from_yaml
def test_from_yaml():

    json_string = "[\"abc\"]"
    data = from_yaml(json_string)
    assert isinstance(data, list)
    assert data[0] == "abc"

    yaml_string = "--- [\"abc\"]\n"
    data = from_yaml(yaml_string)
    assert isinstance(data, list)
    assert data[0] == "abc"

    json_string = "{\"foo\":\"bar\"}"
    data = from_yaml(json_string)
    assert isinstance(data, dict)
    assert data["foo"] == "bar"

    yaml_string = "---\nfoo: bar\n"
    data = from_yaml(yaml_string)
    assert isinstance(data, dict)
    assert data["foo"] == "bar"

    json

# Generated at 2022-06-20 23:49:39.056448
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}") == {u'a': u'b'}
    assert from_yaml("{a: b}") == {u'a': u'b'}
    assert from_yaml("{'a:b': [1,2,3]}") == {u'a:b': [1, 2, 3]}
    assert from_yaml("{a: b, 'a:b': [1,2,3]}") == {u'a': u'b', u'a:b': [1, 2, 3]}
    assert from_yaml("a: b") == {u'a': u'b'}
    assert from_yaml('8') == 8
    assert from_yaml('["a", "b"]') == [u'a', u'b']


# Generated at 2022-06-20 23:49:45.340582
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":"b"}') == {'a': 'b'}
    assert from_yaml('{"a":"b"}') != {'b': 'a'}
    assert from_yaml('a: b') == {'a': 'b'}
    assert from_yaml('a: b') != {'b': 'a'}
    print("Success : from_yaml")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:49:48.584003
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "test" : "test" }'
    assert from_yaml(data) == {"test" : "test"}

    data = 'test'
    try:
        from_yaml(data)
        raise Exception('Test should fail')
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:49:53.440029
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('''
---
{ "test-name": { "test-key": "test-value" }}
''')
        assert True
    except Exception:
        assert False, 'test_from_yaml failed'

test_from_yaml()

# Generated at 2022-06-20 23:50:06.605193
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from io import StringIO
    input = '''
    # yaml test
    - { name: Joe, location: DE, pets: [cat, dog, fish] }
    - { name: Jane, location: US, pets: [bird] }
    '''

    expected = [{'name': 'Joe', 'location': 'DE', 'pets': ['cat', 'dog', 'fish']},
                {'name': 'Jane', 'location': 'US', 'pets': ['bird']}]

    result = from_yaml(StringIO(input))
    assert expected == result


# Generated at 2022-06-20 23:50:14.906477
# Unit test for function from_yaml
def test_from_yaml():
    # Test for basic functionality
    data = from_yaml('{"a":"b"}')
    assert data == {"a": "b"}
    data = from_yaml('a: b')
    assert data == {"a": "b"}

    # Test that JSON ParserError is raised in JSON only mode
    data = from_yaml('{a}', json_only=True)
    assert data is None
    try:
        data = from_yaml('{"a":"b"}', json_only=True)
    except AnsibleParserError:
        assert False

    # Test that JSON ParserError is handled correctly
    try:
        data = from_yaml('{a}')
    except AnsibleParserError:
        assert True
    except Exception:
        assert False

    # Test that YAML ParserError is handled correctly
   

# Generated at 2022-06-20 23:50:18.679372
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('null') is None
    assert from_yaml('[1,2,3]')[0] == 1
    assert from_yaml('{"a": "b"}')['a'] == "b"

