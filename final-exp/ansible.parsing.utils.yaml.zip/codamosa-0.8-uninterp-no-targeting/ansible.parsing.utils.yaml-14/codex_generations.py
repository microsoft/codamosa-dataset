

# Generated at 2022-06-20 23:40:24.245017
# Unit test for function from_yaml
def test_from_yaml():
    class C(object):
        pass

    obj = C()
    obj.foo = "bar"

    # We need to JSON serialize the object before we deserialize
    json_obj = json.dumps(obj, cls=AnsibleJSONDecoder, indent=4)
    new_obj = from_yaml(json_obj, json_only=True)

    # Make sure we got the same object back
    assert obj.foo == new_obj.foo

# Generated at 2022-06-20 23:40:36.843243
# Unit test for function from_yaml
def test_from_yaml():
    # basic usage
    assert from_yaml("{'foo': 'bar'}") == {u'foo': u'bar'}

    # unicode
    assert from_yaml(u"{'\u2665': '\u2665'}") == {u'\u2665': u'\u2665'}
    assert from_yaml("{'foo': 'bar'}") == {u'foo': u'bar'}

    # list
    assert from_yaml("""[foo, bar, bam]""") == [u'foo', u'bar', u'bam']

# Generated at 2022-06-20 23:40:40.234609
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
---
- hosts: all
  tasks:
  - debug:
      msg: hello world
""",'<string>',True) == [{u'hosts': u'all', u'tasks': [{u'debug': {u'msg': u'hello world'}}]}]

# Generated at 2022-06-20 23:40:47.670556
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Run unit test on the `from_yaml` function

    This test is supposed to be run with pytest.
    '''

    assert from_yaml('HOME=/home/user\n') == {'HOME': '/home/user'}
    assert from_yaml('{"HOME": "/home/user"}') == {'HOME': '/home/user'}
    assert from_yaml('{"HOME": "/home/user"}', json_only=True) == {'HOME': '/home/user'}

# Generated at 2022-06-20 23:40:59.251084
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    yaml_data = """
---
# This is a test, not a real file
- hosts: all
  sudo: yes
  tasks:
    - name: all
      shell: /usr/bin/false
      when: false
      tags: ['always']
    - name: task here
      debug: var={{password}}
"""


# Generated at 2022-06-20 23:41:03.929074
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1') == 1
    assert from_yaml('1', json_only=True) == 1
    assert from_yaml(' 1', json_only=True) is None
    assert from_yaml('{"name": "test"}') == {'name': 'test'}
    assert from_yaml('{name: test}', json_only=True) is None
    with pytest.raises(AnsibleParserError):
        from_yaml('{name: test}')



# Generated at 2022-06-20 23:41:16.265883
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = """
    {
      "a": "b"
    }
    """
    ret = from_yaml(data)
    assert(ret == {'a': 'b'})

    data = """
    ---
    - a
    - b
    - c
    """
    ret = from_yaml(data)
    assert(ret == ['a', 'b', 'c'])

    data = """
    {
        "a": "{{ b }}",
        "c": 2
    }
    """
    ret = from_yaml(data)
    assert(isinstance(ret['a'], AnsibleVaultEncryptedUnicode))


# Generated at 2022-06-20 23:41:28.525095
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar", "bam": null}'
    result = from_yaml(data)
    assert result == {"foo": "bar", "bam": None}

    data = 'foo: bar'
    result = from_yaml(data)
    assert result == {"foo": "bar"}

    data = 'foo: {bar: bam, baz: null}'
    result = from_yaml(data)
    assert result == {"foo": {"bar": "bam", "baz": None}}

    data = 'foo: !!str bar'
    result = from_yaml(data)
    assert result == {"foo": "bar"}

    data = 'foo: !!str 123'
    result = from_yaml(data)
    assert result == {"foo": "123"}


# Generated at 2022-06-20 23:41:32.148047
# Unit test for function from_yaml
def test_from_yaml():
    # json test
    json_data = '{"a":1,"b":2}'
    result = from_yaml(json_data)
    assert result == {"a": 1, "b": 2}


# Generated at 2022-06-20 23:41:35.603410
# Unit test for function from_yaml
def test_from_yaml():
    print("No unit test implemented yet!")

# Run unit test
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:41:46.565549
# Unit test for function from_yaml
def test_from_yaml():
    # simple dict
    assert from_yaml('{"a": "b"}') == {"a": "b"}

    # simple list
    assert from_yaml('["a", "b"]') == ["a", "b"]

    # dict with non-string keys
    assert from_yaml('{1: "a", "b": 2}') == {1: "a", "b": 2}

    # mapping with a list
    assert from_yaml('{"a": ["b", "c"]}') == {"a": ["b", "c"]}

    # list with a mapping
    assert from_yaml('["a", {"b": "c"}]') == ["a", {"b": "c"}]

    # list with a list

# Generated at 2022-06-20 23:41:54.962295
# Unit test for function from_yaml

# Generated at 2022-06-20 23:42:00.430147
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts: "{{ my_host }}"
      tasks:
      - name: test
        debug:
          msg: "test"
      - name: "{{ my_other_variable }}"
        debug:
          msg: "{{ my_variable }}"
    '''
    assert len(from_yaml(data)) == 1


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 23:42:01.140628
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-20 23:42:06.986240
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": "b" }') == {"a": "b"}
    assert from_yaml('a: b') == {"a": "b"}
    assert from_yaml('---\na: b') == "a: b"
    assert from_yaml('---\na: b\n') == "a: b"
    assert from_yaml('- a\n- b') == ["a", "b"]
    assert from_yaml('a: b\nc: d') == {"a": "b", "c": "d"}
    assert from_yaml('a:\n  b:\n    c: d') == {"a": {"b": {"c": "d"}}}
    assert from_yaml('a: !!str c') == {"a": "c"}

# Generated at 2022-06-20 23:42:19.777809
# Unit test for function from_yaml

# Generated at 2022-06-20 23:42:28.325215
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = '''
    ---
    # test for from_yaml
    # books
    - title: The Art of Community
      author: Jono Bacon
      edition: 2nd
      year: 2009
      publisher: O'Reilly
    - title: The Cathedral and the Bazaar
      author: Eric S. Raymond
      edition: 1st
      year: 2001
      publisher: O'Reilly
    '''

    from ansible.parsing.yaml import from_yaml
    data = yaml.load(yaml_string)
    assert data == from_yaml(yaml_string)


if __name__ == '__main__':
    test_from_yaml()
    print(":)")

# Generated at 2022-06-20 23:42:34.304951
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    import base64
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test expected encrypted input

# Generated at 2022-06-20 23:42:47.300420
# Unit test for function from_yaml
def test_from_yaml():

    my_yaml = '''
    a: 1
    b: 2
    c: 3
    '''

    my_json = '''
    {
        "a": 1,
        "b": 2,
        "c": 3
    }
    '''

    # Test JSON
    data = from_yaml(my_json)

    assert data == {
        "a": 1,
        "b": 2,
        "c": 3,
    }, "JSON data does not match JSON string input"

    # Test YAML
    data = from_yaml(my_yaml)

    assert data == {
        "a": 1,
        "b": 2,
        "c": 3,
    }, "YAML data does not match YAML string input"

    # Test JSON error

# Generated at 2022-06-20 23:42:54.623715
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('{"foo": "bar", "baz": "meep"}')
    assert result == {"foo": "bar", "baz": "meep"}, "Not able to deserialize json string to python object"
    try:
        result = from_yaml('{"foo": "bar", "baz": "meep"')
        assert False, "Exception should be raised when loading invalid json string"
    except AnsibleParserError as e:
        assert e is not None, "AnsibleParserError not raised when loading invalid json string"
    result = from_yaml("foo: bar\nbaz: meep")
    assert result == {"foo": "bar", "baz": "meep"}, "Not able to deserialize yaml string to python object"

# Generated at 2022-06-20 23:43:02.368757
# Unit test for function from_yaml
def test_from_yaml():
    with open("/home/ubuntu/awspds/awspds_project/awspds_project/awspds_project/ansible/reader.py") as f:
        print(from_yaml(f))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:43:03.007112
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-20 23:43:13.551414
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # import from from_yaml
    from_yaml_func = from_yaml

    # Check yaml not string
    try:
        from_yaml_func([])
        raise Exception("Expected exception not thrown")
    except AnsibleParserError as e:
        assert "JSON: Expecting value" in str(e)
        assert "We were unable to read either as JSON nor YAML" in str(e)

    # Check if return value is dict
    assert isinstance(from_yaml_func('{"mykey": "myvalue"}'), dict)

    # Check if

# Generated at 2022-06-20 23:43:27.960406
# Unit test for function from_yaml
def test_from_yaml():
    import textwrap
    import pytest

    class AnsibleParserError(Exception):
        pass

    class AnsibleBaseYAMLObject(Exception):
        pass

    # NOTE: YAML_SYNTAX_ERROR is defined in ansible/module_utils/parsing/convert_bool.py, so it's not available here.
    YAML_SYNTAX_ERROR = "We were unable to parse this as YAML, these are the errors we got:\n%s"
    good_yaml = '''
    a: 1
    b: 2
    '''

    good_json = '''
    {
        "a": 3,
        "b": 4
    }
    '''

    bad_yaml = '''
    a: 1
    b
    '''


# Generated at 2022-06-20 23:43:37.952894
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '{"foo": "bar" }'
    new_data = json.loads(data, cls=AnsibleJSONDecoder)
    assert new_data == {u'foo': u'bar'}

    new_data = _safe_load(data, file_name='<string>')
    assert new_data == {u'foo': u'bar'}

    data = u"foo: bar"
    new_data = _safe_load(data, file_name='<string>')
    assert new_data == {u'foo': u'bar'}

    dumper = AnsibleDumper

# Generated at 2022-06-20 23:43:45.816650
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"test": "1"}') == {"test": "1"}
    assert from_yaml('---\ntest: "1"\n') == {"test": "1"}
    assert from_yaml('---\ntest: "1"\n', json_only=True) is None
    assert from_yaml('---\ntest: "1"\n', json_only=True, file_name='<string>') is None

# Generated at 2022-06-20 23:43:57.601270
# Unit test for function from_yaml
def test_from_yaml():
    from ansible import context
    from ansible.plugins.vars import VarsModule
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    data = "{foo: bar, zot: zap}"
    json_data = {u'foo': u'bar', u'zot': u'zap'}
    file_name = './from_yaml.yaml'
    json_only = True

    vm = VariableManager()
    vm.set_inventory(context.CLIARGS.inventory)
    vm.set_vault_secrets([])

    # Initialize the plugin manager

# Generated at 2022-06-20 23:44:08.346107
# Unit test for function from_yaml
def test_from_yaml():

    from_yaml_result = from_yaml('foo: 1')
    assert from_yaml_result == {'foo':1}

    from_yaml_result_2 = from_yaml('{"foo": 1}')
    assert from_yaml_result_2 == {'foo':1}

    from_yaml_result_3 = from_yaml('{foo: 1}')
    assert from_yaml_result_3 == {'foo':1}

    # Test vault_secrets
    from_yaml_result_4 = from_yaml('{{foo}}: 1', vault_secrets={'foo':'1'})
    assert from_yaml_result_4 == {'1':1}


# Generated at 2022-06-20 23:44:19.840556
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    assert from_yaml('''
- hosts: localhost
  tasks:
  - name: test
    ping:
    when: false
    tags:
    - not_json_friendly
''') == [ { 'hosts': 'localhost', 'tasks': [{'name': 'test', 'ping': {}, 'when': False, 'tags': ['not_json_friendly']}]}]
    assert from_yaml('', json_only=True) == None
    assert from_yaml("{'a': 'b'}", json_only=True) == None
    assert from_yaml("{'a': 'b'}", json_only=False) == {'a': 'b'}

# Generated at 2022-06-20 23:44:30.727558
# Unit test for function from_yaml
def test_from_yaml():
    test_string = """
    a: 1
    b:
        c: 3
        d: 4
    """
    json_string = """
    {"a": 1,
    "b": {"c": 3, "d": 4}}
    """
    json_string2 = """
    {"a": 1,
    "b": {"c": 3, "d": 4},
    "e": [5, 6]}
    """

    yaml_string = """
    a: 1
    b: {c: 3, d: 4}
    """

    data = from_yaml(json_string)
    assert data == {"a": 1, "b": {"c": 3, "d": 4}}

    data = from_yaml(test_string)

# Generated at 2022-06-20 23:44:37.677285
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml({"key": "value"}, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)

# Generated at 2022-06-20 23:44:44.188913
# Unit test for function from_yaml
def test_from_yaml():
    # Test basic YAML loading
    try:
        from_yaml("""
---
foo: "bar"
""") == {'foo': 'bar'}
        assert(False)
    except AnsibleParserError:
        pass

    # Test basic JSON loading
    try:
        from_yaml("{'foo': 'bar'}", show_content=False) == {'foo': 'bar'}
        assert(False)
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:44:56.447311
# Unit test for function from_yaml
def test_from_yaml():
    """
    Verifies that function from_yaml correctly parses JSON and YAML strings to
    the correct Python datastructures.  It also verifies that the correct
    AnsibleParserError exception is raised if both YAML and JSON parsing fails.
    """
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.dataloader import DataLoader
    import os

    data_loader = DataLoader()

    # Test good JSON strings
    assert len(data_loader.load('[1, 2, 3, true, null]')) == 5
    assert data_loader.load("{ 'a': [ 1, 2, 3 ], 'b': [ 4, 5, 6 ] }") == {'a': [1, 2, 3], 'b': [4, 5, 6]}


# Generated at 2022-06-20 23:45:01.070388
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert from_yaml('''
- {json: yes}
- {yaml: "no"}
''') == [{u'json': True}, {u'yaml': u'no'}]
    except Exception as e_obj:
        raise AssertionError('Exception raised during from_yaml(): %s' % to_native(e_obj))

# Generated at 2022-06-20 23:45:11.809859
# Unit test for function from_yaml
def test_from_yaml():
    """Unit test for function from_yaml in module parsing."""
    from ansible.parsing.yaml import objects
    import os
    import sys

    # create a list of files to process

# Generated at 2022-06-20 23:45:23.530288
# Unit test for function from_yaml
def test_from_yaml():
    assert (from_yaml('1\n') == 1)
    assert (from_yaml('{"x": "y"}') == {'x': 'y'})
    try:
        from_yaml('{"x": "y"')
    except AnsibleParserError as e:
        assert(str(e) == "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n"
                         "JSON: Expecting object: line 1 column 12 (char 12)\n\n\n"
                         "The error appears to be in '/tmp/test': line 1, column 1, but may\n"
                         "be elsewhere in the file depending on the exact syntax problem.\n"
                         "The offending line appears to be:\n\n"
                         "{\n"
                         "^ here\n")

# Generated at 2022-06-20 23:45:27.698709
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    {
        "name": "foobarbaz",
        "some_data": 3
    }
    """
    result = from_yaml(data)
    assert "name" in result
    assert "foobarbaz" == result["name"]
    assert "some_data" in result
    assert 3 == result["some_data"]

# Generated at 2022-06-20 23:45:34.101859
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None
    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('a: 1') == {'a': 1}
    assert from_yaml('{ "a": 1 }') == {'a': 1}
    assert from_yaml("{ 'a': 1 }") == {'a': 1}
    assert from_yaml("'a'") == 'a'
    assert from_yaml("a") == 'a'
    assert from_yaml("a, b") == ['a', 'b']
    assert from_yaml("a, b", json_only=True) == 'a, b'
    assert from_yaml("a", json_only=True) == 'a'
    assert from_yaml

# Generated at 2022-06-20 23:45:38.271160
# Unit test for function from_yaml
def test_from_yaml():

    from_yaml('{}')

    # Uncomment once https://github.com/ansible/ansible/pull/56716 is backported to stable-2.6
    # assertFalse(from_yaml('', json_only=True))

# Generated at 2022-06-20 23:45:49.507351
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import BytesIO, PY3
    from collections import namedtuple

    # Python 3 needs strings to be (unicode)
    if PY3:
        b = lambda x: x
    else:
        b = lambda x: x.encode()

    test = namedtuple('Test', ['yaml', 'expected'])


# Generated at 2022-06-20 23:46:04.394646
# Unit test for function from_yaml
def test_from_yaml():
    # Valid input
    testvar = { "key": "value"}
    yamldata = from_yaml(json.dumps(testvar))
    assert yamldata == testvar

    # Invalid input
    bad_yaml = "key: value"
    try:
        from_yaml(bad_yaml)
        assert False
    except:
        assert True

# Generated at 2022-06-20 23:46:15.085364
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts:
        - localhost
      vars:
        foo: bar
    '''
    AnsibleJSONDecoder.set_secrets(None)
    new_data = json.loads(data, cls=AnsibleJSONDecoder)
    assert len(new_data) == 3
    assert new_data[1] == 'hosts'

    data = '''
    - hosts:
        - localhost
      vars:
        foo: bar
    '''
    AnsibleJSONDecoder.set_secrets(None)
    new_data = json.loads(data, cls=AnsibleJSONDecoder)
    assert len(new_data) == 3
    assert new_data[1] == 'hosts'


# Generated at 2022-06-20 23:46:21.431350
# Unit test for function from_yaml
def test_from_yaml():
    import sys

    if sys.version_info[0] > 2:
        # Skip tests on python3
        return

    # Test Scenarios

# Generated at 2022-06-20 23:46:32.110065
# Unit test for function from_yaml
def test_from_yaml():
    # Load a simple yaml string
    data = from_yaml('a: 1')
    assert data == {'a': 1}

    data = from_yaml('a: !!int 1')
    assert data == {'a': 1}

    # Load a simple json string
    data = from_yaml('{"a": 1}')
    assert data == {"a": 1}

    data = from_yaml('{"a": 1}', json_only=True)
    assert data == {"a": 1}

    try:
        from_yaml('a: 1', json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, 'AnsibleParserError not raised'

    # Raise an error if both json and yaml fail

# Generated at 2022-06-20 23:46:42.804802
# Unit test for function from_yaml
def test_from_yaml():
    # FIXME: This test will be re-enabled in Ansible 2.9
    pass
    # assert from_yaml('{"k1" : 123, "k2": 234}') == {u"k1": 123, u"k2": 234}
    # assert from_yaml('k1 : 123') == {u"k1": 123}
    # assert from_yaml('k1 : [123, "abcd"]') == {u"k1": [123, u"abcd"]}
    # assert from_yaml('k1 : "中国"') == {u"k1": u"中国"}
    # assert from_yaml('k1 : "中国"', json_only=True) is None
    # assert from_yaml('k1: abc\ndef') == {u"k

# Generated at 2022-06-20 23:46:55.245054
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import difflib

    for v in [True, False]:
        for data in ['{ "a": 1, "b": 2 }',
                     '{"a": 1, "b": 2}']:
            result = from_yaml(data, json_only=v)
            assert result == {'a': 1, 'b': 2}, result
            assert type(result) is dict

        for data in ['key: value',
                     '{key: value}',
                     'key: value\n',
                     'key: value\n\n',
                     'key: value\n\n']:
            result = from_yaml(data, json_only=v)
            assert result == 'value', result
            assert type(result) is str

        result

# Generated at 2022-06-20 23:46:58.002184
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": 1}') == {"foo": 1}
    assert from_yaml('foo: 1') == {"foo": 1}

# Generated at 2022-06-20 23:47:03.555604
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml.loader
    from ansible.plugins.loader import discover_inventory_plugins

    data = """
_meta:
  hostvars:
    host1:
      proxy: demo
"""
    print(from_yaml(data))


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:47:12.357291
# Unit test for function from_yaml
def test_from_yaml():
    def assert_equal(result, expected, filename):
        assert result == expected, 'Expected to parse yaml %s, got %s' % (expected, result)

    err = None
    try:
        from_yaml('{foo: bar', json_only=True)
    except AnsibleParserError as err:
        assert err.message.startswith('We were unable to read either as JSON nor YAML')

    assert err is not None
    assert err.orig_exc.message == 'Unterminated string starting at: line 1 column 8 (char 8)'

    assert_equal(from_yaml('foo: bar'), {'foo': 'bar'}, 'test 1')
    assert_equal(from_yaml('{foo: bar}'), {'foo': 'bar'}, 'test 2')

# Generated at 2022-06-20 23:47:23.954168
# Unit test for function from_yaml
def test_from_yaml():
    from f5_utils.yaml_utils import from_yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    data = """
        {
           "hosts": "{{ inventory_hostname }}",
           "vm_type": "{{ vm_type }}",
           "gw": "{{ gw }}"
        }
    """
    result = from_yaml(data, json_only=True, vault_secrets=None)
    print(result)

    # data = """
    #     {
    #        "hosts": "{{ inventory_hostname }}",
    #        "vm_type": "{{ vm_type }}",
    #        "gw": "{{

# Generated at 2022-06-20 23:47:51.133050
# Unit test for function from_yaml

# Generated at 2022-06-20 23:47:53.443825
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    with pytest.raises(AnsibleParserError):
        from_yaml('{bad: yaml}')

# Generated at 2022-06-20 23:47:55.391722
# Unit test for function from_yaml
def test_from_yaml():
   data = '{}'
   result = from_yaml(data)
   assert result == {}

if __name__ == '__main__':
   test_from_yaml()

# Generated at 2022-06-20 23:48:00.841481
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_text

    assert from_yaml(b"happy") == "happy"
    assert from_yaml(b"test\n : # comment\n - yay") == {'test': ['yay']}
    assert from_yaml(b"unicode: \xe2\x84\xa2") == {u'unicode': u'\u2122'}
    assert from_yaml(b'happy: "1"') == {u'happy': u'1'}
    assert isinstance(from_yaml(b'happy: "1"')['happy'], AnsibleUnsafeText)

# Generated at 2022-06-20 23:48:13.221664
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from_yaml_out = from_yaml('[1, 2, 3, 4, 5]')
    assert from_yaml_out == [1, 2, 3, 4, 5]

    AnsibleLoader.add_constructor(
        u'tag:yaml.org,2002:str',
        AnsibleLoader.construct_yaml_str
    )

    AnsibleDumper.add_representer(
        str,
        AnsibleDumper.represent_str
    )

    AnsibleJSONDecoder.set_secrets('test_vault_secret')
    test_data = u

# Generated at 2022-06-20 23:48:25.049080
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'foo: bar') == {'foo': 'bar'}
    assert from_yaml(b'{ "foo": "bar" }') == {'foo': 'bar'}
    assert from_yaml(b'foo: { "bar": "baz" }') == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-20 23:48:36.165600
# Unit test for function from_yaml
def test_from_yaml():
    # set data
    data1 = '{"key": "value"}'
    data2 = '{"key": "value"}\n'
    data3 = '{"key": "value"\n'
    data4 = '{"key": "value"}\n  '
    data5 = '{"key": "value"}\n\n'
    data6 = '{"key": "value"}\n{"key": "value"}'
    data7 = '  {"key": "value"}'
    data8 = '{\n "key": "value"}'
    data9 = '{"key": "value"\n}\n'

    # check if data1 is JSON
    assert from_yaml(data1) == json.loads(data1)

    # check if data2 is JSON
    assert from_yaml(data2) == json.loads

# Generated at 2022-06-20 23:48:48.561084
# Unit test for function from_yaml
def test_from_yaml():
    import re
    import os
    import sys


# Generated at 2022-06-20 23:48:57.227926
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": [1,2], "b": "foo"}'
    result = from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=True)
    assert result == {'a': [1,2], 'b': 'foo'}

    try:
        from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    except AnsibleParserError:
        pass
    else:
        assert False, "The code should not have reached here"

# Generated at 2022-06-20 23:49:00.859480
# Unit test for function from_yaml
def test_from_yaml():
    '''
    json_only=False test; pass YAML string
    '''
    from_yaml('---\n- test_1\n- test_2\n', file_name='<string>', show_content=True, vault_secrets=None, json_only=False)


# Generated at 2022-06-20 23:49:44.843500
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Simple unit test for Ansible's from_yaml() function.
    '''

    # This data structure is both valid JSON and YAML, so from_yaml should return the same data
    # structure no matter which format you give it.
    both_formats = '''{
        "foo": "bar",
        "baz": 1,
        "qux": true,
        "nested_list": [
            1,
            2,
            3
        ],
        "nested_dict": {
            "nested_string": "hello",
            "nested_dict_in_nested_dict": {
                "foo": "bar"
            }
        }
    }'''

    # This data structure only valid as YAML, so if we request JSON_ONLY, it will raise an exception

# Generated at 2022-06-20 23:49:50.112087
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = """\
    {
       "ansible_facts": {
          "os_family": "RedHat"
       },
       "changed": false,
       "failed": false,
       "invocation": {
          "module_args": {
             "hostname": "rh8-01.example.org"
          }
       },
       "rc": 0
    }
    """
    ret = from_yaml(yaml_str)
    assert ret['ansible_facts']['os_family'] == 'RedHat'
    assert ret['rc'] == 0

# Generated at 2022-06-20 23:50:00.562823
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    FAKE_PASS = 'fake_pass'
    FAKE_STRING = 'mysecret'
    FAKE_STRING_2 = 'mysecret2'

    # no vault in file
    data = {'test': 'test2'}
    data_string = 'test: "test2"'

    result = from_yaml(data_string)
    assert result == data

    # one vaulted string
    vault = VaultLib([VaultSecret(FAKE_PASS)])
    vaulted_string = vault.encrypt(FAKE_STRING)
    data = {'test': vaulted_string}

# Generated at 2022-06-20 23:50:10.529120
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts: localhost
      roles:
      - role: role_name
        tags: [tag_name]
      tasks:
      - name: Ansible Hello world
        debug:
          msg: "Hello world"
    '''

    parsed_data = from_yaml(data, show_content=True)
    print(parsed_data)


if __name__ == '__main__':
    test_from_yaml()


# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
# Copyright: (c) 2017, Ansible Project
# Copyright: (c) 2018, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)


# Generated at 2022-06-20 23:50:14.912851
# Unit test for function from_yaml
def test_from_yaml():

    res = from_yaml("foo: \"bar\"")
    assert res == {"foo": "bar"}

    res = from_yaml("foo: !!str 1")
    assert res == {"foo": "1"}

    res = from_yaml("[1]")
    assert res == [1]

# Generated at 2022-06-20 23:50:25.232504
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"key":"value"}') == {u'key': u'value'}
    assert from_yaml('key:value') == {u'key': u'value'}
    assert from_yaml('key:value\ntwo:1') == {u'key': u'value', u'two': 1}
    assert from_yaml('key:value\ntwo:1\n') == {u'key': u'value', u'two': 1}
    assert from_yaml('key:value\ntwo:1\n\n') == {u'key': u'value', u'two': 1}
    assert from_yaml('- key:value\n  two:1\n\n') == [{u'key': u'value', u'two': 1}]
    assert from_y