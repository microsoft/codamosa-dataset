

# Generated at 2022-06-20 23:40:28.510377
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # example snippet from https://github.com/ansible/ansible/issues/27899
    yaml_str = """
        - name: Disable SELinux, next steps
          selinux: state=disabled
          tags: [selinux,selinux-disabled]
          when: ansible_selinux.status|default('unknown') not in ('disabled', 'permissive')
    """

    results = from_yaml(yaml_str)

# Generated at 2022-06-20 23:40:36.864730
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    json_string = '{"k1": "v2"}'
    assert from_yaml(json_string) == json.loads(json_string)

    yaml_string = '''
    k1: v1
    k2:
      - v2
      - v3
    k3:
      k4: v4
      k5: v5
    '''
    assert from_yaml(yaml_string) == {'k1': 'v1', 'k2': ['v2', 'v3'], 'k3': {'k4': 'v4', 'k5': 'v5'}}


# Generated at 2022-06-20 23:40:44.312745
# Unit test for function from_yaml
def test_from_yaml():
    print("from_yaml test")
    try:
        data = from_yaml("---\n- debug: msg=hi\n- debug: msg=bye\n", "test_from_yaml", True)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:40:53.684467
# Unit test for function from_yaml
def test_from_yaml():
    # Test for JSON errors
    json_error_msg = """\
    {
        "items": [
            "a",
            "b",
            "c"
        ]
    } [
      {
        "items": [
          "a",
          "b",
          "c"
        ]
      }
    ]"""
    try:
        from_yaml(json_error_msg)
    except AnsibleParserError:
        pass
    else:
        assert False, "Should have raised an AnsibleParserError"

    # Test for YAML errors
    test_list2 = "[a,b,c][d,e,f]"
    try:
        from_yaml(test_list2)
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:40:57.226671
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('[1,2,3]')
    from_yaml('{"a": 1, "b": 2, "c": 3}')

# Generated at 2022-06-20 23:41:09.909949
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Tests the loading of YAML data (str) using 'from_yaml' function.
    '''
    import os
    import yaml

    data = "foo: bar"
    assert from_yaml(data) == yaml.safe_load(data)

    # test passing in vault secrets

# Generated at 2022-06-20 23:41:22.917547
# Unit test for function from_yaml
def test_from_yaml():
    # load ansible.cfg to get defaults and initialize plugin paths
    from ansible.cli.config import ConfigCLI
    from ansible.config.manager import ConfigManager

    args = ['-v', 'none']
    config = ConfigCLI(args)
    config.parse()
    config_manager = ConfigManager(config.options, config.args)
    config_manager.get_plugin_paths()

    data = '{"a": "b"}'
    results = from_yaml(data)
    assert results == {"a": "b"}

    data = '{"a": "b"}'
    results = from_yaml(data, json_only=True)
    assert results == {"a": "b"}

    data = '{"a": "b"}'

# Generated at 2022-06-20 23:41:34.644503
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    yaml_data = to_bytes(u"""
        a: 1
        b:
          c: 3
          d: 4
    """)

    result = from_yaml(yaml_data)
    assert isinstance(result, dict)
    assert len(result) == 2
    assert result == dict(a=1, b=dict(c=3, d=4))

    if not PY3:
        yaml_data = to_bytes(u"{'a': 1, 'b': {'c': 3, 'd': 4}}")
        result = from_yaml(yaml_data)
        assert isinstance(result, dict)
        assert len(result) == 2

# Generated at 2022-06-20 23:41:45.110669
# Unit test for function from_yaml
def test_from_yaml():
    array = ['a', 'b', 'c']
    array_json = "['a', 'b', 'c']"
    array_yaml = '- a\n- b\n- c'
    assert from_yaml(array_json) == array
    assert from_yaml(array_yaml) == array
    assert from_yaml(array_json, json_only=True) == array
    assert from_yaml(array_yaml, json_only=True) == array
    assert from_yaml(array_json, json_only=False) == array
    assert from_yaml(array_yaml, json_only=False) == array

# Generated at 2022-06-20 23:41:52.631485
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import ensure_text
    from ansible.parsing.vault import VaultLib

    test_file = "./ansible/playbook/data/yaml_files/yaml_load_tests.yml"
    test_file_data = open(test_file).read().encode('utf-8')

    # Without vault secrets
    dataAfter = from_yaml(test_file_data, test_file, True, None)
    assert dataAfter is not None, "data - %s" % (dataAfter)

    # With vault secrets
    vault_secrets = ["./ansible/playbook/data/vault_pass.txt"]
    vault = VaultLib(vault_secrets)
    dataAfter = from_

# Generated at 2022-06-20 23:42:04.864356
# Unit test for function from_yaml
def test_from_yaml():

    print("\nTesting from_yaml")

    from ansible.module_utils.common._collections_compat import (
        Mapping, MutableMapping, Sequence, MutableSequence, Set, MutableSet)

    # Array and Object test
    A = from_yaml("[1, 2, 3]")
    assert isinstance(A, (Sequence, MutableSequence)) and len(A) == 3
    B = from_yaml("{'1': 2, '3': 4}")
    assert isinstance(B, (Mapping, MutableMapping)) and len(B) == 2
    assert B['1'] == 2 and B['3'] == 4

    # Checking boolean and null
    assert not from_yaml("false") and from_yaml("true")

# Generated at 2022-06-20 23:42:18.161236
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    - hosts: localhost
      tasks:
      - debug: var=hostvars["localhost"]
    '''

    json_str = '''
    [
      {
        "hosts": "localhost",
        "tasks": [
          {
            "debug": {
              "var": "hostvars[\"localhost\"]"
            }
          }
        ]
      }
    ]
    '''

    json_str_nested = '''
    [
      {
        "hosts": "localhost",
        "tasks": [
          {
            "debug": {
              "var": "{{ hostvars[\"localhost\"] }}"
            }
          }
        ]
      }
    ]
    '''
    assert from_yaml(yaml_str)

# Generated at 2022-06-20 23:42:28.254109
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    class A:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    class B:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    # Here we assert some basic functionality of pyyaml and its ability to represent standard Python objects.
    # In particular, we assert the ability to represent dictionaries, lists, strings, integers, and bools.

# Generated at 2022-06-20 23:42:40.772533
# Unit test for function from_yaml
def test_from_yaml():
    """
    Run tests on the from_yaml function.
    """

    # list of tuples (a,b,c) with a/b being test data, and c being the expected output.
    TESTS = [
        ("""{ "testvar" : "testvalue" }""", None, {"testvar":"testvalue"}),
        ("""{ "testvar" : "testvalue", "listvar" : [1,2,3], "dicvar" : { "foo" : "bar" } }""", None, {"testvar":"testvalue", "listvar" : [1,2,3], "dicvar" : { "foo" : "bar" }})
    ]
    
    for (data, file_name, expected) in TESTS:
        result = from_yaml(data)


# Generated at 2022-06-20 23:42:48.102033
# Unit test for function from_yaml
def test_from_yaml():
    # AnsibleBaseYAMLObject.ansible_pos
    #assert from_yaml("foo: !include a.txt\n") == {"foo": {"!include": "a.txt"}}
    assert from_yaml("foo: !include a.txt\n") == {"foo": {"include": "a.txt"}}
    assert from_yaml("foo: !include\n    a.txt") == {"foo": {"include": "a.txt"}}

# Generated at 2022-06-20 23:42:55.063381
# Unit test for function from_yaml
def test_from_yaml():
    data="{'var': 'test'}"
    file_name = 'test_file'
    show_content = True
    vault_secrets = None
    json_only = False

    actual = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    expected = {u"var": u"test"}
    assert actual == expected

    data='var: test'
    actual = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    expected = {u"var": u"test"}
    assert actual == expected

    # testing exception
    # use JSON instead of JSON5 - JSON5 is not supported by json module
    data="{'var': 'test'"
    file_name = 'test_file'
    show_content = True


# Generated at 2022-06-20 23:43:08.244322
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import collections

    class TestFromYaml(unittest.TestCase):
        def test_yaml_string(self):
            ''' test data from ansible-config source file '''

# Generated at 2022-06-20 23:43:12.231220
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'status':{'current_code':0,'msg':'OK','results':{}}}"
    file_name = 'it6784.yml'
    show_content = True
    from_yaml(data, file_name, show_content)

# Generated at 2022-06-20 23:43:12.810342
# Unit test for function from_yaml
def test_from_yaml():
    # Test empty data
    assert from_yaml("") == None



# Generated at 2022-06-20 23:43:20.309958
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml(b'{"foo": "bar"}') == from_yaml(b'{"foo": "bar"}', json_only=True)
    assert from_yaml(b'foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-20 23:43:36.198528
# Unit test for function from_yaml
def test_from_yaml():
    '''
    >>> test_from_yaml()
    OK
    '''
    import os
    import tempfile

    _, tmp_file = tempfile.mkstemp(suffix='.yml')


# Generated at 2022-06-20 23:43:44.330839
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    # Test that we can load simple YAML files
    yaml_data = "- name: item1\n- name: item2\n- name: item3\n"
    assert [{'name': 'item1'}, {'name': 'item2'}, {'name': 'item3'}] == from_yaml(yaml_data)

    # Test that we can load simple JSON files.
    # the JSON should probably be pretty-printed, but the parser will accept it
    json_data = '[ { "name": "item1" }, { "name": "item2" }, { "name": "item3" } ]'
    assert [{'name': 'item1'}, {'name': 'item2'}, {'name': 'item3'}] == from_yaml(json_data)

   

# Generated at 2022-06-20 23:43:47.119358
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic test to see if we can read valid YAML
    '''

    valid_yaml = """
- hosts: localhost
  connection: local
  tasks:
    - name: Testing from_yaml
      debug: msg="Success!"
    """
    from ansible.parsing.dataloader import DataLoader
    ds = DataLoader().load_from_string(valid_yaml)
    assert type(ds) == list

# Generated at 2022-06-20 23:43:58.390630
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    if sys.version_info[0] < 3 and sys.version_info[1] < 3:
        import unittest2 as unittest
    else:
        import unittest
    import io

    from ansible.parsing.dataloader import DataLoader

    class TestFromYaml(unittest.TestCase):

        class TestInternal(object):
            pass

        class TestExternal(object):
            pass

        def run_from_yaml(self, params):
            data = params.get('data', None)
            expected = params.get('expected', None)
            file_name = params.get('file_name', None)
            show_content = params.get('show_content', True)
            vault_secrets = params.get('vault_secrets', None)
            json

# Generated at 2022-06-20 23:44:09.348997
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert isinstance(from_yaml('{}'), dict)
    assert isinstance(from_yaml('{"a": "b"}'), dict)
    assert isinstance(from_yaml('[1, 2, 3]'), list)
    assert from_yaml('{"a": "b"}') == {u'a': u'b'}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert isinstance(from_yaml('{"a": "b"}', file_name='file'), AnsibleLoader)
    assert isinstance(from_yaml('[1, 2, 3]', file_name='file'), AnsibleLoader)

# Generated at 2022-06-20 23:44:20.321732
# Unit test for function from_yaml
def test_from_yaml():
    # Test if function returns empty strings for empty YAML
    assert from_yaml("") == ""

    # Test if function returns None for empty JSON
    assert from_yaml("{}", json_only=True) == None

    # Test if function returns empty lists for empty JSON array
    assert from_yaml("[]", json_only=True) == []

    # Test if function returns None for invalid JSON
    assert from_yaml("{", json_only=True) == None

    # Test if function returns None for invalid YAML
    assert from_yaml("{", json_only=False) == None

    # Test if function returns empty strings for empty YAML
    assert from_yaml("") == ""

    # Test if function returns None for empty JSON

# Generated at 2022-06-20 23:44:25.832309
# Unit test for function from_yaml
def test_from_yaml():
    """from_yaml function test."""

    data = { "key1": "value1", "key2": "value2" }

    from_yaml_json = from_yaml(json.dumps(data))
    from_yaml_yaml = from_yaml(yaml.dump(data))

    assert from_yaml_json == data
    assert from_yaml_yaml == data

# Generated at 2022-06-20 23:44:38.077224
# Unit test for function from_yaml
def test_from_yaml():  # noqa: F811
    import yaml
    from ansible.parsing.vault import VaultLib

    vault_password = '$1$ZjBmZDM1$Q0DtMCTPzjROY.YFJR3qe1'
    vault = VaultLib(vault_password)

# Generated at 2022-06-20 23:44:46.120035
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    test_data_1:
        test_data_2:
            test_data_3:
                test_data_4: hello world
            other_test_data_3:
                test_data_4: hello world2
    '''

    test_data_struct = from_yaml(test_data)
    assert test_data_struct == {'test_data_1': {'test_data_2': {'test_data_3': {'test_data_4': 'hello world'}, 'other_test_data_3': {'test_data_4': 'hello world2'}}}}



# Generated at 2022-06-20 23:44:57.772924
# Unit test for function from_yaml
def test_from_yaml():
    # TODO: check that vault is handled correctly
    # TODO: check that filenames are handled correctly
    # TODO: check that AnsibleParserError is correctly raised

    # try to parse valid json
    json_data = '{"valid": "json", "number": 1, "list": [1, 2, 3], "dict": {"k": "v"}}'
    assert from_yaml(json_data) == json.loads(json_data)

    # try to parse valid yaml
    yaml_data = '''
            valid: yaml
            number: 2
            list:
                - 2
                - 3
                - 4
            dict:
                k: v
            '''

# Generated at 2022-06-20 23:45:13.025081
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml '''
    # pylint: disable=redefined-outer-name
    import os
    import pytest

    test_data_folder = os.path.join(os.path.dirname(__file__), 'test_data')
    sample_file_path = os.path.join(test_data_folder, 'parser', 'yaml_sample.yml')

    def load_file(file_path):
        ''' return contents from the sample file '''
        with open(file_path, 'rb') as fin:
            return fin.read()

    # test from_yaml with a good yaml file

# Generated at 2022-06-20 23:45:17.219415
# Unit test for function from_yaml
def test_from_yaml():
    '''Test function from_yaml with an array as input.'''
    data = '---\n- foo\n- bar'
    assert from_yaml(data) == ['foo', 'bar']

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:45:21.492525
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This simple function returns a python datastructure from a JSON string.
    '''
    json_content = {"a":1}
    assert from_yaml(json.dumps(json_content)) == json_content

# Generated at 2022-06-20 23:45:30.671499
# Unit test for function from_yaml
def test_from_yaml():
    from collections import namedtuple
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-20 23:45:33.719430
# Unit test for function from_yaml
def test_from_yaml():
    from __main__ import from_yaml
    assert from_yaml('{"key1": "value1", "key2": "value2"}') == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-20 23:45:45.578304
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1,2,3]", json_only=True) == [1, 2, 3]
    assert from_yaml("[1,2,3]") == [1, 2, 3]
    assert from_yaml("[1,2,3]", json_only=False) == [1, 2, 3]
    assert from_yaml("[1,2,3]") == [1, 2, 3]
    assert from_yaml("[1,2,3]", json_only=True) == [1, 2, 3]
    assert from_yaml("{\"a\":1,\"b\":2,\"c\":3}") == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-20 23:45:55.278768
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('foo') == None

    errormsg = "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" \
               "JSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)\n\n" \
               "The error appears to be in '/path/to/file': line 1, column 1, but may be elsewhere in the file " \
               "depending on the exact syntax problem.\n\nThe offending line appears to be:\n\n{  ^ here\n"

    try:
        from_yaml('{', 'file.yaml')
    except AnsibleParserError as e:
        assert e.message == errormsg
        assert e.line_number == 1

# Generated at 2022-06-20 23:46:05.261653
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import sys

    class TestAnsibleYaml(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_yaml_loader(self):
            test_cases = [
                (u"---\nanother: [1, 2, 3]\n", {u'another': [1, 2, 3]}),
            ]

            for (yaml, out) in test_cases:
                self.assertEqual(from_yaml(yaml), out)

    if __name__ == '__main__':
        unittest.main(verbosity=2)

# Generated at 2022-06-20 23:46:15.800939
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from ansible.parsing.vault import VaultLib
    except:
        return

    # Create data to test with
    data1 = '''
    {
        "list": [
            "item1",
            "item2",
            "item3"
        ], "bool": true,
        "int": 23,
        "string": "value",
        "dict": {
            "key1": "value",
            "key2": "value",
            "key3": "value"
        }
    }
    '''

    data2 = '''
    - hosts: localhost
      user: admin
    '''

    # Create a vault secret to use
    vault_password = 'vault_password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-20 23:46:20.423886
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts: localhost
      vars:
        var1: "{{ var2 }}"
    '''

    print(from_yaml(data))


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:46:33.244887
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') is None
    assert from_yaml('{}') == {}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('---\nfoo\n', json_only=True) == {'foo': None}

# Generated at 2022-06-20 23:46:43.587631
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":1, "b":2}') == {'a': 1, 'b': 2, '_ansible_no_log': False}
    assert from_yaml('{"a":1, "b":2}', json_only=True) == {'a': 1, 'b': 2, '_ansible_no_log': False}
    assert from_yaml('{"a":1, "b":2}', json_only=False) == {'a': 1, 'b': 2, '_ansible_no_log': False}
    assert from_yaml('a: 1\nb: 2') == {'a': 1, 'b': 2, '_ansible_no_log': False}

# Generated at 2022-06-20 23:46:56.438829
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text

    data = AnsibleLoader(None, 'test_from_yaml', None, None).get_single_data('''
        ---
        list_of_lists: [ [ 1, 2, 3 ] ]
        map_of_strings: { a: b, "c": d }
        ''')

    assert data == {'list_of_lists': [[1, 2, 3]],
                    'map_of_strings': {'a': 'b', 'c': 'd'}}, data

    data = AnsibleLoader(None, 'test_from_yaml', None, None).get_single_data('''
        - 1
        - 2
        - 3
        ''')



# Generated at 2022-06-20 23:47:04.430527
# Unit test for function from_yaml
def test_from_yaml():
    assert {} == from_yaml('')
    assert {'a': 1} == from_yaml('a: 1')
    assert {u'a': 1} == from_yaml(u'a: 1')
    assert {'a': 1} == from_yaml('{ "a": 1 }')
    assert {'a': 1} == from_yaml('{ "a": 1 }', json_only=True)
    assert {u'a': u'déja vu'} == from_yaml(u'a: déja vu')

# Generated at 2022-06-20 23:47:12.863081
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # Test if the default loader (YAML) is used by default.
    value = {
        'first_var': True,
        'second_var': False,
        'third_var': None,
    }
    data = DataLoader().load_from_file("/tmp/test.yaml", value)
    assert data == value

    # Test if the JSON loader is used as requested.
    value = {
        'first_var': True,
        'second_var': False,
        'third_var': None,
    }

# Generated at 2022-06-20 23:47:24.207470
# Unit test for function from_yaml
def test_from_yaml():
    # Test empty data
    data = ""
    try:
        from_yaml(data)
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in to_native(e)

    # Test JSON data
    json_data = '''
{
    "configs": [
        {
            "name": "config1"
        }
    ]
}
'''
    assert from_yaml(json_data) == {"configs": [{"name": "config1"}]}

    # Test YAML data
    yaml_data = '''
configs:
- name: config1
'''
    assert from_yaml(yaml_data) == {"configs": [{"name": "config1"}]}

    # Test YAML with vault
    vault_

# Generated at 2022-06-20 23:47:33.494649
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys

    # Change to test directory so that test modules can be specified as
    # relitive paths to the test yaml files.
    test_dir = os.path.dirname(__file__)
    os.chdir(test_dir)

    # file_list is the compound list of test files we will be testing.
    file_list = [
        'test_from_yaml_demo.yml',
        'test_from_yaml_demo.json',
    ]

    # file_data is the compound list of data we expect to get back from the
    # from_yaml function.
    file_data = [
        {
            u'foo': u'bar'
        },
        {
            u'foo': u'bar'
        },
    ]

    # Do the tests


# Generated at 2022-06-20 23:47:45.498452
# Unit test for function from_yaml
def test_from_yaml():
    class TestClass:
        def __init__(self, value):
            self.value = value

    test_json_string = '{"value":"test_value","test_class":{"value":"test_class_value"}}'
    obj = from_yaml(test_json_string)
    assert(obj['value'] == 'test_value')
    assert(obj['test_class'].value == 'test_class_value')

    test_yaml_string = '''
    value: test_value2
    test_class:
      value: test_class_value2
    '''
    obj = from_yaml(test_yaml_string)
    assert(obj['value'] == 'test_value2')
    assert(obj['test_class'].value == 'test_class_value2')


# Generated at 2022-06-20 23:47:54.966783
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    data = dict(a=1, b=dict(c=2, d={'0': 0, '1': 1}))
    data_yaml = u'---\na: 1\nb:\n  c: 2\n  d:\n    0: 0\n    1: 1\n'
    data_json = u'{"a": 1, "b": {"c": 2, "d": {"0": 0, "1": 1}}}'
    data_wrong_yaml = u'---\na: 1\nb:\n  c: 2\n  d:\n    0: 0\n    1: 1'

# Generated at 2022-06-20 23:47:59.740590
# Unit test for function from_yaml
def test_from_yaml():

    print("Running unit test for from_yaml")

    data = {
        'a': 'foo',
        'b': 'bar',
        'c': ['foo', 'bar', 'baz'],
        'd': [
            {'a': 'foo', 'b': 'bar'},
            {'b': 'baz', 'd': 'foo'}
        ]
    }

    print(from_yaml(json.dumps(data)))

    print(from_yaml(json.dumps(data), json_only=True))


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:48:28.490250
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\nfoo") == "foo"
    assert from_yaml("- foo") == ["foo"]
    assert from_yaml("foo: bar") == {"foo": "bar"}
    assert from_yaml("foo: false") == {"foo": False}
    assert from_yaml("foo: true") == {"foo": True}
    assert from_yaml("foo: null") == {"foo": None}
    assert from_yaml("foo: 1") == {"foo": 1}
    assert from_yaml("foo: 0") == {"foo": 0}

    assert from_yaml("false") == False
    assert from_yaml("true") == True
    assert from_yaml("null") == None
    assert from_yaml("1") == 1

# Generated at 2022-06-20 23:48:36.411337
# Unit test for function from_yaml
def test_from_yaml():
    data = from_yaml('''
    {
        'nested': [
            {
                'some': 'more',
                'data': {
                    'and': 'more',
                    'and': 'even more'
                }
            }
        ]
    }
    ''')

    assert data['nested'][0]['data']['and'] == 'even more'

    data = from_yaml("""
    nested:
    - 1
    - 2
    - 3
    """)
    assert data['nested'] == [1, 2, 3]

# Generated at 2022-06-20 23:48:42.635549
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import pytest
    from ansible.parsing.yaml import from_yaml

    TEST_DIR = os.path.dirname(__file__)
    TEST_DATA_DIR = os.path.join(TEST_DIR, 'test_data')
    TEST_PLAYBOOK_PATH = os.path.join(TEST_DATA_DIR, 'test_playbook.yml')
    TEST_PATH = os.path.join(TEST_DATA_DIR, 'test1.yml')

    # Test that a simple yaml file can be parsed with from_yaml
    assert from_yaml(open(TEST_PLAYBOOK_PATH).read())

    # Test that a file with just a string can be parsed.
    assert from_yaml('This is a simple string.')

    # Test

# Generated at 2022-06-20 23:48:51.042299
# Unit test for function from_yaml
def test_from_yaml():
    valid_json = '{"json": "valid"}'
    valid_yaml = "{yaml: 'valid'}"
    invalid_json_yaml = "invalid_json_yaml"

    # invalid data is not parsed
    assert from_yaml(invalid_json_yaml) is None

    # valid JSON data is parsed
    assert from_yaml(valid_json) == json.loads(valid_json)

    # valid YAML data is parsed
    assert from_yaml(valid_yaml) == {"yaml": "valid"}

# Generated at 2022-06-20 23:48:55.415783
# Unit test for function from_yaml
def test_from_yaml():
    # Check that the function returns the correct results
    result = from_yaml("""---
      foo: bar
      baz:
        "foo1": bar1
    """)
    assert result == {'foo': 'bar', 'baz': {'foo1': 'bar1'}}

# Generated at 2022-06-20 23:48:57.316826
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'
    assert from_yaml(data) == json.loads(data)

# Generated at 2022-06-20 23:49:02.325213
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - name: Create /tmp/file1
      file:
        path: /tmp/file1
        state: touch
    '''
    new_data = from_yaml(data)

    expected = [
        {
            'name': 'Create /tmp/file1',
            'file': {
                'path': '/tmp/file1',
                'state': 'touch'
            }
        }
    ]

    assert new_data == expected

# Generated at 2022-06-20 23:49:12.141895
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('{}\n') == {}
    assert from_yaml('{}\n\n') == {}
    assert from_yaml('{ "test" : "test" }') == {'test': 'test'}
    assert from_yaml('{ "test" : "test" }\n') == {'test': 'test'}
    assert from_yaml('{ "test" : "test" }\n\n') == {'test': 'test'}
    assert from_yaml('{ "test" : "test" }\n\n\n') == {'test': 'test'}

# Generated at 2022-06-20 23:49:18.431773
# Unit test for function from_yaml
def test_from_yaml():
    assert ({'a':1} == from_yaml('{"a": 1}'))
    assert ({'a':1} == from_yaml('a: 1'))
    try:
        from_yaml('a: 1', json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not raised but expected"

    assert ('' == from_yaml('""'))
    try:
        from_yaml('a: 1', json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not raised but expected"

    assert ('' == from_yaml('""'))

# Generated at 2022-06-20 23:49:24.057430
# Unit test for function from_yaml
def test_from_yaml():
    data_json = b'{"key":"value"}'
    data_yaml = b'---\nkey: value\n'
    file_name = '/path/to/file'

    assert from_yaml(data_json, file_name) == {
        'key': 'value',
    }

    assert from_yaml(data_yaml, file_name) == {
        'key': 'value',
    }

# Generated at 2022-06-20 23:49:49.443433
# Unit test for function from_yaml
def test_from_yaml():
    # Helper function for test_from_yaml that make sure to_text() is working
    def unit_test(data, expected_result, json_only=False):
        result = from_yaml(data, json_only=json_only)
        assert result == expected_result

    # Test simple values
    unit_test("1234", 1234)
    unit_test("1234.1234", 1234.1234)
    unit_test('"1234"', "1234")
    unit_test("true", True)
    unit_test("false", False)
    unit_test("null", None)

    # Test lists
    unit_test("[1234, true, 'text', null]", [1234, True, 'text', None])

# Generated at 2022-06-20 23:49:59.680932
# Unit test for function from_yaml
def test_from_yaml():
    json_data = """{
        "foo": [
            { "bar": "baz" }
        ]
    }"""
    assert from_yaml(json_data) == {'foo': [{u'bar': u'baz'}]}
    assert from_yaml(json_data, vault_secrets=[]) == {'foo': [{u'bar': u'baz'}]}
    assert from_yaml(json_data, vault_secrets=['foo']) == {'foo': [{u'bar': u'baz'}]}

    yaml_data = """
    foo:
      bar: baz
    """
    assert from_yaml(yaml_data) == {'foo': {u'bar': u'baz'}}

# Generated at 2022-06-20 23:50:09.763919
# Unit test for function from_yaml
def test_from_yaml():
    msg = AnsibleParserError
    yaml_strings = [
      '{foo: bar}',
      '{ foo: bar }',
    ]
    json_strings = [
      '{"foo": "bar"}',
      '{"foo": "bar"}\n'
    ]
    for yaml_string in yaml_strings:
        print("trying yaml_string = %s" % yaml_string)
        new_data = from_yaml(yaml_string)
        assert new_data == {'foo': 'bar'}
    for json_string in json_strings:
        print("trying json_string = %s" % json_string)
        new_data = from_yaml(json_string, json_only=True)
        assert new_data == {"foo": "bar"}

    json_

# Generated at 2022-06-20 23:50:19.827987
# Unit test for function from_yaml
def test_from_yaml():
    # Note: json string is not parsed correctly by the standard yaml parser
    print("json string is not parsed correctly by the standard yaml parser")
    print("=> json_only")
    # Input:
    data ="'{\"\\\"foo\\\"\": \"bar\"}'"
    # Output:
    print("'{\"\\\"foo\\\"\": \"bar\"}'")
    # Expected output:
    print("'{\"foo\": \"bar\"}'")
    print("Result:")
    yuml_result = from_yaml(data, file_name="name", show_content=True, \
                        vault_secrets=None, json_only=False)
    print(yuml_result)
    # Input:
    data ="'{\"foo\": \"bar\"}'"
    # Output: