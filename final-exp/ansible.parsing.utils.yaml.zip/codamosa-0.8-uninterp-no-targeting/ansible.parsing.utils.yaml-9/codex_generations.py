

# Generated at 2022-06-20 23:40:23.561722
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    test: key
    '''

    r = from_yaml(yaml_str, '<test>')
    assert type(r) == dict
    assert r['test'] == 'key'


# Generated at 2022-06-20 23:40:29.030351
# Unit test for function from_yaml
def test_from_yaml():
    data = """
---
a: 1
b:
  c: 3
  d: 4
"""
    f = 't'
    r = from_yaml(data, file_name=f)
    assert r == {'a': 1, 'b': {'c': 3, 'd': 4}}, "%s != {'a': 1, 'b': {'c': 3, 'd': 4}}" % r

# Generated at 2022-06-20 23:40:36.546249
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"this": "is valid json"}'
    assert from_yaml(test_data, json_only=True) == {"this": "is valid json"}
    assert from_yaml(test_data) == {"this": "is valid json"}

    test_data = 'this is not valid json'
    try:
        assert from_yaml(test_data, json_only=True)
        assert False
    except AnsibleParserError as e:
        assert isinstance(e.orig_exc, ValueError)

    assert from_yaml(test_data) == "this is not valid json"


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:40:41.750980
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": 2 }') == {'a': 1, 'b': 2}


# Generated at 2022-06-20 23:40:51.823938
# Unit test for function from_yaml

# Generated at 2022-06-20 23:41:01.609538
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test to run:
        python -c 'from ansible import module_utils; module_utils.basic.from_yaml.test_from_yaml()'
    '''
    data = '''
    ---
    - test.yaml

    - another.yaml

    - ID: 123
      NAME: Test
    '''

    expected = [
        'test.yaml',
        'another.yaml',
        {'ID': 123, 'NAME': 'Test'},
    ]

    actual = from_yaml(data)

    assert expected == actual, 'Expected: %s, Received: %s' % (expected, actual)


if __name__ == "__main__":
    import sys

    import pytest

    test_from_yaml()

# Generated at 2022-06-20 23:41:06.882472
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml('{ "a": 1, "b": 2, "c": 3 }', file_name='<string>', show_content=True, vault_secrets=None, json_only=False))


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:41:11.813929
# Unit test for function from_yaml
def test_from_yaml():

    from_yaml("{'a': 'z'}", file_name='<string>', show_content=True, vault_secrets=None, json_only=False)

    try:
        from_yaml("{'a': 'z'}")
    except Exception as e:
        pass

# Generated at 2022-06-20 23:41:25.697460
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ \"abc\": 123 }') == { u'abc': 123 }
    assert from_yaml('[1, 2]') == [1, 2]
    assert from_yaml('1') == 1
    assert from_yaml('"1"') == u'1'
    assert from_yaml('yaml') == u'yaml'
    assert from_yaml('[1, 2]') == [1, 2]
    assert from_yaml('{}') == {}
    assert from_yaml('foo: bar', json_only=True) == u'foo: bar'
    assert from_yaml(u'---\n- foo: bar', json_only=True) == u'- foo: bar'

# Generated at 2022-06-20 23:41:35.702574
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = """
        - test_list:
          - item1
          - item2
          - item3
        - test_list:
          - item4
          - item5
          - item6
    """
    json_string = """
        [{
            "test_list": [
                "item1",
                "item2",
                "item3"
            ]
        },
        {
            "test_list": [
                "item4",
                "item5",
                "item6"
            ]
        }]
    """

    # test yaml parsing
    yaml_result = from_yaml(yaml_string)
    assert isinstance(yaml_result, list)
    assert len(yaml_result) == 2

# Generated at 2022-06-20 23:41:48.753567
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Function from_yaml is a wrapper function, this function will test the core function it wraps
    and not the wrapper.
    '''
    # valid json
    json_data = '{"name": "John"}'
    assert from_yaml(json_data, 'json_test', False) == json.loads(json_data)

    # invalid json
    json_data = """{"name": "John""}"""
    try:
        from_yaml(json_data, 'json_test', False)
        assert False
    except AnsibleParserError:
        assert True
        pass

    # valid yaml
    yaml_data = 'name: John'
    assert from_yaml(yaml_data, 'yaml_test', False) == {'name': 'John'}

    # invalid yaml
   

# Generated at 2022-06-20 23:41:59.577205
# Unit test for function from_yaml
def test_from_yaml():
    '''
    We are using the json module to test our YAML parsing since the json module
    is better tested and we believe it to be correct.  We just want to verify
    that from_yaml produces the same output as json.loads.  We don't want to
    test YAML syntax here, that's already tested in the yaml and ansible
    project repos.
    '''
    import os
    import pytest
    import tempfile

    test_dir = os.path.join(os.path.dirname(__file__), 'unit', 'parsing', 'fixtures', 'from_yaml')
    yaml_files = [f for f in os.listdir(test_dir) if f.endswith('.yaml')]

# Generated at 2022-06-20 23:42:12.808279
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = """
    test_dict:
        foo: "this is a string"
        bar: 33
    """

    yaml_dict = from_yaml(yaml_str)
    assert isinstance(yaml_dict, dict)
    assert yaml_dict == {"test_dict": {"foo": "this is a string", "bar": 33}}

    yaml_str = """
    test_dict:
        foo: "this is a string"
        bar: 33
    """

    yaml_list = from_yaml(yaml_str)
    assert isinstance(yaml_list, list)
    assert len(yaml_list) == 1
    assert yaml_list[0] == {"test_dict": {"foo": "this is a string", "bar": 33}}


# Generated at 2022-06-20 23:42:24.129625
# Unit test for function from_yaml
def test_from_yaml():
    # Invalid JSON string, should raise an AnsibleParserError
    try:
        from_yaml("}")
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Invalid JSON string did not throw AnsibleParserError")

    # Invalid YAML string, should raise an AnsibleParserError
    try:
        from_yaml("}", json_only=True)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Invalid YAML string did not throw AnsibleParserError")

    # Invalid JSON string, should raise an AnsibleParserError
    try:
        from_yaml("}", json_only=False)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Invalid JSON string did not throw AnsibleParserError")



# Generated at 2022-06-20 23:42:32.655577
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    class TestFromYaml(unittest.TestCase):
        def test_from_yaml(self):
            import os
            import tempfile

            tmpdir = tempfile.mkdtemp()

            os.makedirs(os.path.join(tmpdir, 'ansible'))
            sam_path = os.path.join(tmpdir, "ansible", "test.yml")
            with open(sam_path, 'w') as f:
                f.write('{"hosts": "all", "remote_user": "root", "become": true, "tasks": [{"name": "shell test", "command": "echo hello world", "register": "shell_out"}]}')

            from ansible.parsing.dataloader import DataLoader
            dl = DataLoader()
           

# Generated at 2022-06-20 23:42:40.421252
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # We'll test with JSON, YAML and a mix of both.
    # It is important to note that whole file is interpreted as string,
    # so we need to escape quotes in YAML tests.


# Generated at 2022-06-20 23:42:53.181179
# Unit test for function from_yaml
def test_from_yaml():
    # the goal of this test is not to test yaml parsing
    # but to ensure the from_yaml function is parsed correctly
    import sys
    import io
    from collections import namedtuple
    YamlData = namedtuple('YamlData', ['text', 'expected'])

# Generated at 2022-06-20 23:43:06.915268
# Unit test for function from_yaml
def test_from_yaml():
    res = from_yaml("""
---
- ['foo', 'bar', 'baz']
-
  - abc
  - def
  -
   - 123
   - 345
""")
    assert res == [['foo', 'bar', 'baz'], ['abc', 'def', [123, 345]]]
    try:
        res = from_yaml("""
---
foo:
  bar: baz
  nested:
    - abc
    - def
    -
     - 123
     - 345
""")
        # missing colon after foo
        assert False
    except AnsibleParserError:
        pass

    # from_yaml should accept the JSON syntax, too
    res = from_yaml('{"foo": "bar"}')
    assert res == {"foo": "bar"}
    res = from_y

# Generated at 2022-06-20 23:43:14.435859
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == dict()
    assert from_yaml('[]') == []
    assert from_yaml('42') == 42
    assert from_yaml('42.1') == 42.1
    assert from_yaml('false') is False
    assert from_yaml('true') is True
    assert from_yaml('null') is None

    # ansible/ansible#29430
    assert from_yaml('"ansible-playbook"') == 'ansible-playbook'
    assert from_yaml('"{{ playbook_dir }}/{{ inventory_file }}"') == '{{ playbook_dir }}/{{ inventory_file }}'

# Generated at 2022-06-20 23:43:28.436341
# Unit test for function from_yaml
def test_from_yaml():
    import ast
    import sys
    # If python supports unicode
    if sys.version_info[0] > 2:
        if sys.version_info[1] > 5:
            assert ast.literal_eval(repr(from_yaml("---\n- 'Test String'\n- String2"))) == [u'Test String', u'String2']
        else:
            assert ast.literal_eval(repr(from_yaml("---\n- 'Test String'\n- String2"))) == [u'Test String', u'String2']
    else:
        assert ast.literal_eval(repr(from_yaml("---\n- 'Test String'\n- String2"))) == [u'Test String', u'String2']
    # If python doesn't support unicode

# Generated at 2022-06-20 23:43:39.433873
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import objects
    import os

    file_name = os.path.join(os.path.dirname(__file__), 'vault_test_utils.py')
    with open(file_name, 'r') as f_name:
        data = f_name.read()

    data = from_yaml(data)
    assert isinstance(data, objects.AnsibleMapping)

    vault_secrets = dict(vault_password='secret')
    file_name = 'my_file'
    assert isinstance(from_yaml(data, vault_secrets=vault_secrets, file_name=file_name), objects.AnsibleMapping)

# Generated at 2022-06-20 23:43:45.961455
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import datetime


# Generated at 2022-06-20 23:43:57.727907
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("'string'") == 'string'
    assert from_yaml('["a", "b", null, 1, {"k":"v"}]') == ['a', 'b', None, 1, {'k': 'v'}]
    assert from_yaml("{'hello': 'world'}") == {'hello': 'world'}
    assert from_yaml("[1,2,3]") == [1, 2, 3]

# Generated at 2022-06-20 23:44:04.397274
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleSequence

    def _assert_string(value):
        assert isinstance(value, str)

    def _assert_list(value, expected_list):
        assert isinstance(value, list)
        assert value == expected_list

    def _assert_dict(value, expected_dict):
        assert isinstance(value, dict)
        assert value == expected_dict

    def _assert_cls(value, expected_cls):
        assert isinstance(value, expected_cls)


# Generated at 2022-06-20 23:44:14.427462
# Unit test for function from_yaml
def test_from_yaml():
    ''' Test with various strings  '''
    strings = ('0', '0.1', '-10', '10', "0o11", '-0o11', '10.0', '10e2', '10E2',
               '10e+2', '10e-2', '-0b11', '-0B11', '-0o11', '0x12', '1a2', '1.5')
    for s in strings:
        assert s == from_yaml(s)
    assert 1e2 == from_yaml('1e2')
    assert -1e2 == from_yaml('-1e2')

# Generated at 2022-06-20 23:44:23.416866
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    _test_vault_id = '$ANSIBLE_VAULT;1.1;AES256'
    _test_vault_secret = 'vaultsecret'
    _test_vault_data = b'vaultencrypted'
    _test_vault_obj = AnsibleVaultEncryptedUnicode(u'bar', vault_id=_test_vault_id, vault_secret=_test_vault_secret)


# Generated at 2022-06-20 23:44:35.500264
# Unit test for function from_yaml
def test_from_yaml():
    input_yaml = '''
        ---
        name: null
        age: 40
        address:
          street: "110 E. UCF St."
          city: "Orlando"
          state: "FL"
          zip: 32804
        interests:
          - {topic: hockey, adjectives: [fast, hard]}
          - {topic: music, adjectives: [loud, "fast paced"]}
    '''


# Generated at 2022-06-20 23:44:42.177703
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode

    sio = StringIO('---')
    if PY2:
        assert isinstance(from_yaml(sio.read()), AnsibleUnicode)
    else:
        assert isinstance(from_yaml(sio.read()), str)

# Generated at 2022-06-20 23:44:49.802340
# Unit test for function from_yaml
def test_from_yaml():
    string = "---\nnode1: value1\nnode2: value2\n"
    data = {'node1': 'value1', 'node2': 'value2'}
    assert from_yaml(string) == data

    string = "node1: value1\\\n        value2\n"
    data = {'node1': 'value1value2'}
    assert from_yaml(string) == data

    string = "node1: [1, 2, 3]\n"
    data = {'node1': [1, 2, 3]}
    assert from_yaml(string) == data


# Generated at 2022-06-20 23:45:00.690621
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    # Make sure that the public functions are available for usage
    assert AnsibleDumper.__module__ == 'ansible.parsing.yaml.dumper'
    assert AnsibleLoader.__module__ == 'ansible.parsing.yaml.loader'

    # Test with valid YAML
    test_data = """
    - hosts: localhost
      tasks:
      - name: test task
    """
    parsed_data = from_yaml(test_data)
    assert parsed_data == [{'hosts': 'localhost', 'tasks': [{'name': 'test task'}]}]

    # Test with valid JSON
    test_data = '{"test": "json"}'

# Generated at 2022-06-20 23:45:10.141981
# Unit test for function from_yaml
def test_from_yaml():

    assert(from_yaml('1') == 1)
    assert(from_yaml('[1]') == [1])

    # with open('./tests/yaml/basic.yml') as f:
    #     assert(from_yaml(f.read()) == {'a': ['b', 'c']})

# Generated at 2022-06-20 23:45:21.756904
# Unit test for function from_yaml
def test_from_yaml():
    data = u"""
    variables:
      name: "abcd"
      list:
        - "a"
        - "b"
        - "c"
        - "d"
    """
    new_data = from_yaml(data)
    assert 'variables' in new_data
    assert 'name' in new_data['variables']
    assert new_data['variables']['name'] == u"abcd"
    assert 'list' in new_data['variables']
    assert len(new_data['variables']['list']) == 4
    assert new_data['variables']['list'][0] == u"a"
    assert new_data['variables']['list'][3] == u"d"

# Generated at 2022-06-20 23:45:30.849166
# Unit test for function from_yaml
def test_from_yaml():
    # Success for json and yaml
    assert from_yaml('{"test_json_key": "test_json_value"}') == {'test_json_key': 'test_json_value'}
    assert from_yaml('test_yaml_key: test_yaml_value') == {'test_yaml_key': 'test_yaml_value'}
    # Success for json_only flag and yaml
    assert from_yaml('test_yaml_key: test_yaml_value', json_only=True) == {'test_yaml_key': 'test_yaml_value'}
    # Failure for json_only flag and json

# Generated at 2022-06-20 23:45:37.487609
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"name": "Readme"}'
    json_data = from_yaml(data)
    assert isinstance(json_data, dict)
    assert json_data['name'] == 'Readme'

    data = 'name: Readme'
    yaml_data = from_yaml(data)
    assert isinstance(yaml_data, dict)
    assert yaml_data['name'] == 'Readme'

# Generated at 2022-06-20 23:45:48.713407
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": ["b", "c"], "d": "e"}'
    new_data = from_yaml(data)
    assert new_data == json.loads(data)

    data = '{"a": ["b", "c"], "d": "e", "f": "g"}'
    new_data = from_yaml(data)
    assert new_data == json.loads(data)

    data = '{"a": ["b", "c"], "d": "e", "f": [1, 2]}'
    new_data = from_yaml(data)
    assert new_data == json.loads(data)

    data = '{"a": ["b", "c"], "d": "e", "f": "g", "h": {"i": {"j": "k"}}}'
    new_data

# Generated at 2022-06-20 23:45:56.275226
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    - hosts: localhost
      gather_facts: no

      tasks:
        - name: test
          command: /bin/foo
          args:
            chdir: somedir/
            creates: somedir/somefile
            executable: /bin/bash
          register: result
          changed_when: "'/bin/foo' in result.stdout"

        - name: test
          command: /bin/foo
          args:
            chdir: somedir/
            creates: somedir/somefile
            executable: /bin/bash
          register: result
          failed_when: "'/bin/foo' in result.stdout"
    """

    from ansible.parsing.yaml.objects import AnsibleSequence

    assert isinstance(from_yaml(data), AnsibleSequence)

# Generated at 2022-06-20 23:46:08.431151
# Unit test for function from_yaml
def test_from_yaml():
    json_str = '''{
        "test": "{{ foo }}",
        "test2": "test2"
    }'''
    results = from_yaml(json_str)
    assert results['test'] == "{{ foo }}"
    assert results['test2'] == "test2"

    yaml_str = '''
    test: "{{ foo }}"
    test2: "test2"
    '''
    results = from_yaml(yaml_str)
    assert results['test'] == "{{ foo }}"
    assert results['test2'] == "test2"

    json_str = '''{
        "test": "test",
        "test2": "test2"
    }'''
    results = from_yaml(json_str, json_only=True)

# Generated at 2022-06-20 23:46:11.250778
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing from_yaml")
    from_yaml('{"test": "data"}')
    from_yaml("---\ntest: data\n")



# Generated at 2022-06-20 23:46:15.704125
# Unit test for function from_yaml
def test_from_yaml():
    data = """
        foo: [bar, baz]
    """
    # test for no file_name
    new_data = from_yaml(data)
    assert new_data == {'foo': ['bar', 'baz']}, new_data

    # test for file_name
    new_data = from_yaml(data, file_name='test')
    assert new_data == {'foo': ['bar', 'baz']}, new_data

# Generated at 2022-06-20 23:46:20.844328
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"test": {"a": "b", "b": "c"}}'
    new_data = from_yaml(data)
    assert new_data.get('test').get('a') == 'b'
    assert new_data.get('test').get('b') == 'c'



# Generated at 2022-06-20 23:46:27.022328
# Unit test for function from_yaml
def test_from_yaml():
  assert from_yaml('---\nansible-for-beginners') == 'ansible-for-beginners'

# Generated at 2022-06-20 23:46:32.737480
# Unit test for function from_yaml
def test_from_yaml():
    expect = {
        'name': 'value',
        'list': [
            'value',
        ],
        'dict': {
            'name': 'value',
        },
    }
    string = '''
name: value
list:
  - value
dict:
  name: value
'''
    data = from_yaml(string)
    assert data == expect



# Generated at 2022-06-20 23:46:38.294896
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import Mapping
    data = {}
    try:
        from_yaml('')
        assert False, "Expected yaml parse error"
    except AnsibleParserError as e:
        assert e.show_content is True # We are testing what we are testing
        assert len(e.obj.ansible_pos) == 3
        assert isinstance(e.obj.ansible_pos, tuple)
        assert isinstance(e.obj.ansible_pos[1], int)
        assert isinstance(e.obj.ansible_pos[2], int)
        assert e.obj.ansible_pos[1] > 0
        assert e.obj.ansible_pos[2] > 0

# Generated at 2022-06-20 23:46:45.813977
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    d = from_yaml('''---
a: 1
b:
    c: 3
        ''')
    assert isinstance(d['a'], int)
    assert isinstance(d['b'], dict)
    assert isinstance(d['b']['c'], int)

    d = from_yaml('''---
a: 1
b:
    c: "{{ foo }}"
        ''')
    assert isinstance(d['b']['c'], AnsibleUnsafeText)


# Generated at 2022-06-20 23:46:58.521353
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1+1') == 2
    assert from_yaml('{ "a": "b", "c": "d" }') == {"a": "b", "c": "d"}
    assert from_yaml('{ "a": "b", "c": "d" }', json_only=True) == {"a": "b", "c": "d"}
    assert from_yaml('{ "a": "b", "c": "d" }\n{ "e": "f", "g": "h" }') == {"a": "b", "c": "d"}
    assert from_yaml('---\n1+1') == 2
    assert from_yaml('---\n{"a": "b", "c": "d" }') == {"a": "b", "c": "d"}


# Generated at 2022-06-20 23:47:09.265269
# Unit test for function from_yaml
def test_from_yaml():
    # Test YAML
    data = """
    {
        "var1": "value1",
        "var2": "value2"
    }
    """
    ret = from_yaml(data)
    assert isinstance(ret, dict)
    assert ret['var1'] == "value1"
    assert ret['var2'] == "value2"

    # Test JSON
    data = """
    {
        "var3": "value3",
        "var4": "value4"
    }
    """
    ret = from_yaml(data)
    assert isinstance(ret, dict)
    assert ret['var3'] == "value3"
    assert ret['var4'] == "value4"

    # Test YAML with vault

# Generated at 2022-06-20 23:47:21.443524
# Unit test for function from_yaml
def test_from_yaml():
    import tempfile

    fd, fname = tempfile.mkstemp(text=True)
    with os.fdopen(fd, "w") as f:
        f.write("""---
        - hosts: test
          gather_facts: no
          tasks:
          - name: task1
            ping:
          - name: task2
            debug: msg="bye"
        """)


# Generated at 2022-06-20 23:47:31.161349
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3, text_type
    if PY3:
        unicode = str
    def _assert_data_equals(data, expected):
        assert data == expected, 'Data: %s != expected: %s' % (data, expected)
    def _assert_data_is_unicode(data):
        assert isinstance(data, unicode), 'Data: %s is of type %s, not unicode' % (data, type(data))
    def _assert_data_is_bytes(data):
        assert isinstance(data, bytes), 'Data: %s is of type %s, not bytes' % (data, type(data))

# Generated at 2022-06-20 23:47:34.952273
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
    - name: test
      hosts: localhost
      tasks:
        - debug: msg="{{ lookup('pipe','echo "hello world!"') }}"
    """) == {'tasks': [{'debug': {'msg': 'hello world!'}, 'name': 'debug'}], 'name': 'test', 'hosts': 'localhost'}

# Generated at 2022-06-20 23:47:46.960953
# Unit test for function from_yaml
def test_from_yaml():
    # These should all pass
    from_yaml("""{ "a": "b" }""")
    from_yaml("""{ a: b }""")
    from_yaml("""a: b""")
    from_yaml("""[ { a: b }, { c: "d" } ]""")
    from_yaml("""{ a: { b: { c: { d: e } } } }""")

    # The rest should raise exceptions

# Generated at 2022-06-20 23:47:58.260489
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.constants as C
    from ansible.errors import AnsibleError

    # Setup
    orig_vault_secrets = C.DEFAULT_VAULT_SECRETS
    C.DEFAULT_VAULT_SECRETS = ['/etc/ansible/vault_password.txt']
    orig_vault_password_file = C.DEFAULT_VAULT_PASSWORD_FILE
    C.DEFAULT_VAULT_PASSWORD_FILE = '~/.ansible_vault_password.txt'

    json_only = True
    file_name = "test.yml"
    show_content = True
    vault_secrets = None

    # Test using a non-yaml, non-json string
    data = "Testing string"
    assert from_yaml(data) == data

    # Test

# Generated at 2022-06-20 23:48:09.306140
# Unit test for function from_yaml
def test_from_yaml():
    test_data = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3, 4],
        'd': {
            'a': 1,
            'b': 2,
            'c': [1, 2, 3, 4],
            'd': {
                'a': 1,
                'b': 2,
                'c': [1, 2, 3, 4],
            },
        },
    }

    yamled = to_yaml(test_data)
    parsed = from_yaml(yamled)
    assert test_data == parsed

# Generated at 2022-06-20 23:48:17.499243
# Unit test for function from_yaml
def test_from_yaml():
    data_good_yaml_dict = '''
    ---
    key1: val1
    key2: val2
    key3: val3
    '''

    data_good_yaml_list = '''
    ---
    - val1
    - val2
    - val3
    '''

    data_good_json_dict = '''
    {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3"
    }
    '''

    data_good_json_list = '''
    [
        "val1",
        "val2",
        "val3"
    ]
    '''


# Generated at 2022-06-20 23:48:20.212283
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 1}') == json.loads('{"a": 1}')
    assert from_yaml('a: 1') == {"a": 1}

# Generated at 2022-06-20 23:48:20.794565
# Unit test for function from_yaml
def test_from_yaml():
    return True

# Generated at 2022-06-20 23:48:32.943486
# Unit test for function from_yaml
def test_from_yaml():
    file_name = 'test.yaml'
    show_content = True
    vault_secrets = None
    data = '''
    foo: bar
    baz:
      baz: buz
    '''
    assert from_yaml(data, file_name, show_content, vault_secrets) == {'foo': 'bar', 'baz': {'baz': 'buz'}}

    data = '''
    foo: bar
    baz:
      - 1
      - 2
    '''
    assert from_yaml(data, file_name, show_content, vault_secrets) == {'foo': 'bar', 'baz': [1, 2]}

    data = '''
    foo: baz
    '''

# Generated at 2022-06-20 23:48:40.907246
# Unit test for function from_yaml
def test_from_yaml():
    # Test for failure on invalid YAML inputs (Issue #21688)
    result = None
    try:
        result = from_yaml("{{{ invalid yaml")
    except AnsibleParserError as e:
        assert result is None
        assert(to_native(e)) == "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" \
                                 "JSON: Expecting property name enclosed in double quotes: line 1 column 1 (char 0)\n" \
                                 "\nYAML: " \
                                 "could not find expected ':'\n  in \"<unicode string>\", line 1, column 1"

    # Test for failure on valid JSON inputs (Issue #21688)
    result = None

# Generated at 2022-06-20 23:48:46.654752
# Unit test for function from_yaml
def test_from_yaml():
    test_data = from_yaml('[{ "host_user": "root", "become": true, "hosts": ["localhost"]}]')
    assert test_data[0]['host_user'] == 'root'
    assert test_data[0]['become'] == True
    assert test_data[0]['hosts'] == ["localhost"]

# Generated at 2022-06-20 23:48:50.081301
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1,2,3]') == [1,2,3]
    assert from_yaml('[1,2,3]', json_only=True) == [1,2,3]

# Generated at 2022-06-20 23:48:56.306012
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"abc": 123}') == {"abc": 123}
    assert from_yaml('{"abc": 123}', json_only=True) == {"abc": 123}
    assert from_yaml('a: 123') == {"a": 123}
    assert from_yaml('a: 123', json_only=True)
    assert from_yaml('[1,2,3]') == [1,2,3]

# Generated at 2022-06-20 23:49:08.015514
# Unit test for function from_yaml
def test_from_yaml():
    data = "1"
    result = from_yaml(data, file_name="test")
    assert result == 1
# End unit test

# Generated at 2022-06-20 23:49:16.929679
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
---
- hosts:
    - host1
  gather_facts: no
  tasks:
    - name: one
    - name: two
'''
    json_data = '{"hosts": ["host1"], "gather_facts": "no", "tasks": [{"name": "one"}, {"name": "two"}]}'
    assert from_yaml(json_data, json_only=True) == from_yaml(yaml_data)
    assert from_yaml(yaml_data) == from_yaml(json_data)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:49:24.715251
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('- 1') == [1]
    assert from_yaml('[1]') == [1]
    assert from_yaml('{"numbers": [1]}') == {'numbers': [1]}
    assert from_yaml('hello') == 'hello'
    assert from_yaml('1') == '1'
    assert from_yaml('True') is True
    assert from_yaml('true') is True
    assert from_yaml('False') is False
    assert from_yaml('false') is False
    assert from_yaml('null') is None
    assert from_yaml('Null') is None

# Generated at 2022-06-20 23:49:26.012932
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}

# Generated at 2022-06-20 23:49:38.017135
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml'''
    import re
    import sys
    import subprocess
    import shlex
    import filecmp
    import os
    import shutil
    import tempfile

    # The actual yamllint command.
    yamllint_command = "yamllint -c yamllinttest.yaml *yaml"

    # The directory where the yamllint tests are located.
    yamllint_test_dir = "test/utils/parsing/fixtures/yamllint"

    # The expected directory where the yamllint output is located.
    yamllint_expected_dir = "test/utils/parsing/fixtures/yamllint/expected"

    # Get the output from the yamllint command.
    yamllint_

# Generated at 2022-06-20 23:49:47.182270
# Unit test for function from_yaml
def test_from_yaml():
    data='{"key1": {"key2": "value1"}}'
    assert from_yaml(data, json_only=True) == {"key1": {"key2": "value1"}}
    assert from_yaml('[1,2,4]') == [1,2,4]
    assert from_yaml('[1,2,"4"]') == [1,2,"4"]
    assert from_yaml('{"key1": {"key2": "value1"}}') == {"key1": {"key2": "value1"}}
    assert from_yaml('["key1", {"key2": "value1"}]') == ["key1", {"key2": "value1"}]

# Generated at 2022-06-20 23:49:52.932589
# Unit test for function from_yaml
def test_from_yaml():

    test_list = [
        ('''{"k": "v"}''', {'k': 'v'}),
        ('''
            k: v
            ''', {'k': 'v'}),
        ('''---
            foo: bar
            ''', {'foo': 'bar'}),
        ('''{}''', {})
    ]
    for test_string, expected_result in test_list:
        result = from_yaml(test_string)
        assert result == expected_result

# Generated at 2022-06-20 23:50:03.591603
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.ajson import AnsibleJSONEncoder

    def loads(d):

        # test with byte string and unicode
        data1 = json.dumps(d)
        data2 = json.dumps(d, cls=AnsibleJSONEncoder)

        assert(from_yaml(data1) == d)
        assert(from_yaml(data2) == d)

        assert(from_yaml(data1, json_only=True) == d)
        assert(from_yaml(data2, json_only=True) == d)

    loads({'branch': 'master'})

# Generated at 2022-06-20 23:50:12.864585
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault as vaultlib
    # Test valid/invalid JSON and YAML using from_yaml()
    for extension in ('json', 'j2', 'yml', 'yaml'):
        for invalidity in ('!', '! !', '! ! !', '!! ! ! !', '!! !! !!', '~~~', '~', ''):
            if extension == 'json':
                # Invalid json with invalid json comment
                test_str = '{ "foo": "bar"%s }' % invalidity
            else:
                # Invalid yaml with invalid yaml comment
                test_str = '{ foo: bar%s }' % invalidity


# Generated at 2022-06-20 23:50:24.332600
# Unit test for function from_yaml
def test_from_yaml():
    from tempfile import NamedTemporaryFile
    import jinja2
    import os

    # Test data
    # =========
    # Simple case
    data = dict(a=1, b=2, c=3)
    test_filename = 'test.yml'
    with NamedTemporaryFile(mode='w+t') as tmpf:
        tmpf.write('\n'.join(['a: 1', 'b: 2', 'c: 3']))
        tmpf.seek(0)
        res = from_yaml(tmpf, test_filename)
    assert(data==res)

    # Compare with default yaml parser
    from yaml import safe_load
    data = dict(a=1, b=2, c=3)