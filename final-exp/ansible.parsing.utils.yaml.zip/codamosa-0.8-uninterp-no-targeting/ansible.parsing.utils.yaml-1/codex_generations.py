

# Generated at 2022-06-20 23:40:28.649310
# Unit test for function from_yaml
def test_from_yaml():
    # Sample data as string and dictionary
    json_str = "{\"a\": \"A\", \"b\": \"B\"}"
    yaml_str = ("a: A\n"
                "b: B\n")
    expected = {'a': "A", 'b': 'B'}
    # Check result of from_yaml
    assert from_yaml(json_str) == expected
    assert from_yaml(yaml_str) == expected
    assert from_yaml(json_str, show_content=False) == expected
    assert from_yaml(yaml_str, show_content=False) == expected
    # Check exception with invalid yaml
    invalid_yaml_str = "a A\nb: B\n"

# Generated at 2022-06-20 23:40:37.571149
# Unit test for function from_yaml
def test_from_yaml():
    data = {"foo": "bar"}
    ans = {"foo": "bar"}

    assert ans == from_yaml(json.dumps(ans))
    assert ans == from_yaml(json.dumps(ans, cls=AnsibleJSONDecoder))

    assert ans == from_yaml(yaml.dump(ans))
    assert ans == from_yaml(yaml.dump(ans, Dumper=AnsibleDumper))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:40:46.398140
# Unit test for function from_yaml
def test_from_yaml():
    data1 = '''
        {
            "key": "value"
        }
    '''
    data2 = '''
        ---
        key: value
    '''
    data3 = '''
        some_string
    '''

    assert from_yaml(data1) == {"key": "value"}
    assert from_yaml(data2) == {"key": "value"}
    with pytest.raises(AnsibleParserError):
        from_yaml(data3)

# Generated at 2022-06-20 23:40:55.359725
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    vault_pass = 'testpass'

    test_dir = tempfile.makedirs('test-from_yaml')

# Generated at 2022-06-20 23:40:59.692221
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"some": "stuff"}') == {"some": "stuff"}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    try:
        from_yaml('[1, 2, 3', json_only=True)
        assert False
    except AnsibleParserError:
        pass



# Generated at 2022-06-20 23:41:06.176956
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.tests.unit.parsing.yaml.test_yaml import AnsibleVaultEncryptedYAMLObject
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys

    fake_filename = 'test_file.yaml'

    # NOTE: pytest parametrizing is not used here because it's actually not
    # that simple to pass in parameters to it and thus tests in this file
    # are not dynamically generated. It's still much better than writing
    # out every single test case though.

    # We have to be careful using assertIn to avoid issues with
    # python < 2.7.5 (which is what travis-ci tests against)
    # See https://github.com/ansible/ansible/issues/22256

    # Test valid YAML

# Generated at 2022-06-20 23:41:14.009078
# Unit test for function from_yaml
def test_from_yaml():
    test_me = from_yaml('{"hello": "world"}')
    assert test_me == {"hello": "world"}

    test_me = from_yaml('hello: world')
    assert test_me == {"hello": "world"}

    try:
        test_me = from_yaml('hello: world: [1, 2, 3]')
    except AnsibleParserError as e:
        assert 'mapping values are not allowed here' in to_native(e)
    else:
        assert False, "No exception was thrown"

# Generated at 2022-06-20 23:41:21.062380
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("123", file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == 123
    assert from_yaml("123", file_name='<string>', show_content=True, vault_secrets=None, json_only=True) != 123


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:41:29.935183
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test from_yaml with known input and known output.
    '''
    # define known input
    input_str = '''
    - name: "First item"
      value: "First value"
    - name: "Second item"
      value: "Second value"
    '''
    # define known output
    output_dict = {'value1': 'First value', 'value2': 'Second value', 'name1': 'First item', 'name2': 'Second item'}

    # run the function convert input_str to known output
    output_dict = from_yaml(input_str)
    # reverse the dictionary
    reversed_dict = {v: k for k, v in output_dict.items()}
    assert(reversed_dict['value1'] == 'name1')

# Generated at 2022-06-20 23:41:40.828679
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Make sure we can load with and without extra vars.
    '''

    # vault and vault_prompt is irrelevant for this test.
    d = from_yaml("---\nuser: '*'\npassword: '*'\n", file_name='<string>', vault_secrets=None)
    assert (d == {'user': '*', 'password': '*'})

    # Also test loading with vault_secrets
    d = from_yaml("---\nuser: '*'\npassword: '*'\n", file_name='<string>', vault_secrets=['foo'])
    assert (d == {'user': '*', 'password': '*'})

# Generated at 2022-06-20 23:41:50.412756
# Unit test for function from_yaml
def test_from_yaml():
    # Basic test of JSON only parsing
    data = '{"hello": "world"}'
    assert from_yaml(data, json_only=True) == {'hello': 'world'}

    # Test of JSON with comments
    data = '''
{
  # Test JSON with comments
  "hello": "world"
}
'''
    assert from_yaml(data, json_only=True) == {'hello': 'world'}

    # Test that illegal JSON syntax throws an exception
    data = '''
{
  # Test JSON with comments
  "hello": "world"

'''

# Generated at 2022-06-20 23:41:57.936479
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Verify the from_yaml function returns a Python data structure
    when the input is either a JSON string or YAML string.
    '''
    json_string = '{"a":12,"b":13}'
    yaml_string = "---\na: 12\nb: 13\n"
    result = from_yaml(json_string)
    assert result == {"a": 12, "b": 13}
    result = from_yaml(yaml_string)
    assert result == {"a": 12, "b": 13}

# Generated at 2022-06-20 23:42:02.031385
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'a': 1 }") == {'a': 1}
    assert from_yaml("{ 'a': 1 }", json_only=True) == {'a': 1}
    assert from_yaml("{ 'a': 1 }") == {'a': 1}
    assert from_yaml("{ 'a': 1 }") == {'a': 1}

# Generated at 2022-06-20 23:42:09.369475
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1, this should work just fine
    yaml = u"---\nfoo: 1"
    ansible = from_yaml(yaml)

    # Test 2, this should cause a JSON error, it is not valid JSON
    yaml = u"---\nfoo: {"
    ansible = from_yaml(yaml, json_only=True)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:42:16.789576
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    test_variable: 
        - "with line break"
        - 'with double quotes: " and a single quote: \''
        - 'only single quotes'
    '''

    yaml_dict = from_yaml(yaml_data)

    assert yaml_dict == {'test_variable': ['with line break', 'with double quotes: " and a single quote: \'', 'only single quotes']}

# Generated at 2022-06-20 23:42:27.140488
# Unit test for function from_yaml
def test_from_yaml():

    import unittest
    # Loads test cases
    class Test_from_yaml(unittest.TestCase):

        def test_json(self):
            import ansible.parsing.dataloader
            vault_secrets = {}

            # Test basic json
            data = b'{"a":"b"}'
            res = ansible.parsing.dataloader.from_yaml(data, vault_secrets=vault_secrets)
            self.assertEqual(res, {'a': 'b'})

            # Test json with comments
            data = b'{"a":"b"} /* Comment */'
            res = ansible.parsing.dataloader.from_yaml(data, vault_secrets=vault_secrets)

# Generated at 2022-06-20 23:42:33.438548
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"test3": [1, 2, 3], "test4": { "test5": "test6" } }'
    print("data is \n", data)
    result = from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=True)
    print("result is \n", result)

# Generated at 2022-06-20 23:42:36.905573
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    a: 1
    b:
      - 2
      - 3
    '''

    ds = from_yaml(test_data)

    assert(ds == {u'a': 1, u'b': [2, 3]})


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:42:43.948390
# Unit test for function from_yaml
def test_from_yaml():
    # test with a string that contains valid YAML
    assert from_yaml(u'[1, 2, 3]') == [1, 2, 3]

    try:
        # test with a string that isn't valid YAML
        from_yaml(u'{one: 1]')
        assert False
    except AnsibleParserError:
        # expected exception
        assert True

# Generated at 2022-06-20 23:42:57.256764
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("string") == "string"
    assert from_yaml("100") == 100
    assert from_yaml("100.5") == 100.5
    assert from_yaml("[]") == []
    assert from_yaml("{}") == {}
    assert from_yaml("true") is True
    assert from_yaml("false") is False
    assert from_yaml("y") is True
    assert from_yaml("n") is False
    assert from_yaml("yes") is True
    assert from_yaml("no") is False
    assert from_yaml("on") is True
    assert from_yaml("off") is False
    assert from_yaml("null") is None
    assert from_yaml("~") is None
    assert from_yaml("") is None

   

# Generated at 2022-06-20 23:43:07.310039
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1 }', json_only=True) == { "a": 1 }
    assert from_yaml('{ "a": 1 }', json_only=False) == { "a": 1 }

    try:
        from_yaml('{ "a": 1')
        assert False, "Did not throw an exception"
    except AnsibleParserError:
        pass

    try:
        from_yaml('a: 1')
        assert False, "Did not throw an exception"
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:43:15.764268
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible_collections.notmintest.not_a_real_collection.plugins.v2.test_foobar import Foobar
    assert from_yaml(yaml_data) == {'a': [1, 2], 'b': {'b': [3, 4]}}
    assert from_yaml(json_data) == {'a': [1, 2], 'b': {'b': [3, 4]}}
    vault = VaultLib([(VaultSecret('secret', Foobar.SECRET_ENV_KEY, '',
                                   Foobar.secret_env_var_name),)])

# Generated at 2022-06-20 23:43:19.622908
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("name: foo", json_only=True) is None

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:43:24.939511
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"hello": "world"}') == {'hello': 'world'}
    assert from_yaml('hello: world') == {'hello': 'world'}
    assert from_yaml('hello:', json_only=True) == {'hello': 'world'}

# Generated at 2022-06-20 23:43:36.305544
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": [1, 2, 3]}') == {"a": [1, 2, 3]}
    assert from_yaml('{a: [1, 2, 3]}') == {"a": [1, 2, 3]}
    assert from_yaml('{a: [1, 2, 3], b: 4}') == {"a": [1, 2, 3], "b": 4}
    assert from_yaml('{a: [1, 2, 3], b: "str"}') == {"a": [1, 2, 3], "b": "str"}
    assert from_yaml('a: [1, 2, 3], b: 4') == {"a": [1, 2, 3], "b": 4}
    assert from_yaml('a: [1, 2, 3], b: "str"')

# Generated at 2022-06-20 23:43:44.380576
# Unit test for function from_yaml
def test_from_yaml():
    from nose2 import tools as test

    assert from_yaml('stuff') == 'stuff'
    assert from_yaml('stuff', json_only=True) == 'stuff'

    test.assert_raises(AnsibleParserError, from_yaml, '{', json_only=True)
    test.assert_raises(AnsibleParserError, from_yaml, '{')

    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}

    assert from_yaml('{"stuff": "otherstuff"}') == {'stuff': 'otherstuff'}
    assert from_yaml('{"stuff": "otherstuff"}', json_only=True) == {'stuff': 'otherstuff'}


# Generated at 2022-06-20 23:43:56.346244
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import re
    import yaml
    test_dir = os.path.dirname(os.path.realpath(__file__))
    yaml_file = os.path.join(test_dir, 'playbooks', 'playbook.yml')
    with open(yaml_file) as f:
        raw_data = f.read()

    data = from_yaml(raw_data, vault_secrets=['secret'])
    old = yaml.load(raw_data)
    assert data == old

    # Test to see if aliases are properly resolved
    raw_data = '''
---
all:
  hosts:
    foo:
      hostname: foo
      alias: foo.ansible.com
      children:
        child:
          alias: child.foo.ansible.com
'''

# Generated at 2022-06-20 23:44:06.198547
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert from_yaml("[{}]") == [{}]
    assert from_yaml("test") == "test"

# Generated at 2022-06-20 23:44:18.266356
# Unit test for function from_yaml
def test_from_yaml():
    # Instead of importing from_yaml, we use it as a local function
    # because it might not be installed in this system
    #from ansible.parsing.yaml.objects import from_yaml

    # Test basic types
    assert from_yaml(u'{"a": "b"}') == {'a': 'b'}
    assert from_yaml(u'simple: with spaces') == {'simple': 'with spaces'}

    # Test arrays
    assert from_yaml(u"{'a': ['b', 'c']}") == {'a': ['b', 'c']}
    assert from_yaml(u"- - 1\n  - 2") == [-1, -2]

    # Test unicode

# Generated at 2022-06-20 23:44:29.839078
# Unit test for function from_yaml
def test_from_yaml():
    import copy
    import os
    import sys
    import stat
    import tempfile
    import textwrap
    from ansible.module_utils import basic

    def _make_temp_file(data):
        (fd, tmp_file) = tempfile.mkstemp(prefix='ansible-test-file', suffix='.yml')
        os.write(fd, data.encode())
        os.chmod(tmp_file, stat.S_IRUSR | stat.S_IWUSR)
        os.close(fd)
        return tmp_file

    def _remove_temp_file(filename):
        os.remove(filename)


# Generated at 2022-06-20 23:44:43.438625
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.ajson import AnsibleJSONDecoder

    test_list = """
    - item 1
    - item 2
    - item 3
    """

    test_dict = """
    key1: value1
    key2: value2
    key3: value3
    """

    test_list2 = '''
    - item 1
    - { key1: value1, key2: value2 }
    - [ item 1, item 2 ]
    '''


# Generated at 2022-06-20 23:44:50.443101
# Unit test for function from_yaml
def test_from_yaml():

    # Basic yaml type convert to python
    yaml_str = u'{"ansible_facts": { "fact_one": "test1" } }'
    parsed_data = from_yaml(yaml_str)
    assert parsed_data == {u'ansible_facts': {u'fact_one': u'test1'}}

    # Basic json type convert to python
    yaml_str = u'{"ansible_facts": { "fact_one": "test1" } }'
    parsed_data = from_yaml(yaml_str, json_only=True)
    assert parsed_data == {u'ansible_facts': {u'fact_one': u'test1'}}

    # Invalid json

# Generated at 2022-06-20 23:44:57.957683
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    data = '''
    foo:
        bar: baz
    '''
    result = from_yaml(data)
    assert isinstance(result, AnsibleMapping)
    assert isinstance(result['foo'], AnsibleMapping)
    assert isinstance(result['foo']['bar'], AnsibleUnicode)
    assert result['foo']['bar'] == 'baz'

# Generated at 2022-06-20 23:45:07.042075
# Unit test for function from_yaml
def test_from_yaml():
    y_list = "[1, 2, 3]"
    j_list = "[1, 2, 3]"
    d_list = "[1, 2, 3]"

    y_str = "bar"
    j_str = "bar"
    d_str = "bar"

    y_dict = '{"foo": "bar", "baz": "qux"}'
    j_dict = '{"foo": "bar", "baz": "qux"}'
    d_dict = '{"foo": "bar", "baz": "qux"}'

    y_dict2 = '''
  foo: bar
  baz: qux
    '''
    j_dict2 = '''
  foo: bar
  baz: qux
    '''

# Generated at 2022-06-20 23:45:12.532388
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\nnot_valid_json: yes") == {"not_valid_json": "yes"}
    try:
        from_yaml("---\n{}", json_only=True)
        assert False
    except AnsibleParserError as e:
        assert "string indices must be integers" in to_native(e)

# Generated at 2022-06-20 23:45:13.406857
# Unit test for function from_yaml
def test_from_yaml():
    data = "{\"a\": 3}"
    assert from_yaml(data) == {"a": 3}

# Generated at 2022-06-20 23:45:18.211676
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    foo:
      bar: a
      baz: b
    '''
    data = from_yaml(yaml_str)
    assert data['foo']['bar'] == 'a'
    assert data['foo']['baz'] == 'b'

# Generated at 2022-06-20 23:45:28.681897
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-20 23:45:39.702216
# Unit test for function from_yaml
def test_from_yaml():
    # Test that invalid yaml raises an error
    test_string = '''
        -
          foo: a
          bar:
            foo: b
    '''
    raised_error = False
    try:
        from_yaml(test_string)
    except AnsibleParserError:
        raised_error = True
    assert raised_error

    # Test that valid yaml loads correctly
    test_string = '''
        -
          foo: a
          bar: b
    '''
    yaml_data = from_yaml(test_string)
    assert yaml_data == [{'foo': 'a', 'bar': 'b'}]

    # Test that valid json loads correctly
    test_string = '[{"foo": "a", "bar": "b"}]'

# Generated at 2022-06-20 23:45:50.842219
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO

    if PY3:
        # These test inputs must be unicode in Python3:
        json_input = '{"a": "\u1234"}'
        yaml_input = 'a: "\u1234"'
    else:
        # These test inputs must be byte strings in Python2:
        json_input = '{"a": "\xe1\x88\xb4"}'
        yaml_input = 'a: "\xe1\x88\xb4"'

    assert from_yaml(json_input) == json.loads(json_input)
    assert from_yaml(yaml_input) == json.loads(json_input)

    # Test the file_name parameter:

# Generated at 2022-06-20 23:45:56.084130
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"test": "this test should have a json structure"}')["test"] == "this test should have a json structure"
    try:
        from_yaml('{test: "this test should have a json structure"}')
    except AnsibleParserError:
        assert True
    else:
        assert False

# Generated at 2022-06-20 23:46:09.321118
# Unit test for function from_yaml
def test_from_yaml():
    test_obj = """
    {
        "name": "John Doe",
        "contact": {
            "email": "johndoe@example.com",
            "phone": "555-123-4567"
        }
    }
    """
    assert from_yaml(test_obj) == {
        "name": "John Doe",
        "contact": {
            "email": "johndoe@example.com",
            "phone": "555-123-4567"
        }
    }

    # Now test with a string that can be interpreted as both a JSON string and a YAML string
    test_obj = "1: one"
    assert from_yaml(test_obj) == 1

    # Now test with a string that can be interpreted as neither a JSON string nor a YAML string
    test_

# Generated at 2022-06-20 23:46:14.441692
# Unit test for function from_yaml
def test_from_yaml():
    """
    Basic function test for from_yaml. It simply verifies if from_yaml
    can handle a valid yaml.
    """
    yaml = """
    - hosts: localhost
      gather_facts: False
      tasks:
        name: test
        shell: echo hi
    """
    
    json_only = False
    file_name = 'test'
    show_content = True
    vault_secrets = None
    print(from_yaml(yaml, file_name, show_content, vault_secrets, json_only))

# Generated at 2022-06-20 23:46:26.492952
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    # Basic YAML document
    doc = '''
---
a: 3
b:
  - 1
  - 2
'''
    data = from_yaml(doc)
    # Make sure the YAML document is the same as what we started with
    assert doc == to_native(yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper))

    # Make sure the data is what we expect
    assert data == {'a': 3, 'b': [1, 2]}

    # Basic JSON document
    doc = '''
{
    "a": 3,
    "b": [
        1,
        2
    ]
}
'''

# Generated at 2022-06-20 23:46:31.663066
# Unit test for function from_yaml
def test_from_yaml():
    the_data = from_yaml('{"some": "json"}', file_name='/path/to/file.json')
    assert the_data['some'] == 'json'

    the_data = from_yaml('{some: "yaml"}', file_name='/path/to/file.yml')
    assert the_data['some'] == 'yaml'

# Generated at 2022-06-20 23:46:42.425230
# Unit test for function from_yaml
def test_from_yaml():
    def check_yaml_error(parser):
        try:
            parser(None)
            return False
        except AnsibleParserError:
            return True

    def check_json_error(parser):
        try:
            parser(None)
            return True
        except AnsibleParserError:
            return False

    # no error because we pass None to both parsers
    assert check_yaml_error(from_yaml) == check_json_error(from_yaml)

    # if we disable JSON parsing, YAML error should remain
    yaml_only = lambda data: from_yaml(data, json_only=True)
    assert check_yaml_error(yaml_only)

    # conversely, if we disable YAML parsing, JSON error should remain

# Generated at 2022-06-20 23:46:54.530623
# Unit test for function from_yaml
def test_from_yaml():
    import os, tempfile
    test_file = '''{"message": "foo"}
"""
{"message": "bar"}
"""
{message: "baz"}
'''
    fh, fname = tempfile.mkstemp(suffix='.txt', prefix='test_from_yaml_')
    os.write(fh, test_file)
    os.close(fh)

# Generated at 2022-06-20 23:47:06.025851
# Unit test for function from_yaml
def test_from_yaml():
    import os
    assert(from_yaml(u'{}'))
    assert(from_yaml(u'{}', file_name='path/to/json_file.json'))

    # test yaml file
    data_path = os.path.join(os.path.dirname(__file__), 'unit/parsegen/yaml_files/dst_file')
    assert(from_yaml(file(data_path).read(), file_name=data_path, show_content=False))

    # test json file
    data_path = os.path.join(os.path.dirname(__file__), 'unit/parsegen/json_files/hello_world')
    assert(from_yaml(file(data_path).read(), file_name=data_path, show_content=False))

# Generated at 2022-06-20 23:47:17.520742
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert from_yaml('{ "foo": "bar" }') == { u'foo': u'bar' }
    assert from_yaml('{ "foo": "bar" }', json_only=True) == { u'foo': u'bar' }

# Generated at 2022-06-20 23:47:28.086411
# Unit test for function from_yaml
def test_from_yaml():
    data = u'{"key1": "value1", "key2": "value2", "key3": "value3"}'
    decoded = from_yaml(data, file_name=u"<string>", show_content=True)
    assert decoded == {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}
    assert type(decoded) == dict

    data = u'{"key1": "value1", "key2": "value2", "key3": "value3"}'
    decoded = from_yaml(data, file_name=u"<string>", show_content=False)

# Generated at 2022-06-20 23:47:43.597334
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.ajson import AnsibleJSONDecoder

    #
    # Test regular YAML (non JSON)
    #
    yaml_str = """
        - hosts: localhost
          connection: local
          tasks:
          - name: print hello world
            debug: msg=Hello World!
    """
    try:
        data = from_yaml(yaml_str)
    except AnsibleParserError as e:
        assert False

    #
    # Test YAML (non JSON) with a vault
    #

# Generated at 2022-06-20 23:47:52.987119
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml '''
    test_json_str = '{"a": "b"}'
    test_yaml_str = 'a: b'
    test_yaml_str_invalid_format = 'hello: world'
    assert from_yaml(test_json_str) == json.loads(test_json_str)
    assert from_yaml(test_yaml_str) == yaml.safe_load(test_yaml_str)
    try:
        from_yaml(test_yaml_str_invalid_format)
    except AnsibleParserError as err:
        assert isinstance(err, AnsibleParserError)
    else:
        assert False

# Generated at 2022-06-20 23:47:57.730451
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import traceback
    import StringIO
    import unittest
    test_out = StringIO.StringIO()
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(YAMLTest))
    runner = unittest.TextTestRunner(test_out)
    runner.run(suite)

# Generated at 2022-06-20 23:48:04.349765
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'input': 'data'}"
    file_name = 'unittest'
    show_content = False
    vault_secret = None
    new_data = from_yaml(data, file_name, show_content, vault_secret, True)
    assert type(new_data) == dict
    assert new_data['input'] == 'data'



# Generated at 2022-06-20 23:48:14.883495
# Unit test for function from_yaml
def test_from_yaml():

    import unittest
    from ansible.parsing.yaml.loader import AnsibleLoader, AnsibleUnsafeLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeYAMLObject
    from ansible.parsing.dataloader import DataLoader

    class TestFromYaml(unittest.TestCase):

        def setUp(self):
            self.myvars = dict(
                sponge=dict(bob='squarepants'),
                foo='one',
                listofints=[1, 2, 3],
                listofstrings=['a', 'b'],
                nestedlist=[1, 'a', [1, 2, 'c'], ['d', 'e']],
                empty_array=[],
                empty_dict=dict(),
            )
            self.myvars_unsafe

# Generated at 2022-06-20 23:48:27.012654
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test, when YAML failed to load, we got correct error message &
    # exception class
    data = """
    This is Invalid YAML Syntax.
    """
    loader = AnsibleLoader(data)
    try:
        loader.get_single_data()
        assert False, "should have thrown exception"
    except AnsibleParserError as e:
        assert e.orig_exc is not None
        assert 'YAML Syntax Error' in e.message
        assert 'mapping values are not allowed' in e.message
    finally:
        try:
            loader.dispose()
        except AttributeError:
            pass  # older versions of yaml don't have dispose function, ignore

    # Test, when JSON failed to load, we got correct

# Generated at 2022-06-20 23:48:37.655968
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    # Test from_yaml when json_only == True
    try:
        from_yaml('bad json', json_only=True)
        assert False
    except AnsibleParserError:
        pass

    # Test from_yaml for YAML strings

# Generated at 2022-06-20 23:48:50.080411
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{}')
    from_yaml('{}', json_only=True)

    try:
        from_yaml('{')
        raise Exception("This line should not be reached")
    except AnsibleParserError as e:
        pass

    try:
        from_yaml('{', json_only=True)
        raise Exception("This line should not be reached")
    except AnsibleParserError as e:
        pass

    try:
        from_yaml('{')
        raise Exception("This line should not be reached")
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in str(e)


# Generated at 2022-06-20 23:48:57.664386
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib

    try:
        from_yaml('{}')
    except:
        pass

    try:
        from_yaml('{}', json_only=True)
    except AnsibleParserError:
        pass

    try:
        v = VaultLib({})
        from_yaml('{}', vault_secrets=v)
    except:
        pass

    try:
        from_yaml('{x')
    except AnsibleParserError:
        pass

# Generated at 2022-06-20 23:49:04.430971
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    loader = DataLoader()
    data = '{"foo":"bar"}'
    assert from_yaml(data, '<string>') == {u'foo': u'bar'}

    data = "{'foo':'bar'}"
    assert from_yaml(data, '<string>') == {u'foo': u'bar'}

    data = "{'foo': 'bar'"
    assert from_yaml(data, '<string>') == {u'foo': u'bar'}

    data = '{"foo": "bar'

    with pytest.raises(AnsibleParserError) as exc:
        from_

# Generated at 2022-06-20 23:49:12.760203
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
- hosts: localhost
  tasks:
  - name: test
    debug:
      msg: hello
    when: ansible_distribution == "Debian"
'''

    obj = from_yaml(yaml_str)
    print(obj)

# Generated at 2022-06-20 23:49:16.084688
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'first':'1', 'second':'2'}"
    result = {"first": "1", "second": "2"}
    assert from_yaml(data, 'test_from_yaml.yaml', show_content=True) == result

# Generated at 2022-06-20 23:49:25.583952
# Unit test for function from_yaml
def test_from_yaml():
    data = """---
# Simple string
[test]
a: 'test a'
b: test b
# integer
c: 7
d: 8
e: 9
# float
f: 0.1337
g: 0.73
# Boolean
h: True
i: False
# Test nested dictionaries
j:
    k: 'test'
    l: 1337
    m: True
...
"""

# Generated at 2022-06-20 23:49:38.017204
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('123') == 123
    assert from_yaml('foo') == 'foo'
    assert from_yaml('') == None

    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('[1, 2, "a"]') == [1, 2, 'a']

    assert from_yaml('{"a": "b"}') == {'a': 'b'}
    assert from_yaml('{"a": 123}') == {'a': 123}
    assert from_yaml('{"a": {"b": "c"}}') == {'a': {'b': 'c'}}
    assert from_yaml('{"a": [1,2,3]}') == {'a': [1, 2, 3]}


# Generated at 2022-06-20 23:49:47.137594
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = """
---
- hosts: all
  tasks:
  - name: This plays a message on your terminals
    debug:
      msg: "Hello from Ansible, {{ ansible_distribution }}!"
    tags: example
- hosts: localhos
  tasks:
  - name: This plays a message on your terminals
    debug:
      msg: "Hello from Ansible, {{ ansible_distribution }}!"
    tags: example
   """


# Generated at 2022-06-20 23:49:56.516589
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.parsing.yaml import from_yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import json
    import yaml
    class MyDumper(yaml.Dumper):
        # This emulates the ruamel.yaml.YAML() API
        def __init__(self):
            super(MyDumper, self).__init__(None, default_flow_style=False)

        def dump(self, data):
            return yaml.dump(data, Dumper=MyDumper)

    import string

# Generated at 2022-06-20 23:49:58.797993
# Unit test for function from_yaml
def test_from_yaml():
    # We don't have a good way to test this function
    assert False, "to_yaml() needs to be tested"

# Generated at 2022-06-20 23:50:09.020613
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types

    # Testing to make sure that from_yaml properly converts dicts to immutable dicts
    # A whole list of tests is found in test_collections_module.py
    test_dict = dict(key1=dict(key1=['value1']))
    test_immutable_dict = ImmutableDict(key1=ImmutableDict(key1=['value1']))
    assert_immutable_dict = from_yaml(json.dumps(test_dict))
    assert isinstance(assert_immutable_dict, dict)
    assert isinstance(assert_immutable_dict['key1'], dict)

# Generated at 2022-06-20 23:50:16.700087
# Unit test for function from_yaml
def test_from_yaml():
    """
    Functional test of from_yaml function.
    :return:
    """
    try:
        from_yaml("""
            ---
            foo: true
        """)
        from_yaml("""
            ---
            foo: 1
        """)
        from_yaml("""
            ---
            foo: 1.0
        """)
        from_yaml("""
            ---
            foo: yes
        """)
        from_yaml("""
            ---
            foo: null
        """)
        from_yaml("""
            ---
            foo: foo
        """)
        from_yaml("""
            ---
            foo: foo: false
        """)
    except Exception as e:
        print('from_yaml test failed: %s' % e.__str__())