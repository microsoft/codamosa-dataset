

# Generated at 2022-06-20 23:40:28.801877
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault

    # Invalid YAML (missing ":")
    data = """
    key data
    """
    try:
        from_yaml(data)
        assert False
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in to_native(e)

    # Valid JSON
    data = """
    {
        "key": "data"
    }
    """

    try:
        new_data = from_yaml(data)
    except AnsibleParserError as e:
        print(to_native(e))
        assert False

    assert isinstance(new_data, dict)
    assert new_data.get('key') == "data"

    # Valid YAML

# Generated at 2022-06-20 23:40:37.179614
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''

    print("Testing from_yaml")

    assert from_yaml("""
name: test
""") == {u'name': u'test'}

    assert from_yaml("""
name: ansible
state: present
""") == {u'name': u'ansible', u'state': u'present'}

    assert from_yaml("""
name: ansible
state: present
""", json_only=True) == None

    assert from_yaml("""
name: ansible
state: present
""", json_only=True, file_name='_test_') == None


# Generated at 2022-06-20 23:40:49.881670
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_text

    result = from_yaml('{"foo": "bar"}')
    assert result["foo"] == "bar"

    vault_secrets_file = 'tests/test_vault.yml'

    def check_vault_values(json_only=False):
        with open(vault_secrets_file, 'r') as fd:
            vault_data = to_text(fd.read())

        # assume vault_data was stored in a file called foo.yml
        result = from_yaml(vault_data, file_name='foo.yml', vault_secrets=secrets, json_only=json_only)

# Generated at 2022-06-20 23:40:54.297248
# Unit test for function from_yaml
def test_from_yaml():

    test1 = {'test': 'blah'}
    test2 = "--- \n test: blah \n"
    test3 = '[1, 2, 3]'

    assert from_yaml(test1) == test1
    assert from_yaml(test2) == test1
    assert from_yaml(test3) == [1, 2, 3]

# Generated at 2022-06-20 23:41:03.132720
# Unit test for function from_yaml
def test_from_yaml():
    # build some fake secrets data
    secrets = {
        'password' : 'secret',
        'token' : 'supersecret',
    }
    fake_vars = {
        'foo' : 'bar',
        'baz' : ['1', '2'],
        'nested_dict' : {
            'foo' : 'bar',
            'baz' : 'qux',
        },
    }
    fake_vars2 = {
        'foo' : 'bar',
        'baz' : 'qux',
    }
    fake_vars3 = {
        'password' : 'secret',
        'token' : 'supersecret',
    }

    # test simple json
    json_str = json.dumps(fake_vars)
    result = from_yaml(json_str)

# Generated at 2022-06-20 23:41:09.127431
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('[1, 2, 3]')
    assert result == [1, 2, 3]

    result = from_yaml('foo: bar')
    assert result == {'foo': 'bar'}

    result = from_yaml('true')
    assert result is True

    result = from_yaml('false')
    assert result is False

test_from_yaml()

# Generated at 2022-06-20 23:41:20.073310
# Unit test for function from_yaml
def test_from_yaml():
    data = from_yaml("""
    ---
    - file:
        path: /etc/yum.conf
        state: file
        owner: 'root'
        group: 'root'
        mode: '0644'
        content: |
          #!/usr/bin/python
          #
          # yum.conf example file
          #

    """)

    assert data is not None
    assert data[0]['file']['path'] == '/etc/yum.conf'
    assert data[0]['file']['content']
    assert data[0]['file']['content'].endswith('#')

# Generated at 2022-06-20 23:41:23.711490
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    [
        {
            "user": "root"
        }
    ]
    '''
    expected = [
        {
            'user': 'root'
        }
    ]
    result = from_yaml(data)
    assert(expected == result)

# Generated at 2022-06-20 23:41:32.684166
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    test_file1 = """
    {
        "test": {
            "test1": "test1"
        }
    }
    """
    assert from_yaml(test_file1) == {'test': {'test1': 'test1'}}
    test_file2 = """
    {
        "test": {
            "test1": "test1",
            "test2": "test2",
            "test3": [
                "test31",
                "test32"
            ]
        }
    }
    """
    assert from_yaml(test_file2) == {'test': {'test1': 'test1', 'test2': 'test2', 'test3': ['test31', 'test32']}}
    test

# Generated at 2022-06-20 23:41:45.317328
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Simple unit test for from_yaml().
    '''
    from ansible.compat.tests import unittest

    class TestFromYaml(unittest.TestCase):
        '''
        Test class for from_yaml().
        '''

        def setUp(self):
            ''' setup for test '''
            pass

        def tearDown(self):
            ''' cleanup for test '''
            pass

        def test_json_only(self):
            '''
            Unit test for from_yaml() to try to parse as JSON only.
            '''
            self.assertRaises(ValueError, from_yaml, '{ "foo": "bar"', file_name='<string>', show_content=True, json_only=True)

# Generated at 2022-06-20 23:41:56.940354
# Unit test for function from_yaml
def test_from_yaml():

    def create_file(contents):
        ''' Creates a temporary file and returns its path '''
        import tempfile
        fp = tempfile.NamedTemporaryFile(prefix='ansible-test', delete=False)
        fp.write(contents)
        fp.close()
        return fp.name

    # basic YAML parsing
    s = "{ key: { subkey: value } }"
    assert from_yaml(s) == {'key': {'subkey': 'value'}}

    # basic JSON parsing
    s = "{ \"key\": { \"subkey\": \"value\" } }"
    assert from_yaml(s) == {"key": {"subkey": "value"}}

    # basic check for vault contents

# Generated at 2022-06-20 23:42:04.918123
# Unit test for function from_yaml
def test_from_yaml():
    # Test on valid yaml and json strings
    test_yaml = '{ "a": 1, "b": 2 }'
    test_json = '{ "a": 1, "b": 2 }'
    from_yaml(test_yaml)
    from_yaml(test_json, json_only=True)

    # Test on invalid strings

    # Test on a string that is neither valid json nor yaml
    invalid_string = '''
    {
        "a": 1
        "b": 2
    }
    '''

    try:
        from_yaml(invalid_string)
        assert False
    except AnsibleParserError:
        pass

    try:
        from_yaml(invalid_string, json_only=True)
        assert False
    except AnsibleParserError:
        pass



# Generated at 2022-06-20 23:42:18.214498
# Unit test for function from_yaml
def test_from_yaml():
    ''' 
    Unit test for function from_yaml
    '''
    result = from_yaml('{"key1": [1, 2, 3], "key2": 7}', file_name='<string>')
    assert (result == {"key1": [1, 2, 3], "key2": 7})

    result = from_yaml({"key1": [1, 2, 3], "key2": 7}, file_name='<string>')
    assert (result == {"key1": [1, 2, 3], "key2": 7})

    result = from_yaml({"key1": [1, "2", 3], "key2": 7}, file_name='<string>')
    assert (result == {"key1": [1, "2", 3], "key2": 7})

test_from_y

# Generated at 2022-06-20 23:42:28.290599
# Unit test for function from_yaml

# Generated at 2022-06-20 23:42:34.316611
# Unit test for function from_yaml
def test_from_yaml():
    # Test data
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = b'{"foo": "bar", "baz": "qux"}'

# Generated at 2022-06-20 23:42:47.441407
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import os

    class TestAnsibleMemoize(unittest.TestCase):

        def test_from_yaml(self):

            data = '{"hello": "world"}'
            data_result = {'hello': 'world'}
            self.assertEqual(from_yaml(data), data_result)

            data = 'hello: world'
            data_result = {'hello': 'world'}
            self.assertEqual(from_yaml(data), data_result)

            data = 'hello: world'
            data_result = {'hello': 'world'}
            self.assertEqual(from_yaml(data, json_only=True), data_result)


# Generated at 2022-06-20 23:42:53.549599
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic test and use case example.
    '''
    file_content = {'hello': 'world'}
    data = json.dumps(file_content)

    new_data = from_yaml(data)

    assert file_content == new_data

# Generated at 2022-06-20 23:43:07.265449
# Unit test for function from_yaml
def test_from_yaml():

    def _validate(raw, expected):
        assert from_yaml(raw) == expected

    _validate("'foo'", 'foo')
    _validate("foo: bar", {'foo': 'bar'})
    _validate("foo:\n  bar", {'foo': 'bar'})
    _validate("foo: '1 2 3'", {'foo': '1 2 3'})
    _validate("foo: 1", {'foo': 1})
    _validate("foo: 1.2", {'foo': 1.2})
    _validate("foo: '{{bar}}'", {'foo': '{{bar}}'})
    _validate("foo: '{{bar | baz}}'", {'foo': '{{bar | baz}}'})

# Generated at 2022-06-20 23:43:15.736932
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') is None
    assert from_yaml('1') == 1
    assert from_yaml('{}') == {}
    assert from_yaml('hello: world') == {'hello': 'world'}
    assert from_yaml('a:') is None
    assert from_yaml('a: 1') == {'a': 1}
    assert from_yaml('a: 1\nb: 2') == {'a': 1, 'b': 2}
    assert from_yaml('a: 1\nb: 2\n') == {'a': 1, 'b': 2}
    assert from_yaml('a: b\nc: d') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-20 23:43:30.183773
# Unit test for function from_yaml
def test_from_yaml():

    # Test loading valid YAML file
    import os
    import ansible.release
    ansible_root = os.path.dirname(ansible.__file__)
    yaml_file = os.path.join(ansible_root, 'module_utils', 'facts', 'network.py')
    data = from_yaml(filename=yaml_file)
    assert data['ATH0_MAC'][0:2] == '00', "YAML file did not load correctly"

    # Test loading empty YAML file
    test_file = 'test_empty_yaml.yml'
    with open(test_file, 'w') as handle:
        handle.write('')
    data = from_yaml(filename=test_file)

# Generated at 2022-06-20 23:43:42.467390
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":"b"}') == {"a":"b"}, 'should be equal'
    assert from_yaml("{'a':'b'}") == {"a":"b"}, 'should be equal'
    assert from_yaml("'{\"a\":\"b\"}'") == {"a":"b"}, 'should be equal'
    assert from_yaml("""a: b
b:
  - c
  - d""") == {"a":"b","b":["c","d"]}, 'should be equal'
    assert from_yaml("""a: 1
b:
  c: 3
  d: 4""") == {"a":1,"b":{"c":3,"d":4}}, 'should be equal'
    json_str = json.dumps({"a": "b"})
    assert from_yaml

# Generated at 2022-06-20 23:43:53.131395
# Unit test for function from_yaml
def test_from_yaml():

    # test the "or" case between JSON and YAML
    good_data = '{ "foo": "bar" }'
    assert from_yaml(good_data) == {u'foo': u'bar'}

    good_data = 'foo: bar'
    assert from_yaml(good_data) == {u'foo': u'bar'}

    # Test json error handeling
    bad_data = 'foo'

    try:
        from_yaml(bad_data, json_only=True)
    except AnsibleParserError as e:
        assert to_native(e.orig_exc) == 'No JSON object could be decoded'
    else:
        assert False

# Generated at 2022-06-20 23:44:02.146558
# Unit test for function from_yaml
def test_from_yaml():
    class VAULT(object):
        vault_secrets = {'unknown': 'value'}
    data = '{"key": "value", "dict":{"key":"value"}}'
    new_data = from_yaml(data, vault_secrets=VAULT())
    assert new_data == {u'key': u'value', u'dict': {u'key': u'value'}}
    new_data = from_yaml(data, vault_secrets=VAULT(), json_only=True)
    assert new_data == {u'key': u'value', u'dict': {u'key': u'value'}}

    data = '{"key": "value", "dict":{"key":"{{ unknown }}"}}'
    new_data = from_yaml(data, vault_secrets=VAULT())
    assert new_data

# Generated at 2022-06-20 23:44:14.884874
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import os
    import sys
    import tempfile

    class TestFromYaml(unittest.TestCase):

        def setUp(self):
            self.json_data = """ { "key": "value",
                                    "key2": "value2" } """

            self.yaml_data = """---
                                  - name: task1
                                    debug: "msg={{ item }}"
                                    with_items:
                                      - "I was added later"
                                      - "I was added later2" """

            self.bad_data_file = tempfile.NamedTemporaryFile(suffix='yaml', delete=False)

# Generated at 2022-06-20 23:44:23.496647
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    # Test data that should be parsed as JSON
    j_data = to_bytes(u'{"a": "b"}')
    j_data_broken = to_bytes(u'{"a": "b"')

    # Test data that should be parsed as YAML
    y_data = to_bytes(u'a: b')
    y_data_broken = to_bytes(u'a: b\n')

    # Test data that should be parsed as JSON, but that can be parsed as YAML
    jy_data = to_bytes(u'{"a": "b: c"}')

    # Test data that can't be parsed as neither JSON nor YAML
    bad_data = to_bytes(u'a b')

    # Test a combination of JSON and Y

# Generated at 2022-06-20 23:44:31.199816
# Unit test for function from_yaml
def test_from_yaml():
    # Only checking yaml functionality.
    # File reading and json functionality are tested in other places.
    assert from_yaml('{"Hello": "World"}') == {'Hello': 'World'}

    with pytest.raises(AnsibleParserError):
        from_yaml('{"Hello": "World",')

    assert from_yaml('Hello: World') == {'Hello': 'World'}

    with pytest.raises(AnsibleParserError):
        from_yaml('Hello: World,', json_only=True)

# Generated at 2022-06-20 23:44:43.022430
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml('') is None
    assert from_yaml('', False) is None
    assert from_yaml('---') is None
    assert from_yaml('---\n...') == {}
    assert from_yaml('[foo]') == ['foo']
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar"}', False) == {'foo': 'bar'}

    # These three should throw an AnsibleParserError because they can't be parsed
    try:
        from_yaml('---{}', True)
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-20 23:44:50.058249
# Unit test for function from_yaml
def test_from_yaml():
    data_json = '{"foo": "bar"}'
    data_yaml = 'foo: bar'
    foo_bar, bar_baz = from_yaml(data_json), from_yaml(data_yaml)
    assert foo_bar == bar_baz, "from_yaml fail to parse valid json and yaml"
    assert isinstance(foo_bar, dict) and len(foo_bar) == 1 and foo_bar['foo'] == 'bar', "from_yaml fail to parse json"
    assert isinstance(bar_baz, dict) and len(bar_baz) == 1 and bar_baz['foo'] == 'bar', "from_yaml fail to parse yaml"

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:45:00.859797
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    class TestFromYaml(unittest.TestCase):
        def setUp(self):
            self.original_data = {
                'one': {
                    'key1': 'some data',
                    'key2': 'more data'
                },
                'two': {
                    'key1': 'some data',
                    'key2': 'more data'
                },
                'three': {
                    'key1': 'some data',
                    'key2': 'more data'
                }
            }

            self.yaml_data = u'''
                one:
                    key1: some data
                    key2: more data
                two:
                    key1: some data
                    key2: more data
                three:
                    key1: some data
                    key2: more data
                '''

       

# Generated at 2022-06-20 23:45:11.592269
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
- hosts:
    - server1
    - server2
  remote_user: root
  tasks:
  - name: this is a debug
    debug:
      msg: "{{inventory_hostname}} is an awesome server"
  - name: this is a fail
    fail:
      msg: "I'm not gonna work"
    ignore_errors: yes
'''
    data = from_yaml(yaml_str)

# Generated at 2022-06-20 23:45:25.466181
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "hello": "world" }') == { "hello": "world" }
    assert from_yaml('{ hello: world }') == { "hello": "world" }
    assert from_yaml('hello: world') == { "hello": "world" }

    assert from_yaml('- name: world') == [{ "name": "world" }]
    assert from_yaml('- { name: world }') == [{ "name": "world" }]
    assert from_yaml('- hello: world') == [{ "hello": "world" }]

    assert from_yaml('{"a": {"b": [1, 2, 3]}}') == {"a": {"b": [1, 2, 3]}}

# Generated at 2022-06-20 23:45:34.629758
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='Hello World!')))
            ]
        )

    # Create play object, playbook objects use .load instead of init or new methods,
    # this will also automatically create the task objects from the info provided in play_source
    # above
   

# Generated at 2022-06-20 23:45:44.755550
# Unit test for function from_yaml
def test_from_yaml():
    # Simple test using empty yaml
    yaml_str = ""
    yaml_python = {}


    # More complex yaml
    yaml_str2 = """
---
# example
name:
  # details
  family: Smith   # very common
  given: Alice    # one of the siblings
"""
    yaml_python2 = {'name': {'family': 'Smith', 'given': 'Alice'}}

    assert from_yaml(yaml_str) == yaml_python
    assert from_yaml(yaml_str2) == yaml_python2

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:45:54.727690
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('null') is None
    assert from_yaml('true') is True
    assert from_yaml('false') is False
    assert from_yaml('1') == 1
    assert from_yaml('1.1') == 1.1
    assert from_yaml('1.1e1') == 1.1e1
    assert from_yaml('[1, 2]') == [1, 2]
    assert from_yaml('{"1": 2}') == {"1": 2}
    assert from_yaml('{"1": 2}') != [1, 2]
    assert from_yaml('{"1": 2}') != {"1": 2}
    assert from_yaml('{"1": 2}') != {"2": 2}

# Generated at 2022-06-20 23:46:06.278109
# Unit test for function from_yaml
def test_from_yaml():

    # Test with JSON only, which should not raise an exception
    test_json = '''{
        "a": 1,
        "b": {
            "c": 3,
            "d": [4, 5, 6]
        },
        "c": [7, 8, 9]
    }'''
    test_data = from_yaml(test_json, json_only=True)
    assert isinstance(test_data, dict)
    assert test_data['a'] == 1
    assert test_data['b']['c'] == 3
    assert test_data['b']['d'] == [4, 5, 6]
    assert test_data['c'] == [7, 8, 9]

    # This should raise an exception since it is not valid JSON nor YAML

# Generated at 2022-06-20 23:46:16.621268
# Unit test for function from_yaml
def test_from_yaml():
    test_file = 'test_from_yaml.yml'
    test_data = '''
    - name: hello
      value: world
    '''

    data = from_yaml(test_data, test_file)
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], dict)
    assert len(data[0]) == 2
    assert data[0]["name"] == "hello"
    assert data[0]["value"] == "world"

    test_data = '''---
- name: hello
  value: world'''
    data = from_yaml(test_data, test_file)
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], dict)
    assert len

# Generated at 2022-06-20 23:46:24.457616
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    try:
        from_yaml('1')
        from_yaml('{}')
        from_yaml('- foo')
        from_yaml('name: - foo')
    except Exception as e:
        assert False, "Unit test for function from_yaml failed" \
            " with unexpected error: %s" % str(e)
    else:
        assert True, "Unit test for function from_yaml" \
            " succeeded"

# Generated at 2022-06-20 23:46:35.034205
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": 1, "bar": "2", "baz": 3.0 }') == {"foo": 1, "bar": "2", "baz": 3.0}  # JSON
    assert from_yaml('foo: 1\nbar: 2\nbaz: 3') == {"foo": 1, "bar": "2", "baz": 3}  # YAML
    assert from_yaml('{ "foo": 1, "bar": "2", "baz": 3 }\nfoo: 4\nbar: 5\nbaz: 6.0') == {"foo": 4, "bar": "5", "baz": 6.0}  # JSON followed by YAML

# Generated at 2022-06-20 23:46:44.857822
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # json string
    json_str = '{"foo" : "bar"}'
    ret = from_yaml(json_str, json_only=False)
    assert isinstance(ret, AnsibleMapping)
    assert ret[u'foo'].value == u'bar'
    json.dumps(ret)

    # yaml string
    yaml_str = "foo: bar"
    ret = from_yaml(yaml_str, json_only=False)
    assert isinstance(ret, AnsibleMapping)
    assert ret[u'foo'].value == u'bar'
    AnsibleDumper().dump(ret)

# Generated at 2022-06-20 23:46:57.655717
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Metadata: Specifying a string value for a boolean metadata var
    '''

# Generated at 2022-06-20 23:47:08.039845
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
- {name: foo }
- {name: bar }
- {name: baz }
""") == [
        {u'name': u'foo'},
        {u'name': u'bar'},
        {u'name': u'baz'},
    ]
    assert from_yaml("""---
- foo
- bar
- baz
""") == [u'foo', u'bar', u'baz']


# Generated at 2022-06-20 23:47:19.512700
# Unit test for function from_yaml
def test_from_yaml():
    def assert_yaml_load(data, expected_data):
        loaded_data = from_yaml(data)
        assert loaded_data == expected_data

    # Normal string
    test_yaml = "this is a normal string"
    assert_yaml_load(test_yaml, test_yaml)

    # JSON string
    test_yaml = '{"a": "b", "c": [1,2,3]}'
    assert_yaml_load(test_yaml, json.loads(test_yaml))

    # YAML string
    test_yaml = "a: b\nc:\n  - 1\n  - 2\n  - 3\n"
    assert_yaml_load(test_yaml, {'a': 'b', 'c': [1, 2, 3]})

# Generated at 2022-06-20 23:47:22.767137
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": "b"}') == {"a": "b"}
    assert from_yaml('a: b') == {u"a": u"b"}



# Generated at 2022-06-20 23:47:25.767913
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = "'{{ foo }}'"

    new_data = from_yaml(data, json_only=True)

    assert new_data == data

# Generated at 2022-06-20 23:47:32.267335
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    data = """
    {
        "type": "refresh",
        "name": "data_center",
        "vars": {
            "foo": 1,
            "bar": [2, 3],
            "baz": {"some": "dict"},
            "bat": "{{ foo }}"
        },
        "parent": null
    }
    """

    my_vars = {
        u'foo': 2
    }

    result = from_yaml(data, '<test>', True, my_vars)
    assert result['vars']['bat'] == 2
    assert result['vars']['foo'] == 1

# Generated at 2022-06-20 23:47:43.273709
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"abc" : "def"}') == {"abc": "def"}
    assert from_yaml('abc : def') == {"abc": "def"}
    assert from_yaml('{"a" : "a",}') == {"a": "a",}
    assert from_yaml('a: a') == {"a": "a"}
    assert from_yaml('- 2') == [2]
    assert from_yaml('- 2\n- 3') == [2, 3]
    assert from_yaml('2') == 2
    assert from_yaml('2.0') == 2.0
    assert from_yaml('a') == 'a'
    assert from_yaml('null') is None
    assert from_yaml('-') is None
    assert from_yaml(':') is None

# Generated at 2022-06-20 23:47:47.564673
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "test": "foo" }') == {"test": "foo"}
    assert "test" not in from_yaml('{ test: "foo" }')
    assert "test" not in from_yaml('test: "foo"')

# Generated at 2022-06-20 23:47:55.985403
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test cases for function from_yaml
    '''
    test_cases = [
        ["", None],
        ["[]", []],
        ["{}", {}],
        ["1", 1],
        ["\"a\"", "a"],
        ["1.1", 1.1],
        ["true", True],
        ["false", False],
        ["null", None],
        [
            "["
            "   1,"
            "   2,"
            "   3,"
            "]",
            [1,2,3]
        ],
        [
            "{"
            "   \"one\": 1,"
            "   \"two\": 2,"
            "   \"three\": 3"
            "}",
            {"one":1, "two":2, "three":3}
        ]
    ]


# Generated at 2022-06-20 23:48:07.887994
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test that from_yaml works with different types of yaml files and a json file.
    '''

    # Use yaml file with no extension.
    data = open(os.path.join(os.path.dirname(__file__), 'test_yaml')).read()
    assert from_yaml(data, 'test_yaml')

    # Use yaml file with .yml extension.
    data = open(os.path.join(os.path.dirname(__file__), 'test_yaml.yml')).read()
    assert from_yaml(data, 'test_yaml.yml')

    # Use yaml file with .yaml extension.

# Generated at 2022-06-20 23:48:17.053167
# Unit test for function from_yaml
def test_from_yaml():
    # Make function from_yaml available.
    import sys
    import os
    oldpath = sys.path
    sys.path = [os.path.dirname(os.path.realpath(__file__)) + '/../../'] + sys.path
    from ansible.parsing.yaml.loader import from_yaml
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.module_utils._text import to_text
    sys.path = oldpath

    data = "'python string'\n"
    # Expect the same
    assert data == to_text(from_yaml(data), errors='strict')

    data = "'python string'"
    assert data == to_text(from_yaml(data), errors='strict')

    data = "True\n"

# Generated at 2022-06-20 23:48:36.742700
# Unit test for function from_yaml
def test_from_yaml():

    # test JSON
    json_str = '{"foo": "bar"}'
    data = from_yaml(json_str)
    assert data == {"foo": "bar"}, 'from_yaml returned %s' % data

    # test YAML
    yaml_str = '''
    ---
    - name: foo1
      value: bar1
    - name: foo2
      value: bar2
    '''
    data = from_yaml(yaml_str)
    assert data == [{u'name': u'foo1', u'value': u'bar1'}, {u'name': u'foo2', u'value': u'bar2'}], \
            'from_yaml returned %s' % data

    # test JSON with vault
    vault_password = 'secret'
    vault_secrets

# Generated at 2022-06-20 23:48:39.561867
# Unit test for function from_yaml
def test_from_yaml():
    data = "---\n" \
           "test string"

    assert from_yaml(data) == "test string"


# Generated at 2022-06-20 23:48:51.761778
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

    data = dict(a=1, b=2, c=3)

    yaml_data = AnsibleDumper.dump(data, default_flow_style=False)
    assert from_yaml(yaml_data) == data

    json_data = json.dumps(data, cls=AnsibleJSONEncoder)
    assert from_yaml(json_data, json_only=True) == data

    try:
        from_yaml(json_data, json_only=True)
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in to_native(e)

# Generated at 2022-06-20 23:49:01.633223
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1,2,3]") == [1,2,3]
    # Backslash is not permitted as start of escape sequence
    assert from_yaml("[1,\n2,3]") == [1,'\n2',3]
    # Line break is not permitted between bracket and curly brace
    assert from_yaml("[\n1,\n  2,\n  3\n]") == [1,2,3]
    # Expected <block end>, but found '<block mapping start>'

# Generated at 2022-06-20 23:49:08.208737
# Unit test for function from_yaml
def test_from_yaml():
    data = \
    '''
    {
        "name": "myhost.example.com",
        "ansible_ssh_host": "10.10.10.10",
        "ansible_ssh_port": 22,
        "ansible_ssh_user": "root",
        "ansible_ssh_pass": "password",
        "foo": "bar"
    }
    '''
    assert type(from_yaml(data)) is dict

# Generated at 2022-06-20 23:49:18.786395
# Unit test for function from_yaml
def test_from_yaml():
    # load a json string as yaml
    data = '{"test_key": "test_data"}'
    new_data = from_yaml(data)
    assert new_data['test_key'] == "test_data"

    # load a json string as json
    new_data = from_yaml(data, json_only=True)
    assert new_data['test_key'] == "test_data"

    # load a yaml string as yaml
    data = '''
    test_key:
      - test_data_1
      - test_data_2
      - test_data_3
    '''
    new_data = from_yaml(data)
    assert new_data['test_key'] == ['test_data_1', 'test_data_2', 'test_data_3']

   

# Generated at 2022-06-20 23:49:27.217595
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import yaml
    testfile = open("/tmp/test.yml", "w")
    testfile.write("""
    ---
    name: "test"
    """)
    testfile.close()

# Generated at 2022-06-20 23:49:35.684963
# Unit test for function from_yaml
def test_from_yaml():

    import sys

    # The following is a yaml string taken from an ansible yaml test file.
    data = """
    - hosts: localhost
      tasks:
      - name: this is just a placeholder
        ping: {}
    """
    # We use the from_yaml() function to load the data into a python datastructure.
    # If it fails we raise an error.
    try:
        from_yaml(data)
    except AnsibleParserError as e:
        print("Exception caught : {0}".format(e.message))
        sys.exit(1)

# Generated at 2022-06-20 23:49:44.569419
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}")
    assert from_yaml("{'foo': 'bar'}", json_only=True)
    assert from_yaml("""\
    ---
    - hosts: localhost
      connection: local
      tasks:
        - name: do something
          debug: msg="hello world"
          when: true
    """)
    try:
        assert from_yaml("{'foo': 'bar'", json_only=True)
    except AnsibleParserError as e:
        assert e.message.startswith("We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: ")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:49:51.249758
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1') == 1
    assert from_yaml('-5') == -5
    assert from_yaml('0') == 0
    assert from_yaml('null') == None
    assert from_yaml('true') == True
    assert from_yaml('false') == False
    assert from_yaml('3.14') == 3.14
    assert from_yaml('""') == ""
    assert from_yaml('"text"') == "text"
    assert from_yaml('"http://docs.ansible.com/ansible/"') == "http://docs.ansible.com/ansible/"
    assert from_yaml('"/home/user/file.txt"') == "/home/user/file.txt"
    assert from_yaml('"file_\n_path"')

# Generated at 2022-06-20 23:50:10.317699
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Run through some basic test cases for from_yaml()
    '''


# Generated at 2022-06-20 23:50:18.939223
# Unit test for function from_yaml
def test_from_yaml():
    """test from_yaml/test_from_yaml"""
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    assert from_yaml('{ "some_key": [ "2", 3 ] }') == {'some_key': ['2', 3]}
    assert from_yaml('some_key:\n- 2\n- 3') == {'some_key': ['2', 3]}
    assert isinstance(from_yaml('!unsafe foo bar'), AnsibleUnsafeText)
    assert from_yaml('!unsafe foo bar', json_only=True) == '!unsafe foo bar'