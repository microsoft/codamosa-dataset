

# Generated at 2022-06-20 23:40:26.133032
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import os

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestFromYaml(unittest.TestCase):
        def testEnsureTrue(self):
            my_data = '''{"a": "b", "c": "d"}'''

            try:
                new_data = from_yaml(my_data)
                self.assertEqual(new_data, {u'a': u'b', u'c': u'd'})
            except AnsibleParserError as e:
                self.assertTrue(False, 'AnsibleParserError raised: %s' % e)


# Generated at 2022-06-20 23:40:34.453577
# Unit test for function from_yaml
def test_from_yaml():

    data1 = '''{
        "name": "tungshou",
        "age": 12
    }'''
    new_data1 = json.loads(data1, cls=AnsibleJSONDecoder)
    print(new_data1)

    data = '''
        {
            "name": "tungshou",
            "age": 12,
            "list": [1, 2, 3],
            "dict": {"a":1, "b":2},
            "true": true,
            "false": false,
            "null": null
        }
        '''
    data = '''
name: tungshou
age: 12
dict: {a: 1, b: 2}
true: true
false: false
null: null
'''

# Generated at 2022-06-20 23:40:40.606042
# Unit test for function from_yaml
def test_from_yaml():
    try:
        # Use this function to test the from_yaml function
        test_data = from_yaml("""
        {{ lookup('lookup_plugin') }}
        - hosts: localhost
          tasks:
            - name: test
              debug:
                msg: "{{ item }}"
              with_items:
                - 15
                - 20
        """)
        assert test_data[1]['hosts'] == ['localhost']
    except Exception:
        print("{0}: [ERROR] parsing problem happened".format(__file__))
        assert False

# Generated at 2022-06-20 23:40:49.418561
# Unit test for function from_yaml
def test_from_yaml():
    # It should accept a JSON string and create a data structure
    assert from_yaml('{"key": "val"}') == {'key': 'val'}

    # It should accept a YAML string and create a data structure
    assert from_yaml('key: val') == {'key': 'val'}

    # It should raise an exception if the input is neither JSON or YAML
    from ansible.errors.yaml_strings import YAML_SYNTAX_ERROR
    try:
        from_yaml('foo: bar', file_name='none')
    except AnsibleParserError as e:
        assert YAML_SYNTAX_ERROR in to_native(e)

# Generated at 2022-06-20 23:40:53.849303
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml("hello world")
    except AnsibleParserError:
        pass

    try:
        from_yaml("{ hello: world")
    except AnsibleParserError:
        pass

    assert from_yaml("{ hello: world }") == {"hello": "world"}

# Generated at 2022-06-20 23:41:02.162316
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml('{ "foo": "bar", "baz": [ "a", "b", "c" ], "multiple": { "levels": { "of": "nesting" } } }') == \
        { 'foo': 'bar', 'baz': ['a', 'b', 'c'], 'multiple': { 'levels': { 'of': 'nesting' }} })

    assert(from_yaml('{ foo: bar, baz: [ a, b, c ], multiple: { levels: { of: nesting } } }') == \
        { 'foo': 'bar', 'baz': ['a', 'b', 'c'], 'multiple': { 'levels': { 'of': 'nesting' }} })

# Generated at 2022-06-20 23:41:14.267749
# Unit test for function from_yaml
def test_from_yaml():
    # Invalid JSON
    result = from_yaml(data='{invalid_json_data}', file_name='<test>')
    assert isinstance(result, AnsibleParserError)

    # Valid JSON
    result = from_yaml(data='{"valid_json_data": "test"}', file_name='<test>')
    assert isinstance(result, dict)
    assert result['valid_json_data'] == 'test'

    # Invalid YAML
    result = from_yaml(data='{invalid_yaml_data}', file_name='<test>', json_only=True)
    assert isinstance(result, AnsibleParserError)

    # Valid YAML

# Generated at 2022-06-20 23:41:17.897038
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": 42}') == {u'foo': 42}
    assert from_yaml('foo: 42') == {u'foo': 42}

# Generated at 2022-06-20 23:41:25.394453
# Unit test for function from_yaml
def test_from_yaml():
    # test case for https://github.com/ansible/ansible/issues/19833
    # We expect to load valid YAML
    try:
        result = from_yaml("---\n- name: foo\n  value: 1")
        assert result
        assert result[0]['name'] == 'foo'
        assert result[0]['value'] == 1
    except AnsibleParserError:
        assert False, "should not have failed to parse YAML"

# Generated at 2022-06-20 23:41:35.534392
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"spam": "ham"}') == {"spam": "ham"}
    assert from_yaml('spam: ham') == {"spam": "ham"}
    assert from_yaml('---\n- foo\n- bar\n') == ["foo", "bar"]
    assert from_yaml('[foo, bar]') == ["foo", "bar"]
    assert from_yaml('[foo, "bar", [{}, "nested"], "foo"]') == ["foo", "bar", [{}, "nested"], "foo"]
    assert from_yaml('{foo: bar}') == {"foo": "bar"}
    assert from_yaml('foo: bar') == {"foo": "bar"}

# Generated at 2022-06-20 23:41:48.633959
# Unit test for function from_yaml

# Generated at 2022-06-20 23:41:59.538517
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils import context_objects as co

    from ansible.parsing.dataloader import DataLoader

    def set_context(**kwargs):
        for k,v in kwargs.items():
            setattr(co, k, v)

    dl = DataLoader()

    set_context(vault_secrets=['secret_key'])

    assert from_yaml("{}") == {}
    assert from_yaml("{'key': 'value'}") == {'key': 'value'}
    assert from_yaml("key: value") == {'key': 'value'}
    assert from_yaml("{'key': 'value'}", json_only=True) == {'key': 'value'}

# Generated at 2022-06-20 23:42:12.798745
# Unit test for function from_yaml
def test_from_yaml():

    class Secret:
        def __init__(self, secret):
            self.secret = secret

        def decode(self):
            return self.secret

    case1 = {'foo': 1, 'bar': '{{secret}}'}
    case1_expected = {'foo': 1, 'bar': 'secret'}

    assert from_yaml(json.dumps(case1), vault_secrets={'secret': Secret('secret')}) == case1_expected

    assert from_yaml(json.dumps(case1), vault_secrets={'secret': {'vault_secret': 'secret'}}) == case1_expected


    case2 = {'foo': '{{secret}}'}
    case2_expected = {'foo': '{{secret}}'}


# Generated at 2022-06-20 23:42:17.614716
# Unit test for function from_yaml
def test_from_yaml():

    data = """
a: 1
b:
  c: 3
  d: 4
"""

    data_json = """
{
  "a":1,
  "b":{
    "c":3,
    "d":4
  }
}
"""

    assert from_yaml(data) == from_yaml(data_json)
    assert from_yaml(data, json_only=True) != from_yaml(data_json, json_only=True)
    assert from_yaml(data) == from_yaml(data_json, json_only=True)

# Generated at 2022-06-20 23:42:27.805265
# Unit test for function from_yaml
def test_from_yaml():
    data = "'{ foo: 1, bar: 2 }'"
    yaml.safe_load(data)
    data = "'{ foo: 1, bar: 2 }'"
    yaml.load(data)
    data = "'{ foo: 1, bar: 2 }'"
    yaml.load(data, Loader=yaml.FullLoader)
    data = "{ foo: 1, bar: 2 }"
    yaml.safe_load(data)
    data = "{ foo: 1, bar: 2 }"
    yaml.load(data)
    data = "{ foo: 1, bar: 2 }"
    yaml.load(data, Loader=yaml.FullLoader)
    # not vulnerable
    data = "{ foo: !!python/object:datetime.datetime 2012-12-21T12:00:00 }"
   

# Generated at 2022-06-20 23:42:36.143991
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import Mapping

    data_str_j = '{"foo": {"bar": "baz"}}'
    data_str_y = '''foo:
      bar: baz
    '''

    data_j = from_yaml(data_str_j)
    data_y = from_yaml(data_str_y)

    assert isinstance(data_j, Mapping)
    assert isinstance(data_y, Mapping)
    assert data_j == data_y



# Generated at 2022-06-20 23:42:49.305396
# Unit test for function from_yaml
def test_from_yaml():
    class A(object): pass

    # Some examples of serialized data.  The json is a representation of
    # the YAML, so we don't have to deal with quoting issues.

# Generated at 2022-06-20 23:42:57.115939
# Unit test for function from_yaml
def test_from_yaml():

    test_data = [
                    ("1", 1),
                    ('{"foo": "bar"}', {"foo": "bar"}),
                    ('foo: bar', {"foo": "bar"}),
                    ('foo: 1', {"foo": 1}),
                    ('foo bar', None),
                    ('true', None),
              ]

    for data, expected in test_data:
        assert from_yaml(data) == expected

# Generated at 2022-06-20 23:43:03.041285
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}', json_only=True) == { "foo": "bar" }

    try:
        from_yaml('foo: bar', json_only=True)
        assert False
    except AnsibleParserError as e:
        assert str(e).startswith('We were unable')



# Generated at 2022-06-20 23:43:12.820144
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.compat import PY3
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.compat.tests.mock import patch
    import sys

    TEST_DICT_INPUT = {
        'foo': 'bar',
        'bar': 'baz',
        'baz': [1, 'quux'],
        1: 'quux',
        'qux': True,
        'quux': False,
        'corge': None
    }

    # Test 1: generate some yaml bytecode and parse it
    TEST_YAML_DATA = AnsibleDumper().encode(TEST_DICT_INPUT)

    if not PY3:
        TEST_Y

# Generated at 2022-06-20 23:43:30.865638
# Unit test for function from_yaml
def test_from_yaml():

    data = """
    { 
        "foo": "bar",
        "list": [1, 2, 3],
        "dict": {
            "key": "value"
        },
        "quoted_num": "1"
    }
    """

    expected_data = {
        "foo": "bar",
        "list": [1, 2, 3],
        "dict": {
            "key": "value"
        },
        "quoted_num": "1"
    }

    result = from_yaml(data)
    assert expected_data == result

    data = """
    ---
    foo: bar
    list: [1, 2, 3]
    dict: {
        key: value
    }
    quoted_num: "1"
    """

# Generated at 2022-06-20 23:43:34.643726
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_return = from_yaml(data='test data', file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    assert from_yaml_return == "test data"

# Test with Vault

# Generated at 2022-06-20 23:43:43.446918
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    # Create a Vault object so we can decrypt vaulted content
    vault = VaultLib([])
    vault.update_secrets(['password'], '123')   # password is a dict, must use update_secrets()

    # valid json
    json_str = '{"a": 1, "b": 2}'
    assert from_yaml(json_str, json_only=True) == {'a': 1, 'b': 2}

    # valid yaml
    yaml_str = '''\
    a: 1
    b: 2'''
    assert from_yaml(yaml_str) == {'a': 1, 'b': 2}

    # json that is not valid y

# Generated at 2022-06-20 23:43:45.024488
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-20 23:43:48.649123
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('''
- hosts: web
  become: yes''')
    assert result == [{'hosts': 'web', 'become': True}]


# Generated at 2022-06-20 23:43:50.739749
# Unit test for function from_yaml
def test_from_yaml():
    result=from_yaml("{\"a\" : true}")
    assert result == {"a": True}

# Generated at 2022-06-20 23:44:00.848256
# Unit test for function from_yaml
def test_from_yaml():
    stream = "{'a': 1, 'b': 2}"
    try:
        new_data = from_yaml(stream)
        assert False
    except AnsibleParserError as e:
        assert to_native(e) == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)\n\nFailed to parse the playbook\n\nThe error appears to be in \'/tmp/ansible_ansible-parser_payload.json\': line 1, column 1, but may\nbe elsewhere in the file depending on the exact syntax problem.\n\nThe offending line appears to be:\n\n{\'a\': 1, \'b\': 2}\n^ here'

# Generated at 2022-06-20 23:44:12.837878
# Unit test for function from_yaml

# Generated at 2022-06-20 23:44:22.364335
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    # Test that yaml is converted to Ansible mapping
    yaml_dict = from_yaml('{"key": "value"}')
    assert isinstance(yaml_dict, AnsibleMapping)
    assert yaml_dict.get('key') == 'value'

    # Test that yaml with comments is converted to Ansible mapping
    yaml_dict_with_comments = from_yaml('# this is a comment\n{"key": "value"}')
    assert isinstance(yaml_dict_with_comments, AnsibleMapping)
    assert yaml_dict_with_comments.get('key') == 'value'

    # Test that yaml is converted to Ansible sequence

# Generated at 2022-06-20 23:44:31.199126
# Unit test for function from_yaml
def test_from_yaml():
    res = from_yaml("""
# ansible-vault-password-file is the path to the password file
# used to decrypt the inventory file given with "-i".
ansible-vault-password-file = /etc/ansible/secrets.txt

[all:vars]
ssh_key_file = /home/me/.ssh/my_private_key
my_cache_dir = /home/me/.cache/my_cache_dir
    """)

    assert res == {'ssh_key_file': '/home/me/.ssh/my_private_key', 'my_cache_dir': '/home/me/.cache/my_cache_dir'}

# Generated at 2022-06-20 23:44:39.565475
# Unit test for function from_yaml

# Generated at 2022-06-20 23:44:44.548735
# Unit test for function from_yaml
def test_from_yaml():
    import os
    main_dir = os.path.dirname(os.path.dirname(__file__))
    print(from_yaml(open(os.path.join(main_dir, '../../ansible/playbooks/samples/simple.yaml')).read()))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:44:56.649659
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"items": [{"_id":"WP8sTJTzdxeT"}, {"_id":"Ww8sTJTzdxeT"}]}', json_only=True) == {u'items': [{u'_id': u'WP8sTJTzdxeT'}, {u'_id': u'Ww8sTJTzdxeT'}]}
    assert from_yaml('["foo", "bar"]') == [u'foo', u'bar']

# Generated at 2022-06-20 23:45:05.051489
# Unit test for function from_yaml
def test_from_yaml():

    import ansible.constants as C
    from ansible.parsing.vault import VaultLib

    def _test_from_yaml(data, result):
        decoded = from_yaml(data)
        assert decoded == result

    _test_from_yaml('{"a": "b"}', dict(a='b'))
    _test_from_yaml('hello: world', dict(hello='world'))
    _test_from_yaml('["foo", "bar"]', ['foo', 'bar'])
    _test_from_yaml('- foo\n- bar', ['foo', 'bar'])
    # One use case is with variables through the command line
    _test_from_yaml('{ "foo": "{{bar}}" }', dict(foo='{{bar}}'))

    # Test vault

# Generated at 2022-06-20 23:45:10.625715
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = "{ name: 'Vivek', occupation: 'Network Engineer' }"
    json_str = '{"name": "Vivek", "occupation": "Network Engineer"}'

    print(from_yaml(yaml_str))
    print(from_yaml(json_str))

test_from_yaml()

# Generated at 2022-06-20 23:45:22.595809
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.tests.unit.parser.test_yaml import TestYaml

    test_instance = TestYaml()

    yaml_string_single = '''
        ---
        string: v1
        integer: 42
        '''

    dict_single = {
        'string': 'v1',
        'integer': 42,
        }

    yaml_string_multiple = '''
        ---
        - string: v1
           integer: 42
        - string: v2
           integer: 43
        '''

    dict_multiple = [
            {
                'string': 'v1',
                'integer': 42,
                },
            {
                'string': 'v2',
                'integer': 43,
                },
            ]

    # test from_yaml
    assert test_instance.from_yaml

# Generated at 2022-06-20 23:45:24.147432
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{ "test": "value" }')

# Generated at 2022-06-20 23:45:32.267825
# Unit test for function from_yaml
def test_from_yaml():
    import os, sys

    here = os.path.dirname(__file__)
    lib = os.path.join(here, '..', '..')
    sys.path.insert(0, lib)
    from unittest.mock import MagicMock, patch

    import json

    import ansible.parsing.vault
    import ansible.parsing.vault_lib.vaultsecrets

    import pytest

    class TestVaultSecrets(ansible.parsing.vault.VaultLib):
        def __init__(self, secrets=None, vault_password_file=None,
                     ask_vault_pass=False, team_vault_password_file=False):
            pass

        def format_secret(self, secret):
            return secret.replace(',', '\n')



# Generated at 2022-06-20 23:45:39.544175
# Unit test for function from_yaml
def test_from_yaml():

    # This is the test string we will read from.
    # It consists of a single dictionary, with a single value,
    # the key is "hello", the value is "world".
    test_yaml = """
---
hello: world
"""
    # We should get back a python dictionary with one key/value pair.
    # The key should be "hello", and the value should be "world"
    expected = dict(hello='world')

    assert from_yaml(test_yaml) == expected

# Generated at 2022-06-20 23:45:43.565559
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    a: 1
    b:
      c: 3
      d: 4
'''
    assert from_yaml(test_data) == {'a': 1, 'b': {'c': 3, 'd': 4}}

# Generated at 2022-06-20 23:46:03.410372
# Unit test for function from_yaml
def test_from_yaml():
    # Sample yaml.safe_load() function
    # test 1:
    data = '{ foo: { bar: {baz: blah} } }'
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    new_data = from_yaml(data=data, file_name=file_name, show_content=show_content, vault_secrets=vault_secrets, json_only=json_only)
    assert new_data == {'foo': {'bar': {'baz': 'blah'}}}

    # test 2:
    data = '{ foo: { bar: {baz: blah} } }'
    file_name = 'test1.json'
    show_content = False
    vault_secrets = None


# Generated at 2022-06-20 23:46:10.820539
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    json_data = '{"lldp_interfaces": "eth1"}'
    yaml_data = '''
    lldp_interfaces:
      - eth1
      - eth2
    '''
    assert from_yaml(json_data) == {"lldp_interfaces": "eth1"}
    assert from_yaml(yaml_data) == {"lldp_interfaces": ["eth1", "eth2"]}

# Generated at 2022-06-20 23:46:19.368238
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml.objects
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    c = PlayContext()
    l = lookup_loader()
    l.set_loader_context(c)
    data = "{ foo: 'bar' }"
    res = from_yaml(data, json_only=True)
    ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.fail_on_missing_variables = True
    res2 = from_yaml(data, json_only=False)
    assert res == res2

    # bad data, get a dict back
    data = "{ foo: 'bar, baz: 42}"
    res = from_yaml(data, json_only=True)
   

# Generated at 2022-06-20 23:46:22.470585
# Unit test for function from_yaml
def test_from_yaml():
    """
    basic test of from_yaml()
    """
    a = from_yaml("a: b")
    assert a == {"a": "b"}

# Generated at 2022-06-20 23:46:27.615185
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.hostvars import HostVars

    # Test that a string is returned unmodified.
    test_string = "test string"
    assert from_yaml(test_string) == test_string

    # Test that a JSON string is returned as a dictionary.
    test_json_string = '{"a": "b"}'
    assert from_yaml(test_json_string) == {'a': 'b'}

    # Test that a YAML string is returned as a dictionary.
    test_yaml_string = '---\na: b'
    assert from_yaml(test_yaml_string) == {'a': 'b'}

    # Test that a HostVars object is returned unmodified.

# Generated at 2022-06-20 23:46:38.814237
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.dataloader
    import ansible.parsing.vault

    # Testing a yaml file
    data = ansible.parsing.dataloader.load_from_file("./test_from_yaml.yml")
    assert(data['test_from_yaml'] == 'ok')
    # Testing a json file
    data = ansible.parsing.dataloader.load_from_file("./test_from_yaml.json")
    assert(data['test_from_yaml'] == 'ok')
    # Testing a yaml string
    data = ansible.parsing.dataloader.load(u'test_from_yaml: ok')
    assert(data['test_from_yaml'] == 'ok')
    # Testing

# Generated at 2022-06-20 23:46:46.756038
# Unit test for function from_yaml
def test_from_yaml():
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))

    with open(dir_path + '/' + 'test.yml') as test_file:
        data = test_file.read()

    test = from_yaml(data)
    assert isinstance(test, dict)
    assert test['test_string'] == 'test_value'
    assert test['test_boolean']
    assert test['test_number'] == 123
    assert test['test_list'] == ['test1', 'test2']
    assert test['test_dict']['test_string'] == 'test_value'
    assert test['test_dict']['test_boolean']
    assert test['test_dict']['test_number'] == 123

# Generated at 2022-06-20 23:46:53.575302
# Unit test for function from_yaml
def test_from_yaml():
    ''' Not the best test, however the file currently contains unicode '''
    file_name = 'tests/fixtures/unicode_sample.yaml'
    with open(file_name, 'rb') as f:
        data = f.read()
        result = from_yaml(data.decode('utf-8'), file_name)
        assert result['unicode'] == 'こんにちは'

# Generated at 2022-06-20 23:47:05.320214
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import get_file_vault_secret

    d = DataLoader()

    # Test for error on invalid yaml

    test_data = """
    - hosts: all
        gather_facts: False
        tasks:
          - name: print hello world
            debug:
              msg: "{{ 'hello' | repeat(2) }} world"
    """

    with pytest.raises(AnsibleParserError) as ex:
        from_yaml(test_data)

    assert "mapping values are not allowed here" in to_native(ex.value)


# Generated at 2022-06-20 23:47:10.760275
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('foo') is None
    assert from_yaml('') is None
    assert from_yaml('{ "foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('- foo') == ['foo']

# Generated at 2022-06-20 23:47:30.408859
# Unit test for function from_yaml
def test_from_yaml():
    test_data = 'foo: [1,2,3]'
    test_output = from_yaml(test_data)
    assert test_output['foo'][0] == 1

# Generated at 2022-06-20 23:47:37.403497
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

# Generated at 2022-06-20 23:47:49.753484
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.compat import BytesIO

    yaml.add_constructor('!decode', lambda loader, node: node.value)

# Generated at 2022-06-20 23:47:57.022926
# Unit test for function from_yaml
def test_from_yaml():
    data = dict()
    data['test_one'] = ['test_one', 'test_two']
    data['another_key'] = {'dict': 'inside'}

    yaml_str = '---\n'
    yaml_str = yaml_str + 'test_one:\n'
    yaml_str = yaml_str + '- test_one\n'
    yaml_str = yaml_str + '- test_two\n'
    yaml_str = yaml_str + 'another_key:\n'
    yaml_str = yaml_str + '  dict: inside\n'

    data_from_yaml = from_yaml(yaml_str)

    # Testing if data is equal to data_from_yaml
    assert data == data_from_yaml


#

# Generated at 2022-06-20 23:48:09.595550
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Define tests

# Generated at 2022-06-20 23:48:12.389753
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{"foo": "bar"}')
    from_yaml('foo: bar')
    from_yaml('foo: bar', json_only=True)

# Generated at 2022-06-20 23:48:18.785381
# Unit test for function from_yaml
def test_from_yaml():
    file_name = 'test_yaml'
    data = '''
            ---
            False: False
            True: True
            None: null
            String: strings
            Integer: 1234
            Float: 3.14
            Array:
              - a
              - b
              - c
            Dict:
              k1: v1
              k2: v2
            Complex:
              - 1
              -
                - 1.1
                - 1.2
                - 1.3
              -
                key_a: val_a
                key_b: val_b
                key_c: val_c
                dict_key:
                  foo: bar
            '''
    new_data = from_yaml(data, file_name)
    assert new_data['False'] is False
    assert new_data['True']

# Generated at 2022-06-20 23:48:24.239305
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''{"version": "12.1", "hostname": "test"}'''
    assert isinstance(from_yaml(test_data), dict)

    test_data = '''version: "12.1"\nhostname: "test"'''
    assert isinstance(from_yaml(test_data), dict)

# Generated at 2022-06-20 23:48:33.641014
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1,2,3]") == [1,2,3]
    assert from_yaml("[1,2,3]", json_only=True) == [1,2,3]
    assert from_yaml("{'a':'b'}") == {'a':'b'}
    assert from_yaml("{'a':'b'}", json_only=True) == {'a':'b'}
    assert from_yaml("- 1\n- 2\n- 3") == [1,2,3]
    assert from_yaml("- !include test.yaml") == [-1]

# Generated at 2022-06-20 23:48:38.343218
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == {"foo": "bar"}
    # Verify that the yaml parser can parse both single quotes and double quotes
    assert from_yaml("""{ 'foo': 'bar' }""") == {'foo': 'bar'}
    assert from_yaml("""{ "foo": "bar" }""") == {'foo': 'bar'}



# Generated at 2022-06-20 23:49:14.121779
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('')

# Generated at 2022-06-20 23:49:22.188841
# Unit test for function from_yaml
def test_from_yaml():
    data = """
        {
            "bar": [ "baz", "qux" ]
        }
    """
    assert from_yaml(data, json_only=True) == {"bar": ["baz", "qux"]}
    data = """
        bar: [ "baz", "qux" ]
    """
    assert from_yaml(data) == {"bar": ["baz", "qux"]}
    data = """
        - "baz"
        - "qux"
    """
    assert from_yaml(data) == ["baz", "qux"]



# Generated at 2022-06-20 23:49:28.767029
# Unit test for function from_yaml
def test_from_yaml():
    import os
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    os.system('echo "hi" > /tmp/test.yml')

    data = from_yaml("""
    foo:
      - bar
      - 123
      - true

    num: 123

    str: "foo"

    bool: false

    - bar
    """,'/tmp/test.yml',False)

    assert type(data) == AnsibleMapping

# Generated at 2022-06-20 23:49:33.020834
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1,2,3]') == [1,2,3]
    assert from_yaml('{}') == {}
    assert from_yaml('{"a":"b"}') == {"a":"b"}

# Generated at 2022-06-20 23:49:43.029082
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}") == {'a': 'b'}
    assert from_yaml("{'a': 'b'}", json_only=True) == {'a': 'b'}
    assert from_yaml("a: b") == {'a': 'b'}
    assert from_yaml("a: b", json_only=True) == {'a': 'b'}
    assert from_yaml("{\"a\": \"b\"}") == {'a': 'b'}
    assert from_yaml("{\"a\": \"b\"}", json_only=True) == {'a': 'b'}
    assert from_yaml("a: b") == {'a': 'b'}

# Generated at 2022-06-20 23:49:48.648128
# Unit test for function from_yaml
def test_from_yaml():
    ''' Test whether the from_yaml function returns the same, as the
    corresponding version from the module lib'''
    import yaml
    for data in ['["foo", {"bar":["baz", null, 1.0, 2]}]',
                 """
        foo:
          - 1
          - 2
          - 3
        bar:
            bam: true
                 """]:
        data = yaml.safe_load(data)
        assert data == from_yaml(yaml.dump(data, default_flow_style=False))

# Generated at 2022-06-20 23:49:58.799477
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Setup some test cases
    basic_test_cases = [
        ("foo", "foo"),
        (1234, 1234),
        (1.23, 1.23),
        (True, True),
        ([1,2,3], [1,2,3]),
        (dict(a=1, b=2, c=3), dict(a=1, b=2, c=3))
    ]

    # Test basic JSON/YAML cases
    print("Testing basic cases...")
    for data, expected_result in basic_test_cases:
        JSON_STRING = json.dumps(data)
        YAML_STRING = AnsibleDumper(data).get_single_data()

# Generated at 2022-06-20 23:50:09.727976
# Unit test for function from_yaml
def test_from_yaml():
    # This should work
    d = {'foo': 'bar'}
    j = '{"foo": "bar"}'
    y = '---\nfoo: bar'

    assert from_yaml(j) == d
    assert from_yaml(y) == d

    # This should fail
    bad_j = '{"foo": "bar"'
    bad_y = '---\nfoo: bar\n---'

    try:
        from_yaml(bad_j)
    except Exception as json_exc:
        try:
            from_yaml(bad_y)
        except Exception as yaml_exc:
            _handle_error(json_exc, yaml_exc, '', True)
        else:
            assert False, 'yaml should have failed'

# Generated at 2022-06-20 23:50:13.711619
# Unit test for function from_yaml
def test_from_yaml():
    """ Test some values """
    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"a": 1, "b": "c"}') == {'a': 1, 'b': 'c'}