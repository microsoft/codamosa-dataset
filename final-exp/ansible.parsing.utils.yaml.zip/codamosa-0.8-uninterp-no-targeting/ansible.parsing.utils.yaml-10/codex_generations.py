

# Generated at 2022-06-20 23:40:26.464730
# Unit test for function from_yaml
def test_from_yaml():
    # Tests with valid json string
    test_json_input = '''
    {
        "unit_test_variable": "This is a unit test"
    }
    '''
    result = {}
    result = from_yaml(test_json_input)
    assert result is not None, 'Loaded json string incorrect'

    # Tests with valid yaml string
    test_yaml_input = '''
    ---
    unit_test_variable: "This is a unit test"
    '''
    result = {}
    result = from_yaml(test_yaml_input)
    assert result is not None, 'Loaded yaml string incorrect'

    # test with invalid json string
    test_json_invalid = '''
    {
        "test_variable"
    }
    '''
    result = {}


# Generated at 2022-06-20 23:40:32.914047
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    data = dict(a=5, b=6, c=dict(d=7, e=8))
    yaml_str = AnsibleDumper(None).dump(data)
    new_data = from_yaml(yaml_str)
    assert new_data == data

# Generated at 2022-06-20 23:40:41.993701
# Unit test for function from_yaml
def test_from_yaml():
    # Positive test cases
    yaml_str = "a: 12"
    yaml_str_output = {'a': 12}
    yaml_str_2 = "a: 12\nb: 13"
    yaml_str_2_output = {'a': 12, 'b': 13}
    yaml_str_3 = "a:\n  b: 12\n  c: 13"
    yaml_str_3_output = {'a': {'b': 12, 'c': 13}}


    json_str_output = {'a': 12}
    json_str_2_output = {'a': 12, 'b': 13}
    json_str_3_output = {'a': {'b': 12, 'c': 13}}

    # Negative test cases

# Generated at 2022-06-20 23:40:51.906495
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import shutil
    from ansible.module_utils._text import to_bytes
    from tempfile import mkdtemp
    from ansible.vars.unsafe_proxy import wrap_var

    tmp_dir = mkdtemp()


# Generated at 2022-06-20 23:41:02.052514
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile
    import yaml
    data = '''
        ---
        - name: one
        - name: two
        - name: three
        '''
    (fd, fn) = tempfile.mkstemp()
    os.write(fd, data.encode('utf-8'))
    os.close(fd)
    f = open(fn, 'rb')
    d = from_yaml(f.read())
    f.close()
    os.unlink(fn)
    assert d == [{'name': 'one'}, {'name': 'two'}, {'name': 'three'}], "Failed to parse simple yaml file: %s" % (d,)
    assert not os.path.exists(fn)

# Generated at 2022-06-20 23:41:14.058652
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_text

    original_data = {'a': u'\xe9', 'b': [{'c': u'\xe9'}]}
    json_string = to_text(json.dumps(original_data))
    yaml_string = to_unicode(u"a: \xe9\nb:\n- c: \xe9")

    data = test_from_yaml_json(json_string, original_data)
    data = test_from_yaml_yaml(yaml_string, original_data)


# Generated at 2022-06-20 23:41:26.773880
# Unit test for function from_yaml
def test_from_yaml():

    assert None == from_yaml(0)

    assert [1, 2, 3] == from_yaml('[1, 2, 3]')

    # Test an escaped string with a colon in it to make sure we're handling it correctly
    escaped_string = 'key1: value1\nkey2: value2\nkey3: value:3\n'
    assert from_yaml(escaped_string) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value:3'}

    # Test an escaped string with a colon in it to make sure we're handling it correctly
    escaped_string = 'key1 :value1\nkey2: value2\nkey3: value:3\n'

# Generated at 2022-06-20 23:41:36.005065
# Unit test for function from_yaml
def test_from_yaml():
    data = from_yaml("""
    ---
    - name: test json object
      value: true
    - name: test json array
      value: [1, 2, 3]
""")

    assert isinstance(data, list)
    assert len(data) == 2

    assert data[0]['name'] == 'test json object'
    assert data[0]['value'] is True

    assert data[1]['name'] == 'test json array'
    assert isinstance(data[1]['value'], list)
    assert len(data[1]['value']) == 3
    assert data[1]['value'][0] == 1
    assert data[1]['value'][1] == 2
    assert data[1]['value'][2] == 3

# Generated at 2022-06-20 23:41:47.175855
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == {'foo': 'bar'}
    assert from_yaml('{ foo: bar }') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('foo: bar\n') == {'foo': 'bar'}

    with pytest.raises(AnsibleParserError):
        from_yaml('{ "foo": "bar " }')

    with pytest.raises(AnsibleParserError):
        from_yaml('{ "foo": "bar " }', json_only=True)

    assert from_yaml('{ "foo": "bar " }', json_only=False) == {'foo': 'bar '}

# Generated at 2022-06-20 23:41:53.687467
# Unit test for function from_yaml
def test_from_yaml():
  assert isinstance(from_yaml('{ "test": 123 }', '<string>'), dict)
  assert from_yaml('{ "test": 123 }', '<string>') == { "test": 123 }
  assert from_yaml('good!') == 'good!'
  assert from_yaml('') == ''

# Generated at 2022-06-20 23:42:11.378878
# Unit test for function from_yaml
def test_from_yaml():
    import json
    import yaml
    # Test to see if it can read a simple YAML doc
    yaml_data = "doc: testdata"
    data = from_yaml(yaml_data)
    assert data == yaml.load(yaml_data)

    # Test to see if it can read a simple JSON doc
    json_data = '{"doc": "testdata"}'
    data = from_yaml(json_data)
    assert data == json.loads(json_data)

    # Test to see if it still works with a vault string
    yaml_data = "{'test': !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n"
    data = from_yaml(yaml_data)
    assert data == yaml.load(yaml_data)

# Generated at 2022-06-20 23:42:17.913451
# Unit test for function from_yaml
def test_from_yaml():
    # Test valid yaml
    json_yaml_valid = "key1: value1\nkey2: value2:\n- value3:\n  - value4"
    assert from_yaml(json_yaml_valid) == {'key1': 'value1', 'key2': {'value2': [{'value3': ['value4']}]}}

    # Test valid yaml with embedded json
    json_yaml_json = "key1: value1\nkey2: [1, 2, 3]"
    assert from_yaml(json_yaml_json) == {'key1': 'value1', 'key2': [1, 2, 3]}

    # Test invalid yaml

# Generated at 2022-06-20 23:42:21.214790
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": bar, "baz": "qux"}'
    new_data = from_yaml(data)
    assert new_data == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-20 23:42:30.090565
# Unit test for function from_yaml
def test_from_yaml():
    invalid_yaml_string = '5\n- 6\n- 7'

    invalid_json_string = '{asd: fds}'

    valid_yaml_string = '''
        # Example
        name: foo
        description: bar description
        baz:
            - 1
            - 2
            - 3
        '''

    valid_json_string = '{"name": "foo", "description": "bar description", "baz": ["1","2","3"]}'

    try:
        from_yaml(invalid_json_string)
        assert False
    except AnsibleParserError:
        pass

    try:
        from_yaml(invalid_yaml_string)
        assert False
    except AnsibleParserError:
        pass

    print('Test with YAML:')
    test

# Generated at 2022-06-20 23:42:32.384662
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1 }')['a'] == 1
    assert from_yaml('a: 1')['a'] == 1

# Generated at 2022-06-20 23:42:38.232451
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Runs a unit test to ensure that the from_yaml function works as
    expected. This is mostly to ensure that the unit test infrastructure
    itself is working, rather than to actually test from_yaml.
    '''
    from nose.plugins.skip import SkipTest

    raise SkipTest('No unit tests for %s' % __file__)

# Generated at 2022-06-20 23:42:49.347071
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a':1}") == {"a": 1}
    assert from_yaml("['b', 2]") == ["b", 2]
    assert from_yaml('[foo, 2]') == ["foo", 2]
    assert from_yaml('a: 1') == {"a": 1}
    assert from_yaml('b: [1, 2]') == {"b": [1, 2]}
    assert from_yaml('''b:
  - 1
  - 2''') == {"b": [1, 2]}
    assert from_yaml('''b:
  - 1
    - 2''') == {"b": [1, {"- 2": None}]}

# Generated at 2022-06-20 23:43:03.361382
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play

    # Create yaml
    yaml_data = '''
        - hosts: localhost
          gather_facts: false
          tasks:
          - name: task1
            ping:
            - name: task2
              debug:
                msg: "{{ ansible_distribution }}"
    '''

    p = from_yaml(yaml_data)
    assert isinstance(p, list)
    assert isinstance(p[0], Play)
    assert isinstance(p[0].hosts, AnsibleUnicode)
    assert isinstance(p[0].tasks, list)
    assert isinstance(p[0].tasks[0], dict)

# Generated at 2022-06-20 23:43:08.257461
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    first: 1
    second: 2
    '''
    test_dict = from_yaml(data)
    assert test_dict['first'] == 1
    assert test_dict['second'] == 2


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:43:16.895886
# Unit test for function from_yaml

# Generated at 2022-06-20 23:43:22.952671
# Unit test for function from_yaml
def test_from_yaml():
    # Use config_file: in tests
    data = "foo: bar\n{% if not config_file %}test: a{% endif %}\n"
    parsed = from_yaml(data)
    assert parsed['foo'] == 'bar'

# Generated at 2022-06-20 23:43:28.386801
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    - hosts: all
      tasks:
        - name: print current ansible facts
          debug: var=ansible_facts
    """
    new_data = from_yaml(data)
    assert new_data[0]['hosts'] == 'all'

# Generated at 2022-06-20 23:43:32.697200
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"a": 1, "b": [1, 2]}'

    results = from_yaml(test_data)

    assert results == {"a": 1, "b": [1, 2]}

# Generated at 2022-06-20 23:43:42.722463
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    - hosts: abc
      vars:
        firstvar: "{{x}}"
        secondvar: "{{y}}"
      tasks:
        - name: abc
          debug:
            msg: "{{firstvar}} {{secondvar}}"
    """
    data = from_yaml(data)
    assert data[0]['hosts'] == 'abc'
    assert data[0]['vars']['firstvar'] == '{{x}}'
    assert data[0]['vars']['secondvar'] == '{{y}}'
    assert data[0]['tasks'][0]['name'] == 'abc'
    assert data[0]['tasks'][0]['debug']['msg'] == '{{firstvar}} {{secondvar}}'


# Generated at 2022-06-20 23:43:54.844443
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.module_utils.six import binary_type
    from StringIO import StringIO

    # no input
    assert from_yaml('') == None

    # False, None, True are not affected
    assert from_yaml('False') is False
    assert from_yaml('None') is None
    assert from_yaml('True') is True

    # numbers
    assert from_yaml('1234') == 1234
    assert from_yaml('1234.5') == 1234.5
    assert from_yaml('-1234') == -1234
    assert from_yaml('-1234.5') == -1234.5
    assert from_yaml('.1234') == .1234

    # Unicode

# Generated at 2022-06-20 23:44:03.256553
# Unit test for function from_yaml
def test_from_yaml():
    from ansible import constants as C

    class Args:
        def __init__(self, vault_password_file=C.DEFAULT_VAULT_PASSWORD_FILE, vault_password=None, new_vault_password_file=None,
                     ask_vault_pass=False, vault_ids=None):
            self.vault_password_file = vault_password_file
            self.vault_password = vault_password
            self.new_vault_password_file = new_vault_password_file
            self.ask_vault_pass = ask_vault_pass
            self.vault_ids = vault_ids

    # Test yaml vault data

# Generated at 2022-06-20 23:44:15.724683
# Unit test for function from_yaml

# Generated at 2022-06-20 23:44:24.002124
# Unit test for function from_yaml
def test_from_yaml():
    # This test is a bit weird which is why it's not fully automated.
    # It's essentially a manual test, just to ensure test coverage
    # This function is mainly available for supporting Ansible's changing
    # default parsing of files from YAML to JSON, so test cases are
    # provided as strings of both YAML and JSON
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native

    def _load_yaml_file(in_data):
        '''
        Helper function to load a string to Ansible's internal data structure
        '''
        return {'vars': from_yaml(in_data, file_name=to_native("<test string>", nonstring='empty'))}


# Generated at 2022-06-20 23:44:26.213732
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":1,"b":2,"c":3}') == {"a":1,"b":2,"c":3}

# Generated at 2022-06-20 23:44:39.564971
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    data_sets = (
        (b'{ "foo": "bar" }', True),
        (u'{ "foo": "bar" }', True),
        ('{ "foo": "bar" }', True),
        ('foo: bar', False),
        ('foo: bar', False),
        ('foo: [1, 2]\nbar: baz', False),
        ('foo: {bar: baz}', False),
    )

    for data, expect_dict in data_sets:
        result = from_yaml(data, json_only=False)
        if PY3:
            assert isinstance(result, dict) == expect_dict
            if expect_dict:
                assert result.get('foo') == 'bar'

# Generated at 2022-06-20 23:44:50.593446
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    name:
        - item1
        - item2
    '''
    json_str = '{"name":["item1", "item2"]}'

    assert from_yaml(json_str) == json.loads(json_str)
    assert from_yaml(yaml_data) == json.loads(json_str)

    # test failed json decoder
    failed_json_str = '{name: test}'
    try:
        from_yaml(failed_json_str)
    except AnsibleParserError as e:
        assert to_native(e.orig_exc) == 'Expecting property name enclosed in double quotes: line 1 column 2 (char 1)'

    # test failed yaml decoder

# Generated at 2022-06-20 23:45:01.310520
# Unit test for function from_yaml
def test_from_yaml():
    file_name = '<string>'
    show_content = True
    vault_secrets = True
    json_only = False

    test_1 = '''{"test": [{"test1": 1}, {"test2": 2}]}'''
    test_2 = '''{"test_2": [{"test1": 1}, {"test2": 2}]}'''
    test_3 = '''unexpected string'''
    test_4 = '''{"test": [{"test1": 1}, {"test2": 2}]'''
    json_exception = "Extra data: line 1 column 42 - line 1 column 105 (char 41 - 104)"
    yaml_exception = "mapping values are not allowed here"


# Generated at 2022-06-20 23:45:12.070233
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    {
        "key": "value",
        "key_two": [1, 2, 3]
    }
    '''
    test_dict = from_yaml(data, json_only=True)
    assert test_dict == {'key': 'value', 'key_two': [1, 2, 3]}
    data = '''
    ---
    - name: test_from_yaml
      command: /usr/bin/uptime
      args:
      - username: test_user
        type: user
    '''
    test_dict = from_yaml(data, json_only=True)

# Generated at 2022-06-20 23:45:21.615848
# Unit test for function from_yaml
def test_from_yaml():
    # Verify that from_yaml returns the same as json.loads for a JSON string
    # generated by json.dumps
    json_input = json.dumps({'hi': 'there'})
    assert from_yaml(json_input) == json.loads(json_input)

    # Verify that from_yaml returns the same as yaml.safe_load for a YAML string
    # generated by yaml.safe_dump
    import yaml
    yaml_input = yaml.safe_dump({'hi': 'there'})
    assert from_yaml(yaml_input) == yaml.safe_load(yaml_input)

# Generated at 2022-06-20 23:45:30.777058
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b":2 }') == {"a": 1, "b": 2}
    assert from_yaml('a: 1\nb: 2') == {"a": 1, "b": 2}
    try:
        from_yaml('{')
    except AnsibleParserError as e:
        assert e.message == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting object: line 1 column 2 (char 1)\n\n%s' % YAML_SYNTAX_ERROR % ''
        assert e.obj is None
        assert e.show_content is True
        assert hasattr(e.orig_exc, 'problem_mark')
        assert e.orig_exc.problem_mark.line == 0
        assert e

# Generated at 2022-06-20 23:45:42.534262
# Unit test for function from_yaml
def test_from_yaml():

    # Test valid json
    valid_json_str = '{"spam": 1, "eggs": true}'
    valid_json_dict = {"spam": 1, "eggs": True}
    assert from_yaml(valid_json_str) == valid_json_dict

    # Test valid yaml
    valid_yaml_str = "eggs: true\nspam: 1"
    assert from_yaml(valid_yaml_str) == valid_json_dict

    # Test invalid json string
    invalid_json_str = '{"spam": 1, "eggs": true'  # Missing closing bracket
    try:
        from_yaml(invalid_json_str)
        assert False  # Exception must be raised
    except AnsibleParserError as exception:
        assert "JSON" in exception.message  #

# Generated at 2022-06-20 23:45:53.405570
# Unit test for function from_yaml
def test_from_yaml():

    # This is testing JSON parsing, so no need to test YAML.
    # TODO: move this to test/sanity/json_and_yaml_parsing/tests/test_yaml/test_from_yaml.py

    from ansible.module_utils.common.collections import ImmutableDict

    # test invalid JSON
    data = '{"foo": "bar": "baz"}'
    file_name = 'test_file'
    try:
        from_yaml(data, file_name=file_name)
    except AnsibleParserError as e:
        assert file_name in e.message

    # test non-string input
    fp = open('../../../test/sanity/json_and_yaml_parsing/data/object_list_literal.json')

# Generated at 2022-06-20 23:46:04.554896
# Unit test for function from_yaml
def test_from_yaml():
    # Try a JSON string
    assert from_yaml('{"test": "data"}') == {"test": "data"}

    # Try a YAML string
    assert from_yaml('test: data') == {"test": "data"}

    # Try a YAML string
    assert from_yaml('{test: data}') == {"test": "data"}

    # Try a bad YAML string
    try:
        from_yaml('{test: "data"')
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" in str(e)
        assert "JSON:" in str(e)
        assert "YAML:" in str(e)
    else:
        assert False

# Generated at 2022-06-20 23:46:15.221559
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": true, "c": "string", "d": null }') == {'a': 1, 'b': True, 'c': 'string', 'd': None}
    assert from_yaml('{ "a": { "a1": "value" } }') == {'a': {'a1': 'value'}}

    try:
        from_yaml('{ "a": 1, "b": true, "c": "string", "d": null')
    except AnsibleParserError as e:
        # Check that the exception is propagated up
        assert True
    else:
        assert False

    try:
        from_yaml('malformed json')
    except AnsibleParserError as e:
        # Check that the exception is propagated up
        assert True

# Generated at 2022-06-20 23:46:24.038414
# Unit test for function from_yaml
def test_from_yaml():
    test1_yaml = """
    ---
    - hosts:
        - localhost
      tasks:
        - debug:
            msg: hello world
    """
    test1_json = """
    {"_ansible_verbose_always": true, "_ansible_no_log": false}
    """

    data = from_yaml(test1_yaml)
    assert len(data) == 1
    assert data[0]['hosts'][0] == 'localhost'
    data = from_yaml(test1_json)
    assert data is {}

# Generated at 2022-06-20 23:46:43.168873
# Unit test for function from_yaml
def test_from_yaml():
    # Test good data
    good_yaml = '''
    a: b
    c: d
    '''
    result = from_yaml(good_yaml)
    assert isinstance(result, dict)
    assert result['a'] == 'b'
    assert result['c'] == 'd'

    good_json = '''{"a": "b", "c": "d"}'''
    result = from_yaml(good_json)
    assert isinstance(result, dict)
    assert result['a'] == 'b'
    assert result['c'] == 'd'


# Generated at 2022-06-20 23:46:54.258256
# Unit test for function from_yaml
def test_from_yaml():
    '''
    We have to have a unit test here due to the use of raise_on_error in make_option
    '''

    # Here is a json string that the yaml parser will not accept,
    # since it uses single quotes around the key instead of double quotes
    test_str = "{'foo': 'bar'}"

    # We expect an exception here. If we don't get one, fail.
    try:
        from_yaml(test_str, file_name='/some/path', show_content=True)
        raise Exception("FAILURE in from_yaml")
    except AnsibleParserError as e:
        pass
    except Exception as e:
        raise Exception("FAILURE in from_yaml")

# Generated at 2022-06-20 23:47:05.885542
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import ansible.plugins.loader
    import os.path
    import sys

    class AnsibleModuleLoaderTestSuite(unittest.TestCase):
        def setUp(self):
            self.loader = ansible.plugins.loader.ModuleLoader()
            self.loader._get_cwd = lambda: os.path.join(os.path.dirname(__file__), 'testdata')
            self.loader.add_directory(os.path.join(os.path.dirname(__file__), 'testdata'))
            self.loader.add_directory(os.path.join(os.path.dirname(__file__), 'testdata2'))
            self.loader.add_directory(os.path.join(os.path.dirname(__file__), 'testdata3'))


# Generated at 2022-06-20 23:47:15.272193
# Unit test for function from_yaml
def test_from_yaml():
    # Test valid yaml
    yaml_text = 'this is yaml text'
    data = from_yaml(yaml_text)
    assert data == 'this is yaml text'
    # Test valid json
    json_text = '{"this": "is json text"}'
    data = from_yaml(json_text)
    assert data == {"this": "is json text"}
    # Test some invalid input
    bad_text = '{bad: "this is bad text"}'
    try:
        data = from_yaml(bad_text)
        assert False
    except AnsibleParserError as e:
        assert type(e) == AnsibleParserError

# Generated at 2022-06-20 23:47:26.532984
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"test": [{"test2": 1}, 2, 3]}'
    # Test that if an invalid json is not json_only
    # it's still parsed as valid yaml

    new_data = None

    try:
        # in case we have to deal with vaults
        AnsibleJSONDecoder.set_secrets(vault_secrets)

        # we first try to load this data as JSON.
        # Fixes issues with extra vars json strings not being parsed correctly by the yaml parser
        new_data = json.loads(data, cls=AnsibleJSONDecoder)
    except Exception as json_exc:
        print(json_exc)
        # must not be JSON, let the rest try

# Generated at 2022-06-20 23:47:35.054487
# Unit test for function from_yaml
def test_from_yaml():
    test_data = {
        'int': 1,
        'str': 'bar',
        'dict': {
            'foo': 'str',
            'bar': [1, 2, 3],
            'baz': {'magic': 'boo'}
        },
        'list': [1, 'str'],
        'bool_t': True,
        'bool_f': False,
        'none': None
    }
    assert from_yaml(json.dumps(test_data)) == test_data
    assert from_yaml(json.dumps(test_data), json_only=True) == test_data
    assert from_yaml(json.dumps(test_data), json_only=True) == from_yaml(json.dumps(test_data))

# Generated at 2022-06-20 23:47:47.252664
# Unit test for function from_yaml
def test_from_yaml():

    import unittest2 as unittest

    class TestFromYaml(unittest.TestCase):

        def test_no_data(self):
            self.assertRaises(AnsibleParserError, from_yaml, '', show_content=False)

        def test_empty_data_json(self):
            data = '{}'
            decoded = from_yaml(data)
            self.assertEqual(decoded, {})

        def test_empty_data_yaml(self):
            data = '--- {}'
            decoded = from_yaml(data)
            self.assertEqual(decoded, {})

        def test_json_data(self):
            data = '{"foo":"bar"}'
            decoded = from_yaml(data)

# Generated at 2022-06-20 23:47:55.842527
# Unit test for function from_yaml

# Generated at 2022-06-20 23:48:07.907589
# Unit test for function from_yaml
def test_from_yaml():
    # yaml.safe_load() is not available in Py3.
    import ansible.parsing.yaml as ya
    data = """
        - hosts: localhost
          tasks:
            - name: create an array of things
              set_fact:
                my_things:
                  - dog
                  - cat
                  - antelope
                  - giraffe
                  - fruit bat
                  - kangaroo
                  - dingo
      """
    result = ya.from_yaml(data)
    assert 'my_things' in result[0]['tasks'][0]['set_fact']
    assert result[0]['tasks'][0]['set_fact']['my_things'][3] == 'giraffe'

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:48:16.606008
# Unit test for function from_yaml
def test_from_yaml():
    # Create a JSON string to test
    json_str = json.dumps({'a': 'b', 'c': [1, 2, 3], 'd': {'e': 'f'}})

    # Create a YAML string to test
    yaml_str = '\n'.join([
        'a: b',
        'c:',
        ' - 1',
        ' - 2',
        ' - 3',
        'd:',
        ' e: f'
    ])

    # Test that the JSON string parses and does not raise an error
    from_yaml(json_str)

    # Test that the YAML string parses and does not raise an error
    from_yaml(yaml_str)

# Generated at 2022-06-20 23:48:36.453927
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    broken_source = '{"a": "b", "c": [1, 2, 3, "d"], "e": "f" }'

    # Check that json with no yaml errors returns valid json
    x = from_yaml(broken_source)
    assert isinstance(x, dict)
    assert 'a' in x
    assert 'c' in x
    assert 'e' in x
    assert isinstance(x['a'], str)
    assert isinstance(x['c'], list)
    assert isinstance(x['e'], str)
    assert len(x['c']) == 4

    # Check that yaml with a yaml error returns the right error

# Generated at 2022-06-20 23:48:42.651604
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_data = '["test", "inside", {"test": "nested yaml"}]'

    with open('/tmp/test', 'w') as f:
        f.write(test_data)

    parsed_data = from_yaml(test_data)
    from_file = from_yaml('/tmp/test', json_only=True)

    assert parsed_data == from_file

    with open('/tmp/test', 'w') as f:
        f.write('{"ansible_facts": {"test": "yaml"}}')

    # Complex JSON as string

# Generated at 2022-06-20 23:48:54.737725
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    import os
    import sys

    # set this to 0 to test on systems other than MacOS
    if sys.platform == 'darwin':
        os.environ['ANSIBLE_TEST_YAML_GCOV'] = '0'
    else:
        os.environ['ANSIBLE_TEST_YAML_GCOV'] = '1'

    # Check if the gcov mode is enabled.
    # NOTE: On MacOS python sys.platform is returning darwin even if the machine is on MacOS version 10.10.5
    #       hence Ansible v2.9.2 is not running with gcov mode.

# Generated at 2022-06-20 23:49:03.137142
# Unit test for function from_yaml
def test_from_yaml():

    # Test 1
    # In case of single YAML string, it is converted to native python datatype and returned
    data = "this is not json"
    file_name = '<string>'
    show_content = True
    expected_results = 'this is not json'
    assert from_yaml(data, file_name=file_name, show_content=show_content) == expected_results

    # Test 2
    # In case of JSON string, it is converted to native python datatype and returned
    data = '''{"this":      "should work as json"}'''
    expected_results = {'this': 'should work as json'}
    assert from_yaml(data, file_name=file_name, show_content=show_content) == expected_results

    # Test 3
    # In case of invalid

# Generated at 2022-06-20 23:49:05.129598
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:49:12.336522
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": 1, "b": 2}'

    # Test for JSON data
    new_data = from_yaml(data)
    assert new_data == json.loads(data)

    # Test for YAML data
    data = '---\na: 1\nb: 2\n'
    new_data = from_yaml(data)
    assert new_data == {'a': 1, 'b': 2}
    return



# Generated at 2022-06-20 23:49:15.381009
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'{"a": "b"}') == {"a": "b"}
    assert from_yaml(u'{"a": "b"}', json_only=True) == {"a": "b"}

# Generated at 2022-06-20 23:49:16.382309
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('foo')

# Generated at 2022-06-20 23:49:25.753004
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib

    data = '''
    ---
    foo: bar
    ...
    '''

    assert data == from_yaml(data)

    data = '''
    ---
    foo: bar
    ...
    '''

    assert data == from_yaml(data, False)

    data = '''
    foo: bar
    '''

    assert {'foo': 'bar'} == from_yaml(data)

    data = '''
    foo: bar
    '''

    assert {'foo': 'bar'} == from_yaml(data, False)

    data = '''
    foo:
      - bar
      - baz
    '''

    assert {'foo': ['bar', 'baz']} == from_yaml(data)



# Generated at 2022-06-20 23:49:36.132269
# Unit test for function from_yaml
def test_from_yaml():
    # Try passing in empty value
    assert from_yaml('') == None

    # Test passing in valid JSON string
    assert from_yaml('{"a":{"b":"c","d":{"e":"f"}}}') == {"a":{"b":"c","d":{"e":"f"}}}

    # Test passing in valid YAML
    assert from_yaml('a:\n  b: c\n  d:\n    e: f') == {'a': {'b': 'c', 'd': {'e': 'f'}}}

    # Passing in an invalid value
    import pytest
    with pytest.raises(AnsibleParserError):
        from_yaml('{a:b}')

# Generated at 2022-06-20 23:49:48.913596
# Unit test for function from_yaml
def test_from_yaml():
    data = "a\n aa\naaa\n"
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    print(new_data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:49:59.281143
# Unit test for function from_yaml
def test_from_yaml():
    # Test case from Issue #3033
    generated_yaml = '''{% if page_name != "index" %}---
                            layout: page
                            title: {{ page_name | capitalize }}
                          {% else %}---
                            layout: home
                          {% endif %}
                          permalink: /{{ page_name }}/
                          '''.replace('                            ', '')

    expected_data = {u'layout': u'page', u'title': u'{{ page_name | capitalize }}', u'permalink': u'/{{ page_name }}/'}
    actual_data = from_yaml(generated_yaml)

    try:
        assert expected_data == actual_data
    except AssertionError:
        print("data expected:")
        print(expected_data)

# Generated at 2022-06-20 23:50:09.727542
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.text.converters import to_bytes

    for string, expected in [
        (to_bytes(u"{'a':1}"), {u'a': 1}),
        (to_bytes(u"1"), 1),
        (to_bytes(u"a"), u'a'),
        (to_bytes(u"1.1"), 1.1),
        (to_bytes(u"true"), True),
        (to_bytes(u"false"), False),
    ]:
        # Loads bytes as JSON
        assert from_yaml(string, json_only=True) == expected


# Generated at 2022-06-20 23:50:19.736268
# Unit test for function from_yaml
def test_from_yaml():
    data = {
        'ansible': {
            'string': 'string',
            'int': 1,
            'true': True,
            'false': False,
            'list': ['a', 'b', 'c'],
            'dict': {
                'a': 1,
                'b': '2',
                'c': False
            },
            'unix_epoch': 1585118655.7285194,
            'iso8601': "2020-03-25T09:44:15.728439+00:00"
        }
    }
    json_str = json.dumps(data)
    # convert to and from yaml
    yaml_str = json.dumps(json.loads(json_str), indent=4, sort_keys=True)
    new_data = from_y