

# Generated at 2022-06-20 23:40:28.685597
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    # Make sure we can load a string that is not JSON, but is YAML,
    # and should raise YAMLError for python <= 2.7
    # Check for PY3 because we can't do this for py3k, we get a
    # YAML invalid token string error
    # TODO: Deprecate python 2.7 YAML error tests
    if not PY3:
        try:
            from_yaml('true: OK')
        except AnsibleParserError as e:
            assert isinstance(e.orig_exc, YAMLError)
            return
        assert False, "Failed to raise an AnsibleParserError"

    # Test multi-line YAML block

# Generated at 2022-06-20 23:40:37.057020
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError):
        from_yaml('{"var": {"a": "b", "b", "c"}}', '<string>')
    with pytest.raises(AnsibleParserError):
        from_yaml('{var: "a"}', '<string>')
    with pytest.raises(AnsibleParserError):
        from_yaml('{7: "a"}', '<string>')
    with pytest.raises(AnsibleParserError):
        from_yaml('{"var": false}', '<string>')
    res = from_yaml('{"var": "a"}', '<string>')
    assert res == {'var': 'a'}

# Generated at 2022-06-20 23:40:45.258354
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == { "foo": "bar" }
    assert from_yaml('{ foo: "bar" }') == { "foo": "bar" }
    assert from_yaml('foo: bar') == { "foo": "bar" }
    assert from_yaml('"foo": "bar"') == { "foo": "bar" }

# Generated at 2022-06-20 23:40:49.726959
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    stream = "whatever: whatever"
    assert from_yaml(stream) == {u'whatever': u'whatever'}
    if not PY3:
        stream = stream.decode('utf-8')
    assert from_yaml(stream) == {u'whatever': u'whatever'}

# Generated at 2022-06-20 23:41:00.219756
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # test encrypted vars
    vault_secrets = ['secret']
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-20 23:41:06.538369
# Unit test for function from_yaml

# Generated at 2022-06-20 23:41:19.022161
# Unit test for function from_yaml
def test_from_yaml():
   # test function from_yaml
   test_data = "true"
   var_dump = from_yaml(test_data)
   assert var_dump == True, "test_from_yaml: Expected True"
   # test function from_yaml
   test_data = "false"
   var_dump = from_yaml(test_data)
   assert var_dump == False, "test_from_yaml: Expected False"
   # test function from_yaml
   test_data = "string"
   var_dump = from_yaml(test_data)
   assert var_dump == "string", "test_from_yaml: Expected string"
   # test function from_yaml
   test_data = "1"
   var_dump = from_yaml(test_data)
   assert var

# Generated at 2022-06-20 23:41:23.033051
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'
    assert from_yaml(data) == {"foo": "bar"}

    data = 'foo: bar'
    assert from_yaml(data) == {"foo": "bar"}

    # TODO: need to add more test cases

# Generated at 2022-06-20 23:41:26.695597
# Unit test for function from_yaml
def test_from_yaml():
    assert( isinstance(from_yaml('{"a":1,"b":2,"c":3}'), dict) )
    assert( isinstance(from_yaml('[1,2,"c"]'), list) )

# Generated at 2022-06-20 23:41:33.457038
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'var1': 'foo', 'var2': 'bar'}", json_only=True) == {'var1': 'foo', 'var2': 'bar'}
    assert from_yaml("{'var1': 'foo', 'var2': 'bar'}") == {'var1': 'foo', 'var2': 'bar'}

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-20 23:41:47.354432
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.errors.yaml_strings import YAML_SYNTAX_ERROR
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_native
    from ansible.parsing.ajson import AnsibleJSONDecoder
    import json
    # Test _handle_error

# Generated at 2022-06-20 23:41:59.172803
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.utils.yaml import from_yaml
    data = "key1: value\nkey2: value2"
    assert type(from_yaml(data)) == dict
    data = "key1: value\nkey2: value2\nlist: [test,test1,test2]"
    assert type(from_yaml(data)) == dict
    data = "key: so\n  deep:\n    - i\n    - am\n    - a\n    - list!\n    - 1\n    - 2\n    - 3"
    assert type(from_yaml(data)) == dict

# Generated at 2022-06-20 23:42:12.537289
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    source = """
        - a: 1
          b: 2
        - a: 3
          b: 4
    """

    data = from_yaml(source)

    assert type(data) == list
    assert len(data) == 2
    assert type(data[0]) == AnsibleMapping
    assert type(data[1]) == AnsibleMapping

    source = """
        foo:
          - 1
          - 2
          - 3
        bar:
          baz:
             - 4
             - 5
             - 6
    """

    data = from_yaml(source)

    assert type(data) == AnsibleMapping

# Generated at 2022-06-20 23:42:23.882787
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import io
    import crypt
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultLib

    vault_secrets = VaultLib(0)

    # Test vaulted file
    # Generate a test vault file with the password "ansible"
    vault_id = 'test1'
    vault_data = "this text is vaulted"
    vault_pass = "ansible"

    vault_file = io.StringIO(vault_data)
    vault_secrets.read_vault_file(vault_file, vault_id, vault_pass)

# Generated at 2022-06-20 23:42:35.813608
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'{}', b'message') == {}, 'ensure YAML is parsed as JSON'
    assert from_yaml(b'[{}, {}]', b'[message1, message2]') == [{}, {}], 'ensure YAML is parsed as JSON'
    assert from_yaml(b'foo: bar', b'foo: bar') == {u'foo': u'bar'}, 'ensure YAML is parsed as JSON'
    assert from_yaml(b'foo: - bar1 - bar2', b'foo: [bar1, bar2]') == {u'foo': [u'bar1', u'bar2']}, 'ensure YAML is parsed as JSON'

# Generated at 2022-06-20 23:42:46.133069
# Unit test for function from_yaml
def test_from_yaml():
    testcases = [
        {
            "data": '',
            "expected": {}
        },
        {
            "data": '{"a": "b"}',
            "expected": {
                'a': 'b'
            }
        },
        {
            "data": '{"a": ["1", "2", "3"]}',
            "expected": {
                'a': ['1', '2', '3']
            }
        }
    ]
    for t in testcases:
        assert t['expected'] == from_yaml(t['data'])

# Generated at 2022-06-20 23:42:59.831128
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.module_utils.basic
    expected_output = [
        {
            "k1": {
                "k2": {
                    "k3": [1, 2, 3]
                }
            }
        }
    ]
    output = ansible.module_utils.basic.from_yaml("""
    - k1:
        k2:
            k3:
              - 1
              - 2
              - 3
    """)
    assert output == expected_output

    try:
        ansible.module_utils.basic.from_yaml("""
        - k1:
            k2:
                k3:
                  - 1
                  - 2
                  - 3
        """, json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False

# Generated at 2022-06-20 23:43:10.552260
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Function to perform verification checks on the from_yaml function
    '''

    # Test for yaml data
    YAML_DATA = '''
    test-1:
      key1: value1
      key2: value2
    test-2:
      key3: value3
      key4: value4
    '''

    # Expected output
    DATA = {
        'test-1': {
            'key1': 'value1',
            'key2': 'value2',
        },
        'test-2': {
            'key3': 'value3',
            'key4': 'value4',
        },
    }

    returned_data = from_yaml(YAML_DATA)

    assert returned_data == DATA

    # Test for JSON data

# Generated at 2022-06-20 23:43:12.472693
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{"foo": "bar"}')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:43:19.356336
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test the basic object
    test_obj = {'foo': {'bar': ['fie', 'ble', 'blah'], 'baz': True}}
    data = yaml.dump(test_obj, Dumper=AnsibleDumper)
    assert data == 'foo:\n  bar:\n  - fie\n  - ble\n  - blah\n  baz: true\n', data
    new_data = from_yaml(data)
    assert new_data == test_obj, new_data

    # test the object dumping
    test_obj = {'foo': {'bar': ['fie', 'ble', 'blah'], 'baz': True}}

# Generated at 2022-06-20 23:43:31.777355
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}") == {'a': 'b'}
    # Test input is a string and output is a string
    assert from_yaml("'a'") == "a"
    # Test input is a string and output is a list
    assert from_yaml("['a', 'b']") == ["a", "b"]
    # Test input is a string and output is a dict
    assert from_yaml("{'a': 'c', 'b': 'd'}") == {'a': 'c', 'b': 'd'}

# Generated at 2022-06-20 23:43:41.746411
# Unit test for function from_yaml
def test_from_yaml():
    # Test parsing good yaml
    yaml_string = '''
    - - 0
      - 1
      - 2
      - 3
      - [4, 5]
      - {
          "foo": "bar",
          "foobar": [7, 8, 9]
        }
    - - 10
      - 11
    - - 12
    '''
    expected_value = [[0, 1, 2, 3, [4, 5], {'foo': 'bar', 'foobar': [7, 8, 9]}], [10, 11], [12]]
    assert expected_value == from_yaml(yaml_string)

    # Test parsing bad yaml

# Generated at 2022-06-20 23:43:54.248123
# Unit test for function from_yaml
def test_from_yaml():

    # Test for issue https://github.com/ansible/ansible/issues/36643
    # If YAML parsing fails it will raise an AnsibleParserError
    bad_yaml = "abc: <"
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vaults = VaultLib([])

    try:
        combine_vars(None, from_yaml(bad_yaml, json_only=True))
        raise AssertionError
    except AnsibleParserError as e:
        assert isinstance(e.orig_exc, ValueError)
        assert e.file_name == "<string>"

    # Test for issue https://github.com/ansible/ansible/issues/37974

# Generated at 2022-06-20 23:43:55.193225
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": 2 }') == { u'a': 1, u'b': 2 }

# Generated at 2022-06-20 23:44:03.356381
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    class TestParser(unittest.TestCase):
        def test_from_yaml(self):
            #json_input = '{"ansible_ssh_host": "172.16.1.1", "ansible_ssh_port": 22, "ansible_ssh_user": "test"}'
            json_input = '{"a": "test"}'

            json_output = {'a':  'test'}
            yaml_output = json_output

            self.assertEqual(json_output, from_yaml(json_input, file_name='<string>', show_content=True, vault_secrets=None, json_only=False))


# Generated at 2022-06-20 23:44:15.724832
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Test various input data
    data = dict(
        ansible=True,
        python=[2, dict(minor=7)],
        version='2.4.1.0',
        deep=dict(nested=[dict(value=1)])
    )
    dumped_data = dict(
        ansible='true',
        python=['2', dict(minor='7')],
        version='2.4.1.0',
        deep=dict(nested=['dict(value=1)'])
    )

    # Convert loaded data back into YAML

# Generated at 2022-06-20 23:44:24.001321
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    import json
    import re

    # Verify that a valid JSON input returns
    # the same result as json.loads() with the
    # AnsibleJSONDecoder()
    s = '{"a": "b", "c": "d"}'
    r1 = json.loads(s, cls=AnsibleJSONDecoder)
    r2 = from_yaml(s)
    assert r1 == r2

    # Verify that an invalid input gives a consistent error
    # We use pytest.raises() since we expect an exception
    pytest.raises(AnsibleParserError, from_yaml, '{"a": "b", "c": "d"}:')

    # Verify that we get the same error for JSON or YAML
    y = '{"a": "b", "c": "d"}:'

# Generated at 2022-06-20 23:44:32.591056
# Unit test for function from_yaml
def test_from_yaml():
    json_data = "{\"a\": \"foobar\"}"
    assert from_yaml(json_data, json_only=True) == {"a": "foobar"}
    assert from_yaml(json_data) == {"a": "foobar"}
    assert from_yaml(json_data, json_only=False) == {"a": "foobar"}
    yaml_data = "a: foobar"
    assert from_yaml(yaml_data) == {"a": "foobar"}
    assert from_yaml(yaml_data, json_only=False) == {"a": "foobar"}

# Generated at 2022-06-20 23:44:40.746473
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("{ }") == {}
    assert from_yaml("{ a: 1 }") == {'a': 1}
    assert from_yaml("{ a :1 }") == {'a': 1}
    assert from_yaml("{ 'a': 1 }") == {'a': 1}
    assert from_yaml("{ \"a\": 1 }") == {'a': 1}
    assert from_yaml("[ ]") == []

# Generated at 2022-06-20 23:44:49.032267
# Unit test for function from_yaml
def test_from_yaml():
    from yaml.scanner import ScannerError

    json_data = '{"a": "b"}'
    yaml_data = '"a": "b"'

    # Assert json data can be parsed properly
    parsed_json_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert parsed_json_data == {"a": "b"}

    # Assert yaml data can be parsed properly
    parsed_yaml_data = _safe_load(yaml_data)

# Generated at 2022-06-20 23:45:03.102034
# Unit test for function from_yaml
def test_from_yaml():
    text1 = """
    ---
    - hosts: localhost
      vars:
        var1: "{{ abc }}"
        var2: "{{ abc }}"
        var3: "{{ abc }}"
      tasks:
      - raw: "{{ var1 }}"
      - raw: "{{ var2 }}"
      - raw: "{{ var3 }}"
    """

    text2 = """
    ---
    - hosts: localhost
      vars:
        var1: "{{ abc }}"
        var2: "{{ abc }}"
        var3: "{{ abc }}"
      tasks:
      - raw: "{{ var1 }}"
      - raw: "{{ var2 }}"
      - raw: "{{ var3 }}"
    """


# Generated at 2022-06-20 23:45:14.381196
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import random
    import tempfile
    import textwrap

    # We need to create a sample YAML file to test this function
    # Here a sample file with valid YAML

    # create a temp dir
    tmp_dir = tempfile.gettempdir()
    test_file_name = os.path.join(tmp_dir, "%s.yml" % (str(random.randint(0, 10000))))


# Generated at 2022-06-20 23:45:17.116751
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    roles:
      - role: test_role
        role_with_name_override:
            name: test_role
        role_without_name_override:
            name: test_role
    """
    result = from_yaml(data)
    if not result:
        raise AssertionError("from_yaml returned no data")

# Generated at 2022-06-20 23:45:21.654907
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\n- hosts: all\n\n  roles:\n  - role1\n") == { 'hosts': 'all', 'roles': [ 'role1' ] }
    assert from_yaml("---\n- hosts: all\n\n  roles:\n  - role1\n", '<string>', False) == { 'hosts': 'all', 'roles': [ 'role1' ] }
    assert from_yaml("---\n- hosts: all\n\n  roles:\n  - role1\n", '<string>', True) == { 'hosts': 'all', 'roles': [ 'role1' ] }

# Generated at 2022-06-20 23:45:29.248511
# Unit test for function from_yaml
def test_from_yaml():
    ''' Check that from_yaml() returns the expected result '''

    # Create input
    input_yaml = """ [ { 'a': 1, "b": 2 }, [ 1, 2, 3 ] ] """
    file_name = 'TESTFILE'
    secrets_file = '/secrets.txt'
    show_content = False

    # Create the expected output
    expected_output = [ { 'a': 1, "b": 2 }, [ 1, 2, 3 ] ]

    # Create output
    output = from_yaml(input_yaml, file_name, show_content, secrets_file)

    # Unit test
    assert output == expected_output

# Generated at 2022-06-20 23:45:35.937184
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 1}', show_content=True) == {"a": 1}
    assert from_yaml('{"a": 1}', show_content=False) == {"a": 1}
    assert from_yaml('a: 1', show_content=True) == {"a": 1}
    assert from_yaml('a: 1', show_content=False) == {"a": 1}
    assert from_yaml('a: 1', json_only=True)

# Generated at 2022-06-20 23:45:41.437200
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    v = VaultLib(b'asdfasdf')
    import sys
    v.update({'a': 1, 'b': 2, 'c': '{{ ansible_hostname }}'}, None, False)
    print(from_yaml(v.dump()))
    print(sys.version)

# Generated at 2022-06-20 23:45:52.442786
# Unit test for function from_yaml
def test_from_yaml():
    file_name = '/etc/ansible/hosts'
    data = "hosts: localhost \nremote: web01"
    try:
        new_data = json.loads(data, cls=AnsibleJSONDecoder)
    except Exception as json_exc:
        print("json_exc: %s" % json_exc)
        try:
            new_data = _safe_load(data, file_name=file_name, vault_secrets=None)
        except YAMLError as yaml_exc:
            print("yaml_exc: %s" % yaml_exc)
            _handle_error(json_exc, yaml_exc, file_name, True)

    print("new_data: %s" % new_data)

if __name__ == '__main__':
    test

# Generated at 2022-06-20 23:45:57.154714
# Unit test for function from_yaml
def test_from_yaml():
    assert type(from_yaml('{ "test": "foo" }')) == dict
    assert type(from_yaml('test: foo')) == dict
    assert from_yaml('{ "test": "foo" }')['test'] == "foo"
    assert from_yaml('test: foo')['test'] == "foo"


# Generated at 2022-06-20 23:46:09.433874
# Unit test for function from_yaml
def test_from_yaml():

    test = from_yaml("{ 'foo': 'bar' }")

    assert test == { 'foo': 'bar' }

    test = from_yaml("{ 'foo': 'bar' }", json_only=True)

    assert test == { 'foo': 'bar' }

    # Should fail with a syntax error
    try:
        test = from_yaml("{ foo: 'bar' }", json_only=True)
    except AnsibleParserError as e:
        pass

    # Should fail with a syntax error
    try:
        test = from_yaml("{ foo: 'bar' }")
    except AnsibleParserError as e:
        pass

    # Should not fail with a syntax error because it is yaml
    test = from_yaml("{ 'foo': 'bar' }")


# Generated at 2022-06-20 23:46:29.402405
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import pytest
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - hosts: example
    - tasks:
        - name: this is a task
          shell: whoami
    '''
    res = from_yaml(yaml_str)
    assert res == [{u'hosts': u'example'},
                   {u'tasks': [{u'shell': u'whoami',
                                u'name': u'this is a task'}]}]

    with open(os.path.dirname(__file__) + '/../module_utils/layout.yml') as f:
        res = from_yaml(f.read())

# Generated at 2022-06-20 23:46:35.474002
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test the from_yaml function.
    """

    assert from_yaml('{ "a": 1 }') == { 'a': 1}
    assert from_yaml('[ 1 ]') == [ 1 ]

    with pytest.raises(AnsibleParserError) as execinfo:
        from_yaml('"foo"')
    assert 'We were unable to read either as JSON nor YAML' in str(execinfo.value)

# Generated at 2022-06-20 23:46:45.158091
# Unit test for function from_yaml
def test_from_yaml():
    # Test json only
    data = '{"a": 3, "b": 2, "c": {"d": 4, "e": 5}}'

    try:
        new_data = from_yaml(data, json_only=True)
        assert new_data == {'a': 3, 'b': 2, 'c': {'d': 4, 'e': 5}}
    except AnsibleParserError:
        assert False

    # Test yaml

# Generated at 2022-06-20 23:46:48.645697
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"a\": \"b\"}") == {'a': 'b'}
    assert from_yaml("foo") == 'foo'

# Generated at 2022-06-20 23:47:01.038565
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import (AnsibleSequence,
                                              AnsibleMapping,
                                              AnsibleUnicode)
    from ansible.parsing.yaml.data import VaultSecret
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json

    # Testing yaml to python
    d = dict(a=1, b=2, c=3)
    y_data = to_yaml(d)
    p_data = from_yaml(y_data)
    assert d == p_data

    # Testing yaml to string
    d = dict(a=1, b=2, c=3)

# Generated at 2022-06-20 23:47:09.968197
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml import dumper
    from ansible.errors import AnsibleParserError
    from ansible.parsing.ajson import AnsibleJSONDecoder

    # test yaml without JSON

# Generated at 2022-06-20 23:47:16.287149
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test function from_yaml.
    '''
    try:
        from_yaml("---\n- hosts: localhost")
    except AnsibleParserError as e:
        assert e.obj != None
        print(e.obj.ansible_pos)
        assert e.obj.ansible_pos == ('<string>', 1, 1)


# Generated at 2022-06-20 23:47:18.556941
# Unit test for function from_yaml
def test_from_yaml():
    import doctest
    # This shouldn't throw an exception
    doctest.testmod(from_yaml)

# Generated at 2022-06-20 23:47:29.065181
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml

    # Test good JSON input
    json_string = '{"a": 1}'
    assert from_yaml(json_string) == {u'a': 1}

    # Test good YAML input
    yaml_string = 'a: 1'
    assert from_yaml(yaml_string) == {u'a': 1}

    # Test bad JSON input
    json_string = '{"a: 1}'
    try:
        from_yaml(json_string)
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError was not raised (bad JSON)"

    # Test bad YAML input
    yaml_string = 'a: 1]'

# Generated at 2022-06-20 23:47:37.466350
# Unit test for function from_yaml
def test_from_yaml():
    # Simple test
    data1 = """
    foo: 1
    bar: 2
    """

    result = from_yaml(data1, file_name='anonymous_test1', show_content=True)
    assert isinstance(result, dict)

    # Test with invalid json data
    data2 = """
    {
    "foo": 1,
    }
    """

    result = from_yaml(data2, file_name='anonymous_test2', show_content=True)
    assert result == 'AnsibleJSONDecoder'

    # Test with invalid yaml data
    data3 = """
    foo: 1
    bar
    """

    result = from_yaml(data3, file_name='anonymous_test3', show_content=True)

# Generated at 2022-06-20 23:47:52.909624
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    try:
        # just run the from_yaml function with some test data
        from_yaml("""
            - hosts: web
              gather_facts: false
              tasks:
                - shell: echo "Hello World"
                  register: result
        """)

    except AnsibleParserError as e:
        sys.exit("ANSIBLE_TEST_ERROR: %s" % to_native(e))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:47:59.230327
# Unit test for function from_yaml
def test_from_yaml():

    # This is a valid YAML string
    test_yaml_string = '''
    foo:
        bar: baz
    '''

    # This is a valid JSON string, but invalid YAML
    test_json_string = '''
        {"foo" : {"bar": "baz"} }
    '''

    # This is neither a valid JSON nor YAML string
    test_invalid_string = '''
        { "foo" : { "bar" : "baz" }}
    '''


    # Test valid YAML
    result = from_yaml(test_yaml_string)
    assert result['foo']['bar'] == 'baz'

    # Test valid JSON
    result = from_yaml(test_json_string, json_only=True)

# Generated at 2022-06-20 23:48:12.170914
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('string') == 'string'
    assert from_yaml(u'string') == u'string'
    assert from_yaml('string\n') == 'string'
    assert from_yaml(u'string\n') == u'string'
    assert from_yaml('"string"') == 'string'
    assert from_yaml(u'"string"') == u'string'
    assert from_yaml('"string\n"') == 'string\n'
    assert from_yaml(u'"string\n"') == u'string\n'
    assert from_yaml('"string\n"\n') == 'string\n'
    assert from_yaml(u'"string\n"\n') == u'string\n'
    assert from_

# Generated at 2022-06-20 23:48:14.287273
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": "b"}') == {'a': 'b'}
    assert from_yaml('---\na: b') == {'a': 'b'}
    assert from_yaml('{bad json') == None

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-20 23:48:26.311403
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import unittest

    TEST_DIR = os.path.abspath(os.path.dirname(__file__) + '/../../../test')
    TEST_FILES_DIR = os.path.abspath(os.path.dirname(__file__) + '/../../../test/files')
    sys.path.append(TEST_DIR)
    from lib.loader import AnsibleLoader
    from unit.mock.yaml_loader_mock import YamlLoaderMock
    from unit.mock.fs_mock import FS
    loader = AnsibleLoader(None, None)
    loader.set_fs_plugin(FS(cfg=None))
    loader._create_plugin_loader = lambda t: YamlLoaderMock()
    loader.set_mocked_ansible_

# Generated at 2022-06-20 23:48:31.329666
# Unit test for function from_yaml
def test_from_yaml():
    load_data = from_yaml("""
- name: test
  foo: bar
    """)
    assert(load_data[0]['name'] == 'test')
    assert(load_data[0]['foo'] == 'bar')
    assert(len(load_data) == 1)

# Generated at 2022-06-20 23:48:39.767780
# Unit test for function from_yaml
def test_from_yaml():
    import copy
    test_data = dict(
        password='secret',
        group='wheel',
        port=8888,
        enabled=False,
    )
    # Test for non-string argument
    assert from_yaml(copy.deepcopy(test_data)) == test_data
    test_data['sub'] = dict(sub_sub=dict(sub_sub_sub='subsubsub'))
    # Test for string argument
    assert from_yaml(json.dumps(test_data)) == test_data
    assert from_yaml(json.dumps(test_data), json_only=True) == test_data
    assert from_yaml(json.dumps(test_data), json_only=True) == test_data



# Generated at 2022-06-20 23:48:51.943448
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import yaml
    ansiblestring = os.path.dirname(__file__)
    ansiblestring = ('/'.join(ansiblestring.split('/')[:-1]))
    filedata = open(ansiblestring+'/../../../lib/ansible/module_utils/basic.py', 'r')
    filedata2 = open(ansiblestring+'/../../../lib/ansible/module_utils/basic.py', 'r')
    filedata3 = open(ansiblestring+'/../../../lib/ansible/module_utils/basic.py', 'r')
    filedata4 = open(ansiblestring+'/../../../lib/ansible/module_utils/basic.py', 'r')
    fileobj = filedata.read()
   

# Generated at 2022-06-20 23:49:01.778955
# Unit test for function from_yaml
def test_from_yaml():
    test_data = {
        'json_data': {
            'json_data': 'this is json data',
            'boolean': True
        },
        'yaml_data': {
            'yaml_data': 'this is yaml data',
            'boolean': False
        }
    }
    yaml_str = '''
json_data:
  json_data: "this is json data"
  boolean: True
yaml_data:
  yaml_data: "this is yaml data"
  boolean: False\n'''

# Generated at 2022-06-20 23:49:13.060906
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('$ANSIBLE_VAULT;1.1;AES256', b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')]
    vault = VaultLib(vault_secrets)

    test_dict = dict(a=1)
    test_str = 'a: 1'
    assert test

# Generated at 2022-06-20 23:49:28.470867
# Unit test for function from_yaml
def test_from_yaml():
    # valid JSON and YAML
    assert from_yaml("{\"something\": 1}", json_only=True) == {"something": 1}
    assert from_yaml("---\nsomething: 1") == {"something": 1}
    assert from_yaml("---\nsomething: 1", show_content=False) == {"something": 1}

    # invalid JSON and YAML
    try:
        from_yaml("{\"something(): 1}", json_only=True)
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml("---\nsomething: 1")
        assert False
    except AnsibleParserError:
        pass

    # invalid JSON, valid YAML

# Generated at 2022-06-20 23:49:39.290968
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("42") == 42
    assert from_yaml("some string") == "some string"
    assert from_yaml("- 1\n- 2\n- 3") == [1, 2, 3]
    assert from_yaml("{x: 42}")['x'] == 42
    # Test that JSON-compatible data is correctly parsed:
    assert from_yaml("42", json_only=True) == 42
    assert from_yaml('["a","b","c"]', json_only=True) == ['a', 'b', 'c']
    assert from_yaml('{"a":1, "b":2}', json_only=True) == {'b': 2, 'a': 1}

    # Test YAML:
    assert from_yaml("42") == 42
    assert from_y

# Generated at 2022-06-20 23:49:48.321820
# Unit test for function from_yaml
def test_from_yaml():

    yaml_data = """
    dog:
        name: spot
        age: 2
    """
    assert from_yaml(yaml_data) == {'dog': {'name': 'spot', 'age': 2}}

    json_data = """
    {
        "dog": {
            "name": "spot",
            "age": 2
        }
    }
    """
    assert from_yaml(json_data) == {'dog': {'name': 'spot', 'age': 2}}

    json_data = """
    {
        "dog": {
            "name": "spot",
            "age": 2
        },
        "foo": [
            "bar",
            "baz"
        ]
    }
    """

# Generated at 2022-06-20 23:49:58.339616
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    assert from_yaml('{}') == {}
    assert from_yaml('{"foo": 42}') == {"foo": 42}

    assert from_yaml('foo: 42') == {"foo": 42}
    assert from_yaml('foo : 42') == {"foo": 42}
    assert from_yaml(' foo : 42') == {"foo": 42}
    assert from_yaml(' foo : 42 ') == {"foo": 42}
    assert from_yaml(' foo : 42 # comment') == {"foo": 42}

    # this doesn't work on Python 2.6 or 2.7, need to upgrade to 2.6.9 or use 2.7.9+
    if PY3:
        assert from_yaml('42') == 42
        assert from_y

# Generated at 2022-06-20 23:50:03.817307
# Unit test for function from_yaml
def test_from_yaml():

    test_input = """
    ---
    - name: fail
      fail:
        msg: hello
    - name: fail
      fail:
        msg: world
    """

    result = from_yaml(test_input)
    assert result == [{"fail": {"msg": "hello"}, "name": "fail"}, {"fail": {"msg": "world"}, "name": "fail"}], "Bad JSON parsing"

# Generated at 2022-06-20 23:50:13.048854
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import Mapping

    test_yaml = "---\n" \
                "foo:  123\n" \
                "bar:  456\n" \
                "baz:  789\n" \
                "nested:\n" \
                "  - foo\n" \
                "  - bar\n" \
                "  - baz\n" \
                "...\n"

    test_yaml_dict = {
        'foo': 123,
        'bar': 456,
        'baz': 789,
        'nested': [
            'foo',
            'bar',
            'baz'
        ]
    }


# Generated at 2022-06-20 23:50:24.331464
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # ansible yaml parser
    from_yaml_parsed_value = from_yaml(
        '''{"foo": "\\"bar\\""}''',
        json_only=True
    )
    # python yaml parser
    import yaml
    yaml_parsed_value = yaml.safe_load(
        '''{"foo": "\\"bar\\""}'''
    )

    assert from_yaml_parsed_value == yaml_parsed_value

    # ansible yaml parser
    from_yaml_parsed_value = from_yaml(
        '''{"foo": "\\nbar\\n"}''',
        json_only=True
    )
    # python yaml