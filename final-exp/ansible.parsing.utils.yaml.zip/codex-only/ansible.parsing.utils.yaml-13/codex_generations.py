

# Generated at 2022-06-23 05:21:41.856948
# Unit test for function from_yaml
def test_from_yaml():
    # should raise exception if String is not passed
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.ajson import AnsibleJSONDecoder


# Generated at 2022-06-23 05:21:51.209571
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_to_json_object = from_yaml('{"key": "value"}')
    from_yaml_to_yaml_object = from_yaml('key: value')
    from_yaml_to_json_object_to_yaml_object = from_yaml(from_yaml('{"key": "value"}'))
    from_yaml_to_yaml_object_to_json_object = from_yaml(from_yaml('key: value'))

    assert from_yaml_to_json_object == {"key": "value"}
    assert from_yaml_to_yaml_object == {"key": "value"}
    assert from_yaml_to_json_object_to_yaml_object == {"key": "value"}
    assert from_yaml_to_y

# Generated at 2022-06-23 05:22:01.467182
# Unit test for function from_yaml
def test_from_yaml():
    '''
    We're going to test that, for valid and invalid inputs, the following
    functions/exceptions work (or don't work) as expected:
    - _handle_error
    - json.loads
    - AnsibleLoader.get_single_data
    - _safe_load

    Please note:

    Because the lines here are hardcoded, they do not correspond to the actual
    lines from from_yaml, but merely illustrate that the proper line numbers
    are shown in the error message.

    There are 4 kinds of valid YAML test cases:
    - dicts, lists, strings, and integers.
    Therefore the tests for valid cases are grouped into those 4 types, based
    on the value we expect to parse.

    There are more invalid YAML test cases; we've got a bunch!
    '''

# Generated at 2022-06-23 05:22:08.819818
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml(json.dumps({'foo':'bar'}))
    except AnsibleParserError:
        raise Exception('from_yaml should not have raised an exception')

    try:
        from_yaml('foo: bar', json_only=True)
    except AnsibleParserError:
        pass
    else:
        raise Exception('from_yaml should have raised an exception')

    try:
        from_yaml('foo: bar')
    except AnsibleParserError:
        raise Exception('from_yaml should not have raised an exception')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:22:12.656428
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(data="1234", file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    pass

# Generated at 2022-06-23 05:22:21.606966
# Unit test for function from_yaml
def test_from_yaml():
    # simple example
    yaml = "---\n- hosts: localhost\n  tasks:\n  - name: test\n    debug: msg='hello'"
    assert from_yaml(yaml, file_name='test') == {
        'tasks': [
            {
                'debug': {
                    'msg': 'hello'
                },
                'name': 'test'
            }
        ],
        'hosts': 'localhost'
    }

    # complex example

# Generated at 2022-06-23 05:22:27.925891
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Make sure we can read both YAML and JSON files
    '''

    list_data = """
    - 1
    - 2
    - 3
    """

    list_data_as_json = """
    [1, 2, 3]
    """

    expected_list = [1, 2, 3]

    import pprint
    pprint.pprint(expected_list)

    assert from_yaml(list_data) == expected_list
    assert from_yaml(list_data_as_json) == expected_list

    list_with_unicode = u"""
    - 1
    - 2
    - 3
    - 正念
    """

    list_with_unicode_as_json = u"""
    [1, 2, 3, 正念]
    """

# Generated at 2022-06-23 05:22:28.600184
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-23 05:22:40.577771
# Unit test for function from_yaml
def test_from_yaml():
    data = {'a': 'b', 'c': 'd'}
    file_name = 'test_file'

    assert isinstance(from_yaml(json.dumps(data)), dict)
    assert isinstance(from_yaml(json.dumps(data), file_name=file_name), dict)
    assert isinstance(from_yaml(json.dumps(data), file_name=file_name, show_content=False), dict)
    assert isinstance(from_yaml(json.dumps(data), file_name=file_name, show_content=False, vault_secrets='foo'),
                      dict)

# Generated at 2022-06-23 05:22:51.093388
# Unit test for function from_yaml
def test_from_yaml():
  from ansible.utils.unsafe_proxy import AnsibleUnsafeText
  import pytest
  from ansible.module_utils._text import to_text
  from ansible.parsing.yaml.objects import AnsibleMapping
  from ansible.parsing.dataloader import DataLoader

  test_data = to_text(u"""
    ---
    - hosts: localhost
      gather_facts: false
      tasks:
        - name: create a file
          file:
            path: /tmp/foo
            state: touch
            mode: 0777
  """)

  assert isinstance(from_yaml(test_data), AnsibleMapping)


# Generated at 2022-06-23 05:22:55.491616
# Unit test for function from_yaml
def test_from_yaml():
    ansible_yaml = "foo: 1\nbar:\n  baz:\n    foobar: 2\n"
    ansible_json = '{"bar":{"baz":{"foobar":2}},"foo":1}'
    assert ansible_json == json.dumps(from_yaml(ansible_yaml))



# Generated at 2022-06-23 05:23:00.452311
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import ansible

    file_path = os.path.join(os.path.dirname(ansible.__file__), 'ansible.cfg')
    print(file_path)
    print(from_yaml(open(file_path).read()))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:23:11.866270
# Unit test for function from_yaml
def test_from_yaml():
    # Test a valid YAML file
    data = """
    ---
    - hosts: localhost
      tasks:
        - name: test
          command: echo hello
    """
    file_name = 'test.yml'
    new_data = from_yaml(data, file_name)
    foo = new_data[0]
    assert foo['hosts'] == 'localhost'
    task = foo['tasks'][0]
    assert task['name'] == 'test'
    assert task['command'] == 'echo hello'

    # Test valid JSON file
    data = """
    [{
      "hosts": "localhost",
      "tasks": {
        "name": "test",
        "command": "echo hello"
      }
    }]
    """
    file_name = 'test.json'

# Generated at 2022-06-23 05:23:19.094669
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml('{"id": 1, "name":', json_only=True)
    assert 'unexpected end of JSON input' in str(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml('{"id": 1, "name":')
    assert 'but could not parse as YAML' in str(excinfo.value)

# Generated at 2022-06-23 05:23:29.032114
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    a : 1
    b :
      - 2
      - 3
    '''
    res = from_yaml(yaml_str)
    assert res == {'a': 1, 'b': [2, 3]}
    try:
        from_yaml(yaml_str, json_only=True)
        assert False
    except AnsibleParserError:
        pass

    yaml_str = '''
    a : 1
    b :
      - 2
      - 3
    - 4
    '''
    try:
        from_yaml(yaml_str)
        assert False
    except AnsibleParserError:
        pass

    # Try a real JSON string
    json_str = '{"a": 1, "b": [2, 3]}'
    res = from_

# Generated at 2022-06-23 05:23:40.138201
# Unit test for function from_yaml
def test_from_yaml():
    # Test for JSON
    json_data = """{
      "hello": "world"
    }"""
    data = from_yaml(json_data)
    assert isinstance(data, dict)
    assert data['hello'] == "world"

    # Test for JSON w/ comment
    json_data = """{
      // some comment
      "hello": "world"
    }"""
    data = from_yaml(json_data)
    assert isinstance(data, dict)
    assert data['hello'] == "world"

    # Test for YAML
    yaml_data = """
    hello: "world"
    """
    data = from_yaml(yaml_data)
    assert isinstance(data, dict)
    assert data['hello'] == "world"

    # Test for YAML w/ comment

# Generated at 2022-06-23 05:23:44.506042
# Unit test for function from_yaml
def test_from_yaml():

    yaml_string = """
    ---
    - hosts: localhost
      tasks:
      - name: test_task
        debug:
         msg: "{{ hostvars[inventory_hostname]['ansible_default_ipv4']['address'] }}"
        tags: test
    """

    result = from_yaml(yaml_string)

    assert result[0]['hosts'] == 'localhost'

# Generated at 2022-06-23 05:23:47.290966
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-23 05:23:53.354826
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml("{\"test\": true}"))
    print(from_yaml("{\"test\": true}", vault_secrets=['bad', 'vault']))
    print(from_yaml("--- {\"test\": true}", vault_secrets=['bad', 'vault']))

# Generated at 2022-06-23 05:24:02.709749
# Unit test for function from_yaml
def test_from_yaml():
    v = {"foo": "looks good", "bar": "really good"}
    json_data = json.dumps(v)
    yaml_data = '---\nfoo: looks good\nbar: really good\n'

    assert from_yaml("{'foo': 'baz', 'ansible': '2.0'}") == {"foo": "baz", "ansible": "2.0"}
    assert from_yaml(json_data) == v
    assert from_yaml(yaml_data) == v

    # throw exception when invalid json string
    try:
        from_yaml("{foo: 'baz', 'ansible': '2.0'}")
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-23 05:24:13.343278
# Unit test for function from_yaml
def test_from_yaml():
    # Good JSON
    assert from_yaml("{\"key\": \"value\"}") == {"key": "value"}

    # Bad JSON
    try:
        assert from_yaml("{\"key\": \"value\"")
    except AnsibleParserError:
        pass

    # Good YAML
    assert from_yaml("key: value") == {"key": "value"}

    # Bad YAML
    try:
        assert from_yaml("key: value\n")
    except AnsibleParserError:
        pass

    # Bad JSON and Bad YAML
    try:
        assert from_yaml("\"key\": \"value\"")
    except AnsibleParserError:
        pass

    # Fail only if JSON is bad, not YAML

# Generated at 2022-06-23 05:24:19.970224
# Unit test for function from_yaml

# Generated at 2022-06-23 05:24:26.046115
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == {u'foo': u'bar'}
    assert from_yaml('{ foo: bar }') is None
    assert from_yaml('{ foo: bar }', json_only=True) is None

# Generated at 2022-06-23 05:24:34.635384
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    ---
    'borris':
      name: borris
      age: 20
      pets:
      - name: dog
        species: dalmation
      - name: cat
        species: moggie
    'jeremy':
      name: jeremy
      age: 30
      pets:
      - name: dog
        species: labrador
      - name: cat
        species: tabby
      - name: frog
        species: frog
    """
    data = from_yaml(test_data)
    assert data
    assert data[0]['name'] == 'borris'

# Generated at 2022-06-23 05:24:43.466759
# Unit test for function from_yaml
def test_from_yaml():
    # Not sure why we need to do this but the tests in test_parser.py have
    # hidden errors that might be caused by this test.
    n_yaml_syntax_error = YAML_SYNTAX_ERROR % u''

    assert from_yaml('{"foo": 1}') == {"foo": 1}
    assert from_yaml("'foo': 1") == {'foo': 1}
    try:
        from_yaml('{"foo": 1')
        assert False, "from_yaml did not raise error for invalid JSON"
    except AnsibleParserError as e:
        assert n_yaml_syntax_error in str(e)

    assert from_yaml("- foo") == [u'foo']

# Generated at 2022-06-23 05:24:54.631222
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("test: hello") == {"test": "hello"}
    assert from_yaml("[]") == []
    assert from_yaml("{}") == {}
    assert from_yaml("[a,b,c]") == ["a", "b", "c"]
    assert from_yaml("{a:b,c:d}") == {"a": "b", "c": "d"}
    assert from_yaml("{a:b,c:[d,e,f]}") == {"a": "b", "c": ["d", "e", "f"]}
    assert from_yaml("a") == "a"
    assert from_yaml("true") == True
    assert from_yaml("10") == 10
    assert from_yaml("-10") == -10
    assert from_

# Generated at 2022-06-23 05:25:04.061928
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml("{}") == {}
    assert from_yaml("a: 1") == {'a': 1}
    assert from_yaml("{'a': {}}") == {'a': {}}

    # All things that are valid JSON should be parsed as JSON
    assert from_yaml("[]") == []
    assert from_yaml("""{
        "a": 1,
        "b": [2, 3]
    }""") == {"a": 1, "b": [2, 3]}

    # yaml.load() does not support parsing of JSON strings
    assert from_yaml("{\"a\": 1}") == {"a": 1}

    # some yaml not supported by json.loads
    assert from_yaml("[1, 2]") == [1, 2]
    assert from_y

# Generated at 2022-06-23 05:25:08.815939
# Unit test for function from_yaml
def test_from_yaml():

    json_str = '{ "test" : "test" }'
    yaml_str = 'test: test'
    json_data = from_yaml(json_str)
    yaml_data = from_yaml(yaml_str)

    assert json_data == yaml_data

# Generated at 2022-06-23 05:25:19.489592
# Unit test for function from_yaml
def test_from_yaml():
    """Providing a test case for the from_yaml() function.
    """

    import os
    import tempfile
    import unittest

    class AnsibleJSONDecoderTestCase(unittest.TestCase):
        """Providing a test case for the AnsibleJSONDecoder class.
        """

        def test_from_yaml_1(self):
            """Test case for the from_yaml() function.
            """
            valid_yaml = "---\n- hosts: all\n  gather_facts: false\n"
            data = from_yaml(valid_yaml)
            self.assertTrue(type(data) is list)
            content = data[0]
            self.assertEqual(type(content), dict)
            self.assertEqual(content['hosts'], 'all')
            self

# Generated at 2022-06-23 05:25:25.322476
# Unit test for function from_yaml
def test_from_yaml():
    # a simple test to verify the alias
    sample = "{\"hello\": \"world\"}"
    res = from_yaml(sample, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    assert sample == res

# Generated at 2022-06-23 05:25:33.498485
# Unit test for function from_yaml

# Generated at 2022-06-23 05:25:35.013187
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{ "a": 1, "b": 2 }')

# Generated at 2022-06-23 05:25:44.135754
# Unit test for function from_yaml
def test_from_yaml():
    data = {'a': 1, 'b': 2}
    data_yaml = 'a: 1\nb: 2\n'
    data_json = '{"a": 1, "b": 2}'
    assert from_yaml(data_yaml) == data
    assert from_yaml(data_yaml, json_only=True) == data
    assert from_yaml(data_json) == data
    assert from_yaml(data_json, json_only=True) == data
    assert from_yaml(data_yaml, json_only=True) == data
    assert from_yaml(data_json, json_only=True) == data

# Generated at 2022-06-23 05:25:46.564169
# Unit test for function from_yaml
def test_from_yaml():
    input_data = "{'test': true}"
    output_data = from_yaml(input_data)
    assert output_data == {'test': True}, "from_yaml returned incorrect data"

# Generated at 2022-06-23 05:25:48.869056
# Unit test for function from_yaml
def test_from_yaml():
    d = from_yaml('{"foo": "bar"}')
    assert d == {'foo': 'bar'}

# Generated at 2022-06-23 05:25:55.314998
# Unit test for function from_yaml
def test_from_yaml():
    import os
    file_path=os.path.dirname(os.path.realpath(__file__))
    with open(file_path+'/test.yml', 'r') as f:
                data = f.read()
    vault_secrets=None
    file_name='<string>'
    show_content=True
    json_only=False
    result = json.loads(from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False))
    assert result['my_var'] == 'bar'

# Generated at 2022-06-23 05:26:07.187235
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    data = """
    ---
    mykey: my_value
    my_list:
      - "test"
    another_dict:
      key1: value1
      key2: value2
    ...
    """

    data2 = """
    ---
    my_list:
      - "test"
      - "test2"
    ...
    """

    data3 = b"""
    ---
    my_list:
      - "test"
      - "test2"
    ...
    """


# Generated at 2022-06-23 05:26:17.162393
# Unit test for function from_yaml

# Generated at 2022-06-23 05:26:22.323813
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}") == {u'a': u'b'}
    assert from_yaml("a: b") == {u'a': u'b'}
    try:
        from_yaml("{'a': 1")
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-23 05:26:33.720177
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "a": true }'
    res = from_yaml(data, json_only=True)
    assert res == {'a': True}
    data = '{"a": "{{ a }}"}'
    res = from_yaml(data, json_only=True)
    assert res == {'a': '{{ a }}'}
    data = '''{ "a": [
        1,
        {
            "b": 2,
            "c": "{{ a }}",
            "d": 3
        }
    ]}'''
    res = from_yaml(data, json_only=True)
    assert res == {'a': [1, {'b': 2, 'c': '{{ a }}', 'd': 3}]}

# Generated at 2022-06-23 05:26:45.021133
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{foo: 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{1:2, 3:4}") == {1: 2, 3: 4}
    assert from_yaml('''{foo: 'bar',
        baz: {
            fred: 'ted',
            barney: ['betty','wilma','dino']
        }
    }''') == {'foo': 'bar', 'baz': {'fred': 'ted', 'barney': ['betty', 'wilma', 'dino']}}

# Generated at 2022-06-23 05:26:53.573712
# Unit test for function from_yaml
def test_from_yaml():
    # Test a simple data structure
    assert from_yaml('- robert') == ['robert']

    # Test an invalid yaml data structure
    try:
        assert from_yaml('-robert')
    except AnsibleParserError:
        pass
    except:
        assert False

    # Test an invalid JSON data structure
    try:
        assert from_yaml('-robert', json_only=True)
    except AnsibleParserError:
        pass
    except:
        assert False

# Generated at 2022-06-23 05:26:56.777310
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{foo: bar}') == {'foo': 'bar'}


# Unit test loader

# Generated at 2022-06-23 05:27:03.979543
# Unit test for function from_yaml
def test_from_yaml():
    string_input = '''
    {
        'val1': 1,
        'val2': 'string',
        'val3': [
            1,
            'string',
            {
                'val1': 1
            }
        ]
    }
    '''
    result = from_yaml(string_input)

    assert result['val1'] == 1
    assert result['val2'] == 'string'
    assert result['val3'][0] == 1
    assert result['val3'][1] == 'string'
    assert result['val3'][2]['val1'] == 1

# Generated at 2022-06-23 05:27:14.212846
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.facts.system.distribution import Distribution

    distribution = Distribution()
    os = distribution.get_distribution()

    if os == 'unknown':
        print("Unit tests not run: distribution unknown")
        return

    # Load data into python structure
    data = """
    first_name: John
    last_name: Smith
    """
    parsed = from_yaml(data)
    # print(parsed)

    # Compare parsed data to expected data
    expected_result = {'first_name': 'John', 'last_name': 'Smith'}
    assert(parsed == expected_result)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:27:19.323142
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"key": "value"}') == {u'key': u'value'}
    assert from_yaml('{"key": "value"}', json_only=True) == {u'key': u'value'}

    assert from_yaml('key: value') == {u'key': u'value'}
    assert from_yaml('key: value', json_only=True) is None

# Generated at 2022-06-23 05:27:22.262973
# Unit test for function from_yaml
def test_from_yaml():
    data_str = """# This is a test yaml
---
foo: "bar"
baz: 123
"""
    data = from_yaml(data_str)
    assert data == {'foo': 'bar', 'baz': 123}

# Generated at 2022-06-23 05:27:34.250626
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.dataloader
    data1 = '{"json": "data"}'
    data2 = """{
    "json": "data"
}
---
- {"json": "other data"}
- { "json": "other data" }
"""
    data3 = """{ json: "data" }"""
    data4 = "data"
    data5 = """{
    "json": "data"
}
 - { "json": "other data" }
"""
    data6 = """
- { "json": "other data" }
"""
    data7 = """
- { "json": "other data" }
---
{ "json": "data" }
"""

    # test basic JSON parsing

# Generated at 2022-06-23 05:27:43.816004
# Unit test for function from_yaml
def test_from_yaml():
    """Test conversion of YAML to Python data structures."""

    # A simple test for a YAML literal scalar.
    yaml_str = "foo"
    assert from_yaml(yaml_str) == "foo" and from_yaml(yaml_str) != 42

    # A simple test for a YAML folded scalar.
    yaml_str = ">\n  foo\nbar"
    assert from_yaml(yaml_str) == "foo bar" and from_yaml(yaml_str) != "foobar"

    # A simple test for a YAML literal scalar.
    yaml_str = '"foo"'
    assert from_yaml(yaml_str) == "foo" and from_yaml(yaml_str) != 42

    # A simple test for a

# Generated at 2022-06-23 05:27:53.168237
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic unit test for function from_yaml.
    '''
    test_yaml = b'{ "foo": "bar", "baz": "bam" }'
    test_data = from_yaml(test_yaml)
    assert test_data == {'foo': 'bar', 'baz': 'bam'}
    # test it as well when using the json not yaml
    test_data = from_yaml(test_yaml, json_only=True)
    assert test_data == {'foo': 'bar', 'baz': 'bam'}

# Generated at 2022-06-23 05:28:03.312600
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 05:28:13.243050
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml.objects
    ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.SECRET_NAMESPACE = 'vault'
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    def test_data(data, vault_secrets):
        if vault_secrets is None:
            vault_secrets = ['']
        for secret in vault_secrets:
            decrypted_data = from_yaml(data, vault_secrets=[secret])
            assert decrypted_data == {'key': 'value'}

    def y(data):
        return yaml.dump(data, Dumper=AnsibleDumper)


# Generated at 2022-06-23 05:28:19.457457
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert from_yaml("{ 'foo': 'bar' }") == None
    except:
        print("assertion failed")

    assert from_yaml("""{ 'foo': 'bar' }""", json_only=False) == { 'foo': 'bar' }


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:28:30.236143
# Unit test for function from_yaml
def test_from_yaml():
    # Import ``json`` here to keep Ansible's ``json`` (in ``module_utils``) unused.
    import json

    def_data = {
        'name': 'test',
        'list': [1, 2, 3],
        'another_dict': {
            'key1': 'value1',
            'key2': 'value2'
        }
    }
    json_string = json.dumps(def_data)

# Generated at 2022-06-23 05:28:39.054881
# Unit test for function from_yaml
def test_from_yaml():
    data = yaml.safe_load("""
---
- name: Testing with yaml data
  connection: local
  tasks:
  - name: Find the files
    find:
      paths: /etc
      file_type: directory
      recurse: yes
      patterns:
        - "*.conf"
        - "*.ini"
        - "*.d"
        - "*.conf.d"
    register: files
  - debug: msg="{{files.files}}"
""")
    assert isinstance(data, list)
    assert data[0]['name'] == 'Testing with yaml data'

# Generated at 2022-06-23 05:28:41.752058
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '---\nfirst: second'
    assert from_yaml(test_data) == {'first': 'second'}

# Generated at 2022-06-23 05:28:53.512428
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    foo: val1
    bar:
        - val2
        - val3
    '''
    json_data = '{"foo":"val1","bar":["val2","val3"]}'

    # Test without vault secrets
    assert from_yaml(yaml_data) == {'foo': 'val1', 'bar': ['val2', 'val3']}
    assert from_yaml(json_data) == {'foo': 'val1', 'bar': ['val2', 'val3']}

    # Test with vault secrets
    vault_secrets = {'3': {'vault_string': '$ANSIBLE_VAULT;3.2;AES256;'}}

# Generated at 2022-06-23 05:29:03.962221
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"boolean\": true}") == {"boolean" : True}
    assert from_yaml("{\"string\": \"foo\"}") == {"string" : "foo"}
    assert from_yaml("{\"list\": [\"foo\", \"bar\"]}") == {"list" : ["foo", "bar"]}
    assert from_yaml("{\"dict\": {\"foo\": \"bar\"}}") == {"dict" : {"foo" : "bar"}}
    assert from_yaml("{\"int\": 42}") == {"int" : 42}
    assert from_yaml("{\"float\": 3.14}") == {"float" : 3.14}
    assert from_yaml("{\"none\": null}") == {"none" : None}

    # these dicts will be interpreted as lists (because the

# Generated at 2022-06-23 05:29:15.082846
# Unit test for function from_yaml
def test_from_yaml():
    data = 'a: b'
    res = from_yaml(data)
    assert res == {u'a': u'b'}

    data = 'a: b\nc: 1\nd: true'
    res = from_yaml(data)
    assert res == {u'a': u'b', u'c': 1, u'd': True}

    # Testing boolean values
    data = 'a: true'
    res = from_yaml(data)
    assert res == {u'a': True}

    data = 'a: false'
    res = from_yaml(data)
    assert res == {u'a': False}

    # Testing complex values
    data = 'a: {b: c}'
    res = from_yaml(data)

# Generated at 2022-06-23 05:29:24.722034
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import Mapping

    def assert_dict_and_int(d):
        assert isinstance(d, Mapping)
        assert d.get('a') == 10

        assert isinstance(d.get('b'), Mapping)
        assert d.get('b').get('b1') == 11
        assert d.get('b').get('b2') == 12

        assert isinstance(d.get('c'), Mapping)
        assert d.get('c').get('c1') == 21
        assert d.get('c').get('c2') == 22
        assert d.get('c').get('c3') == 23

        assert isinstance(d.get('d'), Mapping)
        assert isinstance(d.get('d').get('c'), Mapping)


# Generated at 2022-06-23 05:29:35.016665
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    # Basic test for json loading
    data = to_bytes('{"a": "1"}')
    assert from_yaml(data, json_only=True) == {u'a': u'1'}
    assert isinstance(from_yaml(data, json_only=True)['a'], AnsibleUnicode)
    # Basic test for the default non-json loader
    data = to_bytes('a: 1')
    assert from_yaml(data) == {u'a': 1}
    assert isinstance(from_yaml(data)['a'], int)
    # Basic test for the non-default non-json loader

# Generated at 2022-06-23 05:29:42.098455
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    {
        "a": "1",
        "b": 2,
        "c": [1, 2, 3]
    }
    '''
    result = from_yaml(data, file_name="file_name", show_content=True, vault_secrets=None, json_only=True)
    assert result == {
        "a": "1",
        "b": 2,
        "c": [1, 2, 3]
    }
    result = from_yaml(data, file_name="file_name", show_content=False, vault_secrets=None, json_only=True)
    assert result == {
        "a": "1",
        "b": 2,
        "c": [1, 2, 3]
    }

# Generated at 2022-06-23 05:29:45.869687
# Unit test for function from_yaml
def test_from_yaml():

    data = '''
    foo: bar
    '''

    assert from_yaml(data) == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}


# Generated at 2022-06-23 05:29:52.814310
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.unsafe_proxy import UnsafeProxy, create_unsafe_proxy

    # Test if json.loads can handle string value
    data = 'string value'
    assert json.loads(data) == data

    # Test if json.loads can handle empty string
    data = ''
    assert json.loads(data) is None

    # Test if json.loads can handle None
    data = None
    assert json.loads(data) is None

    # Test if json.loads can handle list
    data = [1, 2, 3, 4]
    assert json.loads(json.dumps(data)) == data

    # Test if json.loads can handle empty list
    data = []
    assert json.loads(json.dumps(data)) == data

    # Test if json.loads can handle dict

# Generated at 2022-06-23 05:30:03.838944
# Unit test for function from_yaml
def test_from_yaml():
    json_only = True
    data = '[ { "a": true }, { "b": true } ]'
    # data = '[ { "a": "true" }, { "b": "true" } ]'
    try:
        new_data = from_yaml(data, json_only=json_only)
        assert type(new_data) is list
        assert len(new_data) == 2
        assert new_data[0]['a'] == True
    except Exception as json_exc:
        print(json_exc)
        assert False, "Shouldn't have gotten here"

    json_only = False

# Generated at 2022-06-23 05:30:14.470258
# Unit test for function from_yaml
def test_from_yaml():
    # Test normal safe_load
    data = '''
        - -test
          - test2
          - test3
        - - test4
          - test5
          - test6
        - - test7
          - test8
          - test9
    '''
    result = from_yaml(data)
    assert result == [[u'test', u'test2', u'test3'], [u'test4', u'test5', u'test6'], [u'test7', u'test8', u'test9']]

    # Test normal load
    data = '''
        - -test
          - test2
          - test3
        - - test4
          - test5
          - test6
        - - test7
          - test8
          - test9
    '''
    result = from_

# Generated at 2022-06-23 05:30:23.225900
# Unit test for function from_yaml

# Generated at 2022-06-23 05:30:32.542488
# Unit test for function from_yaml
def test_from_yaml():
    import json
    test_string = '{"name": "joe", "age": 16}'
    assert json.loads(test_string) == from_yaml(test_string)
    test_string = '''
        - name: Joe
          age: 16
        - name: Mike
          age: 15
    '''
    assert json.loads(test_string) == from_yaml(test_string)
    test_string = '# this is not a valid JSON or YAML string'
    try:
        from_yaml(test_string)
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:30:36.650476
# Unit test for function from_yaml
def test_from_yaml():
    data = "test_data"
    file_name = 'foo'
    show_content = True
    vault_secrets = None
    json_only = False

    from_yaml(data, file_name, show_content, vault_secrets, json_only)

# Generated at 2022-06-23 05:30:40.843587
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('foo: bar', json_only=True) is None

# Generated at 2022-06-23 05:30:42.384727
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}

# Generated at 2022-06-23 05:30:51.637953
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
        a:
          - aaa
          - bbb
        b:
          - bbb
          - ccc
    '''

    json_data = '''
        {
            "a": ["aaa", "bbb"],
            "b": ["bbb", "ccc"]
        }
    '''

    # can load yaml
    yaml_data = from_yaml(yaml_data)
    assert yaml_data
    assert yaml_data['a'] == ['aaa', 'bbb']
    assert yaml_data['b'] == ['bbb', 'ccc']

    # can load json
    json_data = from_yaml(json_data)
    assert json_data
    assert json_data['a'] == ['aaa', 'bbb']
    assert json

# Generated at 2022-06-23 05:31:03.457458
# Unit test for function from_yaml
def test_from_yaml():
    import io

    data = """
    {
        "data": {
            "key": "value"
        }
    }
    """
    res = from_yaml(data)
    assert res['data']['key'] == 'value'

    data = """
    - plain
    - string
    """
    res = from_yaml(data)
    assert res[0] == 'plain'
    assert res[1] == 'string'

    data = '''
    ---
    - &anchor1 a value
    - &anchor2 &anchor1
    - *anchor1
    '''
    res = from_yaml(data)
    assert res[0] == 'a value'
    assert res[1] == 'a value'
    assert res[2] == 'a value'

    data

# Generated at 2022-06-23 05:31:14.542399
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    json_only = True
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    data = """
{
  "ip": "{{ ansible_eth0.ipv4.address }}",
  "dpdk_version": "16.07",
  "interface": "eth0"
}
"""
    assert data == from_yaml(data, json_only=json_only, file_name=file_name, show_content=show_content, vault_secrets=vault_secrets)
    # un-matching yaml

# Generated at 2022-06-23 05:31:20.479013
# Unit test for function from_yaml
def test_from_yaml():
    input_data = '''{
        "name": "ansible",
        "dependencies": {
            "paramiko": "2.4.2",
            "PyYAML": "3.12"
        },
        "maintainers": [
            "michael.dehaan",
            "jimi.hendrix",
            "elvis.presley"
        ],
        "galaxy_tags": [
            "network",
            "cloud",
            "test",
            "configuration"
        ]
    }'''

# Generated at 2022-06-23 05:31:31.144271
# Unit test for function from_yaml
def test_from_yaml():
    good_yaml_str = '''
    - hosts:
        - foo
        - bar
      gather_facts: False
      tasks:
      - name: test
        setup:
        register: result
    '''
    data = from_yaml(good_yaml_str)
    assert 'hosts' in data[0]
    assert 'foo' in data[0]['hosts']
    assert 'bar' in data[0]['hosts']
    assert False == data[0]['gather_facts']
    assert 'tasks' in data[0]
    assert 1 == len(data[0]['tasks'])
    assert 'test' == data[0]['tasks'][0]['name']

# Generated at 2022-06-23 05:31:42.476884
# Unit test for function from_yaml
def test_from_yaml():
    import data_type_tests as tests
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from tempfile import NamedTemporaryFile

    a_dict = {
        "test": {
            "value1": "test1",
            "value2": "test2",
            "sub": {
                "subvalue1": "subtest1",
                "subvalue2": "subtest2"
            }
        }
    }

    # yaml equivalent of above a_dict
    yaml_text = """\
{test: {value1: "test1", value2: "test2", sub: {subvalue1: "subtest1",
                    subvalue2: "subtest2"}}}
    """

    # encrypted version of above