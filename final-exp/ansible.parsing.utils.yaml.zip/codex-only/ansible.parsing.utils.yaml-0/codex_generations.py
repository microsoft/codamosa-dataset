

# Generated at 2022-06-23 05:21:43.968955
# Unit test for function from_yaml
def test_from_yaml():
    # this test is for the "json" system integration tests, which have no valid YAML to use
    invalid_yaml = "no_valid_yaml_here"
    json_data = "{\"v\": 123}"

    yaml_data_simple = "---\nkey: value\n"
    yaml_data_array = "---\n- 1\n- 2\n"

    # try to load the YAML test data as JSON, which should fail
    try:
        json.loads(yaml_data_simple)
        assert False
    except Exception:
        assert True

    try:
        json.loads(yaml_data_array)
        assert False
    except Exception:
        assert True

    # make sure the function can safely load no data into JSON

# Generated at 2022-06-23 05:21:54.480155
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
---

- hosts: localhost
  vars:
    name: hello
    age: 10
  tasks:
    - shell: echo "user_name is {{name}}, user_age is {{age}}"
      register: result
    - debug: var=result.stdout_lines
'''
    result = from_yaml(yaml_str)
    assert(result[0]['hosts'] == 'localhost')
    assert(result[0]['vars']['name'] == 'hello')
    assert(result[0]['vars']['age'] == 10)
    assert(result[0]['tasks'][0]['shell'] == 'echo "user_name is {{name}}, user_age is {{age}}"')

# Generated at 2022-06-23 05:21:59.732068
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    import yaml
    yaml_file = open('../../yaml-example.yaml', 'r')
    if yaml_file.mode == 'r':
        data = yaml_file.read()
        print(data)
        print(yaml.dump(from_yaml(data), default_flow_style=False))
        yaml_file.close()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:22:10.846690
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('foo: bar', vault_secrets=[ 'foo' ]) == {'foo': AnsibleVaultEncryptedUnicode('foo', 'bar')}
    assert from_yaml('foo: !!python/object/apply:subprocess.Popen') == {'foo': {'_legacy_invocation': {'module_args': {'_raw_params': 'subprocess.Popen'}}}}

# Generated at 2022-06-23 05:22:13.258826
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_data = from_yaml("", file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    assert from_yaml_data == None

# Generated at 2022-06-23 05:22:22.005890
# Unit test for function from_yaml

# Generated at 2022-06-23 05:22:27.917338
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.compat.tests import unittest

    import sys

    class TestErrors(unittest.TestCase):
        def test_from_yaml(self):
            self.assertRaises(AnsibleParserError, from_yaml, '')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 05:22:36.851318
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import is_sequence, is_set
    from ansible.parsing.yaml.objects import AnsibleMapping
    import types

    class FixedOffset(datetime.tzinfo):
        def __init__(self, offset, name):
            self.__offset = datetime.timedelta(minutes=offset)
            self.__name = name

        def utcoffset(self, dt):
            return self.__offset

        def tzname(self, dt):
            return self.__name

        def dst(self, dt):
            return datetime.timedelta(0)


# Generated at 2022-06-23 05:22:47.001827
# Unit test for function from_yaml
def test_from_yaml():
    # valid JSON should work in either case
    assert from_yaml('{ "foo": "bar" }') == { u'foo': u'bar' }
    assert from_yaml('{ "foo": "bar" }', json_only=True) == { u'foo': u'bar' }

    # YAML inside valid JSON should be treated as JSON
    assert from_yaml('{ "foo": "bar", "baz": "{ key: value }" }') == { u'foo': u'bar', u'baz': u'{ key: value }' }
    assert from_yaml('{ "foo": "bar", "baz": "{ key: value }" }', json_only=True) == { u'foo': u'bar', u'baz': u'{ key: value }' }

    # invalid JSON is

# Generated at 2022-06-23 05:22:51.212965
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''
- hosts: localhost
  tasks:
  - name: task1
    debug:
      msg: "Hello Ansible"''') == [{'hosts': 'localhost', 'tasks': [{'name': 'task1', 'debug': {'msg': 'Hello Ansible'}}]}]

# Generated at 2022-06-23 05:23:00.128291
# Unit test for function from_yaml
def test_from_yaml():

    # Ensure YAML dictionaries are preserved as such
    data_dict = {'foo': 'bar'}
    assert from_yaml(data_dict) == data_dict

    # Ensure YAML list are preserved as such
    data_list = ['foo', 'bar']
    assert from_yaml(data_list) == data_list

    # Ensure JSON strings are preserved as such
    data_string = '"foo"'
    assert from_yaml(data_string) == data_string

    # Ensure JSON objects are preserved as such
    data_object = '{"foo": "bar"}'
    assert from_yaml(data_object) == data_object

    # Ensure JSON arrays are preserved as such
    data_array = '["foo", "bar"]'
    assert from_yaml(data_array) == data_array



# Generated at 2022-06-23 05:23:04.084024
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    data=from_yaml('{"name": "test"}')
    assert data["name"] == "test"

# Generated at 2022-06-23 05:23:11.300817
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"some_key": [{"one": "foo", "two": {"bar": "baz"}}]}'
    result = from_yaml(data)
    assert isinstance(result, dict)
    assert 'some_key' in result.keys()
    assert isinstance(result['some_key'], list)
    assert isinstance(result['some_key'][0], dict)
    assert 'one' in result['some_key'][0].keys()
    assert 'two' in result['some_key'][0].keys()
    assert 'bar' in result['some_key'][0]['two'].keys()
    assert result['some_key'][0]['two']['bar'] == 'baz'
    assert from_yaml(data, json_only=True) == result

# Generated at 2022-06-23 05:23:16.130654
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    test_data = "foo: bar"
    data = from_yaml(test_data)

    assert isinstance(data, AnsibleMapping)
    assert 'foo' in data
    assert data['foo'] == 'bar'

# Generated at 2022-06-23 05:23:19.607822
# Unit test for function from_yaml
def test_from_yaml():
    ''' test a yaml string '''
    data = '''
    key1: 1
    key2: 2
    '''
    assert from_yaml(data) == {'key1': '1', 'key2': '2'}

# Generated at 2022-06-23 05:23:27.070899
# Unit test for function from_yaml
def test_from_yaml():
    json_vars = "{\"test_var\": \"json_value\"}"
    yaml_vars = "{test_var: yaml_value}"
    assert from_yaml(json_vars) == {"test_var": "json_value"}
    assert from_yaml(yaml_vars, json_only=True) is None
    assert from_yaml(yaml_vars) == {"test_var": "yaml_value"}
    assert from_yaml("broken") is None
    assert from_yaml("broken", json_only=True) is None

# Generated at 2022-06-23 05:23:34.704147
# Unit test for function from_yaml
def test_from_yaml():
    example_yaml_1 = '''
    ---
    - hosts: all
      tasks:
        - name: include
          include_vars:
            file: "../defaults/main.yml"
    '''
    example_yaml_2 = '''
    ---
    - hosts: all
      tasks:
        - name: include
          include_vars:
            file: "{{ lookup('env','PWD') }}/../defaults/main.yml"
    '''
    example_yaml_3 = '''
    ---
    - hosts: all
      vars:
        test_var1: "../defaults/main.yml"
    '''

# Generated at 2022-06-23 05:23:37.805767
# Unit test for function from_yaml
def test_from_yaml():
    docs = """- a
- b
- c
"""

    expected = [u'a', u'b', u'c']

    assert from_yaml(docs) == expected



# Generated at 2022-06-23 05:23:46.204663
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test our from_yaml() function with a few different valid and invalid formats.
    '''
    from ansible.utils.jsonfun import from_json, json_loads
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml import objects
    from ansible.parsing.vault import VaultLib
    import sys, os

    vault_pass = 'vault_password'

    try:
        vault = VaultLib(vault_pass)
    except TypeError:
        vault = VaultLib(vault_pass.encode('utf-8'))

    vault_secrets = dict(vault_pass=vault_pass)

    # no vault secrets

# Generated at 2022-06-23 05:23:54.185900
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    load_data = DataLoader()
    invalid_yaml_data = load_data.load_from_file("test/functional/common/test_parser/test_yaml.yml")
    test_data = {
        "test_variable": "test_value",
        "test_list": [
            "item1",
            "item2"
        ]
    }

    try:
        from_yaml(invalid_yaml_data)
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in e.message

    yaml_data = from_yaml(invalid_yaml_data, json_only=True)
    assert yaml_data == {"Hello": "World"}

   

# Generated at 2022-06-23 05:23:59.526718
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"test1": 1, "test2": 2, "test3": 3, "test4": {"test5": 5}}'

    new_data = from_yaml(test_data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    assert new_data == json.loads(test_data)

# Generated at 2022-06-23 05:24:09.748854
# Unit test for function from_yaml
def test_from_yaml():
    '''
    The unit test for function from_yaml.
    '''
    # Success1:decode YAML data to python data
    data = "{'name': 'liu','age': 20, 'hobby': ['eat','play','sleep']}"
    new_data = from_yaml(data)
    assert type(new_data) == dict
    assert new_data['name'] == 'liu'
    assert new_data['age'] == 20
    assert len(new_data['hobby']) == 3
    assert new_data['hobby'][0] == 'eat'


# Generated at 2022-06-23 05:24:16.464757
# Unit test for function from_yaml
def test_from_yaml():
    # Test for a valid data string
    assert from_yaml('{}') == {}
    # Test the JSON string
    assert from_yaml('{}', json_only=True) == {}
    # Now test the exception
    try:
        from_yaml('{', json_only=True)
    except AnsibleParserError:
        pass
    except Exception as e:
        assert False, "A different exception type was caught"

# Generated at 2022-06-23 05:24:26.710996
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.errors.yaml_strings import YAML_SYNTAX_ERROR

    # Vault tests

# Generated at 2022-06-23 05:24:28.620356
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[{}, [1],2,3]') == [{}, [1], 2, 3]

# Generated at 2022-06-23 05:24:35.346067
# Unit test for function from_yaml
def test_from_yaml():
    print("Start testing")
    data = [1,2,3,4,5]
    json_data = json.dumps(data)
    yaml_data = yaml.dump(data)
    json_from_from_yaml = from_yaml(json_data)
    yaml_from_from_yaml = from_yaml(yaml_data)
    assert json_data == json_from_from_yaml
    assert yaml_data == yaml_from_from_yaml
    return

# Generated at 2022-06-23 05:24:41.520655
# Unit test for function from_yaml
def test_from_yaml():
    import yaml
    valid_yaml = """
        - {'id': 1, 'is_active': True, 'name': 'Mark'}
        - {'id': 2, 'is_active': False, 'name': 'Jared'}
        - {'id': 3, 'is_active': True, 'name': 'Don'}
    """
    obj = yaml.safe_load(valid_yaml)
    print (from_yaml(valid_yaml))
test_from_yaml()

# Generated at 2022-06-23 05:24:47.057744
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
contacts:
    - Mark McGwire
    - Sammy Sosa
    - Ken Griffy'''
    yaml_data = from_yaml(data)
    json_data = json.loads(data)
    assert yaml_data == json_data
    print(yaml_data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:24:53.245654
# Unit test for function from_yaml
def test_from_yaml():

    example = '''
    # A simple YAML list
    - a
    - b
    - c
    - d

    # A more complex dictionary
    'world' :
      foo :
        - bar
      - 'baz' : quux
    '''

    assert from_yaml(example) == [
        'a',
        'b',
        'c',
        'd'
    ], 'was unable to re-create the original datastructure'

# Generated at 2022-06-23 05:25:01.298794
# Unit test for function from_yaml
def test_from_yaml():
    # Valid yaml
    valid_yaml = from_yaml("""
      - hosts:
          - foo
          - bar
       tags:
          - always
       tasks:
         - debug:
             msg: hello
    """)

    assert valid_yaml == [{
        u'hosts': [u'foo', u'bar'],
        u'tags': [u'always'],
        u'tasks': [{u'debug': {u'msg': u'hello'}}]
    }]

    # Valid json

# Generated at 2022-06-23 05:25:02.546104
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("'test'") == 'test'

# Generated at 2022-06-23 05:25:13.071697
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault

    # Test Yaml
    yaml = """
      foo:
         - 1
         - two
         - [3, 4]
      bar:
      - 1.1
      - bar
      key with spaces: 1
      key with "quotes": "2"
      'key with quotes on both sides': '3'
      key with quotes and spaces: '4'
      "key with spaces and quotes": '5'
      complex: !vault |
          $ANSIBLE_VAULT;1.2;AES256;test
          333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333
          3333333333333333333333333333333333333333333333333333
    """


# Generated at 2022-06-23 05:25:21.496091
# Unit test for function from_yaml
def test_from_yaml():
    # Tests the safe loading of only valid YAML files
    def good_yaml_test(filename):
        contents = open(filename, "r").read()
        data = from_yaml(contents)
        assert data is not None

    # Tests that corrupting json string with # doesn't render it invalid YAML
    def bad_yaml_test(filename):
        contents = open(filename, "r").read()
        try:
            from_yaml(contents)
            assert False
        except AnsibleParserError as e:
            assert True

    good_yaml_test("tests/parser/fixtures/good_yaml.yml")
    good_yaml_test("tests/parser/fixtures/good_yaml.json")

# Generated at 2022-06-23 05:25:32.086993
# Unit test for function from_yaml
def test_from_yaml():
    json_string = u'{"test": "value"}'
    result = from_yaml(json_string)
    assert result == {"test": "value"}

    yaml_string = u"test: value"
    result = from_yaml(yaml_string)
    assert result == {"test": "value"}

    json_string_with_comments = u'{"test": "value"} # this is a comment'
    result = from_yaml(json_string_with_comments)
    assert result == {"test": "value"}

    yaml_string_with_comments = u"test: value # this is a comment"
    result = from_yaml(yaml_string_with_comments)
    assert result == {"test": "value"}


# Generated at 2022-06-23 05:25:43.731711
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os
    import tempfile
    import shutil
    import collections

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 05:25:54.490306
# Unit test for function from_yaml
def test_from_yaml():
    res = from_yaml('{ "a": "b" }')
    assert isinstance(res, dict)

    try:
        from_yaml('{ "a": "b", }')
        assert False, 'should not get here'
    except AnsibleParserError as e:
        assert 'JSON: Expecting property name enclosed in double quotes' in to_native(e)
        assert '{{{ "a": "b", }}}' in to_native(e)

    res = from_yaml('{ a: b }')
    assert isinstance(res, dict)


# Generated at 2022-06-23 05:26:06.677763
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    if sys.version_info[0] > 2:
        assert from_yaml('{ "a": 1 }') == {u'a': 1}
        assert from_yaml('{ "a": [1, "a", "b"] }') == {u'a': [1, u'a', u'b']}
        assert from_yaml('example.yml') == {u'a': [1, u'a', u'b']}
    else:
        assert from_yaml('{ "a": 1 }') == {'a': 1}
        assert from_yaml('{ "a": [1, "a", "b"] }') == {'a': [1, 'a', 'b']}

# Generated at 2022-06-23 05:26:15.150800
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(r'"foo"') == "foo"
    assert from_yaml(r'"foo"', json_only=True) == "foo"

    # yaml multiline string
    assert from_yaml(r'"foo\nbar"') == "foo\nbar"
    assert from_yaml(r'"foo\nbar"', json_only=True) == "foo\nbar"

    # yaml string with key
    assert from_yaml(r"foo: bar") == {"foo": "bar"}
    assert from_yaml(r"foo: bar", json_only=True) == "{\"foo\": \"bar\"}"

# Generated at 2022-06-23 05:26:23.012887
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence
    x = b"---\n# this is a comment\n- x\n- y\n- z"
    with pytest.raises(AnsibleParserError):
        from_yaml(x, "<unicode>", False)
    y = from_yaml(x)
    assert(isinstance(y, AnsibleSequence))
    assert(y == ['x','y','z'])
    assert(from_yaml(b"---\n1", json_only=True))

# Generated at 2022-06-23 05:26:34.180034
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic function unit test for function from_yaml.
    '''

    # internal test, no need to be installed
    from ansible.parsing.vault import VaultLib, VaultSecret
    test_data = {'a': 1, 'b': "value", 'c': None, 'd': VaultSecret('This is a secret')}

    # create a vault to use
    vault = VaultLib([])
    vault_secrets = vault.secrets
    password = 'testpass'
    vault.update(password, vault.dump(test_data))

    # save the vault and encrypt it
    encrypted_data = vault.encrypt(vault.serialize())

    # load the vault and decrypt it
    vault.deserialize(encrypted_data, password)

    # load the data from yaml and make sure it is correct

# Generated at 2022-06-23 05:26:37.527688
# Unit test for function from_yaml
def test_from_yaml():
    file_name = './test_from_yaml.yml'
    result = from_yaml(open(file_name, 'r').read(), file_name)
    assert( result['name'] == 'from_yaml' )

# Generated at 2022-06-23 05:26:47.219237
# Unit test for function from_yaml
def test_from_yaml():
    ret=from_yaml("""---
    - hosts: testserver
      gather_facts: no
      tasks:
        - name: print
          debug:
              msg: "name is {{ ansible_hostname }}"
        - name: ping
          ping:
    """)
    assert type(ret) is list, "test_from_yaml failed"
    assert len(ret) == 1, "test_from_yaml failed"
    assert type(ret[0]) is dict, "test_from_yaml failed"
    assert 'hosts' in ret[0], "test_from_yaml failed"
    assert ret[0]['hosts'] == 'testserver', "test_from_yaml failed"

# Generated at 2022-06-23 05:26:58.298458
# Unit test for function from_yaml
def test_from_yaml():

    data = '''
    {
        "foo": "bar",
        "numbers": [1, 2, 3, 4],
        "quoted": "single ' quote",
        "boolean": [true, false],
        "hash": { "one": 1, "two": 2 },
        "braces": { "red": "{{red}}", "green": "{{green}}" },
        "red": "{{red}}",
        "green": "{{green}}"
    }
    '''

    red_value = 'red'
    green_value = 'green'

    vars_dict = from_yaml(data)
    assert vars_dict['foo'] == 'bar'
    assert vars_dict['boolean'][0] == True
    assert vars_dict['boolean'][1] == False


# Generated at 2022-06-23 05:27:01.527730
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"a\":\"b\"}") == {"a":"b"}
    assert from_yaml("a: b") == {"a":"b"}

# Generated at 2022-06-23 05:27:13.162000
# Unit test for function from_yaml
def test_from_yaml():
    # Test to make sure that the function returns YAML object when
    # YAML data is given
    yaml_obj = from_yaml("""{
        'table': {
            'foo': {'bar': 'baz'}
        }
    }""")
    assert type(yaml_obj) is dict

    # Test to make sure that the function returns JSON when
    # JSON data is given
    json_obj = from_yaml("""{
        "table": {
            "foo": {"bar": "baz"}
        }
    }""")
    assert type(json_obj) is dict

    # Exceptions should be caught and passed on
    from ansible.errors import AnsibleParserError
    try:
        from_yaml("a bad yaml document")
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:27:22.916515
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    - hosts: localhost
      tasks:
        - name: Echo back the provided message
          debug: msg="{{ msg }}"
          vars:
            msg: "Hello World"
    '''
    expected_data = [{'hosts': 'localhost',
                      'tasks': [
                          {
                              'name': 'Echo back the provided message',
                              'debug': {
                                  'msg': '{{ msg }}'
                              },
                              'vars': {
                                  'msg': 'Hello World'
                              }
                          }
                      ]
                      }]
    assert expected_data == from_yaml(yaml_data)

# Generated at 2022-06-23 05:27:34.870701
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loaders import AnsibleLoader

    # Test list
    input_str = """
    - this
    - is
    - a
    - list
    """
    assert from_yaml(input_str) == ['this', 'is', 'a', 'list']

    # Test dictionary
    input_str = """
    this:
      is:
        a:
          dictionary:
            with:
              "several":
              - levels
              - of
              - keys
    """
    assert from_yaml(input_str) == {'this': {'is': {'a': {'dictionary': {'with': {'several': ['levels', 'of', 'keys']}}}}}}

    # Test a string that is not valid YAML

# Generated at 2022-06-23 05:27:44.361093
# Unit test for function from_yaml
def test_from_yaml():
    # Some minimal smoke tests
    test_cases = [
        ('[1, 2, 3]', json.loads('[1, 2, 3]')),
        ('{"a":1, "b":2}', json.loads('{"a":1, "b":2}')),
        ('[1, 2, 3]', [1, 2, 3]),
        ('{"a":1, "b":2}', {'a': 1, 'b': 2}),
    ]

    for s, expected in test_cases:
        actual = from_yaml(s)
        assert expected == actual

    # Now some tests using from_yaml to load YAML files
    # These tests load up the test files in ./unit/ and ensure that
    # the resulting Python structures are correct for a given YAML file.
    # These tests are

# Generated at 2022-06-23 05:27:52.266339
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hash_behaviour: merge
    - name: test
    '''
    from ansible.utils.yaml.dumper import AnsibleDumper
    from ansible.utils.yaml.loader import AnsibleLoader
    from ansible.utils.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    import yaml
    from io import StringIO

    class AnsibleConstructor(yaml.SafeConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self._file_name = file_name
            self._vault_secrets = vault_secrets
            self._loader = AnsibleLoader
           

# Generated at 2022-06-23 05:27:56.953698
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\nfoo: 42") == {"foo": 42}
    assert from_yaml("{\"foo\": 42}") == {"foo": 42}
    try:
        from_yaml("---\nfoo: 'bar'") == {"foo": "bar"}
    except AnsibleParserError:
        pass
    else:
        assert False, "Need to catch error on invalid YAML"

# Generated at 2022-06-23 05:28:08.444731
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultEditor

    def _assert_yaml_equal(a, b):
        assert a == b
        assert a.__class__ == b.__class__
        assert to_text(a) == to_text(b)

        # Write to YAML and compare
        # As AnsibleUnicode inherits from unicode, it is an acceptable type to pass to AnsibleDumper
        if isinstance(a, str):
            a = AnsibleUnicode(a)
            b = AnsibleUnicode(b)
        a = AnsibleDumper

# Generated at 2022-06-23 05:28:09.635382
# Unit test for function from_yaml
def test_from_yaml():
    assert False == bool(from_yaml(''))

# Generated at 2022-06-23 05:28:20.254850
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils._text import to_native, to_text
    from ansible.parsing.ajson import AnsibleJSONDecoder
    import ansible.errors.yaml_strings as yaml_strings
    data = """
- name: One
  value: 1
- name: Two
  value: 2
- name: Three
  value: 3
    """
    loader = AnsibleLoader(data, '<string>', None)
    try:
        return loader.get_single_data()
    finally:
        try:
            loader.dispose()
        except AttributeError:
            pass
#assert test_from_yaml() ==

# Generated at 2022-06-23 05:28:24.476064
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{foo: bar}") == {'foo': 'bar'}
    assert from_yaml("{{foo: bar}}") == {'foo': 'bar'}
    assert from_yaml("foo: bar") == {'foo': 'bar'}

# Generated at 2022-06-23 05:28:34.574683
# Unit test for function from_yaml
def test_from_yaml():
    print('from_yaml function')

    # Test with empty yaml string
    yml_data = ''
    try:
        ret_data = from_yaml(yml_data)
        assert(ret_data == None)
    except Exception as err:
        print("from_yaml() is failed to handle empty yaml string, error: %s" % err)
        return (-1)

    # Test with invalid yaml string
    yml_data = 'invalid_yml_string'
    try:
        ret_data = from_yaml(yml_data)
        assert(False)
    except Exception as err:
        print("from_yaml() is failed to handle invalid yaml string, error: %s" % err)
        return (-1)

    # Test with valid yaml string
    yml_

# Generated at 2022-06-23 05:28:38.481119
# Unit test for function from_yaml
def test_from_yaml():
    import doctest
    failed, tests = doctest.testmod(from_yaml)
    assert failed == 0, "%d of %d docstring tests failed" % (failed, tests)

# Generated at 2022-06-23 05:28:46.191909
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts: localhost
      tasks:
        - name: "test1"
          shell: "echo {{ test | to_json }}"
          register: v
        - name: "test2"
          shell: "echo {{ v.stdout | from_json }}"
    '''
    output = from_yaml(data)
    assert output == [{'hosts': 'localhost', 'tasks': [{'name': 'test1', 'shell': 'echo {{ test | to_json }}', 'register': 'v'}, {'name': 'test2', 'shell': 'echo {{ v.stdout | from_json }}'}]}]

# Generated at 2022-06-23 05:28:57.530068
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import traceback
    #from_yaml()


# Generated at 2022-06-23 05:29:07.644042
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test that load works properly.
    """
    # Make sure script can be loaded and used as a module.
    if __name__ == '__main__':
        from ansible.parsing.yaml.loader import AnsibleFileLoader
        from ansible.parsing.yaml.dumper import AnsibleDumper
        from ansible.module_utils._text import to_bytes
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
        import sys


# Generated at 2022-06-23 05:29:19.072984
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Run tests on from_yaml to ensure the code behaves properly.
    '''

    # Test 1: YAML Syntax Error
    yaml_str = '''
        ---
        - test_1
             - should have a space
        - test_2
    '''

    try:
        from_yaml(yaml_str)
    except AnsibleParserError as e:
        # Test 1: YAML Syntax Error
        assert "mapping values are not allowed here" in str(e), \
            "'mapping values are not allowed here' is expected in " + str(e)
    else:
        assert False, "from_yaml should fail when provided with incorrect YAML syntax"

    # Test 2: JSON Syntax Error

# Generated at 2022-06-23 05:29:25.690963
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Example unit test for the from_yaml function.
    '''
    assert from_yaml(u'{"test1":"ok","test2":"ok"}') == {'test1': 'ok', 'test2': 'ok'}
    assert from_yaml(u'{"test1": "ok", "test2": "ok"}') == {'test1': 'ok', 'test2': 'ok'}
    assert from_yaml(u'{"test1": "ok", "test2": "ok"}', json_only=True) == {'test1': 'ok', 'test2': 'ok'}

# Generated at 2022-06-23 05:29:35.451420
# Unit test for function from_yaml
def test_from_yaml():
    samples = [
        # good yaml
        """
        - hosts: localhost
          tasks:
            - name: debug
              debug: msg={{ myvar }}
        """,
        # good json
        '{"a": [1, 2, 3], "b": "c"}',
        # good json with yaml-like syntax
        '{"a": [1, 2, 3], "b": "c", "d": "e"}',
        # bad json
        '{"a": [1, 2, 3], "b": "c"',
        # bad yaml
        """
        - hosts: localhost
          tasks host=localhost
            - name: debug
              debug: msg={{ myvar }}
        """
    ]

    import textwrap

    results, exceptions = [], []


# Generated at 2022-06-23 05:29:40.756261
# Unit test for function from_yaml
def test_from_yaml():
  import sys
  data = """
  {
    "id": "test",
    "name": "test"
  }
  """
  ansible_data = from_yaml(data)
  assert isinstance(ansible_data, dict) and ansible_data['id'] == 'test'
  print("Pass!")

if __name__ == "__main__":
  test_from_yaml()

# Generated at 2022-06-23 05:29:47.567315
# Unit test for function from_yaml
def test_from_yaml():

    data = """
    foo: bar
    baz:
      - 1
      - 2
      - [3,4]
    """
    res = from_yaml(data)
    assert res == {"foo": "bar", 'baz': [1, 2, [3, 4]]}

    data = "{\"foo\": \"bar\"}"
    res = from_yaml(data, json_only=True)
    assert res == {"foo": "bar"}

# Generated at 2022-06-23 05:29:54.399156
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = \
'''
---
- name: Test playbook
  hosts: all
'''
    parsed = from_yaml(test_yaml)
    assert type(parsed) == list
    assert parsed[0]['name'] == 'Test playbook'
    assert parsed[0]['hosts'] == 'all'

# Generated at 2022-06-23 05:29:56.719903
# Unit test for function from_yaml
def test_from_yaml():
    yml="""
    ---
    name: Test
    ..."""
    from_yaml(yml)

# Generated at 2022-06-23 05:30:00.026519
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'

    assert from_yaml(data=data) == {"foo": "bar"}


# Generated at 2022-06-23 05:30:07.492861
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    import pytest
    from io import StringIO

    data = u'''
    hello: world
    foo:
      - 1
      - 2
      - [3, 4]

    bar:
      "<<":
        - &centos7
          - test-1.example.com
          - test-2.example.com
        - *centos7
    '''

    # Make sure we can't import something not JSON or YAML
    with pytest.raises(AnsibleParserError):
        from_yaml('{][')

    assert from_yaml(data, json_only=True)

# Generated at 2022-06-23 05:30:14.759318
# Unit test for function from_yaml
def test_from_yaml():
    data = 'string'
    new_data = from_yaml(data)

    assert new_data == data
    assert isinstance(new_data, str)

    data = "{'foo': '123'}"
    new_data = from_yaml(data)

    assert new_data == eval(data)
    assert isinstance(new_data, dict)

    data = "{'foo': {'bar': '123'}}"
    new_data = from_yaml(data)

    assert new_data == eval(data)
    assert isinstance(new_data, dict)

# Generated at 2022-06-23 05:30:23.388761
# Unit test for function from_yaml
def test_from_yaml():
    import types
    import ansible.parsing.yaml.data
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Generate YAML string for a dictionary with a unicode value and a byte
    # string value by first generating a dictionary with an AnsibleUnicode
    # value and a byte string value then using yaml.safe_dump to generate
    # the YAML string.
    test_dict = {'unicode': AnsibleUnicode(u'unicode'), 'bytes': to_bytes('bytes')}

# Generated at 2022-06-23 05:30:34.497148
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.utils import json

    answer = from_yaml(json.dumps({'json': 'works'}), json_only=True)
    assert answer == {'json': 'works'}

    answer = from_yaml(json.dumps({'json': 'works'}))
    assert answer == {'json': 'works'}

    answer = from_yaml(json.dumps(['json', 'works']))
    assert answer == ['json', 'works']

    answer = from_yaml('{json: works}')
    assert answer == {'json': 'works'}

    answer = from_yaml('[json, works]')
    assert answer == ['json', 'works']


# Generated at 2022-06-23 05:30:35.144906
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml()

# Generated at 2022-06-23 05:30:39.427420
# Unit test for function from_yaml
def test_from_yaml():
    contents = '''
- - Foo
  - Bar
- - Foo2
  - Bar2
'''

    rval = from_yaml(contents)
    assert rval is not None
    assert len(rval) == 2

# Generated at 2022-06-23 05:30:49.193860
# Unit test for function from_yaml
def test_from_yaml():
    import ast
    import pytest
    # Verify that  function returns dictionary as expect

    yamldata = """
        -
            name: hello
            color: red
            state: absent
        -
            name: world
            color: blue
            state: present
    """

    jsondata = '''
        [
            {
              "color": "red",
              "name": "hello",
              "state": "absent"
            },
            {
              "color": "blue",
              "name": "world",
              "state": "present"
            }
          ]
        '''
    datadict = ast.literal_eval(jsondata)
    assert from_yaml(yamldata) == datadict

    

# Generated at 2022-06-23 05:30:59.791498
# Unit test for function from_yaml
def test_from_yaml():
    from collections import MutableMapping
    from ansible.module_utils.json_utils import from_json

    example_yaml = """
    # This is an example YAML document for use in testing the from_yaml function
    data:
      key1: value1
      key2:
        key3:
          key4: value2
    """
    example_json = """
    // This is an example JSON document for use in testing the from_yaml function
    {
        "data": {
            "key1": "value1",
            "key2": {
                "key3": {
                    "key4": "value2"
                }
            }
        }
    }
    """

# Generated at 2022-06-23 05:31:11.113355
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    json_string = '{"foo": "bar"}'

    # Test JSON object
    data = loader.load(json_string)
    assert data.get('foo') == 'bar'

    # Test YAML object
    yaml_string = 'foo: bar'
    data = loader.load(yaml_string)
    assert data.get('foo') == 'bar'

    # Test error
    err_string = '{foo: bar}'
    try:
        loader.load(err_string)
        assert False
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in e.message

# Generated at 2022-06-23 05:31:17.829242
# Unit test for function from_yaml
def test_from_yaml():
    json_data = {
        'foo': [ 'bar', 'baz' ],
        'bar': 'foo',
        'baz': True,
        'bax': False,
        'nest': {'a': 'foo'}
    }

    yaml_data = """
foo:
- bar
- baz
bar: foo
baz: True
bax: false
nest:
  a: foo
"""

    assert from_yaml(json.dumps(json_data), file_name='dummy') == json_data
    assert from_yaml(yaml_data, file_name='dummy') == json_data

# Generated at 2022-06-23 05:31:25.568681
# Unit test for function from_yaml
def test_from_yaml():
    # Try to convert a YAML string
    yaml_str = '''---
- hosts: localhost
  become: yes
  tasks:
  - name: yum_service_install
    yum:
      name: elasticsearch
    register: es_install

  - name: blockinfile
    blockinfile:
      path: /etc/elasticsearch/elasticsearch.yml
      block: |
        network.host: "{{ hostvars[inventory_hostname]['ansible_'+network_interface]['ipv4']['address'] }}"
        bootstrap.memory_lock: true
    tags: tags_elasticsearch
'''
    # Try to convert a JSON string

# Generated at 2022-06-23 05:31:36.920739
# Unit test for function from_yaml
def test_from_yaml():
  from unittest import TestCase
  class FromYamlTestCase(TestCase):
    def test_from_yaml(self):
      # Valid YAML
      self.assertIsNotNone(from_yaml('---'))

      # Valid JSON
      self.assertIsNotNone(from_yaml('{}'))

      # Invalid
      with self.assertRaises(AnsibleParserError):
        from_yaml('foo')

      # Invalid JSON, invalid YAML
      with self.assertRaises(AnsibleParserError):
        from_yaml('foo\nbar\ntest')

      # Invalid JSON, valid YAML
      with self.assertRaises(AnsibleParserError):
        from_yaml('foo\n---\ntest')

      # Invalid JSON, valid YAML, invalid