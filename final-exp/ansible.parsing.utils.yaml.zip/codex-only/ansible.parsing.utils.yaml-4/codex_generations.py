

# Generated at 2022-06-23 05:21:40.187442
# Unit test for function from_yaml
def test_from_yaml():
    '''
        Just a basic smoke test to make sure nothing is broken.
        We are testing the function outside of the Ansible class
        so that we can run this individual test outside of the
        docker containers.

        Use --debug-module to run the unit tests.
    '''
    data = from_yaml('{ "test": "data" }')
    assert data['test'] == 'data'

# Generated at 2022-06-23 05:21:48.021239
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import tempfile


# Generated at 2022-06-23 05:21:49.857164
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'{ "test": "value" }') == {"test": "value"}



# Generated at 2022-06-23 05:22:01.403840
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml '''

    import os
    from ansible.module_utils.six import StringIO

    from ansible.parsing.vault import VaultLib

    # We need to create a fake Secret object for the vault class
    class FakeVaultSecret:
        vault_files = []

        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            pass

        def _get_vault_text(self, *args, **kwargs):
            return 'Test'

        def get_decrypted_contents(self, *args, **kwargs):
            return ''


# Generated at 2022-06-23 05:22:04.535263
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml("FOO: foobar") == {'FOO': 'foobar'}
    assert from_yaml("FOO: foobar",json_only=True) != {'FOO': 'foobar'}

# Generated at 2022-06-23 05:22:11.208357
# Unit test for function from_yaml
def test_from_yaml():
  test_data = '{"a": 1, "b": 2}'
  assert(from_yaml(test_data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
  == {"a": 1, "b":2})

# Generated at 2022-06-23 05:22:20.730660
# Unit test for function from_yaml
def test_from_yaml():
    """ Test to check AnsibleBaseYAMLObject from_yaml function """

    # Load single data
    data1 = """
---
- include: ../main.yml
- name: USERS
  hosts: all
  become: yes
  roles:
    - common
    - users
  vars:
    users:
      ansible:
        fullname: Ansible User
        state: present
        shell: /bin/bash
"""
    loader = AnsibleLoader(data1, file_name='test_file')
    try:
        result1 = loader.get_single_data()
    finally:
        loader.dispose()

    # Load multiple data

# Generated at 2022-06-23 05:22:21.783389
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("hello") == "hello"

# Generated at 2022-06-23 05:22:23.256039
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("data") is None



# Generated at 2022-06-23 05:22:29.905427
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml
    import os

    test_dat = os.path.join(os.path.dirname(ansible.parsing.__file__), 'tests', 'shippable', 'test_yaml.yml')
    with open(test_dat, 'r') as data:
        res = from_yaml(data.read())
    assert(res[0]['hosts'] == 'localhost')

# Generated at 2022-06-23 05:22:38.346199
# Unit test for function from_yaml
def test_from_yaml():

    import ansible.parsing.vault as vault
    from ansible.module_utils.six.moves import StringIO

    my_vault_secret = vault.VaultSecret('password')

    # JSON
    test_json = """
        { "some": "json", "foo": "bar", "baz": [ "one", "two", "three" ], "bool": true }
    """
    my_data = from_yaml(test_json, file_name='<string>', show_content=True, vault_secrets=[my_vault_secret], json_only=False)
    print(my_data)
    print('')
    print('---')
    print('')

    # YAML

# Generated at 2022-06-23 05:22:46.837539
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    # NOTE: This function is used by the python-yaml library.
    # Ensure that it can be imported correctly.
    assert isinstance(from_yaml('some_key: some_value', '<test_from_yaml>'), AnsibleMapping)
    assert isinstance(from_yaml('{ "some_key": "some_value" }', '<test_from_yaml>'), AnsibleMapping)

# Generated at 2022-06-23 05:22:57.163549
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_data = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
            'e': [1, 2, 3, 4],
            'f': u'unicode_string',
            'g': u'\u20ac',
            'h': b'bytes_string',
            'i': None,
        },
        'c': [1, 2, 3, "three", {'four': 4}],
        'd': True,
        'last': False,
    }

    # Test with a filename
    from_yaml_data = from_yaml(AnsibleDumper(None, None, None).dump(test_data), 'test_from_yaml')


# Generated at 2022-06-23 05:23:04.770149
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import PY3

    dl = DataLoader()

    test_data = {
        'basic_string': 'this is a simple string',
        'list1': [1, 2, 3, 4],
        'dict1': {
            'a': 1,
            'b': 2,
            'c': [3, 4, 5],
        },
    }

    yaml_output = dl.dump(test_data, Dumper=AnsibleDumper)
    round_trip = dl.load(yaml_output)

    assert round_trip == test_data

# Generated at 2022-06-23 05:23:12.284886
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []
    assert from_yaml("123") == 123
    assert from_yaml("false") is False
    assert from_yaml("null") is None
    assert from_yaml("[1,2,3]") == [1,2,3]
    assert from_yaml("""---
a: 1
b: 2
c:
  d: 3
  e: 4
""") == {'a':1, 'b':2, 'c':{'d':3, 'e':4}}

# vim: set sts=4 sw=4 et :

# Generated at 2022-06-23 05:23:20.086732
# Unit test for function from_yaml
def test_from_yaml():
    data1 = """
    {
        "test": "success",
        "ansible": "ok"
    }
    """
    data2 = """
    test: success
    ansible: ok
    """

    # from_yaml(data, file_name, show_content, vault_secrets, json_only):
    for data in (data1, data2):
        assert from_yaml(data) == {
            "test": "success",
            "ansible": "ok"
        }

    data3 = """
    {
        "test": "success",
        "ansible": "ok"
    """

# Generated at 2022-06-23 05:23:25.773709
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test if from_yaml works.
    '''
    json_str = '{"a": 1, "b": 2}'
    yaml_str = """a: 1
b: 2
"""
    assert from_yaml(json_str) == {"a": 1, "b": 2}
    assert from_yaml(yaml_str) == {"a": 1, "b": 2}


# Generated at 2022-06-23 05:23:34.412422
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo: - 1\n  - 2\n  - 3') == {'foo': [1, 2, 3]}
    assert from_yaml('foo: [1, 2, 3]') == {'foo': [1, 2, 3]}
    assert from_yaml('foo: - bar\n        baz') == {'foo': ['bar\nbaz']}
    assert from_yaml("foo: 'bar\nbaz'") == {'foo': 'bar\nbaz'}
    assert from_yaml("foo: !foo_type 'bar\nbaz'") == {'foo': {u'!foo_type': 'bar\nbaz'}}
    assert from_yaml("foo: !!str 'bar\nbaz'") == {'foo': 'bar\nbaz'}

# Generated at 2022-06-23 05:23:43.648250
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 1}') == {"a": 1}
    assert from_yaml('{"a": 1}\n{"a": 1}') == {"a": 1}
    assert from_yaml('{"a": 1}', json_only=True) == {"a": 1}
    assert from_yaml('a: 1') == {"a": "1"}

    try:
        from_yaml('{not json}')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Expected exception')

    try:
        from_yaml('{"a": 1}', json_only=True)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Expected exception')


if __name__ == "__main__":
    test_

# Generated at 2022-06-23 05:23:53.058536
# Unit test for function from_yaml
def test_from_yaml():
    yaml_output = '''
---
- hosts: localhost
  tasks:
  - name: test1
    debug:
      msg: 'test1'
    when: "'test1' == test1"
  - name: test2
    debug:
      msg: 'test2'
    when: "'test2' == test2"
  - name: test3
    debug:
      msg: 'test3'
    when: "'test3' == test3"
    '''


# Generated at 2022-06-23 05:24:03.734172
# Unit test for function from_yaml
def test_from_yaml():
    text = """
[
{
"berlin": {
    "hosts": [
      "172.16.238.10",
      "172.16.238.11"
    ],
    "vars": {
      "ntp_server": "192.168.1.1",
      "app_server": "10.0.0.50"
    }
  },
"london": {
    "hosts": [
      "172.16.238.2",
      "172.16.238.4"
    ],
    "vars": {
      "ntp_server": "192.168.1.1",
      "app_server": "10.0.0.50"
    }
  }
}
]
"""
    from_yaml(text,show_content=True)



# Generated at 2022-06-23 05:24:14.355813
# Unit test for function from_yaml
def test_from_yaml():
    # import unit test modules
    import ansible.parsing.yaml.dumper
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader

    # check if naming is correct
    assert ansible.parsing.yaml.dumper.AnsibleDumper == ansible.parsing.yaml.objects.AnsibleDumper
    assert ansible.parsing.yaml.loader.AnsibleLoader == ansible.parsing.yaml.objects.AnsibleLoader

    # test function from_yaml with a json file
    example_json = '{"test": 123}'
    result_1 = from_yaml(example_json)
    assert isinstance(result_1, dict)

# Generated at 2022-06-23 05:24:20.779038
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.__init__ import AnsibleModule
    import os
    dir_path = '/home/jay/ansible-2.9.6/test/units/parsing/ajson/data'
    test_file = os.path.join(dir_path, 'test.yml')
    test_file1 = os.path.join(dir_path, 'test1.yml')
    test_file2 = os.path.join(dir_path, 'test2.yml')
    test_file3 = os.path.join(dir_path, 'test3.yml')
    test_file4 = os.path.join(dir_path, 'test4.yml')
    test_file5 = os.path.join(dir_path, 'test5.yml')
    test_

# Generated at 2022-06-23 05:24:24.507552
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 1}') == {'a': 1}
    assert from_yaml('{"a": 1}', json_only=True) == {'a': 1}
    assert from_yaml('a: 1') == {'a': 1}
    assert from_yaml('a: 1', json_only=True) == None

# Generated at 2022-06-23 05:24:29.014621
# Unit test for function from_yaml
def test_from_yaml():
    ansible_yaml = """
    - hosts:
        - localhost
      tasks:
      - name: failing ping test
        ping:
      - name: failing command test
        command:
    """
    from_yaml(ansible_yaml)



# Generated at 2022-06-23 05:24:39.140551
# Unit test for function from_yaml
def test_from_yaml():
    test_vars = {
        "key1": "value1"
    }
    assert from_yaml(json.dumps(test_vars), json_only=True) == test_vars
    assert from_yaml(json.dumps(test_vars)) == test_vars
    assert from_yaml(json.dumps({"key1": 1})) == {"key1": 1}
    assert from_yaml(json.dumps({"key1": ["a", 2, True]})) == {"key1": ["a", 2, True]}
    assert from_yaml(json.dumps({"key1": {"key2": "value2"}})) == {"key1": {"key2": "value2"}}

# Generated at 2022-06-23 05:24:49.656427
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("test") == "test"
    assert from_yaml("{ test") == "{ test"
    assert from_yaml("{ test }") == "{ test }"
    assert from_yaml("{ test\n }") == "{ test\n }"
    assert from_yaml("{ test:1 }") == {"test": 1}
    assert from_yaml("[]") == []
    assert from_yaml("['test', 'test']") == ["test", "test"]
    assert from_yaml("{}") == {}
    assert from_yaml("{ 'key': 'value' }") == {"key": "value"}
    assert from_yaml("{ key: value }") == {"key": "value"}

# Generated at 2022-06-23 05:24:53.978403
# Unit test for function from_yaml
def test_from_yaml():
    (ret, err) = from_yaml('''---
a: 1
b:
  - a
  - b
  - c
''')
    expected = {"a": 1, "b": ["a", "b", "c"]}
    assert ret == expected

# Generated at 2022-06-23 05:24:54.894500
# Unit test for function from_yaml
def test_from_yaml():
    assert b'a' == b'a'

# Generated at 2022-06-23 05:25:02.757060
# Unit test for function from_yaml
def test_from_yaml():
    from sys import version_info
    from os.path import dirname, join

    py_version = [version_info.major, version_info.minor]
    ANSIBALLZ_PATH = join(dirname(__file__), '../../lib/ansible/modules/extras')

# Generated at 2022-06-23 05:25:07.642098
# Unit test for function from_yaml
def test_from_yaml():
    ansibleVar = from_yaml("""
    - hosts: localhost
      gather_facts: False
      tasks:
        - debug:
            msg: "{{ this is json }}"
        - debug:
            msg: "{{ this is yaml }}"
    """)

    #assert(type(ansibleVar) == list)
    print(ansibleVar)

# Generated at 2022-06-23 05:25:17.753453
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_text = '''
- hosts: all
  tasks:
  - name: just echos
    debug:
      msg: "{{ inventory_hostname }}: {{ foo }} {{ bar }}"
'''
    data = from_yaml(yaml_text)

    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], AnsibleMapping)
    assert len(data[0].keys()) == 2

    assert 'hosts' in data[0]
    assert data[0]['hosts'] == 'all'
    assert len(data[0]['tasks']) == 1
    assert len

# Generated at 2022-06-23 05:25:26.101797
# Unit test for function from_yaml
def test_from_yaml():
    print("Running from_yaml() test")
    class TestClass:
        def __str__(self):
            return "TestClass"

    test_objects = [
        'string',
        5,
        1.0,
        [1,2,3],
        { "a": 5},
        True,
        False,
        None,
        TestClass()
    ]

    for obj in test_objects:
        data = json.dumps(obj)
        json_obj = json.loads(data)
        yaml_obj = from_yaml(data)
        if json_obj != yaml_obj:
            print("Incorrect data from %s" % (obj))
            return False

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:25:33.805110
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    builtins_open = builtins.open
    data = ''

    class _open(object):
        def __init__(self, data):
            self._data = data
            self._pos = 0

        def read(self, n):
            s = self._data[self._pos:self._pos + n]
            self._pos += n
            return s

        def seek(self, pos):
            self._pos = pos

        def close(self):
            pass

    def open_mock(filename, mode='r', buffering=-1):
        return _open(data)

    builtins.open = open_mock

    global data

# Generated at 2022-06-23 05:25:43.564920
# Unit test for function from_yaml
def test_from_yaml():
    d = from_yaml('{"a": "b"}')
    assert d == {"a": "b"}
    # The string '{"a": "b"}' is a valid JSON string and is therefore parsed
    # as a JSON string.
    d = from_yaml('{"a": "b"}', json_only=True)
    assert d == {"a": "b"}
    # The string 'a: b\n' is a valid YAML string, but not a valid JSON string,
    # and therefore raises an AnsibleParserError.
    try:
        d = from_yaml('a: b\n', json_only=True)
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-23 05:25:54.374381
# Unit test for function from_yaml
def test_from_yaml():
    test_data_json_ok={'empleado': {'apellido': 'Molina', 'nombre': 'Ariel'}}
    test_data_json_fail='{"empleado":{"apellido":"Molina","nombre":"Ariel"}'
    test_data_yaml_ok='empleado:\n  apellido: Molina\n  nombre: Ariel'
    test_data_yaml_fail='empleado:\n  apellido: Molina\n  nombre: Ariel\n'
    assert test_data_json_ok == from_yaml(test_data_json_ok)
    assert test_data_yaml_ok == from_yaml(test_data_yaml_ok)

# Generated at 2022-06-23 05:25:58.452017
# Unit test for function from_yaml
def test_from_yaml():

    data = from_yaml('- foo\n- bar')
    assert isinstance(data, list)

    data = from_yaml('foo: bar')
    assert isinstance(data, dict)

    assert from_yaml('1.0', json_only=True) == 1.0

# Generated at 2022-06-23 05:26:09.717881
# Unit test for function from_yaml
def test_from_yaml():

    # This tests a simple dictionary loaded from a string
    test_yaml = "---\nfoo: bar\n"
    assert from_yaml(test_yaml) == {'foo': 'bar'}
    test_yaml = "---\nfoo: bar\n\n"
    assert from_yaml(test_yaml) == {'foo': 'bar'}

    # This tests a simple dictionary loaded from a file
    test_yaml_file = "/tmp/ansible_test_yaml"
    f = open(test_yaml_file, 'w+')
    f.write(test_yaml)
    f.close()
    assert from_yaml(open(test_yaml_file)) == {'foo': 'bar'}

    # This tests a list of dictionaries with a boolean key
   

# Generated at 2022-06-23 05:26:19.313871
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    data = """
- debug:
    msg: Traversing the YAML object looking for the vars
- debug:
    msg: To find the Data
- debug:
    msg: test data
    """

    new_data = from_yaml(data, '<string>')
    assert isinstance(new_data, list)
    assert isinstance(new_data[0], AnsibleMapping)
    assert isinstance(new_data[1], AnsibleMapping)
    assert isinstance(new_data[2], AnsibleMapping)


# Generated at 2022-06-23 05:26:29.959451
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test function from_yaml.
    Test ansible/playbooks/raw.yml file content to test the function further.
    '''
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    yaml_data = """
    - hosts: all
      gather_facts: no
      tasks:
        - raw: echo hello
          register: hello_result
        - debug:
            msg: '{{ hello_result.stdout }}'
    """
    ansible_yaml_obj = from_yaml(yaml_data)
    assert isinstance(ansible_yaml_obj, AnsibleSequence)
    assert len(ansible_yaml_obj) == 1
    assert isinstance(ansible_yaml_obj[0], AnsibleMapping)
   

# Generated at 2022-06-23 05:26:39.716965
# Unit test for function from_yaml
def test_from_yaml():
    # Test invalid json
    invalid_json_data = '{"a": "b"'
    try:
        from_yaml(invalid_json_data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError was not raised')

    # Test valid json
    json_data = '{"a": "b"}'
    assert from_yaml(json_data) == {'a': 'b'}

    # Test invalid yaml
    invalid_yaml_data = '{{'
    try:
        from_yaml(invalid_yaml_data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError was not raised')

    # Test valid yaml

# Generated at 2022-06-23 05:26:51.332659
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    _test_data = "ansible_test_data:"
    _test_yaml = b"---\n%s" % to_bytes(_test_data)

    # load the data into a data structure
    new_data = from_yaml(_test_yaml, file_name='<string>')
    assert isinstance(new_data, dict) and new_data == dict(ansible_test_data='')


    # JSON data is also valid YAML data
    _test_json = b'{"%s"}' % to_bytes(_test_data)
    new_data = from_yaml(_test_json, file_name='<string>')

# Generated at 2022-06-23 05:27:00.018682
# Unit test for function from_yaml
def test_from_yaml():
    json_valid_str = "{\"a\":2}"
    json_invalid_str = "{\"a\":2:}"
    yaml_valid_str = "a: 2"
    yaml_invalid_str = "a: 2:"
    json_valid_dict = {u'a':2}
    yaml_valid_dict = {u'a':2}

    assert from_yaml(json_valid_str) == json_valid_dict
    assert from_yaml(yaml_valid_str) == yaml_valid_dict
    assert from_yaml(json_invalid_str) == yaml_invalid_str
    assert from_yaml(yaml_invalid_str) == yaml_invalid_str

    import traceback

# Generated at 2022-06-23 05:27:06.658525
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"key": "value"}'
    res = from_yaml(data)
    assert res == {"key": "value"}
    data2 = '{"key": value}'
    try:
        res = from_yaml(data2)
    except AnsibleParserError as e:
        assert 'JSON' in str(e)
        assert 'YAML' in str(e)

# Generated at 2022-06-23 05:27:17.627000
# Unit test for function from_yaml
def test_from_yaml():
    # Valid YAML
    assert from_yaml('{}') == {}
    assert from_yaml('\nfoo: bar\n') == {'foo': 'bar'}

    # Invalid YAML
    try:
        from_yaml('{')
        assert False, 'Should have thrown exception'
    except AnsibleParserError as e:
        assert 'YAML parser error' in to_native(e)

    # Valid JSON
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('{"foo": "bar"}', json_only=True) == {'foo': 'bar'}

    # Invalid JSON

# Generated at 2022-06-23 05:27:27.269271
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    data = {
        'a': 1,
        'b': [1, 2, 3],
        'c': {
            'd': 2,
            'e': 3
        }
    }

    # test json only
    result = from_yaml(json.dumps(data), file_name='<inline>', vault_secrets=None, json_only=True)

    assert result == data

    # test various inputs

# Generated at 2022-06-23 05:27:37.223187
# Unit test for function from_yaml
def test_from_yaml():
    data = {'key': 'val'}
    assert(from_yaml(json.dumps(data)) == data)
    try:
        from_yaml(json.dumps(data), json_only=True)
    except AnsibleParserError:
        failed=True
    assert(failed)
    assert(from_yaml(json.dumps(data).replace('"key":', '"InvalidKey":')) != data)
    assert(from_yaml('yaml: not yaml') != data)
    try:
        from_yaml('yaml: not yaml')
    except AnsibleParserError:
        failed=True
    assert(failed)

# Generated at 2022-06-23 05:27:43.067539
# Unit test for function from_yaml
def test_from_yaml():
  print(from_yaml('{"foo":"bar"}'))
  print(from_yaml('foo: bar', json_only=False))
  print(from_yaml('foo: bar', json_only=True))

if __name__ == '__main__':
  test_from_yaml()

# Generated at 2022-06-23 05:27:54.278155
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.compat.tests.mock import patch

    mock_data_yaml = '''\
    my_key: my_data
    my_key2: my_data2
    '''

    mock_data_json = '''\
    {"my_key": "my_data",
    "my_key2": "my_data2"}
    '''

    file_name = './test_file.yaml'

    with patch('ansible.parsing.yaml.loader.open', return_value=mock_data_yaml):
        assert from_yaml(file_name) == {'my_key': 'my_data', 'my_key2': 'my_data2'}


# Generated at 2022-06-23 05:27:58.160789
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from_yaml_result = from_yaml('''
        tasks:
          - name: Ansible task
            shell: echo Hello World
        ''')
    assert from_yaml_result["tasks"][0]["name"] == "Ansible task"

# Generated at 2022-06-23 05:28:08.301642
# Unit test for function from_yaml

# Generated at 2022-06-23 05:28:14.845204
# Unit test for function from_yaml
def test_from_yaml():
    # empty string
    yml = ''
    assert from_yaml(yml) == None

    # single scalar
    yml = 'greeting: hello'
    assert from_yaml(yml) == {'greeting': 'hello'}

    # list of scalar
    yml = '- one\n- two\n- three'
    assert from_yaml(yml) == ['one', 'two', 'three']

    # list of objects
    yml = '- name: joe\n  password: 123\n- name: jim\n  password: abc'
    assert from_yaml(yml) == [{'name': 'joe', 'password': '123'}, {'name': 'jim', 'password': 'abc'}]

    # objects

# Generated at 2022-06-23 05:28:23.149571
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 1}") == {"foo": 1}
    assert from_yaml("{'foo': 1}", json_only=True) == {"foo": 1}
    assert from_yaml("{foo: 1}", json_only=True) == {"foo": 1}
    assert from_yaml("{'foo': 1}", json_only=True) == {"foo": 1}
    assert from_yaml("[ 'foo', 'bar' ]") == ["foo", "bar"]
    assert from_yaml("[ 'foo', 'bar' ]", json_only=True) == ["foo", "bar"]

# Generated at 2022-06-23 05:28:33.408794
# Unit test for function from_yaml
def test_from_yaml():
    '''
    >>> from_yaml("foo bar biz")
    u'foo bar biz'
    >>> from_yaml("42\n")
    42
    >>> from_yaml("[1,2,3]")
    [1, 2, 3]
    >>> from_yaml("{a: b}")
    Traceback (most recent call last):
        ...
    ansible.errors.AnsibleParserError: We were unable to read either as JSON nor YAML, these are the errors we got from each:
    JSON: No JSON object could be decoded

    YAML parser error: unexpected end of stream:
    did not find expected key
    in "<unicode string>", line 1, column 6:
        {a: b}
            ^
    '''


# Generated at 2022-06-23 05:28:41.232009
# Unit test for function from_yaml
def test_from_yaml():

    import json

    try:
        from_yaml("""
            {
                "a": "b",
                "c": "d"
            }
        """, json_only=True)
    except AnsibleParserError as e:
        assert(False)

    try:
        from_yaml("""
            {
                "a": "b",
                "c": "d"
            }
        """, json_only=True)
    except AnsibleParserError as e:
        assert(False)

    try:
        from_yaml("""
            {
                "a": "b",
                "c": "d"
            }
        """)
    except AnsibleParserError as e:
        assert(False)


# Generated at 2022-06-23 05:28:52.744808
# Unit test for function from_yaml
def test_from_yaml():
    json_str = '{"msg": "Hello World"}'
    assert from_yaml(json_str, json_only=True) == {"msg": "Hello World"}

    json_str = '{"msg": "Hello World"}}'
    try:
        from_yaml(json_str, json_only=True)
        assert False
    except AnsibleParserError:
        assert True

    from_yaml(json_str, json_only=True, show_content=False)
    assert True

    yaml_str = 'msg: Hello World'
    assert from_yaml(yaml_str) == {"msg": "Hello World"}

    yaml_str = 'msg: Hello World}}'

# Generated at 2022-06-23 05:29:02.907478
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = """
    {
    "resource_group": "test_rg_with_commas, abc",
    "vm_name": "test_vm_with_commas, abc"
    }
    """
    parsed_yaml = from_yaml(yaml_data)
    assert parsed_yaml == {'resource_group': 'test_rg_with_commas, abc', 'vm_name': 'test_vm_with_commas, abc'}

    json_data = json.dumps(yaml_data)

# Generated at 2022-06-23 05:29:04.220589
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml.__doc__ is not None

# Generated at 2022-06-23 05:29:11.665188
# Unit test for function from_yaml
def test_from_yaml():
    def _safe_load(stream, file_name=None):
        ''' Implements yaml.safe_load(), except using our custom loader class. '''

        loader = AnsibleLoader(stream, file_name)
        try:
            return loader.get_single_data()
        finally:
            try:
                loader.dispose()
            except AttributeError:
                pass  # older versions of yaml don't have dispose function, ignore

    data = '{"a": "b"}'
    new_data = from_yaml(data)
    assert new_data.get('a') == "b"

    # try with yaml
    data = '''
---
name : test
location : lab
ip : 192.168.0.1
'''
    new_data = from_yaml(data)
    assert new

# Generated at 2022-06-23 05:29:17.219208
# Unit test for function from_yaml
def test_from_yaml():
    # Check that passing a string of json data works
    json_text = r"""
    {
        'name': value,
        'bool': true,
        'list': [1, 2, 3],
        'object': {'a': 'b'},
        'float': 0.01
    }
    """
    assert from_yaml(json_text, json_only=True) == {'name': 'value', 'bool': True, 'list': [1, 2, 3], 'object': {'a': 'b'}, 'float': 0.01}

    # Check that passing a string of yaml data works
    yaml_text = r"""
    name: value
    bool: true
    list: [1, 2, 3]
    object: {a: b}
    float: 0.01
    """

# Generated at 2022-06-23 05:29:24.765037
# Unit test for function from_yaml
def test_from_yaml():
  import ansible


# Generated at 2022-06-23 05:29:31.287470
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = '''
    ---
    foo:
      - number: 1
        name: test
      - number: 2
        name: test2
    '''
    assert from_yaml(test_yaml) == {'foo': [{'number': 1, 'name': 'test'}, {'number': 2, 'name': 'test2'}]}
    assert from_yaml('{ "foo": "bar" }') == {'foo': 'bar'}

# Generated at 2022-06-23 05:29:35.019262
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    {
        "key1": "value1",
        "key2": "value2"
    }
    """
    result = from_yaml(data)
    assert result['key1'] == 'value1'
    assert result['key2'] == 'value2'

# Generated at 2022-06-23 05:29:40.756205
# Unit test for function from_yaml
def test_from_yaml():
    test_from_yaml_1(None)
    test_from_yaml_2(None)
    test_from_yaml_3(None)
    test_from_yaml_4(None)
    test_from_yaml_5(None)
    test_from_yaml_6(None)
    test_from_yaml_7(None)
    test_from_yaml_8(None)


# Generated at 2022-06-23 05:29:49.369039
# Unit test for function from_yaml
def test_from_yaml():
    from units.mock.loader import DictDataLoader

    test1_data = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }
    test1_json = (
        b'{"key1": "value1", "key2": "value2", "key3": "value3"}'
    )
    test1_yaml = (
        b'key1: value1\n'
        b'key2: value2\n'
        b'key3: value3\n'
    )

    # test JSON input
    result = from_yaml(test1_json)
    assert result == test1_data

    # test YAML input
    result = from_yaml(test1_yaml)

# Generated at 2022-06-23 05:30:01.872851
# Unit test for function from_yaml
def test_from_yaml():
    # FIXME: This is a hack to allow unit testing to work. It should be
    #        removed when the module_utils._text code switch is complete.
    global to_text

    try:
        from ansible.module_utils._text import to_text
    except ImportError:
        from ansible.module_utils.six import text_type as to_text

    body = """
    ---
    - hosts: localhost
      tasks:
      - name: Test1
        debug:
          msg: "{{ test_vars.test_var }}"
    """


# Generated at 2022-06-23 05:30:12.986363
# Unit test for function from_yaml
def test_from_yaml():
    ''' Basic sanity check on function ansible.parsing.yaml.objects.from_yaml() '''

    # In the future, this test will grow in complexity as the function grows in complexity

    # First, verify that a valid YAML string can be processed without error
    yaml_string = """
    ---
    # This is an example YAML string
    this_is_a_string: "This is a string"
    # This is a list of strings
    my_list:
      - "Hello"
      - "World"
      - "!"
    # This is a dictionary of strings
    my_dict:
      hello: "my"
      world: "name"
      is: "Ansible!"
    """
    data = from_yaml(yaml_string)

# Generated at 2022-06-23 05:30:15.332557
# Unit test for function from_yaml
def test_from_yaml():
    """Functionality of from_yaml is tested in parsers/test_yaml.py"""
    pass

# Generated at 2022-06-23 05:30:23.801668
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.ajson import AnsibleJSONDecoder
    import json
    import sys

    test_data = """
    ---
    - name: test
      hosts: localhost
      gather_facts: no
      tasks:
      - name: test
        copy:
          content: '{{var}}'
          dest: /tmp/test.txt
        vars:
           var: "{{ var }}"
    """

    # from_yaml() with JSON only
    try:
        json_data = json.loads(test_data, cls=AnsibleJSONDecoder)
    except Exception as json_exc:
        print("Can't open test_data as JSON: %s" % json_exc)
        sys.exit(1)

# Generated at 2022-06-23 05:30:32.786968
# Unit test for function from_yaml
def test_from_yaml():
    """test_from_yaml: test the from_yaml function

    When the json_only parameter is True and the data is not JSON
    this function should raise an AnsibleParserError.
    """
    from ansible.parsing import from_yaml
    from ansible.errors import AnsibleParserError
    import pytest

    with pytest.raises(AnsibleParserError):
        from_yaml("---\nfoo: bar", json_only=True)

    assert from_yaml("{ \"foo\": \"bar\" }", json_only=True) == {"foo": "bar"}

# Generated at 2022-06-23 05:30:43.477054
# Unit test for function from_yaml
def test_from_yaml():
    d = from_yaml('''
        ---
        - hosts: all
          gather_facts: no
          vars:
            test: "abc"
          tasks:
            - ansible.builtin.debug:
                msg: "hello world"
    ''')

    assert d == [
        {
            'tasks': [
                {
                    'ansible': {
                        'builtin': {
                            'debug': {
                                'msg': 'hello world'
                            }
                        }
                    }
                }
            ],
            'vars': {
                'test': 'abc'
            },
            'gather_facts': 'no',
            'hosts': 'all'
        }
    ]

# Generated at 2022-06-23 05:30:52.375944
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]  # test json compatibility
    assert from_yaml('[1, 2, 3]', json_only=True) == [1, 2, 3]
    assert from_yaml('[1, 2, 3]', json_only=False) == [1, 2, 3]
    assert from_yaml('[1') == [1]  # test json compatibility
    assert from_yaml('[1', json_only=True) == [1]
    assert from_yaml('[1', json_only=False) == [1]
    assert from_yaml('{1: 2}') == {'1': 2}  # test json compatibility

# Generated at 2022-06-23 05:30:58.983568
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == {"foo": "bar"}
    assert from_yaml('foo: bar') == {"foo": "bar"}
    assert from_yaml('foo: "bar"') == {"foo": "bar"}
    assert from_yaml('foo: "bar', json_only=True) is None
    assert from_yaml('foo: "bar') == {"foo": "bar"}

# Generated at 2022-06-23 05:31:11.525478
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'my secret'
    vaulted_secret = AnsibleVaultEncryptedUnicode(secret)

    # TODO: also test with '|' and '>' here

# Generated at 2022-06-23 05:31:20.316183
# Unit test for function from_yaml
def test_from_yaml():
    try:
        data = "['...']: foo"
        yaml_data = _safe_load(data)
        assert False
    except YAMLError:
        assert True

    try:
        data = "['...']: foo"
        yaml_data = from_yaml(data, json_only=True)
        assert False
    except AnsibleParserError:
        assert True

    try:
        data = "['...']: foo"
        yaml_data = from_yaml(data, json_only=False)
        assert False
    except AnsibleParserError:
        assert True

# must have a main in order to be included in the coverage report
if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:31:30.990821
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.utils.plugin_docs import read_docstring
    from ansible.utils.display import Display
    from ansible.utils.vars import isidentifier

    display = Display()
    display.verbosity = 4

    def parse_docstring(docstring, plugin_type, plugin_subdir):
        """Return the parsed data from a docstring, without actually loading the plugin"""
        doc = read_docstring(docstring)
        loader = get_all_plugin_loaders()[plugin_type](subdir=plugin_subdir)
        _prepare_plugin_docs(loader, doc, plugin_type, plugin_subdir)

        return doc


# Generated at 2022-06-23 05:31:40.528133
# Unit test for function from_yaml
def test_from_yaml():
    from yaml.compat import ordereddict
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    import sys

    # ordereddicts are used in tests because the order of keys is important
    # when testing exception output
    data = '''
    - 1
    - { key: value }
    '''

    assert from_yaml(data) == [1, ordereddict(key='value')]

    # test vault secrets
    secrets = ['secrets']
    vault = VaultLib(secrets)
    vault_secrets = vault.secrets