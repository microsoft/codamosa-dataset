

# Generated at 2022-06-23 05:21:45.291913
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "changed": false, "ping": "pong" }') == {"changed": False, "ping": "pong"}
    assert from_yaml('{ "changed": false, "ping": "pong" }\n') == {"changed": False, "ping": "pong"}
    assert from_yaml('{ "changed": false, "ping": "pong" }\n') == {"changed": False, "ping": "pong"}
    assert from_yaml('{ "changed": false, "ping": "pong" }', show_content=False) == {"changed": False, "ping": "pong"}
    assert from_yaml('changed: false\nping: pong') == {"changed": False, "ping": "pong"}

# Generated at 2022-06-23 05:21:51.703889
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a":1}'
    assert from_yaml(data) == {'a': 1}

    # check that json hasn't changed
    data = '{"x":1}'
    assert from_yaml(data) == {'x': 1}

    # check that yaml works
    data = '{ %YAML 1.1\n---\nx: 1}'
    assert from_yaml(data) == {'x': 1}

# Generated at 2022-06-23 05:21:57.297294
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('true') is True
    assert from_yaml('{ "a": "foo" }') == {"a": "foo"}
    assert from_yaml('a: foo') == {"a": "foo"}

    # Python 2.6 has this yaml bug where "yes" is True, we are testing that it is false for us
    if str is bytes:
        assert from_yaml('yes') == "yes"

# Generated at 2022-06-23 05:22:08.507560
# Unit test for function from_yaml
def test_from_yaml():
    """
    This unit test will make sure that our from_yaml behaves the same way as yaml.safe_load
    This test will also help us avoid regression in the future, if something changes in the
    code. It tests both the json_only and yaml_only cases.
    """

    import yaml
    from_yaml_data = from_yaml('{"a": "simple", "json": true, "map": {"foo": "bar"}}')

    yaml_data = yaml.safe_load('{"a": "simple", "json": true, "map": {"foo": "bar"}}')

    assert from_yaml_data == yaml_data


# Generated at 2022-06-23 05:22:19.385033
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import random
    

# Generated at 2022-06-23 05:22:30.636754
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.utils.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    from_yaml('true') == True
    from_yaml('"a"') == 'a'
    from_yaml("'a'") == 'a'
    from_yaml("1") == 1


# Generated at 2022-06-23 05:22:33.086337
# Unit test for function from_yaml
def test_from_yaml():
    data = "['data']"
    assert from_yaml(data, json_only=True) == ["data"]

# Generated at 2022-06-23 05:22:40.718842
# Unit test for function from_yaml
def test_from_yaml():
    # Test bad JSON input
    try:
        from_yaml('{}bad_json_input')
    except AnsibleParserError as e:
        assert 'json' in to_native(e)

    # Test bad YAML input
    try:
        from_yaml('{}bad_yaml_input')
    except AnsibleParserError as e:
        assert 'yaml' in to_native(e)

    # Test JSON input
    assert from_yaml('{"key1": "value1", "key2": "value2"}') == {"key1": "value1", "key2": "value2"}

    # Test YAML input
    assert from_yaml('key1: value1\nkey2: value2') == {"key1": "value1", "key2": "value2"}

# Unit

# Generated at 2022-06-23 05:22:46.212719
# Unit test for function from_yaml
def test_from_yaml():
  data = '{"foo":"bar"}'
  new_data = from_yaml(data)
  data = '{"foo":"bar"}\n'
  new_data = from_yaml(data)
  data = "{'foo':'bar'}"
  try:
    new_data = from_yaml(data)
  except Exception:
    return True
  return False

# Generated at 2022-06-23 05:22:56.675709
# Unit test for function from_yaml

# Generated at 2022-06-23 05:23:00.852290
# Unit test for function from_yaml
def test_from_yaml():
    yaml = '''
    ---
    - name: test1
      foo: bar
    ...
    '''

    data = from_yaml(yaml)
    assert data[0]['name'] == 'test1'

    yaml = '''
    ---
    - hosts: test1
      foo: bar
    ...
    '''

    data = from_yaml(yaml)
    assert data[0]['hosts'] == 'test1'

# Generated at 2022-06-23 05:23:12.144740
# Unit test for function from_yaml
def test_from_yaml():
    import json
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins  # python3

    test_set = {
        "a": {
            "b": "c",
            "d": "e {{ x }} f"
        },
        "p": [1, 2, 3],
        "q": "{{ y }}",
        "x": "g",
        "y": "h"
    }

    test_input = json.dumps(test_set, cls=AnsibleJSONEncoder)

    # test that we can read JSON input and get the same result back
   

# Generated at 2022-06-23 05:23:19.954758
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"testkey\": \"testvalue\"}") == {"testkey": "testvalue"}
    assert from_yaml("{\"testkey\": \"testvalue\"}", json_only=True) == {"testkey": "testvalue"}
    # Test quotes
    assert from_yaml("{\"testkey\": 'testvalue'}", json_only=True) == {"testkey": "testvalue"}
    assert from_yaml("{\"testkey\": \"testvalue\"}") == {"testkey": "testvalue"}
    # Test newlines
    assert from_yaml("{\n\"testkey\": \"testvalue\"\n}") == {"testkey": "testvalue"}

# Generated at 2022-06-23 05:23:21.403966
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{'a': 'b'}")

# Generated at 2022-06-23 05:23:30.906582
# Unit test for function from_yaml
def test_from_yaml():
    # Test for json
    json_content = '{"list": ["item1", "item2", "item3"], "boolean": true, "null": null, "int": 1}'
    json_decoded = from_yaml(json_content, json_only=True)
    assert json_decoded == {'boolean': True, 'int': 1, 'list': ['item1', 'item2', 'item3'], 'null': None}

    # Test for yaml
    yaml_content = '''
    list:
    - item1
    - item2
    - item3
    boolean: True
    null: null
    int: 1
    '''
    yaml_decoded = from_yaml(yaml_content, json_only=True)

# Generated at 2022-06-23 05:23:42.379693
# Unit test for function from_yaml
def test_from_yaml():
    assert AnsibleJSONDecoder.secrets is None
    assert not hasattr(AnsibleJSONDecoder, 'secrets')

    assert from_yaml('') == None
    assert from_yaml('{}') == {}
    assert from_yaml('{"key1": "value1"}') == {'key1': 'value1'}
    assert from_yaml('["content1"]') == ['content1']
    assert from_yaml('[{"key1": "value1"}]') == [{'key1': 'value1'}]

    try:
        from_yaml('[', json_only=True)
    except AnsibleParserError:
        pass
    except Exception as err:
        raise AssertionError('Unexpected exception "%s"' % err)

# Generated at 2022-06-23 05:23:50.428736
# Unit test for function from_yaml
def test_from_yaml():
    # case: yaml
    yaml = """
        a: 1
        b: 2
    """
    parsed = from_yaml(yaml)
    assert parsed['a'] == 1
    assert parsed['b'] == 2

    # case: json
    json_input = """
        {
            "a": 1,
            "b": 2
        }
    """
    parsed = from_yaml(json_input)
    assert parsed['a'] == 1
    assert parsed['b'] == 2

# Generated at 2022-06-23 05:23:56.591894
# Unit test for function from_yaml
def test_from_yaml():
    # test loading of YAML file
    example_yaml = '''
    ---
    this is a yaml file
    '''
    assert from_yaml(example_yaml) == 'this is a yaml file'

    # test loading of YAML file with encoding
    example_yaml = '''
    ---
    - spam
    - eggs
    '''
    assert from_yaml(example_yaml) == ['spam', 'eggs']

    # test loading of YAML file with invalid syntax
    example_yaml = '''
    ---
    spam
    '''
    try:
        from_yaml(example_yaml)
        assert False
    except AnsibleParserError as e:
        assert 'YAML' in e.message
        assert 'is not a valid YAML'

# Generated at 2022-06-23 05:24:08.706908
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(
        '''
            - hosts:
                - localhost
              connection: local
              gather_facts: False
              tasks:
                - debug:
                    msg: "Hello world!"
        '''
    )['tasks'] == [{'debug': {'msg': 'Hello world!'}}]

    assert from_yaml(
        '''
            - hosts:
                - localhost
              connection: local
              gather_facts: False
              tasks:
                - debug:
                    msg: Hello world!
        '''
    )['tasks'] == [{'debug': {'msg': 'Hello world!'}}]


# Generated at 2022-06-23 05:24:15.397963
# Unit test for function from_yaml
def test_from_yaml():
    json_string = '{"some_key": "some_value"}'
    yaml_string = '''some_key: some_value'''
    yaml_string_multi = '''some_key:
                              some_value'''

    assert from_yaml(json_string) == {'some_key': 'some_value'}
    assert from_yaml(yaml_string) == {'some_key': 'some_value'}
    assert from_yaml(yaml_string) == from_yaml(yaml_string_multi)



# Generated at 2022-06-23 05:24:22.765643
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test the three different ways to create an AnsibleUnicode object.
    assert isinstance(
        from_yaml(u'\u041b'),
        AnsibleUnicode)
    assert isinstance(
        from_yaml(u'\u043b', json_only=True),
        AnsibleUnicode)
    assert isinstance(
        from_yaml(u'{"\u043b":""}'),
        AnsibleUnicode)

# Generated at 2022-06-23 05:24:32.567600
# Unit test for function from_yaml
def test_from_yaml():
    # Should be a dictionary
    assert isinstance(from_yaml("{\"hosts\":\"all\", \"remote_user\":\"root\"}"), dict)
    # Should be a list
    assert isinstance(from_yaml("[1, 2, 3]"), list)
    # Should be an integer
    assert isinstance(from_yaml("12345"), int)
    # Should be a boolean
    assert isinstance(from_yaml("true"), bool)
    # Should be a string
    assert isinstance(from_yaml("\"hello\""), str)

if __name__ == "__main__":
    # Execute the unit tests in this file
    import pytest
    import sys
    import os

# Generated at 2022-06-23 05:24:43.307478
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}")[0]['a'] == 'b'

    try:
        from_yaml("foo bar: baz", json_only=True)
        assert False
    except AnsibleParserError as e:
        assert isinstance(e.orig_exc, ValueError)

    assert from_yaml("foo bar: baz")['foo bar'] == 'baz'

    assert from_yaml("{ 'a': 'b' }")['a'] == 'b'

    assert from_yaml("foo: {{ bar }}")['foo'] == "{{ bar }}"

    assert from_yaml("[{ 'a': 'b' }]")[0]['a'] == 'b'
    assert from_yaml("- 1 - 2") == [1, 2]


# Generated at 2022-06-23 05:24:54.599357
# Unit test for function from_yaml
def test_from_yaml():
    # test parsing of roles
    yaml = '''
- role:
    name: webtrees
    tasks_from: install
  when: ansible_os_family == 'RedHat' and ansible_distribution_version | version_compare('6.0', '<')
'''
    result = from_yaml(yaml, file_name='<string>', show_content=False)
    assert result[0]['role']['name'] == 'webtrees'
    assert result[0]['role']['tasks_from'] == 'install'
    assert result[0]['when'] == ("ansible_os_family == 'RedHat' and ansible_distribution_version | version_compare('6.0', '<')")

    # test parsing of list of dictionaries

# Generated at 2022-06-23 05:25:10.308666
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert from_yaml('{"a": 1, "b": 2}', json_only=True) == {'a': 1, 'b': 2}

    assert from_yaml('a: 1\nb: 2\n') == {'a': 1, 'b': 2}
    assert from_yaml('a: 1\nb: 2\n', json_only=True) == {'a': 1, 'b': 2}

    assert from_yaml('') == None

    try:
        from_yaml('')
    except AnsibleParserError:
        assert False  # there should be no ParserError when called with an empty string

    assert from_yaml('{') == None

   

# Generated at 2022-06-23 05:25:20.492626
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1 }') == {"a": 1}
    assert from_yaml('- 1') == [1]
    assert from_yaml('  # test comment\n- 1') == [1]
    assert from_yaml('  # test comment\n  - 1') == [1]
    assert from_yaml(
        '''
        - 1
        # test comment
        - 2
        ''') == [1, 2]
    assert from_yaml(
        '''
        # test comment
        - 1
        # test comment
        - 2
        ''') == [1, 2]
    assert from_yaml(
        '''
        # test comment
        - 1

        # test comment
        - 2
        ''') == [1, 2]

# Generated at 2022-06-23 05:25:22.127238
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{"a": "b"}')

# Generated at 2022-06-23 05:25:30.545108
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        ("test", True),
        ("{test}", True),
        ("{'test': 'test'}", True),
        ("{'test': 'test'", True),
        ("test:\n  - test", True)
    ]

    for test_case in test_cases:
        try:
            from_yaml(test_case[0])
        except AnsibleParserError as e:
             assert str(e) == test_case[1], ("{} expected to have error message {}").format(test_case[0], test_case[1])

# Generated at 2022-06-23 05:25:42.846075
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import sys


# Generated at 2022-06-23 05:25:50.153461
# Unit test for function from_yaml
def test_from_yaml():
    ''' ansible.utils.from_yaml unit test'''
    import io
    from ansible.plugins.loader import vault_secrets_from_file

    # test data
    TEST_DATA = "a: 1\n"

    # Test for successful yaml parse
    new_data = from_yaml(TEST_DATA, '<none>', True, [None, None, None])
    assert new_data is not None
    assert new_data['a'] == 1

    # Test an invalid yaml document
    TEST_DATA = "a: 1\n  x: 2"
    try:
        new_data = from_yaml(TEST_DATA, '<none>', True, [None, None, None])
        assert False
    except AnsibleParserError:
        pass

    # Test a vault document
   

# Generated at 2022-06-23 05:25:52.303836
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"hello": "world"}') == {"hello": "world"}

# Generated at 2022-06-23 05:26:00.071196
# Unit test for function from_yaml
def test_from_yaml():
    for input_data in ["{}", "foo", '{"foo": "bar"}', '{"foo": [1, 2, 3]}', '{"foo": ["bar", "baz"]}']:
        yaml_data = from_yaml(input_data, file_name="<string>", show_content=True, json_only=False)
        assert yaml_data is not None, 'Failed to decode {}'.format(input_data)

# vim: set ffs=unix expandtab ts=4 sw=4 :

# Generated at 2022-06-23 05:26:11.235697
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    sample = """
    - a
    - b
    - c
    """
    assert from_yaml(sample) == ['a', 'b', 'c']

    sample = u"""
    - a
    - b
    - c
    """
    assert from_yaml(sample) == ['a', 'b', 'c']

    sample = """
    - a
    - b
    - c
    """
    assert from_yaml(sample, json_only=True) is None


# Generated at 2022-06-23 05:26:17.340492
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    data = '{"a": "b"}'
    new_data = from_yaml(data, json_only=True)
    assert(new_data['a'] == 'b')
    data = '---{a: b}'
    new_data = from_yaml(data)
    assert(new_data['a'] == 'b')

# Generated at 2022-06-23 05:26:26.114274
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Tests that from_yaml() works as expected.
    '''


# Generated at 2022-06-23 05:26:35.783894
# Unit test for function from_yaml
def test_from_yaml():

    # Uses yaml as input
    json_only = False
    data = '''
    key1:
      - key2: 1
    '''
    new_data = from_yaml(data, json_only=json_only)
    assert isinstance(new_data, dict)
    assert isinstance(new_data['key1'], list)
    assert isinstance(new_data['key1'][0], dict)
    assert isinstance(new_data['key1'][0]['key2'], int)

    # Uses json as input
    json_only = False
    data = '''
    {"key1": [{"key2": 1}]}
    '''
    new_data = from_yaml(data, json_only=json_only)
    assert isinstance(new_data, dict)
   

# Generated at 2022-06-23 05:26:46.801071
# Unit test for function from_yaml
def test_from_yaml():

    # simple yaml/json test
    assert from_yaml("{'a': 1, 'b':2}") == {u'a': 1, u'b': 2}
    assert from_yaml("['a', 'b']") == [u'a', u'b']
    assert from_yaml("- a\n- b") == [u'a', u'b']
    assert from_yaml("a: 1") == {u'a': 1}
    assert from_yaml("a: !!str 1") == {u'a': u'1'}
    assert from_yaml("a: !!str 10") == {u'a': u'10'}
    assert from_yaml("a: !!str 0.123") == {u'a': u'0.123'}

# Generated at 2022-06-23 05:26:51.319696
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "a": "b", "c": "d" }'
    new_data = from_yaml(data)
    assert new_data == {u'c': u'd', u'a': u'b'}

# Generated at 2022-06-23 05:27:01.530719
# Unit test for function from_yaml
def test_from_yaml():
  """from_yaml"""
  # Test: simple YAML
  data = """
  - name: "Foo"
    state: "present"
    value: "bar"
  """
  result = from_yaml(data, file_name="foo.yml", show_content=False)
  assert result == [{'state': 'present', 'name': 'Foo', 'value': 'bar'}]

  # Test: simple JSON
  data = """
  [
    { "name": "Foo", "state": "present", "value": "bar" }
  ]
  """
  result = from_yaml(data, file_name="foo.json", show_content=False)
  assert result == [{'state': 'present', 'name': 'Foo', 'value': 'bar'}]



# Generated at 2022-06-23 05:27:13.162349
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"result":1}') == {'result': 1}
    assert from_yaml('{"result":1}', json_only=True) == {'result': 1}
    assert from_yaml('{"result":1}', json_only=False) == {'result': 1}
    assert from_yaml(json.dumps({'result': 1})) == {'result': 1}
    assert from_yaml(json.dumps({'result': 1}), json_only=True) == {'result': 1}
    assert from_yaml(json.dumps({'result': 1}), json_only=False) == {'result': 1}
    assert from_yaml('result: 1') == {'result': 1}

# Generated at 2022-06-23 05:27:22.523225
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    import os
    import sys

    # load_file() is used to prevent constructor from assigning instance attributes.
    # AnsibleParserError.__init__() will assign __dict__ attribute to self and
    # AnsibleJSONDecoder.default() will serialize it by accident.
    import ansible.errors

    ansible_parsing_dir = os.path.join(os.path.dirname(__file__), os.path.pardir)

    def load_file(file):
        with open(file, 'rb') as f:
            return f.read()


# Generated at 2022-06-23 05:27:30.502785
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml('[]', json_only=True) == []
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('"foo"', json_only=True) == "foo"
    assert from_yaml('null', json_only=True) is None
    # Make sure case matters
    try:
        assert from_yaml('Null', json_only=True)
        assert False, 'Should have failed'
    except AnsibleParserError:
        pass
    assert from_yaml('true', json_only=True) == True
    assert from_yaml('false', json_only=True) == False
    assert from_yaml('0', json_only=True) == 0
    assert from_yaml('0.0', json_only=True) == 0.

# Generated at 2022-06-23 05:27:33.601410
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("") == None
    assert from_yaml("{\"key\": \"value\"}") == {"key": "value"}
    assert from_yaml("key: value") == {"key": "value"}

# Generated at 2022-06-23 05:27:40.524918
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a':'b'}", '<test>') == {'a': 'b'}
    try:
        from_yaml("{'a':'b'}", '<test>', False, False)
    except AnsibleParserError as e:
        assert e.obj.ansible_pos[0] == '<test>'
        assert e.obj.ansible_pos[1] == 1
        assert e.obj.ansible_pos[2] == 1
    else:
        assert False, "Function should raise an exception."

# Generated at 2022-06-23 05:27:49.102966
# Unit test for function from_yaml
def test_from_yaml():
    # Test JSON
    assert from_yaml('{"a": 1}') == {"a": 1}
    # Test invalid JSON
    try:
        from_yaml('{"a": 2')
        assert False
    except AnsibleParserError as e:
        assert str(e).startswith('We were unable to read either as JSON nor YAML, these are the errors we got from each')
        assert str(e).endswith('\'{"a": 2\'')
    # Test YAML
    assert from_yaml('a: 1') == {"a": 1}
    # Test invalid YAML

# Generated at 2022-06-23 05:27:58.848464
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Function that tests the above function.
    '''
    assert from_yaml("{}") == {}
    assert from_yaml("{}{}") == {}
    assert from_yaml("{}{}", show_content=False) == {}
    assert from_yaml('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert from_yaml("{\"a\": \"b\", \"c\": \"d\"}") == {"a": "b", "c": "d"}

    assert from_yaml("{}{}{}{}{}{}") == {}
    assert from_yaml("{}{}{}{}{}{}", show_content=False) == {}
    assert from_yaml("{\"a\": \"b\"}{\"c\": \"d\"}")

# Generated at 2022-06-23 05:28:02.577848
# Unit test for function from_yaml
def test_from_yaml():

    from_yaml("""
    - tasks:
      - debug:
          msg: 'This is a JSON string with yaml syntax so it will throw a yaml exception'
    - debug:
       msg: 'This is a JSON string'

    """)
    print('Test was successful!')

# Generated at 2022-06-23 05:28:12.664791
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
    ---
    sequence:
    - 1
    - 2
    """) == {'sequence': [1, 2]}

    assert from_yaml("""
    ---
    - key: value
    """) == [{'key': 'value'}]

    # Test using the function directly, instead of built-in module
    import ansible.parsing.yaml.loader
    assert ansible.parsing.yaml.loader.from_yaml("""
    ---
    sequence:
    - 1
    - 2
    """) == {'sequence': [1, 2]}

    assert ansible.parsing.yaml.loader.from_yaml("""
    ---
    - key: value
    """) == [{'key': 'value'}]

# Generated at 2022-06-23 05:28:18.285352
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    new_data = from_yaml('{"foo": "bar"}')
    assert new_data == {"foo": "bar"}, "Could not parse json string that was passed to from_yaml"
    new_data = from_yaml('foo: bar')
    assert new_data == {"foo": "bar"}, "Could not parse yaml string that was passed to from_yaml"

# Generated at 2022-06-23 05:28:27.982209
# Unit test for function from_yaml
def test_from_yaml():
    orig_data = {'a': 'b', 'c': ['3', 4], 'd': {'1': '2'}, 'e': True, 'f': False, 'g': None}
    data = {}
    data.update(orig_data)
    json_data = json.dumps(data)
    assert from_yaml(json_data, json_only=True) == data
    assert from_yaml(json_data) == data
    yaml_data = 'a: b\nc:\n- 3\n- 4\nd:\n  1: 2\ne: true\nf: false\ng: null\n'
    assert from_yaml(yaml_data) == data


# Generated at 2022-06-23 05:28:39.689600
# Unit test for function from_yaml
def test_from_yaml():

    import json
    from ansible.parsing.vault import VaultLib

    test_yaml = """
---
"banana"
---
baz:
  - 1
  - 2
foo: 42
bar: "best"
...
"""

    test_json = json.dumps({"banana": None, "foo": 42, "baz": [1, 2], "bar": "best"})

    vault_secrets = dict(vault_password='test')
    vault_lib = VaultLib(vault_secrets)

    print("python-yaml version: %s" % AnsibleLoader.version)
    print("python-yaml version: %s" % AnsibleBaseYAMLObject.version)

    # Try parsing YAML as YAML

# Generated at 2022-06-23 05:28:45.420912
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("- foo") == ["foo"]
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    try:
        from_yaml('{"foo": "bar"')
        assert False, 'Should have failed to parse'
    except AnsibleParserError as e:
        assert 'foo' in str(e)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:28:51.727399
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    assert isinstance(from_yaml(loader, "---"), dict)
    assert isinstance(from_yaml(loader, "---\n"), dict)
    assert isinstance(from_yaml(loader, "--- {}\n"), dict)
    assert isinstance(from_yaml(loader, "---\n{}"), dict)
    assert isinstance(from_yaml(loader, "--- {}"), dict)

# Generated at 2022-06-23 05:29:01.495408
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test method used to test "from_yaml" function
    :return:
    """

    print("==========================================================")
    print("Testing function from_yaml")
    print("==========================================================")

    # Test 1: Test the method with a valid JSON file
    print("********** Test 1 **********")
    file = open("/Users/tony.bihari/Desktop/Ansible/tests/test.json", "r")
    if file.mode == 'r':
        contents = file.read()
        result = from_yaml(data=contents)
        print("Result: ", result)


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:29:07.097574
# Unit test for function from_yaml
def test_from_yaml():
    good_yaml = '''Hello:
 world'''

    bad_yaml = '''Hello
 world'''

    assert from_yaml(good_yaml) == {'Hello': 'world'}

    try:
        from_yaml(bad_yaml)
        assert False == 'from_yaml() did not raise an AnsibleParserError exception, like it should have.'
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:29:17.754140
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1,2,3]') == [1, 2, 3]
    assert from_yaml('{ "a" : 1 }') == {'a': 1}
    assert from_yaml('{a: 1}', json_only=True) == {'a': 1}
    assert from_yaml('[1,2,3') == [1, 2, 3]
    assert from_yaml('[1,2,3', json_only=True) == None
    assert from_yaml('---\n[1,\n2,3\n]') == [1, 2, 3]
    assert from_yaml('#comment\n[1,\n2,3\n]') == [1, 2, 3]

# Generated at 2022-06-23 05:29:27.365099
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.utils.unsafe_proxy import UnsafeText

    data = '{"a": "b"}'
    result = from_yaml(data)
    assert result == {"a": "b"}
    assert isinstance(result, dict)
    assert not isinstance(result, UnsafeText)

    data = 'a: b'
    result = from_yaml(data)
    assert result == {"a": "b"}
    assert isinstance(result, dict)
    assert not isinstance(result, UnsafeText)

    with pytest.raises(AnsibleParserError):
        result = from_yaml('a: b', json_only=True)

# Generated at 2022-06-23 05:29:36.920339
# Unit test for function from_yaml
def test_from_yaml():
    import pytest


# Generated at 2022-06-23 05:29:40.234565
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{'key': 'value'}") # json
    from_yaml("key: 'value'")     # yaml

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:29:48.904233
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for from_yaml '''

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # invalid json
    test_data = '{"test": "value"\n}'
    try:
        result = from_yaml(test_data)
    except AnsibleParserError:
        pass
    else:
        assert(False)  # should fail

    # invalid yaml
    test_data = '---\ntest: value\n:\n'
    try:
        result = from_yaml(test_data)
    except AnsibleParserError:
        pass
    else:
        assert(False)  # should fail

    # valid yaml
    test_data = '---\ntest: value\n\n'

# Generated at 2022-06-23 05:29:59.401342
# Unit test for function from_yaml
def test_from_yaml():
    # Create a valid yaml object to test with
    data = '''
    id: 1
    name: God
    email: god@heaven.af
    '''
    # Call from_yaml with the data
    deserialized_data = from_yaml(data)
    # Test the data
    # Should return a dictionary with the id: 1, name: God and email: god@heaven.af
    assert deserialized_data == {u'id': 1, u'name': u'God', u'email': u'god@heaven.af'}

test_from_yaml()

# Generated at 2022-06-23 05:30:03.748914
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{\n  "key1": "value1",\n  "key2": "value2"\n}\n') == {"key1": "value1", "key2": "value2"}

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:30:11.854077
# Unit test for function from_yaml
def test_from_yaml():
    test_data_yaml = """
        key1: value1
        key2:
            key3: value2
        key4:
            - key5: value3
            - key3: value4
    """
    results = from_yaml(test_data_yaml)
    assert results['key1'] == 'value1'
    assert results['key2']['key3'] == 'value2'
    assert results['key4'][0]['key5'] == 'value3'
    assert results['key4'][1]['key3'] == 'value4'

# Generated at 2022-06-23 05:30:22.034689
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert from_yaml("test") == "test"
    assert from_yaml("1") == 1
    assert from_yaml("123.4") == 123.4
    assert from_yaml("yes") is True
    assert from_yaml("True") is True
    assert from_yaml("True") is True
    assert from_yaml("no") is False
    assert from_yaml("false") is False
    assert from_yaml("False") is False
    assert from_yaml("['a', 'b', 'c']") == ['a', 'b', 'c']

# Generated at 2022-06-23 05:30:31.625011
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    for _, e in ansible_yaml_mapping_tab.items():
        try:
            data = from_yaml(e)
        except Exception as e:
            data = e
        o = ""
        if isinstance(data, AnsibleMapping):
            o = data.to_json()
        elif isinstance(data, AnsibleUnicode):
            o = str(data)
        print("%30s => %s" % (e.split('\n')[0], o))


# Generated at 2022-06-23 05:30:43.194693
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    filename = 'test_from_yaml.yml'

    # Loads should succeed
    data1 = from_yaml("{'foo': 'bar'}", json_only=True)
    assert data1 == {'foo': 'bar'}

    data2 = from_yaml("---\nfoo: bar", file_name=filename)
    assert isinstance(data2, AnsibleMapping)
    assert data2['foo'] == 'bar'

    # Loads should fail
    try:
        from_yaml("{foo: 'bar'}", json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, 'AnsibleParserError not raised'


# Generated at 2022-06-23 05:30:46.837059
# Unit test for function from_yaml
def test_from_yaml():
    string = '''
    {
        "foo": {
            "bar": "baz"
        }
    }
    '''
    assert from_yaml(string) == { "foo": { "bar": "baz" } }


# Generated at 2022-06-23 05:30:52.182253
# Unit test for function from_yaml
def test_from_yaml():
    data1 = '- key: value'
    data2 = '{"key": "value"}'
    data3 = '{key: value'

    assert from_yaml(data1) == [{'key': "value"}]
    assert from_yaml(data2) == [{'key': "value"}]

    try:
        from_yaml(data3)
        assert False, "should have failed"
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:30:59.709674
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    test_data = """
a:
  b:
    c: 20
  """
    try:
        res = from_yaml(test_data)
    except AnsibleParserError as e:
        err_msg = 'Exception: %s' % to_native(e)
        assert False, err_msg
    assert type(res) == AnsibleMapping, 'Value %s is not of AnsibleMapping type' % res

# Generated at 2022-06-23 05:31:03.918985
# Unit test for function from_yaml
def test_from_yaml():
    data = "['a', 'b']"
    new_data = from_yaml(data)
    assert type(new_data) == list

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:31:14.892478
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Check if we can parse both YAML and JSON strings
    '''
    data = {
        'a': 'some string',
        'b': 42,
        'c': True,
        'd': None,
        'e': 3.14,
        'f': {
            'foo': 'bar'
        },
        'g': [
            'foo', 'bar'
        ]
    }

    json_string = json.dumps(data)
    yaml_string = """
        a: some string
        b: 42
        c: yes
        d: null
        e: 3.14
        f:
            foo: bar
        g:
            - foo
            - bar
    """

    # parse as JSON

# Generated at 2022-06-23 05:31:21.356085
# Unit test for function from_yaml
def test_from_yaml():

    # test for unicode
    data = u'{"name": "\xab"}\n'
    assert from_yaml(data) == {u'name': u'\xab'}

    # test for binary data
    data = b'{"name": "\xc3\xab"}\n'
    assert from_yaml(data) == {u'name': u'\xeb'}

# Generated at 2022-06-23 05:31:24.312328
# Unit test for function from_yaml
def test_from_yaml():
  assert from_yaml("[a, b, c]", vault_secrets=None) == ['a', 'b', 'c']

# Generated at 2022-06-23 05:31:36.403980
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    { "test":
        { "test_list": [1, 2, 3],
          "test_str": "I am a string" } }
    """

    # Test no error parsing json
    new_data = from_yaml(data)
    assert new_data['test']['test_str'] == "I am a string"
    assert new_data['test']['test_list'][1] == 2

    # Test error parsing json
    data = """
    { "test":
        { "test_list": [1, 2, 3],
          "test_str": "I am a string"
    """
    new_data = from_yaml(data)
    assert new_data['test']['test_str'] == "I am a string"