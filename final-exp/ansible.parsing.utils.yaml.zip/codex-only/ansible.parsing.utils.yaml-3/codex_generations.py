

# Generated at 2022-06-23 05:21:45.547523
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import unittest
    import ansible
    from ansible.module_utils.six import PY2

    if PY2:
        from StringIO import StringIO
    else:
        from io import StringIO

    # The test foo.yml is a string and then a list of strings.  We must decode
    # the bytes read from disk to a string to test against this file
    with open(os.path.join(ansible.__path__[0], 'lib', 'ansible', 'parsing', 'dataloader', 'tests', 'test_data', 'foo.yml'), 'rb') as fp:
        data = fp.read()

    if PY2:
        data = data.decode('utf-8')


# Generated at 2022-06-23 05:21:54.309493
# Unit test for function from_yaml
def test_from_yaml():
    # Simple string and list
    assert from_yaml("a: b") == {"a": "b"}
    assert from_yaml("[foo, bar]") == ["foo", "bar"]

    # Valid json should be parsed as such
    assert from_yaml("{\"foo\": \"bar\"}") == {'foo': 'bar'}

    # Invalid yaml should raise and AnsibleParserError
    from ansible.errors import AnsibleParserError
    try:
        from_yaml("[foo, bar}")
        assert False, "invalid yaml did not raise AnsibleParserError"
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:21:55.064405
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-23 05:22:04.613579
# Unit test for function from_yaml
def test_from_yaml():
    from ansible._vault import VaultLib
    data = """
        ---
        name: test
        value: test
        """
    assert from_yaml(data) == {'name': 'test', 'value': 'test'}

# Generated at 2022-06-23 05:22:13.940006
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1 }') == { 'a': 1 }
    assert from_yaml('{ a: 1 }') == { 'a': 1 }
    assert from_yaml('{ "a": 1 }') == from_yaml('{ "a": 1 }', json_only=True)
    assert from_yaml('{ "a": 1 }') == from_yaml('{ "a": 1 }', json_only=False)

# Generated at 2022-06-23 05:22:18.254656
# Unit test for function from_yaml
def test_from_yaml():
    data = "{foo: bar}"
    try:
        from_yaml(data)
    except AnsibleParserError as err:
        assert err.obj and err.obj.ansible_pos == ('<string>', 1, 1)
    else:
        assert False, 'Expected AnsibleParserError of type AnsibleParserError'


# Generated at 2022-06-23 05:22:29.804898
# Unit test for function from_yaml
def test_from_yaml():

    data_yaml = '''
    eckd_extents:
    - sectors: 61440
      tracks: 2
      cylinders: 3
      primary_space: 3
      secondary_space: 3 '''

    data_json = '''{
    "eckd_extents": [
      {
        "cylinders": 3,
        "primary_space": 3,
        "sectors": 61440,
        "secondary_space": 3,
        "tracks": 2
      }
    ]
  }'''

    data_yaml_json = '''
    eckd_extents:
    - sectors: 61440
      tracks: 2
      cylinders: 3
      primary_space: 3
      secondary_space: 3 '''


# Generated at 2022-06-23 05:22:41.311731
# Unit test for function from_yaml
def test_from_yaml():
    # python2.6/2.7 dict ordering is arbitrary, resulting in different structures, so skip these tests
    import sys
    if sys.version_info[:2] < (2, 7):
        return

# Generated at 2022-06-23 05:22:51.843384
# Unit test for function from_yaml
def test_from_yaml():
    string_yaml = '''
    ---
    - hosts: localhost
      vars:
        var1: foo
        var2:
          - a
          - b
      tasks:
      - name: Display Vars
        debug: var=var1
    ...
    '''
    data = from_yaml(string_yaml)
    assert data['hosts'] == 'localhost'
    assert data['vars']['var1'] == 'foo'
    assert data['vars']['var2'][0] == 'a'
    assert data['vars']['var2'][1] == 'b'
    assert data['tasks'][0]['name'] == 'Display Vars'
    assert data['tasks'][0]['debug']['var'] == 'var1'

# Generated at 2022-06-23 05:23:00.601159
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test parsing a valid YAML string
    '''
    test_yaml = """
    meta:
      hostvars:
        localhost:
          foo: bar
          bam: baz
        all:
          bar: foo
          baz: bam
    tasks:
      - ping:
    """
    test_data = from_yaml(test_yaml)
    assert test_data == {'meta': {'hostvars': {'all': {'baz': 'bam', 'bar': 'foo'}, 'localhost': {'foo': 'bar', 'bam': 'baz'}}}, 'tasks': [{'ping': None}]}

    '''
    Test parsing an invalid yaml string
    '''

# Generated at 2022-06-23 05:23:11.934608
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This function test function from_yaml in lib/ansible/parsing/yaml/__init__.py
    '''
    from ansible.parsing.yaml import from_yaml
    from ansible.module_utils._text import to_text

    test_vault_secret = [{u'a': u'a'}]
    test_string = '''
    ---
    name: test
    ...
    '''
    data = from_yaml(to_text(test_string, errors='surrogate_or_strict'))
    assert data == {'name': 'test'}

    data = from_yaml(to_text(test_string, errors='surrogate_or_strict'), vault_secrets=test_vault_secret)

# Generated at 2022-06-23 05:23:16.012362
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml('{"valid": "json", "key": "value"}'))
    print(from_yaml('valid: yaml'))


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:23:26.381790
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test from_yaml function
    '''
    '''
    Test for json_only option
    '''
    test_json_string = '{"hostname": "host1", "ipaddress": "10.0.0.1"}'
    assert from_yaml(test_json_string, json_only=True) == {u"hostname": u"host1", u"ipaddress": u"10.0.0.1"}

    test_yaml_string = '---\nhostname: host1\nipaddress: 10.0.0.1\n'
    try:
        from_yaml(test_yaml_string, json_only=True)
        raise Exception('Expected AnsibleParserError')
    except AnsibleParserError as e:
        pass


# Generated at 2022-06-23 05:23:31.689735
# Unit test for function from_yaml
def test_from_yaml():
    example = """
    # this is an example
    1
    """
    assert(from_yaml(example) == 1)
    assert(from_yaml(example, json_only=True) == None)

# Generated at 2022-06-23 05:23:42.758995
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    vault_password = '$1$VTZysBnx$bYFcQ2XSUrBTzkgnrCn86.'

    # TODO: we need to fix the unit test framework to not assume that we are
    # running python unit tests from the root of the source tree.

# Generated at 2022-06-23 05:23:47.500970
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('foo')
        assert False, 'exception not thrown'
    except AnsibleParserError:
        pass

    try:
        from_yaml('foo', json_only=True)
        assert False, 'exception not thrown'
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:23:59.380636
# Unit test for function from_yaml
def test_from_yaml():
    from io import StringIO

    assert from_yaml(u'{"key": "value"}') == {u'key': u'value'}
    assert from_yaml(u'["item1", "item2"]') == [u'item1', u'item2']
    assert from_yaml(u'key: value') == {u'key': u'value'}
    assert from_yaml(u'- item1\n- item2') == [u'item1', u'item2']
    assert from_yaml(u"key: 'value'") == {u'key': u'value'}

    assert from_yaml(u'---\n{ "key": "value" }\n') == {u'key': u'value'}

# Generated at 2022-06-23 05:24:10.016704
# Unit test for function from_yaml
def test_from_yaml():
    """Test function from_yaml"""
    # Valid data
    print("Testing valid data")
    print("Expected: {}\nGot: {}".format("{'foo': 'bar'}", from_yaml("{'foo': 'bar'}")))
    print("Expected: {}\nGot: {}".format("{'foo': 'bar'}", from_yaml("{foo: bar}", json_only=True)))
    print("Expected: {}\nGot: {}".format("{'foo': 'bar'}", from_yaml("foo: bar")))
    print("Expected: {}\nGot: {}".format("{'foo': {'bar': 'baz'}}", from_yaml("foo:\n  bar: baz")))

    # Invalid data
    print("Testing invalid data")
    invalid

# Generated at 2022-06-23 05:24:21.151744
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a valid yaml
    result = from_yaml("""
        - hosts: localhost
          tasks:
            - debug:
                msg: Hello World
      """)

    assert isinstance(result, list)
    item = result[0]
    assert isinstance(item, dict)
    assert item['hosts'] == 'localhost'
    tasks = item['tasks']
    assert isinstance(tasks, list)
    task = tasks[0]
    assert isinstance(task, dict)
    assert task['debug']['msg'] == 'Hello World'

    # Cannot load invalid yaml

# Generated at 2022-06-23 05:24:30.829301
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import pytest

    path_to_test_data = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../test/utils/')
    path_to_json_data = os.path.join(path_to_test_data, 'test_from_yaml_json.json')
    path_to_yaml_data = os.path.join(path_to_test_data, 'test_from_yaml_yaml.yml')

    with pytest.raises(AnsibleParserError):
        from_yaml('{"test_when_false": false,}')

    with open(path_to_json_data) as f:
        json_data = f.read()

# Generated at 2022-06-23 05:24:37.559230
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Just make sure we can load a simple dictionary.
    '''
    data = '{"hello": "world"}'

    rval = from_yaml(data, json_only=True)
    assert isinstance(rval, dict)
    assert rval.get('hello') == 'world'

    rval = from_yaml(data)
    assert isinstance(rval, dict)
    assert rval.get('hello') == 'world'

# Generated at 2022-06-23 05:24:48.104673
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import requests

    secret = VaultSecret('myVaultPassword')


# Generated at 2022-06-23 05:24:59.545844
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("name: constant_value") == {"name": "constant_value"}
    assert from_yaml('"name: constant_value"') == "name: constant_value"
    assert from_yaml("{'name': 'constant_value'}") == {"name": "constant_value"}
    assert from_yaml("\"name: constant_value\"") == "name: constant_value"
    assert from_yaml("{\"name\": \"constant_value\"}") == {"name": "constant_value"}

    assert from_yaml("""name:
  constant_value""") == {"name": "constant_value"}
    assert from_yaml("'name:\n  constant_value'") == "name:\n  constant_value"

# Generated at 2022-06-23 05:25:09.942104
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('[]') == []
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('[1, 2, 3]', json_only=True) == [1, 2, 3]
    assert from_yaml('[1, \'1\', true]', json_only=True) == [1, u'1', True]

# Generated at 2022-06-23 05:25:15.444862
# Unit test for function from_yaml
def test_from_yaml():
   print ("Test case #1: test_from_yaml")
   try:
      data = '[{"name":"Red"}, {"name":"Green"}, {"name":"Blue"}]'
      from_yaml(data)
   except:
      print("test_from_yaml: Exception Occurred")
      assert False;
   finally:
      print("test_from_yaml: Finished")
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:25:21.033184
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("""{
      "name": "test",
      "state": "present",
      "astring": "hello",
      "afloat": 8.8,
      "anint": 22,
      "abool": true,
      "anull": null,
      "alist": [
        "foo",
        "bar"
      ],
      "adict": {
        "name": "tempest"
      }
    }""")


# Generated at 2022-06-23 05:25:31.905503
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml

    assert from_yaml('{ "foo": "bar" }') == {'foo': 'bar'}
    assert from_yaml('{ "marker": "here", "foo": "bar" }\n---\n{ "baz": "hooray" }') == [{'marker': 'here', 'foo': 'bar'}, {'baz': 'hooray'}]
    assert from_yaml('[ 1, 2, 3 ]') == [1, 2, 3]
    assert from_yaml('[ 1, 2, 3 ]', json_only=True) == [1, 2, 3]

# Generated at 2022-06-23 05:25:43.607198
# Unit test for function from_yaml
def test_from_yaml():
    # 1. Check the case where JSON is not valid
    my_json = '{"test": "this is a json test"}'
    my_json += '"test2": "this JSON is invalid!"}'
    try:
        from_yaml(my_json, json_only=True)
    except AnsibleParserError as e:
        print("JSON data is invalid, AnsibleParserError was raised")
    else:
        # The exception should have been raised for this test to pass
        raise ValueError("The JSON data is invalid, AnsibleParserError should have been raised")

    # 2. Check case where data is not valid YAML or valid JSON
    my_data = "not valid YAML, not valid JSON"

# Generated at 2022-06-23 05:25:54.147023
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - name: Create a user
      user:
        name: "{{ lookup('environment','USER') }}"
        groups: wheel
        state: present
        append: yes
        generate_ssh_key: yes
        ssh_key_file: ".ssh/id_rsa"
    - name: Copy SSH public key
      copy:
        content: "{{ lookup('file','.ssh/id_rsa.pub') }}"
        dest: "{{ lookup('file','.ssh/authorized_keys') }}"
    '''
    file_name = 'test/test_from_yaml'
    data = from_yaml(data, file_name)
    print(data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:25:59.439979
# Unit test for function from_yaml
def test_from_yaml():
    with open('test_yaml_file.yaml') as file:
        result_data = from_yaml(file, file_name = 'test_yaml_file.yaml')
        assert result_data
        assert result_data['test'] == 3
        assert result_data['blablabla'] == 'bla'
        print(result_data)

# Generated at 2022-06-23 05:26:10.671456
# Unit test for function from_yaml
def test_from_yaml():
    # Test good data
    data_sample_1 = '{"key1":"value 1","key2":123,"key3":{"key4":true,"key5":"value 5"}}'
    yaml_data_1 = from_yaml(data_sample_1)
    assert yaml_data_1 == json.loads(data_sample_1)

    # Test bad data
    data_sample_2 = '{"key1":"value 1","key2":123,"key3":"{"key4":true,"key5":"value 5"}"}'
    try:
        yaml_data_2 = from_yaml(data_sample_2)
        assert False, "Should have thrown an exception"
    except AnsibleParserError:
        assert True

    # Test good YAML

# Generated at 2022-06-23 05:26:21.758376
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.dataloader import DataLoader

    # Tests for proper handling of vault data

# Generated at 2022-06-23 05:26:31.565970
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test loading the given yaml file path.
    '''
    import yaml
    import os

    yaml_file_path = './test_playbook.yml'
    assert os.path.exists(yaml_file_path)

    with open(yaml_file_path) as f:
        data = f.read()
        assert data
        r = from_yaml(data, yaml_file_path, show_content=True)
        assert r == yaml.load(data, Loader=yaml.SafeLoader)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:26:42.778928
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('{"foo": "bar"}') == {u"foo": u"bar"}
    assert from_yaml('["foo", "bar"]') == [u"foo", u"bar"]
    assert from_yaml('["foo", "bar"]', json_only=True) == [u"foo", u"bar"]
    assert from_yaml('foo: [{}, {}]') == {u"foo": [{}, {}]}
    assert from_yaml('foo: [{}, {}]', json_only=True) == {u"foo": [{}, {}]}
    assert from_yaml('foo: bar', json_only=True) == {u"foo": u"bar"}


# Generated at 2022-06-23 05:26:53.479858
# Unit test for function from_yaml

# Generated at 2022-06-23 05:27:03.433688
# Unit test for function from_yaml
def test_from_yaml():
    # no errors with valid YAML
    try:
        assert from_yaml("---\nfoo: bar") == {'foo': 'bar'}
    except Exception as e:
        print(e)
        assert False

    # raises error with invalid YAML
    try:
        from_yaml("---\nfoo: bar\n...\n")
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # raises error if not given strings
    try:
        from_yaml(['---\nfoo: bar'])
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # no errors with valid JSON

# Generated at 2022-06-23 05:27:15.139512
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.dumper import AnsibleDumper

    stream = '''
---
# This is a comment line
- name: foo
  data:
      # A nested comment inside foobar
      foobar: |
        This is
        a long
        multiline
        multinode
        flask
        string
      # A list of items
      items:
        - item1
        - item2
        - item3
'''

    expected_data = [{
        'name': 'foo',
        'data': {
            'foobar': 'This is\na long\nmultiline\nmultinode\nflask\nstring\n',
            'items': ['item1', 'item2', 'item3'],
        }
    }]


# Generated at 2022-06-23 05:27:19.238734
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":42}') == {"a": 42}
    assert from_yaml('a: 42') == {"a": 42}
    assert from_yaml('- ["foo", 42, 3.141, true, false]') == [["foo", 42, 3.141, True, False]]
    return True

# Generated at 2022-06-23 05:27:30.609898
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(from_yaml("{}"), dict)
    assert isinstance(from_yaml("[]"), list)
    assert isinstance(from_yaml("not json"), dict)
    assert isinstance(from_yaml("{'foo': 'bar'}"), dict)
    assert isinstance(from_yaml(u"{'foo': 'bar'}"), dict)
    assert isinstance(from_yaml("'foo'"), dict)
    assert isinstance(from_yaml("1"), dict)
    assert isinstance(from_yaml("1.0"), dict)
    assert isinstance(from_yaml("1e-100"), dict)
    assert isinstance(from_yaml("-1"), dict)
    assert isinstance(from_yaml("true"), dict)

# Generated at 2022-06-23 05:27:40.602587
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    import sys

    enc = AnsibleJSONEncoder(sys.stdout, sort_keys=True)
    vault_secrets = {'_ansible_vault_password': 'vault_password'}
    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vaulted_yaml = vault.encrypt(u'secrets')
    vaulted_json = vault.encrypt(u'secrets')

    # test json
    # setup a single element list containing a single element dict
   

# Generated at 2022-06-23 05:27:47.706762
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    dl = DataLoader()
    path = '../../test/unit/sanity/code-smell/invalid-yaml/json_like.yml'
    content = dl.load_from_file(path)
    data = from_yaml(content)

    assert isinstance(data, dict)
    assert isinstance(data.get('encrypted_string'), AnsibleVaultEncryptedUnicode)
    assert data.get('yaml_string') == 'dummy string'


# Generated at 2022-06-23 05:27:52.760199
# Unit test for function from_yaml
def test_from_yaml():
    test_value = {'a': 'b'}
    test_json = json.dumps(test_value)
    test_yaml = 'a: b'
    assert from_yaml(test_json) == test_value
    assert from_yaml(test_yaml) == test_value

# Generated at 2022-06-23 05:28:00.535932
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    - hosts: localhost
      gather_facts: false
      tasks:
        - include_tasks: test.yml
          when: test_var | bool
    '''
    yaml_data = from_yaml(yaml_str)
    assert yaml_data == [
        {
            "hosts": "localhost",
            "gather_facts": False,
            "tasks": [
                {
                    "include_tasks": "test.yml",
                    "when": "test_var | bool"
                }
            ]
        }
    ]

# Generated at 2022-06-23 05:28:09.392157
# Unit test for function from_yaml
def test_from_yaml():
    # JSON input
    json_data = '{"key1": [1, 2, 3], "key2": "value2"}'
    output = from_yaml(json_data)
    assert output == {'key1': [1, 2, 3], 'key2': 'value2'}

    # YAML input
    yaml_data = '''
        key1:
            - 1
            - 2
            - 3
        key2: value2
    '''
    output = from_yaml(yaml_data)
    assert output == {'key1': [1, 2, 3], 'key2': 'value2'}

# Generated at 2022-06-23 05:28:12.888052
# Unit test for function from_yaml
def test_from_yaml():
    """
    :return:
    """
    import pdb;pdb.set_trace()
    assert from_yaml("""
        #!/bin/bash
        cd /tmp
        touch ABC
        """) == ["#!/bin/bash", 'cd /tmp', 'touch ABC']

# Generated at 2022-06-23 05:28:23.009632
# Unit test for function from_yaml
def test_from_yaml():
    # Valid JSON
    data = b'{"key1": "value1", "key2": "value2"}'
    assert(from_yaml(data) == json.loads(data))
    data = b'{"key1": "value1", "key2": "value2"}'
    assert(from_yaml(data, json_only=True) == json.loads(data))

    # Valid YAML
    data = b'key1: value1\nkey2: value2'
    assert(from_yaml(data) == {u'key1': u'value1', u'key2': u'value2'})
    data = b'key1: value1\nkey2: value2'

# Generated at 2022-06-23 05:28:31.486423
# Unit test for function from_yaml
def test_from_yaml():
    _test_data = '{ "key1": 1, "key2": 2 }'
    _test_file_name = '<string>'
    _test_show_content = True
    _test_vault_secrets = None
    _test_json_only = False
    test_result = {'key1': 1, 'key2': 2}
    assert test_result == from_yaml(_test_data, _test_file_name, _test_show_content, _test_vault_secrets,
                                    _test_json_only)
    _test_data = 'key: str'
    _test_file_name = '<string>'
    _test_show_content = True
    _test_vault_secrets = None
    _test_json_only = False

# Generated at 2022-06-23 05:28:40.210921
# Unit test for function from_yaml
def test_from_yaml():
    fy = from_yaml('''{
      "changed": false,
      "ping": "pong"
    }''')

    assert fy == {"changed": False, "ping": "pong"}

    fy = from_yaml('''---
      - hosts: all
        gather_facts: no
        tasks:
          - name: this is a task
            debug:
              msg: this is a message ''')

    assert fy == [{"hosts": "all", "gather_facts": "no", "tasks": [{"name": "this is a task", "debug": {"msg": "this is a message"}}]}]

# Generated at 2022-06-23 05:28:44.410936
# Unit test for function from_yaml
def test_from_yaml():
    data = "{foo: 'bar'}"
    new_data = from_yaml(data)
    assert new_data == {'foo': 'bar'}
    # test that a string containing json is interpreted as json
    data = '"foo: bar"'
    new_data = from_yaml(data)
    assert new_data == "foo: bar"

# Generated at 2022-06-23 05:28:55.974479
# Unit test for function from_yaml
def test_from_yaml():
    def test_from_yaml_raises_typeerror(data):
        data = to_native(data)
        assertRaisesRegexp(TypeError,
                           "expected string or buffer",
                           from_yaml, data)

    test_from_yaml_raises_typeerror(3)
    test_from_yaml_raises_typeerror(None)
    test_from_yaml_raises_typeerror(dict(a=3))

    def test_from_yaml_returns_expected(data, expected):
        data = to_native(data)
        parsed = from_yaml(data)
        assert expected == parsed

    test_from_yaml_returns_expected(
        u'\u20ac10',
        u'\u20ac10'
    )
    test

# Generated at 2022-06-23 05:29:03.106357
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.vars import vault_loader

    v = '$ANSIBLE_VAULT;1.1;AES256\n'
    v += '626163636465663735373665386262666264353930643164663734353563383262634038336232373\n'
    v += '60104e00134b40001a08196c016f6d000e0c616e73696e6272606e2f\n'
    v += '9a0e550a237544f6d0463ab55e819dfa28a127920\n'

# Generated at 2022-06-23 05:29:14.350050
# Unit test for function from_yaml

# Generated at 2022-06-23 05:29:20.506764
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ \"hello\": \"world\" }") == { 'hello': 'world' }
    assert from_yaml("hello: world") == { 'hello': 'world' }
    assert from_yaml("- hello\n- world") == [ 'hello', 'world' ]

# Generated at 2022-06-23 05:29:28.014634
# Unit test for function from_yaml
def test_from_yaml():

    data_json = dict(a=1,b=2,c=dict(d=4,e=5))
    data_yaml = "a: 1\nb: 2\nc:\n  d: 4\n  e: 5\n"
    data_yaml_complex = "a: 1\n\nb: 2\nc:\n  d: 4\n  e: 5\n\nf: !!python/object/apply:os.urandom [ 10 ]"

    import yaml
    yaml.warnings({'YAMLLoadWarning': False})

    assert from_yaml(data_yaml) == data_json
    assert from_yaml(data_yaml) == from_yaml(data_json)

# Generated at 2022-06-23 05:29:30.950003
# Unit test for function from_yaml
def test_from_yaml():
    data = 'a: 1'
    data_object = {'a': 1}
    assert from_yaml(data) == data_object
    assert from_yaml(data, json_only=True) == data_object

# Generated at 2022-06-23 05:29:36.479164
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"a\":1}") == dict(a=1)
    assert from_yaml("{\"a\":1}", json_only=True) == dict(a=1)

    try:
        from_yaml("{\"a\":1}", json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False



# Generated at 2022-06-23 05:29:45.878641
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.ajson import AnsibleJSONDecoder

    # Test that when the vault_secret is not supplied, the from_yaml function
    # will not decrypt the data.

# Generated at 2022-06-23 05:29:54.053385
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    class TestFromYaml(unittest.TestCase):
        def test_from_yaml(self):
            import sys
            import os
            import tempfile
            import ansible.parsing.vault

            self.assertIsNotNone(from_yaml('1', 'test_from_yaml_simple_int'))
            self.assertEqual(from_yaml('1', 'test_from_yaml_simple_int'), 1)
            self.assertEqual(from_yaml('1', 'test_from_yaml_simple_int', json_only=True), 1)
            self.assertIsNotNone(from_yaml('1.0', 'test_from_yaml_simple_float'))

# Generated at 2022-06-23 05:30:01.603576
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_data = from_yaml("{}", file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    assert from_yaml_data == {}

    try:
        from_yaml("not a yaml or json", file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
        assert e.orig_exc is not None
        assert e.obj is not None


# Generated at 2022-06-23 05:30:06.579998
# Unit test for function from_yaml
def test_from_yaml():
    data_yaml = '''
    foo: bar
    '''

    data_json = '''
    {
      "foo": "bar"
    }
    '''
    assert from_yaml(data_yaml) == from_yaml(data_json)

# Generated at 2022-06-23 05:30:14.742190
# Unit test for function from_yaml
def test_from_yaml():

    yaml_text = "---\n- hosts: localhost\n  connection: local\n  gather_facts: no\n  tasks:\n    - debug: msg=\"Hello world!\"\n"
    json_text = '[{"hosts": "localhost", "connection": "local", "gather_facts": "no", "tasks": [{"debug": {"msg": "Hello world!"}}]}]'

    assert(json.loads(json_text) == from_yaml(json_text))
    assert(json.loads(json_text) == from_yaml(yaml_text))

# Generated at 2022-06-23 05:30:20.994955
# Unit test for function from_yaml
def test_from_yaml():
    # Test the YAML loading function for double bracket sequence
    # assertion: [[<path: to some file>, <path2: to some other file>]]
    s = "[[{{ lookup('file', 'path') }}, {{ lookup('file', 'path2') }}]]"
    ret = from_yaml(s, file_name='<string>')
    assert ret == [['path', 'path2']]

# Generated at 2022-06-23 05:30:23.701346
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    some_key: some value
    """

    module = None
    result = from_yaml(data, module, False)
    assert result == {'some_key': 'some value'}

# Generated at 2022-06-23 05:30:30.726691
# Unit test for function from_yaml
def test_from_yaml():
    test = """
    players:
      -
        name: joe
        number: 12
        position: forward
        stats:
          goals: 3
          assists: 11
      -
        name: bob
        number: 22
        position: defense
        stats:
          goals: 7
          assists: 14
          blocked_shots: 51
    """
    assert from_yaml(test) == {'players': [{'name': 'joe', 'number': 12, 'position': 'forward', 'stats': {'goals': 3, 'assists': 11}}, {'name': 'bob', 'number': 22, 'position': 'defense', 'stats': {'goals': 7, 'assists': 14, 'blocked_shots': 51}}]}

# Generated at 2022-06-23 05:30:37.542575
# Unit test for function from_yaml
def test_from_yaml():
    data = """
from_yaml_data:
   - name1: value1
   - name2: value2
"""
    new_data = from_yaml(data)
    assert type(new_data) == dict
    assert new_data['from_yaml_data'][0]['name1'] == 'value1'
    assert new_data['from_yaml_data'][1]['name2'] == 'value2'


# Generated at 2022-06-23 05:30:45.943117
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('foo') == 'foo'

    # test that the function correctly raises an exception on invalid YAML (in
    # this case a missing ':') and that the exception contains the faulty line
    # number and column
    try:
        from_yaml('{ foo bar }')
    except AnsibleParserError as e:
        assert ' line 1, column 1' in str(e)
        assert '1, column 6' in str(e)
    else:
        assert False, "from_yaml did not error out when it should have for invalid input"

# Generated at 2022-06-23 05:30:48.372452
# Unit test for function from_yaml
def test_from_yaml():
    output = from_yaml("""
---
test:
  - {a: 1, b: 2}
""")
    assert output['test'] == [{'a': 1, 'b': 2}]

# Generated at 2022-06-23 05:30:55.689060
# Unit test for function from_yaml
def test_from_yaml():
    data = {'key': 'value'}
    # Test with a json string
    json_data = '{"key": "value"}'
    assert from_yaml(json_data) == data
    # Test with a yaml string
    yaml_data = 'key: value'
    assert from_yaml(yaml_data) == data
    # Test with a valid json but invalid yaml string
    bad_yaml = 'json: "{"key": "value"}"'
    try:
        from_yaml(bad_yaml)
    except AnsibleParserError:
        assert True

# Generated at 2022-06-23 05:31:04.232899
# Unit test for function from_yaml
def test_from_yaml():
    test_data = {'test_key': {'test_key1': 'test_value1', 'test_key2': 'test_value2'}}
    yaml_data = """test_key:
      test_key1: test_value1
      test_key2: test_value2"""
    assert from_yaml(yaml_data) == test_data
    assert from_yaml(json.dumps(test_data)) == test_data
    assert from_yaml(yaml_data, json_only=True) != test_data

# Generated at 2022-06-23 05:31:15.192351
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - name: some_name
      host: 127.0.0.1
    '''

    res = from_yaml(data)
    assert res == [{u'name': u'some_name', u'host': u'127.0.0.1'}]


if __name__ == '__main__':
    # run unit test for this module
    import sys
    import doctest
    import ansible.parsing.yaml.loader
    import ansible.parsing.ajson
    module = sys.modules[__name__]

# Generated at 2022-06-23 05:31:24.810857
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test that from_yaml returns the correct python datastructure
    given JSON or YAML strings.
    '''
    json_string = '{"a_list":[1,2,3],"a_dict":{"hello":"world"}}'
    assert from_yaml(json_string) == {u'a_list': [1, 2, 3], u'a_dict': {u'hello': u'world'}}

    yaml_string = '''
    a_list:
      - 1
      - 2
      - 3
    a_dict:
      hello: world
    '''
    assert from_yaml(yaml_string) == {u'a_list': [1, 2, 3], u'a_dict': {u'hello': u'world'}}

# Generated at 2022-06-23 05:31:36.480232
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    yaml_str = "key: value"
    assert from_yaml(yaml_str) == {"key": "value"}

    json_str = '{"key": "value"}'
    assert from_yaml(json_str) == {"key": "value"}

    # FIXME: with vault enabled, the following test fails
    # json_str = '{"key": !vault |\n\n      $ANSIBLE_VAULT;1.2;AES256;foo\n      393561393364663338626332323431383638373966363566663337646661396165316433323532316\n      333631383332376339363234343539376337383564303