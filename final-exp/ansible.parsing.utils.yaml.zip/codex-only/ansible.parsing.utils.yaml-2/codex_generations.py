

# Generated at 2022-06-23 05:21:41.061215
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml
    yaml_string = r'''
- role: blah
  foo: 1
- role: blah
  foo: 3
    '''
    data = yaml.dump(yaml.load(yaml_string, Loader=AnsibleLoader))
    assert(yaml_string == data)
    assert isinstance(data, AnsibleUnicode)
    data = yaml.dump(yaml.load(yaml_string, Loader=AnsibleLoader), default_flow_style=False, Dumper=AnsibleDumper)
    assert(yaml_string == data)
    assert isinstance(data, AnsibleUnicode)

# Generated at 2022-06-23 05:21:50.726103
# Unit test for function from_yaml
def test_from_yaml():
    '''
    make sure that it handles some special cases
    '''

    # the following cases come from ansible/test/units/parsing/test_yaml.py
    # the file is:
    #
    # ---
    # #default: &default
    # #  enabled: True
    #
    # #project_features:
    # #  <<: *default
    # #  enabled: False
    #
    # #custom_features:
    # #  <<: *default
    # #  enabled: False
    #
    # #project_features:
    # #  <<: *default
    # #  enabled: False
    # #custom_features:
    # #  <<: *default
    # #  enabled: False
    #
    # #project_features:
    # #  <<:

# Generated at 2022-06-23 05:21:54.230258
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'
    assert from_yaml(data) == {'foo': "bar"}



# Generated at 2022-06-23 05:21:56.258658
# Unit test for function from_yaml
def test_from_yaml():
    import doctest
    doctest.testmod(from_yaml)

# Generated at 2022-06-23 05:22:07.409076
# Unit test for function from_yaml
def test_from_yaml():
    d = '{"foo": 1, "bar": 2}'
    assert from_yaml(d) == {"foo": 1, "bar": 2}

    d = '{"foo": 1, "bar": [1, 2 ,3]}'
    assert from_yaml(d) == {"foo": 1, "bar": [1, 2 ,3]}

    d = "{foo: 1, bar: 2}"
    assert from_yaml(d) == {u'bar': 2, u'foo': 1}

    d = "{foo: 1, bar: 2"
    try:
        from_yaml(d)
        raise AssertionError("Invalid JSON should have raised exception")
    except:
        pass

    d = "{foo: 1, bar: 2}"

# Generated at 2022-06-23 05:22:18.585042
# Unit test for function from_yaml
def test_from_yaml():
    string = "foo:"
    try:
        from_yaml(string, show_content=False)
    except AnsibleParserError as e:
        assert str(e) == "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" \
                          "JSON: Expecting value: line 1 column 1 (char 0)\n\n" \
                          "Syntax Error while loading YAML.\n" \
                          "The error appears to be in '/dev/null': line 1, column 4, but may\n" \
                          "be elsewhere in the file depending on the exact syntax problem.\n" \
                          "The offending line appears to be:\n\n" \
                          "foo:\n" \
                          "   ^ here\n"



# Generated at 2022-06-23 05:22:30.101417
# Unit test for function from_yaml
def test_from_yaml():
    data1 = [
        '#!/usr/bin/env python',
        '"key1" : "value1",',
        '"key2" : "value2",',
        '"key3" : "value3",',
        '"key4" : "value4",',
        '"key5" : "value5",',
        '"key6" : "value6",',
        '"key7" : "value7",',
        '"key8" : "value8"',
    ]


# Generated at 2022-06-23 05:22:35.260152
# Unit test for function from_yaml
def test_from_yaml():
    test1 = u'set_fact:\n  foo: bar'
    result = from_yaml(test1)
    assert isinstance(result, dict)
    assert 'foo' in result['set_fact']
    assert result['set_fact']['foo'] == 'bar'


# Generated at 2022-06-23 05:22:42.205370
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"version": 1, "secrets": [["vault", "my secret"]], "other": "secret"}'
    vault_id = 'vault_1'
    vault_secrets = { vault_id: dict(v='v', password='p') }
    result = from_yaml(data, vault_secrets=vault_secrets)
    assert result == { 'version': 1, 'secrets': ['vault', 'p'], 'other': 'secret' }



# Generated at 2022-06-23 05:22:49.802237
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml

    yaml_example = """
- base:
    - one
    - two
  override:
    - { merge: left, key: value}
  dict:
    key: value
"""

    python_example = from_yaml(yaml_example)

    assert python_example[0] == {
        'base': ['one', 'two'],
        'override': [{'merge': 'left', 'key': 'value'}],
        'dict': {'key': 'value'}
    }

# Generated at 2022-06-23 05:22:59.567826
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    try:
        result = from_yaml("""
        {
            "root": {
                "key1": "value1",
                "key2": "value2",
                "key3": {
                    "key31": "value31",
                    "key32": "value32"
                }
            }
        }
        """)
        module.exit_json(changed=False, ansible_facts={"result": result})
    except Exception as e:
        module.fail_json(msg='Error when converting YAML to JSON: %s' % to_native(e), exception=traceback.format_exc())



# Generated at 2022-06-23 05:23:11.416461
# Unit test for function from_yaml
def test_from_yaml():
    json_str = '{"a": "b"}'
    yaml_str = 'a: b'
    assert from_yaml(yaml_str, json_only=True) == {"a": "b"}
    assert from_yaml(json_str, json_only=True) == json.loads(json_str)
    assert from_yaml(json_str) == json.loads(json_str)
    assert from_yaml(yaml_str) == {"a": "b"}
    assert from_yaml(json_str) == from_yaml(yaml_str)
    assert from_yaml(json_str, json_only=True) == from_yaml(yaml_str)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:23:22.323002
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import objects
    import json
    import yaml
    data = '''
    test:
        - abc
        - 123
        - !Json
          [1,2,3]
        - 123.34
        - !Yaml
          abc: 123
        - !!str 1
        - !!str 123abc
    '''
    ret = from_yaml(data)
    assert ret == {'test': ['abc', 123, [1, 2, 3], 123.34, {'abc': 123}, '1', '123abc']}

    ret = from_yaml(data, vault_secrets=dict(vault_password='test'))

# Generated at 2022-06-23 05:23:29.306386
# Unit test for function from_yaml
def test_from_yaml():
    d1 = from_yaml("{'a': 1, 'b': [1,2,3]}")
    assert d1 == {'a': 1, 'b': [1, 2, 3]}

    d2 = from_yaml("a: 1\nb:\n- 1\n- 2\n- 3")
    assert d2 == {'a': 1, 'b': [1, 2, 3]}

# Generated at 2022-06-23 05:23:40.259895
# Unit test for function from_yaml
def test_from_yaml():
    # Runs with Python 3.5.2 and PyYAML 3.12
    # These tests are written to cover the error handling in this module
    # and to provide a regression test for:
    # https://github.com/dmsimard/ansible/issues/12685
    # https://github.com/ansible/ansible/issues/49384
    from ansible import context
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.module_utils._text import to_native


# Generated at 2022-06-23 05:23:41.506667
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"name": "john", "age": "31"}'
    new_data = from_yaml(data)
    assert type(new_data) is dict
    assert new_data.get('name') == 'john'

# Generated at 2022-06-23 05:23:51.716726
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeText

    import tempfile, os
    tmpfile = tempfile.NamedTemporaryFile(delete=False, mode='w')
    tmpfile.write('''---
{% vars %}
my_var: "{{ vault_variable }}"
{% endvars %}
''')
    tmpfile.close()
    vault_secrets = [('vault_variable', 'vault_value')]
    data = from_yaml(open(tmpfile.name, 'r').read(), file_name=tmpfile.name, vault_secrets=vault_secrets)
    assert data['my_var'] == 'vault_value'

    os.unlink(tmpfile.name)

# Generated at 2022-06-23 05:24:01.478297
# Unit test for function from_yaml
def test_from_yaml():
    # invalid yaml, even though yaml is not enabled
    bad_yaml = """
    hosts: 'all
    remoteUser: ansible
    """
    # valid json, will be turned into dict
    valid_json = """
    {
      "hosts": "all",
      "remoteUser": "ansible"
    }
    """
    # invalid json
    bad_json = """
    {
      "hosts": "all",
      "remoteUser": "ansible"
      }
    }
    """
    # valid yaml, will be turned into dict
    valid_yaml = """
    hosts: all
    remoteUser: ansible
    """
    # regular string, will be turned into str
    regular_str = "hello world"

    # invalid yaml

# Generated at 2022-06-23 05:24:06.379600
# Unit test for function from_yaml
def test_from_yaml():
    import os
    assert os.path.exists("./modules.yaml") == True
    with open("./modules.yaml",'r') as f:
        yaml_data = f.read()
    print(from_yaml(yaml_data, file_name='modules.yaml'))

# Generated at 2022-06-23 05:24:14.854826
# Unit test for function from_yaml
def test_from_yaml():
    content = ""
    file_name = '<string>'
    json_only = False

    assert from_yaml(content, file_name, json_only=json_only) == None
    content = "variable"
    assert from_yaml(content, file_name, json_only=json_only) == 'variable'
    content = "variable2"
    assert from_yaml(content, file_name, json_only=json_only) == 'variable2'

    content = "---\nvariable: 'test'"
    assert from_yaml(content, file_name, json_only=json_only) == {'variable': 'test'}
    content = "---\nvariable: 'test2'"

# Generated at 2022-06-23 05:24:19.782966
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":12}')['a'] == 12
    assert from_yaml('a: 12')['a'] == 12
    assert from_yaml('a: [1, 2, {"a": "b"}]')['a'][0] == 1
    assert from_yaml('{')['a'] == 12
    assert from_yaml('a: 12')['a'] == 12
    assert from_yaml('a: [1, 2, {"a": "b"}]')['a'][0] == 1
    assert from_yaml('{')['a'] == 12

# Generated at 2022-06-23 05:24:28.474943
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == {
        "foo": "bar"
    }
    assert from_yaml('{ foo: bar }') == {
        "foo": "bar"
    }
    assert from_yaml('- foo\n- bar\n') == [
        "foo",
        "bar"
    ]
    assert from_yaml('{"foo": "{{ foo }}"}') == {
        "foo": "{{ foo }}"
    }

# Generated at 2022-06-23 05:24:33.625637
# Unit test for function from_yaml
def test_from_yaml():
    the_yaml = '''
    a: 1
    b:
      - 2
      - 3
    '''
    correct_data = {'a': 1, 'b': [2, 3]}
    assert from_yaml(the_yaml) == correct_data
    assert from_yaml(json.dumps(correct_data)) == correct_data

# Generated at 2022-06-23 05:24:43.983446
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Test valid json
    assert from_yaml("{\"foo\": \"bar\"}") == {"foo": "bar"}
    assert from_yaml("{\"foo\": [1, 2, 3, 4]}") == {"foo": [1, 2, 3, 4]}
    # Test valid yaml
    assert from_yaml("foo: bar") == {"foo": "bar"}
    assert from_yaml("foo:") == {"foo": None}
    assert from_yaml("foo: {}") == {"foo": {}}
    assert from_yaml("foo: []") == {"foo": []}

# Generated at 2022-06-23 05:24:54.669049
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}", file_name='<test>') == {}
    assert from_yaml("[]", file_name='<test>', json_only=True) == []
    try:
        from_yaml("[]", file_name='<test>') == []
    except Exception:
        pass
    assert from_yaml("[]", file_name='<test>') == []
    try:
        from_yaml("[", file_name='<test>')
    except Exception as e:
        assert "JSON" in to_native(e)
        assert "YAML" in to_native(e)
    try:
        from_yaml("", file_name='<test>', json_only=True)
    except Exception as e:
        assert "JSON" in to_native(e)

# Generated at 2022-06-23 05:25:10.308759
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

# Generated at 2022-06-23 05:25:15.273814
# Unit test for function from_yaml
def test_from_yaml():
    data = dict(a=1, b=2)
    yaml_data = from_yaml(json.dumps(data), file_name='<string>', show_content=True)
    assert data == yaml_data

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:25:18.320515
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    {
        "foo": "bar",
        "boo": "far"
    }
    """
    assert from_yaml(data) == json.loads(data)

# Generated at 2022-06-23 05:25:25.639047
# Unit test for function from_yaml
def test_from_yaml():
    sample_dict = {'key1':'value1','key2':'value2','key3':'value3','key4':'value4','key5':'value5','key6':'value6'}

    # Test for YAML
    sample_yaml = """
        ---
        key1: value1
        key2: value2
        key3: value3
        key4: value4
        key5: value5
        key6: value6
    """

    assert from_yaml(sample_yaml) == sample_dict

    # Test for JSON

# Generated at 2022-06-23 05:25:27.597529
# Unit test for function from_yaml
def test_from_yaml():
    assert {'a': 'b'} == from_yaml("{a: b}")


# Generated at 2022-06-23 05:25:35.657789
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # We don't want any deprecation warnings and such
    import warnings
    warnings.simplefilter('ignore')

    import os

    my_dir = os.path.dirname(__file__)
    vault_id = 'ansible-vault-test'
    vault_password = 'ansible'

    # A list of test items

# Generated at 2022-06-23 05:25:45.822059
# Unit test for function from_yaml
def test_from_yaml():

    # Test normal behavior
    yaml_string = 'hello: world'
    dict_string = {u'hello': u'world'}
    assert(from_yaml(yaml_string) == dict_string)

    # Test with vault information
    vault_secrets = {
        "vault_password_file": ".vault_pass.txt",
        "new_vault_password_file": ".new_vault_pass.txt",
        "vault_ids": [u'1111-1111-1111'],
        "vault_version": 1.1,
        "vault_id": u'1111-1111-1111'
    }

    vault_secrets['vault_ids'].append(u'2222-2222-2222')

    # Test with vault_secrets

# Generated at 2022-06-23 05:25:53.968613
# Unit test for function from_yaml
def test_from_yaml():
    yaml_input = """
- hosts: localhost
  gather_facts: no
  tasks:
    - name: test
      command: echo 1
      register: result
    - name: show
      debug: var=result
"""
    json_input = """
[{"hosts": "localhost", "gather_facts": "no", "tasks": [{"name": "test", "command": "echo 1", "register": "result"}, {"name": "show", "debug": {"var": "result"}}]}]
"""
    assert from_yaml(yaml_input) == from_yaml(json_input)

# Generated at 2022-06-23 05:25:57.217312
# Unit test for function from_yaml
def test_from_yaml():
    """
    :return:
    """
    yaml_str = """
    ---
    name: test_from_yaml
    """
    #print(from_yaml(yaml_str))


# Generated at 2022-06-23 05:26:08.881382
# Unit test for function from_yaml

# Generated at 2022-06-23 05:26:18.315960
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from ansible.parsing.yaml.objects import AnsibleMapping as Dict
    except ImportError:
        from ansible.utils.compat import OrderedDict as Dict

    def _check(data, expect, file_name=None, show_content=True, vault_secrets=None, json_only=False):
        want = from_yaml(data, file_name, show_content, vault_secrets, json_only)
        assert want == expect, 'want=%s, expect=%s for data=%s' % (want, expect, data)

    # check that we can parse JSON
    _check(data='{"abc":123}', expect=Dict(abc=123))

    # check that we can parse YAML

# Generated at 2022-06-23 05:26:28.794743
# Unit test for function from_yaml
def test_from_yaml():
    t = dict()
    t['json_only'] = dict()
    t['json_only']['json'] = dict()
    t['json_only']['json']['data'] = '{"a": true}'
    t['json_only']['json']['result'] = dict()
    t['json_only']['json']['result']['a'] = True
    t['json_only']['json']['result']['__ansible_vault'] = None
    t['json_only']['json']['exception'] = False
    t['json_only']['json']['exception_msg'] = None
    t['json_only']['yaml'] = dict()

# Generated at 2022-06-23 05:26:38.916802
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    wrong_json = "{ \"test\": \"this is not valid json\"}"
    wrong_yaml = "test: this is not valid yaml"
    if PY3:
        wrong_yaml = b"test: this is not valid yaml"

    assert isinstance(from_yaml(wrong_json, json_only=False), dict)
    assert isinstance(from_yaml(wrong_yaml, json_only=False), dict)
    assert isinstance(from_yaml(wrong_json, json_only=True), dict)

    try:
        from_yaml(wrong_yaml, json_only=True)
    except AnsibleParserError as e:
        # From here, we only care about the exception type
        assert True
        pass

    correct

# Generated at 2022-06-23 05:26:47.580758
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string="""---
- hosts: localhost
  connection: local
  tasks:
  - name: Use localhost action
    local_action: command echo "hello world"
  roles:
    - myrole
"""
    yaml_string2="""---
- hosts: localhost
  connection: local
  tasks:
  - name: Use localhost action
    local_action: command echo "hello world"
  roles:
    - myrole
"""
    assert from_yaml(yaml_string2) == from_yaml(yaml_string)



# Generated at 2022-06-23 05:26:58.586068
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import tempfile
    import textwrap
    import ansible.module_utils.basic

    assert not os.path.exists(tempfile.mktemp())

    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []
    assert from_yaml("42") == 42
    assert from_yaml("42.42") == 42.42
    assert from_yaml("42.0") == 42.0
    assert from_yaml("42.1") == 42.1

    assert from_yaml("false") == False
    assert from_yaml("true") == True

    assert from_yaml("null") is None

    assert from_yaml("{}", json_only=True) == {}

# Generated at 2022-06-23 05:27:03.652269
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    host: localhost
    user: ansible
    password: ansible
    """
    res = from_yaml(data, file_name='<string>')
    assert res == {u'host': u'localhost', u'user': u'ansible', u'password': u'ansible'}

# Generated at 2022-06-23 05:27:08.036831
# Unit test for function from_yaml
def test_from_yaml():
    class A:
        pass
    # Redirect stdout
    import sys
    import io
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    # Execute function
    result = from_yaml("a: 1", "testfile", True, None)
    assert result == {"a": 1}
    result = from_yaml("a: 1", "testfile", True, None, json_only=True)
    sys.stdout = old_stdout

# Generated at 2022-06-23 05:27:18.712902
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import json
    import yaml
    data = {
        'foo': 'bar',
        'baz': ['one', 'two', 'three'],
        'bar': {
            'foo-bar': 'baz',
            'foobarbaz': 'bar'
        }
    }
    json_data = json.dumps(data)
    yaml_data = yaml.safe_dump(data, default_flow_style=False)

    # Test loading from JSON
    loaded_data = from_yaml(json_data)

    assert loaded_data == data

    # Test loading from YAML
    loaded_data = from_yaml(yaml_data)

    assert loaded_data == data


# Generated at 2022-06-23 05:27:25.207919
# Unit test for function from_yaml
def test_from_yaml():
    # Passing json string should successfully return python object
    assert isinstance(from_yaml("{\"foo\":\"bar\"}"), dict)
    # Passing yaml string should successfully return python object
    assert isinstance(from_yaml("foo: bar"), dict)
    # Passing bad yaml string should raise an error
    try:
        from_yaml("foo: bar:\n - test")
        # If no error raised, test fails
        assert False
    except YAMLError as e:
        assert True

# Generated at 2022-06-23 05:27:35.758650
# Unit test for function from_yaml
def test_from_yaml():
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import PY3
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-23 05:27:45.136741
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {
        u'foo': u'bar',
    }

    assert from_yaml('[1,2,3]') == [1,2,3]
    assert from_yaml('[1, 2\n, 3]') == [1, 2, 3]
    assert from_yaml('{"foo": "bar"}') == {u'foo': u'bar'}
    assert from_yaml('{"foo": {"bar": "baz"}}') == {u'foo': {u'bar': u'baz'}}
    assert from_yaml(u"{'foo': 'bar'}") == {u'foo': u'bar'}

    assert from_yaml(u'1') == 1

# Generated at 2022-06-23 05:27:55.883852
# Unit test for function from_yaml
def test_from_yaml():
    def _assert_yaml_json_both(data):
        try:
            # Verify JSON-only mode fails for YAML data
            from_yaml(data, json_only=True)
        except AnsibleParserError:
            pass
        else:
            print('Expected exception from JSON-only mode for YAML data')
            raise
        try:
            # Verify JSON-only mode fails for JSON data
            from_yaml('{ "a": 5, "b": "string", "c": true, "d": false }', json_only=True)
        except AnsibleParserError:
            print('Expected exception from JSON-only mode for JSON data')
            raise
        else:
            pass
        # Verify JSON/YAML mode succeeds for YAML data

# Generated at 2022-06-23 05:28:02.063740
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    - hosts: localhost
      gather_facts: false
      vars:
        var1: '{{ value1 }}'
        var2: '{{ value2 }}'
    """
    assert from_yaml(data) == [{'hosts': 'localhost', 'gather_facts': False, 'vars': {'var1': '{{ value1 }}', 'var2': '{{ value2 }}'}}]

# Generated at 2022-06-23 05:28:08.612504
# Unit test for function from_yaml
def test_from_yaml():

    # FIXME: I haven't found a way to test the original parser error show_content boolean yet
    #assert should be equal to the expected result
    assert from_yaml("{\"a\": \"b\"}") == {"a": "b"}
    assert from_yaml("a: b") == {"a": "b"}
    assert from_yaml("a: b", show_content=False) == {"a": "b"}

    pass

# Generated at 2022-06-23 05:28:19.419367
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    yaml_string_1 = '''
        a:
          b:
            c:
              d: 10
              e: 20
              f: 30
        '''
    expected_data_1 =  {'a': {'b': {'c': {'d': 10, 'e': 20, 'f': 30}}}}


# Generated at 2022-06-23 05:28:30.176267
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.errors import AnsibleParserError

    try:
        from_yaml('{junk', 'file.yaml')
        assert False, "should have thrown AnsibleParserError"
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in str(e)

    try:
        from_yaml('[junk')
        assert False, "should have thrown AnsibleParserError"
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in str(e)


# Generated at 2022-06-23 05:28:31.945453
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": "b" }') == {'a': 'b'}

# Generated at 2022-06-23 05:28:42.582011
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''

    ret1 = from_yaml('{"a": "b"}')
    assert ret1 == {"a": "b"}

    ret2 = from_yaml('{"a": "b"}', json_only=True)
    assert ret2 == {"a": "b"}


# Generated at 2022-06-23 05:28:51.172602
# Unit test for function from_yaml
def test_from_yaml():
    sample_yaml = """
    # This is some YAML
    nginx:
      http:
        server:
          listen: 80
          server_name: {{ server_name }}
    """
    yaml_data = from_yaml(sample_yaml)
    assert yaml_data == {'nginx': {'http': {'server': {'listen': 80, 'server_name': {'_ansible_no_log_eval': None, '_ansible_unsafe': True, '_ansible_value': '{{ server_name }}'}}}}}


# Generated at 2022-06-23 05:28:55.728452
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    x = dl.load_from_file('../../lib/ansible/parsing/dataloader.py')
    y = dl.load_from_file('../../lib/ansible/module_utils/common.py')
    assert x, y

# Generated at 2022-06-23 05:28:58.206242
# Unit test for function from_yaml
def test_from_yaml():
    data = """
- a: b
- c: d
"""
    res = from_yaml(data)
    assert res == [{'a': 'b'}, {'c': 'd'}]

# Generated at 2022-06-23 05:29:08.296512
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    ---
     - "test": "a"
       "test_b":
         "test_c": 123
     - test_a:
         test_b:
           test_c: 123
    '''
    assert from_yaml(yaml_str) == [{'test': 'a', 'test_b': {'test_c': 123}}, {'test_a': {'test_b': {'test_c': 123}}}]

    json_str = '''
    [{"test":"a","test_b":{"test_c":123}},{"test_a":{"test_b":{"test_c":123}}}]
    '''

# Generated at 2022-06-23 05:29:18.564608
# Unit test for function from_yaml
def test_from_yaml():
    '''
    tests the from_yaml function
    '''
    from ansible.utils.vars import combine_vars

    test_data = b'{"foo": "bar"}'
    json_result = from_yaml(test_data)
    assert json_result == {"foo": "bar"}

    test_data = b'{"foo": "bar", "bam": {{foo}}}'
    with combine_vars([{'foo': "zap"}, {'foo': "zaptoo"}], vault_secrets=None) as my_vars:
        json_result = from_yaml(test_data, vault_secrets=my_vars)
        assert json_result == {"foo": "bar", "bam": "zaptoo"}

# Generated at 2022-06-23 05:29:28.149870
# Unit test for function from_yaml
def test_from_yaml():
    assert {'simple_key': 'one', 'dict_key': {'nested_key': 'two'}, 'list_key': ['one', 'two']} == from_yaml('''{simple_key: one, dict_key: {nested_key: two}, list_key: [one, two]}''')
    assert {'simple_key': 'one', 'dict_key': {'nested_key': 'two'}, 'list_key': ['one', 'two']} == from_yaml('''simple_key: one
dict_key:
  nested_key: two
list_key:
  - one
  - two''')

# Generated at 2022-06-23 05:29:35.370015
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('''
    ---
    foo:
      - name: barn
        thing:
          - key1: value1
          - key2: value2
        other:
          - key3: value3
          - key4:
              - value4a
              - value4b
          - key5: value5
    ''')

    # TODO: test that if no vault_secrets are provided,
    # AnsibleJSONDecoder.set_secrets() is eventually called with a value of None
    # (in order to test the new_data.pop('vault_password', None) call in
    # the AnsibleJSONDecoder)

# Generated at 2022-06-23 05:29:43.522438
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    - hosts: localhost
      tasks:
        - name: this is a task
          debug:
            msg: this is a message
    '''
    import ansible.playbook.play_context
    from ansible.parsing.vault import VaultLib

    vault_secrets = VaultLib([])
    play_context = ansible.playbook.play_context.PlayContext()
    result = from_yaml(yaml_str, vault_secrets=vault_secrets, loader=AnsibleLoader)

    print(result)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:29:49.237865
# Unit test for function from_yaml
def test_from_yaml():
    # Data to be tested
    data = '{"a": 1}'

    # Expected result
    expected_result = {'a': 1}

    # Actual result
    result = from_yaml(data)

    # Testing if actual result is the same as expected result
    assert result == expected_result

# Generated at 2022-06-23 05:29:56.512602
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("not json")
    # the following will fail with json.decoder.JSONDecodeError
    # but the yaml parser should get it
    assert from_yaml("null")
    # the following will fail with yaml.parser.ParserError
    # but the json parser should get it
    assert from_yaml("{ 1: '2' }")

# Generated at 2022-06-23 05:30:04.629383
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml(data='{ "a": "test", "b": [1, 2, 3] }', file_name='test')
        from_yaml(data='a: "test"\nb: [1, 2, 3]\n', file_name='test')
    except Exception:
        assert False

    try:
        from_yaml(data='a: "test"\nb: [1, 2, 3\n', file_name='test')
        assert False
    except AnsibleParserError:
        pass
    except Exception:
        assert False

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:30:14.680688
# Unit test for function from_yaml
def test_from_yaml():
    # if a file is passed as a first arg, we will try to replace
    # all \r\n with \n.  Otherwise, we just read the file as-is.
    import sys
    import os


# Generated at 2022-06-23 05:30:25.149736
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    result = from_yaml(to_bytes(AnsibleDumper().dump({'test': 2})))
    assert result == {'test': 2}

    result = from_yaml(to_bytes('{ test: 2 }'))
    assert result == {'test': 2}

    result = from_yaml(to_bytes('--- { test: 2 }'))
    assert result == {'test': 2}

    assert from_yaml(to_bytes('{ test: {deep: true} }')) == {'test': {'deep': True}}
    assert from_yaml(to_bytes('test: {deep: true}')) == {'test': {'deep': True}}


# Generated at 2022-06-23 05:30:35.094542
# Unit test for function from_yaml
def test_from_yaml():
    '''
    from_yaml() function unit test
    '''

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # valid YAML/JSON input
    simple_yaml = b'{"a": 1, "b": true, "c": "foo"}'
    simple_json = b'{"a": 1, "b": true, "c": "foo"}'

    # complex YAML/JSON input
    complex_yaml = b'[["foo", {"a": "b"}], {"bar": "baz"}]'
    complex_json = b'[["foo", {"a": "b"}], {"bar": "baz"}]'

    # invalid JSON input
    invalid_json = b'{"a": 1 true, "c": "foo"}'

    # invalid Y

# Generated at 2022-06-23 05:30:40.261610
# Unit test for function from_yaml
def test_from_yaml():
    # Test for bug https://github.com/ansible/ansible/issues/20697
    data = '{"test": "{{myvar}}"}'
    new_data = from_yaml(data, json_only=True)
    assert '{{myvar}}' in new_data['test']

# Generated at 2022-06-23 05:30:49.980047
# Unit test for function from_yaml
def test_from_yaml():
    test_dict_string = "{'a': 'b', 'c': 'd'}"
    assert from_yaml(test_dict_string, file_name='<string>') == {'a': 'b', 'c': 'd'}
    test_list_string = "['a', 'b', 'c']"
    assert from_yaml(test_list_string, file_name='<string>') == ['a', 'b', 'c']
    test_nested_list_string = "['e', ['f', ['g', 'h']]]"
    assert from_yaml(test_nested_list_string, file_name='<string>') == ['e', ['f', ['g', 'h']]]

# Generated at 2022-06-23 05:30:55.811213
# Unit test for function from_yaml
def test_from_yaml():
    s = """\
        - hosts:
            - localhost
        tasks:
          - shell: ls -lR
            register: result
    """
    yaml_str = '{0}'.format(s)
    yaml_dict = from_yaml(yaml_str)
    assert yaml_dict[0]['hosts']
    assert yaml_dict[0]['tasks']

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:31:07.599280
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    json_data = """
    {
        "some_key": "some_value",
        "some_list": [
            "some_list_value"
        ]
    }
    """

    yaml_data = """
    some_key: some_value
    some_list:
      - some_list_value
    """

    # Test from_yaml using JSON data
    data = from_yaml(json_data)
    assert data
    assert data['some_key'] == 'some_value'
    assert data['some_list'][0] == 'some_list_value'

    # Test from_yaml using YAML data
    data = from_yaml(yaml_data)
    assert data

# Generated at 2022-06-23 05:31:13.359403
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}', json_only=True) == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-23 05:31:16.235670
# Unit test for function from_yaml
def test_from_yaml():
    output = from_yaml("hello world")
    assert output == 'hello world'

    output = from_yaml("hello: world")
    assert output == {'hello': 'world'}

    output = from_yaml("hello:\n- world")
    assert output == {'hello': ['world']}

# Generated at 2022-06-23 05:31:20.160639
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'{ "test": "foo" }') == {u"test": u"foo"}

# Generated at 2022-06-23 05:31:23.645276
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('''
[
  {
    "foo": {
      "bar": {
        "baz": "foobarbaz"
      }
    }
  }
]
''')

# Generated at 2022-06-23 05:31:32.900302
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
- first_line:
    second_line: second
  first_line
- first_line:
    second_line: second
    third_line: third
  first_line""") == [{'first_line': {'second_line': 'second'}}, 'first_line', {'first_line': {'second_line': 'second', 'third_line': 'third'}}, 'first_line']