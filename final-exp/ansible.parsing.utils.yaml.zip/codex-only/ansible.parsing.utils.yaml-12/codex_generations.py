

# Generated at 2022-06-23 05:21:38.917206
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode

    secret_val = 'secret_value'
    vault_secret = 'secret_password'
    secret_var = objects.AnsibleVaultEncryptedUnicode.load(vault_secret, secret_val)
    assert isinstance(secret_var, AnsibleVaultEncryptedUnicode)
    assert secret_var.vault_secret == vault_secret
    assert str(secret_var) == secret_val
    assert secret_var.decrypt(vault_secret) == secret_val

# Generated at 2022-06-23 05:21:49.135086
# Unit test for function from_yaml

# Generated at 2022-06-23 05:21:54.163589
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'foo: bar') == {'foo': 'bar'}
    assert from_yaml(b'[{foo: bar}]') == [{'foo': 'bar'}]
    assert from_yaml(b'{"foo":"bar"}') == {'foo': 'bar'}
    assert from_yaml(u'foo: [\u1234]') == {'foo': ['ሴ']}

# Generated at 2022-06-23 05:22:04.285701
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing from_yaml:')

    print('  - Testing legacy behavior with list of dicts')
    data = '''
    - foo: bar
    - baz: quux
    '''
    new_data = from_yaml(data)
    assert type(new_data) == list
    assert type(new_data[0]) == dict

    print('  - Testing ajson behavior with json like dict and list')
    data = '''
    {
        "foo": "bar",
        "baz": "quux"
    }
    '''
    new_data = from_yaml(data)
    assert type(new_data) == dict

    print('  - Testing ajson and legacy yaml behavior with dict of dicts')

# Generated at 2022-06-23 05:22:14.243492
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test for successful conversion using the basic example from
    # https://yaml.org/start.html#id_258924
    basic_example = '''
    receipt:     Oz-Ware Purchase Invoice
    date:        2012-08-06
    customer:
        first_name:   Dorothy
        family_name:  Gale

    items:
        - part_no:   A4786
          descrip:   Water Bucket (Filled)
          price:     1.47
          quantity:  4

        - part_no:   E1628
          descrip:   High Heeled "Ruby" Slippers
          size:      8
          price:     100.27
          quantity:  1
    '''
    assert from_yaml(basic_example)

# Generated at 2022-06-23 05:22:18.399872
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1,2,3]") == [1,2,3]
    assert from_yaml("[1,2,3]", json_only=True) == [1,2,3]


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:22:29.952094
# Unit test for function from_yaml
def test_from_yaml():

    def test_data_from_yaml(s, expected):
        actual = from_yaml(s)
        assert actual == expected

    test_data_from_yaml("""
[1, 2, 3]
""", [1, 2, 3])

    test_data_from_yaml("""
null
""", None)

    test_data_from_yaml("""
true
""", True)

    test_data_from_yaml("""
false
""", False)

    test_data_from_yaml("""
"abc"
""", "abc")

    test_data_from_yaml("""
42
""", 42)

    test_data_from_yaml("""
- a
- b
""", ["a", "b"])


# Generated at 2022-06-23 05:22:33.599085
# Unit test for function from_yaml
def test_from_yaml():
    # For some reason, this prints out 11.0.0 instead
    # of 11.0 so we can't do an exact comparison
    assert abs(from_yaml("11.0") - 11.0) < 0.0001

# Generated at 2022-06-23 05:22:44.599290
# Unit test for function from_yaml
def test_from_yaml():
    # test_input:
    #   test_input_key: test_input_value
    # test_output:
    #   test_output_key: test_output_value

    # ansible_module_utils._text.to_text('test_input_value') == 'test_input_value'
    # ansible_module_utils._text.to_text('test_output_key') == 'test_output_key'
    # ansible_module_utils._text.to_text(data) == 'test_input: {test_input_key: test_input_value}'
    data = u'''test_input:
        test_input_key: test_input_value
    test_output:
        test_output_key: test_output_value'''
    test_data = from_yaml(data)

# Generated at 2022-06-23 05:22:48.913258
# Unit test for function from_yaml
def test_from_yaml():
    data = '''{
  "test": {
    "test": {
      "test": "test"
    }
  }
}'''
    assert isinstance(from_yaml(data), dict) is True
    assert isinstance(from_yaml(data, True), dict) is True

# Generated at 2022-06-23 05:22:59.418067
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function ansible.parsing.yaml.objects.from_yaml()

    Input:  JSON string

    Expected result:  list
    '''
    # A simple string, cannot be parsed to JSON
    yaml_str = 'abc'

# Generated at 2022-06-23 05:23:11.405491
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = r"""
    # YAML test string
    - name: test string
      some_boolean: 'yes'
      some_integer: 1234
      some_float: 1234.1234
      some_list: [True, False]
      some_dict:
        - nested_list:
            - nested_dict:
                key: value
      some_null: null
      some_date: 2001-12-15T02:59:43.1Z
      some_binary: !!binary |
        R0lGODlhDAAMAIQAAP//9/X
        17unp5WZmZgAAAOfn515eXv
        Pz7Y6OjuDg4J+fn5OTk6enp
        56enmleECcgggoBADs=
    """

# Generated at 2022-06-23 05:23:22.367025
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    if not vault_available:
        return
    from .yaml_test_data import test_data


# Generated at 2022-06-23 05:23:32.422000
# Unit test for function from_yaml
def test_from_yaml():
    if get_distribution("ansible").version.startswith("2.7"):
        # Python 3x introduced the difference
        return
    import unittest

    class TestAnsibleErrorsFromYaml(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_from_yaml(self):
            class VaultSecret:
                """ VaultSecret is a class that stubs the behavior of passwords-as-files """
                def __init__(self, filepath):
                    self.filepath = filepath

                def read_vault_password_file(self):
                    fp = open(self.filepath)
                    password = fp.readline()
                    return password.strip()


# Generated at 2022-06-23 05:23:42.501815
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import json
    import yaml
    import tempfile
    import os
    import stat
    import shutil
    import filecmp
    import subprocess
    import base64
    import difflib

    testdir = os.path.dirname(os.path.abspath(__file__))
    testdir = os.path.join(testdir, 'test_from_yaml')
    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-23 05:23:51.266797
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    try:
        from_yaml("{'foo':'bar'}") # JSON encoding
        from_yaml("{'foo':'bar'}", json_only=True) # JSON encoding
        raise Exception("Should have failed")
    except AnsibleParserError:
        pass

    ansible = from_yaml("{'foo':'bar'}", json_only=False)
    assert ansible["foo"] == "bar"

    ansible = from_yaml("foo: bar")
    assert ansible["foo"] == "bar"

# Generated at 2022-06-23 05:24:02.331099
# Unit test for function from_yaml
def test_from_yaml():
    import unittest


# Generated at 2022-06-23 05:24:12.943258
# Unit test for function from_yaml
def test_from_yaml():
    # Test AnsibleParserError exception
    exception = False
    try:
        from_yaml("{ foo: bar", json_only=True)
    except AnsibleParserError as e:
        exception = e.orig_exc
    assert isinstance(exception, ValueError)
    assert 'Extra data' in str(exception)

    # Test json input
    foo = {'foo': 'bar'}
    assert from_yaml(json.dumps(foo)) == foo

    # Test yaml input
    assert from_yaml("""
    foo: bar
    baz:
      - 1
      - 2
      - 3
    """) == foo

    # Test yaml input with vault encrypted foo

# Generated at 2022-06-23 05:24:17.530709
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1,2,3]') == [1,2,3]
    assert from_yaml('{ "a": { "b": [ "c", "d", "e" ] }, "f": [1,2,3] }') == { "a": { "b": [ "c", "d", "e" ] }, "f": [1,2,3] }

# Generated at 2022-06-23 05:24:27.279138
# Unit test for function from_yaml
def test_from_yaml():

    yamlstr = """
---
- name: test
  src: "{{item.src}}"
  dest: "{{item.dest}}"
  mode: "{{item.mode}}"
  owner: "{{item.owner}}"
  group: "{{item.group}}"
  force: "{{item.force}}"
  state: "{{item.state}}"
with_items:
  - { src: /tmp/testdir, dest: "/tmp/testdir", mode: "0755", owner: root, group: root, force: yes, state: link }
"""

# Generated at 2022-06-23 05:24:37.674552
# Unit test for function from_yaml
def test_from_yaml():
    try:
        print (from_yaml('{ hello: world }'))
        print (from_yaml('{ hello: world }', json_only=True))
    except AnsibleParserError as e:
        print ("Failed to parse as JSON: %s" % to_native(e))
    try:
        print (from_yaml('hello: world'))
        print (from_yaml('hello: world', json_only=True))
    except AnsibleParserError as e:
        print ("Failed to parse as YAML: %s" % to_native(e))
    try:
        print (from_yaml('hello: world', json_only=True))
    except AnsibleParserError as e:
        print ("Failed to parse as JSON or YAML: %s" % to_native(e))

# Generated at 2022-06-23 05:24:48.151132
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import binary_type

    # We try to cover every edge case found on #28265
    for i in ['localhost', '_localhost', 'localhost_', '_localhost_', 'localhost_with_underscore']:
        # We have to use the dumper as data may contain non-ascii chars
        # and we can not use str() on py3
        data = AnsibleDumper.add_yaml_loader_name(i).encode('utf-8')
        entry = from_yaml(data)
        assert isinstance(entry, binary_type)
        # We had a regression where the string was wrapped into a list
        assert isinstance(entry, binary_type)


# Generated at 2022-06-23 05:24:59.592556
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing from_yaml')

    import os
    import json
    import yaml

    HOME = os.getenv('HOME')
    TEST_DIR = 'test_test_test'
    TEST_FILE = os.path.join(HOME, TEST_DIR, 'test.yml')

    os.system('rm -rfv {}'.format(TEST_FILE))
    os.system('mkdir -pv {}'.format(os.path.join(HOME, TEST_DIR)))
    os.system('touch {}'.format(TEST_FILE))

    with open(TEST_FILE, 'w') as f:
        f.write('---\n')
        f.write('my_list:\n')
        f.write('- hello\n')
        f.write('- world\n')


# Generated at 2022-06-23 05:25:03.813174
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = """
    name: sample
    enabled: True
    """
    ansible_data = from_yaml(yaml_string)
    assert ansible_data['name'] == 'sample'
    assert ansible_data['enabled'] == True
    print(ansible_data)

# Generated at 2022-06-23 05:25:15.903940
# Unit test for function from_yaml
def test_from_yaml():

    # This is just a convenient wrapper around json vs yaml parsing
    assert from_yaml(b'{"bar":"baz"}', json_only=True) == {"bar":"baz"}

    # json is first, to check we don't get false positive from yaml parser
    # when an extra vars json string is given, e.g. case of:
    #      - debug: var=@test.json

    # This is just a convenient wrapper around json vs yaml parsing
    assert from_yaml(b'{"bar":"baz"}') == {"bar":"baz"}
    assert from_yaml(b'["foo", "bar"]') == ["foo", "bar"]
    assert from_yaml(b'{"bar":"baz"}', file_name='foo') == {"bar":"baz"}

# Generated at 2022-06-23 05:25:20.052569
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'foo': 'bar' }") == {'foo': 'bar'}
    assert from_yaml("{ 'foo': 1234 }") == {'foo': 1234}
    assert from_yaml("{ 'foo': '{{ bar }}' }") == {'foo': '{{ bar }}'}



# Generated at 2022-06-23 05:25:29.978889
# Unit test for function from_yaml
def test_from_yaml():
    d = {'a': 1, 'b': 2, 'c': {'c1': "xyz", 'c2': [1, 2, 3]}}
    s_json = json.dumps(d)
    s_yaml = '---\na: 1\nb: 2\nc:\n  c1: "xyz"\n  c2: [1, 2, 3]\n'
    assert json.loads(s_json) == d
    assert _safe_load(s_yaml) == d
    assert from_yaml(s_json) == d
    assert from_yaml(s_yaml) == d

# Generated at 2022-06-23 05:25:37.519597
# Unit test for function from_yaml
def test_from_yaml():
    # Important note: If this test fails and the error message is a Python stack trace,
    # it is likely you have an issue with your installed version of PyYAML.
    # Specifically, PyYAML 5.1 changed the exception raised from LibYAML when
    # failing to parse YAML, to a Python stack trace that is not caught by Ansible.
    # PyYAML 3.13 and 5.3 have been confirmed to work correctly in this area.
    assert from_yaml("---\n  a: 1") == {'a': 1}
    # If a string is parsed using the common yaml.load() api, it will return a
    # "unicode" string on Python 2 and a "str" string on Python 3, but both are
    # subclasses of "basestring"

# Generated at 2022-06-23 05:25:42.127329
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1') == 1
    assert from_yaml('- 1') == [-1]
    assert from_yaml('{"a": "1", "b": "2"}') == dict(a='1', b='2')

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:25:49.814772
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.ajson import from_json
    content = '''
    - name: all
      hosts: all
      tasks:
      - name: test0
        debug: msg="Hello world!"
      - name: test1
        debug: msg="Hello {{ name }}!"
        vars:
          name: world
    '''
    result = from_yaml(content)
    assert isinstance(result, list)
    assert len(result) == 1
    play_dict = result[0]
    assert play_dict['name'] == 'all'
    assert play_dict['hosts'] == 'all'
    assert isinstance(play_dict['tasks'], list)
    assert len(play_dict['tasks']) == 2

# Generated at 2022-06-23 05:26:01.481069
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import open_url
    from ansible.parsing.vault import VaultLib

    with open(os.path.join(os.path.dirname(__file__), 'files/test_vault.yml'), 'rb') as f:
        test_vault_yaml = AnsibleLoader(f, os.path.join(os.path.dirname(__file__), 'files/test_vault.yml')).get_single_data()

# Generated at 2022-06-23 05:26:10.922120
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

# Generated at 2022-06-23 05:26:21.977048
# Unit test for function from_yaml
def test_from_yaml():
    class Foo:
        def __init__(self, bar):
            self.bar = bar

        def __eq__(self, other):
            return isinstance(other, Foo) and self.bar == other.bar

    # test regular yaml
    assert from_yaml('["foo", "bar"]') == ["foo", "bar"]

    # test json
    assert from_yaml('["foo", "bar"]', json_only=True) == ["foo", "bar"]

    # test json decoding
    assert from_yaml('{"foo": ["bar", "baz"]}') == {"foo": ["bar", "baz"]}

    # test json decoding errors

# Generated at 2022-06-23 05:26:33.216885
# Unit test for function from_yaml
def test_from_yaml():
    print("Called test_from_yaml")
    assert True
    # For creating a unit test, we need a first line that asserts something.
    # The above line is just a placeholder; something that will always be true.
    # It is important to have this line, however, because it is used to assert
    # that no errors occurred in execution before reaching this line.
    #
    # Below, this should be changed to something more useful, like:
    # assert from_yaml("foo: bar") == {"foo": "bar"}
    # or even better:
    # assert from_yaml("a: b\nc: d") == {"a": "b", "c": "d"}


if __name__ == "__main__":
    test_from_yaml()
    print("Test finished")

# Generated at 2022-06-23 05:26:42.172126
# Unit test for function from_yaml
def test_from_yaml():
    data = '\n'.join([
        '---',
        '- name: jack',
        '  age: 18',
        '- name: jessy',
        '  age: 17',
        '...',
        ''
    ])
    res = from_yaml(data)
    assert isinstance(res, list)
    assert len(res) == 2
    assert isinstance(res[0], dict)
    assert res[0]['name'] == 'jack'
    assert res[0]['age'] == 18
    assert isinstance(res[1], dict)
    assert res[1]['name'] == 'jessy'
    assert res[1]['age'] == 17


# Generated at 2022-06-23 05:26:49.288529
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''
        - name: test
          version: "{{ version }}"
          plugins:
           - name: test-plugin
             version: "{{ test-version }}"
           - name: prod-plugin
             version: "{{ prod-version }}"
    ''') == [{'name': 'test', 'version': '{{ version }}', 'plugins': [{'name': 'test-plugin', 'version': '{{ test-version }}'}, {'name': 'prod-plugin', 'version': '{{ prod-version }}'}]}]

# Generated at 2022-06-23 05:26:59.730111
# Unit test for function from_yaml
def test_from_yaml():
    # Test with YAML string
    yaml_string = "---\n- hosts: localhost\n  gather_facts: no\n  tasks:\n  - debug: msg='Hello World!'"

    from_yaml_data = from_yaml(yaml_string)
    assert from_yaml_data[0]['hosts'] == "localhost"
    assert from_yaml_data[0]['gather_facts'] == "no"
    assert from_yaml_data[0]['tasks'][0]['debug']['msg'] == "Hello World!"

    json_string = json.dumps({"host": "localhost"})
    from_yaml_data = from_yaml(json_string)
    assert from_yaml_data['host'] == "localhost"



# Generated at 2022-06-23 05:27:11.766586
# Unit test for function from_yaml
def test_from_yaml():
    string = '{"hello": "world"}'
    testdict = {"hello": "world"}
    assert from_yaml(string) == testdict
    assert from_yaml(string, json_only=True) == testdict
    string = '{"hello": "world"}\n{"hello": "world"}'
    try:
        from_yaml(string, json_only=True)
    except AnsibleParserError as exc:
        assert str(exc) == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n' \
            'JSON: Extra data: line 2 column 1 - line 2 column 22 (char 22 - 43)\n\n%s' % YAML_SYNTAX_ERROR % u''
    else:
        assert False

# Generated at 2022-06-23 05:27:22.969653
# Unit test for function from_yaml
def test_from_yaml():
    '''
    unit test for function to test yaml data structure
    '''
    import os
    import platform
    import unittest
    import json
    import yaml

    yaml_out = '''{"foo": "bar"}
'''

    class TestFromYAML(unittest.TestCase):
        """
        Test parsing of yaml
        """

        def test_yaml(self):
            """
            test_yaml: test that string can be parsed as a yaml
            """
            data = from_yaml(yaml_out)
            assert data == {u'foo': u'bar'}

        def test_yaml_stream(self):
            """
            test_yaml_stream: test that string can be parsed as a yaml
            """

# Generated at 2022-06-23 05:27:30.703227
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Set up some test data.
    test_strings = dict()
    test_strings['unicode'] = u"foo: bar\n"
    test_strings['bytestring'] = "foo: bar\n"
    test_strings['mixed-strings'] = u"foo: bar\n" + b"foo: bar\n" + "foo: bar\n"
    test_strings['invalid'] = "foo: [1,\n  2,\n]"
    test_strings['nasty-unicode'] = u"foo: \u263a\n"
    test_strings['nasty-bytestring'] = "foo: \xe2\x98\xba\n"

    # Load the test data and check that it matches the expected results

# Generated at 2022-06-23 05:27:40.649830
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_native

    class TestCase(unittest.TestCase):
        def test_from_yaml(self):
            from_yaml_res = from_yaml(
                (
                    '{"foo": "bar", "baz": "qux", "nested": {"a": "b"}, "bin": "'
                    'aGVsbG8gd29ybGQ="}'
                ),
            )
            self.assertEqual(from_yaml_res, {"foo": "bar", "baz": "qux", "nested": {"a": "b"}, "bin": "aGVsbG8gd29ybGQ="})

        def test_from_yaml_exc(self):
            test

# Generated at 2022-06-23 05:27:46.032309
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
a: 1
""")['a'] == '1'
    assert from_yaml("""
a: 1
b: c
""")['b'] == 'c'
    assert from_yaml("""
{
    'a': 1
}
""")['a'] == 1
    assert from_yaml("""
{
    "a": 1
}
""")['a'] == 1

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:27:55.185738
# Unit test for function from_yaml
def test_from_yaml():
    # Test parsing of a simple valid JSON string with a single dict
    json_string = '{"a": "b"}'
    data = from_yaml(json_string)
    assert isinstance(data, dict)
    assert data.get('a') == 'b'

    # Test parsing of a simple valid YAML string with a single dict
    yaml_string = '---\na: b\n'
    data = from_yaml(yaml_string, json_only=True)
    assert isinstance(data, dict)
    assert data.get('a') == 'b'

    # Test error handling of non-dict JSON string
    json_string = '[]'

# Generated at 2022-06-23 05:28:05.656828
# Unit test for function from_yaml
def test_from_yaml():

    # Test 1:
    data = '{"a":"b"}'
    new_data = from_yaml(data)
    assert new_data == {"a": "b"}

    # Test 2:
    new_data = from_yaml(data, json_only=True)
    assert new_data == {"a": "b"}

    # Test 3:
    data = '{"a":""b"}'
    try:
        new_data = from_yaml(data, json_only=True)
        assert False, "Should have failed"
    except AnsibleError:
        pass

    # Test 4:
    data = 'this is not valid json'

# Generated at 2022-06-23 05:28:16.533005
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    assert isinstance(from_yaml("[1]"), AnsibleSequence)
    assert isinstance(from_yaml("{a: 1}"), AnsibleMapping)
    assert isinstance(from_yaml('{"a": 1}'), AnsibleMapping)
    assert isinstance(from_yaml("{a: {b: 1}}"), AnsibleMapping)
    assert from_yaml("{a: {b: 1}}").get('a') == {'b': 1}
    assert from_yaml("{a: 1}").get('a') == 1
    assert from_yaml("{a: 1}", json_only=True).get('a') == 1

# Generated at 2022-06-23 05:28:26.107311
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This function should assert that multiple types of data
    can be parsed as yaml and json consistently
    '''
    # simple list
    yaml = '''
    ---
    - 1
    - 2
    - 3
    '''
    yaml_result = from_yaml(yaml)
    assert yaml_result == [1, 2, 3]

    # simple json list
    json_list = '[1, 2, 3]'
    json_list_result = from_yaml(json_list)
    assert json_list_result == [1, 2, 3]

    # simple hash
    yaml_hash = '''
    ---
    key1: value1
    key2: value2
    '''
    yaml_hash_result = from_yaml(yaml_hash)

# Generated at 2022-06-23 05:28:35.890162
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('{"foo": "bar"}')
        assert False   # should throw error
    except AnsibleParserError as e:
        assert "JSON" in to_native(e)

    try:
        from_yaml('{"foo": "bar"}', json_only=True)
        assert False   # should throw error
    except AnsibleParserError as e:
        assert "JSON" in to_native(e)

    try:
        from_yaml('{"foo": "a": "b"}', json_only=True)
        assert False   # should throw error
    except AnsibleParserError as e:
        assert "JSON" in to_native(e)

    from_yaml('{"foo": "bar"}', json_only=True, show_content=False)


# Generated at 2022-06-23 05:28:47.275599
# Unit test for function from_yaml
def test_from_yaml():

    # Test invalid inputs
    invalid_inputs = []

    invalid_inputs.append(None)
    invalid_inputs.append('')

    for invalid_input in invalid_inputs:
        for json_only in [True, False]:
            try:
                from_yaml(invalid_input, json_only=json_only)
            except AnsibleParserError:
                pass
            else:
                assert False

    # Test valid inputs
    valid_inputs = []

    valid_inputs.append(('', {}))
    valid_inputs.append(('{}', {}))
    valid_inputs.append(('[]', []))
    valid_inputs.append(('{"key": "value"}', {'key': 'value'}))

# Generated at 2022-06-23 05:28:56.451773
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": 2 }') == { 'a': 1, 'b': 2 }
    assert from_yaml('{ "a": 1, "b": 2 }', json_only=True) == { 'a': 1, 'b': 2 }
    assert from_yaml('{ "a": 1, "b": 2 }', json_only=False) == { 'a': 1, 'b': 2 }

    assert from_yaml('a: 1\nb: 2') == { 'a': 1, 'b': 2 }
    assert from_yaml('a: 1\nb: 2', json_only=True) != { 'a': 1, 'b': 2 }

# Generated at 2022-06-23 05:29:00.378575
# Unit test for function from_yaml
def test_from_yaml():
    data = '''---
    - name: "dummy task"
      block:
        - debug: msg="hello world"
    '''

    print(from_yaml(data, file_name='dummy.yml'))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:29:09.584422
# Unit test for function from_yaml
def test_from_yaml():
    string = '''
    # Basic usage
    - { role: common, when: ansible_os_family == "RedHat" }

    # Conditional include
    - include: webservers.yml
      when: inventory_hostname in groups['webservers']

    # You can also use the `vars` subkey to set variables. This sets a
    # variable `apache_port` for hosts within the `webservers` group
    - hosts: webservers
      vars:
        apache_port: 80
    '''
    #Test with a string
    result = from_yaml(string)
    assert result[0]['role'] == 'common'
    assert result[1]['include'] == 'webservers.yml'

# Generated at 2022-06-23 05:29:20.264544
# Unit test for function from_yaml
def test_from_yaml():
    new_data = from_yaml('{"name":"John", "age":30, "car":null}')
    assert(new_data == {'name': 'John', 'age': 30, 'car': None})

    new_data = from_yaml("{'name':'John', 'age':30, 'car':null}")
    assert(new_data == {'name': 'John', 'age': 30, 'car': None})

    new_data = from_yaml('name: John\nage: 30\ncar: null')
    assert(new_data == {'name': 'John', 'age': 30, 'car': None})

    new_data = from_yaml("name: John\nage: 30\ncar: null", json_only=True)

# Generated at 2022-06-23 05:29:23.316748
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('{ "foo": "bar" }') == {'foo': 'bar'}

# Generated at 2022-06-23 05:29:33.740005
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    cwd = os.path.dirname(__file__)
    fixture_path = os.path.join(cwd, 'yaml_fixtures')
    test_fixtures = ['dict', 'list', 'str', 'unicode', 'int', 'float', 'bool_t', 'bool_f']
    for fixture in test_fixtures:
        fixture_file = os.path.join(fixture_path, fixture)
        fixture_content = open(fixture_file).read()
        fixture_data = json.loads(fixture_content)
        yaml_data = from_yaml(to_bytes(fixture_content))

# Generated at 2022-06-23 05:29:39.344536
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    dumper = AnsibleDumper()
    data = {'a_list': ['foo', 'bar', 'baz'], 'a_dict': {'foo': 'bar', 'bar': 'baz'}}
    yaml_bytes = dumper.dump(data)
    test_data = AnsibleLoader(yaml_bytes).get_single_data()
    assert test_data == data

# Generated at 2022-06-23 05:29:48.209889
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import copy

    class TestSequence(unittest.TestCase):
        def setUp(self):
            self.vault_secrets = {"vault_password": "secret"}

        def test_from_yaml(self):
            data = '''{"a": "{{foo}}"}'''
            result = from_yaml(data, vault_secrets=self.vault_secrets)
            expected = {"a": "{{foo}}"}
            self.assertEqual(copy.copy(result), expected)

        def test_from_yaml_json_only(self):
            data = '''{"a": "{{foo}}"}'''
            result = from_yaml(data, json_only=True)
            expected = {"a": "{{foo}}"}

# Generated at 2022-06-23 05:30:00.529766
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('{"hello": "json world"}')
    assert result == {"hello": "json world"}

    result = from_yaml('hello: world')
    assert result == {"hello": "world"}

    try:
        result = from_yaml('{hello: "json world"}')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('from_yaml should raise an AnsibleParserError')

    try:
        result = from_yaml('not a json')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('from_yaml should raise an AnsibleParserError')


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:30:03.884328
# Unit test for function from_yaml
def test_from_yaml():
    data = "this is some yaml"
    assert from_yaml(data) == data
    data = '{"some_key": "some_value"}'
    assert from_yaml(data) == {'some_key': 'some_value'}

# Generated at 2022-06-23 05:30:10.740049
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    [
    {
    "name": "jumper",
    "price": 19.95,
    "style": "B5104"
    },

    {
    "name": "top",
    "price": 29.95,
    "style": "T998"
    }
    ]
    '''

    from_yaml(data=test_data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:30:18.505017
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"first_key": value, "second_key": value2}'

    def first_key_in_data(data):
        return data['first_key'] == 'value'

    def second_key_in_data(data):
        return data['second_key'] == 'value2'

    new_data = from_yaml(data)

    assert first_key_in_data(new_data)
    assert second_key_in_data(new_data)

# Generated at 2022-06-23 05:30:20.317774
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('test') == 'test'
    assert from_yaml('["test"]') == ['test']

# Generated at 2022-06-23 05:30:26.346774
# Unit test for function from_yaml
def test_from_yaml():
    # Valid json data
    data = '{"a": 1, "b": 2}'
    assert from_yaml(data) == {"a": 1, "b": 2}

    # Valid yaml data
    data = "a: 1\nb: 2"
    assert from_yaml(data) == {"a": 1, "b": 2}

    # Invalid data
    data = "{'a'}"
    try:
        from_yaml(data, json_only=True)
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:30:35.696038
# Unit test for function from_yaml
def test_from_yaml():

    with open("test_files/data.yaml", "r") as f:
        data = f.read()

    a = from_yaml(data, file_name='test_files/data.yaml', show_content=True)
    assert len(a) == 2
    assert a[0]['hosts'] == 'host1'
    assert a[1]['hosts'] == 'host2'

    with open("test_files/data.json", "r") as f:
        data = f.read()

    a = from_yaml(data, file_name='test_files/data.json', show_content=True)
    assert len(a) == 2
    assert a[0]['hosts'] == 'host1'
    assert a[1]['hosts'] == 'host2'


# Generated at 2022-06-23 05:30:40.476683
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = "[0, 1, 2]"
    json_string = "[1, 2, 3]"

    assert(from_yaml(yaml_string) == [0, 1, 2])
    assert(from_yaml(json_string) == [1, 2, 3])

# Generated at 2022-06-23 05:30:49.193991
# Unit test for function from_yaml
def test_from_yaml():

    data = """
    - name: "value"
    - names1:
        - name: "value"
    - names2:
        - name: "value"
    - names3:
        - name: "value"
    - names4:
        - name: "value"
    """

    # use_dslt_loader=True will return a sequence of AnsibleDSL objects instead of a python list
    assert from_yaml(data, use_dslt_loader=True)[0].module == "value"

    # use_dslt_loader=False will return a python list of AnsibleDSL objects
    assert from_yaml(data, use_dslt_loader=False)[0].module == "value"

# Generated at 2022-06-23 05:30:59.791627
# Unit test for function from_yaml
def test_from_yaml():
    import textwrap
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test simple yaml

    yaml_src = textwrap.dedent("""\
    ---
    a : b
    c : d
    e :
      - 1
      - 2
      - 3
    """)

    result_obj = AnsibleMapping()

    result_obj.ansible_line_number = 1
    result_obj['a'] = AnsibleUnicode(u'b', 'c')

# Generated at 2022-06-23 05:31:11.931847
# Unit test for function from_yaml
def test_from_yaml():
    # check for empty data
    assert from_yaml('') is None

    # check for json data
    json_data = '{"data": "success"}'
    assert from_yaml(json_data) == {'data': 'success'}

    # check for yaml data
    yaml_data = '''
    data: success
    '''
    assert from_yaml(yaml_data) == {'data': 'success'}

    # check for multiline json data
    json_multiline = '''
    {
      "data": "success"
    }
    '''
    assert from_yaml(json_multiline) == {'data': 'success'}

if __name__ == '__main__':
    import pytest

# Generated at 2022-06-23 05:31:20.948526
# Unit test for function from_yaml

# Generated at 2022-06-23 05:31:31.512569
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.utils.unsafe_proxy import wrap_var

    assert '- "ea871278-4a4e-4f59-abbb-e79c53dee"\n  - "asdf"' == from_yaml('- ea871278-4a4e-4f59-abbb-e79c53dee\n- asdf')
    assert '- val1\n  - "asdf"' == from_yaml('- val1\n- asdf')
    assert '- "foo"\n  - bar' == from_yaml('- foo\n- bar')
    assert '- "foo"\n  - bar' == from_yaml('- foo\n- bar\n')
    assert '- "foo"\n  - bar\n  - 42' == from_y