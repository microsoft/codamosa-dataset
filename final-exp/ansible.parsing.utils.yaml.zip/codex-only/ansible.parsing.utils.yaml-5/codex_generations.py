

# Generated at 2022-06-23 05:21:38.476397
# Unit test for function from_yaml
def test_from_yaml():
    # Test to_json
    assert from_yaml('{"a": 1}', '<string>', show_content=True) == {"a": 1}
    assert from_yaml('a: 1', '<string>', show_content=True) == {"a": 1}
    try:
        from_yaml('{"a": 1', '<string>', show_content=True)
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-23 05:21:43.142658
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    test_yaml = {"c": "d"}
    test_yaml = json.dumps(test_yaml)
    new_data = from_yaml(test_yaml)
    assert(new_data['c'] == "d")

# Generated at 2022-06-23 05:21:54.444596
# Unit test for function from_yaml
def test_from_yaml():
    # from_yaml test
    from_yaml_json = from_yaml('''{
        "key": "value"
    }''')
    assert from_yaml_json == {'key': 'value'}

    from_yaml_yaml = from_yaml('''
        key: value
    ''')
    assert from_yaml_json == from_yaml_yaml
    assert from_yaml_yaml == {'key': 'value'}

    # from_yaml test with json_only
    from_yaml_json_only = from_yaml('''{
        "key": "value"
    }''', json_only=True)
    assert from_yaml_json_only == {'key': 'value'}


# Generated at 2022-06-23 05:22:04.368494
# Unit test for function from_yaml
def test_from_yaml():
    import yaml

    # empty stream
    try:
        from_yaml(None)
        assert False
    except Exception as e:
        assert type(e) == AnsibleParserError

    # empty stream
    try:
        from_yaml('')
        assert False
    except Exception as e:
        assert type(e) == AnsibleParserError

    # empty stream
    try:
        from_yaml(b'')
        assert False
    except Exception as e:
        assert type(e) == AnsibleParserError

    # empty stream
    try:
        from_yaml(yaml.load(''))
        assert False
    except Exception as e:
        assert type(e) == AnsibleParserError

    # empty stream

# Generated at 2022-06-23 05:22:09.898900
# Unit test for function from_yaml
def test_from_yaml():
    lst = from_yaml('["a", "b"]')
    assert lst[0] == "a"
    assert lst[1] == "b"

    lst = from_yaml('{"a": "1", "b": "2"}')
    assert lst["a"] == "1"
    assert lst["b"] == "2"

# Generated at 2022-06-23 05:22:21.037525
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    import ansible.module_utils.basic

    #
    # Test: Valid JSON string
    #
    test_string = '{"a": "b"}'
    expected_result = {u'a': u'b'}

    result = from_yaml(test_string)

    assert result == expected_result
    assert type(result) == type(expected_result)

    #
    # Test: Valid JSON object
    #
    test_obj = {u'a': u'b'}
    expected_result = {u'a': u'b'}

    result = from_yaml(test_obj)

    assert result == expected_result
    assert type(result) == type(expected_result)

    #
    # Test: Invalid JSON string

# Generated at 2022-06-23 05:22:26.448962
# Unit test for function from_yaml
def test_from_yaml():
    test_data = u"""[{
        "name": "test",
        "foo": "bar"
    }]"""
    assert from_yaml(test_data, json_only=False) == json.loads(test_data)
    assert from_yaml(test_data, json_only=True) == json.loads(test_data)

# Generated at 2022-06-23 05:22:37.260724
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    good_yaml_text = '''
    ---
    # Valid yaml

    # Hello world
    - hosts: localhost
      tasks:
      - command: echo "hello world"
    '''

    good_json_text = '''
    {
        "hello": "world"
    }
    '''

    bad_json_text = '''
    '''

    good_data = from_yaml(good_yaml_text)
    assert isinstance(good_data, list)
    assert len(good_data) == 1

    good_data = from_yaml(good_json_text)

# Generated at 2022-06-23 05:22:39.266545
# Unit test for function from_yaml
def test_from_yaml():

    data = "{'a': 1, 'b': 2}"
    decoded = from_yaml(data, '<test>', json_only=True)
    assert isinstance(decoded, dict)
    assert decoded['a'] == 1
    assert decoded['b'] == 2



# Generated at 2022-06-23 05:22:41.735357
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\nfoo: bar\n") == {'foo': 'bar'}

# Generated at 2022-06-23 05:22:53.882907
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader

    # This function returns an AnsibleBaseYAMLObject, but we want to be able to
    # textually compare the results to the original file.
    def _get_yaml_result(file_name):
        obj = from_yaml(open(file_name, 'rb').read())
        return ansible.parsing.yaml.objects._obj_to_safe_yaml(obj, width=160)

    for test in ('test/test_ajson_input.yml', 'test/test_ajson_output.yml', 'test/test_yaml_output.yml'):
        test_file_name = 'test/unittests/%s' % test
        expected_file_name

# Generated at 2022-06-23 05:23:03.492891
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"username\":\"test\", \"password\": \"test\"}") == {"username": "test", "password": "test"}
    assert from_yaml("{'username':'test', 'password': 'test'}") == {"username": "test", "password": "test"}
    assert from_yaml("{username:'test', password: 'test'}") == {"username": "test", "password": "test"}
    assert from_yaml("username: 'test',") == {"username": "test"}
    assert from_yaml("username: 'test'") == {"username": "test"}
    assert from_yaml("username: 'test'\npassword: 'test'") == {"username": "test", "password": 'test'}
    assert from_yaml("username : test,\npassword : test")

# Generated at 2022-06-23 05:23:07.981186
# Unit test for function from_yaml
def test_from_yaml():
    string = """
    ---
    - name: hello
      item:
        - redfish
        - trout
    - name: world
      item:
        - abalone
        - tilapia
        - hoki
    """
    y = from_yaml(string)
    assert y[0]['name'] == 'hello'
    assert y[1]['name'] == 'world'

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:23:18.718657
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": "b"}'
    new_data = from_yaml(data)
    assert new_data == {"a": "b"}, "The data are not correctly parsed"

    data = '{"a": "b"}\n'
    new_data = from_yaml(data)
    assert new_data == {"a": "b"}, "The data are not correctly parsed"

    data = "{'a': 'b'}\n"

# Generated at 2022-06-23 05:23:28.782647
# Unit test for function from_yaml
def test_from_yaml():
    # Test load from yaml
    data = '---\n- 1\n- 2\n- 3'
    expected_output = [1, 2, 3]
    assert from_yaml(data) == expected_output

    # Test load from yaml with file name
    data = '---\n- 1\n- 2\n- 3'
    expected_output = [1, 2, 3]
    assert from_yaml(data, file_name='test') == expected_output

    # Test load from yaml with show content
    data = '---\n- 1\n- 2\n- 3'
    expected_output = [1, 2, 3]
    assert from_yaml(data, show_content=False) == expected_output

    # Test load from yaml with vault secret

# Generated at 2022-06-23 05:23:39.939369
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import copy
    import tempfile

    # vault_secrets to use for testing
    test_secrets = ['secret', 'test']
    # test_secret_string to use for testing

# Generated at 2022-06-23 05:23:50.568480
# Unit test for function from_yaml
def test_from_yaml():
    try:
        vars = from_yaml('{ foo: bar }')
        if vars['foo'] != 'bar':
            print('Failed')
    except:
        print('Failed')
    try:
        vars = from_yaml('foo: bar')
        if vars['foo'] != 'bar':
            print('Failed')
    except:
        print('Failed')
    try:
        vars = from_yaml('foo:\n  - bar\n  - baz')
        if vars['foo'] != ['bar', 'baz']:
            print('Failed')
    except:
        print('Failed')

# Generated at 2022-06-23 05:23:56.847440
# Unit test for function from_yaml
def test_from_yaml():
    data = """
---
- hosts: localhost
  tasks:
    - name: test
      debug:
        msg="hello world"
"""
    assert from_yaml(data) == [{'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'hello world'}, 'name': 'test'}]}]

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:24:08.814655
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = dict(
        a=1,
        b=dict(
            c=range(10),
            d='foo',
            e=[
                dict(
                    f=2.2,
                    g=None,
                ),
            ],
        ),
        z='bar',
    )

    assert from_yaml(json.dumps(data)) == data
    assert from_yaml(json.dumps(data)) == from_yaml(json.dumps(data, cls=AnsibleJSONDecoder))

    yaml.add_representer(AnsibleBaseYAMLObject, AnsibleDumper.represent_yaml_object)


# Generated at 2022-06-23 05:24:15.211165
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1') == 1
    assert from_yaml('- 1') == [-1]
    assert from_yaml('[1]') == [1]
    assert from_yaml('{"k": "v"}') == {"k": "v"}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"k": {"k": "v"}}') == {"k": {"k": "v"}}

# Generated at 2022-06-23 05:24:24.658126
# Unit test for function from_yaml
def test_from_yaml():
    # Setup
    yaml_data = """
     - hosts : all
       remote_user: root
       tasks:
         - name: test
           shell: echo hello!"""

    json_data = """
     [
     {
       "hosts" : "all",
       "remote_user": "root",
       "tasks":
         [
           {
             "name": "test",
             "shell": "echo hello!"
           }
         ]
       }
      ]"""

    # Test
    yaml_result = from_yaml(yaml_data)
    json_result = from_yaml(json_data)

    # Assert
    assert yaml_result == json_result

# Generated at 2022-06-23 05:24:35.740661
# Unit test for function from_yaml
def test_from_yaml():
    # Create string data
    data = "---\n" \
           "- one: test1\n" \
           "- two: test2\n" \
           "- three: test3\n"

    # Create dictionary from string data
    d = from_yaml(data)

    # Assert that type is dictionary
    assert type(d) is dict, "from_yaml did not return a dict object"

    # Assert that key one has value test1
    assert d['one'] == "test1", "from_yaml has incorrect value for key one"

    # Assert that key two has value test2
    assert d['two'] == "test2", "from_yaml has incorrect value for key two"

    # Assert that key three has value test3

# Generated at 2022-06-23 05:24:40.319078
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("1", json_only=True) == 1
    assert from_yaml("[1]", json_only=True) == [1]
    assert from_yaml("{\"a\": 1}", json_only=True) == {"a": 1}
    assert from_yaml("a: 1", json_only=False) == {"a": 1}

# Generated at 2022-06-23 05:24:50.863213
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    with open("test_from_yaml.yml", 'r') as stream:
        data = stream.read()
        new_data = from_yaml(data, file_name='test_from_yaml.yml')
        assert new_data.keys() == ["a", "b", "c", "fruits"]
        assert new_data["a"] == "b"
        assert new_data["fruits"][0] == "apple"
        assert new_data["fruits"][1] == "orange"
        assert new_data["fruits"][2] == "strawberry"

    with open("test_from_yaml.json", 'r') as stream:
        data = stream.read()

# Generated at 2022-06-23 05:24:56.330342
# Unit test for function from_yaml
def test_from_yaml():
    json_data = '{"a":1, "b":2}'
    yaml_data = 'a: 1\nb: 2'

    assert from_yaml(json_data) == {'a': 1, 'b': 2}
    assert from_yaml(yaml_data) == {'a': 1, 'b': 2}



# Generated at 2022-06-23 05:25:05.160992
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert from_yaml(u'{"foo": "bar"}') == {u'foo': u'bar'}
    assert from_yaml(u'{"foo": false}') == {u'foo': False}
    assert from_yaml(u'{"foo": "{{x}}"}') == {u'foo': u'{{x}}'}
    assert from_yaml(u'{"foo": [ "a", "b" ] }') == {u'foo': [u'a', u'b']}

# Generated at 2022-06-23 05:25:16.573791
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml(u'{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml(u'{a: a}') == {"a": "a"}
    assert from_yaml(u'{a: 1}') == {"a": 1}

    assert from_yaml(u'{a: [1,2,3]}') == {"a": [1, 2, 3]}
    assert from_yaml(u'{a: {b: {c: {d: e} } } }') == {"a": {"b": {"c": {"d": "e"}}}}

    assert from_yaml(u'---\na: 1') == {"a": 1}
    assert from_yaml(u'---\na: 1\n') == {"a": 1}
    assert from_yaml

# Generated at 2022-06-23 05:25:25.183454
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import objects
    import os
    import sys
    import pytest
    from pprint import pprint
    from ansible.utils.display import Display
    from ansible.parsing.utils.yaml.dumper import AnsibleDumper

    display = Display()

    cwd = os.path.dirname(os.path.abspath(__file__))
    mm_path = os.path.join(cwd, 'meta_module')

    # Test option json_only=True
    meta_module = os.path.join(mm_path, 'meta_module_json.json')
    meta_module_data = open(meta_module).read()
    meta_module_yaml_data = from_yaml(meta_module_data, json_only=True)

# Generated at 2022-06-23 05:25:33.449265
# Unit test for function from_yaml
def test_from_yaml():
    x = {u"foo": u"bar" }
    assert from_yaml(json.dumps(x)) == x
    assert from_yaml(json.dumps(x), json_only=True) == x

    # https://bugs.launchpad.net/ansible/+bug/1470681
    x = {u"name": u"dict_with_non_string_key", u"data": {u"foo": u"bar", 1: u"two", u"three": 3}}
    assert from_yaml(json.dumps(x), json_only=True) == x

    x = {u"foo": u"bar"}
    assert from_yaml(json.dumps(x), file_name="test1") == x

# Generated at 2022-06-23 05:25:41.427240
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"mykey": "myval"}') is not None
    assert from_yaml('myval') is None
    assert from_yaml('{"mykey": "myval"}', json_only=True) is not None
    assert from_yaml('myval', json_only=True) is None

    # Validate we are properly handling non-json/yaml encoding
    try:
        from_yaml(b'{"mykey": "myval"}')
    except AnsibleParserError:
        pass
    else:
        assert False, "from_yaml() did not error on non-string"

# Generated at 2022-06-23 05:25:44.433742
# Unit test for function from_yaml
def test_from_yaml():

    test_string = "{'json_only': true}"

    assert from_yaml(test_string, file_name='<string>', json_only=True) == {'json_only': True}

# Generated at 2022-06-23 05:25:48.604355
# Unit test for function from_yaml
def test_from_yaml():
    data = {u'foo': [1, 2, 3], u'bar': 44}
    actual = from_yaml(json.dumps(data))
    assert data == actual
    assert data == from_yaml(json.dumps(data))
    assert data == from_yaml(json.dumps(data))
    assert data == from_yaml(json.dumps(data))



# Generated at 2022-06-23 05:25:56.418479
# Unit test for function from_yaml
def test_from_yaml():
    s = '{"a": 1}'
    vars = from_yaml(s, json_only=True)
    assert(vars == {u'a': 1})

    s = 'a: 1'
    vars = from_yaml(s, json_only=True)
    assert(vars is None)

    s = '{a:1}'

# Generated at 2022-06-23 05:26:03.410530
# Unit test for function from_yaml
def test_from_yaml():
    data = {'foo': 'bar'}
    in_data = json.dumps(data)
    out_data = from_yaml(in_data)
    assert in_data == json.dumps(out_data)

    in_data = '{"name": "world", "foo": "bar"}'
    out_data = from_yaml(in_data)
    assert in_data == json.dumps(out_data)

# Generated at 2022-06-23 05:26:09.184108
# Unit test for function from_yaml
def test_from_yaml():
    json_string = '{"foo": "bar"}'
    assert from_yaml(json_string,json_only=True) == json.loads(json_string)

    yaml_string = 'foo: bar'
    assert from_yaml(yaml_string,json_only=True) is None
    assert from_yaml(yaml_string) == yaml.load(yaml_string)

# Generated at 2022-06-23 05:26:18.532012
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = '''
    ---
    meta:
    - name: "meta1"
    - name: "meta2"
      value: "awesome"
    - name: "meta3"
      value: "awesome"
      another_value: "awesome"
    '''
    test_json = '''
    {
        "meta": [
            { "name": "meta1" },
            { "name": "meta2", "value": "awesome" },
            { "name": "meta3", "value": "awesome", "another_value": "awesome" }
        ]
    }
    '''
    import json

    yaml_data = json.loads(json.dumps(from_yaml(test_yaml)))

# Generated at 2022-06-23 05:26:29.074760
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{}")
    from_yaml("""{
        'a': 'b',
        'c': 'd'
    }""", show_content=True)
    from_yaml("""{
        'a': 'b',
        'c': 'd'
    }""", show_content=False)
    from_yaml("""{
        'a': 'b',
        'c': 'd'
    }""", file_name='<string>')
    from_yaml("""{
        'a': 'b',
        'c': 'd'
    }""", 'bad_file_name.txt')
    from_yaml("""{
        'a': 'b',
        'c': 'd'
    }""", vault_secrets=None)
    from_

# Generated at 2022-06-23 05:26:39.169188
# Unit test for function from_yaml
def test_from_yaml():
    # import unit test modules
    import unittest
    from ansible.module_utils import basic

    class TestFromYaml(unittest.TestCase):
        '''
        Unit test class for testing the ansible.module_utils.basic.from_yaml()
        method.
        '''

        def setUp(self):
            self.data = {'a':{'b':'c'}}

        def tearDown(self):
            pass

        def test_json(self):
            ''' Test json data sequence. '''

            json_data = '{"a": {"b": "c"}}'
            returned_data = basic.from_yaml(json_data, show_content=False)
            self.assertEqual(returned_data, self.data)


# Generated at 2022-06-23 05:26:50.613381
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys

    class_file_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(class_file_path + '/../../../../lib/ansible/galaxy/api')
    sys.path.append(class_file_path + '/../../../../lib/ansible/module_utils/urls')
    try:
        from galaxy_importer import GalaxyImporter
    except ImportError:
        print("Unable to import GalaxyImporter, skipping test for from_yaml")
        return

    galaxy_importer = GalaxyImporter()
    path = galaxy_importer._galaxy.role_path

# Generated at 2022-06-23 05:26:55.783583
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""hello: 'world'""") == {"hello": "world"}
    assert from_yaml("""hello: 'world'""", file_name='/root/test') == {"hello": "world"}
    assert from_yaml("""hello: 'world'""", show_content=False) == {"hello": "world"}
    assert from_yaml("""hello: 'world'""", json_only=True) == {"hello": "world"}


# Generated at 2022-06-23 05:27:03.818850
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test a few cases where we want to make sure the YAML parser
    can do what is expected of it

    Test:
        - Basic json parsing
        - Simple yaml
        - Multiline data
        - Multilevel structure
        - Multilevel structure with integers
    """
    data = '{ "foo": "bar" }'
    assert from_yaml(data) == {
        "foo": "bar"
    }

    data = """
    ---
    foo: bar
    """
    assert from_yaml(data) == {
        "foo": "bar"
    }

    data = """
    ---
    foo: bar
baz: >
    - something
    - something else
    """

# Generated at 2022-06-23 05:27:14.062032
# Unit test for function from_yaml
def test_from_yaml():
    test_json_string = '''{"test_key": "test_val", "test_key_2": "test_val_2"}'''
    test_yaml_string = '''test_key: test_val\ntest_key_2: test_val_2'''
    test_yaml_dict = {
        "test_key": "test_val",
        "test_key_2": "test_val_2"
    }
    json_result = from_yaml(test_json_string)
    assert json_result == test_yaml_dict
    yaml_result = from_yaml(test_yaml_string)
    assert yaml_result == test_yaml_dict

# Generated at 2022-06-23 05:27:24.727404
# Unit test for function from_yaml
def test_from_yaml():
    import ast
    import random
    import string

    for char in ['[', '{', '"', "'", ':', '#']:
        test_string = '{char}'.format(char=char)

        # The following will raise a ValueError if the test_string contains brackets and is not a valid
        # JSON/YAML string
        result = from_yaml(test_string, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
        assert ast.literal_eval(result) == char

    # This will test random strings
    for _ in range(10):
        test_string = ''.join(random.choice(string.ascii_letters) for _ in range(10))

        # The following will raise a YAMLError, if the test

# Generated at 2022-06-23 05:27:26.696940
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('- a') == [u'a']



# Generated at 2022-06-23 05:27:38.384119
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    dl = DataLoader()
    yaml_data = u"""
greetings:
  - hello
  - world
"""
    json_data = u'{"greetings": ["hello", "world"]}'
    # First test YAML
    ut_obj = from_yaml(yaml_data)
    ut_dump = AnsibleDumper().dump(ut_obj, Dumper=AnsibleDumper)
    json_obj = from_yaml(json_data)
    assert ut_obj == json_obj

    # Next test JSON
    ut_obj = from_yaml(json_data)

# Generated at 2022-06-23 05:27:44.835115
# Unit test for function from_yaml
def test_from_yaml():
    data1 = "data1"
    data2 = "data2"
    data3 = "data3"
    data4 = "data4"
    data5 = "data5"
    data6 = "data6"

    assert from_yaml(data1) == data1
    assert from_yaml(data2) == data2
    assert from_yaml(data3) == data3
    assert from_yaml(data4) == data4
    assert from_yaml(data5) == data5
    assert from_yaml(data6) == data6
    # from_yaml()

# Generated at 2022-06-23 05:27:53.513013
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    datastruct = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    data_yaml = AnsibleDumper(allow_unicode=True).dump(datastruct)
    new_datastruct = from_yaml(data_yaml)
    print(new_datastruct)
    assert new_datastruct['b']['c'] == 2

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-23 05:28:00.535616
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib

    file_name = 'test'
    show_content = False
    vault_secrets = VaultLib('test')

    data = from_yaml('''
---
key: value
''', file_name, show_content, vault_secrets)

    assert data == {'key': 'value'}

    data = from_yaml('''
{
    key: value
}
''', file_name, show_content, vault_secrets)

    assert data == {'key': 'value'}



# Generated at 2022-06-23 05:28:10.674408
# Unit test for function from_yaml
def test_from_yaml():
    # test with JSON
    data = '{"test": "some-value"}'
    obj = from_yaml(data)
    if obj == None:
        raise AssertionError("Failed to parse JSON data: '%s'" % to_native(data))

    # test with YAML
    data = 'hello: world'
    obj = from_yaml(data)
    if obj == None:
        raise AssertionError("Failed to parse YAML data: '%s'" % to_native(data))

    # test with invalid data
    data = 'invalid: data'
    try:
        obj = from_yaml(data, json_only=True)
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 05:28:20.866921
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.ajson import AnsibleJSONEncoder

    # test proper yaml parsing
    expected_results = {'foo': ['bar', 'baz'], 'spam': 'eggs', 'meh': {'a': 1}}
    json_data = json.dumps(expected_results, cls=AnsibleJSONEncoder)
    results = from_yaml(json_data, file_name='json', show_content=False, json_only=True)
    assert results == expected_results

    yaml_data = "---\nfoo:\n- bar\n- baz\nspam: eggs\nmeh:\n  a: 1\n"
    results = from_yaml(yaml_data, file_name='yaml', show_content=False, json_only=False)


# Generated at 2022-06-23 05:28:31.531579
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-23 05:28:42.202548
# Unit test for function from_yaml
def test_from_yaml():
    # when given a string with json data
    # it should return a python object
    assert {'test1': 'test2'} == from_yaml('{\"test1\": \"test2\"}')

    # when given a string with yaml data
    # it should return a python object
    assert {'test1': 'test2'} == from_yaml('test1: test2')

    # when given a string with no json or yaml data
    # it should raise an error
    try:
        from_yaml('Some string', json_only=True)
        assert False
    except AnsibleParserError as e:
        print(e)

    # when given a string with no json or yaml data
    # it should raise an error

# Generated at 2022-06-23 05:28:53.953817
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic unit tests for function from_yaml
    '''

    # basic YAML loads
    data = "test: 'basic string'\n"
    assert from_yaml(data) == {'test': 'basic string'}

    data = "test: \"basic string\"\n"
    assert from_yaml(data) == {'test': 'basic string'}

    data = "test: {'complex': 'dict'}\n"
    assert from_yaml(data) == {'test': {'complex': 'dict'}}

    data = "test: {\"complex\": 'dict'}\n"
    assert from_yaml(data) == {'test': {'complex': 'dict'}}


# Generated at 2022-06-23 05:28:56.719269
# Unit test for function from_yaml
def test_from_yaml():
    s = """
    - hosts: all
    """
    result = from_yaml(s)
    assert result == [{'hosts': 'all'}]

# Generated at 2022-06-23 05:29:03.960234
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 1: json_only is False
    assert from_yaml('{"test": "success"}', json_only=False) == {"test": "success"}
    # Test case 2: json_only is True
    try:
        from_yaml('{"test": "success"}', json_only=True)
    except AnsibleParserError as e:
        assert e.orig_exc is not None


if __name__ == '__main__':
    # Unit test for function from_yaml
    test_from_yaml()

# Generated at 2022-06-23 05:29:10.267737
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}
    from_yaml("{'foo': 'bar'}")


# Generated at 2022-06-23 05:29:15.198866
# Unit test for function from_yaml
def test_from_yaml():
    yamldata = {'a': 1, 'b': 2}
    jsondata = json.dumps(yamldata)
    assert from_yaml(jsondata) == yamldata

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-23 05:29:24.721589
# Unit test for function from_yaml
def test_from_yaml():
    import pytest


# Generated at 2022-06-23 05:29:34.992706
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test from_yaml() function

    Tested cases:
       - Dictionary (both JSON and YAML)
       - List (both JSON and YAML)
       - Flat list (both JSON and YAML)
       - String
       - Integer
       - Float
       - True (JSON only)
       - False (JSON only)
       - None (JSON only)

    Note: JSON data type is only used as a test. All data is considered YAML
    """


# Generated at 2022-06-23 05:29:44.571157
# Unit test for function from_yaml

# Generated at 2022-06-23 05:29:51.194024
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test function to call from_yaml and make sure that it is returning the correct structure
    :return:
    '''

    data = """---
- hosts: localhost
  tasks:
  - debug:
      msg: Hello there
      vars:
        hello: world
    """

    expected_data = [{'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'Hello there', 'vars': {'hello': 'world'}}}]}]

    actual_data = from_yaml(data)
    assert expected_data == actual_data

# Generated at 2022-06-23 05:29:53.806213
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": "b"}') == {'a': 'b'}
    assert from_yaml('a: b') == {'a': 'b'}
    assert from_yaml('{a: b}') == {'a': 'b'}

# Generated at 2022-06-23 05:30:04.284375
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-23 05:30:14.638558
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.text.converters import to_bytes
    import sys

    assert type(from_yaml('{}')) == dict
    assert type(from_yaml('[]')) == list

    # Test when json_only option is True.
    try:
        from_yaml('{bad_json}', json_only=True)
    except AnsibleParserError:
        # We expect an exception, just keep going.
        pass
    else:
        assert False, 'AnsibleParserError expected to be raised.'

    # Test when json_only option is False.
    try:
        from_yaml('{bad_json}', json_only=False)
    except AnsibleParserError:
        # We expect an exception, just keep going.
        pass
    else:
        assert False

# Generated at 2022-06-23 05:30:25.108422
# Unit test for function from_yaml
def test_from_yaml():
    test_vars = {}

    # Tests with valid yaml
    #
    test_vars['foo'] = 'bar'
    test_vars['hello'] = 'world'
    test_vars['dummy'] = { 'foo': 'bar' }
    test_vars['dummy2'] = { 'foo': 'bar', 'hello': 'world' }
    test_yaml = from_yaml(test_vars)

    assert test_yaml['foo'] == 'bar'
    assert test_yaml['hello'] == 'world'
    assert test_yaml['dummy']['foo'] == 'bar'
    assert test_yaml['dummy2']['hello'] == 'world'
    assert test_vars == test_yaml

    # Tests with valid json
    #
    test_

# Generated at 2022-06-23 05:30:33.933819
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"a":"a", "b":"b"}'
    assert from_yaml(test_data) == {"a" : "a", "b" : "b"}
    assert from_yaml(test_data, vault_secrets=["vault"]) == {"a" : "a", "b" : "b"}

    test_data = 'foo'
    try:
        from_yaml(test_data)
        assert False
    except:
        pass

    test_data = 'foo'
    try:
        from_yaml(test_data, vault_secrets=["vault"])
        assert False
    except:
        pass

# Generated at 2022-06-23 05:30:45.244597
# Unit test for function from_yaml
def test_from_yaml():
    '''Unit tests for function from_yaml()'''
    # Test invalid yaml
    try:
        from_yaml('-invalid yaml string')
    except AnsibleParserError as e:
        assert e.message.startswith('We were unable to read either as JSON nor YAML, these are the errors we got from each:')
        assert to_native(e.original_exc.problem) == 'expected \'<document start>\', but found \'\'\n'
        assert e.show_content == True

    # Test invalid yaml, with file_name and show_content specified

# Generated at 2022-06-23 05:30:53.786386
# Unit test for function from_yaml

# Generated at 2022-06-23 05:31:02.291329
# Unit test for function from_yaml
def test_from_yaml():

    # yaml_input = {'input_key': 'input_value'}
    # yaml_input = to_text(json.dumps(yaml_input))

    yaml_input = '''
        - hosts: local
          tasks:
            - name: include another yaml file
              include_vars: var.yaml
    '''

    yaml_data = from_yaml(data=yaml_input, json_only=False)
    print(yaml_data)

test_from_yaml()

# Generated at 2022-06-23 05:31:12.138664
# Unit test for function from_yaml
def test_from_yaml():
    # Test to parse a valid json data
    data = '{"no":1,"yes":2}'
    file_name = 'json_file'
    res = from_yaml(data, file_name)
    assert res['no'] == 1 and res['yes'] == 2
    # Test to parse a valid yaml data
    data = '''\
    first: 1
    second: 2
    third:
        - 1
        - 2
    '''
    file_name = 'yaml_file'
    res = from_yaml(data, file_name)
    assert res['first'] == 1 and res['second'] == 2 and res['third'][0] == 1 and res['third'][1] == 2

# Generated at 2022-06-23 05:31:21.139052
# Unit test for function from_yaml
def test_from_yaml():
    def eq_or_raise(data, expected):
        result = from_yaml(data)
        if result == expected:
            return
        else:
            raise AssertionError("returned result is not as expected:\n  got: %s\n  excepted: %s" % (repr(result), repr(expected)))

    # Test json with string
    eq_or_raise("'string'", "string")
    # Test json with number
    eq_or_raise("42", 42)
    # Test json with true
    eq_or_raise("true", True)
    # Test json with false
    eq_or_raise("false", False)
    # Test json with null
    eq_or_raise("null", None)
    # Test json with list

# Generated at 2022-06-23 05:31:31.658388
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("{'foo': 42}", json_only=False)
    assert result['foo'] == 42

    result = from_yaml("{{{'foo': 42}}}", json_only=True)
    assert result is None

    result = from_yaml("{{{'foo': 42}}}", json_only=False)
    assert result['foo'] == 42

    result = from_yaml("{{{'foo': 42}}}", json_only=True)
    assert result is None

    result = from_yaml('{ "foo": { "bar": { "baz": true }}}', json_only=False)
    assert result['foo']['bar']['baz'] == True


# Generated at 2022-06-23 05:31:42.993101
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        {
            'file_name': 'test.yml',
            'show_content': True,
            'vault_secrets': None,
            'data': '{foo: bar, bar: foo}',
            'expectation': {'foo': 'bar', 'bar': 'foo'},
        },
        {
            'file_name': 'test2.yml',
            'show_content': True,
            'vault_secrets': None,
            'data': '{foo: bar, bar: foo}',
            'expectation': {'foo': 'bar', 'bar': 'foo'},
        },
    ]
