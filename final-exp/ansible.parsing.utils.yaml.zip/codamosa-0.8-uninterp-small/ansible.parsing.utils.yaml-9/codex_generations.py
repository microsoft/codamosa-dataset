

# Generated at 2022-06-25 04:21:45.260991
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# Generated at 2022-06-25 04:21:48.938306
# Unit test for function from_yaml
def test_from_yaml():
    fixture_0 = ['a', 'b', 'c']
    fixture_1 = 'Test string'
    fixture_2 = '\u0040'

    # Call function from_yaml with a, b and c given
    a = from_yaml(fixture_0, fixture_1, fixture_2)
    assert a

# Generated at 2022-06-25 04:21:57.285352
# Unit test for function from_yaml
def test_from_yaml():
    tuple_0 = '\n---\n-james\n'
    var_0 = from_yaml(tuple_0)
    assert(var_0 == [u'james'])
    assert(var_0 == from_yaml(var_0))

    tuple_1 = '\n#comment\n---\njames\n'
    var_1 = from_yaml(tuple_1)
    assert(var_1 == u'james')
    assert(var_1 == from_yaml(var_1))

    tuple_2 = '''\n
    #! /usr/bin/python
    ---
    - james \n'''
    var_2 = from_yaml(tuple_2)
    assert(var_2 == [u'james'])

# Generated at 2022-06-25 04:21:58.487098
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(test_case_0(), object)

test_from_yaml()

# Generated at 2022-06-25 04:22:01.637830
# Unit test for function from_yaml
def test_from_yaml():
    print('Start from_yaml test...')
    test_case_0()
    print('End from_yaml test...')



# Generated at 2022-06-25 04:22:06.472170
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
- hosts: localhost
  tasks:
  - debug:
      msg: '{{ foo }}'
"""
    expected_result = [{'tasks': [{'debug': {'msg': "{{ foo }}"}}], 'hosts': 'localhost'}]
    result = from_yaml(test_data)
    assert result == expected_result



# Generated at 2022-06-25 04:22:08.885455
# Unit test for function from_yaml
def test_from_yaml():
    tuple_0 = ('')
    var_0 = from_yaml(tuple_0)
    tuple_1 = ('2')
    var_1 = from_yaml(tuple_1)
    assert type(var_0) == type(var_1)


# Generated at 2022-06-25 04:22:19.408376
# Unit test for function from_yaml
def test_from_yaml():
    # Test for from_yaml
    tuple_0 = ''
    var_0 = from_yaml(tuple_0)

    # Test for from_yaml
    tuple_0 = None
    var_0 = from_yaml(tuple_0)

    # Test for from_yaml
    tuple_0 = '{"foo": "bar"}'
    var_0 = from_yaml(tuple_0)

    # Test for from_yaml
    tuple_0 = '{"foo": "bar", "baz": "qux"}'
    var_0 = from_yaml(tuple_0)

    # Test for from_yaml
    tuple_0 = '{"foo": "bar", "baz": "qux"}'
    var_0 = from_yaml(tuple_0)

    #

# Generated at 2022-06-25 04:22:20.465339
# Unit test for function from_yaml
def test_from_yaml():
    tuple_0 = None
    var_0 = from_yaml(tuple_0)

# Generated at 2022-06-25 04:22:22.578057
# Unit test for function from_yaml
def test_from_yaml():
    assert(0)
    # Verify that the output of the function call returns the expected result.
    assert(0)
    # Verify that the function call raises the expected exception.
    assert(0)

# Generated at 2022-06-25 04:22:30.098613
# Unit test for function from_yaml
def test_from_yaml():
    # Test case #0
    test_case_0()

if __name__ == '__main__':
    # Run unit tests
    test_from_yaml()

# Generated at 2022-06-25 04:22:42.839759
# Unit test for function from_yaml

# Generated at 2022-06-25 04:22:53.276646
# Unit test for function from_yaml
def test_from_yaml():
    str_00 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_00)
    str_0 = '~/#0x=TCB(W8\x1a0L0`E{N\x7fdGXO'
    var_1 = from_yaml(str_0)
    str_2 = '~/\x7f\x1e`4\n)1\x1d8\x13a\x1a:.\x0fh#T7~u\x19\x7f'
    var_2 = from_yaml(str_2)

# Generated at 2022-06-25 04:23:04.159627
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)

    # From pexpect.py.
    str_1 = '1\x0b'
    var_1 = from_yaml(str_1)

    # From netmiko.py.
    str_2 = '/SS,Y)|V\x0b>BIA[j'
    var_2 = from_yaml(str_2)

    # From moler.py.
    str_3 = '\x1b[?1002h\x1b[?1h\x1b=#'
    var_3 = from_yaml(str_3)

    # From moler.py.

# Generated at 2022-06-25 04:23:16.131364
# Unit test for function from_yaml
def test_from_yaml():
    # Function test
    str_0 = from_yaml('fND')
    str_1 = from_yaml('U\x06lB')
    str_2 = from_yaml('o}{')
    str_3 = from_yaml('rZ')
    str_4 = from_yaml('xRv')
    str_5 = from_yaml('\x08`O')
    str_6 = from_yaml('v6')
    str_7 = from_yaml('\x0bx/')
    str_8 = from_yaml('vA')
    str_9 = from_yaml('\x0bI4')
    str_10 = from_yaml('G.')
    str_11 = from_yaml('\x0cC)')

# Generated at 2022-06-25 04:23:27.520378
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml('false') is False)
    assert(from_yaml('null') is None)
    assert(from_yaml('true') is True)
    assert(from_yaml('"foobar"') == 'foobar')
    assert(from_yaml('42') == 42)
    assert(from_yaml('42.42') == 42.42)
    assert(from_yaml('-42') == -42)
    assert(from_yaml('-42.42') == -42.42)
    assert(from_yaml('"42"') == '42')
    assert(from_yaml('"42.42"') == '42.42')
    assert(from_yaml('["foo", "bar"]') == ['foo', 'bar'])

# Generated at 2022-06-25 04:23:29.064663
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:30.220651
# Unit test for function from_yaml
def test_from_yaml():
    # No need to test anything, since just calls other functions
    pass

# Generated at 2022-06-25 04:23:40.515183
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import sys, io
        import yaml
        yaml_str = b"""---
        - hosts: all
          remote_user: root
          gather_facts: no
          pre_tasks:
          - name: gather facts
            setup:
              filter: ansible_*
          tasks:
          - name: test
            ping:
              data: "{{ test.stdout }}"
        """
        f = io.BytesIO(yaml_str)
        r = yaml.load(f)
        assert(r == {'hosts': 'all', 'remote_user': 'root', 'gather_facts': 'no'})
    except Exception:
        print('Exception')

test_from_yaml()

# Generated at 2022-06-25 04:23:43.604203
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert "tests/fixtures/test.yml" == from_yaml("tests/fixtures/test.yml")
    except (AnsibleParserError, YAMLError)  as e:
        assert False, "AnsibleParserError or YAMLError exception raised."



# Generated at 2022-06-25 04:23:46.419867
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

test_from_yaml()

# Generated at 2022-06-25 04:23:47.147447
# Unit test for function from_yaml
def test_from_yaml():

    assert test_case_0() == None

# Generated at 2022-06-25 04:23:54.038087
# Unit test for function from_yaml
def test_from_yaml():
    #assert from_yaml() == "Evaluates to True"
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)
    test_case_0()
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:23:57.037088
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    result_0 = test_case_0()
    assert result_0 == None

# Generated at 2022-06-25 04:24:06.495484
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'J=,H>u:8:7-L!@^'
    var_0 = from_yaml(str_0, '<string>', True, None)
    str_1 = '&T7T`)n9sSh\x0bHc<'
    var_1 = from_yaml(str_1, '<string>', True, None)
    str_2 = '=C)t0mii+$/F|{w'
    var_2 = from_yaml(str_2, '<string>', True, None)
    str_3 = '''\
iY3a(8Eh_5}IWB\x0b$`k'''
    var_3 = from_yaml(str_3, '<string>', True, None)
    str

# Generated at 2022-06-25 04:24:09.592233
# Unit test for function from_yaml
def test_from_yaml():

    str_0 = 'W5ZC//vJHY/+t"x/t[P,bL]n/BH|o&K*z@+}'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:24:12.769201
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('/SS,Y)|V\x0b>BIA[j') == '/SS,Y)|V\x0b>BIA[j'

# Generated at 2022-06-25 04:24:22.249581
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '<'
    var_0 = from_yaml(str_0)
    str_1 = '- '
    var_1 = from_yaml(str_1)
    str_2 = 'verify_ssl: disable'
    var_2 = from_yaml(str_2)
    str_3 = '#'
    var_3 = from_yaml(str_3)
    str_4 = '\x7f'
    var_4 = from_yaml(str_4)
    str_5 = '{'
    var_5 = from_yaml(str_5)
    str_6 = 'true'
    var_6 = from_yaml(str_6)
    str_7 = 'Ab'
    var_7 = from_yaml(str_7)

# Generated at 2022-06-25 04:24:30.371962
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert(from_yaml('{"a":1}') == {u'a': 1})
        assert(from_yaml('{a:1}') == {u'a': 1})
        assert(from_yaml('---\na: 1\n') == {u'a': 1})
        test_case_0()
    except AssertionError as e:
        print(str(e))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:24:32.403043
# Unit test for function from_yaml
def test_from_yaml():
    response = from_yaml("{'a': 'b'}")
    assert isinstance(response, dict) == True

# Generated at 2022-06-25 04:24:41.626445
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:24:52.935864
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = 'eyJTZWN1cml0aWVzIjp7InNlY3JldF9jb25maWc'
    str_2 = '''
    - name: Create a new user
      user:
        name: "{{ result.user }}"
        state: present
'''
    str_3 = '\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x8d\x8d\x91Q\xb2\xb0H\xe2\xec\xe4\xe4\xe4\xcev1\x92\x89"\x85\x8c\x00U\x00\x00\x00'

# Generated at 2022-06-25 04:25:02.444414
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"key": "value"}'
    str_1 = '{"key": "value"}'
    str_2 = '{\n    "key": "value"\n}'
    str_3 = "false"
    str_4 = "- false\n- false"
    str_5 = "- false\n- false"

    assert from_yaml(str_0) == from_yaml(str_1)
    assert from_yaml(str_1) == from_yaml(str_2)
    assert from_yaml(str_2) == from_yaml(str_3)
    assert from_yaml(str_3) == from_yaml(str_4)
    assert from_yaml(str_4) == from_yaml(str_5)

# Generated at 2022-06-25 04:25:04.630760
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:05.295304
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:25:11.634009
# Unit test for function from_yaml
def test_from_yaml():
    # Check that an exception is thrown if file_name is not provided
    result = from_yaml(123)
    assert isinstance(result, Exception)

    # Check that AnsibleParserError is thrown if json_only = True and parsing fails
    result = from_yaml(123, json_only=True)
    assert isinstance(result, AnsibleParserError)

    # Check that AnsibleParserError is thrown if json_only = True and parsing fails
    result = from_yaml('foo')
    assert isinstance(result, AnsibleParserError)

# Generated at 2022-06-25 04:25:21.185371
# Unit test for function from_yaml

# Generated at 2022-06-25 04:25:26.931107
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError) as excinfo:
        test_case_0()
    assert 'ansible.errors.AnsibleParserError: We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting value: line 1 column 1 (char 0)\n\nWe were unable to read this as YAML, but a JSON parser succeeded. The JSON parser output:\n\n  {0}\n\nIf this is not valid JSON, please consult the documentation on jinja2\'s template expression syntax and the --syntax-check CLI option.'.format(excinfo.value.message) in str(excinfo.value)

# Generated at 2022-06-25 04:25:29.655713
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1: test_case_0
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:25:34.192662
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    import timeit

    print(timeit.timeit(test_from_yaml, number=1))

# Generated at 2022-06-25 04:25:48.329659
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = '/SS,Y)|V\x0b>BIA[j'
        var_0 = from_yaml(str_0)
    except AnsibleParserError as e:
        print(e)
        print(e.args)
        print(e.message)
        print(e.obj)
        print(e.show_content)
        print(e.orig_exc)



# Generated at 2022-06-25 04:25:52.244886
# Unit test for function from_yaml
def test_from_yaml():
    arg_0 = '*&1'
    arg_1 = '%'
    arg_2 = '^'
    arg_3 = '-'
    arg_4 = '-'
    expected_0 = None
    expected_1 = None
    expected_2 = None
    expected_3 = None
    expected_4 = None
    test_0 = from_yaml(arg_0, arg_1, arg_2, arg_3, arg_4)
    assert test_0 == expected_0
    test_1 = from_yaml(arg_0, arg_1, arg_2, arg_3, arg_4)
    assert test_1 == expected_1
    test_2 = from_yaml(arg_0, arg_1, arg_2, arg_3, arg_4)

# Generated at 2022-06-25 04:25:55.307731
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:26:05.288848
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_1)
    assert var_0 == b'\x01\x02\x03\x04'

    str_2 = '\x01\x02\x03\x04'
    var_1 = from_yaml(str_2, vault_secrets=['$ANSIBLE_VAULT;1.2;AES256;ansible'])
    assert var_1 == b'\x01\x02\x03\x04'

    str_3 = '/SS,Y)|V\x0b>BIA[j'

# Generated at 2022-06-25 04:26:09.455491
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:13.904920
# Unit test for function from_yaml
def test_from_yaml():
    pass
    # dummy test
    assert True


# Generated at 2022-06-25 04:26:16.078805
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:19.881598
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:24.454734
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = '/SS,Y)|V\x0b>BIA[j'
        var_0 = from_yaml(str_0)
    except AnsibleParserError as ex:
        print('An error occurred parsing the YAML configuration')
        print(ex)


# Generated at 2022-06-25 04:26:28.066210
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:26:56.119832
# Unit test for function from_yaml
def test_from_yaml():

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 04:27:06.700299
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)
    str_1 = 'm(l\x15?K)n=C\x0beP5'
    var_1 = from_yaml(str_1)
    str_2 = '\x15\x06\x0b\t\x11\x05\tS\x1b\x15\x0f'
    var_2 = from_yaml(str_2)
    str_3 = '\x05\x06\r\r\r\r\r\r\r'
    var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:27:07.561072
# Unit test for function from_yaml
def test_from_yaml():
  # Test cases
  test_case_0()

# Generated at 2022-06-25 04:27:12.620659
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as e:
        raise e

# Generated at 2022-06-25 04:27:15.393843
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:27:26.040760
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a 1-element array.
    arg_array = [ '[', '1', ']' ]
    var_return = from_yaml(arg_array)
    assert (var_return, {}, var_return == [ 1 ])

    # Test with a 2-element array.
    arg_array = [ '[', '1', ',', '2', ']' ]
    var_return = from_yaml(arg_array)
    assert (var_return, {}, var_return == [ 1, 2 ])

    # Test with an empty object.
    arg_array = [ '{', '}' ]
    var_return = from_yaml(arg_array)
    assert (var_return, {}, var_return == { })

    # Test with an empty object.
    arg_array = [ '{', '}' ]

# Generated at 2022-06-25 04:27:37.025020
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '\x15\x0f\x12X\x1b\x1b\x15\x1f\r\r\r\r\x1e\x1c\x05\x12\x10\x0b\f\x05\x1aY'
    var_0 = from_yaml(str_0)

    str_1 = '\x12\x1b\x05\x1b\x16\x13\x19\x0f\x0f\x0f\x0f\x19\x1a\x1c\x19\x10\x12\x19\x1f\x1a\x10\x05\x14\x07\x1b\x15\x12\x1a\x0b\x04O'

# Generated at 2022-06-25 04:27:45.889376
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile
    import shutil
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence


# Generated at 2022-06-25 04:27:48.837608
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)
    assert var_0 == None


# Generated at 2022-06-25 04:27:58.543960
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'x"*\x0c\x1c:b\x05\n\n,\tA\x06{I\x16]^1\x1b\x02\x0b\x1bz\r\r'
    str_1 = '\x1ct\x0c4\x1b\x0c\x02\x04\x1f\x0b\x1d\x00T\x19\x14\x1f\x1f&\n\x01'

# Generated at 2022-06-25 04:28:24.164143
# Unit test for function from_yaml
def test_from_yaml():
    # Testing if JSON is properly loaded
    json_string = '{"a":1}'
    assert isinstance(from_yaml(json_string), dict)
    assert from_yaml(json_string)['a'] == 1

    # Testing if YAML is properly loaded
    yaml_string = 'a: 1'
    assert isinstance(from_yaml(yaml_string), dict)
    assert from_yaml(yaml_string)['a'] == 1

    try:
        from_yaml('{')
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-25 04:28:32.612128
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)

# File: ansible/module_utils/six/__init__.py

import sys
import types

__author__ = 'Benjamin Peterson'
__version__ = '1.14.0'

# True if we are running on Python 3.
PY3 = sys.version_info[0] == 3

if PY3:
    string_types = str,
    integer_types = int,
    class_types = type,
    text_type = str
    binary_type = bytes
    long = int
    xrange = range
else:
    string_types = basestring,
    integer_types = (int, long)

# Generated at 2022-06-25 04:28:34.023963
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:28:35.196303
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:28:41.452001
# Unit test for function from_yaml
def test_from_yaml():
    # Checking to see if the function correctly returns a dict object.
    # Input:  str_0 = 'bunny'
    # Expected Output: <class 'dict'>
    str_0 = 'bunny'
    var_0 = from_yaml(str_0)
    assert isinstance(var_0, dict)

    # Checking to see if the function correctly returns a dict object.
    # Input:  str_0 = 'bunny'
    # Expected Output: <class 'dict'>
    str_0 = 'bunny'
    var_0 = from_yaml(str_0)
    assert isinstance(var_0, dict)

    # Checking to see if the function correctly returns a dict object.
    # Input:  str_0 = '/SS,Y)|V\x0b>BIA[j'
    #

# Generated at 2022-06-25 04:28:46.344979
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:48.499667
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


# Generated at 2022-06-25 04:28:49.103804
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-25 04:28:49.969977
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

# Generated at 2022-06-25 04:28:52.145575
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except AnsibleParserError as e:
        assert False, "No exception should be thrown. Message: {0}".format(e.message)

# Generated at 2022-06-25 04:29:14.004850
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '\x03\x1d\x1d~#\x1d'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:29:24.463016
# Unit test for function from_yaml

# Generated at 2022-06-25 04:29:28.832344
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml((0, None)) == from_yaml(('0', 'None'))
    assert from_yaml(('0', 'None')) == from_yaml('0') == from_yaml('None')

# Generated at 2022-06-25 04:29:38.108145
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%# %$ %5 %e %r %q %n %t %w %g %d %h %f %u %a %c %x %z'
    str_1 = '.0 1.0 0.0 0e0 0e1 1e0 1e1 0E0 0E1 1E0 1E1 0.0e+10 1.0e+10 0.0e-10 1.0e-10 '
    str_2 = '0x0 0x1 0x01 0x1234 0x1234abcd 0x7f 0x7FF 0x7FFF 0xFFFF 0x7FFFFFFF '
    str_3 = '0xFFFFFFFF 0x7FFFFFFFFFFFFFFF 0x7FFFFFFFFFFFFFFF 0xFFFFFFFFFFFFFFFF 0xFFFFFFFFFFFFFFFG '
    str

# Generated at 2022-06-25 04:29:43.055424
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except BaseException as e:
        assert False, "Exception occured while testing function from_yaml: %s" % e
    else:
        assert True

# Generated at 2022-06-25 04:29:44.437574
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing String: '%s'" % str_0)
    assert(var_0 == None)


# Generated at 2022-06-25 04:29:54.101227
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'E"'
    var_0 = from_yaml(str_0)
    str_1 = '?s'
    var_1 = from_yaml(str_1)
    str_2 = 'I8\x0b+v\x0b=wz\x17\x0e'
    var_2 = from_yaml(str_2)
    str_3 = 'wE\x16\x0b\x11O'
    var_3 = from_yaml(str_3)
    str_4 = '[\x1d\x1d]\x1d'
    var_4 = from_yaml(str_4)

# Generated at 2022-06-25 04:29:57.014705
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml({"a": {"b": "c"}})
    assert result[0] == u"a"
    assert result[1].keys()[0] == u"b"
    assert result[1].values()[0] == u"c"



# Generated at 2022-06-25 04:30:05.132895
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml() == '', 'Expected "")'
    assert from_yaml(file_name='<string>') == '', 'Expected "")'
    assert from_yaml(vault_secrets=None) == '', 'Expected "")'
    assert from_yaml(show_content=True) == '', 'Expected "")'
    assert from_yaml(json_only=False) == '', 'Expected "")'
    assert from_yaml(data=None) == '', 'Expected "")'


# Generated at 2022-06-25 04:30:10.186277
# Unit test for function from_yaml
def test_from_yaml():
    # Issue #1211
    stream = '''
- 123:
    name: abc
  retries: 3
'''

    try:
        from_yaml(stream)
    except AnsibleParserError as e:
        assert "line 2, column 5, did not find expected '-' indicator" in to_native(e)



# Generated at 2022-06-25 04:30:31.355796
# Unit test for function from_yaml
def test_from_yaml():
    group = set()
    group.add(str_0)
    var_0 = from_yaml(group)


# Generated at 2022-06-25 04:30:34.588355
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)


test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:30:38.209316
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    str_0 = '/SS,Y)|V\x0b>BIA[j'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:30:46.307629
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '\n'
    var_0 = from_yaml(str_0)
    str_1 = '\n'
    var_1 = from_yaml(str_1)
    str_2 = '\n'
    var_2 = from_yaml(str_2)
    str_3 = '\n'
    var_3 = from_yaml(str_3)
    str_4 = '\n'
    var_4 = from_yaml(str_4)
    str_5 = '\n'
    var_5 = from_yaml(str_5)
    str_6 = '\n'
    var_6 = from_yaml(str_6)
    str_7 = '\n'
    var_7 = from_yaml(str_7)

# Generated at 2022-06-25 04:30:56.345838
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '+'
    var_0 = from_yaml(str_0)
    try:
        test_case_0()
    except TestException as e:
        raise TestException(str_0, e.message)
    try:
        str_1 = '['
        var_1 = from_yaml(str_1)
    except TestException as e:
        raise TestException(str_1, e.message)
    try:
        str_2 = '['
        var_2 = from_yaml(str_2)
    except TestException as e:
        raise TestException(str_2, e.message)

# Generated at 2022-06-25 04:30:58.243127
# Unit test for function from_yaml
def test_from_yaml():
    for i in range(1):
        test_case_0()

# Generated at 2022-06-25 04:31:02.636694
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = from_yaml('./check_ansible/test/data/sample0_good.json')

    assert(var_0 == {
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5
    })

    var_1 = from_yaml('./check_ansible/test/data/sample1_simple.yml')

    assert(var_1 == {
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5
    })

    var_2 = from_yaml('./check_ansible/test/data/sample2_complex.yml')


# Generated at 2022-06-25 04:31:06.934415
# Unit test for function from_yaml
def test_from_yaml():

    assert test_case_0() == '/SS,Y)|V\x0b>BIA[j'


if __name__ == '__main__':
    test_from_yaml

# Generated at 2022-06-25 04:31:17.475263
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:18.407285
# Unit test for function from_yaml
def test_from_yaml():
    pass

# from_yaml() function test