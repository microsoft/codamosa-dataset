

# Generated at 2022-06-25 04:21:46.690750
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:21:50.112034
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 04:21:56.320253
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)
    assert var_0 == "\xeb'deh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"


# Generated at 2022-06-25 04:22:04.653820
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)
    assert var_0 == b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    bytes_1 = b'\xa0\x0c\x08\x12]\xbb\x0c\x08\x12\x80\x10\xfc\x13\xbb\x0c\x08\x12\x80\x10\xfc\x13'

# Generated at 2022-06-25 04:22:06.510500
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

    # TODO: implement your test cases here.
    test_case_0()
    pass



# Generated at 2022-06-25 04:22:09.621109
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    try:
        from_yaml(b'\xeb\x07\x98\x9e\x9d\x05Z\x02\x15\x91\x96\xe8\x05\x1a\xf2\x13', file_name='<string>')
    except Exception as e:
        assert False, "Unable to call function from_yaml successfully: {0}".format(e)



# Generated at 2022-06-25 04:22:14.469518
# Unit test for function from_yaml

# Generated at 2022-06-25 04:22:20.396931
# Unit test for function from_yaml
def test_from_yaml():

    bytes_0 = b'\x94\xe2\xebj\xf2\x1d\x86\xb9!\xe5\x8f\xbe\x1b\xa6\x1fS\xab\xfe\x06F\xcf\x8e\x122\x14\xd4\xeb\x8b\x7f\x03\xf1\x1d\x12\xa7'
    var_0 = from_yaml(bytes_0)


# Test runner

# Generated at 2022-06-25 04:22:22.278309
# Unit test for function from_yaml
def test_from_yaml():
    assert (from_yaml(b'[\x00', '<string>', False, None, False) == [b'\x00'])

# Generated at 2022-06-25 04:22:25.955965
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0()


# Generated at 2022-06-25 04:22:36.183306
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test if from_yaml works as expected.
    """

    # Load the YAML data from a string
    yaml_data = """
    - fruit:
        - Orange
        - Apple
        - Pineapple
        - Banana
      veggie:
        - Tomato
        - Cucumber
        - Lettuce
        - Spinach
    - fruit:
        - Mango
        - Papaya
      veggie:
        - Potato
        - Onion
        - Garlic
    """

    # Convert the YAML to a Python dictionary
    python_data = from_yaml(yaml_data)

    # Print the Python dictionary
    print(python_data)


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:47.303996
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    input = b'{test: !vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          633361626133323963623461633939643638326233663564626639303464376239336431396136613\n          63323661316264643536383338396236643937393133323633616239303735663332306637333762\n          3236333537333363663966626639376162\n        }\n'

    res = DataLoader().load(input, '<string>')

# Generated at 2022-06-25 04:22:56.206251
# Unit test for function from_yaml
def test_from_yaml():
    # Tests if the function returns the correct type
    assert type(from_yaml('{\"file\":\"test.yml\"}')) is dict
    assert type(from_yaml('[1, 2, 3]')) is list
    assert type(from_yaml('true')) is bool
    assert type(from_yaml('1')) is int
    assert type(from_yaml('\"Hello World!\"')) is str
    assert type(from_yaml('null')) is type(None)
    if __name__ == '__main__':
        test_case_0()
    function_ret = from_yaml('{\"file\":\"test.yml\"}')
    assert function_ret == {'file': 'test.yml'}

# Generated at 2022-06-25 04:23:07.735632
# Unit test for function from_yaml
def test_from_yaml():
    input_0 = b"- hosts: all\n  name: test playbook\n\n  gather_facts: false\n\n  tasks:\n    - name: this is a test\n      debug: msg=\"hello world\"\n\n    - name: this is an error\n      debug: msg=\"something went wrong\"\n      failed_when: True\n"
    expected_0 = {'gather_facts': False, 'hosts': 'all', 'name': 'test playbook', 'tasks': [{'debug': {'msg': 'hello world'}, 'name': 'this is a test'}, {'debug': {'msg': 'something went wrong'}, 'failed_when': True, 'name': 'this is an error'}]}
    out_0 = from_yaml(input_0)
    assert expected_0 == out

# Generated at 2022-06-25 04:23:10.620120
# Unit test for function from_yaml
def test_from_yaml():
    # This is harder than it looks, since a different exception is produced based on the yaml syntax error
    pass

# Generated at 2022-06-25 04:23:19.838064
# Unit test for function from_yaml
def test_from_yaml():
    # Tests for the following types: lists, strings, and dictionaries.
    # Also tests for the error handling when it can't decode the bytes.
    var_0 = from_yaml(b"{\"_raw_params\": \"useradd -p '$6$salt$hashed' ansible\"}")
    assert isinstance(var_0, dict)
    var_1 = from_yaml(b"{\"_raw_params\": \"useradd -p '$6$salt$hashed' ansible\"}")
    assert isinstance(var_1, dict)

    var_2 = from_yaml(b"{\"_raw_params\": \"useradd -p '$6$salt$hashed' ansible\"}")
    assert isinstance(var_2, dict)


# Generated at 2022-06-25 04:23:28.245638
# Unit test for function from_yaml
def test_from_yaml():

    assert_equals(from_yaml(b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"), b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13")
    assert_equals(from_yaml(b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"), b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13")
    assert_

# Generated at 2022-06-25 04:23:30.969538
# Unit test for function from_yaml
def test_from_yaml():
    # Write your code here to test your implementation.
    # The test should fail if your implementation fails to pass the tests.
    pass

if __name__ == "__main__":
    test_from_yaml() # If you want to run your test

# Generated at 2022-06-25 04:23:35.010061
# Unit test for function from_yaml
def test_from_yaml():
    data = '''---
- hosts: localhost
  connection: local
  gather_facts: no

  tasks:
  - name: test
    debug: msg="test"
    when:
    - false
    - false'''
    result = from_yaml(data)
    assert isinstance(result, list)
    assert isinstance(result[0], dict)
    assert result[0]['hosts'] == 'localhost'



# Generated at 2022-06-25 04:23:41.258984
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)
    assert var_0 is None



# Generated at 2022-06-25 04:23:52.884959
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("") is None
    assert from_yaml("true") is True
    assert from_yaml("false") is False
    assert from_yaml("29") == 29
    assert from_yaml("\"29\"") == "29"
    assert from_yaml("'29'") == "29"
    assert from_yaml("null") is None
    assert from_yaml("{}") == {}
    assert from_yaml("{\"a\": \"b\"}") == {"a": "b"}
    assert from_yaml("{\"a\": 29}") == {"a": 29}
    assert from_yaml("{\"a\": true}") == {"a": True}
    assert from_yaml("[]") == []

# Generated at 2022-06-25 04:24:03.373849
# Unit test for function from_yaml
def test_from_yaml():
    yaml_0 = "{\n    \"foo\": \"bar\"\n}"
    var_0 = from_yaml(yaml_0)
    assert var_0 == {"foo": "bar"}, "from_yaml test # 0 failed"
    yaml_1 = bytes("{\n    \"foo\": \"bar\"\n}", encoding="utf-8")
    var_1 = from_yaml(yaml_1)
    assert var_1 == {"foo": "bar"}, "from_yaml test # 1 failed"
    yaml_2 = "{\n    \"foo\": \"bar\"\n}"
    var_2 = from_yaml(yaml_2)
    assert var_2 == {"foo": "bar"}, "from_yaml test # 2 failed"

# Generated at 2022-06-25 04:24:12.333810
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)
    var_1 = None
    try:
        var_1 = from_yaml(b'{\n    "test" : [\n        1,\n        2,\n        3\n    ]\n}')
        assert var_1 != None
    except AnsibleParserError as e:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:24:20.776452
# Unit test for function from_yaml
def test_from_yaml():
    data = "---\n" \
           "foo:\n" \
           "  - bar\n" \
           "  - oof\n" \
           "bar:\n" \
           "  - 3\n" \
           "  - 2\n" \
           "  - 1\n" \
           "empty: ''\n"

    actual = from_yaml(data)
    expected = {'foo': ['bar', 'oof'], 'bar': [3, 2, 1], 'empty': ''}

    assert actual == expected



# Generated at 2022-06-25 04:24:25.600647
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:24:35.438546
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:39.511499
# Unit test for function from_yaml
def test_from_yaml():

    #
    #
    #
    assert test_case_0() == 1

# Generated at 2022-06-25 04:24:41.781161
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml == _safe_load)



# Generated at 2022-06-25 04:24:53.027290
# Unit test for function from_yaml
def test_from_yaml():
    ansible_input = "---\n- hosts: localhost\n  connection: local\n  gather_facts: false\n  tasks:\n  - name: Ensure a specified port is open\n    firewalld:\n      service: http\n      port: 8080\n      permanent: true\n      state: enabled\n      immediate: yes"
    ansible_expected = [{'tasks':[{'name':'Ensure a specified port is open','firewalld':{'service':'http','port':8080,'permanent':True,'state':'enabled','immediate':True}}],'gather_facts':False,'connection':'local','hosts':'localhost'}]

    ansible_output = from_yaml(ansible_input)
    #assert ansible_output == ansible_expected

# Generated at 2022-06-25 04:24:53.713907
# Unit test for function from_yaml
def test_from_yaml():
    assert False


# Generated at 2022-06-25 04:25:06.869494
# Unit test for function from_yaml
def test_from_yaml():
    data_dict = {u'hello': u'world'}
    data_yaml = '{hello: world}'
    data_json = b'{\n  "hello": "world"\n}'
    parsed = from_yaml(data_yaml)
    assert parsed == data_dict
    parsed = from_yaml(data_json)
    assert parsed == data_dict
    try:
        from_yaml(data_json, json_only=True)
    except AnsibleParserError:
        return
    assert False, "Should have thrown an exception"

# Generated at 2022-06-25 04:25:08.083677
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 04:25:19.133000
# Unit test for function from_yaml
def test_from_yaml():
    assert (from_yaml(b'moon') == 'moon')
    assert (from_yaml(b'42') == 42)
    assert (from_yaml(b'3.14') == 3.14)
    assert (from_yaml(b'true') == True)
    assert (from_yaml(b'null') == None)
    assert (from_yaml(b'[1,2,3,4]') == [1, 2, 3, 4])
    assert (from_yaml(b'[1, null, 2.3, false, ["a", "b"]]') == [1, None, 2.3, False, ["a", "b"]])

# Generated at 2022-06-25 04:25:30.305837
# Unit test for function from_yaml
def test_from_yaml():
    #
    # Test empty bytes
    #
    bytes_0 = b''
    var_0 = from_yaml(bytes_0)
    assert var_0 == '', 'Empty bytes did not return expected value'

    # Test empty string
    string_0 = ''
    var_0 = from_yaml(string_0)
    assert var_0 == '', 'Empty string did not return expected value'

    # Test bytes.
    bytes_1 = b'{}'
    var_1 = from_yaml(bytes_1)
    assert var_1 == {}, 'Byte did not return expected value'

    # Test bytes with no digits
    bytes_2 = b'{ "a" : "a" }'
    var_2 = from_yaml(bytes_2)

# Generated at 2022-06-25 04:25:39.449915
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xdaHi\x86\x01\x19\x04\x00\x01\x00\x00\x00\x00\x00\x00\x19\x95\x00\x01\x00\x00\x00\x01\xf4\x03\x1d\x04\x19\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x06'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:25:44.194080
# Unit test for function from_yaml
def test_from_yaml():
    # Case 0
    try:
        test_case_0()
    except Exception as err:
        assert False, "Unexpected exception raised: {0}".format(err)

test_from_yaml()

# Generated at 2022-06-25 04:25:47.059431
# Unit test for function from_yaml
def test_from_yaml():
    # Cases are ordered by last modified date, newest first
    test_case_0()

if __name__ == '__main__':
    # Unit test execution
    test_from_yaml()

# Generated at 2022-06-25 04:25:47.898372
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:25:52.686812
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:25:58.290734
# Unit test for function from_yaml
def test_from_yaml():
    # Test call to function
    assert bytes == type(test_case_0)

if __name__ == "__main__":
    # Test calls to function
    test_from_yaml()

# Generated at 2022-06-25 04:26:03.806355
# Unit test for function from_yaml
def test_from_yaml():
    # Test case for from_yaml
    test_case_0()


# Generated at 2022-06-25 04:26:09.829715
# Unit test for function from_yaml
def test_from_yaml():
    # Test with invalid JSON
    try:
        test_case_0()
    except AnsibleParserError as e:
        assert e.message == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n'
        assert isinstance(e.orig_exc, YAMLError)
    else:
        assert False

# Generated at 2022-06-25 04:26:10.700238
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:26:17.008602
# Unit test for function from_yaml
def test_from_yaml():
    json_data = "{}"
    yaml_data = '''
        - hosts: all
          tasks:
            - name: test
              debug:
                msg: Hello world
    '''
    # Testing JSON
    assert from_yaml(json_data) == {}
    # Testing YAML
    assert from_yaml(yaml_data) == [{'hosts': 'all', 'tasks': [{'debug': {'msg': 'Hello world'}, 'name': 'test'}]}]
    # Testing non-JSON, non-YAML
    assert from_yaml('123abc') == '123abc'

# Generated at 2022-06-25 04:26:27.271041
# Unit test for function from_yaml
def test_from_yaml():
    a = from_yaml(b'---\n')
    assert expect_equal(a, {})

    a = from_yaml(b'{}')
    assert expect_equal(a, {})

    a = from_yaml(b'---\n- A\n- B\n')
    assert expect_equal(a, ['A', 'B'])

    a = from_yaml(b'---\n- 1\n- 2\n')
    assert expect_equal(a, [1, 2])

    a = from_yaml(b'---\nkey1: value1\nkey2: value2\n')
    assert expect_equal(a, {'key1': 'value1', 'key2': 'value2'})


# Generated at 2022-06-25 04:26:32.235521
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    assert from_yaml(bytes_0) == True

# Generated at 2022-06-25 04:26:38.519411
# Unit test for function from_yaml
def test_from_yaml():
    b = b'Hello'
    assert from_yaml(b) == {'Hello': None}
    assert from_yaml(b, json_only=True) == b'Hello'
    b = b'Hello\n'
    assert from_yaml(b) == {'Hello': None}
    assert from_yaml(b, json_only=True) == b'Hello\n'
    b = b'{"Hello": "World"}'
    assert from_yaml(b) == {'Hello': 'World'}
    assert from_yaml(b, json_only=True) == {'Hello': 'World'}
    b = b'["Hello", "World"]'
    assert from_yaml(b) == ['Hello', 'World']

# Generated at 2022-06-25 04:26:41.922689
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml(b'---\n- hosts: localhost\n  gather_facts: no\n  tasks:\n  - debug:\n      msg: hogehoge\n', b'<string>', False, None, False))


# Generated at 2022-06-25 04:26:47.963275
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:50.783784
# Unit test for function from_yaml
def test_from_yaml():
    print('Running test for from_yaml')
    test_case_0()

# Collect tests into test suite
from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-25 04:27:10.513966
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = "'x'"
    var_0 = from_yaml(bytes_0)

    # assert var_0 == 'x'

    bytes_1 = u"'\""
    var_1 = from_yaml(bytes_1)

    # assert var_1 == '"'

    bytes_2 = "'\"'"
    var_2 = from_yaml(bytes_2)
    # assert var_2 == '"'

    bytes_3 = '\'"\''
    var_3 = from_yaml(bytes_3)
    # assert var_3 == '"'

    bytes_4 = '"\'"'
    var_4 = from_yaml(bytes_4)
    # assert var_4 == '\''

    bytes_5 = "'\\\''"

# Generated at 2022-06-25 04:27:17.954754
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    my_loader = DataLoader()
    def load_yaml(my_content):
        return from_yaml(data=my_content,
                         file_name='<string>',
                         show_content=True)

    def assert_type(my_content, my_type):
        assert isinstance(load_yaml(my_content), my_type), \
            "for data: '%s', expected: %s, got: %s" \
            % (my_content, my_type, type(load_yaml(my_content)))

    def assert_content(my_content, my_result):
        assert load_yaml(my_content)

# Generated at 2022-06-25 04:27:29.422677
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:30.844838
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 04:27:33.771216
# Unit test for function from_yaml
def test_from_yaml():
    a = from_yaml('{"hello": "world"}')
    assert a == {'hello': 'world'}

# Generated at 2022-06-25 04:27:42.808425
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:53.077086
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('{}')
    except AnsibleParserError:
        assert False, "Unable to parse valid JSON"

    try:
        from_yaml('a: {}')
    except AnsibleParserError:
        assert False, "Unable to parse valid YAML"

    try:
        from_yaml('wxyz: []')
    except AnsibleParserError:
        assert False, "Unable to parse valid YAML"

    try:
        from_yaml('\xde\xad\xbe\xef')
    except AnsibleParserError:
        pass
    else:
        assert False, "Able to parse invalid JSON"

    try:
        from_yaml('!@#$%^&*()')
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 04:27:59.844327
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xeb\'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13'
    var_0 = from_yaml(bytes_0)
    assert var_0 == '#!#'
    assert var_0 != '#!#'
    return (var_0, )

if __name__ == "__main__":

    test_0 = test_case_0()

# Generated at 2022-06-25 04:28:07.533959
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:08.892952
# Unit test for function from_yaml
def test_from_yaml():
    assert True

test_case_0()

# Generated at 2022-06-25 04:28:29.111002
# Unit test for function from_yaml
def test_from_yaml():
    assert 0 == from_yaml(bytes(0))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:41.726901
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:47.591339
# Unit test for function from_yaml
def test_from_yaml():
    test_file = open("test_yaml.txt", "r")
    lines = test_file.readlines()
    
    yaml_str = lines[0]
    var_0 = from_yaml(yaml_str)
 
    print(var_0)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:48.610421
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:28:58.074806
# Unit test for function from_yaml
def test_from_yaml():
    assert True



# This is how you would normally write the above test case.
# def test():
#     test_case_0()

# Error messages:
#   File "./ansible_module_from_yaml.py", line 95, in test_from_yaml
#     test_case_0()
#   File "./ansible_module_from_yaml.py", line 60, in test_case_0
#     var_0 = from_yaml(bytes_0)
#   File "./ansible_module_from_yaml.py", line 72, in from_yaml
#     new_data = json.loads(data, cls=AnsibleJSONDecoder)
#   File "/usr/lib/python3.7/json/__init__.py", line 359, in loads
#     return

# Generated at 2022-06-25 04:29:10.663181
# Unit test for function from_yaml
def test_from_yaml():
    # This is a random data from a binary file.
    # The script pointed the data as a JSON or YAML so it's a good test case.
    # (You can use the function in the comment to generate a new test case.)
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"

    # The data is a JSON and the parser should handle it correctly.
    assert from_yaml(bytes_0) == {}


if __name__ == '__main__':
    # We use the following function to generate a random binary test data.
    def get_random_bytes(size):
        return bytes(random.randint(0, 255) for _ in range(size))

    import random
   

# Generated at 2022-06-25 04:29:14.515756
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


# Generated at 2022-06-25 04:29:16.240191
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None

# vim: et:sta:bs=2:sw=4:

# Generated at 2022-06-25 04:29:19.122494
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-25 04:29:21.806116
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("{ }") == {}
    assert from_yaml("hello") == "hello"
    assert from_yaml("True") == True


# Generated at 2022-06-25 04:30:09.551128
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("nope_not_a_file", file_name='/dev/null')
    assert from_yaml("nope_not_a_file", file_name='/dev/null', show_content=False)
    assert from_yaml("nope_not_a_file", file_name='/dev/null', show_content=True)
    assert from_yaml("nope_not_a_file", file_name='/dev/null', show_content=True, vault_secrets=None)
    assert from_yaml("nope_not_a_file", file_name='/dev/null', show_content=True, vault_secrets=None, json_only=False)


# Generated at 2022-06-25 04:30:17.201172
# Unit test for function from_yaml
def test_from_yaml():

    # from_yaml with correct args
    file_path = 'file_path'
    assert from_yaml('data', file_name=file_path)

    # from_yaml with incorrect args
    with pytest.raises(AnsibleParserError):
        from_yaml(5, file_name='file_name')

# Generated at 2022-06-25 04:30:21.846730
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing',
          'test_case_0')
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:30:30.068762
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    assert from_yaml('foo: bar', show_content=False, file_name='<foo>', json_only=False, vault_secrets=None) == {'foo': 'bar'}
    try:
        from_yaml('foo: bar', show_content=False, file_name='<foo>', json_only=True, vault_secrets=None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError

    try:
        from_yaml('foo: bar', show_content=False, file_name='<foo>', json_only=False, vault_secrets=None)
    except AssertionError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-25 04:30:40.750709
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\xac\x19\x8d\x19\xef\xe1\xeb\x8a\x96\xab\xa2\xbb\xc8\xe2'
    var_1 = from_yaml(bytes_1)

# Generated at 2022-06-25 04:30:41.548682
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True



# Generated at 2022-06-25 04:30:48.589436
# Unit test for function from_yaml
def test_from_yaml():
    import optparse
    import glob
    import sys
    import os
    import errno
    import subprocess

    # Hardcoded testcase values
    testcase_list = [
        {
            "file": "testcase_0",
            "bytes": b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
        }
    ]

    test_file_list = glob.glob(os.path.dirname(os.path.realpath(__file__)) + "/testcases/*")


# Generated at 2022-06-25 04:30:58.005586
# Unit test for function from_yaml
def test_from_yaml():
    import datetime
    from dateutil.tz import tzutc
    from ansible.module_utils.common.collections import is_sequence

    # YAML -> JSON -> Python test
    assert from_yaml('a') == 'a'
    assert from_yaml('a:') == {'a': None}
    assert from_yaml('a: b') == {'a': 'b'}
    assert from_yaml('a: b\n: c') == {'a': 'b', 'c': None}
    assert from_yaml('a: b\n: c\n: d') == {'a': 'b', 'c': None, 'd': None}

# Generated at 2022-06-25 04:31:00.543180
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"\xeb'\xdeh\xdb<\xcb\x00\xdewmi\xe6\xd0\xc94\xab:\xce\x13"
    var_0 = from_yaml(bytes_0)

if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:31:07.660517
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True


# Main for testing
if __name__ == '__main__':
    print(test_case_0())
    print(test_from_yaml())


#       0 '\xeb'                                                                      eb
#       1 "'"                                                                         27
#       2 '\xde'                                                                      de
#       3 'h'                                                                         68
#       4 '\xdb'                                                                      db
#       5 '<'                                                                         3c
#       6 '\xcb'                                                                      cb
#       7 '\x00'                                                                      00
#       8 '\xde'                                                                      de
#       9 'w'                                                                         77
#      10 'm'                                                                         6d
#      11 'i'                                